

# Generated at 2022-06-21 18:41:51.913400
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class DummyClass:
        def __init__(self):
            self.name = None

    class DummyClass2:
        def __init__(self):
            self.name = None

    dummy_node = DummyClass()
    dummy_node2 = DummyClass2()
    dummy_node2.name = "dummy name"

    dummy_dict = {"name": "dummy value"}

    def dummy_generic_visit():
        return dummy_node2

    def dummy_replace_field_or_node():
        return dummy_node2

    pattern_instance = VariablesReplacer(dummy_dict)

    pattern_instance.generic_visit = dummy_generic_visit
    pattern_instance._replace_field_or_node = dummy_replace_field_or_node


# Generated at 2022-06-21 18:42:00.501435
# Unit test for function let
def test_let():
    @snippet
    def fn():
        let(x)
        x += 1
        y = 1

    assert fn.get_body() == [
        ast.Assign(
            targets=[
                ast.Name(id='_py_backwards_x_0', ctx=ast.Store())
            ],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1))),
        ast.Assign(
            targets=[
                ast.Name(id='y', ctx=ast.Store())
            ],
            value=ast.Num(n=1))
    ]



# Generated at 2022-06-21 18:42:03.671352
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    actual = ast.parse("print(x)")
    actual = VariablesReplacer.replace(actual, variables={'x': 'y'})
    assert 'print(y)' == ast.unparse(actual)



# Generated at 2022-06-21 18:42:07.930692
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: 1).get_body(a=2, b=3) == [ast.Assign([ast.Name(id='_py_backwards_a_0', ctx=ast.Store())], ast.Num(n=1))]

# Generated at 2022-06-21 18:42:19.815552
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from . import tree
    ext_vars = {'site': '_py_backwards_site_0'}
    tree1 = ast.parse("import site")
    tree2 = ast.parse("from site import foo")
    tree3 = ast.parse("from site import bar as baz")
    tree.extend_tree(tree1, ext_vars)
    tree.extend_tree(tree2, ext_vars)
    tree.extend_tree(tree3, ext_vars)

    vari = VariablesReplacer.replace(tree1, ext_vars)
    assert vari.body[0].module == ext_vars['site']

    vari = VariablesReplacer.replace(tree2, ext_vars)
    assert vari.body[0].module == ext_vars['site']

    vari

# Generated at 2022-06-21 18:42:30.213342
# Unit test for function extend
def test_extend():
    def foo():
        extend(vars2)
        print(x,y)
    vars2 = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                         value=ast.Constant(value=1)),
             ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                         value=ast.Constant(value=2))]
    assert snippet(foo).get_body(vars2=vars2) == vars2 + [ast.Print(
        values=[ast.Name(id='x', ctx=ast.Load()), ast.Name(id='y', ctx=ast.Load())],
        dest=None, nl=True)]

# Generated at 2022-06-21 18:42:31.237268
# Unit test for function find_variables

# Generated at 2022-06-21 18:42:42.669146
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import_node = ast.ImportFrom(
        level=0,
        module='foo.bar',
        names=[ast.alias(
            name='a',
            asname='b'
        )]
    )
    variables = {'b': 'coderdojowarrington'}

    class TestVisitor(VariablesReplacer):
        def visit_ImportFrom(self, node):
            node = VariablesReplacer.visit_ImportFrom(self, node)
            for alias in node.names:
                alias = self.visit_alias(alias, node)
                alias = self.visit(alias)
                alias.name = self._replace_module(alias.name)
                if alias.asname in self._variables:
                    alias.asname = self._variables[alias.asname]

            return node

   

# Generated at 2022-06-21 18:42:46.016701
# Unit test for function extend_tree

# Generated at 2022-06-21 18:42:56.956983
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    def testcase(i, o):
        import ast
        import re
        import astunparse, ast
        import ast
        p = ast.parse(i)
        v = VariablesReplacer.replace(p, {'foo': 'bar'})
        return re.sub(r'\n', '', astunparse.unparse(p).strip()) == o


# Generated at 2022-06-21 18:43:01.341729
# Unit test for function extend_tree

# Generated at 2022-06-21 18:43:08.038730
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    node = ast.Name(id='_py_backwards_x_0', ctx='Load')
    tree = ast.parse('1')
    variables = {
        '_py_backwards_x_0': 'x'
    }
    new_node = VariablesReplacer.replace(node, variables)
    assert new_node.id == 'x'

# Generated at 2022-06-21 18:43:18.648942
# Unit test for constructor of class snippet
def test_snippet():
    x = 1
    y = 2
    assert snippet(lambda a, b: let(a)).get_body(a=x, b=y) == [ast.Expr(value=ast.Call(func=ast.Name(id='let', ctx=ast.Load()), args=[ast.Name(id='a', ctx=ast.Load())], keywords=[], starargs=None, kwargs=None)), ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1)), ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())], value=ast.Num(n=2))]

# Generated at 2022-06-21 18:43:26.298757
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class_ = ast.ClassDef(name='class_', bases=[], body=[], decorator_list=[], keywords=[])
    alias = ast.alias(name='alias', asname='asname', module=None)
    arguments_ = ast.arguments(args=[], vararg=None, kwarg=None, defaults=[])
    arguments = ast.arguments(args=[], vararg='vararg', kwarg='kwarg', defaults=[])
    keyword = ast.keyword(arg='arg', value=None)
    arg = ast.arg(arg='arg', annotation=None)
    function_def = ast.FunctionDef(name='function_def', args=arguments, body=[], decorator_list=[], returns=None)
    name = ast.Name(id='name', ctx=None)

# Generated at 2022-06-21 18:43:29.296963
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    x = 1
    import ast
    import py_backwards.tree as py_backwards_tree
    import ast
    import py_backwards.tree as py_backwards_tree
    assert x == 1

# Generated at 2022-06-21 18:43:31.114793
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer({"var": "new_var"})._variables == {"var": "new_var"}

# Generated at 2022-06-21 18:43:39.323709
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = "let(x)\nx += 1"
    snippet_instance = snippet(lambda : None)
    tree_body = snippet_instance.get_body()
    assert len(tree_body) == 1
    assert isinstance(tree_body[0], ast.AugAssign)
    assert tree_body[0].value.n == 1
    assert tree_body[0].target.id == '_py_backwards_x_0'
    assert tree_body[0].op.__class__ == ast.Add

# Generated at 2022-06-21 18:43:49.621924
# Unit test for function extend
def test_extend():
    tree = ast.parse("""extend(vars)
print(x, y)
""")

    vars = [ast.parse("""x = 1
x = 2""").body]

    extend_tree(tree, {'vars': vars})

    # print(ast.dump(tree))
    assert ast.dump(tree) == """(Module ()
  (Print (Name (id='x'), Name (id='y'), newline=True))
  (Assign (targets=[(Name (id='x', ctx=Store()))]) (value=(Num (n=1))))
  (Assign (targets=[(Name (id='x', ctx=Store()))]) (value=(Num (n=2)))))"""

# Generated at 2022-06-21 18:43:58.354541
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
	from .find_variables import test_find_variables
	from .helpers import get_source
	from src.helpers import VariablesGenerator
	from src.sym_tab import SymbolTable
	from src.tree import find
	from src.variables import find_variables
	from src.variables import VariablesReplacer
	from src.variables import extend_tree
	from src.variables import Variable

	tree = test_find_variables()
	source = get_source(test_find_variables)

	names = find_variables(tree)
	variables = {name: VariablesGenerator.generate(name) for name in names}


	for node in find(tree, ast.Name):
		if node.id in variables:
			node.id = variables[node.id]




# Generated at 2022-06-21 18:44:10.031670
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    source = '''
    class Foo(object):
        def __init__(self, a):
            self.a = a
    class Bar(Foo):
        c = self.a
    '''
    tree = ast.parse(source)
    variables = {'foo': '_py_backwards_foo_0', 'bar': '_py_backwards_bar_0'}
    VariablesReplacer.replace(tree, variables)
    expected_code = '''
    class _py_backwards_foo_0(object):
        def __init__(self, a):
            self.a = a
    class _py_backwards_bar_0(_py_backwards_foo_0):
        c = self.a
    '''

# Generated at 2022-06-21 18:44:14.702138
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:44:17.372736
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse(
        """def f():
            let(x)
            let(y)
            """
    ))) == ['x', 'y']

# Generated at 2022-06-21 18:44:20.254686
# Unit test for function find_variables
def test_find_variables():
    source = """
        let(a)
        let(b)
        a = 1
    """
    tree = ast.parse(source)
    assert find_variables(tree) == {'a', 'b'}



# Generated at 2022-06-21 18:44:27.865252
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import inspect
    import astunparse
    import ast

    class TestClass():
        class_var = 1

        def method_one(self):
            return 2

        def method_two(self, arg):
            return arg

    test_class = TestClass()

    def test_func():
        pass

    def test_snippet():
        extend(test_class)
        x = TestClass.class_var
        y = TestClass.method_one()
        z = TestClass.method_two(x)
        let(x)
        let(y)
        let(z)

    test_func_source = inspect.getsource(test_func)
    test_snippet_source = inspect.getsource(test_snippet)

# Generated at 2022-06-21 18:44:35.203139
# Unit test for function let
def test_let():
    @snippet
    def fn(x):
        let(y)
        return x + y

    x = ast.Name(id='x', ctx=ast.Load())
    y = ast.Name(id='y', ctx=ast.Load())
    ast_y = ast.Name(id='y', ctx=ast.Store())
    body = fn.get_body(y=ast_y)
    assert body == [ast.Assign(targets=[y], value=ast.BinOp(left=x, op=ast.Add(), right=y))]



# Generated at 2022-06-21 18:44:45.930735
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source = '''
a = 1
a.attr
'''
    tree = ast.parse(source)
    node = find(tree, ast.Name).__next__()
    assert node.id == 'a'
    replacer = VariablesReplacer({'a': 'b'})
    result = replacer.visit_Name(node)
    assert result.id == 'b'
    node = find(tree, ast.Name).__next__()
    assert node.id == 'a'
    node = find(tree, ast.Name).__next__()
    assert node.id == 'a'
    result = replacer.visit_Name(node)
    assert result.id == 'a'
    assert result.attr == 'attr'


# Generated at 2022-06-21 18:44:52.867019
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    print("test_VariablesReplacer_visit_alias()")
    from .testing import Executor
    from .testing import TestCase

    with TestCase(
            globals(), "VariablesReplacer",
            (
                ('test_visit_alias', lambda: VariablesReplacer.visit_alias(
                    ast.alias('a', 'b'), {}))
            ), Executor
    ) as run_test:
        run_test()



# Generated at 2022-06-21 18:45:00.135460
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars); print(x)")
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Constant(value=1))]})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Constant(value=1)), print(x)])'

# Generated at 2022-06-21 18:45:06.367284
# Unit test for function let
def test_let():
    import unittest

    @snippet
    def fn():
        let(x)
        let(y)
        print(x + y)

    class TestSnippet(unittest.TestCase):
        def test_fn(self):
            blocks = fn.get_body()
            self.assertEqual(len(blocks), 1)

    unittest.main()

# Generated at 2022-06-21 18:45:16.582513
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class_def = ast.ClassDef(name='Class',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             body=[ast.FunctionDef(name='method', args=ast.arguments(args=[ast.arg(arg='self', annotation=None)],
                                                                                     posonlyargs=[],
                                                                                     vararg=None,
                                                                                     kwonlyargs=[],
                                                                                     kw_defaults=[],
                                                                                     kwarg=None,
                                                                                     defaults=[]),
                                                    body=[ast.Pass()],
                                                    decorator_list=[],
                                                    returns=None)],
                             decorator_list=[])
    variables = {'Class': 'NewClass'}
    class_def = Vari

# Generated at 2022-06-21 18:45:24.331201
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse("""
      def fn():
          pass
    """)
    tree = VariablesReplacer.replace(tree, {'fn': 'new_name'})
    source = ast.fix_missing_locations(tree).body[0].name
    assert(source == 'new_name')



# Generated at 2022-06-21 18:45:27.731244
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class X: pass
    node = ast.parse('class X:\n    pass').body[0]
    variables = {'X': X}
    VariablesReplacer.replace(node, variables)
    assert type(node) == type(ast.parse('class Y:\n    pass').body[0])

# Generated at 2022-06-21 18:45:34.864446
# Unit test for function extend_tree
def test_extend_tree():
    class Assign:
        def __init__(self, name, value):
            self.name = name
            self.value = value

    assign1 = Assign('x', 1)
    assign2 = Assign('x', 2)
    tree = ast.parse('extend(vars)\nprint(x)')
    extend_tree(tree, {'vars': [assign1, assign2]})
    assert get_source(tree) == 'x = 1\nx = 2\nprint(x)'

# Generated at 2022-06-21 18:45:41.070847
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    test_str = "with open('test.txt', 'r') as f:"
    tree = ast.parse(test_str)
    tree = VariablesReplacer.replace(tree, {'f': 'f1'})
    tree_str = ast.unparse(tree).strip()
    expected_str = "with open('test.txt', 'r') as f1:"
    assert tree_str == expected_str

# Generated at 2022-06-21 18:45:45.875526
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    source = "def foo(x, y, z):\n  pass"
    tree = ast.parse(source)
    variables = {'x': 'foo'}
    assert get_source(tree) == source, get_source(tree)
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == "def foo(foo, y, z):\n  pass", get_source(tree)



# Generated at 2022-06-21 18:45:47.350478
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class X:
        pass
    assert isinstance(X(), X)

# Generated at 2022-06-21 18:45:48.291141
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-21 18:45:55.983080
# Unit test for function let
def test_let():
    @snippet
    def foo(x: str, y: str) -> None:
        let(x)
        x += y

    assert [x.s + ' += ' + y.s for x, y in zip(('_py_backwards_x_0', '_py_backwards_x_1'), ('a', 'b'))] == [
        str(node).strip() for node in foo.get_body(x=ast.Name('a', ast.Load()), y=ast.Name('b', ast.Load()))
    ]

# Generated at 2022-06-21 18:46:05.539296
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def add_one_to_x(x: int) -> None:
        let(x)
        x += 1

    @snippet
    def add_one_to_x_and_y(x: int, y: int) -> None:
        let(x)
        x += 1
        y += 1

    @snippet
    def extend_with_x_and_y(vars: List[ast.AST]) -> None:
        extend(vars)
        print(x, y)


# Generated at 2022-06-21 18:46:13.940023
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import parse_code
    source = """import example.module as example"""
    tree = parse_code(source)
    import_from_node = tree.body[0]
    assert isinstance(import_from_node, ast.ImportFrom)
    assert import_from_node.module == 'example.module'
    assert import_from_node.names[0].name == 'module'
    assert import_from_node.names[0].asname == 'example'
    variables = {'example': 'another_example'}
    tree = VariablesReplacer.replace(tree, variables)
    import_from_node = tree.body[0]
    assert isinstance(import_from_node, ast.ImportFrom)
    assert import_from_node.module == 'example.module'
    assert import_from_node

# Generated at 2022-06-21 18:46:29.103843
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def test_func(a, b, c=3, **d):
        pass
    tree = ast.parse(get_source(test_func))
    
    func_name = ast.Name(id=VariablesGenerator.generate('test_func'), ctx=ast.Load())
    variables = {'test_func': func_name, 'a': 'a', 'b': 'bb', 'c': 'ccc', 'd': 'dddd'}
    VariablesReplacer.replace(tree, variables)
    
    assert tree.body[0].name == '_py_backwards_test_func_0'
    assert tree.body[0].args.args[0].arg == 'a'
    assert tree.body[0].args.args[1].arg == 'bb'
    assert tree.body[0].args

# Generated at 2022-06-21 18:46:37.232415
# Unit test for function let
def test_let():
    """Testing function let"""
    def fn():  # pylint: disable=unused-variable
        let(a)
        return a

    snippet_fn = snippet(fn)
    body = snippet_fn.get_body()

    assert isinstance(body[0], ast.Return)
    assert isinstance(body[0].value, ast.Name)
    assert body[0].value.id.startswith('_py_backwards_a_')



# Generated at 2022-06-21 18:46:40.282221
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def ctor():
        a = 1
        return a

    assert ctor.get_body() == [ast.Return(value=ast.Num(n=1))]



# Generated at 2022-06-21 18:46:44.909121
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .tree import visit_alias
    from .get_source import get_source
    from .parse_ast import parse_ast

    code = 'from . import a'
    alias = parse_ast(code).body[0].names[0]
    repl = VariablesReplacer.replace(alias, {'.': '..'})
    assert get_source(repl) == 'from .. import a'

# Generated at 2022-06-21 18:46:56.624585
# Unit test for constructor of class snippet
def test_snippet():
    class A:
        x = 1
        y = 2
        a = snippet(lambda: let(x))
        b = snippet(lambda: let(y))
        c = snippet(lambda: extend(vars))

    assert A.a.get_body() == [ast.AugAssign(ast.Name(_py_backwards_x_0, ast.Load()), ast.Add(), ast.Num(1))]
    assert A.b.get_body() == [ast.AugAssign(ast.Name(_py_backwards_y_1, ast.Load()), ast.Add(), ast.Num(2))]

# Generated at 2022-06-21 18:47:07.895112
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class TestClass(object):
        def method(self, a, b):
            pass

    import_from = ast.ImportFrom(module='test_module',
                                 names=[ast.alias(name='TestClass', asname='T')],
                                 level=0)
    import_from.__class__ = ast.ImportFrom
    tree = ast.parse('''from test_module import TestClass as T
                                    from test_module import TestClass
                                    from test_module2 import TestClass as T2
                                    from test_module2 import TestClass as T3
                                    ''')
    variables = {'TestClass': import_from}
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-21 18:47:15.699860
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('''
        let(x)
        extend(vars)
        let(y)

        class A:
            let(z)

        def func(let(w)):
            let(s)

        x = 1
        y = 2
        z = 3

        try:
            x = 1
        except let(M):
            print(M)
        ''')


# Generated at 2022-06-21 18:47:25.289847
# Unit test for function let
def test_let():
    @snippet
    def test_snippet(x: int, y: ast.Name):
        let(y)
        print(x)
        print(y)


# Generated at 2022-06-21 18:47:31.587413
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def test(x):
        return x * x

    tree = ast.parse(get_source(test))
    node = tree.body[0]
    assert isinstance(node, ast.FunctionDef)
    node = VariablesReplacer.replace(node, {'x': '_x'})
    assert isinstance(node, ast.FunctionDef)
    assert node.name == '_x'

# Generated at 2022-06-21 18:47:36.197424
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.ImportFrom(
        module='unittest',
        names=[],
        level=0
    )
    variables = {
        'unittest': 'unittest_modified'
    }
    VariablesReplacer.replace(import_from, variables)
    assert import_from.module == 'unittest_modified'

# Generated at 2022-06-21 18:47:55.360958
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("""
    x = "a"
    x = "b"
    """)
    variables = {'x': '_py_backwards_x_0'}

    # to check if changing _variables in place
    assert variables == {'x': '_py_backwards_x_0'}

    VariablesReplacer.replace(tree, variables)

    visitor = ast.NodeVisitor()
    expected = """
    _py_backwards_x_0 = "a"
    _py_backwards_x_0 = "b"
    """
    assert visitor.visit(tree) == visitor.visit(ast.parse(expected))


# Generated at 2022-06-21 18:47:58.695416
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def fn():
        a = 2
        b = 3
        c = a + b

    assert len(fn.get_body()) == 3



# Generated at 2022-06-21 18:48:06.591711
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class MyNodeTransformer(VariablesReplacer):
        def visit_FunctionDef(self, node):
            node = self._replace_field_or_node(node, 'name')
            return self.generic_visit(node)  # type: ignore

    node = ast.parse('def a():\n  pass').body[0]
    variables = {'a': 'b'}
    transformed_node = MyNodeTransformer.replace(node, variables)
    assert transformed_node.name == 'b'



# Generated at 2022-06-21 18:48:10.854811
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    variable = VariablesGenerator.generate('variable')
    node = ast.alias(name='', asname=variable)
    visitor = VariablesReplacer({'variable': 'replaced_variable'})
    visitor.visit(node)
    assert node.asname == 'replaced_variable'



# Generated at 2022-06-21 18:48:20.504517
# Unit test for function let
def test_let():
    def test():
        let(x)
        x += 1
        y = 1
        
    tree = snippet(test).get_body()
    assert ast.dump(tree[0]) == 'Assign(targets=[Name(id=\'_py_backwards_x_0\', ctx=Store())], value=BinOp(left=Name(id=\'_py_backwards_x_0\', ctx=Load()), op=Add(), right=Num(n=1)))'
    assert ast.dump(tree[1]) == 'Assign(targets=[Name(id=\'y\', ctx=Store())], value=Num(n=1))'


# Generated at 2022-06-21 18:48:21.236472
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:48:26.187724
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = "import a.b.c as d"

    def wrap(code):
        return code

    tree = ast.parse(wrap(source))
    variables = {"a.b.c": "e.f.g"}
    VariablesReplacer.replace(tree, variables)

    expected = "import e.f.g as d"
    result = ast.unparse(tree)

    assert expected == result

# Generated at 2022-06-21 18:48:30.372260
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('''
        def foo():
            pass
    ''')

    VariablesReplacer.replace(tree, {'foo': 'bar'})

    assert get_source(tree) == 'def bar():\n    pass\n'

# Generated at 2022-06-21 18:48:37.591591
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # set environment
    input_module_name = 'module'
    import_from_node = ast.ImportFrom(module=input_module_name,
                                      names=[ast.alias(name='a', asname='b')], lineno=0, col_offset=0)
    variables = {input_module_name: 'module_1'}
    # call function
    res = VariablesReplacer.replace(import_from_node, variables)
    assert res.module == 'module_1'

# Generated at 2022-06-21 18:48:41.050870
# Unit test for method get_body of class snippet

# Generated at 2022-06-21 18:49:14.096201
# Unit test for function let
def test_let():
    source = 'let(x)\nx += 1\n'
    tree = ast.parse(source)

    variables = find_variables(tree)
    assert variables == {'x'}

    generated_vars = {name: VariablesGenerator.generate(name)
                      for name in variables}
    expected_tree = ast.parse('_py_backwards_x_1 += 1\n')
    replace_tree = VariablesReplacer.replace(tree, generated_vars)
    assert ast.dump(expected_tree) == ast.dump(replace_tree)



# Generated at 2022-06-21 18:49:23.505357
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_python_syntax_error():
        a = 1
        let(a)

    def snippet_python_syntax_error2():
        a = 1
        let(a)
        a += 1

    def snippet_python_syntax_error3():
        a = 1
        extend(a)

    import pytest

    with pytest.raises(SyntaxError):
        assert snippet(snippet_python_syntax_error).get_body()
    with pytest.raises(SyntaxError):
        assert snippet(snippet_python_syntax_error2).get_body()
    with pytest.raises(SyntaxError):
        assert snippet(snippet_python_syntax_error3).get_body()
    
    def snippet_python_syntax_error4():
        a

# Generated at 2022-06-21 18:49:28.128154
# Unit test for function let
def test_let():
    @snippet
    def snippet_dummy(x: int, y: int) -> int:
        let(x)
        x += y
        y += 2

    expected = ast.parse('x += y; y += 2;').body
    
    assert snippet_dummy.get_body(x=1, y=2) == expected



# Generated at 2022-06-21 18:49:34.192985
# Unit test for function find_variables
def test_find_variables():
    source = inspect.getsource(test_find_variables)
    tree = ast.parse(source)
    source = source.split('\n')
    variables = list(find_variables(tree))
    assert variables == ['x', 'y', 'vars']
    assert source[1] == 'x = 1'
    assert source[2] == 'y = 2'
    assert True



# Generated at 2022-06-21 18:49:42.965144
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import io
    import sys
    import ast as ast_module

    sys.stdout = io.StringIO()

    source = """
from test1 import a as test1_a, b as test1_b
from test2 import c
"""

    tree = ast_module.parse(source)
    variables = {
        'test1': 'test3',
        'test2': 'test4'
    }

    VariablesReplacer.replace(tree, variables)

    tree = ast_module.parse(source)
    tree.body[0].body = []
    test_module = ast_module.Module(body=tree.body)

    exec(compile(test_module, filename="<ast>", mode="exec"), {})


# Generated at 2022-06-21 18:49:47.970493
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("try:pass\nexcept Exception as e:pass")
    variables = {"e": ast.Name(id="e2", ctx=ast.Store())}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].handlers[0].name.id == "e2"

# Generated at 2022-06-21 18:49:59.201861
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class Test:

        def test(self, tree):
            for node in find(tree, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id == 'let':
                    parent, index = get_non_exp_parent_and_index(tree, node)
                    parent.body.pop(index) # type: ignore
                    yield node.args[0].id # type: ignore
    #    @classmethod
    #    def replace(cls, tree: T, variables: Dict[str, Variable]) -> T:
    #        """Replaces all variables with unique names."""
    #        inst = cls(variables)
    #        inst.visit(tree)
    #        return tree
    #    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.Function

# Generated at 2022-06-21 18:50:06.776305
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # Given
    import ast
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from lib.backwards import VariablesReplacer
    alias = ast.alias("name", "asname")
    variables = {'name': 'foobar', 
                 'asname': 'foobas'}

    # When
    result = VariablesReplacer.replace(alias, variables)

    # Then
    assert result.name == 'foobar'
    assert result.asname == 'foobas'

# Generated at 2022-06-21 18:50:11.466350
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('from a import b as c')
    VariablesReplacer.replace(tree, {'a': 'd'})
    assert tree.body[0].module == 'd'


# Unit tests for method visit_ImportFrom of class VariablesReplacer

# Generated at 2022-06-21 18:50:21.568933
# Unit test for function extend_tree
def test_extend_tree():
    from .helpers import parse

    src = """
    extend(vars)
    x += 1
    """

    node = parse(src)
    extend_tree(node, {'vars': [
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name('y', ast.Store())], ast.Num(2))
    ]})

    assert node.body[0].value.targets[0].id == 'x'
    assert node.body[0].value.value.n == 1
    assert node.body[1].value.targets[0].id == 'y'
    assert node.body[1].value.value.n == 2

# Generated at 2022-06-21 18:51:27.274211
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = 'from a.b.c import a'
    tree = ast.parse(source)
    replacer = VariablesReplacer({'a': 'x'})
    replacer.visit(tree)
    assert get_source(tree) == 'from x.b.c import a'



# Generated at 2022-06-21 18:51:33.126406
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class A:
        def __init__(self):
            self.x = 1

    inst = A()

    def f():
        nonlocal inst
        inst.x = 2

    tree = ast.parse(get_source(f))
    variables = {'inst': inst}  # type: ignore
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    tree_code = compile(tree, '', 'exec')
    ns = {}
    exec(tree_code, ns)

    assert ns['inst'].x == 2