

# Generated at 2022-06-21 18:41:57.025940
# Unit test for function find_variables
def test_find_variables():
    source = """
    def fn(x):
        x = let(x)
        y = let(y)
        z = z
        return z
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert set(variables) == {'x', 'y'}


# Generated at 2022-06-21 18:42:02.648847
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import pytest
    @snippet
    def test_function():
        let(x)
        from math import floor
        assert floor(x) == 0
    tree = ast.parse(get_source(test_function))
    variables = test_function._get_variables(tree, {})
    new_tree = VariablesReplacer.replace(tree, variables)
    import_node = new_tree.body[0].body[0]
    assert import_node.module == 'math'

# Generated at 2022-06-21 18:42:08.233923
# Unit test for function let
def test_let():
    @snippet
    def s():
        let(x)
        x += 1
        y = 2

    assert s.get_body() == [
        ast.AugAssign(target=ast.Name(id="_py_backwards_x_0", ctx=ast.Load()),
                      op=ast.Add(), value=ast.Num(1)),
        ast.Assign(targets=[ast.Name(id="y", ctx=ast.Store())],
                   value=ast.Num(2))]



# Generated at 2022-06-21 18:42:20.026069
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import astor
    from .helpers import VariablesGenerator
    from .ast_node_replace import VariablesReplacer
    vg = VariablesGenerator()
    node = ast.parse("class_def(x, body=call(f, 1, 2, b=3, a=4)")
    node.body[0].keywords[0].arg = 'z'
    assert astor.to_source(node) == 'class_def(x, body=call(f, 1, 2, b=3, a=4))'
    node = VariablesReplacer.replace(node, {'z': vg.generate('z')})

# Generated at 2022-06-21 18:42:26.630494
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.parse('import sys\n')
    assert get_source(import_from) == ',\n'
    import_from = import_from.body[0]
    variables_replacer = VariablesReplacer(variables={'sys': 'test2'})
    import_from = variables_replacer.visit_ImportFrom(import_from)
    assert get_source(import_from) == ',\n'



# Generated at 2022-06-21 18:42:30.381397
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    ast_tree = ast.parse("a")
    variables={'a':'b'}
    inst = VariablesReplacer(variables)
    node = inst.visit(ast_tree.body[0])
    assert node.id == 'b'


# Generated at 2022-06-21 18:42:33.758462
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars);print(x)')
    new_tree = ast.parse('x=1;x=2;print(x)')
    extend_tree(tree, {'vars': new_tree.body})

    assert get_source(tree) == 'x = 1; x = 2; print(x)'

# Generated at 2022-06-21 18:42:34.209948
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-21 18:42:45.183084
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import typing  
    l = list()
    node = ast.Attribute(value = ast.Attribute( value = ast.Name(id = "typing", ctx=ast.Load()),  
                                                attr= "List",
                                                ctx= ast.Load()),
                                                attr = "append",
                                                ctx = ast.Load())
    assert isinstance(node, ast.Attribute)
    assert isinstance(node.value, ast.Attribute)
    assert isinstance(node.value.value, ast.Name)
    assert node.value.value.id == "typing"
    assert node.attr == "append"

    replacer = VariablesReplacer({})
    node = replacer.visit_Attribute(node)
    assert isinstance(node, ast.Attribute)

# Generated at 2022-06-21 18:42:56.212690
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = '''
    def f():
        x = 1
        def f2():
            return 1
        return x
    '''
    tree = ast.parse(source)
    s = snippet(f)
    variables = s._get_variables(tree, {})
    extend_tree(tree, variables)

# Generated at 2022-06-21 18:43:06.311297
# Unit test for function let
def test_let():
    @snippet
    def snaipet(a: int, b: int) -> int:
        let(x)
        x = a + b
        return x + 1


# Generated at 2022-06-21 18:43:11.015161
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    t = ast.parse('''
import ext2
ext2.Let(fn)
''')
    tree = VariablesReplacer.replace(t, {'fn': str()})
    source = ast.unparse(tree)
    assert source == '''
import ext2
fn2
'''

# Generated at 2022-06-21 18:43:20.179294
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    fn = snippet(lambda x: let(x) + x)
    body = fn.get_body()

    assert body == [ast.AnnAssign(target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()), annotation=None, value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()), op=ast.Add(), right=ast.Name(id='_py_backwards_x_0', ctx=ast.Load())), simple=1)]  # noqa



# Generated at 2022-06-21 18:43:27.930094
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class_def = ast.parse('class A: pass')
    alias = class_def.body[0].bases[0]
    var = ast.Name('a', ast.Load())
    alias.value = var
    replacer = VariablesReplacer.replace(alias, {'a': 'b'})
    assert(replacer.value.id == 'b')

# Generated at 2022-06-21 18:43:34.113463
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    module = ast.Module(
        body=[ast.ImportFrom(
            module='foo.bar',
            names=[
                ast.alias(
                    name='foo',
                    asname='bar'
                )
            ],
            level=0
        )]
    )
    variables = {
        'foo': 'baz',
        'bar': 'foo_bar'
    }
    VariablesReplacer.replace(module, variables)
    expected = ast.Module(
        body=[ast.ImportFrom(
            module='baz.foo_bar',
            names=[
                ast.alias(
                    name='baz.foo_bar',
                    asname='foo_bar'
                )
            ],
            level=0
        )]
    )
    assert module == expected

# Generated at 2022-06-21 18:43:37.767123
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def fn(x: int, y: int) -> int:
        return x + y

    body = fn.get_body(x=1, y=2)



# Generated at 2022-06-21 18:43:43.864043
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    source = """
    def foo(x, *args):
        ...
    """
    tree = ast.parse(source)
    expected_tree = ast.parse(source)
    variables = {
        'x': '_py_backwards_x_0',
        }
    inst = VariablesReplacer(variables)
    actual_tree = inst.visit(tree)
    assert ast.dump(actual_tree) == ast.dump(expected_tree)


# Generated at 2022-06-21 18:43:52.870532
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    try:
        1 + "a"
    except TypeError as e:
        #e_id = id(e)
        #print(e_id)
        pass
    #print(e)
    class A(ast.NodeVisitor):
        def __init__(self, _variables):
            self._variables = _variables
        def visit_ExceptHandler(self, node):
            node = node._replace_field_or_node(node, 'name')
            return self.generic_visit(node)
    #a = A(id(e))
    a = VariablesReplacer(id(e))

# Generated at 2022-06-21 18:43:58.425903
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('''
    def foo(a):
        pass
    ''')
    variables = {'a': ['b', 'c']}
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-21 18:44:10.075726
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import from_source
    from .tree import find, get_non_exp_parent_and_index, replace_at
    from .helpers import VariablesGenerator
    
    source = """from math import a, b as c"""
    tree: ast.AST = from_source(source)
    for node in find(tree, ast.alias):
        if node.name == 'a':
            replace_at(get_non_exp_parent_and_index(tree, node)[1],
                       get_non_exp_parent_and_index(tree, node)[0],
                       VariablesGenerator.generate(node))
    
    new_source = """from math import __py_backwards_0 as c"""
    new_tree: ast.AST = from_source(new_source)

# Generated at 2022-06-21 18:44:14.399627
# Unit test for function let

# Generated at 2022-06-21 18:44:23.470249
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def test_fn(x: int) -> int:
        let(x)
        x += 1
        let(y)
        y = 1
        return x + y

    body = test_fn.get_body()
    assert isinstance(body, list)
    for stmt in body:
        assert isinstance(stmt, ast.AST)

    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[0].target, ast.Name)
    assert body[0].target.id == '_py_backwards_x_0'

    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[1].targets[0], ast.Name)

# Generated at 2022-06-21 18:44:31.469176
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    tree = ast.parse("class MyClass:\n"
                     "  def my_method():\n"
                     "    pass\n")
    variables = {"MyClass": "MyClass2", "my_method": "my_method2"}

    inst = VariablesReplacer(variables)
    inst.visit(tree)
    print(ast.dump(tree))

    assert isinstance(tree.body[0].body[0], ast.FunctionDef)
    assert tree.body[0].body[0].name == "my_method2"

# Generated at 2022-06-21 18:44:35.071531
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('x = 1')
    variables = {'x': 'x'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert tree.body[0].targets[0].id == 'x'  # type: ignore



# Generated at 2022-06-21 18:44:41.923211
# Unit test for constructor of class snippet
def test_snippet():
    # noinspection PyUnusedLocal
    def func():
        let(x)
        x += 1
        y = 1

    res = snippet(func)
    body = res.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert body[0].value.value == 1
    assert body[1].value.value == 1

# Generated at 2022-06-21 18:44:43.401128
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-21 18:44:54.139119
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from . import reverse
    from .helpers import stringify
    var = '_py_backwards_var_0'

    code = stringify(reverse.increment_variables.get_body(var=var))
    assert code == f'{var} += 1'

    code = stringify(reverse.increment_variables.get_body(var=var, y='_py_backwards_y'))
    assert code == f'{var} += 1; y = 1'

    code = stringify(reverse.increment_variables.get_body(x='_py_backwards_x'))
    assert code == 'x += 1'

    extend_code = stringify(reverse.extended.get_body(vars=['x = 1', 'x = 2']))

# Generated at 2022-06-21 18:44:59.327772
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('''
        class Foo:
            def __str__(self):
                return 'Foo'
        
        foo = Foo()
        print(foo.__str__())
    ''')
    variables = {
        'foo': 'bar',
        'self': 'baz',
        'Foo': 'Qux',
    }
    VariablesReplacer.replace(tree, variables)

    source = ast.fix_missing_locations(tree)
    assert source == ast.parse('''
        class Qux:
            def __str__(baz):
                return 'Foo'
        
        bar = Qux()
        print(bar.__str__())
    ''')



# Generated at 2022-06-21 18:45:10.771071
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class TestClass(ast.NodeTransformer):
        def __init__(self, variables: Dict[str, Variable]):
            self._variables = variables

        def visit_Name(self, node: ast.Name) -> ast.Name:
            node = self._replace_field_or_node(node, 'id', True)
            return self.generic_visit(node) # type: ignore

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            node = self._replace_field_or_node(node, 'name')
            return self.generic_visit(node) # type: ignore

        def visit_Attribute(self, node: ast.Attribute) -> ast.Attribute:
            node = self._replace_field_or_node(node, 'name')
            return self.generic_

# Generated at 2022-06-21 18:45:22.088188
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: int, y: int) -> int:
        let(z)
        return x + y + z

    assert fn.get_body(x=1, y=2, z=3) == fn.get_body(x=1, y=2, z=3)
    assert fn.get_body(x=1, y=2, z=3) != fn.get_body(x=3, y=2, z=3)
    assert fn.get_body(x=1, y=2, z=3) != fn.get_body(x=1, y=4, z=3)
    assert fn.get_body(x=1, y=2, z=3) != fn.get_body(x=1, y=2, z=5)

    # import

# Generated at 2022-06-21 18:45:37.819132
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    input_string = "from module_name import one, two"
    input_tree = ast.parse(input_string)

    variables = {'module_name': 'replaced_module_name'}
    VariablesReplacer.replace(input_tree, variables)
    result = ast.dump(input_tree)
    assert result == "Module(body=[ImportFrom(module='replaced_module_name', names=[alias(name='one', asname=None), alias(name='two', asname=None)], level=0)], type_ignores=[])"  # noqa



# Generated at 2022-06-21 18:45:42.563089
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse('from importlib import reload')
    variables = {'reload': 'y_13'}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert tree.body[0].names[0].name == 'y_13'

# Unit tests for method visit_alias of class VariablesReplacer

# Generated at 2022-06-21 18:45:46.462966
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Test(ast.NodeVisitor):
        def visit_Name(self, node):
            return node

    tree = ast.parse('''
a = 1
b = a
c = 1
a += 1
    ''')

    VariablesReplacer.replace(tree, {'a': 'mm'})
    Test().visit(tree)

# Generated at 2022-06-21 18:45:51.796198
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(a)
    let(b)
    let(c)
""")
    variables = find_variables(tree)
    assert 'a' in variables
    assert 'b' in variables
    assert 'c' in variables
    assert len(variables) == 3



# Generated at 2022-06-21 18:45:58.137162
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class _Mock_Replacer(VariablesReplacer):
        def visit_Name(self, node):
            self.visit_Name_was_called = True
            return node
    
    variables = {"var": 1}
    replacer = _Mock_Replacer(variables)
    replacer.visit_Name(ast.Name("var"))
    assert replacer.visit_Name_was_called == True


# Generated at 2022-06-21 18:45:58.745465
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    pass

# Generated at 2022-06-21 18:46:04.473804
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    snip = snippet(lambda x, y: let(x) + x)
    assert snip.get_body(x=x, y=y) == [  # type: ignore
        ast.AugAssign(
            target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            op=ast.Add(),
            value=ast.Num(n=1),
        ),
    ]

# Generated at 2022-06-21 18:46:06.221037
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    x += 1
    '''
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-21 18:46:11.837711
# Unit test for function let
def test_let():
    def _test(x: int) -> None:
        let(x)
        x += 1

    body = snippet(_test).get_body()
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                         ast.Add(),
                                         ast.Num(1)))]



# Generated at 2022-06-21 18:46:15.863939
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = """import a, b, c"""
    tree = ast.parse(source)
    variables = {"a": 1, "b": 2}
    got = VariablesReplacer.replace(tree, variables)
    expected = """import 1, 2, c"""
    assert got.body[0] == ast.parse(expected).body[0]



# Generated at 2022-06-21 18:46:37.075901
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    node = ast.ExceptHandler(None, ast.Name("name", None), [], None)
    replacer = VariablesReplacer({
        "name": ast.Name("name_temp", None)
    })
    result = replacer.visit_ExceptHandler(node)
    assert result.name.id == "name_temp"


# Generated at 2022-06-21 18:46:42.735809
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = "try: a = 1 \nexcept Exception as e: print(e)"
    tree = ast.parse(source)
    variables = {'e': 'test'}
    expected_tree = ast.parse("try: a = 1 \nexcept Exception as test: print(test)")
    actual_tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(actual_tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 18:46:45.510123
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def foo(x, foo=foo):
        y = foo
        class Foo:
            pass
        baz = Foo()
    fn = snippet(foo)
    result = fn.get_body()
    assert len(result) == 5

# Generated at 2022-06-21 18:46:47.702409
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:46:58.382598
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    from .helpers import CallableGenerator
    from ast import ClassDef, Assign, Call
    cls = ClassDef(name="MyClass", body=[Assign(targets=[Call(
        func=Call(func=Call(func="Callable", args=[], keywords=[]),
                  args=[], keywords=[]), args=[], keywords=[])],
        value=Call(func=Call(func=CallableGenerator, args=[], keywords=[]),
                   args=[], keywords=[]))])
    tree = cls
    variables = {'Callable': CallableGenerator}
    instance = VariablesReplacer(variables)
    instance.visit(tree)
    assert tree.body[0].targets[0].func.func == CallableGenerator

# Generated at 2022-06-21 18:47:04.971574
# Unit test for function let
def test_let():
    assert snippet(lambda: let(x) == 5)().get_body() == ast.parse('_py_backwards_x_0 == 5').body
    assert snippet(lambda: let(x) == 5 or let(y) == 6)().get_body() == ast.parse('_py_backwards_x_0 == 5 or _py_backwards_y_1 == 6').body



# Generated at 2022-06-21 18:47:12.396783
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet(x):
        print(x)
        x **= 2

    snippet = snippet_class(snippet)
    body = snippet.get_body(x=2)

    assert isinstance(body, list)
    assert isinstance(body[0], ast.Print)
    assert isinstance(body[1], ast.AugAssign)

    assert isinstance(body[0].values[0], ast.Num)
    assert isinstance(body[1].value, ast.BinOp)
    assert body[0].values[0].n == 2



# Generated at 2022-06-21 18:47:20.488669
# Unit test for function extend_tree
def test_extend_tree():
    extend_tree(
        ast.parse("""
            extend(variables)
        """),
        {
            'variables': [
                ast.Assign(
                    targets=[ast.Name(id='x', ctx=ast.Store())],
                    value=ast.Num(n=1)
                ),
                ast.Assign(
                    targets=[ast.Name(id='x', ctx=ast.Store())],
                    value=ast.Num(n=2)
                )
            ]
        }
    )



# Generated at 2022-06-21 18:47:24.324647
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer.replace(
        ast.parse('a()'), {'a': 'b'}).body[0].value.func.id == 'b'

    assert VariablesReplacer.replace(
        ast.parse('a()'), {'a': 'a'}).body[0].value.func.id == 'a'



# Generated at 2022-06-21 18:47:31.681977
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('x.y = 1')
    variables = {'x': '_x'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Assign(targets=[Attribute(value=Name(id='_x', ctx=Load())," \
                              " attr='y', ctx=Store())], value=Num(n=1))"



# Generated at 2022-06-21 18:48:12.912107
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-21 18:48:20.730744
# Unit test for function let
def test_let():
    def snippet_fn():
        x, y = 1, 2
        let(y)
        y += 1
        return x, y


# Generated at 2022-06-21 18:48:23.423825
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("a.b = 1")
    tree = VariablesReplacer.replace(tree, {'a': 'c'})
    assert ast.dump(tree, annotate_fields=False) == "c.b = 1"



# Generated at 2022-06-21 18:48:27.372404
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    vr = VariablesReplacer({'__x': '__x'})
    kw = ast.keyword(
        arg='__x',
        value=ast.Num(n=1)
    )
    expected = ast.keyword(
        arg='__x',
        value=ast.Num(n=1)
    )
    result = vr.visit_keyword(kw)
    assert result == expected

# Generated at 2022-06-21 18:48:35.002693
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    # Test with keyword argument 'arg'
    class TestClass:
        def f(self, a):
            pass
    source = get_source(TestClass.f)
    tree = ast.parse(source)
    variables = {'a': "new_var"}
    VariablesReplacer.replace(tree, variables)
    args = tree.body[0].body[0].args
    assert args[0].arg == "new_var"
    assert args[0].annotation is None


# Generated at 2022-06-21 18:48:38.446102
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class TestClass(ast.NodeTransformer):
        def visit_alias(self, node):
            return node

    test_alias = ast.parse('''
from . import alias
''').body[0]
    TestClass().visit(test_alias)

# Generated at 2022-06-21 18:48:41.728768
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from func: x as y")
    variables = {"x": "z"}

    VariablesReplacer.replace(tree, variables)

    assert ast.dump(tree) == "ImportFrom(module='func', names=[alias(name='z', asname='y')], level=0)"

# Generated at 2022-06-21 18:48:50.713940
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():

    node_name = ast.Name(id='A', ctx=None)
    node_import_from = ast.ImportFrom(module='X.Y.Z', names=[node_name], level=3)

    node_expr = ast.Expr(value=node_import_from)
    node_body = [node_expr]
    node_module = ast.Module(body=node_body)

    print('In:')
    print(ast.dump(node_module))
    print('Out:')
    print(ast.dump(VariablesReplacer.replace(node_module, {'X.Y.Z': 'B'})))

# Generated at 2022-06-21 18:48:56.820196
# Unit test for function extend
def test_extend():
    tree = ast.parse('''
        extend(vars)
        print(x, y)
    ''')
    vars = [
        ast.Assign(
            targets = [ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == '''
        x = 1
        x = 2
        print(x, y)
    '''


# Generated at 2022-06-21 18:49:01.981644
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("def test_fn(a, b):pass").body[0]
    variables = {'a': 'new_a'}
    VariablesReplacer.replace(tree, variables)

    assert tree.args.args[0].id == 'new_a'



# Generated at 2022-06-21 18:50:09.702671
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = """
from test1 import a as b 
from test2 import * as *
from test3 import * as x
from test4 import *
from test5 import * as *
    """ 
    tree = ast.parse(source)
    variables = {'b': 'x'}
    tree = VariablesReplacer.replace(tree, variables) 
    assert get_source(tree) == """\
from test1 import a as x
from test2 import * as *
from test3 import * as x
from test4 import *
from test5 import * as *"""

# Generated at 2022-06-21 18:50:13.827032
# Unit test for function let
def test_let():
    def _test() -> ast.AST:
        let(x)
        x += 1
        y = 1
        return x

    assert _test() == ast.parse('_py_backwards_x_0 += 1').body[0]



# Generated at 2022-06-21 18:50:17.504095
# Unit test for function find_variables
def test_find_variables():
    source = '''
        def foo():
            def bar():
                let(x)
                x = 1
                y = 2
            return bar()
    '''
    assert sorted(find_variables(ast.parse(source))) == ['x']

# Generated at 2022-06-21 18:50:24.824281
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class test_VariablesGenerator_generate(VariablesReplacer):
        def visit_FunctionDef(self, node):
            return 'replaced'
    source = 'def hello():\n    pass\n'
    tree = ast.parse(source)
    replaced = test_VariablesGenerator_generate.replace(tree, {})
    assert isinstance(replaced, ast.AST)
    assert isinstance(replaced.body[0], str)
    assert replaced.body[0] == 'replaced'


# Generated at 2022-06-21 18:50:31.570032
# Unit test for function let
def test_let():
    @snippet
    def example():
        let(x)
        x += 1
        return x
    assert example.get_body() == [ast.Assign(
        targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
        value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                        op=ast.Add(),
                        right=ast.Num(n=1)))], [ast.Return(
        value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()))]



# Generated at 2022-06-21 18:50:35.388501
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('def x():\n    y(1, a=x)')
    VariablesReplacer.replace(tree, {'x': '_py_backwards_x'})
    assert get_source(tree) == 'def _py_backwards_x():\n    y(1, a=_py_backwards_x)'



# Generated at 2022-06-21 18:50:45.701778
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 10
    y = 200

    @snippet
    def f(a: int, b: int, **kwargs) -> int:
        let(x)
        let(y)
        extend(kwargs)
        x += a
        y += b
        return x + y
    body = f.get_body(x=x, y=y, kwargs={'z': 12})
    assert body[0].targets[0].id == 'x'
    assert body[0].value.id == 'a'
    assert body[1].targets[0].id == 'y'
    assert body[1].value.id == 'b'
    assert body[2].targets[0].id == 'x'
    assert body[2].value.value == 10 + 1

# Generated at 2022-06-21 18:50:49.977751
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    node = ast.Name(id="x", ctx=ast.Load())
    variables = {"x": "y"}
    result = VariablesReplacer(variables).visit_Name(node)
    assert isinstance(result, ast.Name)
    assert result.id == "y"

test_VariablesReplacer_visit_Name()


# Generated at 2022-06-21 18:50:56.666558
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert ast.dump(VariablesReplacer.replace(
        ast.parse("x.y", mode='eval'),
        {'x': 'z'}
    )) == 'Call(func=Name(id=z, ctx=Load()), args=[], keywords=[])'

    assert ast.dump(VariablesReplacer.replace(
        ast.parse("x.y", mode='eval'),
        {'x.y': 'z.w'}
    )) == 'Call(func=Attribute(value=Name(id=z, ctx=Load()), attr=w, ctx=Load()), args=[], keywords=[])'

# Generated at 2022-06-21 18:51:06.884008
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = "from abc import A, B as b"
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, {"A": "A_"})
    assert ast.dump(tree) == "ImportFrom(module='abc', names=[alias(name='A_', asname=None)], level=0)"
    tree = VariablesReplacer.replace(tree, {"A_": "A_1"})
    assert ast.dump(tree) == "ImportFrom(module='abc', names=[alias(name='A_1', asname=None)], level=0)"
    tree = VariablesReplacer.replace(tree, {"b": "b_"})