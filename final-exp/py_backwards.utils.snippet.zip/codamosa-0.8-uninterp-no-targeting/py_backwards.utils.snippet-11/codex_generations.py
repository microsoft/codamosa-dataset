

# Generated at 2022-06-21 18:41:44.238770
# Unit test for function let
def test_let():
    def function():
        let(x)
        x += 1
        return x

    context = {}
    exec(compile(snippet(function).get_body(), "", "exec"), context)
    assert sorted(context) == ['_py_backwards_x_0']



# Generated at 2022-06-21 18:41:49.961711
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.ImportFrom(module='module', names=[ast.alias(name='name', asname=None)])
    variables = {'module': 'new_module'}

    VariablesReplacer.replace(import_from, variables)
    assert import_from.module == 'new_module'

# Generated at 2022-06-21 18:41:51.020442
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: let(1))

# Generated at 2022-06-21 18:42:00.159773
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    just_Id = ast.parse("Id").body[0]
    from_nodes_with_fields = ast.parse("def x(): pass").body[0]
    from_node_with_fields_other_type = ast.parse("class x(): pass").body[0]
    from_arg_with_field = ast.parse("def x(y): pass").body[0]
    replace_import = ast.parse("from x import y").body[0]
    replace_alias = ast.parse("import x.y as z").body[0]
    replace_except_handler = ast.parse("except x: pass").body[0]
    replace_keyword = ast.parse("def x(**y): pass").body[0]


# Generated at 2022-06-21 18:42:01.489239
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    import astor

# Generated at 2022-06-21 18:42:07.088168
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class C:
        def f(self):
            return 1
    x = C()
    ast_node = ast.parse('x.f()')
    assert ast_node.body[0].value.value.id == 'x'
    assert ast_node.body[0].value.value.attr == 'f'
    VariablesReplacer.replace(ast_node, {'x': x})
    assert ast_node.body[0].value.value.id == 'x'


# Generated at 2022-06-21 18:42:08.492683
# Unit test for constructor of class snippet
def test_snippet():
    assert isinstance(snippet(let), snippet)



# Generated at 2022-06-21 18:42:20.275615
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    import typed_ast.ast3 as ast

# Generated at 2022-06-21 18:42:28.255160
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    import astor
    import ast
    expected = ast.parse('\n    def b(a0, a1):\n        pass\n    ')
    node = ast.parse('\n    def b(a, b):\n        pass\n    ')
    matcher = {'a': ast.Str(s='a'), 'b': ast.Num(n=1)}
    result = VariablesReplacer(matcher).visit(node)
    assert astor.to_source(result) == astor.to_source(expected)

# Generated at 2022-06-21 18:42:31.007881
# Unit test for constructor of class snippet
def test_snippet():
    def my_function():
        return 1
    # Create a snippet object
    my_snippet = snippet(my_function)
    # Unit test
    assert isinstance(my_snippet, snippet)

# Generated at 2022-06-21 18:42:45.393387
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from_import = ast.ImportFrom(
        module='py_backwards.extensions.pytest',
        names=[
            ast.alias(
                name='mark',
                asname=ast.Name(
                    id='mark',
                    ctx=ast.Load(),
                ),
            ),
            ast.alias(
                name='mark2',
                asname=ast.Name(
                    id='mark2',
                    ctx=ast.Load(),
                ),
            ),
        ],
        level=0,
    )
    ast_list = []
    ast_list.append(from_import)
    tree = ast.Module(body=ast_list)
    variables = {}
    variables['py_backwards'] = 'pyback'
    variables['extensions'] = 'ext'


# Generated at 2022-06-21 18:42:56.386786
# Unit test for function find_variables

# Generated at 2022-06-21 18:43:02.006543
# Unit test for function extend
def test_extend():
    @snippet
    def test(vars: Any):
        extend(vars)
        print(x, y)

    class_ast = ast.parse('''
    x = 1
    x = 2''')

    variables = {}
    extend_tree(class_ast, variables)
    assert test.get_body(vars=class_ast) == ast.parse('''
    x = 1
    x = 2
    print(x, y)''').body



# Generated at 2022-06-21 18:43:13.849751
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .lexer import lexer
    imports = lexer.import_from('from b.c import f as g, h, i')
    replacer = VariablesReplacer({
        'f': 'a',
        'h': 'b'
    })
    replaced = replacer.visit_alias(imports.names[0])
    assert replaced.name == 'b.a'
    assert replaced.asname == 'g'
    replaced = replacer.visit_alias(imports.names[1])
    assert replaced.name == 'b.b'
    assert replaced.asname is None
    replaced = replacer.visit_alias(imports.names[2])
    assert replaced.name == 'i'
    assert replaced.asname is None



# Generated at 2022-06-21 18:43:24.452513
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    # Test when variable is in _variables
    v = ast.parse("n = 1")
    v = v.body[0]
    vars = {'x': 'y'}
    assert v.targets[0].id == 'n'
    node = VariablesReplacer(vars).visit_Name(v.targets[0])
    assert node.id == 'y'

    # Test when variable isn't in _variables
    v = ast.parse("n = 1")
    v = v.body[0]
    vars = {'y': 'x'}
    assert v.targets[0].id == 'n'
    node = VariablesReplacer(vars).visit_Name(v.targets[0])
    assert node.id == 'n'

    # Test when

# Generated at 2022-06-21 18:43:32.262976
# Unit test for function extend
def test_extend():
    print('TEST: Function extend()')
    def snippet_extend_test():
        extend(vars)
        print(x, y)
    
    vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=1)),
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=2))]
    code = snippet(snippet_extend_test).get_body(vars=vars)
    print(ast.dump(ast.Module(body=code), annotate_fields=False))
    return True



# Generated at 2022-06-21 18:43:43.941913
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class Foo:
        id = 'a'

    class Bar:
        id = 'a'

    class Baz(ast.Name):
        id = 'a'

    def a(x: ast.Name) -> int:
        return x.id

    def b(x: ast.Expression) -> ast.Expression:
        return x

    def c(x: ast.AST) -> ast.AST:
        return x

    def d(x: str) -> str:
        return x

    for name, fn in [('name', a), ('ast', b), ('all_types', c), ('no_types', d)]:
        replacer = VariablesReplacer.replace
        assert replacer(Foo(), {'a': 'b'}).id == 'b'

# Generated at 2022-06-21 18:43:55.157899
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-21 18:44:01.152054
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(x)
        print(1)
        print(2)
        print(3)
    """)
    extend_tree(tree, {'x': [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                       value=ast.Num(n=1)),
                             ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())],
                                        value=ast.Num(n=2))
                             ]})
    assert ast.dump(tree.body[0]) == 'Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=1))'

# Generated at 2022-06-21 18:44:09.386093
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import_from = ast.ImportFrom(
        module='py_backwards',
        names=[
            ast.alias(name='a', asname='b')
        ],
        level=0
    )
    variables = {'py_backwards': 'py_backwords', 'a': 'c'}
    node = VariablesReplacer.replace(import_from, variables)
    assert node.module == 'py_backwords'
    assert node.names[0].name == 'c'
    assert node.names[0].asname == 'b'

# Generated at 2022-06-21 18:44:21.949331
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    # type: ()-> None
    from .helpers import compile_ast
    
    source = '''
        def f(a, **kwargs):
            pass
    '''
    tree = ast.parse(source)
    variables = {'kwargs': '_kwargs'}
    VariablesReplacer.replace(tree, variables)
    source = compile_ast(tree)
    assert source == 'def f(a, _kwargs):\n    pass'

# Generated at 2022-06-21 18:44:22.844740
# Unit test for function let
def test_let():
    pass


# Generated at 2022-06-21 18:44:27.057592
# Unit test for function let
def test_let():
    import _py_backwards.extractor as ex

    def f():
        let(x)
        x += 1
        y = 1
    
    assert ex.extract(f).replace(' ', '').replace('\n', '') == 'let(x)\nx+=1\ny=1'
    assert ex.extract(f) == "let(x)\n_py_backwards_x_0 += 1\ny = 1"



# Generated at 2022-06-21 18:44:32.733567
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('x = 0').body[0]  # type: ast.Assign
    replacer = VariablesReplacer({'x': 'y'})
    replacer.visit(tree)
    assert isinstance(tree, ast.Assign) and isinstance(tree.targets[0], ast.Name) and tree.targets[0].id == 'y'



# Generated at 2022-06-21 18:44:36.950381
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
    def f():
        try:
            pass
        except Exception:
            pass
        except Exception as e:
            pass
    """
    tree = ast.parse(source)
    variables = {"Exception": "BackwardsException"}
    VariablesReplacer.replace(tree, variables)
    visitor = VariablesReplacer(variables=variables)
    visitor.visit(tree)
    assert(ast.dump(tree) == ast.dump(ast.parse(source)))

# Generated at 2022-06-21 18:44:38.848542
# Unit test for constructor of class snippet
def test_snippet():
    def func():
        let(1)  # name 'let' is not defined
    snippet(func)

# Generated at 2022-06-21 18:44:39.884367
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-21 18:44:44.183018
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("if a == 0: print(b)")
    variables = {'a': '_a', 'b': '_b'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'if _a == 0: print(_b)'



# Generated at 2022-06-21 18:44:49.163830
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    src = "def f(x): return x * 2"
    tree = ast.parse(src)

    v = {'temp': 'temp'}

    res = ast.parse("def f(temp): return temp * 2")
    VariablesReplacer.replace(tree, v)
    assert res == tree


# Generated at 2022-06-21 18:44:53.744403
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    ast_node = ast.Name(id='a', ctx=ast.Load())
    variables_ = {'a': 'a2'}  # type: Dict[str, Variable]
    replacer = VariablesReplacer(variables_)
    return replacer.visit_Name(ast_node)


# TODO: fix

# Generated at 2022-06-21 18:45:38.744138
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import astunparse
    import ast
    import sys
    module_name = 'test_VariablesReplacer_visit_ImportFrom'
    path = sys.path

# Generated at 2022-06-21 18:45:47.194097
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def foo(name: str,
            a: int,
            c: List[str],
            d: ast.AnnAssign) -> None:
        """
            func(x)
        """
        let(a)
        extend(c)
        let(d)

    body = """
x = "What up"
a = 1
c = ['a', 'b', 'c']
d: int = 1
y = a
y = "asd"
""".strip()
    res_body = foo.get_body(a=1, d=ast.parse("z: int = 1").body[0])

    res_body = ast.unparse(ast.Module(body=res_body)).split('\n')
    tree = ast.parse(body)
    real_body = ast.unparse

# Generated at 2022-06-21 18:45:55.253338
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    var_name = 'var'
    unique_name = 'unique_var'
    variables = {var_name: unique_name}
    tree = ast.parse('foo(var=var)')
    node = tree.body[0].value
    assert node.args[0].arg == var_name
    assert node.keywords[0].arg == var_name

    replacer = VariablesReplacer(variables)
    replacer.visit(tree)

    assert node.args[0].arg == unique_name
    assert node.keywords[0].arg == unique_name

# Generated at 2022-06-21 18:46:02.393871
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    def test_func(x: str = "") -> str:
        import sys # noqa
        return x
    source = get_source(test_func)
    tree = ast.parse(source)
    variables = {'sys': 'sys2'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == "def test_func(x:str='')->str:\n    import sys2\n    return x"


# Generated at 2022-06-21 18:46:13.103880
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():

    @snippet
    def snippet():
        let(x)
        print(x.y)
        print(x.y)

    tree = ast.parse('x = "test"')
    tree.body[0].targets[0].attr = 'attr'

    variables = {'x': '_py_backwards_x_0'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == '_py_backwards_x_0.attr = "test"'
    assert get_source(snippet.get_body()) == \
        '_py_backwards_x_0.y\n' \
        '_py_backwards_x_0.y'



# Generated at 2022-06-21 18:46:19.349040
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    root = ast.parse(
        'class MyNotEqual(object):\n'
        '    def __init__(o, x):\n'
        '        o.x = x\n'
        '    def __ne__(o, other):\n'
        '        return not (o.x == other.x)\n')
    replacer = VariablesReplacer({'o': 'this'})
    replacer.visit(root)
    expected = ast.parse(
        'class MyNotEqual(object):\n'
        '    def __init__(this, x):\n'
        '        this.x = x\n'
        '    def __ne__(this, other):\n'
        '        return not (this.x == other.x)\n')

# Generated at 2022-06-21 18:46:29.190625
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import astor
    var1 = ast.alias('import_name', 'import_as_name')
    var2 = ast.alias('name', 'asname')
    module = ast.parse('from . import name', mode='exec')
    from_import = module.body[0]
    from_import.names = [var1, var2]
    assert astor.to_source(from_import) == 'from . import import_name as import_as_name, name as asname'
    new_var1 = ast.alias('import_name', 'new_import_as_name')
    new_var2 = ast.alias('new_name', 'new_asname')
    new_vars = {'import_name': new_var1, 'name': new_var2}

# Generated at 2022-06-21 18:46:30.703832
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda x: x)


# Public api:



# Generated at 2022-06-21 18:46:42.655157
# Unit test for function extend
def test_extend():
    class Point:
        def __init__(self, x: int, y: int) -> None:
            self.x = x
            self.y = y
    
    def test() -> None:
        x = 1
        y = 2
        p = Point(x, y)
        extend(vars())
        print(x, y, p.x, p.y)

    source = '''
    x = 1
    y = 2
    p = Point(x, y)
    print(x, y, p.x, p.y)
    '''

    tree = ast.parse(source)
    tree.body[0], tree.body[1] = tree.body[1], tree.body[0]
    _sort = lambda a: a.targets[0].id

# Generated at 2022-06-21 18:46:47.879939
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("""\
    def outer_fn():
        _py_backwards_x_0 = 1
        def inner_fn():
            return _py_backwards_x_0
        return inner_fn()
    """)
    VariablesReplacer.replace(tree, {'x': '_py_backwards_x_0'})
    source = ast.unparse(tree)
    assert source == """\
    def outer_fn():
        _py_backwards_x_0 = 1
        def inner_fn():
            return _py_backwards_x_0
        return inner_fn()
    """

# Generated at 2022-06-21 18:47:27.751792
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    # Test function check if atribute name of ast.FunctionDef is attribute id of ast.Name
    def func():
        pass
    tree = ast.parse(get_source(func))
    tree = VariablesReplacer({'func': 'test'}).visit(tree)
    assert(tree.body[0].name == 'test')


# Generated at 2022-06-21 18:47:37.852931
# Unit test for function extend_tree
def test_extend_tree():
    # Test 1
    vars_dict = {'x': ast.copy_location(ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                   value=ast.Num(n=1)),
                                       ast.parse('1'))}
    tree = ast.parse('extend(vars); print(x)')
    extend_tree(tree, vars_dict)
    assert get_source(tree) == 'x = 1; print(x)'

    #Test 2
    tree = ast.parse('extend(vars); print(x)')
    extend_tree(tree, vars_dict)
    assert get_source(tree) == 'x = 1; print(x)'

# Generated at 2022-06-21 18:47:46.818357
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    def f(x: int = 1):
        pass

    source = """def f(x: int = 1):
    pass"""

    tree = ast.parse(source)
    variables = {'int': VariablesGenerator.generate('int')}
    VariablesReplacer.replace(tree, variables)
    result = ast.dump(tree)
    assert result == ast.dump(ast.parse("""def f(x: _py_backwards_int_0 = 1):
    pass""".format(variables[0])))

# Generated at 2022-06-21 18:47:48.351696
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    "replace self.x with self.y"

# Generated at 2022-06-21 18:47:51.237166
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert isinstance(VariablesReplacer(None), ast.NodeTransformer)
    assert isinstance(VariablesReplacer({}), ast.NodeTransformer)

# Generated at 2022-06-21 18:47:59.207522
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    from typed_ast import ast3
    from .helpers import VariablesGenerator
    var = VariablesGenerator.generate("arg")
    tree = ast3.parse("""
        def func(arg):
            print(arg)
    """)
    replacer = VariablesReplacer({'arg': var})
    replacer.visit(tree)
    assert(str(tree) == f"""
        def func({var}):
            print({var})
    """)



# Generated at 2022-06-21 18:48:06.880679
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class TestVisitor(ast.NodeTransformer):
        def visit_ExceptHandler(self, node):
            node.name = 'asd'
            return node

    if __name__ == '__main__':
        tree = ast.parse('try: asd\nexcept Exception as e: pass')
        v = TestVisitor()
        v.visit(tree)

        x = v.generic_visit(tree)
        assert x.body[0].handlers[0].name == 'asd'



# Generated at 2022-06-21 18:48:14.439236
# Unit test for function extend
def test_extend():
    snippet_extend = snippet(lambda: extend(vars))
    for name, value in vars.items():
        original_line = '{} = {}'.format(name, value)
        if len(vars) == 1:
            expected = '{} = {}'.format(name, value)
        else:
            expected = '{}\n{}'.format(original_line, '\n'.join(vars))
        body = snippet_extend.get_body(vars=original_line)
        assert get_source(body) == expected


# Unit tests for function let

# Generated at 2022-06-21 18:48:15.353831
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-21 18:48:21.020697
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    variables = {'name': 'new_name'}
    code = 'import os'
    tree = ast.parse(code)
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert code != ast.dump(tree)

# Generated at 2022-06-21 18:49:46.661470
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    foo = ast.Name('foo')
    var = ast.Name('var')

# Generated at 2022-06-21 18:49:49.364659
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    var = VariablesGenerator.generate()


# Generated at 2022-06-21 18:49:59.745562
# Unit test for function extend_tree
def test_extend_tree():
    extend_tree(ast.parse("""
    def fn():
        let(x)
        extend(vars)
        let(y)
    """), {'vars': ast.parse("""
    x = 1
    x = 2
    """).body})
    # Function should be untouched
    assert str(ast.parse("""
    def fn():
        let(x)
        extend(vars)
        let(y)
    """).body[0]) == str(ast.parse("""
    def fn():
        let(x)
        extend(vars)
        let(y)
    """).body[0])
    # But x should be extended

# Generated at 2022-06-21 18:50:07.196023
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import astor
    class A:
        def b(self, **kwargs):
            pass

    tree = ast.parse(astor.to_source(A.b))
    assert astor.to_source(tree) == 'def b(self, **kwargs):\n    pass\n'

    tree = VariablesReplacer.replace(tree, {'kwargs': ['var']})
    assert astor.to_source(tree) == 'def b(self, **var):\n    pass\n'

# Generated at 2022-06-21 18:50:11.474591
# Unit test for function extend_tree
def test_extend_tree():
    source = """
        y = 1
        extend(vars)
        y = 2
    """
    tree = ast.parse(source)
    extend_tree(tree, {
        'vars': ast.Module(
            body=[ast.Assign(
                targets=[ast.Name(id="x", ctx=ast.Store)],
                value=ast.Num(n=1),
            )],
        ),
    })

    assert get_source(tree) == """\
y = 1
x = 1
y = 2"""

# Generated at 2022-06-21 18:50:16.291417
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    v1 = ast.Call(func=ast.Name(id='let', ctx=ast.Load()), 
                    args=[ast.Str(s='__tmp'), ast.Num(n=4)], keywords=[])

    v2 = ast.Call(func=ast.Name(id='let', ctx=ast.Load()), 
                    args=[ast.Str(s='__tmp'), ast.Num(n=3)], keywords=[])

    class_node = ast.ClassDef(name=ast.Str(s='B'), bases=[], body=[v1, v2])

    variables = {'__tmp': 'str'}
    inst = VariablesReplacer(variables)
    class_node = inst.visit_ClassDef(class_node)

    assert(len(class_node.body) == 2)

# Generated at 2022-06-21 18:50:17.311089
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-21 18:50:24.633093
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse(
        "def a(x, y):\n"
        "    x\n"
        "    y\n")

    variables = {'x': '_x_'}
    VariablesReplacer.replace(tree, variables)
    t2 = ast.parse(
        "def a(_x_, y):\n"
        "    _x_\n"
        "    y\n")
    assert ast.dump(tree) == ast.dump(t2)


# Generated at 2022-06-21 18:50:27.163619
# Unit test for constructor of class snippet
def test_snippet():
    def my_snippet():
        let(x)
        x += 1
    my_snippet = snippet(my_snippet)
    assert isinstance(my_snippet, snippet)



# Generated at 2022-06-21 18:50:30.667175
# Unit test for constructor of class snippet
def test_snippet():
    def test():
        let(x)
        let(x)
        x = 1
        print(x)


    assert test.__module__ == '__main__'
    assert test.__name__ == 'test'
    snippet_obj = snippet(test)
    assert isinstance(snippet_obj, snippet)

