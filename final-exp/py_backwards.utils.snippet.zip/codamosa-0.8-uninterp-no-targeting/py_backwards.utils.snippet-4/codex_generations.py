

# Generated at 2022-06-21 18:41:58.877005
# Unit test for function let
def test_let():
    @snippet
    def f(x):
        for x in range(x):
            let(y)
            y = 1
            x += y
        return x


# Generated at 2022-06-21 18:42:07.888271
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet1():
        let(x)
        let(y)
        x += 1

    body = snippet1.get_body(x=42)
    assert len(body) == 1
    assert isinstance(body[0], ast.AugAssign)
    assert body[0].value.n == 42

    # Test for extend
    @snippet
    def snippet2():
        extend(vars)
        print(x, y)

    body = snippet2.get_body(vars=[ast.Assign([ast.Name(id='x')], ast.Num(1)),
                                    ast.Assign([ast.Name(id='x')], ast.Num(2))])
    assert len(body) == 3
    assert isinstance(body[0], ast.Assign)

# Generated at 2022-06-21 18:42:19.774527
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class _Class:
        x = 1

    a = _Class()

    class _Class2:
        x = 2

    b = _Class2()

    def f(a, b):
        pass

    def f2(a, b):
        pass

    def f3(a, b):
        pass


# Generated at 2022-06-21 18:42:23.992573
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    def fun1(a):
        pass
    source = get_source(fun1)
    tree = ast.parse(source)
    variables = {'a': 'b'}
    replace = VariablesReplacer.replace(tree, variables)



# Generated at 2022-06-21 18:42:28.805947
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    t = VariablesReplacer.replace(ast.parse("x"), {"x": "_py_backwards_x_0"})

    xn = t.body[0].value
    assert isinstance(xn, ast.Name)
    assert xn.id == "_py_backwards_x_0"


# Generated at 2022-06-21 18:42:30.803776
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    import sys
    import os.path
    sys.path.append(os.path.dirname(__file__))
    import test_snippets

# Generated at 2022-06-21 18:42:31.679194
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-21 18:42:39.544300
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    code = "try:\n    1/0\nexcept ZeroDivisionError as err:\n    print(err)"
    expected_code = "try:\n    1/0\nexcept ZeroDivisionError as _py_backwards_err_0:\n    print(_py_backwards_err_0)"
    tree = ast.parse(code)
    variables = {'err': '_py_backwards_err_0'}
    VariablesReplacer.replace(tree, variables)
    assert expected_code == ast.unparse(tree)

# Generated at 2022-06-21 18:42:47.025393
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("print(a)")
    vars = ast.parse("x = 1; y = 1")
    extend_tree(tree, {"vars": vars})
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=1)), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[]))])"



# Generated at 2022-06-21 18:42:53.267213
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    class A:
        pass
    extend(x)
    print(x)
    """)
    tree2 = ast.parse("""
    class A:
        pass
    extend(x)
    print(x)
    """)
    extend_tree(tree, {'x': tree2})
    assert get_source(tree) == get_source(tree2)

# Generated at 2022-06-21 18:43:02.439437
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('lambda x: x')
    replacer = VariablesReplacer({'x': '_py_backwards_x_0'})
    replacer.visit(tree)
    assert get_source(tree) == 'lambda _py_backwards_x_0: _py_backwards_x_0'

# Generated at 2022-06-21 18:43:04.125508
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda x: print(x))

# Generated at 2022-06-21 18:43:08.086655
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    p = ast.parse("from a import b\n")
    assert len(p.body) > 0 and isinstance(p.body[0], ast.ImportFrom)
    assert p.body[0].module == "a"
    assert len(p.body[0].names) > 0 and p.body[0].names[0].name == "b"
    replacer = VariablesReplacer({"a": "c"})
    replacer.visit(p)
    assert p.body[0].module == "c"
    assert p.body[0].names[0].name == "b"

# Generated at 2022-06-21 18:43:19.938624
# Unit test for function let
def test_let():
    import pytest
    @snippet
    def test_snippet():
        let(x)
        x += 1
        y = 1

    expected = [
        ast.AnnAssign(target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()),
                      annotation=None, value=None, simple=1),
        ast.AugAssign(target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                      op=ast.Add(), value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=1))]
    assert test_snippet.get_body() == expected



# Generated at 2022-06-21 18:43:29.215393
# Unit test for function extend
def test_extend():
    assert get_source(snippet(lambda x: extend(x)).get_body(x=[
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ])) == 'x = 1\nx = 2'


# Generated at 2022-06-21 18:43:39.705183
# Unit test for function extend
def test_extend():
    import inspect
    import __main__
    __main__.__builtins__['let'] = let
    __main__.__builtins__['extend'] = extend
    snippet = """
i = 2
extend(myvars)
i += 2
      """
    myvars = ast.parse("""
i = 5
    """)
    result = ast.parse("i = 5\ni += 2")
    tree = ast.parse(snippet)
    extend_tree(tree, {'myvars': myvars.body})
    fn = compile(tree, '<string>', 'exec')
    __main__.__dict__['i'] = 0
    exec(fn)

    assert i == 5 + 2

# Generated at 2022-06-21 18:43:50.967260
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class TestB(ast.AST):
        _fields = ('b',)
        b: str

    class TestA(ast.AST):
        _fields = ('a',)
        a: List[TestB]

    node = ast.parse("""
{
    'a': a,
    'b': b
}
    """).body[0].value  # type: ast.Dict
    variables = {
        'a': 'x',
        'b': 'y'
    }
    inst = VariablesReplacer(variables)
    inst.visit(node)

    assert node.keys[0].value.id == 'a'
    assert node.keys[0].value.id == 'x'
    assert node.keys[1].arg == 'b'
    assert node.keys[1].arg == 'y'

# Generated at 2022-06-21 18:43:52.301804
# Unit test for method visit_ImportFrom of class VariablesReplacer

# Generated at 2022-06-21 18:43:59.611370
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse(
        """
from abc import dEf
import random
from foo import (
bar,
Baz
)
from abc import dEf, aBc, def_abc
"""
    )
    variables = {
        'dEf': ast.parse('def dEf():pass').body[0],
        'aBc': ast.parse('class aBc:pass').body[0],
    }
    VariablesReplacer.replace(tree, variables)
    assert(get_source(tree) ==
           """
from abc import dEf_py_backwards_0
import random
from foo import (
bar,
Baz
)
from abc import (def_abc,
aBc_py_backwards_0)
""")

# Generated at 2022-06-21 18:44:02.729235
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    variables = {'x': 'y'}
    replacer = VariablesReplacer(variables)
    assert replacer._variables == variables


# Generated at 2022-06-21 18:44:12.972674
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse('let(x); x + y')) == ['x']
    assert find_variables(ast.parse('let(x); let(y); x + y')) == ['x', 'y']
    assert find_variables(ast.parse('let(x); let(y); let(z); x + y')) == ['x', 'y', 'z']



# Generated at 2022-06-21 18:44:19.900197
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import ast
    import astor
    a = ast.ClassDef(name='A')
    a = VariablesReplacer.replace(a, {'A': 'B'})
    assert astor.to_source(a) == 'class B:\n    pass'
    b = ast.ClassDef(name='A', decorator_list=[ast.Name(id='a')])
    b = VariablesReplacer.replace(b, {'A': 'B'})
    assert astor.to_source(b) == '@a\nclass B:\n    pass'

# Generated at 2022-06-21 18:44:27.146046
# Unit test for function extend
def test_extend():
    def snippet_with_extend(**kwargs):
        extend(kwargs['vars'])

    variables = {'vars': [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(2))
    ]}

    expected = '\n'.join([
        'x = 1',
        'x = 2'
    ])
    assert expected == ast.unparse(snippet(snippet_with_extend).get_body(
        **variables))


# Generated at 2022-06-21 18:44:32.338265
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class DummyClass1:
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node = self._replace_field_or_node(node, 'name')
            return self.generic_visit(node)  # type: ignore
    class DummyClass2:
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node = self._replace_field_or_node(node, 'name')
            return self.generic_visit(node)  # type: ignore

    tree = ast.parse("""class A: pass""").body[0]
    variables = {
        "A": "B"
    }
    replacer1 = DummyClass1()
    replacer1.variables = variables

# Generated at 2022-06-21 18:44:43.646469
# Unit test for function extend_tree
def test_extend_tree():

    code = """
        def f():
            extend(vars)

    """
    body = ast.parse(code).body[-1].body[0].body
    assert body == []

    vars1 = [ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()), annotation=None, value=ast.Num(n=1))]
    vars2 = [ast.AnnAssign(target=ast.Name(id='y', ctx=ast.Store()), annotation=None, value=ast.Num(n=2))]
    extend_tree(ast.parse(code), {'vars': vars1})
    extend_tree(ast.parse(code), {'vars': vars2})
    body = ast.parse(code).body[-1].body[0].body

# Generated at 2022-06-21 18:44:50.713059
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # python:
    # class Foo:
    #     pass
    class_def = ast.ClassDef(
        'Foo',
        [],
        [],
        [],
        [],
        []
    )
    variables = {'Foo': 'Bar'}
    replacer = VariablesReplacer(variables)
    replacer.visit(class_def)
    assert class_def.name == 'Bar'


# Generated at 2022-06-21 18:44:58.549862
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 'x'
    b = 'y'
    @snippet
    def code():
        let(a)
        extend(b)
        print(a)
        print(b)

    body = code.get_body(a=2, b=[ast.parse('x = 0'), ast.parse('x = 1')])
    assert len(body) == 3 and all(isinstance(node, ast.Expr) for node in body)

# Generated at 2022-06-21 18:45:01.485263
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    expected_tree = ast.parse('import x').body[0]
    tree = ast.parse('import math')
    variables = {'math': 'x'}
    VariablesReplacer.replace(tree, variables)
    assert expected_tree == tree.body[0]



# Generated at 2022-06-21 18:45:13.075965
# Unit test for function extend
def test_extend():
    # ARRANGE
    var = snippet(lambda x, y: extend(x))
    body = var.get_body(x=[ast.Assign([ast.Name('x', ast.Store())], [ast.Num(1)]),
                            ast.Assign([ast.Name('x', ast.Store())], [ast.Num(2)])])
    
    # ACT

# Generated at 2022-06-21 18:45:18.912111
# Unit test for constructor of class snippet
def test_snippet():
    def _test() -> None:
        let(x)
        x += 1
        print(x)
    assert snippet(_test).get_body() == [ast.Assign(
        targets=[ast.Name('_py_backwards_x_0', ast.Store())],
        value=ast.BinOp(
            left=ast.Name('_py_backwards_x_0', ast.Load()),
            op=ast.Add(),
            right=ast.Num(1)),
        type_comment=None), ast.Expr(value=ast.Call(
            func=ast.Name('print', ast.Load()),
            args=[ast.Name('_py_backwards_x_0', ast.Load())],
            keywords=[],
            starargs=None,
            kwargs=None))]


# Unit

# Generated at 2022-06-21 18:45:26.823557
# Unit test for function let
def test_let():
    from .utils import parse_snippet

    @snippet
    def snippet(x: int) -> int:
        let(y)

        y = x + 1

        return y

    x = ast.parse('x = 1').body[0]
    body = snippet.get_body(x=x)
    assert parse_snippet(body) == parse_snippet('y = x + 1')



# Generated at 2022-06-21 18:45:34.370760
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class Test(ast.NodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            node = self._replace_field_or_node(node, 'id')
            return self.generic_visit(node)

        def _replace_field_or_node(self, node: ast.Name, field: str) -> ast.Name:
            return node
    vr = VariablesReplacer({})
    assert isinstance(vr, VariablesReplacer)
    assert isinstance(Test(), VariablesReplacer)

# Generated at 2022-06-21 18:45:36.741202
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:45:45.805436
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def wrapper():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)


# Generated at 2022-06-21 18:45:53.910275
# Unit test for function extend_tree
def test_extend_tree():
    vars = ast.parse('x = 1\nx = 2').body  # type: ignore
    tree = ast.parse('x\nextend(vars)\nx').body
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == "[Assign(targets=[Name(id='x', ctx=Load())], value=Num(n=1)), Assign(targets=[Name(id='x', ctx=Load())], value=Num(n=2)), Expr(value=Name(id='x', ctx=Load()))]"

# Generated at 2022-06-21 18:46:01.600214
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    code = "numpy.array(np.empty(shape=1))"
    tree = ast.parse(code)
    variables = {'numpy': 'foo', 'np': 'bar'}
    VariablesReplacer.replace(tree, variables)
    gen_code = ast.unparse(tree)
    desired_code = "foo.array(bar.empty(shape=1))"
    assert gen_code == desired_code, "Error of VariablesReplacer.visit_Attribute"



# Generated at 2022-06-21 18:46:08.833456
# Unit test for function extend
def test_extend():
    from .tree import to_source, find
    tree = ast.parse("""
    extend(vars)
    print(a)
    """)
    vars = ast.parse("""
    a = 1
    """)

    extend_tree(tree, {"vars": vars.body})
    assert to_source(tree) == """
    a = 1
    print(a)
    """

# Generated at 2022-06-21 18:46:13.421272
# Unit test for function extend
def test_extend():
    let(x)
    extend(x)
    x = 1
    x = 2
    assert(x == 2)
    extend(x)
    x = 3
    assert(x == 3)
    del(x)
    try:
        x
        assert(False)
    except NameError:
        pass


# Generated at 2022-06-21 18:46:14.076750
# Unit test for function find_variables

# Generated at 2022-06-21 18:46:19.268159
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class C:
        pass

    c = C()
    body = c.__class__.__bases__[0].__new__(c.__class__)
    instance_dict = c.__dict__
    if body.__dict__ is not instance_dict:
        body.__dict__ = instance_dict

    tree = ast.parse(get_source(C))
    name = ast.Name('TestClass', ast.Load())
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    parent.body[index].name = name

    result = VariablesReplacer.replace(tree, {'TestClass': body})
    assert result == tree



# Generated at 2022-06-21 18:46:38.979503
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import to_source
    from .type_checking import type_check

    @type_check
    def my_sum(x: int, y: int) -> int:
        let(x)
        let(y)
        return x + y

    tree = my_sum.get_body(x=1, y=2)
    assert to_source(tree) == '_py_backwards_x_0 = 1\n_py_backwards_y_0 = 2\nreturn _py_backwards_x_0 + _py_backwards_y_0\n'



# Generated at 2022-06-21 18:46:43.254799
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
    try:
        test_123
    except Exception as e:
        e
    """

    tree = ast.parse(source)
    variables = {'e': 'test'}
    replace = VariablesReplacer.replace(tree, variables)

    assert replace.body[0].handlers[0].name.id == 'test'

# Generated at 2022-06-21 18:46:54.543455
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse("""def f(x: int) -> int: return x * 2""").body[0]
    variables = {'x': ast.Name(id='y')}
    tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == ("""FunctionDef(args=arguments(args=[arg(arg='y', annotation=Name(id='int', ctx=Load()))], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), name='f', body=[Return(value=BinOp(left=Name(id='y', ctx=Load()), op=Mult(), right=Constant(value=2)))], decorator_list=[], returns=Name(id='int', ctx=Load()))""")

# Generated at 2022-06-21 18:47:03.211964
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('def f(x, y): pass')
    variables = {'x': 'a'}
    VariablesReplacer.replace(tree, variables)
    assert str(ast.dump(tree)) == 'Module(body=[FunctionDef(name=f, args=arguments(args=[arg(arg=a, annotation=None), arg(arg=y, annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[])])'



# Generated at 2022-06-21 18:47:13.485554
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    # type: () -> None
    import itertools

    def _test(arg):
        ast_ = ast.parse('def foo(%s): pass' % arg, mode='eval')

        class Transformer(ast.NodeTransformer):
            i = itertools.count()
            def visit_arg(self, arg):
                arg.arg = '_py_backwards_%s_%s' % (arg.arg, next(self.i))
                return arg

        ast_.body = Transformer().visit(ast_.body)
        ast_.body = VariablesReplacer.replace(ast_.body, {})
        return ast_.body.body[0].body[0].args[0]

    assert _test('x').arg == '_py_backwards_x_0'

# Generated at 2022-06-21 18:47:20.997810
# Unit test for function extend
def test_extend():
    from .tree import get_ast
    from .runner import from_snippet
    from .library.std import std

    def test_fn():
        var1 = 1
        var2 = 2
        extend(vars)
        assert var1 == 1
        assert var2 == 2

    vars = get_ast('''
    var1 = 2
    var2 = 1
    ''')
    test_runner = from_snippet(test_fn, std())
    test_runner.run()

# Generated at 2022-06-21 18:47:29.370972
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    import unittest
    from .tree import parse

    class TestVariablesReplacer(unittest.TestCase):
        def test_replace(self):
            tree = parse("""
                a == 0
            """)

            class TestVariablesReplacer(VariablesReplacer):
                def visit_Name(self, node: ast.Name) -> ast.Name:
                    if node.id == 'a':
                        return ast.Name(id='b', ctx=ast.Load())

            expected = parse("""
                b == 0
            """)
            self.assertEqual(TestVariablesReplacer.replace(tree, {}), expected)

    unittest.main()

# Generated at 2022-06-21 18:47:34.829308
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse('''
from a import b
import a as b
import b
b.a
''')
    variables = {
        'a': 'x',
        'b': 'y'
    }
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == '''
import x as y
import y
y.x
'''

# Generated at 2022-06-21 18:47:45.984981
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():

    tree = ast.parse(
        """
        def f():
            print(foo)
            x = 1
            print(x)
        """)
    params = {"foo": ast.Name(id="foo_1", ctx=ast.Store()), "x": ast.Name(id="x_2", ctx=ast.Store())}
    VariablesReplacer.replace(tree, params)

    expected = ast.parse(
        """
            def f():
                print(foo)
                x_2=1
                print(x_2)
            """)

    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-21 18:47:50.950276
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    code = 'except Exception as e: pass'
    tree = ast.parse(code)

    replacements = {'e': 'tmp_e'}
    VariablesReplacer.replace(tree, replacements)

    source = get_source(tree)
    assert source == 'except Exception as tmp_e: pass'

# Generated at 2022-06-21 18:48:16.365877
# Unit test for constructor of class snippet
def test_snippet():
    class snippet():
        def __init__(self, fn: Callable[..., None]) -> None:
            self._fn = fn
        def _get_variables(self, tree: ast.AST,
                       snippet_kwargs: Dict[str, Variable]) -> Dict[str, Variable]:
            names = find_variables(tree)
            variables = {name: VariablesGenerator.generate(name)
                         for name in names}

            for key, val in snippet_kwargs.items():
                if isinstance(val, ast.Name):
                    variables[key] = val.id
                else:
                    variables[key] = val  # type: ignore
            return variables  # type: ignore


# Generated at 2022-06-21 18:48:24.581832
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    source1 = 'def f(a):\n    a = a\n    return a\n'
    source2 = 'def f(a):\n    a = a\n    return a\n'
    v = VariablesReplacer({"a": "test"})
    tree = ast.parse(source1)
    new_tree = v.replace(tree, {"a": "test"})
    new_source = ast.unparse(new_tree)
    assert source2 == new_source

# Generated at 2022-06-21 18:48:31.649239
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    v_g = VariablesGenerator()
    v_g.generate('a')
    variables = {'a': '_py_backwards_a_0'}
    src_code = 'def func(a, b): pass'
    tree = ast.parse(src_code)
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert str(tree) == 'def func(_py_backwards_a_0, b): pass', str(tree)

# Generated at 2022-06-21 18:48:40.371449
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    def function():
        class Test:
            def test(self, x):
                self.x = x
                return x
        tt = Test()
        tt.test(4)
    code = snippet(function)
    tree = code.get_body()
    tree = ast.parse(str(tree))
    var = {"self" : ast.Name(id="self1"), "x" : "x1"}
    inst = VariablesReplacer(var)
    for node in tree.body[0].body[0].body[0].body[1].body[1].value.args:
        inst.visit(node)
    assert "self1" == node.id

# Generated at 2022-06-21 18:48:44.458330
# Unit test for constructor of class snippet
def test_snippet():
    "Test for snippet constructor"
    def f():
        let(1)
        let([1, 2, 3])
        let(x)
        let(x)
        extend(['[1, 2, 3]', 'print(x)'])
    s = snippet(f)

# Generated at 2022-06-21 18:48:54.004391
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .helpers import dump
    from .helpers import get_source
    from .tree import parse
    from .variables import variables_replace
    source = get_source(test_VariablesReplacer_visit_ImportFrom)
    tree = parse(source)
    variables_replace(tree, {'math': 'math_new'})
    result = dump(tree)

# Generated at 2022-06-21 18:49:00.354587
# Unit test for function extend
def test_extend():
    from .helpers import get_source

    a = 1
    b = 2

    @snippet
    def f():
        extend({'a': a})

    sample = get_source(f)
    assert sample == "a=1"

    @snippet
    def f():
        extend({'b': b})

    sample = get_source(f)
    assert sample == "b=2"



# Generated at 2022-06-21 18:49:04.366307
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("from math import cos, sin, inf")
    variables = {'math': 'my_math'}
    result = VariablesReplacer.replace(tree, variables)

    assert ast.dump(result) == "from my_math import cos, sin, inf"


# Generated at 2022-06-21 18:49:16.837855
# Unit test for function let
def test_let():
    class A:
        @snippet
        def f(self):
            let(x)
            print(x)

    assert A().f.get_body() == [ast.parse('print(_py_backwards_x_0)')]
    assert A().f.get_body(x=3) == [ast.parse('print(3)')]

    class B:
        @snippet
        def f(self):
            let(x)
            x += 1

    assert B().f.get_body() == [ast.parse('_py_backwards_x_0 += 1')]

    class B:
        @snippet
        def f(self):
            let(x)
            x += 1


# Generated at 2022-06-21 18:49:17.706469
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda: 0)

# Generated at 2022-06-21 18:49:54.565468
# Unit test for function let
def test_let():
    snippet_body = snippet(lambda x, y: let(x) + y).get_body()
    assert snippet_body[0].value.left.id == '_py_backwards_x_0'



# Generated at 2022-06-21 18:50:03.886665
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class not_ast(object):
        def __init__(self, field, value):
            self.field = field
            self.value = value
    vars = {
        'x': not_ast('name', '_py_backwards_x_0')
    }
    class ast_type(object):
        def __init__(self, field, value):
            self.field = field
            self.value = value
    name = ast_type('name', 'x')
    obj = VariablesReplacer(vars)
    obj.visit_Attribute(name)
    assert name.value == '_py_backwards_x_0'


# Generated at 2022-06-21 18:50:08.155425
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    source = 'class A: pass'
    tree = ast.parse(source)
    variables = {'A': 'B'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'Module(body=[ClassDef(name=\'B\', bases=[], keywords=[], body=[Pass()], decorator_list=[])])'



# Generated at 2022-06-21 18:50:14.886164
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""
    try:
        pass
    except:
        pass
    """)
    node = tree.body[0].handlers[0]
    new_name = 'new_name'

    replacer = VariablesReplacer({
        'asdf': new_name
    })

    replacer.visit(tree)

    assert node.name is None
    assert node.name == new_name

# Generated at 2022-06-21 18:50:24.908132
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse(
        "from my_module import a, b as my_b")
    variables = {
        'my_module': 'i_am_another_module',
        'my_b': 'my_c'
    }
    inst = VariablesReplacer(variables)
    inst.visit(tree)

    lines = ast.dump(tree).split('\n')
    assert lines[0] == 'ImportFrom(module=\'i_am_another_module\', names=[alias(name=\'a\', asname=None)], level=0)'
    assert lines[1] == 'alias(name=\'b\', asname=\'my_c\')]'
    assert len(lines) == 2

# Generated at 2022-06-21 18:50:32.954580
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class_def = ast.parse("""class A:
            pass""").body[0]
    import_from = ast.parse("""from a.b import A""").body[0]
    alias = import_from.names[0]
    def_alias = ast.parse("foo = bar").body[0].value
    
    assert VariablesReplacer(dict()).visit_alias(alias).name == alias.name

# Generated at 2022-06-21 18:50:37.231638
# Unit test for function extend_tree
def test_extend_tree():
    test_tree = ast.parse('import a; b = 1')
    var_name = 'a'
    vars_tree = ast.parse('a = 1; a = 2')
    vars = {var_name: vars_tree}
    extend_tree(test_tree, vars)
    assert(len(test_tree.body) == 4)

# Generated at 2022-06-21 18:50:37.836645
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-21 18:50:44.724601
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class TestVariablesReplacer(VariablesReplacer):
        def __init__(self):
            super().__init__({})

    tree = ast.parse("getattr(s, 'attr')").body[0].value
    assert "getattr(s, 'attr')" == get_source(tree)

    tree = TestVariablesReplacer.replace(tree, {'attr': "'attr_new'"})
    assert "getattr(s, 'attr_new')" == get_source(tree)

# Generated at 2022-06-21 18:50:48.884461
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    a = """
    def func(x: int, *args):
        pass
    """
    tree = ast.parse(a)
    replace_tree = VariablesReplacer.replace(tree, {
        'x': 'y'
    })
    assert str(replace_tree) == """
    def func(y: int, *args):
        pass
    """