

# Generated at 2022-06-21 18:41:33.629953
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():

    def foo():
        from unittest import mock

    source = get_source(foo)
    tree = ast.parse(source)

    vg = VariablesGenerator()
    variables = {
        'unittest': vg.generate('unittest'),
        'mock': vg.generate('mock')
    }

    VariablesReplacer.replace(tree, variables)

    assert get_source(tree) == 'from unittest import mock\n'

# Generated at 2022-06-21 18:41:39.344657
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class Vars:
        def __init__(self, tree):
            self.tree = tree

        def __eq__(self, other):
            return self.tree == other.tree

    class Name:
        def __init__(self, id, ctx):
            self.id = id
            self.ctx = ctx

        def __eq__(self, other):
            return self.id == other.id and self.ctx == other.ctx

    vars = {'x': Vars(Name('x', ast.Store()))}
    tree = VariablesReplacer.replace(Name('x', ast.Store()), vars)
    assert tree == Name('x', ast.Store())



# Generated at 2022-06-21 18:41:51.816275
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int) -> int:
        let(x)
        x = 1
        return x

    def snippet_fn_with_extend(x: int) -> None:
        let(x)
        extend(vars)
        x += 1

    assert snippet(snippet_fn).get_body(x=2) == [ast.Assign([ast.Name('x', ast.Store())],
                                                           ast.Num(1))]
    assert snippet(snippet_fn).get_body() == [ast.Assign([ast.Name('x', ast.Store())],
                                                          ast.Num(1))]

# Generated at 2022-06-21 18:42:00.689956
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert (ast.parse("""
    class A(object):
        @property
        def a(self):
            pass
    """) == VariablesReplacer.replace(
        ast.parse("""
        class A(object):
            @property
            def a(self):
                pass
        """), {'object': 'object'}))

    assert (ast.parse("""
    class A(object):
        @property
        def a(self):
            pass
    """) == VariablesReplacer.replace(
        ast.parse("""
        class A(type):
            @property
            def a(self):
                pass
        """), {type: object}))


# Generated at 2022-06-21 18:42:02.069949
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    from .helpers import parse, has_node_class


# Generated at 2022-06-21 18:42:12.327222
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""
    def foo():
        pass
        
    try:
        foo()
    except Exception as blabla:
        pass
    except:
        pass
    """)
    variables = {'blabla': VariablesGenerator.generate('blabla')}
    VariablesReplacer.replace(tree, variables)
    expected = ast.parse("""
    def foo():
        pass
        
    try:
        foo()
    except Exception as _py_backwards_blabla_0:
        pass
    except:
        pass
    """)
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 18:42:12.962249
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    pass


# Generated at 2022-06-21 18:42:13.964802
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-21 18:42:22.880160
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    replace_table = {"var1": "var2", "var3": "var4"}

    def test_func(var1, var3):
        var3 = var3 + var1
        return var3

    test_source = """def test_func(var1, var3):
        var3 = var3 + var1
        return var3
    """

    expected_result = """def test_func(var1, var4):
        var4 = var4 + var2
        return var4
    """

    def check():
        tree = ast.parse(test_source)
        VariablesReplacer.replace(tree, replace_table)
        result = ast.unparse(tree)
        assert result == expected_result

    check()

# Generated at 2022-06-21 18:42:29.523756
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    @snippet
    def body(*args, **kwargs):
        let(foo)
        def foo():
            pass
    variables = {'foo': 'bar'}
    replacer = VariablesReplacer(variables)
    body = replacer.visit(body.get_body())
    assert get_source(body) == (
        'def bar():\n'
        '    pass'
    )


# Generated at 2022-06-21 18:42:38.921652
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = """
    from module1 import field as some_field
    """
    tree = ast.parse(source)
    variables = {'field': 'other_name'}
    replace = VariablesReplacer.replace(tree, variables)
    assert replace.body[0].names[0].name == 'some_field'

# Generated at 2022-06-21 18:42:46.270662
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 0
    y = 1
    def test_snippet():
        let(x)
        x += 1

    tree = snippet(test_snippet).get_body()
    assert ast.dump(tree[0]) == ast.dump(ast.Assign(targets=[ast.Name(id='_py_backwards_x_0')],
                                                  value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0'),
                                                                  op=ast.Add(),
                                                                  right=ast.Num(n=1))))


# Generated at 2022-06-21 18:42:53.266884
# Unit test for function extend
def test_extend():
    """
    Basic test for function extend
    :return:
    """
    @snippet
    def test():
        a = 0
        extend(b)
    b = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                   value=ast.Num(1))

    # Check that variables are replaced correctly
    assert get_source(test.get_body()) == 'a = 1'

# Generated at 2022-06-21 18:43:00.197289
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import ast
    from .helpers import VariablesGenerator
    from .snippets import let

    def let_x():
        x = 1

    source = get_source(let_x)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name)
                 for name in names}
    extended_tree = VariablesReplacer.replace(tree, variables)
    assert extended_tree.body[0].keywords[0].arg == '_py_backwards_x_0'

# Generated at 2022-06-21 18:43:05.903550
# Unit test for function let
def test_let():
    source = """
    let(x)
    print(x)
    """

    tree = ast.parse(source)
    variables = {name: VariablesGenerator.generate(name) for name in find_variables(tree)}
    VariablesReplacer.replace(tree, variables)
    assert isinstance(get_source(tree), str)



# Generated at 2022-06-21 18:43:10.187931
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('from fooooo import a, b as c')
    replacer = VariablesReplacer({'a': 'bb', 'b': 'cc'})
    replacer.visit(tree)
    assert 'import bb, cc as c' == get_source(tree)

# Generated at 2022-06-21 18:43:21.495203
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        let(y)
        x += 1
        y = 1


# Generated at 2022-06-21 18:43:31.299122
# Unit test for constructor of class snippet
def test_snippet():
    source = """      
        def test():
            let(x)
            x += 1
            y = 1
        """
    tree = ast.parse(source)
    snippet = Snippet(tree.body[0].body)
    assert len([x for x in find(tree, ast.Call) if
                isinstance(x.func, ast.Name) and x.func.id == 'let']) == 0
    assert len([x for x in find(tree, ast.Call) if
                isinstance(x.func, ast.Name) and x.func.id == 'extend']) == 0
    assert snippet.get_body() == tree.body[0].body



# Generated at 2022-06-21 18:43:38.777645
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A(object):
        pass

    source = get_source(A)
    tree = ast.parse(source)
    variables = {'A': 'B'}
    VariablesReplacer.replace(tree, variables)

    expected_source = dedent('''
    class B(object):
        pass
    ''')
    assert astunparse.unparse(tree).strip() == expected_source.strip()



# Generated at 2022-06-21 18:43:43.896077
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class TestClass(ast.AST):
        _fields = ('attr',)
        _attributes = ('attr',)

    test = TestClass()
    test.attr = 'test'
    variables = {'test': 'test_refactor'}

    result = VariablesReplacer(variables).visit(test)
    assert(result.attr == 'test_refactor')


# Generated at 2022-06-21 18:43:56.202855
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> int:
        let(z)
        z = x + y
        return z

    snippet_kwargs = {'x': 1, 'y': 2}
    body = snippet(snippet_fn).get_body(**snippet_kwargs)
    assert body[0].value.id == '_py_backwards_z_0'
    assert body[1].value.left.id == '_py_backwards_z_0'
    assert body[1].value.op == '+'
    assert body[1].value.right.id == 'y'



# Generated at 2022-06-21 18:44:07.263208
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import rename_variables
    from .tree import find

    @let
    def _py_backwards_foo_0():
        from .helpers import rename_variables
        from .tree import find

        import foo
        import bar as bar

        extend(rename_variables((_py_backwards_foo_0, 'bar.bar')))

    tree = ast.parse(_py_backwards_foo_0.get_body())
    alias = find(tree, ast.alias, lambda n: n.name == 'bar')

    assert alias == [ast.alias(name='bar', asname='_py_backwards_foo_0')]

# Generated at 2022-06-21 18:44:15.790963
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_var = 'test_var'
    
    class TestClass:
        @snippet
        def test_method(a, b, c=1, d=2,
                        e: int=3, f: str=4, g: int=5) -> int:
            let(a)
            let(b)
            let(c)
            let(d)
            let(e)
            let(f)
            let(g)
            return a + b


# Generated at 2022-06-21 18:44:24.312616
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    # Prepare AST
    call_node = ast.Call(
        func=ast.Name(id='let', ctx=ast.Load()),
        args=[ast.Name(id='e', ctx=ast.Load())],
        keywords=[],
    )
    except_node = ast.ExceptHandler(
        type=None,
        name=ast.Name(id=call_node.args[0].id, ctx=ast.Load()),
        body=[],
    )
    exception_node = ast.Try(
        body=[call_node],
        handlers=[except_node],
        orelse=[],
        finalbody=[],
    )
    variables = {'e': 'e_0'}
    # Actual test
    visit_except_res = VariablesReplacer.replace(exception_node, variables)


# Generated at 2022-06-21 18:44:27.581046
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    tree = ast.parse('class Test: pass')
    assert VariablesReplacer.replace(tree, {'Test': 'A'}) == ast.parse('class A: pass')



# Generated at 2022-06-21 18:44:32.733599
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
let(x)
let(y)
extend(vars)
""")
    vars = ast.parse("x = 1")

    extend_tree(tree, {"vars": vars})

    expected = ast.parse("x = 1\nx = 1\n")

    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 18:44:39.739674
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    test_case = {"from t import x as y"}

    class CustomizeNodeTransformer(ast.NodeTransformer):
        def visit_alias(self, node):
            node.asname = 'toto'
            return self.generic_visit(node)

    v = CustomizeNodeTransformer()
    for test in test_case:
        tree = ast.parse(test)
        v.visit(tree)
        print(ast.dump(tree))

# Generated at 2022-06-21 18:44:45.506323
# Unit test for function extend_tree
def test_extend_tree():
    from .compile import compile

    @snippet
    def foo(a: str) -> None:
        extend(a)

    variables = {'x': 1, 'y': 2}
    result = compile(foo, a=variables).strip()
    expected = """(lambda x_0:
    x_0 = 1
    x_0 = 2
    return x_0)"""
    assert result == expected

# Generated at 2022-06-21 18:44:51.103009
# Unit test for function find_variables
def test_find_variables():
    source = """
    def fn():
        let(x)
        y = x
        let(z)
        print(x, y, z)
    """
    tree = ast.parse(source)
    names = find_variables(tree)
    assert list(names) == ['x', 'z']



# Generated at 2022-06-21 18:44:57.845666
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('foo(a=b)')
    variables = {'some_var': ast.Name(id='some_other_var', ctx=ast.Load())}
    res = VariablesReplacer.replace(tree, variables)
    assert res == ast.parse('foo(a=some_other_var)').body[0]  # type: ignore

# Generated at 2022-06-21 18:45:08.201872
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('x = 2 + 1; y = 2; z = x')
    variables = set(find_variables(tree))
    assert variables == {'x', 'y', 'z'}



# Generated at 2022-06-21 18:45:19.000575
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    # Test 1
    class_def = ast.ClassDef(name='a', bases=[], keywords=[], body=[], decorator_list=[])
    func_def = ast.FunctionDef(name='a', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)
    call = ast.Call(func=ast.Name(id='a', ctx=ast.Load()), args=[], keywords=[])
    node_list = find(class_def, ast.ClassDef) + find(func_def, ast.FunctionDef) + find(call, ast.Call)
    variables = {'a': 0}
    for node in node_list:
        node = VariablesReplacer.replace

# Generated at 2022-06-21 18:45:20.157711
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-21 18:45:28.001610
# Unit test for function extend
def test_extend():
    a = ast.parse('x=1;y=2')
    b = ast.parse('x=2')
    tree = ast.parse('let(vars);extend(vars);vars=1;x;y=2')
    extend_tree(tree, dict(vars=a))
    src = astor.to_source(tree)
    assert src == "vars = 1;\nn1 = 2;"

    extend_tree(tree, dict(vars=b))
    src = astor.to_source(tree)
    assert src == "vars = 1;\nn1 = 2;"


# Generated at 2022-06-21 18:45:39.497718
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    # pylint: disable=no-member
    # pylint: disable=unsubscriptable-object
    a = ast.arg(arg="a", annotation=None)
    b = ast.arg(arg="b", annotation=None)
    c = ast.arg(arg="c", annotation=None)
    d = ast.arg(arg="d", annotation=None)
    e = ast.arg(arg="e", annotation=None)
    args = [a, b, c, d, e]

    # Case 1
    var = {"a": "x", "b": "x", "c": "y", "d": "z"}
    replacer = VariablesReplacer(var)
    for i in range(len(args)):
        replacer.visit_arg(args[i])

# Generated at 2022-06-21 18:45:46.528941
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class TestVisitor(VariablesReplacer):
        def __init__(self, is_field: bool = False):
            super().__init__({})
            self.visited = []
            self.is_field = is_field

        def visit_Name(self, node: ast.Name) -> ast.Name:
            self.visited.append(node)

            if not self.is_field:
                return super().visit_Name(node)
            return node

    tree = ast.parse('x')
    visitor = TestVisitor()
    visitor.visit(tree)

    assert visitor.visited



# Generated at 2022-06-21 18:45:57.948765
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    extend_tree(tree, {'vars': [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ]})
    assert str(tree) == \
        "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), " \
        "Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2)), "

# Generated at 2022-06-21 18:46:03.687749
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class c:
        def foo(self):
            return 10
    v = VariablesGenerator()
    tree = ast.parse(inspect.getsource(c))
    replacer = VariablesReplacer({'c': v.generate('c')})
    replacer.visit_ClassDef(tree.body[0]) # type: ignore
    assert tree.body[0].name == v.generate('c') # type: ignore



# Generated at 2022-06-21 18:46:10.826260
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\nlet(y)')
    result = find_variables(tree)
    assert ('x', 'y') == tuple(result)

    tree = ast.parse('let(x)\nlet(y)\nprint(x, y)')
    result = find_variables(tree)
    assert ('x', 'y') == tuple(result)



# Generated at 2022-06-21 18:46:18.120394
# Unit test for function extend
def test_extend():
    tree = """class Test:
        extend(vars)
        def x(self):
            assert True
    """
    variables = {'vars': [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]}
    extend_tree(ast.parse(tree), variables)
    expected = """class Test:
        x = 1
        x = 2
        def x(self):
            assert True
    """
    assert ast.dump(ast.parse(tree)) == ast.dump(ast.parse(expected))


# Generated at 2022-06-21 18:46:28.422812
# Unit test for function find_variables
def test_find_variables():
    source = """
        let(a)
        a += 1
        def d(let(x), let(y), let(z)):
            x = 1
            y, z = 1, 2
            return x + y + z
        c = a + d(1, 2, 3) + b
        c += 1
        b = 3
    """
    tree = ast.parse(source)
    names = find_variables(tree)
    assert names == ['a', 'x', 'y', 'z']



# Generated at 2022-06-21 18:46:40.281715
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class_name = 'ClassName'
    ast_class_def = ast.Module(body=[ast.ClassDef(name=class_name, bases=[], keywords=[], body=[], decorator_list=[])])
    new_class_name = 'NewClassName'
    new_ast_class_def = ast.Module(body=[ast.ClassDef(name=new_class_name, bases=[], keywords=[], body=[], decorator_list=[])])
    var_dict = {class_name: new_ast_class_def}
    var_repl = VariablesReplacer(var_dict)
    var_repl.visit_ClassDef(ast_class_def.body[0])
    assert ast_class_def.body[0].name == new_class_name

# Generated at 2022-06-21 18:46:41.070583
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-21 18:46:46.951129
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x) x = 1')
    find_variables(tree)
    assert tree.body[0].value.target.id == 'x'

    tree = ast.parse('x = let(x)\nx = 1')
    find_variables(tree)
    assert tree.body[0].targets[0].id == 'x'

    tree = ast.parse('x = let(x)\ny = 2')
    find_variables(tree)
    assert tree.body[0].targets[0].id == 'x'
    assert tree.body[1].value.n == 2



# Generated at 2022-06-21 18:46:53.452471
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    def function(arg: int):
        let(arg)
        return arg + 1

    assert len(find_variables(ast.parse(get_source(function)))
               ) == 1, 'Should find just one variable'
    assert isinstance(ast.dump(function), str), 'Should dump AST to str'
    assert isinstance(snippet(function).get_body()[0],
                      ast.Assign), 'Should return first node of body'

# Generated at 2022-06-21 18:46:55.944009
# Unit test for function let
def test_let():
    from .test_snippets import test_let

    assert test_let == snippet(test_let).get_body()



# Generated at 2022-06-21 18:47:06.011224
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .parse import parse
    from .transform import transform
    source = b'''
import sys
from turtle import Turtle
from turtle import Turtle
'''
    tree = parse(source)
    variables = dict(sys="_py_backwards_sys_1", Turtle="_py_backwards_Turtle_2")
    expected_source = b'''
import _py_backwards_sys_1
from turtle import _py_backwards_Turtle_2
from turtle import _py_backwards_Turtle_2
'''
    expected_tree = parse(expected_source)
    VariablesReplacer.replace(tree, variables)
    assert transform(tree) == transform(expected_tree)



# Generated at 2022-06-21 18:47:12.581137
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    from .test_transformers import check_python_code
    from .helpers import VariablesGenerator
    vg = VariablesGenerator('_py_backwards')
    local_variables = {}
    tree = ast.parse("let(a=1)").body[0]
    variables = {tree.args[0].id: vg.generate()}
    tree = VariablesReplacer.replace(tree, variables)
    assert check_python_code(tree.args[0].value)

# Generated at 2022-06-21 18:47:17.512671
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import_tree = ast.parse("from x import y as z")

    variables = {"x": "a", "y": "b", "z": "c"}

    VariablesReplacer.replace(import_tree, variables)
    assert "from a import b as c" == ast.unparse(import_tree).strip()

# Generated at 2022-06-21 18:47:26.407773
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('''
        class C(object):
            def __init__(self, yyy):
                self.yyy = yyy

            def f(self):
                self.yyy += 1
                print(self.yyy + 1)
        ''')

    # _py_backwards_C_0 = C
    C = ast.Name(id='C', ctx=ast.Load())
    _py_backwards_C_0 = ast.Name(id='_py_backwards_C_0', ctx=ast.Store())
    C_assign = ast.Assign(targets=[
        _py_backwards_C_0
    ], value=C)

    # _py_backwards_self_0 = self

# Generated at 2022-06-21 18:47:34.698043
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: None)

# Generated at 2022-06-21 18:47:41.362834
# Unit test for function let
def test_let():
    source = """
    let(x)

    x = 1
    y = 1
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert variables == {'x'}
    assert astor.to_source(tree) == """
    x = 1
    y = 1
    """



# Generated at 2022-06-21 18:47:46.134962
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from typed_ast import ast3
    register_classes()
    variables = {'a_class':ast.Name('test','test.test')}
    replacer = VariablesReplacer(variables)
    node = ast3.ExceptHandler()
    replacer.visit(node)

# Generated at 2022-06-21 18:47:48.512418
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    tree = ast.parse("class TestCls: pass")
    variables = {"TestCls": ast.ClassDef("TestCls", None, None, [], [])}
    VariablesReplacer.replace(tree, variables)
    assert VariablesReplacer.replace(tree, variables) == ast.parse("class TestCls: pass")


# Generated at 2022-06-21 18:47:55.862561
# Unit test for function extend
def test_extend():
    class snippet1(snippet):
        def __init__(self):
            super().__init__(self)

        def test(self, x):
            x += 1

    class snippet2(snippet):
        def __init__(self):
            super().__init__(self)

        def test(self, x):
            extend(self)
            x += 1

        def extend(var):
            var += 1
            var += 1

    """The body of the snippet1 would be:
    [Assign(
        targets=[x],
        value=BinOp(
            left=Name(
                id=x,
                ctx=Load()
            ),
            op=Add(),
            right=Num(
                n=1
            )
        )
    )]
    """

# Generated at 2022-06-21 18:48:02.997550
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    expected = ast.parse('_py_backwards_x_0 = 5')

    code = 'x = 5'
    tree = ast.parse(code)
    variables = {'x': VariablesGenerator.generate('x')}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree, include_attributes=True) == ast.dump(expected, include_attributes=True)



# Generated at 2022-06-21 18:48:13.144349
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    # arrange
    node = ast.ExceptHandler(
        type=ast.Name(id="Exception", ctx=ast.Load()),
        name=ast.Name(id="e", ctx=ast.Store()),
        body=[
            ast.Expr(
                value=ast.Str(s=ast.Str(s="b"))
            ),
            ast.Raise(
                exc=None,
                cause=None,
                type=None
            )
        ],
        lineno=1,
        col_offset=0
    )
    variables = {
        "e": "ee"
    }

    # act
    node = VariablesReplacer.replace(node, variables)

    # assert
    assert node.name.id == "ee"



# Generated at 2022-06-21 18:48:21.874888
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    node = ast.ClassDef(
        name='Z',
        bases=[],
        keywords=[],
        body=[],
        decorator_list=[],
        lineno=1,
        col_offset=1
    )
    variables = {
        'name': ast.Name(id='_py_backwards_name_0', ctx=ast.Load(), lineno=1, col_offset=1),
    }
    VariablesReplacer.replace(node, variables)
    print(node.name)



# Generated at 2022-06-21 18:48:24.500081
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    replacer = VariablesReplacer({})
    node = ast.alias("A", "B")
    assert replacer.visit_alias(node) == node



# Generated at 2022-06-21 18:48:26.035915
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class_name = VariablesGenerator.generate('foo')


# Generated at 2022-06-21 18:48:44.857585
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
  tree = ast.parse('from a.b import c')
  variables = {
    'a': {'b': {'c': 'd'}}
  }
  inst = VariablesReplacer(variables)
  inst.visit(tree)
  assert get_source(tree) == 'from a.b.c import d'


# Generated at 2022-06-21 18:48:52.008532
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_a = ast.ImportFrom(level=0, module='import_a', names=[
                              ast.alias(name="func_a", asname=None)])
    import_b = ast.ImportFrom(level=0, module='import_b', names=[
                              ast.alias(name="func_b", asname=None)])

    assert VariablesReplacer.replace(import_a, {
        "import_a": "import_c",
        "func_a": "func_c"
    }) == import_b



# Generated at 2022-06-21 18:48:57.431574
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('def a(b): b + 1')
    assert tree.body[0].name == 'a'
    VariablesReplacer.replace(tree, {'b': 'c'})
    assert tree.body[0].name == 'c'
    assert tree.body[0].args.args[0].arg == 'c'



# Generated at 2022-06-21 18:49:03.505689
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import pytest
    class TestCls:
        def test(self):
            try:
                raise Exception()
            except Exception as e:
                pass

    source = get_source(TestCls)
    tree = ast.parse(source)

    variables = {'e': VariablesGenerator.generate('e')}
    VariablesReplacer.replace(tree, variables)


# Generated at 2022-06-21 18:49:10.512097
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test_fn():
        let(x)
        x = 1
        y = 2
        z = x + y
        return z

    def test_fn():
        let(a)
        let(b)
        let(c)
        let(d)
        extend(vars_)
        let(e)
        let(f)
        let(g)
        let(h)
        return [a, b, c, d, e, f, g, h]


# Generated at 2022-06-21 18:49:11.130065
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet is not None

# Generated at 2022-06-21 18:49:16.224798
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class Test(ast.NodeTransformer):
        def visit_alias(self, node: ast.alias) -> ast.alias:
            setattr(node, 'name', 'name')
            return node

    tree = Test().visit(ast.parse('from . import name'))
    assert get_source(tree) == 'from . import name'

# Generated at 2022-06-21 18:49:17.109579
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-21 18:49:21.154515
# Unit test for function find_variables
def test_find_variables():
    variables = find_variables(ast.parse("let(x)\nlet(y)\nx = 1\ny = 2"))
    assert variables == {'x', 'y'}



# Generated at 2022-06-21 18:49:28.097260
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse("""
    def fn(arg):
        pass
    """)
    variables = {'arg': 'new_arg'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == '''
    Module(body=[FunctionDef(name='fn', args=arguments(args=[arg(arg='new_arg')], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])
    '''

# Generated at 2022-06-21 18:49:50.697777
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse('try: pass\nexcept Exception as Ex: pass\n')
    variables = {'Ex': VariablesGenerator.generate('Ex')}
    VariablesReplacer.replace(tree, variables)
    # We are comparing only the second line because the first one will be
    # rewritten anyway
    assert tree.body[0].body[0].name == variables['Ex']


# Generated at 2022-06-21 18:49:56.478901
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class C:
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node = self._replace_field_or_node(node, 'name')
            return self.generic_visit(node)  # type: ignore

    class D(C):
        pass

    assert type(D().visit_ClassDef('')) == str


# Generated at 2022-06-21 18:49:58.683772
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from ast_helpers import ast_helpers
    from .helpers import VariablesGenerator

# Generated at 2022-06-21 18:50:03.809350
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('def foo():\n\tpass')
    variables = {'foo': 'bar'}
    t = VariablesReplacer.replace(tree, variables)
    assert ast.dump(t, include_attributes=False) == tree
    assert ast.dump(t, include_attributes=True) == ast.dump(tree, include_attributes=True)

# Generated at 2022-06-21 18:50:09.913490
# Unit test for function let
def test_let():
    @snippet
    def example():
        let(x)
        x += 1
        y = 1
    body = example.get_body()
    assert body == [
        ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                   ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                             ast.Add(),
                             ast.Num(1))),
        ast.Assign([ast.Name('y', ast.Store())],
                   ast.Num(1))
    ]



# Generated at 2022-06-21 18:50:14.738995
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    """Unit test for method visit_keyword of class VariablesReplacer"""
    ast_node = ast.Name("keyword")
    ast_node = VariablesReplacer.replace(ast_node, variables={"keyword": "arg"})
    assert ast_node.id == "arg"

# Generated at 2022-06-21 18:50:15.406200
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:50:20.188013
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .test_helpers import get_alias
    
    alias = get_alias()
    v = {'x': 'y'}
    replacer = VariablesReplacer(v)
    replacer.visit_alias(alias)
    assert alias.name == 'y'

test_VariablesReplacer_visit_alias()

# Generated at 2022-06-21 18:50:25.234440
# Unit test for function extend
def test_extend():
    x = 100
    tree = ast.parse("extend(vars)\ny = x")
    extend_tree(tree, {"vars": [ast.Assign([ast.Name("x", ast.Store())], ast.Num(5))]})
    assert eval(compile(tree, filename="<ast>", mode="exec")) == 5



# Generated at 2022-06-21 18:50:30.401682
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    import pytest
    
    code = """
    def x(x, y=x):
        pass
    """
    
    tree = ast.parse(code)
    variables = {"x": "changed"}
    assert "changed" == tree.body[0].args.args[0].arg

    VariablesReplacer.replace(tree, variables)
    assert "changed" == tree.body[0].args.args[0].arg
    assert "changed" == tree.body[0].args.defaults[0].id

# Generated at 2022-06-21 18:51:15.875799
# Unit test for function extend
def test_extend():
    def fn(x):
        extend(vars)
        return x + y

    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(2))]

    snippet_ = snippet(fn)
    snippet_body = snippet_.get_body(x=23, y=42)

    assert snippet_body == vars + [ast.Return(value=ast.BinOp(left=ast.Name(id='x'),
                                                             op=ast.Add(),
                                                             right=ast.Name(id='y')))]


# Generated at 2022-06-21 18:51:23.685074
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .snippets import test_snippet_extend, test_snippet_let
    from .snippets import test_snippet_extend_var, test_snippet_let_var

    assert snippet.get_body(test_snippet_extend) == snippet(test_snippet_extend).get_body()
    assert snippet.get_body(test_snippet_let) == snippet(test_snippet_let).get_body()
    assert snippet.get_body(test_snippet_extend_var) == snippet(test_snippet_extend_var).get_body()
    assert snippet.get_body(test_snippet_let_var) == snippet(test_snippet_let_var).get_body()