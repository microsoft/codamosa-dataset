

# Generated at 2022-06-21 18:41:58.647104
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    @snippet
    def fn():
        let(foo)
        class Foo:
            pass
        return Foo

    tree = fn.get_body()
    class_name = tree[0].name
    class_def = tree[1]
    assert class_name == '_py_backwards_foo_0', "Wrong class name"
    assert isinstance(class_def, ast.ClassDef), "Wrong node kind"
    assert class_def.name == 'Foo', "Wrong class definition"



# Generated at 2022-06-21 18:42:00.217883
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-21 18:42:06.694128
# Unit test for function extend_tree
def test_extend_tree():
    code = """
let(module)
extend(module)
"""
    tree = ast.parse(code)
    module = ast.Module([
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2)),
    ])
    extend_tree(tree, {'module': module})
    assert tree.body == module.body

# Generated at 2022-06-21 18:42:18.681400
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A:
        @classmethod
        def create(cls, a, b):
            if a > b:
                return cls(a, b)
            return cls(b, a)
        def __init__(self, a, b):
            self.a = a
            self.b = b
    module = ast.parse(inspect.getsource(A))
    module = VariablesReplacer.replace(module, {'A': 'B'})
    import_from = module.body[0]
    assert isinstance(import_from, ast.ImportFrom)
    class_def = import_from.names[0].name
    assert isinstance(class_def, ast.ClassDef)
    assert class_def.name == 'B'
    assert class_def.bases[0].id == 'object'


# Generated at 2022-06-21 18:42:30.086480
# Unit test for function let
def test_let():
    @snippet
    def fn():
        let(a)
        let(b)
        a += 1
        b += 2


# Generated at 2022-06-21 18:42:33.742751
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse('''from . import x''')
    variables = {'x': 'y'}
    VariablesReplacer.replace(tree, variables)
    assert(tree.body[0].module == '.y')



# Generated at 2022-06-21 18:42:35.854238
# Unit test for constructor of class snippet
def test_snippet():
    _snippet = snippet(lambda x: x + 1)
    assert _snippet is not None


# Generated at 2022-06-21 18:42:41.249462
# Unit test for function let
def test_let():
    def test_fn():
        x = 1
        let(x)
        x += 1

    snippet_fn = snippet(test_fn)
    snippet_ast = snippet_fn.get_body()

    assert get_source(snippet_ast) == '_py_backwards_x_0 += 1'



# Generated at 2022-06-21 18:42:47.128075
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    fn_str = "let(x)"

    source = 'def foo():\n    a = 1\n    print(a)\n    return x'

    tree = ast.parse(source)

    variables = {
        "x": ast.Call(
            func=ast.Name(id="a", ctx=ast.Load()),
            args=[],
            keywords=[],
        ),
    }
    VariablesReplacer.replace(tree, variables)

    assert source != get_source(tree)
    assert get_source(variables["x"]) in get_source(tree)

# Generated at 2022-06-21 18:42:54.747683
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class C(ast.NodeVisitor):
        def visit_arg(self: ast.NodeVisitor, node: ast.arg) -> ast.arg:
            def f(arg: ast.arg) -> str:
                return arg.arg + 'f'
            node = f(node)
            return self.generic_visit(node)
    c = C()
    node = ast.arg(arg='x', annotation=None)
    node = c.visit(node)
    assert node.arg == 'xf'

# Generated at 2022-06-21 18:43:04.869480
# Unit test for function find_variables
def test_find_variables():
    code = """
    let(a)
    let(b)
    """
    tree = ast.parse(code)
    assert set(find_variables(tree)) == set(['a', 'b'])


# Generated at 2022-06-21 18:43:08.882178
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from .helpers import normalize_source
    from .tree import get_body
    from .changes import apply_changes

    source = normalize_source('''
        try:
            pass
        except e:
            pass
    ''')

    changes = [('replace', 'e', 'exc')]
    result_source = normalize_source('''
        try:
            pass
        except exc:
            pass
    ''')

    body = get_body(ast.parse(source))
    VariablesReplacer.replace(body, {})
    apply_changes(body, changes)
    assert get_source(body) == result_source

# Generated at 2022-06-21 18:43:16.370080
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def func(x):
        pass
    source = get_source(func)
    tree = ast.parse(source)
    node = find(tree, ast.FunctionDef)
    functions_generator = VariablesGenerator()
    variables = {'x': functions_generator.generate('x')}
    old_node = node.name
    new_node = VariablesReplacer.replace(node, variables).name
    assert old_node == 'func'
    assert new_node == variables['x']


# Generated at 2022-06-21 18:43:24.702127
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def f():
        let(x)
        return x

    assert f.get_body() == ast.Module(body=[ast.Return(value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()))]).body
    assert f.get_body(x=1) == ast.Module(body=[ast.Return(value=ast.Num(n=1))]).body
    assert f.get_body(x=ast.Num(n=1)) == ast.Module(body=[ast.Return(value=ast.Num(n=1))]).body



# Generated at 2022-06-21 18:43:31.570975
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import unittest
    from ..utils.printer import print_ast
    class TestVariablesReplacer(unittest.TestCase):
        variables = {'cls': '_py_backwards_cls_0'}
        def test_replace(self):
            source = 'class A: pass'
            tree = ast.parse(source)
            VariablesReplacer.replace(tree, TestVariablesReplacer.variables)
            print(print_ast(tree))

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-21 18:43:32.477400
# Unit test for constructor of class snippet
def test_snippet():
    ret = snippet(int)

# Generated at 2022-06-21 18:43:40.097508
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    cls = VariablesReplacer({'x': '_py_backwards_x'})
    assert cls.visit_keyword(ast.keyword(arg='x', value=None)) == ast.keyword(arg='_py_backwards_x', value=None)
    assert cls.visit_keyword(ast.keyword(arg='y', value=None)) == ast.keyword(arg='y', value=None)

# Generated at 2022-06-21 18:43:51.336330
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    name_node = ast.Name(id='name', ctx=ast.Load())
    string_node = ast.Str(s='hello')
    function_node = ast.FunctionDef(name='function_name', args=ast.arguments(args=[ast.arg(arg='arg_name')]))
    attributes_node = ast.Attribute(value=function_node, attr='attr', ctx=ast.Load())
    keyword_node = ast.keyword(arg='arg_name')
    class_node = ast.ClassDef(name='class_name')
    arg_node = ast.arg(arg='arg_name')
    import_node = ast.ImportFrom(module='module_name', names=[ast.alias(name='module_name')])
    except_node = ast.ExceptHandler(type=name_node)
   

# Generated at 2022-06-21 18:43:55.245882
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('def f(x):\n    x = 0')
    variables_dict = {'x': 'y'}
    VariablesReplacer.replace(tree, variables_dict)
    assert get_source(tree) == 'def f(y):\n    y = 0'

# Generated at 2022-06-21 18:43:58.539849
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
try:
    1/0
except ZeroDivisionError:
    pass
"""
    tree = ast.parse(source)
    result = VariablesReplacer.replace(tree, {'ZeroDivisionError': 'ZeroDivisionErrorz'})

    assert(ast.dump(result) == ast.dump(tree))


# Generated at 2022-06-21 18:44:07.779066
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(snippet)

# Generated at 2022-06-21 18:44:10.752205
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Example():
        def __init__(self):
            """this is a test docstring"""


# Generated at 2022-06-21 18:44:19.663594
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import astunparse
    from . import helpers
    from .helpers import VariablesGenerator
    
    class PickleTest(helpers.TestCase):
        def test_pickle_basic_classdef(self):
            node = ast.parse('''
            class Foo:
                pass
            ''')
            node = node.body[0]
            variables = {'Foo': VariablesGenerator.generate('Foo')}
            n = VariablesReplacer.replace(node, variables)
            self.assertEqual(astunparse.unparse(n), '\nclass _py_backwards_Foo_0:\n    pass\n')
    
    PickleTest('test_pickle_basic_classdef').run()

# Generated at 2022-06-21 18:44:26.501463
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test():
        let(x)
        x += 1
        y = 1

    body = test.get_body(x=1)
    assert_equal(
        body,
        [
            ast.AugAssign(
                target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()),
                op=ast.Add(),
                value=ast.Constant(1, kind=None)),
            ast.Assign(
                targets=[ast.Name(id='y', ctx=ast.Store())],
                value=ast.Constant(1, kind=None))
        ])



# Generated at 2022-06-21 18:44:33.034624
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():

    # Test case:
    input = '''
    class MyClass(object):
        foo = 1
    '''

    # Expected:
    expected = '''
    class MyClass(object):
        foo = 1
    '''
    # Get tree
    tree = ast.parse(input)

    # Execute replace
    VariablesReplacer.replace(tree, {})

    # Check result
    assert(ast.dump(tree, False) == expected)


# Generated at 2022-06-21 18:44:44.851731
# Unit test for function find_variables
def test_find_variables():
    tree1 = ast.parse("""
    let(y)
    """)
    assert list(find_variables(tree1)) == ['y']

    tree2 = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert sorted(find_variables(tree2)) == ['x', 'y', 'z']

    tree3 = ast.parse("""
    let(x)
    y = x
    let(z)
    """)
    assert sorted(find_variables(tree3)) == ['x', 'z']

    tree4 = ast.parse("""
    let(x)
    x += 1
    let(y)
    """)
    assert sorted(find_variables(tree4)) == ['x', 'y']



# Generated at 2022-06-21 18:44:49.989950
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\nx = 1\nlet(y)\ny = 2\nprint(1, 2)')
    assert find_variables(tree) == {'x': '_py_backwards_x_0',
                                    'y': '_py_backwards_y_1'}

# Generated at 2022-06-21 18:44:52.861198
# Unit test for function let
def test_let():
    from .test_snippets import test_let
    test_let()



# Generated at 2022-06-21 18:45:01.225177
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class TestTransformer(VariablesReplacer):
        def __init__(self, variables: Dict[str, Variable]):
            self._variables = variables

    def test():
        obj.attr = 1

    source = get_source(test)
    tree = ast.parse(source)
    obj, attr = VariablesGenerator.generate('obj'), VariablesGenerator.generate('attr')
    variables = {'obj': obj, 'attr': attr}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].value.func.value.id == obj

# Generated at 2022-06-21 18:45:12.837129
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class TestException(Exception):
        pass

    class TestException2(Exception):
        pass

    def foo():
        print('foo')

    def bar():
        print('bar')

    def test():
        try:
            foo()
        except TestException as e:
            print(e)
        except TestException2:
            bar()

    test_tree = ast.parse(get_source(test))
    test_tree_exception = ast.parse(get_source(test))
    variable = VariablesGenerator.generate('TestException')
    test_tree_exception.body[0].body[0].body[1].type.names[0] = variable  # type: ignore
    VariablesReplacer.replace(test_tree_exception, {'TestException': variable})

    assert test_tree == test_tree

# Generated at 2022-06-21 18:45:23.801132
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(let(1))) == ['1']
    assert list(find_variables(let(1) + let(2))) == ['1', '2']



# Generated at 2022-06-21 18:45:27.014316
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def test(x: str, y: str = '1') -> None:
        let(x)
        x += y
        y = 1
        print(y)
    assert hasattr(test, 'get_body')



# Generated at 2022-06-21 18:45:38.538343
# Unit test for function extend
def test_extend():
    def foo(**kwargs):
        extend(param)
        print(x, y)
    
    param = [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
             ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))]
    x, y = 1, 2
    snippet_obj = snippet(foo)

# Generated at 2022-06-21 18:45:47.048074
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import json
    import re
    from astor import to_source
    from .helpers import VariablesGenerator
    from .main import snippet, let
    from .codegen import get_snippet_code
    from .tree import get_non_exp_parent_and_index, replace_at
    from .variables import find_variables, VariablesReplacer

    def sample_func(x: str) -> str:
        """Snippet body."""
        from requests.app import app

        let(app)
        data = {'value': f'{x}'}
        resp = app.post(data)
        return resp.content.decode('utf-8')

    body = to_source(snippet(sample_func).get_body(x='1')).strip()

# Generated at 2022-06-21 18:45:53.504036
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    input = ast.parse(
        """class N:
        pass"""
    )
    expected = ast.parse(
        """class N:
        pass"""
    )
    variables = {
        "N": ast.parse(
            """class N:
        pass"""
        )
    }
    actual = VariablesReplacer.replace(input, variables)
    assert ast.dump(expected) == ast.dump(actual)



# Generated at 2022-06-21 18:45:58.231594
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class1 = ast.ClassDef(name='class1', body=[])
    vars = {'x': ast.Name('class1')}
    expected = ast.ClassDef(name='class1', body=[])
    VariablesReplacer.replace(class1, vars)
    assert class1 == expected


# Generated at 2022-06-21 18:46:06.445492
# Unit test for method visit_alias of class VariablesReplacer

# Generated at 2022-06-21 18:46:13.026580
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    """
    >>> tree = ast.parse('def foo(): pass')
    >>> vars = VariablesGenerator.generate_variable_dictionary(['foo'])
    >>> VariablesReplacer.replace(tree, vars)
    ast.Module(body=[ast.FunctionDef(name='_py_backwards_foo_0', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)])
    """
    pass


# Generated at 2022-06-21 18:46:17.629802
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = """
    def f():
        def f():
            x = 1
        f()
    """
    tree = ast.parse(source)
    v = VariablesGenerator.generate('x')
    variables = {'x': v}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == """
    def f():
        def f():
            _py_backwards_x_0 = 1
        f()
    """



# Generated at 2022-06-21 18:46:21.965947
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('a')
    variables = {'a': 'b'}
    inst = VariablesReplacer(variables)
    a = inst.visit(tree)
    assert a.body[0].value.id == 'b'


# Generated at 2022-06-21 18:46:38.790014
# Unit test for function find_variables
def test_find_variables():
    from astunparse import unparse

# Generated at 2022-06-21 18:46:42.186741
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('x.y.z')
    variables = dict(x='xx', y='yy')
    inst = VariablesReplacer(variables)
    res = inst.visit(tree)
    assert str(res) == 'xx.yy.z'



# Generated at 2022-06-21 18:46:50.076632
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    body = snippet(lambda x, y: let(x) + y)(1, 2).get_body()
    assert body == [ast.Assign(
        targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
        value=ast.BinOp(
            left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            op=ast.Add(),
            right=ast.Name(id='y', ctx=ast.Load())
        )
    )]

# Generated at 2022-06-21 18:46:55.987144
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = "from .models import Movie"
    tree = ast.parse(source)
    variables = {'Movie': 'Movie'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert ast.dump(tree.body[0]) == "ImportFrom(module='.', names=[alias(name='models.Movie', asname=None)], level=0)"


# Generated at 2022-06-21 18:47:00.404478
# Unit test for function extend
def test_extend():
    class TestClass(object):
        def test(self):
            x = 1
            def f():
                x = 2
                extend(vars())
                print(x)

            vars()
        pass
    
    code = get_source(TestClass.test)

# Generated at 2022-06-21 18:47:11.717486
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    node = ast.FunctionDef('name', ast.arguments([ast.arg('self')], b=None, kwonlyargs=[ast.arg('a'), ast.arg('b')],
                                                 kw_defaults=[ast.Num(1), ast.Num(2)], kwarg=ast.arg('kwargs')), [],
                           [], ast.Name('name'), ast.Name('name'), 123)
    node = VariablesReplacer({'name': 'othername'}).visit(node)
    assert node.name == 'othername'
    assert node.args.args[0].arg == 'othername'
    assert node.args.kwonlyargs[0].arg == 'a'
    assert node.args.kwonlyargs[1].arg == 'b'

# Generated at 2022-06-21 18:47:22.888714
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    if not hasattr(__builtins__, 'unicode'):
        setattr(__builtins__, 'unicode', str)
    if not hasattr(__builtins__, 'long'):
        setattr(__builtins__, 'long', int)
    if not hasattr(__builtins__, 'xrange'):
        setattr(__builtins__, 'xrange', range)
    if not hasattr(__builtins__, 'raw_input'):
        setattr(__builtins__, 'raw_input', input)

    tree = ast.parse("""
    class A():
        def __init__(self):
            self.x = 1
            self.y = 2
            
    a = A()
    a.x = a.y
    a.x = 2
    """)
    variables

# Generated at 2022-06-21 18:47:34.458041
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Test:
        def __init__(self, a, b):
            self.x = a
            self.y = b + 1
            self.z = 1
            self.get = self.x

        @staticmethod
        def f(a, b):
            return a + b

    fn = Test.f

    # ClassDef with body, decorators and bases
    source = get_source(fn)
    tree = ast.parse(source)
    var1 = VariablesGenerator.generate()
    var2 = VariablesGenerator.generate()
    var3 = VariablesGenerator.generate()
    variables = {'Test': var1, 'x': var2, 'y': var3}
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-21 18:47:37.000657
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import math
    import random
    import math
    import random



# Generated at 2022-06-21 18:47:48.974559
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from . import snippet, let, extend
    from .tree import get_body

    def test():
        let(a)
        extend(ext)
        for i in range(4):
            a += ext

    source = get_source(test)
    body = snippet(test).get_body(
        ext=[ast.AnnAssign(
            target=ast.Name(id='a', ctx=ast.Store()),
            value=ast.Num(n=1),
            annotation=None
        ), ast.AnnAssign(
            target=ast.Name(id='a', ctx=ast.Store()),
            value=ast.Num(n=2),
            annotation=None
        )],
        a=1
    )

    assert body == get_body(source)

# Generated at 2022-06-21 18:48:26.004754
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = 'from foo import bar\n'
    tree = ast.parse(source)
    assert tree.body[0].names[0].name == 'bar'
    VariablesReplacer.replace(tree, {'foo': 'other_foo'})
    assert tree.body[0].module == 'other_foo'
    assert tree.body[0].names[0].name == 'bar'


# Generated at 2022-06-21 18:48:33.365783
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('x = 1').body[0]
    replacer = VariablesReplacer({'x': ast.Name(id='y')})
    result = replacer.visit(tree)
    assert isinstance(result, ast.Assign)
    assert isinstance(result.targets[0], ast.Name)
    assert result.targets[0].id == 'y'
    assert isinstance(result.value, ast.Num)
    assert result.value.n == 1


# Generated at 2022-06-21 18:48:37.828983
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    input = 'a = b.c'
    tree = ast.parse(input)
    variables = find_variables(tree)
    expected = 'd = b.e'
    actual = VariablesReplacer.replace(input, variables)
    assert actual == expected


# Generated at 2022-06-21 18:48:42.062999
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class1 = ast.ExceptHandler(type=None, name=None, body=None)
    class2 = ast.ExceptHandler(type=None, name=None, body=None)
    tree = ast.ExceptHandler(type=None, name=class1, body=None)
    variables = {class1: class2}
    VariablesReplacer.replace(tree, variables)
    assert tree == class2

# Generated at 2022-06-21 18:48:52.659035
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():

    def snip():
        def let(func):
            return func

        def let(arg1):
            return arg1

    source = get_source(snip)
    tree = ast.parse(source)
    name = find(tree, ast.Name)
    name[0].id = 'some_name'
    name[1].id = 'some_name'
    v = VariablesReplacer({'func': ['func_1', 'func_2'], 'arg1': ['arg1_1', 'arg1_2']})
    node = v.visit(tree)

# Generated at 2022-06-21 18:48:54.633684
# Unit test for constructor of class snippet
def test_snippet():
    def test():
        let(x)
        x += 1

    assert snippet(test)



# Generated at 2022-06-21 18:49:00.254328
# Unit test for function extend
def test_extend():
    def main():
        extend(vars)

        """
        x = 123
        """

    vars = [
        ast.parse('x = 1').body[0],
        ast.parse('x = 2').body[0],
    ]

    print(snippet(main).get_body(vars=vars))



# Generated at 2022-06-21 18:49:03.945727
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class Test(ast.NodeVisitor):
        def generic_visit(self, node):
            pass
    node = ast.parse("from test import aaa as bbb").body[0]
    assert Test().visit(node) is None


# Generated at 2022-06-21 18:49:12.386700
# Unit test for function extend
def test_extend():
    from . import snippet, let, extend
    @snippet
    def test_extend_snippet(vars_node):
        extend(vars_node)
    tree = ast.parse("x = 1\ny = 2")
    for node in tree.body:
        assert isinstance(node, ast.Assign)
    test_extend_snippet(tree.body)
    assert test_extend_snippet.get_body() == tree.body

# Generated at 2022-06-21 18:49:22.695570
# Unit test for function extend_tree
def test_extend_tree():
    from .tree import flatten
    from .helpers import parse_and_unparse


# Generated at 2022-06-21 18:50:41.799545
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_snippet(a, b=7):
        let(x)
        x += 1
        y = 1
    snippet_obj = snippet(my_snippet)
    body = snippet_obj.get_body()
    source = ast.dump(body)
    assert source.replace(" ", "") == "[Assign([Name(_py_backwards_x_0,Store())],BinOp(Name(_py_backwards_x_0,Load()),Add(),Num(1))),Assign([Name(y,Store())],Num(1))]".replace(" ", "")



# Generated at 2022-06-21 18:50:46.771287
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
try:
    pass
except Exception as e:
    logger.exception(e)
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    for name in variables:
        variables[name] = VariablesGenerator.generate(name)
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == source

# Generated at 2022-06-21 18:50:50.191449
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    module = ast.parse("from math import pi as _PI")
    module.body[0] = VariablesReplacer.replace(module.body[0], {"_PI": "PI"})

    expected_module = ast.parse("from math import pi as PI")
    assert module == expected_module

# Generated at 2022-06-21 18:50:57.186508
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1

    snippet = snippet(fn)
    assert snippet.get_body() == [
        ast.Assign(
            targets=[ast.Name("_py_backwards_x_0")],
            value=ast.BinOp(
                left=ast.Name("_py_backwards_x_0"),
                op=ast.Add(),
                right=ast.Num(1)
            )
        ),
        ast.Assign(
            targets=[ast.Name("y")],
            value=ast.Num(1)
        )
    ]

# Generated at 2022-06-21 18:51:04.667383
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    a = ast.Alias("a", "a")
    b = ast.Alias("b", "b")
    c = ast.Alias("c", "c")
    list_ = [a, b, c]
    node = ast.copy_location(ast.Import(list_), a)
    node = VariablesReplacer.replace(node, {"a": "c"})
    assert type(node.names[0]) == ast.alias
    assert node.names[0].name == "c"
    assert node.names[0].asname == "c"

# Generated at 2022-06-21 18:51:15.439817
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def f():
        let(x)
        x += 1
        y = x
        extend(z)
    print(f.get_body(x=1, z=[ast.Assign([ast.Name('y', ast.Store())], ast.Num(n=2))]))

# Generated at 2022-06-21 18:51:20.873042
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    name = ast.Name('a', ast.Store())
    name.id = 'b'
    cls = ast.ClassDef(
        name=name,
        bases=[],
        body=[],
        keywords=[],
        starargs=None,
        kwargs=None)
    variables = {'b': ast.Name('a', ast.Store())}
    VariablesReplacer.replace(cls, variables)
    assert cls.name.id == 'a'

# Generated at 2022-06-21 18:51:27.524720
# Unit test for function let
def test_let():
    @snippet
    def code():
        let(x)
        x += 1
        let(y)
        return x + y
    assert code.get_body() == ast.parse("""
_py_backwards_x_0 += 1
_py_backwards_y_1 = 0
return _py_backwards_x_0 + _py_backwards_y_1
""").body



# Generated at 2022-06-21 18:51:28.467542
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:51:30.410038
# Unit test for method visit_Name of class VariablesReplacer