

# Generated at 2022-06-21 18:41:54.339115
# Unit test for constructor of class snippet
def test_snippet():
    with pytest.raises(TypeError):
        snippet()

# Generated at 2022-06-21 18:42:03.994024
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('\n'.join([
        'def extend(a): pass',
        'extend(x)',
        'extend(y)',
        'print(x, y)',
    ]))

    extend_tree(tree, {
        'x': [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
              ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))],
        'y': ast.Num(3),
    })

    expected = '\n'.join([
        'x = 1',
        'x = 2',
        'print(x, 3)',
    ])
    assert expected == get_source(tree)



# Generated at 2022-06-21 18:42:10.588451
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
  tree = ast.parse("from mod import a as b")
  variables = {"mod" : "modified_mod", "a" : "modified_a"}
  replacer = VariablesReplacer(variables)
  replacer.visit(tree)
  assert get_source(tree.body[0]) == "from modified_mod import modified_a as b\n"

# Generated at 2022-06-21 18:42:17.212727
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    ast_tree = ast.parse('def func(x,y): pass')
    vars_map = {'x':'z','y':'z'}
    ast_tree_transformed = VariablesReplacer.replace(ast_tree, vars_map)
    assert ast_tree_transformed.body[0].args.args[0].id == 'z'
    assert ast_tree_transformed.body[0].args.args[1].id == 'z'



# Generated at 2022-06-21 18:42:21.289866
# Unit test for function find_variables
def test_find_variables():
    snippet_ast = ast.parse(""" 
let(a)
let(b)
let(c)
let(d)
""").body[0]

    result = list(find_variables(snippet_ast))

    assert result == ['a', 'b', 'c', 'd']

# Generated at 2022-06-21 18:42:29.822716
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class T:
        def __init__(self, arg : str) -> None:
            self.arg = arg
    node = T('key')
    # Replace all values of 'arg' attribute with 'newkey'
    VariablesReplacer.replace(node, {'key' : 'newkey'})
    assert node.arg == 'newkey'
    # Replace only str values of 'arg' attribute with 'newkey'
    VariablesReplacer.replace(node, {'key' : [1,2,3]})
    assert node.arg == 'newkey'

# Generated at 2022-06-21 18:42:31.974493
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(foo)\nlet(bar)')
    assert list(find_variables(tree)) == ['foo', 'bar']



# Generated at 2022-06-21 18:42:38.423846
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from . import core  # type: ignore
    from .tree import get_source

    source = get_source(core.code(extend, core.functions()))
    tree = ast.parse(source)
    variables = {
        'extend': ('module', 'module'),
    }
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert get_source(tree) == 'from module import module'

# Generated at 2022-06-21 18:42:46.691382
# Unit test for function extend
def test_extend():
    tree = ast.parse("""
let(z)
extend(g)


print(z)
""")

    g = [ast.Assign([ast.Name(id='z')], ast.Num(n=5))]
    extend_tree(tree, {'g': g})
    variables = {'g': 'g', 'z': 'z'}
    VariablesReplacer.replace(tree, variables)
    ast.fix_missing_locations(tree)
    assert compile(tree, '', 'exec').co_code == compile("""
z = 5
print(z)
""", '', 'exec').co_code


if __name__ == '__main__':
    test_extend()

# Generated at 2022-06-21 18:42:57.548501
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import typing
    import typed_astunparse
    import astor

    def create_ExceptHandler(name: str) -> ast.ExceptHandler:
        return ast.ExceptHandler(ast.Constant(1), name, [])

    name = "name"
    replacement = "name_0"

    visitor = VariablesReplacer({name: replacement})

    # Test visit_ExceptHandler
    node = create_ExceptHandler(name)
    result = visitor.visit_ExceptHandler(node)

    assert isinstance(result, ast.ExceptHandler)
    assert result.name == replacement
    
    # Test no replacement
    node = create_ExceptHandler("other_name")
    result = visitor.visit_ExceptHandler(node)
    
    assert isinstance(result, ast.ExceptHandler)
    assert result.name == "other_name"



# Generated at 2022-06-21 18:43:11.905640
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    code = 'def f(a=a):pass'
    tree = ast.parse(code)
    variables = {'a': ast.parse('1')}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'FunctionDef(name=\'f\', args=arguments(args=[arg(arg=\'a\', annotation=None, value=Num(n=1))], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)'

# Generated at 2022-06-21 18:43:17.768797
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import sys
    import ast
    import astor

    tree_str = """from sys import *"""
    tree = ast.parse(tree_str)
    result_str = """from sys import *"""

    VariablesReplacer.replace(tree, {})

    assert astor.to_source(tree) == result_str



# Generated at 2022-06-21 18:43:23.306827
# Unit test for function extend
def test_extend():
    import astor

    @snippet
    def foo(vars_list: ast.AST):
        extend(vars_list)

    tree = ast.parse('pass')
    vars_list = ast.parse('x = 1\nx = 2')
    foo(tree, vars_list)
    assert astor.to_source(tree) == 'x = 1\nx = 2'



# Generated at 2022-06-21 18:43:24.152129
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-21 18:43:31.913588
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def foo(x):
        return x

    ast_tree = ast.parse(get_source(foo))
    variables = {"x": "y"}
    VariablesReplacer.replace(ast_tree, variables)
    assert ast.dump(ast_tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='y', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Name(id='y', ctx=Load()))], decorator_list=[], returns=None)])"


# Generated at 2022-06-21 18:43:40.567755
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse('''
try:
    pass
except Exception as e:
    pass
''')

    variables = {'e': '_py_backwards_e_5'}

    VariablesReplacer().replace(tree, variables)

    assert ast.dump(tree) == '''Module(body=[Try(body=[Pass()], handlers=[ExceptHandler(type=Name(id='Exception', ctx=Load()), name=_py_backwards_e_5, body=[Pass()])], orelse=[], finalbody=[])])'''

# Generated at 2022-06-21 18:43:41.575605
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet is not None



# Generated at 2022-06-21 18:43:52.870141
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .test_tree import get_tree

    source = """
    from .a import b
    from . import c
    from .d import *
    from .e import f as g
    """
    tree = get_tree(source)
    variables = {'b': 'b', 'c': 'c', 'f': 'f', 'g': 'g'}
    VariablesReplacer.replace(tree, variables)

    assert isinstance(tree.body[0], ast.ImportFrom)
    assert tree.body[0].module == 'a'
    assert isinstance(tree.body[0].names[0], ast.alias)
    assert tree.body[0].names[0].name == 'b'
    assert isinstance(tree.body[1], ast.ImportFrom)
    assert tree.body[1].module == '.'

# Generated at 2022-06-21 18:43:58.387994
# Unit test for function extend_tree
def test_extend_tree():
    input_tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)

    output_tree = ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """)

    vars = {'vars': [output_tree.body[0], output_tree.body[1]]}
    extend_tree(input_tree, vars)
    VariablesReplacer.replace(output_tree, {})
    assert input_tree == output_tree



# Generated at 2022-06-21 18:44:10.029536
# Unit test for function extend
def test_extend():
    from .helpers import build_ast

    # Raw snippet:
    # extend(vars)
    # x += 1
    #
    # vars:
    # y = 1
    # z = y
    raw_snippet = build_ast([
        ast.Call(
            func=ast.Name(id='extend', ctx=ast.Load()),
            args=[ast.Name(id='vars', ctx=ast.Load())],
            keywords=[]
        ),
        ast.AugAssign(
            target=ast.Name(id='x', ctx=ast.Store()),
            op=ast.Add(),
            value=ast.Num(n=1)
        )
    ])

# Generated at 2022-06-21 18:44:20.938629
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2

    decorated_func = snippet(lambda: print(x, y))
    tree = decorated_func.get_body()
    assert ast.dump(tree[0]) == ast.dump(ast.Expr(value=ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Name(id='x', ctx=ast.Load()),
              ast.Name(id='y', ctx=ast.Load())],
        keywords=[])))

# Generated at 2022-06-21 18:44:27.206054
# Unit test for function let
def test_let():
    source = '''
    def f(x):
        let(y)
        let(z)
        z = 2
        y = 1
        return x + y + z
    '''
    tree = ast.parse(source)
    expected = ast.parse('''
    def f(x):
        _py_backwards_y_0 = 1
        _py_backwards_z_1 = 2
        return x + _py_backwards_y_0 + _py_backwards_z_1
    ''')
    assert VariablesReplacer.replace(tree, find_variables(tree)) == expected



# Generated at 2022-06-21 18:44:29.115862
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    input = {'id': 'arg'}
    result = VariablesReplacer.replace(input, {'arg': 'test'})
    # {'id': 'test'}
    assert result == {'id': 'test'}

# Generated at 2022-06-21 18:44:35.687090
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""try:
    1/0
except ZeroDivisionError as e:
    print(e)
""")
    tree2 = ast.parse("""try:
    1/0
except ZeroDivisionError as _py_backwards_e_0:
    print(_py_backwards_e_0)
""")
    variables = {'e': VariablesGenerator.generate()}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == ast.dump(tree2)


# Generated at 2022-06-21 18:44:46.497164
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(snippet_fn)
    assert snippet_instance.get_body(x=12) == [
        ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   ast.BinOp(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                             ast.Add(),
                             ast.Num(n=1))),
        ast.Assign([ast.Name(id='y', ctx=ast.Store())], ast.Num(n=1))]



# Generated at 2022-06-21 18:44:53.584740
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    t = ast.parse('''
from .test import x
from .test2 import x as x2
''').body  # type: ignore
    replace_dict = {
        "test.x": 'x',
        "test2.x": 'x2'
    }
    new_t = VariablesReplacer.replace(t, replace_dict)
    assert new_t[0].names[0].name == 'x'
    assert new_t[1].names[0].name == 'x2'



# Generated at 2022-06-21 18:45:02.626423
# Unit test for function extend_tree
def test_extend_tree():
    import textwrap

    raw_ast = textwrap.dedent('''
    def foo(x: int) -> None:
        let(x)
        extend(tree)
    ''')

    tree = ast.parse(raw_ast)
    variables = {'tree':
                 ast.Assign(
                     targets=[ast.Name(id='x')],
                     value=ast.Num(n=1)
                 )}
    extend_tree(tree, variables)

    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert len(tree.body[0].body) == 1
    assert isinstance(tree.body[0].body[0], ast.Assign)
    assert len(tree.body[0].body[0].targets) == 1


# Generated at 2022-06-21 18:45:12.735025
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    '''
    # test_VariablesReplacer_visit_keyword
    # Visit keyword test
    '''
    # input
    root = ast.parse("def f(a = b): pass").body[0]
    variables = {"b": [ast.Assign(targets=[ast.Name(id='a')],
        value=ast.Num(n=1))]}
    # object
    replacer = VariablesReplacer(variables)
    # output
    out = get_source(replacer.visit_keyword(root.args.defaults[0]))
    # assert
    assert out == "a = 1"



# Generated at 2022-06-21 18:45:19.685230
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    tree = ast.parse("class Foo(object): pass")
    variables = {"Foo": "Bar"}
    class_def = VariablesReplacer.replace(tree, variables)
    assert isinstance(class_def, ast.ClassDef)
    assert class_def.name == "Bar"
    assert isinstance(class_def.bases[0], ast.Name)
    assert class_def.bases[0].id == "object"
    

# Generated at 2022-06-21 18:45:25.611457
# Unit test for function extend_tree
def test_extend_tree():
    import astunparse
    tree = ast.parse("extend(vars)\na = b").body
    extend_tree(tree, {'vars': [ast.parse("x=1").body[0], ast.parse("x=2").body[0]]})
    assert astunparse.unparse(tree) == 'x = 1\nx = 2\na = b\n', 'Extend tree is not working properly'

# Generated at 2022-06-21 18:45:40.594944
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class A:
        pass
    g = globals()
    a = A()
    tree = ast.parse("a.b")
    replace = {"a.b": "c.d"}
    replacer = VariablesReplacer(replace)
    replacer.visit(tree)
    exec(compile(tree, "<ast>", "exec"))
    assert c.d == A.b


# Generated at 2022-06-21 18:45:48.328223
# Unit test for function extend_tree
def test_extend_tree():
    source = """extend(vars)
vars = list(range(5))
x = 1"""
    tree = ast.parse(source)
    extend_tree(tree, {'vars': ast.parse('x = 1').body})

# Generated at 2022-06-21 18:45:55.685750
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('x = 1')
    variables = {'x': '_py_backwards_x'}
    result = VariablesReplacer.replace(tree, variables)
    assert isinstance(result.body[0], ast.Assign)
    assert isinstance(result.body[0].value, ast.Num)
    assert result.body[0].value.n == 1
    assert result.body[0].targets[0].id == '_py_backwards_x'


# Generated at 2022-06-21 18:45:58.461621
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    from .tree import get_source
    import astor
    #import ast

# Generated at 2022-06-21 18:46:03.218323
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class D(ast.NodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            return node

    node = ast.Name('a', ast.Load())
    assert VariablesReplacer.replace(node, {'a': 'b'}) == ast.Name('b', ast.Load())



# Generated at 2022-06-21 18:46:06.606639
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import ast, astor

# Generated at 2022-06-21 18:46:12.149372
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    x = ast.Name(id='x', ctx=ast.Load())
    y = ast.Name(id='y', ctx=ast.Load())
    
    node = ast.Attribute(value=x, attr='y', ctx=ast.Load())
    n = VariablesReplacer({"x": y}).visit(node)
    for i in n.get_fields():
        print(i, n.__dict__[i])


# Generated at 2022-06-21 18:46:17.917220
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    globals = {}
    locals = {}
    exec("def f(): pass", globals, locals)
    class Node(ast.Attribute):
        def __init__(self, id, value):
            self.lineno = 0
            self.col_offset = 0
            self.__dict__['id'] = id
            self.__dict__['value'] = value

    statement = Node("statement", Node("__class__", Node("f", None)))
    replacer = VariablesReplacer({ "f": Node("test", None) })
    result = replacer.visit(statement)
    assert result.value.value.id == "test"

# Generated at 2022-06-21 18:46:23.858871
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_ = ast.ImportFrom(lineno=1, col_offset=2,
                             module='test_module',
                             names=[ast.alias(name='test_module',
                                              asname='alias_test_module')])
    res = VariablesReplacer.replace(import_, {'test_module': 'new_module'})
    assert res.module == 'new_module'



# Generated at 2022-06-21 18:46:31.043363
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-21 18:46:46.121147
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.parse("""
        from a.b import c, d
        from .a import b, c, d
        from .e import x
        from . import b
    """).body[0]

    assert(VariablesReplacer.replace(import_from, {"c": "c", "d": "d", "e": "e"}) == ast.parse("""
        from a.b import c, d
        from .a import b, c, d
        from .e import x
        from . import b
    """).body[0])


# Generated at 2022-06-21 18:46:50.249072
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f(x):
        let(y)
        y += 1
        print(x, y)

    print(f.get_body(x=1, y=2))

# Generated at 2022-06-21 18:46:53.547021
# Unit test for function let
def test_let():
    @snippet
    def f(x: int) -> None:
        let(y)
        print(y)
        assert y == x * 2

    f(2)



# Generated at 2022-06-21 18:46:54.867682
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:46:59.384279
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    source = '''
        def foo(x):
            def bar(y):
                pass
            return bar
    '''
    fn = ast.parse(source).body[0]
    replacer = VariablesReplacer({'foo': 'bar'})
    replacer.visit(fn)
    assert fn.name == 'bar'

# Generated at 2022-06-21 18:47:11.058153
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import unittest
    data = [
        (
            """
            x = 1
            y = 4
            z = 5
            """,
            """
            x = 1
            y = 3
            z = 5
            """
        ),
        (
            """
            x = 1
            y = 4
            z = 5
            """,
            """
            x = 1
            y = 3
            z = 4
            """
        ),
        (
            """
            x = lambda x, y1=4: x + y1
            """,
            """
            x = lambda x, y1=3: x + y1
            """
        ),
    ]

    for code, expected in data:
        tree = ast.parse(dedent(code))

# Generated at 2022-06-21 18:47:17.613488
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class visitor(VariablesReplacer):
        pass

    assert_body(
        [ast.FunctionDef(args=ast.arguments(args=[]),
                          body=[ast.Return(value=ast.Num(n=9))],
                          decorator_list=[])],
        [visitor.replace(ast.parse('def foo(): return 1').body[0], {'1': ast.Num(n=9)})])


# Generated at 2022-06-21 18:47:22.355992
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    assert VariablesReplacer.replace(
        ast.parse('''from module import foo, bar as baz''').body[0],
        {'baz': 'zab'}
    ) == ast.parse('''from module import foo, bar as zab''').body[0]



# Generated at 2022-06-21 18:47:34.005338
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_code():
        x = 1
        y = let(x)
        z = 1
        x += 1
        z += 1
        return x, z


# Generated at 2022-06-21 18:47:36.130296
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: let(x)).get_body() == snippet(lambda: _py_backwards_x_0).get_body()

# Generated at 2022-06-21 18:47:56.072532
# Unit test for function extend
def test_extend():
    vars = [ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Constant(value=1)
    ), ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Constant(value=2)
    )]

    @snippet
    def extend_example(x: int, y: int):
        extend(vars)
        print(x, y)

    tree = extend_example.get_body(x=ast.Name(id='_x', ctx=ast.Store()),
                                   y=ast.Name(id='_y', ctx=ast.Store()))


# Generated at 2022-06-21 18:48:05.466710
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class AppendVisitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self.a = []
        def visit_FunctionDef(self, node: ast.FunctionDef):
            self.a.append(node)
            return ast.NodeVisitor.visit(self, node)
    visitor = AppendVisitor()
    tree = ast.parse("def foo(): print('foo')")
    visited = VariablesReplacer.replace(tree, {'foo': 'bar'})
    visitor.visit(visited)
    assert visitor.a[0].name == 'bar'


# Generated at 2022-06-21 18:48:10.912191
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from types import ModuleType

    class TestMod(ModuleType):
        def __init__(self, name: str, module_dict: Dict[str, Any]):
            self.__name__ = name
            self.__dict__ = module_dict

    original_import = ast.ImportFrom(module='core', names=[ast.alias(name='coreC', asname='coreC')])
    tree = [original_import]
    replacer = VariablesReplacer({'core': 'coreA', 'coreC': 'coreC'})
    replacer.visit(tree)
    assert tree[0].module == 'coreA'
    module = TestMod('core', {'coreC': 1})
    module_name = replacer._replace_module('core.coreC')
    assert module_name == 'coreA.coreC'

# Generated at 2022-06-21 18:48:14.400313
# Unit test for function let
def test_let():
    def sum(a, b):
        let(a)
        let(b)
        c = a + b
        return c
    assert sum(3, 4) == 7
    assert sum(2, 3) == 5
    assert sum(1, 2) == 3
    assert sum(0, 1) == 1

# Generated at 2022-06-21 18:48:15.292598
# Unit test for method visit_Name of class VariablesReplacer

# Generated at 2022-06-21 18:48:24.621706
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    def foo():
        __import__('foo')
        import foo
        import foo as bar
        from foo import bar
        from foo import bar as baz

    source = get_source(foo)
    tree = ast.parse(source)
    replacer = VariablesReplacer({'foo': 'baz'})
    replacer.visit(tree)
    assert compile(tree, '', 'exec').__globals__.get('foo') is None
    assert compile(tree, '', 'exec').__globals__.get('baz')



# Generated at 2022-06-21 18:48:30.551571
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import1 = ast.ImportFrom(module='sys', names=[ast.alias(name='path', asname='p')], level=0)
    tree = ast.parse(get_source(test_VariablesReplacer_visit_ImportFrom))
    variables = {'sys': 'my_sys'}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0] == import1

# Generated at 2022-06-21 18:48:37.783304
# Unit test for function find_variables
def test_find_variables():
    program = """
    a = 1
    let(b)
    b = 2
    execute()
    """

    tree = ast.parse(program)
    assert find_variables(tree) == ['b']

    program = """
    a = 1
    let(b)
    b = 2
    let(c)
    c = 3
    execute()
    """

    tree = ast.parse(program)
    assert find_variables(tree) == ['b', 'c']


# Generated at 2022-06-21 18:48:41.365775
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    node = ast.FunctionDef(**{'name': 'f'})
    variables = {'f': 1}
    replacement = VariablesReplacer.replace(node, variables)
    assert types_match(replacement, ast.Num)
    assert replacement.n == 1


# Generated at 2022-06-21 18:48:52.127416
# Unit test for function let
def test_let():
    def foo():
        x = 1
        let(x)
        x += 1
        y = 1
        return x, y

    tree = ast.parse(get_source(foo))
    variables = {name: VariablesGenerator.generate(name) for name in find_variables(tree)}
    extend_tree(tree, variables)
    tree = VariablesReplacer.replace(tree, variables)
    code = compile(tree, '<test>', 'exec')
    x_name, y_name = variables['x'], variables['y']
    assert x_name != y_name
    glob = {}
    exec(code, glob)
    value = glob['foo']()
    assert value == (2, 1)
    assert isinstance(value[0], int)


# Generated at 2022-06-21 18:49:29.463522
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class_name = None
    global_var_name = None
    global_var_name2 = None
    tree = []
    tree2 = []
    class_name = 'test_VariablesReplacer_visit_Attribute'
    global_var_name = 'test_VariablesReplacer_visit_Attribute_variable'
    global_var_name2 = 'test_VariablesReplacer_visit_Attribute_variable2'
    x = ast.Name()
    x.id = class_name
    x.ctx = ast.Store()
    y = ast.Str()
    y.s = 'global'
    z = ast.Name()
    z.id = global_var_name
    z.ctx = ast.Store()
    v = ast.Attribute()
    v.attr = global_var_name

# Generated at 2022-06-21 18:49:32.800169
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    assert ast.dump(VariablesReplacer(
        variables={}).visit_keyword(ast.parse("def f(a=1):pass\n").body[0].args.defaults[0])) == "1"

# Generated at 2022-06-21 18:49:34.238837
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    try:
        1+'a'
    except:
        pass

# Generated at 2022-06-21 18:49:43.002877
# Unit test for function extend
def test_extend():
    def test_snippet(vars):
        extend(vars)
        
    source = get_source(test_snippet)
    tree = ast.parse(source)
    variables = find_variables(tree)
    extend_tree(tree, variables)
    assert tree.body[0].body[0] == ast.Name(id="x", ctx=ast.Store())
    assert tree.body[0].body[1] == ast.Name(id="x", ctx=ast.Store())
    assert tree.body[0].body[2] == ast.Print(
        dest=None,
        values=[ast.Name(id="x", ctx=ast.Load()), ast.Name(id="y", ctx=ast.Load())],
        nl=True
    )

# Generated at 2022-06-21 18:49:55.166789
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class_ = ast.ClassDef(
        name='Class', body=[ast.FunctionDef(name='func', args=ast.arguments(args=[ast.arg(arg='arg', annotation=None)]))])
    VariablesReplacer.replace(class_,
                              {'arg': 'new_name_arg'})
    func = class_.body[0]
    assert isinstance(func, ast.FunctionDef)
    assert hasattr(func, 'args')
    assert isinstance(func.args, ast.arguments)
    assert hasattr(func.args, 'args')
    assert isinstance(func.args.args, list)
    assert isinstance(func.args.args[0], ast.arg)
    assert hasattr(func.args.args[0], 'arg')
    assert func.args.args[0].arg

# Generated at 2022-06-21 18:49:59.212075
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse('from my_module import y')
    tree = VariablesReplacer.replace(tree, {'my_module': 'y'})

    import_from = tree.body[0]
    assert import_from.module == 'y'



# Generated at 2022-06-21 18:50:07.118966
# Unit test for function let
def test_let():
    source = '''
    let(x)
    y = x
    print(x, y)
    '''

    tree = ast.parse(source)
    variables = {name: VariablesGenerator.generate(name)
                 for name in find_variables(tree)}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].body[0].value.id == variables['y']
    assert tree.body[0].body[1].args[0].id == variables['y']
    assert tree.body[0].body[1].args[1].id == variables['y']



# Generated at 2022-06-21 18:50:18.672184
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''def f():
                           let(vars)
                           extend(vars)
                           print(x)
                           print(y)
                           print(z)''')

    vars = [
        ast.Assign(
            [ast.Name('x', ast.Store())],
            ast.Num(1)
        ),
        ast.Assign(
            [ast.Name('y', ast.Store())],
            ast.Num(2)
        ),
        ast.Assign(
            [ast.Name('z', ast.Store())],
            ast.Num(1)
        )
    ]

    extend_tree(tree, {'vars': vars})

    assert tree.body[0].body[1].targets[0].id == 'x'

# Generated at 2022-06-21 18:50:19.936240
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-21 18:50:24.565896
# Unit test for function find_variables
def test_find_variables():
    input = '''
    def test_find():
        let(x)
        let(y)
        x += 1
        y = 1
    '''
    tree = ast.parse(input)
    assert list(find_variables(tree)) == ['x', 'y']

