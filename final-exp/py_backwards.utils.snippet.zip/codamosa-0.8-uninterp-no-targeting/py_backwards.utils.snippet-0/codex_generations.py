

# Generated at 2022-06-21 18:41:46.362213
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import astor
    code = 'from mymodule import variable as var; var'
    variables = {
        'mymodule': 'yourmodule'
    }
    tree = ast.parse(code)
    VariablesReplacer.replace(tree, variables)
    assert astor.to_source(tree) == 'from yourmodule import variable as var; var'

# Generated at 2022-06-21 18:41:53.536274
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from random import randint
    t = ast.parse('import os, sys as sys_')
    v = {'sys': randint(0, 100)}
    r = VariablesReplacer(v)
    r.visit_alias(t.body[0].names[1])
    assert t.body[0].names[1].name == 'sys'
    assert t.body[0].names[1].asname == v['sys']

# Generated at 2022-06-21 18:41:57.226756
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class_node = ast.ClassDef(name="Test", body=[ast.Pass()])
    key_word_node = ast.keyword(arg='name', value=ast.Name(id='Test'))
    args_node = ast.arguments(args=[key_word_node], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    function_node = ast.FunctionDef(name="test_function", body=[class_node], decorator_list=[], args=args_node)
    node_example = ast.Module(body=[function_node, class_node], type_ignores=[])

    expected_name = "Changed_name"
    VariablesReplacer.replace(node_example, {'Test': expected_name})

# Generated at 2022-06-21 18:42:04.606755
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("def foo():\n print(var.attr)")
    body = tree.body[0].body[0].value
    assert isinstance(body, ast.Call) and body.func.name == "print" and body.args[0].attr == "attr"
    attr = body.args[0]
    assert isinstance(attr, ast.Attribute) and attr.value.id == "var"
    replacer = VariablesReplacer({"var": "var_new"})
    replacer.visit_Attribute(attr)
    assert attr.value.id == "var_new"


# Generated at 2022-06-21 18:42:07.051581
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = "import x.y as z"
    tree = ast.parse(source)
    assert VariablesReplacer.replace(tree, {}).body[0].asname == 'z'



# Generated at 2022-06-21 18:42:17.450134
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    v = ast.parse("def f(b): pass", mode='exec')
    variables = {
        "b": ast.parse("def a(): pass", mode='eval')
    }
    result = ast.dump(VariablesReplacer.replace(v, variables))
    assert result == dedent(
        """\
        Module(body=[FunctionDef(name='f', args=arguments(args=[arg(arg='b', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None, type_comment=None)])
        """
    )



# Generated at 2022-06-21 18:42:22.232004
# Unit test for function extend
def test_extend():
    extend_source = "x = 1\ny = 2"
    extended = ast.parse(extend_source)
    extended.body[0].value.n = 3 # x = 3

    @snippet
    def fn():
        extend(extended)
        print(x, y)

    assert fn.get_body() == extended.body + ast.parse("print(x, y)").body


# Generated at 2022-06-21 18:42:28.206931
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('x = 1\nimport test\n')
    variables = {'x': 'y',
                 'test': 'test2'}
    ast.fix_missing_locations(VariablesReplacer.replace(tree, variables))
    assert ast.dump(tree) == 'x = 1\nimport test2\n'



# Generated at 2022-06-21 18:42:31.901311
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""
        try:
            pass
        except Exception:
            pass
    """)
    variables = {
        'Exception': [ast.Name("Exception", ast.Load())]
    }
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == """"""

# Generated at 2022-06-21 18:42:32.880619
# Unit test for function extend

# Generated at 2022-06-21 18:42:44.602733
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    def func(x):
        x += 1
        raise Exception()

    variables = {'x': '_py_backwards_x_0'}
    tree = ast.parse(get_source(func))
    VariablesReplacer.replace(tree, variables)
    func = None  # type: ignore



# Generated at 2022-06-21 18:42:49.348967
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import astor
    tree = ast.parse("a.b=3")
    variables = {}
    variablesReplacer = VariablesReplacer(variables)
    variablesReplacer.visit(tree)
    assert astor.to_source(tree).strip() == "a.b=3"
# Test passes, as expected

# Generated at 2022-06-21 18:42:59.427091
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class Test(VariablesReplacer):
        def __init__(self, variables: Dict[str, Variable]) -> None:
            self._variables = variables

        def visit_arg(self, node: ast.arg) -> ast.arg:
            node = self._replace_field_or_node(node, 'arg')
            self.generic_visit(node)
            return node

    tree = ast.parse('def test1(test1):\n    print(test1)')
    variables = {'test1': 'test2'}
    tree = Test.replace(tree, variables)
    assert isinstance(tree.body[0].args.args[0], ast.arg)
    assert tree.body[0].args.args[0].arg == 'test2'

# Generated at 2022-06-21 18:43:03.245153
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    node = ast.Name(id="x")
    replacer = VariablesReplacer({})
    replacer.visit_Name(node)
    assert node.id == "x"

    replacer = VariablesReplacer({"x":"y"})
    replacer.visit_Name(node)
    assert node.id == "y"



# Generated at 2022-06-21 18:43:05.086291
# Unit test for function extend
def test_extend():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 18:43:11.609157
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(a: int, b: int) -> None:
        assert let(a + b) == 3

    s = snippet(snippet_fn)
    assert s.get_body(a=1, b=2) == [ast.Assert(test=(ast.Eq(left=ast.Name(id='_py_backwards_a_0'), right=ast.Num(n=3))), msg=None)]

# Generated at 2022-06-21 18:43:17.118359
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    visit_arg: Callable[..., Any] = VariablesReplacer({}).visit_arg
    node = ast.arg(arg="arg")
    assert visit_arg(node) == node
    node1 = ast.arg(arg="arg2")
    node2 = ast.arg(arg="arg")
    assert visit_arg(node) == node

# Generated at 2022-06-21 18:43:21.803217
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    tree = ast.parse('''
    class X():
        pass
    ''')
    variables = {'X': 'Y'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert get_source(tree) == '''
    class Y():
        pass
    '''



# Generated at 2022-06-21 18:43:23.193323
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:43:32.620793
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import_statement = """from my_lib.my_module import my_function as func"""
    tree = ast.parse(import_statement)
    variables = {
        'my_function': 'func',
        'my_lib.my_module': 'module',
    }
    result = """from module import func as func"""

    node = tree.body[0]
    assert isinstance(node, ast.ImportFrom)
    assert node.module == 'my_lib.my_module'
    assert node.names[0].name == 'my_function'
    assert node.names[0].asname == 'func'

    VariablesReplacer.replace(node, variables)

    assert node.module == 'module'
    assert node.names[0].name == 'func'
    assert node.names[0].asname == 'func'

# Generated at 2022-06-21 18:43:46.079665
# Unit test for function extend
def test_extend():
    def x():
        extend(vars)
        print(a, b)

    t = let(vars)

    # Throws error because extend is inside let
    with pytest.raises(Exception):
        ast.parse(get_source(x))

    # No error
    t = let(vars)
    ast.parse(get_source(x))

# Generated at 2022-06-21 18:43:50.441234
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import_node = ast.parse('import a.b as c').body[0]
    variables = {'a': 'd'}
    visited_import_node = VariablesReplacer.replace(import_node, variables)
    assert isinstance(visited_import_node, ast.Import)

# Generated at 2022-06-21 18:43:56.354880
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class TestVariablesReplacer(VariablesReplacer):
        def __init__(self):
            super().__init__({})
        def generic_visit(self, node):
            return node

    ast_with_variable = ast.parse('x')
    ast_with_variable.body[0].value = ast.Name(id='a', ctx=ast.Load())

    assert TestVariablesReplacer().generic_visit(ast_with_variable).body[0].value.id == 'a'

# Generated at 2022-06-21 18:44:02.972553
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # given
    variables = {'x': 'y'}
    tree = ast.parse('import x as b')

    # when
    class Dummy(VariablesReplacer):
        def visit_Name(self, node):
            return node
    
    Dummy.replace(tree, variables)

    # then
    assert tree == ast.parse('import y as b')

# Generated at 2022-06-21 18:44:06.014428
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def f():
        let(x)
        x += 1
        y = 1
    assert f
    
    

# Generated at 2022-06-21 18:44:10.381187
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    """This unit test is for visit_Name method of VariablesReplacer class"""
    class_instance = VariablesReplacer({'xyz': 'abc'})
    class_instance._replace_field_or_node(ast.parse('xyz'), 'id', True)
    assert ast.dump(ast.parse('xyz')) == ast.dump(ast.parse('abc'))

# Generated at 2022-06-21 18:44:17.633608
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A:
        pass

    gen = ast.parse(get_source(A))
    assert isinstance(gen.body[0], ast.ClassDef)
    cls = gen.body[0]
    cls.name = 'B'
    replace = {'A': cls}
    tree = ast.parse(get_source(test_VariablesReplacer_visit_ClassDef))
    VariablesReplacer.replace(tree, replace)

    assert isinstance(tree.body[0], ast.ClassDef)
    assert tree.body[0].name == 'B'



# Generated at 2022-06-21 18:44:23.674276
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('call(x=y)')
    variables = {'y': 'z'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'Expr(value=Call(func=Name(id=\'call\', ctx=Load()), args=[], keywords=' \
                           '[keyword(arg=\'x\', value=Name(id=\'z\', ctx=Load()))], starargs=None, kwargs=None))'



# Generated at 2022-06-21 18:44:26.199355
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    source = """
    class C:
        pass
    """
    
    tree = ast.parse(source)
    variables = {}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    

# Generated at 2022-06-21 18:44:35.781753
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import inspect
    import astunparse
    import sys
    import pexpect
    #python 2
    if sys.version_info[0] == 2:
        import exceptions
        #python 3
    else:
        import builtins
        exceptions = builtins

    try:
        raise exceptions.ArithmeticError("oops")
    except exceptions.ArithmeticError as exc:
        print("caught it! exc: {0}".format(exc))

    #rewrite code in a node by visit_ExceptHandler
    def rewrite_code():
        import astunparse
        import inspect
        import sys
        import pexpect

        # python 2
        if sys.version_info[0] == 2:
            import exceptions
            # python 3
        else:
            import builtins
            exceptions = builtins


# Generated at 2022-06-21 18:44:53.743513
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    import astunparse
    import sys
    TreenodeGenerator = VariablesReplacer({"x": "1", "y": "2", "z": "3"})
    STRING = "a = x + y + z + (x + y + z)"
    result = astunparse.unparse(TreenodeGenerator.visit(ast.parse(STRING)))
    print("test_VariablesReplacer:")
    print("    input:")
    print("    " + STRING)
    print("    output:")
    print("    " + result)
    sys.stdout.flush()
    assert(result == "a = 1 + 2 + 3 + (1 + 2 + 3)")

# Generated at 2022-06-21 18:45:00.379972
# Unit test for function extend_tree
def test_extend_tree():
    import astor

    tree = ast.parse("""
extend(a)
print(x)
""")
    tree.body[0] = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Constant(value=1))  # type: ignore

    extend_tree(tree, {'a': tree.body[0]})  # type: ignore

    assert astor.to_source(tree) == "x = 1\nprint(x)\n"

# Generated at 2022-06-21 18:45:07.188103
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    test_node = ast.Name(id='name')
    test_arg = 'name'
    test_variable = 'name_replacement'
    replacer = VariablesReplacer({test_arg: test_variable})
    result, expected = replacer.visit_Name(test_node), ast.Name(id=test_variable)
    assert result.id == expected.id


# Generated at 2022-06-21 18:45:08.602868
# Unit test for function extend
def test_extend():
    extend_helper()
    extend_helper1()


# Generated at 2022-06-21 18:45:10.939351
# Unit test for function let
def test_let():
    @snippet
    def tree():
        let(x)
        let(y)
        x, y = 1, 2

    assert isinstance(tree.get_body(), list)

# Generated at 2022-06-21 18:45:15.292825
# Unit test for constructor of class snippet
def test_snippet():
    assert issubclass(snippet, ast.NodeTransformer)

# Generated at 2022-06-21 18:45:26.605220
# Unit test for constructor of class snippet
def test_snippet():
    from .tree import Name
    def fn():
        let(x)
        x += 1
        y = 1

    snippet = snippet(fn)
    body = snippet.get_body(y=Name('ahoj'))


# Generated at 2022-06-21 18:45:32.793444
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""
    class Foo:
        def foo(self):
            try:
                pass
            except ValueError as error:
                pass
    """)
    name = ast.Name(id='bar', ctx=ast.Load())
    variables = {'error': name}
    tree = VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-21 18:45:37.610212
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    extend_tree(tree, {'vars': [ast.parse('x = 1'), ast.parse('x = 2')]})
    assert get_source(tree) == 'x = 1\nx = 2'

# Generated at 2022-06-21 18:45:46.396039
# Unit test for function let
def test_let():
    @snippet
    def snippet():
        let(x)
        x += 1
        y = 1
        print(x)
        print(y)
        
    body = snippet.get_body()

# Generated at 2022-06-21 18:45:54.120796
# Unit test for function find_variables
def test_find_variables():
    source = """
let(x)
let(y)
x
y
let(z)
z
"""
    variables = set(find_variables(ast.parse(source)))
    assert variables == {'x', 'y', 'z'}



# Generated at 2022-06-21 18:46:04.382705
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import os
    import sys
    import subprocess
    import py_backwards.system

    # Test that we can import a module of a module

# Generated at 2022-06-21 18:46:05.482109
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class Example:
        a = 1
        b = 2

    assert VariablesReplacer.replace(Example, {}) == Example

# Generated at 2022-06-21 18:46:08.264922
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    actual = VariablesReplacer({'x': 'y'}).replace(
        ast.parse("import x").body[0],
        {'y': 'x'}
    )
    expected = ast.parse("import x").body[0]

    assert actual == expected


# Generated at 2022-06-21 18:46:14.542214
# Unit test for function extend_tree
def test_extend_tree():
    code = """
    @snippet
    def test(a, b):
        extend(a)
        b = 2
    """
    
    print(code)
    exec(code)
    
    tree = test.get_body(a=[ast.Assign([ast.Name('x', ast.Store())], ast.Num(4)), ast.Assign([ast.Name('y', ast.Store())], ast.Num(5))], b=ast.Num(6))
    print(ast.dump(tree))
    print(tree)

test_extend_tree()

# Generated at 2022-06-21 18:46:18.200503
# Unit test for constructor of class snippet
def test_snippet():
    # pylint: disable=unused-variable
    @snippet
    def fn():
        extend(vars)
        let(x)
        print(x)



# Generated at 2022-06-21 18:46:27.059814
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import astor
    snippet_str = """
from a_module_name as x
from other_name import y
"""
    variables = {
        'a_module_name': 'NOT_a_module_name',
        'other_name': 'NOT_other_name'
    }
    tree = ast.parse(snippet_str)
    VariablesReplacer.replace(tree, variables)
    assert 'from NOT_a_module_name as x' in astor.to_source(tree)
    assert 'from NOT_other_name import y' in astor.to_source(tree)

# Generated at 2022-06-21 18:46:34.555849
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    def foo():
        let(x)
        let(y)
        z = 1

        print(x + y - z)

    source = get_source(foo)
    tree = ast.parse(source)
    find_variables(tree)
    c = VariablesReplacer()
    c.visit(tree)
    assert ast.dump(tree).strip() == '<ast.Module object at 0x107b845f8>'


# Generated at 2022-06-21 18:46:35.638353
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-21 18:46:43.454901
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
    extend(tree_vars)
    print(x, y)
    '''  # noqa
    tree = ast.parse(source)

    extend_tree(tree, {'tree_vars': [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=1)),
                                     ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=2))]})

    assert get_source(tree) == '\nx = 1\nx = 2\nprint(x, y)\n'

# Generated at 2022-06-21 18:47:05.221138
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(a, b):
        let(c)
        var = c
        return var
    
    snippet_variables = {
        'c': ast.Name(id='a', ctx=ast.Load()),
        'b': ast.Name(id='b', ctx=ast.Load())
    }
    body = fn.get_body(**snippet_variables)
    for node in body:
        assert isinstance(node, ast.Assign)
        if node.targets[0].id == 'b':
            assert node.value.id == 'b'  # type: ignore
        if node.targets[0].id == ast.Name(id='_py_backwards_c_0', ctx=ast.Store()).id:
            assert node.value

# Generated at 2022-06-21 18:47:10.330446
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    expected = ast.parse("assert x and y").body[0]
    other = ast.Name('x', ast.Load())
    module = ast.Name('y', ast.Load())
    assert isinstance(VariablesReplacer.replace(expected, {'x' : module, 'y': other}), ast.Assert)



# Generated at 2022-06-21 18:47:12.755352
# Unit test for function find_variables
def test_find_variables():
    snippet = ast.parse("""\
    let(a)
    let(b)
    """)
    assert set(find_variables(snippet)) == {'a', 'b'}



# Generated at 2022-06-21 18:47:19.598342
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars)\nprint(x, y)")
    vars = [ast.parse("x = 1"),
            ast.parse("x = 2")]
    extend_tree(tree, {'vars' : vars})
    print(astor.to_source(tree))
    assert astor.to_source(tree) == "x = 1\nx = 2\nprint(x, y)\n"

# Generated at 2022-06-21 18:47:26.983059
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("print(var0)")
    expected = ast.parse("print(var0)")
    replacer = VariablesReplacer({})
    replacer.visit(tree)
    assert ast.dump(expected) == ast.dump(tree)

    tree = ast.parse("print(var)")
    expected = ast.parse("print(var_0)")
    replacer = VariablesReplacer({'var': 'var_0'})
    replacer.visit(tree)
    assert ast.dump(expected) == ast.dump(tree)

    tree = ast.parse("print(var)")
    expected = ast.parse("print(var_0)")
    replacer = VariablesReplacer({'var': 'var_0'})
    replacer.visit(tree)

# Generated at 2022-06-21 18:47:29.608007
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(
        ast.parse('let(x)\nx + 1'))) == ['x']



# Generated at 2022-06-21 18:47:30.252107
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    pass

# Generated at 2022-06-21 18:47:33.589546
# Unit test for function let
def test_let():
    assert get_source(snippet(
        lambda: let(x + y)
    ).get_body(x=1)) == '_py_vars_0 = 1 + y\n'



# Generated at 2022-06-21 18:47:35.447179
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse(''))) == []

    assert list(find_variables(ast.parse('let(code)'))) == ['code']

    assert list(find_variables(ast.parse(
        'let(code)\n'
        'let(code2)\n'
    ))) == ['code', 'code2']



# Generated at 2022-06-21 18:47:48.165023
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    k1 = ast.keyword(arg='a', value=ast.Num(n=1))
    k2 = ast.keyword(arg='a', value=ast.Num(n=2))
    k3 = ast.keyword(arg='a', value=ast.Num(n=3))

    t = ast.parse('''
lambda a=a: print(a)
    ''').body[0].value

    v = {'a': k2}
    VariablesReplacer.replace(t, v)

    assert t.keywords[0].arg is v['a']
    assert t.keywords[0].arg == 'a'

    t.keywords = [k3]
    VariablesReplacer.replace(t, v)

    assert t.keywords[0].arg is not v['a']
   

# Generated at 2022-06-21 18:48:10.758342
# Unit test for function extend
def test_extend():
    def test(x):
        extend('test')
        print(x)

    tree = snippet(test).get_body(test=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                   value=ast.Num(n=1),
                                                   type_comment=None),
                                       ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                  value=ast.Num(n=2),
                                                  type_comment=None)])

    assert get_source(tree) == 'x = 1\nx = 2\nprint(x)'



# Generated at 2022-06-21 18:48:17.226440
# Unit test for function let
def test_let():
    snippet = """
    def f():
        let(x)
        x = 0

    def g():
        let(x)
        x = 0
        let(y)
        y = 0
    """
    _let = let
    del let

    try:
        exec(snippet)
    except Exception as x:
        raise x
    finally:
        let = _let

    assert f"x" not in globals()
    assert f"y" not in globals()

    output = get_source(f)

# Generated at 2022-06-21 18:48:21.822098
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class A:
        def f(self, a: int) -> None:
            return a + 1

    a = A()

    assert 6 == a.f(5)
    assert 6 == a.f(5)



# Generated at 2022-06-21 18:48:32.250021
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    "test for visit_arg method of VariablesReplacer class"
    tree = ast.parse('def foo(x): pass')
    variables = {'x': 'y'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert tree._fields == ['body']
    assert tree.body[0]._fields == ['name', 'args', 'body', 'decorator_list', 'returns']
    assert tree.body[0].args._fields == ['args', 'defaults', 'vararg', 'kwonlyargs', 'kw_defaults', 'kwarg', 'posonlyargs']
    assert tree.body[0].args.args[0]._fields == ['arg', 'annotation']
    assert tree.body[0].args.args[0].arg == 'y'

# Generated at 2022-06-21 18:48:41.971472
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class A:
        pass

    node = A()
    node.id = 'x'
    node.name = 'y'
    node.arg = 'z'
    node.asname = 'asname'
    node.module = 'module'
    node.other = 'other'
    node.nested = A()
    node.nested.id = 'nested'
    node.nested.name = 'other_nested'
    node.nested.arg = 'other_nested'
    node.nested.asname = 'other_nested'
    node.nested.module = 'other_nested'
    node.nested.other = 'other_nested'

# Generated at 2022-06-21 18:48:52.622802
# Unit test for function extend_tree
def test_extend_tree():
    import astor
    first = ast.parse("""vars = [Assign(targets=[Name(id='x', ctx=Store())],
                                 value=Num(n=1, lineno=2, col_offset=4)),
                             Assign(targets=[Name(id='x', ctx=Store())],
                                 value=Num(n=2, lineno=3, col_offset=4))]
                        extend(vars)
                        print(x)""")
    # Check that code is the same

# Generated at 2022-06-21 18:48:59.599483
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    """Test visit_Name method of class VariablesReplacer."""
    tree = ast.parse("x = 1")
    variables = {'x': '_py_backwards_x_0'}
    tree = VariablesReplacer.replace(tree, variables)
    expected = ast.parse("_py_backwards_x_0 = 1")
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-21 18:49:06.349632
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(a)
    let(a)
    let(a)
    """

    tree = ast.parse(source)
    correct = {
        'a': '_py_backwards_a_0',
        '_py_backwards_a_0': '_py_backwards_a_1',
        '_py_backwards_a_1': '_py_backwards_a_2',
    }

    variables = list(find_variables(tree))
    assert variables == list(correct.values())



# Generated at 2022-06-21 18:49:12.725263
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    """
    Test the method VariablesReplacer.modify_attributes
    """
    class_body = [ast.Assign(targets=[ast.Name(id='var_1', ctx=ast.Store())],
                             value=ast.Name(id='Function', ctx=ast.Load())),
                  ast.Return(value=ast.Name(id='var_1', ctx=ast.Load()))]
    class_def = ast.ClassDef(name='MyClass',
                             bases=[],
                             keywords=[],
                             body=class_body,
                             decorator_list=[])

# Generated at 2022-06-21 18:49:15.060598
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import is_equal
    from .backwards import ast_to_source

# Generated at 2022-06-21 18:49:54.800569
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from .test_astbuilder import astbuilder
    builder = astbuilder()
    builder.try_start()
    builder.pass_(node_kw=dict(
        lineno=2,
        col_offset=4,
    ))
    builder.except_start()
    builder.import_from('sys', 'exit')
    builder.except_end()
    builder.try_end()
    result = builder.get_ast()
    assert result == ast.parse("""
    try:
        None
    except ImportError:
        from sys import exit
    """)
    assert VariablesReplacer.replace(result, {'ImportError': 'MyError'}) == ast.parse("""
    try:
        None
    except MyError:
        from sys import exit
    """)

# Generated at 2022-06-21 18:50:05.419329
# Unit test for function extend_tree
def test_extend_tree():
    assert ast.dump(extend_tree(
        ast.parse('''
if True:
    extend(vars)
    print('x', x)
'''), {
            'vars': ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Load())],
                value=ast.Num(n=3)
            )
        }
    )) == '''\
Module(body=[If(test=NameConstant(value=True), body=[Assign(targets=[Name(id='x', ctx=Load())], value=Num(n=3)), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Str(s='x'), Name(id='x', ctx=Load())], keywords=[]))], orelse=[])])
'''

# Generated at 2022-06-21 18:50:08.144702
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .context import tree_check


    @tree_check
    def foo(x: int) -> int:
        let(ctypes)
        return ctypes.c_int(x).value


    assert foo(0) == 0

# Generated at 2022-06-21 18:50:15.333306
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source = get_source(test_VariablesReplacer_visit_Name)
    tree = ast.parse(source)
    x = ast.Name(id='x_0')
    var_replacer = VariablesReplacer.replace(  # type: ignore
        tree, {'x': x})
    name = find(var_replacer, ast.Name)[0]
    assert name.id == 'x_0'



# Generated at 2022-06-21 18:50:23.695931
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .example import f
    v = VariablesGenerator('alias')
    code = ast.parse(get_source(f))
    code_new = VariablesReplacer.replace(code, {'a': v.generate('a'), 'b': v.generate('b')})
    actual = ast.dump(code_new)
    expected = "Module(body=[ImportFrom(module='x', names=[alias(name='a', asname=None)], level=0), ImportFrom(module='y', names=[alias(name='b', asname=None)], level=0)])"
    assert actual == expected

# Generated at 2022-06-21 18:50:29.589816
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer._replace_value('a', {'a': 'b'}) == 'b'
    assert VariablesReplacer._replace_value('a', {'a': ast.arg(arg='b')}) == ast.arg(arg='b')
    assert VariablesReplacer._replace_value('a', {'a': [ast.arg(arg='b')]}) == [ast.arg(arg='b')]
    assert VariablesReplacer._replace_value('a', {'a': ast.Name(id='b')}) == 'b'

# Generated at 2022-06-21 18:50:32.603952
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source = "a = 1\nprint(a)"
    tree = ast.parse(source)
    variables = {
        'a': 'b',
    }
    VariablesReplacer.replace(tree, variables)
    pass_tree = "b = 1\nprint(b)"
    assert ast.dump(tree) == ast.dump(ast.parse(pass_tree))



# Generated at 2022-06-21 18:50:38.270322
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('y(x=10)', mode='eval')

    extend_tree(tree, {'y': ast.Name('X', ast.Load()),
                       'x': ast.Name('Y', ast.Load())})
    result = VariablesReplacer.replace(tree, {'x': ast.Name('Z', ast.Load()),
                                              'y': ast.Name('A', ast.Load())})
    assert result.to_source() == 'A(Y=Z)'

# Generated at 2022-06-21 18:50:46.083418
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .tree import find
    import typed_ast.ast3 as ast
    from .helpers import get_source, VariablesGenerator

    source = get_source(lambda: 1 + 1)

    tree = ast.parse(source)
    alias = ast.alias('foo', None)
    tree.body[0].body[0].names[0] = alias

    variables = {alias: VariablesGenerator.generate(alias)}  # type: ignore

    VariablesReplacer.replace(tree, variables)

    node = find(tree, ast.alias)[0]
    assert node.name == 'foo'

# Generated at 2022-06-21 18:50:51.904133
# Unit test for function extend
def test_extend():
    def snippet(x: int, y: int, z: int) -> None:
        extend(vars)
        print(x, y)

    tree = snippet.get_body(
        vars=[ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
              ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))])
    assert len(tree) == 2
    assert tree[0].value.n == 1
    assert tree[1].value.n == 2

