

# Generated at 2022-06-21 18:41:35.347973
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # Given
    node = ast.ClassDef(name='Test', bases=[], body=[])
    replacer = VariablesReplacer(variables={'Test': 'NewTest'})
    # When
    node = replacer.visit_ClassDef(node)
    # Then
    assert node.name == 'NewTest'


# Generated at 2022-06-21 18:41:37.868386
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = ast.Name("x", ast.Load())
    let(x)
    code = snippet(lambda: x).get_body()
    assert code == [ast.Assign(targets=[x], value=ast.Num(1))], code

# Generated at 2022-06-21 18:41:42.887340
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .snippets import a, b
    snippet = a.get_body(b=b)
    # `b` should be replaced with unique name
    assert not any(isinstance(stmt, ast.ImportFrom) and stmt.module == 'snippets.b'
                   for stmt in snippet)

# Generated at 2022-06-21 18:41:50.220007
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    variables = {
        'a': 'b'
    }
    tree = ast.parse('f(a=1)')
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='f', ctx=Load()), args=[], keywords=[keyword(arg='b', value=Num(n=1))]))])"



# Generated at 2022-06-21 18:41:59.716734
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class S(ast.NodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            node = VariablesReplacer._replace_field_or_node(node, 'name', {'def_name': 'def_name_'})
            return self.generic_visit(node)  # type: ignore
    source = """def def_name(x):\n    print(x)"""
    tree = ast.parse(source)
    replaced_tree = S().visit(tree)

# Generated at 2022-06-21 18:42:05.928464
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    def f():
        try:
            raise Exception
        except Exception:
            raise Exception
    
    tree_1 = ast.parse(get_source(f))
    variables = {'Exception': 'ex'}
    VariablesReplacer.replace(tree_1, variables)
    # The parameter name in ExceptHandler should be replaced:
    assert len(find(tree_1, ast.ExceptHandler)) == 2
    for node in find(tree_1, ast.ExceptHandler):
        assert node.name == 'ex'


# Generated at 2022-06-21 18:42:18.089463
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f_test1(n: int, m: int) -> None:
        let(x)
        for i in range(m):
            extend(vars)
            x = i
        return x

    assert f_test1.get_body(vars='assign', m='2') == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.Num(n=0)),
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.Num(n=1))
    ]


# Generated at 2022-06-21 18:42:23.097646
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    from .tree import get_source

    source = """
    def foo(x, y):
        """

# Generated at 2022-06-21 18:42:33.103852
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import sys
    class TestVariablesReplacer(ast.NodeTransformer):
        def visit_ImportFrom(self, node: ast.ImportFrom) -> ast.ImportFrom:
            node = TestVariablesReplacer._replace_module(node, {"spam": "eggs"})
            return self.generic_visit(node)
        @classmethod
        def _replace_module(cls, node: ast.ImportFrom, variables: Dict[str, Variable]) -> ast.ImportFrom:
            node.module = VariablesReplacer._replace_module(node.module, variables)
            return node
    t = ast.parse('from spam import eggs')
    t = TestVariablesReplacer().visit(t)
    assert (astor.to_source(t) == 'from eggs import eggs\n')

# Generated at 2022-06-21 18:42:38.796397
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class Dummy(ast.arg):
        def __init__(self, arg):
            self.arg = arg

    node = Dummy('arg')
    variables = {'arg': 'new_arg'}
    replacer = VariablesReplacer(variables)
    replacer.visit(node)
    assert node.arg == 'new_arg'


# Generated at 2022-06-21 18:42:49.894773
# Unit test for function let
def test_let():
    def snippet_fn():
        let(x)
        x = 5 # type: ignore
        x += 1

    assert snippet(snippet_fn).get_body() == [
        ast.parse('_py_backwards_x_0 = 5').body[0],
        ast.parse('_py_backwards_x_0 += 1').body[0]
    ]



# Generated at 2022-06-21 18:42:51.154934
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda: 0)

# Generated at 2022-06-21 18:42:55.248107
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    y = 1
    let(z)
    '''
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'z'}



# Generated at 2022-06-21 18:42:56.169289
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda x: None)

# Generated at 2022-06-21 18:43:00.532015
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("a.b = 1")
    node = tree.body[0].value # value = Name(id='a', ctx=Load())
    variables = {'a': 'b'}

    replacer = VariablesReplacer(variables)
    replacer.visit(node)

    assert type(tree.body[0].value) == ast.Name

# Generated at 2022-06-21 18:43:05.725196
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():

    class A:
        class B:
            def f(self):
                pass
    variables = {'A': A}
    tree = ast.parse('A.B')

    result = VariablesReplacer.replace(tree, variables)

    assert(result.body[0].value.value.func.id == 'A')

# Generated at 2022-06-21 18:43:17.769133
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    # replace argumet of class str
    tree = ast.parse("let(x)\n' a = 1'.replace(x, '2')")
    variables = snippet(lambda: None)._get_variables(tree, {})
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree.body[0].value) == '\' a = 1\'.replace(_py_backwards_x_0, \'2\')'

    # replace attribute name of class str
    tree = ast.parse("let(x)\n''.x.replace(x, '2')")
    variables = snippet(lambda: None)._get_variables(tree, {})
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-21 18:43:24.161253
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("f(a=1, b=2, c=3)")
    variables = {'a': 1, 'b': 'new_b'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Call(func=Name(id='f', ctx=Load()), args=[], keywords=[keyword(arg='a', value=1), keyword(arg='b', value='new_b'), keyword(arg='c', value=3)])"


# Generated at 2022-06-21 18:43:31.404222
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('a = 1')
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                           value=ast.Num(n=2))]})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=2)), Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=1))])'

# Generated at 2022-06-21 18:43:41.123385
# Unit test for function let
def test_let():
    def foo():
        let(x)
        x += 1
        return x

    variables = find_variables(foo)
    assert len(variables) == 1
    assert 'x' in variables

    tree = ast.parse(inspect.getsource(foo))
    extend_tree(tree, variables)
    mod = VariablesReplacer.replace(tree, variables)
    assert mod.body[0].body[0].target.id.startswith('_py_backwards_x_')
    assert mod.body[0].body[0].value.id == '_py_backwards_x_0'



# Generated at 2022-06-21 18:43:58.481691
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    class Foo:
        @classmethod
        def import_module(cls):
            return "core.tests"

    class MockVariablesGenerator:
        def __init__(self):
            self._fakes = {}
            self._names = {}
            self._is_fake = True

        def generate(self, name: str) -> str:
            if name == "core.tests":
                return name

            if self._is_fake:
                key = name
                name = "0"
            else:
                key = "core.tests"

            if key not in self._fakes:
                self._fakes[key] = "fake." + name

            return self._fakes[key]

    VariablesGenerator._fake = MockVariablesGenerator()

# Generated at 2022-06-21 18:44:04.992049
# Unit test for function find_variables
def test_find_variables():
    import ast
    import textwrap
    source = textwrap.dedent('''\
        def foo():
            let(x)
            print(1)
            let(y)
            print(2)''')
    tree = ast.parse(source)
    assert find_variables(tree) == ['x', 'y']



# Generated at 2022-06-21 18:44:09.065733
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("x=1")
    variables = {'x': 'y'}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)

    assert ast.dump(tree) == ast.dump(ast.parse("y=1"))



# Generated at 2022-06-21 18:44:13.671452
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("import a as alias_a")
    visit_alias = VariablesReplacer.replace(tree, {'alias_a': 'b'}).body[0]
    assert str(visit_alias.names[0].asname) == 'b'



# Generated at 2022-06-21 18:44:22.966253
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import astor
    from .helpers import get_source

    def test_fn():
        x = "Hello"
        let(x)
        print(x)

    source = get_source(test_fn)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name)
                 for name in names}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    new_source = astor.to_source(tree)

    assert new_source == ("\n"
                          "def test_fn():\n"
                          "    x = 'Hello'\n"
                          "    print(_py_backwards_x_0)\n"
                          "\n")

# Generated at 2022-06-21 18:44:24.143793
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda: None)

# Generated at 2022-06-21 18:44:30.555794
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    var = ast.Name(id='var', ctx=ast.Load())
    var.lineno = 1
    var.col_offset = 0
    code = 'var.x()'
    tree = ast.parse(code)
    variables = {'var': var}
    assert VariablesReplacer.replace(tree, variables).body[0].value.value.id \
        == 'var'


# Generated at 2022-06-21 18:44:33.539011
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    node = ast.Attribute(value=ast.Name(id="x"), attr="y", ctx=ast.Load())
    node = ast.copy_location(node, ast.Name(id="y"))
    node = ast.keyword(arg=node, value=ast.Name(id="z"))

    repl = VariablesReplacer({'y': ast.Name(id="q")})
    repl.visit_keyword(node)

    assert node.arg.id == "q"

# Generated at 2022-06-21 18:44:36.827058
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def foo(a, b):
        pass
    tree = ast.parse(get_source(foo))
    inst = VariablesReplacer({'a': 'b'})
    inst.visit_FunctionDef(tree.body[0])
    assert get_source(tree) == 'def foo(b, b):\n    pass\n'



# Generated at 2022-06-21 18:44:45.040874
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    def _a():
        try:
            pass
        except ZeroDivisionError:
            pass

    test_source = 'def _a():\n    try:\n        pass\n    except ZeroDivisionError:\n        pass\n'
    tree = ast.parse(test_source)
    assert ast.dump(tree) == test_source
    VariablesReplacer.replace(tree, {'_a': '_a_func'})
    assert ast.dump(tree) == 'def _a_func():\n    try:\n        pass\n    except ZeroDivisionError:\n        pass\n'

# Generated at 2022-06-21 18:45:12.787810
# Unit test for function extend
def test_extend():
    # test_extends_tree
    snippet_fn = lambda output: extend(output)
    snippet_kwargs = {'output': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                            value=ast.Name(id='a', ctx=ast.Load())),
                                   ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                                              value=ast.Name(id='x', ctx=ast.Load())),
                                   ast.Assign(targets=[ast.Name(id='z', ctx=ast.Store())],
                                              value=ast.Name(id='y', ctx=ast.Load()))]}

# Generated at 2022-06-21 18:45:13.828877
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda x: x + 1)

# Generated at 2022-06-21 18:45:19.115776
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    fn = lambda: 6
    ast_tree = ast.parse(inspect.getsource(fn))
    # print(ast.dump(ast_tree))
    variables = {'fn': 'fn_0'}
    result = VariablesReplacer.replace(ast_tree, variables)
    assert(result.body[0].name == 'fn_0')

# Generated at 2022-06-21 18:45:28.682669
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from py_backwards.walkers.visitors import test_VariablesReplacer
    from py_backwards.transformers.transformers import VariablesReplacer
    import ast
    import typed_ast.ast3 as ast3
    class TypeDef(ast3.AST):
        _fields = ()
        _attributes = ('_fields', '_attributes')
        _astname = "typed_ast.ast3.Name"

    tree = TypeDef(id='_py_backwards_x_0')
    tree = ast3.alias(name=tree)
    node = VariablesReplacer({'x': '_py_backwards_x_0'})
    tree = VariablesReplacer.replace(tree, {'x': '_py_backwards_x_0'})
    result = test_VariablesReplacer.test

# Generated at 2022-06-21 18:45:39.662773
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("""def f(b=let(a)):
                            pass
                     """)

    inst = VariablesReplacer({})
    new_tree = inst.visit(tree)
    assert new_tree is tree

    inst = VariablesReplacer({'a': '_py_backwards_a_0'})
    new_tree = inst.visit(tree)

    assert new_tree is not tree
    assert new_tree.body[0].args.kwarg == '_py_backwards_a_0'

    inst = VariablesReplacer({'a': '_py_backwards_a_0', 'b': '_py_backwards_b_0'})
    new_tree = inst.visit(tree)

    assert new_tree is not tree

# Generated at 2022-06-21 18:45:43.005683
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    node = ast.ExceptHandler()
    node.name = 'x'
    assert 'x' == node.name
    variables = {'x': 'y'}
    assert VariablesReplacer.replace(node, variables).name == 'y'

# Generated at 2022-06-21 18:45:49.619540
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # Create the AST
    example = ast.Module(body=[ast.ClassDef(name='example'),
                               ast.Assign(targets=[ast.Name(id='example', ctx=ast.Store())],
                                          value=ast.Name(id='example', ctx=ast.Load()))])

    # Create the transformer
    class_to_string = ast.NodeTransformer()
    """Transformer that converts a class definition to a string definition"""

    # Define the visit_ClassDef() method
    @class_to_string.visit_ClassDef
    def _visit_ClassDef(self, node):
        return ast.Str("example")

    # Transform the AST
    class_to_string.visit(example)
    assert example.body[0] == ast.Str("example")

# Generated at 2022-06-21 18:46:01.684231
# Unit test for function extend_tree
def test_extend_tree():
    # test for no extend calls
    tree = ast.parse('x = 2')
    extend_tree(tree, {})
    assert tree.body == [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                          value=ast.Num(n=2))]

    # test for one extend call
    tree = ast.parse('extend(x)\n')
    extend_tree(tree, {'x': [ast.parse('x+=2').body[0]]})
    assert tree.body[0] == ast.AugAssign(target=ast.Name(id='x', ctx=ast.Load()),
                          op=ast.Add(), value=ast.Num(n=2))

    # test for more extend calls

# Generated at 2022-06-21 18:46:12.949307
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import re
    import astor
    frum = ast.parse('''from A.B import C as D''')
    node = frum.body[0]
    assert isinstance(node, ast.ImportFrom)
    assert node.module == 'A.B'
    assert node.aliases[0].name == 'C'
    assert node.aliases[0].asname == 'D'
    D = '__D_0'
    inst = VariablesReplacer({'D': D})
    new_node = inst.visit_alias(node.aliases[0])
    assert new_node.asname == D
    assert new_node.name == 'C'
    assert isinstance(new_node, ast.alias)

# Generated at 2022-06-21 18:46:19.268566
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    alias_node = ast.alias(name="alias", asname='alias1')
    alias_node = VariablesReplacer.replace(alias_node, dict())
    assert(alias_node.name == 'alias')
    assert(alias_node.asname == 'alias1')

    alias_node = ast.alias(name="alias", asname='alias1')
    alias_node = VariablesReplacer.replace(alias_node, dict(alias='new_alias'))
    assert(alias_node.name == 'new_alias')
    assert(alias_node.asname == 'alias1')

    alias_node = ast.alias(name="alias", asname='alias1')
    alias_node = VariablesReplacer.replace(alias_node, dict(alias1='new_alias1'))

# Generated at 2022-06-21 18:46:26.720464
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-21 18:46:29.100064
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    node = ast.arg(arg='x', annotation=None)
    assert VariablesReplacer.replace(node, {'x': 'y'}) == ast.arg(arg='y', annotation=None)

# Generated at 2022-06-21 18:46:41.327085
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class visitor(VariablesReplacer):
        def visit_Name(self, node):
            return super().visit_Name(node)

    visitor_obj = visitor({'x': 'y'})

    def visit_Name_test(x):
        return visitor_obj.visit_Name(x)

    assert visit_Name_test(ast.parse('x', mode='eval').body) == ast.parse('y', mode='eval').body
    assert visit_Name_test(ast.Name('x', ast.Load())) == ast.Name('y', ast.Load())
    assert visit_Name_test(ast.Name('x', ast.Store())) == ast.Name('y', ast.Store())
    assert visit_Name_test(ast.Name('x', ast.Param())) == ast.Name('y', ast.Param())


# Generated at 2022-06-21 18:46:45.241993
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    assert get_source(VariablesReplacer.replace(ast.parse("""
    def f(a, b):
        return a + b
    """), {'a': 'b'})) == """
    def f(b, b_0):
        return b + b_0
    """


# Generated at 2022-06-21 18:46:56.973001
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''let(x)
           x = 1
           def foo(add): 
               x *= add
               bar(x)
        ''', mode='exec')
    variables = find_variables(tree)
    assert next(variables) == 'x'
    with pytest.raises(StopIteration):
        next(variables)

    tree = ast.parse('''let(x)
           x = 1
           let(y)
           y = 1
           def foo(add): 
               x *= add
               bar(x, y)
        ''', mode='exec')
    variables = find_variables(tree)
    assert next(variables) == 'x'
    assert next(variables) == 'y'

# Generated at 2022-06-21 18:47:07.895749
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars)\nprint('hello')")
    x = ast.Name('x', ast.Store())
    y = ast.Name('y', ast.Store())
    var = ast.Assign([y], ast.Num(1))
    vars = {'vars': [x, var]}
    extend_tree(tree, vars)
    assert ast.dump(tree) == ast.dump(ast.Module(body=[x, var, ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                                                                                   args=[ast.Str(s='hello')],
                                                                                   keywords=[])), ast.Expr(value=ast.Num(n=1))]))

# Generated at 2022-06-21 18:47:13.601712
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source="from a.b.c import test, test2 as test3"
    tree = ast.parse(source)
    variables = {'a': 'd'}
    variables_replacer = VariablesReplacer(variables)
    visited_tree = variables_replacer.visit(tree)
    expected_source = "from d.b.c import test, test2 as test3"
    assert(get_source(visited_tree) == expected_source)

# Generated at 2022-06-21 18:47:21.837383
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse('''
try:
    pass
except:
    pass
''')
    as_tree = ast.parse('''
try:
    pass
except Exception as e:
    pass
''')
    node = tree.body[0]
    inst = VariablesReplacer.__dict__['visit_ExceptHandler']
    res = inst(VariablesReplacer, node.handlers[0])
    assert ast.dump(res, include_attributes=False) == ast.dump(as_tree)


# Generated at 2022-06-21 18:47:26.252536
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source = """
a = 1
r = a
print(r)
"""
    tree = ast.parse(source)
    variables = {'a': 1}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert(ast.dump(tree) == source)



# Generated at 2022-06-21 18:47:28.012496
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    from typing import List

# Generated at 2022-06-21 18:47:39.383547
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("""
    a = 3
    b = 5
    """)
    variables = {'a': 'c', 'b': 'd'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == """Module(body=[Assign(targets=[Name(id='c', ctx=Store())], value=Num(n=3)), Assign(targets=[Name(id='d', ctx=Store())], value=Num(n=5))])"""


# Generated at 2022-06-21 18:47:47.290579
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from typed_ast.ast3 import ImportFrom
    import_ = ImportFrom(
        module='a.b',
        names=[
            ast.alias(name='x', asname=None)
        ]
    )
    imports = {
        'x': 'c',
        'a': 'd'
    }
    replacer = VariablesReplacer(imports)
    assert replacer.visit_ImportFrom(import_).module == 'd.b'



# Generated at 2022-06-21 18:47:55.427514
# Unit test for function extend_tree
def test_extend_tree():
    source = '''def fn():
    extend(vars)
    print(x)
    print(y)'''
    tree = ast.parse(source)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(1)),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(2))
    ]
    extend_tree(tree, {'vars': vars})
    assert get_source(tree.body[0].body[0]) == \
        'x = 1'
    assert get_source(tree.body[0].body[1]) == \
        'y = 2'

# Generated at 2022-06-21 18:48:07.157196
# Unit test for function extend
def test_extend():
    def foo():
        extend(dict(x=1))
        print(x)
    tree = ast.parse(get_source(foo))
    assert isinstance(tree.body[0].body[0], ast.Expr)
    assert isinstance(tree.body[0].body[0].value, ast.Dict)
    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=\'foo\', args=arguments(args=[], vararg=None, kwonlyargs=[], defaults=[], kw_defaults=[]), body=[Expr(value=Dict(keys=[], values=[])), Print(dest=None, values=[Name(id=\'x\', ctx=Load())], nl=True)], decorator_list=[], returns=None)])'

# Generated at 2022-06-21 18:48:12.864384
# Unit test for function find_variables
def test_find_variables():
    source = '''
let(z)
let(x)
z = 1
x = 2
let(y)
y = 3
'''

    tree = ast.parse(source)
    expected = ['x', 'y', 'z']
    assert len(list(find_variables(tree))) == len(expected)
    assert all(find(tree, ast.Name, True)[0].id == var for var in expected)



# Generated at 2022-06-21 18:48:20.692680
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class TestClass(ast.NodeTransformer):
        var_dict = {}

        def __init__(self, var_dict_):
            self.var_dict = var_dict_
            self.visit(ast.parse('''
from a.b import x as c
from a.b.c import x'''))

        def visit_alias(self, node):
            if node.asname:
                if node.asname in self.var_dict:
                    if isinstance(self.var_dict[node.asname], str):
                        node.asname = self.var_dict[node.asname]
                    elif isinstance(self.var_dict[node.asname], type(node)):
                        node = self.var_dict[node.asname]

            return node


# Generated at 2022-06-21 18:48:29.224216
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    # Given
    class FunctionDefExtractor(ast.NodeVisitor):
        def __init__(self):
            self.function_def = None

        def visit_FunctionDef(self, node: ast.FunctionDef):
            self.function_def = node

    source = '''
        def lambda_func(x):
            return x + 1
    '''
    tree = ast.parse(source)
    function_def_extractor = FunctionDefExtractor()
    function_def_extractor.visit(tree)
    function_def = function_def_extractor.function_def

    # When
    new_function_def = VariablesReplacer.visit_FunctionDef(
        VariablesReplacer({'lambda_func': 'func'}), function_def)

    # Then
    assert new_function_def is not None

# Generated at 2022-06-21 18:48:39.678095
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    source = "def test(x): return x"
    tree = ast.parse(source)
    variables = {'x': 1}
    VariablesReplacer.replace(tree, variables)
    assert source == get_source(tree)

    source = "def test(x): x.strict += 1"
    tree = ast.parse(source)
    variables = {'x': ast.Name(id='a', ctx=ast.Load())}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == "def test(a): a.strict += 1"

    source = "def test(x): x.strict += 1"
    tree = ast.parse(source)
    variables = {'x': ast.Name(id='a', ctx=ast.Load())}
    VariablesRepl

# Generated at 2022-06-21 18:48:50.371961
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    class_source = "class Foo(Bar): pass"
    tree = ast.parse(class_source)
    class_def = tree.body[0]
    import_source = "from foo.bar import Baz"
    import_tree = ast.parse(import_source)
    import_from = import_tree.body[0]
    # Set import_from as a function body
    class_def.body.append(import_from)
    # Set 'Baz' as the base class
    class_def.bases[0].elts[0] = ast.Name('Baz', ast.Load())
    # Replace variables
    variables = dict(Foo='Foo_0', Bar='Bar_0', Baz='Baz_0')
    new_tree = VariablesReplacer.replace(tree, variables)
    # Make sure that

# Generated at 2022-06-21 18:48:57.039245
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    # Example:
    # def func(self, test_id=_py_backwards_pid):
    # result:
    # def func(self, test_id=pid):
    tree = ast.parse(
        "def func(self, test_id=let(pid)):\n    pass\n")
    variables = {'pid': 'pid'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='func', args=arguments(args=[arg(arg='self', annotation=None), arg(arg='test_id', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])\n"

# Generated at 2022-06-21 18:49:04.508985
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    pass

# Generated at 2022-06-21 18:49:06.273215
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-21 18:49:12.687370
# Unit test for function extend
def test_extend():
    from .helpers import var
    from .snippet import snippet

    def extended():
        extend(vars)
        print(x, y)

    for i in range(2):
        x = var()
        y = var()
        vars = [ast.Assign([ast.Name(x, ast.Store())], ast.Num(i + 1)),
                ast.Assign([ast.Name(y, ast.Store())], ast.Num(i + 1))]
        expected = [ast.Expr(ast.Call(
            ast.Name('print', ast.Load()),
            [ast.Name(x, ast.Load()), ast.Name(y, ast.Load())],
            []))]
        assert snippet(extended).get_body(vars=vars) == expected

# Generated at 2022-06-21 18:49:17.754051
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("""assert a(b, x=c)""")
    var_replacer = VariablesReplacer({'a':'z', 'c':'d'})
    tree = var_replacer.visit(tree)
    assert ast.dump(tree.body[0]) == "Assert(test=z(b, x=d), msg=None)"

# Generated at 2022-06-21 18:49:24.574374
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = 'from aa import bb'
    tree = ast.parse(source)
    variables = {'aa': 'cc.dd'}

    inst = VariablesReplacer(variables)
    inst.visit(tree)

    expected = 'from cc.dd import bb'
    actual = ast.fix_missing_locations(tree).body[0]
    assert expected == ast.dump(actual)



# Generated at 2022-06-21 18:49:27.946160
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    replacer = VariablesReplacer({})
    def foo(): pass
    tree = ast.parse(get_source(foo))
    replacer.visit(tree)
    assert tree.body[0].name == 'foo'


# Generated at 2022-06-21 18:49:38.546028
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
    extend(a)
    extend(b)
    extend(c)
    ''')

    extend_tree(tree, {'a': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                        value=ast.Num(n=7))],
                         'b': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                          value=ast.Num(n=8))],
                         'c': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                          value=ast.Num(n=9))]})


# Generated at 2022-06-21 18:49:47.913848
# Unit test for function extend
def test_extend():
    def snippet_fn(vars: List[ast.AST], x: ast.AST) -> None:
        extend(vars)
        print(x)

    x = ast.parse('x * 2').body[0]
    snippets_ast = snippet(snippet_fn).get_body(vars=[ast.Assign([x], ast.Num(1))], x=ast.Num(1))
    assert snippets_ast == [
        ast.Assign([x], ast.Num(1)),
        ast.Assign([x], ast.Num(2)),
        ast.Expr(ast.Call(ast.Name('print', ast.Load()), [x], [], None, None))
    ]

# Generated at 2022-06-21 18:49:49.699818
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:49:55.774493
# Unit test for function extend_tree
def test_extend_tree():
    @snippet
    def test_tree():
        extend(vars)

    tree = ast.parse(get_source(test_tree))
    extend_tree(tree, {'vars': [ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1))]})
    assert get_source(tree) == 'x = 1\n'



# Generated at 2022-06-21 18:50:25.807176
# Unit test for function let
def test_let():

    def sample():
        let(x)
        x += 1
        y = 1

    body = snippet(sample).get_body()

    assert len(body) == 2

    assert ast.dump(body[0]) == "AugAssign(target=Name(id='_py_backwards_x_0', ctx=Store()), op=Add(), value=Num(n=1))"
    assert ast.dump(body[1]) == "Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=1))"


# Generated at 2022-06-21 18:50:29.178496
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class B:
        pass

    b = B()
    b.x = 2
    b.y = 3
    var = VariablesGenerator.generate('a')
    vr = VariablesReplacer({'x': var})
    assert vr.visit_Attribute(b.x) == var

# Generated at 2022-06-21 18:50:29.711662
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:50:33.004196
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    result = VariablesReplacer.replace(
        ast.parse("def f(x)"), {'x': 'x_0'}
    )
    assert ast.dump(result) == 'FunctionDef(name=\'f\', args=arguments(args=[arg(arg=\'x_0\', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)'

# Generated at 2022-06-21 18:50:42.654621
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import random
    import astor
    
    # generate random code
    node = random.choice([
        ast.ClassDef(name=None, bases=[], keywords=[], body=[], decorator_list=[]),
        ast.ClassDef(name='', bases=[], keywords=[], body=[], decorator_list=[]),
        ast.ClassDef(name='class', bases=[], keywords=[], body=[], decorator_list=[]),
        ast.ClassDef(name='class_with_long_name', bases=[], keywords=[], body=[], decorator_list=[]),
    ])

# Generated at 2022-06-21 18:50:51.193647
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    test_case = {
            'name': 'bar',
            'value': 'foo',
            'expected_name': 'foo'
    }

    def test():
        tree = ast.parse(
            '''
            class MyClass:
                def __init__(self):
                    self.bar = None
        ''')
        attribute = tree.body[0].body[0].body[0].value
        assert isinstance(attribute, ast.Attribute)
        assert attribute.attr == test_case['name']
        return attribute

    attribute = test()
    variables = {test_case['name']: test_case['value']}
    VariablesReplacer.replace(attribute, variables)
    assert attribute.attr == test_case['expected_name']



# Generated at 2022-06-21 18:51:01.886212
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():

    class TestClass:
        """Test class"""

        def __init__(self, x, y) -> None:
            self.x = x
            self.y = y

        def test_method(self) -> None:
            """Test method"""

            try:
                raise ValueError
            except ValueError as e:
                e = '1'

    var_finder = snippet(TestClass.test_method)
    names = find_variables(ast.parse(get_source(TestClass.test_method)))
    variables = {name: VariablesGenerator.generate(name) for name in names}
    VariablesReplacer.replace(ast.parse(get_source(TestClass.test_method)), variables)
    replaced = var_finder.get_body()
    tree = ast.Module(body=replaced)
    assert get

# Generated at 2022-06-21 18:51:05.556825
# Unit test for function let
def test_let():
    @snippet
    def test():
        let(x)
        x += 1
        y = x

    assert test.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1),
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load())
        ),
    ]


#

# Generated at 2022-06-21 18:51:11.401296
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    var_replacer = VariablesReplacer(
        {"echo": "_py_backwards_echo_0"}
    )  # TODO check if it doesn't have to be a `function_def_0`
    new_tree = var_replacer.visit(ast.parse("def echo():\n    print(1)"))
    print(ast.dump(new_tree))

# Generated at 2022-06-21 18:51:20.698005
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # Case 1
    # Input
    tree = ast.parse("from src.root.module import x as y")
    variables = {'src.root.module': 'new.name'}
    # Expected
    expected = "from new.name import x as y"
    # Actual
    actual = VariablesReplacer.replace(tree, variables)
    actual_src = ast.dump(actual)
    assert expected == actual_src

    # Case 2
    # Input
    tree = ast.parse("from src.root.module import x as y")
    variables = {'x': 'z'}
    # Expected
    expected = "from src.root.module import z as y"
    # Actual
    actual = VariablesReplacer.replace(tree, variables)
    actual_src = ast.dump(actual)
    assert expected