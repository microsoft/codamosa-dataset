

# Generated at 2022-06-21 18:41:55.890585
# Unit test for function extend_tree
def test_extend_tree():
    src = """extend(var)"""
    tree = ast.parse(src)
    var = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(1))
    extend_tree(tree, {'var': var})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1))])'

# Generated at 2022-06-21 18:41:56.800832
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-21 18:42:05.836948
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import pytest
    class TestNode(ast.ExceptHandler):
        def __init__(self, name):
            self.name = name

    handlers = [TestNode(name) for name in ['a', 'b', 'c']]
    tree = ast.Try(body=None,
                   handlers=handlers,
                   orelse=None,
                   finalbody=None)

    variables = {
        'a': '_a',
        'b': '_b',
        'x': '_x',
        'c': '_c'
    }

    VariablesReplacer.replace(tree, variables)
    for handler in tree.handlers:
        assert handler.name in ['_a', '_b', '_c']


# Generated at 2022-06-21 18:42:17.647889
# Unit test for function extend
def test_extend():
    import astor
    
    # Example of assign statement (extended code)
    assign = ast.Assign(targets=[ast.Name(id='x')],
        value=ast.Constant(value=1, kind=None))

    # Contain AST of assign statement that should be extended
    @snippet
    def func(vars):
        extend(vars)
        print(x)

    # Expected code
    # x = 1
    # print(x)
    expected_ast = ast.Module(body=[assign, ast.Expr(value=ast.Name(id='x'))])
    
    # Test
    # Generate code from AST
    res = func.get_body(vars=assign)
    res_ast = ast.Module(body=res)
    res_code = ast

# Generated at 2022-06-21 18:42:18.742452
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:42:30.183501
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    node = ast.Name(id="n")
    kwargs = [ast.keyword(arg="n", value=node)]
    parent = ast.FunctionDef(name="f", args=ast.arguments(args=[],
                                                          vararg=None,
                                                          kwarg=None,
                                                          defaults=[],
                                                          kw_defaults=[]),
                             body=[],
                             decorator_list=[],
                             returns=None)
    call_node = ast.Call(func=parent,
                         args=[],
                         keywords=kwargs, starargs=None, kwargs=None)
    k = ast.Name(id="k")
    variables = {"n": k}
    inst = VariablesReplacer(variables)
    inst.visit(call_node)

# Generated at 2022-06-21 18:42:34.667503
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from_node = ast.ImportFrom('os.path', [ast.alias('path', 'path')], 0)
    variables = {'path': 'os.path.realpath'}
    assert VariablesReplacer.replace(import_from_node, variables).module == 'os.realpath'

# Generated at 2022-06-21 18:42:37.883245
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    from .snippets import snippet_1
    from .helpers import assert_tree_equal

    source = get_source(snippet_1)
    tree = ast.parse(source)
    variables = find_variables(tree)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

    expected = ast.parse("""
    some.assign(a, b=1)
    """)

    assert_tree_equal(tree, expected)

# Generated at 2022-06-21 18:42:46.663147
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    import astor
    code = """
    def func():
        return 1


    def func(arg):
        return arg


    def func(arg1, arg2):
        return arg1 + arg2
    """
    tree = ast.parse(code)
    VariablesReplacer.replace(tree, {'func': '_py_backwards_func_0'})
    assert astor.to_source(tree) == '\ndef _py_backwards_func_0():\n    return 1\n\n\ndef _py_backwards_func_0(arg):\n    return arg\n\n\ndef _py_backwards_func_0(arg1, arg2):\n    return arg1 + arg2\n'

# Generated at 2022-06-21 18:42:55.365891
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():

    source = 'x'
    tree = ast.parse(source)

    variables = {'x': '_py_backwards_x_0'}

    expected = '_py_backwards_x_0'
    actual = VariablesReplacer.replace(tree, variables)
    assert(get_source(actual) == expected)

    source = 'x'
    tree = ast.parse(source)

    variables = {'x': List[ast.AST]}

    expected = 'x'
    actual = VariablesReplacer.replace(tree, variables)
    assert(get_source(actual) == expected)


# Generated at 2022-06-21 18:43:02.865043
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('a.b')
    tree.body[0].value.value.id = 'c'
    assert ast.dump(tree) == u'Module(body=[Expr(value=Attribute(value=Name(id=\'c\', ctx=Load()), attr=\'b\', ctx=Load()))])'

# Generated at 2022-06-21 18:43:05.775859
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer({"a1": "b1"})
    assert VariablesReplacer({"a1": ast.parse("1")})


# Generated at 2022-06-21 18:43:10.972441
# Unit test for function let
def test_let():
    assert get_source(lambda: let(None)) == 'let(None)'
    assert get_source(lambda: let(1)) == 'let(1)'
    assert get_source(lambda: let(x)) == 'let(x)'
    assert get_source(lambda: let(x.y)) == 'let(x.y)'



# Generated at 2022-06-21 18:43:15.746328
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Node(ast.ClassDef):
        name = 'test_name'
        body = 'test_body'

    node = Node()
    replaced = VariablesReplacer.replace(node, {'test_name': 'replaced_test_name'})
    assert replaced.name == 'replaced_test_name'

# Generated at 2022-06-21 18:43:19.510990
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    v = {'a': 'b'}
    assert VariablesReplacer(v).visit_ImportFrom(ast.ImportFrom('a', [], 1)) == ast.ImportFrom('b', [], 1)

# Generated at 2022-06-21 18:43:25.681775
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = get_source(snippet)
    tree = ast.parse(source)
    variables = find_variables(tree)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    return tree.body[0].body # type: ignore

# Generated at 2022-06-21 18:43:27.049319
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:43:33.587240
# Unit test for function extend
def test_extend():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)

    variables = {"vars": []}

    for n in range(10):
        variables["vars"].append(
            ast.Assign([ast.Name(id='x')], ast.Num(n))  # type: ignore
        )

    extend_tree(tree, variables)

    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 0
        x = 1
        x = 2
        x = 3
        x = 4
        x = 5
        x = 6
        x = 7
        x = 8
        x = 9
        print(x, y)
    """))

# Generated at 2022-06-21 18:43:40.222701
# Unit test for function let
def test_let():
    """ Tests whether the let function works properly or not """
    def snippet_body():
        let(x)
        x += 1
        y = 1

    snippet_body_upd = snippet(snippet_body).get_body()
    assert snippet_body_upd[0].value.id == '_py_backwards_x_0'
    assert snippet_body_upd[2].target.id == 'y'



# Generated at 2022-06-21 18:43:51.818211
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import astor

    class test:
        def __init__(self, a, b='x'):
            a = self.a = a
            b = self.b = b
            z = a + b
            z = z + z

    def source_fn(a, b='x'):
        class A:
            def __init__(self, a, b='x'):
                a = self.a = a
                b = self.b = b
                z = a + b
                z = z + z

    tree = ast.parse(source_fn.__code__.co_consts[1])

    variables = {'A': test, 'a': 'b'}
    assert VariablesReplacer.replace(tree, variables)


# Generated at 2022-06-21 18:44:03.027540
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('def f(x, y):\n    return x\ny=f(x=1,y=2)')
    variables = {'x': 'a', 'y': 'b'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'def f(a, b):\n    return a\nb=f(x=1,y=2)'

# Generated at 2022-06-21 18:44:10.244007
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    code = 'x = 1; y = 2; return x + y'
    tree = ast.parse(code)

    class VariablesReplacerSubclass(VariablesReplacer):
        def visit_keyword(self, node: ast.keyword) -> ast.keyword:
            node = super().visit_keyword(node)
            return node.value.left
    
    instance = VariablesReplacerSubclass({})
    result = instance.visit(tree)
    assert 'return x + y' in ast.dump(result)

# Generated at 2022-06-21 18:44:11.771153
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    # type: () -> None
    assert VariablesReplacer


# Generated at 2022-06-21 18:44:21.093917
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def to_test():
        x = None  # type: ignore
        x = None  # type: ignore
        let(x)
        x = 1
        extend(x)
        y = 1

    snippet1 = snippet(to_test)
    body1 = snippet1.get_body()
    body2 = snippet1.get_body(x=1)
    body3 = snippet1.get_body(x=ast.Name(id='_py_backwards_let_0'))

    assert body1 == body2
    assert body1 != body3

# Generated at 2022-06-21 18:44:25.595528
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    source = """
    let(x)
    x = 'backwards'
    def some_func(x):
        return x
    """
    try:
        VariablesReplacer(None)
    except AttributeError:
        return
    assert False


# Generated at 2022-06-21 18:44:34.308241
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('def f(x): return x')
    # Build new VariablesReplacer instance and replace 'x' with ['a', 'b']
    VariablesReplacer.replace(tree, {'x': ['a', 'b']})

# Generated at 2022-06-21 18:44:38.160344
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class MyClass:
        a = 4
        b = 4
    x = MyClass()
    x.a += 1
    x.b -= 3
    assert x.a == 5
    assert x.b == 1

# Generated at 2022-06-21 18:44:49.213377
# Unit test for function let
def test_let():
    @snippet
    def test_let1():
        let(a)
        return (a + a)
    @snippet
    def test_let2():
        a = 10
        let(b)
        return (a + b)
    @snippet
    def test_let3():
        let(a)
        a = 10
        return (a + a)
    @snippet
    def test_let4():
        let(a)
        let(b)
        return (a + b)
    @snippet
    def test_let5():
        let(a)
        let(b)
        return (a + b)
    @snippet
    def test_let6():
        let(a)
        print(a)
        a = 10

# Generated at 2022-06-21 18:44:57.110371
# Unit test for function extend_tree
def test_extend_tree():
    import ast as ast3
    from .backwards import extend_tree

    def _test_extend_tree(code_template: str) -> None:
        code = code_template.format('')
        tree = ast3.parse(code)
        extend_tree(tree, {'vars': ast3.parse(code).body[0]})
        assert code == compile(tree, '', 'exec')

    _test_extend_tree("""
let(vars)
{}
""")

    _test_extend_tree("""
let(a)
let(b)
{}
""")

    _test_extend_tree("""
extend(vars)
{}
""")


# Generated at 2022-06-21 18:45:04.064902
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast_unparse
    from ast_unparse import ast_unparse

    # test
    @snippet
    def test5():
        import a.b
        let(x)
        extend(vars)
        return x

    a = ast.parse("x = 1; y = 2;")


# Generated at 2022-06-21 18:45:22.738694
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var1 = ast.Name(id='x')
    var2 = 'y'
    var3 = ast.Name(id='z')

    @snippet
    def test_snippet(arg1, arg2, arg3):
        a = 1
        let(arg1)
        let(arg2)
        a = arg1

    body = test_snippet.get_body(arg1=var1, arg2=var2, arg3=var3)

# Generated at 2022-06-21 18:45:28.829082
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("x = 1\nx + 1\n")
    variables = {'x': 'y'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="y", ctx=Store())], value=Num(n=1)), Expr(value=BinOp(left=Name(id="y", ctx=Load()), op=Add(), right=Num(n=1)))])'


# Generated at 2022-06-21 18:45:39.745001
# Unit test for function extend_tree

# Generated at 2022-06-21 18:45:40.389912
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    pass

# Generated at 2022-06-21 18:45:42.965490
# Unit test for function extend_tree
def test_extend_tree():
    import py_backwards.transform  # pylint: disable=import-outside-toplevel

# Generated at 2022-06-21 18:45:47.249583
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
  src = """
  assert(a == b)
  """
  tree = ast.parse(src)
  variables = {'a': '1', 'b': '2'}
  VariablesReplacer.replace(tree, variables)
  assert(ast.dump(tree) == "Module(body=[Assert(test=Compare(left=Num(n=1)\n,\n, ops=[Eq()], comparators=[Num(n=2)]))])")

# Generated at 2022-06-21 18:45:48.202377
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(int) is not None

# Generated at 2022-06-21 18:45:55.160504
# Unit test for function extend
def test_extend():
    vars = [
        ast.parse('''x = 1''').body[0],
        ast.parse('''x = 2''').body[0],
    ]
    body = snippet(extend_test).get_body(vars=vars)
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[2], ast.Expr)



# Generated at 2022-06-21 18:46:03.268088
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    assert VariablesReplacer({'a': ['b']}).visit_Name(ast.Name('a', ast.Load())) == ast.Name('b', ast.Load())
    assert VariablesReplacer({'a': 'b'}).visit_Name(ast.Name('a', ast.Load())) == ast.Name('b', ast.Load())
    assert VariablesReplacer({'a': ast.Name('b', ast.Load())}).visit_Name(ast.Name('a', ast.Load())) == ast.Name('b', ast.Load())


# Generated at 2022-06-21 18:46:13.693205
# Unit test for function let
def test_let():
    import unittest

    tree = ast.parse("""
    let(uniq_var)
    some_var1 = 1
    uniq_var = 2
    some_var2 = 3
    """)

    uniq_vars = {'uniq_var': 'replaced_var'}
    VariablesReplacer.replace(tree, uniq_vars)
    assert ast.dump(tree) == 'Module([Assign([Name(some_var1, Store())], Constant(1)), Assign([Name(replaced_var, Store())], Constant(2)), Assign([Name(some_var2, Store())], Constant(3))])'



# Generated at 2022-06-21 18:46:24.262022
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # setup
    class TestImportFrom(ast.ImportFrom):
        pass
    root = TestImportFrom(module="module.submodule")

    modules = {
        "module": {
            "submodule": "module.submodule2"
        }
    }
    replacer = VariablesReplacer(modules)
    # act
    replacer.visit(root)
    # verify
    assert root.module == "module.submodule2"



# Generated at 2022-06-21 18:46:27.325891
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    snippet = Snippet(lambda x: y)
    tree = snippet.get_body(x)
    print(tree)


# Generated at 2022-06-21 18:46:39.367360
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class T(VariablesReplacer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            node = self._replace_field_or_node(node, 'id', True)
            return node
    source = """
let(x)
let(y)
x = 1
x += 1
x += y
x += y
x += y
x += y
let(z, 2)
x += z
x += y"""
    tree = ast.parse(source)
    variables = {'x': 1, 'y': 2, 'z': 3}
    replace_variables = T(variables)
    replace_variables.visit(tree)

# Generated at 2022-06-21 18:46:42.613013
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    a = ast.parse('class A: pass').body[0]
    b = ast.parse('class B: pass').body[0]
    assert VariablesReplacer.replace(a, {'A': b}).name == 'B'



# Generated at 2022-06-21 18:46:43.196617
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-21 18:46:50.731950
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("foo(x=x, y=x)")
    variables = {'x': 3}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert ast.dump(tree) == "Expr(value=Call(func=Name(id='foo', ctx=Load()), " \
                            "args=[], keywords=[keyword(arg='x', value=Num(n=3)), " \
                            "keyword(arg='y', value=Num(n=3))]))"

# Generated at 2022-06-21 18:46:58.733404
# Unit test for function let
def test_let():
    code = """
        x = 'abc'
        let(x)
        x += 'd'
        x = 'abc'
    """
    tree = ast.parse(code)
    variables = find_variables(tree)
    assert len(variables) == 1
    assert variables['x'] == '_py_backwards_x_0'
    new_code = astor.to_source(tree)
    assert new_code == code.replace('let(x)', '_py_backwards_x_0 += \'d\'')



# Generated at 2022-06-21 18:47:09.425477
# Unit test for function extend
def test_extend():
    def x(vars):
        extend(vars)

    body = x.get_body(vars=[
        ast.Assign([ast.Name(id='x', ctx=ast.Store())],
                   ast.Num(n=1)),
        ast.Assign([ast.Name(id='y', ctx=ast.Store())],
                   ast.Num(n=2)),
    ])

    assert body == [
        ast.Assign([ast.Name(id='x', ctx=ast.Store())],
                   ast.Num(n=1)),
        ast.Assign([ast.Name(id='y', ctx=ast.Store())],
                   ast.Num(n=2)),
    ]


# Generated at 2022-06-21 18:47:16.102674
# Unit test for function extend
def test_extend():
    from ._test import run_test, ASTTestCase
    from .tree import get
    from . import astutils

    class TestExtend(ASTTestCase):
        @staticmethod
        def _get_extended_tree(variables):
            @snippet
            def func():
                extend(variables)
                x = 1  # noqa

            return func.get_body()

        def test_simple(self):
            tree = self._get_extended_tree([ast.Assign(targets=[ast.Name(id='x',
                                                                          ctx=ast.Load())],
                                                       value=ast.Num(n=1))])

# Generated at 2022-06-21 18:47:23.329509
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    parent = ast.parse('pass')
    keyword = ast.keyword(arg='x', value=ast.Name(id='y'))
    parent.body[0].keywords.append(keyword)  # type: ignore
    vars = {'x': 'z'}
    VariablesReplacer.replace(parent, vars)
    assert ast.dump(parent) == 'Module(body=[Pass(keywords=[arg(arg=\'z\', value=Name(id=\'y\', ctx=Load()))])])'

# Generated at 2022-06-21 18:47:32.545592
# Unit test for function extend_tree
def test_extend_tree():
    import astor

# Generated at 2022-06-21 18:47:33.771721
# Unit test for method visit_ExceptHandler of class VariablesReplacer

# Generated at 2022-06-21 18:47:37.390324
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.ExceptHandler()
    tree.name = ast.Name()
    tree.name.id = "foo"
    replacer = VariablesReplacer({
        "foo": ast.Name()
    })
    replacer.visit(tree)
    assert tree.name.id == "foo"

# Generated at 2022-06-21 18:47:41.845114
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    node = ast.ExceptHandler()
    node.name = "name"
    new_node = VariablesReplacer.replace(node, {"name": "new_name"})
    assert new_node.name == "new_name"

# Generated at 2022-06-21 18:47:52.222717
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("test.test_function()")
    variables = {"test": "var"}
    VariablesReplacer.replace(tree, variables)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Attribute)
    assert isinstance(tree.body[0].value.func.value, ast.Name)
    assert isinstance(tree.body[0].value.func.value.id, str)
    assert tree.body[0].value.func.value.id == "var"

# Generated at 2022-06-21 18:48:04.591828
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    a_ast = ast.Name(id="a")
    b_ast = ast.Name(id="b")
    c_ast = ast.Name(id="c")
    d_ast = ast.Name(id="d")
    e_ast = ast.Name(id="e")
    f_ast = ast.Name(id="f")

# Generated at 2022-06-21 18:48:12.547189
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class TestAttributes(ast.Attribute):
        def __init__(self, *args, **kwargs):
            ast.Attribute.__init__(self, *args, **kwargs)

    node = TestAttributes(value=ast.Name(id='test', ctx=ast.Store()), attr='test', ctx=ast.Store())
    replacer = VariablesReplacer({'test': 'test'})
    replacer.visit_Attribute(node)
    assert node.value.id == 'test'
    assert node.attr == 'test'
    assert node.ctx == ast.Store()



# Generated at 2022-06-21 18:48:20.447786
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # 1. Let t = ClassDef(name='y', body=[Assign(target=Name(id='x', ctx=Store()),
    #    value=Num(n=1))])
    # 2. t = VariablesReplacer.replace(t, {'y': 'n', 'x': 'q'})
    # 3. Assert that t equals ClassDef(name='n', body=[Assign(target=Name(id='q',
    #    ctx=Store()), value=Num(n=1))])
    t = ast.ClassDef(name='y', body=[ast.Assign(target=ast.Name(id='x', ctx=ast.Store()),
                                               value=ast.Num(n=1))])

# Generated at 2022-06-21 18:48:28.274792
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    root = ast.parse("""
import test_package.test_module
from test_package.test_module2 import test_class
test_package.test_module.test_method(test_class(test_var1, test_var2))
""")
    variables = {
        'test_package': 'test_package_1',
        'test_module': 'test_module_1',
        'test_module2': 'test_module2_1',
        'test_class': 'test_class_1',
        'test_var1': 'test_var1_1',
        'test_var2': 'test_var2_1',
        'test_method': 'test_method_1',
    }

# Generated at 2022-06-21 18:48:33.127282
# Unit test for function extend
def test_extend():
    snippet_kwargs = {
        "vars": ast.copy_location(ast.parse("x = 1").body[0], None),  # type: ignore
        "vars1": ast.copy_location(ast.parse("y = 2").body[0], None)  # type: ignore
    }

# Generated at 2022-06-21 18:48:53.228216
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("x=1").body[0]
    assert tree.targets[0].id == 'x'
    vars = {'x': 'newx'}
    VariablesReplacer.replace(tree, vars)
    assert tree.targets[0].id == 'newx'


# Generated at 2022-06-21 18:48:59.839739
# Unit test for function find_variables
def test_find_variables():
    class Foo:
        pass

    let(Foo)
    let(1)

    assert list(find_variables(ast.parse('''let(Foo)'''))) == ['Foo']
    assert list(find_variables(
        ast.parse('let(x); let(y); let(z); x + y + z'))) == ['x', 'y', 'z']



# Generated at 2022-06-21 18:49:08.391327
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    v1 = ast.Name(id='_py_backwards_a_0')
    vr = VariablesReplacer({'a': v1})
    f1 = ast.FunctionDef(name='a', body=[])
    b1 = ast.Expr(value=ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Str(s='Hello')],
        keywords=[]
    ))

    vr.visit(f1)

    assert f1.name == v1.id
    assert f1.body == []

    f2 = ast.FunctionDef(name='a', body=[b1])

# Generated at 2022-06-21 18:49:09.320458
# Unit test for constructor of class snippet
def test_snippet():
    assert isinstance(snippet(lambda: None), snippet)



# Generated at 2022-06-21 18:49:20.335502
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    var_dict = {'name': VariablesGenerator.generate('name')}
    except_handler = ast.ExceptHandler(name='name')
    replaced_except_handler = VariablesReplacer.replace(except_handler, var_dict)
    assert replaced_except_handler.name == '_py_backwards_name_0'

    var_dict = {'name': VariablesGenerator.generate('name')}
    except_handler = ast.ExceptHandler(name='name', body=[])
    replaced_except_handler = VariablesReplacer.replace(except_handler, var_dict)
    assert replaced_except_handler.name == '_py_backwards_name_0'
    assert replaced_except_handler.body == []

    var_dict = {'name': VariablesGenerator.generate('name')}
   

# Generated at 2022-06-21 18:49:26.231623
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    s = ast.parse(
'''foo(yield_if=True, yield_if_0=None)''').body[0]
    variables = {
        'yield_if': [ast.parse(
            '''yield_if_0''').body[0]]
    }
    VariablesReplacer.replace(s, variables)
    assert get_source(s) == 'foo(yield_if_0=None)'



# Generated at 2022-06-21 18:49:28.909598
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('def fn():pass')
    VariablesReplacer.replace(tree, {'fn': 'new_fn'})
    assert get_source(tree) == 'def new_fn():pass'



# Generated at 2022-06-21 18:49:38.632433
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('''
    def a(x):
        return x
    
    print(a(3))
    ''')
    variables = {'x': '456', 'a': 'b'}

    inst = VariablesReplacer(variables)
    inst.visit(tree)

    fn = tree.body[0]
    print(fn, fn.args.args[0])
    assert fn.name == 'b'
    assert fn.args.args[0].arg == 'x'
    assert isinstance(fn.args.args[0], ast.arg)

    call = tree.body[1].value
    assert call.func.id == 'b'
    assert call.args[0].n == 3



# Generated at 2022-06-21 18:49:42.658128
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    node = ast.ClassDef(
        'idlelib.run_a_program.ProgramInspectDialog',
        bases=[ast.Name('object', ast.Load())]
    )
    variables = {'object': ast.Name('list', ast.Load())}
    VariablesReplacer(variables).visit(node)

    assert node.name == 'list'


# Generated at 2022-06-21 18:49:43.917366
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-21 18:50:04.391057
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    test_node = ast.parse('x.y').body[0] # type: ignore
    replaced_node = VariablesReplacer.replace(test_node, {'x': 'q'})

    assert isinstance(replaced_node, ast.Attribute) # type: ignore
    assert replaced_node.value.id == 'q'



# Generated at 2022-06-21 18:50:05.717251
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda _x: None)._fn(1) == None

# Generated at 2022-06-21 18:50:12.260166
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    a1 = ast.alias("test_alias", None)
    a1.name = "test_module"
    a2 = ast.alias("test_alias", None)
    a2.name = "test_module.function"
    a3 = ast.alias("test_alias", None)
    a3.name = "test_module_alias"
    a3.asname = "test_alias"
    a4 = ast.alias("test_alias", None)
    a4.name = "test_module.function_alias"
    a4.asname = "test_alias"
    a5 = ast.alias("test_alias", None)
    a5.name = "test_module_alias.function"
    a5.asname = "test_alias"


# Generated at 2022-06-21 18:50:18.568807
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # TODO: Add more tests
    # TODO: Test this with kwargs
    def snippet_body(x: int = 3) -> List[ast.AST]:
        let(x)
        x += 1
        y = 1
        return [x, y]

    class_snippet = snippet(snippet_body)
    assert class_snippet.get_body(x=1) == snippet_body(x=1)

# Generated at 2022-06-21 18:50:28.540941
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class NodeTransformer(ast.NodeTransformer):
        def visit_ExceptHandler(self, node: ast.ExceptHandler) -> ast.ExceptHandler:
            node = VariablesReplacer._replace_field_or_node(self, node, 'name')
            return self.generic_visit(node)  # type: ignore

    source = """try:
        pass
    except Exception as e:
        print(e)"""
    tree = ast.parse(source)
    variables = find_variables(tree)
    node_transformer = NodeTransformer()
    node_transformer.visit(tree)
    extend_tree(tree, variables)
    assert len(variables) == 0

# Generated at 2022-06-21 18:50:32.798592
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    def snippet():
        try:
            pass
        except Exception:
            pass

    var = VariablesGenerator.generate("Exception")
    snip = snippet()
    tree = snip.get_body()
    node = tree[0]
    inst = VariablesReplacer({'Exception': var})
    new_node = inst.visit_ExceptHandler(node)
    assert new_node.name == var

# Generated at 2022-06-21 18:50:42.366118
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    body = ast.parse('list(x for x in x)').body[0].value.args[0]
    assert body == ast.parse('list(x for x in x)').body[0].value.args[0]

    class A2(ast.NodeTransformer):
        def visit_arg(self, node: ast.arg) -> ast.arg:
            return ast.Name(id='y', ctx=ast.Store())

    class A(ast.NodeTransformer):
        def visit_arg(self, node: ast.arg) -> ast.arg:
            return A2().visit(node)

    assert A().visit(body) == ast.parse('list(y for y in y)').body[0].value.args[0]

    def f(x):
        x = f'x{x}'



# Generated at 2022-06-21 18:50:48.611474
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    module_name = 'test'
    tree = ast.parse("from module import *")
    tree.body[0].module = module_name
    tree.body[0].names = ["*"]
    variables_mapping = {module_name : module_name}
    visitor = VariablesReplacer(variables_mapping)
    result = visitor.visit(tree)
    assert result.body[0].module == module_name
    # It should be the same as the one above, otherwise a new object will be returned.



# Generated at 2022-06-21 18:50:52.147648
# Unit test for constructor of class snippet
def test_snippet():
    def foo():
        let(x)
        let(y)
        z = x + y

    code = """
    x = 1
    y = 2
    z = x + y
    """
    body = snippet(foo).get_body()
    assert get_source(body) == code


# Generated at 2022-06-21 18:51:02.661990
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class TestClass(ast.NodeTransformer):
        def __init__(self, variables: Dict[str, Variable]) -> None:
            self._variables = variables
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            for i in range(len(node.body)):
                child = node.body[i]
                node.body[i] = self.visit(child)  # type: ignore

            node = VariablesReplacer._replace_field_or_node(self, node, 'name')
            return node

    a = ast.parse("def func(): pass")
    b = TestClass({'func': 'test'}).visit(a)
    assert b.body[0].name == 'test'