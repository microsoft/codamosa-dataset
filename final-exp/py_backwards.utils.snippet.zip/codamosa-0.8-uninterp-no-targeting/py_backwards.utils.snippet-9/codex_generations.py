

# Generated at 2022-06-21 18:41:42.303822
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    # pylint: disable=unused-argument
    def foo(x):
        try:
            x += 1
        except:
            let(except_name)  # noqa
            pass

    from . import generate  # pylint: disable=import-outside-toplevel
    tree = generate(foo)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.FunctionDef)
    func_def = tree.body[0]
    assert isinstance(tree.body[1], ast.Expr)
    assert isinstance(tree.body[1].value, ast.Call)
    assert len(func_def.body) == 2
    assert isinstance(func_def.body[0], ast.Try)
    assert isinstance

# Generated at 2022-06-21 18:41:50.370595
# Unit test for function extend
def test_extend():
    test_code = """
    extend(var)
    a = 1
    a = 2
    """ + "\n"
    var = ast.parse("a = 1\na = 2").body
    tree = ast.parse(test_code)
    extend_tree(tree, {"var": var})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    a = 1
    a = 2
    a = 1
    a = 2
    """ + "\n"))



# Generated at 2022-06-21 18:41:55.042927
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('def somefunc():\n    print("Hello World")')
    assert tree.body[0].name == 'somefunc'
    variables = {'somefunc': 'somefunc_new'}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].name == 'somefunc_new'



# Generated at 2022-06-21 18:41:58.837318
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from datetime import datetime as dt")
    variables = {'datetime': 'some_datetime'}
    VariablesReplacer.replace(tree, variables)
    assert "from some_datetime import datetime as dt" == ast.dump(tree)



# Generated at 2022-06-21 18:42:03.051946
# Unit test for constructor of class snippet
def test_snippet():
    class Foo:
        @snippet
        def f():
            let(x)
            if x:
                pass
            x = 1
            return x

        @snippet
        def g():
            let(x)
            return x

        @snippet
        def h(x):
            return x

# Generated at 2022-06-21 18:42:08.013270
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    ast_node = ast.alias()
    ast_node.name = "module_name.module2"
    ast_node.asname = "module_as_name"
    variables = {
            "module_name": "other_module_name"
            }
    VariablesReplacer.replace(ast_node, variables)
    assert ast_node.name == "other_module_name.module2"
    assert ast_node.asname == "module_as_name"

# Generated at 2022-06-21 18:42:15.140627
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # Given
    source = '''from sys import path as sys_path'''
    tree = ast.parse(source)
    variables = {'path': 'new_path'}

    # When
    VariablesReplacer.replace(tree, variables)
    source_changed = ast.unparse(tree)

    # Then
    assert source_changed == 'from sys import new_path as sys_path\n'



# Generated at 2022-06-21 18:42:23.313987
# Unit test for function extend
def test_extend():
    def extend_test():
        r = 1
        s = 1
        extend(vars)
        r += 1
        return r

    vars = [ast.Assign(targets=[ast.Name(id='r', ctx=ast.Store())],
                       value=ast.Num(1)),
            ast.Assign(targets=[ast.Name(id='s', ctx=ast.Store())],
                       value=ast.Num(1))]

    tree = snippet(extend_test).get_body(vars=vars)
    exec(compile(ast.Module(body=tree), '<ast>', 'exec'), {})
    assert (r == 2) and (s == 1)


# Generated at 2022-06-21 18:42:30.212558
# Unit test for function extend
def test_extend():
    @snippet
    def foo():
        extend({'x': 2})
        let(x)
        x += 2
        print(x)

    body = foo.get_body()
    module = ast.Module(body=body)

    locals_ = {
        '__builtins__': __builtins__,
        'print': print

    }
    exec(compile(module, '<string>', 'exec'), locals_)

    assert locals_['x'] == 4

# Generated at 2022-06-21 18:42:37.908273
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import unittest


    class TestVariablesReplacer(unittest.TestCase):
        def setUp(self) -> None:
            self.variables = {'ast': 'node'}
            self.keyword = ast.keyword(arg="ast", value=3)

        def test_replace(self):
            node = VariablesReplacer.replace(self.keyword, self.variables)
            self.assertEqual(ast.keyword(arg="node", value=3), node)

    unittest.main()

# Generated at 2022-06-21 18:42:48.433104
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    t = ast.parse("for _py_backwards_x_0 in range(5):\n"
                  "    print(_py_backwards_x_0)")
    assert t.body[0].target.id == "_py_backwards_x_0"

# Generated at 2022-06-21 18:42:59.005009
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = """
        import a
        import b
        import c
        import a.b
        import a.b.c
        from a import b
        from a import b as c
        from a import b, c
        from a.b import c
        from a.b.c.d import e as f
        from a import *
    """
    tree = ast.parse(source)
    variables = {'a': 'top'}
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-21 18:43:05.213533
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    variables = {'x': 'a', 'y': 'b'}
    attribute = ast.parse('x').body[0]
    attribute = ast.copy_location(attribute, attribute)
    expected = ast.parse('a').body[0]
    expected = ast.copy_location(expected, expected)
    actual = VariablesReplacer.replace(attribute, variables)
    assert actual == expected
    assert actual.__class__ == expected.__class__



# Generated at 2022-06-21 18:43:09.033332
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Test(ast.NodeVisitor):
        def visit_Attribute(self, node):
            VariablesReplacer.replace(node, dict())
    Test().visit(ast.parse('x.y').body[0].value)

# Generated at 2022-06-21 18:43:10.374448
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-21 18:43:15.544424
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('x.y')
    variables = {'x': 'unique_name'}
    node = VariablesReplacer.replace(tree, variables)
    assert ast.dump(node) == "Attribute(value=Name(id='unique_name', ctx=Load()), attr='y', ctx=Load())"


# Generated at 2022-06-21 18:43:24.909227
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    """
    >>> tree = ast.parse("self.get(kwargs['name'])")
    >>> tree = VariablesReplacer.replace(tree, {'kwargs': '_kwargs'})
    >>> ast.dump(tree)
    "Expr(value=Call(func=Attribute(value=Name(id='self', ctx=Load()), attr='get', ctx=Load()), args=[Subscript(value=Name(id='_kwargs', ctx=Load()), slice=Index(value=Str(s='name')), ctx=Load())], keywords=[], starargs=None, kwargs=None))"
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 18:43:28.968554
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('x = 1')

    replacer = VariablesReplacer({'x':
        ast.parse('x = 2').body[0]})
    replacer.visit(tree)

    assert get_source(tree) == 'x = 2'


# Generated at 2022-06-21 18:43:30.654485
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def fn(*args, **kwargs):
        _ = args
        _ = kwargs

# Generated at 2022-06-21 18:43:35.604513
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class A:
        def __init__(self):
            self.x = 1
    class B:
        def __init__(self):
            self.x = 1

    try:
        raise A()
    except A as c:
        c = B()
        assert c.x == 1

# Generated at 2022-06-21 18:43:48.721241
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\nlet(y)\nlet(z)\nx + y - z')
    names = find_variables(tree)
    assert list(names) == ['x', 'y', 'z']



# Generated at 2022-06-21 18:43:57.215312
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = 'try: x\nexcept Exception as e: pass'
    tree = ast.parse(source)

    variables = find_variables(tree)
    extend_tree(tree, {'e': ['a', 'x.y']})
    result = VariablesReplacer.replace(tree, variables)
    assert ast.dump(result) == 'Module(body=[Try(body=[Name(id=_py_backwards_x_0, ctx=Load())], handlers=[ExceptHandler(type=Name(id=Exception, ctx=Load()), name=Name(id=_py_backwards_x_0_0, ctx=Store()), body=[Pass()])], orelse=[], finalbody=[])])'


# Generated at 2022-06-21 18:43:58.655268
# Unit test for function find_variables

# Generated at 2022-06-21 18:44:06.880113
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('''
file = open('file.txt', 'w')
data = file.read()
file.write(data)
''')
    variables = {'file': 'f'}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert get_source(tree) == '''\
f = open('file.txt', 'w')
data = f.read()
f.write(data)
'''

# Generated at 2022-06-21 18:44:14.610280
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("f(x=(a, b), y=c)")
    variables = {'a': ast.parse("x = 1").body[0],
                 'b': ast.parse("x = 2").body[0],
                 'c': ast.parse("y = 3").body[0]}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, {})

    assert get_source(tree) == "f(x=(x = 1, x = 2), y=(y = 3,))"

# Generated at 2022-06-21 18:44:23.685060
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    """Test for method visit_Attribute of class VariablesReplacer
    """
    # given
    class_def = ast.ClassDef(
        name='A',
        bases=[],
        keywords=[],
        body=[],
        decorator_list=[]
    )
    call = ast.Call(
        func=class_def,
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None
    )
    function_def = ast.FunctionDef(
        name='f',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[],
        decorator_list=[],
        returns=None
    )

# Generated at 2022-06-21 18:44:33.531255
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
        # source = """
        #     let(x)
        #     let(y)
        #     a = x + 1
        # """
        # tree = ast.parse(source)
        # variables = {'x': '_py_backwards_x_0', 'y': ast.parse('2').body[0]}
        # VariablesReplacer.replace(tree, variables)
        # assert ast.dump(tree) == '''
        #     Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=BinOp(left=_py_backwards_x_0, op=Add(), right=Num(n=1)))])

        # '''
        pass

# Generated at 2022-06-21 18:44:39.012700
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = snippet(lambda y: let(y))
    assert x.get_body() == [ast.parse('let(y)').body[0]]
    assert x.get_body(y=2) == [ast.parse('let(y)').body[0]]

    x = snippet(lambda a, b: let(a) + let(b))
    assert x.get_body() == [ast.parse('let(a) + let(b)').body[0]]
    assert x.get_body(a=2, b=3) == [ast.parse('let(a) + let(b)').body[0]]

    x = snippet(lambda a, b: sn.let(a) + sn.let(b))

# Generated at 2022-06-21 18:44:40.086195
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda x: None)

# Generated at 2022-06-21 18:44:45.409691
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def let(var):
        pass

    def function(x):
        let(x)

    source = get_source(function)
    tree = ast.parse(source)
    variables = find_variables(tree)
    VariablesReplacer.replace(tree, variables)
    body = tree.body[0].body[0]
    assert isinstance(body, ast.Pass)

# Generated at 2022-06-21 18:45:02.454483
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    import unittest
    import ast


# Generated at 2022-06-21 18:45:10.046301
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(a)\nx = 1')
    extend_tree(tree, {'a': [ast.Assign(targets=[ast.Name(id='x')])]})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Constant(value=1),\n                                             ctx=Store())])'



# Generated at 2022-06-21 18:45:21.271050
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('\n'.join([
        'import requests',
        'from requests import *',
        '',
        'res = requests.get(url, timeout=10, params={"a": 1, "b": 2})',
        '',
        'for arg in res.options:',
        '    print(arg)',
    ]))

    replacer = VariablesReplacer({'url': 'http://test.com/'})
    replacer.visit(tree)
    result = ast.unparse(tree)

# Generated at 2022-06-21 18:45:29.785171
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    """Unit test for constructor of class VariablesReplacer."""
    source = '''
        class C:
            D = {
                'a': 'A',
                'b': 'B'
            }
    '''
    tree = ast.parse(source)
    variables = {
        'C': 'NewClass',
        'D': 'MyDict',
        'a': 'a_var',
        'b': 'b_var'
    }
    actual = VariablesReplacer.replace(tree, variables)
    source = """
        class NewClass:
            MyDict = {
                'a_var': 'A',
                'b_var': 'B'
            }
    """
    expected = ast.parse(source)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-21 18:45:40.681915
# Unit test for function extend
def test_extend():
    def test():
        vars = [
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))
        ]
        extend(vars)
        print(x)
        x += 1

    test = snippet(test)

    result = test.get_body()
    print(result)

# Generated at 2022-06-21 18:45:48.892366
# Unit test for function extend_tree
def test_extend_tree():
    a = ast.parse('a=1')
    b = ast.parse('b=2')
    x = ast.parse('x=1')
    y = ast.parse('y=2')

    assert extend_tree(ast.parse('''
let(nodes)
    extend(nodes)
    nodes
nodes = a, b
'''), {'nodes': [ast.parse('a=1'), ast.parse('b=2')]}) == \
        ast.parse('''
    a=1
    b=2
    a=1
    b=2
''')


# Generated at 2022-06-21 18:46:00.490750
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from py_backwards.transformations.variables import VariablesReplacer
    import ast
    import astor
    node = ast.ExceptHandler(body=[ast.AnnAssign(target=ast.Name(id='x'), annotation=None, value=None, simple=True)], name=ast.Name(id='name'))
    new_node = ast.ExceptHandler(body=[ast.AnnAssign(target=ast.Name(id='x'), annotation=None, value=None, simple=True)], name=ast.Name(id='name_1'))
    replacer = VariablesReplacer({'name': new_node})
    replacer.visit_ExceptHandler(node)
    print (astor.to_source(node))

# Generated at 2022-06-21 18:46:07.581529
# Unit test for function extend_tree
def test_extend_tree():
    ast_1 = ast.parse("x = 1; y = 2;")
    tree = ast.parse("""\
extend(vars)
x += 1
y += 2
    """)
    extend_tree(tree, {'vars': ast_1})

# Generated at 2022-06-21 18:46:11.561797
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    # Given
    node = ast.parse('def f():\n\tpass')
    visitor = VariablesReplacer({'f': '_py_backwards_f_0'})

    # When
    visitor.visit_FunctionDef(node.body[0])

    # Then

# Generated at 2022-06-21 18:46:13.104262
# Unit test for constructor of class snippet
def test_snippet():
    assert isinstance(snippet(lambda x: let(x)), snippet)



# Generated at 2022-06-21 18:46:29.034341
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(
        """\
extend(values)
a = 0
print(a)
        """
    )
    variables = {'values': [
        ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.Name(id='b', ctx=ast.Load())
        ),
        ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.Name(id='c', ctx=ast.Load())
        )
    ]}
    extend_tree(tree, variables)
    result = ast.dump(tree)


# Generated at 2022-06-21 18:46:41.278171
# Unit test for function let
def test_let():
    source = """
    def asd():
        let(x)
        let(y)
        a = x = y = 1
    """

    tree = ast.parse(source)
    variables = {name: VariablesGenerator.generate(name)
                 for name in find_variables(tree)}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-21 18:46:45.977852
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    for module, expected in (('package.module', 'p_0.m_0'),
        ('package.module.submodule', 'package.module.s_0')):
        node = ast.ImportFrom(module=module, names=[], level=0)
        variables = {'package': 'p_0', 'module': 'm_0', 'submodule': 's_0'}
        VariablesReplacer.replace(node, variables)
        assert node.module == expected

# Generated at 2022-06-21 18:46:57.850131
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    expected = '''try:
    a
except ValueError as b:
    d'''
    except_handler = ast.ExceptHandler(type=None, name=None, body=[])
    except_handler.type = ast.Name(id='ValueError', ctx=None)
    except_handler.name = ast.Name(id='b', ctx=ast.Store())
    except_handler.body = [ast.Expr(value=ast.Name(id='d', ctx=ast.Store()))]
    try_except = ast.Try(body=[ast.Expr(value=ast.Name(id='a', ctx=ast.Load()))],
                         handlers=[except_handler],
                         orelse=[], finalbody=None)
    res = VariablesReplacer({'b': 'c'})

# Generated at 2022-06-21 18:47:01.471370
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    assert VariablesReplacer.replace(ast.parse('x'), {'x': 'y'}).body[0].value.id == 'y'

# Generated at 2022-06-21 18:47:05.616557
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse(
        """
        let(x)
        x += 1
        y = 1
        """
    ).body[0]
    names = find_variables(tree)
    assert names == ['x', 'y']

# Generated at 2022-06-21 18:47:14.500765
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from py_backwards.core import VariablesReplacer

    # Example 1
    #
    # """
    # import x
    # import y as z
    # """
    variables = {'x': 'a', 'y': 'b'}
    source = """from x import ab; from y import cd as ef"""
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, variables)
    # Expect: """from a import ab; from b import cd as ef"""
    assert ast.dump(tree) == 'Module(body=[ImportFrom(module=\'a\', names=[alias(name=\'ab\', asname=None)], level=0), ImportFrom(module=\'b\', names=[alias(name=\'cd\', asname=\'ef\')], level=0)])'

    #

# Generated at 2022-06-21 18:47:15.859742
# Unit test for method visit_Attribute of class VariablesReplacer

# Generated at 2022-06-21 18:47:21.470737
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("x = 1", mode='eval')
    replacer = VariablesReplacer({'x': 'y'})
    replacer.visit(tree)
    assert ast.dump(tree) == "Expr(value=BinOp(left=Name(id='y', ctx=Store()), op=Add(), right=Num(n=1)))"



# Generated at 2022-06-21 18:47:27.675921
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    @snippet
    def test():
        let(x)  # noqa
        let(y)  # noqa

        def foo(arg):
            let(arg)

            def bar():
                let(arg)
                let(foo)


# Generated at 2022-06-21 18:47:51.885677
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import unittest
    from .helpers import VariablesGenerator, get_source
    class VariableReplacerTestCase(unittest.TestCase):
        def test_visit_alias_rename_one_level_module(self):                
            class A:
                def b(func):
                    def wrapper(self, event):                                                                                
                        return func(self, event)                
                    return wrapper           
                    
                @b
                def x(self):                                                
                    import module1
                    let(module1)
                    
            tree = ast.parse(get_source(A.x))
            variables = {'module1': VariablesGenerator.generate('module1')}
            VariablesReplacer.replace(tree, variables)
            for node in find(tree, ast.ImportFrom):
                self.assertE

# Generated at 2022-06-21 18:48:03.146374
# Unit test for function let
def test_let():
    from .snippet import let, snippet
    from .tree import find
    
    counter = 0
    def check_let(source):
        nonlocal counter
        tree = ast.parse(source)
        assert [node.id for node in find(tree, ast.Name)] == ['_py_backwards_x_0']
        counter += 1

    @snippet
    def func():
        let(x)
        check_let('''
x += 1
        ''')

    assert counter == 1

    @snippet
    def func():
        let(x)
        check_let('''
_py_backwards_x_0 += 1
        ''')

    assert counter == 2
    
    

# Generated at 2022-06-21 18:48:07.472073
# Unit test for function let
def test_let():
    cat = snippet(lambda x, y: let(x + y))
    body = cat.get_body()
    assert len(body) == 1
    assert body[0].body[0].right.left.id == '_py_backwards_x_0'  # type: ignore

# Generated at 2022-06-21 18:48:16.835312
# Unit test for function let
def test_let():
    assert ast.dump(snippet(
        lambda: let(x)
    ).get_body()) == '[]'

    assert ast.dump(snippet(
        lambda: let(x)
        for i in range(2)
    ).get_body()) == '[For(target=Name(id=_py_backwards_i_0, ctx=Store()), iter=Call(func=Name(id=range, ctx=Load()), args=[Num(n=2)], keywords=[]), body=[], orelse=[])]'


# Generated at 2022-06-21 18:48:27.291127
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    def test_func():
        let(x)
        let(x)
        y = let(x)
        extend(vars)
        
    body = snippet(test_func).get_body()

# Generated at 2022-06-21 18:48:36.868551
# Unit test for function let
def test_let():
    @snippet
    def let_test_snippet(x: int) -> None:
        let(x)
        x += 1

    assert let_test_snippet.get_body(x=1) == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        )
    ]



# Generated at 2022-06-21 18:48:43.220101
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    # tree = ast.parse('x = 1 + 3')
    # parent, index = get_non_exp_parent_and_index(tree, find(tree, ast.BinOp)[1])
    # replace_at(index, parent, '5')
    # print(ast.dump(tree))
    tree = ast.parse('x = 1 + 3')
    variables = {'x': ast.Num(1)}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=1))])'

# Generated at 2022-06-21 18:48:50.965081
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Test:
        def __init__(self):
            self.ast = ast.parse('''
                class A:
                    pass
            ''')
            self.var = 'B'
            self.cd = self.ast.body[0]
            self.replacer = VariablesReplacer({'A': self.var})
    
    test = Test()
    actual = test.replacer.visit_ClassDef(test.cd)
    assert actual.name == test.var, 'It should set new name for class'


# Generated at 2022-06-21 18:48:55.553151
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import ast
    from .helpers import generate_random_variables_with_names, generate_random_ast_node
    from . import _tree_analyzer_VariablesReplacer as VariablesReplacer

    _num_of_iterations = 1000

    for _ in range(_num_of_iterations):
        node = ast.keyword(arg=generate_random_variables_with_names(), value=generate_random_ast_node())
        VariablesReplacer.visit_keyword(node)

# Generated at 2022-06-21 18:48:59.888680
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    name = ast.Name()
    name.id = 'str'
    replacer = VariablesReplacer({'str': 'str1'})
    changed_name = replacer.visit(name)
    assert changed_name.id == 'str1'

# Generated at 2022-06-21 18:49:34.100224
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x = 1
    let(y)
    y = x
    extend(vars)
    x = 3
    y = x
    z = 5
    """
    tree = ast.parse(source)
    assert sorted(find_variables(tree)) == ['vars', 'x', 'y']



# Generated at 2022-06-21 18:49:37.206490
# Unit test for function find_variables
def test_find_variables():
    from .examples import find_variables as vars
    tree = ast.parse(get_source(vars))
    assert find_variables(tree) == {'x', 'y', 'z'}



# Generated at 2022-06-21 18:49:37.946340
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    assert True

# Generated at 2022-06-21 18:49:48.082515
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert ast.parse('a').body[0] == VariablesReplacer.replace(ast.parse('x') , {'x':'a'}).body[0]
    assert list(find(VariablesReplacer.replace(ast.parse('a[x]'), {'x':'y'}), ast.Subscript))[0].slice.value.id == 'y'
    assert list(find(VariablesReplacer.replace(ast.parse('a.x'), {'x':'y'}), ast.Attribute))[0].attr == 'y'
    assert list(find(VariablesReplacer.replace(ast.parse('def x():\n return x'), {'x':'y'}), ast.FunctionDef))[0].name == 'y'

# Generated at 2022-06-21 18:49:59.317935
# Unit test for function extend
def test_extend():
    from .tree import get_source, find
    from .snippets import extend
    from .demo_snippets import print_vars, print_vars2

    @snippet
    def fn():
        x = 5
        extend(print_vars())
        print(x)

    expected_source = """x = 1
x = 2
print(x)"""

    source = get_source(fn)
    assert source == expected_source

    @snippet
    def fn():
        x = 5
        extend(print_vars())
        extend(print_vars2())
        print(x)

    source = get_source(fn)
    assert source == expected_source

    @snippet
    def fn():
        x = 5
        y = 10
        extend(print_vars())


# Generated at 2022-06-21 18:50:07.156336
# Unit test for function extend_tree
def test_extend_tree():
    source = """
extend(vars)
x = 1
y = 2
print(x, y)
"""
    tree = ast.parse(source)
    extend_tree(tree, {
        'vars': [
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=1)),
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=2)),
        ]
    })
    assert ast.dump(tree) == """
<_ast.Module object at 0x10ca0d198>
"""

# Generated at 2022-06-21 18:50:18.713209
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    from .backwards import backwards
    from .helpers import block

    tree = ast.parse('''
        with open('tmp', 'w') as _py_backwards_file_0:
            _py_backwards_file_0.write('hello')
        ''')

    backwards_snippet = snippet(backwards)
    body = backwards_snippet.get_body(file=ast.Name('_file'))
    tree.body.extend(body)

    with open('tmp') as f:
        assert f.read() == 'hello'

    # Check that module name 'backwards' was replaced
    assert all(node.module == '_py_backwards' for node in find(tree, ast.ImportFrom))

    # Check that function name 'block' was replaced

# Generated at 2022-06-21 18:50:24.765162
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    suite = ast.parse("from datetime import date, time").body
    from_datetime = suite[0]
    variables = {
        'datetime': VariablesGenerator.generate('date'),
    }
    node = from_datetime.names[0]
    assert node.name == 'datetime'
    VariablesReplacer.replace(suite, variables)
    assert node.name == 'date'

# Generated at 2022-06-21 18:50:25.689393
# Unit test for constructor of class snippet

# Generated at 2022-06-21 18:50:29.035989
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse("""
    def test_func(x):
        pass
    """)
    variables = {'x': ast.Name('y')}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].args.args[0].arg == 'y'