

# Generated at 2022-06-21 18:41:42.899843
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("""
import ipywidgets as widgets

widget = widgets.Button(
    description='Advanced function',
    disabled=True,
    button_style='danger',  # 'success', 'info', 'warning', 'danger' or ''
    tooltip='Description',
    icon='check'
)
""")
    variables = {
        'widgets': 'widgets',
        'Button': 'Button',
        'description': 'description',
        'disabled': 'disabled',
        'button_style': 'button_style',  # 'success', 'info', 'warning', 'danger' or ''
        'tooltip': 'tooltip',
        'icon': 'icon'
    }
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-21 18:41:43.533450
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-21 18:41:53.292677
# Unit test for function let
def test_let():
    @snippet
    def fn():
        let(x)
        x = 1
        x += 2

    assert fn.get_body() == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.AugAssign(target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()),
                      op=ast.Add(), value=ast.Num(n=2))
    ]



# Generated at 2022-06-21 18:42:01.466595
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class Visitor(ast.NodeTransformer):
        def visit_keyword(self, node: ast.keyword) -> ast.keyword:
            node = self._replace_field_or_node(node, 'arg')
            return self.generic_visit(node)  # type: ignore

        def _replace_field_or_node(self, node: Any, field: str) -> Any:
            value = getattr(node, field, None)
            if value in self._variables:
                if isinstance(self._variables[value], str):
                    setattr(node, field, self._variables[value])

            return node

    visitor = Visitor({'x': 'y', 'z': 'y'})

# Generated at 2022-06-21 18:42:05.797461
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_function(x: Any, y: Any) -> None:
        let(x)
        y = 1
        extend(y)

    assert snippet_function.get_body() == snippet_function.get_body()
    assert not snippet_function.get_body() == snippet_function.get_body(x = 1, y = 2)

# Generated at 2022-06-21 18:42:11.851405
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class DummyVariablesReplacer(VariablesReplacer):
        def __init__(self) -> None:
            self._variables = {'arg': 'new_name'}

        def visit_arg(self, node: ast.arg) -> ast.arg:
            return self._replace_field_or_node(node, 'arg')

    tree = ast.parse("def test(arg):\n pass\n")
    class_name = tree.body[0].name
    assert class_name == 'test'

    tree = DummyVariablesReplacer.replace(tree, {'arg': 'new_name'})
    class_name = tree.body[0].name
    assert class_name == 'new_name'

# Generated at 2022-06-21 18:42:18.292679
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    # Should replace keyword arg
    node = ast.Call(func=ast.Name(id='foo', ctx=ast.Load()),
                    args=[],
                    keywords=[ast.keyword(arg='a',
                                          value=ast.Name(id='a', ctx=ast.Load()))])
    variables = {'a': 'b'}
    VariablesReplacer(variables).visit(node)
    assert node.keywords[0].arg == 'b'

    # Should replace keyword arg in nested call

# Generated at 2022-06-21 18:42:18.928687
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-21 18:42:26.838331
# Unit test for function extend
def test_extend():
    from .helpers import test_compile

    vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2))]
    expected = "x = 1\nx = 2\nprint(x)\n"
    assert test_compile(expected) == test_compile(expected, vars)



# Generated at 2022-06-21 18:42:31.215162
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from module import name as asname")
    variables = {'module.name': 'module_name'}
    VariablesReplacer.replace(tree, variables)
    result = ast.dump(tree)
    expected = ast.dump(ast.parse("from module import module_name as asname"))
    assert result == expected

# Generated at 2022-06-21 18:42:54.836369
# Unit test for function extend
def test_extend():
    snippet_text = '''
for _ in range(10):
    let(n)
    extend(vars)
    n += 1
    print(n)
'''
    snippet_vars = {
        'vars': [
            ast.Name(id='n', ctx=ast.Store()),
            ast.Num(1)
        ]
    }
    tree = ast.parse(snippet_text)
    vars = find_variables(tree)
    variables = {key: [VariablesGenerator.generate(key + '_0')] for key in vars}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    result_text = ast.unparse(tree)


# Generated at 2022-06-21 18:43:03.215943
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import copy
    import ast
    tree = ast.parse('x.y')
    variables = {'x': '_x'}
    tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'x.y'
    tree = ast.parse('x.y')
    variables = {'x.y': '_x.y'}
    tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == '_x.y'
    tree = ast.parse('x.y')
    variables = {'y': '_y', 'x.y': '_x.y'}
    tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == '_x.y'

# Generated at 2022-06-21 18:43:07.781168
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    obj = VariablesReplacer({'foo': 'bar'})
    source = 'class foo: pass'
    tree = ast.parse(source)
    obj.visit(tree)
    assert ast.dump(tree) == 'Module(body=[ClassDef(name=\'bar\', bases=[], body=[])])\n'

# Generated at 2022-06-21 18:43:19.695222
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class A:
        pass
    class B:
        pass

    out = VariablesReplacer.replace(A(), {A: B()})
    assert isinstance(out, B)

    out = VariablesReplacer.replace(A(), {})
    assert isinstance(out, A)

    def f():
        pass

    tree = ast.parse(get_source(f))
    out = VariablesReplacer.replace(tree, {'f': 'replace'})
    assert isinstance(out, ast.AST)
    assert out.body[0].name == 'replace'
    assert out.body[0].args.args[0].id == 'replace'

    tree = ast.parse(get_source(f))
    out = VariablesReplacer.replace(tree, {'f': ['preserve', 'remove']})
   

# Generated at 2022-06-21 18:43:29.574015
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("""call(a=b, c=d)""")
    variables = {'b': '1', 'd': '2'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Expr(value=Call(func=Name(id='call', ctx=Load()), args=[], keywords=[arg(arg='a', value=Name(id='1', ctx=Load())), arg(arg='c', value=Name(id='2', ctx=Load()))], starargs=None, kwargs=None))"

# Generated at 2022-06-21 18:43:38.501380
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def function_with_name(x):
        return x + 1
    func_def_node = ast.parse(get_source(function_with_name)).body[0]
    assert func_def_node.name == 'function_with_name'
    replacer = VariablesReplacer({'x': '__test_x'})
    new_func_def_node = replacer.visit(func_def_node)
    assert new_func_def_node.name == 'function_with_name'
    assert new_func_def_node == func_def_node


# Generated at 2022-06-21 18:43:40.652420
# Unit test for function extend
def test_extend():
    x = 10
    y = [1, 2, 3]
    extend(y)
    extend(x)
    print(x, y)

# Generated at 2022-06-21 18:43:43.509948
# Unit test for constructor of class snippet
def test_snippet():
    import inspect
    import pytest

    with pytest.raises(TypeError):
        snippet()

    foo = snippet(snippet)

    assert inspect.isclass(foo)



# Generated at 2022-06-21 18:43:47.810223
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    node = ast.ExceptHandler(ast.Name("Exception", ast.Load()), "e", [], None)
    variables = {}

    inst = VariablesReplacer(variables)
    inst.visit(node)

    assert node.name == "e"

# Generated at 2022-06-21 18:43:51.259447
# Unit test for function let
def test_let():
    tree: ast.AST

    @snippet
    def foo(x):
        let(y)
        x += 1
        y += 1

    tree = ast.parse('x += 1; y += 1;')  # type: ignore
    assert foo.get_body() == tree.body



# Generated at 2022-06-21 18:44:01.556624
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    import unittest
    import ast
    import astunparse

    class VariablesReplacerTestCase(unittest.TestCase):
        def test_VariableReplacer_returns_unique_variable_name(self):
            a = ast.parse("""
            def func1(x):
                a = func2(x)
                return a
            """)
            VariableReplacer.replace(a)
            self.assertEqual(
                astunparse.unparse(a), """def func1(x):
    a = func2(x)
    return a
            """)


# Generated at 2022-06-21 18:44:08.090171
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():

    def test_snippet(a, b):
        let(a)
        let(b)
        pass

    tb = snippet(test_snippet).get_body(
        a=ast.Name(id='a', ctx=ast.Load()),
        b=ast.Name(id='b', ctx=ast.Load())
    )


# Generated at 2022-06-21 18:44:16.775084
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("print(x)")
    extend_tree(tree, {'x': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                       value=ast.Num(n=1))]})
    assert ast.dump(tree) == "Module([Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Print(dest=None, values=[Name(id='x', ctx=Load())], nl=True)])"


# Generated at 2022-06-21 18:44:22.035307
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse(
        'def f(a, b, c):\n'
        '    print(a, b, c)\n'
    )

    variables = {'a': 'A', 'b': 'B'}
    replace = VariablesReplacer.replace(tree, variables)

    assert get_source(replace.body[0]) == \
        'def f(A, B, c):\n' \
        '    print(A, B, c)\n'

# Generated at 2022-06-21 18:44:27.026334
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = get_source(lambda: let(x))
    tree = ast.parse(source)
    variables = {'x': 'y'}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].value.args[0].id == 'y'

# Generated at 2022-06-21 18:44:36.232306
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    """This tests method visit_Attribute of class VariablesReplacer.

    This test checks if the method returns the correct ast node. Visit_Attribute
    must not change the input ast node of the method if it does not have to be replaced.
    The input ast node is a type ast.Attribute with an value of type string in the field
    'attr'. This field contains an unused variable, which is not in the dictionary of
    VariablesReplacer. Therefore no changes must be made to the Ast node.

    """
    # Create the ast node that should not be changed
    ast_node_in = ast.Attribute(value=ast.Name(id="my_id_in", ctx=ast.Load()), attr="my_attr_in", ctx=ast.Load())
    # Create the dictionary for the VariablesReplacer

# Generated at 2022-06-21 18:44:44.550283
# Unit test for function let
def test_let():
    import astunparse
    source = """
    let(x)
    x += 1
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert variables == ['x']
    extend_tree(tree, {'x': ['x = 1', 'x = 2']})
    VariablesReplacer.replace(tree, {'x': '_py_backwards_x_0'})
    res = astunparse.unparse(tree)
    assert res == '_py_backwards_x_0 = 1\n_py_backwards_x_0 = 2\n'

# Generated at 2022-06-21 18:44:51.691611
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():   
    tree = ast.parse("""def a():pass""")
    VariablesReplacer({"a": "d"}).visit_FunctionDef(tree)
    assert ast.dump(tree) == """Module(body=[FunctionDef(name='d', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])"""
 

# Generated at 2022-06-21 18:44:55.756122
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import alias
    alias_obj = alias()
    alias_obj.name = "a.b"
    variables = {"a.b": "c"}
    transformer = VariablesReplacer(variables)
    result = transformer.visit_alias(alias_obj)
    assert str(result.name) == "c"


# Generated at 2022-06-21 18:45:03.336445
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .helpers import get_source
    from .snippets import test_ImportFrom
    source = get_source(test_ImportFrom)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name) for name in names}
    extend_tree(tree, variables)
    assert not isinstance(tree.body[1], ast.ImportFrom)
    tree = VariablesReplacer.replace(tree, variables)
    import_node = tree.body[0]  # type: ignore
    assert isinstance(import_node, ast.ImportFrom)
    assert import_node.module == 'math'
    assert import_node.names[0].name == 'cos'



# Generated at 2022-06-21 18:45:22.825343
# Unit test for function extend
def test_extend():
    def test_func():
        x = 1
        y = 2
        extend(vars)
        x = 3
        y = 4
        print(x, y)

    tree = ast.parse(get_source(test_func))
    vars_ = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars_})
    assert get_source(tree) == 'x = 1\nx = 2\nx = 3\ny = 4\nprint(x, y)\n'



# Generated at 2022-06-21 18:45:23.912818
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    instances = VariablesReplacer({})
    assert type(instances) == VariablesReplacer


# Generated at 2022-06-21 18:45:30.875468
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer.replace(ast.parse("x = 1").body[0], {"x": "z"}) == ast.parse("z = 1").body[0]
    assert VariablesReplacer.replace(ast.parse("x = 1").body[0], {"x": ast.BinOp(ast.Name("y", ast.Load()),
                                                                               ast.Add(), ast.Num(0))}) == \
           ast.BinOp(ast.Name("y", ast.Load()), ast.Add(), ast.Num(0))

# Generated at 2022-06-21 18:45:37.191616
# Unit test for constructor of class snippet
def test_snippet():
    from .snippet import snippet

    @snippet
    def test_snip(app):
        let(app)
        return app

    assert 'app' in test_snip.get_body(app=1)
    assert 'app' not in test_snip.get_body(app=2)
    assert 'app' not in test_snip.get_body(app=1)

# Generated at 2022-06-21 18:45:38.130276
# Unit test for method visit_Name of class VariablesReplacer

# Generated at 2022-06-21 18:45:41.534339
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    variables = {}
    source = get_source(let)
    tree = ast.parse(source)
    variables = {'x': 'x_0'}
    tree = VariablesReplacer.replace(tree, variables)
    assert tree is not None

# Generated at 2022-06-21 18:45:45.576497
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = "from x.y.z import a, b"
    tree = ast.parse(source)
    variables = {
        "x.y.z": "module.submodule"
    }
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == "from module.submodule import a, b"


# Generated at 2022-06-21 18:45:51.329489
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class Test:
        pass
    t = Test()
    t.a = "bac"
    t.b = "fui"
    t.c = "cde"
    t.d = "def"
    t.e = "efg"
    assert VariablesReplacer(t.__dict__)._variables == t.__dict__


# Generated at 2022-06-21 18:45:54.721695
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    variables = {
        'y': 'new_variable'
    }
    tree = ast.parse("from x import y")
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == "from x import new_variable"

# Generated at 2022-06-21 18:45:58.643916
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def f():
        pass
    tree = ast.parse(get_source(f))
    VariablesReplacer.replace(tree, {"f": "_var_0"})
    assert tree.body[0].name == "_var_0"

# Generated at 2022-06-21 18:46:27.432828
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class A():
        x = 1
    class B(A):
        pass
    class C(B):
        pass
    v = ast.Name(id='B', ctx=ast.Load())
    f = ast.Attribute(value=ast.Name(id='a', ctx=ast.Load()), attr='x', ctx=ast.Load())
    ast.fix_missing_locations(f)
    variables = {'B': v, 'a.x': f}
    new_node = VariablesReplacer.replace(v, variables)
    assert new_node.id == 'a.x'


# Generated at 2022-06-21 18:46:33.235734
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""
try:
    v = 1
except Exception as e:
    print('error')
    pass
""")
    variables = {
        'e': '_py_backwards_e_0'
    }
    VariablesReplacer.replace(tree, variables)


# Test for let keyword

# Generated at 2022-06-21 18:46:43.295034
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def foo(arg1, arg2):
        return arg1 + arg2
    source = get_source(foo)
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, {'arg1': 'a', 'arg2': 'b'})
    assert ast.dump(tree) == "(Module(body=[FunctionDef(name='foo', args=arguments(args=[Name(id='a', ctx=Param()), Name(id='b', ctx=Param())], vararg=None, kwarg=None, defaults=[]), body=[Return(value=BinOp(left=Name(id='a', ctx=Load()), op=Add(), right=Name(id='b', ctx=Load())))], decorator_list=[])]))"

# Generated at 2022-06-21 18:46:54.591888
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class NestedClass(object):
        class NestedNestedClass(object):
            pass

    class Test(NestedClass):
        def __init__(self, x: int) -> None:
            self.x = x
            self.y = x + 1

        def func(self) -> None:
            self.x *= self.y

    def test() -> int:
        t = Test(42)
        t.func()
        return t.x

    source = get_source(test)
    tree = ast.parse(source)

# Generated at 2022-06-21 18:46:55.609077
# Unit test for function find_variables

# Generated at 2022-06-21 18:46:56.220863
# Unit test for constructor of class snippet
def test_snippet():
    pass

# Generated at 2022-06-21 18:47:07.497627
# Unit test for function extend
def test_extend():
    from astor import to_source
    vars = ast.Module([])
    vars.body.append(ast.Assign([ast.Name(id='c', ctx=ast.Store())],
                                ast.Num(n=2)))
    vars.body.append(ast.Assign([ast.Name(id='c', ctx=ast.Store())],
                                ast.Num(n=3)))
    ext = ast.Expr(ast.Call(ast.Name(id='extend', ctx=ast.Load()),
                            [ast.Name(id='vars', ctx=ast.Load())],
                            []))
    print(to_source(vars))
    print(to_source(ext))

# Generated at 2022-06-21 18:47:10.931483
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A(object):
        class B(object):
            pass
    
    class C(object):
        class B(object):
            pass
    

# Generated at 2022-06-21 18:47:14.141748
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    module_name = 'test_module'
    import_node = ast.parse('from ' + module_name + ' import a').body[0]
    assert (
        VariablesReplacer.replace(import_node, {module_name: 'new_module'}).module
        == 'new_module'
    )



# Generated at 2022-06-21 18:47:22.100435
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = """
    from . import foo
    from . import bar as b
    """

    tree = ast.parse(source)
    variables_replacer = VariablesReplacer({"foo": "foo", "bar": "foo"})
    variables_replacer.visit(tree)
    assert ast.dump(tree) == "Module(body=[ImportFrom(module='foo', names=[alias(name='foo', asname=None)], level=1), ImportFrom(module='foo', names=[alias(name='foo', asname='b')], level=1)])"

# Generated at 2022-06-21 18:47:51.768999
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class A:
        def __init__(self, i):
            self.i = i

    class B(A):
        pass

    class C:
        def __init__(self, i):
            self.i = i

    a = A(1)
    b = B(1)
    c = C(1)
    d = [
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1),
        )
    ]

    assert VariablesReplacer.replace(a, {'a': b}).i == 1
    assert VariablesReplacer.replace(b, {'b': c}).i == 1
    assert VariablesReplacer.replace(c, {'c': a}).i == 1

# Generated at 2022-06-21 18:47:56.851803
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import sys
    import ast
    import astunparse
    tree = ast.parse("try:\n    pass\nexcept Exception as e:\n    pass\n")
    variables = {"e": "some_variable"}
    VariablesReplacer.replace(tree, variables)
    astunparse.unparse(tree)

# Generated at 2022-06-21 18:47:58.013549
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:48:00.187148
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    test_VariablesReplacer.__name__ == 'test_VariablesReplacer'


# Generated at 2022-06-21 18:48:10.855765
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import Node, compare_nodes
    @snippet
    def my_snippet():
        let(x)
        let(y)
        x += 1
        y = 1

    snippet_body = my_snippet.get_body()
    expected_body = [
        Node(ast.AugAssign, target=Node(ast.Name, id='_py_backwards_x_0'),
             op=Node(ast.Add), value=Node(ast.Num, n=1)),
        Node(ast.Assign, targets=[Node(ast.Name, id='y')],
             value=Node(ast.Num, n=1)),
    ]

    assert compare_nodes(snippet_body, expected_body) is True

# Generated at 2022-06-21 18:48:22.323832
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    classDef = ast.ClassDef(name='SomeClass', bases=[], body=[], decorator_list=[], keywords=[])
    name = ast.Name(id='SomeClass', ctx=ast.Load())
    parent = ast.Module(body=[name])
    classDef.name = 'testName'

    classDefResult = VariablesReplacer(variables={'testName': 'testName'}).visit(classDef)
    nameResult = VariablesReplacer(variables={'testName':'testName'}).visit(name)
    parentResult = VariablesReplacer(variables={'testName':'testName'}).visit(parent)
    assert isinstance(classDefResult, ast.ClassDef)
    assert isinstance(nameResult, ast.Name)
    assert isinstance(parentResult, ast.Module)

# Generated at 2022-06-21 18:48:26.257726
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    source = '''print(obj.f)'''
    tree = ast.parse(source)

    replacer = VariablesReplacer({'obj': 'obj2'})
    replacer.visit(tree)

    for node in find(tree, ast.Attribute):
        assert node.value.id == 'obj2'


# Generated at 2022-06-21 18:48:35.300181
# Unit test for function let
def test_let():
    @snippet
    def fn():
        let(x)
        return x + 1

    assert fn.get_body(x=2) == [
        ast.Assign([  # type: ignore
            ast.Name('_py_backwards_x_0', ast.Store())],  # type: ignore
            ast.Num(2))]
    assert fn.get_body(x=3) == [
        ast.Assign([  # type: ignore
            ast.Name('_py_backwards_x_1', ast.Store())],  # type: ignore
            ast.Num(3))]



# Generated at 2022-06-21 18:48:43.192546
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = """
import a.b.c.d as e
"""

    class Visitor(ast.NodeVisitor):
        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
            node.module = VariablesReplacer._replace_module(node, {"a.b.c.d": "a.b.c"})
        def generic_visit(self, node: ast.AST) -> None:
            pass

    tree = ast.parse(source)

    visitor = Visitor()
    visitor.visit(tree)

    transformed = ast.dump(tree)
    expected = """
Module(body=[ImportFrom(module='a.b.c', names=[alias(name='d', asname='e')], level=0)])
"""

    assert transformed == expected

# Generated at 2022-06-21 18:48:52.623928
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    varsDict = {"a": "b"}
    inst = VariablesReplacer(varsDict)

    ast_node_1 = ast.ExceptHandler(
        type=None, name="a", body=[], lineno=1, col_offset=1)
    ast_node_2 = ast.ExceptHandler(
        type=None, name=None, body=[], lineno=1, col_offset=1)

    new_node_1 = inst.visit_ExceptHandler(ast_node_1)
    new_node_2 = inst.visit_ExceptHandler(ast_node_2)

    assert new_node_1.name == "b"
    assert new_node_2.name == None

# Generated at 2022-06-21 18:49:33.913086
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("from a.b.c import x, y")
    variables = {'a.b.c': 'd.e.f'}

    VariablesReplacer.replace(tree, variables)

    assert get_source(tree) == "from d.e.f import x, y"

# Generated at 2022-06-21 18:49:38.719213
# Unit test for function extend
def test_extend():
    test_var = snippet(lambda x, y: extend(vars))
    vars = ast.parse('x = 1').body
    code = test_var.get_body(vars=vars)
    assert ast.dump(code[0], include_attributes=True) == ast.dump(vars[0], include_attributes=True)


# Generated at 2022-06-21 18:49:45.250143
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class MyAlias(ast.alias):
        name = "foo"
    class MyFromImport(ast.ImportFrom):  
        module = "bar"
        names = [MyAlias()]
    fromimport = MyFromImport() 
    # This is what it looks like in the AST:
    assert fromimport.names[0].name == "foo"
    assert fromimport.module == "bar"

    # This is what it looks like when we try to get the source
    assert ast.dump(fromimport, include_attributes=True) == \
        "ImportFrom(module='bar', names=[alias(name='foo', asname=None)])"

    # Replace variables works fine with this
    result = VariablesReplacer.replace(fromimport, {"foo": "bar", "bar": "baz"})

# Generated at 2022-06-21 18:49:53.146787
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import os
    import sys
    code = '''
import os
from sys import path'''
    tree = ast.parse(code)
    variables = {'os': 'os_path', 'path': 'sys_path'}
    new_tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(new_tree) == ast.dump(ast.parse(
'''
import os_path
from sys import sys_path'''
    ))

# Generated at 2022-06-21 18:50:04.654095
# Unit test for function extend
def test_extend():
    def f(x):
        extend(a)
        extend(b)
        print(x)
    a = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1))]
    b = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]
    body = snippet(f).get_body(x=3, a=a, b=b)

# Generated at 2022-06-21 18:50:06.282889
# Unit test for constructor of class snippet
def test_snippet():
    def func():
        let(x)

    assert snippet(func).__class__.__name__ == 'snippet'

# Generated at 2022-06-21 18:50:12.254564
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import astor
    import_from_node = ast.parse('from foo.bar.baz import x').body[0]
    assert astor.to_source(VariablesReplacer.replace(import_from_node,
                            {'foo.bar': 'foo', 'bar.baz': 'bar'})) == 'from foo.bar import x'


# Generated at 2022-06-21 18:50:18.189474
# Unit test for function extend_tree
def test_extend_tree():
    vars = ast.parse('x = 1\ny = 2').body
    extend_tree(ast.parse('extend(vars)\nprint(x, y)'), {'vars': vars})
    assert get_source(ast.parse('extend(vars)\nprint(x, y)')) == \
           'x = 1\ny = 2\nprint(x, y)'



# Generated at 2022-06-21 18:50:27.922314
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class TestVisitor(VariablesReplacer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            return ast.Name(id="NewName", ctx=ast.Load())

    source = """
        def test(x, y=1, **kw):
            pass
    """
    tree = ast.parse(source)
    expected_tree = ast.parse("""
        def test(NewName, NewName=1, **NewName):
            pass
    """)

    variables = {"x": "Changed", "y": "Changed", "kw": "Changed"}
    VariablesReplacer.replace(tree, variables)

    visitor = TestVisitor(variables)
    visitor.visit(tree)
    assert tree == expected_tree



# Generated at 2022-06-21 18:50:28.757221
# Unit test for function find_variables

# Generated at 2022-06-21 18:50:59.378035
# Unit test for function find_variables

# Generated at 2022-06-21 18:51:07.514236
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .tree import find
    from .helpers import get_source

    tree = ast.parse("""
    import x, y as z
    import a.b.c as d, e.f.g as h
    """)

    tree = VariablesReplacer.replace(tree, {'x': 'y', 'a': 'x', 'd': 'y', 'e': 'x'})

    assert get_source(tree) == """
    import y, y as z
    import x.b.c as y, x.f.g as z
    """

    assert find(tree, ast.alias, "name == 'x'") == []
    assert find(tree, ast.alias, "asname == 'x'") == []

# Generated at 2022-06-21 18:51:18.477132
# Unit test for function extend
def test_extend():
    def test_function():
        extend(snippet(lambda: _py_backwards_x_0))
        print(_py_backwards_x_0)

    test_function()
    assert test_function.__code__.co_code == \
        b'|\x00\x00t\x00|\x00\x00S'

# Generated at 2022-06-21 18:51:19.302166
# Unit test for constructor of class snippet
def test_snippet():
    snippet("")

# Generated at 2022-06-21 18:51:22.855149
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("a.b(x)")
    variables = {
        "x": ast.Name(id='_x', ctx=ast.Load())
    }
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert tree.body[0].value.func.value.id == "_x"


# Generated at 2022-06-21 18:51:32.617802
# Unit test for constructor of class snippet
def test_snippet():
    # Given
    snippet_builder = snippet(lambda x: x)

    # When
    body = snippet_builder.get_body(
        {'c': 1},
        int,
    )

    # Then
    assert len(body) == 2
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[0].value, ast.Call)
    assert isinstance(body[0].value.func, ast.Name)
    assert body[0].value.func.id == 'let'
    assert isinstance(body[0].value.args[0], ast.Str)
    assert body[0].value.args[0].s == 'c'
    assert isinstance(body[0].value.args[1], ast.Call)