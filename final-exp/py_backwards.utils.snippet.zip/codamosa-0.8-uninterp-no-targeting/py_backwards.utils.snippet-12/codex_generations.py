

# Generated at 2022-06-21 18:41:58.906683
# Unit test for function find_variables
def test_find_variables():
    #test 1
    t1 = ast.parse('let(x)')
    output1 = next(find_variables(t1))
    assert output1 == 'x'
    assert t1.body[0].body == []

    #test 2
    t2 = ast.parse('let(x)\nprint(x)')
    output2 = next(find_variables(t2))
    assert output2 == 'x'
    assert t2.body[0].body == [ast.Expr(value = ast.Call(
                                              func = ast.Name(id = 'print', ctx = ast.Load()),
                                              args = [ast.Name(id = 'x', ctx = ast.Load())],
                                              keywords = []))]

    #test 3

# Generated at 2022-06-21 18:42:05.143369
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
        tree1 = ast.parse('def f(x): pass')
        tree2 = ast.parse('def f(x): pass')
        variables = {'x': 'y'}
        tree1 = VariablesReplacer.replace(tree1, variables)
        visit = VariablesReplacer.replace(tree2, variables)
        visit.visit_arg(tree2.body[0].args.args[0])
        assert ast.dump(tree1) == ast.dump(tree2)


# Generated at 2022-06-21 18:42:08.793535
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    assert ast.dump(VariablesReplacer.replace(ast.parse("f(a=b)").body[0], {
        'b': Variable('c')
    })) == "Call(func=Name(id='f', ctx=Load()), args=[], keywords=[keyword(arg='a', value=Name(id='c', ctx=Load()))])"

# Generated at 2022-06-21 18:42:10.368824
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import ast as std_ast


# Generated at 2022-06-21 18:42:19.686792
# Unit test for constructor of class snippet
def test_snippet(): # type: ignore
    @snippet
    def foo(x):
        let(x)
        x += 1
        print(x)
        
    ast_snippet = foo.get_body()
    assert ast.dump(ast_snippet) == '[Assign(targets=[Name(id=_py_backwards_x_0, ctx=Store())], value=BinOp(left=Name(id=_py_backwards_x_0, ctx=Load()), op=Add(), right=Num(n=1))), Print(dest=None, values=[Name(id=_py_backwards_x_0, ctx=Load())], nl=True)]'

# Generated at 2022-06-21 18:42:20.532362
# Unit test for function find_variables

# Generated at 2022-06-21 18:42:31.407628
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
            let(a)
            let(b)
            let(c)
            let(d)
            let(e)
            let(f)
            let(g)
            let(h)
            a = b
            let(kl)
            c = d
            let(mn)
            e = f
            let(op)
            g = h
            i = j
            let(qr)
            k = l
            let(st)
            m = n
            o = p
            let(uv)
            q = r
            let(wx)
            s = t
            let(yz)
            u = v
            w = x
            y = z
            """)

# Generated at 2022-06-21 18:42:36.765597
# Unit test for function let
def test_let():
    def foo():
        let(x)
        x += 1
        let(y)
        y = 1

    tree = snippet(foo).get_body()

    expected_tree = [
        ast.AugAssign(
            target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            op=ast.Add(),
            value=ast.Num(n=1),
        ),
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_y_0', ctx=ast.Store())],
            value=ast.Num(n=1),
        ),
    ]

    assert tree == expected_tree



# Generated at 2022-06-21 18:42:46.496925
# Unit test for function extend
def test_extend():
    snippet_vars = {
        'x': ast.parse('''x = 1; x = 2''').body,
        'y': ast.parse('''y = 2; y = 2''').body
    }

    @snippet
    def test() -> None:
        extend(vars)
        print(x, y)

    body = test.get_body(vars=snippet_vars)

# Generated at 2022-06-21 18:42:53.404396
# Unit test for function extend
def test_extend():
    x = 1
    let(x)

    def test_extend_snippet(x: int, y: int) -> None:
        x = 2
        extend(x)
        print(y)

    context = {}
    exec(compile(ast.Module(body=snippet(test_extend_snippet).get_body()), '', 'exec'), context)
    assert context['x'] == 2
    assert context['y'] == 2

# Generated at 2022-06-21 18:42:57.383760
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-21 18:42:57.992454
# Unit test for method visit_ExceptHandler of class VariablesReplacer

# Generated at 2022-06-21 18:43:02.438311
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('foo = foo')
    variables = {'foo': 'bar', 'bar': 'baz'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Assign(targets=[Name(id='baz', ctx=Store())], value=Name(id='baz', ctx=Load()))"



# Generated at 2022-06-21 18:43:07.475036
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class Handler:
        def __enter__(self):
            pass

        def __exit__(self, *args):
            return True

    assert isinstance(ast.parse('''
try:
    pass
except Exception as e:
    with Handler() as handler:
        pass
''').body[0], ast.Try)

# Generated at 2022-06-21 18:43:13.658585
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    def test():
        extend(vars)
        print(x, y)
        print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert len(tree.body[0].body) == 7



# Generated at 2022-06-21 18:43:21.027566
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    var = VariablesGenerator.generate('x')
    tree = ast.parse("try: pass\nexcept as e: pass")
    tree.body[0].body[0].name = var
    VariablesReplacer.replace(tree, {'e': var})
    assert ast.dump(tree) == 'Try([], [ExceptHandler(name=<_ast.Name object at 0x7f9d9f8b0ac0>, type=None, body=[Pass()])], [])'


# Generated at 2022-06-21 18:43:27.833111
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("def a(a): pass", mode='exec')
    variables = {'a': 'b'}
    tree_new = VariablesReplacer.replace(tree, variables)
    assert tree_new.body[0].args.args[0].id == 'b'  # type: ignore



# Generated at 2022-06-21 18:43:33.437485
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    def foo(x):
        return x

    ast_vanilla = ast.parse(get_source(foo))
    variables = {'x': VariablesGenerator.generate('x')}
    
    variables_replacer = VariablesReplacer(variables)

    x = variables_replacer.visit_Name(ast_vanilla.body[0].args.args[0])
    
    ast_expected = ast.parse(get_source(foo).replace('x: int', '_py_backwards_x_0: int'))

    assert ast.dump(x) == ast.dump(ast_expected.body[0].args.args[0])

# Generated at 2022-06-21 18:43:34.736817
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-21 18:43:40.752108
# Unit test for function extend
def test_extend():
    class Test(ast.AST):
        _fields = ('body', )
        _attributes = ('body', )

    tree = Test(body=[])
    extend_tree(tree, {'x': [ast.Assign(targets=[ast.Name(
        id='a', ctx=ast.Store())], value=ast.Num(n=1))]})
    assert tree.body[0].value.n == 1

# Generated at 2022-06-21 18:43:53.752504
# Unit test for function let
def test_let():
    class A:
        def fn(self, a, b):
            let(a1)
            a1 = 'hello'
            assert a == 1
            assert b == 2
            assert a1 == 'hello'
            let(b2)
            b2 = 'world'
            return a1 + ' ' + b2
           

    a = A()
    assert a.fn(1, 2) == 'hello world'



# Generated at 2022-06-21 18:43:57.962081
# Unit test for function find_variables
def test_find_variables():
    source_var = '''let(a)
if a > b:
  let(b)
  c = a + b
  print(c)
'''
    expected_vars = {'a', 'b', 'c'}
    tree = ast.parse(source_var)
    actual_vars = set(find_variables(tree))
    assert actual_vars == expected_vars



# Generated at 2022-06-21 18:44:06.722223
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # The purpose of this test is to make sure that VariablesReplacer does not
    # replace the name of module in import statement.
    tree = ast.parse("import os")
    replacer = VariablesReplacer({
        'os': {
            'module': 'my_module',
            'asname': None,
            'lineno': 0,
            'col_offset': 0
        }
    })
    replacer.visit(tree)
    assert tree.body[0].names[0].name == 'os'

# Generated at 2022-06-21 18:44:12.088756
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f1(x, y):
        let(z)
        z += 1
        return x + z

    body = f1.get_body(x=1, y=2)

    assert get_source(body) == 'z = 1\n'\
        'return x + z\n'



# Generated at 2022-06-21 18:44:21.398947
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    def nothing():
        pass

    def function_with_kw_only_args(a, *, b, c, d=nothing):
        b.append(1)
        a.append(2)
        c.append(3)
        d()

    vars = {
        'b': ast.Name(id='b', ctx=ast.Store()),
        'c': ast.Name(id='c', ctx=ast.Store()),
        'a': ast.Name(id='a', ctx=ast.Store()),
        'd': None
    }

    tree = ast.parse(get_source(function_with_kw_only_args))
    args = tree.body[0].args.args
    assert args[0].arg == 'a'
    assert args[1].arg == 'b'
   

# Generated at 2022-06-21 18:44:28.176753
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    source = """
    class A:
        def f(self):
            self.x = self.x + 1
            return self.x
    """
    tree = ast.parse(source)
    assert len(tree.body) == 1
    self_x_node = tree.body[0].body[0].body[0].value.value
    variables = {'self.x': 'self._py_backwards_self_x'}
    assert isinstance(self_x_node, ast.Attribute)
    replacer = VariablesReplacer(variables)
    replacer.visit_Attribute(self_x_node)
    assert self_x_node.attr == '_py_backwards_self_x'



# Generated at 2022-06-21 18:44:34.577444
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    code = 'from a as b'
    module = ast.parse(code)
    variables = {'a': 'c'}
    VariablesReplacer.replace(module, variables)
    assert(module.body[0].names[0].name == 'b')
    assert(module.body[0].module == 'c')
    assert(ast.dump(module) == "Module(body=[ImportFrom(module='c', names=[alias(name='b', asname=None)], level=0)])")



# Generated at 2022-06-21 18:44:35.580966
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-21 18:44:41.727361
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    source = "class A:\n  def b():\n    pass"
    tree = ast.parse(source)
    replacer = VariablesReplacer({"A": "B"})
    actual = replacer.visit(tree)
    expected = ast.parse("class B:\n  def b():\n    pass")
    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-21 18:44:52.908650
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse("let(x) x += 1"))) == ['x']
    assert list(find_variables(ast.parse("x = 1; let(y); y = 2"))) == ['y']
    assert list(find_variables(ast.parse("x = 1; let(y)\ny = 2"))) == ['y']
    assert list(find_variables(ast.parse("x = 1; let(y)\ny = 2"))) == ['y']
    assert list(find_variables(ast.parse("x = 1; let(y)\ny = 2\n"))) == ['y']
    assert list(find_variables(ast.parse("x = 1; let(y)\ny = 2\n# comment\n"))) == ['y']

# Generated at 2022-06-21 18:45:04.333023
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer
    vr = VariablesReplacer({'x': 'y', 'z': ast.Name('a')})
    assert vr._replace_field_or_node(ast.Name('x', 'Store'), 'id') == ast.Name('y', 'Store')
    assert vr._replace_field_or_node(ast.Name('z', 'Store'), 'id') == ast.Name('a', 'Store')
    assert vr._replace_field_or_node(ast.Name('w', 'Store'), 'id') == ast.Name('w', 'Store')
    assert vr._replace_field_or_node(ast.Name('w', 'Store'), 'id', True) == ast.Name('w', 'Store')

# Generated at 2022-06-21 18:45:12.206268
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    module = 'from django.db import models'
    tree = ast.parse(module)
    variables = {
        'django': 'django_test',
        'db': 'db_test',
        'models': 'models_test'
    }
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'Module(body=[ImportFrom(module=\'django_test.db_test\', names=[alias(name=\'models_test\', asname=None)], level=0)])'


# Generated at 2022-06-21 18:45:23.936099
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    b = 2

    @snippet
    def snippet():
        res = let(a) + let(b)
        return res

    assert snippet.get_body() == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_res_0', ctx=ast.Store())],
                   value=ast.BinOp(left=ast.Name(id='_py_backwards_a_0', ctx=ast.Load()),
                                   op=ast.Add(),
                                   right=ast.Name(id='_py_backwards_b_0', ctx=ast.Load()))),
        ast.Return(value=ast.Name(id='_py_backwards_res_0', ctx=ast.Load()))
    ]



# Generated at 2022-06-21 18:45:33.837032
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class FakeName:
        id = 'x'
        ctx = None

    class FakeAttribute:
        attr = 'y'
        value = FakeName()

    class FakeAttributeReturned:
        attr = 'z'
        value = FakeName()

    class FakeVariablesReplacer(VariablesReplacer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            if node.id == 'x':
                return FakeNameReturned().__class__  # type: ignore
            else:
                return self.generic_visit(node)  # type: ignore


    variables = dict()
    variables['x'] = FakeNameReturned()

    inst = FakeVariablesReplacer(variables)
    r = inst.visit_Attribute(FakeAttribute)  # type: ignore

# Generated at 2022-06-21 18:45:41.267263
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('def f(x): pass')
    variables = {'x': 'y'}
    tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'FunctionDef(body=[Pass()], decorator_list=[], name=x, args=arguments(args=[arg(arg=y, annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), returns=None)'

# Generated at 2022-06-21 18:45:46.018569
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():

    class TestClass:
        a = 'a'
        b = 'b'

    test_class = ast.parse(inspect.getsource(TestClass)).body[0]

    variables_replacer = VariablesReplacer({'test_class': TestClass})
    variables_replacer.visit(test_class)
    assert get_source(test_class) == 'class TestClass:\n    a = 1\n    b = 2\n'

# Generated at 2022-06-21 18:45:57.438685
# Unit test for function extend_tree
def test_extend_tree():
    def extend_tree_fn():
        extend(vars)

    tree = ast.parse(get_source(extend_tree_fn))

    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=2)
        ),
    ]

    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-21 18:46:05.753007
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.ExceptHandler(
        type=ast.Name(id='IndexError', ctx=ast.Load()),
        name=ast.Name(id='err', ctx=ast.Store()),
        body=[ast.Expr(value=ast.Call(
            func=ast.Name(id='print', ctx=ast.Load()),
            args=[ast.Str(s='got an error')],
            keywords=[]
        ))],
    )

    replacer = VariablesReplacer({
        'err': ast.Name(id='my_err', ctx=ast.Store())
    })

    replacer.visit(tree)

    assert isinstance(tree.name, ast.Name)
    assert tree.name.id == 'my_err'

# Generated at 2022-06-21 18:46:08.788608
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("dummy = y()")
    variables = {"y" : "z"}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)

    assert(
        tree.body[0].value.keywords[0].arg == "z"
    )

# Generated at 2022-06-21 18:46:16.846923
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    from .tests.utils import test_ast
    from .tree import deep_replace
    from .helpers import VariablesGenerator

    class_declaration = ast.parse('class Klass: pass').body[0]

    def test_visit_ClassDef(tree):
        return VariablesReplacer.visit_ClassDef(VariablesReplacer(dict()), tree)

    assert test_ast(test_visit_ClassDef(class_declaration), class_declaration)

    # VariablesReplacer.replace

    a_name = VariablesGenerator.generate('a')
    b_name = VariablesGenerator.generate('b')
    c_name = VariablesGenerator.generate('c')


# Generated at 2022-06-21 18:46:30.651790
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert(type(VariablesReplacer(dict()))==VariablesReplacer)


# Generated at 2022-06-21 18:46:42.613995
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    f1 = snippet(lambda a:let(a))
    f2 = snippet(lambda a:let(2))

    def d(a, b):
        let(a)
        return let(b)

    f3 = snippet(d)

    tree = ast.parse(
        '''
        def fn(a):
            a = 1
            b = 2
            fn2 = f1(a)
            fn3 = f2(a)
            fn35 = f3(a, b)
        '''
    )

    variables = {
        'f1': f1,
        'f2': f2,
        'f3': f3,
        'a': 'fn_a',
        'b': 'fn_b',
    }

    VariablesReplacer.replace(tree, variables)

    fn = tree

# Generated at 2022-06-21 18:46:46.147016
# Unit test for function find_variables
def test_find_variables():
    code = """
    def foo(x):
        let(x)
        x += 2
    let(y)
    y = 'test'
    """
    tree = ast.parse(code)
    assert(list(find_variables(tree)) == ['x', 'y'])



# Generated at 2022-06-21 18:46:56.306769
# Unit test for function let
def test_let():
    def test():
        let(x)
        x += 1
        y = 1

        return x, y

    # Check that we can read return values:
    assert test() == (1, 1)

    # Check that the names really changed:
    tree = snippet(test).get_body()
    assert len(tree) == 2
    assert isinstance(tree[0].value, ast.BinOp)
    assert isinstance(tree[1].value, ast.Num)
    assert tree[0].value.left.id != 'x'
    assert tree[0].value.right.n == 1
    assert tree[1].value.n == 1



# Generated at 2022-06-21 18:46:57.242065
# Unit test for method visit_ExceptHandler of class VariablesReplacer

# Generated at 2022-06-21 18:47:09.249430
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    from .tree import make_tree, find
    from typed_ast.ast3 import parse
    source = """
    def f(a):
        print(a)
    """
    tree = parse(source)

    vr = VariablesReplacer({'a': 'b'})
    vr.replace(tree, {'a': 'b'})
    # No tree should be changed
    assert tree == parse(source)

    # One call inside function should be modified
    tree = parse("""def a(a):
    b = 1
    print(a)
    """)
    vr = VariablesReplacer({'a': 'b'})
    vr.replace(tree, {'a': 'b'})

# Generated at 2022-06-21 18:47:16.015283
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class ReplaceFoo(VariablesReplacer):
        def __init__(self, variables: Dict[str, str]) -> None:
            super().__init__(variables)

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            if node.name == 'foo':
                node.name = self._variables['foo']
            return self.generic_visit(node)  # type: ignore

    # given
    tree = ast.parse("""def foo(arg):\n    pass""")
    variables = {'foo': 'bar'}
    expected = ast.parse("""def bar(arg):\n    pass""")

    # when
    ReplaceFoo.replace(tree, variables)

    # then
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-21 18:47:21.622561
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class Dummy(ast.NodeTransformer):
        def visit_keyword(self, node):
            return node
    dummy = Dummy()
    node = ast.parse('{x: 1}').body[0].value
    result = dummy.visit_keyword(node.keywords[0])
    assert result.arg == 'x'


# Generated at 2022-06-21 18:47:25.847863
# Unit test for function find_variables
def test_find_variables():
    def f():
        let(x)
        x.foo
        def g():
            x = 1
        let(y)
        let(z)

    assert set(find_variables(ast.parse(get_source(f)))) == {'x', 'y', 'z'}


# Generated at 2022-06-21 18:47:31.769711
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
        try:
            pass
        except Exception as e:
            print(e)
    """
    tree = ast.parse(source)
    tree.body[0].body[0].body[1].name = 'Error'
    inst = VariablesReplacer({'e': 'Error'})
    inst.visit(tree)
    assert get_source(tree) == source

# Generated at 2022-06-21 18:48:05.932465
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A:
        let(10)
        class B:
            class C:
                ...

    source = get_source(A)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name)
                 for name in names}
    extend_tree(tree, variables)
    varaibles_replacer = VariablesReplacer(variables)
    varaibles_replacer.visit(tree)
    assert tree.body[0].body[0].body[0].name == variables['10']

# Generated at 2022-06-21 18:48:15.704097
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import inspect
    snippet_source = inspect.getsource(snippet)
    snippet_ast = ast.parse(snippet_source)
    module_name = "py_backwards.snippet"
    module_alias = "snippet"
    found = False
    for node in snippet_ast.body:
        if isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name == module_name:
                    found = True
                    alias.asname = module_alias
    assert found

    replacer = VariablesReplacer.replace(snippet_ast, {"snippet": "snippet_1"})
    found = False

# Generated at 2022-06-21 18:48:24.085890
# Unit test for function extend_tree
def test_extend_tree():
    node = ast.parse('extend(vars)\n'
                     'print(a, b)').body[0]

    vars = ast.parse('a = 1\n'
                     'b = 2').body[:]

    extend_tree(node, {'vars': vars})

    expected = 'a = 1\na = 2\nprint(a, b)'
    actual = ast.fix_missing_locations(node.body[0])
    assert ast.dump(actual) == expected



# Generated at 2022-06-21 18:48:25.921023
# Unit test for constructor of class snippet
def test_snippet():
    assert isinstance(snippet, type)
    assert isinstance(snippet(lambda x, y: None), snippet)

# Generated at 2022-06-21 18:48:30.505906
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\nx += 1\ny = 1')
    assert list(find_variables(tree)) == ['x']
    assert ast.dump(tree) == 'Module([Assign([Name(y, Store())], Num(1))])'



# Generated at 2022-06-21 18:48:37.175287
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_test():
        let(x)
        print(x)
        let(y)
        print(y)

    body = snippet_test.get_body()

    assert len(body) == 2
    assert body[0].value.args[0].id == '_py_backwards_x_0'
    assert body[1].value.args[0].id == '_py_backwards_y_0'



# Generated at 2022-06-21 18:48:44.123557
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    module = ast.parse("x = 1\npass")

    variables = {"x": "y"}
    VariablesReplacer.replace(module, variables)
    assert get_source(module) == "y = 1\npass"

    variables = {"y": "x"}
    VariablesReplacer.replace(module, variables)
    assert get_source(module) == "y = 1\npass"

    variables = {"y": [ast.Assign(targets=[ast.Name(id="x", ctx=ast.Store())],
                                  value=ast.Num(n=2))]}
    VariablesReplacer.replace(module, variables)
    assert get_source(module) == "y = 1\nx = 2\npass"


# Generated at 2022-06-21 18:48:50.756212
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class Test(ast.NodeTransformer):
        def visit_keyword(self, node):
            if node.name.id == 'name':
                node.name.id = 'new_name'
            return super().visit_keyword(node)

    node = ast.parse('''def foo(name=None): print(1)''').body[0]
    Test().visit(node)

    assert node.args.kwarg == 'new_name'

# Generated at 2022-06-21 18:48:54.262098
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('''{foo: let(x), bar: let(y)}''')
    VariablesReplacer.replace(tree, {'x': 'qwerty', 'y': 'qwerty'})
    assert get_source(tree) == '{foo: qwerty, bar: qwerty}'



# Generated at 2022-06-21 18:48:56.520722
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    node = ast.parse("def test(): pass")
    assert VariablesReplacer.replace(node, {}).body[0].name == "test"

# Generated at 2022-06-21 18:49:35.976152
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("f(x=1, y=let(1))")
    variables = {'_py_backwards_x_0': 1}
    VariablesReplacer.replace(tree, variables)
    assert compile(tree, '', 'eval').eval() == 2

# Generated at 2022-06-21 18:49:43.993533
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("""
    from . import foo
    from . import foo as bar
    from . import foo as bar, foo as boo
    from .foo import bar
    from .foo.bar import boo
    """)
    tree = extend_tree(tree, {})
    VariablesReplacer.replace(tree, {})

# Generated at 2022-06-21 18:49:45.522891
# Unit test for constructor of class snippet
def test_snippet():
    assert isinstance(snippet(lambda: None), snippet)



# Generated at 2022-06-21 18:49:56.280364
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    """ Test for method visit_alias of VariablesReplacer class"""
    import typing as _typing

    class TestClass:
        pass

    TestClass.alias = ast.alias(name='test', asname='as_test')

    assert TestClass.alias.name == 'test'
    assert TestClass.alias.asname == 'as_test'

    replacer = VariablesReplacer(
        {'test': 'test_var', 'as_test': 'as_test_var'})

    replacer.visit(TestClass.alias)

    assert TestClass.alias.name == 'test_var'
    assert TestClass.alias.asname == 'as_test_var'



# Generated at 2022-06-21 18:50:00.717498
# Unit test for function find_variables
def test_find_variables():
    # type: () -> None
    tree = ast.parse("""
    [let(x) for i in range(10)]
    y = let(y) + let(z)
    """)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-21 18:50:09.457908
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    #
    # All the tests below are of the form
    # input_node -> expected_node
    #
    # input_node is of type ast.Name
    # expected_node is of type ast.Name
    #


    #
    # Test 0:
    # input_node.id does not appear in self._variables
    #
    input_node = ast.parse('x').body[0].value
    expected_node = ast.parse('x').body[0].value
    variables = {'y': 'z'}
    result_node = VariablesReplacer.replace(input_node, variables)
    assert ast_equal(expected_node, result_node)

    #
    # Test 1:
    # input_node.id appears in self._variables and
    # self._variables[input_node.id

# Generated at 2022-06-21 18:50:20.773264
# Unit test for function let
def test_let():
    @snippet
    def test_snippet():
        let(a)
        a += 1
        b = 2

        let(b)
        b += 2

    source = '\n'.join(get_source(test_snippet).split('\n')[2:])
    tree = ast.parse(source)
    variables = {
        'a': VariablesGenerator.generate('a'),
        'b': VariablesGenerator.generate('b'),
    }
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

    assert get_source(tree.body[0].body[0]) == '{} += 1'.format(variables['a'])
    assert get_source(tree.body[0].body[1]) == 'b = 2'

# Generated at 2022-06-21 18:50:26.403407
# Unit test for function find_variables
def test_find_variables():
    func_body = """
        let(x)
        x = 1
        let(x)
        x = 2
        print('Lets find x:')
        print(x)
    """
    ast_tree = ast.parse(func_body)
    expected_result = ['x', 'x']
    assert list(find_variables(ast_tree)) == expected_result



# Generated at 2022-06-21 18:50:29.747737
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(name)
    let(name)
    let(other)
    def foo():
        let(func_var)
    """)
    assert list(find_variables(tree)) == ['name', 'other', 'func_var']


# Generated at 2022-06-21 18:50:34.059431
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from_node = ast.parse(
        'from module1.module2.module3 import x, y', mode='eval').body
    variables = {'module1.module2': 'new_module'}
    VariablesReplacer.replace(import_from_node, variables)
    assert ast.dump(import_from_node) == '[<_ast.ImportFrom at 0x1054dbe80>]'

# Generated at 2022-06-21 18:51:37.477095
# Unit test for function let
def test_let():
    @snippet
    def test_function():
        let(x)
        x += 1
        y = 1

    assert test_function.get_body()[0].id == '_py_backwards_x_0'
    assert test_function.get_body()[1].targets[0].id == 'y'

# Generated at 2022-06-21 18:51:38.291483
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet  # type: ignore