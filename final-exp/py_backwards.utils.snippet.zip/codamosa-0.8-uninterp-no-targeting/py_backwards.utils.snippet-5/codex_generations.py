

# Generated at 2022-06-21 18:42:10.172715
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A(ast.AST):
        """A test class"""
        _fields = ('test1', 'test2')

    class B(ast.AST):
        """A test class"""
        _fields = ('test1', 'test2')

    class C(ast.AST):
        """A test class"""
        _fields = ('test1', 'test2')

    tree = A(test1=B(test1=C(test1='test1', test2='test2'), test2='test2'), test2='test2')  # type: ignore
    variables = {'test1': 'test3'}
    resultTree = VariablesReplacer.replace(tree, variables)
    assert resultTree.test1.test1.test1 == 'test3' and resultTree.test1.test1.test2 == 'test2' and result

# Generated at 2022-06-21 18:42:20.875593
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class_obj = ast.ClassDef(
        name='var_1',
        bases=[ast.Name(id='base_1', ctx=ast.Load())]
    )

    function_obj = ast.FunctionDef(
        name='var_2',
        args=ast.arguments(
            args=[ast.arg(arg='arg_1', annotation=None)],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[],
        ),
        body=[ast.Name(id='var_1', ctx=ast.Load())],
        decorator_list=[],
    )

    module_obj = ast.Module(
        body=[class_obj, function_obj]
    )


# Generated at 2022-06-21 18:42:22.453344
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import typed_ast.ast3 as ast

# Generated at 2022-06-21 18:42:29.949938
# Unit test for function extend
def test_extend():
    @snippet
    def my_snippet(x: int):
        extend(vars)
        return x

    tree = my_snippet.get_body(
        vars=[ast.parse('''x = 1'''), ast.parse('''x = 2''')]
    )
    assert tree == [
        ast.parse('x = 1'),
        ast.parse('x = 2'),
        ast.parse('return x')
    ]

test_extend()

# Generated at 2022-06-21 18:42:30.872261
# Unit test for method visit_Attribute of class VariablesReplacer

# Generated at 2022-06-21 18:42:34.952601
# Unit test for function let
def test_let():
    @snippet
    def snippet(x: int):
        x += 1

    assert(str(snippet) == 'def snippet(_py_backwards_x_0: int):\n    _py_backwards_x_0 += 1')


# Generated at 2022-06-21 18:42:41.647942
# Unit test for function find_variables
def test_find_variables():
    code = """
    def foo(x, y, z=1):
        let(x)
        let(y)
        let(z)
    
        x += 1
        y = 1
        '''
        docstring
        '''
        z = 1
    """

    tree = ast.parse(code)
    variables = list(find_variables(tree))
    assert variables == ['x', 'y', 'z']

# Generated at 2022-06-21 18:42:48.425068
# Unit test for function extend_tree
def test_extend_tree():
    code = """
    extend(vars1)
    extend(vars2)
    extend(vars3)
    """
    tree = ast.parse(code)
    vars1 = ast.Assign([ast.Name(id="a", ctx=ast.Store())], ast.Num(1))
    vars2 = ast.Assign([ast.Name(id="b", ctx=ast.Store())], ast.Num(2))
    vars3 = ast.Assign([ast.Name(id="c", ctx=ast.Store())], ast.Num(3))
    variables = {'vars1': vars1, 'vars2': vars2, 'vars3': vars3}
    extend_tree(tree, variables)
    result = ast.dump(tree)
    expected = ast.dump

# Generated at 2022-06-21 18:42:59.004951
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    def test_function():
        from foo.bar.baz import spam, eggs

        spam, eggs
        spam, eggs
        spam, eggs
        spam, eggs
        spam, eggs

    variables = {'spam': VariablesGenerator.generate('spam'), 'eggs': VariablesGenerator.generate('eggs')}
    tree = ast.parse(test_function)
    tree = VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-21 18:43:02.440057
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x, y):
        let(x)
        extend(y)

    x = 1
    y = [ast.Pass()]
    result = test.get_body(x=x, y=y)
    assert len(result) == 1
    assert result == y



# Generated at 2022-06-21 18:43:15.390093
# Unit test for constructor of class snippet
def test_snippet():
    def first():
        print('Hello')
        let(x)
        x = 1
        let(y)
        extend(vars)
        y = 2

    def second():
        print('World')
        let(y)
        y = 1

    assert snippet(second).get_body() == snippet(first).get_body(
        vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                         value=ast.Num(n=2))])

# Generated at 2022-06-21 18:43:25.199480
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    from .tree import build_ast
    import ast
    import inspect
    import textwrap

    # We want to test a method of a class, so we need to get the class
    # object by looking at the module
    module = inspect.getmodule(VariablesReplacer)
    assert module.__name__ == 'py_backwards.replacers'
    class_obj = getattr(module, 'VariablesReplacer')
    # Now we instantiate a class object to call methods from it
    class_inst = class_obj(dict())

    # The input for this test is a class definition that looks like
    # this:
    #
    # class Class_Name(Class_0, Class_1):
    #     pass
    #
    # The class' name and the name of the base classes are all
    # variables. The name of the class

# Generated at 2022-06-21 18:43:32.286365
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int) -> None:
        let(x)
        let(y)
        x += y
    
    tree = snippet(test_fn).get_body(x=1, y=2)
    assert str(tree) == "[Assign(targets=[Name(id='_py_backwards_x_0', ctx=Store())], value=BinOp(left=Name(id='_py_backwards_x_0', ctx=Load()), op=Add(), right=Name(id='_py_backwards_y_1', ctx=Load())))]"



# Generated at 2022-06-21 18:43:40.264320
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse(
"""
from functools import partial, reduce
""")
    from .tree import find
    new_name = 'new_name'
    new_body = ast.parse(
        new_name + ' = '+ '1').body[0]
    variables = {
        'functools': new_body
    }
    result = VariablesReplacer.replace(tree, variables)
    assert result.body[0].module == new_name


# Generated at 2022-06-21 18:43:46.279475
# Unit test for constructor of class snippet
def test_snippet():
    # pylint: disable=too-few-public-methods
    class Foo:
        pass

    f = snippet(lambda x: Foo())
    assert f.get_body() == [ast.Expr(ast.Call(func=ast.Name(id='Foo', ctx=ast.Load()), args=[], keywords=[], starargs=None, kwargs=None))]



# Generated at 2022-06-21 18:43:52.488702
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    from .parser import Parser
    from .generator import Generator
    source = '''
        class Abc:
            def foo():
                pass
    '''

    class_ = Parser(source).parse().body[0]
    class_ = VariablesReplacer.replace(class_, {'Abc': 'Def'})
    assert Generator().generate(class_) == '''
        class Def:
            def foo():
                pass
    '''

# Generated at 2022-06-21 18:43:54.195203
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    assert VariablesReplacer.visit_Name(ast.Name(), '') == ast.Name()


# Generated at 2022-06-21 18:43:55.784686
# Unit test for constructor of class snippet
def test_snippet():
    with pytest.raises(NotImplementedError):
        snippet.__init__(1)


# Generated at 2022-06-21 18:43:59.558420
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    def foo():
        bar(1)
    variables = {
        'bar': 'a'
    }
    tree = ast.parse(get_source(foo))
    VariablesReplacer.replace(tree, variables)
    assert type(tree.body[0].body[0].value.func) is ast.Name
    assert tree.body[0].body[0].value.func.id == 'a'


# Generated at 2022-06-21 18:44:05.486604
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class TestClass():
        pass

    class TestClass2():
        pass

    tree = ast.parse('class TestClass:\n    pass')
    replacer = VariablesReplacer({'TestClass': TestClass2})
    replacer.visit(tree)
    assert TestClass.__name__ == TestClass2.__name__


# Generated at 2022-06-21 18:44:18.131625
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    def assert_statements(statements, code):
        assert ast.unparse(statements).strip() == code.strip()

    def assert_code(origin, target):
        tree = ast.parse(origin)
        new_statements = VariablesReplacer.replace(tree.body, {'a': 'b'}).body
        assert_statements(new_statements, target)

    assert_code('import a', 'import b')
    assert_code('import a as b', 'import b as b')



# Generated at 2022-06-21 18:44:28.900148
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    info1 = ast.Name(
        id='info1',
        ctx=ast.Load()
    )
    info2 = ast.Name(
        id='info2',
        ctx=ast.Load()
    )
    info3 = ast.Name(
        id='info3',
        ctx=ast.Load()
    )
    info4 = ast.Name(
        id='info4',
        ctx=ast.Load()
    )
    info5 = ast.Name(
        id='info5',
        ctx=ast.Load()
    )
    info6 = ast.Name(
        id='info6',
        ctx=ast.Load()
    )

    # test code:
    #
    #   info1
    #   info2
    #   info3
    #   info

# Generated at 2022-06-21 18:44:34.465250
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    module = ast.parse("def a(x=y): pass")
    variables = {
        'y': ast.Name(
            ast.Load(),
            'z'
        )
    }

    VariablesReplacer.replace(module, variables)
    assert(isinstance(module.body[0].args.defaults[0], ast.Name))
    assert(module.body[0].args.defaults[0].id == 'z')

# Generated at 2022-06-21 18:44:35.540397
# Unit test for function extend_tree

# Generated at 2022-06-21 18:44:39.191663
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(a)
x = 1
""")
    variables = find_variables(tree)

    assert list(variables) == ['a']



# Generated at 2022-06-21 18:44:50.763991
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    import typed_ast.ast3 as ast
    class T(ast.NodeTransformer):
        _target = ''
        _result = ''
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            node = self._replace_field_or_node(node, 'name')
            node.name = self._result
            return node
        def _replace_field_or_node(self, node: ast.AST, field: str) -> ast.AST:
            value = getattr(node, field, None)
            if value in self._target:
                if isinstance(self._result, str):
                    setattr(node, field, self._result)
                elif all_types or isinstance(self._result, type(node)):
                    node = self._result
            return node

# Generated at 2022-06-21 18:44:59.031328
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class T(ast.NodeVisitor):
        def visit_arg(self, node: ast.arg):
            raise Exception("arg")

    d = {'x': '_py_backwards_x_0'}
    tree = ast.parse("def f(x): pass").body[0]
    assert all(isinstance(node, ast.Name) for node in ast.walk(tree))
    VariablesReplacer.replace(tree, d)
    T().visit(tree)

# Generated at 2022-06-21 18:45:10.472664
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import unittest
    import sys
    import ast

    class Test(unittest.TestCase):
        def test(self):
            import_from = ast.ImportFrom('import', [ast.alias('a.b', 'bb')], 1)
            ast.fix_missing_locations(import_from)
            v = {'a.b': 'a.c'}
            replace = VariablesReplacer(v)
            replace.visit_alias(import_from.names[0])
            self.assertEqual(import_from.names[0].name, 'a.c')

    suite = unittest.TestLoader().loadTestsFromTestCase(Test)
    result = unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 18:45:21.755511
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        let(y)
        x += 1
        y = 1

    body = snippet(test_snippet).get_body()
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)
    assert body == [
        ast.AugAssign(
            target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()),
            op=ast.Add(),
            value=ast.Num(n=1),
        ),
        ast.Assign(
            targets=[
                ast.Name(id='_py_backwards_y_0', ctx=ast.Store())
            ],
            value=ast.Num(n=1),
        ),
    ]

# Generated at 2022-06-21 18:45:22.380182
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:45:35.312253
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    node = ast.FunctionDef(name='test', body=[], args=ast.arguments(args=[], vararg=None, varargannotation=None, \
            kwarg=None, kwonlyargs=[], kwargannotation=None, defaults=[], kw_defaults=[]), decorator_list=[], \
            returns=None)
    node_visited = VariablesReplacer(variables = {'test': 'fake'}).visit(node)
    assert(node_visited.name == 'fake')


# Generated at 2022-06-21 18:45:37.738931
# Unit test for constructor of class snippet
def test_snippet():
    def func():
        pass
    assert snippet(func)


# Generated at 2022-06-21 18:45:42.803254
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    old_name = ast.Name(id="old_name", ctx=None)
    new_name = ast.Name(id="new_name", ctx=None)
    expected_result = ast.Name(id="new_name", ctx=None)
    result = VariablesReplacer.replace(old_name, {"old_name": new_name})
    assert result == expected_result



# Generated at 2022-06-21 18:45:49.470751
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""extend(vars)\nprint(b)""")
    vars = ast.parse("""x = 1\nx = 2""")
    extend_tree(tree, {'vars': vars})
    
    assert tree.body[0].body == [ast.parse('x = 1').body[0],
                                 ast.parse('x = 2').body[0],
                                 ast.parse('print(b)').body[0]]

# Generated at 2022-06-21 18:46:01.354957
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = '''
try:
    print("try something here")
except IndexError as err:
    print("except an exception here")
else:
    print("else?")
finally:
    print("finally")
'''

    tree = ast.parse(source)
    variables = find_variables(tree)
    replace_names = {name: VariablesGenerator.generate(name)
                     for name in variables}
    VariablesReplacer(replace_names).visit(tree)
    assert get_source(tree) == '''
try:
    print("try something here")
except IndexError as err_0:
    print("except an exception here")
else:
    print("else?")
finally:
    print("finally")
'''


# Generated at 2022-06-21 18:46:11.981952
# Unit test for function extend
def test_extend():
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    
    @snippet
    def test_extend_snippet():
        extend(vars)
        return x
    
    body = test_extend_snippet.get_body(vars=vars)
    assert body == vars + [ast.Return(value=ast.Name(id='x', ctx=ast.Load()))]



# Generated at 2022-06-21 18:46:15.695993
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('''
    def test(x):
        pass
    ''')
    replace_map = {'test': '_test'}
    inst = VariablesReplacer(replace_map)
    inst.visit(tree)
    assert tree.body[0].name == '_test'


# Generated at 2022-06-21 18:46:16.410455
# Unit test for function extend_tree

# Generated at 2022-06-21 18:46:26.821993
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    """
    Test visit_keyword method of class VariablesReplacer

    """
    class TestClass(VariablesReplacer):
        """
        Test class for testing method visit_keyword of class VariablesReplacer
        """
        def __init__(self):
            super().__init__(None)
        def visit_keyword(self, node):
            return node

    code = '''{ "a": a, "b": b }'''
    node = ast.parse(code)
    node_before = ast.dump(node)
    replacer_inst = TestClass()
    replacer_inst.visit(node)
    node_after = ast.dump(node)
    assert(node_before == node_after)

# Generated at 2022-06-21 18:46:38.551174
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    @snippet
    def s(x: int, **kwargs: int):
        return kwargs

    class F:
        x: int

    vars = {
        'x': 1,
        'kwargs': {
            'a': 1,
            'b': 2,
            'c': 3,
            'd': 4,
            'f': F
        }
    }

    tree = s.get_body(**vars)

# Generated at 2022-06-21 18:46:45.343902
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x = 0
    let(y)
    y = 1
    z = 2
    z += y
    """

    tree = ast.parse(source)
    assert find_variables(tree) == {'x', 'y'}



# Generated at 2022-06-21 18:46:55.213834
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .snippet import VariablesReplacer
    source = "import a.b as c"

    tree = ast.parse(source)
    variables = {'c': 'xyz'}
    node = VariablesReplacer.replace(tree, variables)

    assert node._fields == ('body', )
    assert node.body[0]._fields == ('module', 'names', 'level')
    assert node.body[0].module == 'a.b'
    assert node.body[0].names[0]._fields == ('name', 'asname')
    assert node.body[0].names[0].name == 'xyz'



# Generated at 2022-06-21 18:47:01.732826
# Unit test for constructor of class snippet
def test_snippet():
    source = "def foo(x):\n" \
             "    let(n)\n" \
             "    return n + x"
    tree = ast.parse(source)
    variables = {'n': VariablesGenerator.generate('n')}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].body[0].value.args[0].id == '_py_backwards_n_0'

# Generated at 2022-06-21 18:47:12.617464
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    # Regular function
    tree = ast.parse("""
        def hello(x):
            x = 1
    """)
    variables = {"x": "hello"}
    new_tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(new_tree) == ast.dump(tree) # type: ignore

    # Lambda function
    tree = ast.parse("""
        lambda x: 1
    """)
    variables = {"x": "hello"}
    new_tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(new_tree) == ast.dump(tree)  # type: ignore

    # Visitor function
    tree = ast.parse("""
        visitor.visit(x)
    """)
    variables = {"x": "hello"}
    new_tree = Variables

# Generated at 2022-06-21 18:47:18.673071
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    var = 'x'
    name = ast.Name(id=var)
    variables = {var: '_new'}
    result = VariablesReplacer.replace(name, variables)
    assert isinstance(result, ast.Name)
    assert result.id == variables[var]
    assert not isinstance(variables[var], ast.Name)


# Generated at 2022-06-21 18:47:26.617028
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: let(x)) \
        .get_body(x = [ast.BinOp(ast.Name(id='x', ctx=ast.Load()),
                                 ast.Add(),
                                 ast.Num(n=1))]) == \
        [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                    value=ast.BinOp(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                    ast.Add(),
                                    ast.Num(n=1)))
        ]

# Generated at 2022-06-21 18:47:32.337854
# Unit test for function let
def test_let():
    x = 1
    let(x)
    x += 1

    snippet(test_let).get_body() == [
        ast.AugAssign(target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()),
                      op=ast.Add(),
                      value=ast.Num(n=1))]



# Generated at 2022-06-21 18:47:38.050587
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():

    class Test:
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node = self._replace_field_or_node(node, 'name')
            return self.generic_visit(node)

    tree = ast.parse('class test:\n    pass')
    variables = {'test': 'test_new'}
    inst = Test()
    inst.visit(tree)
    assert 'class test_new:' == get_source(tree)




# Generated at 2022-06-21 18:47:44.377546
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    variable = "variable"
    node = ast.ExceptHandler()
    node.name = variable
    vars = {}
    vars[variable] = "Test"
    replacer = VariablesReplacer(vars)
    replacer.visit_ExceptHandler(node)
    assert node.name == "Test"

# Generated at 2022-06-21 18:47:54.115190
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    from py_backwards.tree import find
    from py_backwards.helpers import get_source
    from .tree import replace_at
    import astor
    
    def get_ast(source):
        tree = ast.parse(source)
        variables = {'f': VariablesGenerator.generate('f')}
        VariablesReplacer.replace(tree, variables)
        return tree

    def get_names(tree):
        return [node.id for node in find(tree, ast.Name)]
    
    def get_names_from_func_def(tree):
        return [node.name for node in find(tree, ast.FunctionDef)]
    
    ### test 1
    source = 'def func(): pass'
    actual = get_ast(source)
    expected_names = ['func']
    expected_names

# Generated at 2022-06-21 18:48:01.225768
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda x: let(x)).__doc__ == snippet.__doc__
    assert snippet(lambda x: let(x))._fn.__name__ == '<lambda>'
    assert snippet(lambda x: let(x)).__class__.__name__ == snippet.__name__
    return 'Snippet class is ok!'


# Generated at 2022-06-21 18:48:12.085156
# Unit test for function extend
def test_extend():
    from .tree import find, get_non_exp_parent_and_index, replace_at
    from .helpers import eager

    # first test:
    assignment = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1)
    )
    assignment2 = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=2)
    )
    assignment_list = [assignment, assignment2]

    # second test:
    assignment_list2 = [ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1)
    )]
    tree = ast.parse

# Generated at 2022-06-21 18:48:23.697268
# Unit test for method visit_alias of class VariablesReplacer

# Generated at 2022-06-21 18:48:35.542088
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    x = 1
    extend(vars)
    extend(vars2)
    x = 2
    z = 1
    z = 2
    """)

# Generated at 2022-06-21 18:48:37.782968
# Unit test for function let
def test_let():
    global _py_backwards_x_0, _py_backwards_x_0
    _py_backwards_x_0 = 1



# Generated at 2022-06-21 18:48:38.693582
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-21 18:48:43.546398
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = 'def f(x, y=1, z=2):\n    return z'
    tree = ast.parse(source)
    variables = {'z': 'a'}

    node = tree.body[0]
    assert isinstance(node, ast.FunctionDef)
    assert node.args.kwarg == 'z'

    node = VariablesReplacer.replace(tree, variables)
    source = get_source(node)
    assert source == 'def f(x, y=1, a=2):\n    return a'

# Generated at 2022-06-21 18:48:53.673454
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    code = '''
try:
    1/0
except ZeroDivisionError as e:
    print(e)
    '''
    tree = ast.parse(code)
    new_name = 'e_new'
    variables = {'e': new_name}
    VariablesReplacer.replace(tree, variables)
    print(ast.dump(tree))
    # Result:
    # Module(body=[Try(body=[Expr(value=BinOp(left=Num(n=1), op=Div(), right=Num(n=0)))],
    # handlers=[ExceptHandler(name='e_new', type=Name(id='ZeroDivisionError', ctx=Load()),
    # body=[Expr(value=Call(func=Name(id='print', ctx=Load()),
    # args=[Name(id

# Generated at 2022-06-21 18:48:54.552251
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:48:59.007589
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from ast import *")
    variables = {'ast' : 'ast3'}
    node = VariablesReplacer.replace(tree, variables)
    assert node.body[0].name == 'ast3'

# Generated at 2022-06-21 18:49:09.380246
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    from .test_helpers import compare_asts
    source = "x.y"
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, {"x.y": "z"})
    compare_asts(source, tree)


# Generated at 2022-06-21 18:49:14.058360
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    node_replacement = ast.Name(id='node_replacement', ctx=ast.Load())
    node = ast.arg(arg='node')
    node = VariablesReplacer.replace(node, {'node': node_replacement})
    assert node == node_replacement



# Generated at 2022-06-21 18:49:18.095884
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    node = ast.ExceptHandler(ast.Name('it', ast.Store()), None, None)
    variables = {'it': 'e'}
    inst = VariablesReplacer(variables)
    inst.visit_ExceptHandler(node)
    assert node.name == 'e'



# Generated at 2022-06-21 18:49:27.405287
# Unit test for function let
def test_let():
    snippet_1 = snippet(lambda x: None)
    snippet_2 = snippet(lambda x: None)
    snippet_3 = snippet(lambda x: None)

    source_1 = get_source(snippet_1.get_body)
    source_2 = get_source(snippet_2.get_body)
    source_3 = get_source(snippet_3.get_body)

    code_1 = get_source(snippet_1._fn)
    code_2 = get_source(snippet_2._fn)
    code_3 = get_source(snippet_3._fn)

    assert source_1 != source_2 != source_3
    assert code_1 == code_2 == code_3


if __name__ == '__main__':
    test_let()

# Generated at 2022-06-21 18:49:37.807256
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    """
    Tests the method visit_ImportFrom of class VariablesReplacer with input:
    module = 'foo.bar'
    variables = {'foo': '_py_backwards_foo_0',
                 'bar': '_py_backwards_bar_0'}
    """
    module = 'foo.bar'
    variables = {'foo': '_py_backwards_foo_0',
                 'bar': '_py_backwards_bar_0'}

    expr = ast.parse(f'from foo import bar').body[0]


# Generated at 2022-06-21 18:49:42.139366
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
     src = """
try:
    x = 1
except Exception:
    x = 3
     """
     exceptHandler = ast.parse(src).body[0].handlers[0]
     assert(isinstance(exceptHandler, ast.ExceptHandler))
     assert(isinstance(VariablesReplacer.replace(exceptHandler, {'x': 'y'}), ast.ExceptHandler))

# Generated at 2022-06-21 18:49:42.605833
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet
    snippet

# Generated at 2022-06-21 18:49:52.589784
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .test_snippets import string_1
    from .helpers import extract_tree_from_fn
    original_tree = extract_tree_from_fn(string_1)
    alias0 = original_tree.body[1].names[0]
    alias0.name = 'alias0name'
    alias0.asname = 'alias0asname'
    new_tree = VariablesReplacer.replace(original_tree, {'alias0asname': alias0})
    assert new_tree.body[1].names[0].name == new_tree.body[1].names[1].name

# Generated at 2022-06-21 18:49:58.026989
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    code = "try:\n    pass\nexcept: pass"
    tree = ast.parse(code)
    replacer = VariablesReplacer({"except": "Exception"})
    replacer.visit(tree)
    assert code == ast.dump(tree)

# Generated at 2022-06-21 18:50:07.641995
# Unit test for function extend
def test_extend():
    source = """
        extend(vars)
        print(x, y)
    """

    tree = ast.parse(source)
    vars = [
        ast.Assign(
            targets=[ast.Name(
                id='x', ctx=ast.Load()
            )],
            value=ast.Num(n=1),
        ),
        ast.Assign(
            targets=[ast.Name(
                id='x', ctx=ast.Load()
            )],
            value=ast.Num(n=2),
        ),
        ast.Assign(
            targets=[ast.Name(
                id='y', ctx=ast.Load()
            )],
            value=ast.Num(n=3),
        )
    ]
    extend_tree(tree, {'vars': vars})


# Generated at 2022-06-21 18:50:37.786611
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A:
        pass


# Generated at 2022-06-21 18:50:47.650708
# Unit test for function extend
def test_extend():
    def test() -> None:
        x = 'foo'
        extend(vars)
        print(x)
        
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                        value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                        value=ast.Num(n=2))]
    body = snippet(test).get_body(vars=vars)

# Generated at 2022-06-21 18:50:49.727304
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    assert VariablesReplacer.replace(
        ast.parse('class A: pass').body[0], {'A': 'B'}).name == 'B'

# Generated at 2022-06-21 18:50:59.792650
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    # Arrange
    variables = {
        'a': ast.FunctionDef(
            name='_var_a',
            args=ast.arguments(
                args=[ast.arg(arg='x', annotation=None)],
                vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]
            ),
            body=[ast.Expr(value=ast.Num(n=1))],
            decorator_list=[], returns=None
        )
    }

# Generated at 2022-06-21 18:51:09.821167
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    test_value_1 = ast.parse("""def test(arg1, arg2):
        res = arg1 + arg2
        return arg1 + arg2
    """).body[0]
    test_value_2 = ast.parse("""def test():
        res = var1 + var2
        return var1 + var2
    """).body[0]
    test_value_3 = ast.parse("""def test2(arg1, arg2):
        res = var1 + var2
        return var1 + var2
    """).body[0]
    test_value_4 = ast.parse("""def test(var1, var2):
        res = var1 + var2
        return var1 + var2
    """).body[0]

# Generated at 2022-06-21 18:51:19.478909
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    snippet = ast.parse("""
    for k, v in [("a", 1), ("b", 2)]:
        print(k, v)
    """)
    VariablesReplacer.replace(snippet, {"k": "kek"})

# Generated at 2022-06-21 18:51:24.457497
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('x = 1\nprint(42)\nx = 2')
    extend_tree(tree, {
        'vars': [
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))
        ]
    })

    assert get_source(tree) == 'x = 1\nx = 2\nprint(42)'

# Generated at 2022-06-21 18:51:30.506815
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    def fn():
        extend(imports)
        x = 1
    """)
    imports = ast.parse("""
    import abc
    import def
    """).body
    extend_tree(tree, {'imports': imports})
    assert tree.body[0].body == [imports[0], imports[1], ast.parse("""
    x = 1
    """).body[0]]



# Generated at 2022-06-21 18:51:31.037934
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    pass

# Generated at 2022-06-21 18:51:37.413588
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class ExceptHandlerTestVariablesReplacer(VariablesReplacer):
        def visit_ExceptHandler(self, node: Union[ast.ExceptHandler, List[ast.ExceptHandler]]) -> Union[ast.ExceptHandler, List[ast.ExceptHandler]]:
            return node

    try:
        code = """
        x = 1
        try:
            pass
        except Exception:
            x += 1
        """
        tree = ast.parse(code)
        variables = dict(x='_x_0')
        inst = ExceptHandlerTestVariablesReplacer(variables)
        inst.visit(tree)
    except Exception as e:
        assert False