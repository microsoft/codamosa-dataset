

# Generated at 2022-06-23 23:43:02.028313
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import ast
    import typing
    from py_backwards.transformers.variables import VariablesReplacer
    value1: typing.Any = None
    value2: typing.Any = None
    value3: typing.Any = None
    value4: typing.Any = None
    value5: typing.Any = None
    value6: typing.Any = None
    value7: typing.Any = None
    value8: typing.Any = None
    value9: typing.Any = None
    value10: typing.Any = None
    value11: typing.Any = None
    value12: typing.Any = None
    value13: typing.Any = None
    value14: typing.Any = None
    value15: typing.Any = None
    value16: typing.Any = None
    value17: typing.Any = None
    value18

# Generated at 2022-06-23 23:43:06.512280
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from . import snippet  # import local version of snippet
    with snippet.snippet(lambda: None) as snippet_:
        assert snippet_ is snippet
        let(True)
        assert [type(x) for x in snippet_] == [ast.Assign, ast.Expr]

import unittest

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-23 23:43:15.039596
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    source = """
    def f(x: int) -> float:
        return x
    """
    tree = ast.parse(source)
    variables = {'f': VariablesGenerator.generate('f')}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert tree.body[0].name == '_py_backwards_f_0'
    assert tree.body[0].args.args[0].arg == '_py_backwards_x_0'
    assert tree.body[0].returns.id == 'float'



# Generated at 2022-06-23 23:43:25.815803
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    code = """
        let(var)
        var.append(1)
        var = 1
        var += 1
        y = 1
        """
    tree = ast.parse(code)
    variables = {'var': ast.Name(id='unique_0_var', ctx=ast.Store())}
    VariablesReplacer.replace(tree, variables)
    expected_code = """
        unique_0_var.append(1)
        unique_0_var = 1
        unique_0_var += 1
        y = 1
        """
    compare_code = compile(tree, filename='<ast>', mode='exec')  # type: ignore
    assert(expected_code == compare_code.co_code.decode(encoding='UTF-8'))



# Generated at 2022-06-23 23:43:34.357403
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    variables = {'x': 'y'}
    class LambdaClass:
        def __init__(self):
            self.func = ast.Lambda(args=ast.arguments(args=[ast.arg(arg='x', annotation=None)],
                                                     vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None,
                                                     defaults=[]),
                                   body=ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                                                                args=[ast.Name(id='x', ctx=ast.Load())],
                                                                keywords=[])),
                                   returns=None)
    tree = LambdaClass()
    inst = VariablesReplacer(variables)
    inst.visit(tree)

# Generated at 2022-06-23 23:43:43.925983
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    code = 'def f(x): return x'
    tree = ast.parse(code)
    replacer = VariablesReplacer({'x': 'y'})
    replacer.visit(tree)
    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=\'f\', args=arguments(args=[arg(arg=\'y\', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Name(id=\'y\', ctx=Load()))], decorator_list=[], returns=None)])'


# Generated at 2022-06-23 23:43:47.268747
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("x = 'test'; print(x)")
    variables = {
        'x': 'test'
    }
    assert VariablesReplacer.replace(tree, variables) == ast.parse("test = 'test'; print(test)")

# Generated at 2022-06-23 23:43:54.211706
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""\
    extend(vars)
    print(a, b)
    """)  # type: ignore
    vars = ast.Module([
        ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.Num(n=1)),
        ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.Num(n=2)),
    ])
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""\
    a = 1
    a = 2
    print(a, b)
    """))  # type: ignore



# Generated at 2022-06-23 23:43:55.429256
# Unit test for function extend_tree

# Generated at 2022-06-23 23:44:05.487471
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    #Tests if the name a is replaced by b in the assignment a = 2 .
    tree = ast.parse('a = 2')
    variables: Dict[str, Variable] = {'a':'b'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert(str(tree) == 'b = 2')

    #Tests if the name a is replaced by b in the function call f(a) .
    tree = ast.parse('f(a)')
    variables: Dict[str, Variable] = {'a':'b'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert(str(tree) == 'f(b)')

    #Tests if the name a is replaced by b in the function call f(a,b

# Generated at 2022-06-23 23:44:09.430705
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import3 = ast.Import([ast.alias("a", None)], 1, 1)
    expected = ast.Import([ast.alias("a", None)], 1, 1)
    actual = VariablesReplacer.replace(
        import3, {"a": ast.alias("b", None)})
    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-23 23:44:13.885263
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    tree = ast.parse(
        """
        class A():
            def __init__(self, a):
                self.a = a
        A(1)
        """
    )
    result = VariablesReplacer.replace(tree, {'A': 'B'})
    assert isinstance(result.body[0], ast.ClassDef)
    assert result.body[0].name == 'B'
    assert isinstance(result.body[1], ast.Call)
    assert result.body[1].func.id == 'B'



# Generated at 2022-06-23 23:44:19.384469
# Unit test for function extend
def test_extend():
    class F:
        pass
    f = F()
    f.x = 0
    f.y = 0
    def fn():
        let(x=1)
        let(y=2)
        extend(_)
        f.x += x
        f.y += y
    fn()
    assert f.x == 1
    assert f.y == 2


# Generated at 2022-06-23 23:44:30.226804
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A:
        def replace_field_or_node_module(self, node1: ast.Name, field: str, all_types=False) -> ast.Name:
            return node1

        def replace_field_or_node_class(self, node2: ast.ClassDef, field: str, all_types=False) -> ast.ClassDef:
            return node2

        def replace_module(self, module: str) -> str:
            return module

        def _replace_node(self, node: ast.ClassDef) -> ast.ClassDef:
            node = self.replace_field_or_node_module(node, 'id', all_types=True)
            node = self.replace_field_or_node_class(node, 'name')
            return node

    a = A()

# Generated at 2022-06-23 23:44:32.605665
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse("""def p(x):\n    return x * x\n""")
    v = VariablesReplacer.replace(tree, {"p": "p"})
    assert v is not tree



# Generated at 2022-06-23 23:44:36.388925
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    d1 = {"name": "z"}
    d2 = {"name": "y"}
    d3 = {}
    body = snippet(snippet_function).get_body(x=d1, y=d2, z=d3)
    assert body == snippet_function.__closure__[0].cell_contents.body


# Generated at 2022-06-23 23:44:46.173844
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # Given
    import_1 = "from x import y"
    import_2 = "from z import y as a"
    target = ast.parse(import_1)
    target_2 = ast.parse(import_2)

    replace_dict = {'x': 'm', 'z': 'n', 'y': 'o'}

    # When
    transformed = VariablesReplacer.replace(target, replace_dict)
    transformed_2 = VariablesReplacer.replace(target_2, replace_dict)

    # Then
    assert str(transformed) == 'from m import o'
    assert str(transformed_2) == 'from n import o as a'

# Generated at 2022-06-23 23:44:55.037014
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def test(x: int, y: int = 1) -> int:
        let(x)
        x += 1
        y = 1
        return x + y
    assert test.get_body(x=2) == test.get_body()

# Generated at 2022-06-23 23:44:55.956153
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:45:06.550996
# Unit test for function extend
def test_extend():
    @snippet
    def code():
        extend(vars)
        print(a, b)

    vars = {"a": 1, "b": 2}


# Generated at 2022-06-23 23:45:07.549114
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:45:13.152940
# Unit test for function extend
def test_extend():
    def foo(n: int) -> int:
        if extend(vars):
            x = 1
            x = 2
        print(x)
        return x

    assert foo(1) == 2
    assert foo.__code__.co_code == b'd\x01\x00d\x00S\x00'
    assert foo(2) == 2



# Generated at 2022-06-23 23:45:22.754035
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    node = ast.parse(
        """
import x.y
sqrt = x.y.sqrt
print(sqrt(4))
""").body[2].value.elts[0]  # type: ignore
    variables = {
        'x.y': ast.parse('y.x', mode='eval').body,
        'sqrt': ast.parse('(lambda x: x*x)', mode='eval').body
    }
    VariablesReplacer.replace(node, variables)
    assert ast.dump(node) == ast.dump(ast.parse('''
((lambda y: (lambda x: x*x))(y.x)).sqrt(4)
'''))



# Generated at 2022-06-23 23:45:23.404757
# Unit test for function extend
def test_extend():
    assert extend(vars)


# Generated at 2022-06-23 23:45:28.741011
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class test(ast.NodeTransformer):
        def __init__(self, variables: Dict[str, Variable]) -> None:
            self._variables = variables

        def visit_ExceptHandler(self, node: ast.ExceptHandler) -> ast.ExceptHandler:
            node = self._replace_field_or_node(node, 'name')
            return self.generic_visit(node)  # type: ignore

    variables = {'x': '_py_backwards_x_0'}

    node = ast.ExceptHandler(body=['try'], name='x')
    expected_node = ast.ExceptHandler(body=['try'], name='_py_backwards_x_0')
    inst = test(variables)
    actual = inst.visit_ExceptHandler(node)
    assert actual == expected_node

# Generated at 2022-06-23 23:45:33.591233
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    # Function declaration
    def test_function():
        try:
            a=b
        except IndexError as e:
            c=d


    # Parse source code of function
    tree = ast.parse(get_source(test_function))

    # Replace 'except' handler
    replacer = VariablesReplacer({'e': 'new_e'})
    replacer.visit(tree)

    # Check that target code is a same
    assert(get_source(tree) == get_source(test_function))

# Generated at 2022-06-23 23:45:39.673829
# Unit test for method get_body of class snippet

# Generated at 2022-06-23 23:45:48.482853
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse("let(x)"))) == ['x']
    assert list(find_variables(ast.parse("let(x)\nlet(y)"))) == ['x', 'y']
    assert list(find_variables(ast.parse("let(x)\nlet(y)\nx"))) == ['x', 'y']
    assert list(find_variables(ast.parse("let(x)\nlet(y)\nx + y"))) == ['x', 'y']
    assert list(find_variables(ast.parse("let(x)\nlet(y)\nx + y.x"))) == ['x', 'y']
    assert list(find_variables(ast.parse("let(x)\nlet(y)\nx + let(y)"))) == ['x', 'y']

# Generated at 2022-06-23 23:45:52.099737
# Unit test for constructor of class snippet
def test_snippet():
    import random

    def sample_fn(x: int) -> int:
        let(a=random.randint(1, 10))
        return a + x

    s = snippet(sample_fn)
    assert s is not None

# Generated at 2022-06-23 23:45:55.868779
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("a, b, c")

    vars = {"a": "d", "b": "e", "c": "f"}
    expected = ast.parse("d, e, f")
    assert VariablesReplacer.replace(tree, vars) == expected

# Generated at 2022-06-23 23:46:07.179462
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import sys
    import tempfile
    import ast
    from _py_backwards import variables_replacer
    from astunparse import unparse

    try:
        raise RuntimeError()
    except Exception as e:
        exc_info = sys.exc_info()
        typ, value, tb = exc_info
        tree = ast.parse(
            "except Exception as replaced_name:\n"
            "    pass"
        )

        variables_replacer.VariablesReplacer.replace(tree, {
            "replaced_name": ast.Name(id="new_name", ctx=ast.Store())
        })

        with tempfile.NamedTemporaryFile(suffix='.py', mode='w+') as f:
            f.write(unparse(tree))
            f.seek(0)


# Generated at 2022-06-23 23:46:14.426607
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    source = "x.y.z"
    variables = {"x": "v"}
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, variables)
    src = ast.unparse(tree)
    assert src == "v.y.z"

    variables = {"x.y.z": "v"}
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, variables)
    src = ast.unparse(tree)
    assert src == "v"

    variables = {"x.y.z": "v.y"}
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, variables)
    src = ast.unparse(tree)
    assert src == "v.y"

# Generated at 2022-06-23 23:46:24.691246
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    m = ast.Module([
        ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.Call(
                func=ast.Attribute(
                    value=ast.Name(id='b', ctx=ast.Load()),
                    attr='c', ctx=ast.Load()),
                args=[],
                keywords=[],
                starargs=None,
                kwargs=None)
        )
    ])
    variables = {
        'b': ast.Name(id='b', ctx=ast.Load()),
        'b.c': ast.Name(id='b.c', ctx=ast.Load())
    }
    VariablesReplacer.replace(m, variables)

# Generated at 2022-06-23 23:46:34.045878
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class FunctionDefVisitor(ast.NodeVisitor):
        def __init__(self):
            self.body_count = 0

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            self.body_count += len(node.body)

    # Test for len(node.body) == 0
    ast_node = ast.parse("def foo(x: int) -> int: pass")
    visitor = FunctionDefVisitor()

# Generated at 2022-06-23 23:46:39.163864
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("""x, y = a, b""")
    variables = {"a": "c", "b": "d", "x": "e"}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert str(tree) == "e, y = c, d"



# Generated at 2022-06-23 23:46:45.371975
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    src = """
        foo(a,b)
        """
    tree = ast.parse(src)
    variables = {'a': 1, 'b': 2}
    VariablesReplacer.replace(tree, variables)
    assert(str(ast.dump(tree)) == """
        Expr(value=Call(func=Name(id='foo', ctx=Load()), args=[Num(n=1), Num(n=2)], keywords=[], starargs=None, kwargs=None))
        """)



# Generated at 2022-06-23 23:46:55.990773
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    snippets_source = get_source(test_VariablesReplacer)
    snippets_tree = ast.parse(snippets_source)
    snippets_body = snippets_tree.body[0].body
    variables = {'x': VariablesGenerator.generate('x'),
                 'y': VariablesGenerator.generate('y'),
                 'z': VariablesGenerator.generate('z')}
    VariablesReplacer.replace(snippets_body, variables)
    print(ast.dump(snippets_body, include_attributes=False))
    # [FunctionDef(name='snippets', args=arguments(args=[arg(arg='x', annotation=None), arg(arg='y', annotation=None), arg(arg='z', annotation=None)], vararg=arg(arg=None, annotation=None), k

# Generated at 2022-06-23 23:47:03.405527
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda x: let(x))
    assert s.get_body(x=3) == [ast.Expr(ast.Call(ast.Name('let', ast.Load()), [ast.Num(3)], [], None, None))]
    assert get_source(s.get_body) == 'x = 3'

    s = snippet(lambda x: let(x) + let(x))
    assert get_source(s.get_body) == 'x = x + x'

    s = snippet(lambda x: let(x) + let(x) * 2)
    assert get_source(s.get_body) == 'x = x + (x * 2)'

    s = snippet(lambda x: let(x[1]))

# Generated at 2022-06-23 23:47:10.554755
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    source = """
    def test(x):
        extend(vars)
        print(x, y)
        print(x, y)
    """
    snippet_tree = ast.parse(source)
    variables = find_variables(snippet_tree)
    extend_tree(snippet_tree, variables)
    VariablesReplacer.replace(snippet_tree, variables)
    assert ast.dump(source) == ast.dump(snippet_tree)

# Generated at 2022-06-23 23:47:15.710747
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source = """
        v = 1
        if v:
            print('ok')
        """
    tree = ast.parse(source)
    variables = {"v": "VAR"}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == """
        VAR = 1
        if VAR:
            print('ok')
        """


# Generated at 2022-06-23 23:47:16.879184
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:47:27.643042
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    v0 = ast.Name(id='test', ctx=ast.Load())
    v1 = ast.Name(id='test1', ctx=ast.Load())
    v2 = ast.Name(id='test2', ctx=ast.Load())
    v3 = ast.Name(id='test3', ctx=ast.Load())
    v4 = ast.Name(id='test4', ctx=ast.Load())
    v5 = ast.Name(id='test5', ctx=ast.Load())

    vars = {
        'test': v1,
        'test1': v2,
        'test2': v3,
        'test3': v4,
        'test4': v5,
        'test5': v0
    }

    # name = ast.Name()
    # alias =

# Generated at 2022-06-23 23:47:31.498932
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(test)
    let(test2)
    let(test3)
    let(test4)
    '''
    assert find_variables(ast.parse(source)) == ['test', 'test2', 'test3', 'test4']



# Generated at 2022-06-23 23:47:40.786139
# Unit test for function extend
def test_extend():
    source = """
    extend(vars)
    print(x, y)
    """
    tree = ast.parse(source)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})

    expected = ast.parse(
        "x = 1; x = 2; print(x, y);").body

    assert expected == tree.body


# Generated at 2022-06-23 23:47:42.853257
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    """Tests for VariablesReplacer class"""

# Generated at 2022-06-23 23:47:50.814639
# Unit test for function find_variables
def test_find_variables():
    source = get_source(find_variables)
    tree = ast.parse(source)
    variables: Dict[str, Variable] = {}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert len(tree.body) == 1
    assert 'state' not in tree.body[0].body[0].targets[0].id
    assert 'v' not in tree.body[0].body[0].targets[1].id
    assert 'n' not in tree.body[0].body[0].targets[2].id



# Generated at 2022-06-23 23:47:54.478498
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class A(ast.ast3.NodeTransformer):
        def visit_keyword(self, node):
            return node

    node = ast.keyword(arg='x', value='')

    assert node is A().visit(node)

# Generated at 2022-06-23 23:48:00.654895
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('class A(B):\n    pass')
    variables = {'B': 'C'}
    tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "ClassDef(name='A', bases=[Name(id='C', ctx=Load())], keywords=[], body=[Pass()], decorator_list=[])"



# Generated at 2022-06-23 23:48:11.122761
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""\
print(x, y)
extend(vars)
print(y, x)
""")

    var_names = ['x', 'y']
    variables = {name: VariablesGenerator.generate(name) for name in var_names}
    extend_tree(tree, variables)

# Generated at 2022-06-23 23:48:17.534348
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    """Unit test for VariablesReplacer."""
    src = """
    x = y + 1
    """
    tree = ast.parse(src)
    vr = VariablesReplacer({'y': 'x', 'x': '_x'})
    # pylint: disable=protected-access
    tree = vr.visit(tree)
    assert get_source(tree) == "_x = x + 1\n"

# Generated at 2022-06-23 23:48:22.747134
# Unit test for function let
def test_let():
    @snippet
    def f() -> None:
        let(x)
        x += 1
        y = 1
        x += 1
        y += 1

    body = f.get_body()
    assert body == ast.parse('_py_backwards_x_0 += 1; y = 1; _py_backwards_x_0 += 1; y += 1').body


# Generated at 2022-06-23 23:48:28.830450
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def snippet(x: int) -> int:
        let(x)
        def f() -> int:
            return x
        return f()

    assert ast.dump(snippet.get_body()) == "FunctionDef(name='_py_backwards_x_0', " \
                                          "args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], " \
                                          "kwarg=None, defaults=[]), body=[Return(_py_backwards_x_0)], " \
                                          "decorator_list=[])"



# Generated at 2022-06-23 23:48:29.853116
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:48:37.218428
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class TestVisitor(VariablesReplacer):
        def visit_Name(self, node):
            node = self._replace_field_or_node(node, 'id', True)
            return node

    tree = ast.parse("def f(x):\n    print(x)")
    variables = {"x": ast.Name(id='y', ctx=ast.Load())}
    TestVisitor.replace(tree, variables)

    assert tree.body[0].args.args[0].arg == "y"

# Generated at 2022-06-23 23:48:44.028288
# Unit test for function let
def test_let():
    def test1():
        let(x)
        let(x)
        let(x)
        assert x + 1 == 1

    def test2():
        let(y)
        x = y
        assert x == y

    def test3():
        let(z)
        let(y)
        x = y
        assert x == z + y



# Generated at 2022-06-23 23:48:54.142583
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet():
        let(x)
        let(y)
        x += 1
        y = 1

    expected_source = '\n'.join([
        '_py_backwards_x_0 += 1',
        '_py_backwards_y_0 = 1',
    ])

    body = snippet.get_body()
    assert expected_source == ast.unparse(body)

    def snippet2():
        let(x)
        x += 1

    expected_source = '_py_backwards_x_0 += 1'

    body = snippet2.get_body()
    assert expected_source == ast.unparse(body)

    def snippet3():
        let(x)
        let(y)
        z = x + y


# Generated at 2022-06-23 23:49:00.551223
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    import sys
    tree = ast.parse("from math import cos")
    variables = {"math" : "sys"}
    inst = VariablesReplacer.replace(tree, variables)
    assert inst.body[0].module == "sys"



# Generated at 2022-06-23 23:49:06.255221
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    # Case 1
    test_node = ast.Name(id="test", ctx=ast.Load())
    variables = {test_node.id: VariablesGenerator.generate("test_variable")}
    assert VariablesReplacer.replace(test_node, variables).id == variables["test"]

    # Case 2
    test_node = ast.Name(id="test", ctx=ast.Load())
    variables = {test_node.id: ast.Name(id="test_variable", ctx=ast.Load())}
    assert VariablesReplacer.replace(test_node, variables).id == variables["test"].id

    # Case 3
    test_node = ast.Name(id="test", ctx=ast.Load())
    variables = {test_node.id: ("test_variable", "qwerty")}


# Generated at 2022-06-23 23:49:13.860999
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Test:
        def __init__(self):
            self.field = 0
        def func(self):
            return self.field

    source = get_source(Test)
    source = source.replace('(self):', '(abc):')
    tree = ast.parse(source)
    variables = {'abc': 'self'}
    tree = VariablesReplacer.replace(tree, variables)
    replace_at(1, tree.body[0].body, variables['abc'])  # type: ignore
    ev = ast.Expression(tree.body[0].body[0])
    code = compile(ast.fix_missing_locations(ev), '', 'eval')
    assert eval(code) == 0



# Generated at 2022-06-23 23:49:19.594191
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class MockAstAlias(ast.alias):
        def __init__(self, name: str, asname: str = None):
            self.name = name
            self.asname = asname
            self.__class__ = ast.alias

    alias_example = MockAstAlias('import.name', 'asname')
    VariablesReplacer.replace(alias_example, {'import': 'import_new'})
    assert alias_example.name == 'import_new.name'
    assert alias_example.asname == 'asname'

# Generated at 2022-06-23 23:49:24.139996
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    # Given
    tree = ast.parse('print(x, y, z)')
    variables = [ast.arg(arg='_x'), ast.arg(arg='_y')]
    # When
    for node in find(tree, ast.Name):
        node.id = node.id + '_0'
    # Then
    assert(get_source(tree) == 'print(_x_0, _y_0, z_0)')

# Generated at 2022-06-23 23:49:30.382518
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('from pkg import x, y as z')
    variables = {'x': 'y',
                 'y': 'z',
                 'z': 'u'}
    VariablesReplacer.replace(tree, variables)
    body = tree.body[0]
    assert isinstance(body, ast.ImportFrom)
    assert body.module == 'pkg'
    assert len(body.names) == 2
    assert body.names[0].name == 'z'
    assert body.names[0].asname is None
    assert body.names[1].name == 'u'
    assert body.names[1].asname == 'z'

# Generated at 2022-06-23 23:49:38.598475
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Declares variables
    x = ast.Name(id='x')

    def test_snippet(a: int, b: str, c: ast.AST,
                     d: int = 1, e: str = '', f: ast.AST = y) -> None:
        # Code of snippet
        pass

    snippet_code = snippet(test_snippet).get_body(
        a=x, b='', c=y, f=z)

    # Checks if snippet code contains only assignments
    for node in snippet_code:
        assert isinstance(node, ast.Assign)

    # Checks if values of variables are unique
    for node in find(snippet_code, ast.Name):
        assert '_py_backwards_' in node.id

    # Checks if variable c is replaced

# Generated at 2022-06-23 23:49:45.451551
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test get_body method of class snippet."""
    import typing
    import inspect

    example_body_source = inspect.getsource(test_snippet_get_body)
    example_body_source = example_body_source[
        example_body_source.find('"""') + len('"""'):
        example_body_source.rfind('"""')
    ]
    example_body_source = example_body_source.replace(
        'example_body_source', 'source')

# Generated at 2022-06-23 23:49:54.869677
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    varname = "var"

    def make_var_decl(name):
        return ast.arg(name, None)

    def make_test_tree(varname):
        return ast.FunctionDef(name=varname, args=ast.arguments(args=[ast.arg(varname, None)]),
                               body=[ast.Return(value=ast.Name(id=varname, ctx=ast.Load()))],
                               decorator_list=[], returns=None)

    def get_old_arg_value(tree):
        return tree.args.args[0].arg

    def get_changed_arg_value(tree):
        return tree.args.args[0].arg

    def get_new_arg_value(new_tree):
        return new_tree.args.args[0].arg



# Generated at 2022-06-23 23:50:05.279990
# Unit test for function extend
def test_extend():
    import astor
    from .helpers import get_source, ast2str
    source = get_source(lambda: extend(vars))
    tree = ast.parse(source)
    for node in find(tree, ast.Call):
        if isinstance(node.func, ast.Name) and node.func.id == 'extend':
            parent, index = get_non_exp_parent_and_index(tree, node)
            assert ast2str(parent) == '<Module lineno="1" col_offset="0">'
            assert ast2str(index) == '<Expr lineno="1" col_offset="0">'
            assert ast2str(node) == '<Call lineno="1" col_offset="0">'

# Generated at 2022-06-23 23:50:06.297106
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:50:15.068274
# Unit test for function find_variables
def test_find_variables():
    fake_global = ast.Name(id='global_var', ctx=ast.Load())

    code = """
    let(x)
    x += 1
    let(y)
    
    def f(x):
        x = 5
        let(y)
        y += 1
        print(x, y)
    """
    tree = ast.parse(code)
    variables = find_variables(tree)  # type: ignore
    assert list(variables) == ['x', 'y', 'y']

    extend_tree(tree, {'x': fake_global, 'y': fake_global})
    assert len(list(find(tree, ast.Call))) == 0

    variables = find_variables(tree)  # type: ignore
    assert list(variables) == ['y']

# Generated at 2022-06-23 23:50:20.831542
# Unit test for function find_variables
def test_find_variables():
    assert len(list(find_variables(ast.parse('let(x)')))) == 1
    assert len(list(find_variables(ast.parse('let(x)\nlet(y)')))) == 2
    assert len(list(find_variables(ast.parse('let(x)\nlet(y)\nprint(x)')))) == 2
    

# Generated at 2022-06-23 23:50:30.638373
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
        extend(vars)
        print(x)
        x = 1
    ''')
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                     value=ast.Num(n=1))]})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Print(dest=None, values=[Name(id=\'x\', ctx=Load())], nl=True), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1))])'


# Generated at 2022-06-23 23:50:34.436121
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    """Checks function name finding and replacing.

    fn = lambda x: x**2
    t = ast.parse('fn(2)')
    vars = {'fn': 'my_func'}
    tree = VariablesReplacer.replace(t, vars)
    assert tree.body[0].value.func.id == 'my_func'
    """



# Generated at 2022-06-23 23:50:39.995906
# Unit test for constructor of class snippet
def test_snippet():
    class TestSnippet:
        def __init__(self):
            pass

    assert snippet(TestSnippet)



# Generated at 2022-06-23 23:50:43.546716
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("a.b.c.d")
    variables = {'a.b': 'e.f'}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].value.value.value.value.value == 'd'
    assert tree.body[0].value.value.value.attr == 'f'
    assert tree.body[0].value.value.attr == 'e'



# Generated at 2022-06-23 23:50:46.069331
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('x = 1')
    testing_tree = ast.parse('foo(x = x)')
    variables = {'x': 'foo'}
    VariablesReplacer.replace(testing_tree, variables)
    assert testing_tree.body[0].value.keywords[0].arg == 'foo'

# Generated at 2022-06-23 23:50:46.947028
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer({}) != None

# Generated at 2022-06-23 23:50:57.364861
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    """
   def func():
        let(x)
        let(y)
        a = x.val
        b = x.y.z
        c = y.c.d
        d = y.x
    """
    source = '''
    def func():
        x = 1
        y = 2
        a = x.val
        b = x.y.z
        c = y.c.d
        d = y.x
    '''
    tree = ast.parse(source)
    find_variables(tree)
    tree = VariablesReplacer.replace(tree, {'x': 5, 'y': 3})
    print(ast.dump(tree))

# Generated at 2022-06-23 23:51:01.568127
# Unit test for function let
def test_let():
    tree = ast.parse('let(x)\nx += 1\ny = 1')
    find_variables(tree)

    variables = {
        'x': ['_py_backwards_x_0', ast.parse('y = 2')]
    }

    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)



# Generated at 2022-06-23 23:51:08.017693
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    import astor
    a = ast.Name('a', ast.Load())
    b = ast.Name('b', ast.Load())
    assert astor.to_source(VariablesReplacer.replace(a, {'a': b})) == 'b'


# Generated at 2022-06-23 23:51:12.453621
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    variables = {"x": ast.NameConstant(True)}
    tree = ast.parse("x=1").body[0]
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert(tree.targets[0].id == "True")


# Generated at 2022-06-23 23:51:18.797038
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    ast_body = [ast.ClassDef("hello", [], [], [], []), ast.ClassDef("foo", [], [], [], [])]
    dummy_ast_module = ast.Module(ast_body)
    variables = {'foo': 'bar'}
    obj = VariablesReplacer(variables)
    result = obj.visit(dummy_ast_module)
    assert result.body[1].name == "bar"

# Generated at 2022-06-23 23:51:30.756843
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class TestVisitor(ast.NodeVisitor):
        """Visitor for test."""
        def visit_arg(self, node: ast.arg) -> ast.arg:
            if node.arg == 'x':
                node.arg = 'y'
            return node

    # Case 1
    # TestVisitor.visit_arg can handle ast.arg that is passed
    # as an argument to a function call.
    source = """
    def f(x: int = 1) -> None:
        print(x)
    f()
    """
    tree = ast.parse(source)
    TestVisitor().visit(tree)
    VariablesReplacer.replace(tree, {})
    tree = ast.fix_missing_locations(tree)

# Generated at 2022-06-23 23:51:34.021730
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:51:39.632386
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class MyClass:
        def f(a, b=2):
            pass

    tree = ast.parse(get_source(MyClass.f))
    assert 'b' in find_variables(tree)

    VariablesReplacer.replace(tree, {'b': 'b1'})
    assert 'b' not in find_variables(tree)

    assert tree.body[0].body[0].args.args[1].arg == 'b1'

# Generated at 2022-06-23 23:51:48.032953
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from astunparse import unparse

    class TestVisitor(ast.NodeVisitor):
        def __init__(self):
            self.result = ""

        def visit_ExceptHandler(self, except_node):
            if except_node.name is not None:
                self.result += except_node.name.id
            else:
                self.result += "None"

    # Tests with name as None
    code = "try:\n    pass\nexcept:\n    pass"
    tree = ast.parse(code)
    visitor = TestVisitor()
    visitor.visit(tree)
    assert visitor.result == "None"

    # Tests with name as string
    code = "try:\n    pass\nexcept Exception as e:\n    pass"
    tree = ast.parse(code)
    visitor = TestVisitor()

# Generated at 2022-06-23 23:51:55.242872
# Unit test for function let
def test_let():
    with snippet(None) as s:
        let(x)
        x += 1
        y = 1
        
    print(s.get_body())
    assert s.get_body() == \
           [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0')],
                       value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0'),
                                       op=ast.Add(),
                                       right=ast.Num(n=1))),
            ast.Assign(targets=[ast.Name(id='y')], value=ast.Num(n=1))]
            
    with snippet(None) as s:
        let(x)
        x += 1
        y = 1
            
    print(s.get_body())

# Generated at 2022-06-23 23:52:03.663789
# Unit test for function let
def test_let():
    def func():
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_ = snippet(func)
    assert snippet_ is not None
    func_body = snippet_.get_body()
    assert func_body is not None
    assert len(func_body) == 3
    assert isinstance(func_body[0], ast.Assign)
    assert isinstance(func_body[1], ast.Assign)
    assert isinstance(func_body[2], ast.Return)
    assert func_body[0].value.n == 1
    assert func_body[1].value.n == 1
    assert func_body[2].value.n == 2



# Generated at 2022-06-23 23:52:04.471617
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    VariablesReplacer(VariablesReplacer._variables)
    return

# Generated at 2022-06-23 23:52:11.684046
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    x = ast.Name(id='x', ctx=ast.Load())
    y = ast.Name(id='y', ctx=ast.Load())
    z = ast.Name(id='z', ctx=ast.Load())

    expr = ast.BinOp(x, ast.Add(), y)
    parent = ast.BinOp(expr, ast.Sub(), z)
    body = [expr]
    name = 'replace_tree'

    fn = ast.FunctionDef(name=name, args=None, body=body, decorator_list=None,
                         returns=None)
    cls = ast.ClassDef(name=name, bases=None, body=body, decorator_list=None)
    tree = ast.Module(body=[ast.Expr(value=parent), fn, cls])


# Generated at 2022-06-23 23:52:16.467323
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    def fn():
        pass

    inst = VariablesReplacer.replace(fn, {'a': 'b'})
    if not isinstance(inst, ast.FunctionDef) or not isinstance(inst.name, str):
        print("failed")
        exit(-1)


# Generated at 2022-06-23 23:52:19.558633
# Unit test for constructor of class snippet
def test_snippet():
    from .python import *

    def f():
        let(x)
        return x

    snippet(f)

# Generated at 2022-06-23 23:52:27.200872
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    a = ast.parse("a = 1")
    b = ast.parse("a = 2")
    new_node = b.body[0]
    new_keyword = new_node.targets[0]
    new_keyword.id = "b"
    replace_dict = {"a": new_keyword}
    inst = VariablesReplacer(replace_dict)
    new_node = inst.visit_keyword(new_keyword)
    assert new_node.arg == "b"

# Generated at 2022-06-23 23:52:32.907010
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    # I don't know how to write unit test if pytest doesn't support dynamic
    # creation of fixtures
    tree = ast.parse("""self.name.upper()""")
    VariablesReplacer.replace(tree, {'self': 'upper'})
    assert ast.dump(tree) == "upper.upper()"



# Generated at 2022-06-23 23:52:34.425957
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    from .test import assert_ast_equal
    variables = {'x': 'y'}

# Generated at 2022-06-23 23:52:44.497957
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from \
        py_backwards.transformers.helpers import VariablesReplacer
    from typed_ast import ast3 as ast
    import collections
    Attr1 = collections.namedtuple('Attr1', '_fields')
    Attr2 = collections.namedtuple('Attr2', '_fields')
    Attr3 = collections.namedtuple('Attr3', '_fields')
    Attr4 = collections.namedtuple('Attr4', '_fields')
    Attr5 = collections.namedtuple('Attr5', '_fields')
    Attr6 = collections.namedtuple('Attr6', '_fields')
    Attr7 = collections.namedtuple('Attr7', '_fields')
    Attr8 = collections.namedtuple('Attr8', '_fields')
    Attr

# Generated at 2022-06-23 23:52:47.173583
# Unit test for function let
def test_let():
    def test_omega() -> None:
        let(a)
        let(b)
        let(c)

    snippet_body = snippet(test_omega).get_body()
    assert snippet_body == []

# Generated at 2022-06-23 23:52:55.865400
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    variables = {"x": "s"}