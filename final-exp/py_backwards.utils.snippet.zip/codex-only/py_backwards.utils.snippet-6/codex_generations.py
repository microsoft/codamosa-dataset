

# Generated at 2022-06-23 23:43:02.752199
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import unittest
    import sys
    import io
    import astor
    import os

    def test_method(self):
        code = """
        try:
            a = 1
        except Exception as e:
            print(e)
        """
        tree = ast.parse(code)
        node = VariablesReplacer.replace(tree, {"e": "_py_backwards_e_0"})
        expected_node = """
        try:
            a = 1
        except Exception as _py_backwards_e_0:
            print(_py_backwards_e_0)
        """
        self.assertEqual(astor.to_source(node), expected_node)

    class TestCase(unittest.TestCase):
        pass
    TestCase.test_method = test_method

    test_runner

# Generated at 2022-06-23 23:43:05.574569
# Unit test for function let
def test_let():
    source = """
    let(a)
    a += 1
    """
    tree = ast.parse(source)
    names = find_variables(tree)

    assert names == {'a'}

# Generated at 2022-06-23 23:43:12.617925
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from a import b as c")
    variables = {'a': 'a1',
                 'c': 'c1'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)

    expected = ast.ImportFrom(module='a1',
                              names=[ast.alias(name='b', asname='c1')],
                              level=0)
    assert tree.body[0] == expected



# Generated at 2022-06-23 23:43:23.606449
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import ast
    from falcon.asg import Subscript, Index, Constant, Load, Store, Attribute
    fake_att = ast.Attribute(ast.Name(id='fake_name', ctx=ast.Load()),
                             ast.Load())
    fake_simple_node = Attribute(Load(), Subscript(Attribute(Load(), fake_att),
                                                   Index(Constant(0))),
                                 Store(),
                                 )
    fake_node = Attribute(Load(), Subscript(fake_simple_node,
                                            Index(Constant(0))),
                          Store(),
                          )
    fake_variables = {'fake_name': 'different_name'}
    fake_instance = VariablesReplacer(fake_variables)
    fake_instance.visit_Attribute(fake_node.ast)


# Generated at 2022-06-23 23:43:32.100254
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    py_backwards_x_0 = 0
    py_backwards_y_0 = "y"
    tree = ast.parse("def foo(x):\n let(y)\n extend(vars)\n print(x, y)")
    vars = ast.parse("x = 1\n x = 2")
    variables = {
        'x': py_backwards_x_0,
        'y': py_backwards_y_0,
        'vars': vars.body
    }
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].body[0].args[0].arg == "py_backwards_x_0"

# Generated at 2022-06-23 23:43:38.664265
# Unit test for function extend
def test_extend():
    def example():
        extend(vars)
        print(x, y)
    
    source = get_source(example)
    vars = ast.parse('x = 1; x = 2;').body
    tree = ast.parse(source)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(vars) in ast.dump(tree)


# Generated at 2022-06-23 23:43:44.682384
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import astor
    from .test_snippets import test_snippet

    tree = test_snippet()
    replacer = VariablesReplacer({'Rec': 'x'})
    replacer.visit(tree)

    assert astor.to_source(tree) == """\
import z

x = z.a()
y = z.b()
assert x.c == 1
assert y.c == 1
"""

# Generated at 2022-06-23 23:43:48.683956
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    new_name= '_py_backwards_x_0'
    tree = ast.parse('def f(): pass')
    variables = {'f': new_name}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].name == new_name



# Generated at 2022-06-23 23:43:53.815179
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    T = TypeVar('T')
    tree = ast.parse("x.x")
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.Expr)
    tree = tree.body[0].value
    assert isinstance(tree, ast.Attribute)
    assert isinstance(tree.value, ast.Name)
    assert isinstance(tree.value.id, str)
    tree = VariablesReplacer({"x": ast.Attribute("")}).visit(tree)
    assert isinstance(tree, ast.Attribute)


# Generated at 2022-06-23 23:44:00.179806
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("""(1 for i in range(10))""")
    expected_tree = ast.parse("""(1 for _py_backwards_i_0 in range(10))""")
    variables = {'i': '_py_backwards_i_0'}
    new_tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(expected_tree) == ast.dump(new_tree)

# Generated at 2022-06-23 23:44:05.170176
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("from os.path import isfile as do_check")
    variables = {'isfile': 'isfile', 'do_check': 'exists'}
    replacer = VariablesReplacer(variables)
    replacer.visit_ImportFrom(tree.body[0])
    assert get_source(tree) == 'from os.path import exists as do_check'



# Generated at 2022-06-23 23:44:09.804666
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # Arrange
    expected_module = "module_X_0.module_Y_1"
    sut = VariablesReplacer({"module_X_0": "module_X_1", "module_Y_0": "module_Y_1"})

    # Act
    result = sut.visit_ImportFrom(ast.ImportFrom("module_X_0.module_Y_0", [], 0, False))

    # Assert
    assert result.module == expected_module


# Generated at 2022-06-23 23:44:12.896487
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let('3')
    let('a, b')
    """

    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == ['x', 'y', "'3'", "'a, b'"]



# Generated at 2022-06-23 23:44:23.866245
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import is_equal_as_source
    from .tree import find, node_to_source

    @snippet
    def do_something():
        let(a)
        let(b)
        extend(body)

    a = ast.parse("""1 + 2""").body[0]
    b = ast.parse("""3 + 4""").body[0]
    body = ast.parse("""c = c + 1""").body
    assert node_to_source(do_something.get_body(a=a, b=b, body=body)) == """
        _py_backwards_a_0 = 1 + 2
        _py_backwards_b_0 = 3 + 4
        c = c + 1
    """.strip()

# Generated at 2022-06-23 23:44:32.863564
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse(
        """
        import itertools
        import a as b
        from c import d,e as f
        """
    )
    variables = {
        'itertools': 'itertools2',
        'b': 'a',
        'd': 'e',
        'f': 'g'
    }
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == """(Module
  (Import (alias itertools2 (asname None)))
  (Import (alias a (asname b)))
  (ImportFrom itertools2 (names (alias d (asname e)) (alias g (asname f))))
)"""



# Generated at 2022-06-23 23:44:35.797383
# Unit test for function let
def test_let():
    def test():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test)
    assert snippet_.get_body() == ast.parse('''
    _py_backwards_x_0 += 1
    y=1
    ''').body



# Generated at 2022-06-23 23:44:40.415571
# Unit test for function find_variables
def test_find_variables():
    source = '''
let(x)
let(y)
let(z)
    '''

    tree = ast.parse(source)
    variables = find_variables(tree)
    assert(variables == ['x', 'y', 'z'])


# Generated at 2022-06-23 23:44:46.460312
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # check_with_variables_with_old_module_name:
    # variables = {'a': 'b'}
    # check_with_variables_with_new_module_name:
    # variables = {'b': 'c'}
    module = ast.parse('from a import b').body[0]
    assert VariablesReplacer.replace(module, variables).body[0].module == 'c'

# Generated at 2022-06-23 23:44:51.554702
# Unit test for function extend
def test_extend():
    def test():
        extend(vars)

    vars = ast.parse('x = 1\nx = 2\n').body
    tree = snippet(test).get_body(vars=vars)

    assert [node.lineno for node in tree] == [1, 2, 1]
    assert [node.col_offset for node in tree] == [0, 0, 4]



# Generated at 2022-06-23 23:44:55.257038
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    source = '''
        let(x)
        def x():
            pass
    '''
    tree = ast.parse(source)
    variables = find_variables(tree)
    VariablesReplacer.replace(tree, variables)
    assert str(tree) == '''
        def _py_backwards_x_0():
            pass
    '''



# Generated at 2022-06-23 23:45:05.444175
# Unit test for function extend_tree
def test_extend_tree():
    """Test function extend_tree."""
    import ast
    import astor
    tree = ast.parse('print(x, y)')
    variables = {'vars': [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Constant(value=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Constant(value=2)
        )
    ]}
    extend_tree(tree, variables)
    expected_code = '''x = 1
x = 2
print(x, y)'''
    assert expected_code == astor.to_source(tree)

# Generated at 2022-06-23 23:45:10.055127
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    def foo(bar):
        pass

    source = get_source(foo)
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, {'bar': 'foobar'})
    assert str(tree) == 'def foo(foobar):\n    pass\n'

# Generated at 2022-06-23 23:45:18.112884
# Unit test for function extend_tree
def test_extend_tree():
    node = ast.parse('''
        class A:
            let(x)
            extend(B)
            a = let(y)
            
    ''')
    B = [ast.Assign([ast.Name('y', ast.Load())], ast.Num(1))]
    extend_tree(node, {'B': B})
    assert get_source(node) == '''
        class A:
            _py_backwards_x_0
            y = 1
            a = _py_backwards_x_0
    '''



# Generated at 2022-06-23 23:45:28.762227
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import astor
    node = ast.Attribute()
    node.name = "name"
    node.attr = "attr1"
    node.ctx = "ctx1"
    assert repr(node) == "Attribute(name=name, attr=attr1, ctx=ctx1)"

    # when no name in replacement dict
    variables = dict(some_name="some_name_value")
    inst = VariablesReplacer(variables)
    node1 = inst.visit_Attribute(node)
    assert repr(node1) == "Attribute(name=name, attr=attr1, ctx=ctx1)"

    # when name in replacement dict
    variables = dict(name="name_value")
    inst = VariablesReplacer(variables)
    node2 = inst.visit_Attribute(node)

# Generated at 2022-06-23 23:45:33.397893
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    a = ast.Attribute(value=ast.Name(id="test", ctx=ast.Load()), attr='now', ctx=ast.Load())
    actual = VariablesReplacer.replace(a, {'now': 'attr'})
    expected = ast.Attribute(value=ast.Name(id="test", ctx=ast.Load()), attr='attr', ctx=ast.Load())
    assert_equal(actual, expected)



# Generated at 2022-06-23 23:45:40.800223
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f(a: int, b: int):
        let(a, b)
        let(x, y)
        return x + y
    assert f.get_body(a=1, b=2) == [ast.Expr(ast.BinOp(ast.Name(_py_backwards_a_0, ast.Load()), ast.Add(),
                                                 ast.Name(_py_backwards_b_0, ast.Load())))]

# Generated at 2022-06-23 23:45:44.141060
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    var = "v"
    tree = ast.ExceptHandler(type = None, name = var)
    variables = {var: "v_"}
    VariablesReplacer.replace(tree, variables)
    assert tree.name == "v_"

# Generated at 2022-06-23 23:45:53.857218
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    import inspect
    import astor
    from ast import parse

    ast_tree_function = inspect.getsource(test_VariablesReplacer_visit_arg)
    ast_tree_function = parse(ast_tree_function)
    ast_tree_function = ast_tree_function.body[0]

    tree_args = ast_tree_function.args
    arg_b = tree_args.args[0]

    arg_a = arg_b.__class__(arg='a')

    tree_args.args[0] = arg_a

    new_str_tree = astor.to_source(ast_tree_function)

    assert 'def test_VariablesReplacer_visit_arg(a):' in new_str_tree
    assert 'def test_VariablesReplacer_visit_arg(b):'

# Generated at 2022-06-23 23:45:56.472135
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)\nx = 1\ny = 1")
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-23 23:46:01.473345
# Unit test for function extend_tree
def test_extend_tree():
    assert "some_code_block = ['block1', 'block2']" == ast.dump(
        extend_tree(ast.parse("extend(some_code_block)"), {"some_code_block": ast.parse("['block1', 'block2']")})).strip()



# Generated at 2022-06-23 23:46:02.609833
# Unit test for constructor of class snippet
def test_snippet():
    snippet(None)



# Generated at 2022-06-23 23:46:12.047916
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("""
from x import y
""")
    tree1 = VariablesReplacer.replace(tree, {'x': 'a'})
    source1 = ast.unparse(tree1)
    assert source1 == """\
from a import y
"""
    tree2 = VariablesReplacer.replace(tree, {'x': 'b'})
    source2 = ast.unparse(tree2)
    assert source2 == """\
from b import y
"""
    tree3 = VariablesReplacer.replace(tree, {'x': 'c'})
    source3 = ast.unparse(tree3)
    assert source3 == """\
from c import y
"""
    tree4 = VariablesReplacer.replace(tree, {})
    source4 = ast.unparse(tree4)
    assert source

# Generated at 2022-06-23 23:46:17.132563
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import sys
    import typed_ast.ast3 as ast
    from .helpers import VariablesGenerator

    unique_name = VariablesGenerator.generate('name')
    tree = ast.parse('''
    from a import b
    from c import d
    import e as f
    ''')
    module_name = 'a.b.c'
    module_name_as_alias = 'a.b.c as alias'
    module_name_as_alias_with_another_alias = 'a.b.c as alias as another_alias'
    module_name_as_alias_with_another_alias_and_one_more = 'a.b.c as alias as another_alias as one_more'
    module_name_with_another_alias = 'a.b.c as another_alias'
   

# Generated at 2022-06-23 23:46:23.512226
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    source = """class C:
    foo = 1
    def bar(self):
        return "bar"
"""
    tree = ast.parse(source)
    variables = {"C": VariablesGenerator.generate("C")}
    tree = VariablesReplacer.replace(tree, variables)
    source = get_source(tree)
    assert source == """class _py_backwards_C_0:
    foo = 1
    def bar(self):
        return "bar"
"""

# Generated at 2022-06-23 23:46:29.452592
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    fn = snippet(lambda x: x + 1)
    body = fn.get_body(x=3)
    assert len(body) == 1
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[0].value.left, ast.Num)
    assert isinstance(body[0].value.op, ast.Add)
    assert isinstance(body[0].value.right, ast.Num)
    assert body[0].value.left.n == 3
    assert body[0].value.right.n == 1


# Generated at 2022-06-23 23:46:39.952628
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)")
    assert find_variables(tree) == ['x']
    tree = ast.parse("let(x); y = let(a); print(a)")
    assert find_variables(tree) == ['x', 'a']
    tree = ast.parse("let(x) if y: let(a)")
    assert find_variables(tree) == ['x']
    tree = ast.parse("if 1: let(x); let(a)")
    assert find_variables(tree) == ['x', 'a']
    tree = ast.parse("if 1: let(x); let(a); let(b)")
    assert find_variables(tree) == ['x', 'a', 'b']

# Generated at 2022-06-23 23:46:45.650075
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    assmt = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                              value=ast.Name(id='datetime', ctx=ast.Load()))
    r = VariablesReplacer({'datetime': ['datetime']})
    assert ast.dump(r.visit(assmt)) == 'Assign(targets=[Name(id=\'x\', ctx=Store())], value=\'datetime\')'


# Generated at 2022-06-23 23:46:54.804558
# Unit test for constructor of class snippet
def test_snippet():
    x = ast.Name('x')
    y = ast.Name('z')
    kwargs = {'x': x, 'z': y}
    snippet_ = snippet(
        lambda foo, bar, **kwargs: let(foo) + let(bar) + foo + bar)

    assert snippet_.get_body(foo=1, bar=2, **kwargs) == \
           [ast.Assign([x], [ast.Num(1)]),
            ast.Assign([y], [ast.Num(2)]),
            ast.AugAssign(x, ast.Add(), x),
            ast.AugAssign(y, ast.Add(), y)]



# Generated at 2022-06-23 23:46:58.076868
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    node = ast.alias(name='x', asname='y')
    node = VariablesReplacer.replace(node, {'x': ast.Name(id='a', ctx=ast.Load())})
    assert node.name == 'a'
    assert node.asname == 'y'

    node = ast.alias(name='x', asname='y')
    node = VariablesReplacer.replace(node, {'x': 'a'})
    assert node.name == 'a'
    assert node.asname == 'y'

# Generated at 2022-06-23 23:47:05.874668
# Unit test for function let
def test_let():
    @snippet
    def test():
        x = 1
        let(x)
        x += 1

    body = test.get_body()
    assert len(body) == 1
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[0].value, ast.Num)
    assert body[0].value.n == 1
    assert isinstance(body[0].target, ast.Name)
    assert body[0].target.id == '_py_backwards_x_0'



# Generated at 2022-06-23 23:47:10.506162
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    code = """
from module1 import *
from module2 import *
    """
    variables = {}
    root = ast.parse(code)
    variables = find_variables(root)
    VariablesReplacer.replace(root, variables)
    assert code == get_source(root)



# Generated at 2022-06-23 23:47:20.044243
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source1 = '''
        def fn():
            pass
    '''
    source2 = '''
        x = 1
    '''
    source3 = '''
        z = 1
    '''
    tree1 = ast.parse(source1)
    tree2 = ast.parse(source2)
    tree3 = ast.parse(source3)

    variables = {'x': tree2.body[0].targets[0].id,
                 'y': tree3.body[0].targets[0].id}

    VariablesReplacer.replace(tree1, variables)
    check_name_in_FunctionDef(tree1, '_py_backwards_x_0')



# Generated at 2022-06-23 23:47:28.683427
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    import codegen
    import ast as _ast

    class A:
        def __init__(self):
            pass

    @codegen
    def fn(*args, **kwargs):
        """""
        fn.visit_arg(node)
        """
        pass

    locals_ = {'self': A()}  # type: Any
    eval(compile(fn(), '<string>', mode='exec'), locals_)
    args = _ast.arg(arg='blah')  # type: _ast.arg
    locals_['fn'].visit_arg(args)
    assert args.arg == 'blah'

# Generated at 2022-06-23 23:47:32.694252
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        for i in range(let(n)):
            let(x)
        let(y) = let(z)
        def func():
            let(z) = x ** let(n)
            return let(f)
        f = func()
    """)
    assert tuple(find_variables(tree)) == ('n', 'x', 'y', 'z', 'z', 'n', 'f')


# Generated at 2022-06-23 23:47:36.816450
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    """Test method visit_Name of class VariablesReplacer"""
    tree = ast.parse('a = 5')
    replacer = VariablesReplacer({'a': 'b'})
    result = replacer.visit(tree)
    assert(get_source(result) == 'b = 5')



# Generated at 2022-06-23 23:47:47.855408
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    extend(numbers)
    print('end')
    """

    tree = ast.parse(source)
    extend_tree(tree, {
        'numbers': [
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=1),
            ),
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=2),
            ),
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=3),
            ),
        ],
    })


# Generated at 2022-06-23 23:47:55.947666
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import random
    import sys
    sys.path.append("..")
    from importlib import import_module
    import_module("py_backwards")

    tree = ast.parse('from py_backwards import snippet')
    variables = {'py_backwards': 'my_py_backwards'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'from my_py_backwards import snippet'

    tree = ast.parse('from py_backwards.tree import find')
    variables = {'py_backwards': 'my_py_backwards'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'from my_py_backwards.tree import find'


# Generated at 2022-06-23 23:48:07.188730
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():

    tree = ast.parse("""x = 1
                        x = 2
                        x = 3""")

    variables = {'x': '_py_backwards_x_0'}

    VariablesReplacer.replace(tree, variables)

    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='_py_backwards_x_0', ctx=Store())], value=Constant(value=1)), Assign(targets=[Name(id='_py_backwards_x_0', ctx=Store())], value=Constant(value=2)), Assign(targets=[Name(id='_py_backwards_x_0', ctx=Store())], value=Constant(value=3))])"



# Generated at 2022-06-23 23:48:10.541857
# Unit test for constructor of class snippet
def test_snippet():
    def function(x: int, y: int) -> int:
        assert isinstance(x, int)
        assert isinstance(y, int)
        let(z)
        assert isinstance(z, int)
        return x + y + z

    snippet(function)

# Generated at 2022-06-23 23:48:14.778004
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    node = ast.arg('old_name', None)
    variables = {'old_name': 'new_name'}
    replacer = VariablesReplacer(variables)
    replacer.visit(node)

    assert node.arg == 'new_name'

# Generated at 2022-06-23 23:48:23.448810
# Unit test for function let
def test_let():
    @snippet
    def test():
        let(x)
        x += 1
        y += 2

    result = test.get_body()

    assert len(result) == 2

    node = result[0]
    assert isinstance(node, ast.AugAssign)
    assert isinstance(node.target, ast.Name)
    assert node.target.id == '_py_backwards_x_0'

    node = result[1]
    assert isinstance(node, ast.AugAssign)
    assert isinstance(node.target, ast.Name)
    assert node.target.id == 'y'



# Generated at 2022-06-23 23:48:24.343964
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    try:
        print(1)
    except Exception as e:
        print(2)

# Generated at 2022-06-23 23:48:29.712619
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import sys
    node = ast.parse('sys.stdout.write()')
    replacer = VariablesReplacer({'sys.stdout': 'stdout',
                                  'sys': 'stdout'})
    replacer.visit(node)
    assert node.body[0].value.func.value.value.id == 'stdout'



# Generated at 2022-06-23 23:48:36.890160
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    node1 = ast.Name(id='a', ctx=ast.Load())
    node2 = ast.Name(id='a', ctx=ast.Load())
    assert VariablesReplacer.visit_Name(VariablesReplacer({'a': {'a': 1}}), node1) == node2
    assert VariablesReplacer.visit_Name(VariablesReplacer({'a': {'a': 1}}), node2) == node2



# Generated at 2022-06-23 23:48:47.870526
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class TestClass(ast.NodeVisitor):
        def visit_Call(self, node):
            node = VariablesReplacer.replace(node, {'var': 'name'})
            self.generic_visit(node)
            
    test_call = ast.parse("func({'kw1': var, 'kw2': var})").body[0].value
    TestClass().visit(test_call)
    
    assert test_call.func.id == 'func'
    assert isinstance(test_call.args[0], ast.Dict)
    
    for key in test_call.args[0].keys:
        assert key.s == 'kw1' or key.s == 'kw2'
        
    for value in test_call.args[0].values:
        assert value.s == 'name'

# Generated at 2022-06-23 23:48:52.209165
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    test_code = "from abc import (def as d)"
    test_ast = ast.parse(test_code)
    VariablesReplacer.replace(test_ast, {'d': 'def'})
    assert test_ast.body[0].names[0].asname == 'def'


# Generated at 2022-06-23 23:49:00.960383
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import ast

    from ast import ClassDef
    from .tree import find
    from .helpers import VariablesGenerator

    varGen = VariablesGenerator("_py_backwards_")

    tree = ast.parse("""
        class Class1:
            def __init__(self):
                a = 0
                b = a
                
            def func(self):
                b = a
                Class2.func2()
                
        class Class2:
            def __init__(self):
                print(a)
                b = a
                
            @staticmethod
            def func2():
                print(a)
                b = a
        """)

    classVariables = find(tree, ClassDef)
    for classDef in classVariables:
        classDef.name = varGen.generate(classDef.name)



# Generated at 2022-06-23 23:49:10.741874
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class VariablesReplacer1(ast.NodeTransformer):
        def __init__(self):
            pass
        def visit_keyword(self, node: ast.keyword) -> ast.keyword:
            print("Replacing ", node.arg)
            return node

    class VariablesReplacer2(ast.NodeTransformer):
        def __init__(self):
            pass
        def visit_keyword(self, node: ast.keyword) -> ast.keyword:
            print("Replacing ", node.arg)
            # Этот синтаксис используется в стандартной библиотеке в таком паттер

# Generated at 2022-06-23 23:49:16.715329
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = "from x import y"
    tree = ast.parse(source)
    variables = {'x': 'a', 'y': 'b'}
    VariablesReplacer.replace(tree, variables)
    assert compile(tree, "<test>", "exec", optimize=2) == compile(source, "<test>", "exec", optimize=2)

test_VariablesReplacer_visit_alias()

# Generated at 2022-06-23 23:49:28.309217
# Unit test for function extend
def test_extend():
    @snippet
    def a():
        extend(vars)
        print(x, y)

    vars = []
    vars.append(ast.parse('x = 1').body[0])
    vars.append(ast.parse('x = 2').body[0])
    vars.append(ast.parse('y = 3').body[0])
    source = compile(ast.Module(a.get_body(vars=vars)), '<snippet>', 'exec')
    ns = {}
    exec(source, ns)
    assert ns['x'] == 2, 'expected x == 2, got %r' % ns['x']
    assert ns['y'] == 3, 'expected y == 3, got %r' % ns['y']



# Generated at 2022-06-23 23:49:32.839087
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    x = ast.Name('unique', ast.Load())
    tree = ast.parse("def foo(x):\n    print(x)")
    VariablesReplacer.replace(tree, {'x': x})
    assert tree.body[0].args.args[0].id == 'unique'

# Generated at 2022-06-23 23:49:42.432177
# Unit test for function let
def test_let():
    @snippet
    def func(x):
        let(x)
        x += 1
        y = 1

    assert func.get_body() ==\
        [
            ast.Assign(
                targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                value=ast.BinOp(
                    left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                    op=ast.Add(),
                    right=ast.Num(n=1),
                ),
            ),
            ast.Assign(
                targets=[ast.Name(id='y', ctx=ast.Store())],
                value=ast.Num(n=1),
            )
        ]


# Generated at 2022-06-23 23:49:45.697060
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    print(True)


if __name__ == '__main__':
    test_VariablesReplacer_visit_ImportFrom()

# Generated at 2022-06-23 23:49:51.373456
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x: int, y: int, z: str) -> None:
        let(x)
        x += 1
        y = 1
        extend(z)
        
    snippet = snippet(f)
    result = snippet.get_body(x={'a': 1, 'b': 2}, y=2, z="")
    print("result = '{0}'".format(result))

# Generated at 2022-06-23 23:49:57.577888
# Unit test for function extend
def test_extend():
    vars = ast.parse('x = 1; x = 2').body
    source = 'extend(vars)\nprint(x)'
    tree = ast.parse(source)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2)), Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Name(id=\'x\', ctx=Load())], keywords=[]))])'

# Generated at 2022-06-23 23:50:05.055049
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    from .testing import compare_ast

    # type: Dict[str, Variable]
    variables = {'x': [ast.parse('y = 2').body[0]], 'y': 'z'}

    tree = ast.parse('x; y; x;')
    VariablesReplacer.replace(tree, variables)

    expected = ast.parse('y = 2; z; z;')
    assert compare_ast(tree, expected)

# Generated at 2022-06-23 23:50:15.374473
# Unit test for function extend
def test_extend():
    class Example:
        def __init__(self, name: str) -> None:
            self.name = name

        @snippet
        def say_hello(self, name: str) -> None:
            extend(vars)
            print(f'Hello {name}, my name is {self.name}')

    class ExampleWithLet:
        @snippet
        def say_hello(self, name: str) -> None:
            let(x)
            let(y)
            extend(vars)
            z = x + y
            print(z)

    code = Example('John').say_hello.get_body(name='World')

# Generated at 2022-06-23 23:50:21.183068
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source = """
    if (x == ""):
        x = 1
        x = 2
    else:
        print(x, y)
    """
    tree = ast.parse(source)
    expected = """
    if (_py_backwards_x_0 == ""):
        x = 1
        x = 2
    else:
        print(_py_backwards_x_0, _py_backwards_y_0)
    """
    variables = {'x': '_py_backwards_x_0', 'y': '_py_backwards_y_0'}
    inst = VariablesReplacer(variables)
    assert ast.dump(tree) == expected, ast.dump(tree)
    inst.visit(tree)
    assert ast.dump(tree) == expected



# Generated at 2022-06-23 23:50:24.736188
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('f()')
    variables = {'f': 'g'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'g()'


# Generated at 2022-06-23 23:50:25.715389
# Unit test for function extend

# Generated at 2022-06-23 23:50:31.246724
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    @snippet
    def my_snippet(**kwargs: Any) -> None:
        pass

    code = my_snippet.get_body(**{'kwargs': 2})

    assert ast.dump(code) == ast.dump([
        ast.Expr(
            value=ast.Call(
                func=ast.Name(id='kwargs', ctx=ast.Load()),
                args=[ast.Constant(value=1)],
                keywords=[],
                starargs=None,
                kwargs=None
            )
        )
    ])

# Generated at 2022-06-23 23:50:31.872931
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-23 23:50:41.885558
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    print()
    # Case 1
    locals_ = {'__builtins__': None, 'var': 'var', 'var2': 'var2'}
    v1 = VariablesGenerator.generate('var')
    v2 = VariablesGenerator.generate('var2')
    variables = {'var': v1, 'var2': v2}
    
    parsed_tree = ast.parse('var = 1; var2 = 2;')
    
    result = VariablesReplacer.replace(parsed_tree, variables)
    exec(compile(result, '<test>', 'exec'), locals_)
    
    assert 'var' not in locals_
    assert locals_[v1] == 1
    assert locals_[v2] == 2
    
    # Case 2

# Generated at 2022-06-23 23:50:49.352079
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x = 1
        y = 1
        y = 2
        print(x, y)

    s = snippet(f)

# Generated at 2022-06-23 23:50:55.120588
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A(ast.AST):
        _fields = []

    class B(ast.AST):
        _fields = []

    class C(ast.AST):
        _fields = []

    a = A()
    setattr(a, 'name', 'x')
    b = B()
    setattr(b, 'name', 'x')
    c = C()
    setattr(c, 'name', 'x')

    dct = {'x': a}

    replacer = VariablesReplacer(dct)

    assert id(replacer.visit_ClassDef(a)) == id(a)
    assert id(replacer.visit_ClassDef(b)) != id(b)
    assert id(replacer.visit_ClassDef(c)) == id(c)

# Generated at 2022-06-23 23:50:59.099055
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    """
        Replaces variables from list of keyword arguments.
        
        Example:
            class Foo:
                def bar(a, b=let(var)):
                    pass
        Will be replaced with:
            class Foo:
                def bar(a, b=_py_backwards_var_0):
                    pass
    """
    source_ast = ast.parse("""class Foo:
    def bar(a, b=let(var)):
        pass""")
    variables = {'var': VariablesGenerator.generate('var', 1)}
    extend_tree(source_ast, variables)
    new_ast = VariablesReplacer.replace(source_ast, variables)
    assert (new_ast != source_ast)
    source_code = ast.unparse(source_ast)
    new_code = ast.unparse

# Generated at 2022-06-23 23:51:03.144133
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    k = ast.keyword(value=ast.Name(id="x"))
    v = VariablesReplacer({'x': ast.Name(id='y')})
    v.visit(k)
    assert k.arg == 'y'


# Generated at 2022-06-23 23:51:06.598591
# Unit test for constructor of class snippet
def test_snippet():
    snippet(snippet)

# Generated at 2022-06-23 23:51:10.921534
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    node = ast.keyword()
    node.arg = 'abc'
    node = VariablesReplacer.replace(node, {'abc': 'xyz'})
    assert node.arg == 'xyz'

# Generated at 2022-06-23 23:51:14.110183
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    assert ast.dump(
        VariablesReplacer.replace(
            ast.parse('def foo(a):\n  2').body[0].args[0],
            {'a': 'bar'}
        )
    ) == "arg(arg='bar', anno=None)"

# Generated at 2022-06-23 23:51:18.179943
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    from .test_snippet import test_snippet
    arg = ast.arg('x', None, None)
    variables = dict(x='_py_backwards_x_0')
    actual = VariablesReplacer.replace(arg, variables)
    expected = test_snippet.expected_visit_arg_result
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-23 23:51:28.062221
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    a = ast.ClassDef(name='a')
    tree = ast.FunctionDef(name='b', body=[a])
    vr = VariablesReplacer({'a': 'c'})
    tree = vr.visit(tree)
    assert(ast.dump(tree) == 'FunctionDef(name=c, args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ClassDef(name=c, bases=[], keywords=[], body=[], decorator_list=[])])')



# Generated at 2022-06-23 23:51:32.765965
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from itertools import *")
    replacer = VariablesReplacer({'itertools': '_py_backwards_itertools'})
    replacer.visit(tree)
    assert ast.dump(tree) == 'Module(body=[ImportFrom(module=\'_py_backwards_itertools\', names=[alias(name=\'*\', asname=None)], level=0)])'

# Generated at 2022-06-23 23:51:37.831398
# Unit test for function find_variables
def test_find_variables():
    source = """
let(a)
let(b)
a = 1
b = 2
    """
    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == [
        'a', 'b']
    assert get_source(tree) == """
a = 1
b = 2
"""

# Generated at 2022-06-23 23:51:44.856612
# Unit test for constructor of class snippet
def test_snippet():
    assert type(snippet(lambda: 1)) == snippet

# Generated at 2022-06-23 23:51:48.134826
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class CustomNode(ast.AST):
        _fields = ['arg']
        def __init__(self, arg):
            self.arg = arg

    test_ = CustomNode(ast.Name('test', ast.Store()))
    test_.name = 'test'
    replacer = VariablesReplacer({'test': 'new_test'})
    res = replacer.visit_keyword(test_)
    assert res.arg == 'new_test'

# Generated at 2022-06-23 23:51:51.610152
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    import astor
    @snippet
    def f():
        a = None
        let(a)
        a += 1
        b = 2
        let(b)
        b += 1
        return a + b

    ast = f.get_body()
    print(astor.to_source(ast))

# Generated at 2022-06-23 23:51:56.015849
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class A:
        x = 3
    a = A()
    a.x = 4
    print(a.x)
    print(A.x)



# Generated at 2022-06-23 23:52:00.808903
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = '''
try:
    1
except Exception as e:
    1
'''
    node = ast.parse(source)
    v = {"e": "test_key"}
    VariablesReplacer.replace(node, v)
    assert node.body[0].handlers[0].name.id == "test_key"




# Generated at 2022-06-23 23:52:07.432901
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    source = '''
        class A:
            x = 0
            def f(self):
                pass
    '''
    source_expected = source
    tree = ast.parse(source)
    variables = {'A': 'B'}
    VariablesReplacer.replace(tree, variables)
    source_actual = ast.unparse(tree)
    assert source_actual == source_expected



# Generated at 2022-06-23 23:52:15.258977
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def generated_code():
        def fn():
            return 1
    tree = ast.parse(get_source(generated_code))
    tree1 = ast.parse(get_source(generated_code))
    inst = VariablesReplacer({'fn': '_py_backwards_fn'})
    inst.visit_FunctionDef(tree.body[0].body[0].value)
    assert ast.dump(tree) == ast.dump(tree1)
    return 1


# Generated at 2022-06-23 23:52:16.804241
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    foo = snippet(lambda x: x)
    foo.get_body()

# Generated at 2022-06-23 23:52:25.033784
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = """
from module1.module2 import alias1 as alias2
from module1.module2 import alias3 as alias4
    """
    variables = {
        'module1.module2.alias1': ast.Name(id='xx', ctx=ast.Load()),
        'module1.module2.alias3': ast.Name(id='yy', ctx=ast.Load())
    }
    tree = ast.parse(source)
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    expected = """
from module1.module2 import xx as alias2
from module1.module2 import yy as alias4
    """
    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 23:52:34.696678
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    # case 1
    # test 1
    case1 = ast.parse("if a: print('1')").body[0]
    variables = {'a': ast.Name('a', ast.Load())}
    res1 = VariablesReplacer.replace(case1, variables)
    assert res1 == ast.parse("if a: print('1')").body[0]

    # test 2
    variables = {'a': ast.Name('b', ast.Load())}
    res2 = VariablesReplacer.replace(case1, variables)
    assert res2 == ast.parse("if b: print('1')").body[0]

    # test 3
    variables = {'a': "asdf"}
    res3 = VariablesReplacer.replace(case1, variables)

# Generated at 2022-06-23 23:52:37.999911
# Unit test for function let
def test_let():
    @snippet
    def s():
        let(x)
        y = x
        return y

    body = s.get_body()

    assert body[1].value.id == '_py_backwards_x_0'



# Generated at 2022-06-23 23:52:39.621543
# Unit test for constructor of class snippet
def test_snippet():
    a = snippet(lambda: None)
    # Only for coverage, the code of snippet doesn't use any of None attributes

# Generated at 2022-06-23 23:52:45.383610
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("def _hacked_Name(a):\n  return a")
    original_tree = copy.deepcopy(tree)
    variables = {'_hacked_Name': 'name'}
    new_tree = VariablesReplacer.replace(copy.deepcopy(tree), variables)
    assert ast.dump(original_tree) == ast.dump(new_tree)



# Generated at 2022-06-23 23:52:53.959795
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    def f1():
        nested = 3
    def f2():
        nested = 4
    tree = ast.parse(get_source(f1))
    variables = {'nested': ast.parse(get_source(f2)).body[0]}
    instance = VariablesReplacer(variables)
    node = tree.body[0].body[0]
    instance.visit_keyword(node)
    assert node.arg == 'nested'
    assert node.value.n == 4