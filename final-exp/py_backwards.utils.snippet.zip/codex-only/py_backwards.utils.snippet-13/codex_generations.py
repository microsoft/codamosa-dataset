

# Generated at 2022-06-23 23:42:54.137906
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: None)._fn is not None

# Generated at 2022-06-23 23:42:55.819266
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:43:02.748752
# Unit test for function let
def test_let():
    def my_snippet(x):
        let(x)
        x += 1
        return x

    ast_body = snippet(my_snippet).get_body()
    assert ast.dump(ast_body[0]) == "Assign(targets=[Name(_py_backwards_x_0, Store())], value=BinOp(left=Name(_py_backwards_x_0, Load()), op=Add(), right=Constant(1, None)))"
    assert ast.dump(ast_body[1]) == "Return(value=Name(_py_backwards_x_0, Load()))"



# Generated at 2022-06-23 23:43:13.530626
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class Boiler:
        def __init__(self, name: str) -> None:
            self.name = name

        def __repr__(self) -> str:
            return 'Boiler({!r})'.format(self.name)

    test_args = {
        'list': [
            ast.parse('a_ = 123'),
            ast.parse('b = 456'),
            ast.parse('pass')
        ],
        'node': ast.parse('x = 123'),
        'string': 'string'
    }    
    
    test_template = '''
        def foo(x, y):
            let(a)
            let(b)
            let(c)
            x.name = a
            return y + b + c + x'''
    

# Generated at 2022-06-23 23:43:20.820008
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    import astunparse

    tree = ast.parse(
        'def foo():\n'
        '    x = 1\n'
        '    print(x)'
    )

    variables = {'x': VariablesGenerator.generate('x')}
    variables['x'] = 'a'

    VariablesReplacer.replace(tree, variables)
    res = astunparse.unparse(tree)
    assert res == 'def foo():\n    a = 1\n    print(a)\n', 'not a = 1'



# Generated at 2022-06-23 23:43:23.656617
# Unit test for function extend
def test_extend():
    from .test_snippets import test_extend as test_extend_fn
    assert test_extend_fn() == 3

# Generated at 2022-06-23 23:43:33.004437
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    def f(a: int, b: str, *args, **kwargs):
        pass

    f.__annotations__['b'] = 'str'
    f.__annotations__['d'] = 'int'
    tree = ast.parse(inspect.getsource(f))
    variables = {'str': 'str'}
    replacer = VariablesReplacer(variables)
    replacer.visit_FunctionDef(tree.body[0])
    replacer.visit(tree)

# Generated at 2022-06-23 23:43:36.485595
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(a); let(b)")
    assert set(find_variables(tree)) == {'a', 'b'}



# Generated at 2022-06-23 23:43:40.086476
# Unit test for constructor of class snippet
def test_snippet():
    def noop(*args, **kwargs):
        let(x)
        x += 1
        y = 1

    fn = snippet(noop)

    assert isinstance(fn, snippet)
    assert fn._fn == noop



# Generated at 2022-06-23 23:43:45.747518
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class TestSnippet(snippet):
        def __init__(self):
            super().__init__(self.body)
        def body(self):
            x = 1
            class Test:
                a = 1
                def __init__(self):
                    self.x = x
            return Test
    assert(len(TestSnippet().get_body()) == 3)


# Generated at 2022-06-23 23:43:53.589739
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    expected_node = ast.ExceptHandler(
        type=None, name=ast.Name(id='x', ctx=ast.Store()),
        body=[
            ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                                    args=[ast.Num(n=10)], keywords=[])),
            ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                                    args=[ast.Num(n=20)], keywords=[]))
        ],
        lineno=1, col_offset=0
    )
    node = VariablesReplacer({'x': 'y'}).visit_ExceptHandler(expected_node)
    assert node == expected_node, 'Should be equal'

# Generated at 2022-06-23 23:43:56.487770
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(i)
let(j)
""")
    assert find_variables(tree) == ['i', 'j']



# Generated at 2022-06-23 23:44:03.314795
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    from .dsl import DSL
    from .helpers import VariablesGenerator
    from .tree import replace_at

    a = DSL.build(lambda: a.b.c)
    tree = ast.parse(get_source(a))
    variables = {'a.b.c': VariablesGenerator.generate('a.b.c')}
    expected = ast.parse('_.n_.a.b.c')
    VariablesReplacer.replace(tree, variables)
    assert tree == expected



# Generated at 2022-06-23 23:44:08.617137
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # pylint: disable=missing-function-docstring
    def fn(var1: str, var2: str) -> None:
        let(var1)
        let(var2)
        print(var1)
        print(var2)

    s = snippet(fn)
    assert s.get_body(var1='a', var2='b') == ast.parse(
        """
print(_py_backwards_var1_0)
print(_py_backwards_var2_0)
""").body  # type: ignore

# Generated at 2022-06-23 23:44:10.717852
# Unit test for function find_variables
def test_find_variables():
    source = """
        let(x)
        let(y)
        print(x, y)
    """

    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-23 23:44:16.209607
# Unit test for function let
def test_let():
    x = -1
    y = 1
    @snippet
    def f():
        let(x)
        x += 1
        y = 1

    assert get_source(f._fn) == '''
    let(x)
    x += 1
    y = 1
    '''

# Generated at 2022-06-23 23:44:19.435305
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    test_code = "def foo(): pass"
    tree = ast.parse(test_code)
    assert VariablesReplacer.replace(tree, {"foo": "bar"}).body[0].name == "bar"

# Generated at 2022-06-23 23:44:21.863177
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .test_variables_replacer import VariablesReplacer_visit_ImportFrom
    VariablesReplacer_visit_ImportFrom()

# Generated at 2022-06-23 23:44:26.009713
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    node = ast.alias(name="foo.bar")
    replacer = VariablesReplacer({'foo': 'bar'})
    node = replacer.visit_alias(node)
    assert node.name == 'bar.bar'

# Generated at 2022-06-23 23:44:34.813129
# Unit test for function extend_tree
def test_extend_tree():
    tree: ast.AST = ast.parse('extend(vars)')
    variables = {
        'vars': [
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(1)
            ),
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(2)
            )
        ]
    }
    extend_tree(tree, variables)
    assert ast.dump(tree) == "Module([Assign(targets=[Name(id='x', ctx=Store())], value=Num(1)), Assign(targets=[Name(id='x', ctx=Store())], value=Num(2))])"


# Generated at 2022-06-23 23:44:46.068955
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    assert isinstance(ast.parse('').body[0], ast.Expr)

    def f():
        let(a)
        b = a

    tree = ast.parse(get_source(f))
    let_node = tree.body[0].value  # type: ignore
    variables = {let_node.args[0].id: let_node.args[1]}  # type: ignore
    assert variables == {'a': let_node.args[1]}
    assert isinstance(variables['a'], ast.Str)
    VariablesReplacer.replace(tree, variables)
    assert isinstance(tree.body[0].value, ast.Name)
    assert tree.body[0].value.id == variables['a'].s

# Generated at 2022-06-23 23:44:51.350575
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    source = """
        x = 1
        def fn(y):
            return x
        print(fn(x))
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    variables.update({'x':'_x'})
    replace = VariablesReplacer.replace
    replace(tree, variables)
    assert '_x' in get_source(tree)

# Generated at 2022-06-23 23:44:56.110310
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class A:
        def f(self, a, *args):
            pass

    source = get_source(A.f)
    tree = ast.parse(source)
    variables = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name) for name in variables}
    r = VariablesReplacer(variables)
    r.visit(tree)
    for node in find(tree, ast.keyword):
        assert node.arg == "self"

# Generated at 2022-06-23 23:45:06.729884
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_body(x, y):
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-23 23:45:12.263567
# Unit test for function extend
def test_extend():
    tree = ast.parse('extend(vars)')
    variables = {
        'vars': [
            ast.Assign([ast.Name(id='x1', ctx=ast.Store())],
                       ast.Num(n=5))
        ]
    }
    extend_tree(tree, variables)
    assert get_source(tree) == 'x1 = 5\n'

# Generated at 2022-06-23 23:45:15.860430
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""let(x)
                        let(y)
                        z = 4""")
    variables = find_variables(tree)
    assert 'x' == list(variables)[0]
    assert 'y' == list(variables)[1]
    assert 'z' == tree.body[2].targets[0].id


# Generated at 2022-06-23 23:45:16.541215
# Unit test for method visit_alias of class VariablesReplacer

# Generated at 2022-06-23 23:45:19.037059
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import assert_proper_ast
    from typed_ast import ast3

# Generated at 2022-06-23 23:45:23.119054
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("from math import sin; sin(x=1)")
    variables = {'math.sin': 'math.cos'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == "from math import cos; cos(x=1)"

# Generated at 2022-06-23 23:45:26.297543
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():

    class AttributeVisitor(ast.NodeTransformer):
        def visit_Attribute(self, node: ast.Attribute) -> ast.Attribute:
            if node.attr == 'a':
                node.attr = 'z'
            return node

    tree = ast.parse('foo.a')
    visitor = AttributeVisitor()
    visitor.visit(tree)
    assert get_source(tree) == 'foo.z'

# Generated at 2022-06-23 23:45:33.657177
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test_snippet_get_body(a: int, b: int, c: int) -> None:
        let(x)
        let(y)
        let(z)
        extend(vars)
        extend(vars2)
        x = a
        vars = vars2

# Generated at 2022-06-23 23:45:34.932192
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:45:45.651490
# Unit test for function find_variables
def test_find_variables():
    from pprint import pprint
    from textwrap import dedent
    import typing
    import os
    import sys

    def check_result(code, expected_result, **kwargs):
        tree = ast.parse(dedent(code))
        result = find_variables(tree)
        if set(result) != set(expected_result):
            raise AssertionError("Result does not match expectation.")

    check_result("""
    let(x)
    let(y)
    x = 1
    """, ['x', 'y'])

    check_result("""
    let(x)
    x = 1
    let(x)
    """, ['x', 'x_1'])


# Generated at 2022-06-23 23:45:53.412083
# Unit test for function let
def test_let():
    """
    >>> @snippet
    ... def fn():
    ...    let(x)
    ...    x += 1
    ...    return x + 2
    
    >>> fn().get_body()
    [Expr(value=AugAssign(target=Name(id='_py_backwards_x_0', ctx=Load()), op=Add(), value=Num(n=1))), Return(value=BinOp(left=Name(id='_py_backwards_x_0', ctx=Load()), op=Add(), right=Num(n=2)))]
    """



# Generated at 2022-06-23 23:46:01.202046
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import inspect
    import os
    import sys
    import os.path

    cur_dir = os.path.dirname(inspect.getabsfile(test_find_variables))
    sys.path.insert(0, cur_dir)
    from .ast_test import ast_test_object as ast_test_object_test
    from .helpers import simple_parse
    from .ast_test import AstExample

    alias_before = ast.parse("from module_name import Bbb").body[0]
    alias_after = ast.parse("from module_name import Aaa").body[0]
    assertVariablesReplacerReplacesAlias(alias_before, alias_after)

    alias_before = ast.parse("from module_name import Bbb").body[0]

# Generated at 2022-06-23 23:46:08.465087
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('def a():\n    pass\n')
    replacer = VariablesReplacer({'a': 'b'})
    replacer.visit(tree)
    result = ast.dump(tree)
    expected = 'Module(body=[FunctionDef(name="b", args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])'
    assert result == expected



# Generated at 2022-06-23 23:46:15.031608
# Unit test for function extend_tree
def test_extend_tree():
    root = ast.parse(inspect.getsource(test_extend_tree))

    # Insert test itself as a snippet
    vars = {'vars': [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1),
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2),
        ),
    ]}
    extend_tree(root, vars)

    # Check that our code executed
    assert root.body[0].body[0].value.n == 2


# Generated at 2022-06-23 23:46:19.569074
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import tokenize
    source = 'try:\n    pass\nexcept Exception as e:\n    pass'
    tree = ast.parse(source)
    unused_variables = {'e': '_py_backwards_e_0'}
    VariablesReplacer.replace(tree, unused_variables)

# Generated at 2022-06-23 23:46:20.588757
# Unit test for function extend_tree

# Generated at 2022-06-23 23:46:24.918706
# Unit test for method visit_ExceptHandler of class VariablesReplacer

# Generated at 2022-06-23 23:46:28.119443
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Ast(ast.AST):
        _fields = ('name',)

    class Foo(object):
        a = 1

    tree = Ast(Foo.a)
    replacer = VariablesReplacer({'a': 'c'})
    assert replacer.visit(tree).name == 'c'

# Generated at 2022-06-23 23:46:31.362537
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse("""
let(x)
let(y)
x = 1
y = 2
"""))) == ['x', 'y']



# Generated at 2022-06-23 23:46:32.285230
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda x: 1)

# Generated at 2022-06-23 23:46:36.411092
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def f(x):
        return x + 1

    assert f.get_body(x=1) == [ast.Return(value=ast.BinOp(left=ast.Num(n=1), op=ast.Add(), right=ast.Num(n=1)))]



# Generated at 2022-06-23 23:46:45.953165
# Unit test for function extend_tree
def test_extend_tree():
    code = dedent('''
    extend(vars)
    extend(vars1)
    ''')
    tree = ast.parse(code)
    vars = [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1))]
    extend_tree(tree, {'vars': vars, 'vars1': vars})
    assert get_source(tree) == 'x = 1\nx = 1'

    code = dedent('''
    extend(vars)
    extend(vars1)
    ''')
    tree = ast.parse(code)
    vars = [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1))]

# Generated at 2022-06-23 23:46:50.652696
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def test(a, b=1):
        return a + b
    source = get_source(test)
    tree = ast.parse(source)
    variables = find_variables(tree)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:46:59.925390
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = '''
    import a
    import b, c
    import a.b.c
    import a.b.c as d
    import a.b, c.d
    '''
    tree = ast.parse(source)
    variables = {'let': 'def'}
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:47:11.044628
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    variables = {'x': 'y', 'y': 'z'}
    tree = ast.parse("""
    def f(x, y):
        pass
    f(x, y)
    """)
    def_tree = VariablesReplacer.replace(tree, variables)
    assert isinstance(def_tree, ast.AST)
    assert isinstance(def_tree.body[0], ast.FunctionDef)
    assert def_tree.body[0].name == 'f'
    assert def_tree.body[0].args.args[0].arg == 'y'
    assert def_tree.body[0].args.args[1].arg == 'z'
    assert isinstance(def_tree.body[1], ast.Expr)
    assert isinstance(def_tree.body[1].value, ast.Call)

# Generated at 2022-06-23 23:47:21.744633
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse("f(0, y=lambda: y, a=x)")
    variables = dict(x="_py_backwards_x_0", y="_py_backwards_y_1")
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:47:25.776489
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class test(ast.NodeTransformer):
        def visit_Name(self, node):
            print(node.id)
            return node
    tree = ast.parse('x')
    test().visit(tree)
    assert tree == ast.parse('x')


# Generated at 2022-06-23 23:47:31.296823
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source = '''
    a = b
    '''
    variables = {'b': 'c'}
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, variables)
    assert(ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Name(id="c", ctx=Load()))])')



# Generated at 2022-06-23 23:47:33.178423
# Unit test for constructor of class snippet
def test_snippet():
    def test_func():
        pass
    assert Snippet(test_func)._fn == test_func


# Generated at 2022-06-23 23:47:44.090023
# Unit test for function extend
def test_extend():
    x = 'x'
    y = 'y'

    def sample() -> None:
        extend(vars)
        print(x, y)

    vars = ast.parse('y = 5; x = 10').body
    body = snippet(sample).get_body(vars=vars)
    assert isinstance(body, list)
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].targets[0], ast.Name)
    assert body[0].targets[0].id == 'y'
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[1].targets[0], ast.Name)
    assert body[1].targets[0].id == 'x'
   

# Generated at 2022-06-23 23:47:51.734409
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))


# Generated at 2022-06-23 23:47:58.436559
# Unit test for function let
def test_let():
    @snippet
    def snippet(a):
        let(b)
        b = a
        assert tuple(sorted(find_variables(snippet.get_body()))) == ('b',)
        assert b == '_py_backwards_b_0'
        return b + 2

    assert snippet(5) == 7
    assert snippet(3) == 5
    assert snippet(1) == 3



# Generated at 2022-06-23 23:48:03.975124
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    let(z)
    x = 1
    y = 2
    z = 3
    '''
    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == ['x', 'y', 'z']


# Generated at 2022-06-23 23:48:10.096483
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    """Unit test for method visit_keyword of class VariablesReplacer"""
    code = """let('a')
              def foo(a):
                  pass
           """
    tree = ast.parse(code)
    variables = {'a': '_py_backwards_a_0'}
    VariablesReplacer.replace(tree, variables)
    source = get_source(tree)
    assert source == """def foo(_py_backwards_a_0):
    pass
"""

# Generated at 2022-06-23 23:48:17.342124
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = """
from ..module import c
"""
    tree = ast.parse(source)
    variables = {'module': 'module.submodule'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=[ImportFrom(module='module.submodule', names=[alias(name='c', asname=None)], level=2)])"


if __name__ == '__main__':
    print(__doc__)

# Generated at 2022-06-23 23:48:19.339928
# Unit test for constructor of class snippet
def test_snippet():
    check = isinstance(snippet(lambda: None), snippet)
    assert check



# Generated at 2022-06-23 23:48:25.530963
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = """from mod.submod import cls"""
    tree = ast.parse(source)
    variables = {'mod': ['prefix'], 'cls': 'Class'}
    VariablesReplacer.replace(tree, variables)
    code = compile(tree, filename='<ast>', mode='exec')
    ns: Dict[str, Any] = {}
    exec(code, ns)
    assert ns == {'prefix': {'submod': {'Class': None}}}



# Generated at 2022-06-23 23:48:31.623719
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    replacer = VariablesReplacer({})
    node = ast.arg(arg=ast.Name(id="foo", ctx=ast.Load()))
    node = replacer.visit_arg(node)
    assert isinstance(node, ast.arg)
    assert node.arg == "foo"

# Generated at 2022-06-23 23:48:36.609073
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    tree = ast.parse('from foo import bar, baz')
    import_dict = dict()
    import_dict['foo'] = 'foo2'
    import_dict['bar'] = 'bar2'
    import_dict['baz'] = 'baz2'
    replacer = VariablesReplacer(import_dict)
    replacer.visit(tree)
    assert str(tree).strip() == 'from foo2 import bar2, baz2'

# Generated at 2022-06-23 23:48:42.553575
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    module = ast.Module(body=[
        ast.Call(func=ast.Name(id='let', ctx=ast.Load()), 
                 args=[ast.Name(id='x', ctx=ast.Load())], keywords=[])
    ])
    tree = ast.parse('let(x);')
    replacer = VariablesReplacer({'x': '_py_backwards_x_0'})
    replacer.visit(tree)
    assert ast.dump(tree) == ast.dump(module)


# Generated at 2022-06-23 23:48:49.335066
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = """
    def function(keyword):
        pass
    """
    tree = ast.parse(source)

    variables = {'keyword': ast.Name(id='new_keyword', ctx=ast.Load())}
    VariablesReplacer.replace(tree, variables)

    new_tree = ast.parse("""
    def function(new_keyword):
        pass
    """)

    assert ast.dump(tree) == ast.dump(new_tree)



# Generated at 2022-06-23 23:48:52.743763
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    inst = VariablesReplacer({"a": "b"})
    import_from = ast.ImportFrom(a, [ast.alias(a, None)], 0)
    assert inst.visit(import_from).module == b



# Generated at 2022-06-23 23:49:00.232992
# Unit test for function extend_tree
def test_extend_tree():
    tree = """
    if True:
        extend(vars_list)
    """
    t = ast.parse(tree)
    vars_list = [ast.Assign(targets=[ast.Name('x', None)], value=ast.Num(1)),
                 ast.Assign(targets=[ast.Name('x', None)], value=ast.Num(2))]
    extend_tree(t, {'vars_list': vars_list})
    assert ast.dump(t) == 'Module(body=[If(test=Constant(value=True, kind=None), body=[vars_list], orelse=[])])'



# Generated at 2022-06-23 23:49:00.710035
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-23 23:49:05.945857
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import unittest

    class TestVariablesReplacer(unittest.TestCase):
        """A class to test the visit_ImportFrom method."""

        # defines the first test to run
        def test_visit_import(self):
            import_ast = ast.parse("import py_backwards.snippet").body[0]
            variables = {"py_backwards": "some_local_name"}
            replaced_import_ast = VariablesReplacer.replace(import_ast, variables)
            self.assertEqual(ast.dump(replaced_import_ast), "Import(names=[alias(name='some_local_name.snippet', asname=None)])")
            self.assertIs(type(replaced_import_ast), ast.Import)

# Generated at 2022-06-23 23:49:13.506948
# Unit test for function extend_tree
def test_extend_tree():
    ast.fix_missing_locations = lambda node: None
    result = extend_tree(
        ast.parse('print(x, y)'),
        {'vars': [
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=1)
            ),
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=2)
            ),
        ]})
    assert get_source(result) == 'x = 1\nx = 2\nprint(x, y)'


# vim: foldmethod=indent foldlevel=0

# Generated at 2022-06-23 23:49:17.028120
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def snippet_test():
        x = 5
        y = 10
        let(z)
        let(vars)
        extend(vars)
        x = 5
        y = 7
        print('{} {}'.format(x, y))


if __name__ == "__main__":
    test_snippet()

# Generated at 2022-06-23 23:49:22.866801
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('''
    let('a')
    let('b')
    def c():
        let('c')
        let('d')
    '''))) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-23 23:49:28.997214
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class GetLength:
        def __len__(self):
            return 1

    t = ast.parse('GetLength().__len__()').body[0].value
    assert t.func.elts
    var = {
        'GetLength': GetLength()
    }

    t = VariablesReplacer.replace(t, var)
    assert len(t.func.elts) == 0

# Generated at 2022-06-23 23:49:33.449623
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(x)\na = 1')
    extend_tree(tree, {'x': ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1))})
    assert tree.body[1].value == ast.Num(1)

# Generated at 2022-06-23 23:49:43.380585
# Unit test for constructor of class snippet
def test_snippet():
    def f():
        let(x)
        y = 1
        z = 2
        x += 1


# Generated at 2022-06-23 23:49:52.817626
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    from .test_helpers import get_source, with_source
    
    def test():
        def fn(x, y):
            return x + y
        fn('x', 'y')
    
    output = with_source(test, get_source, True)
    assert 'x = "x"' in output
    assert 'y = "y"' in output
    assert '_py_backwards_fn_0' in output
    assert 'return x + y' in output
    assert '_py_backwards_fn_0(_py_backwards_x_0, _py_backwards_y_0)' in output
    print(output)



# Generated at 2022-06-23 23:50:00.904181
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    from .helpers import import_path
    tree = ast.parse("""
        class A:
            pass
    
        if x:
            class A:
                pass
            
        A = 1
        def A():
            pass
        
        def H():
            pass
            
        if x:
            def H():
                pass
            A = 2
            
        H = 3
    """)
    vars = {'x': 1, 'A': 'B', 'H': 'G'}
    replace = VariablesReplacer.replace
    replace(tree, vars)
    result = import_path(tree, 'A')
    assert result is None
    result = import_path(tree, 'B')
    assert isinstance(result, ast.ClassDef)
    assert isinstance(result, ast.FunctionDef)


# Generated at 2022-06-23 23:50:05.489845
# Unit test for function extend
def test_extend():
    def test():
        extend(assignments)

    assignments = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                              value=ast.Num(n=1)),
                   ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                              value=ast.Num(n=2))]
    code = snippet(test).get_body(assignments=assignments)

    assert len(code) == 3
    assert isinstance(code[0], ast.Assign)
    assert isinstance(code[0].targets[0], ast.Name)
    assert code[0].targets[0].id == 'x'
    assert isinstance(code[0].value, ast.Num)

# Generated at 2022-06-23 23:50:09.660219
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(var); print(x)')
    extend_tree(tree, {'var': [ast.parse('x = 1'), ast.parse('x = 2')]})
    assert astor.to_source(tree) == 'x = 1\nx = 2\nprint(x)\n\n'

# Generated at 2022-06-23 23:50:17.526716
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import sys
    import unittest
    from unittest.mock import patch, mock_open


# Generated at 2022-06-23 23:50:28.462545
# Unit test for function extend_tree
def test_extend_tree():
    snippet_tree = ast.parse("""
        x = 1
        let(y)
        """
    )
    vars_tree = ast.parse("""
        _py_backwards_x_0 = 2
        """
    )
    extend_tree(snippet_tree, {'vars': vars_tree.body})
    assert ast.dump(snippet_tree) == textwrap.dedent("""
        Module(body=[Assign(targets=[Name(id='_py_backwards_x_0', ctx=Store())], value=Num(n=1)), Module(body=[Assign(targets=[Name(id='_py_backwards_x_0', ctx=Store())], value=Num(n=2))])])
        """).strip()



# Generated at 2022-06-23 23:50:31.656292
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    code = "bla"
    tree = ast.parse(code)
    replacer = VariablesReplacer({"bla": "foo"})
    replacer.visit(tree)
    assert code == "bla"



# Generated at 2022-06-23 23:50:40.148973
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    a = 1
    b = 2
    let(a)
    let(b)
    try:
        pass
    except ValueError as a:
        b = 123

    expected = """
try:
    pass
except ValueError as _py_backwards_a_0:
    _py_backwards_b_0 = 123
    """
    expected = ast.parse(expected)
    variables = {'a': '_py_backwards_a_0',
                 'b': '_py_backwards_b_0'}
    assert VariablesReplacer.replace(actual, variables) == expected



# Generated at 2022-06-23 23:50:47.510924
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    valid_tree = ast.parse('from a.b.c import d')
    var = VariablesGenerator.generate('a.b.c')
    new_node = ast.alias('d', 'e')
    variables = {'a.b.c': var}
    replaced = VariablesReplacer.replace(valid_tree, variables)
    assert replaced.body[0].names[0].name == 'e'

# Generated at 2022-06-23 23:50:56.231115
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from .tests import VariablesReplacerExceptions
    from .tests import VariablesReplacer
    
    def f():
        let(x)
        try:
            1 / 0
        except IOError as e:
            print(x)
        
    source = get_source(f)
    tree = ast.parse(source)
    variables = find_variables(tree)
    extend_tree(tree, variables)
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    
    VariablesReplacerExceptions

# Generated at 2022-06-23 23:51:02.148343
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
a = 1
extend(vars)
b = 1
""")
    extend_tree(tree, {
        'vars': [ast.parse('c = 1').body[0]]
    })
    assert get_source(tree)[0] == """
a = 1
c = 1
b = 1
"""[1:]

# Generated at 2022-06-23 23:51:10.550620
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('def foo(a, b, c, d=3, e=4, f=5, g=6)\n pass')
    variables = {'a': 'z1', 'b': 'z2', 'c': 'z3', 'd': 'z4', 'e': 'z5', 'f': 'z6', 'g': 'z7'}
    replace = VariablesReplacer.replace(tree, variables)
    correct_tree = ast.parse('def foo(z1, z2, z3, d=z4, e=z5, f=z6, g=z7)\n pass')
    eq_(correct_tree, replace)



# Generated at 2022-06-23 23:51:19.194789
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class TestVariablesReplacer(VariablesReplacer):
        def visit_ExceptHandler(self, node: ast.ExceptHandler) -> ast.ExceptHandler:
            self._replace_field_or_node(node, 'name')
            return self.generic_visit(node)  # type: ignore

    source = """try:
        1 / 0
    except ZeroDivisionError as e:
        print(e)"""
    tree = ast.parse(source)
    variables = {'e': VariablesGenerator.generate('e')}
    TestVariablesReplacer.replace(tree, variables)
    assert(tree.body[0].handlers[0].name == variables['e'])

# Generated at 2022-06-23 23:51:31.155630
# Unit test for function extend
def test_extend():
    tree = ast.parse("""
        def f():
            x = 1
            y = 2
            
            extend(vars)
            print(x, y)
        """)

    vars = ast.parse("""
        x = 2
    """)

    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-23 23:51:38.686898
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import copy
    code1 = 'import x.y.z'
    code2 = 'import z.y.z'
    tree1 = ast.parse(code1)
    tree2 = ast.parse(code2)

    variables = {'x': 'z'}

    VariablesReplacer.replace(tree2, variables)

    assert ast.dump(tree1) == ast.dump(tree2)


# Generated at 2022-06-23 23:51:47.374675
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    """Testing VariablesReplacer."""
    def _do_test(source: str, variables: Dict[str, Variable],
                 expected: str) -> None:
        tree = ast.parse(source)
        VariablesReplacer.replace(tree, variables)
        assert ast.dump(tree) == expected

    _do_test("a = 1", {"a": "_py_backwards_a_0"},
             "a = 1")
    _do_test("a = 1", {"a": "a"},
             "a = 1")
    _do_test("a = 1", {},
             "a = 1")
    _do_test("a = 1", {"z": "_py_backwards_z_0"},
             "a = 1")

# Generated at 2022-06-23 23:51:55.224271
# Unit test for function extend
def test_extend():
    def snippet_with_extend():
        x = 5
        y = 7
        extend(vars)
        print(x + y)

    vars = [ast.Assign(
        [ast.Name(id='x', ctx=ast.Store())],
        ast.Num(1)
    ), ast.Assign(
        [ast.Name(id='x', ctx=ast.Store())],
        ast.Num(2)
    )]

# Generated at 2022-06-23 23:52:04.559111
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect

    def test_snippet(**kwargs):
        x = let(kwargs['x'])
        y = kwargs['y']
        return x * y

    # To make sure that test run for compiled code using bytecode
    fun_code = test_snippet.__code__
    fun_code = compile(fun_code.co_consts[1],
                       fun_code.co_filename,
                       fun_code.co_name,
                       'exec')  # type: ignore

    locals_ = locals()
    exec(fun_code, globals(), locals_)

    snippet = locals_['test_snippet']
    assert inspect.isfunction(snippet)

    code = snippet(x=1, y=2)
    assert code == 2


# Generated at 2022-06-23 23:52:05.464853
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:52:08.619240
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from a import b")
    variables = {'a': 'c'}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert tree.body[0].module == 'c'

# Generated at 2022-06-23 23:52:17.115861
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    node = ast.ImportFrom(module='module', names=[ast.alias(name='name', asname='asname')])
    replacer = VariablesReplacer({'module': 'module2', 'name': 'name2', 'asname': 'asname2'})
    replacer.visit_ImportFrom(node)
    assert node.module == 'module2'
    assert node.names[0].name == 'module2.name2'
    assert node.names[0].asname == 'asname2'


# Generated at 2022-06-23 23:52:25.370027
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    from typed_ast import ast3 as ast
    from .tree import replace_at

    def test(node, field_name, expected_node):
        class _MockNode(ast.AST):
            pass

        class _MockVisitor(ast.NodeVisitor):
            @staticmethod
            def visit(node):
                return node

        src = ast.parse("""def f(a):
    pass
""")
        v = VariablesReplacer({"a": "b"})
        n = ast.fix_missing_locations(src)
        n.body[0] = _MockNode()
        n.body[0].body = [node]
        n.body[0].name = "f"
        setattr(n.body[0], field_name, "a")

# Generated at 2022-06-23 23:52:35.979461
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # VariablesReplacer.visit_ClassDef should replace variables
    # and return new node
    
    class Replacement(ast.ClassDef):
        pass

    class NewNode(ast.Name):
        pass
    
    class Name(ast.Name):
        def __init__(self, id):
            self.id = id
    
    class ClassDef(ast.ClassDef):
        def __init__(self, name: ast.Name):
            self.name = name

    class AST(ast.AST):
        def __init__(self, name: ast.Name):
            self.name = name
    
    variables = {
        "a": Replacement,
        "b": NewNode,
        "c": ClassDef(Name("c"))
    }
    
    inst = VariablesReplacer(variables)

    #

# Generated at 2022-06-23 23:52:40.101200
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    nodes = ast.parse('from module import *').body
    target = 'from _py_backwards_module_0 import *'
    variables = {'module': '_py_backwards_module_0'}
    actual = VariablesReplacer.replace(nodes, variables)
    assert get_source(actual) == target

# Generated at 2022-06-23 23:52:43.710003
# Unit test for function extend
def test_extend():
    from .tree import get_source
    from .helpers import VariablesGenerator

    a = 1
    b = 2


# Generated at 2022-06-23 23:52:50.624873
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
    try:
        1 + 2
    except ValueError:
        print(1)
    except:
        print(2)
    """
    tree = ast.parse(source)
    variables = {'ValueError': 'ValueError2'}
    VariablesReplacer.replace(tree, variables)
    assert isinstance(tree.body[0].handlers[0], ast.ExceptHandler)
    assert isinstance(tree.body[0].handlers[1], ast.ExceptHandler)
    assert isinstance(tree.body[0].handlers[0].type, ast.Name)
    assert tree.body[0].handlers[0].type.id == 'ValueError2'

# Generated at 2022-06-23 23:52:56.389087
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    assert VariablesReplacer.replace(ast.parse('def f(x, y): x = 2; return y').body[0], {'x': 5, 'y': 'z'}).args.args == [ast.arg('z', None), ast.arg('x', None)]