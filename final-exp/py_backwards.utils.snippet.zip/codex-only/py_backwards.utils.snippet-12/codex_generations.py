

# Generated at 2022-06-23 23:43:01.574715
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    code = "def foo():\n    a.b.c += 1"
    tree = ast.parse(code)
    variables = {
        'a.b': 'a'
    }
    VariablesReplacer.replace(tree, variables)
    name_node = find(tree, ast.Name, 'a')[0]
    assert name_node.id == 'a'
    attr_node = find(tree, ast.Attribute, 'c')[0]
    assert attr_node.name == 'c'
    assert attr_node.value.id == 'a'

# Generated at 2022-06-23 23:43:10.070159
# Unit test for function extend
def test_extend():
    x = 1
    y = 2
    tree = ast.parse('''extend(vars)
    print(x, y)''')
    extend_tree(tree, {'vars': [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
                                 ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))]})
    assert ast.dump(tree) == 'Module(body=[Print(dest=None, values=[Name(id=\'x\', ctx=Load()), Name(id=\'y\', ctx=Load())], nl=True)])'



# Generated at 2022-06-23 23:43:11.061289
# Unit test for function extend
def test_extend():
    let(vars)

    extend(vars)



# Generated at 2022-06-23 23:43:21.644544
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    empty_snippet_source = """
    @decorator
    def function_name(arg1):
        return arg1
    """
    empty_snippet_tree = ast.parse(empty_snippet_source)
    empty_snippet = snippet(lambda: None)

    no_snippet_variables = {'arg1': 'arg2'}
    VariablesReplacer.replace(empty_snippet_tree, no_snippet_variables)
    assert get_source(empty_snippet_tree) == empty_snippet_source

    arg_snippet_source = """
    @decorator
    def function_name(arg1):
        print(arg1)
    """
    arg_snippet_tree = ast.parse(arg_snippet_source)

# Generated at 2022-06-23 23:43:32.029680
# Unit test for function extend
def test_extend():
    let(x)
    x = 1
    x = 2
    x = 3
    extend(vars)
    x = 4
    print(x)

# Generated at 2022-06-23 23:43:40.948825
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import astor  # type: ignore
    SOURCE_CODE = """
from pymongo import MongoClient

name = MongoClient().test
"""
    TREE = ast.parse(SOURCE_CODE)
    VARIABLES = {'MongoClient': astor.to_source(ast.Attribute(ast.Name('test', ast.Load()), 'collections', ast.Load()))}
    NEW_SOURCE = astor.to_source(VariablesReplacer.replace(TREE, VARIABLES))
    assert NEW_SOURCE == """
from test import collections

name = collections().test
"""

# Generated at 2022-06-23 23:43:50.669190
# Unit test for function extend
def test_extend():
    @snippet
    def test1():
        extend(a)
        a += 1
        b = 2

    a = [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                    value=ast.Num(1)),
         ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                    value=ast.Num(2))]


# Generated at 2022-06-23 23:44:00.945460
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x: Any, y: Any) -> None:
        let(x)
        let(y)
        x = y
        extend(y)

    snippet_obj = snippet(fn)
    body = snippet_obj.get_body(x='x_value', y=['y_value', 'y_value1'])

    assert isinstance(body[0], ast.Assign)
    assert body[0].targets[0].id == 'x_value'
    assert body[0].value.id == 'y_value'

    assert isinstance(body[1], ast.Assign)
    assert body[1].targets[0].id == 'x_value'
    assert body[1].value.id == 'y_value1'

# Generated at 2022-06-23 23:44:06.685030
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_function(x=let(1), y=let(2), z=let(3)):
        print(x, y, z)

    snippet_object = snippet(test_snippet_function)
    import astor
    ast_code = astor.to_source(snippet_object.get_body())
    assert ast_code == 'print(_py_backwards_x_0, _py_backwards_y_1, _py_backwards_z_2)\n'

# Generated at 2022-06-23 23:44:09.323449
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = 'try:\n  try:\n    print("try")\n  except Exception as exc:\n    pass\n'
    tree = ast.parse(source)

    inst = VariablesReplacer({})
    inst.visit(tree)

    assert ast.dump(tree) == source

# Generated at 2022-06-23 23:44:14.640901
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
    try:
        x = 1
    except (ValueError, Exception):
        x = 2
    """
    tree = ast.parse(source)
    variables = {'x': VariablesGenerator.generate('x')}
    ast.fix_missing_locations(VariablesReplacer.replace(tree, variables))

# Generated at 2022-06-23 23:44:25.692203
# Unit test for function let
def test_let():
    @snippet
    def test_snippet():
        a = 1
        b = 1
        let(a)
        a = 2 + a
        let(b)
    assert test_snippet.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Num(n=2),
                op=ast.Add(),
                right=ast.Name(id='a', ctx=ast.Load())
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='b', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]


# Generated at 2022-06-23 23:44:34.647498
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    var = ast.ClassDef("ClassDef_name",
                       [ast.Name("Name", ast.Load())],
                       [ast.FunctionDef("FunctionDef_name",
                                        ast.arguments(
                                            [ast.arg("arg", None)],
                                            None,
                                            [],
                                            [],
                                            None,
                                            []
                                        ),
                                        [ast.Return(ast.Num(42))],
                                        [])],
                       [ast.Assign([ast.Name("Name", ast.Store())],
                                   ast.Num(42))])
    tree_with_var = ast.Module([var])
    vars_dict = {"ClassDef_name": "ClassDef_name_2",
                 "FunctionDef_name": "FunctionDef_name_3"}
    res

# Generated at 2022-06-23 23:44:41.519946
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    arg = ast.arg(arg=ast.Name(id='x', ctx=ast.Load()), annotation=None)
    replacer = VariablesReplacer({'x': 'x1', 'x1': 'x2'})
    replacer.visit_arg(arg)
    assert isinstance(arg, ast.arg)
    assert isinstance(arg.arg, ast.Name)
    assert arg.arg.id == 'x2'


# Generated at 2022-06-23 23:44:43.365836
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    try:
        raise NotImplementedError
    except NotImplementedError:
        pass



# Generated at 2022-06-23 23:44:45.070820
# Unit test for function extend_tree

# Generated at 2022-06-23 23:44:46.183882
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:44:49.126573
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    from . import snippets
    source = get_source(snippets.test_VariablesReplacer_visit_Name)
    tree = ast.parse(source)
    variables = {"x": "y", "z": "w"}
    expected_source = get_source(snippets.test_VariablesReplacer_visit_Name_expected)
    expected_tree = ast.parse(expected_source)
    VariablesReplacer.replace(tree, variables)
    assert tree == expected_tree

# Generated at 2022-06-23 23:44:54.241497
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    src = """
from a import A
import b as B
from c import C as D

    """
    tree = ast.parse(src)
    VariablesReplacer.replace(tree, {
        'a': 'x',
        'b': 'y',
        'c': 'z'
    })
    assert ast.dump(tree) == """Module(body=[ImportFrom(module='x', names=[alias(name='A', asname=None)], level=0), Import(names=[alias(name='y', asname='B')]), ImportFrom(module='z', names=[alias(name='C', asname='D')], level=0)])"""

# Generated at 2022-06-23 23:44:56.884897
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        return x

    body = snippet(fn).get_body()
    assert body == [ast.Return(value=VariablesGenerator.generate('x'))]

# Generated at 2022-06-23 23:44:57.465186
# Unit test for function find_variables

# Generated at 2022-06-23 23:45:07.020571
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    # import this module so we can generate a Module
    # from a string
    from . import backwards
    # construct
    var = VariablesGenerator.generate('a')
    b = ast.alias('some.module', None)
    # expected
    expected = ast.alias('some.module', None)
    expected.name = 'some.module.' + var
    # actual
    actual = VariablesReplacer.replace(b, {'a':var})
    # check
    if astor.to_source(actual) != astor.to_source(expected):
        raise AssertionError('Name of alias was not properly replaced')
    # if we get here we're good to go

# Generated at 2022-06-23 23:45:08.157642
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer({}) is not None

# Generated at 2022-06-23 23:45:16.875558
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    code = """
        import a
        class MyClass(object):
            def __init__(self):
                pass
    """
    # TODO maybe the next import should be in the upper level
    from typed_ast.ast3 import parse
    tree = parse(code)
    variables = {'MyClass': 'MyClass_backwards_0'}
    VariablesReplacer.replace(tree, variables)
    assert(get_source(tree).strip() == """
        import a
        class MyClass_backwards_0(object):
            def __init__(self):
                pass""".strip())

# Generated at 2022-06-23 23:45:22.713258
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = 'from a import b, c as d'
    tree = ast.parse(source)
    variables = {'b': 'e', 'd': 'f'}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert tree.body[0].module == 'a'
    assert len(tree.body[0].names) == 2
    assert tree.body[0].names[0].name == 'e'
    assert tree.body[0].names[0].asname is None
    assert tree.body[0].names[1].name == 'c'
    assert tree.body[0].names[1].asname == 'f'


# Generated at 2022-06-23 23:45:28.320903
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    variables = {"y": "x"}
    tree = ast.parse('obj.y = 1')
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Assign(targets=[Attribute(value=Name(id='obj', ctx=Load()), attr='x', ctx=Store())], value=Constant(value=1, kind=None))"



# Generated at 2022-06-23 23:45:34.703344
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import inspect
    snippet = """
    let(Base)
    class Derived(Base):
        pass
    """
    tree = ast.parse(inspect.getsource(test_VariablesReplacer_visit_ClassDef))
    replace_tree = tree.body[0].body

    original_class_def_node = replace_tree[0]
    assert original_class_def_node.name == 'Base'
    assert original_class_def_node.bases == []

    derived_class_def_node = replace_tree[1]
    assert derived_class_def_node.name == 'Derived'
    assert derived_class_def_node.bases[0].id == 'Base'

    new_variables = {'Base': '_py_backwards_Base_0'}


# Generated at 2022-06-23 23:45:45.502300
# Unit test for constructor of class snippet
def test_snippet():
    class Test:
        @snippet
        def test_snippet(func_var: str) -> None:
            func_var += '123'
            print(func_var)

    assert Test.test_snippet.get_body() == \
        ast.parse("""
            func_var_0 += '123'
            print(func_var_0)
        """).body
    assert Test.test_snippet.get_body(func_var='value') == \
        ast.parse("""
            value += '123'
            print(value)
        """).body

# Generated at 2022-06-23 23:45:50.026677
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
    let(x)
    x = 5
    y.x = 3
    let(a)
    a = 2
    b = 4
    ''')
    variables = find_variables(tree)
    assert list(variables) == ['x', 'a']



# Generated at 2022-06-23 23:45:57.685823
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    names = find_variables(ast.parse("""
try:
    0
except IndexError as ex:
    raise ex
    """).body[0])
    variables = {name: VariablesGenerator.generate(name) for name in names}

    class test_VariablesReplacer(VariablesReplacer):
        def visit_ExceptHandler(self, node):
            node = self._replace_field_or_node(node, 'name')
            return self.generic_visit(node)

    VariablesReplacer.replace(ast.parse("""
try:
    0
except IndexError as ex:
    raise ex
    """).body[0], variables)

# Generated at 2022-06-23 23:45:58.529442
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-23 23:46:01.803862
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class X:
        pass
    class Y:
        pass
    x = X()
    y = Y()

# Generated at 2022-06-23 23:46:02.951146
# Unit test for method visit_Name of class VariablesReplacer

# Generated at 2022-06-23 23:46:11.419701
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import astor
    node = ast.parse("node.test_attrib").body
    replace = {
        "test_attrib": "test_attrib_replace"
    }
    # Create new instance of VariablesReplacer
    vr = VariablesReplacer(replace)
    result = vr.visit(node)
    # The result should be: <_ast.Module object at 0x000001B2C72F9978>
    assert isinstance(result, ast.Module)
    # The source code should be: 'node.test_attrib_replace\n'
    assert astor.to_source(result).rstrip() == 'node.test_attrib_replace'


# Generated at 2022-06-23 23:46:13.979074
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    node = ast.FunctionDef()
    node.name = 'foo'
    variables = {'foo': 'bar'}
    replacer = VariablesReplacer(variables)
    assert replacer.visit(node).name == 'bar'



# Generated at 2022-06-23 23:46:18.743907
# Unit test for function extend
def test_extend():
    extend(ast.parse("x = 1").body)
    assert extend.get_body().body == ast.parse("x = 1\n").body

    extend(ast.parse("x = 1\nx = 2").body)
    assert extend.get_body().body == ast.parse("x = 1\nx = 2\n").body


# Generated at 2022-06-23 23:46:25.412804
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    # GIVEN: Function with extension and unique variable declaration
    @snippet
    def test_visit_arg(var1: ast.arg):
        extend(var1)
        let(var1)

    # WHEN: Get AST of this snippet
    body = test_visit_arg.get_body()

    # THEN: Check that extension and unique variable declaration works properly
    assert body[0].args[0].arg == '_py_backwards_var1_0' and isinstance(body[0], ast.AnnAssign)



# Generated at 2022-06-23 23:46:28.655756
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("from a import x as b")
    variables = {
        "a": "a1",
        "x": "b1",
        "b": "b"
    }
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == "from a1 import b1 as b"


# Generated at 2022-06-23 23:46:31.895067
# Unit test for function extend_tree
def test_extend_tree():
    snippet_a = 'x = 3'
    snippet_b = 'var = extend(snippet_a) \n print(var + 5)'
    assert ast.parse(snippet_b).body[1].value.value.n == 8


# Generated at 2022-06-23 23:46:39.750015
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    from .test_tree import parse
    from . import backwards
    import inspect

    source = inspect.getsource(backwards)
    tree = ast.parse(source)
    variables = {name: VariablesGenerator.generate(name)
                 for name in find_variables(tree)}
    replace_tree = VariablesReplacer.replace(tree, variables)
    names = set()
    # Check that all keyword args are replaced
    for node in find(replace_tree, ast.keyword):
        assert node.arg not in names
        names.add(node.arg)

# Generated at 2022-06-23 23:46:44.475810
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def f():
        let(a)
        let(b)
        let(a)
        return b

    variables = f._get_variables({'a': 1, 'b': 2}, {})
    assert variables == {
        'a': '_py_backwards_a_0',
        'b': '_py_backwards_b_0'
    }

# Generated at 2022-06-23 23:46:47.304057
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse('''
        let('1')
        let('2')
        let('3')
    ''')) == ['1', '2', '3']



# Generated at 2022-06-23 23:46:57.771971
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    # Arrange
    class FunctionDefArg(FunctionDef):
        def __init__(self, arguments):
            self.arguments = arguments
            self.name = 'abc'
            self.returns = None
            self.decorator_list = []

    input_ = FunctionDefArg(arguments=Arguments(args=[arg(arg='test_test')],
                                               vararg=None,
                                               kwonlyargs=[],
                                               kw_defaults=[],
                                               kwarg='',
                                               defaults=[]))


# Generated at 2022-06-23 23:47:03.317741
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Foo:
        def bar(self):
            pass
    
    class DummyCallable(ast.Call):
        arguments = [ast.Name('x')]
        func = ast.Attribute(ast.Name('Foo'), ast.Name('bar'))
        
    class DummyFunctionDef(ast.FunctionDef):
        body = [DummyCallable()]
        name = 'x'
        
    class DummyAssign(ast.Assign):
        value = ast.Name('x')
        targets = [ast.Attribute(ast.Name('Foo'), ast.Name('x'))]
        
    class DummyClassDef(ast.ClassDef):
        body = [DummyAssign()]
        name = 'x'
    
    DummyMain = DummyFunctionDef
    
    DummyTree = Dummy

# Generated at 2022-06-23 23:47:11.556220
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')
    vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=1)),
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == 'x = 1\nx = 2\nprint(x, y)'



# Generated at 2022-06-23 23:47:20.247421
# Unit test for function let
def test_let():
    @snippet
    def snippet():
        let(x)
        x += 1
        y = 1

    body = snippet.get_body()
    assert len(body) == 3
    assert isinstance(body[0], ast.Assign)
    assert body[0].targets[0].id == 'x'
    assert isinstance(body[1], ast.AugAssign)
    assert body[1].target.id == '_py_backwards_x_0'
    assert isinstance(body[2], ast.Assign)
    assert body[2].targets[0].id == 'y'


# Generated at 2022-06-23 23:47:30.573379
# Unit test for function extend
def test_extend():
    # type: () -> None
    @snippet
    def s(x=let(1), y=let(2)):
        x += 1
        extend(y)
        print(x, y)

    s(y=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                    value=ast.Num(n=1)),
         ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                    value=ast.Num(n=2))])
    
    body = s.get_body()

# Generated at 2022-06-23 23:47:33.321446
# Unit test for function let
def test_let():
    def code():
        let(a)
        a += 1
        b = 1
        c = a + b

    tree = snippet(code).get_body()
    assert get_source(code) == get_source(tree)

# Generated at 2022-06-23 23:47:41.649957
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def snippet_code1(x: int, y: int) -> int:
        let(x)
        x += 1
        z = x + y
        return z

    @snippet
    def snippet_code2(x: int, y: int) -> int:
        let(x)
        x += 1
        z = x + y
        return z

    # Test that it doesn't matter if snippet is in module or not
    assert snippet_code1.get_body(x=0, y=9) == snippet_code2.get_body(x=0, y=9)

# Generated at 2022-06-23 23:47:48.344397
# Unit test for function let
def test_let():
    snippet_code = '''
        def code_snippet():
            let(x)
            x += 1
            y = 1
    '''
    snippet_ast = ast.parse(snippet_code)
    snippet_ast.body[0].body.pop()
    _fn = snippet(code_snippet).get_body()
    assert ast.dump(_fn) == ast.dump(snippet_ast.body[0].body)


# Generated at 2022-06-23 23:47:53.281736
# Unit test for function find_variables
def test_find_variables():
    # type: () -> None
    """Checks if find_variables outputs variables correctly"""
    def test_func():
        # type: () -> None
        let(x)
        let(y)
        let(z)

    source = get_source(test_func)
    tree = ast.parse(source)
    assert sorted(find_variables(tree)) == ["x", "y", "z"]


# Generated at 2022-06-23 23:47:57.315730
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_func():
        let(x)
        x = 1
        y = 2
        print(x, y)

    assert snippet(test_func).get_body(x=5) == test_func.__code__.co_consts[5].body



# Generated at 2022-06-23 23:48:02.879070
# Unit test for function find_variables
def test_find_variables():
    code = """
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """

    tree = ast.parse(code)
    assert [name for name in find_variables(tree)] == ['x', 'y', 'z']



# Generated at 2022-06-23 23:48:04.029944
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(None) is not None



# Generated at 2022-06-23 23:48:08.942816
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .tree import dump

    tree = ast.parse('''
    from . import x as y
    ''')

    variables = {'y': 'xxx'}
    res = VariablesReplacer.replace(tree, variables)
    assert res is not tree
    assert dump(res) == '''
    from . import x as xxx
    '''

# Generated at 2022-06-23 23:48:18.672584
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse("def f(x: a) -> None: pass")
    variables = {'a': ast.Call(ast.Name('b', ast.Load()), [], [])}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='f', args=arguments(args=[arg(arg='x', annotation=Call(func=Name(id='b', ctx=Load()), args=[], keywords=[]))], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])"

# Generated at 2022-06-23 23:48:27.744163
# Unit test for function extend
def test_extend():
    def snippet1():
        extend(vars)
        print(x, y)

    vars = ast.Module(body=[
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ])
    tree = snippet1.get_body(vars=vars)

# Generated at 2022-06-23 23:48:31.040519
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    assert isinstance(ast.parse("_py_backwards_x_0").body[0], ast.Expr)




# Generated at 2022-06-23 23:48:35.081606
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    a = ast.parse("x = 1\n").body[0]

    v = {
        'x': 'y'
    }

    b = VariablesReplacer.replace(a, v)
    assert b.targets[0].id == 'y'

# Generated at 2022-06-23 23:48:41.625520
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("try: a = 1\nexcept ValueError as e: a = 2")
    vg = VariablesGenerator()
    variables = {"e": "a"}
    VariablesReplacer.replace(tree, variables)
    body = tree.body[0]
    assert isinstance(body, ast.Try)
    assert len(body.handlers) == 1
    handler = body.handlers[0]
    assert isinstance(handler, ast.ExceptHandler)
    assert handler.name == "a"



# Generated at 2022-06-23 23:48:44.291500
# Unit test for function find_variables

# Generated at 2022-06-23 23:48:50.980794
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1

    snippet = snippet(f)
    body = snippet.get_body(x='y')
    assert body == [ast.Assign([ast.Name(id='y')], ast.Num(1)),
                    ast.Assign([ast.Name(id='y')], ast.BinOp(ast.Name(id='y'),
                                                             ast.Add(),
                                                             ast.Num(1)))]

# Generated at 2022-06-23 23:48:55.536369
# Unit test for constructor of class snippet
def test_snippet():
    def snippet_fn():
        x = let(3.5)
        y = let(4)
        x + y
    
    snippet_instance = snippet(snippet_fn)
    
    assert str(snippet_instance.get_body()) == '_py_backwards_x_0 + _py_backwards_y_0'

# Generated at 2022-06-23 23:48:59.985197
# Unit test for function find_variables
def test_find_variables():
    assert set(find_variables(ast.parse('''
        let(a)
        let(b)
    '''))) == {'a', 'b'}



# Generated at 2022-06-23 23:49:02.260760
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    node = ast.Name(id='foo', ctx=ast.Load())
    variables = {'foo': 'bar'}
    newTree = VariablesReplacer.replace(node, variables)
    assert newTree.id == 'bar'


# Generated at 2022-06-23 23:49:10.505532
# Unit test for function extend_tree
def test_extend_tree():
    source = 'extend(variables)'
    tree = ast.parse(source)
    variables = {'variables': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                         value=ast.Num(n=1))]}
    extend_tree(tree, variables)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1))])'

# Generated at 2022-06-23 23:49:19.180974
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    input = """def method(a):\n  a = 1\n  for i in range(10):\n    print("a")\n  if a == 1:\n    pass\n  else:\n    pass\n  return"""
    output = """def _py_backwards_method_0(a):\n  a = 1\n  for i in range(10):\n    print("a")\n  if a == 1:\n    pass\n  else:\n    pass\n  return"""
    tree = ast.parse(input)
    variables = {'method': '_py_backwards_method_0'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == output


# Generated at 2022-06-23 23:49:24.890410
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def test_function():
        pass

    source = get_source(test_function)
    tree = ast.parse(source)

    variables = {'test_function': 'test_function_name'}
    VariablesReplacer.replace(tree, variables)

    node = tree.body[0]
    assert isinstance(node, ast.FunctionDef)
    assert node.name == 'test_function_name'



# Generated at 2022-06-23 23:49:31.237552
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    node = ast.arg("test_name", None)
    variables = {
        "test_name": "new_name"
    }
    expected = ast.arg("new_name", None)
    replaced = VariablesReplacer.replace(node, variables)
    assert replaced.__repr__() == expected.__repr__()


# Generated at 2022-06-23 23:49:36.665368
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    original = ast.parse("""
import os.path as path
path
    """)
    expected = ast.parse("""
import os.path as path_0
path_0
    """)
    result = VariablesReplacer.replace(original, {'path': 'path_0'})
    assert ast.dump(result, include_attributes=False) == ast.dump(expected, include_attributes=False)



# Generated at 2022-06-23 23:49:37.910916
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: let(x))



# Generated at 2022-06-23 23:49:44.868800
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    def fn():
        import abc
        class Foo(metaclass=abc.ABCMeta):
            class_attr = 2

        @property
        def f():
            return Foo.class_attr

    block = snippet(fn).get_body()

    assert block[0].target.attr == 'class_attr'
    assert block[0].value.value == 2

    assert block[2].args[0].id == 'class_attr'



# Generated at 2022-06-23 23:49:49.716973
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # When
    tree = ast.parse('from foo import bar as baz')
    variables = {'foo': 'bar'}
    new_tree = VariablesReplacer.replace(tree, variables)
    # Then
    assert new_tree.body[0].module == 'bar'


# Generated at 2022-06-23 23:49:55.306943
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    source = 'a.b'
    target = 'a.b'
    tree = ast.parse(source)
    #not using real VariableGenerator because I'm lazy
    var_gen = lambda x:x
    variables = find_variables(tree)
    variable_map = {var: var_gen(var) for var in variables}
    tree_2 = VariablesReplacer.replace(tree, variable_map)
    new_source = get_source(tree_2)
    assert new_source == target


# Generated at 2022-06-23 23:50:03.426212
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Class1:
        pass

    class Class2:
        pass

    class Class3:
        pass

    tree = ast.parse("""Class1.Class2.Class3""")
    variables = {'Class1': '_0',
                 'Class2': '_1',
                 'Class3': '_2'}
    result = ast.dump(VariablesReplacer.replace(tree, variables))
    expected = "Attribute(value=Name(id='_0', ctx=Load()), attr='_1', ctx=Load())"
    assert(result == expected)



# Generated at 2022-06-23 23:50:08.168729
# Unit test for function extend
def test_extend():
    snippet_1 = snippet(lambda k: print(k))
    tree = ast.parse('extend(x)')
    variables = snippet_1._get_variables(tree, {'x': '1'})
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == '1'

# Generated at 2022-06-23 23:50:14.963976
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import get_source_from_tree

    func = ast.parse(
        'from var_module import var_name as var_name2\n'
        'var_name2').body[0]  # type: ignore

    VariablesReplacer.replace(func, {'var_name': 'var_name3'})

    source = get_source_from_tree(func)
    assert source == (
        'from var_module import var_name3 as var_name2\n'
        'var_name2')

# Generated at 2022-06-23 23:50:16.078818
# Unit test for constructor of class snippet
def test_snippet():
    snippet_ = snippet(lambda x: x)

    assert snippet_ is not None

# Generated at 2022-06-23 23:50:27.146348
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import pytest
    import sys

    code = "import a, b.d as c\n" \
           "from utils.a import b as c\n" \
           "from utils import a as b, c\n"
    variables = {'a': 'new_a', 'b': 'new_b'}
    tree = ast.parse(code)
    tree = VariablesReplacer.replace(tree, variables)
    exec(compile(tree, filename="<ast>", mode='exec'), sys._getframe(1).f_globals)

    assert "import new_a, new_b.d as new_b\n" \
           "from utils.a import b as c\n"  \
           "from utils import new_a as new_b, c\n" == code

# Generated at 2022-06-23 23:50:31.460939
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source = 'x = 1'
    tree = ast.parse(source)
    variables = {'x': 'y'}
    inst = VariablesReplacer(variables)
    inst.visit_Name(tree.body[0].targets[0])
    assert get_source(tree) == 'y = 1'


# Generated at 2022-06-23 23:50:38.114338
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-23 23:50:44.280269
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = """
from re import a, _b, c as d
from re import x as y, _z
from re import a as b
"""
    variables = {'_b': 'foo', '_z': 'bar'}
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:50:52.143696
# Unit test for function let
def test_let():
    @snippet
    def my_snippet():
        let(x)
        x += 1
        y = 1

    assert my_snippet.get_body() == [
        ast.Assign(
            targets=[ast.Name(id=generator.variable('x'))],
            value=ast.BinOp(
                left=ast.Name(id=generator.variable('x')),
                op=ast.Add(),
                right=ast.Constant(value=1, kind=None),
            ),
            type_comment=None,
        ),
        ast.Assign(
            targets=[ast.Name(id='y')],
            value=ast.Constant(value=1, kind=None),
            type_comment=None,
        ),
    ]

    assert my_snippet.get

# Generated at 2022-06-23 23:50:53.066098
# Unit test for method visit_Name of class VariablesReplacer

# Generated at 2022-06-23 23:51:00.281762
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    src = """
        def f(x, y):
            pass
    """
    tree = ast.parse(src)
    VariablesReplacer.replace(tree, {'x': 42})
    assert(ast.dump(tree) == "Module(body=[FunctionDef(name='f', args=arguments(args=[arg(arg='x', annotation=None), arg(arg='y', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])")

# Generated at 2022-06-23 23:51:07.632819
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    # The expression is: call(Arg(1), name="a")
    # This expression represents: call(1, name="a")
    expression = ast.Call(ast.Name("call"), [ast.keyword(ast.Name("a"), ast.Num(1))], [], None, None)
    # The expected expression is: call(Arg(1), name="a_new_name")
    # This expected expression represents: call(1, name="a_new_name")
    expected_expression = ast.Call(ast.Name("call"), [ast.keyword(ast.Name("a_new_name"), ast.Num(1))], [], None, None)

    variables = {"a": ast.Name("a_new_name")}

    new_expression = VariablesReplacer.replace(expression, variables)


# Generated at 2022-06-23 23:51:11.385246
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
x += 1
y = 1

let(z)
z += 1
    
""")
    variables = find_variables(tree)
    assert list(variables) == ['x', 'z']

# Generated at 2022-06-23 23:51:20.472011
# Unit test for function extend
def test_extend():
    class A:
        @snippet
        def extend_snippet(vars):
            assign1 = ast.Assign([ast.Name('x', ast.Store())], ast.Num(1))
            assign2 = ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))
            extend(vars)
            print(x, y)

    a = A()
    result = a.extend_snippet(vars=[assign1, assign2])
    assert result == [assign1, assign2, ast.Expr(ast.Call(ast.Name('print', ast.Load()), [ast.Name('x', ast.Load()), ast.Name('y', ast.Load())], []))]


# Generated at 2022-06-23 23:51:29.622746
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source =\
'''try:
    print('hi')
except Exception as e:
    raise'''

    tree = ast.parse(source)

    variables = find_variables(tree)
    variables['e'] = '_py_backwards_e_qwerty'

    VariablesReplacer.replace(tree, variables)

    expected =\
'''try:
    print('hi')
except Exception as _py_backwards_e_qwerty:
    raise'''

    assert ast.dump(tree) == expected

# Generated at 2022-06-23 23:51:33.315271
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class Call(ast.Call):
        pass

    class Name(ast.Name):
        pass

    class Keyword(ast.keyword):
        pass

    tree = ast.parse('''
        def function(a, b, arg1 = 1, arg2 = 2, arg3 = 3):
            return arg1
    ''')
    variables = {'a': '_py_backwards_a_0', 'b': '_py_backwards_b_0'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == get_source('''
        def function(_py_backwards_a_0, _py_backwards_b_0, arg1 = 1, arg2 = 2, arg3 = 3):
            return arg1
    ''')


# Generated at 2022-06-23 23:51:34.850333
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    node = ast.arg(arg='c', annotation=None)
    variables = {'c': 'b'}
    assert VariablesReplacer.replace(node, variables).arg == 'b'

# Generated at 2022-06-23 23:51:42.747956
# Unit test for function extend
def test_extend():
    def foo():
        extend(vars)
        print(x, y)
    
    x = 1
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], 
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], 
                       value=ast.Num(n=2))]
    
    tree = snippet(foo).get_body(vars=vars)
    exec(compile(ast.Module(body=tree), filename='<ast>', mode='exec'))


# Generated at 2022-06-23 23:51:50.357220
# Unit test for function extend
def test_extend():
    def inc(x):
        return ast.BinOp(x, ast.Add(), ast.Num(1))

    @snippet
    def f():
        x = 0
        extend(vars)
        print(x)

    body = f.get_body(vars=[
        ast.Assign(
            targets=[ast.Name('x', ast.Store())],
            value=inc(ast.Name('x', ast.Load()))),
        ast.Assign(
            targets=[ast.Name('x', ast.Store())],
            value=inc(ast.Name('x', ast.Load()))),
    ])
    # will end up like:
    #     x = 0
    #     x = x + 1
    #     x = x + 1
    #     print(x)

# Generated at 2022-06-23 23:51:58.068029
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    input = ast.parse('''
        try:
            pass
        except ex:
            pass
    ''')
    expected = ast.parse('''
        try:
            pass
        except ex:
            pass
    ''')

    input.body[0].body[0].body[0].name = 'ex' # type: ignore
    node = VariablesReplacer.replace(input, {})

    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 23:52:03.624631
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_with_let():
        let(x)
        let(y)
        x += 1
        y = 1

    body = snippet(snippet_with_let).get_body()
    assert isinstance(body[0], ast.Assign)
    assert body[0].targets[0].id == '_py_backwards_x_0'
    assert body[1].value.id == '_py_backwards_y_1'



# Generated at 2022-06-23 23:52:08.859030
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """try:
    pass
except Exception as e:
    pass
except Exception:
    pass
finally:
    pass
"""
    tree = ast.parse(source)
    lst = VariablesReplacer.replace(tree,['e']).body[0].body[1].body[0].value.targets[0]
    assert(str(lst)=='_py_backwards_e_0')
    lst = VariablesReplacer.replace(tree,['e']).body[0].body[1].body[1]
    assert(str(lst)=='pass')

# Generated at 2022-06-23 23:52:20.793547
# Unit test for function extend
def test_extend():
    def set_a_b_c() -> ast.Assign:
        a = ast.Name('a', ast.Store())
        b = ast.Name('b', ast.Store())
        c = ast.Name('c', ast.Store())
        a_assign = ast.Assign(targets=[a], value=ast.Num(1))
        b_assign = ast.Assign(targets=[b], value=ast.Num(2))
        c_assign = ast.Assign(targets=[c], value=ast.Num(3))
        return ast.Assign(targets=[], value=ast.Tuple(elts=[a_assign, b_assign, c_assign], ctx=ast.Store()))


# Generated at 2022-06-23 23:52:32.074070
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Foo:
        def __init__(self, x: int) -> None:
            self.x = x
    
    tree = ast.parse(get_source(Foo))
    replacer = VariablesReplacer({'x': 'y'})
    replacer.visit(tree)

# Generated at 2022-06-23 23:52:41.533357
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    """
    Create a AST with a function with a parameter.
    Replace the parameter.
    Check the output.
    """
    tree = ast.parse("def foo(bar):\n\treturn bar")
    vari = {"bar":"baz"}
    VariablesReplacer.replace(tree, vari)
    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=foo, args=arguments(args=[arg(arg=baz, annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=baz)], decorator_list=[], returns=None)])'


# Generated at 2022-06-23 23:52:47.215404
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = 'from sys import path'
    tree = ast.parse(source)
    variables = {'sys': ast.Name(id='os', ctx=ast.Load())}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'Module(body=[ImportFrom(module="os", names=[alias(name="path", asname=None)], level=0)])'



# Generated at 2022-06-23 23:52:53.663170
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""try:
    pass
except NameError as e:
    raise e""")
    variables = {'e': VariablesGenerator.generate('e')}
    visit = VariablesReplacer(variables)
    visit.visit(tree)
    assert get_source(tree) == """try:
    pass
except NameError as _py_backwards_e_0:
    raise _py_backwards_e_0"""

# Generated at 2022-06-23 23:52:58.370246
# Unit test for function let
def test_let():
    @snippet
    def f():
        let(x)
        x += 1
        y = 1
        print(x, y)

    assert f.get_body() == ast.parse('print(_py_backwards_x_0,1)').body

