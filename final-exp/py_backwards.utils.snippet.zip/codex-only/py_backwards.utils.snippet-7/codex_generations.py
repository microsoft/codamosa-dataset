

# Generated at 2022-06-23 23:42:55.953812
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    assert isinstance(VariablesReplacer.visit_Name(None, ast.Name(id='MyName')), ast.Name)

# Generated at 2022-06-23 23:43:03.809238
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = {'vars': [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        ),
    ]}
    extend_tree(tree, vars)
    res = ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """)
    assert res.body == tree.body

# Generated at 2022-06-23 23:43:14.516041
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    snippet_vars = {
        'x': x
    }

    def snippet_print(x: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_print_wrap = snippet(snippet_print)
    body = snippet_print_wrap.get_body(**snippet_vars)


# Generated at 2022-06-23 23:43:15.973191
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import astor

# Generated at 2022-06-23 23:43:16.984677
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-23 23:43:21.448926
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    name = ast.Name('foo', ast.Load())
    assert VariablesReplacer.replace(name, {}) == ast.Name('foo', ast.Load())
    assert VariablesReplacer.replace(name, {'foo': 'foo_'}) == ast.Name('foo_', ast.Load())



# Generated at 2022-06-23 23:43:27.611927
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    expected_result = 'from ast import parse'
    name = 'parse'
    alias = 'parse'
    node = ast.alias(name=name, asname=alias)

    replacer = VariablesReplacer({})
    result = replacer.visit_alias(node).__repr__()
    assert result == expected_result, 'Wrong result in class VariablesReplacer method visit_alias'

# Generated at 2022-06-23 23:43:35.273031
# Unit test for function find_variables

# Generated at 2022-06-23 23:43:41.040401
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    test_tree_data = ast.parse("kw=1")
    test_tree = test_tree_data.body[0]
    test_kw = test_tree.value
    test_variables = {"kw":"new_kw"}
    inst = VariablesReplacer(test_variables)
    inst.visit_keyword(test_kw)
    assert(test_kw.arg == "new_kw")

# Generated at 2022-06-23 23:43:46.322084
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet.get_body(test_snippet_get_body.x, test_snippet_get_body.y) == [
        ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name('y', ast.Store())], ast.Num(2))
    ]

# Generated at 2022-06-23 23:43:50.462302
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = """
    from foo import bar as baz
    """
    tree = ast.parse(source)
    variables = {'bar': 'new_bar'}
    VariablesReplacer.replace(tree, variables)
    expected_source = """
    from foo import new_bar as baz
    """
    new_source = ast.unparse(tree)
    print(new_source == expected_source)



# Generated at 2022-06-23 23:43:53.511249
# Unit test for constructor of class snippet
def test_snippet():
    def test_snippet(a: ast.Name, b: ast.Name):
        """Function with docstring."""

    assert snippet(test_snippet)._fn == test_snippet

# Generated at 2022-06-23 23:44:04.035613
# Unit test for function extend_tree
def test_extend_tree():
    a = ast.parse('a = 1')
    b = ast.parse('b = 2')

    tree = ast.parse(
        '''\
extend(a)
extend(b)
c = 3
'''
    )

    extend_tree(tree, dict(a=a, b=b))


# Generated at 2022-06-23 23:44:11.670678
# Unit test for function extend
def test_extend():
    def extend_snippet(x, y):
        x = 1
        y = 1
        print(x + y)
        extend(vars)
        print(x, y)
    vars = ast.Expression(ast.Tuple(elts=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]))
    # vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]
    src = snippet(extend_snippet).get_body(vars=vars)

# Generated at 2022-06-23 23:44:20.418113
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = 'from a import b'
    tree = ast.parse(source)
    variables = {'a': 'a1'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse('from a1 import b'))
    variables = {'b': 'b1'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse('from a1 import b1'))

# Generated at 2022-06-23 23:44:31.140748
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    """Test of constructor VariablesReplacer"""

# Generated at 2022-06-23 23:44:35.039998
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse("""
    def fn(a, b=2):
        pass
    """)
    arg = find(tree, ast.arg)[0]

    replacer = VariablesReplacer({"a": "b"})
    replaced_arg = replacer.visit_arg(arg)

    assert replaced_arg.arg == "b"


# Generated at 2022-06-23 23:44:46.459559
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import astor
    import_from = "from foo import bar"
    tree = ast.parse(import_from)
    # print(astor.to_source(tree).strip())

    node = tree.body[0]
    assert isinstance(node, ast.ImportFrom)
    assert str(node.module) == 'foo'
    assert str(node.names[0].name) == 'bar'

    variables = {'foo': 'bar'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)

    # print(astor.to_source(tree).strip())
    assert str(node.module) == 'bar'
    assert str(node.names[0].name) == 'bar'

    # Same for relative imports
    for_relative = "from .foo import bar"
    tree

# Generated at 2022-06-23 23:44:47.305461
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = let(1)
    y = let(2)
    extend(let(x + y))



# Generated at 2022-06-23 23:44:50.028220
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    code = '''class X:
    def m(self):
        return 1
'''
    tree = ast.parse(code)
    variables = {'X': 'Y'}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert get_source(tree) == 'class Y:\n    def m(self):\n        return 1\n'

# Generated at 2022-06-23 23:44:57.221156
# Unit test for function extend_tree
def test_extend_tree():
    ext_func = ast.parse(
        'def f():\n'
        '  extend(vars)\n'
        '  let(x)\n'
        '  let(y)\n'
        '  let(z)\n'
        '  return z\n').body[0]

    globals = [ast.parse('z = 1').body[0]]
    locals = [ast.parse('x = 2').body[0],
              ast.parse('y = 3').body[0]]
    extend_tree(ext_func, {'vars': globals + locals})

# Generated at 2022-06-23 23:45:05.307982
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import get_source

    def get(val):
        return ast.parse(get_source(val)).body[0].value

    n = ast.Name('a', ast.Load())
    n1 = ast.Name('b', ast.Load())
    v = VariablesReplacer({'a': n1})
    assert 'b' == v.visit_alias(ast.alias(name='a', asname=None)).name
    assert 'a' == v.visit_alias(ast.alias(name='a', asname='c')).asname

# Generated at 2022-06-23 23:45:08.200701
# Unit test for function let
def test_let():
    @snippet
    def snippet():
        let(x)
        x = x + 1

    assert snippet.get_body() == ast.parse('_py_backwards_x_0 = _py_backwards_x_0 + 1').body

# Generated at 2022-06-23 23:45:16.876967
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    test_name = "test_name"
    node = ast.arg(arg=test_name)
    assert ast.dump(node) == "arg(arg='test_name')"
    node = node.visit(VariablesReplacer(dict()))
    assert ast.dump(node) == "arg(arg='test_name')"

    new_name = "new_name"
    node = node.visit(VariablesReplacer({
        test_name: new_name
    }))
    assert ast.dump(node) == "arg(arg='new_name')"



# Generated at 2022-06-23 23:45:23.386279
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    from .meta import node
    from .tree import get_root
    from .helpers import find_call
    from .snippets import let

    root = get_root(node(let(x)))
    x = find_call(root, let).args[0]

    variables = {x.id: ast.parse('x').body[0]}
    root2 = VariablesReplacer.replace(root, variables)
    assert "x" in str(root2)


# Generated at 2022-06-23 23:45:31.477500
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    a = ast.Name(id="a")
    exc = ast.ExceptHandler(name=a, body=[ast.Print(dest=None, values=[a], nl=True)])
    tree = ast.Module(body=[ast.TryExcept(body=[ast.Pass()], handlers=[exc])])
    VariablesReplacer.replace(
        tree, {
            "a": ast.Name(id="z"),
        })
    assert tree == ast.Module(body=[ast.TryExcept(body=[ast.Pass()], handlers=[ast.ExceptHandler(name="z", body=[ast.Print(dest=None, values=["z"], nl=True)])])])

# Generated at 2022-06-23 23:45:36.313756
# Unit test for function find_variables
def test_find_variables():
    test_source = """def x():
    let(a)
    let(b)
    return a, b"""
    expected = ['a', 'b']
    result = list(find_variables(ast.parse(test_source)))
    assert result == expected



# Generated at 2022-06-23 23:45:43.356494
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('def foo(a, b=a): pass')
    variables = {'a': 'test'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    body = tree.body[0]
    assert body.args.args[0].arg == 'test'
    assert body.args.kwonlyargs[0].arg == 'a'

if __name__ == '__main__':
    test_VariablesReplacer_visit_arg()

# Generated at 2022-06-23 23:45:52.956355
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import sys
    from inspect import getsourcefile, getfile
    # sys.argv[0] is name of currently executed file
    program_path = sys.argv[0]
    filename = getfile(test_VariablesReplacer_visit_ImportFrom)
    get_source_file_path = getsourcefile(test_VariablesReplacer_visit_ImportFrom)
    if get_source_file_path is None:
        # Executed from IDE, use file name
        get_source_file_path = filename

    import os, inspect
    program_file = os.path.abspath(program_path)
    test_file = os.path.abspath(get_source_file_path)
    is_program_file = os.path.isfile(program_file)

# Generated at 2022-06-23 23:45:56.813706
# Unit test for function let
def test_let():
    dct = {}
    @snippet
    def test():
        var = 'a'
        let(var)
        dct[var] = 1
    
    test()
    assert dct == {'a': 1} or dct == {'_py_backwards_var_0': 1}


# Generated at 2022-06-23 23:45:57.578197
# Unit test for constructor of class snippet
def test_snippet():
    sn = snippet(lambda: [1])
    assert sn

# Generated at 2022-06-23 23:46:08.465693
# Unit test for function extend
def test_extend():
    tree = ast.parse('extend(vars)\nprint(x, y)')

# Generated at 2022-06-23 23:46:11.434668
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    t = ast.parse('def f(y: int):\n    pass')
    v = {'y': 'x'}
    VariablesReplacer.replace(t, v)

    fn = ast.Name(id='x', ctx=ast.Load())
    assert t.body[0].args.args[0].arg == fn.id

# Generated at 2022-06-23 23:46:14.289580
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_snippet():
        let(x)
        x = 1

    snippet1 = snippet(my_snippet)
    body = snippet1.get_body()
    assert body[0].value.value == 1

# Generated at 2022-06-23 23:46:19.470060
# Unit test for function let
def test_let():
    def foo():
        x = 5
        let(x)
        return x

    tree = snippet(foo).get_body()
    assert tree[0].value.id == '_py_backwards_x_0'
    assert ast.dump(tree) == '[Assign([Name(_py_backwards_x_0, Load())], Constant(5, None))]'


# Generated at 2022-06-23 23:46:28.095107
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from .backend import prepare

    # test
    @prepare
    def foo():
        try:
            let(a)
        except Exception:
            a += 1
    assert str(foo).strip() == '''
_py_backwards_a_0 += 1
'''

    # test
    @prepare
    def foo():
        try:
            let(a)
        except Exception as a:
            a += 1
    assert str(foo).strip() == '''
_py_backwards_a_0 += 1
'''

    # test
    @prepare
    def foo():
        let(a)
        try:
            pass
        except Exception as a:
            a += 1
    assert str(foo).strip() == '''
_py_backwards_a_0 += 1
'''

# Generated at 2022-06-23 23:46:38.918773
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        let(y)
        x = 0
        y = 1
        let(x1)
        x1 = x + 1
        extend(vars)
        return x1 + y + 2


# Generated at 2022-06-23 23:46:44.102772
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class Replacer(VariablesReplacer):
        pass

    class A(ast.NodeVisitor):
        def visit_arg(self, node):
            return True

    replacer = Replacer({'arg': 'name'})
    node = ast.parse("def func(arg): pass").body[0]
    replacer.generic_visit(node)
    a = A()
    assert a.visit(node.args)

# Generated at 2022-06-23 23:46:50.335975
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def foo(a, b, c):
        ...

    tree = ast.parse(get_source(foo))
    variables = {'_py_backwards_a_0': 'a', '_py_backwards_b_0': 'b', '_py_backwards_c_0': 'c'}

    result = VariablesReplacer.replace(tree, variables)
    assert result.body[0].name == 'foo'



# Generated at 2022-06-23 23:46:56.471400
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> int:
        let(x)
        let(y)
        x += 1
        return x + y
    snippet_object = snippet(test_fn)
    assert snippet_object.get_body(x=1, y=1)[0].value.right.n==1
    assert snippet_object.get_body(x=1, y=1)[1].value.left.id=='_py_backwards_y_0'

# Generated at 2022-06-23 23:46:57.771718
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x); let(y); print(x, y)')
    assert eager(find_variables)(tree) == ['x', 'y']



# Generated at 2022-06-23 23:46:59.932189
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    node = ast.parse('''def f(a=1+1)''')

    snip = snippet(lambda a=1+1: None)
    node_body = snip.get_body()
    assert node_body == node.body

# Generated at 2022-06-23 23:47:00.895813
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet
    assert snippet(lambda x: None)

# Generated at 2022-06-23 23:47:05.248378
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    parser = ast.parse('def x(a=b): pass')
    variables = {
        'b': 'a'
    }
    VariablesReplacer.replace(parser, variables)
    assert str(parser) == 'def x(a=a):\n    pass\n'

# Generated at 2022-06-23 23:47:09.023033
# Unit test for function let
def test_let():
    @snippet
    def add():
        let(x)
        x += 1

    body = add().get_body()
    assert body[0].value.left.id == '_py_backwards_x_0'



# Generated at 2022-06-23 23:47:18.164914
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: 1).get_body() == [ast.Return(ast.Num(n=1))]

    assert snippet(lambda: x.y).get_body() == [ast.Expr(ast.Attribute(
        value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
        attr='y', ctx=ast.Load()))]

    assert snippet(lambda: x).get_body() == [ast.Expr(ast.Name(
        id='_py_backwards_x_0', ctx=ast.Load()))]

    assert snippet(lambda: let(x)).get_body() == []

    assert snippet(lambda: extend(x)).get_body() == []


# Generated at 2022-06-23 23:47:24.620438
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class A(ast.NodeTransformer):
        def __init__(self):
            self.res = ""
        
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            self.res = node.name
            return node
    
    node = ast.parse("def test():\n    return 1").body[0]
    t = A()
    t.visit(node)
    assert t.res == "test"



# Generated at 2022-06-23 23:47:30.774512
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('let(x); x.y = 1;')
    variables = find_variables(tree)
    unique_variables = {
        key: VariablesGenerator.generate(key)
        for key in variables
    }

    unique_variables['y'] = 'z'
    VariablesReplacer.replace(tree, unique_variables)
    assert get_source(tree).strip() == '_py_backwards_x_0.z = 1;'

# Generated at 2022-06-23 23:47:37.043902
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse('''\
    from ast import parse
    from typed_ast import ast3 as ast

    from .generator import Generator
    from .helpers import get_source
    from .tree import find
    from .variables import get_variables, let, extend, snippet
    ''')
    variables = {'get_variables': ['get_variables_bak', 'get_variables_bak_0'], 'let': 'let_0', 'extend': 'extend_0', 'snippet': 'snippet_0'}
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:47:41.598941
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('var.a.b')
    def replace():
        replacer = VariablesReplacer({'var': ast.Name(id='a', ctx=ast.Load())})
        replacer.visit(tree)
    assert(replace() == "a.a.b")


# Generated at 2022-06-23 23:47:45.741034
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class_ = VariablesReplacer({'x': '_py_backwards_x_0'})
    node = ast.Name('x')
    result = class_.visit_Name(node)
    assert result.id == '_py_backwards_x_0'



# Generated at 2022-06-23 23:47:46.509278
# Unit test for constructor of class snippet
def test_snippet():
    pass

# Generated at 2022-06-23 23:47:52.561429
# Unit test for constructor of class snippet
def test_snippet():
    source = get_source(snippet)
    tree = ast.parse(source)
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert len(tree.body[0].body) == 1
    assert isinstance(tree.body[0].body[0], ast.Return)
    assert isinstance(tree.body[0].body[0].value, ast.Call)
    assert tree.body[0].body[0].value.args[0].s == 'snippet'

# Generated at 2022-06-23 23:47:57.382971
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import astor
    from .tree import find, get_non_exp_parent_and_index, replace_at
    from .helpers import eager
    from .snippet import VariablesReplacer

# Generated at 2022-06-23 23:48:09.025856
# Unit test for method visit_Attribute of class VariablesReplacer

# Generated at 2022-06-23 23:48:15.494038
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('x = 1\nextend(vars)\nprint(x)')
    extend_tree(tree, {'vars': [ast.parse('x = 2').body[0]]})
    compiled = compile(tree, '<test>', 'exec')
    globals_ = {}
    locals_ = {}
    exec(compiled, globals_, locals_)
    assert locals_['x'] == 2


# Generated at 2022-06-23 23:48:24.333006
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Tree:
        pass

    tree = Tree()

    tree.body = [
        ast.ImportFrom(
            module=ast.Name(id="a", ctx=ast.Load()),
            names=[
                ast.alias(name=ast.Name(id="b", ctx=ast.Store()), asname=None)
            ],
            level=0
        )]

    variables = {
        "a.b": 'a.c'
    }

    result = VariablesReplacer.replace(tree, variables)

    assert result.body[0].module.id == "a"
    assert result.body[0].names[0].name.id == "c"

# Generated at 2022-06-23 23:48:33.794209
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def function():
        a = 1
        pass
    tree = ast.parse(get_source(function))
    VariablesReplacer.replace(tree, {'a': 1})
    assert ast.dump(tree) == "(Module(body=[FunctionDef(name='function', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1)), Pass()], decorator_list=[])]))"  # noqa


# Generated at 2022-06-23 23:48:37.090160
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    orig = ast.parse('import a.b')
    tree = orig

    variables = {'a': 'c'}
    result = VariablesReplacer.replace(tree, variables)

    assert isinstance(result, ast.AST)
    assert orig == result

# Generated at 2022-06-23 23:48:38.282601
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    assert get_source(VariablesReplacer)

# Generated at 2022-06-23 23:48:48.556588
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # Given
    class Dummy(ast.NodeTransformer):
        def generic_visit(self, node: ast.AST) -> ast.AST:
            return node

        def visit_alias(self, node: ast.alias) -> ast.alias:
            self.visitor(node)
            return node

    func = lambda: None
    _tree = ast.parse(get_source(func))
    replacer = VariablesReplacer({'x': 'y', 'y': 'z'})
    visitor = Dummy()
    replacer.visitor = visitor.visit_alias
    # When
    replacer.visit_alias(_tree.body[0].body[0])
    # Then
    import re
    assert re.search(r"from x import y as z", get_source(func))



# Generated at 2022-06-23 23:48:50.713073
# Unit test for function extend_tree
def test_extend_tree():
    from astpretty import pprint

# Generated at 2022-06-23 23:48:52.919634
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
  # Arrange
  alias = ast.alias(
    name='test',
    asname=None
  )

# Generated at 2022-06-23 23:49:00.088420
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    test_variables = {'_py_backwards_x_0': 'x_0', '_py_backwards_y_0': 'y_0', '_py_backwards_result_0': 'result_0',
                      '_py_backwards_a_0': 'a_0', '_py_backwards_b_0': 'b_0', '_py_backwards_d_0': 'd_0',
                      '_py_backwards_e_0': 'e_0', '_py_backwards_f_0': 'f_0'}

# Generated at 2022-06-23 23:49:00.587921
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:49:01.453609
# Unit test for function find_variables

# Generated at 2022-06-23 23:49:10.777174
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("""
        class B:
            def m(self):
                pass
        class A(B):
            a = 1
            def __init__(self):
                self.b = 2
    """)

    var_name = 'var'
    variables = {
        var_name: ast.Attribute(value=ast.Name(id=var_name), attr='b'),
    }
    VariablesReplacer.replace(tree, variables)

    expected = """
        class B:
            def m(self):
                pass
        class A(B):
            a = 1
            def __init__(self):
                self.b = 2
            @property
            def var(self):
                return self.b
    """

    assert expected == ast.unparse(tree)

# Generated at 2022-06-23 23:49:11.628866
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x); let(y)')
    assert find_variables(tree) == ['x', 'y']

# Generated at 2022-06-23 23:49:13.884700
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer({'x': '_x_0'})

# Generated at 2022-06-23 23:49:18.073030
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    print('ok')
    v = VariablesReplacer({"a": ast.Name(id="b")})
    print(v.visit_alias(ast.alias(name="a", asname="c")))
    # this will print (with a blank line in the middle):
    # <alias object at 0x7f3a3b7e2f60>
    # alias(name='b', asname='c')
    # 



# Generated at 2022-06-23 23:49:28.144499
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # 1 case
    input_node = ast.ClassDef(
        name='MyClass'
    )
    expected_output = ast.ClassDef(
        name='MyClass'
    )
    variables = {
        'MyClass': 'MyClass'
    }
    actual_output = VariablesReplacer.replace(input_node, variables)
    assert ast.dump(actual_output) == ast.dump(expected_output)

    # 2 case
    input_node = ast.ClassDef(
        name='MyClass'
    )
    expected_output = ast.ClassDef(
        name='MyClass'
    )
    variables = {
        'MyClass': ast.Name(id='MyClass', ctx=ast.Load())
    }
    actual_output = VariablesReplacer.replace(input_node, variables)

# Generated at 2022-06-23 23:49:31.320698
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x); x += 1')
    variables = list(find_variables(tree))
    assert variables == ['x']



# Generated at 2022-06-23 23:49:34.185928
# Unit test for function find_variables
def test_find_variables():
    assert find_variables('''
        let(x)
        x += 1
        let(y)
        y += 2
        let(z)
        z += 3
    ''') == ['x', 'y', 'z']

# Generated at 2022-06-23 23:49:45.169084
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    from typing import List

    class T:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    def f(a: int, *, b: int = 0, c: int = 1) -> List[int]:
        return [a, b, c]

    assert f(1) == [1, 0, 1]
    assert f(1, c=2) == [1, 0, 2]
    assert f(a=1, c=2) == [1, 0, 2]

    node = ast.parse(inspect.getsource(f)).body[0]
    args = node.args
    assert isinstance(args, ast.arguments)

    kw = T(**node.keywords[0].__dict__)
    assert kw.arg == 'b'

# Generated at 2022-06-23 23:49:47.591562
# Unit test for constructor of class snippet
def test_snippet():
    snippet.__init__(snippet, lambda x, y: None)

# Generated at 2022-06-23 23:49:53.738756
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
   
    class TestClass(ast.AST):
        _fields = ('name', 'test')
        name: str
        test: int
   
    def test_method(tree):
        variables = {'TestClass': TestClass(name='NewTestClass', test=42)}
        VariablesReplacer.replace(tree, variables)
    
    tree = TestClass(name='TestClass', test=13)
    test_method(tree)
    assert tree.name == 'NewTestClass'
    assert tree.test == 42

# Generated at 2022-06-23 23:49:54.800500
# Unit test for function let
def test_let():
    assert snippet(lambda: let(x))



# Generated at 2022-06-23 23:49:58.353081
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("a.b")
    variables = {'a': 'c'}
    replacer = VariablesReplacer(variables)
    replacer.visit_Attribute(tree)
    assert(tree.value.id == 'c')
    assert(tree.attr == 'b')


# Generated at 2022-06-23 23:50:04.949701
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    v = VariablesGenerator(['a'], [])
    tree = ast.parse('[b for a in c if f(a)]')

    variables = {'a': v.generate('a')}
    VariablesReplacer.replace(tree, variables)
    VariablesReplacer._visit_FunctionDef(tree, variables)
    assert ast.dump(tree) == ast.dump(ast.parse('a = 1'))


# Generated at 2022-06-23 23:50:14.107174
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class VarTestNode(ast.Name):
        pass

    class NewNode(ast.Name):
        pass

    # Test name with id in variables
    new_id = 'aaa'
    old_id = 'old_id'
    node = VarTestNode(id=old_id, ctx=None)
    new_name = NewNode(id=new_id, ctx=None)
    variables = {old_id: new_name, new_id: new_id}
    node = VariablesReplacer.replace(node, variables)

    assert isinstance(node, NewNode)
    assert node.id == new_id

    # Test name with id not in variables
    new_id = 'aaa'
    old_id = 'old_id'

# Generated at 2022-06-23 23:50:18.189496
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    node = ast.parse('''
    try:
        1 / 0
    except ZeroDivisionError as err:
        print(err)
    ''').body[0]  # type: ast.Try
    except_handler = node.handlers[0]
    assert except_handler.name == 'err'
    VariablesReplacer.replace(node, {'err': 'exc'})
    assert except_handler.name == 'exc'


# Generated at 2022-06-23 23:50:27.056708
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class Def(ast.FunctionDef):
        def __init__(self, name: str):
            self.name = name

    scope = ast.Module()
    scope.body.append(Def('fn'))

    original = ast.ExceptHandler(
        None,
        ast.Name('fn', ast.Load()),
        [],
    )

    replacer = VariablesReplacer({'fn': '_fn'})
    result = replacer.visit_ExceptHandler(original)
    assert result == ast.ExceptHandler(
        None,
        ast.Name('_fn', ast.Load()),
        [],
    )

# Generated at 2022-06-23 23:50:35.671008
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        x = 2
        print(x)
    """)
    extend_tree(tree, {'vars': [
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Constant(value=1)),
        ast.Assign([ast.Name(id='y', ctx=ast.Store())], ast.Constant(value=2))
    ]})
    assert(get_source(tree) == """\
x = 1
y = 2
x = 2
print(x)""")

# Generated at 2022-06-23 23:50:44.310760
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .typed_ast import ast3 as ast, get_ast
    snippet = """
    import foo.bar
    import baz as bar
    """
    tree = ast.parse(snippet)
    assert get_ast(tree) == snippet
    variables = {"bar": "my_bar", "baz": "my_baz"}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert get_ast(tree) == """
    import foo.bar
    import my_baz as my_bar
    """

# Generated at 2022-06-23 23:50:52.165665
# Unit test for function let
def test_let():
    @snippet
    def func():
        let(x)
        x += 1
        y = 1

    assert func.get_body() == [
        ast.Assign(
            targets=[
                ast.Name(id='_py_backwards_x_0', ctx=ast.Store())
            ],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[
                ast.Name(id='y', ctx=ast.Store())
            ],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-23 23:50:56.950794
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    module = """
    class X:
        pass
    """
    module = ast.parse(module)
    replacer = VariablesReplacer({'X': 'Y'})
    replacer.visit(module)
    assert(get_source(module).strip() == 'class Y: pass')


# Generated at 2022-06-23 23:51:05.570033
# Unit test for function extend_tree
def test_extend_tree():
    def simple_func():
        pass

    def extend_func():
        extend(vars_)
        simple_func()

    def first_case_func():
        extend(vars_)

    def second_case_func():
        pass

    tree = ast.parse(get_source(extend_func))
    extend_tree(tree, {'vars_': [ast.Assign(targets=[ast.Name(id='x')],
                                            value=ast.Num(n=1))]})
    expect = get_source(first_case_func)
    output = ast.fix_missing_locations(tree)
    assert expect == output, 'Expected %s, got %s' % (expect, output)

    tree = ast.parse(get_source(extend_func))
    extend_

# Generated at 2022-06-23 23:51:10.922354
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse('except Exception as e:\n    pass')
    variables = {'e': 'y'}
    node = tree.body[0].handlers[0]
    assert node.name.id == 'e'
    inst = VariablesReplacer(variables)
    inst.visit(node)
    assert isinstance(node, ast.ExceptHandler)
    assert node.name.id == 'y'

# Generated at 2022-06-23 23:51:19.747662
# Unit test for function extend_tree
def test_extend_tree():
    def add(x, y):
        extend(vars)
        return x + y
    vars = [
        ast.Assign(
            targets=[ast.Name(id="x", ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id="x", ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    tree = snippet(add).get_body(vars=vars)
    assert len(tree) == 2
    assert isinstance(tree[0].value, ast.Num)
    assert tree[0].value.n == 1
    assert isinstance(tree[1].value, ast.Num)
    assert tree[1].value.n == 2

# Generated at 2022-06-23 23:51:31.543074
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("""x = 1
x.y = 2
x.y.z = 3
x.y.z.z = 4
x.y.z.c = 5
x.p = 6
""")
    variables = {'x': ast.parse('y').body[0],
                 'y': ast.parse('z').body[0],
                 'z': ast.parse('p').body[0]}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert isinstance(tree.body[0].value.value, ast.Name)  # type: ignore
    assert isinstance(tree.body[1].value.value, ast.Name)  # type: ignore
    assert isinstance(tree.body[2].value.value, ast.Name)  # type:

# Generated at 2022-06-23 23:51:42.711164
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    a = ast.FunctionDef(
        name = 'f',
        args = ast.arguments(
            args = [ast.arg(arg = 'x')],
            vararg = None,
            kwarg = None,
            defaults = [],
            kw_defaults = []
        ),
        body = [
            ast.Return(
                value = ast.BinOp(
                    left = ast.Num(n = 1),
                    op = ast.Add(),
                    right = ast.Name(id = 'x', ctx = ast.Load())
                )
            )
        ],
        decorator_list = [],
        returns = None,
        type_comment = None
    )
    tree = ast.Module(body = [a])

# Generated at 2022-06-23 23:51:50.301003
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    varaible = ast.Name(id='x', ctx=ast.Load())
    variable_dict = {"x": ast.Name(id='x', ctx=ast.Load())}

    # check if replace the variable
    node = ast.Name(id='x', ctx=ast.Load())
    result = VariablesReplacer.replace(node, variable_dict)
    assert result == ast.Name(id='x', ctx=ast.Load())

    # check if don't replace the variable
    variable_dict = {"y": ast.Name(id='x', ctx=ast.Load())}
    node = ast.Name(id='x', ctx=ast.Load())
    result = VariablesReplacer.replace(node, variable_dict)

# Generated at 2022-06-23 23:52:01.550452
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    import unittest
    import ast
    import typed_ast.ast3

    class VariablesReplacer(ast.NodeTransformer):
        """Replaces declared variables with unique names."""

        def __init__(self, variables: Dict[str, Variable]) -> None:
            self._variables = variables

        def _replace_field_or_node(self, node: T, field: str, all_types=False) -> T:
            value = getattr(node, field, None)
            if value in self._variables:
                if isinstance(self._variables[value], str):
                    setattr(node, field, self._variables[value])
                elif all_types or isinstance(self._variables[value], type(node)):
                    node = self._variables[value]  # type: ignore

           

# Generated at 2022-06-23 23:52:09.269041
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class NodeTransformer(ast.NodeTransformer):
        def visit_ClassDef(self, node):
            return node

    tree = ast.parse('def func(a: int) -> str: pass')
    transformer = NodeTransformer() # type: ignore
    node = transformer.visit(tree)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.FunctionDef)
    func_def = node.body[0]
    assert func_def.name == 'func'
    assert len(func_def.args.args) == 1
    assert isinstance(func_def.args.args[0], ast.arg)
    arg = func_def.args.args[0]
    assert arg.arg == 'a'

# Generated at 2022-06-23 23:52:15.718037
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        extend(vars)

    s = snippet(test_snippet)
    
    assert s.get_body(x=1) == [
        ast.Expr(value=ast.literal_eval('_py_backwards_x_0')),
        ast.Expr(value=ast.literal_eval('vars'))
    ]

# Generated at 2022-06-23 23:52:21.086635
# Unit test for function let
def test_let():
    assert str(snippet(lambda: let(3)).get_body()[0]) == '_py_backwards_3_0 = 3'

# Generated at 2022-06-23 23:52:27.036667
# Unit test for function extend
def test_extend():
    ext = extend

    @snippet
    def f():
        let(a)
        a = 3
        ext(b)

    assert isinstance(f.get_body(b={'a': 'b', 'b': [ast.Assign(
        [ast.Name('a')], ast.Num(1))]})[0], ast.Assign)



# Generated at 2022-06-23 23:52:34.740295
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('a + b').body[0] # Add(Name(id='a', ctx=Load()), Name(id='b', ctx=Load()))
    variables = {
        'a': 'a_renamed',
        'b': 'b_renamed'
    }
    tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Expr(value=BinOp(left=Name(id='a_renamed', ctx=Load()), op=Add(), right=Name(id='b_renamed', ctx=Load())))"

# Generated at 2022-06-23 23:52:41.001591
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    test_tree = ast.parse("""
        def main():
            extend(vars)
            print(x, y)
        """).body[0]
    vars = ast.parse("""
        x = 1
        x = 2
        """).body

    variables = {'vars': vars}
    new_tree = VariablesReplacer.replace(test_tree, variables)
    assert new_tree.body[0].body[0].value.args[0].id == 'x'

# Generated at 2022-06-23 23:52:50.211777
# Unit test for function extend_tree
def test_extend_tree():
    code = """
        def f():
            extend(vars)
            extend(vars_2)
            let(a)
            print(a, x)
            
        x = 1
        y = 1
    """

    tree = ast.parse(code)

# Generated at 2022-06-23 23:52:56.536220
# Unit test for function let
def test_let():
    @snippet
    def test():
        let(x)
        x = 1
        x += 1

    x = test().get_body()
    assert x[0].value.id == '_py_backwards_x_0'
    assert x[1].value.id == '_py_backwards_x_0'

