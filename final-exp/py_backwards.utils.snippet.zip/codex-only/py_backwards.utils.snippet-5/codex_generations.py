

# Generated at 2022-06-23 23:43:01.479272
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    import pytest
    from .helpers import get_source, parse_code, get_node
    from .tree import get_non_exp_parent_and_index, replace_at
    tree = parse_code("a = 1\n print(a)")
    variables = {'a':'a_0'}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert get_source(tree) == "a_0 = 1\n print(a_0)"



# Generated at 2022-06-23 23:43:08.253273
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .test.test_snippet import test_factory
    from .test.test_snippet import test_factory2
    from .test.test_snippet import test_factory3
    from .test.test_snippet import test_factory4
    from .test.test_snippet import test_factory5
    from .test.test_snippet import test_factory6
    source1 = 'from foo import a'
    source2 = 'from foo import a as b'
    source3 = 'from foo import a as c, b'
    source4 = 'from foo import a, b as c'
    source5 = 'from foo import a, b as c, d'
    source6 = 'from foo.bar import a'

    sut1 = ast.parse(source1)
   

# Generated at 2022-06-23 23:43:10.424264
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''extend(vars)''')
    variables = {'vars': [ast.parse('a = b').body[0]]}
    extend_tree(tree, variables)

    assert get_source(tree) == 'a = b'


# Generated at 2022-06-23 23:43:11.468467
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet is not None


# Generated at 2022-06-23 23:43:17.838004
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    def f(x: ast.arg, y: ast.arg):
        pass

    tree = ast.parse(get_source(f))
    variables = {'x': 'new_x', 'y': 'new_y'}
    VariablesReplacer.replace(tree, variables)
    # Using astor to convert AST to source code.
    assert astor.to_source(tree) == 'def f(new_x, new_y):\n    pass\n'

# Generated at 2022-06-23 23:43:26.978694
# Unit test for function extend_tree
def test_extend_tree():
    def func():
        x = 1
        x = 2
        print(x, y)

    tree = ast.parse(get_source(func))
    extend_tree(tree, {'vars': [ast.Assign([ast.Name(id='x')], ast.Num(n=1)),
                                ast.Assign([ast.Name(id='x')], ast.Num(n=2))]})
    assert get_source(tree) == '\n'.join(['x = 1',
                                          'x = 2',
                                          'print(x, y)',
                                          ''])


# Generated at 2022-06-23 23:43:34.955472
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    from .test_helpers import assert_ast_equal
    from .test_helpers import assert_no_warnings
    from .test_helpers import assert_warnings
    tree = ast.parse("""
        class Foo:
            def __init__(self, arg):
                arg = arg
    
            def foo(self):
                @stuff
                def bar(self, arg):
                    print(arg)
    """)

    VariablesReplacer.replace(tree, {
        'self': '_py_backwards_arg_0',
        'arg': '_py_backwards_arg_1',
    })


# Generated at 2022-06-23 23:43:39.799091
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def _():
        def func():
            pass

    tree = ast.parse(get_source(_))
    variables = dict(func=['a']) # any number of variables will result in replacement
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].body[0].name == 'a'

# Generated at 2022-06-23 23:43:45.643439
# Unit test for function find_variables
def test_find_variables():
    @snippet
    def fn():
        let(x)
        x += 1
        y = 1

    assert find_variables(fn.get_body()) == ['x']

    @snippet
    def fn():
        let(x)
        x += 1
        y = 1

    assert set(find_variables(fn.get_body())) == {'x'}

    @snippet
    def fn():
        let(x)
        let(y)
        x += 1
        y = 1

    assert set(find_variables(fn.get_body())) == {'x', 'y'}



# Generated at 2022-06-23 23:43:49.634440
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""
try:
    1/0
except Exception:
    pass
    """)
    variables = {
        'Exception': 'SomeException'
    }
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert get_source(tree) == """
try:
    1/0
except SomeException:
    pass
    """

# Generated at 2022-06-23 23:44:00.512050
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2

    @snippet
    def fn(z):
        let(x)
        let(y)
        extend(vars)
        let(q)
        x += 1
        y = 3
        print(x, y, z)

    vars = {
        'x': x,
        'y': y,
    }

# Generated at 2022-06-23 23:44:05.450377
# Unit test for method get_body of class snippet

# Generated at 2022-06-23 23:44:07.406723
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    # Given
    variables = {'x': '_py_backwards_x_0'}

# Generated at 2022-06-23 23:44:12.310683
# Unit test for function let
def test_let():
    @snippet
    def let_test():
        let(x)
        x += 42

    assert let_test.get_body() == [ast.Assign([ast.Name('_py_backwards_x_0',
                                                      ast.Store())],
                                              ast.BinOp(ast.Name('_py_backwards_x_0',
                                                                ast.Load()),
                                                        ast.Add(),
                                                        ast.Num(n=42)))]



# Generated at 2022-06-23 23:44:15.529443
# Unit test for function let
def test_let():
    @snippet
    def snippet(name: str):
        let(name)
        let(name)

    tree = snippet.get_body(name='name')
    assert len(tree) == 2
    assert isinstance(tree[0], ast.Assign)
    assert isinstance(tree[1], ast.Assign)
    assert tree[0].targets[0].id == 'name'
    assert tree[1].targets[0].id != 'name'



# Generated at 2022-06-23 23:44:16.787219
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:44:20.002326
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer.replace
    assert VariablesReplacer.replace.__name__ == 'replace'
    assert VariablesReplacer.replace.__doc__ == 'Replaces all variables with unique names.'


# Generated at 2022-06-23 23:44:26.268438
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = '''
x = y(a=let(z), b=1)
    '''
    tree = ast.parse(source)
    variables_replacer = VariablesReplacer({'z': '_z'})
    node = tree.body[0].value.keywords[0]
    variables_replacer.visit_keyword(node)
    assert node.arg == '_z'



# Generated at 2022-06-23 23:44:31.632872
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class _NodeTransformer(ast.NodeTransformer):
        def visit(self, node):
            return node

    tree = ast.parse("""def fun(arg1: int, arg2: str, **kwargs) -> None:
        pass""")
    fn = tree.body[0]  # type: ignore

    assert 'kwargs' == fn.args.kwarg
    assert {"arg": "arg1", "value": ast.parse("int")}, {"arg": "arg2", "value": ast.parse("str")} == fn.args.kwonlyargs

    variables = {"arg1": "arg1_new", "int": "int_new", "arg2": "arg2_new", "str": "str_new"}
    transformer = VariablesReplacer(variables)
    transformer.visit(tree)


# Generated at 2022-06-23 23:44:36.515372
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import get_source
    from .snippets import my_func

    tree = ast.parse(get_source(my_func))
    expected_ast = ast.parse('''

import sys  # type: ignore
import datetime
import time  # type: ignore
x = 1
y = 2

''')

    variables = {'sys': 'sys'}
    VariablesReplacer.replace(tree, variables)

    assert ast.dump(tree) == ast.dump(expected_ast)

# Generated at 2022-06-23 23:44:37.912465
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-23 23:44:38.995497
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:44:50.149360
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    var = VariablesGenerator.generate('x')
    classdef = ast.ClassDef(id=ast.Name(id='A'), bases=[],
                            body=[ast.FunctionDef(name=ast.Name(id='f'), args=ast.arguments(
                                args=[ast.Name(id='self')], vararg=None, kwarg=None, kwonlyargs=[], defaults=[], kw_defaults=[]), body=[ast.Return(value=ast.Name(id='x'))], decorator_list=[], returns=None)])
    tree = ast.Module(body=[classdef])
    tree = VariablesReplacer.replace(tree, variables={'x': var})
    assert get_source(tree) == 'class A:\n    def f(self):\n        return ' + var

# Generated at 2022-06-23 23:44:51.056183
# Unit test for constructor of class snippet
def test_snippet():
    exec(snippet(lambda: None).get_body())

# Generated at 2022-06-23 23:44:53.414832
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('x = 1')
    variables = {'x': 'y'}
    VariablesReplacer.replace(tree, variables)
    assert(str(tree) == 'y = 1')


# Generated at 2022-06-23 23:44:56.884489
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    node = ast.parse("from math import sqrt as root").body[0]
    VariablesReplacer.replace(node, {'sqrt': 'root'})
    assert ast.dump(node) == "ImportFrom(module='math', names=[alias(name='root', asname=None)], level=0)"



# Generated at 2022-06-23 23:44:57.805364
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer


# Generated at 2022-06-23 23:45:03.307501
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    source = 'A.b(c.d)'
    tree = ast.parse(source)
    variables = {
        'c': 'C',
    }
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert(get_source(tree) == 'A.b(C.d)')


# Generated at 2022-06-23 23:45:08.879293
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from .helpers import parse
    old_code = 'try: pass\nexcept Exception as e: pass'
    new_code = 'try: pass\nexcept Exception as _py_backwards_e_0: pass'
    tree = parse(old_code)
    variables = {'e': VariablesGenerator.generate('e')}
    VariablesReplacer.replace(tree, variables)
    assert old_code != new_code
    assert get_source(tree) == new_code

# Generated at 2022-06-23 23:45:19.936951
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from .helpers import equal_source
    from .compat import with_metaclass
    class Type(type):
        def __getattr__(self, attr):
            return 'type'
    class Type2(with_metaclass(Type)):
        pass
    class Type3(with_metaclass(Type)):
        pass
    ast_1 = ast.parse('try: pass\nexcept Type: pass')
    member = ast_1.body[0].handlers[0].type.elts[0]
    replacer = VariablesReplacer({'Type': 'Type2'})
    replacer.visit_ExceptHandler(ast_1.body[0].handlers[0])
    assert(equal_source(get_source(ast_1), 'try: pass\nexcept Type2: pass'))


# Generated at 2022-06-23 23:45:23.947939
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)\nx += 1")
    assert set(find_variables(tree)) == {'x'}

    tree = ast.parse("let(x)\nx += 1\nlet(y)\nx *= 2")
    assert set(find_variables(tree)) == {'x', 'y'}

    tree = ast.parse("let(x)\n(x, y) = foo(x)\nx *= 2")
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-23 23:45:32.851617
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class_def = ast.ClassDef(name='Name0',body=[],decorator_list=[])
    attribute = ast.Attribute(attr='attr1',value=class_def)
    variable_generator = VariablesGenerator(prefix="Name")
    variables = {'Name0': variable_generator.generate('Name0')}
    replacer = VariablesReplacer.replace(tree=attribute, variables=variables)
    assert replacer.attr == 'attr1'
    assert replacer.value.name == 'Name0_0'

    function_def = ast.FunctionDef(name='Function0',body=[],decorator_list=[])
    attribute = ast.Attribute(attr='attr2',value=function_def)
    variable_generator = VariablesGenerator(prefix="Function")

# Generated at 2022-06-23 23:45:43.401654
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('x = 1\n' +
                     'extend(vars)\n' +
                     'extend(vars2)\n' +
                     'x = 3\n' +
                     'def outsid():\n' +
                     '  x = 2\n')
    variables = {
        'vars': ast.parse('x = 1\nx = 2').body,
        'vars2': [ast.parse('x = 3')]
    }
    extend_tree(tree, variables)
    assert get_source(tree) == 'x = 1\nx = 1\nx = 2\nx = 3\n' + \
                                'def outsid():\n  x = 2\n'



# Generated at 2022-06-23 23:45:45.830087
# Unit test for function find_variables
def test_find_variables():
    result = find_variables(ast.parse(
'''
    let(x)
    x += 1
    y = 1
'''))
    assert list(result) == ['x']



# Generated at 2022-06-23 23:45:55.607554
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import astor
    from .tree import find
    from .snippet import let, extend

    tree = ast.parse(
    """
    from string import a as A
    def fn():
        let(A)
        print(A)
    """
    )

    # ast.dump(tree)
    # astor.dump_tree(tree)

    extend(
        [ast.parse(
            """
            let(B)
            A = '1'
            B = 2
            """
        ).body[0]]
    )
    # print(astor.dump_tree(tree))

    variables = {
        'A': 'C',
        'B': ast.Name(id='F', ctx=ast.Load())
    }
    # print(astor.dump_tree(tree.body[0]))

# Generated at 2022-06-23 23:46:06.866644
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    from typing import List, Dict
    from typed_ast import ast3 as ast
    from .tree import find, get_non_exp_parent_and_index, replace_at
    from .helpers import VariablesGenerator, get_source
    from .variables import VariablesReplacer

    source = get_source(test_VariablesReplacer_visit_Attribute)
    tree = ast.parse(source)
    names = find(tree, ast.Attribute)
    variables = {name.attr: VariablesGenerator.generate() for name in names}

    VariablesReplacer.replace(tree, variables)


# Generated at 2022-06-23 23:46:12.595203
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class func_def(ast.AST):
        _fields = ('name',)
        name: ast.Name

    func_def_instance = func_def(name=ast.Name(id='a'))

    class b:
        @classmethod
        def replace(self, tree, variables):
            trans = VariablesReplacer(variables)
            trans.visit(tree)
            return tree

    b.replace(func_def_instance, {'a': 'a'})
    assert func_def_instance.name.id == 'a'

# Generated at 2022-06-23 23:46:22.693853
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import ast
    import astunparse
    import textwrap
    k = ast.keyword()
    k.arg = "let"
    s = ast.Call()
    s.keywords = [k]
    tree = ast.parse(textwrap.dedent("""
    if True:
        pass
    else:
        pass
    """))
    tree.body[1].body[0].body = [s]
    module = ast.Module(body=tree)
    v = {"let": "let_"}
    replacer = VariablesReplacer(v)

    replacer.visit_keyword(k)
    result = astunparse.unparse(module)

    expected = textwrap.dedent("""
    if True:
        pass
    else:
        pass
    """)

    assert expected in result


# Generated at 2022-06-23 23:46:27.681147
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x)
    """)
    vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Constant(42))]
    extend_tree(tree, {'vars': vars})

    expected = """
        x = 42
        print(x)
    """
    assert(expected == ast.unparse(tree))



# Generated at 2022-06-23 23:46:33.546546
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def fn(a: int, b: int) -> int:
        return a + b
    tree = ast.parse(get_source(fn))
    tree = VariablesReplacer.replace(tree, {'a': ast.Name(id="c", ctx=ast.Load()), 
        'b': ast.Name(id="d", ctx=ast.Load())})

# Generated at 2022-06-23 23:46:43.761992
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')

# Generated at 2022-06-23 23:46:50.188291
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    variables = {
        "ast": "ast",
        "find": "find",
        "find_variables": "find_variables",
        "x": "x",
        "y": "y"
    }

    tree = ast.parse(
        'import ast\n'
        'from ast3 import find, find_variables\n'
        'let(x)\n'
        'let(y)\n'
        'extend(list)\n'
        'def foo() -> None:\n'
        '    pass\n'
    )

    VariablesReplacer.replace(tree, variables)
    print(ast.dump(tree))

# Generated at 2022-06-23 23:46:57.687127
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    # Sample code
    source = "def f(a: int) -> int: return a"
    # Parse code
    tree = ast.parse(source)
    # "a" is a parmeter of fnction "f"
    # Detect "a" and generate new name
    variables = {'a': VariablesGenerator.generate('a')}
    # Replace "a" with generated name
    VariablesReplacer.replace(tree, variables)
    # Compile and execute
    code = compile(tree, '<stdin>', 'exec')
    # Check result
    assert eval(code)() == 'a'

# Generated at 2022-06-23 23:46:59.493401
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    import astor
    tree = ast.parse("def f(a): pass")
    variables = {"a": "b"}
    assert astor.to_source(VariablesReplacer.replace(tree, variables)) == "def f(b): pass"


# Generated at 2022-06-23 23:47:10.610276
# Unit test for function find_variables
def test_find_variables():
    # Check `let` and `extend`
    code = '''
    let(x)
    let(y)
    extend(let(z=1))
    print(x)
    '''

    tree = ast.parse(code)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}

    # Check multiple lines
    code = '''
    let(x)
    let(y)
    extend(let(z=1))
    print(x)
    '''

    tree = ast.parse(code)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}

    # Check `let` and `extend` in other order

# Generated at 2022-06-23 23:47:17.969536
# Unit test for function let
def test_let():
    tree = ast.parse("""
let(x)
x += 1
y = 1""")
    names = find_variables(tree)

    variables = {name: VariablesGenerator.generate(name)
                 for name in names}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

    code = ast.unparse(tree).strip()
    expected_code = '{} += 1\ny = 1'.format(variables['x'])

    assert code == expected_code



# Generated at 2022-06-23 23:47:27.042336
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    testSnippet = snippet(lambda: None)
    testVariablesDict = {"self": "this"}
    testClass = ast.parse("class Foo(object):\n    def __init__(self):\n        pass").body[0]
    replacer = VariablesReplacer(testVariablesDict)
    replacer.visit_ClassDef(testClass)
    assert testClass.name == "Foo"
    assert testClass.bases[0].id == "object"
    assert testClass.body[0].name == "__init__"
    assert testClass.body[0].args.args[0].arg == "this"


# Generated at 2022-06-23 23:47:28.965584
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    # Arrange
    tree = ast.parse("var1 = 'value'")
    variables = {"var1": "var2"}

    # Act
    result = VariablesReplacer.replace(tree, variables)

    # Assert
    assert result.body[0].targets[0].id == "var2"



# Generated at 2022-06-23 23:47:32.291004
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('def f(y = 0, z = 1) -> int: return y + z')
    new_tree = VariablesReplacer.replace(tree, {
        'y': ['assign']
    })
    assert new_tree.body[0].args.args[0].arg == '_py_backwards_y_0'


# Generated at 2022-06-23 23:47:33.705557
# Unit test for function find_variables

# Generated at 2022-06-23 23:47:34.962797
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:47:46.286521
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import json
    with open('tests/resources/VisitorTest.json', 'r') as f:
        tree = json.load(f)
    var3 = ['v3', ast.Name('v3', ast.Load())]
    var2 = ['v2', ast.Name('v2', ast.Load())]
    var1 = ['v1', ast.Name('v1', ast.Load())]
    var4 = ['v4', ast.Name('v4', ast.Load())]
    var5 = ['v5', ast.Name('v5', ast.Load())]
    var6 = ['v6', ast.Name('v6', ast.Load())]
    var7 = ['v7', ast.Name('v7', ast.Load())]

# Generated at 2022-06-23 23:47:47.806831
# Unit test for function extend
def test_extend():
    def tree():
        pass

    assert snippet(tree).get_body() == []

# Generated at 2022-06-23 23:47:53.800248
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Id:
        def __init__(self, name):
            self.name = name

    node = ast.Attribute(
        value=Id('foo'),
        attr='bar',
        ctx=ast.Load()
    )

    variables = {'foo': ast.Name(id='baz', ctx=ast.Load())}
    VariablesReplacer.replace(node, variables)

    assert node.value.name == 'baz'
    assert node.attr == 'bar'
    assert node.ctx == ast.Load()

# Generated at 2022-06-23 23:47:58.202971
# Unit test for constructor of class snippet
def test_snippet():
    class Test(snippet):
        def __init__(self):
            snippet.__init__(self, self.__class__.__init__)

    t = Test()
    tree = t.get_body()
    assert len(tree) == 1



# Generated at 2022-06-23 23:48:09.484233
# Unit test for function extend_tree
def test_extend_tree():
    ast_import_from = ast.ImportFrom(
        lineno=2,
        col_offset=0,
        module='collections',
        names=[
            ast.alias(
                lineno=2,
                col_offset=0,
                name='defaultdict',
                asname=None,
            )
        ],
        level=0,
    )

# Generated at 2022-06-23 23:48:21.131773
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    parent = ast.Module([
        ast.FunctionDef(name='test', args=ast.arguments(
            args=[ast.arg(arg='a', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]
        ),
            body=[ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())], value=ast.Name(id='a', ctx=ast.Load()))],
            decorator_list=[],
            returns=None
            )
        ]
    )
    variables = {
        'a': 'aa',
        'b': 'bb'
    }

# Generated at 2022-06-23 23:48:24.957070
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    var = 'var'
    node = ast.keyword(arg=var, value=1)
    replacer = VariablesReplacer({var: 'var_1'})
    assert replacer.visit_keyword(node) == ast.keyword(arg='var_1', value=1)

# Generated at 2022-06-23 23:48:30.895988
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    source = '''
        def test():
            class Test:
                def __init__(self):
                    pass
            x = Test()
            x.some_attr = 1
            Test.some_attr = 1
    '''
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, {'Test': 'SomeClass', 'x': 'var'})
    assert get_source(tree.body[0]) == '''
        def test():
            class SomeClass:
                def __init__(self):
                    pass
            var = SomeClass()
            var.some_attr = 1
            SomeClass.some_attr = 1
    '''

# Generated at 2022-06-23 23:48:34.107474
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    x = ast.Name(id='x', ctx=ast.Load())
    variables = {'x': 'y'}
    VariablesReplacer.replace(x, variables)
    assert x.id == 'y'

# Generated at 2022-06-23 23:48:37.713675
# Unit test for function extend
def test_extend():
    fn = lambda: extend(ast.parse("x=1;x=2"))
    snip = snippet(fn)
    body = snip.get_body()
    assert get_source(body) == 'x = 1\nx = 2'



# Generated at 2022-06-23 23:48:44.757207
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    src = 'try: pass \nexcept Exception as e: pass \n'
    tree = ast.parse(src)
    d = {'e': 'a'}
    VariablesReplacer.replace(tree, d)
    v = VariablesGenerator.generate('a')
    expected = f'except Exception as {v}: pass \n'
    assert expected == astor.to_source(tree).split('\n')[1]



# Generated at 2022-06-23 23:48:55.289879
# Unit test for constructor of class snippet
def test_snippet():
    class Bla:
        @snippet
        def my_snippet(x, y):
            z = x + y
            print(z, x)
            return z


# Generated at 2022-06-23 23:49:04.571771
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_func(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
    
    snippet = snippet(test_func)
    tree = snippet.get_body(x=1, y=2)

    # Expectations

# Generated at 2022-06-23 23:49:06.779729
# Unit test for function extend
def test_extend():
    def test_snippet():
        extend(vars)
        print(x, y)

    tree = ast.parse("y = 1")
    vars = tree.body
    assert [n.value for n in test_snippet.get_body(vars=vars)] == [None, 1]

# Generated at 2022-06-23 23:49:10.027469
# Unit test for function find_variables
def test_find_variables():
    source = """a = let(1)
    a = let(2)"""
    tree = ast.parse(source)
    variables = set(find_variables(tree))

    assert 'a' in variables

# Unit tests for class VarablesReplacer

# Generated at 2022-06-23 23:49:16.784957
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
    try:
        x = 2
    except Exception as e:
        pass
    """
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, {'e': [ast.parse("""x = 1""").body[0]]})
    assert get_source(tree) == "try:\n    x = 2\nexcept Exception:\n    x = 1\n    pass"

# Generated at 2022-06-23 23:49:20.372578
# Unit test for method visit_Attribute of class VariablesReplacer

# Generated at 2022-06-23 23:49:24.115388
# Unit test for function find_variables
def test_find_variables():
    text = '''
        def body():
            let(x)
            x += 1
        let(y)
        y = 1
    '''
    root = ast.parse(text)
    assert set(find_variables(root)) == {'x', 'y'}


# Generated at 2022-06-23 23:49:35.454902
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    def foo():
        let(y)
        test_function(y=y)
    source = get_source(foo)
    tree = ast.parse(source)
    variables = find_variables(tree)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:49:38.769162
# Unit test for function let
def test_let():
    tree = snippet(lambda x: let(x)).get_body(x=1)
    assert tree == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.Num(1))]


# Generated at 2022-06-23 23:49:42.265022
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def test():
        let(x)
        x += 1
        y = 1



# Generated at 2022-06-23 23:49:45.133635
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse(
        """
        if True:
            pass
        """
    )
    variables = {
        'pass': 'pass_var'
    }
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "If(test=Name(id='True', ctx=Load()), body=[Pass(lineno=2, col_offset=4)], orelse=[])"


# Generated at 2022-06-23 23:49:48.919357
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(a)\nlet(b)\nq = a + b\nb = a / q\nreturn q')
    assert set(find_variables(tree)) == {'a', 'b'}



# Generated at 2022-06-23 23:49:50.998696
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(fn)
    actual = snippet_instance.get_body()
    expected = ast.parse("x += 1\ny = 1").body
    assert actual == expected



# Generated at 2022-06-23 23:49:55.610509
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .tests.test_snippet import test_VariablesReplacer_visit_ImportFrom as test_VariablesReplacer_visit_ImportFrom_impl
    test_VariablesReplacer_visit_ImportFrom_impl()


# Generated at 2022-06-23 23:49:56.449092
# Unit test for function extend_tree

# Generated at 2022-06-23 23:50:07.271064
# Unit test for constructor of class snippet
def test_snippet():
    # Check that the constructor is implemented correctly
    # This is how I implemented it
    @snippet
    def fun(x):
        let(x)
        x += 1
        return x
    # This is how I expect it to be implemented
    class snippet2:
        def __init__(self, fn: Callable[..., None]) -> None:
            self._fn = fn

        def get_body(self, **snippet_kwargs: Variable) -> List[ast.AST]:
            source = get_source(self._fn)
            tree = ast.parse(source)
            names = find_variables(tree)
            variables = {name: VariablesGenerator.generate(name)
                         for name in names}

# Generated at 2022-06-23 23:50:11.101010
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    print(x)
    """)
    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-23 23:50:17.258603
# Unit test for function let
def test_let():
    @snippet
    def fn():
        let(a)
        let(b)
        a = 1
        b = 2

    assert repr(fn.get_body()) == repr([
        ast.Assign(targets=[
            ast.Name(id='_py_backwards_a_0', ctx=ast.Store())
        ],
            value=ast.Num(n=1)),
        ast.Assign(targets=[
            ast.Name(id='_py_backwards_b_1', ctx=ast.Store())
        ],
            value=ast.Num(n=2))
    ])



# Generated at 2022-06-23 23:50:21.791405
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    x += 1
    let(y)
    y = 1
    '''
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']

# Generated at 2022-06-23 23:50:29.767711
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .helpers import VariablesGenerator, VariablesReplacer

    vgen = VariablesGenerator()
    source = '''
            class x:
                def method(self):
                    return self.x
            '''

    tree = ast.parse(source)
    variables = {'x': vgen.generate('x')}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree, include_attributes=False) == '''
            class <VariablesGenerator:1>:
                def method(self):
                    return self.<VariablesGenerator:1>
            '''

# Generated at 2022-06-23 23:50:30.321176
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-23 23:50:33.880160
# Unit test for function find_variables
def test_find_variables():
    from astunparse import unparse
    tree = ast.parse("let(a)\na = 1\nlet(b)\nb = 2")
    vars = list(find_variables(tree))
    assert unparse(tree) == "a = 1\nb = 2"
    assert vars == ['a', 'b']



# Generated at 2022-06-23 23:50:43.535765
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    import astor
    class_def = ast.parse("class foo(object):\n  pass").body[0]
    class_def.name = 'foo'
    class_def.args.args[0].arg = 'bar'
    class_def.args.args[0].annotation = ast.parse('bar').body[0].value
    def_node = ast.parse('def bar():\n  pass').body[0]
    def_node.args.args[0].arg = 'bar'
    def_node.args.args[0].annotation = ast.parse('bar').body[0].value
    with_item = ast.parse('with bar as b:\n  pass').body[0].items[0]
    with_item.context_expr = ast.parse('bar').body[0].value
    with_

# Generated at 2022-06-23 23:50:52.005454
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    # source code
    source = "try:\n    pass\nexcept Exception as e:\n    pass"
    # parse into AST
    tree = ast.parse(source)
    # replace "e" with "raisa"
    variables = {"e": "raisa"}
    # replace variables
    VariablesReplacer.replace(tree, variables)
    # expected result
    expected = "try:\n    pass\nexcept Exception as raisa:\n    pass"
    # actual result
    actual = to_source(tree)
    assert(expected == actual)

# Generated at 2022-06-23 23:50:57.213783
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def get_ast(tree, field):
        node = ast.FunctionDef()
        node.name = None
        node = VariablesReplacer.replace(node, {tree: field})
        return node.name
    assert get_ast(123, 'str') is None
    assert get_ast(123, [ast.FunctionDef()]) is None

# Generated at 2022-06-23 23:50:59.730677
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("c = b")
    variables = {'b': 'b_replacement'}

    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert (tree.body[0].targets[0].id == 'c')
    assert (tree.body[0].value.id == 'b_replacement')



# Generated at 2022-06-23 23:51:03.381591
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(foo)')
    variables = {'foo': ast.parse('x = 0').body[0]}
    extend_tree(tree, variables)
    assert get_source(tree) == 'x = 0\n'

# Generated at 2022-06-23 23:51:12.535124
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x):
        let(x)
        let(y)
        let(z)
        x += 1
        y = 2
        z += 3

    tree = ast.parse(get_source(f))
    my_snippet = snippet(f)
    body = my_snippet.get_body(x=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()))
    assert ast.dump(tree.body[0].body[3]) == ast.dump(body[0])
    assert ast.dump(tree.body[0].body[4]) == ast.dump(body[1])



# Generated at 2022-06-23 23:51:15.512466
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)\nlet(y)")
    assert next(find_variables(tree)) == 'x'
    assert next(find_variables(tree)) == 'y'
    assert len(list(find_variables(tree))) == 0



# Generated at 2022-06-23 23:51:22.089031
# Unit test for function let
def test_let():
    @snippet
    def my_snippet():
        let(x)
        x += 1

    assert my_snippet.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        )
    ]



# Generated at 2022-06-23 23:51:33.309943
# Unit test for function extend
def test_extend():
    ext = snippet(extend)

    test_list = [ast.Assign([ast.Name(id='a')], ast.Name(id='b')), ast.Assign([ast.Name(id='c')], ast.Name(id='d'))]

# Generated at 2022-06-23 23:51:36.675709
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import astor
    variables = {'sys': 'foo'}
    tree = ast.parse('import sys')
    VariablesReplacer.replace(tree, variables)
    assert astor.to_source(tree) == "import foo"

# Generated at 2022-06-23 23:51:45.794024
# Unit test for constructor of class snippet
def test_snippet():
    def t():
        let(x)
        let(y)
        x += 1
        y += 1
        return x + y


# Generated at 2022-06-23 23:51:53.208578
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    """Basic unit test for class VariablesReplacer"""
    test_tree = ast.parse("""def foo():
        pass""")
    
    test_variables = {"foo": "bar"}
    test_replacer = VariablesReplacer(test_variables)
    result = test_replacer.visit_FunctionDef(test_tree.body[0])
    
    assert result.name == "bar"
    
    

# Generated at 2022-06-23 23:52:03.633586
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # helper function for generating list of ast.Expr objects
    def to_exprs(lst):
        return [ast.Expr(value=node) for node in lst]

    # short alias for ast.parse
    parse = lambda code: ast.parse(code=code).body[0].body

    # short alias for class snippet
    snippet = lambda fn: snippet(fn).get_body()

    # basic case, no variables in snippet
    def test():
        stmt1 = ast.parse('x = 1').body[0]
        stmt2 = ast.parse('print(x)').body[0]
        expected = [stmt1, stmt2]


# Generated at 2022-06-23 23:52:13.296556
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(a: int, b: int) -> int:
        let(x)
        let(y)
        x = a
        y = b
        return x + y

    body = snippet(test_snippet).get_body(a=1, b=2)
    assert body[0] == ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                                 value=ast.Num(n=1))
    assert body[1] == ast.Assign(targets=[ast.Name(id='_py_backwards_y_0', ctx=ast.Store())],
                                 value=ast.Num(n=2))



# Generated at 2022-06-23 23:52:19.998252
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():  # added
    node = ast.parse('print(let(x))', mode='eval').body
    find_variables(node)
    tree = VariablesReplacer.replace(node, {'x': 'y'})
    assert(ast.dump(tree) == "Expr(value=Call(func=Name(id='print', ctx=Load()), args=[y], keywords=[], starargs=None, kwargs=None))")


# Generated at 2022-06-23 23:52:31.348542
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    import os
    import sys
    sys.path.append(os.path.dirname(__file__))
    import helpers

    def test(input_tree, expected_tree):
        tree = ast.parse(input_tree)
        variables = helpers.find_variables(tree)
        helpers.VariablesReplacer.replace(tree, variables)
        assert ast.dump(tree) == expected_tree

    test("from . import a", "from . import a")
    test("from . import a as b", "from . import a as b")
    test("from . import a, b", "from . import a, b")
    test("from . import a as b, c", "from . import a as b, c")
    test("from . import a, b as c", "from . import a, b as c")

# Generated at 2022-06-23 23:52:39.839781
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import unittest
    import ast
    class Unit(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.result1 = ast.alias(
                name='importname',
                asname='asname'
            )
            self.result2 = ast.alias(
                name='importname',
                asname='asname'
            )
            self.result3 = ast.alias(
                name='importname',
                asname='asname2'
            )
            self.result4 = ast.alias(
                name='importname1',
                asname='asname'
            )


# Generated at 2022-06-23 23:52:40.957098
# Unit test for constructor of class snippet
def test_snippet():
    snippet = snippet(lambda: None)
    assert snippet

# Generated at 2022-06-23 23:52:47.895784
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    gen = VariablesGenerator('a', 'b', 'c')
    variables = {'x': 'y', 'a': gen.generate('a')}
    module = ast.parse('from x import a')
    VariablesReplacer.replace(module, variables)
    assert module._fields == ('body',)
    assert isinstance(module.body[0], ast.ImportFrom)
    assert module.body[0].names[0].name == 'a'
    assert module.body[0].module == 'y'

# Generated at 2022-06-23 23:52:50.378424
# Unit test for function extend_tree
def test_extend_tree():
    x = 1
    y = 2

# Generated at 2022-06-23 23:53:00.444787
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    """Unit test for method visit_Attribute of class VariablesReplacer."""
    variables = {
        'attr': 'new_attr',
    }

    attr_node = ast.Attribute(
        lineno=0,
        col_offset=0,
        value=ast.Name(
            lineno=0,
            col_offset=0,
            id='value',
        ),
        attr='attr',
        ctx=ast.Load(),
    )

    new_node = VariablesReplacer.replace(attr_node, variables)

    assert isinstance(new_node, ast.Attribute)
    assert new_node.value.id == 'value'
    assert new_node.attr == 'new_attr'

