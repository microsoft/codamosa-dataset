

# Generated at 2022-06-23 23:43:02.873843
# Unit test for function extend_tree
def test_extend_tree():
    module = ast.parse("""
        extend(variable)
        print(variable)
    """)

    extended_module = ast.parse("""
        extend(variable)
        a = 1
        print(variable)
    """)

    extended_module_changed = ast.parse("""
        extend(variable)
        a = 2
        print(variable)
    """)

    extend_tree(module, {'variable': [extended_module.body[1]]})

    assert ast.dump(module) == ast.dump(extended_module)

    extend_tree(module, {'variable': [extended_module_changed.body[1]]})

    assert ast.dump(module) == ast.dump(extended_module_changed)

# Generated at 2022-06-23 23:43:05.103507
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    a = 1
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-23 23:43:06.116681
# Unit test for function extend

# Generated at 2022-06-23 23:43:17.085243
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    # Define a function that takes "foo" as its parameter
    func_source = '''def func(foo):
        pass'''
    func_tree = ast.parse(func_source)
    # Define a snippet which contains only the parameter of "func",
    # i.e., "foo"
    snippet_source = '''snippet(foo)'''
    snippet_tree = ast.parse(snippet_source)

    # Get the only node of type "arg" for the snippet and for the function
    snippet_arg_node = snippet_tree.body[0].args[0]
    func_arg_node = func_tree.body[0].args[0]

    # Replace "foo" with "bar" in the snippet
    replacement_dict = {'foo': 'bar'}
    VariablesReplacer.replace

# Generated at 2022-06-23 23:43:28.266405
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    h = ast.arg(arg='h')
    impo = ast.ImportFrom(module='foo', names=[ast.alias(name='*', asname=None)])
    func = ast.FunctionDef(name='f', args=ast.arguments(args=[h], vararg=None, kwonlyargs=[], kw_defaults=[],
                                                         kwarg=None, defaults=[]),
                           body=[impo], decorator_list=[])
    tree = ast.Module(body=[func])
    variables = {'h': ast.Name(id='hh'), 'foo': ast.Name(id='a')}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].args.args[0].arg == 'hh'

# Generated at 2022-06-23 23:43:34.188818
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Foo:
        foo = 0

    class Foo2(Foo):
        foo = 0

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D, C):
        pass
    # Test support of multiple inheritance
    assert E.__mro__ == (E, D, B, C, A, object)
    # Test support of single inheritance
    assert B.__mro__ == (B, A, object)



# Generated at 2022-06-23 23:43:37.914785
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("print(y)")
    variables = {'y': 'x'}
    assert VariablesReplacer.replace(tree, variables).body[0].value.args[0].id == 'x'

# Generated at 2022-06-23 23:43:48.171977
# Unit test for function let
def test_let():
    from .tree import find
    global let
    fn = snippet(lambda: let(x))
    assert len(find(fn.get_body()[0], ast.Assign)) == 0
    fn = snippet(lambda: let(x) + 1)
    assert len(find(fn.get_body()[0], ast.Assign)) == 0
    fn = snippet(lambda: let(x) + let(y))
    assert len(find(fn.get_body()[0], ast.Assign)) == 0
    fn = snippet(lambda: let(y)[let(x)])
    assert len(find(fn.get_body()[0], ast.Assign)) == 0
    fn = snippet(lambda: let(x).attr)

# Generated at 2022-06-23 23:43:53.919713
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # for value in [ast.Name('c', ast.Store())]
    #     tree = ast.ClassDef('a', [ast.Name('b', ast.Store())], [], [value], [])
    #     expected = ast.ClassDef('a', [ast.Name('b', ast.Store())], [], [], [])
    #     actual = VariablesReplacer.replace(tree, {'c': 'd'})
    #     assert expected == actual
    #     actual = VariablesReplacer.replace(tree, {'c': expected})
    #     assert expected == actual
    assert 1 == 1


# Generated at 2022-06-23 23:44:04.406555
# Unit test for function find_variables
def test_find_variables():
    def fn(x):
        return x * 2

    tree = ast.parse(get_source(fn))
    assert {'x'} == set(find_variables(tree))

    @snippet
    def snippet(x):
        let(x)
        x += 1
        return x

    tree = ast.parse(get_source(snippet))
    assert {'x'} == set(find_variables(tree))

    @snippet
    def snippet_with_var(x):
        let(x)
        x += 1
        return x + y

    tree = ast.parse(get_source(snippet_with_var))
    assert {'x', 'y'} == set(find_variables(tree))


# Generated at 2022-06-23 23:44:05.337631
# Unit test for constructor of class snippet
def test_snippet():
    snippet(test_snippet)
    let(1)
    extend(1)

# Generated at 2022-06-23 23:44:13.000869
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    from . import bool_to_int

    tree = ast.parse(get_source(bool_to_int))

    tree = VariablesReplacer.replace(tree, {'bool_to_int': '__bool_to_int__'})


# Generated at 2022-06-23 23:44:18.927138
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
        print('{:d} {:d}'.format(x, y))

    # test(x=1, y=1)
    get_body = snippet(test).get_body(x=1, y=1)
    print(ast.dump(get_body))

# Generated at 2022-06-23 23:44:22.043595
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('let(x)'))) == ['x']
    assert list(find_variables(ast.parse('let(x); let(y)'))) == ['x', 'y']
    assert list(find_variables(ast.parse('let(x); let(y); let(z)'))) == ['x', 'y', 'z']



# Generated at 2022-06-23 23:44:32.376181
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Node():
        pass
    
    value = Node()
    value.name = 'name'
    value.bases = [
        Node(),
        Node(),
    ]
    value.bases[0].id = 'bases_0'
    value.bases[1].id = 'bases_1'
    value.body = [
        Node(),
        Node(),
    ]
    value.body[0].name = 'body_0'
    value.body[1].name = 'body_1'
    value.decorator_list = [
        Node(),
        Node(),
    ]
    value.decorator_list[0].id = 'decorator_list_0'
    value.decorator_list[1].id = 'decorator_list_1'
    value.keywords

# Generated at 2022-06-23 23:44:37.085784
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # Tests

    class_def = ast.ClassDef(
        "test",
        [],
        [],
        [],
        []
    )
    print(class_def.__dict__)

    node = VariablesReplacer({"test": "test2"}).visit_ClassDef(class_def)
    print(node.__dict__)

    assert (node.name == "test2")



# Generated at 2022-06-23 23:44:44.453842
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class N(ast.Name):
        def __init__(self, id):
            self.id = id

    nodes = {
        N('x'): 'y',
        N('x_0'): 'y_0',
        N('x_1'): N('y_1'),
    }

    vr = VariablesReplacer(nodes)
    for key, value in nodes.items():
        assert vr.visit_Name(key) == value


# Generated at 2022-06-23 23:44:53.943139
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
try:
    a = 2
except Exception as b:
    pass
"""
    tree = ast.parse(source)
    variables = {'b': 'c'}
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:44:54.735110
# Unit test for method visit_ExceptHandler of class VariablesReplacer

# Generated at 2022-06-23 23:45:05.308607
# Unit test for function let
def test_let():
    def fn():
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_body = snippet(fn).get_body()
    assert snippet_body[0].value.id == '_py_backwards_x_0'
    assert snippet_body[0].value.op == 'Add'
    assert snippet_body[1].value.id == '_py_backwards_y_0'
    assert snippet_body[1].value.n == 1
    assert snippet_body[2].value.left.id == '_py_backwards_x_0'
    assert snippet_body[2].value.op == 'Add'
    assert snippet_body[2].value.right.id == '_py_backwards_y_0'



# Generated at 2022-06-23 23:45:12.776573
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import typed_ast.ast3 as ast
    ast3 = ast.parse('try:\n x = 1\nexcept Exception:\n x = 1')
    replacer = VariablesReplacer({"Exception": "Exception"})
    replacer.visit(ast3)
    assert ast.dump(ast3) == 'Module(body=[Try(body=[Assign(targets=[Name(id=x, ctx=Store())], value=Num(n=1))], handlers=[ExceptHandler(type=Name(id=Exception, ctx=Load()), name=None, body=[Assign(targets=[Name(id=x, ctx=Store())], value=Num(n=1))], lineno=2, col_offset=0)], orelse=[], finalbody=[])])'

# Generated at 2022-06-23 23:45:18.975448
# Unit test for function extend
def test_extend():
    tree_template = ast.parse('''
    extend(vars)
    print(a)
    ''')

    tree_snippet = ast.parse('''
    a = 1
    a = 2
    ''')

    extend_tree(tree_template, {'vars': tree_snippet.body})

    assert ast.dump(tree_template) == ast.dump(tree_snippet)



# Generated at 2022-06-23 23:45:28.809582
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(
        '''
    extend(params)
    ''')
    node = tree.body[0]
    params = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                          value=ast.Num(n=1)),
                ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                          value=ast.Num(n=2))]
    extend_tree(tree, {node.args[0].id: params})

    want = ast.parse(
        '''
    x = 1
    x = 2
    ''')
    assert ast.dump(tree) == ast.dump(want)

# Generated at 2022-06-23 23:45:33.197467
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import get_nodes_count

    def test_snippet(x: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_test = snippet(test_snippet)
    test_source = snippet_test.get_body(x=1, y=1)  # type: ignore
    assert get_nodes_count(test_source) == 3

# Generated at 2022-06-23 23:45:43.402771
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import foo
    import foo.bar
    import foo.bar.baz as b

    source = "import foo\nimport foo.bar\nimport foo.bar.baz as b"
    tree = ast.parse(source)
    variables = {'foo': 'foox', 'foo.bar': 'foo.barx', 'foo.bar.baz as b': 'foo.bar.baz as bx'}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    print(ast.dump(tree))
    assert ast.dump(tree) == '<_ast.Module object at 0x7f6d4c1b4e10>'


# Generated at 2022-06-23 23:45:44.834645
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda x: x + 1)
    assert snippet(lambda x: x + 1)._fn


# Generated at 2022-06-23 23:45:48.650884
# Unit test for function extend
def test_extend():
    extend_tree(ast.parse("""extend(x)"""), {'x': ast.parse("""x=1;x=2;""")})
    extend_tree(ast.parse("""extend(x)"""), {'x': ast.parse("""x=1;y=2;""")})

# Generated at 2022-06-23 23:45:54.827411
# Unit test for function extend
def test_extend():
    @snippet
    def _(vars):
        extend(vars)

    x = ast.Name(id="x")
    z = ast.Name(id="z")
    vars = [ast.Assign(targets=[x], value=ast.Num(1)),
            ast.Assign(targets=[z], value=ast.Num(3))]
    source = _.get_body(vars=vars)
    assert source == vars

# Generated at 2022-06-23 23:46:05.140619
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('''
x = 1
y = x
x = 1
''')
    variables = {
        'x': 'y',
        'y': 'x'
    }
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == '''\
Module(body=[Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='x', ctx=Store())], value=Name(id='y', ctx=Load())), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1))])'''


# Generated at 2022-06-23 23:46:09.262674
# Unit test for function let
def test_let():
    import pytest
    from .tests import assert_code_equal

    def snippet_let():
        let(1)  # we should not see `let` code in result

    assert_code_equal(snippet(snippet_let).get_body(), ['1'])



# Generated at 2022-06-23 23:46:14.603100
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    source = 'def f(self):\n    print(self.x)'
    tree = ast.parse(source)
    variables = {'self': '_py_backwards_self_0'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)

# Generated at 2022-06-23 23:46:24.841300
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import inspect
    import typed_astunparse
    from typed_ast.ast3 import Assign, ExceptHandler

    tree = ast.parse(inspect.getsource(VariablesReplacer.visit_ExceptHandler))

    variables = {'node': ast.Name(id='n', ctx=ast.Load())}
    VariablesReplacer.replace(tree, variables)
    node = tree.body[0].body[0].value.body[0].body[2]  # type: ignore

    assert isinstance(node, ExceptHandler)
    assert isinstance(node.name, ast.Name)
    assert node.name.id == 'n'

    node.name = ast.Name(id='a', ctx=ast.Load())

    result = typed_astunparse.unparse(tree)

# Generated at 2022-06-23 23:46:27.717702
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Test:
        pass

    test = Test()
    test.name = 'x'
    test.value = 2
    replace_result = VariablesReplacer.replace(test, {'x': 'y'})
    assert replace_result.name == 'y'

# Generated at 2022-06-23 23:46:38.404693
# Unit test for function extend
def test_extend():
    from .tree import get_assignments
    # print(get_assignments(find_function('decorators/decorators.py')))
    variables = VariablesGenerator.generate('vars')
    def b():
        x = 1
        x = 2
    tree = ast.parse(get_source(b))
    extend_tree(tree, {'vars': tree.body})
    assert get_assignments(tree) == [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ]



# Generated at 2022-06-23 23:46:46.938455
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def var(a: int, b: ast.Name):
        let(a)
        b += 1

    assert var.get_body() == [
        ast.Assign(target=ast.Name(id='a'), value=ast.Name(id='a')),
        ast.Assign(
            target=ast.Name(id='b'),
            value=ast.BinOp(
                left=ast.Name(id='b'),
                op=ast.Add(),
                right=ast.Num(n=1)))
    ]


# Generated at 2022-06-23 23:46:52.632940
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('def f():\n    pass')
    variables = {'f': 'foo'}
    inst = VariablesReplacer(variables)
    inst.visit_FunctionDef(tree.body[0])
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert tree.body[0].name == 'foo'


# Generated at 2022-06-23 23:47:00.344514
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 42

    @snippet
    def snippet_fn():
        let(x + 1)
        x += 1

    assert snippet_fn.get_body() == [ast.Assign([ast.Name(id='_py_backwards_x__0', ctx=ast.Store())],
                                                ast.BinOp(ast.Name(id='_py_backwards_x__0', ctx=ast.Load()),
                                                          ast.Add(), ast.Num(n=2))),
                                     ast.AugAssign(ast.Name(id='_py_backwards_x_0', ctx=ast.Store()),
                                                   ast.Add(), ast.Num(n=1))]

# Generated at 2022-06-23 23:47:01.615355
# Unit test for constructor of class snippet

# Generated at 2022-06-23 23:47:07.976973
# Unit test for function extend_tree
def test_extend_tree():
    def snippet():
        extend(x)
        print(x)

    vars = ast.parse("x=1").body
    tree = snippet.get_body(x=vars)
    
    assert len(tree) == 2
    assert len(tree[0].targets) == 1
    assert tree[0].targets[0].id == 'x'
    
    

# Generated at 2022-06-23 23:47:13.535429
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse(
        """let(x)
           x = 1
           let(y)
           x += y
           y = 2
           y"""
    )
    assert find_variables(tree) == ['x', 'y']
    assert get_source(tree) == (
        "x = 1\n"
        "x += y\n"
        "y = 2\n"
        "y\n"
    )



# Generated at 2022-06-23 23:47:14.461360
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-23 23:47:15.026304
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-23 23:47:24.524477
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    vars = [ast.Assign(targets=[ast.Name(id='x')],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x')],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-23 23:47:29.354248
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Tree(ast.AST):
        pass

    t = Tree()
    t.name = 'test'

    replacer = VariablesReplacer({
        'test': 'test123'
    })

    t = replacer.visit_ClassDef(t)

    assert t.name == 'test123'



# Generated at 2022-06-23 23:47:35.353760
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    ITER_NODES = [ast.Import(names=[ast.alias(name='typing', asname=None)]),
                  ast.ImportFrom(module='typing', names=[ast.alias(name='List', asname=None)], level=0)]
    ITER_NODES_MODIFIED = [ast.Import(names=[ast.alias(name='typing_', asname=None)]),
                           ast.ImportFrom(module='typing_', names=[ast.alias(name='List', asname=None)], level=0)]
    for node in ITER_NODES:
        variables = {'typing': 'typing_'}
        visit_ImportFrom = VariablesReplacer.replace(node, variables)

# Generated at 2022-06-23 23:47:39.817747
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    node = ast.ClassDef(name="name", body=[], decorator_list=[], keyword=[])
    node = VariablesReplacer.replace(node, {'name': '_py_backwards_name_0'})
    assert node.name == "_py_backwards_name_0"



# Generated at 2022-06-23 23:47:45.014217
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        return x

    tree = ast.parse(get_source(test))
    snippet_kwargs = {'x': ast.Num(n=1)}
    body = snippet(test).get_body(**snippet_kwargs)
    assert body == tree.body[0].body


# Generated at 2022-06-23 23:47:50.134079
# Unit test for function extend_tree
def test_extend_tree():
    from .snippets import all_imports
    import astunparse

    tree = ast.parse('extend(all_imports)\nx = 2')
    extend_tree(tree, locals())
    assert astunparse.unparse(tree) == \
        astunparse.unparse(all_imports) + \
        '\nx = 2'

# Generated at 2022-06-23 23:47:53.647583
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    node = ast.parse("foo.b.c")
    node = node.body[0].value.args[0]
    variables = {"foo.b.c": ast.Str("a")}
    res = VariablesReplacer.replace(node, variables)
    assert res == ast.Str("a")


# Generated at 2022-06-23 23:47:56.000089
# Unit test for function let
def test_let():
    assert snippet(lambda: let(x)).get_body() == [ast.parse('x=None').body[0]]


# Generated at 2022-06-23 23:48:05.056290
# Unit test for function find_variables
def test_find_variables():
    code = '''
let(x)
let(y)
x = 1
y = 2
'''

    tree = ast.parse(code)
    variables = find_variables(tree)
    assert variables == {'x', 'y'}
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'y\', ctx=Store())], value=Num(n=2))])'


# Unit tests for class snippet

# Generated at 2022-06-23 23:48:09.456189
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    class Mock:
        def __init__(self):
            self.module = "ast"
    a = Mock()
    tree = ast.parse("")
    b = VariablesReplacer.replace(tree, {})
    if b != tree:
        raise AssertionError



# Generated at 2022-06-23 23:48:13.517653
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    classVariablesReplacer = VariablesReplacer({'a': 'b'})
    assert isinstance(classVariablesReplacer.visit_Name(ast.Name('a', ast.Load())), ast.Name)


# Generated at 2022-06-23 23:48:19.593051
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class B:
        pass

    a = B()
    b = B()

    code_tree = ast.parse('class C(b):\n    pass')
    code_tree = VariablesReplacer.replace(
        code_tree,
        {
            'a': a,
            'b': b,
        })
    assert code_tree.body[0].bases[0] == b



# Generated at 2022-06-23 23:48:25.403085
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse("""
        def a(x, y):
            pass
    """)
    replacer = VariablesReplacer({'x': '_a', 'y': '_b'})
    replacer.visit(tree)  # type: ignore
    assert tree.body[0].args.args[0].arg == "_a"  # type: ignore
    assert tree.body[0].args.args[1].arg == "_b"  # type: ignore

# Generated at 2022-06-23 23:48:29.059321
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = """
        from hello import world
        world.abc = 2
    """
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, {'hello': 'bye', 'world': 'moon'})
    assert astor.to_source(tree) == dedent("""
        from bye import moon
        moon.abc = 2
    """)



# Generated at 2022-06-23 23:48:34.151379
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    let(z)
    extend(vars)
    '''
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert variables == {'x', 'y', 'z'}



# Generated at 2022-06-23 23:48:34.738080
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet

# Generated at 2022-06-23 23:48:36.866772
# Unit test for function find_variables
def test_find_variables():
    fn = snippet(lambda: let(1))
    assert fn._get_variables(fn.get_body(), {})['x'] == '_py_backwards_x_0'



# Generated at 2022-06-23 23:48:43.255311
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    #snippet = queue.Queue()
    #snippet.put(1)
    root = ast.parse("x = 1")
    variables = {"x": "y"}
    VariablesReplacer.replace(root, variables)
    id_value = root.body[0].targets[0].id
    assert id_value == "y"

# Generated at 2022-06-23 23:48:53.491290
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import json

    def print_var_name(var):
        print(var.__name__)
        pass

    def print_json_var(var):
        print(json.dumps(var))
        pass

    @snippet
    def my_snippet(x, y):
        let(x)
        let(y)
        print_var_name(x)
        print_json_var(x)

    body = my_snippet.get_body(x = 1)

    assert len(body) == 2

    assert isinstance(body[0], ast.Call)
    assert isinstance(body[0].func, ast.Name)
    assert body[0].func.id == 'print_var_name'
    assert isinstance(body[0].args[0], ast.Name)

# Generated at 2022-06-23 23:49:04.486780
# Unit test for function extend
def test_extend():
    @snippet
    def my_snippet(x: int, y: int, z: int) -> None:
        extend(vars)
        x += 1
        y += 2

    tree = my_snippet.get_body(vars=ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                              value=ast.Num(n=1)),
                               x=3,
                               y=4,
                               z=5)

# Generated at 2022-06-23 23:49:13.220022
# Unit test for function extend
def test_extend():
    def test_snippet(x: int) -> int:
        extend(vars)
        return x + 1
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                        value=ast.Num(n=2))]
    body = test_snippet.get_body(vars=vars)
    assert body == [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                               value=ast.Num(n=2)),
                    ast.Return(value=ast.BinOp(left=ast.Name(id='x'),
                                               op=ast.Add(),
                                               right=ast.Num(n=1)))]



# Generated at 2022-06-23 23:49:14.035614
# Unit test for function extend_tree

# Generated at 2022-06-23 23:49:19.829751
# Unit test for function find_variables
def test_find_variables():
    @snippet
    def tsnippet(a: int, b: int) -> int:
        let(x)
        x += a
        y = 1
        let(z)
        z = 2
        y += x + z + b
        return y
    
    tree = tsnippet.get_body(a = 9, b = 10)

    assert(tree[0].targets[0].id == '_py_backwards_x_0')
    assert(tree[1].value.left.id == '_py_backwards_x_0')
    assert(tree[3].targets[0].id == '_py_backwards_z_0')


# Generated at 2022-06-23 23:49:25.371208
# Unit test for function let
def test_let():
    @snippet
    def test(x, y):
        """Docstring"""
        let(x)
        let(y)
        x += 1
        y += 2
        print(x, y)

    tree = test.get_body(x=4, y=4)
    assert ([node.target.id for node in tree] ==
            ['_py_backwards_x_0', '_py_backwards_y_0'])



# Generated at 2022-06-23 23:49:31.280628
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_fn(x: int, y: int):
        let(z)
        extend(assignments)

    snippet_instance = snippet(test_snippet_fn)
    snippet_instance.get_body(x=1, y=2, z=3, assignments=None)



# Generated at 2022-06-23 23:49:34.688368
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    code = """
            class A:
                def __init__(self):
                    pass
        """
    tree = ast.parse(code)
    variables = {'A': 'B'}
    VariablesReplacer.replace(tree, variables)
    assert("B" in str(get_source(tree)))



# Generated at 2022-06-23 23:49:45.787088
# Unit test for function let
def test_let():
    def test_func():
        let(x)
        x += 1
        y = 1
        let(z)
        print(z)

    exp_body = [
        ast.Assign([ast.Name('x', ast.Store())], ast.BinOp(ast.Name('x'),
                                                            ast.Add(),
                                                            ast.Num(1))),
        ast.Assign([ast.Name('y', ast.Store())], ast.Num(1)),
        ast.Expr(ast.Call(ast.Name('print', ast.Load()),
                          [ast.Name('z', ast.Load())], [])),
    ]
    snippet_obj = snippet(test_func)
    body = snippet_obj.get_body()
    assert body == exp_body



# Generated at 2022-06-23 23:49:48.834957
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree=ast.parse('import a')
    a=snippet.get_body()
    assert a == [ast.Import(names=[ast.alias(name='a', asname=None)])]

# Generated at 2022-06-23 23:49:55.152374
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class ReplaceVisitor(VariablesReplacer):
        def __init__(self):
            super().__init__({'name': '_py_backwards_name_0'})

    node = ast.Name(id='name', ctx=ast.Load(), lineno=1, col_offset=2)
    visitor = ReplaceVisitor()
    new_node = visitor.visit_Name(node)
    assert new_node == ast.Name(id='_py_backwards_name_0', ctx=ast.Load(), lineno=1, col_offset=2)

# Generated at 2022-06-23 23:50:02.026019
# Unit test for function extend_tree
def test_extend_tree():
    # In this function test function extend_tree
    tree = ast.parse("""
x = {let(y)}
extend({extend([x = 1, x = 2])})
print(x)
""")
    variables = {'y': 'y', 'x': 'x', 'extend': 'extend', 'let': 'let'}
    extend_tree(tree, variables)
    assert get_source(tree) == """
x = y
x = 1
x = 2
print(x)
"""

# Generated at 2022-06-23 23:50:05.875899
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    source = "var = list()"
    tree = ast.parse(source)
    tree_new = VariablesReplacer.replace(tree, {"list": "my_list"})
    assert get_source(tree_new) == "var = my_list()"

# Generated at 2022-06-23 23:50:07.727695
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-23 23:50:16.021408
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    input_tree = ast.parse('x')
    # input_tree.body[0].value.func.attr = 'attr'
    # input_tree.body[0].value.func.id = 'id'
    # output_tree = VariablesReplacer.replace(input_tree, {'x': 'y'})
    print(input_tree)
    # print(output_tree)
    # print(ast.dump(output_tree))


# Generated at 2022-06-23 23:50:20.130481
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(a)
    let(b)
    c = a
    """)
    assert set(find_variables(tree)) == {'a', 'b'}



# Generated at 2022-06-23 23:50:21.172716
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    a = 5
    abs(a)

# Generated at 2022-06-23 23:50:30.913371
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():

    def my_func():
        pass

    ast_my_func = ast.parse(inspect.getsource(my_func))

    # Replace by name
    var = VariablesGenerator.generate(my_func.__name__)
    transformer = VariablesReplacer({my_func.__name__: var})
    transformer.visit(ast_my_func)
    assert find(ast_my_func, ast.FunctionDef)[0].name == var

    # Replace by Name node
    name = ast.Name(my_func.__name__, ast.Store())
    transformer = VariablesReplacer({my_func.__name__: name})
    transformer.visit(ast_my_func)
    assert find(ast_my_func, ast.FunctionDef)[0].name == name


# Generated at 2022-06-23 23:50:39.478001
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class TestVariablesReplacer(ast.NodeTransformer):
        def __init__(self, variables: Dict[str, Variable]) -> None:
            self._variables = variables

        def generic_visit(self, node: ast.AST) -> ast.AST:
            return node

    tree = ast.parse('x = 3')
    variables = {'x': 'y'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=3))])"
    return 0


# Generated at 2022-06-23 23:50:46.359273
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
  t = ast.parse("let('a'); let('b'); let('c')")
  v = {'a': 'e', 'b': 'd', 'c': 'f'}
  VariablesReplacer.replace(t, v)
  assert(get_source(t) == 'let(\'e\'); let(\'d\'); let(\'f\')')



# Generated at 2022-06-23 23:50:53.463312
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class_def = ast.ClassDef(
        name="Foo",
        body=[
            ast.FunctionDef(
                name="bar",
                args=ast.arguments(
                    args=[ast.arg(arg=None, annotation=None)]
                ),
                body=[ast.pass_()]
            )
        ]
    )

    class_def_expected = ast.ClassDef(
        name="abc",
        body=[
            ast.FunctionDef(
                name="bar",
                args=ast.arguments(
                    args=[ast.arg(arg=None, annotation=None)]
                ),
                body=[ast.pass_()]
            )
        ]
    )

    variables = {"Foo": "abc"}
    result = VariablesReplacer.replace(class_def, variables)
    assert result == class_

# Generated at 2022-06-23 23:51:03.759924
# Unit test for function find_variables
def test_find_variables():
    @snippet
    def fn():
        x = 1
        let(x)
        x += 1
        y = 1
        return x + y


# Generated at 2022-06-23 23:51:13.891722
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import copy
    import unittest

    from .variables import VariablesReplacer

    class VariablesReplacerTestCase(unittest.TestCase):
        def setUp(self):
            self.inst = VariablesReplacer({})

        def test_replace_module(self):
            standart_list = [
                ast.alias(
                    name='import1.import2asasname',
                    asname='asname',
                    ),
                ast.alias(
                    name='import1',
                    asname='asname',
                    ),
            ]


# Generated at 2022-06-23 23:51:14.437013
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet

# Generated at 2022-06-23 23:51:18.614122
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect
    source = inspect.getsource(test_snippet_get_body)
    ast_tree = ast.parse(source)
    func = ast_tree.body[0]
    snippet_1 = snippet(func)
    namespace = {'var_1': ast.Name(id='var_1', ctx=ast.Load())}
    assert snippet_1.get_body(**namespace) == func.body

# Generated at 2022-06-23 23:51:19.601905
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(extend)

# Generated at 2022-06-23 23:51:20.857810
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    @snippet
    def a():
        let(B)

# Generated at 2022-06-23 23:51:27.511757
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    key = 'x'
    value = '_x'
    variables = {key: value}
    node = ast.parse("x").body[0]
    expected = ast.parse("_x")
    actual = VariablesReplacer.replace(node, variables)
    assert actual == expected


# Generated at 2022-06-23 23:51:30.877358
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    node = ast.Name(id='a', lineno=1, col_offset=1, ctx=None)
    replace = VariablesReplacer.replace(node, {'a': 'b'})
    assert replace.id == 'b'



# Generated at 2022-06-23 23:51:40.567141
# Unit test for function extend
def test_extend():
    def test_snippet(x, vars):
        extend(vars)
        print(x)

    source = 'x = 1\nx = 2\n'
    tree = ast.parse(source)
    snippet_kwargs = {'x': '_py_backwards_x_0',
                      'vars': tree}
    body = snippet(test_snippet).get_body(**snippet_kwargs)  # type: ignore
    expected = ast.parse(source + 'print(_py_backwards_x_0)').body
    assert body == expected


# Generated at 2022-06-23 23:51:50.177143
# Unit test for function extend
def test_extend():
    snippet_kwargs = {'extensions': [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2))
    ]}
    res = snippet(lambda: extend(extensions)  # type: ignore
                  ).get_body(**snippet_kwargs)  # type: ignore

# Generated at 2022-06-23 23:51:58.604646
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
try:
    x = 1
except Exception:
    y = 2
except Exception as e:
    z = 3
"""
    tree = ast.parse(source)
    variables = {'e': ast.Name(id='_e', ctx=ast.Store())}
    VariablesReplacer.replace(tree, variables)
    execute_source = compile(tree, '<ast>', 'exec')
    g = {}
    exec(execute_source, g) # type: ignore
    assert g.get('_e')

# Generated at 2022-06-23 23:52:04.669181
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    root = ast.parse('''def f(a = let(y)):
        let(x)
    ''')
    variables = {'x': '_py_backwards_x_0', 'y': '_py_backwards_y_1'}
    instance = VariablesReplacer(variables)

    instance.visit(root)

    expected = '''def f(_py_backwards_y_1):
        _py_backwards_x_0
    '''

    assert ast.dump(root) == expected

# Generated at 2022-06-23 23:52:08.562606
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    """Check if visit_ClassDef works well."""
    classdef_node = ast.parse('class testName: pass').body[0]
    variables = {'testName': 'newTestName'}
    replacer = VariablesReplacer(variables)

    replacer.visit_ClassDef(classdef_node)
    assert classdef_node.name == 'newTestName'

# Generated at 2022-06-23 23:52:19.743088
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    body = ast.parse("""try:
        1 / 0
    except ZeroDivisionError as e:
        print("Zero division")
    """).body[0] #type: ignore
    assert type(body) == ast.Try
    assert type(body.handlers[0]) == ast.ExceptHandler
    assert type(body.handlers[0].name) == ast.Name
    assert body.handlers[0].name.id == "e"

    body.handlers[0].name.id = "some_name"
    assert body.handlers[0].name.id == "some_name"
    replacer = VariablesReplacer(variables={})
    replaced_body = replacer.visit(body)
    assert body == replaced_body

# Generated at 2022-06-23 23:52:31.155491
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('print(x)\nextend("x += 1")\nprint(x)')
    extend_tree(tree, {'x': ast.parse('x += 1')})
    assert ast.dump(tree) == 'Module(body=[Print(dest=None, values=[Name(id=\'x\', ctx=Load())], nl=True), Expr(value=BinOp(left=Name(id=\'x\', ctx=Load()), op=Add(), right=Num(n=1))), Expr(value=BinOp(left=Name(id=\'x\', ctx=Load()), op=Add(), right=Num(n=1))), Print(dest=None, values=[Name(id=\'x\', ctx=Load())], nl=True)])'

# Generated at 2022-06-23 23:52:37.444849
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
extend(vars)
a = 1
    """)
    vars = {'vars': [ast.Assign(targets=[ast.Name(id='a')], value=ast.Num(n=2))]}
    extend_tree(tree, vars)
    assert get_source(tree) == 'a = 2'



# Generated at 2022-06-23 23:52:42.373121
# Unit test for function let
def test_let():
    def fn():
        let(x)
        x += 1
        y = 1
    snippet_result = snippet(fn).get_body()
    expected_result = [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]
    assert snippet_result == expected_result


# Unit

# Generated at 2022-06-23 23:52:44.894094
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # arrange
    @snippet
    def fn():
        let(x)
        y = 1
        return y + x

    # act
    body = fn.get_body(x=2)

    # assert
    assert body[0].value.args[0].n == 1  # type: ignore



# Generated at 2022-06-23 23:52:49.407284
# Unit test for function extend_tree
def test_extend_tree():
    class new_class:
        def a(self):
            return 11
        def c(self):
            return 12
        def __init__(self):
            return

    x = new_class()

    def check_test():
        def inner_fn():
            extend(x.a)
            return x.c()

        assert inner_fn() == x.a()

    check_test()

# Generated at 2022-06-23 23:52:55.896756
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    def f(a):
       return a
       
    snippet1 = snippet(f)
    body = snippet1.get_body()
    fn_def = body[0]  # type: ast.FunctionDef
    arg = fn_def.args.args[0]  # type: ast.arg
    
    print(arg.arg)
    print(body)