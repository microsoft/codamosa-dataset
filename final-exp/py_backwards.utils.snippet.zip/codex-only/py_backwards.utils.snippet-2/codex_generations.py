

# Generated at 2022-06-23 23:42:57.224154
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    # given
    class Foo:
        def foo(self, x, y=1):
            return x+y
    foo = Foo()

    import ast
    import inspect
    import textwrap

    body = inspect.getsource(Foo.foo).strip()
    code = textwrap.dedent(f'''
    class Foo:
        def foo(self, x, y=1):
            {body}
    ''')
    tree = ast.parse(code)
    attr = next(find(tree, ast.Attribute))

    variables = {'self': self,
                 body: str(self)}

    # when
    VariablesReplacer.replace(attr, variables)

    # then
    assert isinstance(attr, ast.Attribute)
    assert isinstance(attr.value, ast.Call)

# Generated at 2022-06-23 23:43:03.724049
# Unit test for constructor of class snippet
def test_snippet():
    import sys
    import os

    sys.path.append(os.path.abspath('./examples/sample1.py'))
    import sample1
    s = snippet(sample1.foo1)
    assert s.get_body()[0].value.left.id == "_py_backwards_x_0"
    assert s.get_body()[1].value.left.id == "_py_backwards_x_0"
    assert s.get_body()[2].value.left.id == "_py_backwards_y_0"



# Generated at 2022-06-23 23:43:09.722084
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('def foo():pass')

    replacer = VariablesReplacer({})
    replacer.visit(tree)
    assert get_source(tree) == 'def foo():pass'

    replacer = VariablesReplacer({'foo': 'bar'})
    replacer.visit(tree)
    assert get_source(tree) == 'def bar():pass'



# Generated at 2022-06-23 23:43:20.722485
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    import astor

    # Given
    class Tree:
        def __init__(self, stmt: List[ast.AST]):
            self.body = stmt

    def func(a=1, b=2):
        pass

    tree = Tree(ast.parse(func.__code__.co_code.decode("utf-8")).body)
    variables = {'a': '_py_backwards_x_0', 'b': '_py_backwards_x_1'}

    # When
    VariablesReplacer.replace(tree, variables)

    # Then
    assert astor.to_source(tree) == """def _py_backwards_x_2(_py_backwards_x_0=1, _py_backwards_x_1=2):
    pass"""

# Generated at 2022-06-23 23:43:31.308773
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""def test_function(p1):
                            try:
                                x=1
                            except Exception as exc1:
                                print("Exception")
                            except Exception as exc2:
                                print("Exception")
                            except Exception as exc3:
                                print("Exception")
                            return x""")
    variables = {'exc1': 1,
                 'exc2': 2,
                 'exc3': 3}
    result = VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:43:42.521533
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    x = ast.Name(id='x')

    a = ast.Call(func=ast.Name(id='let'),
                 args=[ast.Name(id='x'), x],
                 keywords=[],
                 starargs=None,
                 kwargs=None)

    b = ast.Call(func=ast.Name(id='let'),
                 args=[ast.Name(id='y'), x],
                 keywords=[],
                 starargs=None,
                 kwargs=None)

    c = ast.Call(func=ast.Name(id='let'),
                 args=[ast.Name(id='z'), a],
                 keywords=[],
                 starargs=None,
                 kwargs=None)

    tree = ast.Module(body=[a, b, c])

# Generated at 2022-06-23 23:43:51.799625
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree1 = ast.parse("foo()")
    tree2 = ast.parse("foo()")
    tree3 = ast.parse("foo()")

    # 1.0 Replace all names
    variables = {"foo": "bar"}
    replacer1 = VariablesReplacer(variables)

    replacer1.visit(tree1)
    assert(tree1.body[0].value.func.id == "bar")

    # 1.1 Replace name if matches type
    replacer2 = VariablesReplacer(variables)
    replacer2.visit(tree2)
    assert(tree2.body[0].value.func.id == "bar")

    # 1.2 Replace name if specified explicitly
    variables = {"foo": "bar"}
    replacer3 = VariablesReplacer(variables)

    replacer3.vis

# Generated at 2022-06-23 23:44:02.435991
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse('''def foo():\n    try:\n        x = 5\n    except Exception as x:\n        try:\n            x = 5\n        except Exception as y:\n            y = 5\n    try:\n        x = 5\n    except Exception as x:\n        try:\n            x = 5\n        except Exception as y:\n            y = 5''')

    variables = find_variables(tree)
    assert variables == {'x': '_py_backwards_x_0', 'y': '_py_backwards_y_0'}

    tree = VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:44:10.066563
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    import unittest
    from .tree import print_ast

    class testClass(unittest.TestCase):
        def setUp(self):
            self.v = VariablesReplacer({'a': 'A', 'b': 'B'})

        def test_Name(self):
            node = ast.Name(id='a')
            a = self.v.visit(node)
            self.assertEqual(a.id, 'A')
            node = ast.Name(id='d')
            self.assertRaises(AttributeError, self.v.visit, node)

        def test_FunctionDef(self):
            node = ast.FunctionDef(name='a', args=ast.arguments(),
                                   body=[], decorator_list=[], lineno=0, col_offset=0)

# Generated at 2022-06-23 23:44:15.230392
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    tree = snippet(snippet_fn).get_body()
    assert type(tree[0]) == ast.Assign
    assert tree[0].targets[0].id == '_py_backwards_x_0'
    assert type(tree[0].value) == ast.AugAssign
    assert tree[0].value.op.__class__.__name__ == 'Add'
    assert tree[0].value.target.id == '_py_backwards_x_0'
    assert tree[0].value.value.n == 1
    assert type(tree[1]) == ast.Assign
    assert tree[1].targets[0].id == 'y'

# Generated at 2022-06-23 23:44:16.473675
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    ...


# Generated at 2022-06-23 23:44:23.480894
# Unit test for function extend
def test_extend():
    def my_fn():
        x = 1
        y = 2
        extend(vars)
        print(x, y)

    vars = [
        ast.Assign(targets=[ast.Name(id="x")],
                   value=ast.Num(n=2))
    ]

    print("------- x = 1")
    print("------- x = 2")
    print("------- print(x, y)")

    snippet(my_fn).get_body(vars=vars)

# Generated at 2022-06-23 23:44:33.489062
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    x = 'x'
    y = 'y'
    def let_x():
        let(x)
    def let_y():
        let(y)
    def let_x_y():
        let(x)
        let(y)

# Generated at 2022-06-23 23:44:37.125495
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    a = ast.parse('import a')
    tree = a.body[0]  # type: ignore
    variables = {'a': 'b'}
    vr = VariablesReplacer(variables)
    vr.visit(tree)
    assert tree.module == "b"



# Generated at 2022-06-23 23:44:44.927450
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .utils import assert_ast_equal

    def code():
        let(x)
        x += 1
        y = 1

    def code_equivalent():
        _py_backwards_x_0 += 1
        y = 1

    snippet1 = snippet(code)
    snippet2 = snippet(code_equivalent)

    assert_ast_equal(snippet1.get_body(), snippet1.get_body())
    assert_ast_equal(snippet2.get_body(), snippet2.get_body())

# Generated at 2022-06-23 23:44:51.143953
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class_obj = ast.ClassDef(name='Class', bases=[], keywords=[ast.keyword(arg='self', value=ast.Name(id='other'))])
    result = VariablesReplacer.replace(class_obj, {'self': 'object'})

    a = ast.keyword(arg='object', value=ast.Name(id='other'))
    b = ast.ClassDef(name='Class', bases=[], keywords=[a])
    assert result == b
# End unit test

# Generated at 2022-06-23 23:44:56.037593
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.ImportFrom(module = 'math', names=[ast.alias(name = 'sin', asname = 'sin')], level=0)
    tree = ast.parse("print(1)")
    tree.body.insert(0, import_from)

    variables = {'sin': '_sin'}
    replacer = VariablesReplacer.replace(tree, variables)

    for import_from in find(tree, ast.ImportFrom):
        assert import_from.module == '_math'



# Generated at 2022-06-23 23:45:06.635811
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    import ast as ast
    import astor as astor
    class a:
        pass
    b = a()
    b.id = 'b'
    c = a()
    c.id = 'c'
    d = a()
    d.id = 'd'
    e = a()
    e.id = 'e'
    f = a()
    f.id = 'f'
    g = a()
    g.id = 'g'
    h = a()
    h.id = 'h'
    i = a()
    i.id = 'i'
    j = a()
    j.id = 'j'
    k = a()
    k.id = 'k'
    l = a()
    l.id = 'l'
    m = a()

# Generated at 2022-06-23 23:45:07.214989
# Unit test for constructor of class snippet
def test_snippet():
    pass


# Generated at 2022-06-23 23:45:11.061570
# Unit test for function extend
def test_extend():
    actual = snippet(lambda: extend(ast.parse("x = 1; x = 2").body))
    expected = ast.parse("x = 1; x = 2").body
    assert actual.get_body() == expected


# Generated at 2022-06-23 23:45:13.154290
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)")
    assert find_variables(tree) == ["x"]



# Generated at 2022-06-23 23:45:13.915828
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer({'a': '1', 'b': '2', 'c': '3'})

# Generated at 2022-06-23 23:45:14.666506
# Unit test for function extend_tree
def test_extend_tree():
    pass



# Generated at 2022-06-23 23:45:16.601203
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    """Test if visit_ExceptHandler works with no errors"""
    module = ast.Module([ast.ExceptHandler(None, "error", [], None)])
    VariablesReplacer.replace(module, {})


# Generated at 2022-06-23 23:45:18.107935
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    def fn():
        pass


# Generated at 2022-06-23 23:45:20.913323
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("a = 2\nlet(b)\nlet(c)")
    assert list(find_variables(tree)) == ['b', 'c']

# Generated at 2022-06-23 23:45:26.824099
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    from .helpers import VariablesGenerator
    from .tree import find
    from .snippet import let, extend
    from .transforms import NamedFunction
    from .incomplete import Incomplete

    variables = {
        'x': '_py_backwards_x_0',
        'y': '_py_backwards_y_0',
        '_py_backwards_func_0': NamedFunction('_py_backwards_func_0', ['t', 'z'], []),
        '_py_backwards_res_0': Incomplete('_py_backwards_res_0', ('_py_backwards_res_0', 's'), {}),
        '_py_backwards_x_0': 1,
        '_py_backwards_y_0': 2
    }
    tree = ast.parse

# Generated at 2022-06-23 23:45:30.725688
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def fn(x):
        let(y)
        y = 'a'
        let(z)
        return x + y + z
    snippet_obj = snippet(fn)
    ast_body: List[ast.AST] = snippet_obj.get_body()
    assert ast_body[0].value.id == '_py_backwards_y_0'

# Generated at 2022-06-23 23:45:31.396936
# Unit test for constructor of class snippet
def test_snippet():
    snippet(None)

# Generated at 2022-06-23 23:45:32.782139
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda : None)

# Generated at 2022-06-23 23:45:44.097266
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    node = ast.parse('from A import x').body[0]
    variables = {'A': 'B'}
    VariablesReplacer.replace(node, variables)
    assert to_source(node) == 'from B import x'

    node = ast.parse('from A import x as y').body[0]
    variables = {'A': 'B', 'y': 'z'}
    VariablesReplacer.replace(node, variables)
    assert to_source(node) == 'from B import x as z'

    node = ast.parse('from A import x, y as z').body[0]
    variables = {'A': 'B', 'z': 'w'}
    VariablesReplacer.replace(node, variables)
    assert to_source(node) == 'from B import x, y as w'

   

# Generated at 2022-06-23 23:45:53.857430
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    print('test_VariablesReplacer_visit_arg:')
    def f(a1, a2, a3):
        let(a1)
        let(a2)
        let(a3)
        a1 = 1
        a2 = 2
        a3 = 3
        return a1 + a2 + a3
    tree = ast.parse(get_source(f))
    VariablesReplacer.replace(tree, {'a1': 3, 'a2': 2, 'a3': 1})

# Generated at 2022-06-23 23:46:05.045360
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import astpretty
    program = ast.parse("def foo():\n    bar(x=1)")
    VariablesReplacer.replace(program, {'x': ast.Name("y", ast.Store())})

# Generated at 2022-06-23 23:46:08.836093
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    @snippet
    def my_snippet(foo):
        pass

    body = my_snippet.get_body(foo=ast.Name(id='bar'))
    assert isinstance(body[0], ast.Pass)



# Generated at 2022-06-23 23:46:11.862262
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = "from pkg import mod"
    tree = ast.parse(source)
    variables = {'pkg': 'root'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == \
        "from root import mod"

# Generated at 2022-06-23 23:46:14.530682
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    t = ast.parse('a = 1')
    t = VariablesReplacer.replace(t, {"a": "B"})
    assert t.body[0].targets[0].id == "B"

# Generated at 2022-06-23 23:46:15.078530
# Unit test for constructor of class snippet
def test_snippet():
    snippet()

# Generated at 2022-06-23 23:46:25.298356
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('''
    from let import let, extend
    let(y)
    let(x)
    extend(a)
    def f():
        let(d)
        let(b)
        let(c)
        extend(z)
        if (x):
            print(1)
    f()
    if (y):
        print(2)
    ''', mode='exec')

# Generated at 2022-06-23 23:46:34.769577
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # fake func for testing
    def fake_func():
        from foo.bar.baz.fup import foo, bar, fup
        from foo.bar.baz.fup import foo as bar
        from foo.bar import baz, bar
        from foo.bar import baz as bar

# Generated at 2022-06-23 23:46:39.457782
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = "def foo(a=1): pass"
    tree = ast.parse(source)
    variables = {'a': 2}
    VariablesReplacer.replace(tree, variables)
    func = tree.body[0]
    assert func.args.defaults[0].n == 2


# Generated at 2022-06-23 23:46:42.361461
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class Test:
        def f(self):
            self.x = lambda: None
            self.y = lambda: None
    test_obj = Test()
    test_obj.x()
    test_obj.y()

# Generated at 2022-06-23 23:46:53.211736
# Unit test for function let
def test_let():
    # Here we declare two variables using let function
    @snippet
    def snippet1():
        let(x)
        let(y)
        # Here we use the variables
        x = 1
        y = 2
        z = 3
        # Here we call the variables again
        w = x
        w = y
        w = z

    # Here we declare three variables using let function
    @snippet
    def snippet2():
        let(x)
        let(y)
        let(z)
        # Here we use the variables
        x = 1
        y = 2
        z = 3

    # Here we use the variables that we declared above
    @snippet
    def snippet3():
        let(w)
        w = x
        w = y
        w = z


# Generated at 2022-06-23 23:47:00.170625
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import sys
    import typed_ast.ast3
    assert hasattr(VariablesReplacer, "visit_ImportFrom")
    tree = ast.parse(get_source(sys.modules[__name__].__init__))
    tree = VariablesReplacer.replace(tree, {"sys": "Imp", "typed_ast.ast3": "mod"})
    import_from = find(tree, ast.ImportFrom).next()
    assert import_from.module == "Imp"
    for alias in import_from.names:
        if alias.name == "typed_ast.ast3":
            assert alias.name == "mod"

# Generated at 2022-06-23 23:47:03.460967
# Unit test for function let
def test_let():
    @snippet
    def my_snippet(x: int, y: int):
        let(x)
        x += 1
        y = 1
        return x + y

    assert my_snippet.get_body(x=1, y=2) == my_snippet.get_body(x=2, y=2)



# Generated at 2022-06-23 23:47:04.825025
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: None) is not None

# Generated at 2022-06-23 23:47:05.990264
# Unit test for function extend_tree

# Generated at 2022-06-23 23:47:15.221204
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet = ast.parse(
        """
        __let__0 = 10
        __let__1 = 20
        __let__2 = 30
        (__let__0, __let__1, __let__2)
    """)
    snippet.body[0].value.id = 'let'
    snippet.body[0].value.lineno = 1
    snippet.body[1].value.id = 'let'
    snippet.body[1].value.lineno = 2
    snippet.body[2].value.id = 'let'
    snippet.body[2].value.lineno = 3
    # snippet.body.append(ast.Assign(targets=[ast.Name(id='extend', ctx=ast.Load())],
    #                                value=ast.Name(id='values', ctx=ast.Load

# Generated at 2022-06-23 23:47:22.727074
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import astor  # type: ignore
    import os

    with open(os.path.join(os.path.dirname(__file__), "..", "__init__.py")) as f:
        source = f.read()

    tree = ast.parse(source, "__init__.py")
    test_tree = tree

    extend_tree(tree, {"_py_backwards_a_0": "ast"})


# Generated at 2022-06-23 23:47:28.858232
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source = 'x = 1'
    tree = ast.parse(source)
    variables = {'x': '_py_backwards_x_0'}
    VariablesReplacer.replace(tree, variables)
    result = ast.dump(tree)
    assert result == "Module(body=[Assign(targets=[Name(_py_backwards_x_0, Store())], value=Constant(1, None))])"

# Generated at 2022-06-23 23:47:34.776410
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    test_import_from = ast.parse("from module1 import x, y as y1\n")
    # "from module1 import x as x1, y1 as y1\n"
    result_import_from = VariablesReplacer.replace(test_import_from, {'x': 'x1', 'y1': 'y1'})
    assert ast.dump(result_import_from) == "Module(body=[ImportFrom(module='module1', names=[alias(name='x', asname='x1'), alias(name='y1', asname='y1')], level=0)])"

# Generated at 2022-06-23 23:47:41.401434
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    # arrange
    source = "class A:pass"
    tree = ast.parse(source)
    variables = {"A" : "Haha"}
    class_def = find(tree, ast.ClassDef)[0]
    name = class_def.name

    # assert
    assert name == "A"

    # act
    VariablesReplacer.replace(tree, variables)

    # assert
    assert name == "Haha"



# Generated at 2022-06-23 23:47:45.937370
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('x = a.b')
    assert get_source(tree) == 'x = a.b'
    vars = {'a': 'c'}
    VariablesReplacer.replace(tree, vars)
    assert get_source(tree) == 'x = c.b'



# Generated at 2022-06-23 23:47:52.246584
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    # code to be evaluated
    func_code = 'def foo(): pass'

    # parse the code
    ast_tree = ast.parse(func_code)

    # create an instance of VariablesReplacer
    inst = VariablesReplacer({'foo': 'bar'})

    # evaluate the visit_FunctionDef method of the instance
    new_ast = inst.visit_FunctionDef(ast_tree.body[0])

    # assert the expected results
    assert new_ast.name == 'bar'


# Generated at 2022-06-23 23:48:03.813679
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def test():
        let(x)
        x += 1
        print(x)
        let(y)
        y = 1
        print(y)
        let(z)
        z = let(z_1)
        print(z)
        extend(ext)
        print(x_1, y_1)

    def check(x: int, y: int, z: int, x_1: str, y_1: int):
        assert x == 1 and y == 1 and z == 1
        assert x_1 == '2' and y_1 == 3


# Generated at 2022-06-23 23:48:12.240181
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import lang.ast as ast
    import lang.helpers as helpers
    import lang.rewriters.helpers as helpers_rewriters
    import lang.snippet as snippet
    import lang.tree as tree
    import lang.variables_generator as variables_generator

    tree2 = ast.Module(
        body=[
            ast.ImportFrom(
                module='import_from',
                names=[
                    ast.alias(
                        name='import_from_alias',
                        asname='import_from_alias_asname')],
                level=1)])

    variables = {
        'import_from': 'import_from_var',
        'import_from_alias': 'import_from_alias_var',
        'import_from_alias_asname': 'import_from_alias_asname_var'}



# Generated at 2022-06-23 23:48:23.147467
# Unit test for function extend
def test_extend():
    x = 1
    y = 2

    @snippet
    def test():
        extend(vars())
        print(x, y)


# Generated at 2022-06-23 23:48:24.227406
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert isinstance(VariablesReplacer({}), ast.NodeTransformer)



# Generated at 2022-06-23 23:48:24.908663
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:48:28.091789
# Unit test for constructor of class snippet
def test_snippet():
    def sample_fn():
        let(1)

    snippet_fn = snippet(sample_fn)
    assert isinstance(snippet_fn, snippet)


# Generated at 2022-06-23 23:48:29.287096
# Unit test for method visit_Name of class VariablesReplacer

# Generated at 2022-06-23 23:48:31.462152
# Unit test for constructor of class snippet
def test_snippet():
    snip = snippet(lambda x: print(x))


# Generated at 2022-06-23 23:48:37.999217
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def f():
        let(x)
        x += 1
        let(y)
    assert f.get_body() == [
        ast.AugAssign(
            ast.Name('_py_backwards_x_0', ast.Store()),
            ast.Add(),
            ast.Num(1)
        ),
        ast.Assign(
            [ast.Name('_py_backwards_y_1', ast.Store())],
            ast.Num(1)
        )
    ]

# Generated at 2022-06-23 23:48:47.495496
# Unit test for function extend
def test_extend():
    def test(extend):
        extend(vars)
    vars = [
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2))
    ]
    assert snippet(test).get_body(extend=extend) == [
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2)),
    ]



# Generated at 2022-06-23 23:48:56.840680
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    _arg = ast.arg(arg='arg', annotation=None)
    _tree = ast.Module(body=[ast.ImportFrom(module='module', names=[_arg], level=1)])
    _variables = {'arg': 'new_arg'}
    _instance = VariablesReplacer(_variables)

    with pytest.raises(AttributeError) as excinfo:
         _variables['arg'] = 1
         _instance.generic_visit(_tree)
    assert str(excinfo.value) == '\'int\' object has no attribute \'arg\''

    _instance.visit_arg(_arg)
    assert _arg.arg == 'new_arg'
    #assert _arg.annotation == None
    assert _arg.annotation == None



# Generated at 2022-06-23 23:48:58.025395
# Unit test for constructor of class snippet
def test_snippet():
    assert type(snippet(lambda: 1)) is snippet



# Generated at 2022-06-23 23:49:02.037220
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    class ImportFrom(ast.ImportFrom):
        _fields = ("module", "names", "level")
    class alias(ast.alias):
        _fields = ("name", "asname")
    def f(x):
        from . import x as y
        return y
    variables = {'x': 'y'}
    node = ImportFrom(module='.', names=[alias(name='x', asname='y')], level=None)
    VariablesReplacer.replace(node, variables)
    assert(node.module == 'y')

# Generated at 2022-06-23 23:49:09.868107
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class Snippet:
        @snippet
        def test(self):
            let(x)
            let(y)
            for i in x + y:
                let(z)
            return x + y

    assert Snippet().test.get_body()[0].__class__ == ast.For
    assert Snippet().test.get_body()[0].iter.__class__ == ast.BinOp



# Generated at 2022-06-23 23:49:12.913632
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("""
    def fct(a, c):
        a = 9
        x = a
        return x
    """)
    tree = VariablesReplacer.replace(tree, {'a': 9, 'c': 1})



# Generated at 2022-06-23 23:49:18.967281
# Unit test for function extend
def test_extend():
    class assignment:
        def __init__(self, left: str, right: str):
            self.left = left
            self.right = right

    def get_assignment(name: str) -> assignment:
        return assignment(name, name + ' = 2')

    def const_extend(vars):
        extend(vars)
        print(x)

    tree = ast.parse(get_source(const_extend))
    extend_tree(tree, {'vars': [get_assignment('x')]})

# Generated at 2022-06-23 23:49:25.912748
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = ast.Name('x')
    snippet_body = snippet(test_snippet_get_body).get_body(x=x)
    assert snippet_body == [
        ast.Assign(
            [ast.Name('x')],  # type: ignore
            ast.Name('y')),
        ast.Expr(
            ast.Call(
                ast.Name('print'),
                [ast.Name('x'), ast.Name('y')],
                []
            )
        )
    ]


# Generated at 2022-06-23 23:49:35.561945
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    node = ast.list([
        ast.Call(
            ast.Name('let', ast.Load()),
            [ast.parse('a').body[0]],
            []
        ),
        ast.If(
            ast.Name('a', ast.Load()),
            [ast.Assign(
                [ast.Name('b', ast.Store())],
                ast.Subscript(
                    ast.Name('a', ast.Load()),
                    ast.Index(ast.Name('a', ast.Load())),
                    ast.Load()
                )
            )],
            []
        )
    ])

    vars = {'a': 7}

    VariablesReplacer.replace(node, vars)

    assert len(node.elts) == 1

# Generated at 2022-06-23 23:49:42.214715
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    kw = ast.keyword()
    kw.arg = "a"
    kw.value = ast.Str("a_val")

    newkw = ast.keyword()
    newkw.arg = "b"
    newkw.value = ast.Str("b_val")

    replacer = VariablesReplacer({"a": newkw})

    newkw_from_kw = replacer.visit_keyword(kw)

    assert newkw_from_kw.arg == "b"
    assert newkw_from_kw.value.s == "b_val"

# Generated at 2022-06-23 23:49:51.046568
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
    import some
    
    extend(some.something)
    
    x = 5
    
    if x:
        print(x)
    ''')
    extend_tree(tree, {
        'some': ['', 'var1 = 5', 'var2 = 6'],
    })
    assert get_source(tree) == '''
    import some
    
    var1 = 5
    var2 = 6
    
    x = 5
    
    if x:
        print(x)
    '''



# Generated at 2022-06-23 23:49:56.732333
# Unit test for function find_variables
def test_find_variables():
    source = dedent('''
        let(x)
        x = x + 1
        let(y)
        y = x
        let(z)
    ''').strip()
    tree = ast.parse(source)
    assert {name for name in find_variables(tree)} == {'x', 'y', 'z'}


# Unit tests for class VariablesReplacer

# Generated at 2022-06-23 23:50:07.566366
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    extend(vars)
    print(x, y)
    """
    tree = ast.parse(source)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-23 23:50:17.537742
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class ASTVisitor(ast.NodeVisitor):
        def generic_visit(self, node):
            if isinstance(node, ast.AST):
                n = self.visit(node)
            elif isinstance(node, list):
                n = self.visit_list(node)
            elif isinstance(node, tuple):
                n = self.visit_tuple(node)
            else:
                raise ValueError(
                    'Unsupported type: %r' % type(node).__name__)
            return self.replace_node(node, n) if n is not None else None
        # ...

        def visit_Attribute(self, node: ast.Attribute) -> ast.Attribute:
            node = self.visit(node)
            node.attr = 'foo'
            return node



# Generated at 2022-06-23 23:50:25.588734
# Unit test for function extend
def test_extend():
    from ast_tools import snippet, extend

    assert(snippet(lambda:
        extend({
            'x': 1,
            'y': 2
        })
    ).get_body() == [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=2))
    ])



# Generated at 2022-06-23 23:50:28.702431
# Unit test for function extend
def test_extend():
    def extend_many(variables: List[ast.Assign]) -> None:
        extend(variables)

    tree = ast.parse('extend(vars)')
    extend_many(tree.body[0])



# Generated at 2022-06-23 23:50:31.885818
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(a)
    let(b)
    let(c)
    """
    tree = ast.parse(source)
    assert find_variables(tree) == ['a', 'b', 'c']



# Generated at 2022-06-23 23:50:39.004406
# Unit test for function extend
def test_extend():
    from .tree import get_source

    @snippet
    def simple():
        extend(vars)
        print(x, y)

    vars = [ast.parse('x = 1'), ast.parse('x = 2')]
    body = simple.get_body(vars=vars)
    assert get_source(body) == 'x = 1\nx = 2\nprint(x, y)'



# Generated at 2022-06-23 23:50:43.379264
# Unit test for function extend
def test_extend():
    def test_fn(x: int, y: int):
        extend(vars)
        print(x, y)

    tree = ast.parse(
        """
x = 1
y = 2
print(x, y)
""")

    body = snippet(test_fn).get_body(vars=tree)
    source = ast.unparse(ast.Module(body))
    expected = """
x = 1
y = 2
print(x, y)
"""
    assert source.strip() == expected.strip()



# Generated at 2022-06-23 23:50:44.727958
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    variables = {'x': 'a', 'y': 'b'}

# Generated at 2022-06-23 23:50:52.430811
# Unit test for function let
def test_let():
    @snippet
    def test():
        let(x)
        x += 5
        print(x)

    assert test.get_body() == [
        ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   ast.BinOp(op=ast.Add(),
                             left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                             right=ast.Num(n=5))),
        ast.Expr(ast.Call(
            ast.Name(id='print', ctx=ast.Load()),
            [ast.Name(id='_py_backwards_x_0', ctx=ast.Load())],
            []))
    ]



# Generated at 2022-06-23 23:50:58.352990
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    var = 'x'
    value = 'y'
    variables = {var: value}
    ast_NodeTransformer = VariablesReplacer(variables)
    ast_Attribute = ast.Attribute(ast.Name('a', ast.Load()), var, ast.Load())
    ast_Name = ast_NodeTransformer.visit_Attribute(ast_Attribute)
    assert str(ast_Name) == 'a.y'


# Generated at 2022-06-23 23:51:04.727695
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import_statement = ast.parse('import sys')
    assign_statement = ast.parse('a = 10')
    echo_statement = ast.parse('print(a)')
    expr_statement = ast.parse('a += 1')

    @snippet
    def func():
        let(a)
        let(sys)

        extend(import_statement)
        extend(assign_statement)
        extend(expr_statement)

        print(a)

    statements = func.get_body()
    assert statements[1] == import_statement.body[0], 'sys not imported'
    assert statements[2] == assign_statement.body[0], 'a = 10 not set'
    assert statements[3] == expr_statement.body[0], 'a += 1 not set'
    assert statements[4] == echo_statement.body

# Generated at 2022-06-23 23:51:05.173901
# Unit test for function extend_tree
def test_extend_tree():
    assert tree == etree

# Generated at 2022-06-23 23:51:14.342203
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    result = snippet(lambda: let(x)).get_body(x=1)
    assert len(result) == 1
    assert isinstance(result[0], ast.Assign)
    result = snippet(lambda: let(x)).get_body(x=ast.Name(id='a', ctx=ast.Load()))  # type: ignore
    assert len(result) == 1
    assert isinstance(result[0], ast.Assign)
    assert result[0].targets[0].id == 'a'

    result = snippet(lambda: let(x) and let(y)).get_body(x=1, y=2)
    assert len(result) == 2
    assert isinstance(result[0], ast.Assign)
    assert isinstance(result[1], ast.Assign)

# Generated at 2022-06-23 23:51:16.718859
# Unit test for function let
def test_let():
    @snippet
    def fn():
        a = let(1)
    
    assert fn.get_body() == ast.parse('a = _py_backwards_var_0').body



# Generated at 2022-06-23 23:51:23.337169
# Unit test for function find_variables
def test_find_variables():
    source = '\n'.join([
        'let(x)',
        'y = 1',
        'let(z)',
        'z = y + 1',
        'print(x + z)',
    ])
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == ['x', 'z']



# Generated at 2022-06-23 23:51:30.589724
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    x_id = "x_id"
    node = ast.Name(id=x_id)
    variables = {"x_id":"y_id"}
    replacer = VariablesReplacer(variables)
    result = replacer.visit_Name(node)
    expected_result = ast.Name(id="y_id")
    assert result == expected_result


# Generated at 2022-06-23 23:51:36.056801
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    assert isinstance(VariablesReplacer.replace(
        ast.parse('class a: pass', mode='exec').body[0], {'a': 'b'}), ast.ClassDef)


# Generated at 2022-06-23 23:51:41.497185
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse("def fn(): pass")
    assert len(tree.body) == 1
    fn = tree.body[0]
    assert type(fn) == ast.FunctionDef
    assert fn.name == 'fn'
    replacer = VariablesReplacer({
        'fn': 'asd'
    })
    replacer.visit_FunctionDef(fn)
    assert fn.name == 'asd'


# Generated at 2022-06-23 23:51:49.187431
# Unit test for function let
def test_let():
    def foo():
        let(x)
        x += 1
        y = 1
        return y

    snippet_obj = snippet(foo)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)),
        ),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=1)),
    ]


# Generated at 2022-06-23 23:51:56.380950
# Unit test for function let
def test_let():
    import ast
    import textwrap
    #import astor
    def test1():
        let(x)
        x += 1
        y = 1
        return ast.parse(textwrap.dedent(inspect.getsource(test1)))

    # pylint: disable=unused-variable
    #astor.to_source(test1())

    snippet(test1).get_body(x=ast.Name(id='_x', ctx=ast.Load()))
    # _py_backwards_x_0 = _x
    # _py_backwards_x_0 += 1
    # y = 1
    pass

# Generated at 2022-06-23 23:51:57.862981
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(let)
    assert snippet(extend)



# Generated at 2022-06-23 23:52:01.760288
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    code = """
    def test(a, b=1):
        pass
    """
    tree = ast.parse(code)
    variables = {'a': '__x', 'b': 1}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].keywords[0].arg == '__x'
    assert tree.body[0].keywords[1].arg == 'b'



# Generated at 2022-06-23 23:52:02.146202
# Unit test for function find_variables

# Generated at 2022-06-23 23:52:10.056988
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse(
        """def func(arg):
            pass"""
    )

    class Func(FunctionDef):
        def __init__(self, arg):
            super().__init__(
                name='func',
                args=arguments(
                    args=[arg],
                    vararg=None,
                    kwonlyargs=[],
                    kw_defaults=[],
                    kwarg=None,
                    defaults=[]
                ),
                body=[Pass()],
                decorator_list=[],
                returns=None
            )

    class Arg(arg):
        def __init__(self, arg_name):
            super().__init__(
                arg=arg_name,
                annotation=None
            )

    new_arg = Arg('new_arg')

# Generated at 2022-06-23 23:52:13.546606
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():  # noqa
    from .test_utils import assertNoErrors, parse
    from .utils import AssertAST

    tree = parse('''
        from a import b
        from .c import d
        from . import e
    ''')
    expected = parse('''
        from x import b
        from .c import d
        from . import e
    ''')

    test = AssertAST()
    test.assertEqual(VariablesReplacer.replace(tree, {'a': 'x'}), expected)
    assertNoErrors(test)

# Generated at 2022-06-23 23:52:25.548415
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    s = '''
    def fn(x):
        try:
            x + 1
        except ex1 as e1:
            x + 2
        except ex2 as e2:
            x + 3
        finally:
            return x + 4
    '''
    tree = ast.parse(s)
    variables = {}

    for name in find_variables(tree):
        variables[name] = VariablesGenerator.generate(name)

    v = VariablesReplacer.replace(tree, variables)
    e = """
    def _py_backwards_fn_1(x):
        try:
            x + 1
        except ex1 as e1:
            x + 2
        except ex2 as e2:
            x + 3
        finally:
            return x + 4
    """


# Generated at 2022-06-23 23:52:35.450945
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse(
        'a'
        'from test import a'
        'from test import b as c'
        'def d(e): pass'
        'class f: pass'
        'from test import g as h, i as j'
        'except a: print(a)'
        'try: raise a'
        'f.a'
        'a.a'
    )
    variables = {
        'a': 'l',
        'test': 'tests',
        'b': 'c',
        'd': 'fd',
        'f': 'f',
        'g': ['g'],
        'h': 'h',
        'i': ['i'],
        'j': 'j',
        'a': 'a'
    }

# Generated at 2022-06-23 23:52:45.475623
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    print('Checking that constructor of VariablesReplacer works correctly...')

    # test all cases
    source = '''
    class A:
        pass
    a = A()
    let(b)
    import sys
    import b
    from copy import copy as b
    a.b = b
    try:
        1
    except ValueError as b:
        pass
    def b():
        pass
    def a(b):
        pass
    def c(a, b, d):
        pass
    '''
    tree = ast.parse(source)

# Generated at 2022-06-23 23:52:51.305665
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    module = ast.parse(
        'class A: assert True')
    module2 = ast.parse(
        'class A: assert True')
    variables = {'True': 'True'}
    VariablesReplacer.replace(module, variables)
    assert ast.dump(module) == ast.dump(module2)

