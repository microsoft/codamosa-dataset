

# Generated at 2022-06-23 23:42:54.615457
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tests import test_tree_1 as tree
    tree = tree()
    snippet1 = snippet(lambda x, y: None)
    snippet2 = snippet(lambda x, y: None)
    variables = {
        "x": snippet1.get_body(y=1),
        "y": snippet2.get_body(y=2),
        "z": 'z'
    }
    assert(VariablesReplacer.replace(tree, variables)) == ast.parse("""if x:
    print(y)
else:
    print(z)
""")

# Generated at 2022-06-23 23:42:56.683159
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-23 23:43:04.459233
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars)\nx = 1\nprint(y)")
    vars = {"x": ast.Assign(
        targets=[ast.Name(id="x", ctx=ast.Store())],
        value=ast.Num(n=1)
    )}
    extend_tree(tree, vars)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Name(id='y', ctx=Load())], keywords=[]))])"



# Generated at 2022-06-23 23:43:05.438528
# Unit test for constructor of class snippet
def test_snippet():
    snippet('s')


# Generated at 2022-06-23 23:43:12.868160
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def inc(x: int) -> int:
        return x + 1

    def test_snippet(inc: Callable[[int], int]) -> int:
        let(x)
        x = 10
        return inc(x)

    snippet_ = snippet(test_snippet)
    test_snippet_ast = snippet_.get_body(inc=inc)

    expected = ast.parse('x = 10\nreturn inc(x)').body[:]
    assert test_snippet_ast == expected

# Generated at 2022-06-23 23:43:23.505709
# Unit test for function extend
def test_extend():
    tree = ast.parse('extend(vars)')
    vars = [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())], value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'b\', ctx=Store())], value=Num(n=2))])'



# Generated at 2022-06-23 23:43:25.368347
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse('let(x)')) == ['x']



# Generated at 2022-06-23 23:43:29.644199
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    variables = {'name': 'var'}
    ast_test = ast.Name(id="name", ctx=ast.Load())

    inst = VariablesReplacer(variables)
    inst.visit_Name(ast_test)

    assert(ast_test.id == "var")



# Generated at 2022-06-23 23:43:33.469206
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse('''
from x import y
''')
    variables = {'x': 'a'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'Module(body=[ImportFrom(module="a", names=[alias(name="y", asname=None)], level=0),])'



# Generated at 2022-06-23 23:43:44.736434
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class A(ast.AST):
        pass
    class B(ast.AST):
        pass
    class C(ast.AST):
        pass
    class D(ast.AST):
        pass
    class E(ast.AST):
        pass
    class F(ast.AST):
        pass
    class G(ast.AST):
        pass
    class H(ast.AST):
        pass
    class I(ast.AST):
        pass
    class J(ast.AST):
        pass
    class K(ast.AST):
        pass
    class L(ast.AST):
        pass

    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    f = F()
    
    node1 = G(name=a, value=b)
    node

# Generated at 2022-06-23 23:43:48.039928
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("import x as y")
    alias = tree.body[0].names[0]
    assert VariablesReplacer.replace(alias, {'x': 'z'}).name == 'z'


# Generated at 2022-06-23 23:43:50.819394
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    alias_ast = ast.parse("import pathlib as pth")
    assert VariablesReplacer.replace(alias_ast, {
        "pth": "pathlib"
    }).body[0].body[0].asname == "pathlib"

# Generated at 2022-06-23 23:43:51.357840
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet  # typing

# Generated at 2022-06-23 23:44:02.206074
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
extend(vars)
x = 5
'''

    tree = ast.parse(source)
    vars_ = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=5)
    )
    extend_tree(tree, {'vars': vars_})
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[1], ast.Assign)
    assert tree.body[0].targets[0].id == 'x'
    assert tree.body[1].targets[0].id == 'x'
    assert tree.body[0].value.n == 5

# Generated at 2022-06-23 23:44:05.261417
# Unit test for function find_variables
def test_find_variables():
    _ = ast.parse('''
let('x')
let(y)
''')  # type: ignore

    variables = find_variables(_)
    assert set(variables) == set(['x', 'y'])

# Generated at 2022-06-23 23:44:11.940904
# Unit test for function extend
def test_extend():
    @snippet
    def s():
        extend(vars)
        x = 1
        y = 1

    class Assign:
        def __init__(self, name: str, value: ast.AST):
            self._name = name
            self._value = value

        def __eq__(self, other):
            return (self._name == other._name) and (self._value == other._value)

    a1 = Assign('x', ast.Num(n=1))
    a2 = Assign('y', ast.Num(n=1))
    assert s.get_body(vars=[a1, a2]) == [a1, a2]



# Generated at 2022-06-23 23:44:23.434265
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
    extend(vars1)
    extend(vars2)
    extend(vars3)
    '''

    tree = ast.parse(source)
    vars1 = ast.parse('x = 1').body
    vars2 = ast.parse('x = 2').body
    vars3 = ast.parse('x = 3').body
    vars = {'vars1': vars1, 'vars2': vars2, 'vars3': vars3}
    extend_tree(tree, vars)

# Generated at 2022-06-23 23:44:32.157889
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = """
    def test(a: int, *, b: int) -> int:
        return a + b

    # Comment
    """

    tree = ast.parse(source)
    variables = {}

    body = snippet(test).get_body()

    args = [arg for arg in body[0].args.args if arg.arg != 'b']
    kwargs = [arg.arg for arg in body[0].args.args if arg.arg == 'b']

    VariablesReplacer.replace(body[1], variables)
    assert str(body[1].value) == '_py_backwards_a_0 + _py_backwards_b_0'



# Generated at 2022-06-23 23:44:42.031225
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    b = 2
    @snippet
    def my_snippet():
        let(a)
        let(b)
        a += 1
        b += 2


# Generated at 2022-06-23 23:44:42.676269
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    pass

# Generated at 2022-06-23 23:44:44.301141
# Unit test for constructor of class snippet
def test_snippet():
    s = snippet(lambda : 0)
    assert isinstance(s, snippet)

# Generated at 2022-06-23 23:44:53.831419
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    function = ast.FunctionDef(name='foo',
                               args=ast.arguments(args=[ast.arg(arg='x',
                                                               annotation=None)],
                                                  vararg=None,
                                                  kwonlyargs=[],
                                                  kw_defaults=[],
                                                  kwarg=None,
                                                  defaults=[]),
                               body=[ast.Return(value=ast.Name(id='x',
                                                              ctx=ast.Load()))],
                               decorator_list=[],
                               returns=None)
    variables = {'foo': VariablesGenerator.generate('foo')}
    f = VariablesReplacer.replace(function, variables)
    assert isinstance(f.name, str)
    assert f.name == variables['foo']

#

# Generated at 2022-06-23 23:44:59.338054
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    parent = ast.Module(
        body=[
            ast.ImportFrom(module='a', names=[
                ast.alias(name='x', asname='y')
            ], level=0)
        ]
    )
    variables = {
        'x': 'y'
    }
    result = VariablesReplacer.replace(parent, variables)
    assert result.body[0].names[0].name == 'y', 'Import should be replaced with variables'

# Generated at 2022-06-23 23:45:03.653781
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    ast_node = ast.Attribute()
    ast_node.name = 'name'
    variables = {'name': 'test'}
    replacer = VariablesReplacer(variables)
    assert replacer.visit_Attribute(ast_node).name == 'test'


# Generated at 2022-06-23 23:45:05.068174
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def snippet_base():
        ...

# Generated at 2022-06-23 23:45:12.849580
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    import inspect
    import os
    import uuid
    source = inspect.getsource(ast.FunctionDef)

    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, {'FunctionDef': str(uuid.uuid4())})

    with open(os.path.join(os.path.dirname(__file__), "ast3.py"), "w+") as ast3:
        ast3.write(source)
    with open(os.path.join(os.path.dirname(__file__), "ast4.py"), "w+") as ast4:
        ast4.write(ast.dump(tree))
    import pytest
    pytest.main(["-l", os.path.join(os.path.dirname(__file__), "test.py")])

# Generated at 2022-06-23 23:45:19.489067
# Unit test for function let
def test_let():
    source = '''
from py_backwards import let
let(x)
z = 2
let(y)
y = x + z
    '''
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, find_variables(tree))
    assert to_source(tree) == '''
from py_backwards import let
let(x)
z = 2
let(y)
y = x + z
    '''



# Generated at 2022-06-23 23:45:25.157446
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(snippet_fn)
    body = snippet_instance.get_body()

    assert len(body) == 2

    assert isinstance(body[0].value, ast.AugAssign)
    assert isinstance(body[0].value.target, ast.Name)
    assert body[0].value.target.id == '_py_backwards_x_0'
    assert isinstance(body[0].value.value, ast.Num)
    assert body[0].value.value.n == 1

    assert isinstance(body[1].value, ast.Num)
    assert body[1].value.n == 1



# Generated at 2022-06-23 23:45:29.387907
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = '''
        def f(**x):
            pass
    '''
    tree = ast.parse(source)
    visit_keyword = VariablesReplacer(dict()).visit_keyword
    assert isinstance(visit_keyword(tree.body[0].args.kwarg), ast.arg)

# Generated at 2022-06-23 23:45:30.377574
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-23 23:45:39.513135
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
  assert str(ast.ImportFrom('sys', [], 0)) == 'from sys import'
  assert str(ast.ImportFrom('sys', [], -1)) == 'from ...sys import'
  assert str(ast.ImportFrom('sys', [], 2)) == 'from sys import'
  assert str(ast.ImportFrom('sys.a', [], 0)) == 'from sys import a'
  assert str(ast.ImportFrom('sys.a', [], -1)) == 'from ...sys import a'
  assert str(ast.ImportFrom('sys.a', [], 2)) == 'from sys import a'

# Generated at 2022-06-23 23:45:45.190101
# Unit test for function find_variables
def test_find_variables():
    from .typing import T
    assert find_variables(ast.parse('''
    let(x)
    ''')) == ['x']
    assert find_variables(ast.parse('''
    let(x)
    let(y)
    ''')) == ['x', 'y']
    assert find_variables(ast.parse('''
    z = T[let(x)]
    ''')) == ['x']



# Generated at 2022-06-23 23:45:46.131433
# Unit test for constructor of class snippet
def test_snippet():
    ast.FunctionDef



# Generated at 2022-06-23 23:45:47.889458
# Unit test for constructor of class snippet
def test_snippet():
    program = snippet(lambda x: x + 1) # type: snippet
    assert program is not None

# Generated at 2022-06-23 23:45:56.088979
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import ast
    import typed_ast.ast3 as ast3
    import astunparse

    class Test(ast.NodeTransformer):
        def visit_Attribute(self, node):
            node.attr = 'test'
            return node
    #
    # class A:
    #     def test(self):
    #         pass
    #
    # x = A()
    # x.test()

    tree = ast3.parse('''
    class A:
        def test(self):
            pass

    x = A()
    x.test()
    ''')
    tree = Test().visit(tree)
    print(astunparse.unparse(tree))

# Generated at 2022-06-23 23:46:07.368415
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def f():  # type: ignore
        'This is our snippet of code'
        let(x)
        x += 1
        y = 1

    assert f.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1),
            ),
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1),
        ),
    ]


#

# Generated at 2022-06-23 23:46:12.119250
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    extend(vars)
    print(x)
    """
    tree = ast.parse(source)
    variables = {'vars': [ast.parse("a = 1").body[0], ast.parse("a = 2").body[0]]}
    extend_tree(tree, variables)
    result = ast.parse("a = 1\na = 2\nprint(x)").body
    assert tree.body == result

# Generated at 2022-06-23 23:46:22.410788
# Unit test for function extend
def test_extend():
    @snippet
    def f(s):
        let(x)
        extend(vars)
        x += 1
        y = x + 1
    s = {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                      value=ast.Num(1)),
             ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                      value=ast.Num(2))]}
    body = f.get_body(**s)

# Generated at 2022-06-23 23:46:23.167041
# Unit test for function find_variables

# Generated at 2022-06-23 23:46:24.104444
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    from astunparse import unparse
    replacer = VariablesReplacer({})

# Generated at 2022-06-23 23:46:27.802816
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    x = 1
    y += 1
    '''
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert ['x', 'y'] == sorted(variables)

# Generated at 2022-06-23 23:46:36.108526
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree: ast.AST = ast.parse('x.attr')
    variables: Dict[str, Variable] = {'x': 'X'}
    replacer: VariablesReplacer = VariablesReplacer(variables)
    replacer.visit_Attribute(tree.body[0].value)
    # this line fixes the error that is said to be fixed in the
    # typed-ast library by type: ignore.
    tree = replacer.generic_visit(tree)
    assert(ast.dump(tree.body[0].value) == 'Attribute(value=Name(id="X", ctx=Load()), attr="attr", ctx=Load())')

# Generated at 2022-06-23 23:46:41.971004
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg(): 
    code = '''
    def a(b):
        pass
    '''
    tree = ast.parse(code)
    variables = {'b': 'c'}
    assert get_source(tree.body[0]).strip() == code.strip()
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree.body[0]).strip() == 'def a(c): pass'.strip()

# Generated at 2022-06-23 23:46:46.034644
# Unit test for function let
def test_let():
    with open("./tests/test_let.py", "r") as f:
        content = f.read()
        tree = ast.parse(content)
        print(ast.dump(tree))
        assert(content == ast.dump(tree))


# Generated at 2022-06-23 23:46:56.691099
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        let(y)
        x += 1
        y += 1

    tree = snippet(snippet_fn).get_body()

# Generated at 2022-06-23 23:46:57.557272
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-23 23:47:02.052384
# Unit test for function extend
def test_extend():

    # @snippet
    def _():
        x = 1
        y = 2
        extend(vars)
        print(x, y)

    vars = ast.parse('x = 2; y = 5').body
    assert _.get_body(vars=vars) == ast.parse('''
        x = 1
        y = 2
        x = 2
        y = 5
        print(x, y)
    ''').body



# Generated at 2022-06-23 23:47:03.360265
# Unit test for method visit_Attribute of class VariablesReplacer

# Generated at 2022-06-23 23:47:11.892741
# Unit test for function extend
def test_extend():
    import astor
    def test():
        extend(vars)

    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(2))
    ]

    astor.to_source(snippet(test).get_body(vars=vars)) == (
    astor.to_source(ast.parse('x=1\nx=2')))



# Generated at 2022-06-23 23:47:16.429519
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    import inspect

    def foo():
        pass
    node = ast.parse(inspect.getsource(foo))
    node.body[0].name = 'name'
    variables = {'name': 'name_new'}
    tree = VariablesReplacer.replace(node, variables)
    assert tree.body[0].name == 'name_new'

# Generated at 2022-06-23 23:47:25.070572
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    def someFunc(someParam: bool = True):
        return False

    init = snippet(someFunc)
    init_kwargs = init.get_body(someParam=ast.Name(id='not x', ctx=ast.Load()))[0].keywords

    assert len(init_kwargs) == 1, 'no keywords found'
    assert init_kwargs[0].arg == 'someParam', 'kwarg arg not changed'
    assert isinstance(init_kwargs[0].value, ast.Name), 'kwarg value not changed'
    assert init_kwargs[0].value.id == 'not x', 'kwarg value changed'

# Generated at 2022-06-23 23:47:27.931065
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    import ast_utils.tree
    import ast_utils.helpers
    import ast_utils.snippets.variables

# Generated at 2022-06-23 23:47:32.813829
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse('''try:
    pass
except:
    pass''')
    replacer = VariablesReplacer({
        'a': ['x = 1', 'y = 2']  # type: ignore
    })
    replacer.visit(tree)
    assert get_source(tree) == '''try:
    x = 1
    y = 2
except:
    x = 1
    y = 2'''

# Generated at 2022-06-23 23:47:33.916981
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-23 23:47:34.846882
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: None)

# Generated at 2022-06-23 23:47:38.355763
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def f(): pass
    node = ast.parse(get_source(f)).body[0]
    assert VariablesReplacer._replace_field_or_node(node, 'name', {}) is node


# Generated at 2022-06-23 23:47:40.836578
# Unit test for constructor of class snippet
def test_snippet():
    @let
    def var():
        pass

    foo = snippet(lambda: var + 1)
    foo.get_body()



# Generated at 2022-06-23 23:47:44.970007
# Unit test for function find_variables
def test_find_variables():
    source = '''
    def fun():
        let(a)
        let(b)
    '''
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert set(variables) == set(['a', 'b'])



# Generated at 2022-06-23 23:47:48.253527
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    alias = ast.alias("name", None)
    replacer = VariablesReplacer({'name': 'replace'})
    replacer.visit(alias)
    assert alias.name == 'replace'


# Generated at 2022-06-23 23:47:51.378145
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("x = 4")
    replacer = VariablesReplacer.replace(
        tree, {"x": "hh"})
    assert replacer.body[0].value.id == "hh"



# Generated at 2022-06-23 23:47:57.024623
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class A(ast.FunctionDef):
        def __init__(self, arg1=None, arg2=None):
            self.arg1 = arg1
            self.arg2 = arg2
    
    a = A(arg1='a')
    a2 = VariablesReplacer.replace(a, {'a': 'b'})
    assert a2.arg1 == 'b'

# Generated at 2022-06-23 23:48:02.135109
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from a.b as c")
    variables = {'a': 'b'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'ImportFrom(module="b.b", names=[alias(name="c", asname=None)], level=0)'

# Generated at 2022-06-23 23:48:10.919789
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    import astor
    res: List[ast.ClassDef] = []
    classdef = ast.parse('''class A():
    pass
    ''').body[0]
    classdef.name = 'B'
    res.append(classdef)
    assert astor.to_source(res) == 'class B:\n    pass\n    '
    classdef = ast.parse('''class A():
    pass
    ''').body[0]
    classdef.name = 'B'
    res.append(classdef)
    assert astor.to_source(res) == 'class B:\n    pass\n    class B:\n    pass\n    '


# Generated at 2022-06-23 23:48:13.618870
# Unit test for constructor of class snippet
def test_snippet():
    def mysnippet():
        let(a)
        print(a)

    s = snippet(mysnippet)
    assert s._fn is mysnippet

# Generated at 2022-06-23 23:48:14.831347
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:48:20.429089
# Unit test for function extend
def test_extend():
    a = 1
    b = 2


    def snippet(vars):
        extend(vars)
        print(a, b)


    def expected():
        print(a, b)


    assert snippet.get_body(vars=[ast.parse("a = 1").body[0], ast.parse("a = 2").body[0]]) == expected.get_body()

# Generated at 2022-06-23 23:48:28.909313
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree_body = [
        ast.FunctionDef(
            name='some_function',
            args=ast.arguments(
                args=[ast.arg(arg='arg1', annotation=None),
                      ast.arg(arg='arg2', annotation=None)],
                vararg=None,
                kwarg=None,
                kwonlyargs=[],
                defaults=[],
                kw_defaults=[]),
            body=[
                ast.Expr(value=ast.Call(
                    func=ast.Name(id='print', ctx=ast.Load()),
                    args=[ast.Str(s='test print')],
                    keywords=[])),
                ast.Return(value=ast.Str(s='test'))],
            decorator_list=[])
    ]

# Generated at 2022-06-23 23:48:39.175036
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    prog = [
        'def foo(x):',
        '    try:',
        '       x',
        '    except Exception as foo:',
        '       x',
        '    except Exception as bar:',
        '       x',
        '    except Exception:',
        '       x',
        '    except:',
        '       x',
        '    except Exception as foo:',
        '       x',
        '    except Exception as bar:',
        '       x',
        '    except Exception:',
        '       x',
        '    except:',
        '       x'
    ]
    tree = ast.parse('\n'.join(prog))
    variables = {x: VariablesGenerator.generate(x) for x in ['foo', 'bar']}

# Generated at 2022-06-23 23:48:44.503875
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    x = 1
    y = 2
    '''
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-23 23:48:51.569975
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class TestClass:
        def __init__(self):
            pass
    
    instance = TestClass()
    instance_name = 'test_instance'
    setattr(instance, 'test_instance', TestClass())
    instance.test_instance.__dict__['test_name'] = 'test_value'
    instance.test_instance.test_name_2 = 'test_value_2'
    instance.test_instance.test_name_3 = 'test_value_3'


# Generated at 2022-06-23 23:48:55.764523
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import_ = ast.ImportFrom(module = 'module', names = [ast.alias(name = 'a')])
    module = 'module'
    variables = {'module': 'testmodule'}
    tree = VariablesReplacer.replace(import_, variables)
    assert tree.module == 'testmodule'

# Generated at 2022-06-23 23:48:59.671892
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class Dummy(ast.NodeTransformer):
        def __init__(self):
            self.count = 0
        def visit_FunctionDef(self, node):
            self.count += 1
    
    dummy = Dummy()
    tree = ast.parse("def fn(): pass")
    dummy.visit(tree)
    assert dummy.count == 1



# Generated at 2022-06-23 23:49:01.995894
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    node = ast.parse('def foo():\n    return').body[0]
    variables = {'foo': 'bar'}
    res = VariablesReplacer.replace(node, variables)
    assert res.name == 'bar'


# Generated at 2022-06-23 23:49:07.759601
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import parse, dump
    from .tree import get_name

    alias = parse('import a').body[0].names[0]
    alias = VariablesReplacer({'a': 'b'}).visit_alias(alias)
    assert get_name(alias) == 'b'



# Generated at 2022-06-23 23:49:13.410217
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    s = '''def a():
        let(x)
        x += 1
        y = 1'''
    tree = ast.parse(s)
    variables = dict(find_variables(tree))
    VariablesReplacer.replace(tree, variables)
    print(ast.dump(tree))
    assert ast.dump(tree).replace(' ', '').replace('\r', '').replace('\n', '')\
        == r'defa():_py_backwards_x_0+=1y=1'


# Generated at 2022-06-23 23:49:15.187555
# Unit test for constructor of class snippet
def test_snippet():
    name = '__py_backwards_x_0'
    function = 'def {}(): pass'.format(name)
    assert snippet(lambda: function)

# Generated at 2022-06-23 23:49:18.121091
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:49:22.989856
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    x = ast.Name(id='x', ctx=ast.Load())
    x_arg = ast.arg(arg='x', annotation=None)

    result = VariablesReplacer.replace(x_arg, {'x': 'y'})
    assert result.arg == 'y'

# Generated at 2022-06-23 23:49:30.667845
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    def try_except_func():
        try:
            pass
        except Exception:
            pass

    source = get_source(try_except_func)
    tree = ast.parse(source)
    variables = {}
    VariablesReplacer.replace(tree, variables)
    assert source == get_source(tree)

# Generated at 2022-06-23 23:49:38.633680
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: None).get_body() == []
    assert snippet(lambda x: None).get_body(x=1) == []
    assert snippet(lambda x: x).get_body(x=1) == [ast.Expr(ast.Num(n=1))]
    assert snippet(lambda x: x).get_body(x=ast.Num(n=1)) == [ast.Expr(ast.Num(n=1))]
    assert snippet(lambda x: x).get_body(y=1) == [ast.Expr(ast.Name(id='y'))]
    assert snippet(lambda x: x).get_body(y="fsdfsdf") == [ast.Expr(ast.Name(id='y'))]

# Generated at 2022-06-23 23:49:43.181993
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class TestNode():
        def __init__(self, attrib):
            self.attrib = attrib
    test = TestNode(True)
    replacer = VariablesReplacer({'True': 'False'})
    replacer.visit_Name(test)
    assert test.attrib == 'False'


# Generated at 2022-06-23 23:49:47.679848
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    fn = snippet(lambda x: print(x))
    tree = ast.parse(fn.get_body())
    fn_def = find(tree, ast.FunctionDef)
    assert(len(fn_def) > 0)


# Generated at 2022-06-23 23:49:56.179149
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-23 23:50:01.378878
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("from a.b.c import d")
    variables = {"c": "C"}
    VariablesReplacer.replace(tree, variables)
    assert [node.__class__.__name__ for node in tree.body] == ['ImportFrom']
    assert tree.body[0].module == "a.b.C"

# Generated at 2022-06-23 23:50:08.441894
# Unit test for function let
def test_let():
    @snippet
    def s():
        let(x)
        x
        x
        x += 1

    assert s.get_body() == [
        ast.Expr(ast.Name('_py_backwards_x_0')),
        ast.Expr(ast.Name('_py_backwards_x_0')),
        ast.Expr(ast.BinOp(  # type: ignore
            ast.Name('_py_backwards_x_0'),
            ast.Add(),
            ast.Num(1),
        )),
    ]


# Generated at 2022-06-23 23:50:16.793395
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: Union[float, int]=1, y: bool=True, z: str='some') -> None:
        let(x)
        x = x * 2
        x = x + 1
        z = z[:5]
        z += '1'
        extend(y)


# Generated at 2022-06-23 23:50:23.603987
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    root = ast.parse("""
    try:
        pass
    except:
        pass
    """)

    class Myclass(ast.NodeTransformer):
        def visit_ExceptHandler(self, node: ast.ExceptHandler) -> ast.ExceptHandler:
            node = self.generic_visit(node)  # type: ignore
            return node

    replaced_root = Myclass().visit(root)

    assert replaced_root == root

# Generated at 2022-06-23 23:50:31.030679
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:50:36.007365
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    # GIVEN
    class_def_node = ast.ClassDef()
    class_def_node.name = 'aa'
    function_def_node = ast.FunctionDef()
    function_def_node.name = 'bb'
    function_def_node.decorator_list = [class_def_node]

    # WHEN
    variables = {'bb': 'cc'}
    VariablesReplacer.replace(function_def_node, variables)

    # THEN
    assert function_def_node.name == 'cc'



# Generated at 2022-06-23 23:50:40.412824
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_first_snippet(a, b):
        let(x)
        x = a + b

    my_first_snippet.get_body(a=1, b=2)



# Generated at 2022-06-23 23:50:46.486962
# Unit test for function extend
def test_extend():
    snippet_kwargs = {'a': 'first', 'b': 'second'}
    fn = lambda a: extend(a)
    body = snippet(fn).get_body(**snippet_kwargs)
    assert body == ['first', 'second']



# Generated at 2022-06-23 23:50:50.397776
# Unit test for function extend
def test_extend():
    import inspect
    import ast
    def function():
        extend(inspect.currentframe().f_back.f_locals)
        return 0
    tree = ast.parse(inspect.getsource(function))
    tree.body[0].body.append(ast.Return(value=ast.Num(n=1)))
    tree.body[0].body.append(ast.Return(value=ast.Num(n=2)))
    extend_tree(tree, {
                  'x': ast.Num(n=3)
                 })
    assert ast.dump(tree) == '<_ast.FunctionDef object at 0x7f42a41e0f98>'

# Generated at 2022-06-23 23:50:51.552273
# Unit test for function extend
def test_extend():
    from .test_snippet import test_extend as _test_extend
    _test_extend()



# Generated at 2022-06-23 23:50:56.540333
# Unit test for function find_variables
def test_find_variables():
    source = '''
        let(a)
        let(b)
        
        a = 1
        b = 2
    '''
    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == ['a', 'b']


# Generated at 2022-06-23 23:51:00.479785
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    v = {'A': [ast.parse("""class B:
    pass""")]}

    tree = ast.parse("""class A:
    pass""")
    VariablesReplacer.replace(tree, v)

    assert get_source(tree) == get_source([ast.parse("""class B:
    pass""")])

# Generated at 2022-06-23 23:51:04.468354
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class_def = ast.ClassDef(name='abc', bases=[], keywords=[], 
                        body=[], decorator_list=[])
    class_def = VariablesReplacer.replace(class_def, {})
    assert class_def.name == 'abc'


# Generated at 2022-06-23 23:51:10.278577
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class TestClass:
        def __init__(self, a, b=2):
            pass

    @snippet
    def func(arg1: TestClass):
        pass

    tree = func.get_body()

    expected_arguments = [
        ast.arg(arg='arg1', annotation=ast.Name(id='TestClass', ctx=ast.Load()))
    ]

    assert tree[0].args.args == expected_arguments

# Generated at 2022-06-23 23:51:11.845706
# Unit test for constructor of class snippet
def test_snippet():
    def lambda_1():
        return 1
    assert snippet(lambda_1)



# Generated at 2022-06-23 23:51:19.639875
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    variable = ast.alias(
        name='a.b',
        asname='b'
    )
    variable_node = ast.Name('a.b')
    node = ast.ImportFrom(
        module='a.b',
        names=[variable],
        level=0
    )
    variables: Dict[str, Variable] = {
        'a.b': variable_node
    }
    result = VariablesReplacer.replace(node, variables)
    expected = ast.ImportFrom(
        module='a.b',
        names=[variable_node],
        level=0
    )
    assert result == expected

# Generated at 2022-06-23 23:51:20.556085
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: 1)

# Generated at 2022-06-23 23:51:27.554798
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    source = """
x = 1
"""
    old = ast.parse(source)
    variables = {"x": VariablesGenerator.generate("x")}
    new = VariablesReplacer.replace(old, variables)
    assert new.body[0].targets[0].id == variables["x"]


# Generated at 2022-06-23 23:51:35.021718
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class_def = ast.ClassDef(name='Foo', bases=[])
    f = ast.FunctionDef(name='f', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Try(body=[class_def], handlers=[ast.ExceptHandler(name='e', type=None, body=[])], orelse=[], finalbody=[])], decorator_list=[])
    tree = ast.Module(body=[f])
    VariablesReplacer.replace(tree, {'Foo': ['foo']})
    assert isinstance(tree.body[0].body[0].body[0].handlers[0].name, ast.Name)

# Generated at 2022-06-23 23:51:44.222078
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .example import example_function
    import ast

    source = get_source(example_function)
    tree = ast.parse(source)
    variables = {'example_function': 'example_function_changed_name'}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    output = ast.dump(tree)

# Generated at 2022-06-23 23:51:47.301458
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    my_var = 'test'
    tree = ast.parse('import imports.my_module')
    variables = {'imports.my_module': my_var}
    res = VariablesReplacer.replace(tree, variables)
    assert res.body[0].module == my_var

# Generated at 2022-06-23 23:51:53.672051
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    name = ast.Name(id='word', ctx=ast.Load())
    attribute = ast.Attribute(value=name, attr='ui', ctx=ast.Load())
    variables = {'word': 'another_word'}
    VariablesReplacer.replace(attribute, variables)
    assert attribute.attr == 'ui'
    assert attribute.value.id == 'another_word'
    assert isinstance(attribute.value, ast.Name)


# Generated at 2022-06-23 23:52:03.665864
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from . import typed_ast_visitor
    class TestImporter(typed_ast_visitor.Visitor):
        _variables = {}
        _tree = None
        @property
        def variables(self):
            return self._variables
        @variables.setter
        def variables(self, variables):
            self._variables = variables

        @property
        def tree(self):
            return self._tree
        @tree.setter
        def tree(self, tree):
            self._tree = tree

    tree = ast.parse("import os")
    importer = TestImporter()
    importer.tree = tree
    importer.visit_ImportFrom(tree.body[0])
    importer.variables = {'os': 'sys'}
    tree = importer.visit(tree)
   

# Generated at 2022-06-23 23:52:04.472156
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    try:
        pass
    except Exception as e:
        assert False

# Generated at 2022-06-23 23:52:10.491720
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse(
        'def a(x):\n'
        '    def b(z):\n'
        '        return x + z\n'
    )
    variable_map = {'a': 'c'}
    tree_transformed = VariablesReplacer.replace(tree, variable_map)
    assert ast.dump(tree_transformed) == ast.dump(
        ast.parse(
            'def c(x):\n'
            '    def b(z):\n'
            '        return x + z\n'
        )
    )



# Generated at 2022-06-23 23:52:11.567680
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet


# Generated at 2022-06-23 23:52:12.935467
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda: let("a"))

# Generated at 2022-06-23 23:52:21.707890
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class_bind_attrib_instance = ast.parse("class A:\n x = 1\n y = 2", mode="exec").body[0]
    test_class_bind_attrib_instance = ast.parse("class B:\n a = 1\n b = 2", mode="exec").body[0]
    test_class_bind_attrib_instance = VariablesReplacer.replace(test_class_bind_attrib_instance, {"A": [class_bind_attrib_instance]})
    assert test_class_bind_attrib_instance.body[0].value.elts[0].value.value == 1

# Generated at 2022-06-23 23:52:30.245176
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    # Check that visit_ExceptHandler set name of ExceptHandler to new name
    # if old name is in self._variables.
    old_name = 'old_name'
    new_name = 'new_name'
    variables = {
        old_name: new_name,
    }
    tree = ast.parse('try: pass\nexcept Exception as {}: pass'.format(old_name)).body[0]
    VariablesReplacer.replace(tree, variables)
    assert tree.handlers[0].name == new_name
    assert new_name not in variables


# Generated at 2022-06-23 23:52:37.369304
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    variables = {'spam': 'foo', 'bar': 'baz'}
    tree = ast.parse('from spam import bar, foobar')
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'from foo import baz, foobar'

# Unit tests for method visit_ImportFrom of class VariablesReplacer

# Generated at 2022-06-23 23:52:38.206297
# Unit test for constructor of class snippet
def test_snippet():
    a = snippet(lambda: None)
    assert a._fn is not None

# Generated at 2022-06-23 23:52:48.125616
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    variables_dict = {'x': '_py_backwards_x_0'}
    source = """
        def _py_backwards_fun_0(x):
            x += 1
            print(x)
    """
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, variables_dict)