

# Generated at 2022-06-23 23:43:03.395991
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():

    source = """
    let(x)
    let(y)
    print(x)
    """
    
    tree = ast.parse(source)
    extend_tree(tree, {})
    variables = find_variables(tree)
    VariablesReplacer.replace(tree, {})
    assert isinstance(tree.body[2], ast.Expr)
    assert isinstance(tree.body[2].value, ast.Call)
    assert isinstance(tree.body[2].value.func, ast.Name)
    assert tree.body[2].value.func.id == 'print'
    assert isinstance(tree.body[2].value.args[0], ast.Name)
    assert tree.body[2].value.args[0].id == 'x'
    

# Generated at 2022-06-23 23:43:04.520012
# Unit test for method visit_Name of class VariablesReplacer

# Generated at 2022-06-23 23:43:08.591726
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('def fn(x):\n    return x')
    replace = VariablesReplacer.replace(tree, {'x': 'y'})
    assert replace.body[0].body[0].value.id == 'y'

# Generated at 2022-06-23 23:43:13.261673
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    module = 'some.module'
    node = ast.ImportFrom(module, [ast.alias('some_name')], level=1)
    tree = ast.parse('pass')
    tree.body.append(node)
    variables = {'module': 'new_module'}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[-1].module == 'new_module'

# Generated at 2022-06-23 23:43:24.343412
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import find
    from .helpers import get_source
    from .pprint import syntax_diagram
    test_snippet_get_body.called = False

    @snippet
    def f(my_var1: str, my_var2: str) -> None:
        let(my_var1)
        let(my_var2)
        my_var1 = 'hello ' + my_var2
        extend(my_var2)
        my_var2 = 'world'
        print(my_var1)

    tree = ast.parse(get_source(f))
    assert [x.name for x in find(tree, ast.Name)] == ['f']
    tree = ast.parse(get_source(f.get_body))

# Generated at 2022-06-23 23:43:31.117244
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():

    node = ast.ClassDef(name='Class', 
                        body=[ast.Pass()], 
                        decorator_list=[], 
                        keywords=[])
    variables = {'Class': 'NewName'}
    VariablesReplacer.replace(node, variables)
    assert node.name == 'NewName'
    assert node.body == [ast.Pass()]
    assert node.decorator_list == []
    assert node.keywords == []

# Unit tests for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:43:32.073283
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: None)

# Generated at 2022-06-23 23:43:42.563367
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.parse('from x import y').body[0]
    assert 'x' == VariablesReplacer.replace(import_from, {'x': 'a'}).module
    assert 'y' == VariablesReplacer.replace(import_from, {'y': 'a'}).names[0].name
    assert 'x' == VariablesReplacer.replace(import_from, {'x.y': 'a'}).module
    assert 'y' == VariablesReplacer.replace(import_from, {'x.y': 'a'}).names[0].name
    assert 'x.y' == VariablesReplacer.replace(import_from, {'x.y': 'a.b'}).module


# Generated at 2022-06-23 23:43:51.844770
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""
except Exception as e:
    print(e)
except ValueError as e:
    print(e)
except:
    print("Error")
    """)
    variables = {
        "e": "err",
        "ValueError": "ValueError1",
        "Exception": "Exception1"
    }
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert get_source(tree) == '\n' \
                               'except Exception1 as err:\n' \
                               '    print(err)\n' \
                               'except ValueError1 as err:\n' \
                               '    print(err)\n' \
                               'except:\n' \
                               '    print("Error")\n'

# Generated at 2022-06-23 23:44:02.438439
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    node = ast.parse("""def foo(x, y = x): pass""").body[0] # type: ignore
    assert isinstance(node, ast.FunctionDef)
    assert node.name == 'foo'
    assert isinstance(node.args, ast.arguments)
    assert len(node.args.args) == 2
    assert isinstance(node.args.args[0], ast.arg)
    assert node.args.args[0].arg == 'x'
    assert isinstance(node.args.args[1], ast.arg)
    assert node.args.args[1].arg == 'y'
    assert isinstance(node.args.args[1].annotation, ast.Name)
    assert node.args.args[1].annotation.id == 'x'


# Generated at 2022-06-23 23:44:04.589939
# Unit test for function find_variables
def test_find_variables():
    source = '''\
    y = x
    
    let(x)
    
    x += 1
    let(z)
    '''
    tree = ast.parse(source)
    assert find_variables(tree) == ['x', 'z']

# Generated at 2022-06-23 23:44:12.281336
# Unit test for function extend

# Generated at 2022-06-23 23:44:16.281746
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A:
        def b(self):
            return 0

    class B(A):
        def b(self):
            return 1

        def c(self):
            return 2

    class C(B):
        def c(self):
            return 3

    source = (
        'class D(C):\n'
        '    def c(self):\n'
        '        return 4'
    )

    tree = ast.parse(source)
    variables = {'D': 'E', 'B': B, 'A': A, 'C': C}
    VariablesReplacer.replace(tree, variables)
    globals()['E'] = type(tree.body[0])

# Generated at 2022-06-23 23:44:19.487177
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(
        ast.parse("""
            let(x)
            let(y)
            x
        """).body
    )) == ['x', 'y']



# Generated at 2022-06-23 23:44:24.867523
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    node = ast.parse("def foo(arg): pass").body[0].args
    variables = {'arg': ast.Name(id='foo', ctx=ast.Param())}
    tree = VariablesReplacer.replace(node, variables)
    assert ast.dump(tree) == 'foo'
    assert tree.ctx.__class__.__name__ == 'Param'


# Generated at 2022-06-23 23:44:34.379864
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    # Finds variables and remove `let` calls.
    for node in find(tree, ast.Call):
        if isinstance(node.func, ast.Name) and node.func.id == 'let':
            parent, index = get_non_exp_parent_and_index(tree, node)
            parent.body.pop(index)  # type: ignore
            yield node.args[0].id  # type: ignore
    
    
    #Replaces declared variables with unique names.
    class VariablesReplacer(ast.NodeTransformer):
        def __init__(self, variables: Dict[str, Variable]) -> None:
            self._variables = variables

 

# Generated at 2022-06-23 23:44:39.834170
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    global log
    log = []

    def func():
        pass

    def run():
        tree = ast.parse(get_source(func))
        tree = VariablesReplacer.replace(tree, {'log': 'log'})

        exec(compile(tree, filename='<string>', mode='exec'))

    assert run() == ['func', 'run']



# Generated at 2022-06-23 23:44:50.569348
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: int) -> int:
        let(y)
        y += 1
        return x + y

    body = fn.get_body(x=ast.Name(id='var', ctx=ast.Load()),
                       y=ast.Name(id='var2', ctx=ast.Load()))


# Generated at 2022-06-23 23:44:56.256964
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    def foo(x: Any, y: Any, z: Any) -> None:
        let(y)
        let(z)

    snippet_kwargs = {'y': 1, 'z': 2}
    body = snippet(foo).get_body(**snippet_kwargs)

    funcdef = body[0]
    args = funcdef.args
    assert args.args[0].arg == 'x'
    assert args.args[1].arg == '_py_backwards_y_0'
    assert args.args[2].arg == '_py_backwards_z_0'

# Generated at 2022-06-23 23:45:06.853132
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    variables = {
        'x': 'y',
        'a': ast.Attribute(ast.Name('b'), 'c', ast.Load()),
        'b': ast.Call(func=ast.Name('c'), args=[ast.Name('a', ast.Load())], keywords=[], starargs=None, kwargs=None)
    }
    tree = ast.parse("x = 1\na = b\nb = c(a)")
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)


# Generated at 2022-06-23 23:45:08.351626
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Given
    let_ = 'let'

# Generated at 2022-06-23 23:45:19.489609
# Unit test for function extend
def test_extend():
    from .test_helpers import get_source, compare_ast

    def snippet2() -> None:
        extend(vars)
        print(x)
        extend(vars2)
        print(x)
        print(y)

    vars = [
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))
    ]

    vars2 = [
        ast.Assign([ast.Name('y', ast.Store())], ast.Num(3))
    ]

    assert compare_ast(snippet2(), """
    x = 1
    x = 2
    print(x)
    y = 3
    print(x)
    print(y)
    """)

# Generated at 2022-06-23 23:45:25.614605
# Unit test for function extend_tree
def test_extend_tree():
    test_tree = ast.parse("x = 1; extend(vars); print(x)")
    vars = (ast.Assign(targets=[ast.Name(id='x',
                                         ctx=ast.Store())],
                       value=ast.Num(n=2)))  # type: Iterable[ast.AST]
    extend_tree(test_tree, {'vars': vars})

# Generated at 2022-06-23 23:45:30.724523
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    cls = ast.ClassDef(name='ABC', body=[], decorator_list=[])
    assert VariablesReplacer({'ABC': 2}).visit_ClassDef(cls) == cls
    assert not hasattr(cls, 'name')
    cls = ast.ClassDef(name='ABC', body=[], decorator_list=[])
    assert VariablesReplacer({'ABC': 'Test'}).visit_ClassDef(cls) == cls
    assert cls.name == 'Test'



# Generated at 2022-06-23 23:45:31.400206
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    pass

# Generated at 2022-06-23 23:45:37.595517
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    code = "let(x) * let(y) + 2"
    tree = ast.parse(code)
    variables = VariablesReplacer.replace(tree, {"x": "a", "y": "b"})
    assert(get_source(variables) == "a * b + 2")


if __name__ == '__main__':
    test_VariablesReplacer()

# Generated at 2022-06-23 23:45:40.566244
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    assert VariablesReplacer.replace(ast.parse("a.b").body[0], {"a": "c"}) == ast.parse("c.b").body[0]


# Generated at 2022-06-23 23:45:45.320601
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    old_tree = ast.parse('obj.attr')
    new_tree = ast.parse('obj.new_attr')
    variables = {'attr': new_tree.body[0].value}
    VariablesReplacer.replace(old_tree, variables)
    assert ast.dump(old_tree) == ast.dump(new_tree)



# Generated at 2022-06-23 23:45:48.127362
# Unit test for constructor of class snippet
def test_snippet():
    x = 1
    y = 2
    body = let(x)
    assert isinstance(body, snippet)
    assert body.__dict__['_fn'].__name__ == 'let'

# Generated at 2022-06-23 23:45:57.473063
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class TestVariablesReplacer(VariablesReplacer):
        def __init__(self):
            super().__init__({'x': ast.Name(id='a'), 'y': ast.Name(id='b')})

    class TestName(ast.Name):
        def visit(self, visitor, context):
            visitor.visit_Name(self)

    test = TestName(id='x')
    test2 = TestName(id='y')
    test3 = TestName(id='z')

    replacer = TestVariablesReplacer().visit(test)
    replacer = TestVariablesReplacer().visit(test2)
    replacer = TestVariablesReplacer().visit(test3)

    assert replacer.id == 'a'
    assert replacer.id == 'b'
    assert replacer.id

# Generated at 2022-06-23 23:46:03.386176
# Unit test for function extend
def test_extend():
    def my_func():
        extend(hello_world)

        print('Hi')  # will be printed only once

    hello_world = ast.parse('hola = 1')
    tree = snippet(my_func).get_body()

    assert tree[0] == hello_world.body[0]
    assert get_source(tree[1]) == 'print(\'Hi\')'



# Generated at 2022-06-23 23:46:08.876731
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('a(b=c)')
    tree = VariablesReplacer.replace(tree, {'c': 'extra'})
    extra_node = tree.body[0].value.keywords[0]
    assert isinstance(extra_node, ast.keyword)
    assert extra_node.arg == 'extra'
    assert extra_node.value.id == 'c'

# Generated at 2022-06-23 23:46:15.496539
# Unit test for function extend
def test_extend():
    def snippet_extension():
        extend(vars)
        print(x, y)

    snippet_extension = snippet(snippet_extension)
    x = ast.Assign([ast.Name(id='x', ctx=ast.Store())],
                   ast.Num(n=1),
                   )
    y = ast.Assign([ast.Name(id='y', ctx=ast.Store())],
                   ast.Num(n=1),
                   )
    vars = [x, y]

    body = snippet_extension.get_body(vars=vars)
    assert len(body) == 1

    body = body[0]
    assert isinstance(body, ast.Expr)
    assert isinstance(body.value, ast.Call)

# Generated at 2022-06-23 23:46:25.678779
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    '''
    Test for get_body method:
    1. If we call get_body(x=...) with one function - it should be replaced to some other value,
    with another function - it should be replaced to third one.
    2. If we call get_body(x=...) with one function and call get_body(x=...) with another function
    - it should be replaced to third one.
    3. If we call get_body(x=...) with one function and call get_body(x=...) with the same function
    - it should be replaced to the same value.
    4. If we call get_body(x=...) with one function and call get_body(x=...) with the same function
    - after adding extend in snippet body it should be replaced to the same value (extend).
    '''
    import re


# Generated at 2022-06-23 23:46:35.241446
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():

    test_snippet_memory = """
    def plus(a, b):
        return a + b
    """

    test_snippet_memory_result = """
    def plus_0(a, b):
        return a + b
    """

    test_snippet_variable = """
    def plus(a, b):
        return a + b
    """

    test_snippet_variable_result = """
    def test_snippet_variable_0(a, b):
        return a + b
    """

    test_snippet_variable_result_2 = """
    def test_snippet_variable_0_0(a, b):
        return a + b
    """

    ast_snippet_memory = ast.parse(test_snippet_memory)
    ast_sn

# Generated at 2022-06-23 23:46:43.214854
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo(x: int, var: str) -> int:
        let(x)
        x += 1
        return x

    assert snippet(foo).get_body(x=1, var='y') == [
        ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.BinOp(
            ast.Name('_py_backwards_x_0', ast.Load()), ast.Add(), ast.Num(1))),
        ast.Return(ast.Name('_py_backwards_x_0', ast.Load()))
    ]

# Generated at 2022-06-23 23:46:45.054577
# Unit test for function extend
def test_extend():
    ast.parse("""extend(vars)
                print(x, y)""")



# Generated at 2022-06-23 23:46:50.110873
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class SomeClass:
        pass

    cls: ast.AST = ast.Expression(ast.Name(SomeClass, 'Attribute'))
    repl = VariablesReplacer({SomeClass: 'Attribute'})
    assert repl.visit(cls) == ast.Expression(ast.Name('Attribute', 'Attribute'))



# Generated at 2022-06-23 23:46:59.470327
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class A(ast.NodeTransformer):
        def visit_FunctionDef(self, node):
            node = super().visit_FunctionDef(node)
            node.name = "changed_name"
            return node

    class B(A):
        def visit_FunctionDef(self, node):
            node = super().visit_FunctionDef(node)
            node.name = "changed_name2"
            return node
        
    class FunctionDefExample(ast.AST):
        _fields = ('name', 'args', 'body')

        def __init__(self, name, args, body):
            super().__init__()
            self.name = name
            self.args = args
            self.body = body


# Generated at 2022-06-23 23:47:05.247848
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class Node:
        arg = 'a'

    class Node2:
        _arg = Node()

        @property
        def arg(self):
            return self._arg

    node = Node2() # type: ignore
    replacer = VariablesReplacer({'a':'b'})
    replacer.visit_arg(node.arg)
    assert node.arg.arg == 'b'


# Generated at 2022-06-23 23:47:14.456521
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    from .helpers import get_source, unindent
    from astunparse import unparse
    import ast
    import io

    a = ast.Name(id='a', ctx=ast.Load())
    a1 = ast.Name(id='a1', ctx=ast.Load())

    b = ast.BoolOp(op=ast.And(), values=[a, a])

    let_a_node = ast.Call(func=ast.Name(id='let', ctx=ast.Load()), args=[a], keywords=[])

    replace_var = {'a': 'a1'}

    out = io.StringIO()
    unparse(VariablesReplacer.replace(let_a_node, replace_var), out)

# Generated at 2022-06-23 23:47:19.377996
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    variables = {'_py_backwards_name_0': 'name_0'}
    tree = ast.parse('name')
    assert tree.body[0].value.id == 'name'
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].value.id == 'name_0'



# Generated at 2022-06-23 23:47:20.401264
# Unit test for function extend_tree

# Generated at 2022-06-23 23:47:24.721100
# Unit test for function extend_tree
def test_extend_tree():
    class _X(ast.AST):
        _fields = ()

    tree = ast.parse('''
        extend(x)
    ''')
    extend_tree(tree, {'x': [_X(), _X()]})
    assert tree.body == [_X(), _X()]

# Generated at 2022-06-23 23:47:30.236916
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("""
    def outer():
        def inner():
            return let(value)
        return inner()
    """)
    variables = {
        'value': 'value_0'
    }
    output = ast.parse("""
    def outer():
        def inner():
            return value_0
        return inner()
    """)
    assert VariablesReplacer.replace(tree, variables) == output

# Generated at 2022-06-23 23:47:30.788339
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    pass

# Generated at 2022-06-23 23:47:31.988203
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("a.b.c.d")
    VariablesReplacer.replace(tree, {})

# Generated at 2022-06-23 23:47:37.144376
# Unit test for function extend_tree
def test_extend_tree():
    actual_code = \
    """
    extend(x)
    """
    res = ast.parse(actual_code)
    ext = ast.parse("""
    a = 1
    b = 2
    """)
    extend_tree(res, {'x': ext})
    assert get_source(res) == "a = 1\n\nb = 2\n\n"


# Generated at 2022-06-23 23:47:48.193150
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import astor
    from .imports import Import

    tree = ast.parse(
        """
try:
    pass
except Exception:
    pass
    """
    )
    # this is to simulate what happens without let/extend
    variables = {
        'Exception': ast.Name(id='Exception'),
    }

    # this is what happens if there are no let/extend
    expected = ast.parse(
        """
try:
    pass
except Exception:
    pass
    """
    ).body[0]

    instance = VariablesReplacer(variables)
    tree = instance.visit(tree)
    actual = tree.body[0]

    assert astor.dump_tree(actual) == astor.dump_tree(expected)

    # this is to simulate what happens with let/extend

# Generated at 2022-06-23 23:47:55.910220
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
	from ..ast.ast_helpers import create_module_with_body
	module_body = [
		ast.ImportFrom(module='mymodule', names=[ast.alias(name='myfunction', asname='mynewfunction')], level=0)
	]
	module = create_module_with_body(module_body)
	variables = {'mymodule': 'newmodule'}
	VariablesReplacer.replace(module, variables)
	expected_module = create_module_with_body([
		ast.ImportFrom(module='newmodule', names=[ast.alias(name='myfunction', asname='mynewfunction')], level=0)
	])
	assert ast.dump(module) == ast.dump(expected_module)



# Generated at 2022-06-23 23:48:07.815743
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn1(a, b):
        let(c)
        d = a + b
        c = a * b
        return c
    
    @snippet
    def fn2():
        y = 1
        let(x)
        x += 1
        y += 2
        return x, y
    
    @snippet
    def fn3(a, b):
        extend(vars)
        print(a, b)
    
    fn1_body = fn1.get_body(a=1, b=2)
    fn2_body = fn2.get_body()


# Generated at 2022-06-23 23:48:18.771533
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('x = 1\ny = 2')
    assert VariablesReplacer.replace(tree, {}) == ast.parse('x = 1\ny = 2')
    assert VariablesReplacer.replace(tree, {'x': 'm'}) == ast.parse('m = 1\ny = 2')
    assert VariablesReplacer.replace(tree, {'x': 'm', 'y': 'n'}) == ast.parse('m = 1\nn = 2')
    assert VariablesReplacer.replace(tree, {'x': 'm', 'y': 'n'}) == ast.parse('m = 1\nn = 2')
    assert VariablesReplacer.replace(tree, {'x': 'm', 'y': 'n'}) == ast.parse('m = 1\nn = 2')



# Generated at 2022-06-23 23:48:23.289150
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo(x, y):
        let(z)
        z += x + y
        return z

    def foo_x_plus_y(x, y):
        z = x + y
        return z

    snippet_body = snippet(foo).get_body(x=1, y=2)
    snippet_body_x_plus_y = snippet(foo_x_plus_y).get_body()

    assert snippet_body == snippet_body_x_plus_y

# Generated at 2022-06-23 23:48:30.202388
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from astor import to_source
    import ast

    class VariablesReplacer(ast.NodeTransformer):

        def __init__(self, variables: Dict[str, Variable]) -> None:
            self._variables = variables

        def visit_alias(self, node: ast.alias) -> ast.alias:
            node.name = node.name.replace('a', 'b')
            return self.generic_visit(node)

    node = ast.ImportFrom(module='test', names=[ast.alias(name='a', asname='b')])
    tree = VariablesReplacer.replace(node, {'x': 'y'})
    assert to_source(tree) == to_source(node)



# Generated at 2022-06-23 23:48:37.361377
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    variables = {
        'cls': '_py_backwards_cls_0',
        'name': ast.Name(id='_py_backwards_name_0', ctx=ast.Store()),
        'x': '_py_backwards_x_0',
        'kwargs': {
            'key': '_py_backwards_key_0',
            'value': '_py_backwards_value_0'
        }
    }

# Generated at 2022-06-23 23:48:44.966771
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    x = ast.Name(id='x')
    c = ast.Call(func=x, args=[], keywords=[])
    x = ast.Attribute(value=x, attr='attr')
    call = ast.Call(func=x, args=[c], keywords=[])
    variables = {'x': 'y'}
    result = VariablesReplacer.replace(call, variables)
    assert(get_source(result) == 'y.attr(y())')

# Generated at 2022-06-23 23:48:49.176993
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('x.y.z')
    variables = {'x': 'user'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Attribute(value=Name(id='user', ctx=Load()), attr='y', ctx=Load())"

# Generated at 2022-06-23 23:48:50.178037
# Unit test for constructor of class snippet
def test_snippet():
    snippet()

# Generated at 2022-06-23 23:48:54.960291
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    import ast
    import inspect
    code: str = inspect.getsource(lambda x: x)
    tree: ast.FunctionDef = ast.parse(code).body[0]
    inst: VariablesReplacer = VariablesReplacer({'x': 'y'})
    print(inst.visit_FunctionDef(tree)) #noqa: T001

# Generated at 2022-06-23 23:48:55.802919
# Unit test for method visit_Name of class VariablesReplacer

# Generated at 2022-06-23 23:49:00.612241
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Foo:
        pass

    foo = Foo()
    tree = ast.parse('foo.bar')
    vars = {'foo.bar': foo}
    tree = VariablesReplacer.replace(tree, vars)
    assert getattr(tree.body[0].value, 'id') == 'foo'
    assert getattr(tree.body[0].value, 'ctx') == ast.Load()
    assert getattr(tree.body[0].value, 'attr') == 'bar'

# Generated at 2022-06-23 23:49:10.702804
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # Example with variable in class name
    source = '''
        class var1:
            pass
        '''
    tree = ast.parse(source)
    expected = ast.parse("""
        class var2:
            pass
        """)
    variables = {
        'var1': 'var2'
    }
    VariablesReplacer.replace(tree, variables)
    assert ast.fix_missing_locations(tree) == expected

    # Example with variable in method name
    source = '''
        class var1:
            def var2(self):
                pass
        '''
    tree = ast.parse(source)
    expected = ast.parse("""
        class var3:
            def var4(self):
                pass
        """)

# Generated at 2022-06-23 23:49:19.245707
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    import numpy as np
    global d
    d = np.ones(2);
    def test():
        try:
            a = 0
        except Exception as e:
            print(e)
    source = get_source(test)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name) for name in names}
    VariablesReplacer.replace(tree, variables)
    exec(compile(tree, "", "exec"))

# Generated at 2022-06-23 23:49:20.611163
# Unit test for function extend
def test_extend():
    assert False



# Generated at 2022-06-23 23:49:25.109781
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    target = ast.Name(id="import_stmt", ctx=ast.Load())
    alias = ast.alias(name='lib', asname='l')
    node = ast.Import(names=[alias])
    VariablesReplacer.replace(node, {'import_stmt': target})
    assert getattr(target, 'ctx').__class__ == ast.Load

# Generated at 2022-06-23 23:49:31.607702
# Unit test for function extend
def test_extend():
    def hello():
        let(x)
        x = 1

    def world():
        extend(vars)
        vars = ast.parse('x = 1\nx = 2')

    snippet_hello = snippet(hello)
    snippet_world = snippet(world)

    snippet_world.get_body(vars=snippet_hello.get_body())

# Generated at 2022-06-23 23:49:34.294449
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:49:35.561026
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet

# Generated at 2022-06-23 23:49:36.490695
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer({}) is not None

# Generated at 2022-06-23 23:49:45.155472
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = 'from a.b.c.d import a'
    tree = ast.parse(source)
    variables = {
        'a': 'b.c.d',
        'b.c.d': 'a.b.c.d',
        'c.d': 'b.d'
    }
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert(get_source(tree) == 'from a.b.c.d import a')

# Generated at 2022-06-23 23:49:50.859374
# Unit test for function extend
def test_extend():
    def fn():
        extend(vars)
        print(x, y)

    x = ast.parse('x = 1\nx = 2').body
    y = ast.parse('y = 1').body  # type: ignore

    body = snippet(fn).get_body(vars=(x, y))  # type: ignore
    assert body == [ast.Expr(value=x[0]), ast.Expr(value=x[1]), ast.Expr(value=y[0])]  # type: ignore



# Generated at 2022-06-23 23:49:55.965601
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    source = """
        class A:
            a = 1
            b = 2
    """

    tree = ast.parse(source)
    variables = {'a': 'A', 'b': 'B'}
    res = VariablesReplacer.replace(tree, variables)
    assert res == tree

# Generated at 2022-06-23 23:50:06.754777
# Unit test for function find_variables
def test_find_variables():
    source = '''
        import datetime
        
        let(x)
        let(y)
        
        print(y)
    '''
    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']

# Generated at 2022-06-23 23:50:12.088862
# Unit test for function find_variables
def test_find_variables():
    snippet_source = """
let(x)
let(y)
let(z)
x = 2
y = 2
z = 2
"""
    tree = ast.parse(snippet_source)
    variables = find_variables(tree)
    assert set(variables) == set('xyz')



# Generated at 2022-06-23 23:50:20.824307
# Unit test for function let
def test_let():
    @snippet
    def let_snippet():
        let(x)
        x += 1
        y = 1
    body = let_snippet.get_body()
    assert body == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                   op=ast.Add(),
                                   right=ast.Num(n=1))),

        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=1))
    ]



# Generated at 2022-06-23 23:50:25.295866
# Unit test for function extend
def test_extend():
    def outer():
        let(x)
        x = 1
        x = 2
        extend(vars)
        print(x, y)

    vars = outer.get_body()

    assert vars == ast.parse('''
    x = 1
    x = 2
    ''').body



# Generated at 2022-06-23 23:50:33.297239
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    in_code = """
    def let(x):
        x += 2
    let(3)
    """
    source_tree = ast.parse(in_code)
    variables = find_variables(source_tree)
    extend_tree(source_tree, variables)
    VariablesReplacer.replace(source_tree, variables)
    out_code = """
    def _py_backwards_x_0():
        _py_backwards_x_0 += 2
    _py_backwards_x_0()
    """
    out_tree = ast.parse(out_code)
    assert ast.dump(source_tree) == ast.dump(out_tree)



# Generated at 2022-06-23 23:50:39.345373
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("extend('let')")
    variables = {'let': 'x = 1', 'extend': 'y = 1'}
    result = VariablesReplacer.replace(tree, variables)
    assert result.body[0].value.s == 'x = 1'


# Generated at 2022-06-23 23:50:41.627935
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('import module')
    variables = {'module': 'other_module'}
    VariablesReplacer.replace(tree, variables)
    assert str(tree) == 'import other_module'


# Generated at 2022-06-23 23:50:49.666609
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    v1 = VariablesGenerator.generate('x')
    v2 = VariablesGenerator.generate('y')
    v3 = VariablesGenerator.generate('z')
    tree = ast.parse('(x + y) + (a - b) + z')
    result = ast.parse(f'({v1} + {v2}) + (a - b) + {v3}')
    assert VariablesReplacer.replace(tree, {'x': v1, 'y': v2, 'z': v3}) == result

# Generated at 2022-06-23 23:50:55.512555
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # Test for node.module = self._replace_module(node.module)
    source1 = """ from . import sys, os"""
    tree1 = ast.parse(source1)
    variables1 = {'sys': '_py_backwards_sys_0', 'os': '_py_backwards_os_1'}
    res = VariablesReplacer.replace(tree1, variables1)
    expected_module1 = '_py_backwards_sys_0'

    assert(expected_module1 == res.body[0].names[0].name and
           expected_module1 == res.body[0].names[1].name)

    # Test for node = self._replace_field_or_node(node, 'arg')
    source2 = """from . import c, d as c"""

# Generated at 2022-06-23 23:51:02.535151
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class Foo:
        pass

    tree = ast.parse("""try:
    let(except_handler)
except except_handler:
    pass""")
    vars = {'except_handler': ast.ExceptHandler(body=[Foo()])}
    VariablesReplacer.replace(tree, vars)
    assert type(tree.body[0].handlers[0].body[0]) is Foo

# Generated at 2022-06-23 23:51:08.305046
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    vars = {'b': 'a', 'd': 'c'}
    tree = ast.ImportFrom('b.c', [ast.alias('d', 'm')], 0)
    VariablesReplacer.replace(tree, vars)
    assert str(tree) == "from a.c import c as m"

# Generated at 2022-06-23 23:51:14.032507
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    from .snippets import snippets, test_snippet1

    TARGET_CONTROL = """def _py_backwards_x_0():
    pass"""

    tree = ast.parse(get_source(snippets))
    variables = {}
    VariablesReplacer.replace(tree, variables)

    control = ast.parse(TARGET_CONTROL)
    assert ast.dump(tree) == ast.dump(control)



# Generated at 2022-06-23 23:51:20.726599
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    from ast import alias
    from .replace import VariablesReplacer
    # from snippet import extend, let
    tree = ast.parse("from .foo import x as y")
    # tree = ast.parse("from .foo import y")
    
    # tree = ast.parse("from .foo import (x, y)")
    extend_tree(tree, {"x": "y"})
    extend_tree(tree, {"x": "y"})
    # extend_tree(tree, {"x": "y"})
    # extend_tree(tree, {"x": "y"})
    # extend_tree(tree, {"x": "y"})
    # tree.body[0].names = {"x": "y"}
    # tree.body[0].names[0].name = "y"
    # print(tree

# Generated at 2022-06-23 23:51:28.822845
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo(a: int, b: int) -> int:
        let(x)
        return x + b
    snippets = snippet(foo)
    body = snippets.get_body(x=ast.Name(id='a'))
    assert body == [ast.Return(value=ast.BinOp(op=ast.Add(), left=ast.Name('_py_backwards_x_0'), right=ast.Name('b')))]

# Generated at 2022-06-23 23:51:35.635966
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse('try: 0 / 0 except ZeroDivisionError as err: print(err)')
    variables = {'err': ast.Name(id='_py_backwards_err_0', ctx=ast.Store())}
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:51:40.435903
# Unit test for function extend
def test_extend():
    def decorator():
        extend(snippet.get_body())
        return 0

    def func(x):
        return x

    actual = get_source(decorator)
    expected = get_source(func)

    assert actual == expected

    # Check that this doesn't fail
    from .test.test_snippet import test_snippet



# Generated at 2022-06-23 23:51:44.793355
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A:
        class B:
            pass

    tree = ast.parse(get_source(A))
    variables = {'A': ast.Name(id='ABC', ctx=ast.Load())}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert tree.body[0].name == 'ABC'

# Generated at 2022-06-23 23:51:49.304197
# Unit test for function extend
def test_extend():
    # Initial code
    source = """extend(vars)
print(x, y)"""
    tree = ast.parse(source)

    # What we want to extend
    vars = ast.parse("x = 1\nx = 2").body

    extend_tree(tree, {'vars': vars})

    src = get_source(tree)
    expected = """x = 1
x = 2
print(x, y)"""
    assert src == expected



# Generated at 2022-06-23 23:51:59.270309
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class A:
        pass
    _a = A()
    _a.x = "1"
    _b = ast.Name(id=_a, ctx=ast.Load())
    # _b = ast.Name(id=_a.x, ctx=ast.Load())
    tree = ast.parse('''def a(a1):
        pass''')

    variables = {_a: _b}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)

    for node in find(tree, ast.Call):
        if isinstance(node.func, ast.Name):
            assert node.func.id == _a.x  # type: ignore

# Generated at 2022-06-23 23:52:04.297330
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    def f():
        try:
            x = 1
        except Exception as e:
            e = 1 # e = 'some_string' is ok

    tree = ast.parse(get_source(f))
    variables = {'e': 1}
    assert get_source(VariablesReplacer.replace(tree, variables)) == 'def f():\n    try:\n        x = 1\n    except:\n        pass'



# Generated at 2022-06-23 23:52:11.330622
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def my_func(a=3, b=3, c=3):
        let(a)
        return a

    func_a = my_func
    func_b = func_a
    func_c = func_b
    func_d = func_c
    name_a = '_py_backwards_a_0'
    name_b = '_py_backwards_a_1'
    name_c = '_py_backwards_a_2'
    name_d = '_py_backwards_a_3'
    func_a.__name__ = name_a
    func_b.__name__ = name_b
    func_c.__name__ = name_c
    func_d.__name__ = name_d
    source = get_source(my_func)
    tree

# Generated at 2022-06-23 23:52:17.779093
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    ast_ = ast.parse("""try:
            pass
        except Exception as e:
            pass""")

    body = ast_.body[0].body[0].body
    handler = body[0].handlers[0]

    # TODO: add and check 'except Exception as e:'
    body[0].handlers[0] = VariablesReplacer.replace(handler, {"e": "error"})

# Generated at 2022-06-23 23:52:21.033434
# Unit test for function find_variables

# Generated at 2022-06-23 23:52:29.463225
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    from py_backwards.helpers import VariablesGenerator

    variables = {
        'var': 'name',
        'var2': ['var2']
    }

    class TestNode(ast.AST):
        _fields = ('id',)

    class TestNode2(ast.AST):
        _fields = ('id',)

    name = TestNode(TestNode2(id='var'))

    inst = VariablesReplacer(variables)
    result = inst.visit_Name(name)

    assert result.id == 'name'


# Generated at 2022-06-23 23:52:41.131263
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class Node:
        def __init__(self, id) -> None:
            self.id = id
            self.body = [Node('f')]
            self.args = Node('arg')
            self.args.args = [Node('x')]
            self.args.vararg = Node('')
            self.args.kwonlyargs = [Node('')]

        def __repr__(self) -> str:
            return self.id

    class NodeTransformer:
        def generic_visit(self, node: Node) -> Node:
            for n in node.__dict__.values():
                if isinstance(n, Node):
                    self.generic_visit(n)
            return node


# Generated at 2022-06-23 23:52:49.543848
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('''from some_module import x as y''')
    variables = {'x': 'some_module'}
    VariablesReplacer.replace(tree, variables)

    assert ast.dump(tree) == \
        '''ImportFrom(module='some_module', names=[alias(name='some_module', asname='y')], level=0)'''

    tree = ast.parse('''import some_module''')
    variables = {'some_module': 'some_module'}
    VariablesReplacer.replace(tree, variables)

    assert ast.dump(tree) == \
        '''Import(names=[alias(name='some_module', asname=None)])'''

# Generated at 2022-06-23 23:52:58.367979
# Unit test for function let
def test_let():
    def hello():
        let(x)
        x += 1
        y = 1
    
    assert snippet(hello).get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0')],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0'),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y')],
            value=ast.Num(n=1)
        ),
    ]
