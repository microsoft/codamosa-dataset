

# Generated at 2022-06-23 23:42:51.146955
# Unit test for function let
def test_let():
    var = 10
    @snippet
    def func():
        let(var)
        var += 10

    assert func().get_body() == ast.parse('''
    for _py_backwards_var_0 in range(1, 11):
        continue
    ''').body


# Generated at 2022-06-23 23:42:59.802264
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from textwrap import dedent
    from .helpers import get_source

    def fn():
        x = 0

        def get_body():
            let(x)
            y = 1
            x += 1
            return y

        return get_body

    expected_source = dedent("""
        def get_body():
            _py_backwards_x_0 = 0
            y = 1
            _py_backwards_x_0 += 1
            return y
        
        return get_body
    """).strip()
    expected_tree = ast.parse(expected_source)

    snippet_get_body = snippet(fn).get_body()
    actual_source = get_source(snippet_get_body)
    actual_tree = ast.parse(actual_source)
    assert expected_source == actual_source


# Generated at 2022-06-23 23:43:07.281823
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)")
    assert len(list(find_variables(tree))) == 1
    assert len(tree.body) == 0

    tree = ast.parse("let(x)x = 2;let(x)x = 2;")
    assert len(list(find_variables(tree))) == 2
    assert len(tree.body) == 0

    tree = ast.parse("""let(x)
        x = 2;
        let(x)
        x = 2;
    """)
    assert len(list(find_variables(tree))) == 2
    assert len(tree.body) == 0

    tree = ast.parse("let(x)")
    assert len(list(find_variables(tree))) == 1
    assert len(tree.body) == 0


# Generated at 2022-06-23 23:43:14.931909
# Unit test for constructor of class snippet
def test_snippet():
    import ast
    x = 3
    y = 5

    @snippet
    def foo():
        let(x)
        let(y)

        extend(x)
        x += 1
        extend(y)
        y += 1

    body = foo.get_body()

    # body equals to the following AST:
    result = ast.parse('x = 3\ny = 5\n_py_backwards_x_0 += 1\n_py_backwards_y_1 += 1\n').body
    assert body == result

# Generated at 2022-06-23 23:43:26.119453
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    '''
    Given
    - a name,
    - a dict of replacement
    When
    - we call VariablesReplacer.replace
    Then
    - the name is replaced in this dict
    '''
    data = {
        "a": ast.Name(id="1", ctx=ast.Load()),
        "b": ast.Name(id="2", ctx=ast.Load())
    }
    replacement = {
        "a": ast.Name(id="x", ctx=ast.Load()),
        "b": ast.Name(id="y", ctx=ast.Load())
    }
    expected_data = {
        "a": ast.Name(id="x", ctx=ast.Load()),
        "b": ast.Name(id="y", ctx=ast.Load())
    }

# Generated at 2022-06-23 23:43:32.994618
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class DummyClass:
        pass
    tree = DummyClass()
    dummy_field = DummyClass()
    dummy_field.id = 'id1'
    tree.body = [dummy_field]
    
    fake_id = ast.Name()
    fake_id.id = 'id1'
    
    replacer = VariablesReplacer({'id1': 'id2'})
    
    assert(replacer._replace_field_or_node(tree, 'body', True) == tree and
           replacer._replace_field_or_node(fake_id, 'id', True) == 'id2')

# Generated at 2022-06-23 23:43:41.415449
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("let(x)\nx += 1")
    variables = {'x': VariablesGenerator.generate('x')}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='_py_backwards_x_0', ctx=Store())], value=BinOp(left=Name(id='_py_backwards_x_0', ctx=Load()), op=Add(), right=Constant(value=1, kind=None)))])"

# Generated at 2022-06-23 23:43:45.541667
# Unit test for function find_variables
def test_find_variables():
    source = """
        def main():
            let(x)
            x = let(y)
            let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {"x", "y", "z"}



# Generated at 2022-06-23 23:43:53.446339
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tests import assert_equal

    var = VariablesGenerator.generate('x')

    @snippet
    def snippet_test():
        let(x)
        x += 1
        y = 1

    assert_equal(
        snippet_test.get_body(x=var),
        [ast.AugAssign(
            target=ast.Name(id=var, ctx=ast.Store()),
            op=ast.Add(),
            value=ast.Constant(1, None), lineno=0, col_offset=0),
         ast.Assign(
             targets=[ast.Name(id='y', ctx=ast.Store())],
             value=ast.Constant(1, None), lineno=0, col_offset=0)])


# Generated at 2022-06-23 23:44:00.997122
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = ("from module1 import var1 as var2, var3\n"
              "var4 = var1")
    expected_source = ("from module1 import var1 as var2, var3\n"
                       "var4 = var100")
    variables = {"var1": "var100"}
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, variables)
    code = compile(tree, "<test>", mode="exec")
    exec(code)
    assert expected_source == get_source(code)



# Generated at 2022-06-23 23:44:09.169946
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("Foo(x=1)")
    variables = {"x": 1}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse("Foo(x=1)"))
    variables = {"x": ast.Name("n", ast.Load())}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse("Foo(n=1)"))
    tree = ast.parse("Foo(x=x)")
    variables = {"x": 1}
    inst = VariablesReplacer(variables)
    inst.visit(tree)

# Generated at 2022-06-23 23:44:11.639787
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    node = ast.Name(id="name")
    replacer = VariablesReplacer({"name": "new_name"})
    assert replacer.visit_Name(node) == ast.Name(id="new_name")


# Generated at 2022-06-23 23:44:17.042237
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('def fn(x):\n\tpass')
    vars = {'fn': 'test'}
    new_tree = VariablesReplacer.replace(tree, vars)
    assert new_tree.body[0].name == 'test'  # type: ignore



# Generated at 2022-06-23 23:44:26.683195
# Unit test for function extend
def test_extend():
    def f1(a, b, c):
        extend(a)
        extend(b)
        extend(c)

    def f2(a, b, c):
        f1(a, b, c)

    g = ast.Assign(targets=[ast.Name('x', ast.Store())], value=ast.Num(1))
    h = ast.Assign(targets=[ast.Name('x', ast.Store())], value=ast.Num(2))
    source = get_source(f2)
    tree = ast.parse(source)
    body = tree.body[0].body
    assert g in body
    assert h in body



# Generated at 2022-06-23 23:44:29.112268
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    from .let import VariablesReplacer, Variable
    tree = ast.parse('from foo import bar')
    variables = {'foo': 'real_foo'}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].module == 'real_foo'

# Generated at 2022-06-23 23:44:35.965737
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = """
        let(x)
        x = 1
        y = 2
        extend(vars)
        print(x, y)
    """

    t = ast.parse(source)
    snippet_kwargs = {
        'x': ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
        'vars': [
            ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),
                          annotation=None,
                          value=ast.Num(n=1)),
            ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),
                          annotation=None,
                          value=ast.Num(n=2))
        ]
    }

# Generated at 2022-06-23 23:44:41.003963
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def test_function(): return 0
    new_test_function = VariablesReplacer.replace(
        ast.parse(get_source(test_function)), {'test_function': 'new_test_function'})

    assert new_test_function.body[0].name == 'new_test_function'



# Generated at 2022-06-23 23:44:45.539323
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
  class Visitor(ast.NodeVisitor):
    def visit_arg(self, node):
      return node

  tree = ast.parse('def f(a):\n\tpass')
  visitor = Visitor()
  node = visitor.visit(tree)
  assert isinstance(node, ast.arg)

# Generated at 2022-06-23 23:44:53.831765
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars); print(x)")
    vars_ = ast.parse('a = 1; b = 2')
    extend_tree(tree, {'vars': vars_.body})
    assert ast.dump(tree) == 'ExtMod(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id="b", ctx=Store())], value=Num(n=2)), Expr(value=Call(func=Name(id="print", ctx=Load()), args=[Name(id="x", ctx=Load())], keywords=[]))])'  # noqa

# Generated at 2022-06-23 23:45:04.192311
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import inspect
    import typed_ast.ast3 as ast

    # CASE 1:
    # attribute is node.name and node.name is in dict self._variables
    # CASE 4:
    # attribute is node.name and node.name is not in dict self._variables
    # CASE 6:
    # attribute is not node.name

    class Test(VariablesReplacer):
        def visit_Attribute(self, node: ast.Attribute) -> ast.Attribute:
            return node

    # CASE 1:
    def test_case_1():
        node = ast.Attribute(value=ast.Name(id='a', ctx=ast.Load()),
                             attr='b', ctx=ast.Load())

# Generated at 2022-06-23 23:45:09.549708
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("""
    import argparse
    argparse.ArgumentParser()
    """)
    variables = {
        "argparse": "arg_parse",
        "ArgumentParser": "Arg_Parse_fn"
    }
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == """
    import arg_parse
    arg_parse.Arg_Parse_fn()
    """



# Generated at 2022-06-23 23:45:17.238497
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = '''
    def foo(a, b):
        pass
    '''
    tree = ast.parse(source)
    variables = find_variables(tree)
    VariablesReplacer.replace(tree, {'a': 'c', 'b': 'd'})

    def foo(c, d):
        pass

    expected_tree = ast.parse(get_source(foo))
    assert ast.dump(expected_tree, include_attributes=True) == ast.dump(tree, include_attributes=True)

# Generated at 2022-06-23 23:45:20.104359
# Unit test for function find_variables
def test_find_variables():
    code = """
    def f(x):
        let(a)
        a += 1
        return let(a)
    """
    tree = ast.parse(code)
    variables = {name: VariablesGenerator.generate(name) for name in find_variables(tree)}
    assert sorted(variables) == ['a']


# Generated at 2022-06-23 23:45:29.436381
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # it should replace variables names in strings
    source = 'import a.b.c as d'
    variables = {'a': '_py_backwards_a'}
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, variables)
    assert str(tree) == 'import _py_backwards_a.b.c as d'

    # it should not replace variables names in strings
    source = 'import a.b.c as d'
    variables = {'a': 'b'}
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, variables)
    assert str(tree) == 'import a.b.c as d'



# Generated at 2022-06-23 23:45:41.351218
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    ast_string_1 = 'def foo():\n    try:\n        a()\n    except Exception:\n        raise'
    tree_1 = ast.parse(ast_string_1)
    variables = VariablesReplacer.replace(tree_1, {})
    print(ast.dump(variables))

# Generated at 2022-06-23 23:45:49.456186
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    test_case = ast.parse('''f(x=None, y=None)''')
    tree_node = test_case.body[0].value
    # Test that a keyword object has been created and has the right value
    assert isinstance(tree_node.func.args.keywords[0], ast.keyword)
    assert tree_node.func.args.keywords[0].arg == 'x' or tree_node.func.args.keywords[0].arg == 'y'
    # Test that the keyword object is replaced with the correct value
    tree_node = VariablesReplacer.replace(tree_node, {'x': ast.Name(id='test_x', ctx=ast.Load()),
                                                      'y': ast.Name(id='test_y', ctx=ast.Load())})

# Generated at 2022-06-23 23:45:53.728644
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = 'from a.b import c'
    tree = ast.parse(source)
    replacer = VariablesReplacer({})
    node = tree.body[0].names[0]
    replacer.visit_alias(node)
    new_source = ast.dump(tree)
    assert new_source == source

# Generated at 2022-06-23 23:45:56.555208
# Unit test for function find_variables
def test_find_variables():
    source = '''
    a = 1
    def main():
        let(x)
        x += 1
    '''
    tree = ast.parse(source)
    assert find_variables(tree) == ['x']



# Generated at 2022-06-23 23:46:03.720812
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    a = ast.Name(
        id='a',
    )
    funcdef = ast.FunctionDef(
        name='func',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ))
    call = ast.Call(
        func=funcdef,
        args=[],
        keywords=[ast.keyword(
            arg='a',
            value=a
        )],
        starargs=None,
        kwargs=None)
    node = ast.Expr(
        value=call
    )
    tree = ast.Module(
        body=[node]
    )

    replacer = VariablesReplacer({'a': 'b'})
    repl

# Generated at 2022-06-23 23:46:07.459043
# Unit test for function let
def test_let():
    @snippet
    def snippet_with_let():
        x = 1
        let(x)
        x += 1

    assert "x += 1" in str(snippet_with_let.get_body())



# Generated at 2022-06-23 23:46:08.759285
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .examples.simple import snippets

    assert snippets.fn1.get_body() == snippets.fn1._fn().get_body()



# Generated at 2022-06-23 23:46:11.785316
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
	n=ast.parse("import a")
	v={"a": "b"}
	inst=VariablesReplacer(v)
	inst.visit_ImportFrom(n.body[0])
	assert n.body[0].module=="b"


# Generated at 2022-06-23 23:46:12.570850
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: let(1))

# Generated at 2022-06-23 23:46:17.278135
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("x = 2")
    variables = {
        'x': '_py_backwards_x_0'
    }
    # test case
    result = VariablesReplacer.replace(tree, variables)
    assert result.body[0].targets[0].id == '_py_backwards_x_0'



# Generated at 2022-06-23 23:46:20.444465
# Unit test for function find_variables
def test_find_variables():
    source = 'let(a); let(b); let(c)'
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['a', 'b', 'c']


# Generated at 2022-06-23 23:46:21.091129
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-23 23:46:23.727865
# Unit test for function extend_tree

# Generated at 2022-06-23 23:46:27.972677
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    node = ast.Attribute(value = ast.Num(n = 1), attr = 'x', ctx = ast.Load())
    visit = VariablesReplacer.replace(node, {'x': 2})
    assert isinstance(visit, ast.Attribute)
    assert visit.__dict__ == {'value': ast.Num(n = 1), 'attr': 'x', 'ctx': ast.Load()}


# Generated at 2022-06-23 23:46:34.619799
# Unit test for function let
def test_let():
    tree: ast.AST
    def snippet():
        let(x)
        x += 1

    tree = ast.parse(get_source(snippet))
    variables = find_variables(tree)
    assert variables == {'x': ast.Name(id='_py_backwards_x_0')}

    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == '\n\n_py_backwards_x_0 += 1\n'


# Generated at 2022-06-23 23:46:42.363621
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    code = """
    try:
        x
    except Exception as e:
        pass
    """
    tree = ast.parse(code)
    variables = {"e": "foo"}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == """Module(body=[Try(body=[Expr(value=Name(id='x', ctx=Load()))], handlers=[ExceptHandler(type=Name(id='Exception', ctx=Load()), name='foo', body=[Pass()])], orelse=[])])"""


# Generated at 2022-06-23 23:46:53.211707
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""extend(vars)
    x = 2
    print(x)""")
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))
            ]
    extend_tree(tree, {'vars': vars})
    expected_result = ast.parse("""x = 1
    x = 2
    x = 2
    print(x)""")
    assert ast.dump(tree, annotate_fields=False) == ast.dump(expected_result, annotate_fields=False)

# Generated at 2022-06-23 23:46:59.816663
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('x.f(y=1)')
    v = VariablesReplacer({})
    new_tree = v.visit(tree)
    assert ast.dump(new_tree) == ast.dump(tree)
    v = VariablesReplacer({'x': 'z'})
    new_tree = v.visit(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse('z.f(y=1)'))
    v = VariablesReplacer({'y': 'z'})
    new_tree = v.visit(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse('x.f(y=1)'))



# Generated at 2022-06-23 23:47:00.377523
# Unit test for constructor of class snippet
def test_snippet():
    snippet('xyz')

# Generated at 2022-06-23 23:47:08.549989
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    def test_FunctionDef1(x):
        return 1

    def test_FunctionDef2(x):
        return 2

    FunctionDef1 = ast.parse(get_source(test_FunctionDef1), mode='exec')
    FunctionDef2 = ast.parse(get_source(test_FunctionDef2), mode='exec')
    FunctionDef = VariablesReplacer.replace(
        FunctionDef1, {'x': FunctionDef2.body[0]})
    FunctionDef_target = FunctionDef2.body[0]
    assert FunctionDef == FunctionDef_target



# Generated at 2022-06-23 23:47:13.090871
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    ast_code = 'var.name'
    variables = {'var': 'new_var'}
    tree = ast.parse(ast_code)
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Attribute(value=Name(id='new_var', ctx=Load()), attr='name', ctx=Load())"



# Generated at 2022-06-23 23:47:16.220680
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("f(x=1)")
    variables = {"x": "y"}
    VariablesReplacer.replace(tree, variables)
    assert astor.to_source(tree) == "f(y=1)"

# Generated at 2022-06-23 23:47:27.043840
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    z = 3

    @snippet
    def case1() -> None:  # type: ignore
        let(x)
        let(y)
        let(z)
        x += 1
        y += 2
        z += 3


# Generated at 2022-06-23 23:47:31.619321
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = """
        def fn(arg=None):
            pass
    """
    tree = ast.parse(source)
    variables = {'arg': VarGenerator.generate('arg')}
    VariablesReplacer.replace(tree, variables)
    assert variables['arg'] == tree.body[0].args.kwonlyargs[0].arg



# Generated at 2022-06-23 23:47:41.354664
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from ast import ImportFrom
    from .helpers import VariablesGenerator

    tree = ast.parse("from a import b")
    tree.body[0] = VariablesReplacer.replace(tree.body[0], {'a': ast.Name(id=VariablesGenerator.generate(), ctx=None)})
    assert ast.dump(tree) == "from _py_backwards_1 import b"

    tree = ast.parse("from a.b import c")
    tree.body[0] = VariablesReplacer.replace(tree.body[0], {'a': ast.Name(id=VariablesGenerator.generate(), ctx=None)})
    assert ast.dump(tree) == "from _py_backwards_1.b import c"


# Generated at 2022-06-23 23:47:44.681809
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('f(a)')
    tree = VariablesReplacer.replace(tree, {'a': 'b'})
    assert get_source(tree) == 'f(b)'



# Generated at 2022-06-23 23:47:49.492984
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    ast_tree = ast.parse("def foo():\n    print(3)")
    variables = {'foo': 'bar'}
    result = VariablesReplacer.replace(ast_tree, variables)
    assert ast.dump(result) == ast.dump(ast.parse("def bar():\n    print(3)"))


# Generated at 2022-06-23 23:47:56.872792
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    source = """\
        def a(b):
            class C:
                def __init__(self): pass
                def a(self, z):
                    z.b.c.d
                    z.c.a
                def b(self, z):
                    z.b.c.d
            c
        
        d
    """

    tree = ast.parse(source)
    variables = {'a': VariablesGenerator.generate('a'),
                 'c': VariablesGenerator.generate('c'),
                 'd': VariablesGenerator.generate('d'),
                 'b': VariablesGenerator.generate('b'),
                 'z': VariablesGenerator.generate('z')}

    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:48:01.094016
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("import datetime.timedelta as timer")
    variables = {
        'timer': 'timer'
    }
    tree = VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "import datetime.timedelta as timer"

# Generated at 2022-06-23 23:48:05.166639
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    variables = {'x': 'y'}
    tree = ast.ExceptHandler(name='x', type=None, body=[])
    VariablesReplacer.replace(tree, variables)
    assert tree.name == 'y'


# Generated at 2022-06-23 23:48:14.576808
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # define test Function
    def test():
        class Test(object):
            pass

    # get source code of test Function
    source = get_source(test)
    # assert source is equal to '\nclass Test(object):\n    pass\n\n'
    assert source == '\nclass Test(object):\n    pass\n\n'

    # get AST of test Function
    tree = ast.parse(source)
    # get class Test node
    node = find(tree, ast.ClassDef).__next__()
    # get class Test name
    name = node.name
    # define variables {name: 'Test_tmp'}
    variables = {name: 'Test_tmp'}
    # call method replace of class VariablesReplacer
    VariablesReplacer.replace(tree, variables)
    # get class

# Generated at 2022-06-23 23:48:24.998420
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import compile
    from .helpers import VariablesGenerator

    class Meta(type):
        pass

    class f:
        pass

    class g:
        pass

    class A(metaclass=Meta):
        def __init__(self):
            self.A = f
            self.B = g

    class B(metaclass=Meta):
        def __init__(self):
            self.A = g
            self.B = f

    vars_ = {
        'a': A,
        'b': B,
    }

    variables = {var_name: VariablesGenerator.generate(var_name) for var_name in vars_}
    replace = VariablesReplacer.replace

    # import a
    source = compile('''import a''').strip()

# Generated at 2022-06-23 23:48:29.621245
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    print('testing constructor of class VariablesReplacer')
    variables = {}
    transformer = VariablesReplacer(variables)
    try:
        transformer.visit(None)
        print('FAILED')
    except TypeError:
        print('PASSED')

# Generated at 2022-06-23 23:48:34.690369
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    code = "test(test=test)"
    tree = ast.parse(code)
    tree = VariablesReplacer.replace(tree, {"test": "unique_variable_name"})
    assert (code[:5] + "unique_variable_name" == ast.dump(tree))


# Generated at 2022-06-23 23:48:39.238276
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
let(x)
let(y)
y = 1
print(x, y)
''')
    variables = {name: VariablesGenerator.generate(name)
                 for name in find_variables(tree)}
   
    assert variables == {'x': '_py_backwards_x_0', 'y': '_py_backwards_y_0'}

# Generated at 2022-06-23 23:48:49.058600
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import warnings
    warnings.filterwarnings("ignore", category=PendingDeprecationWarning)
    import random
    import string

    random_froms = []
    def generate_from():
        def generate_random_name():
            name = ''.join([random.choice(string.ascii_letters) for _ in range(10)])
            return name
        import_froms = ['from ' + generate_random_name() + ' import ' + generate_random_name() for _ in range(10)]
        return import_froms
    random_froms = generate_from()
    tree = ast.parse(random_froms[0])
    print(VariablesReplacer.replace(tree, {'itertools': 'random'}))

# Generated at 2022-06-23 23:48:55.420836
# Unit test for function extend_tree
def test_extend_tree():
    import astor

    tree = ast.parse('''
if extend(var):
    pass
''')
    var = ast.parse('''
if cond:
    x = 1
else:
    x = 2
''').body
    extend_tree(tree, {'var': var})
    assert astor.to_source(tree) == '''\
if cond:
    x = 1
else:
    x = 2
'''

# Generated at 2022-06-23 23:49:02.290783
# Unit test for function extend
def test_extend():
    def test():
        extend(vars)
        print(x)

    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1))]

    assert list(test.get_body(vars=vars)) == vars + [ast.Expr(value=ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Name(id='x', ctx=ast.Load())],
        keywords=[]))]

# Generated at 2022-06-23 23:49:07.620396
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    inst = VariablesReplacer({'df': '_py_backwards_df_1'})
    alias = ast.alias(name='pandas.DataFrame', asname=None)
    alias = inst.visit_alias(alias)
    assert alias.name == 'pandas._py_backwards_DataFrame_1', alias.name
    alias = ast.alias(name='pandas._backwards_DataFrame', asname=None)
    alias = inst.visit_alias(alias)
    assert alias.name == 'pandas._backwards_DataFrame', alias.name
    alias = ast.alias(name='pandas.DataFrame', asname='df')
    alias = inst.visit_alias(alias)

# Generated at 2022-06-23 23:49:13.024088
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    code = '''try:
    a = 1
except b as c:
    d = 1
'''
    names = [
        'a', 'b', 'c', 'd'
    ]
    variables = {name: name for name in names}

    tree = ast.parse(code)
    VariablesReplacer.replace(tree, variables)
    gen_code = compile(tree, '<string>', 'exec')
    exec(gen_code)

# Unit tests for method replace of class VariablesReplacer

# Generated at 2022-06-23 23:49:20.116216
# Unit test for function extend_tree
def test_extend_tree():
    import ast
    import inspect
    import unittest
    from .helpers import get_source

    class TestCase(unittest.TestCase):
        def assertTreeEqual(self, tree, expected):
            self.assertEqual(ast.dump(tree), ast.dump(expected))

        def test_extend_tree(self):
            source = """
            extend(x)
            a = 1
            """
            tree = ast.parse(source)
            extend_tree(tree, {'x': [ast.Assign(targets=[ast.Name(id='a')],
                                                value=ast.Num(n=0)),
                                   ast.Assign(targets=[ast.Name(id='b')],
                                              value=ast.Num(n=0))]})
            self.assertTree

# Generated at 2022-06-23 23:49:24.575780
# Unit test for function find_variables
def test_find_variables():
    source = '''
    class Class:
        def __init__(self):
            self.attr = 0
 
        def setter(self):
            let(value)
            self.attr = value
    '''
    tree = ast.parse(source)
    actual = list(find_variables(tree))
    expected = ['value']
    assert actual == expected



# Generated at 2022-06-23 23:49:35.455858
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
  import astor
  import inspect
  from typing import List
  from typed_ast import ast3 as ast
  from .helpers import VariablesGenerator

  class VariablesReplacer(ast.NodeTransformer):
    """Replaces declared variables with unique names."""

    def __init__(self, variables: Dict[str, Variable]) -> None:
      self._variables = variables

    def _replace_field_or_node(self, node: T, field: str, all_types=False) -> T:
      value = getattr(node, field, None)
      if value in self._variables:
        if isinstance(self._variables[value], str):
          setattr(node, field, self._variables[value])

# Generated at 2022-06-23 23:49:40.676518
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .visitor import unparse
    from .wip_tests_file import test_VariablesReplacer_visit_ImportFrom
    tree = ast.parse(test_VariablesReplacer_visit_ImportFrom)

# Generated at 2022-06-23 23:49:50.962420
# Unit test for function let
def test_let():
    assert snippet(lambda: let(x) + 2).get_body() == [
        ast.parse('_py_backwards_x_0 = None').body[0],
        ast.parse('_py_backwards_x_0 + 2').body[0]
    ]
    assert snippet(lambda: let(x) + let(y)).get_body() == [
        ast.parse('_py_backwards_x_0 = None').body[0],
        ast.parse('_py_backwards_y_0 = None').body[0],
        ast.parse('_py_backwards_x_0 + _py_backwards_y_0').body[0]
    ]


# Generated at 2022-06-23 23:49:56.685952
# Unit test for function let
def test_let():
    def test():
        a = 1
        let(a)
        a += 1

    snippets = snippet(test)
    assert len(snippets.get_body()) == 1
    assert isinstance(snippets.get_body()[0], ast.Assign)
    assert snippets.get_body()[0].targets[0].id == '_py_backwards_a_0'

# Generated at 2022-06-23 23:50:02.847312
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class A:
        def __init__(self, a: None) -> None:
            self._a = a

    tree = ast.parse('A(a=None)')
    variables = {'None': 'boo'}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    exec(compile(tree, '<ast>', 'exec'))

# Generated at 2022-06-23 23:50:07.356534
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    test_code = """try:
    i = 1
except Exception:
    pass"""
    variables = {"Exception": "Exception_0"}
    tree = ast.parse(test_code)
    VariablesReplacer.replace(tree, variables)
    assert tree == ast.parse("""try:
    i = 1
except Exception_0:
    pass""")

# Generated at 2022-06-23 23:50:15.998020
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('a.b')
    assert isinstance(tree.body[0].value, ast.Attribute)
    assert tree.body[0].value.attr == 'b'
    variables = {'a': 'ast.Name()'}
    VariablesReplacer.replace(tree, variables)
    assert isinstance(tree.body[0].value, ast.Attribute)
    assert tree.body[0].value.attr == 'b'



# Generated at 2022-06-23 23:50:20.931769
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    # When
    tree = ast.parse('def test(x: int): pass')

    # When
    tree = VariablesReplacer.replace(tree, {'x': 'y'})

    # Then
    assert tree.body[0].args.args[0].arg == 'y'

# Generated at 2022-06-23 23:50:30.717122
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A:
        pass

    a = A()
    a.alist = [1, 2, 3]
    a.blist = [4, 5]
    a.clist = [6]
    a.abd = {'a': 1, 'b': 2, 'd': 3}
    a.cde = {'c': 1, 'd': 2, 'e': 3}
    a.defd = []
    a.efg = {}
    a.fgh = {'f': 1, 'g': 2, 'h': 3}
    a.ghi = {'g': 1, 'h': 2, 'i': 3}

    class B:
        pass

    b = B()
    b.alist = []
    b.blist = [4, 5]
    b.clist = []
   

# Generated at 2022-06-23 23:50:31.582342
# Unit test for method visit_Attribute of class VariablesReplacer

# Generated at 2022-06-23 23:50:36.185325
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class Parent:
        pass

    for name in ('x', 'y'):
        x = Parent()
        x.name = name
        x.body = [ast.Expr(ast.Call(
            ast.Name('let', ast.Load()),
            [ast.Str(name)], [], None, None))]

        variables, = VariablesGenerator.generate(name)
        variables = {name: variables}

        VariablesReplacer.replace(x, variables)
        assert x.name == variables[name]

# Generated at 2022-06-23 23:50:39.040399
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("""
        def f():
            a = 1
            a += 1""")

    VariablesReplacer.replace(tree, {'a': 'b'})
    assert get_source(tree) == 'def f():\n    b = 1\n    b += 1'

# Generated at 2022-06-23 23:50:48.654419
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = u'''
        from collections import deque
        deque(maxlen=some_name)
        '''
    tree = ast.parse(source)
    variables = {'some_name': VariablesGenerator.generate('some_name')}

    assert variables['some_name']

    VariablesReplacer.replace(tree, variables)

    source = get_source(deque)
    assert source == u'from collections import deque'

    source = get_source(tree)
    assert source == ''.join((
        'from collections import deque',
        'deque(maxlen=%s)' % variables['some_name']))



# Generated at 2022-06-23 23:50:51.144742
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('let(a)\nlet(b)'))) == ['a', 'b']



# Generated at 2022-06-23 23:50:54.646601
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    module = ast.parse('def a(x): pass')
    VariablesReplacer.replace(module, {'x': 'y'})
    assert get_source(module) == 'def a(y): pass', "Replace in function definition"



# Generated at 2022-06-23 23:51:04.556051
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pytest
    from typed_ast import ast3 as ast
    from .tree import get_name
    from .helpers import get_source

    def test_fn(x: int, y: int) -> None:
        let(x)
        let(y)
        x += 1
        y += 2

    snp = snippet(test_fn)
    body = snp.get_body()
    assert body == ast.parse(get_source(test_fn)).body[0].body

    x_names = get_name(snp.get_body(), 'x')
    y_names = get_name(snp.get_body(), 'y')
    assert len(x_names) == 1
    assert len(y_names) == 1

    x_name = x_names[0]
    y_name = y

# Generated at 2022-06-23 23:51:07.494279
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse('from pkg import something')
    vars = {'pkg': ['import', 'other']}
    VariablesReplacer.replace(tree, vars)
    assert ast.dump(tree) == "ImportFrom(module=['import', 'other'], names=[alias(name='something', asname=None)], level=0)"


# Generated at 2022-06-23 23:51:18.493341
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    var = VariablesGenerator.generate('x')
    def f():
        let(x)
    x = f()
    tree = ast.parse(dedent(inspect.getsource(ast.parse(dedent(inspect.getsource(f))))))
    VariablesReplacer({"x": var}).visit(tree)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1 and len(tree.body[0].body) == 2
    assert isinstance(tree.body[0].body[0].value, ast.Name)
    assert tree.body[0].body[0].value.id == var
    assert len(tree.body[0].body[1].body) == 1

# Generated at 2022-06-23 23:51:27.281289
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    code = "a.b.c(d.e, f.g.h, let(j), let(k.l), let(m)).n(let(o))"

    class_node = ast.parse(code).body[0]
    variables = {
        'a': 'aa',
        'b': 'bb',
        'j': 'jj',
        'm': 'mm',
        'o': 'oo'
    }

    body = VariablesReplacer.replace(class_node, variables)


# Generated at 2022-06-23 23:51:33.309520
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    ast_node = ast.parse("log_debug(*args, **kwargs)")
    node_keyword = ast_node.body[0].value.keywords[0]  # type: ast.keyword
    variables_replacer = VariablesReplacer({'args':ast.Name(id='val')})
    result = variables_replacer.generic_visit(node_keyword)
    assert(result.arg == 'args')
    assert(isinstance(result.value, ast.Name))
    assert(result.value.id == 'val')



# Generated at 2022-06-23 23:51:37.044549
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    node = ast.Name("node", ast.Load())
    node.id = 'node'

    rv = VariablesReplacer({'node': 'node_1'}).visit(node)
    assert rv.id == 'node_1'



# Generated at 2022-06-23 23:51:46.687313
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo(a: int, b: int) -> int:
        let(c)
        d = a + b
        return d

    snippet_kwargs = {'a': 1, 'b': 2}
    foo(**snippet_kwargs)

    body = foo.get_body(**snippet_kwargs)
    assert body == [ast.Assign([ast.Name('_py_backwards_c_0', ast.Store())],
                               ast.BinOp(ast.Name('a', ast.Load()),
                                         ast.Add(),
                                         ast.Name('b', ast.Load())))], 'Should be equal'

# Generated at 2022-06-23 23:51:51.042271
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    pass


# Generated at 2022-06-23 23:52:01.347589
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int, z: int) -> str:
        let(x)
        x += 1
        y = x + 10
        extend(z)

    result = snippet(test_snippet).get_body(
        x=ast.parse('1').body[0].value,
        y=ast.parse('2').body[0].value,
        z=ast.parse('x = 1; x = 2').body,
    )
    assert result == ast.parse('_py_backwards_x_0 += 1; _py_backwards_y_0 = _py_backwards_x_0 + 10; x = 1; x = 2').body

# Generated at 2022-06-23 23:52:08.093617
# Unit test for constructor of class snippet
def test_snippet():
    test_src = """def snippet_test(x: int, y: int) -> str:
    return (x + y)
"""
    test_ast = ast.parse(test_src)
    assert ast.dump(test_ast) == ast.dump(snippet(snippet_test)._fn)


# Generated at 2022-06-23 23:52:14.587292
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    given_node = ast.Name(id='a', ctx=ast.Load())
    given_variables = {'a': 'b'}
    expected_node_result = ast.Name(id='b', ctx=ast.Load())
    assert VariablesReplacer.replace(given_node, given_variables) == expected_node_result



# Generated at 2022-06-23 23:52:18.233548
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
let(y)
x += 1
y += 2
""")
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']


# Generated at 2022-06-23 23:52:28.416460
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Foo:
        pass

    class Bar:
        pass

    class Sample(ast.NodeTransformer):
        def __init__(self, variables):
            self._variables = variables

        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node = self._replace_field_or_node(node, 'name')
            return self.generic_visit(node)  # type: ignore

    variables = {
        Foo: 'Baz',
        Bar: 'Quux',
    }
    node = Sample(variables).visit(ast.parse('class Foo: pass'))
    assert node.body[0].name == 'Baz'



# Generated at 2022-06-23 23:52:36.206820
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    def func():
        pass
    source = get_source(func)
    source = source[source.find('(') + 1 : source.find(')')]
    tree = ast.parse(source)
    # print(ast.dump(tree))
    node = tree.body[0]
    # print(node)
    assert isinstance(node, ast.arg)
    assert node.arg == ''
    assert node.annotation == None
    variables = {'': 'args'}
    inst = VariablesReplacer(variables)
    node = inst.visit(node)
    assert isinstance(node, ast.arg)
    assert node.arg == 'args'
    assert node.annotation == None

# Generated at 2022-06-23 23:52:39.721265
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(a)
    a += 1
    b = 1
    let(b)
    b += 1
    """
    tree = ast.parse(source)
    variables = {name: VariablesGenerator.generate(name) for name in
                 find_variables(tree)}
    VariablesReplacer.replace(tree, variables)
    assert ast.unparse(tree) == """
    a += 1
    b = 1
    _py_backwards_b_1 += 1
    """



# Generated at 2022-06-23 23:52:45.834952
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import astor
    a = ast.Attribute(value = ast.Name(id = 'a', ctx = ast.Load()), attr = 'b', ctx = ast.Load())
    variables = {'b': 'b'}
    inst = VariablesReplacer(variables)
    inst.visit_Attribute(a)
    assert astor.to_source(a) == 'a.b\n'


# Generated at 2022-06-23 23:52:51.667736
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse('x = 1')
    replacer = VariablesReplacer({'x': 'y'})
    replacer.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse('y = 1'))

