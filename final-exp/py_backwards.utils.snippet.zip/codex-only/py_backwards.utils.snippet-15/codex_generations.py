

# Generated at 2022-06-23 23:43:01.301422
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .tree import get_tree
    from .helpers import get_source

    tree = get_tree('''
from py_backwards.abc import ABCMeta, abstractmethod
''')
    variables = {
        'py_backwards.abc': 'abc',
        'ABCMeta': 'ABCMeta',
        'abstractmethod': 'abstractmethod'
    }
    expected = 'from abc import ABCMeta, abstractmethod'
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == expected

# Generated at 2022-06-23 23:43:04.998852
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func():
        x = 1
        y = 2
        let(x)
        x += 1
        y = 1
    s = snippet(func)

    assert str(s.get_body()) == "x = 1\ny = 2\n_py_backwards_x_0 += 1\ny = 1"



# Generated at 2022-06-23 23:43:09.898043
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("import math from cmath")
    variables = {
        "math": "mymath"
    }
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert "import mymath from cmath" == ast.dump(tree)

# Generated at 2022-06-23 23:43:16.391805
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("x = 1")
    extend_tree(tree, {'vars': [ast.parse("x = 2")]})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=2)), Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=1))])'


# Generated at 2022-06-23 23:43:27.563456
# Unit test for function extend
def test_extend():
    let(a)
    let(b)
    extend(x)
    extend(y)

    @snippet
    def f(a, b):
        x = a
        y = b

    body = f.get_body(x=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                    value=ast.Num(n=2))],
                      y=ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                                   value=ast.Num(n=3)))

# Generated at 2022-06-23 23:43:35.255580
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    import astor
    import inspect
    test_body = inspect.getsource(test_VariablesReplacer_visit_arg).split('\n')[1:]
    test_body = test_body[1: -1]
    test_body = '\n'.join(test_body)
    test_body = ast.parse(test_body)

    # Scope of the `test_body` is a `function`
    assert isinstance(test_body, ast.FunctionDef)

    # One of the arguments of the `test_body` is the following code:
    # def bar(x):
    #     return x
    # foo = bar
    # foo(2)
    # We are going to replace the `foo` with `bar`,
    # so that the `test_body` will look like the following code:
    # def

# Generated at 2022-06-23 23:43:41.415530
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("let(x) x + 1")
    variables = find_variables(tree)
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree, indent=2) == "Module(body=[Expr(value=BinOp(left=Name(id='_py_backwards_x_0', ctx=Load()), op=Add(), right=Constant(value=1, kind=None)))])"

# Generated at 2022-06-23 23:43:45.109439
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(foo: int, bar: int):
        return foo + bar

    @snippet
    def snippet_test():
        let(foo)
        let(bar)
        return test(foo, bar)


# Generated at 2022-06-23 23:43:49.215172
# Unit test for constructor of class snippet
def test_snippet():
    @snippet()
    def test():
        let(x)
        print(x)

    assert test.get_body(x=1) == [
        ast.Expr(
            value=ast.Call(
                func=ast.Name(id='print', ctx=ast.Load()),
                args=[ast.Num(n=1)],
                keywords=[])
        )
    ]



# Generated at 2022-06-23 23:43:55.670018
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class TestClass(ast.NodeTransformer):
        def visit_arg(self, node: ast.arg) -> ast.arg:
            node = VariablesReplacer._replace_field_or_node(self, node, 'arg')
            return self.generic_visit(node)  # type: ignore

    test_class = TestClass({"arg": "arg"})
    test_class.visit(ast.parse("def f(arg): pass"))



# Generated at 2022-06-23 23:44:02.064461
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import builtins
    from .ast_helpers import node_to_source
    
    class Test:
        pass
    
    Test.test = 3
    Test.a = 5
    tree = ast.parse(node_to_source(Test))
    replace = VariablesReplacer.replace(tree, {'Test.test': 'builtins.id'})
    result = node_to_source(replace)
    
    assert result == 'builtins.id(5)'

# Generated at 2022-06-23 23:44:07.753966
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    visitor = VariablesReplacer({'foo': 'bar'})
    tree = ast.parse('def foo(foo): pass')
    visitor.visit(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='bar', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])"


# Generated at 2022-06-23 23:44:08.254653
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:44:10.634917
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse('a')
    tree = VariablesReplacer.replace(tree, {'a': ast.Name(id='b', ctx=ast.Load())})
    assert ast.dump(tree) == 'Name(id="b", ctx=Load())'



# Generated at 2022-06-23 23:44:12.416478
# Unit test for function find_variables
def test_find_variables():
    source = '''let(x)
        x += 1
        y = 1
    '''

    tree = ast.parse(source)
    variables = find_variables(tree)
    assert 'x' in variables



# Generated at 2022-06-23 23:44:23.499411
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    from .parser import parse

    class Def(ast.AST):
        # needed for type annotations
        _fields = ()

        def __init__(self, name: str) -> None:
            self.name = name

    source = '''
    class Klass:
        def __init__(self, val):
            self.val = val

        def add(self, other):
            return Klass(self.val + other.val)

        @staticmethod
        def smth(val):
            return Klass(val)
    '''
    tree = parse(source)

    variables = {'Klass': 'Klass_'}
    replace_result = VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:44:28.339131
# Unit test for function find_variables
def test_find_variables():
    source = 'let(x)\n' \
             'let(y)\n' \
             'if x < 1:\n' \
             '    y += 1'

    tree = ast.parse(source)
    names = find_variables(tree)

    assert list(names) == ['x', 'y']

# Generated at 2022-06-23 23:44:36.249994
# Unit test for function let
def test_let():
    x = 2
    y = 3

    @snippet
    def function():
        let(x)
        x += 1

        let(y)
   
    assert function().get_body() == [ast.AugAssign(target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()), op=ast.Add(), value=ast.Num(n=1)),
                                     ast.Assign(targets=[ast.Name(id='_py_backwards_y_1', ctx=ast.Store())], value=ast.Num(n=3))]

    @snippet
    def function():
        let(x)
        x += 1

        let(y)
        y += 1
   

# Generated at 2022-06-23 23:44:41.718682
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse("""
    def x(a, b):
        return a
    """)

    variables = {'a': '_'}

    inst = VariablesReplacer(variables)
    inst.visit(tree)

    assert(tree.body[0].args.args[0].id == '_')



# Generated at 2022-06-23 23:44:51.959341
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    from .tree import get_class_by_name
    class A:
        pass
    class B:
        pass
    class C:
        pass

    a = A()
    b = B()
    c = C()

    tree = get_class_by_name(a, 'A')

    # Only name of class A should be replaced
    variables = {
        'A': b,
        'B': c,
        'C': a
    }

    new_tree = VariablesReplacer.replace(tree, variables)
    assert isinstance(new_tree, ast.ClassDef)
    assert new_tree.name == 'B'
    assert isinstance(new_tree.bases[0], ast.Name)
    assert new_tree.bases[0].id == 'C'

# Generated at 2022-06-23 23:44:52.736040
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda x: None)

# Generated at 2022-06-23 23:44:55.367453
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    node = ast.arg(arg='arg', annotation=None)
    node = VariablesReplacer.replace(node, {'arg': 'x'})
    assert isinstance(node, ast.arg)
    assert node.arg == 'x'

# Generated at 2022-06-23 23:44:56.253846
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-23 23:45:00.916374
# Unit test for function find_variables
def test_find_variables():
    source = """
    def foo():
        let(y)
        print('this should not change')
        let(x)
        x += 1
    foo()
    """
    tree = ast.parse(source)
    assert find_variables(tree) == ['y', 'x']



# Generated at 2022-06-23 23:45:02.077344
# Unit test for function extend

# Generated at 2022-06-23 23:45:02.740705
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-23 23:45:03.753839
# Unit test for method get_body of class snippet

# Generated at 2022-06-23 23:45:11.748643
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    from .test_tree import test_tree
    from .test_tree import test_tree_3
    from .test_tree import test_tree_4
    from .test_tree import test_tree_5
    from .test_tree import test_tree_6
    from .test_tree import test_tree_7
    from .test_tree import test_tree_8
    from .test_tree import test_tree_9

    a = ast.Name(id='a')
    b = ast.Name(id='b')
    c = ast.Name(id='c')
    func = ast.FunctionDef(name='func', args=ast.arguments(args=[]), body=[b])
    d = ast.FunctionDef(name='d', args=ast.arguments(args=[]), body=[b])

# Generated at 2022-06-23 23:45:21.078449
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = """
if x:
    y = c(z='asd')
"""
    tree = ast.parse(source)
    variables = {"z": "x", "c": "d"}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=[If(test=Name(id='x', ctx=Load()), body=[Assign(targets=[Name(id='y', ctx=Store())], value=Call(func=Name(id='d', ctx=Load()), args=[], keywords=[keyword(arg='x', value=Str(s='asd'))]))], orelse=[])])"

# Generated at 2022-06-23 23:45:26.353231
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test case for method `get_body` of class `snippet`."""
    ast.parse('x = 1')
    code = lambda x: x + 1
    snippet_code = snippet(code).get_body(x=ast.Name(id='x'))
    assert len(snippet_code) == 1
    assert snippet_code[0].value.left.id == '_py_backwards_x_0'

    snippet_code = snippet(code).get_body(x=ast.Name(id='x'))
    assert len(snippet_code) == 1
    assert snippet_code[0].value.left.id == '_py_backwards_x_0'



# Generated at 2022-06-23 23:45:29.099123
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast

    def test(var, name):
        alias = ast.alias(name=name, asname=None)
        VariablesReplacer.replace(alias, {'name': var})
        assert alias.name == var

    test("test", "name")



# Generated at 2022-06-23 23:45:32.462619
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import_node = ast.parse('from . import a').body[0]
    variable = {'a': 'b'}
    actual = VariablesReplacer.replace(import_node, variable)
    expected = ast.parse('from . import b').body[0]
    assert ast.mod_compare(expected, actual)

# Generated at 2022-06-23 23:45:34.465459
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # Given
    variables = {'Class': ast.Name('A')}

# Generated at 2022-06-23 23:45:44.652807
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class Visitor(ast.NodeVisitor):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

        def visit_Name(self, node: ast.Name) -> ast.Name:
            return node

    class Replacer(VariablesReplacer):
        def __init__(self, variables: Dict[str, str]) -> None:
            self._variables = variables

    tree = ast.parse("def foo():pass")
    variables = {'foo': 'bar'}
    replacer = Replacer(variables)
    replacer.visit(tree)

    func = Visitor().visit(tree)
    assert func.name.id == 'bar'



# Generated at 2022-06-23 23:45:51.456464
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
let(single_statement)
a = 2
extend(single_statement)
a = 2
    '''
    tree = ast.parse(source)
    extend_tree(tree, {'single_statement': ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1))})
    source = '\n'.join([get_source(node) for node in tree.body])
    assert source == '''
a = 1
a = 2
    '''

# Generated at 2022-06-23 23:46:00.021810
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    # Test 1
    fn = \
        """
        def fn():
            let(x)
            x = 1
        """
    source = get_source(fn)
    tree = ast.parse(source)
    variables = dict(x = VariablesGenerator.generate('x'))
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert find(tree, ast.Name) == [], "There is free variables in snippet"

    # Test 2
    fn = \
        """
        def fn():
            let(x)
            extend(vars)
            print(x)
        """
    source = get_source(fn)
    tree = ast.parse(source)

# Generated at 2022-06-23 23:46:06.487595
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    test = "def f(x, y):\n    return\n"
    source = compile(test, '', 'exec', ast.PyCF_ONLY_AST)
    tree = source.body[0]  # type: ignore
    variables = {'y': ['a']}
    src = VariablesReplacer.replace(tree, variables).body[0].value.args[1]
    assert src.id == 'a'



# Generated at 2022-06-23 23:46:13.382596
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class DummyException(Exception):
        pass
    
    try:
        raise DummyException()
    except DummyException as e:
        var_name = str(e)
    
    tree = ast.parse("""try:
        pass
    except Exception as e:
        print(str(e))""")
    
    variables = {var_name: str(10)}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    
    expected_tree = ast.parse("""try:
        pass
    except Exception as e:
        print(str(10))""")
    
    assert tree == expected_tree

# Generated at 2022-06-23 23:46:18.833090
# Unit test for constructor of class snippet
def test_snippet():
    import inspect as ins
    import numpy as np

    def snippet_function():
        let(x)
        print(y)

    snippet_instance = snippet(snippet_function)

    assert(snippet_instance._fn == snippet_function)
    assert(ins.getsourcelines(snippet_function) == ins.getsourcelines(snippet_instance._fn))



# Generated at 2022-06-23 23:46:27.699076
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    # SOURCE: https://stackoverflow.com/questions/34169427/ast-module-parse-failure-on-yield-inside-generator
    s = 'def f(x):\n    for i in range(x):\n        yield i'
    tree = ast.parse(s)

    class Okay(ast.NodeVisitor):
        def __init__(self):
            self.seen = set()

        def visit_name(self, node):
            self.seen.add(node.id)
            self.generic_visit(node)

    visitor = Okay()
    visitor.visit(tree)
    unique_variable = VariablesGenerator.generate('unique')
    VariablesReplacer.replace(tree, {'x': unique_variable})
    assert unique_variable in visitor.seen

# Generated at 2022-06-23 23:46:33.594010
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_test():
        let(x)
        let(y)
        z = y
        extend(a)
        extend(b)

    with open("test/test_snippet_get_body.py", "r") as f:
        file = f.read()
        tree = ast.parse(file)
    assert snippet_test.get_body() == tree.body[0].body  # type: ignore

# Generated at 2022-06-23 23:46:42.529274
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse("let(x); x += 1; if something: y += 1"))) == ['x']
    assert list(find_variables(ast.parse("x = 1"))) == []
    assert list(find_variables(ast.parse("let(x); let(y); x = 1"))) == ['x', 'y']
    assert list(find_variables(ast.parse("let(x); let(y); x = 1; x = 1"))) == ['x', 'y']
    assert list(find_variables(ast.parse("let(x); let(x); x = 1; x = 1"))) == ['x']


# Generated at 2022-06-23 23:46:51.612934
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    x, y, z = VariablesGenerator.generate('x'), VariablesGenerator.generate('y'), VariablesGenerator.generate('z')

    tested_code = """
    try:
        pass
    except Exception as e:
        pass
    """

    expected_code = """
    try:
        pass
    except Exception as e_{}:
        pass
    """.format(y)

    variables = {
        'e': y
    }

    tree = ast.parse(tested_code)
    VariablesReplacer.replace(tree, variables)
    obtained_code = ast.unparse(tree)
    assert obtained_code == expected_code

# Generated at 2022-06-23 23:47:00.515563
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    source = """\
    def some_function1(x, *args, **kwargs):
        return x
    
    
    def some_function2(a, b, c, d):
        return a + b + c + d
    """

    tree = ast.parse(source)
    variables = {'x': VariablesGenerator.generate('x'),
                 'a': VariablesGenerator.generate('a')}
    VariablesReplacer.replace(tree, variables)
    result = ast.dump(tree, include_attributes=True)

# Generated at 2022-06-23 23:47:05.643257
# Unit test for function let
def test_let():
    @snippet
    def _():
        let(x)
        x += 1
        y = 1
    
    x, y = _.get_body()
    assert get_source(x).strip() == '_py_backwards_x_0 += 1'
    assert get_source(y).strip() == 'y = 1'



# Generated at 2022-06-23 23:47:14.649926
# Unit test for function extend
def test_extend():
    def test():
        def inner():
            extend(vars)
            print(a, b)
        vars = [
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=1),
            ),
            ast.Assign(
                targets=[ast.Name(id='b', ctx=ast.Store())],
                value=ast.Num(n=2),
            ),
            ast.Assign(
                targets=[ast.Name(id='c', ctx=ast.Store())],
                value=ast.Num(n=2),
            ),
        ]
        inner()
    tree = ast.parse(inspect.getsource(test))
    # Need to use tree from test function to test snippet
    inner_tree = tree

# Generated at 2022-06-23 23:47:25.473117
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    from pybackwards.finder import find
    from pybackwards.tests import test_helpers
    from pybackwards.variables import VariablesReplacer
    from pybackwards.tree import get_source

    class TestCase(test_helpers.TestCase):
        def test_keyword(self):
            def add(x=1, y=2):
                return x + y

            ast_node = ast.parse(get_source(add))
            variables = {'x': 2, 'y': 3}
            VariablesReplacer.replace(ast_node, variables)
            kwargs = find(ast_node, ast.keyword)
            self.assertEqual(len(kwargs), 2)
            self.assertEqual(len([kw for kw in kwargs if kw.arg == 'x']), 1)

# Generated at 2022-06-23 23:47:34.217940
# Unit test for function extend
def test_extend():
    def test_f():
        extend(x)  # type: ignore
        print(x)
        print(y)


# Generated at 2022-06-23 23:47:37.640433
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('def a():\n    pass')
    variables = {'a': 'b'}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].name == 'b'

# Generated at 2022-06-23 23:47:48.642992
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    print("Testing VariablesReplacer...", end="")
    assert VariablesReplacer.replace(
        ast.parse("def f(a, b):\n    a = b\n    return a + b").body[0],
        {'a': 'b', 'b': 'a'},
    ) == ast.parse("def f(b, a):\n    b = a\n    return b + a").body[0]
    assert VariablesReplacer.replace(
        ast.parse("def f():\n    print(a)").body[0],
        {'a': 'b'},
    ) == ast.parse("def f():\n    print(b)").body[0]

# Generated at 2022-06-23 23:47:53.836061
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def s():
        let(x)
        x = 1
        y = 2
        return (x, y)

    assert s.get_body() == [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1),
                                       type_comment=None),
                            ast.Assign([ast.Name('y', ast.Store())], ast.Num(2),
                                       type_comment=None)]



# Generated at 2022-06-23 23:48:04.811969
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    import astor
    source = 'def f():\n\tclass Foo:\n\t\tx = 1\n\treturn Foo.x\n'
    tree = ast.parse(source)
    VariablesReplacer.replace(
        tree, {'Foo': '_py_f_Foo_0', 'Foo.x': '_py_f_Foo_0.x_0'})
    expected = 'def f():\n\tclass _py_f_Foo_0:\n\t\t' \
        'x_0 = 1\n\treturn _py_f_Foo_0.x_0\n'
    assert astor.to_source(tree) == expected



# Generated at 2022-06-23 23:48:09.851365
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("call(a=1, b='b1')")
    variables = {'b1': VariablesGenerator.generate('b1')}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "call(a=1, b='{}')".format(variables['b1'])



# Generated at 2022-06-23 23:48:13.618263
# Unit test for function find_variables
def test_find_variables():
    source = """
let(x)
print(x)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x']


# Generated at 2022-06-23 23:48:14.831859
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda: None)

# Generated at 2022-06-23 23:48:25.203385
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    var_generator = VariablesGenerator()
    source_tree = ast.parse("""
    def wrapping_func(func):
        def wrapped_func(*args):
            return func(*args)
        return wrapped_func
    """)
    variables = {
        'func': var_generator.generate('func')
    }
    body = VariablesReplacer.replace(source_tree.body, variables).body
    # Make sure that wrapped_func got renamed to a unique name
    assert not isinstance(body[0].body[1].name, ast.Name)
    # Make sure that func inside the wrapped_func got renamed to the right name
    assert isinstance(body[0].body[1].body[1].args[1].elts[0].func, ast.Name)
    assert body[0].body[1].body

# Generated at 2022-06-23 23:48:34.381668
# Unit test for function extend
def test_extend():
    x = ast.parse('x = 1')
    y = ast.parse('x = 2')
    vars = {'x': x, 'y': y}
    code = extend(vars)
    body = code.get_body(vars=vars)
    assert isinstance(body, list) and len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert body[0].value.n == 1
    assert body[1].value.n == 2


# Generated at 2022-06-23 23:48:38.259994
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    # given
    node = ast.Name(id='name', ctx=ast.Load())

    # when
    result = VariablesReplacer._replace_field_or_node(node, 'id', all_types=True)

    # then
    assert result == 'name'


# Generated at 2022-06-23 23:48:43.367555
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    value = {'exception': 'my_exception'}
    tree = ast.parse('raise exception')
    tree = VariablesReplacer.replace(tree, value)
    assert get_source(tree) == 'raise my_exception'

# Generated at 2022-06-23 23:48:48.399920
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    let(z)

    x = 1
    y = 2
    z = y + x
    '''
    tree = ast.parse(source)
    next(find_variables(tree))
    next(find_variables(tree))
    next(find_variables(tree))



# Generated at 2022-06-23 23:48:57.882108
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 0
    y = 0
    s = snippet(lambda: ((x, y), (x, y)))
    body = s.get_body()
    assert len(body) == 3
    assert isinstance(body[1], ast.Print)
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[2], ast.Assign)
    assert body[0].targets[0].id == 'x'
    assert body[2].targets[0].id == 'y'
    assert body[0].value.value == 0
    assert body[2].value.value == 0
    assert isinstance(body[1].value.values[0], ast.Name)
    assert isinstance(body[1].value.values[1], ast.Name)

# Generated at 2022-06-23 23:49:03.473970
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    import unittest
    import sys
    import io

    saved_stdout = sys.stdout

# Generated at 2022-06-23 23:49:12.800481
# Unit test for function let
def test_let():
    @snippet
    def snippet_1():
        let(x)
        x += 1
        y = 1

    assert snippet_1.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                            op=ast.Add(),
                            right=ast.Num(n=1))),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1))
    ]



# Generated at 2022-06-23 23:49:19.513391
# Unit test for function extend_tree
def test_extend_tree():
    code = """
    extend(vars)
    print(x, y)
    """
    tree = ast.parse(code)
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                           value=ast.Num(n=1)),
                               ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                          value=ast.Num(n=2))]})
    expected = """
    x = 1
    x = 2
    print(x, y)
    """
    compiled = compile(tree, filename="<ast>", mode="exec")
    assert(expected.strip() == compiled.strip())

# Generated at 2022-06-23 23:49:20.649836
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet


# Generated at 2022-06-23 23:49:26.486777
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("""from a import b, c as d""")
    variables = {
        'a': 'a.b.c',
        'b': 'b.c',
        'd': 'd',
        }
    replaced_tree = VariablesReplacer.replace(tree, variables)
    assert str(replaced_tree) == str(ast.parse("""from a.b.c import a.b.c as b.c, c as d"""))  # noqa



# Generated at 2022-06-23 23:49:33.767910
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    for case in [
        # key_with_value, expected_key_with_value
        ('key', 'key'),
        ('x', 'y')
        ]:
        key, expected_key = case
        tree = ast.parse(f'parse_kwargs(x, {key}=1)')
        replacer = VariablesReplacer({'x': 'y'})
        actual_key = replacer.visit(tree.body[0].value).keywords[0].arg
        assert actual_key == expected_key, f'{actual_key} != {expected_key}'

# Generated at 2022-06-23 23:49:39.963060
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    simple_tree = ast.parse('def foo(a, b, c):\n    print(1)')
    variables = {'a': ('_a', 'b', 'c')}
    replacer = VariablesReplacer(variables)
    replacer.visit(simple_tree)
    assert simple_tree.body[0].args.args == [ast.arg('_a', None), ast.arg('b', None), ast.arg('c', None)]

# Generated at 2022-06-23 23:49:51.296758
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    source = "class A: def f(self): print(self.name)"
    tree = ast.parse(source)
    variables = {"self": "self1"}
    inst = VariablesReplacer(variables)
    inst.visit(tree)

# Generated at 2022-06-23 23:49:58.217837
# Unit test for function let
def test_let():
    @snippet
    def let_test():
        let(x)
        x += 1
        y = 1

    body = let_test.get_body()

    assert body[0].value.args[1].id == '_py_backwards_x_0'
    assert body[1].value.id == 'y'



# Generated at 2022-06-23 23:50:08.803191
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: int, y: str, z: float) -> None:
        let(x)
        let(y)
        x += 1
        y += 'a'
        z += 1.0
        print(x, y, z)

    body = fn.get_body(x=ast.Name(id='_py_backwards_x_0'),
                       y=ast.Name(id='_py_backwards_y_0'),
                       z=ast.Name(id='_py_backwards_z_0'))


# Generated at 2022-06-23 23:50:16.950214
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    # Arrange
    class1 = ast.Name(id='class1')
    class2 = ast.Name(id='class2')
    instance1 = ast.Name(id='instance1')
    instance2 = ast.Name(id='instance2')
    method1 = ast.Name(id='method1')
    method2 = ast.Name(id='method2')
    attribute1 = ast.Name(id='attribute1')
    attribute2 = ast.Name(id='attribute2')
    expr1 = ast.Call(func=ast.Attribute(value=instance1, attr=method1, ctx=ast.Load()), args=[], keywords=[])
    expr2 = ast.Call(func=ast.Attribute(value=instance2, attr=method2, ctx=ast.Load()), args=[], keywords=[])

    #

# Generated at 2022-06-23 23:50:27.233945
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    from .helpers import VariablesGenerator
    import ast as ast3
    class Test(VariablesReplacer):
        def visit_keyword(self, node: ast3.keyword) -> ast3.keyword:
            node = self._replace_field_or_node(node, 'arg')
            return self.generic_visit(node)  # type: ignore

    test = ast3.parse('test(arg=2, arg2=4)')
    variables = {'arg': VariablesGenerator.generate('arg')}
    test = Test.replace(test, variables)

    assert test.body[0].value.keywords[0].arg == 'arg'
    assert test.body[0].value.keywords[0].value.n == 2

# Generated at 2022-06-23 23:50:28.819235
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    ast.Attribute(value='var', attribute='id', _fields=['value', 'attr'])



# Generated at 2022-06-23 23:50:36.125140
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class a:
        def __init__(self, x: int) -> None:
            self.x = x

    class b:
        def __init__(self, x: int) -> None:
            self.x = x

    to_vars = {"a": "b", "x": "y"}
    class_a = a(x=1)
    class_b = b(x=2)

    var_replacer = VariablesReplacer(to_vars)
    assert var_replacer._replace_field_or_node(class_a, "x") == b(x=1)
    assert var_replacer._replace_field_or_node(class_b, "x") == b(x=2)

# Generated at 2022-06-23 23:50:39.710432
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    def test(x: int) -> int:
        try:
            return x + 1
        except Exception as e:
            return x - 1

    tree = ast.parse(get_source(test))
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name)
                 for name in names}
    VariablesReplacer.replace(tree, variables)
    exec(compile(tree, '<string>', 'exec'))
    assert test(1) == 2

# Generated at 2022-06-23 23:50:47.629616
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = """
from my_package import some_var as my_var
    """
    tree = ast.parse(source)
    variables = {'my_package': 'my_package_replacement'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=[ImportFrom(module='my_package_replacement', names=[alias(name='some_var', asname='my_var')], level=0)])"



# Generated at 2022-06-23 23:50:53.602155
# Unit test for function extend
def test_extend():
    def f():
        extend(vars)
        print(x, y)

    vars = [ast.Assign([ast.Name('x')], ast.Num(1)),
            ast.Assign([ast.Name('x')], ast.Num(2))]

    snippet(f).get_body(vars=vars)


# Useful function to create snippets that don't use locals:

# Generated at 2022-06-23 23:51:04.046388
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import unittest

    class VariablesReplacerTests(unittest.TestCase):
        def test_visit_alias(self):
            alias = ast.alias(name="Namespace", asname=None)
            variables = {"Namespace": "i"}
            expect = ast.alias(name="i", asname=None)
            actual = VariablesReplacer.replace(alias, variables)
            self.assertEqual(actual, expect)

        def test_visit_alias_asname(self):
            alias = ast.alias(name="Namespace", asname="T")
            variables = {"Namespace": "i"}
            expect = ast.alias(name="i", asname="T")
            actual = VariablesReplacer.replace(alias, variables)
            self.assertEqual(actual, expect)

# Generated at 2022-06-23 23:51:14.638452
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class TestClass:
        def __init__(self):
            self._x = 1

    tree = compile("class TestClass:\n  def __init__(self):\n    self._x = 1", filename='<ast>', mode='exec', flags=0, dont_inherit=False)
    tree = ast.parse(get_source(TestClass))
    variables = {"TestClass": "TestClass_0", "self": "self_0"}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)

# Generated at 2022-06-23 23:51:15.546923
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:51:23.180513
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.parse(
        "from a import b\n"
        "from a.b import c\n"
        "from a.b import c as c1\n"
        "from a.b.c.d import e\n"
        "from a.b.c.d import e as e1\n"
        "import a\n"
        "import a.b\n"
        "import a.b as b1\n"
        "import a.b.c\n"
        "import a.b.c as c1\n"
    )

# Generated at 2022-06-23 23:51:32.346687
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    var_replacer = VariablesReplacer({"x": "y"})
    assert var_replacer.visit_Attribute(ast.Attribute(value=ast.Name(id="x",
                                                                     ctx=ast.Load()),
                                                      attr="z",
                                                      ctx=ast.Load())) == ast.Attribute(value=ast.Name(id="y", 
                                                                                                         ctx=ast.Load()),
                                                                                         attr="z",
                                                                                         ctx=ast.Load())


# Generated at 2022-06-23 23:51:42.787031
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    a = ast.parse('x = 5')
    b = ast.parse('y = 4')
    c = ast.parse('y')
    d = ast.parse('z = t')
    e = ast.parse('z = t + a')
    f = ast.parse('def z():\n    pass')
    g = ast.parse('class z:\n    pass')
    h = ast.parse('from ml_hackaton import z\nfrom ml_hackaton.a import z')
    i = ast.parse('import os.path as z\nfrom ml_hackaton import b as z')
    j = ast.parse('print(x)')
    k = ast.parse('print(x, y)')
    l = ast.parse('raise A as z\nexcept B as z')

# Generated at 2022-06-23 23:51:47.401646
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    t = ast.parse("""
    try:
        pass
    except ValueError as a:
        pass
    except ValueError as b:
        pass
    """)
    variables = {'a': 'z'}
    VariablesReplacer.replace(t, variables)

    # If a = b = c = 1, b = 2, c = 3
    # If a = b = c = 1, b = 2, c = 3
    # b = 2
    # c = 3

    for i in t.body[0].body[1].body:
        print(i)



# Generated at 2022-06-23 23:51:51.170353
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    source = dedent("""\
        def foo(a, b, c):
            pass
        """)
    tree = ast.parse(source)
    variables = {'a': 'foo', 'b': 'bar', 'c': 'baz'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree.body) == dedent("""\
        def foo(foo, bar, baz):
            pass
        """)


# Generated at 2022-06-23 23:51:57.003381
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class C:
        pass
    
    tree = ast.parse('class C: pass')
    VariablesReplacer.replace(tree, {'C': C})
    tree = ast.parse('class D: pass')
    VariablesReplacer.replace(tree, {'C': C})
    return tree

# Generated at 2022-06-23 23:52:01.985946
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse('try:\n pass\nexcept Exception:\n    pass\n')
    variables = {'Exception': 'MyException'}
    VariablesReplacer.replace(tree, variables)

    expected_tree = ast.parse('try:\n pass\nexcept MyException:\n    pass\n')
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:52:10.009787
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    def foo(x:str, y:str) -> str:
        return x+y

    # test1
    tree = ast.AST(
            body=[ast.FunctionDef(
                    name='foo',
                    args=ast.arguments(
                        args=[ast.arg(arg='x', annotation=None), ast.arg(arg='y', annotation=None)]
                        ),
                    body=[ast.Return(value=ast.BinOp(left=ast.Name(id='x'), op=ast.Add(), right=ast.Name(id='y')))]
                    )]
            )
    variables = {'x': ast.Name(id='a'), 'y': ast.Name(id='b')}
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-23 23:52:14.480988
# Unit test for function extend
def test_extend():
    a = 1
    snippet_func2 = snippet(lambda: extend({"a": 2}))
    for node in snippet_func2.get_body():
        exec(compile(node, filename=__file__, mode='exec'))
    assert a == 2



# Generated at 2022-06-23 23:52:21.934518
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    from .helpers import VariablesGenerator
    from .tree import ClassDef
    from .types import FunctionDef

    func = FunctionDef("foo", [], [], [])
    func.args.append(ClassDef("foo", [], []))
    func.decorator_list.append(ClassDef("foo", [], []))
    code = ast.Module([func])
    var_gen = VariablesGenerator()
    replacer = VariablesReplacer({
        "foo": var_gen.generate("foo"),
    })
    replacer.visit(code)
    assert code

# Generated at 2022-06-23 23:52:29.112953
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    classdef = ast.ClassDef(name='Const', body=[], decorator_list=[])
    cls = VariablesReplacer(variables={'Const': ast.Name(id='Variable', ctx=ast.Load())})
    new_classdef = cls.visit_ClassDef(classdef)
    assert(new_classdef.name == 'Variable') and (new_classdef.body == []) and (new_classdef.decorator_list == [])


# Generated at 2022-06-23 23:52:30.245099
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-23 23:52:39.788606
# Unit test for function extend_tree
def test_extend_tree():
    def f():
        extend(vars)
        print(x, y + z)

    x, y, z = ast.Name('x', ast.Store()), ast.Name('y', ast.Store()), ast.Name('z', ast.Store())
    vars = [
        ast.Assign([x], ast.Num(1)),
        ast.Assign([x], ast.Num(2)),
        ast.Assign([y], ast.Num(1)),
        ast.Assign([z], ast.Num(1)),
    ]

    result = ast.parse(get_source(f)).body[0].body
    assert len(result) == 4
    assert result[0].value.args[0] == 'x'
    assert result[1].value.args[0] == 'y'

# Generated at 2022-06-23 23:52:47.256287
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse("def foo(fn): pass")  # type: ignore
    variables = {"foo": "bar"}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='bar', args=arguments(args=[arg(arg='fn', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])"  # noqa



# Generated at 2022-06-23 23:52:50.882987
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    func_def = ast.parse("""def x(text): print(text)""").body[0]
    variables = {"text": "name"}
    replacer = VariablesReplacer(variables)
    replacer.visit_arg(func_def.args.args[0])
    assert(func_def.args.args[0].arg == "name")

# Generated at 2022-06-23 23:52:57.578041
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nx = 1')
    class_decl = ast.ClassDef(name='class_x', bases=[], keywords=[], body=[], decorator_list=[])
    extend_tree(tree, {'vars': class_decl})
    assert ast.dump(tree) == ast.dump(ast.parse('x = 1\nclass_x = class()'))