

# Generated at 2022-06-23 23:42:57.223851
# Unit test for function extend_tree
def test_extend_tree():
    def f():
        extend(vars)
        print(x, y)
    vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2))]
    tree = f.__code__.co_consts[0].body[0]
    extend_tree(tree, {'vars': vars})

    assert tree.body[0].value.n == 1
    assert tree.body[1].value.n == 2

    vars = {'test': ast.Num(5)}
    tree = f.__code__.co_consts[0].body[0]
    extend_tree(tree, vars)

# Generated at 2022-06-23 23:43:01.193118
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    z = 3
    def foo(bar):
        let(x)
        extend(y)
        let(z)
        print(x, y, z)

    print("foo.get_body(y=5, z=5):\n", foo.get_body(y=5, z=5))



# Generated at 2022-06-23 23:43:07.980391
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class MyClass:
        def this_is_my_method(self):
            return None
    variables = dict()
    variables['MyClass'] = MyClass
    class_def = ast.parse('class MyClass:').body[0]
    VariablesReplacer.replace(class_def, variables)
    assert isinstance(class_def, ast.ClassDef)
    assert class_def.name == 'MyClass'
    assert isinstance(class_def.bases[0], ast.Name)
    assert class_def.bases[0].id == 'object'



# Generated at 2022-06-23 23:43:17.691362
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import py_backwards
    
    @snippet
    def f():
        let(x)
        x = 1
        import py_backwards
        from py_backwards import snippet
        from py_backwards.backwards import let
    
    
    # replacement
    tree = ast.parse(get_source(f))
    variables = find_variables(tree)  # type: ignore
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    # expected
    expected = ast.parse('\n'.join(['import _py_backwards_x_0',
                                    'x = 1'
                                    ]))
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-23 23:43:18.836095
# Unit test for function extend_tree

# Generated at 2022-06-23 23:43:25.468412
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class TestTransformer(ast.NodeTransformer):
        def __init__(self) -> None:
            self.result = None

        def visit_Attribute(self, node: ast.Attribute) -> ast.Attribute:
            # type: ignore
            self.result = node

    node = ast.parse("node.attr").body[0].value
    transformer = TestTransformer()
    transformer.visit(node)
    assert transformer.result is node

# Generated at 2022-06-23 23:43:34.160187
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    import inspect
    import ast

    class MyClass(object):
        def __init__(self):
            pass

        def visit_Name(self, node):
            return node

        def visit_FunctionDef(self, node):
            return node

        def visit_Attribute(self, node):
            return node

        def visit_keyword(self, node):
            return node

        def visit_ClassDef(self, node):
            return node

        def visit_arg(self, node):
            return node

        def visit_ImportFrom(self, node):
            return node

        def visit_alias(self, node):
            return node

        def visit_ExceptHandler(self, node):
            return node


# Generated at 2022-06-23 23:43:41.041097
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    root = ast.parse('{x: 1, y: 2}')
    replace = VariablesReplacer.replace(root, {'x': 'a'})
    assert(ast.dump(replace) == "{'a': 1, 'y': 2}")
    root = ast.parse('{x: 1}')
    replace = VariablesReplacer.replace(root, {})
    assert(ast.dump(replace) == "{'x': 1}")


# Generated at 2022-06-23 23:43:46.694148
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
	tree = ast.parse("""
import os
os.name
""")
	variables = {'os': 'other_os'}
	VariablesReplacer.replace(tree, variables)
	assert isinstance(tree.body[0], ast.Import)
	assert tree.body[1].value.attr == 'name'
	assert ast.dump(tree) == "Module([Import([alias(name='os', asname=None)]), Expr(value=Attribute(value=Name(id='other_os', ctx=Load()), attr='name', ctx=Load()))])"

# Generated at 2022-06-23 23:43:50.323609
# Unit test for function extend_tree
def test_extend_tree():
    from .test_snippet import extend_tree_test_tree
    extend_tree(extend_tree_test_tree, {'m': [
        ast.parse('.test_var = 5').body[0],
        ast.parse('.test_var2 = 5').body[0]
    ]})

# Generated at 2022-06-23 23:43:51.002168
# Unit test for constructor of class snippet
def test_snippet():
    snippet(None)

# Generated at 2022-06-23 23:43:57.590190
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def s():
        let(x)
        x += 1
    assert ast.dump(s.get_body()) == "Module(body=[Assign(targets=[Name(id='_py_backwards_x_0', ctx=Store())], value=BinOp(left=Name(id='_py_backwards_x_0', ctx=Load()), op=Add(), right=Num(n=1)))])"

# Generated at 2022-06-23 23:44:04.528368
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    ast1 = ast.parse("from example import a, b")
    ast2 = ast.parse("import example")

    variables = {
        "example": ast.parse("import asd.zxc").body[0].names[0]
    }
    VariablesReplacer.replace(ast1, variables)
    VariablesReplacer.replace(ast2, variables)
    assert ast1.body[0].names[0].name == "asd.zxc"
    assert ast2.body[0].names[0].name == "asd.zxc"

# Generated at 2022-06-23 23:44:11.325404
# Unit test for function extend_tree
def test_extend_tree():
    def test(name: str, tree: ast.AST, expected: ast.AST) -> None:
        extend_tree(tree, {'extend': expected})
        assert ast.dump(expected) == ast.dump(tree)

    test('extend path', ast.parse('extend(d)').body[0], ast.parse('d').body[0])
    test('extend function', ast.parse('extend(f)').body[0], ast.parse('f').body[0])
    test('extend class', ast.parse('extend(c)').body[0], ast.parse('c').body[0])
    test('extend if', ast.parse('extend(i)').body[0], ast.parse('i').body[0])

# Generated at 2022-06-23 23:44:23.331868
# Unit test for function extend
def test_extend():
    import random
    import astor
    def random_func():
        x = random.random()
        print(x)
    source = get_source(random_func)
    tree = ast.parse(source)
    vars_to_extend = ast.parse('x = 1')
    extend_tree(tree, {'vars': vars_to_extend.body})

# Generated at 2022-06-23 23:44:30.367044
# Unit test for function extend
def test_extend():
    def snippet(x):
        x = 1
        x += 2
        x = 3
        extend(x)
        return x

    code = snippet.get_body()

    assert isinstance(code[0], ast.Assign)
    assert code[0].value.n == 1
    assert isinstance(code[1], ast.AugAssign)
    assert code[1].value.n == 2
    assert isinstance(code[2], ast.Assign)
    assert code[2].value.n == 3

# Generated at 2022-06-23 23:44:32.947432
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    variables = {}
    VariablesReplacer.replace(AstNodes.except_handler, variables)
    assert str(AstNodes.except_handler) == 'except Exception as e:\n    pass'

# Generated at 2022-06-23 23:44:33.850416
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda: None)

# Generated at 2022-06-23 23:44:37.083392
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    ast_code = ast.parse('from foo import bar')
    variables = {"foo": "foo_new"}

    t = VariablesReplacer.replace(ast_code, variables)
    assert t.body[0].module == "foo_new"



# Generated at 2022-06-23 23:44:43.465197
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import astor
    from textwrap import dedent
    code = dedent(
        """
        class A:
            def method(self):
                self.attr = 10
        """
    )

    tree = astor.parse_file(StringIO(code))
    VariablesReplacer.replace(tree, {'self': 'self'})
    assert astor.to_source(tree).strip() == code.strip()

# Generated at 2022-06-23 23:44:50.150205
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def foo(x):
        let(x)
        return x+1

    @snippet
    def bar():
        x = 1
        let(x)
        return x+1

    @snippet
    def baz():
        let(x)
        return x+1

    assert foo.get_body(x=4) == bar.get_body(x=4) == baz.get_body(x=4)

# Generated at 2022-06-23 23:44:53.770149
# Unit test for function extend
def test_extend():
    import pytest
    vars = ast.parse("x = 1\nx = 2").body
    code = ast.parse("extend(vars)\nprint(x, y)")
    extend_tree(code, {"vars": vars})
    assert ast.dump(code) == ast.dump(ast.parse("x = 1\nx = 2\nprint(x, y)"))


# Generated at 2022-06-23 23:44:59.367484
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    test_source = """def f(x: int, y: int = 2, *, z: int = 3, w: int = 4):
    pass
    """
    test_tree = ast.parse(test_source)
    variables = {'x': '_py_backwards_x_0',
                 'y': '_py_backwards_y_1',
                 'z': '_py_backwards_z_2',
                 'w': '_py_backwards_w_3'}
    transformed_tree = VariablesReplacer.replace(test_tree, variables)

# Generated at 2022-06-23 23:45:05.975917
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    # Arrange
    ast_tree = ast.parse("""
    x = 1
    """)
    replacer = VariablesReplacer({"x": "y"})

    # Act
    replacer.visit(ast_tree)

    # Assert
    assert ast.dump(ast_tree) == "Module(body=[Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=1))])"



# Generated at 2022-06-23 23:45:07.005277
# Unit test for function extend_tree

# Generated at 2022-06-23 23:45:16.557372
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    test_str = '''
    from test_project.test_pack import test_module
    '''
    tree = ast.parse(test_str)
    variables = {'test_project': 'test_project1', 'test_pack': 'test_pack1', 'test_module': 'test_module1'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    result = ast.dump(tree)
    result_str = '''Module(body=[ImportFrom(module='test_project1.test_pack1', names=[alias(name='test_module1', asname=None)], level=0)])'''
    assert result == result_str

# Generated at 2022-06-23 23:45:22.990104
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
  my_code = "import a.b.c\n" \
    "x = a.b.c.d\n" \
    "class my_class(a.b.c.e):\n" \
    "    def __init__(self):\n" \
    "        pass\n" \
    "def my_func(a_p, b_p=a.b.c.f):\n" \
    "    pass\n" \
    "y = a.b.c.g.h\n"
  expected_my_code = "import a.b.c\n" \
    "x = a.b.c.d\n" \
    "class my_class(a.b.c.e):\n" \
    "    def __init__(self):\n"

# Generated at 2022-06-23 23:45:30.474968
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    code = """
    def func():
        pass
    """
    tree = ast.parse(code)
    variables = {'func_start': 'new_func'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='new_func', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])," \
                             " decorator_list=[], body=[Pass()], returns=None)])"

# Generated at 2022-06-23 23:45:36.329347
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    class Node:
        def __init__(self, name, id=None, module=None):
            self.name = name
            self.id = id
            self.module = module

        def func(self):
            return Node('func')

    class FunctionDef(Node):
        def __init__(self, name, **kwargs):
            super().__init__('FunctionDef', **kwargs)
            self.name = name

    class Call(Node):
        def __init__(self, function: Node, args: List[Node]):
            super().__init__('Call')
            self.func = function
            self.args = args

    import_from = Node('ImportFrom')

    from .helpers import get_mock_tree
    mock_tree = get_mock_tree()


# Generated at 2022-06-23 23:45:38.535068
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    input_ast = ast.Name(id='x', ctx=ast.Load())
    variables = {'x': '_py_backwards_x_0'}
    result = VariablesReplacer.replace(input_ast, variables)
    assert isinstance(result, ast.Name)
    assert result.id == '_py_backwards_x_0'

# Generated at 2022-06-23 23:45:41.818917
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    node = ast.ExceptHandler()
    node.name = 'a'
    node = VariablesReplacer.replace(node, {'a': 'b'})
    assert node.name == 'b'



# Generated at 2022-06-23 23:45:42.802025
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    pass



# Generated at 2022-06-23 23:45:50.406862
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    a = ast.Name(id='a', ctx=ast.Load())
    a0 = ast.Name(id='a_0', ctx=ast.Load())
    b = ast.Name(id='b', ctx=ast.Load())
    c = ast.Name(id='c', ctx=ast.Load())
    plus = ast.BinOp(left=a0, op=ast.Add(), right=b)
    leta = ast.Call(func=ast.Name(id='let', ctx=ast.Load()), args=[a], keywords=[])
    letc = ast.Call(func=ast.Name(id='let', ctx=ast.Load()), args=[c], keywords=[])
    assign = ast.Assign(targets=[c], value=plus)

# Generated at 2022-06-23 23:45:59.263600
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('x = y')
    VariablesReplacer.replace(tree, {})
    assert get_source(tree) == 'x = y'
    tree = ast.parse('x = y')
    VariablesReplacer.replace(tree, {'y': 'z'})
    assert get_source(tree) == 'x = z'
    tree = ast.parse('x = y')
    VariablesReplacer.replace(tree, {'y': ast.parse('z')})
    assert get_source(tree) == 'z'
    tree = ast.parse('import y')
    VariablesReplacer.replace(tree, {'y': 'z'})
    assert get_source(tree) == 'import z'
    tree = ast.parse('from a import b')

# Generated at 2022-06-23 23:46:03.916535
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    x = ast.Name(id='x', ctx=ast.Load())
    x1 = ast.Name(id='_x', ctx=ast.Load())
    x2 = ast.Name(id='_x', ctx=ast.Load())


# Generated at 2022-06-23 23:46:10.016723
# Unit test for function let
def test_let():
    from .helpers import as_ast, as_source
    from .tree import compare
    from .snippet import snippet, let

    @snippet
    def add():
        let(x)
        let(y)
        x += y
        return x ** 2

    assert compare(add(), as_ast('let(x); let(y); _py_backwards_x_0 += _py_backwards_y_0; return _py_backwards_x_0 ** 2'))

# Generated at 2022-06-23 23:46:17.899726
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('''
        class A:
            def foo(self, x):
                print(x)
                self.bar()

            def bar(self):
                pass
    ''')
    replacer = VariablesReplacer(
        {'A': '_py_backwards_A_0', 'foo': '_py_backwards_foo_1', 'x': '_py_backwards_x_2'}
    )
    replacer.replace(tree, {'A': '_py_backwards_A_0', 'foo': '_py_backwards_foo_1', 'x': '_py_backwards_x_2'})
    assert ast.dump(replacer.tree) == ast.dump(tree)

# Generated at 2022-06-23 23:46:22.782593
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class TestClass():
        def __init__(self, tree):
            self.tree = tree
        def test(self):
            self.tree = VariablesReplacer.replace(self.tree, dict())
            assert True
    test = TestClass(ast.parse("a = 1"))
    test.test()


# Generated at 2022-06-23 23:46:28.724193
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    var = VariablesGenerator.generate('_local_variable')
    tree = ast.parse('var')

    assert get_source(tree) == 'var'
    assert 'var' in tree.body[0].body[0]._fields  # type: ignore
    assert tree.body[0].body[0].var.id == 'var'

    VariablesReplacer.replace(tree, {'_local_variable': var})

    assert 'var' not in tree.body[0].body[0]._fields  # type: ignore
    assert tree.body[0].body[0].id == var



# Generated at 2022-06-23 23:46:31.229960
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""let(x); let(y)""")

    assert list(find_variables(tree)) == ['x', 'y']


# TODO: add unit tests

# Generated at 2022-06-23 23:46:36.612686
# Unit test for function extend
def test_extend():
    class TestClass:
        @snippet
        def test_method(self):
            let(x)
            x = 1
            extend(vars)
            self.assertEqual(x, 2)

    TestClass.test_method.__wrapped__(vars=[ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=2))])



# Generated at 2022-06-23 23:46:42.694728
# Unit test for function extend_tree
def test_extend_tree():
    to_extend = [ast.parse("y = 2").body[0], ast.parse("x = 1").body[0]]
    dictionary = {"vars": to_extend}
    tree = ast.parse("extend(vars)\nprint(x, y)")
    extend_tree(tree, dictionary)
    assert get_source(tree) == "x = 1\nx = 2\nprint(x, y)"

# Generated at 2022-06-23 23:46:53.498089
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source1 = """
from x import y
from y import x
from x import y as a
from y import x as b
"""
    ast1 = ast.parse(source1)
    variables = {'x': 'z', 'y': 'z'}
    VariablesReplacer.replace(ast1, variables)

# Generated at 2022-06-23 23:46:58.908685
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("""from os import path""")
    variables = {'os': 'sys', 'path': 'os'}
    VariablesReplacer.replace(tree, variables)
    assert len(find(tree, ast.ImportFrom)) == 1
    node = find(tree, ast.ImportFrom)[0]
    assert node.module == 'sys'
    assert len(node.names) == 1
    assert node.names[0].name == 'os'


# Generated at 2022-06-23 23:47:08.965036
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def func():
        let(x)

    source = get_source(func)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name)
                 for name in names}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    s = ast.dump(tree)
    assert s == "Module(body=[FunctionDef(name='_py_backwards_x_0', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)])"



# Generated at 2022-06-23 23:47:15.166118
# Unit test for function let
def test_let():
    x = 5
    let(x)
    x += 1
    y = 1

    snippet_str = "let(x)\nx += 1\ny = 1"
    snippet_ = snippet(test_let)
    snippet_body = snippet_.get_body()
    snippet_body[0].body[0].value.value += 1
    ast_ = ast.parse(snippet_str).body[0].body
    assert list(snippet_body) == list(ast_)
    assert ast_[0].value.value == 6



# Generated at 2022-06-23 23:47:16.633684
# Unit test for function extend_tree

# Generated at 2022-06-23 23:47:23.209917
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(l)')
    expected = ast.parse('a = 1\n'
                         'b = 2\n')
    extend_tree(tree, {'l': expected.body})
    tree.body[0].body.append(ast.parse('c = 3').body[0])
    assert get_source(tree) == 'a = 1\n' \
                               'b = 2\n' \
                               'c = 3\n'

# Generated at 2022-06-23 23:47:29.664192
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    var = 'x'
    tree = ast.parse('def x():\n pass')

    assert isinstance(tree.body[0], ast.FunctionDef)
    VariablesReplacer.replace(tree.body[0], {var: '_py_backwards_x_0'})

    assert isinstance(tree.body[0], ast.FunctionDef)
    assert tree.body[0].name == '_py_backwards_x_0'


# Generated at 2022-06-23 23:47:33.853529
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    """
        This function tests whether the visit_alias method within
        the VariablesReplacer class works as expected.
    """
    tree = ast.parse('from mod import a')
    variables = {'mod': 'foo'}
    replacer = VariablesReplacer(variables)
    assert replacer.visit_alias(tree.body[0].names[0]) == ast.alias('foo', 'a', None)

# Generated at 2022-06-23 23:47:36.337940
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:47:39.000826
# Unit test for function find_variables
def test_find_variables():
    @snippet
    def foo():
        let(x)
        let(y)

    assert find_variables.result == {'x', 'y'}

# Generated at 2022-06-23 23:47:49.170255
# Unit test for function let
def test_let():
    source = '''
        def f(x):
            if x:
                y = 1
            let(y)
            print(y)
    '''
    tree = ast.parse(source)
    f_body = find(tree, ast.FunctionDef)[0].body
    variables = find_variables(tree)
    assert variables == {'y': ast.parse('_py_backwards_y')}

    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == '''
        def f(x):
            if x:
                y = 1
            _py_backwards_y = 1
            print(y)
    '''


# Generated at 2022-06-23 23:47:55.552467
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import unittest

    from .typed_ast_helpers import get_source, get_node
    from .typed_ast_helpers import VariablesReplacer

    class TestVariablesReplacer(unittest.TestCase):

        def check(self, code: str):
            alias = get_node(code, ast.alias)
            VariablesReplacer.replace(alias, {})
            self.assertEqual(get_source(alias), code)

        def test_alias(self):
            self.check('import a')
            self.check('import *')
            self.check('import a as b')

# Generated at 2022-06-23 23:47:56.778894
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet(lambda: "")



# Generated at 2022-06-23 23:48:04.503971
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    v = VariablesGenerator.generate('a')
    tree = ast.parse('def a(): pass')
    VariablesReplacer.replace(tree, {'a': v})
    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=%s, args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])' % v

# Generated at 2022-06-23 23:48:10.473416
# Unit test for function extend
def test_extend():
    def test(x: int) -> None:
        extend(x)
        x = 1
        print(x)

    body = snippet(test).get_body()
    assert len(body) == 1
    assert isinstance(body[0], ast.Assign)
    assert len(body[0].targets) == 1
    assert isinstance(body[0].targets[0], ast.Name)
    assert body[0].targets[0].id == 'x'

# Generated at 2022-06-23 23:48:11.763832
# Unit test for function extend_tree

# Generated at 2022-06-23 23:48:16.356744
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def fn():
        def f():
            pass
        return f
    source = get_source(fn)
    tree = ast.parse(source)
    variables = {
        'f': '_py_backwards_f_0'
    }
    VariablesReplacer.replace(tree, variables)



# Generated at 2022-06-23 23:48:26.250009
# Unit test for function let
def test_let():
    """Unit tests for function let"""
    def code():
        let(a)
        return a

    def expected_tree(a, b, c):
        return ast.Return(
            value=a
        )

    trees = [expected_tree(
        ast.Name(id=a, ctx=ast.Load()),
        ast.Name(id=b, ctx=ast.Load()),
        ast.Name(id=c, ctx=ast.Load()),
    ) for a in VariablesGenerator.generate_many(3)
             for b in VariablesGenerator.generate_many(3)
             for c in VariablesGenerator.generate_many(3)]
    for expected_tree in trees:
        tree = ast.parse(get_source(code))

# Generated at 2022-06-23 23:48:33.838072
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    v = VariablesGenerator.generate('x')
    variables = {'x': v}
    node = ast.parse('f(x=x)', mode='eval').body.args[0]
    vr = VariablesReplacer(variables)
    vr.visit_keyword(node.keywords[0])
    assert node.keywords[0].arg == v



# Generated at 2022-06-23 23:48:38.392110
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    src = 'from mod import x as y'
    tree = ast.parse(src)
    variables = {'mod': 'new_mod', 'x': 'new_x'}
    VariablesReplacer.replace(tree, variables)
    src_new = ast.unparse(tree)
    assert src_new == 'from new_mod import new_x as y'


# Generated at 2022-06-23 23:48:48.603788
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    name1 = ast.Name(id='name1', ctx=ast.Store())
    name2 = ast.Name(id='name2', ctx=ast.Store())
    ctx = ast.Store()
    key_word = ast.keyword(arg='name2', value=ast.Num(n=0))
    func_args = [ast.arg(arg='name3', annotation=None)]
    func_body = [ast.Name(id='name4', ctx=ctx), ast.Name(id='name5', ctx=ctx)]

# Generated at 2022-06-23 23:48:58.184379
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1
        print(x)

    snippet_ = snippet(test)
    assert snippet_.get_body() == [
        ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Load())],
                   ast.BinOp(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                             ast.Add(), ast.Num(1))),
        ast.Expr(ast.Call(ast.Name(id='print', ctx=ast.Load()),
                          [ast.Name(id='_py_backwards_x_0', ctx=ast.Load())], []))
    ]



# Generated at 2022-06-23 23:49:02.291177
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("from .x import y")
    VariablesReplacer.replace(tree, {"x": "y"})
    assert ast.dump(tree) == "Module(body=[ImportFrom(module='y', names=[alias(name='y', asname=None)], level=1)])"


if __name__ == '__main__':
    test_VariablesReplacer_visit_ImportFrom()

# Generated at 2022-06-23 23:49:09.868989
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .test_helpers import get_tree
    from .test_helpers import get_source
    from .test_helpers import assert_equal
    source = get_source(test_VariablesReplacer_visit_alias)
    tree = get_tree(source)
    VariablesReplacer.replace(tree, {"x": "y"})
    assert_equal(
        get_source(tree),
        "from y import z"
    )

# Generated at 2022-06-23 23:49:19.539009
# Unit test for function extend
def test_extend():
    import tempfile
    import os
    import typing
    import re

    def test_snippet(fn):
        tmp_filepath = tempfile.mkstemp()[1]
        with open(tmp_filepath, 'w+') as f:
            print(fn, file=f)

        annotations = typing.get_type_hints(fn)
        source = get_source(fn)
        tree = ast.parse(source)
        snippet_kwargs = {key: annotations[key] for key in annotations}
        variables = find_variables(tree)
        new_variables = {name: VariablesGenerator.generate(name)
                         for name in variables}
        snippet = ast.parse(source).body[0]
        extend_tree(snippet, new_variables)

# Generated at 2022-06-23 23:49:24.196412
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
  tree = ast.parse("x = 1")
  variables = {'x': '_py_backwards_x_0'}
  replacer = VariablesReplacer(variables)
  replacer.visit_Name(tree.body[0].value)
  assert tree.body[0].value.id == "_py_backwards_x_0"


# Generated at 2022-06-23 23:49:27.076991
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-23 23:49:28.343169
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    from .tree import find, replace_at

# Generated at 2022-06-23 23:49:36.401805
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    test_code = VariablesReplacer.replace(
        ast.parse("""
    try:
        x = 2
    except ValueError as ex:
        x = 3
    """).body[0], {'ex': 'exc'}
    )
    assert ast.dump(test_code) == """
    ExceptHandler(
        type=Name(
            id='ValueError',
            ctx=Load()
        ),
        name=Name(
            id='exc',
            ctx=Store()
        ),
        body=[
            Assign(
                targets=[
                    Name(
                        id='x',
                        ctx=Store()
                    )
                ],
                value=Num(
                    n=3
                )
            )
        ]
    )
    """

# Generated at 2022-06-23 23:49:46.592033
# Unit test for function extend
def test_extend():
    def snippet_extend(x: int, y: int):
        extend(vars)
        return x + y, x * y

    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Constant(value=1)),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Constant(value=2)),
    ]
    body = snippet_extend.get_body(vars=vars)

# Generated at 2022-06-23 23:49:47.530787
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-23 23:49:56.069610
# Unit test for function find_variables
def test_find_variables():
    # test for function find_variables:
    assert find_variables(ast.parse('''
    let(x)
    x += 1
    ''')) == {'x'}

    assert find_variables(ast.parse('''
    let(x)
    x += 1
    while True:
        let(y)
        y += 1
    ''')) == {'x', 'y'}

    # Test for function VariablesReplacer:

# Generated at 2022-06-23 23:50:00.816137
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(
        ast.parse("""
        let(a)
        z = 1
        """)
    ) == ['a']

    assert find_variables(
        ast.parse("""
        x = 1
        b = 1
        """)
    ) == []



# Generated at 2022-06-23 23:50:10.740283
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    code = 'let(x)\nlet(y)\nprint(x, y)'
    source = get_source(compile(code, '<test>', 'exec', ast.PyCF_ONLY_AST)).strip()
    tree = ast.parse(source)
    tree = snippet(compile(source, '<test>', 'exec', ast.PyCF_ONLY_AST)).get_body()
    new_tree = list(tree)

    var = VariablesGenerator.generate('x')
    names = list(find(tree, ast.Name))
    assert len(names) == 2

    for node in names:
        assert node.id == 'x' or node.id == 'y'

    variables = {
        'x': var,
        'y': 'y'
    }

# Generated at 2022-06-23 23:50:15.139262
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("try: pass\nexcept ValueError as e: pass")
    tree = VariablesReplacer.replace(tree, {"e": "unique_name"})
    code = compile(tree, "<test>", "exec")
    module = {}
    exec(code, module)
    assert "unique_name" in module["test"].body[0].body[0].handlers[0].name.id

# Generated at 2022-06-23 23:50:20.180666
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    # Arrange
    node = ast.Name("x")
    variables = {"x": ["x", "y", "z"]}
    expected = ast.Name("y")

    # Act
    result = VariablesReplacer.replace(node, variables)

    # Assert
    assert result == expected



# Generated at 2022-06-23 23:50:23.878869
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class A:
        def __init__(self, x):
            self.x = x
        def add(self, y):
            self.x += y
    a = A(0)
    a.add(1)
    assert a.x == 1


# Generated at 2022-06-23 23:50:25.682521
# Unit test for function extend_tree
def test_extend_tree():
    x = 1
    y = 2
    extend(vars())
    assert y == 3


# Generated at 2022-06-23 23:50:34.470405
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_fn(a: int = 0, b: int = 0) -> int:
        let(x)
        let(y)
        x += a
        y += b
        return x + y

    def py_backwards_y_0() -> int:
        let(y)
        y += b
        return y

    def py_backwards_x_0() -> int:
        let(x)
        x += a
        return x

    body = snippet_fn.get_body(a=1, b=py_backwards_y_0())
    assert body[0].value.args[0].id == 'py_backwards_x_0'
    assert body[0].value.args[0] == py_backwards_x_0.__code__

# Generated at 2022-06-23 23:50:39.038472
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo(x):
        let(x)
        x += 1
        y = 1
    print(foo.get_body(x=42))

# Generated at 2022-06-23 23:50:46.739614
# Unit test for function find_variables
def test_find_variables():
    expected = {'x': 'x_1', 'y': 'y_1',
                'z': 'z_1', 't': 't_1', 'u': 'u_1'}
    source = '''
print('test')
let(x)
let(y)
let(z)
let(t)
let(u)
print('test')
'''

    tree = ast.parse(source)
    assert find_variables(tree) == expected

# Generated at 2022-06-23 23:50:56.762077
# Unit test for function extend_tree
def test_extend_tree():
    func_body = """
    extend(vars)
    print(x, y)
    """
    tree = ast.parse(func_body)
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=0)], value=ast.Num(1)),
                                ast.Assign(targets=[ast.Name(id='x', ctx=0)], value=ast.Num(2))]})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-23 23:51:02.672889
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def testFunction():
        pass

    tree = ast.parse(get_source(testFunction))
    test_var = VariablesGenerator.generate('test')
    print(VariablesReplacer.replace(tree, {'testFunction': test_var}).body[0].body[0].name)
    assert VariablesReplacer.replace(tree, {'testFunction': test_var}).body[0].body[0].name == test_var


# Generated at 2022-06-23 23:51:05.356895
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert (VariablesReplacer({}))

# Generated at 2022-06-23 23:51:05.847986
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    pass

# Generated at 2022-06-23 23:51:10.235872
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    input_var = "x"
    replacer = VariablesReplacer({input_var: "y"})
    input_value = ast.keyword(arg=ast.Name(id=input_var))
    replacer.visit(input_value)
    assert input_value.arg == "y"


# Generated at 2022-06-23 23:51:15.579973
# Unit test for function extend_tree
def test_extend_tree():
    def test_function():
        x = 1
        let(vars)
        extend(vars)

    source = get_source(test_function)
    tree = ast.parse(source)
    vars = ast.parse('x = 1').body[0]
    variables = {'vars': vars}
    extend_tree(tree, variables)
    assert ast.dump(tree) == ast.dump(ast.parse('x = 1; x = 1;'))



# Generated at 2022-06-23 23:51:20.980199
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("def func(a, b=let(x), c=1): pass")
    variables = find_variables(tree)
    expect = ast.parse("def func(a, b=_py_backwards_x_0, c=1): pass").body[0]
    result = VariablesReplacer.replace(tree.body[0], variables)
    assert expect == result

# Generated at 2022-06-23 23:51:29.102285
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    def f1(x):
        print(x)

    tree = ast.parse(get_source(f1))
    variables = {'x': VariablesGenerator.generate('x')}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree.body[0]) == 'def f1(_py_backwards_x_0_0):\n    print(_py_backwards_x_0_0)'

# Generated at 2022-06-23 23:51:35.780652
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from typed_ast import ast3
    # simple case
    node = ast.ExceptHandler(
        lineno=2,
        col_offset=4,
        type=None,
        name="e",
        body=[ast.Pass()]
    )
    variables = {'e': '_pba_e_1'}
    VariablesReplacer.replace(node, variables)
    assert node == ast.ExceptHandler(
        lineno=2,
        col_offset=4,
        type=None,
        name="_pba_e_1",
        body=[ast.Pass()]
    )
    # simple case with numbers in name

# Generated at 2022-06-23 23:51:37.564626
# Unit test for constructor of class snippet
def test_snippet():
    """Test snippet"""
    s = snippet(None)
    assert s is not None


# Generated at 2022-06-23 23:51:44.848289
# Unit test for function extend
def test_extend():
    s = snippet(lambda: extend([]))
    s.get_body()


# Generated at 2022-06-23 23:51:51.422705
# Unit test for function let
def test_let():
    x = 1
    y = 2

    @snippet
    def test():
        let(x)
        x *= 10
        return x + y


# Generated at 2022-06-23 23:52:01.748868
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    # Create tree
    tree = ast.parse(
    '''
    try:
        x = 3
    except ValueError:
        y = 1
    except:
        e = 1
    ''')
    # Create variables
    variables = {'y': 'y_1', 'e': 'e_1'}
    # Replace variables
    new_tree = VariablesReplacer.replace(tree, variables)
    # Get new source
    new_source = get_source(new_tree)
    # Check result
    assert new_source == 'try:\n    x = 3\nexcept ValueError:\n    y_1 = 1\nexcept:\n    e_1 = 1'


# Generated at 2022-06-23 23:52:09.812841
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    vargen = VariablesGenerator()
    dummy_cls = ast.ClassDef(name="SomeClass", body=[], decorator_list=[])
    attr_node = ast.Attribute(value=dummy_cls, attr="some_attr")
    variables = {"old_id": vargen.generate(), "some_attr": dummy_cls}
    node = ast.Name(id="old_id", ctx=ast.Load())
    new_node = VariablesReplacer.replace(node, variables)
    assert new_node.id == variables["old_id"]
    node = ast.Attribute(value=ast.Name(id="old_id", ctx=ast.Load()), attr="some_attr")
    new_node = VariablesReplacer.replace(node, variables)
    assert new_node

# Generated at 2022-06-23 23:52:19.384223
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class _:
        pass
    class _A:
        pass
    class A(_A):
        pass
    class B:
        pass

    node = ast.parse('class A(_A): pass').body[0]
    variables = {'A': A, '_A': _A, 'B': B, '_': _}
    a = VariablesReplacer.visit_ClassDef(VariablesReplacer(variables), node)
    assert a.bases == [B]
    a = VariablesReplacer.visit_ClassDef(VariablesReplacer(variables), node)
    assert a.bases == [B]

# Generated at 2022-06-23 23:52:30.753307
# Unit test for function extend
def test_extend():
    def snippet1(a, b, c):
        extend({"x": a, "y": b, "z": c})
        return x

    tree1 = snippet1.get_body(a=1, b=2, c=3)
    assert tree1 == [
        ast.Assign([ast.Name("x", ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name("y", ast.Store())], ast.Num(2)),
        ast.Assign([ast.Name("z", ast.Store())], ast.Num(3)),
        ast.Return(ast.Name("x", ast.Load()))
    ]

    # Unit test for function let
    def snippet2(a, b, c):
        let(x=a)
        let(y=b)

# Generated at 2022-06-23 23:52:34.780424
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    pass



# Generated at 2022-06-23 23:52:44.218956
# Unit test for function let
def test_let():
    @snippet
    def fn(a, b):
        let(a)
        a += 1
        let(b)
        b += 2

    body = fn.get_body(a=1, b=2)
    assert body == [ast.AugAssign(
        target=ast.Name(id='_py_backwards_a_0', ctx=ast.Store()),
        op=ast.Add(),
        value=ast.Num(n=1)
    ), ast.AugAssign(
        target=ast.Name(id='_py_backwards_b_0', ctx=ast.Store()),
        op=ast.Add(),
        value=ast.Num(n=2)
    )]



# Generated at 2022-06-23 23:52:51.756908
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("from path1 import path2")
    variables = {}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert(get_source(tree) == "from path1 import path2")

    tree = ast.parse("from path1 import path2")
    variables = {'path2': 'path3'}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert(get_source(tree) == "from path1 import path3")

    tree = ast.parse("from path1 import path2")
    variables = {'path1': 'path3'}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)