

# Generated at 2022-06-23 23:42:54.614716
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    def fn1(x):
        return x.b
    test_snippet = snippet(fn1)
    body = test_snippet.get_body()
    assert(isinstance(body[0].value, ast.Attribute))

# Generated at 2022-06-23 23:43:01.047337
# Unit test for function extend
def test_extend():
    from py_backwards.transform import simple_transform
    @snippet
    def snippet_test():
        extend(vars)
        print(x, y)
    vars = [ast.Assign([ast.Name(id=x, ctx=ast.Store())], ast.Num(n=1)) for x in ["x", "y"]]
    src = simple_transform(snippet_test, vars=vars)
    assert(src == "x = 1\nx = 2\nprint(x, y)\n")

# Generated at 2022-06-23 23:43:05.761163
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    ast_node = ast.parse('foo.bar').body[0]
    variables = {'foo': 'baz'}
    replacer = VariablesReplacer(variables)
    replacer.visit_Attribute(ast_node)
    assert ast.dump(ast_node) == 'Attribute(value=Name(id=baz, ctx=Load()), attr=bar, ctx=Load())'


# Generated at 2022-06-23 23:43:11.468591
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    tree = ast.parse('class A: pass')
    variables = {'A': ast.Name(id='B', ctx=ast.Load())}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'Module(body=[ClassDef(name="B", bases=[], keywords=[], body=[Pass()], decorator_list=[])])'

# Generated at 2022-06-23 23:43:22.261702
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(a: int, b: int) -> None:
        let(x)
        extend(y)
        let(z)
        c = x + b
        d = c + a
        e = c + a
        return d

    source = get_source(test_snippet)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name) for name in names}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert len(tree.body[0].body) == 8
    expected = [ast.FunctionDef, ast.Assign, ast.AugAssign, ast.Return]
 

# Generated at 2022-06-23 23:43:26.118939
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    import unittest
    unittest.TestCase().assertRaises(TypeError,
                                     VariablesReplacer.replace,
                                     ast.parse('x'),
                                     {'x': 'y'})


# Generated at 2022-06-23 23:43:34.275295
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function():
        let(x)
        x += 1
        y = 1
        
    snippet_obj = snippet(function)
    assert snippet_obj.get_body() == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                   op=ast.Add(),
                                   right=ast.Num(n=1))),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                   value=ast.Num(n=1))]



# Generated at 2022-06-23 23:43:38.805814
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse('def x(i): pass')
    variables = {'i': ast.Name(id='j', ctx=ast.Param())}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'def x(j): pass'

# Generated at 2022-06-23 23:43:39.476612
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet != None

# Generated at 2022-06-23 23:43:43.926051
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    shape = ast.parse('shape = tvm.var("shape")')
    var = snippet(lambda shape: shape[0] * shape[1])
    shape = var.get_body(shape=ast.parse('shape'))
    assert get_source(shape) == 'shape[0] * shape[1]'

# Generated at 2022-06-23 23:43:46.518075
# Unit test for constructor of class snippet
def test_snippet():
    def f(a, b):
        let(s)
        s = a + b
    assert snippet(f)

# Generated at 2022-06-23 23:43:50.781558
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    def f():
        try:
            x = 1
        except AssertionError:
            let(x)
            print(x)

    source = get_source(f)
    tree = ast.parse(source)
    variables = find_variables(tree)
    VariablesReplacer.replace(tree, variables)
    print(ast.dump(tree))


# Generated at 2022-06-23 23:43:51.586815
# Unit test for constructor of class snippet
def test_snippet():
    snippet_instance = snippet(foo)


# Generated at 2022-06-23 23:43:56.631960
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    my_kwarg = ast.keyword(id='a', value=ast.Name('x'))
    variables = {'x': 'y'}
    inst = VariablesReplacer(variables)
    my_kwarg = inst.visit_keyword(my_kwarg)
    assert my_kwarg.value.id == 'y'

# Generated at 2022-06-23 23:44:05.411844
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    def test(body):
        tree = ast.parse(body)
        variables = {'x': '1', 'y': '2'}
        VariablesReplacer.replace(tree, variables)
        return tree

    assert 'class 1: 2' == ast.dump(test('class x: y'))
    assert 'class 2: 3' == ast.dump(test('class x: y\nclass y: z'))
    assert 'class 1: y\n2' == ast.dump(test('class x: y\nclass 1: 2'))
    assert 'class 1:\n    2 = 3' == ast.dump(test('class x: y\nclass 1:\n    z = z'))



# Generated at 2022-06-23 23:44:11.344775
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(3)
        a = let(4) + 1
        b = 5
        extend(test_ast)

    test_ast = ast.parse('c = 3')

    snippet_test = snippet(test)
    body = snippet_test.get_body()

    assert body[0].value.left.id == '_py_backwards_3_0'
    assert body[1].value.left.id == 'a'
    assert body[2].value.left.id == 'b'
    assert body[3].value.left.id == 'c'

# Generated at 2022-06-23 23:44:11.936608
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-23 23:44:22.617844
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Foo:
        pass
    class Foo:
        pass

    # tslint:disable-next-line:max-classes-per-file
    class Class:
        # tslint:disable-next-line:variable-name
        def test(self):
            a = 0
            return Foo(a), Foo(a), Foo
    source = get_source(Class)
    tree = ast.parse(source)
    variables = {'Foo': 'Foo_'}  # type: Dict[str, Variable]
    VariablesReplacer.replace(tree, variables)
    parsed_tree = ast.parse(get_source(Class))
    assert ast.dump(parsed_tree) == ast.dump(tree)

# Generated at 2022-06-23 23:44:24.974956
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    a = {}
    a.__name__
    # TODO: finish method test_VariablesReplacer_visit_FunctionDef

# Generated at 2022-06-23 23:44:26.984129
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    from .tree import parse_tree
    from .helpers import get_source
    tree = ast.parse("for i in range(10): print(i)")
    variables = {"i": "j"}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    assert tree == parse_tree(get_source(tree))

# Generated at 2022-06-23 23:44:30.881112
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    test = ast.parse("from test import any").body[0]
    variable = "test"
    keys = {"test": variable}
    ans = ast.parse("from asd import any").body[0]
    actual = VariablesReplacer.replace(test, keys)
    assert actual == ans

# Generated at 2022-06-23 23:44:38.875173
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def foo(x):
        let(x)
        x += 1
        y = 1
        extend(x)

    # fmt: off

# Generated at 2022-06-23 23:44:45.071095
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class Test(ast.NodeTransformer):
        def visit_keyword(self, node: ast.keyword) -> ast.keyword:
            node.arg = 'ok'
            return node
    node = ast.parse('def f(a=1):\n pass')
    Test().visit(node)
    assert get_source(node) == 'def f(ok=1):\n    pass'


# Generated at 2022-06-23 23:44:50.939602
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse('try: pass\nexcept Exception as e: pass').body[0]
    variables = {"e": ast.Name(id="exc", ctx=ast.Store())}
    tree = VariablesReplacer.replace(tree, variables)
    result = ""
    for i in find(tree, ast.ExceptHandler):
        result = getattr(i, "name", None)
    assert result.id == "exc"


# Generated at 2022-06-23 23:44:54.772476
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from_node = ast.parse('from xyz import x').body[0]
    as_node = ast.parse('as xyz').body[0].value.targets[0]

    variables = {'x': as_node}
    visit_ImportFrom_fn = VariablesReplacer.replace(import_from_node, variables)

    assert visit_ImportFrom_fn.module == 'xyz'

# Generated at 2022-06-23 23:44:55.749067
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:44:57.333670
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    variables = {'acc': '_py_backwards_acc_0'}

# Generated at 2022-06-23 23:45:02.686505
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    ast_l = ast.parse('import a')
    ast_t = ast.parse('import b')
    dictionary = {'a': 'b'}
    replacer = VariablesReplacer(dictionary)
    replacer.visit(ast_l)
    assert ast.dump(ast_l) == ast.dump(ast_t)

# Generated at 2022-06-23 23:45:11.183395
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    visit_alias = VariablesReplacer.visit_alias
    variables = {'a': 'a_alias', 'b': 'b_alias'}
    tree = ast.parse("from test import a, b")
    # :D
    assert(isinstance(tree.body[0], ast.ImportFrom))
    assert(isinstance(visit_alias(tree.body[0].names[0], variables), ast.alias))
    assert(isinstance(visit_alias(tree.body[0].names[1], variables), ast.alias))
    assert(tree.body[0].names[0].name == 'a')
    assert(tree.body[0].names[1].name == 'b')
    assert(tree.body[0].names[0].asname == 'a_alias')

# Generated at 2022-06-23 23:45:22.236225
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    v = ast.Name(id='id_1', ctx=ast.Load())
    tree = ast.parse(
        'class Value(object):\n'
        '    def arr():\n'
        '        pass'
    )
    VariablesReplacer({'id_1': v}).replace(tree,{'id_1': v})
    assert ast.dump(tree) == "Module(body=[ClassDef(name='id_1', bases=[Name(id='object', ctx=Load())], keywords=[], " \
                            "body=[FunctionDef(name='arr', args=arguments(args=[], vararg=None, kwonlyargs=[], " \
                            "kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)], "

# Generated at 2022-06-23 23:45:32.047534
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    '''
    Test visit_Name() of class VariablesReplacer
    '''
    # replace_field_or_node()
    n1 = ast.Name(id='x', ctx=ast.Load())
    n2 = ast.Name(id='y', ctx=ast.Load())
    n3 = ast.Name(id='z', ctx=ast.Load())
    variables = {'x': n2, 'y': n3}
    n1_res = VariablesReplacer(variables).visit_Name(n1)
    assert n1_res.id == 'y'
    n2_res = VariablesReplacer(variables).visit_Name(n2)
    assert n2_res.id == 'z'
    n3_res = VariablesReplacer(variables).visit_Name

# Generated at 2022-06-23 23:45:37.039710
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    #setup
    node = ast.arg('arg', None)
    variables = {'arg': 'new_arg'}
    
    #test
    result = VariablesReplacer.replace(node, variables)
    
    #assert
    assert result == ast.arg('new_arg', None)



# Generated at 2022-06-23 23:45:46.827343
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class TestVariablesReplacer(VariablesReplacer):
        def __init__(self, variables: Dict[str, Variable]) -> None:
            super().__init__(variables)
            self.visited_fields_of_arguments = []  # type: ignore

        def visit_Name(self, node: ast.Name) -> ast.Name:
            self.visited_fields_of_arguments.append(node.id)
            node = self._replace_field_or_node(node, 'id', True)
            return self.generic_visit(node)

    class TestAST(ast.AST):
        _fields = ['body']

        def __init__(self, body: List[ast.AST]) -> None:
            self.body = body


# Generated at 2022-06-23 23:45:55.806957
# Unit test for function extend
def test_extend():
    def snippet():
        extend(foo)
    snippet.__name__ = "snippet"

    foo = [ast.Assign([ast.Name('x')], ast.Constant(1)),
           ast.Assign([ast.Name('x')], ast.Constant(2))]

    code = snippet.get_body(foo=foo)
    assert(code[0].targets[0].id == foo[0].targets[0].id)
    assert(code[0].value.n == foo[0].value.n)
    assert(code[1].targets[0].id == foo[1].targets[0].id)
    assert(code[1].value.n == foo[1].value.n)

# Generated at 2022-06-23 23:46:03.194704
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    transformer = VariablesReplacer(
    {'from_list': ast.parse('from_list').body[0].names, 'from_module': "module"})
    import_from_list = ast.ImportFrom("module", [ast.alias("from_list", None)], 1)
    transformer.visit(import_from_list)
    assert import_from_list.module == 'module'
    assert import_from_list.names[0].name == 'from_list'


# Generated at 2022-06-23 23:46:04.810789
# Unit test for constructor of class snippet
def test_snippet():
    snippet._snippet()


test_snippet()

# Generated at 2022-06-23 23:46:13.415674
# Unit test for function extend_tree
def test_extend_tree():
    t = ast.parse('''
a = 1
extend(vars)
b = 2
''')

    class Subtree(ast.NodeVisitor):
        def __init__(self):
            self.subtrees = []  # type: List[ast.AST]

        def visit_Assign(self, node: ast.Assign):
            self.subtrees.append(node)

        def visit(self, node):
            self.subtrees = []
            super().visit(node)
            return self.subtrees

    vars = {'vars': Subtree().visit(t)}

    extend_tree(t, vars)

    assert len(t.body) == 2
    assert isinstance(t.body[0], ast.Assign)

# Generated at 2022-06-23 23:46:23.642705
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import astor
    from .helpers import match, MatchError

    # Test 1.
    ast = snippet(lambda: x + 1).get_body()
    match(astor.to_source(ast), '_py_backwards_x_0 + 1', desc='Snippet with one variable')

    # Test 2.
    ast = snippet(lambda: let(x) and y).get_body()
    match(astor.to_source(ast), '_py_backwards_x_0 and y', desc='Snippet with let call')

    # Test 3.
    ast = snippet(lambda: let(x) and let(y)).get_body()

# Generated at 2022-06-23 23:46:29.529148
# Unit test for function extend
def test_extend():
    def snippet_with_extend():
        extend(vars)
        print(x, x)

    vars = [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(1))]
    assert snippet(snippet_with_extend).get_body(vars=vars) == [
        ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(1)),
        ast.Print(dest=None, values=[ast.Name(id='x'), ast.Name(id='x')], nl=True)
    ]



# Generated at 2022-06-23 23:46:40.000457
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    class TestClass(ast.NodeVisitor):
        def visit_Call(self, node: ast.Call):
            for arg in node.args:
                # assert isinstance(arg, ast.Name) is True
                self.visit(arg)
    test_tree = ast.parse("foo(a, b)")
    test_class = TestClass()
    test_class.visit(test_tree)


if __name__ == '__main__':
    VariablesReplacer.replace(ast.parse("print(x, y)"), {'x': 'y'})
    test_arg = ast.parse("foo(a, b)").body[0].args[0]
    assert isinstance(test_arg, ast.Name) is True
    test_VariablesReplacer_visit_arg()

# Generated at 2022-06-23 23:46:43.761142
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = """
        from module1 import a
    """
    tree = ast.parse(source)
    variables = {"module1": "module2"}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == "from module2 import a\n"  # type: ignore



# Generated at 2022-06-23 23:46:48.125213
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_stmt = ast.ImportFrom(module='foo', names=[ast.alias(name='x', asname=None)])
    replacer = VariablesReplacer({'foo': 'bar'})
    replacer.visit(import_stmt)
    assert import_stmt.module == 'bar'


# Generated at 2022-06-23 23:46:58.487464
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class MyReplacer(VariablesReplacer):
        def __init__(self, variables: Dict[str, Variable]) -> None:
            super().__init__(variables)
            self._funcdef: ast.FunctionDef = ...

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            self._funcdef = node
            return super().visit_FunctionDef(node)

    source1 = '''
    def func(x: int, y: int) -> int:
        return x + y
    '''

    class TestCase(unittest.TestCase):
        def test_1(self):
            tree = ast.parse(source1)
            replacer = MyReplacer({'x': '_x', 'y': '_y'})

# Generated at 2022-06-23 23:47:05.531873
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
    extend(vars)
    print(x)
    '''
    vars = [ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1)
    )]
    tree = ast.parse(source)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree).strip() == '''
    x = 1
    print(x)
    '''.strip()

# Generated at 2022-06-23 23:47:14.596235
# Unit test for function extend_tree
def test_extend_tree():
    code = """
        let(x)
        extend(assignments)
        print(x)
    """
    ast_code = ast.parse(code)
    let_node = ast_code.body[0].body[0]
    let_name_node = let_node.args[0]
    extend_node = ast_code.body[0].body[1]
    extend_name_node = extend_node.args[0]
    let_name_node.id = "x"
    extend_name_node.id = "assignments"
    extend_tree(ast_code, {'assignments': [ast.parse("y = 1").body[0]]})
    assert(astor.to_source(ast_code) == "let(x)\ny = 1\nprint(x)")

# Generated at 2022-06-23 23:47:17.668333
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def f():
        print('f')
    def g():
        print('g')
    r = VariablesReplacer.replace(f, {'g': g})
    assert r == g


# Generated at 2022-06-23 23:47:27.139913
# Unit test for function extend_tree
def test_extend_tree():
    test_input = """
        x = 1
        extend(k)
        x = 2
        print(x)
    """
    tree = ast.parse(test_input)
    extend_tree(tree, {'k': [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))
    ]})
    assert str(tree) == """
        x = 1
        x = 1
        x = 2
        print(x)
    """

# Generated at 2022-06-23 23:47:35.118166
# Unit test for function let
def test_let():
    @snippet
    def fun():
        let(x)
        x += 1
        y = 1

    assert fun.get_body() == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0',
                                                 ctx=ast.Load()),
                                   op=ast.Add(),
                                   right=ast.Num(n=1))),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                   value=ast.Num(n=1))
    ]


# Generated at 2022-06-23 23:47:42.443773
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse(
        'def f(a, b) -> int: \n    return a + b'
    )
    node = tree.body[0].args.args[0]
    variables = {'a': ast.arg(arg='b', annotation=None),
                 'b': ast.arg(arg='a', annotation=None)}
    instance = VariablesReplacer(variables)
    assert instance.visit(node) == ast.arg(arg='b', annotation=None)



# Generated at 2022-06-23 23:47:52.561226
# Unit test for function let
def test_let():
    class Context:
        a = 5

    let = 1
    x = 0
    y = 2
    p = [1]
    s = '2'

    @snippet
    def test():
        let(y)
        y += 1
        let(x)
        x += y
        let(p)
        p.append(x)
        let(s)
        s += '3'
        let(a)
        a += 1


# Generated at 2022-06-23 23:47:56.542598
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    print(x)
    
    let(y)
    print(y)
    """
    tree = ast.parse(source)
    names = list(find_variables(tree))

    assert names == ['x', 'y']



# Generated at 2022-06-23 23:47:57.582535
# Unit test for method visit_Name of class VariablesReplacer

# Generated at 2022-06-23 23:48:09.184515
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    source = """class A():
    a = 1
    _a = 2
    B = 3
    _b = 4
    _a = 5
    a = _a
    b = _b
    c = b
    def _c(self):
        pass
    def d(self):
        pass
    d = _c
    A = 3
    A = 4
    a = A
    b = B
    c = C
    d = D
    _a = a
    _b = b
    _c = c
    _d = d
    _a = 1
    _b = 2
    _c = 3
    _d = 4
    _e = 5
    A = 1
    B = 2
    C = 3
    D = 4
    _e = A
"""

# Generated at 2022-06-23 23:48:17.648556
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse('''
    def a_method(a, b, c=None):
        pass
    ''')

    variables = {'a': 'a1', 'b': 'b1', 'c': 'c1'}
    VariablesReplacer.replace(tree, variables)

    assert tree.body[0].args.args[0].arg == 'a1'
    assert tree.body[0].args.args[1].arg == 'b1'
    assert tree.body[0].args.keywords[0].arg == 'c1'



# Generated at 2022-06-23 23:48:25.204116
# Unit test for function let
def test_let():
    def test():
        let(x)
        x += 1
        y = 1

    tree = snippet(test).get_body()

    assert isinstance(tree[0], ast.Assign)
    assert isinstance(tree[0].targets[0], ast.Name)
    assert tree[0].targets[0].id == '_py_backwards_x_0'
    assert isinstance(tree[1], ast.Assign)
    assert isinstance(tree[1].targets[0], ast.Name)
    assert tree[1].targets[0].id == 'y'



# Generated at 2022-06-23 23:48:36.889617
# Unit test for function let
def test_let():
    def ex():
        let(a)
        a += 1
        b = a

    assert get_source(ex) == '''def ex():
    let(a)
    a += 1
    '''
    assert snippet(ex).get_body() == [
        ast.Assign([
            ast.Name('_py_backwards_a_0', ast.Store())
        ], ast.BinOp(
            ast.Name('_py_backwards_a_0', ast.Load()),
            ast.Add(),
            ast.Num(1)
        )),
        ast.Assign([
            ast.Name('b', ast.Store())
        ], ast.Name("_py_backwards_a_0", ast.Load()))
    ]



# Generated at 2022-06-23 23:48:47.869452
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    import sys
    import os.path
    sys.path.append(
        os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir)))
    import backwards

    node = ast.ImportFrom(
        level=0,
        module="backwards.helpers",
        names=[
            ast.alias(
                name="VariablesGenerator",
                asname=None)
        ],
        lineno=1,
        col_offset=0
    )

    variables = {"backwards": "backwards_troll",
                 "backwards.helpers": "backwards_troll.helpers"}

    instance = backwards.snippets.VariablesReplacer(variables)


# Generated at 2022-06-23 23:48:57.440173
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class_def = ast.parse('''
try:
    pass
except a1mn as e1:
    pass
except a2mn as e2:
    pass
except a3mn:
    pass
except a4mn as e4:
    print(e4)
except a5mn:
    pass
except:
    pass
''').body[0].body[0]

# Generated at 2022-06-23 23:48:58.576009
# Unit test for constructor of class snippet
def test_snippet():
    def fn():
        let('')
    snippet(fn)

# Generated at 2022-06-23 23:49:02.552211
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    snippet = ast.parse('call(x=1)').body[0]
    variables = {'x': 2}
    VariablesReplacer.replace(snippet, variables)
    assert ast.dump(snippet) == 'Call(func=Name(id=call, ctx=Load()), args=[], keywords=[keyword(arg=2, value=Num(n=1))])'

# Generated at 2022-06-23 23:49:13.310983
# Unit test for function find_variables
def test_find_variables():

    found_vars = []
    for node in find_variables(ast.parse("let(x)")):
        found_vars.append(node)
    assert found_vars == ['x']

    found_vars = []
    for node in find_variables(ast.parse("let(a) let(b)")):
        found_vars.append(node)
    assert found_vars == ['a', 'b']

    found_vars = []
    for node in find_variables(ast.parse("let(a) x = a")):
        found_vars.append(node)
    assert found_vars == ['a']

    found_vars = []

# Generated at 2022-06-23 23:49:19.982919
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    # init
    var_name = 'var_name'
    var_name_ast = ast.Name(id=var_name, ctx=ast.Load())

    # var is str
    variables = {var_name: 'none'}

    replaced_var_name_ast = VariablesReplacer(
        variables=variables).visit(var_name_ast)

    assert replaced_var_name_ast.id == 'none'

    # var is list
    variables = {var_name: [1, 2, 3]}

    replaced_var_name_ast = VariablesReplacer(
        variables=variables).visit(var_name_ast)

    assert replaced_var_name_ast.id == var_name

    # var is list
    variables = {var_name: var_name_ast}

    replaced_

# Generated at 2022-06-23 23:49:28.306448
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('def fn(x): print(x)')
    variables = {'x': '_py_backwards_x_0'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "Module(body=" \
                             "[FunctionDef(name='fn', args=arguments(args=[arg(arg='_py_backwards_x_0', annotation=None)], " \
                             "vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Print(dest=None, " \
                             "values=[_py_backwards_x_0], nl=True)], decorator_list=[], returns=None)])"

# Generated at 2022-06-23 23:49:33.807016
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    test_dict = {'a': 'b'}
    obj_1 = ast.Name(id='a')
    obj_2 = ast.Name(id='c')
    assert VariablesReplacer.replace(obj_1, test_dict) == ast.Name(id='b')
    assert VariablesReplacer.replace(obj_2, test_dict) == ast.Name(id='c')

# Generated at 2022-06-23 23:49:38.118641
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    def f():
        extend(x)
        print(x)
    """
    tree = ast.parse(source)
    x = ast.Assign()
    extend_tree(tree, {'x': [x]})
    assert tree.body[0].body[0] == x



# Generated at 2022-06-23 23:49:45.937049
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class MyVisitor(VariablesReplacer):
        def __init__(self, variables: Dict[str, Variable]) -> None:
            super().__init__(variables)
            self.visited = False

        def visit_ExceptHandler(self, node: ast.ExceptHandler) -> ast.ExceptHandler:
            self.visited = True
            return node
    tree = ast.parse('try: pass\nexcept: pass')
    instance = MyVisitor({})
    instance.visit(tree)
    assert instance.visited
    # This test ensures that visit_ExceptHandler of class VariablesReplacer will be called
    # instead of its parent's method.

# Generated at 2022-06-23 23:49:49.728477
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
    try:
        a+b
    except Exception as e:
        pass
    """
    tree = ast.parse(source)
    tree = VariablesReplacer.replace(tree, {'e': '_py_backwards_e_0'})
    assert isinstance(tree.body[0].handlers[0].name, str)

# Generated at 2022-06-23 23:49:50.441222
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    _class = VariablesReplacer({})
    assert _class != None

# Generated at 2022-06-23 23:49:56.450124
# Unit test for function extend
def test_extend():
    @snippet
    def snippet():
        extend(vars)
    snippet_body = snippet.get_body(vars=[
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(2)),
    ])
    assert snippet_body == [
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(2)),
    ]


# Unit tests for function let

# Generated at 2022-06-23 23:50:01.329656
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    keyword = ast.keyword(arg='var')
    variables = {
        'var': 'var_value',
    }
    instance = VariablesReplacer(variables=variables)
    instance.visit_keyword(keyword)
    assert keyword.arg == 'var_value'



# Generated at 2022-06-23 23:50:02.388690
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:50:07.648760
# Unit test for function extend
def test_extend():
    def foo1(vars: List[ast.AST]) -> List[ast.AST]:
        extend(vars)
        print(x, y)

    vars = [ast.Assign([ast.Name('x')], ast.Num(1)), ast.Assign([ast.Name('x')], ast.Num(2))]
    snippet(foo1).get_body(vars=vars)



# Generated at 2022-06-23 23:50:09.726464
# Unit test for method visit_keyword of class VariablesReplacer

# Generated at 2022-06-23 23:50:10.779444
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-23 23:50:17.161658
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    some_snippet = snippet(lambda x: x + 1)

    @some_snippet
    def test(x: int, y: int = 1, z: int = 2) -> int:
        let(y)
        z += 1
        extend(z)
        return x

    # print(ast.dump(test._get_body(z=ast.parse('y = 1'))))

# Generated at 2022-06-23 23:50:24.816842
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    # type: () -> None
    var = VariablesGenerator.generate('test_var')
    class TestClass(ast.AST):
        def __init__(self):
            self.keywords = [ast.keyword(arg=var, value=1)]

    replacer = VariablesReplacer({var: 'replaced_var'})
    node = TestClass()
    replacer.generic_visit(node)
    assert node.keywords[0].arg == 'replaced_var'

# Generated at 2022-06-23 23:50:33.820404
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    # return value not equal node
    variables = {'a': 'b'}

    # node is ast.Name node
    node = ast.Name(id='a', ctx=ast.Load())
    assert VariablesReplacer.replace(node, variables).id == 'b'

    # node is ast.Attribute
    node = ast.Attribute(value=ast.Name(id='c', ctx=ast.Load()), attr='a',
                         ctx=ast.Load())
    result = VariablesReplacer.replace(node, variables)
    assert isinstance(result, ast.Attribute)
    assert result.value.id == 'c'
    assert result.attr == 'b'

    # node is not ast.Name node
    variables = {'b': ast.Name(id='a', ctx=ast.Load())}
   

# Generated at 2022-06-23 23:50:43.512780
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typed_ast.ast3 as ast

    def _test(
        var1: str,
        var2: ast.AST,
        result: str
    ):
        snippet_object = snippet(test_snippet_get_body)
        body = snippet_object.get_body(var1=var1, var2=var2)
        assert ast.dump(body) == result

    x = ast.parse('x')
    y = ast.parse('y')
    z = ast.parse('z')

# Generated at 2022-06-23 23:50:53.135856
# Unit test for method visit_ImportFrom of class VariablesReplacer

# Generated at 2022-06-23 23:50:58.945105
# Unit test for function extend
def test_extend():
    import pytest
    from .helpers import get_source

    @snippet
    def test():
        x = 1
        y = 2
        extend(x)
        print(x, y)

    source = get_source(test)
    source = source.replace('x', 'x = 10')
    tree = ast.parse(source)
    assert tree.body[0].body[-1].value.args[0].id == 'x'

# Generated at 2022-06-23 23:51:03.143829
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    node = ast.ExceptHandler(name='e', type=None, body=[])
    v = dict()
    v['e'] = 'e_new'
    tree = VariablesReplacer.replace(node, v)
    assert tree.name == 'e_new'

# Generated at 2022-06-23 23:51:11.139189
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from x import FooBar as FooBar")
    alias = tree.body[0].names[0]
    alias.name = 'x'
    replacer = VariablesReplacer({'FooBar': 'FooBarBaz'})
    replacer.visit_alias(alias)
    assert ast.dump(tree) == '''Module(body=[ImportFrom(module=\'x\', names=[alias(name=\'x\', asname=\'FooBarBaz\')], level=0)])'''


# Generated at 2022-06-23 23:51:19.747902
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Test:
        def test(self):
            class A:
                pass
            class B:
                pass

            return A, B

    tester = Test()
    source = get_source(tester.test)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables_original = {name: VariablesGenerator.generate(name) for name in names}
    variables_replaced = {**variables_original}
    variables_replaced['A'] = ast.ClassDef(name='A', body=[], decorator_list=[])
    variables_replaced['B'] = ast.ClassDef(name='B', body=[], decorator_list=[])
    extend_tree(tree, variables_replaced)
    VariablesReplacer.replace(tree, variables_replaced)
   

# Generated at 2022-06-23 23:51:20.638148
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:51:32.310053
# Unit test for function let
def test_let():
    class X:
        pass

    x = X()
    y = 'hello'

    @snippet
    def foo():
        let(x)
        x.value = 10
        let(y)
        return y

    foo_body = foo.get_body(x=x, y=y)
    exec(compile(ast.Module([ast.Expr(foo_body[0])]), '', 'exec'))
    assert x.value == 10
    assert foo_body[1].value.id == y

# Generated at 2022-06-23 23:51:34.767453
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A:
        pass


# Generated at 2022-06-23 23:51:38.344312
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    """Unit test for method visit_ImportFrom of class VariablesReplacer"""
    import_from = ast.parse('import a\n')
    inst = VariablesReplacer({})
    assert isinstance(inst.visit(import_from), ast.Module)



# Generated at 2022-06-23 23:51:46.980896
# Unit test for constructor of class snippet
def test_snippet():
    class S:
        @snippet
        def func1(self, x: int) -> None:
            let(x)
            let(y)
            x += 1

    body = S().func1.get_body(x=1, y=2)
    assert body == [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                               value=ast.Num(n=1)),
                    ast.Assign(targets=[ast.Name(id='_py_backwards_y_1', ctx=ast.Store())],
                               value=ast.Num(n=2))]


# Generated at 2022-06-23 23:51:54.647167
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    """Unit test for visit_ClassDef"""
    import ast as ast_lib
    test_var = ast_lib.Name('test', ast_lib.Load())
    class_def = ast_lib.ClassDef(name='ClassName', bases=[], keywords=[], body=[], decorator_list=[])
    class_def_modif = ast_lib.ClassDef(name='ClassName', bases=[], keywords=[], body=[], decorator_list=[])
    vars = {'ClassName': test_var}
    inst = VariablesReplacer(vars)
    inst.visit_ClassDef(class_def)
    assert(class_def_modif.name == test_var)


# Generated at 2022-06-23 23:52:04.336926
# Unit test for function let
def test_let():
    # class
    class MyTest:
        @snippet
        def my_snippet(self):
            first = let(1)
            second = let(first)
            third = let(first)

            first = 3

            return first + second + third

    # global
    @snippet
    def my_snippet():
        first = let(1)
        second = let(first)
        third = let(first)

        first = 3

        return first + second + third

    for inst in [MyTest(), my_snippet]:
        tree = ast.parse(get_source(inst.my_snippet))
        assert find_variables(tree) == ['first']
        variables = {'first': 1}

        extend_tree(tree, variables)

# Generated at 2022-06-23 23:52:11.566558
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Foo:
        pass
    class Bar:
        pass
    def fn(a, b, c, d):
        pass
    v = {'x': Foo, 'a': Bar, 'b': fn}
    source = get_source(fn)
    tree = ast.parse(source)
    tree.body[0].name = 'a'
    tree.body[0].args.args[1] = ast.Name(id='b', ctx=ast.Load())
    tree.body[0].args.args[2] = ast.Name(id='x')
    tree.body[0].decorator_list.append(ast.Name(id='x'))
    tree.body[0].bases.append(ast.Name(id='x'))

# Generated at 2022-06-23 23:52:20.692381
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    input_tree = ast.parse(
        'def fijk(a, b, c, d, e):\n'
        '    pass'
    )
    output_tree = ast.parse(
        'def fijk(ab, b, c, d, e):\n'
        '    pass'
    )
    assert input_tree.body[0] != output_tree.body[0]

    variables = {'a': 'ab'}
    VariablesReplacer.replace(input_tree, variables)
    assert input_tree.body[0] == output_tree.body[0]



# Generated at 2022-06-23 23:52:21.356957
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    assert True

# Generated at 2022-06-23 23:52:30.701562
# Unit test for function extend_tree
def test_extend_tree():
    vars = ast.parse("x = 1; x = 2").body
    tree = ast.parse("extend(vars); y = 1")
    extend_tree(tree, {'vars': vars})
    tree_str = ast.dump(tree)
    assert tree_str == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2)), Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=1))])"

# Generated at 2022-06-23 23:52:35.803125
# Unit test for function find_variables
def test_find_variables():
    src = """
        let(x)
        def foo():
            let(y)
            x, y = y, x
        
    """
    tree = ast.parse(src)
    assert set(find_variables(tree)) == {'x', 'y'}


# Generated at 2022-06-23 23:52:39.241095
# Unit test for function find_variables
def test_find_variables():
    var_name = VariablesGenerator.generate('x')
    source = """
let(x)
x
"""
    tree = ast.parse(source)
    names = find_variables(tree)

    assert var_name == next(names)



# Generated at 2022-06-23 23:52:42.419468
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .types import Variable as V, get_var
    from .helpers import ast_to_str
    var_x = get_var('x')
    var_y = get_var('y')
    def my_snippet(x: V, y: V):
        let(x)
        x += 1
        y = 1
    snippet_ = snippet(my_snippet)
    snippet_body = snippet_.get_body(x=var_x, y=var_y)
    assert ast_to_str(snippet_body) == "x += 1\ny = 1"

# Generated at 2022-06-23 23:52:50.826877
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from typed_ast import ast3 as ast
    from io import StringIO

    test_str1 = '''
import os.path
import typing as t
from os import path as p
    '''
    tree1 = ast.parse(test_str1)
    replacer = VariablesReplacer({"os": "__os", "path": "__path", "typing": "__typing"})
    replacer.visit(tree1)
    out1 = StringIO()
    ast.unparse(tree1, out1)
    res1 = out1.getvalue()
    assert res1 == '\nimport __os.__path\nimport __typing as t\nfrom __os import __path as p\n    '

    test_str2 = '''
import os.path as p
    '''
    tree2

# Generated at 2022-06-23 23:53:01.034325
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class Test(ast.NodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            node = self._replace_field_or_node(node, 'id')
            return self.generic_visit(node)  # type: ignore
    test = Test()
    info = test._replace_field_or_node(ast.Name(id="info", ctx=None), "id")
    assert info.id == "info"
    info = test._replace_field_or_node(ast.Name(id="info", ctx=ast.Store()), "id")
    assert info.id == "info"
    info = test._replace_field_or_node(ast.Name(id="info", ctx=ast.Load()), "id")
    assert info.id == "info"
