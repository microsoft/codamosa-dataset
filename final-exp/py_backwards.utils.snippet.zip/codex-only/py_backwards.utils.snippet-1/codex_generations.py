

# Generated at 2022-06-23 23:43:00.479503
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    @snippet
    def test():
        let(x)  # type: ignore
        class Test:
            pass

    tree = test_VariablesReplacer_visit_ClassDef.__dict__['test'].get_body()
    compare = """class _py_backwards_x_0:
    pass"""
    assert ast.dump(tree[0]) == ast.dump(ast.parse(compare).body[0])



# Generated at 2022-06-23 23:43:08.839383
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse("x"))) == []

    source = """
        def test():
          let(x)
        """
    assert list(find_variables(ast.parse(source))) == ['x']

    source = """
        def test():
          let(x)
          let(y)
        """
    assert list(find_variables(ast.parse(source))) == ['x', 'y']

    source = """
        def test():
            let(x)
            def test2():
                let(y)
        """
    assert list(find_variables(ast.parse(source))) == ['x', 'y']


# Eager unit test for function extend_tree

# Generated at 2022-06-23 23:43:10.947275
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:43:13.711551
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x); let(y)')
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']

# Generated at 2022-06-23 23:43:17.131270
# Unit test for constructor of class snippet
def test_snippet():
    def func():
        let(a)
        a += 1

    my_snippet = snippet(func)

    body = my_snippet.get_body()
    assert len(body) == 1



# Generated at 2022-06-23 23:43:22.949139
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class C:
        def __init__(self, a, b, c):
            pass

    tree = ast.parse('C(1, 2, 3)')
    variables = {'C': 'test', 'a': 'test', 'b': 'test', 'c': 'test'}
    VariablesReplacer.replace(tree, variables)


# Generated at 2022-06-23 23:43:29.738195
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class DemoVariablesReplacer(VariablesReplacer):
        def __init__(self):
            return super().__init__(variables={})

    def _test(source, expected_source):
        tree = ast.parse(source)
        DemoVariablesReplacer.replace(tree, variables={'func': 'new_name'})
        actual = ast.fix_missing_locations(tree)
        expected = ast.parse(expected_source)
        assert actual == expected


# Generated at 2022-06-23 23:43:36.273003
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        x = 0
        let(x)
        x += 1
    snippet = snippet(test)
    body = snippet.get_body()
    assert body == [ast.AugAssign(
        target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()),
        op=ast.Add(),
        value=ast.Num(n=1),
    )]

# Generated at 2022-06-23 23:43:41.088829
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(_: str, y: str) -> None:
        let(x)
        print(x, y)
        print(y)
    
    
    tree = test.get_body(_='hello', y='world')
    assert 'print(y)' in [get_source(node) for node in tree]

# Generated at 2022-06-23 23:43:48.553572
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    import typed_ast.ast3 as ast

    # TODO: Add tests for other methods of class VariablesReplacer
    # Compare expected result with result of method visit_Name of class VariablesReplacer
    tree = ast.parse('print(x, y)')
    variables = {'x': 'var_x', 'y': 'var_y'}
    r = VariablesReplacer(variables)
    result = r.visit(tree)
    expected = ast.parse('print(var_x, var_y)')
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-23 23:43:58.995031
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    # For example:
    # def f():
    #     let(x)
    #     let(y)
    #     let(z)
    #     let(a)
    #     a = x + y + z

    # Here is the constructor's input.
    tree = ast.parse(
        'a = x + y + z'
    )

    # Let's declare some variables.

# Generated at 2022-06-23 23:44:05.250300
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    x = VariablesGenerator.generate('a')
    y = VariablesGenerator.generate('a')
    dict = {'b': 'c'}
    inst = VariablesReplacer(dict)
    assert not isinstance(inst._replace_field_or_node(x, 'id'), str)
    assert not isinstance(inst._replace_field_or_node(y, 'id'), str)
    assert not isinstance(inst._replace_field_or_node(y, 'id'), str)

# Generated at 2022-06-23 23:44:11.757320
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import pretty_print
    # this is just a unit test to ensure that method get_body of class snippet works correctly

    def test(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
        z = 2
        print(x, y, z)
        extend(vars)
        print(x)

    body = snippet(test).get_body(vars=[
        ast.Assign(
            targets=[ast.Name(id='x')],
            value=ast.Num(n=1),
        ),
        ast.Assign(
            targets=[ast.Name(id='x')],
            value=ast.Num(n=2),
        ),
    ])

# Generated at 2022-06-23 23:44:12.570532
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import ast
    import keyword


# Generated at 2022-06-23 23:44:18.937836
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import importlib
    import sys
    vars = {'__builtins__': 'importlib._bootstrap'}
    source = get_source(importlib.reload)
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, vars)
    exec(compile(tree, 'my_reload', mode='exec'), sys.modules)
    assert '__builtins__' not in sys.modules



# Generated at 2022-06-23 23:44:23.235973
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    actual_tree = ast.parse('''
try:
    pass
except Exception as e:
    pass
''')

    expected_tree = ast.parse('''
try:
    pass
except Exception as e:
    pass
''')

    # replace 'e'
    vars_ = {
        'e': 'new_e',
    }
    VariablesReplacer.replace(actual_tree, vars_)
    assert ast.dump(actual_tree, annotate_fields=False) ==\
        ast.dump(expected_tree, annotate_fields=False)


# Generated at 2022-06-23 23:44:32.987605
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    from .typed import args
    import textwrap
    src="""
    a = 1
    b = 2
    def func(a, b):
      print(a)
      print(b)
    """
    tree = ast.parse(textwrap.dedent(src))
    variables = {'a': args.a, 'b': args.b}
    VariablesReplacer.replace(tree, variables)
    compare_src = """
    a = args.a
    b = args.b
    def func(a, b):
      print(a)
      print(b)
    """
    compare_tree = ast.parse(textwrap.dedent(compare_src))
    assert ast.dump(tree) == ast.dump(compare_tree)

# Generated at 2022-06-23 23:44:38.584731
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    from os import path

    tree = ast.parse(open(path.join(path.dirname(__file__), 'test', 'replace_arg.py')).read())
    tree = VariablesReplacer.replace(tree, {'x': 'a'})

    assert ast.dump(tree) == '''
    import x as a
    import y as b
    def foo(c: 1, x: 2) -> 3:
        1
    '''

# Generated at 2022-06-23 23:44:44.301327
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    node = ast.parse("node.name").body[0].value
    variables = {'node': ast.Name(id='new_node', ctx=ast.Load())}
    replacer = VariablesReplacer(variables)
    node = replacer.visit_Attribute(node)
    source = get_source(node).strip()
    assert source == 'new_node.name'

# Generated at 2022-06-23 23:44:53.567884
# Unit test for function extend_tree
def test_extend_tree():
    def tree():
        extend_tree(ast.parse(
                """
                def fn(x):
                    extend(x)
                    return x
                """),
                {'x': [
                    ast.Expr(value=ast.Call(
                        func=ast.Name(id='print', ctx=ast.Load()),
                        args=[ast.Num(n=1)],
                        keywords=[],
                        starargs=None,
                        kwargs=None)),
                    ast.Expr(value=ast.Call(
                        func=ast.Name(id='print', ctx=ast.Load()),
                        args=[ast.Num(n=2)],
                        keywords=[],
                        starargs=None,
                        kwargs=None))]})

    tree()

# Generated at 2022-06-23 23:44:55.366638
# Unit test for function extend
def test_extend():
    def f():
        a = 1
        extend(a)
        b = a
        return b
    assert f() == 1



# Generated at 2022-06-23 23:45:05.930740
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class FakeModule:
        class FakeClass:
            class FakeAttribute: pass

        class FakeClass2:
            class FakeAttribute: pass

    source = "FakeModule.FakeClass.FakeAttribute"
    tree = ast.parse(source)
    variables = {
        'FakeModule': 'FakeModule2',
        'FakeClass': FakeModule.FakeClass2,
        'FakeAttribute': FakeModule.FakeClass2.FakeAttribute
    }

    assert isinstance(tree.body[0].value, ast.Attribute)
    node = tree.body[0].value

    assert node.value.attr == "FakeClass"
    assert node.attr == "FakeAttribute"

    result = VariablesReplacer.replace(tree, variables)
    assert isinstance(result.body[0].value, ast.Attribute)

# Generated at 2022-06-23 23:45:06.522342
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    pass

# Generated at 2022-06-23 23:45:14.326087
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Foo:
        pass
    Attributes_name = Foo()
    Attributes_name.id = 'bar'
    Attributes_value = Foo()
    Attributes_value.id = 'bar'
    Tree_Attributes = Foo()
    Tree_Attributes.value = Attributes_value
    Tree_Attributes.attr = Attributes_name
    _variables = {'bar': 'baz'}
    Replacer = VariablesReplacer(_variables)
    Replacer.visit_Attribute(Tree_Attributes)
    assert(Tree_Attributes.value.id == 'baz')

# Generated at 2022-06-23 23:45:25.053730
# Unit test for function let
def test_let():
    from astunparse import unparse

    code = """
        let(x)
        a = x + 1
        b = 1
    """
    tree = ast.parse(code)
    variables = find_variables(tree)
    # We expect that x is the only generated variable
    assert len(variables) == 1
    assert 'x' in variables
    
    # Now we replace x with another name and do replace
    # if we had multiple x as variables, they would be replaced as well
    variables['x'] = '_py_backwards_x_0'
    VariablesReplacer.replace(tree, variables)
    
    # Unparse the tree to make sure that everything is OK,
    # and the only thing we should see is a = _py_backwards_x_0
    code = unparse(tree)
    expected

# Generated at 2022-06-23 23:45:28.008245
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars); print(x, y)')
    vars = ast.parse('x = 1; x = 2')
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse('x = 1; x = 2; print(x, y)'))

# Generated at 2022-06-23 23:45:31.978888
# Unit test for function find_variables
def test_find_variables():
    source = """
        let(x)
        let(y)
        var = x + y
        z = x * y
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert 'x' in variables
    assert 'y' in variables
    assert 'var' not in variables
    assert 'z' not in variables

# Generated at 2022-06-23 23:45:43.313362
# Unit test for function let
def test_let():
    class A: pass
    
    # Declare value
    @snippet
    def test_snippet():
        let(A)
        A.x = 1
        print(A.x)
        
    new_code = test_snippet.get_body()
    assert new_code == ast.parse('''
_py_backwards_A_0.x = 1
print(_py_backwards_A_0.x)
''').body
    
    # Let can be also used without call
    @snippet
    def test_snippet():
        let(a)
        a += 1
        print(a)
        
    new_code = test_snippet.get_body()

# Generated at 2022-06-23 23:45:49.256555
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_code():
        let(y)
        y = 2
        let(x)
        x = 3

    assert snippet_code.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_y_0', ctx=ast.Store())],
            value=ast.Num(n=2)),
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_1', ctx=ast.Store())],
            value=ast.Num(n=3)),
    ]



# Generated at 2022-06-23 23:45:58.520367
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    from .tree import ast_to_source
    # The snippet is:
    # def foo(x=let(var)):
    #     foo(a=1)
    #
    # The transformed snippet:
    # def foo(x=_py_backwards_var_0):
    #     foo_0(a=1)
    #
    # The expected snippet:
    # def foo(x=_py_backwards_var_1):
    #     foo_0(a=1)
    def foo(x=let(var)):
        foo(a=1)

    source = get_source(foo)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name) for name in names}
    VariablesReplacer

# Generated at 2022-06-23 23:46:09.495509
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    source = """
    def test():
        a.b.c
    """
    tree = ast.parse(source)
    variables = {'a': ['b', 'c', 'd']}
    VariablesReplacer.replace(tree, variables)

    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=\'test\', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), body=[Expr(value=Attribute(value=Attribute(value=Name(id=\'b\', ctx=Load()), attr=\'c\', ctx=Load()), attr=\'d\', ctx=Load()))], decorator_list=[])])'

    source = """
    def test():
        a.b.c

    a.b.c
    """


# Generated at 2022-06-23 23:46:13.430007
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    code_ex = 'a.b.c.d.e'
    ast_node = ast.parse(code_ex)
    variables = {
        'a': 'test_1',
        'c': 'test_2'
    }
    result = VariablesReplacer.replace(ast_node, variables)
    assert get_source(result) == 'test_1.b.test_2.d.e'

# Generated at 2022-06-23 23:46:14.612952
# Unit test for constructor of class snippet
def test_snippet():
    s = snippet(lambda: None)

    assert isinstance(s, snippet)

# Generated at 2022-06-23 23:46:17.381566
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse("""
        let(x)
        let(y)
        x + y
    """)) == ['x', 'y']



# Generated at 2022-06-23 23:46:26.789938
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class DummyVar:
        pass
    dummy_var = DummyVar()


# Generated at 2022-06-23 23:46:29.982209
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    nodes = ast.parse("""
    def foo(x: int, y: list):
        pass
    """).body[0]
    nodes.args.args[0].arg = 100
    variables = {'foo': 'foo'}

    assert VariablesReplacer(variables).visit_FunctionDef(nodes).args.args[0].arg == 'foo'



# Generated at 2022-06-23 23:46:37.466455
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    class TestNodeTransformer(ast.NodeTransformer):
        @staticmethod
        def visit_Name(node):
            node.id = '_py_backwards_' + node.id
            return node

    tree = ast.parse('x = 1')
    variables = {'x': TestNodeTransformer.visit_Name(ast.parse('x').body[0].value)}
    VariablesReplacer.replace(tree, variables)
    assert '_py_backwards_x_0 = 1' == ast.dump(tree)


# Unit tests for class snippet

# Generated at 2022-06-23 23:46:46.490760
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x, y, z = None, None, None
    @snippet
    def mysnippet(a, b=x):
        let(x)
        x = 1
        y = 2
        z = x + y
        return a, b, z

# Generated at 2022-06-23 23:46:52.583015
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('''
    import a as b
    import c as d
    ''')
    variables = {'b': 'b1', 'd': 'd1'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)

    expected = ast.parse('''
    import a as b1
    import c as d1
    ''')

    assert tree == expected

# Generated at 2022-06-23 23:46:57.563423
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # arrange
    source = 'from a.b.c import A'
    tree = ast.parse(source)
    expected = 'from a.b.b.c import A'
    variables = {'a': 'a.b'}
    # act
    result = VariablesReplacer.replace(tree,variables)
    # assert
    assert expected == get_source(result)


# Generated at 2022-06-23 23:47:00.414004
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class MockedNode(ast.AST):
        def __init__(self, keyword):
            self.keyword = keyword

    expr_kwargs = MockedNode(
        ast.keyword(arg=None, value=None)
    )
    replacer = VariablesReplacer({None: 'new_name'})

    new_kwargs = replacer.visit(expr_kwargs)
    assert new_kwargs.keyword.arg == 'new_name'

# Generated at 2022-06-23 23:47:01.312825
# Unit test for function extend_tree

# Generated at 2022-06-23 23:47:04.406874
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    tree = ast.parse("def f(arg=1):\n    pass")
    assert VariablesReplacer.replace(tree, {}).body[0].args[0].arg == 'arg'

# Generated at 2022-06-23 23:47:14.058796
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(x: ast.Name, y: ast.Name) -> None:
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-23 23:47:17.468723
# Unit test for function let
def test_let():
    @eager
    def foo():
        let(x)
        x += 1
    tree = ast.parse(get_source(foo))
    tree = find_variables(tree)
    assert next(tree) == 'x'

# Generated at 2022-06-23 23:47:23.633716
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse("""
    def f(a,b):
        def f2(c):
            return c + d
    """)
    vars = {'f': 'f_1'}
    VariablesReplacer.replace(tree, vars)
    assert tree == ast.parse("""
    def f_1(a,b):
        def f2(c):
            return c + d
    """)



# Generated at 2022-06-23 23:47:28.904095
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse("""try:
        1
    except Exception as e:
        print(e)
    except IndexError:
        pass""")

    variables = {}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == """try:
    1
except Exception as e:
    print(e)
except IndexError:
    pass"""

# Generated at 2022-06-23 23:47:29.837577
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    pass  # Just type check

# Generated at 2022-06-23 23:47:39.327365
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    ali = ast.alias(name='a', asname=None)
    ali = VariablesReplacer.replace(ali, {'a': 'b'})
    assert isinstance(ali, ast.alias)
    assert ali.name == 'b'
    assert ali.asname is None

    ali = ast.alias(name='a.b.c', asname=None)
    ali = VariablesReplacer.replace(ali, {'a': 'b'})
    assert isinstance(ali, ast.alias)
    assert ali.name == 'b.b.c'
    assert ali.asname is None

    ali = ast.alias(name='a.b.c', asname='d')
    ali = VariablesReplacer.replace(ali, {'a': 'b', 'd': 'e'})

# Generated at 2022-06-23 23:47:47.554350
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Name(id='x')],
        keywords=[ast.keyword(
            arg='sep',
            value=ast.Str(s=' '),
        )],
    )

    replacer = VariablesReplacer(
        {
            'print': 'print2',
            'x': 'y',
            'sep': 'z',
        },
    )

    node = replacer.visit_keyword(node)
    assert node.arg == 'z'



# Generated at 2022-06-23 23:47:55.762853
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    expected = """def _py_backwards_func_0(arg1, arg2):\n    pass"""
    branch1 = ast.FunctionDef(
        name="func",
        args=ast.arguments(
            args=[
                ast.arg(arg="arg1", annotation=None),
                ast.arg(arg="arg2", annotation=None)],
            defaults=[],
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            vararg=None
        ),
        body=[
            ast.Pass()
        ],
        decorator_list=[],
        returns=None
    )


# Generated at 2022-06-23 23:48:06.678786
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    module = ast.parse("""
    try:
        pass
    except Exception as e:
        print(e)
    """)
    
    error_type = ast.ExceptHandler()
    error_type.name = ast.Name(id="error")
    
    module.body[0].body[0].handlers.append(error_type)
    
    VariablesReplacer.replace(module, {"error": "Exception"})
    
    # Should be:
    # try:
    #     pass
    # except Exception as Exception:
    #     print(Exception)
    #
    # not:
    # try:
    #     pass
    # except Exception as e:
    #     print(e)
    #



# Generated at 2022-06-23 23:48:07.310449
# Unit test for constructor of class snippet
def test_snippet():
    snippet

# Generated at 2022-06-23 23:48:10.804736
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    variables = {'x': '_py_backwards_x_0'}
    tree = ast.parse('print(x)')
    VariablesReplacer(variables).visit(tree)
    assert get_source(tree) == 'print(_py_backwards_x_0)'

# Generated at 2022-06-23 23:48:16.663117
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():

    node = ast.ClassDef(name='lol',
                        bases=[ast.Name(id='super_lol', ctx=ast.Load())],
                        keywords=[],
                        body=[], decorator_list=[])
    v = {'lol': 'not_lol'}
    result = VariablesReplacer.replace(node, v)
    assert result.name == 'not_lol'


# Generated at 2022-06-23 23:48:22.837700
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = let(5)
    b = let(7)
    c = let(3)

    def fn():
        c += a + b

    ast_body = snippet(fn).get_body()

    expected = '''
_py_backwards_c_0 += _py_backwards_a_0 + _py_backwards_b_0
'''
    assert str(ast_body) == expected



# Generated at 2022-06-23 23:48:24.788665
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('from date.datetime import date')
    variables = {'date.datetime': 'datetime'}
    VariablesReplacer.replace(tree, variables)
    assert tree == ast.parse('from datetime import date')

# Generated at 2022-06-23 23:48:26.383534
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse("def fn(a): return a + 1")
    res = VariablesReplacer.replace(tree, {'a': 2})

# Generated at 2022-06-23 23:48:33.839760
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg(): # noqa
    var_name = "test_name"
    argument = ast.arg(arg=var_name, annotation=None)
    variable = "test_variable_name"
    replacer = VariablesReplacer({var_name: variable})
    assert replacer._replace_field_or_node(argument, "arg") == variable
    assert replacer._replace_field_or_node(argument, "annotation") == None

# Generated at 2022-06-23 23:48:36.889503
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    replacer = VariablesReplacer({"id": "new_id"})
    node1 = ast.Name("id", ast.Load())
    node2 = ast.Name("name", ast.Load())
    assert replacer.visit(node1) == ast.Name("new_id", ast.Load())
    assert node2 == replacer.visit(node2)


# Generated at 2022-06-23 23:48:42.340331
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    vars = {"something": "else"}
    source = "import something"
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, vars)
    assert get_source(tree) == "import else"

# Generated at 2022-06-23 23:48:45.976219
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    tree = ast.parse('def x(): pass')
    VariablesReplacer.replace(tree, {'x': '_v'})
    source = ast.fix_missing_locations(tree).body[0].name
    assert source == "_v", source

# Generated at 2022-06-23 23:48:52.294179
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    global x, y, z
    def f():
        print(x, y, z)

    var_map = {'x': 'a', 'y': ast.Name(lineno=0, col_offset=0, id='b'), 'z': 'c'}
    VariablesReplacer.replace(ast.parse(get_source(f)), var_map)

    assert_equals(f"print(a, b, c)", get_source(f))


# Generated at 2022-06-23 23:49:01.027790
# Unit test for function extend
def test_extend():
    def _extend():
        extend(_vars)

        print(x)

    _vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=1))]
    _body = snippet(_extend).get_body(_vars=_vars)
    assert len(_body) == 2
    assert isinstance(_body[0], ast.Assign)
    assert isinstance(_body[1], ast.Expr)
    assert isinstance(_body[1].value, ast.Call)
    assert isinstance(_body[1].value.func, ast.Name)  # type: ignore
    assert _body[1].value.func.id == 'print'  # type: ignore
    assert _body[1].value.args[0].id == 'x'  # type

# Generated at 2022-06-23 23:49:09.091720
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import sys
    import ast
    module = ast.Module([ast.ImportFrom("arange", ["arange"], 0)])
    expected = ast.Module([ast.ImportFrom("linspace", ["linspace"], 0)])
    variables = {'arange': 'linspace'}
    assert module == VariablesReplacer.replace(module, variables)
    assert module == expected

# Generated at 2022-06-23 23:49:17.235805
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = 'from cls import cls'
    tree_alias = ast.parse(source)
    VariablesReplacer.replace(tree_alias, {"cls": "bla"})
    # It's a workaround because typed_ast automatically changes the form of the AST tree
    source_new = ast.unparse(tree_alias)
    if 'from bla import cls' != source_new:
        raise Exception('Method visit_alias of class VariablesReplacer does not work properly')

# Generated at 2022-06-23 23:49:23.235524
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    var = ast.Name('var', ast.Param())
    node = ast.arg('var_ar', None, None, None)
    replacer = VariablesReplacer({'var': var})
    assert replacer.visit_arg(node) == ast.arg('var', None, None, None)



# Generated at 2022-06-23 23:49:26.707749
# Unit test for constructor of class snippet
def test_snippet():
    assert True

# Generated at 2022-06-23 23:49:27.660214
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-23 23:49:32.880591
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class NodeVisitor2(ast.NodeVisitor):
        def visit_ClassDef(self, node):
            print(node.lineno, node.col_offset, node.name)

    class A:
        pass

    tree = ast.parse(get_source(A))
    node_visitor = NodeVisitor2()
    node_visitor.visit(tree)

# Generated at 2022-06-23 23:49:40.337328
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = 'from src.app.pages.org.dashboard import DashboardPage'
    tree = ast.parse(source)
    alias = tree.body[0].names[0]
    variables = {'src': 's', 'app': 'a', 'pages': 'p', 'org': 'o', 'DashboardPage': 'dp'}
    visit_alias_tree = VariablesReplacer.replace(tree, variables)
    alias_visited = visit_alias_tree.body[0].names[0]
    assert alias_visited.name == 's.a.p.o.dp'

# Generated at 2022-06-23 23:49:51.615124
# Unit test for function extend
def test_extend():
    class SomeBody:
        def __init__(self, body: List[ast.AST]) -> None:
            self._body = body

    @snippet
    def snippet(x: SomeBody):
        extend(x)

    body = snippet(
        x=SomeBody(
            [
                ast.Assign(
                    [ast.Name('x')],
                    ast.Num(1)
                )
            ]
        )).get_body()

    assert len(body) == 1
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].targets[0], ast.Name)
    assert isinstance(body[0].targets[0].id, str)
    assert body[0].targets[0].id == 'x'



# Generated at 2022-06-23 23:49:56.816434
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 23:50:07.648596
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    node = ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Name(id='x', ctx=ast.Load())],
        keywords=[ast.keyword(arg='a', value=ast.Num(n=1))]
    )
    variables = {
        'x': ast.Num(n=2),
        'a': ast.Num(n=2),
        'print': ast.Name(id='print', ctx=ast.Load())
    }
    VariablesReplacer.replace(node, variables)

# Generated at 2022-06-23 23:50:16.363186
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    body = snippet(snippet_fn).get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[0].value, ast.Num)
    assert body[0].value.n == 1
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[1].value, ast.Num)
    assert body[1].value.n == 1

# Generated at 2022-06-23 23:50:21.602786
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("""
foo(a=let(b))
""")

    variables = {'b': 'c'}
    node = VariablesReplacer.replace(tree, variables)
    assert node.body[0].value.keywords[0].arg == 'c'



# Generated at 2022-06-23 23:50:22.640636
# Unit test for method visit_ExceptHandler of class VariablesReplacer

# Generated at 2022-06-23 23:50:30.836219
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    import ast  # Needed to be imported to pass mypy check
    variables_replacer = VariablesReplacer(variables={'a':'b'})

    # Base case
    assert isinstance(variables_replacer.visit(ast.Name('a', ast.Load())), ast.Name)

    # Test case where name of the Name object is in dict of variables
    node = ast.Name('a', ast.Load())
    node_result = variables_replacer.visit(node)
    assert isinstance(node_result, ast.Name)
    assert node_result.id == 'b'
    assert isinstance(node_result.ctx, ast.Load)



# Generated at 2022-06-23 23:50:31.793792
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda x: 1)

# Start of public declarations

# Generated at 2022-06-23 23:50:35.403664
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class A:
        def foo():
            pass

    tree = ast.parse('''
    class A:\n
        def foo():\n
            pass
    ''')

    variables = {'A': 'B'}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].name == 'B'  # type: ignore

# Generated at 2022-06-23 23:50:40.371265
# Unit test for function find_variables
def test_find_variables():
    code = '''
    let(x)
    x += 1
    '''
    tree = ast.parse(code)
    r = find_variables(tree)
    assert(next(r) == 'x')

# Generated at 2022-06-23 23:50:50.426504
# Unit test for function let
def test_let():
    @snippet
    def function():
        let(x)
        x += 1
        y = 1

    assert function.get_body() == [ast.AugAssign(
        target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
        op=ast.Add(),
        value=ast.Num(n=1),
        lineno=1,
        col_offset=0,
    ), ast.Assign(
        targets=[ast.Name(id='y', ctx=ast.Store())],
        value=ast.Num(n=1),
        lineno=2,
        col_offset=0
    )]


# Generated at 2022-06-23 23:50:52.535413
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
a = 'a'
let(b)
c = 'c'
let(d)
    """)
    vars = list(find_variables(tree))
    assert vars == ['b', 'd']

# Generated at 2022-06-23 23:50:59.046770
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    from .helpers import _get_source
    source = _get_source(test_VariablesReplacer_visit_keyword)
    tree = ast.parse(source)
    replace_dict = {'abc': 'abc_changed'}
    replacer = VariablesReplacer(replace_dict)
    replacer.visit(tree)
    compiled = compile(tree, '<string>', 'exec')
    exec(compiled, {})

# Generated at 2022-06-23 23:50:59.985489
# Unit test for constructor of class snippet
def test_snippet():
    snippet(test_snippet)

# Generated at 2022-06-23 23:51:01.053728
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:51:05.107858
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x + 1
    """

    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}
    assert get_source(tree) == 'x + 1'



# Generated at 2022-06-23 23:51:12.424694
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    old_name = ast.Name(id="old_name", ctx=ast.Load())
    new_name = ast.Name(id="new_name", ctx=ast.Load())
    assignment = ast.Assign(targets=[old_name], value=ast.Constant(value=0))
    variables = dict(old_name=new_name)
    VariablesReplacer.replace(assignment, variables)
    ast.dump(assignment) == "Assign(targets=[Name(id='new_name', ctx=Load())], value=Constant(value=0))"

# Generated at 2022-06-23 23:51:13.380688
# Unit test for constructor of class snippet
def test_snippet():
    snippet('snippet name')

# Generated at 2022-06-23 23:51:20.333818
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    """Unit test for constructor of class VariablesReplacer."""
    tree = ast.parse(
        "def f():"
        "    let(x)"
        "    let(y)"
        "    return x"
    )
    ret = tree.body[0].body[1].value
    assert isinstance(ret, ast.Name)
    assert ret.id == 'x'
    variables = {'x': 'y', 'y': [ast.parse('x = 1')]}
    VariablesReplacer.replace(tree, variables)
    ret = tree.body[0].body[1].value
    assert isinstance(ret, ast.Name)
    assert ret.id == 'y'
    assert isinstance(tree.body[0].body[0], ast.Assign)

# Generated at 2022-06-23 23:51:32.056595
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    variables = {'x': '_py_backwards_x_0', 'y': '_py_backwards_y_0'}
    tree = ast.parse('x = 1')
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].targets[0].id == '_py_backwards_x_0'
    tree = ast.parse('x.y = 1')
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].targets[0].attr == '_py_backwards_y_0'
    tree = ast.parse('func(x, y=1)')
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].args[0].id == '_py_backwards_x_0'
   

# Generated at 2022-06-23 23:51:41.055087
# Unit test for constructor of class snippet
def test_snippet():
    @snippet
    def foo():
        a = 2
        let(a)
        a += 1
        b = 2
        print(b)

    assert foo.get_body() == [
        ast.Assign([ast.Name('b', ast.Store())], ast.Num(2)),
        ast.AugAssign(ast.Name(_py_backwards_a_0, ast.Store()),
                      ast.Add(), ast.Num(1)),
        ast.Expr(ast.Call(ast.Name('print', ast.Load()),
                    [ast.Name('b', ast.Load())], [], None, None))
    ]

# Generated at 2022-06-23 23:51:43.936397
# Unit test for function find_variables
def test_find_variables():
    def _check_variables_in_tree(expr: str, variables: List[str]) -> None:
        tree = ast.parse(expr)
        result = list(find_variables(tree))
        assert result == variables


# Generated at 2022-06-23 23:51:50.990586
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class TestException(Exception): pass
    test_src = '''
    try:
        raise TestException
    except TestException:
        raise TestException
    '''
    test_tree = ast.parse(test_src)
    variables = {'TestException': 'TestException2'}
    node_transformer = VariablesReplacer(variables)
    new_tree = node_transformer.visit(test_tree)

    except_handler = new_tree.body[0].handlers[0]
    assert isinstance(except_handler.type, ast.Name)
    assert except_handler.type.id == variables['TestException']

    except_handler = new_tree.body[0].body[0].handlers[0]
    assert isinstance(except_handler.type, ast.Name)

# Generated at 2022-06-23 23:51:58.057582
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    from .ast_checker import assert_ast_equal

    class TestVariablesReplacer(ast.NodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            return 3

    tree = ast.parse("x = 1")
    TestVariablesReplacer.replace(tree, {})
    assert_ast_equal(ast.parse("x = 3"), tree)

# Generated at 2022-06-23 23:52:01.909513
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    class Foo:
        def foo(self):
            pass
    
    source = get_source(Foo)
    tree = ast.parse(source)
    variables = {'Foo': 'Foo1'}
    
    VariablesReplacer(variables).replace(tree, variables)
    assert tree.body[0].name == 'class Foo1:', (
        "Variables should be replaced in ImportFrom"
    )

# Generated at 2022-06-23 23:52:02.535047
# Unit test for method visit_ClassDef of class VariablesReplacer

# Generated at 2022-06-23 23:52:05.033264
# Unit test for function let
def test_let():
    _py_backwards_a_0 = 1
    def fn():
        let(a)
        a += 1
    fn()
    assert _py_backwards_a_0 == 1 + 1


# Generated at 2022-06-23 23:52:11.791728
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Name(ast.AST):
        pass
    class ClassDef(ast.AST):
        pass
    class FunctionDef(ast.AST):
        pass
    class Attribute(ast.AST):
        pass
    class keyword(ast.AST):
        pass
    class arg(ast.AST):
        pass
    class ImportFrom(ast.AST):
        pass
    class alias(ast.AST):
        pass
    class ExceptHandler(ast.AST):
        pass

    class Tree:
        pass
    class node :
        pass
    class ast :
        Name = Name
        ClassDef = ClassDef
        FunctionDef = FunctionDef
        Attribute = Attribute
        keyword = keyword
        arg = arg
        ImportFrom = ImportFrom
        alias = alias
        ExceptHandler = ExceptHandler

    tree_instance= Tree()

    tree

# Generated at 2022-06-23 23:52:12.340080
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-23 23:52:13.482260
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-23 23:52:21.564593
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    # Test with no change
    node = ast.Name(id='name', ctx = ast.Load())
    variables = {}
    replacer = VariablesReplacer(variables)
    node = replacer.visit_ClassDef(node)
    assert node == node
    # Test with change
    variables = {'name': 'new_name'}
    replacer = VariablesReplacer(variables)
    node = replacer.visit_ClassDef(node)
    assert node is not None
    assert node.id == 'new_name'


# Generated at 2022-06-23 23:52:26.721819
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    variable = ast.Name(id='x', ctx=ast.Store())
    node = ast.arg(arg='x', annotation=None)
    replacer = VariablesReplacer({'x': variable})
    result = replacer.visit_arg(node)
    assert(result == variable)



# Generated at 2022-06-23 23:52:27.978873
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer({"x": "1", "y": "2"}) is not None

# Generated at 2022-06-23 23:52:36.004702
# Unit test for function extend
def test_extend():
    x = 1
    y = 2 # noqa
    let(x)
    let(y)
    let(vars)
    vars = [
        ast.Assign(targets=[ast.Name(id=x, ctx=ast.Store())], value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id=x, ctx=ast.Store())], value=ast.Num(n=2)),
        ast.Assign(targets=[ast.Name(id=y, ctx=ast.Store())], value=ast.Num(n=3))
    ]
    extend(vars)
    assert x == 2
    assert y == 3

# Generated at 2022-06-23 23:52:39.749341
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = """
    try:
        a = 1
    except Exception as e:
        pass
    """
    tree = ast.parse(source)
    tree2 = VariablesReplacer.replace(tree, {'e': 'my_e'})
    assert ast.dump(tree) == ast.dump(tree2)

# Generated at 2022-06-23 23:52:45.156744
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    source = 'def func(arg_name_0):\n    pass'
    tree = ast.parse(source)

    VariablesReplacer.replace(tree, {'arg_name_0': 'arg_name'})
    source2 = ast.unparse(tree)
    assert source2 == 'def func(arg_name):\n    pass'



# Generated at 2022-06-23 23:52:51.958745
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    def let_test():
        let(x)
        let(y)
        x += 1
        y += 2
    f = ast.parse(get_source(let_test))
    r = VariablesReplacer({'x': '_py_backwards_x_0', 'y': '_py_backwards_y_1'})
    r.visit(f)

# Generated at 2022-06-23 23:53:01.875469
# Unit test for function extend
def test_extend():
    from .helpers import get_variable_names
    import astor
    def foo():
        extend({
            "a": ast.Assign(targets=[ast.Name(id="x", ctx=ast.Store())], value=ast.Num(n=1)),
            "b": ast.Assign(targets=[ast.Name(id="y", ctx=ast.Store())], value=ast.Num(n=2))
        })
        print(x, y)
    tree = ast.parse(get_source(foo))