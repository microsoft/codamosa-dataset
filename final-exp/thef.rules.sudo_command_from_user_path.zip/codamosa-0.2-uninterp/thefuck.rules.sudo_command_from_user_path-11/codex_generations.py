

# Generated at 2022-06-18 08:44:14.563976
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:44:19.476368
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 0))


# Generated at 2022-06-18 08:44:22.272830
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:44:24.946121
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:44:26.855497
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('sudo apt-get install', '', ''))


# Generated at 2022-06-18 08:44:37.342187
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l -a', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a'
    assert get_new_command(Command('sudo ls -l -a -h', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a -h'

# Generated at 2022-06-18 08:44:39.477086
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:44:43.088352
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:44:44.578818
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:44:45.906869
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command found'))


# Generated at 2022-06-18 08:44:50.158215
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo "test"', 'sudo: echo: command not found')) == 'env "PATH=$PATH" echo "test"'

# Generated at 2022-06-18 08:44:56.430459
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found\n'))


# Generated at 2022-06-18 08:45:01.266721
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))


# Generated at 2022-06-18 08:45:04.045559
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:45:13.532807
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install python3-pip', ''))
    assert not match(Command('sudo apt-get install python3-pip', '',
                             'E: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)\n'
                             'E: Unable to lock the administration directory (/var/lib/dpkg/), are you root?\n'))
    assert not match(Command('sudo apt-get install python3-pip', '',
                             'E: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)\n'
                             'E: Unable to lock the administration directory (/var/lib/dpkg/), are you root?\n'))

# Generated at 2022-06-18 08:45:15.912861
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:45:18.567364
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:45:20.278180
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:45:25.061009
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', '', '', ''))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', '', '', ''))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', '', '', ''))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', '', '', ''))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', '', '', ''))

# Generated at 2022-06-18 08:45:27.893007
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:45:32.321453
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:45:35.012634
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'vim: command not found'))


# Generated at 2022-06-18 08:45:37.419482
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', ''))


# Generated at 2022-06-18 08:45:40.959579
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:45:43.574736
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update',
                             'sudo: apt-get: command not found'))

# Generated at 2022-06-18 08:45:44.565433
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:45:46.348315
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:45:49.594199
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:45:51.597279
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:45:53.220276
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo ls', 'sudo: ls: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:46:07.577088
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 2))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 3))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 4))

# Generated at 2022-06-18 08:46:17.013359
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))

# Generated at 2022-06-18 08:46:20.623272
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', ''))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 1))


# Generated at 2022-06-18 08:46:23.619211
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-18 08:46:26.479729
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:46:28.928436
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:46:30.711002
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:46:33.086605
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install vim', '')) == 'env "PATH=$PATH" apt-get install vim'

# Generated at 2022-06-18 08:46:35.076253
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:46:37.764325
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:46:46.017978
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    from thefuck.types import Command
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:46:47.842836
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo ls', 'sudo: ls: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:46:49.881544
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:46:51.551715
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:46:54.536391
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:46:57.029647
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:46:59.264104
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install vim', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install vim'

# Generated at 2022-06-18 08:47:00.968826
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:47:03.438357
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 1))


# Generated at 2022-06-18 08:47:05.031044
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:47:15.963591
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim',
                             'sudo: apt-get: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo apt-get install vim',
                             'E: Unable to locate package vim'))


# Generated at 2022-06-18 08:47:18.360923
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:47:21.102120
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:47:23.265222
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', ''))
    assert not match(Command('sudo apt-get install vim', '', ''))


# Generated at 2022-06-18 08:47:26.482264
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:47:34.343589
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found',
                             stderr='sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found',
                             stderr='sudo: apt-get: command not found',
                             stdout='sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:47:36.421121
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:47:45.664824
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))

# Generated at 2022-06-18 08:47:55.204858
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l -a', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a'
    assert get_new_command(Command('sudo ls -l -a -h', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a -h'

# Generated at 2022-06-18 08:48:04.272888
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))


# Generated at 2022-06-18 08:48:11.991061
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:48:14.632549
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:48:16.290580
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:48:20.216437
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:48:23.239569
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    from thefuck.types import Command
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:48:25.437790
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:48:27.394272
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo vim', 'sudo: vim: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" vim'

# Generated at 2022-06-18 08:48:29.821644
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:48:32.596887
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:48:35.827736
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:48:51.446018
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts',
                             'sudo: 3 incorrect password attempts',
                             'sudo: 3 incorrect password attempts'))

# Generated at 2022-06-18 08:48:53.682631
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-18 08:48:57.103510
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:48:59.194063
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:49:02.381586
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:49:07.195462
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found',
                             stderr='sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found',
                             stderr='sudo: apt-get: command not found',
                             stdout='sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:49:10.316757
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:49:12.611048
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:49:14.728577
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install', '')) == 'env "PATH=$PATH" apt-get install'
    assert get_new_command(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-18 08:49:17.787773
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:49:26.211293
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:49:28.245333
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:49:36.318257
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 1))

# Generated at 2022-06-18 08:49:39.156292
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 1))


# Generated at 2022-06-18 08:49:45.761015
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', ''))
    assert not match(Command('sudo apt-get update', 'E: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)\nE: Unable to lock the administration directory (/var/lib/dpkg/), are you root?\n'))
    assert not match(Command('sudo apt-get update', 'E: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)\nE: Unable to lock the administration directory (/var/lib/dpkg/), are you root?\n'))


# Generated at 2022-06-18 08:49:47.756313
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:49:49.947854
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:49:52.487012
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:49:54.760225
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:49:57.019288
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:50:06.262239
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', '', '', '', '', ''))


# Generated at 2022-06-18 08:50:07.577435
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:09.482717
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', '', '', '', ''))


# Generated at 2022-06-18 08:50:12.801770
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:50:15.524054
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:50:24.639672
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))

# Generated at 2022-06-18 08:50:26.836121
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:50:29.514732
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', '', '', '', ''))


# Generated at 2022-06-18 08:50:32.055496
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:33.967877
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:42.094647
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:50:43.725820
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:45.303094
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:49.460559
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'sudo: vim: command not found',
                             'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'sudo: vim: command not found',
                             'sudo: vim: command not found',
                             'sudo: vim: command not found'))


# Generated at 2022-06-18 08:50:51.080634
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:52.319508
# Unit test for function match
def test_match():
    assert match(Command('sudo echo', ''))
    assert not match(Command('sudo echo', '', ''))


# Generated at 2022-06-18 08:50:56.127358
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:00.421375
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', '', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', '', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:02.828884
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:08.022600
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l -a', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a'
    assert get_new_command(Command('sudo ls -l -a -h', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a -h'

# Generated at 2022-06-18 08:51:20.088966
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 123))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 123))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 123))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 123))


# Generated at 2022-06-18 08:51:22.874729
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'sudo: vim: command not found',
                             stderr='sudo: vim: command not found'))


# Generated at 2022-06-18 08:51:23.984935
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:25.493256
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:27.105777
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command found'))


# Generated at 2022-06-18 08:51:29.461519
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:31.551683
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:34.459003
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:36.384972
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:38.705991
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:47.210258
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:49.253133
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:51.430196
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:55.131443
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'E: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)\nE: Unable to lock the administration directory (/var/lib/dpkg/), are you root?'))


# Generated at 2022-06-18 08:51:57.171052
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:59.095249
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:52:04.633135
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 1))

# Generated at 2022-06-18 08:52:09.253882
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install',
                             'sudo: apt-get: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo apt-get install',
                             'E: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)'))


# Generated at 2022-06-18 08:52:17.002933
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 123))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 123))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 123))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 123))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 123))

# Generated at 2022-06-18 08:52:20.543298
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 0))


# Generated at 2022-06-18 08:52:29.390769
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:52:31.831623
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-18 08:52:34.356070
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:52:36.791193
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:52:38.752722
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:52:40.419843
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:52:42.970101
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 123))


# Generated at 2022-06-18 08:52:46.062293
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found',
                             'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:52:47.955755
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install vim', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install vim'

# Generated at 2022-06-18 08:52:55.191567
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found',
                             stdout='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found',
                             stdout='sudo: ls: command not found',
                             script='sudo ls'))


# Generated at 2022-06-18 08:53:10.447611
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))

# Generated at 2022-06-18 08:53:13.013021
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:14.675729
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:17.136376
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:53:19.014448
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:22.061913
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:53:24.691007
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:53:29.310100
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:53:32.230359
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:53:34.603041
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found', '')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:41.121186
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:42.798430
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:46.059101
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:53:47.945683
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:51.118963
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('sudo apt-get install', '', ''))


# Generated at 2022-06-18 08:53:54.451787
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:53:56.358467
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:58.504442
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo ls', 'sudo: ls: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:54:00.546637
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', ''))


# Generated at 2022-06-18 08:54:02.863770
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-18 08:54:11.001090
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))
