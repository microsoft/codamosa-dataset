

# Generated at 2022-06-18 08:44:14.109847
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-18 08:44:18.313744
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get install', ''))


# Generated at 2022-06-18 08:44:20.774342
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('sudo apt-get install', 'E: Unable to locate package'))


# Generated at 2022-06-18 08:44:24.863160
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', ''))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:44:26.811683
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:44:33.789418
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', ''))
    assert not match(Command('sudo apt-get update', 'E: Could not open lock file /var/lib/apt/lists/lock - open (13: Permission denied)\nE: Unable to lock directory /var/lib/apt/lists/\nE: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)\nE: Unable to lock the administration directory (/var/lib/dpkg/), are you root?\n'))


# Generated at 2022-06-18 08:44:37.480337
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))


# Generated at 2022-06-18 08:44:40.613714
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:44:43.469815
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:44:45.165169
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:44:51.225852
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:44:53.912287
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get update', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get update'

# Generated at 2022-06-18 08:44:57.203338
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))



# Generated at 2022-06-18 08:45:06.630567
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found',
                             stdout='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found',
                             stdout='sudo: ls: command not found',
                             script='sudo ls'))

# Generated at 2022-06-18 08:45:09.655592
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:45:12.766122
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 123))


# Generated at 2022-06-18 08:45:16.310683
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:45:18.283607
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:45:20.881241
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))


# Generated at 2022-06-18 08:45:25.114362
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:45:30.532595
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:45:40.900429
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))

# Generated at 2022-06-18 08:45:42.658314
# Unit test for function match
def test_match():
    assert match(Command('sudo echo', ''))
    assert not match(Command('sudo echo', '', ''))


# Generated at 2022-06-18 08:45:44.284014
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', ''))


# Generated at 2022-06-18 08:45:50.285714
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found',
                             stdout='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found',
                             stdout='sudo: ls: command not found',
                             script='sudo ls'))

# Generated at 2022-06-18 08:45:53.402480
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:45:55.725511
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', ''))


# Generated at 2022-06-18 08:46:05.157031
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))

# Generated at 2022-06-18 08:46:13.047316
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l -a', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a'
    assert get_new_command(Command('sudo ls -l -a -h', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a -h'

# Generated at 2022-06-18 08:46:17.396510
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 1))


# Generated at 2022-06-18 08:46:23.135834
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:46:33.129966
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             '', '', '', '', '', ''))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             '', '', '', '', '', '', '', '', '', ''))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             '', '', '', '', '', '', '', '', '', '', ''))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             '', '', '', '', '', '', '', '', '', '', '', ''))

# Generated at 2022-06-18 08:46:36.865760
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:46:46.266325
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo ls') == 'env "PATH=$PATH" ls'
    assert get_new_command('sudo ls -l') == 'env "PATH=$PATH" ls -l'
    assert get_new_command('sudo ls -l -a') == 'env "PATH=$PATH" ls -l -a'
    assert get_new_command('sudo ls -l -a -h') == 'env "PATH=$PATH" ls -l -a -h'
    assert get_new_command('sudo ls -l -a -h -r') == 'env "PATH=$PATH" ls -l -a -h -r'
    assert get_new_command('sudo ls -l -a -h -r -t') == 'env "PATH=$PATH" ls -l -a -h -r -t'
    assert get_new_command

# Generated at 2022-06-18 08:46:55.051764
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l -a', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a'
    assert get_new_command(Command('sudo ls -l -a -h', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a -h'

# Generated at 2022-06-18 08:46:58.675074
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'E: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)'))


# Generated at 2022-06-18 08:47:01.309863
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:47:03.469478
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:47:05.595405
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', ''))


# Generated at 2022-06-18 08:47:07.361548
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-18 08:47:12.841596
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('sudo apt-get install', '', ''))


# Generated at 2022-06-18 08:47:14.992541
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:47:17.488785
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:47:20.009514
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo echo', 'sudo: echo: command not found')) == 'env "PATH=$PATH" echo'

# Generated at 2022-06-18 08:47:22.484705
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:47:29.552446
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', -1))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', None))


# Generated at 2022-06-18 08:47:32.169645
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('sudo apt-get install', '', ''))


# Generated at 2022-06-18 08:47:42.463583
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found\n')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found\n\n')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found\n\n\n')) == 'env "PATH=$PATH" ls -l'
   

# Generated at 2022-06-18 08:47:45.706064
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', '', '', '', ''))


# Generated at 2022-06-18 08:47:49.179967
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:47:54.629368
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:47:57.023317
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', ''))
    assert not match(Command('sudo apt-get install vim', '', ''))


# Generated at 2022-06-18 08:47:59.562211
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:48:08.064311
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found\nsudo: ls: command not found')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found\nsudo: ls: command not found\nsudo: ls: command not found')) == 'env "PATH=$PATH" ls -l'

# Generated at 2022-06-18 08:48:10.020939
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:48:11.641388
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', ''))


# Generated at 2022-06-18 08:48:21.088484
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found\n'))

# Generated at 2022-06-18 08:48:24.009065
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 1))


# Generated at 2022-06-18 08:48:26.337813
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('sudo apt-get install', '', ''))


# Generated at 2022-06-18 08:48:32.976973
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found',
                             stderr='sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found',
                             stderr='sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found',
                             stderr='sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:48:45.169172
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', -1))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', -2))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', -3))

# Generated at 2022-06-18 08:48:48.997036
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:48:52.463481
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found\n'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found\n'))


# Generated at 2022-06-18 08:48:54.574937
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get update', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get update'

# Generated at 2022-06-18 08:48:56.962011
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim', 'sudo: vim: command not found')) == 'env "PATH=$PATH" vim'

# Generated at 2022-06-18 08:48:59.064067
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:49:01.017098
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install', '')) == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-18 08:49:04.839812
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('sudo apt-get install', '', ''))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', ''))
    assert not match(Command('sudo apt-get install', 'E: Unable to locate package', ''))


# Generated at 2022-06-18 08:49:07.057745
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:49:09.220172
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found', '')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:49:14.261417
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:49:17.717206
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 1))


# Generated at 2022-06-18 08:49:20.064879
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('sudo apt-get install', '', ''))


# Generated at 2022-06-18 08:49:21.826690
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:49:25.332924
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:49:27.784724
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:49:30.504437
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 1))


# Generated at 2022-06-18 08:49:33.180679
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', ''))
    assert not match(Command('ls', 'sudo: ls: command not found'))


# Generated at 2022-06-18 08:49:34.854279
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:49:36.725542
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:49:42.326727
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'sudo: vim: command found'))


# Generated at 2022-06-18 08:49:44.794055
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:49:47.807876
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('sudo apt-get install', 'E: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)\nE: Unable to lock the administration directory (/var/lib/dpkg/), are you root?\n'))


# Generated at 2022-06-18 08:49:49.336387
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:49:51.776587
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install vim', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install vim'

# Generated at 2022-06-18 08:49:55.309508
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', '', '', '', ''))


# Generated at 2022-06-18 08:49:57.510463
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install vim',
                                   'sudo: apt-get: command not found')) == \
                                   'env "PATH=$PATH" apt-get install vim'

# Generated at 2022-06-18 08:50:00.099202
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:03.320762
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))


# Generated at 2022-06-18 08:50:05.774854
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:50:23.378289
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))


# Generated at 2022-06-18 08:50:25.399970
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:34.669462
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', -1))

# Generated at 2022-06-18 08:50:38.323950
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))


# Generated at 2022-06-18 08:50:40.662329
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:43.006998
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:44.697563
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:46.447358
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:50:48.814101
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:50:51.008696
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:50:58.640001
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:51:02.380458
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim',
                             'sudo: apt-get: command not found'))

# Generated at 2022-06-18 08:51:04.106486
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:06.995843
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:51:08.631888
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == u'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:10.470294
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:13.357338
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:51:15.851171
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:17.759201
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found'))

# Generated at 2022-06-18 08:51:25.433680
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: sorry, you must have a tty to run sudo'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: no tty present and no askpass program specified'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             'sudo: pam_authenticate: Conversation error'))

# Generated at 2022-06-18 08:51:31.183525
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:51:32.819362
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:36.001086
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:51:37.567701
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo ls', 'sudo: ls: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:40.141004
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:51:47.506702
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim',
                             'sudo: apt-get: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo apt-get install vim',
                             'sudo: apt-get: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo apt-get install vim',
                             'sudo: apt-get: command not found',
                             'sudo: 3 incorrect password attempts'))
    assert not match(Command('sudo apt-get install vim',
                             'sudo: apt-get: command not found',
                             'sudo: 3 incorrect password attempts'))

# Generated at 2022-06-18 08:51:49.549510
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-18 08:51:51.227175
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:53.000822
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:51:54.888880
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install vim', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install vim'

# Generated at 2022-06-18 08:51:59.424161
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:52:01.185718
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:52:02.466558
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:52:07.207555
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo ls -l -a', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a'
    assert get_new_command(Command('sudo ls -l -a -h', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls -l -a -h'

# Generated at 2022-06-18 08:52:09.465840
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', ''))
    assert not match(Command('vim', ''))


# Generated at 2022-06-18 08:52:17.185045
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', ''))
    assert not match(Command('sudo apt-get update', 'E: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)\nE: Unable to lock the administration directory (/var/lib/dpkg/), are you root?\n'))
    assert not match(Command('sudo apt-get update', 'E: Could not open lock file /var/lib/dpkg/lock - open (13: Permission denied)\nE: Unable to lock the administration directory (/var/lib/dpkg/), are you root?\n'))

# Generated at 2022-06-18 08:52:19.052553
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-18 08:52:21.151948
# Unit test for function match
def test_match():
    assert match(Command('sudo echo', ''))
    assert not match(Command('sudo echo', 'sudo: echo: command not found'))
    assert not match(Command('echo', ''))


# Generated at 2022-06-18 08:52:22.650845
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:52:24.749222
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:52:30.948661
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim',
                             'sudo: apt-get: command not found',
                             'sudo: 3 incorrect password attempts'))



# Generated at 2022-06-18 08:52:33.138876
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('sudo apt-get install', '', ''))


# Generated at 2022-06-18 08:52:35.692199
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:52:37.474731
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-18 08:52:40.386805
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:52:42.211282
# Unit test for function match
def test_match():
    assert match(Command('sudo echo', ''))
    assert not match(Command('sudo echo', '', ''))
    assert not match(Command('echo', ''))


# Generated at 2022-06-18 08:52:44.524424
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command found'))


# Generated at 2022-06-18 08:52:46.179850
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:52:50.373995
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', 0))


# Generated at 2022-06-18 08:52:52.327458
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found'))

# Generated at 2022-06-18 08:53:00.255305
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found',
                             stderr='sudo: ls: command not found',
                             stdout='sudo: ls: command not found'))


# Generated at 2022-06-18 08:53:08.838224
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', 0))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', -1))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', -2))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '', -3))

# Generated at 2022-06-18 08:53:11.758461
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:14.270936
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:53:16.164026
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:18.884144
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found', '', '', '', ''))


# Generated at 2022-06-18 08:53:21.174322
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:53:23.772911
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command found'))


# Generated at 2022-06-18 08:53:26.718945
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:29.362782
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:36.150146
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:39.686351
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', ''))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found',
                             'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:53:41.859606
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-18 08:53:44.237627
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:53:46.328775
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo "Hello World"', 'sudo: echo: command not found')) == 'env "PATH=$PATH" echo "Hello World"'

# Generated at 2022-06-18 08:53:50.564709
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:53:53.933721
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))


# Generated at 2022-06-18 08:53:55.853277
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-18 08:54:03.541582
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'sudo: abc: command not found'))
    assert not match(Command('sudo abc', 'sudo: abc: command not found',
                             stderr=True))
    assert not match(Command('sudo abc', 'sudo: abc: command not found',
                             stderr=False))
    assert not match(Command('sudo abc', 'sudo: abc: command not found',
                             stderr=False))
    assert not match(Command('sudo abc', 'sudo: abc: command not found',
                             stderr=False))
    assert not match(Command('sudo abc', 'sudo: abc: command not found',
                             stderr=False))

# Generated at 2022-06-18 08:54:05.802374
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', 1))
    assert not match(Command('sudo apt-get update', ''))
