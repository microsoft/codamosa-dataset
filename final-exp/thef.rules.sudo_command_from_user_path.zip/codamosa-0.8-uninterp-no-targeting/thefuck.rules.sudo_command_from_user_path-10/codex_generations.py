

# Generated at 2022-06-22 02:27:08.553108
# Unit test for function match
def test_match():
    command = Command('sudo lol', 'sudo: lol: command not found')
    assert match(command)



# Generated at 2022-06-22 02:27:12.079993
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command("sudo ")
    assert 'sudo echo env "PATH=$PATH" echo' == new_command

# Generated at 2022-06-22 02:27:15.299347
# Unit test for function get_new_command
def test_get_new_command():
    # pylint: disable=protected-access
    from thefuck import types
    command = types.Command('sudo ls', 'sudo: ls: command not found', '', 1)

# Generated at 2022-06-22 02:27:18.375595
# Unit test for function match
def test_match():
    assert match(Command('sudo abc',
                         "sudo: abc: command not found\n"))
    assert not match(Command('sudo abc',
                             "sudo: abc123: command not found\n"))

# Generated at 2022-06-22 02:27:21.215090
# Unit test for function get_new_command
def test_get_new_command():
	test = Command('sudo testtest', 'sudo: testtest: command not found\nsudo: testtest: command not found\nsudo: testtest: command not found')
	assert get_new_command(test).script == 'env "PATH=$PATH" testtest'


# Generated at 2022-06-22 02:27:23.256173
# Unit test for function match
def test_match():
    assert match(Command('sudo xxx', '', 'sudo: xxx: command not found'))


# Generated at 2022-06-22 02:27:26.639160
# Unit test for function get_new_command
def test_get_new_command():
    from tests.tools import Command

    new_command = get_new_command(Command("sudo echo foo",
                                          "sudo: echo: command not found"))
    assert new_command == u"env PATH=$PATH echo foo"

# Generated at 2022-06-22 02:27:28.279293
# Unit test for function match
def test_match():
    assert match(
        Command('sudo abcd', output='sudo: abcd: command not found'))



# Generated at 2022-06-22 02:27:31.171139
# Unit test for function match
def test_match():
    import unittest
    from thefuck.rules.sudo_command_not_found import match
    sudo_command = "sudo: /bin/apt-get: command not found"
    assert match(sudo_command)

# Generated at 2022-06-22 02:27:36.519115
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo xinput --set-prop "Synaptics TM2822-003" "Synaptics Soft Button Areas" 0 0 2790 0 1600 0 3200 0') == \
           u'sudo env "PATH=$PATH" xinput --set-prop "Synaptics TM2822-003" "Synaptics Soft Button Areas" 0 0 2790 0 1600 0 3200 0'

# Generated at 2022-06-22 02:27:43.117716
# Unit test for function match
def test_match():
    assert match(Command('sudo test', 'sudo: test: command not found'))
    assert match(Command('sudo test', 'sudo: test: command not found').with_output(True))
    assert not match(Command('sudo test', 'sudo: test: command not found').with_output(False))
    assert not match(Command('sudo test', 'sudo: test: command not found', ''))


# Generated at 2022-06-22 02:27:43.930532
# Unit test for function match
def test_match():

    # TODO:  add some test cases
    assert False

# Generated at 2022-06-22 02:27:46.825283
# Unit test for function match
def test_match():
    command = Command('sudo apt-get install', 'sudo: apt-get: command not found')
    assert match(command)



# Generated at 2022-06-22 02:27:57.614983
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo connmanctl scan wifi', 'sudo: connmanctl: command not foud')) == 'env "PATH=$PATH" connmanctl scan wifi'
    assert get_new_command(Command('sudo connmanctl scan wifi', u'''sudo: connmanctl: command not foud
sudo: /etc/sudo.conf is owned by uid 2000, should be 0
sudo: no valid sudoers sources found, quitting''')) == 'env "PATH=$PATH" connmanctl scan wifi'
    assert get_new_command(Command('sudo mv a b', 'sudo: mv: command not found')) == 'env "PATH=$PATH" mv a b'

# Generated at 2022-06-22 02:28:03.216645
# Unit test for function match
def test_match():
    assert _get_command_name('sudo: apt-get: command not found') == 'apt-get'
    assert match('sudo apt-get run') == False
    assert match('sudo: apt-get: command not found')


# Generated at 2022-06-22 02:28:04.468506
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo foo') == 'sudo env "PATH=$PATH" foo'

# Generated at 2022-06-22 02:28:06.900018
# Unit test for function match
def test_match():
    assert match('sudo aaaaa') == False
    assert match('sudo: aaaaa: command not found') == None
    assert match('sudo: aaaaa: command ndt found') == False



# Generated at 2022-06-22 02:28:08.637259
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim test', 'sudo: vim: command not found')) == 'env "PATH=$PATH" vim test'

# Generated at 2022-06-22 02:28:11.166508
# Unit test for function match
def test_match():
    assert not match(Command('', ''))
    assert match(Command('sudo apt install', 'sudo: apt: command not found'))
    assert not match(Command('', 'sudo: apt: command not found'))
    assert not match(Command('sudo apt install', 'sudo: apt install'))

# Generated at 2022-06-22 02:28:12.879923
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo foo').script == 'env "PATH=$PATH" foo'
    assert (get_new_command('sudo --user=foo --comment=bar test').script ==
            'env "PATH=$PATH" test')

# Generated at 2022-06-22 02:28:20.390602
# Unit test for function match
def test_match():
    assert not match(Command('sudo ls', ''))
    assert match(Command('sudo foo', 'sudo: foo: command not found'))
    assert not match(Command('sudo abc', 'sudo: abc: command not found'))
    assert match(Command('sudo ls', 'sudo: ls: command not found'))



# Generated at 2022-06-22 02:28:28.995567
# Unit test for function match
def test_match():
    assert match(Command('sudo scala', stderr='Run without argument to get help message.\nsudo: scala: command not found'))
    assert match(Command('sudo scala', stderr='Run without argument to get help message.\nsudo: no scala in (/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin)'))
    assert not match(Command('sudo scala', stderr='Run without argument to get help message.\n'))
    assert not match(Command('sudo scala', stderr='Run without argument to get help message.\n'))



# Generated at 2022-06-22 02:28:31.158453
# Unit test for function get_new_command
def test_get_new_command():
    command = "sudo apt-get install"
    new_command = get_new_command(command)
    assert new_command == 'sudo apt-get install'

# Generated at 2022-06-22 02:28:35.175365
# Unit test for function get_new_command
def test_get_new_command():
    script = 'foobar: command not found'
    args = ('foobar',)
    assert get_new_command(Command(script, '', args)) == \
           'env "PATH=$PATH" foobar'

# Generated at 2022-06-22 02:28:38.958047
# Unit test for function match
def test_match():
    command = Command(script='sudo', output='sudo: env: command not found')
    assert match(command)
    command = Command(script='sudo', output='sudo: env1: command not found')
    assert not match(command)

# Generated at 2022-06-22 02:28:44.573104
# Unit test for function get_new_command
def test_get_new_command():
        cmd = Command("sudo apt-get update", "sudo: apt-get: command not found")
        assert get_new_command(cmd) == "sudo env \"PATH=$PATH\" apt-get update"

# Generated at 2022-06-22 02:28:48.263227
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="sudo vim file",
                      stderr="sudo: vim: command not found")
    assert get_new_command(command) == 'env "PATH=$PATH" vim file'

# Generated at 2022-06-22 02:28:49.275415
# Unit test for function match
def test_match():
    assert which('sudo')



# Generated at 2022-06-22 02:28:52.688021
# Unit test for function get_new_command
def test_get_new_command():
    meta = {}
    assert get_new_command(Command('sudo echo "test"', meta)) == u'env "PATH=$PATH" echo "test"'


enabled_by_default = True

# Generated at 2022-06-22 02:28:56.025362
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo notify-send "Notify-send" "Send a message"', 'sudo: notify-send: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" sudo notify-send "Notify-send" "Send a message"'

# Generated at 2022-06-22 02:29:04.539184
# Unit test for function match
def test_match():
    assert match(Command(script='sudo cd ~',
                         stderr='sudo: cd: command not found'))
    assert not match(Command(script='sudo cd ~', stderr=''))
    assert not match(Command(script='cd ~', stderr=''))


# Generated at 2022-06-22 02:29:07.966071
# Unit test for function match
def test_match():
    assert match(Command('sudo test', ''))
    assert match(Command('sudo test', 'sudo: test: command not found\n'))
    assert not match(Command('sudo test', '\n'))
    assert not match(Command('sudo test', 'sudo: test: command not found'))


# Generated at 2022-06-22 02:29:12.216102
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('sudo not_found', '',
                                   'sudo: not_found: command not found')) == \
                                   'env "PATH=$PATH" not_found'

# Generated at 2022-06-22 02:29:15.175113
# Unit test for function match
def test_match():
    assert match(Command('sudo ll', 'sudo: ll: command not found'))
    assert match(Command('sudo ll', 'sudo: balabala')) is None


# Generated at 2022-06-22 02:29:18.696057
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'asdasdasd'))



# Generated at 2022-06-22 02:29:22.608849
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo vlc', 'sudo: vlc: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" vlc'

# Generated at 2022-06-22 02:29:27.120398
# Unit test for function match
def test_match():
    assert match(Command('sudo dpkg deb', 'sudo: dpkg: command not found'))
    assert match(Command('sudo install deb', 'sudo: install: command not found'))
    assert not match(Command('vim', ''))
    assert not match(Command('sudo vim', ''))
    assert not match(Command('sudo install', ''))


# Generated at 2022-06-22 02:29:33.592534
# Unit test for function match
def test_match():
    from thefuck.types import Command

    assert match(Command('sudo foo bar', '', 'sudo: foo: command not found'))
    assert match(Command('sudo foo bar', '', 'sudo: foo: command not found\n', 'sudo: foo: command not found'))
    assert not match(Command('ls foo bar', '', 'ls: foo: command not found'))
    assert not match(Command('foo bar', '', 'sudo: foo: command not found'))


# Generated at 2022-06-22 02:29:37.184073
# Unit test for function get_new_command
def test_get_new_command():
    # Path doesn't contain command
    assert get_new_command(Command('sudo vim', '', '')) == 'sudo env "PATH=$PATH" vim'
    # Path contain command
    assert get_new_command(Command('sudo vim', '', '')) == 'sudo env "PATH=$PATH" vim'

# Generated at 2022-06-22 02:29:40.984858
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo ls',
                      "sudo: ls: command not found")
    assert ("env 'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin' ls",
            "sudo ls") == get_new_command(command)

# Generated at 2022-06-22 02:29:58.280068
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo -s xed /etc/hosts', 'sudo: xed: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" xed -s xed /etc/hosts'

    command = Command(u'sudo env "PATH=$PATH" xed /etc/hosts',
                      'sudo: xed: command not found')
    assert get_new_command(command) == u'sudo env "PATH=$PATH" xed -s xed /etc/hosts'

# Generated at 2022-06-22 02:29:59.939880
# Unit test for function match
def test_match():
    assert match(Command('sudo bower install bootstrap', 'sudo: bower: command not found'))


# Generated at 2022-06-22 02:30:02.215283
# Unit test for function match
def test_match():
    cmd = Command('sudo apt-get install no-pkg-found', 'sudo: apt-get: command not found')
    assert match(cmd)



# Generated at 2022-06-22 02:30:04.414800
# Unit test for function match
def test_match():
    assert match(Command('sudo ls -a /non-existing',
                         '/bin/ls: /non-existing: No such file or directory\nsudo: ls: command not found'))



# Generated at 2022-06-22 02:30:07.797500
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo chmod 700 ~/Downloads', 'sudo: chmod: command not found')) == 'env "PATH=$PATH" sudo chmod 700 ~/Downloads'

# Generated at 2022-06-22 02:30:12.912216
# Unit test for function match
def test_match():
    assert match(Command(
        script='sudo some_command',
        output='sudo: some_command: command not found'))
    assert not match(Command(
        script='sudo some_command',
        output='sudo: some_command: command found'))
    assert not match(Command(script='sudo some_command'))


# Generated at 2022-06-22 02:30:15.713031
# Unit test for function match
def test_match():
    assert match(Command('sudo htop', output='sudo: htop: command not found'))
    assert not match(Command('htop', output=''))


# Generated at 2022-06-22 02:30:19.055954
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo', 'echo: command not found\r\n')) == 'env "PATH=$PATH" echo'
    assert get_new_command(Command('sudo ls', 'ls: command not found\r\n')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-22 02:30:23.823628
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command((u'fuck', u'fuck'), output=u'sudo: fuck: command not found')) == \
        'env "PATH=$PATH" fuck'
    assert get_new_command(Command((u'sudo', u'fuck'), output=u'sudo: fuck: command not found')) == \
        'env "PATH=$PATH" sudo fuck'

# Generated at 2022-06-22 02:30:25.455541
# Unit test for function match
def test_match():
    assert match('sudo gedit') is False
    assert match('sudo: gedit: command not found')


# Generated at 2022-06-22 02:30:45.751002
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim'))



# Generated at 2022-06-22 02:30:49.750690
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls',
                                   'sudo: ls: command not found')) == \
        'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo fzy',
                                   'sudo: fzy: command not found')) == \
        'env "PATH=$PATH" fzy'

# Generated at 2022-06-22 02:30:51.825952
# Unit test for function match
def test_match():
    command = "sudo: dsfe: command not found"
    expected = True
    assert match(command) == expected


# Generated at 2022-06-22 02:30:54.851953
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo make install', output="sudo: sudo: command not found")) == 'env PATH=$PATH sudo make install'

# Generated at 2022-06-22 02:30:56.501378
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo pip install something')).script == 'env "PATH=$PATH" pip install something'

# Generated at 2022-06-22 02:30:59.248185
# Unit test for function match
def test_match():
    # setup
    input_command = mock(script='sudo test', output='sudo: test: command not found')

    # Given
    assert_true(match(input_command))


# Generated at 2022-06-22 02:31:10.464634
# Unit test for function get_new_command
def test_get_new_command():
    def l(s):
        return Command(script=s, output='sudo: sdd: command not found')

    assert get_new_command(l('sudo sdd')) == 'env "PATH=$PATH" sdd'
    assert get_new_command(l('sudo sdd 2>/dev/null')) == 'env "PATH=$PATH" sdd 2>/dev/null'
    assert get_new_command(l('sudo env "PATH=$PATH" sdd')) == 'env "PATH=$PATH" sdd'
    assert get_new_command(l('sudo env "PATH=$PATH" sdd')) == 'env "PATH=$PATH" sdd'

# Generated at 2022-06-22 02:31:16.332008
# Unit test for function match
def test_match():
    shell.env = {'TEST_VAR': 'test_val'}
    assert match(Command('sudo TEST_VAR')) is not None
    assert match(Command('sudo TEST_VAR', 'sudo: TEST_VAR: command not found')) is not None
    assert match(Command('sudo TEST_VAR', 'sudo: command not found')) is None


# Generated at 2022-06-22 02:31:19.370979
# Unit test for function match
def test_match():
    command = namedtuple('Command', 'script, output')(script = "sudo apt-get install", output = "sudo: apt-get: command not found")
    new_command = get_new_command(command)
    assert new_command == "env \"PATH=$PATH\" apt-get install"

# Generated at 2022-06-22 02:31:22.781610
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo pip install flickrapi', "sudo: pip: command not found\n")
    assert get_new_command(command) == 'sudo env "PATH=$PATH" pip install flickrapi'

# Generated at 2022-06-22 02:32:04.138237
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found\nsudo: vim: command not found'))



# Generated at 2022-06-22 02:32:07.339576
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert match(Command('sudo wrong_command', 'sudo: wrong_command: command not found'))
    assert not match(Command('sudo ls', ''))


# Generated at 2022-06-22 02:32:10.978356
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    output = u'sudo: ruby: command not found'
    assert get_new_command(Command('sudo ruby', output)) == u'env "PATH=$PATH" ruby'

# Generated at 2022-06-22 02:32:13.615914
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'


# Generated at 2022-06-22 02:32:18.011334
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    assert get_new_command(Bash('sudo open -a "App"'))\
        == u'sudo env "PATH=$PATH" open -a "App"'
    assert get_new_command(Bash('sudo vim "App"'))\
        == u'sudo env "PATH=$PATH" vim "App"'



# Generated at 2022-06-22 02:32:20.675194
# Unit test for function get_new_command
def test_get_new_command():
    script = u'sudo ls ~'
    command = Command(script, u'''sudo: ls: command not found
''')
    new_command = get_new_command(command)
    assert new_command == u'sudo env "PATH=$PATH" ls ~'

# Generated at 2022-06-22 02:32:25.161868
# Unit test for function match
def test_match():
    assert match(Command('sudo python blah blah blah', '')) == False
    assert match(Command('sudo ls blah blah blah',
                         'sudo: ls: command not found')) == True
    assert match(Command('sudo python hello.py',
                         'sudo: python: command not found')) == False


# Generated at 2022-06-22 02:32:29.090774
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo go run foo.go'
    command = Command(script, 'sudo: go: command not found')
    assert u'env "PATH=$PATH" go run foo.go' == get_new_command(command)

# Generated at 2022-06-22 02:32:33.283497
# Unit test for function match
def test_match():
    assert not match(Command('sudo mv a b', 'mv: command not found'))
    assert match(Command('sudo f mv a b', 'f: command not found'))



# Generated at 2022-06-22 02:32:38.707907
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("sudo apt-get install", "sudo: apt-get: command not found\n")
    assert get_new_command(command) == 'env "PATH=$PATH" apt-get install'
    command = Command("sudo apt-get install", "sudo: apt-get: command not found\n")
    command_name = _get_command_name(command)
    assert command_name == "apt-get"
    assert which(command_name)


# Generated at 2022-06-22 02:34:03.634657
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', '', None))
    assert not match(Command('sudo ls', 'sudo: ls: command not found', ''))
    assert match(Command('sudo ls', 'sudo: yay: command not found', ''))
    assert not match(Command('sudo ls', 'env: python: No such file or directory', ''))
    assert not match(Command('sudo ls', '', ''))


# Generated at 2022-06-22 02:34:11.556553
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = "sudo pip install requests", output = "sudo: pip: command not found")
    assert(get_new_command(command) == 'env "PATH=$PATH" pip install requests')
    command = Command(script = "sudo pip install requests", output = "sudo: lshw: command not found")
    assert(get_new_command(command) == 'env "PATH=$PATH" lshw')
    command = Command(script = "sudo pip install requests", output = "sudo: pip: a command not found")
    assert(get_new_command(command) == None)


# Generated at 2022-06-22 02:34:17.929939
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim', 'sudo: vim: command not found')) == 'env "PATH=$PATH" vim'
    assert get_new_command(Command('sudo vim test.txt', 'sudo: vim: command not found')) == 'env "PATH=$PATH" vim test.txt'
    assert get_new_command(Command('sudo vim test.txt test.h', 'sudo: vim: command not found')) == 'env "PATH=$PATH" vim test.txt test.h'


# Generated at 2022-06-22 02:34:21.975075
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('sudo echo "Hallo"', '','/usr/bin/echo:\n\'echo\': command not found', 0))
            == 'env "PATH=$PATH" echo "Hallo"')

# Generated at 2022-06-22 02:34:27.019752
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo abc.sh')
    assert (get_new_command(command) ==
        "env \"PATH=$PATH\" abc.sh")
    # Case command name included space
    command = Command('sudo "abc abc".sh')
    assert (get_new_command(command) ==
        "env \"PATH=$PATH\" \"abc abc\".sh")


enabled_by_default = True

# Generated at 2022-06-22 02:34:30.299396
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo vim file', 'env: vim: No such file or directory')
    assert get_new_command(command) == 'env "PATH=$PATH" vim file'

# Generated at 2022-06-22 02:34:32.812763
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo rm test_folder',
                                   'sudo: rm: command not found')) == 'env "PATH=$PATH" rm test_folder'

# Generated at 2022-06-22 02:34:37.273725
# Unit test for function get_new_command
def test_get_new_command():
    command = type(
        'Command', (object,),
        {'script': 'sudo echo $PATH',
         'output': 'sudo: echo: command not found'})
    new_command = get_new_command(command)
    assert new_command == 'sudo env "PATH=$PATH" echo $PATH'

# Generated at 2022-06-22 02:34:39.693854
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("sudo ifconfig") == "env \"PATH=$PATH\" ifconfig"


# Generated at 2022-06-22 02:34:46.315762
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo aa', 'sudo: aa: command not found')
    assert get_new_command(command) == 'aa'

    command = Command('sudo ls', 'sudo: ls: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" ls'

    command = Command('sudo l', 'sudo: l: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" l'