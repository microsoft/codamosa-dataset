

# Generated at 2022-06-26 06:49:52.650628
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = 'env "PATH=$PATH" {0}'
    str_0 = 'sudo: {0}: command not found'
    var_1 = var_0.format('{0}')
    str_1 = str_0.format('{0}')
    var_2 = get_new_command(str_1)
    assert var_1 == var_2
    var_3 = var_0.format('{1}')
    str_2 = str_0.format('{1}')
    var_4 = get_new_command(str_2)
    assert var_3 == var_4
    var_5 = var_0.format('{2}')
    str_3 = str_0.format('{2}')
    var_6 = get_new_command(str_3)

# Generated at 2022-06-26 06:50:04.716775
# Unit test for function match
def test_match():
    sys.path.append('/home/chronos/user/.thefuck/thefuck')
    str_0 = 'sudo: aactive: command not found'
    str_1 = str_0
    var_0 = which(str_1)
    str_2 = str_0
    var_1 = _get_command_name(str_2)
    str_3 = 'aactive'
    var_2 = str_3 == var_1
    var_3 = var_1 == None
    var_4 = var_2 or var_3
    var_5 = not var_4
    str_4 = 'aactive'
    var_6 = not var_5
    var_7 = var_6 and var_4
    var_8 = var_5 and var_4
    var_9 = var_7 or var_

# Generated at 2022-06-26 06:50:07.274220
# Unit test for function match
def test_match():
    assert which('sudo')
    assert not match(which('sudo') + ' -h')
    assert match(which('sudo') + ' zsh')

# Generated at 2022-06-26 06:50:11.067099
# Unit test for function get_new_command
def test_get_new_command():
    str_1 = 'C:\\Users\\pedro\\AppData\\Roaming\\Microsoft\\WindowsApps\\python.exe: applet not found\r\nsudo: applet: command not found'
    var_1 = get_new_command(str_1)
    assert var_1 == 'env "PATH=$PATH" applet'


# Generated at 2022-06-26 06:50:16.291342
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = '?f{0S>\\lqV gkO'
    var_0 = get_new_command(str_0)
    assert var_0 == u'env "PATH=$PATH" ?f{0S>\\lqV gkO'

# Generated at 2022-06-26 06:50:17.333678
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 06:50:21.114289
# Unit test for function match
def test_match():
    var_0 = 'sudo:  : command not found'.strip()
    var_1 = _get_command_name(var_0)
    var_2 = which(var_1)
    assert var_2 == 'sudo:  : command not found'


# Generated at 2022-06-26 06:50:23.775213
# Unit test for function match
def test_match():
    var_1 = match('sudo: oooo: command not found')
    assert(var_1 == which('oooo'))
    var_2 = match('sudo: ooo: command not found')
    assert(var_2 == None)


# Generated at 2022-06-26 06:50:29.954181
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', '', '/bin/bash: apt-get: command not found\n'))
    assert not match(Command('sudo xxx', ''))
    assert match(Command('sudo xxx', '', '/bin/bash: xxx: command not found\n'))
    assert not match(Command('grep xxx', ''))



# Generated at 2022-06-26 06:50:31.575047
# Unit test for function match
def test_match():
    return


# Generated at 2022-06-26 06:50:36.713572
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'sudo: fg: command not found'
    str_1 = 'env "PATH=$PATH" fg'
    var_1 = get_new_command(str_0)
    if get_new_command(str_0) == str_1:
        pass


# Generated at 2022-06-26 06:50:37.978603
# Unit test for function match
def test_match():
    assert _get_command_name(str_1) == str_0


# Generated at 2022-06-26 06:50:44.477426
# Unit test for function match
def test_match():
    var_0 = match('command not found')
    assert var_0 is None
    var_0 = match('sudo: command not found')
    assert var_0 is None
    var_0 = match('sudo: not command not found')
    assert var_0 is None
    var_0 = match('sudo: apt: command not found')
    assert var_0 is not None


# Generated at 2022-06-26 06:50:49.151800
# Unit test for function match
def test_match():
    fname_0 = 'F-5\\?mwFm[:W\\Q8mv\\$xH'
    assert match(fname_0) == False
    fname_0 = 'ftpW8<v=Z?@x}@d+$^'

# Generated at 2022-06-26 06:50:51.291843
# Unit test for function match
def test_match():
    str_0 = 'sudo: tasf: command not found'
    var_0 = _get_command_name(str_0)
    assert var_0 == 'tasf'

# Generated at 2022-06-26 06:50:56.681920
# Unit test for function match
def test_match():
    assert _get_command_name('') == None
    assert which('/usr/bin/pandoc') == '/usr/bin/pandoc'
    assert get_new_command('sudo: pandoc: command not found') == 'env "PATH=$PATH" pandoc'
# Testing all of the unit test functions


# Generated at 2022-06-26 06:50:59.494465
# Unit test for function match
def test_match():
    str_0 = 'sudo: delete-branch: command not found'
    var_0 = match(str_0)
    print(var_0)


# Generated at 2022-06-26 06:51:03.406637
# Unit test for function match
def test_match():
    str_0 = 'sudo: pkg: command not found'
    var_0 = _get_command_name(str_0)
    assert var_0 == 'pkg'



# Generated at 2022-06-26 06:51:05.044606
# Unit test for function match
def test_match():
    str_0 = 'sudo: d: command not found'
    var_0 = match(str_0)

# Generated at 2022-06-26 06:51:06.850376
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo su') == 'env "PATH=$PATH" sudo su'

# Generated at 2022-06-26 06:51:17.610585
# Unit test for function get_new_command
def test_get_new_command():
    # No input, default output
    var_1 = 'sudo -l'
    var_3 = replace_argument(var_1, '-l', '-L')
    assert(var_3 == 'sudo -L')
    # Has input, correct output
    var_1 = 'sudo -l'
    var_2 = '-L'
    var_3 = replace_argument(var_1, '-l', var_2)
    assert(var_3 == 'sudo -L')
    # Has input, wrong output
    var_1 = 'sudo -l'
    var_2 = '-L'
    var_3 = replace_argument(var_1, '-L', var_2)
    assert(var_3 != 'sudo -l')
    # Has input, wrong output, identical strings

# Generated at 2022-06-26 06:51:20.293826
# Unit test for function match
def test_match():
    str_0 = 'sudo: apt-get: command not found'
    var_0 = match(str_0)


# Generated at 2022-06-26 06:51:22.831455
# Unit test for function match
def test_match():
    assert match('?f{0S>\\lqV gkO')


# Generated at 2022-06-26 06:51:28.612788
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo apt-get install vim') == 'sudo env "PATH=$PATH" apt-get install vim'
    assert get_new_command('sudo apt-get install vim') == 'sudo env "PATH=$PATH" apt-get install vim'
    assert get_new_command('sudo apt-get install vim') == 'sudo env "PATH=$PATH" apt-get install vim'
    assert get_new_command('sudo apt-get install vim') == 'sudo env "PATH=$PATH" apt-get install vim'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 06:51:31.191321
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = 'foo'
    var_1 = get_new_command(var_0)
    assert var_1 == 'env "PATH=$PATH" foo'


# Generated at 2022-06-26 06:51:38.345594
# Unit test for function match
def test_match():
    var_0 = match('iZgI8YGX9kFt@5')
    var_1 = match('CLG^$B23x]x#!')
    var_2 = match('f.z67EF"T@T[')
    var_3 = match('QOaCnd*8k6g_')
    var_4 = match('pwt56Kj+wh[N')
    var_5 = match('>|F2~l;D:_/i')
    var_6 = match('S*h<Fx2)ZKW6')
    var_7 = match('%{zV8wR"ED_v')
    var_8 = match('8WZq9%cA7j:k')

# Generated at 2022-06-26 06:51:44.176682
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = None
    str_0 = 'comman not found'
    var_0 = get_new_command(str_0)
    var_1 = 'sudo'
    str_1 = 'sudo: test: command not found'
    assert var_0 == 'sudo env "PATH=$PATH" test'


# Generated at 2022-06-26 06:51:45.949162
# Unit test for function get_new_command
def test_get_new_command():
    assert func(str_0) == var_0

# Generated at 2022-06-26 06:51:47.256615
# Unit test for function get_new_command
def test_get_new_command():
    assert callable(get_new_command)


# Generated at 2022-06-26 06:51:51.799597
# Unit test for function match
def test_match():
    assert match(str('sudo: no tty present and no askpass program specified')) == True
    assert match(str('sudo: kubectl: command not found')) == True
    assert match(str('sudo: gcloud: command not found')) == False


# Generated at 2022-06-26 06:52:02.114895
# Unit test for function match
def test_match():
    print('Searching for _get_command_name')
    if match(_get_command_name):
        print('Unit test passed')
    else:
        print('Unit test failed')


# Generated at 2022-06-26 06:52:02.923936
# Unit test for function get_new_command
def test_get_new_command():
    assert callable(get_new_command)


# Generated at 2022-06-26 06:52:09.343979
# Unit test for function match
def test_match():
    var_0 = _get_command_name('sudo: {0}: command not found'.format('asdf'))
    assert var_0 == 'asdf'

    # TODO: Fix this test with the new command output design
    # command = Command('sudo sush', 'sudo: sush: command not found')
    # assert match(command)

    command_0 = Command('asdf')
    assert match(command_0) == None



# Generated at 2022-06-26 06:52:10.198399
# Unit test for function get_new_command
def test_get_new_command():
    assert func_0(command_0) == command_1

# Generated at 2022-06-26 06:52:16.619237
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('') == '?'
    assert get_new_command('{0S>\\lqV gkO') == '{0S>\\lqV gkO'
    assert get_new_command('f{0S>\\lqV gkO') == 'f{0S>\\lqV gkO'
    assert get_new_command('?f{0S>\\lqV gkO') == '?f{0S>\\lqV gkO'
    assert get_new_command('?f?f{0S>\\lqV gkO0S>\\lqV gkO') == '?f?f{0S>\\lqV gkO0S>\\lqV gkO'

# Generated at 2022-06-26 06:52:18.788797
# Unit test for function match
def test_match():
    str_0 = '?f{0S>\\lqV gkO'
    

# Generated at 2022-06-26 06:52:24.673882
# Unit test for function match
def test_match():
    import subprocess
    assert which('ls')
    assert match(subprocess.run(
        'ls', stderr=subprocess.PIPE, shell=True))
    assert not match(subprocess.run(
        'sudo ls', stderr=subprocess.PIPE, shell=True))
    assert not match(subprocess.run(
        'sudo ls --wrong', stderr=subprocess.PIPE, shell=True))

# Generated at 2022-06-26 06:52:28.130886
# Unit test for function match
def test_match():
    str_1 = 'QF^4Vu+0: command not found'
    var_1 = _get_command_name(str_1)
    assert var_1 == 'QF^4Vu+0'


# Generated at 2022-06-26 06:52:29.773800
# Unit test for function match
def test_match():
    assert match('?f{0S>\\lqV gkO') == False


# Generated at 2022-06-26 06:52:31.482357
# Unit test for function match
def test_match():
    str_0 = 'a'
    var_0 = _get_command_name(str_0)


# Generated at 2022-06-26 06:52:55.198377
# Unit test for function match
def test_match():
    str_0 = '?f{0S>\\lqV gkO'
    str_1 = 'sudo: .: command not found'
    str_2 = 'cat: not: No such file or directory'
    str_3 = 'sudo'
    str_4 = 'sudo'
    str_5 = 'sudo'
    str_6 = 'sudo'
    str_7 = str_2
    str_8 = 'sudo'
    str_9 = 'sudo'
    var_0 = _get_command_name(str_0)
    var_1 = _get_command_name(str_1)
    var_2 = _get_command_name(str_2)
    var_3 = which(str_3)
    var_4 = which(str_4)

# Generated at 2022-06-26 06:52:57.213151
# Unit test for function match
def test_match():
    assert not match(str_0)
    assert match(str_1)


# Generated at 2022-06-26 06:53:07.919079
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo mount') == 'env "PATH=$PATH" mount'
    assert get_new_command('sudo sss') == 'env "PATH=$PATH" sss'
    assert get_new_command('sudo -s') == 'env "PATH=$PATH" -s'
    assert get_new_command('sudo sss') == 'env "PATH=$PATH" sss'
    assert get_new_command('sudo -s') == 'env "PATH=$PATH" -s'
    assert get_new_command('sudo sss') == 'env "PATH=$PATH" sss'
    assert get_new_command('sudo -s') == 'env "PATH=$PATH" -s'
    assert get_new_command('sudo sss') == 'env "PATH=$PATH" sss'

# Generated at 2022-06-26 06:53:14.961448
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = '?f{0S>\\lqV gkO'
    var_0 = get_new_command(str_0)
    str_1 = '1'
    var_1 = get_new_command(str_1)
    str_2 = 'pT;1'
    var_2 = get_new_command(str_2)
    str_3 = 'm'
    var_3 = get_new_command(str_3)
    str_4 = 'x'
    var_4 = get_new_command(str_4)
    str_5 = 'no'
    var_5 = get_new_command(str_5)
    str_6 = '5'
    var_6 = get_new_command(str_6)
    str_7 = 'j'


# Generated at 2022-06-26 06:53:20.571061
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'sudo: ?f{0S>\\lqV_gkO: command not found'
    var_0 = get_new_command(str_0)
    assert var_0 == 'env "PATH=$PATH" ?f{0S>\\lqV_gkO'

# Generated at 2022-06-26 06:53:23.160783
# Unit test for function match
def test_match():
    var_0 = which('ls')
    var_1 = 'sudo ls'

    command = Command(script=var_1, output=var_0)
    var_2 = match(command)

    var_2 = match(command)

# Generated at 2022-06-26 06:53:26.288981
# Unit test for function match
def test_match():
    test_match_0()
    test_match_1()



# Generated at 2022-06-26 06:53:30.499385
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo pip install thefuck') == \
        u'sudo env "PATH=$PATH" pip install thefuck'
    assert get_new_command('sudo pip install thefuck') == \
        u'sudo env "PATH=$PATH" pip install thefuck'

# Generated at 2022-06-26 06:53:34.486770
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'sudo: gkO: command not found'
    str_1 = 'gkO'
    var_0 = _get_command_name(str_0)
    var_1 = var_0 == str_1

# Generated at 2022-06-26 06:53:43.743910
# Unit test for function get_new_command
def test_get_new_command():
    # Get the random key for encryption algorithm
    def get_random_key():
        s = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return s[random.randint(0,len(s))]
    # Get the random encryption algorithm
    def get_random_crypt_algo():
        s = ["caesar","rot13","vignere","vernam"]
        return s[random.randint(0,len(s)-1)]
    # Get the random plain-text
    def get_random_plaintext():
        s = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

# Generated at 2022-06-26 06:54:19.392489
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'sudo: foo: command not found'
    var_2 = get_new_command(str_0)
    if var_2.output != '\n' and var_2.exit_code != 127:
        var_1 = True
        assert var_1 == False


# Generated at 2022-06-26 06:54:24.137072
# Unit test for function match
def test_match():
    # The function `match` should return `False` when given an command that
    # doesn't contain `command not found` in command.output.
    assert match(Command('sudo ifconfig', '')) is False

    # The function `match` should return `True` when given an command that
    # contain `command not found` in command.output.
    command = Command('sudo mkdir -p /tmp/foo', 'sudo: mkdir: command not found')
    assert match(command) is True



# Generated at 2022-06-26 06:54:25.834844
# Unit test for function match
def test_match():
    assert(match(get_new_command(str_0)) == None)


# Generated at 2022-06-26 06:54:30.472788
# Unit test for function get_new_command
def test_get_new_command():
    try:
        assert get_new_command('sudo: ls: command not found') == 'env "PATH=$PATH" ls'
        assert get_new_command('sudo: vim: command not found') == 'env "PATH=$PATH" vim'
    except:
        var_1 = False
    else:
        var_1 = True
    finally:
        assert var_1


# Generated at 2022-06-26 06:54:32.491594
# Unit test for function match
def test_match():
    var_0 = _get_command_name('sudo : gkO')
    assert var_0 == 'gkO'


# Generated at 2022-06-26 06:54:34.427277
# Unit test for function match
def test_match():
    assert match('sudo some_command') == False
    assert match('sudo: some_command: command not found')


# Generated at 2022-06-26 06:54:42.749304
# Unit test for function get_new_command
def test_get_new_command():
    output_1 = get_new_command('~/test sudo ls')
    var_0 = 'sudo env "PATH=$PATH" ls'
    output_1 == var_0
    output_2 = get_new_command('~/test sudo -u user ls')
    var_1 = 'sudo env "PATH=$PATH" ls'
    output_2 == var_1
    output_3 = get_new_command('~/test sudo -u user -s ls')
    var_2 = 'sudo env "PATH=$PATH" ls'
    output_3 == var_2
    output_4 = get_new_command('~/test sudo -u user -e ls')
    var_3 = 'sudo env "PATH=$PATH" ls'
    output_4 == var_3

# Generated at 2022-06-26 06:54:44.044516
# Unit test for function match
def test_match():
    assert isinstance(match(get_new_command), bool)


# Generated at 2022-06-26 06:54:46.241735
# Unit test for function match
def test_match():
    str_0 = 'sudo: /usr/bin/apt-fast: command not found'
    var_0 = _get_command_name(str_0)
    assert var_0 == '/usr/bin/apt-fast'

# Generated at 2022-06-26 06:54:48.114061
# Unit test for function match
def test_match():
    var_0 = _get_command_name('ls')
    assert var_0 == 'ls'


# Generated at 2022-06-26 06:56:06.345274
# Unit test for function match
def test_match():
    str_0 = 'sudo: ll: command not found'
    str_1 = 'sudo wget http://example.com'
    assert match(str_0)
    assert not match(str_1)


# Generated at 2022-06-26 06:56:14.536496
# Unit test for function match

# Generated at 2022-06-26 06:56:15.411336
# Unit test for function match
def test_match():
    assert match(str_0)


# Generated at 2022-06-26 06:56:18.528846
# Unit test for function match
def test_match():
    str_0 = 'sudo: /usr/bin/git: command not found'
    var_0 = _get_command_name(str_0)
    assert var_0 == '/usr/bin/git'


# Generated at 2022-06-26 06:56:26.679458
# Unit test for function get_new_command
def test_get_new_command():
    assert replace_argument('sudo foo bar', 'foo', 'bar') == 'sudo bar bar'
    assert replace_argument('sudo --foo bar baz', 'bar', 'bar') == 'sudo --foo bar bar'
    assert replace_argument('sudo --foo bar', 'bar', 'bar') == 'sudo --foo bar'
    assert replace_argument('sudo --foo=bar baz', 'bar', 'bar') == 'sudo --foo=bar bar'
    assert replace_argument('sudo --foo=bar', 'bar', 'bar') == 'sudo --foo=bar'
    assert replace_argument('sudo foo', 'foo', 'bar') == 'sudo bar'
    assert replace_argument('sudo foo --bar', 'foo', 'bar') == 'sudo bar --bar'
    assert replace_argument('sudo foo --bar=baz', 'foo', 'bar')

# Generated at 2022-06-26 06:56:30.915359
# Unit test for function match
def test_match():
    var_1 = 'sudo: bundle: command not found'
    var_2 = match(var_1)
    var_3 = 'sudo: {0}: command not found'.format('grep')
    var_4 = match(var_3)
    var_5 = 'sudo: {0}: command not found'.format('grep')
    var_6 = match(var_5)

# Generated at 2022-06-26 06:56:34.730167
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo env PATH=$PATH ls') == 'ls'
    assert get_new_command('sudo env PATH=$PATH ./ls') == './ls'
    assert get_new_command('sudo PATH=$PATH ls') == 'sudo env PATH=$PATH ls'
    assert get_new_command('sudo env PATH=$PATH python3 ls') == 'python3 ls'

# Generated at 2022-06-26 06:56:36.352738
# Unit test for function match
def test_match():
    assert match('sudo: ifconfig: command not found')
    assert not match('sudo aptitude install hello')

# Generated at 2022-06-26 06:56:39.457140
# Unit test for function match
def test_match():
    str_0 = 'sudo: pkill: command not found'
    var_1 = re.findall(r'sudo: (.*): command not found', str_0)
    expected_out = ['pkill']
    assert var_1 == expected_out

# Generated at 2022-06-26 06:56:42.038998
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = get_new_command('sudo ls x')
    assert var_0 == u'env "PATH=$PATH" ls x'

    var_0 = get_new_command('sudo ls -la x')
    assert var_0 == u'env "PATH=$PATH" ls -la x'

