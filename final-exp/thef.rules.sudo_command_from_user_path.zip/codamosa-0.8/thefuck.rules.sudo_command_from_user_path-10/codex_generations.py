

# Generated at 2022-06-12 12:11:44.650189
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo foo',
                      'sudo: foo: command not found\n')
    assert get_new_command(command) == 'env "PATH=$PATH" sudo foo'

# Generated at 2022-06-12 12:11:46.814447
# Unit test for function match
def test_match():
    assert match(Command('sudo random_stuff', 'sudo: random_stuff: command not found'))


# Generated at 2022-06-12 12:11:49.257823
# Unit test for function match
def test_match():
    from thefuck.rules.sudo_env_path import match
    assert match(Command('sudo hello world', 'sudo: hello: command not found'))
    assert not match(Command('sudo hello world', ''))

# Generated at 2022-06-12 12:11:52.797747
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install thefuck', ''))
    assert not match(Command('sudo apt-get install thefuck', 'zsh: command not found: apt-get'))


# Generated at 2022-06-12 12:11:54.576919
# Unit test for function match
def test_match():
    assert match(Command('sudo echo fuck', None))
    assert not match(Command('echo fuck', None))

# Generated at 2022-06-12 12:11:58.631542
# Unit test for function match
def test_match():
    # Test for case where sudo is no root
    # Test for case where sudo command is not found
    assert match(Command('sudo apt update', '', 'sudo: apt: command not found'))
    # Test for case where sudo command is found
    assert not match(Command('sudo apt update', '', ''))



# Generated at 2022-06-12 12:12:02.557091
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo rm -rf /tmp/*') == 'sudo env "PATH=$PATH" rm -rf /tmp/*'
    assert get_new_command('sudo -u foo rm -rf /tmp/*') == 'sudo -u foo env "PATH=$PATH" rm -rf /tmp/*'

# Generated at 2022-06-12 12:12:04.389962
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo emacs', 'sudo: emacs: command not found'))=='env "PATH=$PATH" emacs'

# Generated at 2022-06-12 12:12:07.358110
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'sudo: vim: command not found',
                             'sudo: /usr/local/bin/vim: command not found'))



# Generated at 2022-06-12 12:12:08.385015
# Unit test for function match
def test_match():
    assert match(Command('sudo  python', ''))


# Generated at 2022-06-12 12:12:14.326345
# Unit test for function match
def test_match():
    command = Command('sudo apt-get install', '')
    assert match(command)

    command = Command('sudo apt-get install', 'sudo: apt-get: command not found')
    assert not match(command)

# Generated at 2022-06-12 12:12:16.341834
# Unit test for function match
def test_match():
    assert match(Command('echo wangxin | sudo -S cat', '', 'sudo: echo: command not found'))


# Generated at 2022-06-12 12:12:19.787816
# Unit test for function match
def test_match():
    command = Command(script="sudo ls -lh", output="sudo: ls: command not found")
    assert match(command)

    command = Command(script="sudo ls -lh", output="sudo: h: command not found")
    assert not match(command)

    command = Command(script="sudo ls -lh", output="sudo: -lh: command not found")
    assert not match(command)



# Generated at 2022-06-12 12:12:21.480976
# Unit test for function match
def test_match():
    return match(Command('sudo abc', '', 'sudo: abc: command not found'))



# Generated at 2022-06-12 12:12:23.737496
# Unit test for function match
def test_match():
    assert not match(Command('sudo pwd', ''))
    assert match(Command('sudo dmfksj', 'sudo: dmfksj: command not found'))


# Generated at 2022-06-12 12:12:25.177468
# Unit test for function match
def test_match():
    command = Command('sudo echo hello!', '')
    assert match(command) is not None



# Generated at 2022-06-12 12:12:27.079913
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo screen', 'sudo: screen: command not found')) == 'env "PATH=$PATH" screen'

# Generated at 2022-06-12 12:12:29.200741
# Unit test for function match
def test_match():
  assert match('sudo apt-get install abc') == 'sudo apt-get install abc'
  assert match('sudo: apt-get: command not found') == None


# Generated at 2022-06-12 12:12:30.382239
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', "sudo: ls: command not found", ""))



# Generated at 2022-06-12 12:12:32.878912
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'ls: command not found'))
    assert not match(Command('ls', 'ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not'))


# Generated at 2022-06-12 12:12:36.575486
# Unit test for function match
def test_match():
    assert match(Command("sudo apt-get update", ""))


# Generated at 2022-06-12 12:12:39.518181
# Unit test for function match
def test_match():
    assert match(Command('sudo yum update', 'sudo:yum: command not found'))
    assert not match(Command('sudo yum update', 'E: Invalid operation update'))


# Generated at 2022-06-12 12:12:41.143774
# Unit test for function match
def test_match():
    assert not match(Command('sudo env', ''))
    assert match(Command('sudo env', 'sudo: env: command not found'))
    assert not match(Command('sudo env', 'env: foo: No such file or directory'))



# Generated at 2022-06-12 12:12:43.911791
# Unit test for function match
def test_match():
    assert match(Command('sudo pwd', '', 'sudo: pwd: command not found'))
    assert not match(Command('sudo pwd', '', '/bin/pwd: Permission denied'))

# Generated at 2022-06-12 12:12:47.010200
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', ''))
    assert not match(Command('sudo apt-get update',
                             'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'Hit http://archive.ubuntu.com trusty InRelease'))



# Generated at 2022-06-12 12:12:49.994219
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script': 'sudo test'})
    assert get_new_command(command) == "env \"PATH=$PATH\" sudo test"

# Generated at 2022-06-12 12:12:51.662199
# Unit test for function get_new_command

# Generated at 2022-06-12 12:12:56.875841
# Unit test for function get_new_command
def test_get_new_command():
    # this is the example output of command: 'sudo vim /etc/hosts' on bash
    # sudo: vim: command not found
    command = Command('sudo vim /etc/hosts',
                      'sudo: vim: command not found')
    new_command = get_new_command(command)
    assert new_command == 'env "PATH=$PATH" vim /etc/hosts'

# Generated at 2022-06-12 12:12:58.447279
# Unit test for function match
def test_match():
    assert match(Command('sudo htop',
                         output="sudo: htop: command not found"))



# Generated at 2022-06-12 12:13:02.296923
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('sudo dpkg -i', output='sudo: dpkg: command not found'))
    assert new_command == 'env "PATH=$PATH" dpkg -i'



# Generated at 2022-06-12 12:13:07.389587
# Unit test for function match
def test_match():
    command = Command(script='sudo', output='sudo: git: command not found')
    assert match(command)
    command = Command(script='sudo', output='sudo: _git: command not found')
    assert not match(command)


# Generated at 2022-06-12 12:13:09.109355
# Unit test for function match
def test_match():
    assert match(Command('sudo test','''sudo: test: command not found
'''))


# Generated at 2022-06-12 12:13:14.252511
# Unit test for function match
def test_match():
    assert not match(Command(script='terminal', output='sudo: terminal: command not found'))
    assert not match(Command(script='terminal', output='sudo: terminal: not found'))
    assert not match(Command(script='terminal', output='sudo: command terminal not found'))
    assert match(Command(script='terminal', output='sudo: terminal: command not found'))


# Generated at 2022-06-12 12:13:20.499266
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = u'sudo apt-get update',
                                   output = u'sudo: apt-get: command not found')) \
           == u'sudo env PATH=$PATH apt-get update'
    assert get_new_command(Command(script = u'sudo rsync --info=progress2 ~test/test/test/test/test /test/test/test',
                                   output = u'sudo: rsync: command not found')) \
           == u'sudo env PATH=$PATH rsync --info=progress2 ~test/test/test/test/test /test/test/test'

# Generated at 2022-06-12 12:13:22.556769
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("sudo apt-get install", "sudo: apt-get: command not found"))


# Generated at 2022-06-12 12:13:28.241071
# Unit test for function match
def test_match():
    assert not match(Command('sudo ls /var/fuckyou',
                             output='sudo: ls: command not found'))
    assert which('sudo')
    assert match(Command('sudo ls /var/fuckyou',
                         output='sudo: ls: command not found'))
    assert match(Command('sudo ls /var/fuckyou',
                         output='fuck you!'))



# Generated at 2022-06-12 12:13:31.267763
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('ls -al |grep test') == 'sudo env "PATH=$PATH" ls -al |grep test'
    assert get_new_command('rm -rf /') == 'sudo env "PATH=$PATH" rm -rf /'

# Generated at 2022-06-12 12:13:33.447039
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get update', 'sudo: apt-get: command not found')) == u"env \"PATH=$PATH\" apt-get update"

# Generated at 2022-06-12 12:13:34.903749
# Unit test for function match
def test_match():
    assert match(Command('sudo echo asd', 'sudo: echo: command not found'))


# Generated at 2022-06-12 12:13:38.272623
# Unit test for function match
def test_match():
    assert match(Command('sudo ls /sbin', '', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls /sbin', '', 'ls: command not found'))
    assert not match(Command('sudo ls /sbin', '', 'command not found'))


# Generated at 2022-06-12 12:13:43.009022
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo ls', path='/bin', stderr='sudo: ls: command not found',)) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-12 12:13:45.861461
# Unit test for function match
def test_match():
	from thefuck.rules.sudo_error import _get_command_name
	assert _get_command_name('sudo: apt-get: command not found') == 'apt-get'

# Generated at 2022-06-12 12:13:49.557975
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    command = Command('sudo gedit',
                      'sudo: gedit: command not found\n')
    assert get_new_command(command) == 'env "PATH=$PATH" gedit'

# Generated at 2022-06-12 12:13:51.718092
# Unit test for function match
def test_match():
    assert match(Command('sudo ls'))
    assert not match(Command('sudo ls', "sudo: ls: command not found"))
    assert not ma

# Generated at 2022-06-12 12:13:53.885752
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    assert get_new_command('sudo rm -rf') == 'env "PATH=$PATH" rm -rf'

# Generated at 2022-06-12 12:13:56.373527
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('ls', ''))
    assert not match(Command('sudo ls', ''))



# Generated at 2022-06-12 12:13:58.488834
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get update', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get update'

# Generated at 2022-06-12 12:14:03.264403
# Unit test for function match
def test_match():
    # When command is not found
    output = 'sudo: ping: command not found'
    assert match(Command('sudo ping', output=output))

    # When command is found
    assert not match(Command('sudo apt-get install python3'))

# Generated at 2022-06-12 12:14:05.646253
# Unit test for function match
def test_match():
    assert match({'output': 'sudo: 1: command not found'}).group()
    assert not match({'output': 'sudo: 1: something'})



# Generated at 2022-06-12 12:14:10.475827
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('sudo apt-get update') == u'sudo env "PATH=$PATH" apt-get update'
	assert get_new_command('sudo pip install --upgrade pip') == u'sudo env "PATH=$PATH" pip install --upgrade pip'
	assert get_new_command('sudo rm -rf /example') == u'sudo env "PATH=$PATH" rm -rf /example'

# Generated at 2022-06-12 12:14:20.431583
# Unit test for function match
def test_match():
    assert match(Command('sudo command', 
                         'sudo: command: command not found'))
    assert match(Command('sudo not_found command', 
                         'sudo: not_found: command not found'))
    assert not match(Command('sudo command', ''))
    assert not match(Command('sudo command', 
                             'sudo: command: no such file or directory'))
    assert not match(Command('sudo command', 
                             'zsh: command not found: command'))



# Generated at 2022-06-12 12:14:25.721245
# Unit test for function get_new_command
def test_get_new_command():
    # Test when the command is of the form "sudo command_name"
    assert get_new_command(Command('sudo command_name', '')) == u"sudo env 'PATH=$PATH' command_name"

    # Test when the command is of the form "sudo flag1 command_name flag2"
    assert get_new_command(Command('sudo flag1 command_name flag2', '')) == u"sudo flag1 env 'PATH=$PATH' command_name flag2"

# Generated at 2022-06-12 12:14:30.350009
# Unit test for function match
def test_match():
    assert match(Command('sudo pacman -Syu', 'sudo: pacman: command not found'))
    assert match(Command('sudo pacman -Syu', 'sudo: sudo-1.8.16p11: command not found'))
    assert not match(Command('sudo pacman -Syu', 'error: syntax error'))

# Generated at 2022-06-12 12:14:32.204078
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', output='sudo: abc: command not found')) == True


# Generated at 2022-06-12 12:14:33.442731
# Unit test for function match
def test_match():
    assert match(Command('sudo vv', ''))
    asser

# Generated at 2022-06-12 12:14:35.514339
# Unit test for function match
def test_match():
    assert match(Command('sudo xy',
                      'sudo: xy: command not found',
                      ''))

# Generated at 2022-06-12 12:14:38.300487
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', None))
    assert match(Command('sudo apt-get update', 'Command not found'))
    assert not match(Command('ls', 'ls: command not found'))


# Generated at 2022-06-12 12:14:40.556991
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo ls /ddd', "'sudo: ls: command not found'")
    assert get_new_command(command) == 'sudo env "PATH=$PATH" ls /ddd'

# Generated at 2022-06-12 12:14:42.992009
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo nano text.txt',
                                   'sudo: nano: command not found')) == 'env "PATH=$PATH" nano text.txt'

# Generated at 2022-06-12 12:14:44.554615
# Unit test for function match
def test_match():
    assert match(Command('sudo fdgd',
                         'fdgd: command not found\n'))



# Generated at 2022-06-12 12:14:50.988808
# Unit test for function match
def test_match():
    assert match(Command('sudo htop', '', 'sudo: htop: command not found\n'))


# Generated at 2022-06-12 12:14:55.684697
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo -E /bin/bash -c "source ~/.nvm/nvm.sh && nvim -u ~/.bundle/vimproc_install/gvimrc/vimrc +NeoBundleInstall" '
    new_script = get_new_command('sudo: nvim: command not found')
    assert script == new_script

# Generated at 2022-06-12 12:14:58.590655
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command('sudo apt-get install', 'sudo: apt-get: command not found')
    assert get_new_command(command) == 'sudo env "PATH=$PATH" apt-get install'

# Generated at 2022-06-12 12:15:00.536700
# Unit test for function match
def test_match():
    assert match(Command('sudo xdg-open', ''))
    assert not match(Command('sudo ls', ''))

# Generated at 2022-06-12 12:15:04.333897
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim'))
    assert not match(Command('su do apt-get install vim',
                             'bash: su: command not found'))
    assert not match(Command('sudo apt-get install vim',
                             'sudo: apt-get: command not found'))


# Generated at 2022-06-12 12:15:07.550643
# Unit test for function get_new_command
def test_get_new_command():
    expected = u'sudo env "PATH=$PATH" ./command'
    command = Command(command=u'sudo ./command', output=u'sudo: ./command: command not found')
    assert get_new_command(command) == expected

# Generated at 2022-06-12 12:15:16.550223
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo dosomething', output='sudo: dosomething: command not found')) == 'env \'PATH=$PATH\' dosomething'
    assert get_new_command(Command(script='sudo dosomething ', output='sudo: dosomething: command not found')) == 'env \'PATH=$PATH\' dosomething '
    assert get_new_command(Command(script='sudo dosomething asd', output='sudo: dosomething: command not found')) == 'env \'PATH=$PATH\' dosomething asd'
    assert get_new_command(Command(script='sudo dosomething asd', output='asd sudo: dosomething: command not found')) == 'asd env \'PATH=$PATH\' dosomething asd'

# Generated at 2022-06-12 12:15:20.531134
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script': 'command'})
    command_name = 'command_name'
    command_with_missing_command_name = type('Command', (object,),
                                             {'output': 'output'})
    assert get_new_command(command,command_name) == u'env "PATH=$PATH" command_name'
    assert get_new_command(command_with_missing_command_name) == ''

# Generated at 2022-06-12 12:15:30.760191
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo curl') == 'env "PATH=$PATH" curl'
    assert get_new_command('sudo curl -s') == 'env "PATH=$PATH" curl -s'
    assert get_new_command('sudo CURl -s') == 'env "PATH=$PATH" CURl -s'
    assert get_new_command('sudo /usr/bin/curl -s') == 'env "PATH=$PATH" /usr/bin/curl -s'
    assert get_new_command('sudo /usr/bin/CURl -s') == 'env "PATH=$PATH" /usr/bin/CURl -s'
    assert get_new_command('sudo /usr/bin/curl') == 'env "PATH=$PATH" /usr/bin/curl'

# Generated at 2022-06-12 12:15:33.979873
# Unit test for function match
def test_match():
    assert which('sudo')
    assert match(Command('sudo command', stderr='sudo: command: command not found'))
    assert not match(Command('echo command', stderr='sudo: command: command not found'))

# Generated at 2022-06-12 12:15:46.567399
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found', ''))
    assert not match(Command('ls', '', ''))


# Generated at 2022-06-12 12:15:48.665603
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'E: Couldn\'t find package vim\n'))
    assert n

# Generated at 2022-06-12 12:15:52.857345
# Unit test for function match
def test_match():
    assert _get_command_name(Command('sudo psswd', '')) == 'psswd'
    assert not match(Command('sudo ls', ''))
    assert match(Command('sudo psswd', ''))



# Generated at 2022-06-12 12:15:55.899189
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install python3.4', 'sudo: apt-get: command not found\n')) == 'env "PATH=$PATH" apt-get install python3.4'

# Generated at 2022-06-12 12:15:59.886299
# Unit test for function match
def test_match():
    # Test 1: Command match
    command = Command('sudo test 1')
    output = 'sudo: test: command not found'
    assert match(command) == True

    # Test 2: No match
    command = Command('sudo test 2')
    output = 'sudo: test123: command not found'
    assert match(command) == False


# Generated at 2022-06-12 12:16:04.608320
# Unit test for function match
def test_match():
    assert match(Command('sudo metasploit-framework', 'sudo: metasploit-framework: command not found'))
    assert not match(Command('sudo foo', 'sudo: foo: command not found'))
    assert not match(Command('sudo foo', 'sudo: foo: command not found', err=True))
    assert not match(Command('sudo foo', 'sudo: foo: no such file or directory'))
    assert not match(Command('sudo foo', 'sudo: foo: command not found', err=False))



# Generated at 2022-06-12 12:16:07.344255
# Unit test for function get_new_command
def test_get_new_command():
    command = 'sudo: python: command not found'
    new_command = get_new_command(command)
    assert new_command == 'env "PATH=$PATH" python'

# Generated at 2022-06-12 12:16:09.345585
# Unit test for function match
def test_match():
    output = "sudo: gz: command not found\n"
    assert match(Command("sudo gz", output))


# Generated at 2022-06-12 12:16:12.108469
# Unit test for function match
def test_match():
    assert match(Command(script='sudo apt-get install -y htop', output='sudo: apt-get: command not found'))
    assert not match(Command(script='sudo su', output='root@ubuntu:~#'))

# Generated at 2022-06-12 12:16:14.588982
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("sudo ls")
    ret = get_new_command(command)
    assert ret == "sudo env 'PATH=$PATH' ls"

# Generated at 2022-06-12 12:16:26.044235
# Unit test for function match
def test_match():
    command = Command(script='sudo apt-get update', output='sudo: apt-get: command not found')
    assert match(command)


# Generated at 2022-06-12 12:16:29.167573
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get us', ''))
    assert match(Command('sudo apt-get update', ''))
    assert not match(Command('sudo apt-get update', 'E: foo'))

# Generated at 2022-06-12 12:16:31.322098
# Unit test for function match
def test_match():
    assert match(Command('sudo zsh', 'sudo: zsh: command not found'))
    assert not match(Command('sudo zsh', 'zsh: command not found'))
    
    

# Generated at 2022-06-12 12:16:34.365464
# Unit test for function match
def test_match():
    assert match(Command('sudo command not found', ''))
    assert not match(Command('sudo command not found', '', ''))
    assert not match(Command('sudo command not found', '', '', '', '',
                             'sudo: command not found'))



# Generated at 2022-06-12 12:16:36.642258
# Unit test for function match
def test_match():
    assert not match(Command('sudo test', 'sudo: test: command not found\n'))
    assert match(Command('sudo fasdf', 'sudo: fasdf: command not found\n'))


# Generated at 2022-06-12 12:16:40.477762
# Unit test for function get_new_command
def test_get_new_command():
    from mock import Mock
    command_name = u'abc'
    env_command_name = u'env "PATH=$PATH" abc'
    command = Mock(script=u'sudo abc',
                   output=u'sudo: abc: command not found')
    assert get_new_command(command) == u'sudo env "PATH=$PATH" abc'

# Generated at 2022-06-12 12:16:42.000645
# Unit test for function match
def test_match():
    assert(match(Command('sudo git add README.txt', 'sudo: git: command not found')))


# Generated at 2022-06-12 12:16:44.103498
# Unit test for function match
def test_match():
    assert match(Command('sudo su', None, u'sudo: su: command not found'))


# Generated at 2022-06-12 12:16:49.438843
# Unit test for function match
def test_match():
    command_found = Command('sudo apt', 'sudo: apt: command not found\n')
    command_not_found = Command('apt-get update', 'E: Command not found')
    assert match(command_found)
    assert not match(command_not_found)
    assert _get_command_name(command_found) == 'apt'


# Generated at 2022-06-12 12:16:51.921042
# Unit test for function match
def test_match():
    assert match(Command('sudo brew install update',
                    'sudo: brew: command not found'))
    assert not match(Command('sudo apt-get install foo', ''))

# Generated at 2022-06-12 12:17:15.602786
# Unit test for function match
def test_match():
    assert which('ls')
    assert match(Command('sudo ls', output='sudo: ls: command not found'))
    assert match(Command('sudo ls -l', output='sudo: ls: command not found'))
    assert match(Command('sudo ls /', output='sudo: ls: command not found'))
    assert not match(Command('sudo ls /', output='sudo: ls: Permission denied'))


# Generated at 2022-06-12 12:17:18.456544
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("sudo test --opt", "sudo: te: command not found")
    assert get_new_command(command) == "sudo env \"PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin\" test --opt"

# Generated at 2022-06-12 12:17:24.111913
# Unit test for function match
def test_match():
    from thefuck.rules.sudo_env_path import match

    # No match
    assert not match(Command(script="sudo cat /etc/sudoers",
                             output="sudo: cat: command not found"))

    assert not match(Command(script="sudo cat /etc/sudoers",
                             output="sudo: /etc/sudoers: Permission denied"))

    # Matches
    assert match(Command(script="sudo apt-get install",
                         output="sudo: apt-get: command not found"))

    assert match(Command(script="sudo apt-get install",
                         output="==> sudo: apt-get: command not found"))



# Generated at 2022-06-12 12:17:26.244725
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo "test"',
                         'sudo: echo: command not found')) == 'env "PATH=$PATH" echo "test"'

# Generated at 2022-06-12 12:17:35.379896
# Unit test for function match
def test_match():
    assert match(Command('sudo echo "rm fck lol"', '')) == None
    assert match(Command('sudo echo "fuck lol"', '')) == None
    assert match(Command('sudo echo rm "fck lol"', '')) == None
    assert match(Command('sudo -s echo "fuck lol"', '')) == None
    assert match(Command('echo "fuck lol"', '')) == None
    assert match(Command('sudo echo "fuck lol"', 'sudo: echo: command not found'))
    assert match(Command('sudo echo "fuck lol"', 'sudo: echo: command not found\nsudo: cat: command not found')) == None
    assert match(Command('sudo echo "fuck lol"', 'sudo: eho: command not found')) == None

# Generated at 2022-06-12 12:17:37.415493
# Unit test for function match
def test_match():
    # Positive match
    command = Command('sudo apt install', 'sudo: apt: command not found')

    assert match(command)


# Unit test  for function get_new_command

# Generated at 2022-06-12 12:17:39.356516
# Unit test for function match
def test_match():
    assert(match(Command('sudo ls', '')))
    assert(not match(Command('sudo ls', '')))


# Generated at 2022-06-12 12:17:40.605998
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('sudo service start something', '')) == 'env "PATH=$PATH" service start something')

# Generated at 2022-06-12 12:17:43.445644
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo wall'

    assert script == get_new_command(type('obj', (object,), {
        'script': script,
        'output': 'sudo: wall: command not found'
    })).script

# Generated at 2022-06-12 12:17:45.282947
# Unit test for function match
def test_match():
    match(Command('sudo thiscommanddoesntexist', ''))
    assert not match(Command('sudo pacman', ''))


# Generated at 2022-06-12 12:18:35.994696
# Unit test for function match
def test_match():
    assert match(Command('sudo emacs', 'sudo: emacs: command not found'))
    assert match(Command('sudo emacs', 'sudo: emacs: command not found\n'))
    assert match(Command('sudo emacs', 'sudo: emacs: command not found\n'))
    assert not match(Command('sudo emacs', '\n'))


# Generated at 2022-06-12 12:18:38.413133
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo echo') == 'env "PATH=$PATH" echo'
    assert get_new_command('echo') == 'echo'


# Generated at 2022-06-12 12:18:41.372693
# Unit test for function get_new_command
def test_get_new_command():
    # No need to test this function for macOS 10.12.6
    # because its PATH env is same as other os.
    assert get_new_command("sudo asdf") == u'env "PATH=$PATH" asdf'

# Generated at 2022-06-12 12:18:42.997042
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo ls') == 'env "PATH=$PATH" ls'

enabled_by_default = True

# Generated at 2022-06-12 12:18:46.062037
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo su', 'sudo su: command not found')) \
        == "env 'PATH=$PATH' su"

# Generated at 2022-06-12 12:18:47.757567
# Unit test for function match
def test_match():
    command=Command('sudo nautilus', 'sudo: nautilus: command not found')
    assert match(command)


# Generated at 2022-06-12 12:18:49.263347
# Unit test for function match
def test_match():
    assert match(Command('sudo blah blah blah', 'sudo: blah: command not found'))


# Generated at 2022-06-12 12:18:51.660503
# Unit test for function match
def test_match():
    command = Command('sudo ls', '/home/user')
    assert not match(command)
    command = Command('sudo: ls: command not found', '/home/user')
    assert match(command)


# Generated at 2022-06-12 12:18:53.288627
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', ''))
    assert not match(Command('vim', ''))


# Generated at 2022-06-12 12:18:58.546796
# Unit test for function match
def test_match():
    assert match(Command(script='sudo ls'))
    assert match(Command(script='sudo ls -l',
                         output='sudo: ls: command not found'))
    assert not match(Command(script='ls',
                             output='sudo: ls: command not found'))
    assert not match(Command(script='sudo ls',
                             output='sudo: foo: command not found'))



# Generated at 2022-06-12 12:20:48.121087
# Unit test for function match
def test_match():
    assert not match(Command('sudo ls', ''))
    assert match(Command('sudo command',
                         'sudo: command: command not found'))
    assert not match(Command('sudo command', 'test'))



# Generated at 2022-06-12 12:20:52.451474
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('./', 'sudo: ls -la: command not found')) == './'
    assert get_new_command(Command('./', 'sudo: ls: command not found')) == 'sudo env "PATH=$PATH" ls'
    assert get_new_command(Command('./', 'sudo: ll: command not found')) == 'sudo env "PATH=$PATH" ll'
    assert get_new_command(Command('./', 'sudo: l: command not found')) == 'sudo env "PATH=$PATH" l'

# Generated at 2022-06-12 12:20:54.858923
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install python3', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install python3', ''))

    

# Generated at 2022-06-12 12:20:58.562069
# Unit test for function match
def test_match():
    old_command1 = 'sudo: command1: command not found'
    assert not match(Command(old_command1, ''))
    old_command2 = 'sudo: command2: command not found'
    assert match(Command(old_command2, ''))


# Generated at 2022-06-12 12:21:01.500459
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert match(Command('sudo adduser xiaotian', 'sudo: adduser: command not found'))
    assert not match(Command('sudo ls', 'ls: command not found'))


# Generated at 2022-06-12 12:21:04.558997
# Unit test for function match
def test_match():
	assert match(Command('sudo ls', 'sudo: ls: command not found'))
	assert not match(Command('sudo ls', 'sudo: ls: command not found', stderr=''))
	assert not match(Command('sudo ls', ''))
	assert not match(Command('', 'sudo: ls: command not found'))



# Generated at 2022-06-12 12:21:08.111684
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'sudo: abc: command not found\n'))
    assert not match(Command('sudo abc', ''))
    assert not match(Command('sudo abc', 'sudo: abc: command not found\n'
                                          'abc: command not found'))



# Generated at 2022-06-12 12:21:11.519871
# Unit test for function get_new_command
def test_get_new_command():
    command = type("Command", (object,), {"script": "sudo  dpkg --get-selections | grep '^lib*'" })
    assert get_new_command(command) == "sudo env \"PATH=$PATH\"  dpkg --get-selections | grep '^lib*'"

# Generated at 2022-06-12 12:21:12.842773
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo python')) == 'env "PATH=$PATH" python'

# Generated at 2022-06-12 12:21:14.927910
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    assert get_new_command(Bash('sudo echo')) == 'env "PATH=$PATH" sudo echo'