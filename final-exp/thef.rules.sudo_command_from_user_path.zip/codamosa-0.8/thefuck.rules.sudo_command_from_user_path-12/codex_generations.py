

# Generated at 2022-06-12 12:11:46.344778
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))



# Generated at 2022-06-12 12:11:49.731564
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo su', 'sudo: su: command not found')) == u'sudo env "PATH=$PATH" su'
    assert get_new_command(Command('sudo su -', 'sudo: su: command not found')) == u'sudo env "PATH=$PATH" su -'

# Generated at 2022-06-12 12:11:59.832043
# Unit test for function match
def test_match():
    from thefuck.rules.sudo_env_path import match
    assert not match(Command(script=u'sudo', output=u'foo'))
    assert not match(Command(script=u'sudo',
                             output=u'sudo: ssh: command not found'))
    assert match(Command(script=u'sudo',
                         output=u'sudo: /usr/local/bin/lein: command not found'))
    assert not match(Command(script=u'sudo',
                             output=u'sudo: /usr/local/bin/lein: command not found\nsudo: /home/exlex/bin/lein: command not found'))

# Generated at 2022-06-12 12:12:03.009001
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: command not found'))
    assert not match(Command('ls', ''))


# Generated at 2022-06-12 12:12:07.856943
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('ls dir', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls dir'
    assert get_new_command(Command('sudo python script.py', 'sudo: python: command not found')) == 'env "PATH=$PATH" sudo python script.py'
    assert get_new_command(Command('sudo --vanilla R', 'sudo: R: command not found')) == 'env "PATH=$PATH" sudo --vanilla R'

# Generated at 2022-06-12 12:12:10.015758
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo apt-get install boot'
    output = 'sudo: apt-get: command not found'
    command = Command(script, output)
    assert get_new_command(command) == u'env "PATH=$PATH" apt-get install boot'

# Generated at 2022-06-12 12:12:15.974637
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == None
    assert match(Command('sudo apt-get install', 'asdf')) == None
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == None
    assert match(Command('sudo apt-get install', 'asdf')) == None


# Generated at 2022-06-12 12:12:18.114213
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo timestrap', 'sudo: timestrap: command not found')) == 'env "PATH=$PATH" timestrap'

# Generated at 2022-06-12 12:12:20.937406
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get', ''))
    assert match(Command('sudo ./script', ''))
    assert not match(Command('sudo apt-get', '', stderr=None))
    assert not match(Command('sudo', ''))



# Generated at 2022-06-12 12:12:23.013171
# Unit test for function match
def test_match():
    assert match(Command('sudo a', '', 'sudo: a: command not found\n'))
    assert not match(Command('sudo a', '', ''))

# Generated at 2022-06-12 12:12:28.570915
# Unit test for function match
def test_match():
    assert match(Command('sudo bla'))
    assert not match(Command('sudo bla', 'bla\n'))
    assert not match(Command('sudo bla', 'command not found'))
    assert not match(Command('sudo bla', 'sudo: bla: command not found\n'))


# Generated at 2022-06-12 12:12:30.197671
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'sudo: abc: command not found', ''))
    assert not match(Command('sudo abc', '', ''))



# Generated at 2022-06-12 12:12:31.933917
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'sudo: vim: command not found\nfoo'))


# Generated at 2022-06-12 12:12:34.107600
# Unit test for function get_new_command
def test_get_new_command():
    c = Command('sudo touch file', u'sudo: touch: command not found\n')
    assert get_new_command(c) == 'env "PATH=$PATH" touch file'

# Generated at 2022-06-12 12:12:36.082974
# Unit test for function match
def test_match():
    assert match(Command('sudo command', '')) is None
    assert match(Command('sudo command', 'sudo: command: command not found'))
    assert match(Command('sudo command',
                         "sudo: /home/user/bin/command: command not found"))


# Generated at 2022-06-12 12:12:40.861357
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo test',
                                   u'sudo: echo: command not found',
                                   '', 127)) == 'env "PATH=$PATH" echo test'
    assert get_new_command(Command('sudo abc',
                                   u'sudo: abc: command not found',
                                   '', 127)) == 'env "PATH=$PATH" abc'

# Generated at 2022-06-12 12:12:48.198142
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo test', 'sudo: test: command not found')) == u'env "PATH=$PATH" test'
    # Ignore case
    assert get_new_command(Command('sudo test', 'Sudo: test: command not found')) == u'env "PATH=$PATH" test'
    # Ignore extra text
    assert get_new_command(Command('sudo test', 'sudo: test: command not found and some other text')) == u'env "PATH=$PATH" test'
    assert get_new_command(Command('sudo test', 'sudo: test: command not found other text')) == u'env "PATH=$PATH" test'
    assert get_new_command(Command('sudo test', 'sudo: test: command not found other text\n')) == u'env "PATH=$PATH" test'

# Generated at 2022-06-12 12:12:51.714052
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("sudo ls") == "sudo env \"PATH=$PATH\" ls"
    assert get_new_command("sudo ls -l") == "sudo env \"PATH=$PATH\" ls -l"

# Generated at 2022-06-12 12:12:54.173444
# Unit test for function match
def test_match():
    output = "sudo: somecommand: command not found"
    assert match(Command(script="sudo somecommand", output=output))



# Generated at 2022-06-12 12:12:57.925647
# Unit test for function match
def test_match():
    assert _get_command_name(Command('sudo ls', 'sudo: ls: command not found\n')) == 'ls'
    assert match(Command('sudo ls', 'sudo: ls: command not found\n')).group(1) == 'ls'


# Generated at 2022-06-12 12:13:03.556695
# Unit test for function match
def test_match():
    assert match(Command('sudo pacman -TVs asdf',
                         'sudo: pacman: command not found'))
    assert not match(Command('sudo pacman -TVs asdf', 'sudo:  '))

# Generated at 2022-06-12 12:13:06.807109
# Unit test for function match
def test_match():
    assert match(Command('sudo what', 'sudo: what: command not found'))
    assert not match(Command('sudo what', 'sudo: what: command not found', error=True))
    assert not match(Command('sudo what', 'sudo: what: command found'))

# Generated at 2022-06-12 12:13:09.703747
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo echo "Hello, World!"', '')
    assert get_new_command(command) == 'env "PATH=$PATH" echo "Hello, World!"'

# Generated at 2022-06-12 12:13:12.311776
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vi foo.txt', 'sudo: vi: command not found')) == 'env "PATH=$PATH" vi foo.txt'


# Generated at 2022-06-12 12:13:15.652587
# Unit test for function match
def test_match():
    assert not match(Command('sudo a'))
    assert not match(Command('sudo ls', '', err='sudo: cp: command not found\n'))
    assert match(Command('sudo ls', '', err='sudo: a: command not found\n'))


# Generated at 2022-06-12 12:13:23.012456
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo this_should_not_exist', 'sudo: this_should_not_exist: command not found\n')
    assert get_new_command(command) == 'sudo env "PATH=$PATH" this_should_not_exist'

    command = Command('sudo env "PATH=$PATH" this_should_not_exist', 'sudo: this_should_not_exist: command not found\n')
    assert get_new_command(command) == 'sudo env "PATH=$PATH" this_should_not_exist'

    command = Command('sudo env "PATH=$PATH" this-should-not-exist', 'sudo: this-should-not-exist: command not found\n')
    assert get_new_command(command) == 'sudo env "PATH=$PATH" this-should-not-exist'

    command = Command

# Generated at 2022-06-12 12:13:27.141332
# Unit test for function get_new_command
def test_get_new_command():
    script = 'test'
    new_script = 'env "PATH=$PATH" test'
    assert get_new_command(Command(script, 'sudo: test: command not found')) == Command(new_script, 'sudo: test: command not found')

enabled_by_default = True

# Generated at 2022-06-12 12:13:28.231416
# Unit test for function match
def test_match():
  assert match(Command('sudo ls', '', 'sudo: ls: command not found'))



# Generated at 2022-06-12 12:13:32.149517
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo blah blah blah', 'sudo: blah: command not found')).script == 'env "PATH=$PATH" blah blah blah'
    assert get_new_command(Command('sudo blah blah blah', 'sudo: blah: command not found\nblah: command not found')).script == 'env "PATH=$PATH" blah blah blah'

# Generated at 2022-06-12 12:13:35.671267
# Unit test for function match
def test_match():
    assert match(Command(script='sudo cd', output='sudo: cd: command not found'))
    assert not match(Command(script='sudo cd', output='sudo: -cd: command not found'))
    assert match(Command(script='sudo ls', output='sudo: ls: command not found'))


# Generated at 2022-06-12 12:13:40.425438
# Unit test for function match
def test_match():
    command = Command('sudo ls', 'sudo: ls: command not found')
    assert match(command)

    command = Command('sudo ls', 'foo: command not found')
    assert not match(command)



# Generated at 2022-06-12 12:13:43.363505
# Unit test for function match
def test_match():
    assert match(Command('sudo teat', 'sudo: test: command not found'))
    assert not match(Command('sudo test', ''))
    assert not match(Command('test', 'sudo: test: command not found'))


# Generated at 2022-06-12 12:13:48.398264
# Unit test for function match
def test_match():
    assert match(Command('sudo add-apt-repository ppa:foo/bar',
                         'sudo: add-apt-repository: command not found'))
    assert match(Command('sudo apt-get update',
                         'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install foo', ''))


# Generated at 2022-06-12 12:13:51.029694
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', ''))
    assert match(Command('sudo vim', 
        'sudo: vim: command not found'))



# Generated at 2022-06-12 12:13:53.539809
# Unit test for function match
def test_match():
    assert match(Command('sudo foo', stderr='sudo: foo: command not found'))
    assert not match(Command('sudo foo', stderr='sudo: some error'))


# Generated at 2022-06-12 12:13:57.234569
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command(
            'sudo python',
            output="""sudo: python: command not found
            Traceback (most recent call last):
              File "<stdin>", line 1, in <module>
            NameError: name 'python' is not defined""")) == u'env "PATH=$PATH" python'

# Generated at 2022-06-12 12:14:00.682790
# Unit test for function match
def test_match():
    from thefuck.types import Command

    assert match(Command('sudo qwe', '', 'sudo: qwe: command not found'))
    assert not match(Command('sudo qwe', '', ''))



# Generated at 2022-06-12 12:14:08.067371
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', '')) is None
    assert match(Command('sudo apt-dude', '')) is None
    assert match(Command('sudo apt-get install',
                         'sudo: apt-get: command not found')) is True
    assert match(Command('sudo apt-get install',
                         'sudo: apt-get: command not found\n'
                         '/usr/bin/sudo apt-get install')) is True


# Unit tests for functions get_new_command and _get_command_name

# Generated at 2022-06-12 12:14:09.405777
# Unit test for function match
def test_match():
    cmd = Command('sudo nmap 10.0.0.1', "sudo: nmap: command not found")
    assert which('nmap')
    assert match(cmd)


# Generated at 2022-06-12 12:14:11.178760
# Unit test for function match
def test_match():
    command = Command('sudo somecommand')
    assert match(command)



# Generated at 2022-06-12 12:14:17.499988
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command(script='sudo ls -la',
                                   stderr='sudo: ls: command not found\n')) \
            == u'env "PATH=$PATH" ls -la'

# Generated at 2022-06-12 12:14:18.709240
# Unit test for function match
def test_match():
    assert match(Command('sudo yum install thefuck', '$ yum install thefuck'))


# Generated at 2022-06-12 12:14:25.278813
# Unit test for function get_new_command
def test_get_new_command():
    # Test for string with path
    script = "sudo python2 /home/git/gitlab/lib/backup/manager.rb"
    if 'command not found' not in script:
        command = Command(script, 'command not found: python2')
        assert(get_new_command(command) == "env \"PATH=$PATH\" python2 /home/git/gitlab/lib/backup/manager.rb")

    # Test for string without path
    script = "sudo gitlab-rake gitlab:check"
    if 'command not found' not in script:
        command = Command(script, 'command not found: gitlab-rake')
        assert(get_new_command(command) == "env \"PATH=$PATH\" gitlab-rake gitlab:check")

# Generated at 2022-06-12 12:14:31.552895
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert match(Command('sudo ls', '$sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'sudo: command not found'))
    assert not match(Command('sudo ls', '$sudo: ls: command found'))
    assert not match(Command('sudo ls', '$sudo: ls: command'))


# Generated at 2022-06-12 12:14:33.173094
# Unit test for function match
def test_match():
    command = Command(script = 'sudo git --help')
    assert match(command)


# Generated at 2022-06-12 12:14:36.967300
# Unit test for function match
def test_match():
    # Matching
    assert match(Command('sudo apt-get install snoopy',
        'sudo: apt-get: command not found\n'))
    assert not match(Command('apt-get install snoopy', ''))
    assert not match(Command('sudo apt-get install snoopy', ''))



# Generated at 2022-06-12 12:14:40.963247
# Unit test for function get_new_command
def test_get_new_command():
    import warnings

    warnings.filterwarnings('ignore')

    from thefuck.types import Command

    assert get_new_command(Command('cd', 'sudo: cd: command not found')) == 'cd'
    assert get_new_command(Command('sudo cd', 'sudo: cd: command not found')) == 'cd'
    assert get_new_command(Command('sudo ls -la', 'sudo: ls: command not found')) == 'ls -la'


enabled_by_default = False

# Generated at 2022-06-12 12:14:42.672390
# Unit test for function match
def test_match():
    assert match(Command('sudo notfound', u'sudo: notfound: command not found'))


# Generated at 2022-06-12 12:14:45.298296
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('echo test', 'sudo: echo: command not found')) == 'env "PATH=$PATH" echo test'


# vim: expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-12 12:14:48.212155
# Unit test for function get_new_command
def test_get_new_command():
    example = Command(script='sudo apt-get install vim',
                      output='sudo: apt-get: command not found')
    assert get_new_command(example) == "sudo env 'PATH=$PATH' apt-get install vim"

# Generated at 2022-06-12 12:14:56.685942
# Unit test for function match
def test_match():
    """
    >>> match = get_match_fun(__name__)
    >>> match(Command('sudo apt-get install python-fuck'))
    False
    >>> match(Command('sudo apt-get install python-fuck', 'sudo: puthon-fuck: command not found'))
    True
    >>> match(Command('sudo apt-get install python-fuck', 'sudo: apt-get: command not found'))
    True
    """

# Unit tests for function get_new_command

# Generated at 2022-06-12 12:14:59.263400
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'sudo: abc: command not found', ''))
    assert not match(Command('sudo abc', '', ''))


# Generated at 2022-06-12 12:15:04.537276
# Unit test for function match
def test_match():
    assert match(Command('sudo aptt-get update', '/tmp', b'', b'sudo: aptt-get: command not found', 1))
    assert not match(Command('sudo aptt-get update', '/tmp', b'', b'update aptt-get', 1))
    assert not match(Command('sudo aptt-get update', '/tmp', b'', b'sudo: command not found', 1))
    assert not match(Command('sudo aptt-get update', '/tmp', b'', b'command aptt-get update', 1))
    assert not match(Command('sudo aptt-get update', '/tmp', b'', b'', 1))


# Generated at 2022-06-12 12:15:07.382509
# Unit test for function match
def test_match():
    assert match(Command('sudo command_not_found'))
    assert not match(Command('sudo command_not_found',
                             'sudo: command_not_found: command not found'))


# Generated at 2022-06-12 12:15:11.889192
# Unit test for function match
def test_match():
    assert match(Command('sudo echo toto','')) == None
    assert match(Command('sudo zsh','')) == None
    assert match(Command('sudo echo toto',
                         u'sudo: echo: command not found')) == True
    assert match(Command('sudo echo toto',
                         u'sudo: unkown: command not found')) == None

# Generated at 2022-06-12 12:15:15.719976
# Unit test for function match
def test_match():
    assert which(u'ls')
    assert match(Command(u'sudo lsd', u'sudo: lsd: command not found'))
    assert not match(Command(u'sudo sed abcd', u'sudo: sed: command not found'))
    assert not match(Command(u'sudo sed abcd', u''))


# Generated at 2022-06-12 12:15:18.515414
# Unit test for function match
def test_match():
	command = """
	user@computer:~/$ sudo 
	sudo: 1: command not found
	user@computer:~/$ 
	"""
	output = """
	sudo: 1: command not found
	"""
	command = Command(command, output)
	assert match(command)



# Generated at 2022-06-12 12:15:20.500361
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    command = "sudo: pingg: command not found"
    assert get_new_command(Bash(command)) == u'env "PATH=$PATH" pingg'

# Generated at 2022-06-12 12:15:22.714652
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo wtf', 'sudo: wtf: command not found\n')) == 'env "PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"  wtf'

# Generated at 2022-06-12 12:15:27.357839
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo', 'sudo: echo: command not found')).script == 'env "PATH=$PATH" echo'
    assert get_new_command(Command('sudo echo $PWD', 'sudo: echo: command not found')).script == 'env "PATH=$PATH" echo $PWD'

# Generated at 2022-06-12 12:15:31.108491
# Unit test for function match
def test_match():
    assert match(Command('sudo thefuck ll', ''))



# Generated at 2022-06-12 12:15:34.417992
# Unit test for function match
def test_match():
    assert match(Command('sudo hola', None, "sudo: hola: command not found"))
    assert not match(Command('sudo hola', None, "hola: command not found"))


# Generated at 2022-06-12 12:15:37.042918
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert 'env "PATH=$PATH" echo' == get_new_command(Command('sudo echo', ''))
    assert 'env "PATH=$PATH" echo "a b c"' == get_new_command(Command('sudo echo "a b c"', ''))

# Generated at 2022-06-12 12:15:39.070974
# Unit test for function match
def test_match():
    assert not match(Command('sudo ls', ''))
    assert match(Command('sudo neverheardofcommand', 'sudo: neverheardofcommand: command not found'))


# Generated at 2022-06-12 12:15:45.374419
# Unit test for function match
def test_match():
    # Command not found
    output1 = 'sudo: cannot open /etc/sudoers: Permission denied\nsudo: no valid sudoers sources found, quitting\nsudo: unable to initialize policy plugin'
    assert not match(Command('', output=output1))
    # Command found
    output2 = '/home/vagrant/test.sh: line 2: first_command: command not found'
    assert match(Command('', output=output2)) is not None
    # Command found with whitespace
    output3 = '/home/vagrant/test.sh: line 2: second command: command not found'
    assert match(Command('', output=output3)) is not None
    # Command not found
    output4 = 'sudo: second_command: command not found'
    assert not match(Command('', output=output4))
    # Command found
   

# Generated at 2022-06-12 12:15:52.810004
# Unit test for function match
def test_match():
    assert which('sudo')
    assert not match(Command('sudo', stderr='sudo: env: command not found'))

    assert not which('sudo')
    assert not match(Command('sudo', stderr='sudo: env: command not found'))

    assert match(Command('sudo env', stderr='sudo: env: command not found'))
    assert match(Command('sudo env', stderr='sudo: undefined: command not found'))
    assert match(Command('sudo env', stderr='sudo: ls: command not found'))


# Generated at 2022-06-12 12:15:59.956948
# Unit test for function get_new_command
def test_get_new_command():
    # Assert match()
    assert match(Command('sudo vim', output='sudo: vim: command not found'))
    assert not match(Command('sudo vim', output='sudo: vim: no tty present and no askpass program specified'))

    # Assert get_new_command()
    assert get_new_command(Command('sudo vim', output='sudo: vim: command not found')) == 'env "PATH=$PATH" vim'
    assert get_new_command(Command('sudo apt-get install vim', output='sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install vim'

# Generated at 2022-06-12 12:16:04.462114
# Unit test for function get_new_command
def test_get_new_command():
    # test case 1
    command = Command('sudo pacman -Syu', 'sudo: pacman: command not found')
    assert get_new_command(command) == 'sudo env "PATH=$PATH" pacman -Syu'

    # test case 2
    command = Command('sudo pacman -Syu', 'sudo: pacman: blah blah blah command not found')
    assert get_new_command(command) == 'sudo env "PATH=$PATH" pacman -Syu'

# Generated at 2022-06-12 12:16:07.177554
# Unit test for function match
def test_match():
    assert not match(Command('sudo sf', ''))
    assert match(Command('sudo sf', 'sudo: sf: command not found'))


# Generated at 2022-06-12 12:16:16.501189
# Unit test for function get_new_command
def test_get_new_command():
    class Command:
        def __init__(self, script, output):
            self.script = script
            self.output = output
    # test_command1: /usr/bin/nano exists, so command not found error
    test_command1 = Command('sudo nano', 'sudo: nano: command not found')
    # test_command2: /usr/bin/nano doesn't exist, but /usr/bin/vim does
    test_command2 = Command('sudo nano', 'sudo: vim: command not found')
    # test_command3: sudo env "PATH=$PATH" nano
    test_command3 = Command('sudo env "PATH=$PATH" nano', 'sudo: nano: command not found')
    # test_command4: sudo env "PATH=$PATH" vim

# Generated at 2022-06-12 12:16:22.653719
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("sudo greb")
    

# Generated at 2022-06-12 12:16:26.177716
# Unit test for function match
def test_match():
    assert which('ls')
    assert match(Command('sudo ls', 'sudo: ls: command not found', ''))
    assert not match(Command('sudo ls', '', ''))
    assert not which('wtf')
    assert match(Command('sudo wtf', 'sudo: wtf: command not found', ''))


# Generated at 2022-06-12 12:16:28.709087
# Unit test for function match
def test_match():
    assert match(Command('sudo find /usr/local',
                         'find: /usr/local: Permission denied'))



# Generated at 2022-06-12 12:16:30.651188
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found\n')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-12 12:16:33.380712
# Unit test for function match
def test_match():
    command_status_regex = re.compile(r"^sudo: .*: command not found", flags=re.IGNORECASE)
    assert not match(Command('sudo abc', '', command_status_regex))
    assert match(Command('sudo ls', '', command_status_regex))



# Generated at 2022-06-12 12:16:36.263124
# Unit test for function match
def test_match():
    output_no_match = 'sudo: env: command not found'
    output_match = 'sudo: docker-compose: command not found'
    assert not match(Script(output_no_match))
    assert match(Script(output_match))



# Generated at 2022-06-12 12:16:38.326024
# Unit test for function match
def test_match():
    assert match(Command('sudo which',
                         'sudo: which: command not found'))
    assert not match(Command('sudo which', ''))


# Generated at 2022-06-12 12:16:41.084332
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command  # import from tests.utils so it doesn't catch our test method

    arguments = Command('sudo exit 6', 'sudo: exit: command not found')
    assert get_new_command(arguments) == "env 'PATH=$PATH' exit 6"


# Generated at 2022-06-12 12:16:43.303229
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', '', 'sudo: ls: command not found'))
    assert not match(Command('sudo apt-get install -y emacs', '', ''))
    assert not match(Command('sudo: ls: command not found', '', ''))


# Generated at 2022-06-12 12:16:46.419089
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo not_found_command', '')
    assert get_new_command(command) == 'env "PATH=$PATH" not_found_command'

# Generated at 2022-06-12 12:17:01.529470
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    assert get_new_command(Command(script='sudo touch bob.txt',
                                   stderr='sudo: touch: command not found')) == ('env "PATH=$PATH" touch bob.txt')
    assert get_new_command(Command(script='sudo f o o',
                                   stderr='sudo: f: command not found')) == ('env "PATH=$PATH" f o o')



# Generated at 2022-06-12 12:17:04.788688
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import shell

    assert get_new_command(shell.and_(u'sudo pip install jupyter',
                                      u'sudo: pip: command not found')) == u'env "PATH=$PATH" pip install jupyter'


enabled_by_default = False

# Generated at 2022-06-12 12:17:05.960530
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', u'sudo: ls: command not found\n'))


# Generated at 2022-06-12 12:17:08.349719
# Unit test for function match
def test_match():
    assert match(Command('sudo echo',
                         'sudo: echo: command not found'))
    assert not match(Command('sudo echo', 'foo'))



# Generated at 2022-06-12 12:17:12.044716
# Unit test for function match
def test_match():
    assert match(Command('sudo', 'sudo: git: command not found'))
    assert match(Command('sudo', 'sudo: command not found')) is None
    assert match(Command('su', 'su: git: command not found')) is None


# Generated at 2022-06-12 12:17:13.213544
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('sudo vim', 'sudo: vim: command not found'))=='env "PATH=$PATH" vim')

# Generated at 2022-06-12 12:17:17.514107
# Unit test for function match
def test_match():
    assert match(Command('sudo xyz', 'sudo: xyz: command not found'))
    assert not match(Command('ls'))
    assert not match(Command('mkdir test'))
    assert not match(Command('ls test', 'ls: cannot access test: No such file or directory'))
    assert not match(Command('cd /', ''))
    assert not match(Command('cd test', 'bash: cd: test: No such file or directory'))
    assert not match(Command('find . -type f -name test.txt', 'find: paths must precede expression'))


# Generated at 2022-06-12 12:17:19.174768
# Unit test for function match
def test_match():
    output = u"sudo: sshuttle: command not found"
    assert match(Command("sudo sshuttle", output))



# Generated at 2022-06-12 12:17:22.293572
# Unit test for function match
def test_match():
    #Test case 1 - command not found
    result = 'sudo: kubectl: command not found'
    assert match(result) == False
    #Test case 2 - command found
    result = 'sudo: apt: command not found'
    assert match(result) == True


# Generated at 2022-06-12 12:17:26.366372
# Unit test for function get_new_command
def test_get_new_command():
    # Test 1
    script = "sudo apt-get --purge remove nodejs"
    output = "sudo: apt-get: command not found"
    new_command = get_new_command(Command(script, output))
    expected_command = u'env "PATH=$PATH" apt-get --purge remove nodejs'
    assert new_command == expected_command

# Generated at 2022-06-12 12:17:50.444668
# Unit test for function match
def test_match():
    assert _get_command_name(Command('sudo vim', 'sudo: vim: command not found')) == 'vim'
    assert not match(Command('sudo vim', ''))
    assert match(Command('sudo vim', 'sudo: vim: command not found'))


# Generated at 2022-06-12 12:17:53.215104
# Unit test for function get_new_command
def test_get_new_command():
    reverted_command = get_new_command(
        Command('sudo apt-get install',
                u'sudo: apt-get: command not found\r',
                u'foo@bar:~$ '))
    assert reverted_command == "env 'PATH=$PATH' apt-get install"

# Generated at 2022-06-12 12:17:54.908724
# Unit test for function match
def test_match():
    assert match(Command('sudo  bash', 'sudo: bash: command not found'))



# Generated at 2022-06-12 12:17:56.419910
# Unit test for function match
def test_match():
    assert match(Command('sudo not_found', 'sudo: not_found: command not found'))


# Generated at 2022-06-12 12:17:59.010174
# Unit test for function get_new_command
def test_get_new_command():
    assert 'env "PATH=$PATH" test' == get_new_command(Command('sudo', 'test',
                                                               'cmd not found'))

# Generated at 2022-06-12 12:18:01.445038
# Unit test for function match
def test_match():
    assert match(Command('sudo cowsay',
                         'sudo: cowsay: command not found\n'))
    assert not match(Command('sudo cowsay', 'moo\n'))

# Generated at 2022-06-12 12:18:05.295998
# Unit test for function match
def test_match():
    assert match(Command('sudo pactl list', 'sudo: pactl: command not found'))
    assert match(Command('sudo rm /dev/null',
                         'sudo: rm: command not found'))
    assert not match(Command('sudo rm /dev/null',
                         'sudo: rm: command found'))
    assert not match(Command('sudo', 'sudo: command not found'))

# Generated at 2022-06-12 12:18:11.275864
# Unit test for function match
def test_match():
    assert match(Command(script='sudo ls',
                         output='sudo: ls: command not found'))
    assert not match(Command(script='sudo ls',
                             output='sudo: ls: permission denied'))
    assert not match(Command(script='ls',
                             output='sudo: ls: permission denied'))



# Generated at 2022-06-12 12:18:12.868809
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install lol')) == u'sudo env "PATH=$PATH" apt-get install lol'

# Generated at 2022-06-12 12:18:15.576530
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo rm test'
    command_name = _get_command_name(script)
    assert get_new_command(script) == 'env "PATH=$PATH" rm test'

# Generated at 2022-06-12 12:18:39.173820
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install htop',
                         u'sudo: htop: command not found'))
    assert not match(Command('sudo htop', ''))

# Generated at 2022-06-12 12:18:41.892214
# Unit test for function match
def test_match():
    assert match(Command('sudo git',
                         'sudo: git: command not found',
                         1))

    assert not match(Command('sudo git', '', 1))

# Generated at 2022-06-12 12:18:46.857349
# Unit test for function match
def test_match():
    assert (match(Command('sudo date',
                          "sudo: date: command not found")) is
            not None)
    assert (match(Command('sudo date', "")) is
            None)
    assert (match(Command("sudo date",
                          "sudo: date: command not found\nsudo: whoami: command not found")) is
            not None)



# Generated at 2022-06-12 12:18:55.950839
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command(script='sudo apt-get install python', output='sudo: apt-get: command not found')
    command2 = Command(script='sudo apt-get install python2.7', output='sudo: apt-get: command not found')
    command3 = Command(script='sudo apt-get install python3.5', output='sudo: apt-get: command not found')
    new_command1 = get_new_command(command1)
    assert new_command1 == 'sudo env "PATH=$PATH" apt-get install python'
    new_command1 = get_new_command(command2)
    assert new_command1 == 'sudo env "PATH=$PATH" apt-get install python2.7'
    new_command1 = get_new_command(command3)

# Generated at 2022-06-12 12:18:58.179108
# Unit test for function match
def test_match():
    assert match(Command('sudo bla', error='sudo: bla: command not found'))
    assert not match(Command('sudo bla', error='sudo: command not found'))

# Generated at 2022-06-12 12:18:59.278817
# Unit test for function match
def test_match():
	assert match(Command('sudo gedit', ''))


# Generated at 2022-06-12 12:19:02.831807
# Unit test for function get_new_command
def test_get_new_command():
    script = "sudo command_name; sudo"

    assert get_new_command(type('obj', (object, ), dict(script=script,
                                                        output="sudo: command_name: command not found",
                                                        debug=''))).script == "env 'PATH=$PATH' command_name; sudo"

# Generated at 2022-06-12 12:19:09.561998
# Unit test for function match
def test_match():
    # Passing test
    assert match('sudo apt-get install g++')
    assert match('sudo: apt-get: command not found')
    assert match('sudo: command not found')

    # Failing test
    assert not match('sudo apt-get install g++ 2>&1')
    assert not match('sudo apt-get install g++ 1>/dev/null 2>/dev/null')
    assert not match('sudo apt-get install g++')
    assert not match('g++ --version')
    assert not match('apt-get install g++')


# Generated at 2022-06-12 12:19:12.527615
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('sudo xcode-select', 'sudo: xcode-select: command not found')) == Command('env PATH=$PATH xcode-select', '')

# Generated at 2022-06-12 12:19:15.037193
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install a',
                         'sudo: apt-get: command not found'))



# Generated at 2022-06-12 12:20:12.964951
# Unit test for function match
def test_match():
    command_true = Command('sudo apt-get install vim', '', '')
    command_false = Command('sudo apt-get install', '', '')
    assert match(command_true) == True
    assert match(command_false) == False


# Generated at 2022-06-12 12:20:14.821190
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo test', 'sudo: test: command not found')
    assert get_new_command(command) == u'env "PATH=$PATH" test'

# Generated at 2022-06-12 12:20:16.865341
# Unit test for function match
def test_match():
    assert match(Command('sudo echo hello',
                         'sudo: echo: command not found'))
    assert not match(Command('sudo echo hello', ''))



# Generated at 2022-06-12 12:20:18.138226
# Unit test for function get_new_command
def test_get_new_command():
    assert "env 'PATH=$PATH' make" == get_new_command("sudo: make: command not found")

# Generated at 2022-06-12 12:20:27.106012
# Unit test for function get_new_command
def test_get_new_command():
    class sudo_command:
        def __init__(self, script):
            self.script = script
        def __str__(self):
            return self.script

    script1 = 'sudo ls -a /etc'
    script2 = r'''sudo 'echo "Nom Prenom \Nom Prenom"' 'Nom Prenom \Nom Prenom' niveau'''
    command1 = sudo_command(script1)
    command2 = sudo_command(script2)
    print(get_new_command(command1))
    print(get_new_command(command2))

# Generated at 2022-06-12 12:20:30.597744
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    assert get_new_command(Bash('sudo beep', 'sudo: beep: command not found')) == u'env "PATH=$PATH" beep'

# Generated at 2022-06-12 12:20:33.783878
# Unit test for function get_new_command
def test_get_new_command():
    x = "sudo: command: command not found"
    y = "sudo: command"
    new_command, _ = get_new_command(Command('', x))
    assert new_command == 'env "PATH=$PATH" command'

# Generated at 2022-06-12 12:20:37.998287
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command(script='sudo no_command',
                                   stderr='sudo: no_command: command not found')) \
        == 'env "PATH=$PATH" no_command'

    assert get_new_command(Command(script='sudo ls -l',
                                   stderr='sudo: no_command: command not found')) \
        == 'sudo ls -l'

# Generated at 2022-06-12 12:20:42.357954
# Unit test for function match
def test_match():
    output = 'sudo: make: command not found'
    assert _get_command_name(output) == 'make'
    if _get_command_name(output):
        return True
    else:
        return False


# Generated at 2022-06-12 12:20:45.270754
# Unit test for function match
def test_match():
    assert (match(Command(script='sudo', output='sudo: yum: command not found')))
    assert (match(Command(script='yum', output='yum: command not found')))
    assert (match(Command(script='sudo', output='sudo: test: command not found')))
