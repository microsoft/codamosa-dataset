

# Generated at 2022-06-12 12:11:49.891212
# Unit test for function match
def test_match():
    assert match(Command('sudo date',
        stderr='sudo: date: command not found',))
    assert match(Command('sudo wget http://github.com',
        stderr='sudo: wget: command not found',))
    assert not match(Command('sudo su -',
        stderr='user: command not found',))
    assert not match(Command('sudo fdisk -l',
        stderr='fdisk: command not found',))

# Generated at 2022-06-12 12:11:53.897205
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', ''))
    assert not match(Command('sudo apt-get update', 'E: Command line option '
                                                     '\'q\' [from -q] is not '
                                                     'known.'))



# Generated at 2022-06-12 12:11:56.620649
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('sudo echo hi',
                                   'sudo: echo: command not found')) == 'env "PATH=$PATH" echo hi'

# Generated at 2022-06-12 12:11:58.846990
# Unit test for function match
def test_match():
    app = "sudo"
    command= "sudo: vim: command not found"
    assert match(command)


# Generated at 2022-06-12 12:12:07.459725
# Unit test for function match
def test_match():
    assert match(Command('sudo debian', '', '')) is None
    assert match(Command('sudo vim', '', '')) is None
    assert match(Command('sudo vim', '', stderr='sudo: vim: command not found')) is None
    assert match(Command('sudo vim', '', stderr='sudo: vim: command not found\n')) is None
    assert match(Command('sudo vim', '', stderr='sudo: vim: command not found\nThere is another error')) is None
    assert match(Command('sudo vim', '', stderr='sudo: unknonwcommand: command not found\nThere is another error')) is None
    assert match(Command('sudo vim', '', stderr='sudo: vim: command not found\nThere is another error')) is None

# Generated at 2022-06-12 12:12:09.481261
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', output='sudo: ls: command not found'))



# Generated at 2022-06-12 12:12:13.484666
# Unit test for function match
def test_match():
    # Match the output when sudo is used with a command not in eg. PATH
    assert match(Command(script='sudo some-wrong-command', output='sudo: some-wrong-command: command not found'))

    # Match the output when sudo is used with a wrong command
    assert match(Command(script='sudo fdasklfdk', output='sudo: fdasklfdk: command not found'))

    # Don't match the output with other errors
    assert not match(Command(script='sudo fdasklfdk', output='some-wrong-command: command not found'))

    # Don't match the output with other errors
    assert not match(Command(script='sudo some-wrong-command', output='asdf'))



# Generated at 2022-06-12 12:12:15.026013
# Unit test for function match
def test_match():
    if unittest.TestCase().assertTrue(match(Command('sudo apt-get update', ''))):
        print('pass')
    if unittest.TestCase().assertFalse(match(Command('sudo cat', '/bin/bash: cat: command not found'))):
        print('pass')

# Generated at 2022-06-12 12:12:21.779668
# Unit test for function get_new_command
def test_get_new_command():
    ret = get_new_command(
        Command('sudo env "PATH=$PATH" test', 'sudo: test: command not found'))
    assert(ret == 'env "PATH=$PATH" test')
    ret = get_new_command(
        Command('sudo env "PATH=$PATH" -test', 'sudo: -test: command not found'))
    assert(ret == 'env "PATH=$PATH" -test')
    ret = get_new_command(
        Command(
            'sudo env "PATH=$PATH" -test --test',
            'sudo: -test --test: command not found'))
    assert(ret == 'env "PATH=$PATH" -test --test')
    ret = get_new_command(
        Command('sudo env "PATH=$PATH" test -arg',
                'sudo: test -arg: command not found'))

# Generated at 2022-06-12 12:12:26.146325
# Unit test for function match
def test_match():
    assert not match(Command('foo', '', ''))
    assert not match(Command('sudo apt-get update', '', ''))
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found', ''))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command not found', '', stderr='sudo: apt-get: command not found'))



# Generated at 2022-06-12 12:12:30.566415
# Unit test for function get_new_command
def test_get_new_command():
	command_name = _get_command_name("sudo: xyz: command not found")
	assert u'env "PATH=$PATH" xyz'.format(command_name) == get_new_command("sudo: xyz: command not found")

# Generated at 2022-06-12 12:12:34.296248
# Unit test for function match
def test_match():
    assert match(Command('sudo vim test.txt', 'sudo: vim: command not found'))
    assert match(Command('sudo vim test.txt', 'sudo: vim: command not found',
                         None))
    assert not match(Command('vim test.txt',
                             'sudo: vim: command not found'))



# Generated at 2022-06-12 12:12:43.619554
# Unit test for function match
def test_match():
    command= """sudo: python: command not found
    sudo: pip: command not found
    sudo: which: command not found
    sudo: mkdir: command not found
    sudo: echo: command not found
    sudo: export: command not found
    sudo: pwd: command not found
    sudo: cd: command not found
    sudo: locate: command not found
    sudo: su: command not found"""
    found= """sudo: python: command not found
    sudo: pip: command not found
    sudo: which: command not found
    sudo: mkdir: command not found
    sudo: echo: command not found
    sudo: export: command not found
    sudo: pwd: command not found
    sudo: cd: command not found
    sudo: locate: command not found
    sudo: su: command not found"""

# Generated at 2022-06-12 12:12:44.875803
# Unit test for function match
def test_match():
	assert match(Command('sudo echo hello world', ''))



# Generated at 2022-06-12 12:12:46.898834
# Unit test for function match
def test_match():
    assert match(Command('sudo cs', 'sudo: cs: command not found'))
    assert not match(Command('sudo cs', "sudo cs: Permission denied"))


# Generated at 2022-06-12 12:12:51.048989
# Unit test for function match
def test_match():
    assert match(Command('sudo echo a', '', '', '', 'sudo: echo: command not found'))
    assert not match(Command('sudo echo a', '', '', '', '''anacron: Cannot update timestamp for /etc/anacrontab'''))


# Generated at 2022-06-12 12:12:54.291230
# Unit test for function match
def test_match():
    assert match(Command('sudo git status',
                         stderr='sudo: git: command not found'))
    assert not match(Command('sudo git status',
                             stderr='sudo: git: command found'))

# Generated at 2022-06-12 12:12:58.631824
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim', 'sudo: vim: command not found')) == 'env "PATH=$PATH" vim'
    assert get_new_command(Command('sudo vim', 'sudo: vim: command not found\n sudo: /usr/local/bin/vim: command not found')) == 'env "PATH=$PATH" vim'

# Generated at 2022-06-12 12:13:02.073555
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', ''))
    assert not match(Command('sudo apt-get install vim', '', ''))


# Generated at 2022-06-12 12:13:04.857226
# Unit test for function match
def test_match():
    assert match(Command(script='sudo ss -a'))
    assert match(Command(script='sudo s -a'))
    assert not match(Command(script='sudo echo ss -a'))


# Generated at 2022-06-12 12:13:09.072773
# Unit test for function match
def test_match():
    assert match(Command('sudo asdf', stderr='sudo: asdf: command not found'))


# Generated at 2022-06-12 12:13:12.091932
# Unit test for function match
def test_match():
    assert match(Command("sudo echo 'lol'", None, "sudo: echo: command not found"))
    assert not match(Command("sudo echo 'lol'", None, "sudo: lol: command not found"))


# Generated at 2022-06-12 12:13:13.373531
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get', 'foo'))


# Generated at 2022-06-12 12:13:21.474694
# Unit test for function match
def test_match():
    assert match(Command(script='sudo bash', output='sudo: bash: command not found'))
    assert match(Command(script='sudo pwd', output='sudo: pwd: command not found'))
    assert not match(Command(script='sudo pwd', output='sudo: pwd: command not found', stdout='/Users/krunal/Desktop/Power\n'))
    assert match(Command(script='sudo -i', output='sudo: -i: command not found'))
    assert not match(Command(script='sudo -i', output='sudo: -i: command not found', stdout='/Users/krunal/Desktop/Power\n'))
    a = Command(script='sdo', output='sdo: sdo: command not found\n'
        'sdo: sdo: command not found\n')

# Generated at 2022-06-12 12:13:29.723869
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo shutdown now', 'sudo: shutdown: command not found')) == 'env "PATH=$PATH" shutdown'
    assert get_new_command(Command('sudo shudown now', 'sudo: shudown: command not found')) == 'env "PATH=$PATH" shudown'
    assert get_new_command(Command('sudo  shutdown  now', 'sudo: shutdown: command not found')) == 'env "PATH=$PATH" shutdown'
    assert get_new_command(Command('sudo shutdown now shutdown now', 'sudo: shutdown: command not found')) == 'env "PATH=$PATH" shutdown now shutdown now'

# Generated at 2022-06-12 12:13:33.781620
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'sudo: abc: command not found'))
    assert not match(Command('sudo abc', 'sudo: abd: command not found'))
    assert not match(Command('not sudo abc', 'sudo: abc: command not found'))
    assert not match(Command('sudo abc', 'sudo: abc: command not'))
    assert not match(Command('sudo abc', ''))



# Generated at 2022-06-12 12:13:36.830253
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo kubectl get pods',
                                   '/bin/bash: kubectl: command not found')) == \
           'env "PATH=$PATH" kubectl get pods'

# Generated at 2022-06-12 12:13:41.852228
# Unit test for function match
def test_match():
    # Unit test for case command not found
    assert match(Command(script=u'sudo ls', output=u'sudo: ls: command not found'))
    assert match(Command(script=u'sudo ls', output=u'sudo: foo: command not found'))
    # Unit test for case command found
    assert not match(Command(script=u'sudo ls', output=u'unknown option "foo"'))
    # Unit test for case unknown error
    assert not match(Command(script=u'sudo ls', output=u'unknown err'))


# Generated at 2022-06-12 12:13:46.316316
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update',
                         'sudo: apt-get: command not found'))
    assert match(Command('sudo ls frd', 'sudo: ls: command not found'))
    assert not match(Command('ls frd', 'sudo: ls: command not found'))


# Generated at 2022-06-12 12:13:49.601337
# Unit test for function match
def test_match():
    assert match(Command('sudo echo'))
    assert match(Command('sudo ls'))
    assert not match(Command('echo'))
    assert not match(Command('sudo echo', output='sudo: echo: command found'))



# Generated at 2022-06-12 12:13:53.856947
# Unit test for function match
def test_match():
    assert match(Command('sudo test', 'sudo: test: command not found'))
    assert not match(Command('sudo test', ''))

# Generated at 2022-06-12 12:13:56.373516
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get', 'sudo: install: command not found'))


# Generated at 2022-06-12 12:13:59.086765
# Unit test for function match
def test_match():
    # Should return true if there is a command not found in command's output
    from tests.utils import Command
    assert match(Command('sudo bash'))
    assert not match(Command('su bash'))



# Generated at 2022-06-12 12:14:02.533857
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo python test.py', '')) == 'env "PATH=$PATH" python test.py'


# Generated at 2022-06-12 12:14:04.204614
# Unit test for function match
def test_match():
    assert match(Command(script='sudo ls',
                  output='sudo: ls: command not found'))


# Generated at 2022-06-12 12:14:05.479401
# Unit test for function match
def test_match():
    assert match(Command('sudo echo hi', output='output'))



# Generated at 2022-06-12 12:14:08.424510
# Unit test for function get_new_command
def test_get_new_command():
    new = get_new_command(Command('\nsudo: blah: command not found',
                                  '', '\nsudo: blah: command not found'))
    assert new == 'env "PATH=$PATH" blah'

# Generated at 2022-06-12 12:14:11.421259
# Unit test for function match
def test_match():
    # Test for function match
    assert match(Command('sudo true', 'sudo: true: command not found'))
    assert not match(Command('sudo true', 'sudo: true: command found'))
    assert not match(Command('sudo true', 'sudo: true: found'))


# Generated at 2022-06-12 12:14:13.759927
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'W: Not using locking for read only lock file /var/lib/dpkg/lock'))

# Generated at 2022-06-12 12:14:17.167097
# Unit test for function match
def test_match():
    assert match(Command('sudo abc',
                         'sudo: abc: command not found\nsudo: 3 incorrect password attempts\n'))
    assert not match(Command('sudo abc', ''))

# Generated at 2022-06-12 12:14:21.749253
# Unit test for function match
def test_match():
    assert (match(command="# sudo not existing-command") == which(
            "not existing-command"))



# Generated at 2022-06-12 12:14:23.422609
# Unit test for function match
def test_match():
    output = "sudo: node: command not found"
    assert match(Command('sudo node', output))


# Generated at 2022-06-12 12:14:24.988283
# Unit test for function match
def test_match():
    assert match(Command('sudo foo', 'sudo: foo: command not found'))



# Generated at 2022-06-12 12:14:27.910895
# Unit test for function get_new_command
def test_get_new_command():
    c = Command('echo sudo test', 'sudo: test: command not found')
    assert get_new_command(c) == u'env "PATH=$PATH" echo test'


enabled_by_default = True

# Generated at 2022-06-12 12:14:31.822757
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_e import get_new_command
    assert get_new_command(Command('sudo ls', 
        'sudo: ls: command not found\n')) == u'sudo env "PATH=$PATH" ls'

# Generated at 2022-06-12 12:14:35.253101
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo vim', output="sudo: vim: command not found")) == "env \"PATH=$PATH\" vim"
    assert get_new_command(Command(script='sudo vim', output="sudo: vim: command nfound")) == "sudo vim"

# Generated at 2022-06-12 12:14:37.197537
# Unit test for function match
def test_match():
    assert match(Command('sudo lol', 'sudo: lol: command not found'))
    assert not match(Command('sudo lol', ''))


# Generated at 2022-06-12 12:14:40.916585
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    command = Script('nmap 127.0.0.1', 'sudo: nmap: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" nmap 127.0.0.1'
    command = Script('sudo', 'sudo: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" sudo'

# Generated at 2022-06-12 12:14:43.587193
# Unit test for function match
def test_match():
    assert not match(Command('id', '', '', '', ''))
    assert match(Command('sudo testible', '', '', 'sudo: testible: command not found', ''))


# Generated at 2022-06-12 12:14:45.253911
# Unit test for function match
def test_match():
    assert match(Command(script='sudo abc', output="sudo: abc: command not found"))


# Generated at 2022-06-12 12:14:49.829427
# Unit test for function match
def test_match():
    assert list(match(Command('sudo apt-get install', '')))[0].script == \
    u'apt-get install'



# Generated at 2022-06-12 12:14:52.058859
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install lol', ''))
    assert not match(Command('sudo apt-get install lol', 'lol not found'))


# Generated at 2022-06-12 12:14:53.637031
# Unit test for function match
def test_match():
    assert match(Command('sudo ls',
        'sudo: ls: command not found'))


# Generated at 2022-06-12 12:14:57.862936
# Unit test for function match
def test_match():
    assert match(Command('sudo env "PATH=abc" apt-get install', "")) != None
    assert match(Command('sudo env "PATH=abc" apt-get install', "sudo: apt-get: command not found")) != None
    assert match(Command('sudo apt-get install', "")) != None



# Generated at 2022-06-12 12:15:02.000327
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo npm')) == u'env "PATH=$PATH" npm'
    assert get_new_command(Command(script='sudo gem')) == u'env "PATH=$PATH" gem'
    assert get_new_command(Command(script='sudo brew')) == u'env "PATH=$PATH" brew'

# Generated at 2022-06-12 12:15:04.829902
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('sudo ls xxx', 'sudo: ls: command not found'))
            == u'env "PATH=$PATH" ls xxx')

# Generated at 2022-06-12 12:15:07.675972
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: abc: command not found'))


# Generated at 2022-06-12 12:15:10.761003
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('sudo echo a',
                                          'sudo: echo: command not found'))
    assert u'env "PATH=$PATH" echo a' in str(new_command)

# Generated at 2022-06-12 12:15:13.143619
# Unit test for function match
def test_match():
    assert match(Command('sudo app1', 'sudo: app1: command not found'))
    assert not match(Command('sudo app1', ''))



# Generated at 2022-06-12 12:15:15.569008
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo apt-get update', 'sudo: apt-get: command not found\n')
    assert get_new_command(command) == 'sudo env "PATH=$PATH" apt-get update'



# Generated at 2022-06-12 12:15:24.093998
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo abc arg1 arg2 arg3', '')) == 'env "PATH=$PATH" abc arg1 arg2 arg3'
    assert get_new_command(Command('sudo abc arg1 arg2 arg3', 'sudo: abc: command not found\n')) == 'env "PATH=$PATH" abc arg1 arg2 arg3'
    assert get_new_command(Command('sudo abc arg1 arg2 arg3', 'abc: command not found\n')) == 'sudo abc arg1 arg2 arg3'
    assert get_new_command(Command('sudo abc arg1 arg2 arg3', 'sudo abc arg1 arg2 arg3\n')) == 'sudo abc arg1 arg2 arg3'

# Generated at 2022-06-12 12:15:27.861139
# Unit test for function get_new_command
def test_get_new_command():
    output = "sudo: 3: command not found"
    comment = False
    assert get_new_command(Command('sudo 3', output, comment)) == "env " + "\"" + "PATH=$PATH" + "\"" + " 3"


# Generated at 2022-06-12 12:15:34.755152
# Unit test for function match
def test_match():
    # Function match should match 'sudo: /usr/local/bin/pwsh: command not found'
    # The output above is from Mac OSX
    command = 'sudo: /usr/local/bin/pwsh: command not found'
    assert match(command) == True
    # Function match should not match 'sudo: no pwsh in (/usr/local/sbin:/usr/local/bin:...)'
    # The output above is also from Mac OSX
    command = 'sudo: no pwsh in (/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games)'
    assert match(command) == False


# Generated at 2022-06-12 12:15:36.371750
# Unit test for function match
def test_match():
    from test_utils import Command

    assert match(Command('sudo f')) is not None
    assert match(Command('sudo -E f')) is None

# Generated at 2022-06-12 12:15:38.588661
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo sedsad', 'sudo: sedsad: command not found')) == u'sudo env "PATH=$PATH" sedsad'

# Generated at 2022-06-12 12:15:40.030950
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo ls') == 'env "PATH=$PATH" ls'

enabled_by_default = True

# Generated at 2022-06-12 12:15:45.873861
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo test', 'sudo: test: command not found')) == "env 'PATH=$PATH' test"
    assert get_new_command(Command('sudo -E test', 'sudo: test: command not found')) == "env 'PATH=$PATH' test"
    assert get_new_command(Command('sudo test -p --test "test"', 'sudo: test: command not found')) == "env 'PATH=$PATH' test -p --test 'test'"
    assert get_new_command(Command('sudo -E test -p --test "test"', 'sudo: test: command not found')) == "env 'PATH=$PATH' test -p --test 'test'"

# Generated at 2022-06-12 12:15:54.497613
# Unit test for function get_new_command
def test_get_new_command():
    def run_get_new_command(command, expected_script):
        actual_script = get_new_command(Command('', command))
        assert actual_script == expected_script

    run_get_new_command('sudo foo', u'env "PATH=$PATH" sudo foo')
    run_get_new_command('sudo foo >&2', u'env "PATH=$PATH" sudo foo >&2')
    run_get_new_command('sudo foo bar', u'env "PATH=$PATH" sudo foo bar')
    run_get_new_command('sudo foo bar >&2',
                        u'env "PATH=$PATH" sudo foo bar >&2')



# Generated at 2022-06-12 12:15:57.073228
# Unit test for function match
def test_match():
    assert match(Command('sudo ttyecho', '', 'sudo: ttyecho: command not found\n'))
    assert not match(Command('sudo ttyecho', '', 'sudo: ttyecho: command not found d'))


# Generated at 2022-06-12 12:15:59.407728
# Unit test for function match
def test_match():
    assert not match(Command('sudo echo test', '', ''))
    assert match(Command('sudo lsasd', 'sudo: lsasd: command not found', ''))
    assert not match(Command('sudo exit', '', ''))

# Generated at 2022-06-12 12:16:06.993553
# Unit test for function get_new_command
def test_get_new_command():
    def mock_get_cmd_output(script):
        return s
    mock_command = type('obj', (object,), {
        'script': 'sudo echo "Hello world"',
        'output': 'sudo: echo: command not found'
    })
    assert get_new_command(mock_command) == 'env "PATH=$PATH" sudo echo "Hello world"'

# Generated at 2022-06-12 12:16:09.345534
# Unit test for function match
def test_match():
    assert match(Command('sudo echo', '')) is None
    assert not match(Command('sudo echo', 'sudo: echo: command not found'))



# Generated at 2022-06-12 12:16:14.013378
# Unit test for function match
def test_match():
    # command.script is the input string
    command = type('Command', (object,), dict(script='sudo ls', output='sudo: ls: command not found'))

    assert match(command)

    command = type('Command', (object,), dict(script='sudo ls', output='password'))

    assert not match(command)


# Generated at 2022-06-12 12:16:15.845447
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo fk', 'sudo: fk: command not found')) == u'sudo env "PATH=$PATH" fk'

# Generated at 2022-06-12 12:16:18.509460
# Unit test for function match
def test_match():
    script = 'sudo: lala: command not found'
    command = Command(script, script)
    assert match(command)
    assert _get_command_name(command) == 'lala'


# Generated at 2022-06-12 12:16:22.572565
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Shell
    correct = u"env PATH='$PATH' sudo -k lss"
    assert get_new_command(Shell('sudo -k lss', 'sudo: lss: command not found', 'sudo: lss: command not found')) == correct

# Generated at 2022-06-12 12:16:26.092667
# Unit test for function get_new_command
def test_get_new_command():
    from mock import Mock
    command_name = 'much-ado-about-nothing'
    command = Mock(script='sudo {}'.format(command_name),
                   output='sudo: {}: command not found'.format(command_name))
    assert get_new_command(command) == 'env "PATH=$PATH" {}'.format(command_name)

# Generated at 2022-06-12 12:16:28.903697
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', '')) == None
    assert match(Command('sudo ls', 'sudo: ls: command not found'))



# Generated at 2022-06-12 12:16:31.129742
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim', 'sudo: vim: command not found')) == 'env "PATH=$PATH" vim'
    assert get_new_command(Command('sudo', 'sudo: vim: command not found')) == 'env "PATH=$PATH" '

# Generated at 2022-06-12 12:16:32.155101
# Unit test for function match
def test_match():
    return


# Generated at 2022-06-12 12:16:41.237973
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo apt-get update')) == 'env "PATH=$PATH" apt-get update'
    assert get_new_command(Command(script='sudo apt-get update -y')) == 'env "PATH=$PATH" apt-get update -y'
    assert get_new_command(Command(script='sudo apt-get update; sudo apt-get upgrade')) == 'env "PATH=$PATH" apt-get update; sudo apt-get upgrade'
    assert get_new_command(Command(script='sudo apt-get update && sudo apt-get upgrade')) == 'env "PATH=$PATH" apt-get update && sudo apt-get upgrade'

# Generated at 2022-06-12 12:16:42.512354
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', stderr='sudo: apt-get: command not found'))


# Generated at 2022-06-12 12:16:48.772424
# Unit test for function match
def test_match():
    assert(match(Command('sudo touch /etc/rails_gitignore', '')) == True)
    assert(match(Command('sudo touch /etc/rails_gitignore', 'sudo: touch: command not found')) == True)
    assert(match(Command('sudo touch /etc/rails_gitignore', 'sudo: /etc/rails_gitignore: Permission denied')) == False)


# Generated at 2022-06-12 12:16:54.561030
# Unit test for function match
def test_match():
    getattr(match, '__wrapped__')
    with patch('thefuck.rules.sudo.which') as which_mock:
        which_mock.return_value = '/usr/bin/test'
        assert match(Command('sudo test', 'sudo: test: command not found'))
        assert not match(Command('sudo test', 'no such file'))
        assert not match(Command('sudo test'))
        assert not match(Command('test', 'sudo: test: command not found'))


# Generated at 2022-06-12 12:16:55.504070
# Unit test for function match
def test_match():
    assert match(Command(script='sudo some_command', output="sudo: some_command: command not found"))


# Generated at 2022-06-12 12:16:58.004285
# Unit test for function match
def test_match():
    assert not match(Command('sudo c'))
    assert match(Command(u'sudo c', u'sudo: c: command not found'))


# Generated at 2022-06-12 12:16:59.912044
# Unit test for function match
def test_match():
    assert not match(Command('git', 'sudo: git: command not found'))
    assert match(Command('git', 'sudo: git: command not found'))


# Generated at 2022-06-12 12:17:03.443204
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('sudo vim', 'sudo: vim: command not found'))
            == 'env "PATH=$PATH" vim')
    assert (get_new_command(Command('sudo vim', 'sudo: vim: command not found'))
            == 'env "PATH=$PATH" vim')
    assert (get_new_command(Command('sudo vim -c "q"'))
            == 'env "PATH=$PATH" vim -c "q"')

# Generated at 2022-06-12 12:17:05.133819
# Unit test for function match
def test_match():
    assert match(Command('sudo test', 'sudo: test: command not found\n'))
    assert not match(Command('sudo test', ''))


# Generated at 2022-06-12 12:17:09.200306
# Unit test for function match
def test_match():
    assert not match(Command('ls'))
    assert match(Command('sudo test'))
    assert not match(Command('sudo test', 'sudo: test: command not found\n'))
    assert not match(Command('sudo test', 'sudo: test: command not found\n',
                             'sudo: test: command not found'))


# Generated at 2022-06-12 12:17:17.289056
# Unit test for function match
def test_match():
    assert match(Command('sudo dpkg', ''))
    assert not match(Command('sudo apt-get install', ''))

# Generated at 2022-06-12 12:17:18.629587
# Unit test for function match
def test_match():
    assert match(Command('sudo echo test', ''))
    assert not match(Command('echo test', ''))

# Generated at 2022-06-12 12:17:20.073205
# Unit test for function match
def test_match():
    assert match(Command('sudo foo', 'sudo: foo: command not found'))



# Generated at 2022-06-12 12:17:21.469690
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not '
                                   'found\nsudo: command not found')) == 'env "PATH=$PATH" ls'


# Generated at 2022-06-12 12:17:25.465292
# Unit test for function match
def test_match():
    assert match(Command('sudo a', '', 'sudo: a: command not found'))
    assert match(Command('sudo a', '', 'sudo: a: foo bar')) is None
    assert match(Command('sudo a', '', 'foo sudo: a: command not found bar')) is None
    assert match(Command('sudo a', '', '')) is None


# Generated at 2022-06-12 12:17:29.140966
# Unit test for function match
def test_match():
    assert match(Command('sudo su', "", "sudo: /usr/bin/su: command not found"))
    assert not match(Command('sudo su', "", u'\t /usr/bin/su'))
    assert not match(Command('sudo su', "", u'command not found'))


# Generated at 2022-06-12 12:17:32.959608
# Unit test for function get_new_command
def test_get_new_command():
    command_obj = type('command', (object,), {'script':'thefuck git pull', 'output': 'sudo: git: command not found'})
    assert get_new_command(command_obj) == 'thefuck env "PATH=$PATH" git pull'


# Generated at 2022-06-12 12:17:34.498126
# Unit test for function match
def test_match():
    assert match(Command('', ''))
    assert not match(Command('sudo apt-get upgrade', ''))

# Generated at 2022-06-12 12:17:38.884892
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('sudo vim'))
    assert result == u"env 'PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin' vim"

    result = get_new_command(Command('sudo ./vim'))
    assert result == u"env 'PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin' ./vim"

    result = get_new_command(Command('sudo /usr/bin/vim'))
    assert result == u"env 'PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin' /usr/bin/vim"



# Generated at 2022-06-12 12:17:41.636928
# Unit test for function match
def test_match():
    # when error is not command not found
    assert match(Command('sudo rm', 'sudo: rm: command not found', '')) is None
    # when error is command not found
    assert match(Command('sudo rm', 'sudo: rm: command not found', ''))



# Generated at 2022-06-12 12:17:56.018098
# Unit test for function match
def test_match():
    command = Command('sudo x', 'sudo: x: command not found')
    assert match(command)
    command = Command('sudo x', 'sudo: x: command not found')
    assert match(command)


# Generated at 2022-06-12 12:18:04.199146
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo vim test.txt',
        "sudo: vim: command not found")) == 'env "PATH=$PATH" vim test.txt'
    assert get_new_command(Command('sudo vim test.txt',
        "sudo: /usr/local/bin/vim: command not found")) == 'env "PATH=$PATH" /usr/local/bin/vim test.txt'
    assert get_new_command(Command('sudo vim test.txt',
        "sudo: vim: command not found\r\r\nsudo: aa: command not found")) == 'env "PATH=$PATH" vim test.txt'

# Generated at 2022-06-12 12:18:08.076384
# Unit test for function match
def test_match():
    assert match(Command('sudo echo $SHELL',
                         'sudo: echo: command not found'))
    assert not match(Command('sudo echo $SHELL', 'bash'))



# Generated at 2022-06-12 12:18:12.530315
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Generic
    from thefuck.types import Command
    from thefuck.main import Rule
    assert Rule(match, get_new_command).get_new_command(
            Command('sudo ssh abc', 'sudo: ssh: command not found',
                    Generic()), None) == 'env "PATH=$PATH" ssh abc'

# Generated at 2022-06-12 12:18:15.575241
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'sudo: abc: command not found'))
    assert not match(Command('grep lol', ''))
    assert not match(Command('sudo apt-get update', ''))

# Generated at 2022-06-12 12:18:17.521255
# Unit test for function match
def test_match():
    command = Command('sudo gedit', '')
    assert match(command)


# Generated at 2022-06-12 12:18:20.127465
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'sudo: abc: command not found\n'))

    assert not match(Command('sudo abc', 'sudo: abc: command found\n'))



# Generated at 2022-06-12 12:18:21.993461
# Unit test for function match
def test_match():
    assert match(Command('sudo fasdf', 'sudo: fasdf: command not found'))
    assert not match(Command('sudo ls', ''))

# Generated at 2022-06-12 12:18:27.311826
# Unit test for function get_new_command
def test_get_new_command():
    command_name = 'ls'
    script = 'sudo {}'.format(command_name)
    command = type('obj', (object,), {
        'script': script,
        'output': 'sudo: {}: command not found'.format(command_name)})
    assert get_new_command(command) == 'sudo env "PATH=$PATH" {}'.format(command_name)


enabled_by_default = True

# Generated at 2022-06-12 12:18:30.829001
# Unit test for function match
def test_match():
    assert match(Command('sudo command',
                         'sudo: command: command not found'))
    assert not match(Command('sudo command', ''))
    assert not match(Command('sudo command', 'sudo: command: '))
    assert not match(Command('sudo command', 'sudo: command: command'))



# Generated at 2022-06-12 12:18:59.543094
# Unit test for function match
def test_match():
    assert match(Command('sudo a', "sudo: a: command not found"))
    assert match(Command('sudo a', "sudo: a: command not found\n"))
    assert match(Command('sudo a', "sudo: a: command not found\n\n"))
    assert match(Command('sudo a', "sudo: a: command not found\n\n\n"))
    assert match(Command('sudo a', "sudo: a: command not found\n\n\n\n"))
    assert not match(Command('sudo a', "sudo: a: command not found sudo: a: command not found"))

    assert match(Command('sudo a', "XDG_SESSION_ID=64 sudo: a: command not found\n"))


# Generated at 2022-06-12 12:19:02.583927
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    output = u'sudo: l: command not found'
    new_command = get_new_command(output)
    assert new_command == u'env "PATH=$PATH" l'

# Generated at 2022-06-12 12:19:06.956421
# Unit test for function match
def test_match():
    assert match(Command(script='sudo apt-get install lolcathost'))
    assert match(Command(script='sudo python'))
    assert match(Command(script='sudo cd', output='sudo: cd: command not found'))
    assert match(Command(script='sudo gedit', output='sudo: gedit: command not found'))
    assert not match(Command(script='sudo cd', output='sudo: cd: directory not found'))
    assert not match(Command(script='sudo gsettings', output='sudo: gsettings: no such schema'))


# Generated at 2022-06-12 12:19:10.227292
# Unit test for function match
def test_match():
    command = Command(script='sudo pacman -Syyu')
    assert not match(command)
    command = Command(script='sudo pacman -Syyu', output='sudo: pacman: command not found')
    assert match(command)


# Generated at 2022-06-12 12:19:12.287596
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))


# Generated at 2022-06-12 12:19:15.133397
# Unit test for function match
def test_match():
    assert match(Command('sudo test', "sudo: test: command not found\n"))
    assert not match(Command('sudo test', "sudo: test: command found\n"))


# Generated at 2022-06-12 12:19:17.297742
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo abc', 'sudo: abc: command not found')) == 'env "PATH=$PATH" abc'

# Generated at 2022-06-12 12:19:21.761094
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo abc', 'sudo: abc: command not found')) \
            == 'env "PATH=$PATH" abc'
    assert get_new_command(Command('sudo abc def', 'sudo: abc: command not found')) \
            == 'env "PATH=$PATH" abc def'

# Generated at 2022-06-12 12:19:23.172502
# Unit test for function match
def test_match():
    assert match(Command('sudo -v', "sudo: -v: command not found\n"))


# Generated at 2022-06-12 12:19:30.999282
# Unit test for function match
def test_match():
	assert match(Command('git pull',
						'sudo: git: command not found',
						'/usr/local/bin/prs',
						'git@github.com:wahyd4/thefuck#develop'))
	assert not match(Command('git pull',
						'Unknown option: pull',
						'/usr/local/bin/prs',
						'git@github.com:wahyd4/thefuck#develop'))

# Generated at 2022-06-12 12:20:35.140766
# Unit test for function match
def test_match():
    assert which('ls')
    assert not match(Command('sudo ls', ''))

    not_found = Command('sudo blablabla', 'sudo: blablabla: command not found')
    assert match(not_found)
    assert _get_command_name(not_found) == 'blablabla'


# Unit tests for function get_new_command

# Generated at 2022-06-12 12:20:37.006919
# Unit test for function match
def test_match():
    assert match(Command("sudo sudo", "sudo: sudo: command not found"))
    assert match(Command("sudo vim", "sudo: vim: command not found"))


# Generated at 2022-06-12 12:20:42.333810
# Unit test for function match
def test_match():
    script1 = 'sudo: ops: command not found'
    script2 = 'sudo: /home/ops: command not found'
    command1 = Command('', script1)
    command2 = Command('', script2)
    assert(len(match(command1)) == 1)
    assert(len(match(command2)) == 1)


# Generated at 2022-06-12 12:20:43.447227
# Unit test for function match
def test_match():
    assert match(Command('', '', 'sudo: pyton: command not found'))
    assert not match(Command('', '', ''))



# Generated at 2022-06-12 12:20:44.445141
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', '/# '))


# Generated at 2022-06-12 12:20:47.002376
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'abc: command not found'))
    assert not match(Command('sudo abc', 'zsh: command not found'))
    assert not match(Command('sudo abc', 'sudo: command not found'))


# Generated at 2022-06-12 12:20:49.438992
# Unit test for function match
def test_match():
    assert which('ssh')
    assert _get_command_name(Command('sudo foo',
                                     output='sudo: foo: command not found')) == 'foo'
    assert match(Command('sudo foo',
                         output='sudo: foo: command not found'))
    assert not match(Command('sudo foo'))

# Generated at 2022-06-12 12:20:53.193580
# Unit test for function match
def test_match():
    assert match('sudo find /usr/lib/jvm/java-6-openjdk-amd64/include/linux/jawt_md.h')
    assert match('sudo pip install requests')
    assert match('sudo pip install requests')
    assert not match('sudo ls -l')
    assert not match('find /usr/lib/jvm/java-6-openjdk-amd64/include/linux/jawt_md.h')
    assert not match('sudo la')


# Generated at 2022-06-12 12:20:55.907692
# Unit test for function match
def test_match():
    command = Command("sudo echo Hi", "sudo: echo: command not found")
    assert match(command) == which(command)
    assert match(Command('echo Hi', 'echo: command not found')) == False


# Generated at 2022-06-12 12:20:59.975481
# Unit test for function match
def test_match():
    assert match(Command('sudo fg;exit', ''))
    assert match(Command('sudo fg;exit', 'sudo: fg: command not found\n'))
    assert match(Command('sudo fg;exit', 'sudo: fg: command not found\n', None))

