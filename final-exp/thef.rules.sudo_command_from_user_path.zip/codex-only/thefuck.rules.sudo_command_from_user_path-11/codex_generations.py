

# Generated at 2022-06-24 07:18:06.728493
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo update-alternatives', '', 'sudo: update-alternatives: command not found')
    assert 'sudo env "PATH=$PATH" update-alternatives' == get_new_command(command)



# Generated at 2022-06-24 07:18:08.968741
# Unit test for function match
def test_match():
    assert match(Command('sudo tldr hello'))
    assert match(Command('sudo hello', ''))
    assert not match(Command('git push'))


# Generated at 2022-06-24 07:18:13.246681
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim',
                         '/usr/bin/sudo apt-get install vim\nsudo: apt-get: command not found\n',
                         None, 1))
    assert not match(Command('sudo apt-get update vim',
                             '/usr/bin/sudo apt-get update vim\nGet:1 http://ca.archive.ubuntu.com trusty InRelease [65 B]\n',
                             None, 1))

# Generated at 2022-06-24 07:18:16.004336
# Unit test for function match
def test_match():
    assert match(Command('sudo ls',
                         'sudo: ls: command not found',
                         ok_codes=[0, 127]))
    assert not match(Command('sudo ls'))



# Generated at 2022-06-24 07:18:20.036818
# Unit test for function match
def test_match():
  assert not match(Command('sudo apt-get install lol', ''))
  assert not match(Command('sudo lol', ''))
  assert match(Command('sudo lol', 'sudo: lol: command not found'))
  assert match(Command('sudo lol lol', 'sudo: lol: command not found'))



# Generated at 2022-06-24 07:18:22.959302
# Unit test for function get_new_command
def test_get_new_command():
    command = MagicMock(script=u'sudo nano', output=u'sudo: nano: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" sudo nano'

# Generated at 2022-06-24 07:18:32.335945
# Unit test for function match
def test_match():
    assert match(Command('sudo npm init', 'sudo: npm: command not found'))
    assert match(Command('sudo mvn version', 'sudo: mvn: command not found'))
    assert match(Command('sudo kubectl version', 'sudo: kubectl: command not found'))
    assert not match(Command('sudo npm init', 'sudo: node: command not found'))
    assert not match(Command('sudo mvn version', 'sudo: maven: command not found'))
    assert not match(Command('sudo kubectl version', 'sudo: kube: command not found'))


# Generated at 2022-06-24 07:18:37.266413
# Unit test for function get_new_command
def test_get_new_command():
    command_output = 'sudo: /usr/local/bin/python: command not found'
    new_command = get_new_command(Command('sudo /usr/local/bin/python', command_output))
    assert new_command == 'env "PATH=$PATH" /usr/local/bin/python'
    assert not get_new_command(Command('sudo ls'))

# Generated at 2022-06-24 07:18:43.021149
# Unit test for function match
def test_match():
    import tempfile
    exec_path = tempfile.mktemp()
    open(exec_path, 'a').close()
    command = Command('sudo {}'.format(exec_path), 'sudo: {}: command not found'.format(exec_path))
    assert match(command)
    command = Command('sudo {}-test'.format(exec_path), 'sudo: {}-test: command not found'.format(exec_path))
    assert not match(command)
    os.remove(exec_path)


# Generated at 2022-06-24 07:18:44.895703
# Unit test for function match
def test_match():
    assert match(Command('sudo brew install'))
    assert not match(Command('sudo apt-get install'))


# Generated at 2022-06-24 07:18:48.158440
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', 'sudo: apt-get: command found'))


# Generated at 2022-06-24 07:18:51.078920
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('ls', 'sudo: ls: command not found')) == 'sudo env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:18:54.344959
# Unit test for function match
def test_match():
    assert match(Command(script = u'sudo gifsicle', output = u'sudo: gifsicle: command not found'))
    assert not match(Command(script = u'sudo gifsicle', output = u'usage: gifsicle [options] ... [file]'))



# Generated at 2022-06-24 07:19:00.050339
# Unit test for function match
def test_match():
    assert _get_command_name(Command('sudo apt-get install test', 'sudo: apt-get: command not found')) == 'apt-get'
    assert match(Command('sudo apt-get install test', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install test', 'sudo: apt-get: command not found'))

# Generated at 2022-06-24 07:19:03.248165
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('sudo kubectl get clusterrole', 'sudo: kubectl: command not found'))
    assert new_command == 'env "PATH=$PATH" kubectl get clusterrole'

# Generated at 2022-06-24 07:19:06.481944
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo dpkg --configure -a',
                                   'sudo: dpkg: command not found')) == \
                                   u'env "PATH=$PATH" dpkg --configure -a'

# Generated at 2022-06-24 07:19:08.987455
# Unit test for function match
def test_match():
    command = Command(script = u'sudo asdasd', output = u'sudo: asdasd: command not found')
    assert match(command)



# Generated at 2022-06-24 07:19:12.026917
# Unit test for function match
def test_match():
    cmd = Command(
        script=u"sudo ps aux | awk '{print $1}'",
        output=u'sudo: ps: command not found',
    )
    assert match(cmd)



# Generated at 2022-06-24 07:19:20.337481
# Unit test for function get_new_command
def test_get_new_command():
    import sys
    import unittest

    from thefuck.types import Command

    class TestCases(unittest.TestCase):

        def test_get_new_command(self):
            self.assertEqual(get_new_command(Command('sudo ls', '', '')),
                             'env "PATH=$PATH" sudo ls')
            self.assertEqual(get_new_command(Command('sudo  ls', '', '')),
                             'env "PATH=$PATH" sudo  ls')
            self.assertEqual(get_new_command(Command('sudo -abc ls', '', '')),
                             'env "PATH=$PATH" sudo -abc ls')
            self.assertEqual(get_new_command(Command('sudo ls abc', '', '')),
                             'env "PATH=$PATH" sudo ls abc')

# Generated at 2022-06-24 07:19:24.274392
# Unit test for function get_new_command
def test_get_new_command():
    script1 = u'sudo htop'
    script2 = u'sudo env "PATH=$PATH" htop'
    assert get_new_command(Command(script1, 'sudo: htop: command not found')) == script2

# Generated at 2022-06-24 07:19:26.715257
# Unit test for function match
def test_match():
    # Test case 1:
        assert match(Command('sudo apt-get install abc', output='sudo: pip: command not found'))



# Generated at 2022-06-24 07:19:29.838538
# Unit test for function match
def test_match():
    assert match(Command('sudo htop', u'sudo: htop: command not found\n'))
    assert not match(Command('sudo htop', u'sudo: htop: command not foun'))

# Generated at 2022-06-24 07:19:32.262425
# Unit test for function match
def test_match():
    assert match(Command('sudo git', ''))
    assert not match(Command('sudo ls', ''))


# Generated at 2022-06-24 07:19:34.925482
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command(Command('env', 'env "PATH=$PATH" ls')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:19:37.703432
# Unit test for function match
def test_match():
    assert match(Command('sudo aaa'))
    assert not match(Command('sudo aaa', '\nsudo: aaa: command not found'))



# Generated at 2022-06-24 07:19:40.512102
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo vim /etc/hosts') == u'env "PATH=$PATH" vim /etc/hosts'
    assert get_new_command('sudo ls') == u'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:19:43.126503
# Unit test for function match
def test_match():
    assert match(Command('sudo cal', None, 'sudo: cal: command not found'))
    assert not match(Command('sudo: cal: command not found', None))



# Generated at 2022-06-24 07:19:47.367616
# Unit test for function match
def test_match():
    assert match(Command('%s' % 'sudo /usr/bun/test', 'sudo: /usr/bun/test: command not found'))
    assert not match(Command('sudo apt-get install vim', 'Do you want to continue? [Y/n]'))



# Generated at 2022-06-24 07:19:51.789268
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt install', 'sudo: apt: command not found')) == 'sudo env "PATH=$PATH" apt install'
    assert get_new_command(Command('sudo apt install postgresql', 'sudo: apt: command not found')) == 'sudo env "PATH=$PATH" apt install postgresql'

# Generated at 2022-06-24 07:19:56.504724
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='sudo ifconfig',
                      output=u'sudo: ifconfig: command not found')
    assert get_new_command(command) == "sudo env 'PATH=$PATH' ifconfig"
    # command with option
    command = Command(script='sudo ifconfig -a',
                      output=u'sudo: ifconfig: command not found')
    assert get_new_command(command) == "sudo env 'PATH=$PATH' ifconfig -a"

# Generated at 2022-06-24 07:19:59.346969
# Unit test for function get_new_command
def test_get_new_command():
    command = 'sudo service --status-all'
    output = 'sudo: service: command not found'
    command_name = _get_command_name(Command(command, output))
    assert get_new_command(Command(command, output)) == \
           'env "PATH=$PATH" service --status-all'

# Generated at 2022-06-24 07:20:06.626837
# Unit test for function match
def test_match():

    # Positive test
    command = Command(script='sudo apt-get update',
                      output='sudo: apt-get: command not found')
    assert match(command)

    # Negative test
    command = Command(script='sudo apt-get update',
                      output='Some other output')
    assert not match(command)

    # Negative test
    command = Command(script='apt-get update',
                      output='sudo: apt-get: command not found')
    assert not match(command)


# Generated at 2022-06-24 07:20:09.881245
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo service network restart'
    command = Command(script, u'sudo: service: command not found')
    new_command = get_new_command(command)
    assert new_command == u'env "PATH=$PATH" service network restart'

# Generated at 2022-06-24 07:20:12.687678
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    command = Command('sudo echo')
    command.output = 'sudo: echo: command not found'
    assert 'env "PATH=$PATH" echo' == get_new_command(command)

# Generated at 2022-06-24 07:20:15.318135
# Unit test for function match
def test_match():
    assert match(Command('sudo vim test.py', 'sudo: vim: command not found'))

# Unit tests for function get_new_command

# Generated at 2022-06-24 07:20:18.983461
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo vim', 'sudo: vim: command not found')
    output = get_new_command(command)
    assert output == u'env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:20:21.088584
# Unit test for function get_new_command
def test_get_new_command():
    script = u'sudo apt-get install git'
    new_script = get_new_command(script)
    assert new_script == u'env "PATH=$PATH" apt-get'

# Generated at 2022-06-24 07:20:25.283139
# Unit test for function match
def test_match():
    com1 = u'sudo: nvim: command not found'
    assert match(com1)
    com2 = u'sudo:  nvim: command not found'
    assert not match(com2)


# Generated at 2022-06-24 07:20:27.555018
# Unit test for function get_new_command
def test_get_new_command():
    script = "sudo vim file.txt"
    assert("sudo env \"PATH=$PATH\" vim file.txt" == get_new_command(Command(script, "")))

# Generated at 2022-06-24 07:20:29.913643
# Unit test for function match
def test_match():
    assert not match(Command('sudo echo foo'))
    assert not match(Command('sudo echo sudo: foo: command not found'))
    assert match(Command('sudo bar'))



# Generated at 2022-06-24 07:20:33.116349
# Unit test for function match
def test_match():
    assert match(Command('sudo vi', 'sudo: vi: command not found\n'))
    assert not match(Command('sudo vi', 'sudo: vi: command not found'))
    assert not match(Command('sudo vi', ''))


# Generated at 2022-06-24 07:20:39.251731
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(script_with_command("sudo rm -rf test")).script == u'env "PATH=$PATH" rm -rf test'
    assert get_new_command(script_with_command("sudo apt-get")).script == u'env "PATH=$PATH" apt-get'
    assert get_new_command(script_with_command("sudo -u root apt-get --no-install-recommends apt-get update")).script == u'env "PATH=$PATH" -u root apt-get --no-install-recommends apt-get update'

# Generated at 2022-06-24 07:20:44.861945
# Unit test for function get_new_command
def test_get_new_command():
    # test with an exit command
    com = Command('sudo exit')
    com.output = "sudo: exit: command not found"
    assert get_new_command(com) == "env \"PATH=$PATH\" exit"
    # test with an other command
    com = Command('sudo pwd')
    com.output = "sudo: pwd: command not found"
    assert get_new_command(com) == "env \"PATH=$PATH\" pwd"

# Generated at 2022-06-24 07:20:47.996198
# Unit test for function match
def test_match():
    def is_matched(command):
        return bool(match(Command(command, '')))

    assert is_matched('sudo abc')
    assert not is_matched('abc')


# Generated at 2022-06-24 07:20:53.155502
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo ls -d ./-'
    command = Command(script=script, output='sudo: ls: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" ls -d ./-'


enabled_by_default = True

# Generated at 2022-06-24 07:20:57.541418
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(
        Command('sudo nano', 'sudo: nano: command not found')
        ) == 'env "PATH=$PATH" nano'
    assert get_new_command(
        Command('sudo echo', 'sudo: echo: command not found')
        ) == 'env "PATH=$PATH" echo'

# Generated at 2022-06-24 07:21:01.334560
# Unit test for function match
def test_match():
    assert match(Command('sudo gls', 'sudo: gls: command not found\n'))
    assert not match(Command('sudo dmesg', 'No message buffer'))



# Generated at 2022-06-24 07:21:06.207610
# Unit test for function match
def test_match():
    test_input_1 = 'sudo: git: command not found'
    output_1 = match(Command(script=test_input_1, output=test_input_1))
    assert(output_1 == True)

    test_input_2 = 'sudo: git: command not found'
    output_2 = match(Command(script=test_input_2, output=test_input_2))
    assert(output_2 == '/usr/bin/git')

# Generated at 2022-06-24 07:21:13.188085
# Unit test for function get_new_command
def test_get_new_command():
    command_name = 'sudo'
    command = Command('sudo apt-get update -y', 'sudo: apt-get: command not found')
    assert get_new_command(command) == "env " + "PATH='/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/kenneth/.dotnet:/home/kenneth/.nvm/versions/node/v8.11.3/bin:/home/kenneth/.cargo/bin' " + command_name + " apt-get update -y"

# Generated at 2022-06-24 07:21:15.465512
# Unit test for function get_new_command
def test_get_new_command():
    import thefuck.shells.bash
    shell = thefuck.shells.bash.and_(lambda _: True)
    assert 'env "PATH=$PATH" file' == get_new_command(shell.from_string(
        'sudo file')).script

# Generated at 2022-06-24 07:21:18.578824
# Unit test for function match
def test_match():
    assert match(Command('sudo dpkg', ''))
    assert match(Command('sudo dpkg', 'sudo: dpkg: command not found'))
    assert not match(Command('sudo dpkg', 'grep: command not found'))



# Generated at 2022-06-24 07:21:19.921013
# Unit test for function match
def test_match():
    command='sudo: /usr/bin/top: command not found'
    assert match(command)


# Generated at 2022-06-24 07:21:23.167899
# Unit test for function get_new_command
def test_get_new_command():
    command = "sudo pacman -Qo /usr/lib/libQtWebKit.so.4.8.7"
    new_command = get_new_command(command)
    assert 'env "PATH=$PATH" /usr/bin/pacman -Qo /usr/lib/libQtWebKit.so.4.8.7' == new_command



# Generated at 2022-06-24 07:21:24.902950
# Unit test for function match
def test_match():
    command = "sudo: search: command not found"
    assert match(command)


# Generated at 2022-06-24 07:21:28.417017
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command('sudo apt-get install', 'sudo: apt-get: command not found')
    test_get_new_command = get_new_command(test_command)
    assert test_get_new_command == u'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-24 07:21:30.736580
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo zsh', 'sudo: zsh: command not found\n')
    assert get_new_command(command) == 'env "PATH=$PATH" zsh'

# Generated at 2022-06-24 07:21:32.190144
# Unit test for function match
def test_match():
    command = Command('ls', 'sudo: ls: command not found')
    assert match(command) == True


# Generated at 2022-06-24 07:21:34.851847
# Unit test for function match
def test_match():
    assert_true(match(Command('sudo app-not-installed', '', 'sudo: app-not-installed: command not found')))
    assert_false(match(Command('sudo app-installed', '', 'sudo: app-installed')))



# Generated at 2022-06-24 07:21:36.726078
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo hello')) == 'env "PATH=$PATH" echo hello'

# Generated at 2022-06-24 07:21:39.261640
# Unit test for function match
def test_match():
    command = Command(script="sudo /bin/ls", stderr="sudo: /bin/ls: command not found")
    assert match(command)


# Generated at 2022-06-24 07:21:48.747628
# Unit test for function match
def test_match():
    assert match(Command(script = 'sudo echo', output = 'env: echo: No such file or directory'))
    assert match(Command(script = 'sudo echo', output = 'sudo: echo: command not found'))
    assert not match(Command(script = 'sudo echo', output = 'env: echo: No such file or directory\nsudo: echo: command not found'))
    assert not match(Command(script = 'sudo echo', output = 'env: echo: No such file or directory\nsudo: echo: command not found\nsudo: echo: command not found'))
    assert not match(Command(script = 'sudo echo', output = 'Usage: sudo -h | -K | -V'))


# Generated at 2022-06-24 07:21:51.047192
# Unit test for function match
def test_match():
    command = Command('sudo git',
                      'sudo: git: command not found\nexit status 127')
    assert match(command) is True


# Generated at 2022-06-24 07:21:52.062757
# Unit test for function match
def test_match():
    assert match('sudo ls')


# Generated at 2022-06-24 07:21:54.245897
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo echo "asd"', output='sudo: echo: command not found')) == 'env "PATH=$PATH" echo "asd"'
    assert get_new_command(Command(script='sudo echo "asd"', output='sudo: echo: command not found')) != 'env "PATH=$PATH" echo'


# Generated at 2022-06-24 07:21:56.162024
# Unit test for function match
def test_match():
    command = Command('sudo display', 'sudo: display: command not found')
    assert match(command)



# Generated at 2022-06-24 07:22:01.984095
# Unit test for function match
def test_match():
    command = Command("sudo rz", "sudo: rz: command not found\n")
    assert match(command)
    command = Command("sudo rz2", "sudo: rz2: command not found\n")
    assert not match(command)
    command = Command("sudo rz2", "sudo: rz2: command not found\n")
    assert _get_command_name(command) == "rz2"


# Generated at 2022-06-24 07:22:05.842426
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo cilk', '')) == \
        "env 'PATH=$PATH' cilk"
    assert get_new_command(Command('sudo vim-common', '')) == \
        "env 'PATH=$PATH' vim-common"

# Generated at 2022-06-24 07:22:07.856271
# Unit test for function match
def test_match():
    assert match(Command('sudo gedit',
                         'sudo: gedit: command not found'))
    assert not match(Command('sudo gedit', ''))

# Generated at 2022-06-24 07:22:09.065122
# Unit test for function get_new_command
def test_get_new_command():
    """ This function is tested by `tests/tools/test_sudo.py` """
    pass

# Generated at 2022-06-24 07:22:19.258561
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    from thefuck.types import Command

    command_1 = Command('sudo qwerty',
                        'sudo: qwerty: command not found',
                        'qwerty')
    assert get_new_command(command_1) == 'env "PATH=$PATH" sudo qwerty'

    command_2 = Command('sudo echo qwerty',
                        'sudo: echo: command not found',
                        'echo qwerty')
    assert get_new_command(command_2) == 'env "PATH=$PATH" sudo echo qwerty'

    command_3 = Command('sudo echo $PATH; sudo qwerty',
                        'sudo: qwerty: command not found',
                        'qwerty')

# Generated at 2022-06-24 07:22:20.695355
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo foobar', 'sudo: foobar: command not found')) == u'env "PATH=$PATH" foobar'

# Generated at 2022-06-24 07:22:28.037189
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('su myuser -c "ls"', 'ls: command not found')) == "ls"
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == "sudo env PATH=$PATH ls"
    assert get_new_command(Command('sudo ls', 'sudo: foo_bar: command not found')) == "sudo env PATH=$PATH foo_bar"

# Generated at 2022-06-24 07:22:29.408462
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))


# Generated at 2022-06-24 07:22:30.306577
# Unit test for function match
def test_match():
    # Unit test function match, must return True
    command = Command('sudo abc', 'sudo: abc: command not found')
    assert match(command)


# Generated at 2022-06-24 07:22:34.970497
# Unit test for function get_new_command
def test_get_new_command():
    script = u'sudo env'
    # None if command does not match.
    assert get_new_command(Command(script, 'sudo: env: command not found')) == script

    script = u'sudo env'
    # If sudo: {command}: command not found in output, then returns a new command using env.
    example_output = 'sudo: env: command not found'
    assert get_new_command(Command(script, example_output)) == u'sudo env "PATH=$PATH" env'

# Generated at 2022-06-24 07:22:43.273815
# Unit test for function get_new_command
def test_get_new_command():
    print('Test for function get_new_command')
    # Input command is sudo tty
    # The command is not in the system
    command = Command('sudo tty',
                      'sudo: tty: command not found\n')
    # Command is replaced by env "PATH=$PATH" tty
    assert get_new_command(command) == u'env "PATH=$PATH" tty'
    # Input command is sudo man
    # The command is in the system
    command = Command('sudo man echo',
                      'sudo: man: command not found\n')
    # Command is not replaced
    assert get_new_command(command) == u'sudo man echo'

# Generated at 2022-06-24 07:22:53.415047
# Unit test for function get_new_command
def test_get_new_command():
    script = u'sudo python test.py'

# Generated at 2022-06-24 07:22:59.919007
# Unit test for function get_new_command
def test_get_new_command():
    # Git
    assert 'git commit -m "test"' == \
        get_new_command(Command('sudo git commit -m "test"', 'sudo: git: command not found'))
    # Tmux
    assert 'tmux attach-session -t main' == \
        get_new_command(Command('sudo tmux attach-session -t main', 'sudo: tmux: command not found'))
    # Yarn
    assert 'yarn add global jshint' == \
        get_new_command(Command('sudo yarn add global jshint', 'sudo: yarn: command not found'))

# Generated at 2022-06-24 07:23:03.553740
# Unit test for function match
def test_match():
    assert match(Command('sudo xxx', 'sudo: xxx: command not found'))
    assert match(Command('sudo xxx', 'sudo: yyy: command not found')) is None


# Generated at 2022-06-24 07:23:08.193296
# Unit test for function match
def test_match():
    assert match(Command('sudo this-command-does-not-exist', 'sudo: this-command-does-not-exist: command not found'))
    assert not match(Command('sudo this-command-does-exist', 'sudo: this-command-does-exist: command not found'))


# Generated at 2022-06-24 07:23:10.082855
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls')) == u'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:23:14.099259
# Unit test for function match
def test_match():
    assert match(Command('env "PATH=$PATH" pwd', "sudo: pwd: command not found")) is not None
    assert match(Command('env "PATH=$PATH" ls', "sudo: pwd: command not found")) is None


# Generated at 2022-06-24 07:23:18.071142
# Unit test for function match
def test_match():
    assert match(Command('sudo foobar', stderr='sudo: foobar: command not found\n'))
    assert not match(Command('sudo foobar', stderr='sudo: foobar: command found\n'))


# Generated at 2022-06-24 07:23:19.862897
# Unit test for function match
def test_match():
    assert match(Command('sudo get'))
    assert not match(Command('get'))


# Generated at 2022-06-24 07:23:22.529720
# Unit test for function get_new_command
def test_get_new_command():
    command = "sudo apt-get install libnotify4"
    assert get_new_command(command) == "env \"PATH=$PATH\" sudo apt-get install libnotify4"

priority = 1000
enabled_by_default = True

# Generated at 2022-06-24 07:23:24.528316
# Unit test for function match
def test_match():
    assert match(Command('sudo fuck', 'sudo: fuck: command not found'))
    assert not match(Command('fuck', ''))

# Generated at 2022-06-24 07:23:33.939777
# Unit test for function match
def test_match():
    assert match(Command('sudo echo foo', 'sudo: echo: command not found'))
    assert not match(Command('sudo echo foo', 'sudo: echo: foo'))
    assert match(Command('sudo echo foo', 'sudo: echo: command not found\n'))
    assert match(Command('sudo echo foo', 'sudo: echo: command not found\n'
                         'sudo: echo: command not found\n'))
    assert match(Command('sudo echo foo', 'sudo: echo: command not found\r\n'))
    assert match(Command('sudo echo foo', 'sudo: echo: command not found\r\n'
                         'sudo: echo: command not found\r\n'))


# Generated at 2022-06-24 07:23:37.396137
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    # Test the command
    command = Command('sudo systemctl status postfix', '', '')
    new_command = get_new_command(command)
    assert new_command == u'env "PATH=$PATH" systemctl status postfix'

# Generated at 2022-06-24 07:23:39.246324
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('sudo ls').script == 'env "PATH=$PATH" ls')

# Generated at 2022-06-24 07:23:41.547862
# Unit test for function match
def test_match():
    output='sudo: /usr/bin/vim: command not found'
    assert match(Command('sudo mkdir /etc/test/test1', output))


# Generated at 2022-06-24 07:23:45.078050
# Unit test for function match
def test_match():
    match_from = Command('sudo echo fuck', 'sudo: echo: command not found')
    match_from2 = Command('sudo echo', 'sudo: echo: command not found')
    assert match(match_from) is not None
    assert match(match_from2) is None



# Generated at 2022-06-24 07:23:48.307816
# Unit test for function match
def test_match():
    # Test 1
    outputBad = 'sudo: snap: command not found'
    commandBad = 'sudo snap list'
    assert(match(commandBad, outputBad))
    # Test 2
    outputGood = 'sudo: rmdir: command not found'
    commandGood = 'sudo rmdir /mnt/c'
    assert(not match(commandGood, outputGood))


# Generated at 2022-06-24 07:23:51.332845
# Unit test for function match
def test_match():
    assert match(Command('sudo fhjk', 'sudo: fhjk: command not found'))
    assert not match(Command('sudo ls', ''))


# Generated at 2022-06-24 07:23:57.549083
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('sudo rm /usr/local/bin/fuck', 'sudo: rm: command not found')
        ) == 'env "PATH=$PATH" rm /usr/local/bin/fuck'
    assert get_new_command(
        Command('sudo systemctl restart', 'sudo: systemctl: command not found')
        ) == 'env "PATH=$PATH" systemctl restart'

# Generated at 2022-06-24 07:24:02.909484
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo apt-get instal vim', 'sudo: apt-get: command not found', '/')) == u'env "PATH=$PATH" apt-get instal vim'
    assert get_new_command(Command('sudo apt-get install vim', 'sudo: apt-get: command not found', '/')) == u'env "PATH=$PATH" apt-get install vim'

# Generated at 2022-06-24 07:24:03.809228
# Unit test for function match
def test_match():
    assert match(Command('sudo gem',
                         "sudo: gem: command not found"))

# Generated at 2022-06-24 07:24:04.786829
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'vim: command not found'))


# Generated at 2022-06-24 07:24:08.891157
# Unit test for function match
def test_match():
    assert match(
        Command('sudo apt-get install vim-nox', 'sudo: apt-get: command not found')
    )
    assert not match(
        Command('sudo apt-get install vim-nox', 'sudo: apt-get')
    )


# Generated at 2022-06-24 07:24:12.187087
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
           Command(script='sudo apt-get install x',
                   output='sudo: apt-get: command not found')
    ) == 'env "PATH=$PATH" apt-get install x'

# Generated at 2022-06-24 07:24:15.072427
# Unit test for function match
def test_match():
    assert match(Command('sudo marie',
                         u'sudo: marie: command not found\n'))
    assert not match(Command('sudo marie', ''))


# Generated at 2022-06-24 07:24:17.009612
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("sudo slow").script == 'env "PATH=$PATH" slow'

# Generated at 2022-06-24 07:24:23.605509
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo pacman', 'sudo: pacman: command not found')
    new_command = get_new_command(command)
    assert new_command == 'env "PATH=$PATH" sudo pacman'

    command = Command('sudo pacman -Syu',
                      'sudo: pacman: command not found')
    new_command = get_new_command(command)
    assert new_command == 'env "PATH=$PATH" sudo pacman -Syu'

# Generated at 2022-06-24 07:24:24.459379
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', ''))



# Generated at 2022-06-24 07:24:27.959833
# Unit test for function match
def test_match():
    assert match(Command('sudo echo a',
                         output='sudo: echo: command not found'))
    assert not match(Command('sudo echo a',
                             output='sudo: user: command not found'))
    assert not match(Command('echo a',
                             output='sudo: echo: command not found'))


# Generated at 2022-06-24 07:24:29.696745
# Unit test for function match
def test_match():
    command = Command('sudo pacman', '')
    assert match(command)



# Generated at 2022-06-24 07:24:33.101466
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo foo', 'sudo: foo: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" sudo foo'

# Generated at 2022-06-24 07:24:36.717683
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo sudocy -h', 'sudo: sudocy: command not found')
    assert get_new_command(command) == 'sudo env "PATH=$PATH" sudocy -h'



# Generated at 2022-06-24 07:24:40.172537
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    command = Command('sudo ls', 'sudo: ls: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:24:42.848653
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'sudo: vim: command found'))



# Generated at 2022-06-24 07:24:45.625896
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo xix')
    command.output = 'sudo: xix: command not found'
    assert get_new_command(command) == 'env "PATH=$PATH" xix'

# Generated at 2022-06-24 07:24:49.396212
# Unit test for function match
def test_match():
    # test for invalid command
    output = 'sudo: rmdir: command not found\n'
    command = Command('sudo rmdir *', output)
    assert match(command)

    # test for valid command
    output = 'sudo: rmdir: command not found\n'
    command = Command('rmdir *', output)
    assert not match(command)


# Generated at 2022-06-24 07:24:54.406643
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo gem install rake'
    command = Command(script, 'Sorry, user root is not allowed to execute '
                      '/usr/bin/gem as root on tecmint.\nsudo: gem: command'
                      ' not found\n')
    new_command = get_new_command(command)
    assert(new_command == 'sudo env "PATH=$PATH" gem install rake')

# Generated at 2022-06-24 07:24:58.971772
# Unit test for function match
def test_match():
    assert not match(Command(script='shift', output='command not found'))
    assert match(Command(script='sudo apt-get', output='sudo: apt-get: command not found'))
    assert not match(Command(script='sudo apt-get', output='apt: not found'))



# Generated at 2022-06-24 07:25:01.179355
# Unit test for function match
def test_match():
    assert (match(Command('sudo command',
                          output='sudo: command: command not found'))
            is not None)



# Generated at 2022-06-24 07:25:03.079571
# Unit test for function match
def test_match():
    assert match(Command('sudo javac', 'sudo: javac: command not found'))
    assert not match(Command('sudo apt-get install git', '\n'))



# Generated at 2022-06-24 07:25:04.757527
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo make', 'sudo: make: command not found')
    assert get_new_command(command) == "env 'PATH=$PATH' sudo make"

# Generated at 2022-06-24 07:25:06.428157
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo echo something', 'sudo: echo: command not found')
    assert get_new_command(command) == (
        'env "PATH=$PATH" echo something')

# Generated at 2022-06-24 07:25:08.737249
# Unit test for function get_new_command
def test_get_new_command():
    assert ('env "PATH=$PATH" ls' ==
            get_new_command('sudo ls').script)

# Generated at 2022-06-24 07:25:12.794822
# Unit test for function match
def test_match():
    assert not match(Command('', ''))
    assert not match(Command('sudo pacman', '', ''))
    assert match(Command('sudo yum', '', 'yum: command not found'))



# Generated at 2022-06-24 07:25:15.338030
# Unit test for function match
def test_match():
    assert which('ls') == '/bin/ls'
    command = type('', (), {})
    command.output = 'sudo: ls: command not found'
    assert match(command) == '/bin/ls'


# Generated at 2022-06-24 07:25:18.112849
# Unit test for function match
def test_match():
    f = which('sudo') is not None
    assert match(Command('sudo asdgdg', '')) == f



# Generated at 2022-06-24 07:25:24.299087
# Unit test for function match
def test_match():
    command = Command('sudo dpk',
                      'sudo: dpk: command not found\n')
    assert match(command)

    command = Command('sudo cdf',
                      'sudo: cdf: command not found\n')
    assert match(command)

    command = Command('sudo apt-get',
                      'sudo: apt-get: command not found\n')
    assert not match(command)


# Generated at 2022-06-24 07:25:25.897938
# Unit test for function get_new_command
def test_get_new_command():
    script = Command('sudo test', '')
    assert get_new_command(script) == "sudo env 'PATH=$PATH' test"

# Generated at 2022-06-24 07:25:27.852066
# Unit test for function match
def test_match():
    assert which('git')
    assert match(Command('sudo git', 'sudo: git: command not found'))
    assert not match(Command('sudo git', 'sudo: git: command found'))


# Generated at 2022-06-24 07:25:31.437275
# Unit test for function get_new_command
def test_get_new_command():
    script = "sudo ls"
    output = "sudo: ls: command not found"
    command = Command(script, output)
    assert get_new_command(command) == "env 'PATH=$PATH' sudo ls"

# Generated at 2022-06-24 07:25:40.637379
# Unit test for function match
def test_match():
    assert not match(Command('sudo apt-get install',
                             'E: Could not open lock file /var/lib/dpkg/lock - open (13 Permission denied)\n'
                             'E: Unable to lock the administration directory (/var/lib/dpkg/), are you root?'))
    assert not match(Command('sudo apt-get install', 'E: Invalid operation install'))
    assert match(Command('sudo apt-get install',
                         'sudo: apt-get: command not found\n'
                         'sudo: mv: command not found\n'
                         'sudo: find: command not found\n'
                         'sudo: apt-get: command not found\n'
                         'sudo: rm: command not found'))

# Generated at 2022-06-24 07:25:48.300403
# Unit test for function match
def test_match():
    # Type 'sudp mongod' in shell with mongod installed
    assert which('mongod') == '/usr/local/bin/mongod'
    # Type 'sudp mongod' in shell with mongod not installed
    assert which('mongod') == '/usr/local/bin/mongod'
    # Type 'sudp mongod' in shell with mongod installed
    assert which('mongod') == '/usr/local/bin/mongod'
    # Type 'sudp mongod' in shell with mongod not installed
    assert which('mongod') == '/usr/local/bin/mongod'

# Generated at 2022-06-24 07:25:49.816879
# Unit test for function match
def test_match():
    assert(match(Command('sudo vim', 'sudo: vim: command not found')))
    

# Generated at 2022-06-24 07:25:55.105257
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo env "PATH=$PATH" ls',
                           'sudo: ls: command not found')) == 'ls'
    assert get_new_command(Command('sudo env "PATH=$PATH" ls --all',
                           'sudo: ls: command not found')) == 'ls --all'

# Generated at 2022-06-24 07:25:57.268304
# Unit test for function match
def test_match():
    assert match(Command('sudo ll', 'sudo: ll: command not found'))
    assert not match(Command('ll', 'sudo: ll: command not found'))


# Generated at 2022-06-24 07:26:02.974145
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.main import Command

    def test(script, expected):
        new_command = get_new_command(Command(script, '', 'sudo: foo: command not found'))
        assert new_command == expected

    yield test, 'sudo foo bar baz', 'sudo env "PATH=$PATH" foo bar baz'
    yield test, 'sudo -u root foo bar baz', 'sudo -u root env "PATH=$PATH" foo bar baz'
    yield test, 'sudo env "PATH=$PATH" foo bar baz', 'sudo env "PATH=$PATH" foo bar baz'

# Generated at 2022-06-24 07:26:04.131855
# Unit test for function match
def test_match():
    assert match(Command('sudo echo test', '', '', 0))
    assert not match(Command('echo test', '', '', 0))


# Generated at 2022-06-24 07:26:07.247697
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo foo') == 'env "PATH=$PATH" foo'
    assert get_new_command('sudo -u foo') == 'sudo -u foo'
    assert get_new_command('sudo foo bar') == 'env "PATH=$PATH" foo bar'
    assert get_new_command('sudo foo bar baz') == 'env "PATH=$PATH" foo bar baz'

# Generated at 2022-06-24 07:26:08.935793
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert(get_new_command(Command('sudo vim', 'vim: command not found')) == 'env "PATH=$PATH" vim')

# Generated at 2022-06-24 07:26:10.167930
# Unit test for function match
def test_match():
    assert match(Command('sudo foo'))
    assert not match(Command('foo'))


# Generated at 2022-06-24 07:26:12.948084
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_does_not_work import get_new_command
    from tests.utils import Command

    assert (u'env "PATH=$PATH" echo hello' in
            get_new_command(Command(script=u'sudo echo hello',
                                    output=u'sudo: echo: command not found')))

# Generated at 2022-06-24 07:26:16.860825
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found\n', '', 1))
    assert not match(Command(u'sudo echo', 'sudo: echo: command not found\n', '', 1))
    assert not match(Command(u'ls', 'sudo: echo: command not found\n', '', 1))


# Generated at 2022-06-24 07:26:21.503131
# Unit test for function get_new_command
def test_get_new_command():
    output = 'sudo: command_name: command not found'
    command = type('obj', (object,),
                   {'script': 'sudo command_name', 'output': output})
    assert get_new_command(command) == u'env "PATH=$PATH" command_name'

# Generated at 2022-06-24 07:26:24.092029
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command('sudo vim',
    'sudo: vim: command not found'
    )
    assert get_new_command(command) == 'env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:26:26.948307
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    from thefuck.types import Command
    assert(get_new_command(Command('sudo x', 'sudo: x: command not found')) ==
           'env "PATH=$PATH" x')

# Generated at 2022-06-24 07:26:28.168903
# Unit test for function get_new_command
def test_get_new_command():
    assert 'env "PATH=$PATH" x' == get_new_command('sudo x').script

# Generated at 2022-06-24 07:26:33.462176
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', "sudo: ls: command not found"))
    assert not match(Command('sudo ls', "sudo: command not found"))
    assert not match(Command('sudo ls', "x y z"))


# Generated at 2022-06-24 07:26:36.995287
# Unit test for function match
def test_match():
    output = mock.Mock()
    output.return_value = 'sudo: ag: command not found'
    command = mock.Mock()
    command.script = 'sudo ag'
    command.output = output()

    assert match(command)



# Generated at 2022-06-24 07:26:43.351230
# Unit test for function get_new_command
def test_get_new_command():
    input_output = [
        ('sudo xyz -abc', 'env "PATH=$PATH" xyz -abc'),
        ('sudo xyz "-abc"', 'env "PATH=$PATH" xyz "-abc"'),
        ('sudo xyz --abc', 'env "PATH=$PATH" xyz --abc'),
        ('sudo xyz "--abc"', 'env "PATH=$PATH" xyz "--abc"'),
        ('sudo xyz "ab c"', 'env "PATH=$PATH" xyz "ab c"')
    ]
    test_case(get_new_command, input_output)

# Generated at 2022-06-24 07:26:46.150011
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command(script='sudo ls', output="sudo: ls: command not found")) == u'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:26:49.411878
# Unit test for function match
def test_match():
    assert not match(Command('sudo nmap', ''))
    assert match(Command('sudo nmap', 'sudo: nmap: command not found'))
    assert not match(Command('nmap', ''))


# Generated at 2022-06-24 07:26:50.178040
# Unit test for function match
def test_match():
    assert match(Command('sudo', output='sudo: composer: command not found')) == True


# Generated at 2022-06-24 07:26:53.387689
# Unit test for function match
def test_match():
    assert match(Command('sudo pip', output='sudo: pip: command not found'))
    assert not match(Command('sudo pip', output='Error'))
    assert not match(Command('', output=''))


# Generated at 2022-06-24 07:27:02.504146
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo apt-get install git'
    command = script.split(" ")
    out = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    stdout,stderr = out.communicate()
    output = str(out.returncode) + ' ' + stdout.decode("utf-8") + ' ' + stderr.decode("utf-8")
    command = Command(script, output)
    assert get_new_command(command) == 'sudo env "PATH=$PATH" apt-get install git'

# Generated at 2022-06-24 07:27:04.847777
# Unit test for function match
def test_match():
    assert match(Command("sudo apt-get install",
                         "sudo: apt-get: command not found"))



# Generated at 2022-06-24 07:27:08.758523
# Unit test for function match
def test_match():
    match_output = "sudo: update-rc.d: command not found"
    not_match_output = "sudo: /etc/init.d/nginx: command not found"
    assert match(match_output)
    assert not match(not_match_output)


# Generated at 2022-06-24 07:27:18.689317
# Unit test for function match
def test_match():
    non_matching = [
        Command('sudo ls', ''),
        Command('sudo echo', 'sudo: echo: command not found'),
        Command('sudo ls', 'sudo: no tty present and no askpass program specified.\n'
                           'Could not resolve host: no tty present\n'
                           'Could not resolve host: and\n'
                           'Could not resolve host: no\n'
                           'sudo: no tty present and no askpass program specified\n')
    ]

    for each in non_matching:
        assert not match(each)
    
    # matching
    assert match(Command('sudo vi', 'sudo: vi: command not found'))


# Generated at 2022-06-24 07:27:23.140533
# Unit test for function match
def test_match():
    assert _get_command_name(Command('sudo abc', '')) == 'abc'
    assert not _get_command_name(Command('sudo abc', 'def'))
    assert not match(Command('sudo abc', 'def'))
    assert match(Command('sudo abc', ''))



# Generated at 2022-06-24 07:27:26.621272
# Unit test for function get_new_command
def test_get_new_command():
    command = build_command('sudo echo test')

    # No argument
    assert get_new_command(command) == 'sudo env "PATH=$PATH" echo test'

    # With argument
    assert get_new_command(command) == 'sudo env "PATH=$PATH" echo test'

# Generated at 2022-06-24 07:27:29.896547
# Unit test for function match
def test_match():
    assert match(Command('sudo dnf install'))
    assert match(Command('sudo apt-get install'))
    assert match(Command('sudo brew install'))
    assert not match(Command('sudo which dnf'))

# Generated at 2022-06-24 07:27:40.983925
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    from thefuck.rules.sudo_command_not_found import get_new_command

    # Test 1
    command = Command('sudo sudouser -h',
                      'sudo: sudouser: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" sudouser -h'

    # Test 2
    command = Command('sudo sudouser -h',
                      'sudo: sudouser: command not found\n'
                      'sudouser: command not found\n'
                      'sudo: sudouser: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" sudouser -h'

    # Test 3

# Generated at 2022-06-24 07:27:43.264344
# Unit test for function match
def test_match():
    match(Command('echo 123', 'sudo: dafaf: command not found'))


# Generated at 2022-06-24 07:27:45.181158
# Unit test for function match
def test_match():
    assert match(Command(script = 'sudo foobar', output='sudo: foobar: command not found'))


# Generated at 2022-06-24 07:27:53.180100
# Unit test for function get_new_command
def test_get_new_command():
    script1 = u"sudo /bin/bash"
    output1 = "sudo: /bin/bash: command not found"
    script2 = u"sudo /bin/bash"
    output2 = "/bin/bash: command not found"
    command1 = Command(script1, output1)
    command2 = Command(script1, output2)
    assert(get_new_command(command1)==u"env 'PATH=$PATH' /bin/bash")
    assert(get_new_command(command2)==u"env 'PATH=$PATH' /bin/bash")

# Generated at 2022-06-24 07:27:55.339241
# Unit test for function match
def test_match():
    assert match(Command('sudo foo', 'sudo: foo: command not found\n'))
    assert not match(Command('foo', ''))



# Generated at 2022-06-24 07:27:58.699075
# Unit test for function match
def test_match():
    assert match(Command("sudo gits git status", "Command 'gits' not found, but can be installed with:\n\nsudo apt install git-extras\nsudo apt-get install git-extras\n"))
    assert not match(Command("git status", ""))



# Generated at 2022-06-24 07:28:02.054497
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', stderr='sudo: ls: command not found'))
    assert not match(Command('sudo ls', stderr='sudo: ls: command found'))
    assert not match(Command('sudo ls', stderr='sudo: ls: ommand not found'))


# Generated at 2022-06-24 07:28:05.618175
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo echo "test"',
                                   'sudo: echo: command not found',
                                   '')) == u'env "PATH=$PATH" echo "test"'


enabled_by_default = True