

# Generated at 2022-06-24 07:18:04.060929
# Unit test for function match
def test_match():
    assert match(Command("sudo poweroff", "sudo: poweroff: command not found"))
    

# Generated at 2022-06-24 07:18:07.765806
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo import get_new_command
    command = lambda x: type(
        'Command', (object, ), {'script': x, 'output': 'sudo: command not found'})
    assert get_new_command(command('sudo command')) == 'env "PATH=$PATH" sudo command'

# Generated at 2022-06-24 07:18:11.148582
# Unit test for function get_new_command
def test_get_new_command():

    command = Command('sudo apt-get install vim')
    command.output =  'sudo: apt-get: command not found'
    assert get_new_command(command) == 'env "PATH=$PATH" apt-get install vim'

# Generated at 2022-06-24 07:18:15.371922
# Unit test for function match
def test_match():
    assert not match(Command('echo', 'sudo: command not found'))
    assert match(Command('echo', 'sudo: faker: command not found'))
    assert match(Command('echo', 'sudo: run: command not found'))

# Generated at 2022-06-24 07:18:18.752549
# Unit test for function get_new_command
def test_get_new_command():
    output = 'sudo: sudoedit: command not found'
    command = Command('sudo sudoedit -s /etc/hosts', output)
    assert get_new_command(command) == 'env "PATH=$PATH" sudoedit -s /etc/hosts'

# Generated at 2022-06-24 07:18:22.023878
# Unit test for function match
def test_match():
    assert match(Command('sudo gedit', ''))
    assert match(Command('sudo gedit', 'sudo: gedit: command not found'))
    assert not match(Command('sudo gedit', 'gedit: command not found'))



# Generated at 2022-06-24 07:18:23.926066
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo make', 'sudo: make: command not found')) == 'env "PATH=$PATH" make'

# Generated at 2022-06-24 07:18:27.114818
# Unit test for function match
def test_match():
    """Check if command can be matched"""
    assert match(Command('sudo apt-get install', ''))
    assert not match(Command('echo test', ''))



# Generated at 2022-06-24 07:18:28.915708
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo aptitude update')=='sudo env "PATH=$PATH" aptitude update'

# Generated at 2022-06-24 07:18:34.057488
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', '', 'sudo: ls: command not found'))
    assert match(Command('sudo cd', '', 'sudo: cd: command not found'))
    assert not match(Command('sudo --version', '', ''))
    assert not match(Command('sudo -h', '', ''))
    assert not match(Command('sudo', '', ''))


# Generated at 2022-06-24 07:18:36.294452
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('sudo test', 'sudo: test: command not found'))
    assert result == 'env "PATH=$PATH" test'

# Generated at 2022-06-24 07:18:44.036352
# Unit test for function match
def test_match():
    from thefuck.rules.sudo_env_path import match

    assert(
        match(
            Command('sudo ls', 'sudo: ls: command not found')) is not None)
    assert(
        match(
            Command('sudo ls', 'sudo: notfound: command not found')) is None)
    assert(
        match(
            Command('sudo touch temp.txt', 'sudo: touch: command not found'))
        is not None)
    assert(
        match(
            Command('sudo touch temp.txt',
                    'sudo: ls: command not found\nsudo: touch: command not '
                    'found')) is not None)


# Unittest for function get_new_command

# Generated at 2022-06-24 07:18:48.241569
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo import get_new_command
    output = 'sudo: jk: command not found'
    command = 'jk'
    assert get_new_command(Command(command, output)) == 'env "PATH=$PATH" jk'


enabled_by_default = True

# Generated at 2022-06-24 07:18:52.216985
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo ifconfig'
    output = 'sudo: ifconfig: command not found'
    assert get_new_command(Command(script, '', output)) == 'sudo env "PATH=$PATH" ifconfig'


enabled_by_default = True

# Generated at 2022-06-24 07:18:54.685564
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('ls', ''))
    assert not match(Command('sudo ls', ''))


# Generated at 2022-06-24 07:18:58.565273
# Unit test for function match
def test_match():
    assert not match(Command('ls', ''))
    assert match(Command('sudo scp',
                         u'sudo: scp: command not found\n'))
    assert not match(Command('ls', 'lss: command not found'))



# Generated at 2022-06-24 07:19:00.328549
# Unit test for function match
def test_match():
    assert match(Command('sudo cat file.txt', ''))


# Generated at 2022-06-24 07:19:05.518992
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    from thefuck.types import Command

    # For file /etc/sudoers.d/admin containing "username ALL=(ALL) NOPASSWD: ALL"
    assert get_new_command(Command(script='sudo pip',
                                   output='sudo: pip: command not found')) == 'sudo env "PATH=$PATH" pip'

# Generated at 2022-06-24 07:19:07.995533
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo foo', 'sudo: foo: command not found')) == 'env "PATH=$PATH" foo'

# Generated at 2022-06-24 07:19:11.648765
# Unit test for function match
def test_match():
    assert match(Command('sudo htop', 'zsh: command not found: apk')) is None
    assert match(Command('sudo apt', 'sudo: apt: command not found'))


# Generated at 2022-06-24 07:19:15.406727
# Unit test for function match
def test_match():
    # Test case where output of sudo is 'sudo: command not found'
    assert not match(Command('sudo', 'sudo: command not found'))

    # Test case where output of sudo is 'sudo: git: command not found'
    assert match(Command('sudo', 'sudo: git: command not found')).script == 'env "PATH=$PATH" git'



# Generated at 2022-06-24 07:19:17.057317
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('ls', ''))

# Generated at 2022-06-24 07:19:21.033424
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo vi /etc/profile', 'sudo: vi: command not found')
    assert get_new_command(command) == "env 'PATH=$PATH' vi /etc/profile"
    command = Command('sudo ls', 'sudo: ls: command not found')
    assert get_new_command(command) == "env 'PATH=$PATH' ls"


# Generated at 2022-06-24 07:19:28.747551
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo echo ') == 'sudo echo '
    assert get_new_command('sudo echo HELLO') == 'sudo echo HELLO'
    assert get_new_command('sudo scp') == 'sudo env "PATH=$PATH" scp'
    assert get_new_command('sudo echo $PATH') == 'sudo echo $PATH'
    assert get_new_command('sudo git status') == 'sudo env "PATH=$PATH" git status'
    assert get_new_command('sudo ssh') == 'sudo env "PATH=$PATH" ssh'

# Generated at 2022-06-24 07:19:31.153517
# Unit test for function match
def test_match():
    assert not match(Command('sudo apt-get install vim', '', '', '', ''))
    assert match(Command('sudo vim', '', 'sudo: vim: command not found', '', ''))



# Generated at 2022-06-24 07:19:34.267190
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("sudo su", "sudo: su: command not found")
    assert get_new_command(command) == 'sudo env "PATH=$PATH" su'

# Generated at 2022-06-24 07:19:37.501095
# Unit test for function match
def test_match():
    assert which('ls')
    assert not match(Command('sudo ls', ''))
    assert match(Command('sudo asd',
                         'sudo: asd: command not found'))



# Generated at 2022-06-24 07:19:39.311616
# Unit test for function match
def test_match():
    assert match(Command('test', 'sudo: test: command not found')) == None
    assert match(Command('test', 'test')) == which('test')

# Generated at 2022-06-24 07:19:44.661458
# Unit test for function match
def test_match():
    # The result of 'which' is None
    assert not match(Command('sudo echo 1', '', ''))

    # The result of which is not None
    assert match(Command('sudo echo_1', 'sudo: echo_1: command not found', ''))
    assert match(Command('sudo echo_1', 'sudo: echo_1: command not found 1', ''))

# Unit test case for function get_new_command

# Generated at 2022-06-24 07:19:46.561823
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo some_command',
                'sudo: some_command: command not found')) == \
                'env "PATH=$PATH" some_command'

# Generated at 2022-06-24 07:19:51.834018
# Unit test for function match
def test_match():
    assert match(Command('sudo echo "thefuck"', 'sudo: echo: command not found'))
    assert not match(Command('git commit', 'git: command not found'))
    assert not match(Command('echo "thefuck"', 'env: echo: No such file or directory'))
    assert not match(Command('echo "thefuck"', 'env: echo: No such file or directory', 'sudo'))


# Generated at 2022-06-24 07:19:53.767892
# Unit test for function get_new_command
def test_get_new_command():
    example = Command('sudo fortune', 'sudo: fortune: command not found')
    assert get_new_command(example) == 'env "PATH=$PATH" fortune'

# Generated at 2022-06-24 07:19:55.834191
# Unit test for function match
def test_match():
    assert match(Command('sudo echo', '')) is None
    assert match(Command('sudo echo', 'sudo: echo: command not found\n')) is not None


# Generated at 2022-06-24 07:19:58.007726
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="sudo not_in_path",
                                   output="sudo: not_in_path: command not found")) == "env \"PATH=$PATH\" not_in_path"

# Generated at 2022-06-24 07:19:58.597918
# Unit test for function match
def test_match():
    asse

# Generated at 2022-06-24 07:20:04.910806
# Unit test for function match
def test_match():
    assert match(Command('sudo ifconfig',
                    output='sudo: ifconfig: command not found'))

    assert match(Command('sudo echo sudo echo',
                    output='sudo: echo: command not found'))
    assert match(Command('sudo echo sudo echo',
                    output='sudo: echo: command not found'))

    assert not match(Command('sudo ping',
                    output='sudo: ping: command not found'))

# Generated at 2022-06-24 07:20:11.569199
# Unit test for function match
def test_match():
    command = Command('sudo apt-get update', 'sudo: apt-get: command not found')
    assert match(command) == which('apt-get')

    command = Command('sudo apt update', 'sudo: apt: command not found')
    assert match(command) == which('apt')

    command = Command('sudo vim /etc/sudoers', 'sudo: vim: command not found')
    assert match(command) == which('vim')

    assert match(Command('apt update', '')) is None

# Generated at 2022-06-24 07:20:14.380392
# Unit test for function match
def test_match():
    assert match(Command("sudo ls -al", "sudo: ls: command not found"))
    assert not match(Command("sudo ls -al", "sudo: 1: command not found"))


# Generated at 2022-06-24 07:20:18.027805
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("sudo upstart scriptname", "sudo: upstart: command not found")).script == 'env "PATH=$PATH" upstart scriptname'

# Generated at 2022-06-24 07:20:20.005265
# Unit test for function match
def test_match():
    assert match(Command('sudo xxx no_such_command', ''))
    assert not match(Command('sudo ls /', ''))


# Generated at 2022-06-24 07:20:29.243266
# Unit test for function match
def test_match():
    assert match(Command('sudo command', '')) is None
    assert match(Command('sudo command', 'sudo: command: command not found')) \
        is not None
    assert _get_command_name(Command('sudo command',
                                     'sudo: command: command not found'))\
        == 'command'
    assert match(Command('sudo command command2',
                         'sudo: command: command not found')) is None
    assert match(Command('sudo command',
                         'sudo: command: command not found\n')) is None
    assert match(Command('sudo command',
                         'sudo: command: command not found\nsudo: command2: '
                         'command not found')) is None


# Generated at 2022-06-24 07:20:31.034595
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('sudo vim', 'sudo: vim: command not found'))



# Generated at 2022-06-24 07:20:32.314405
# Unit test for function match
def test_match():
    assert match(Command('sudo echo hello')) == False



# Generated at 2022-06-24 07:20:32.799446
# Unit test for function get_new_command
def test_get_new_command():
    pass

# Generated at 2022-06-24 07:20:33.258483
# Unit test for function match

# Generated at 2022-06-24 07:20:35.070183
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo lshw', 'sudo: lshw: command not found')) == "env 'PATH=$PATH' lshw"

# Generated at 2022-06-24 07:20:36.830778
# Unit test for function match
def test_match():
    f = which('ls')
    cmd = Command('sudo ls', 'sudo: ls: command not found')
    assert(match(cmd) == f)



# Generated at 2022-06-24 07:20:38.671833
# Unit test for function match
def test_match():
    command = 'sudo: route: command not found'
    assert match(command)


# Generated at 2022-06-24 07:20:40.688802
# Unit test for function get_new_command
def test_get_new_command():
    assert 'env "PATH=$PATH" sudo' \
        == get_new_command(Command('sudo', 'sudo: command not found'))
    assert 'env "PATH=$PATH" echo' \
        == get_new_command(Command('sudo echo', 'sudo: echo: command not found'))

# Generated at 2022-06-24 07:20:47.817273
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('sudo test', 'sudo: test: command not found')) == u'env "PATH=$PATH" test')
    assert (get_new_command(Command('sudo test -s', 'sudo: test: command not found')) == u'env "PATH=$PATH" test -s')
    assert (get_new_command(Command('sudo test -s --m', 'sudo: test: command not found')) == u'env "PATH=$PATH" test -s --m')
    assert (get_new_command(Command('sudo test -- -s', 'sudo: test: command not found')) == u'env "PATH=$PATH" test -- -s')


# Generated at 2022-06-24 07:20:51.539241
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("sudo ls", "sudo: ls: command not found")
    assert get_new_command(command) == "env 'PATH=$PATH' ls"

# Generated at 2022-06-24 07:20:54.826118
# Unit test for function match
def test_match():
    output = 'sudo: reboot: command not found'
    assert match(Command(script='sudo reboot', output=output))

    output = 'Command not found'
    assert not match(Command(script='sudo reboot', output=output))



# Generated at 2022-06-24 07:20:57.683266
# Unit test for function match
def test_match():
    command = Command('sudo vim', 'sudo: vim: command not found')
    assert match(command)
    assert not match(Command('vim', 'vim: command not found'))


# Generated at 2022-06-24 07:20:59.638335
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo pacman -Syu')) == 'env "PATH=$PATH" pacman -Syu'

# Generated at 2022-06-24 07:21:02.141186
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo google-chrome', 'sudo: google-chrome: command not found')) == \
        'env "PATH=$PATH" google-chrome'

# Generated at 2022-06-24 07:21:04.717217
# Unit test for function match
def test_match():
    assert not match(Command('sudo vim-voom', ''))
    assert match(Command('sudo vim-voom', 'sudo: vim-voom: command not found\n'))


# Generated at 2022-06-24 07:21:07.808949
# Unit test for function get_new_command
def test_get_new_command():
    output = u'sudo: sudoedit: command not found'
    script = u'sudo su'
    assert get_new_command(Command(script, output)) == u'env "PATH=$PATH" sudoedit su'

# Generated at 2022-06-24 07:21:11.211631
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo garble', '')) == 'env "PATH=$PATH" garble'
    assert get_new_command(Command('sudo garble --debug', '')) == 'env "PATH=$PATH" garble --debug'

# Generated at 2022-06-24 07:21:13.704232
# Unit test for function get_new_command
def test_get_new_command():
    res = get_new_command(Command('sudo not_existing_command -p asdf', '', 'sudo: not_existing_command: command not found\n'))
    assert res == 'env "PATH=$PATH" not_existing_command -p asdf'

# Generated at 2022-06-24 07:21:15.944788
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo test'), 'test') == u'sudo env "PATH=$PATH" test'
    assert get_new_command(Command('sudo test')).script == u'sudo env "PATH=$PATH" test'

# Generated at 2022-06-24 07:21:17.043548
# Unit test for function match
def test_match():
    assert match(Command('sudo ll', 'sudo: ll: command not found'))



# Generated at 2022-06-24 07:21:21.965907
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install xfce4',
                         '', 'sudo: xfce4: command not found'))
    assert not match(Command('sudo apt-get install xfce4',
                             '', 'E: Command line option --configure is not understood in combination with the other options provided.'))
    assert not match(Command('sudo apt-get install xfce4',
                             '', 'E: Unable to locate package xfce4'))



# Generated at 2022-06-24 07:21:26.436541
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', output='sudo: ls: command not found')) == u'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo python test.py', output='sudo: python: command not found')) == u'env "PATH=$PATH" python test.py'

# Generated at 2022-06-24 07:21:30.035399
# Unit test for function match
def test_match():
    # Test for not match
    assert not match(Command('sudo ABC'))

    # Test for match
    sudo_command = Command('sudo unzip')
    sudo_command.output = 'sudo: unzip: command not found'
    assert match(sudo_command)


# Generated at 2022-06-24 07:21:32.493685
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("sudo thefuck", 'sudo: thefuck: command not found')
    new_command = get_new_command(command)
    assert new_command == 'env "PATH=$PATH" thefuck'

# Generated at 2022-06-24 07:21:38.040393
# Unit test for function match
def test_match():
	out1 = u'sudo: /usr/local/bin/npm: command not found'
	out2 = u'sudo: /usr/local/bin/npm: No such file or directory'
	out3 = u'sudo: /usr/local/bin/pip: command not found'
	out4 = u'sudo: /usr/local/bin/pip: No such file or directory'
	out5 = u'Something else'
	assert match(Command('', out1))
	assert match(Command('', out2))
	assert not match(Command('', out4))
	assert not match(Command('', out5))


# Generated at 2022-06-24 07:21:40.708742
# Unit test for function match
def test_match():
    assert match(Command('sudo not_found', 'sudo: not_found: command not found\n'))

if which('command_not_found'):
    enabled_by_default = True
else:
    enabled_by_default = False

# Generated at 2022-06-24 07:21:45.515166
# Unit test for function match
def test_match():
    # Should match if sudo command is not found
    assert match(Command('sudo ls', 'sudo: ls: command not found'))

    # Should not match if sudo command is found
    assert not match(Command('sudo ls', ''))

    # Should not match if sudo produces unexpected output
    assert not match(Command('sudo ls', 'moo'))

# Generated at 2022-06-24 07:21:48.420854
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo', '')) == 'env "PATH=$PATH" echo'
    assert get_new_command(Command('echo', '')) == 'echo'

# Generated at 2022-06-24 07:21:49.892972
# Unit test for function match
def test_match():
    assert match(Command('sudo random-command', ''))


# Generated at 2022-06-24 07:21:51.582454
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo echo', 'sudo: echo: command not found')
    assert get_new_command(command) == u'env "PATH=$PATH" echo'


# Generated at 2022-06-24 07:21:54.530807
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo ls') == u'sudo env "PATH=$PATH" ls'
    assert get_new_command('sudo echo "ll"') == u'sudo env "PATH=$PATH" echo "ll"'

# Generated at 2022-06-24 07:21:56.536963
# Unit test for function match
def test_match():
    assert match(Command('sudo test', 'sudo: test: command not found'))


# Generated at 2022-06-24 07:21:58.597743
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo ttydecode').script == "env 'PATH=$PATH' ttydecode"

# Generated at 2022-06-24 07:22:00.002361
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('')==''


# Generated at 2022-06-24 07:22:03.204349
# Unit test for function match
def test_match():
    command = Command('sudo pip list', 'sudo: pip: command not found')
    assert match(command)
    command = Command('sudo pip list', 'zsh: command not found: sudo')
    assert not match(command)


# Generated at 2022-06-24 07:22:05.937367
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls',
                                   'sudo: ls: command not found', '')) \
        == 'env "PATH=$PATH" sudo ls'

# Generated at 2022-06-24 07:22:10.765017
# Unit test for function match
def test_match():
    assert match(Command('sudo sdo', ''))
    assert not match(Command('sudo sdo', 'sdo: command not found'))
    assert not match(Command("sudo -u alex airmon-ng", 'sudo: airmon-ng: command not found'))
    assert match(Command("sudo -u alex airmon-ng", 'sudo: airmon-ng: command not found\nRun `man sudo` for more information.'))


# Generated at 2022-06-24 07:22:19.292881
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('sudo test', 'sudo: test: command not found', '')) == 'env "PATH=$PATH" test')
    assert(get_new_command(Command('sudo sudo', 'sudo: sudo: command not found', '')) == 'env "PATH=$PATH" sudo')
    assert(get_new_command(Command('sudo sudo', 'sudo: sudo: command not found', '')) == 'env "PATH=$PATH" sudo')
    assert(get_new_command(Command('sudo ls -a | sudo wc -l', 'sudo: ls -a | sudo wc -l: command not found', '')) == 'env "PATH=$PATH" ls -a | env "PATH=$PATH" wc -l')

# Generated at 2022-06-24 07:22:20.512030
# Unit test for function match
def test_match():
    assert match(Command('sudo su', 'sudo: su: command not found'))


# Generated at 2022-06-24 07:22:25.672584
# Unit test for function match
def test_match():
    assert which('sudo')
    assert not match(Command('sudo non_existing_command', ''))
    assert match(Command('sudo non_existing_command', 'sudo: non_existing_command: command not found\n'))


# Generated at 2022-06-24 07:22:30.282043
# Unit test for function match
def test_match():
    assert match(Command('sudo fgrep "foo bar" file.txt', ''))
    assert not match(Command('sudo fgrep "foo bar" file.txt', '',
                             'sudo: fgrep: command not found'))
    assert not match(Command('fgrep "foo bar" file.txt', '', ''))

# Generated at 2022-06-24 07:22:34.629765
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo xyz', 'sudo: xyz: command not found')).script == 'env "PATH=$PATH" xyz'
    assert get_new_command(Command('sudo xyz -l', 'sudo: xyz: command not found')).script == 'env "PATH=$PATH" xyz -l'

# Generated at 2022-06-24 07:22:39.073752
# Unit test for function match
def test_match():
    assert match(Command('sudo apra',
                         'sudo: apra: command not found',
                         stderr=True))

    assert not match(Command('apra',
                             'sudo: apra: command not found',
                             stderr=True))


# Generated at 2022-06-24 07:22:40.805587
# Unit test for function match
def test_match():
    assert match(Command('sudo ls /etc', '', 'sudo: ls: command not found'))



# Generated at 2022-06-24 07:22:45.487081
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo nmap') == 'sudo env "PATH=$PATH" nmap'
    assert get_new_command('sudo docker build -t docker-registry.tools.wmflabs.org/test/test-image .') == 'sudo env "PATH=$PATH" docker build -t docker-registry.tools.wmflabs.org/test/test-image .'

# Generated at 2022-06-24 07:22:50.526467
# Unit test for function get_new_command
def test_get_new_command():
    script_name = "sudo"
    command_name = "sudo"
    output_message = "sudo: {}: command not found".format(command_name)
    command = Command('sudo ipconfig', output_message)

    new_command = get_new_command(command)

    assert('env "PATH=$PATH"' in new_command)

# Generated at 2022-06-24 07:22:53.377621
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command = Command('sudo ping')
    command.output = 'sudo: ping: command not found'
    assert get_new_command(command) == 'env "PATH=$PATH" ping'

# Generated at 2022-06-24 07:22:56.456386
# Unit test for function get_new_command
def test_get_new_command():
    command_input = Command("sudo ping", "sudo: ping: command not found")
    assert get_new_command(command_input).script == u'env "PATH=$PATH" ping'

# Generated at 2022-06-24 07:22:57.545812
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', ''))


# Generated at 2022-06-24 07:23:00.940031
# Unit test for function match
def test_match():
    assert match(Command('sudo gedit test.py',
                         "sudo: gedit: command not found"))
    assert not match(Command('sudo gedit test.py',
                             "sudo: correct"))



# Generated at 2022-06-24 07:23:04.494385
# Unit test for function match
def test_match():
    output = 'sudo: test_match: command not found'
    assert match(Command('sudo test_match', output))
    assert not match(Command('sudo test_match', 'No such file or directory'))


# Generated at 2022-06-24 07:23:06.897745
# Unit test for function match
def test_match():
    assert which('sudo')
    assert match('sudo vim')
    assert not match('sudo')
    assert not match('fake_command')


# Generated at 2022-06-24 07:23:09.099949
# Unit test for function get_new_command
def test_get_new_command():
    return_value = get_new_command(command)
    assert return_value == u'sudo env "PATH=$PATH" vim'

    return_value = get_new_command(command)
    assert return_value == u'sudo env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:23:12.858314
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo lola', 'sudo: lola: command not found'))

# Generated at 2022-06-24 07:23:15.699594
# Unit test for function match
def test_match():
    assert match(Command('sudo emacs study.txt',
                         'sudo: emacs: command not found'))
    assert not match(Command('sudo emacs study.txt', 'Permission denied'))


# Generated at 2022-06-24 07:23:19.034622
# Unit test for function match
def test_match():
    assert match(Command('sudo mkdir test',
        "sudo: mkdir: command not found"))
    assert not match(Command('sudo mkdir test', ''))
    assert not match(Command('sudo vim /etc/file',''))


# Generated at 2022-06-24 07:23:22.092614
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', ''))
    assert not match(Command('sudo ls', 'sudo: /usr/bin/ls: No such file or directory'))


# Generated at 2022-06-24 07:23:23.659907
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo install', 'sudo: install: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" install'

# Generated at 2022-06-24 07:23:25.551539
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo foo', 'sudo: foo: command not found')) == 'env "PATH=$PATH" foo'

# Generated at 2022-06-24 07:23:28.062406
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == u'sudo env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:23:32.273535
# Unit test for function match
def test_match():
    assert match(Command('sudo env', ''))
    assert match(Command('sudo echo', ''))
    assert not match(Command('sudo -H echo', ''))
    assert not match(Command('echo', ''))


# Generated at 2022-06-24 07:23:33.785033
# Unit test for function match
def test_match():
    assert for_app('sudo')(lambda command: match(command) is not None)


# Generated at 2022-06-24 07:23:37.776740
# Unit test for function match
def test_match():
    match1 = Command('sudo apt-get install vim', "sudo: apt-get: command not found")
    assert match(match1)
    match2 = Command('sudo apt-get install vim', "sudo: apt-get: command not found\nsudo: vim: command not found")
    assert not match(match2)

# Generated at 2022-06-24 07:23:41.178728
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_path import get_new_command
    assert get_new_command(Command('sudo la', 'sudo: la: command not found\n')) == 'env "PATH=$PATH" la'


# Generated at 2022-06-24 07:23:42.733024
# Unit test for function match
def test_match():
    assert match(Command('ls dummy', "sudo: ls: command not found\n"))


# Generated at 2022-06-24 07:23:47.672952
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'sudo: abc: command not found')).__class__ is Command
    assert match(Command('sudo abc', 'sudo: abc: command')).__class__ is None
    assert _get_command_name(Command('sudo abc', 'sudo: abc: command not found')) == 'abc'


# Generated at 2022-06-24 07:23:50.799232
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo lily', 'sudo: lily: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" lily'

# Generated at 2022-06-24 07:23:52.274844
# Unit test for function get_new_command
def test_get_new_command():
    command = "sudo: /Users/jdoe/bin/brew: command not found"
    assert get_new_command(command) == "env \"PATH=$PATH\" /Users/jdoe/bin/brew"

# Generated at 2022-06-24 07:23:55.948259
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    assert get_new_command(Command('sudo hello', 
            'sudo: hello: command not found')) == 'env "PATH=$PATH" hello'

# Generated at 2022-06-24 07:23:59.098842
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.main import Command
    command = Command("sudo k3b", "k3b: command not found")
    assert get_new_command(command) == u'sudo env "PATH=$PATH" k3b'

# Generated at 2022-06-24 07:24:02.034856
# Unit test for function match
def test_match():
    command = Command('sudo xxx', 'sudo: xxx: command not found\n')
    assert match(command)
    command = Command('ls | xargs sudo', 'sudo: xargs: command not found\n')
    assert not match(command)


# Generated at 2022-06-24 07:24:03.405356
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', ''))
    assert match(Command('sudo lss', ''))


# Generated at 2022-06-24 07:24:04.169725
# Unit test for function match
def test_match():
    command = Command('sudo sudo', 'sudo: sudo: command not found')
    assert match(command)


# Generated at 2022-06-24 07:24:06.121476
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo ls -l', output='sudo: ls: command not found')).script == 'env "PATH=$PATH" ls -l'
    assert get_new_command(Command(script='sudo apt-get install lol', output='sudo: apt-get: command not found')).script == 'env "PATH=$PATH" apt-get install lol'

# Generated at 2022-06-24 07:24:09.440497
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo', 'ls /root', 'sudo: ls: command not found', '')) == 'env "PATH=$PATH" ls /root'



# Generated at 2022-06-24 07:24:13.565438
# Unit test for function match
def test_match():
    assert not match(Command('echo foo', ''))
    assert match(Command('echo foo', 'sudo: echo: command not found'))
    assert not match(Command('echo foo', 'ls: command not found'))
    assert match(Command('echo foo', 'ls: not found'))


# Generated at 2022-06-24 07:24:17.385025
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo thefuck', 'sudo: thefuck: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" thefuck'

# Generated at 2022-06-24 07:24:20.456116
# Unit test for function match
def test_match():
    command = Command('sudo sud')
    assert not match(command)
    command = Command('sudo sud', 'sudo: sud: command not found')
    assert match(command)


# Generated at 2022-06-24 07:24:25.734748
# Unit test for function match
def test_match():
    """Test match function"""
    from thefuck.rules.env_sudo import match
    from thefuck.types import Command

    # should match
    command = Command('sudo cat file',
                      'sudo: cat: command not found',
                      '')

    assert match(command)

    # should not match
    command = Command('sudo cat file',
                      '',
                      '')

    assert not match(command)


# Generated at 2022-06-24 07:24:31.670326
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    # test for command script with various path separator in the PATH
    # check whether the PATH is updated properly
    assert get_new_command(Command('sudo abc', 'sudo: abc: command not found\n', None)) == 'env "PATH=.:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/opt/X11/bin" abc'
    assert get_new_command(Command('sudo abc', 'sudo: abc: command not found\n', None, '$PATH')) == 'env "PATH=$PATH:.:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/opt/X11/bin" abc'

# Generated at 2022-06-24 07:24:35.276732
# Unit test for function match
def test_match():
    assert which('sudo')
    assert match(Command('sudo echo hello', 'sudo: echo: command not found',
                         'echo hello'))
    assert not match(Command('echo hello', 'echo hello'))


# Generated at 2022-06-24 07:24:36.832810
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vi test.txt', 'sudo: vi: command not found')) == 'env "PATH=$PATH" vi test.txt'

# Generated at 2022-06-24 07:24:41.596665
# Unit test for function get_new_command
def test_get_new_command():
    from collections import namedtuple
    Command = namedtuple('Command', 'script output')
    assert get_new_command(Command(script='sudo vi /etc/hosts',
                                   output='sudo: vi: command not found')) == 'sudo env "PATH=$PATH" vi /etc/hosts'

# Generated at 2022-06-24 07:24:43.227001
# Unit test for function match
def test_match():
    assert match(Command(script='sudo apt-get update'))



# Generated at 2022-06-24 07:24:44.736416
# Unit test for function match
def test_match():
    assert match(Command('sudo vim hello.txt', 'sudo: vim: command not found'))



# Generated at 2022-06-24 07:24:47.441075
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'output': "sudo: sudoedit: command not found", 'script': 'sudo sudoedit'})
    assert get_new_command(command) == "env PATH=$PATH sudoedit"

# Generated at 2022-06-24 07:24:50.111756
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo foo',
                                   'sudo: foo: command not found')) == 'env "PATH=$PATH" foo'

# Generated at 2022-06-24 07:24:56.159385
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', output='sudo: abc: command not found')) is True
    assert match(Command('sudo abc', output='sudo: abc: something else')) is False
    # test command is not found
    assert match(Command('abc', output='abc: command not found')) is False
    # test match for multiple different programs
    assert match(Command('abc sudo def', output='sudo: def: command not found')) is True


# Generated at 2022-06-24 07:24:57.846097
# Unit test for function match
def test_match():
    assert match(Command('sudo emacs', 'sudo: emacs: command not found'))
    asser

# Generated at 2022-06-24 07:25:00.307350
# Unit test for function match
def test_match():
    assert match(Command('sudo pacman', output='sudo: pacman: command not found'))


# Generated at 2022-06-24 07:25:05.414712
# Unit test for function match
def test_match():
    assert match(Command('sudo echo hello', 'sudo: echo: command not found', ''))
    assert match(Command('sudo apt-get install nautilus', 'sudo: apt-get: command not found', ''))
    assert not match(Command('sudo ls -laF', '', ''))
    assert not match(Command('sudo -k apt-get install nautilus', 'sudo: no tty present and no askpass program specified', ''))

# Generated at 2022-06-24 07:25:06.709658
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', ''))
    assert not match(Command('apt-get update', ''))



# Generated at 2022-06-24 07:25:09.110521
# Unit test for function match
def test_match():
    assert match(Command('sudo echo lol', ''))
    assert not match(Command('echo lol', ''))



# Generated at 2022-06-24 07:25:12.581745
# Unit test for function match
def test_match():
    assert match(Command('sudo echo', '', 'sudo: echo: command not found'))
    assert not match(Command('sudo apt-get install git', '', 'do it'))

# Generated at 2022-06-24 07:25:15.309212
# Unit test for function match
def test_match():
    message = 'sudo: nfe: command not found'
    assert match(Command('nfe', message))
    assert not match(Command('ls', ''))
    assert not match(Command('ls', 'sudo: nfe: command not found'))



# Generated at 2022-06-24 07:25:16.699862
# Unit test for function match
def test_match():
    assert match(Command('sudo hello', ''))


# Generated at 2022-06-24 07:25:18.746742
# Unit test for function match
def test_match():
    command = Command('sudo apt-get update', 'sudo: apt-get: command not found')
    assert match(command)


# Generated at 2022-06-24 07:25:21.449498
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import shell
    assert get_new_command(shell.and_('sudo ls foo', 'sudo: ls: command not found', '')) == u'env "PATH=$PATH" ls foo'

# Generated at 2022-06-24 07:25:22.889678
# Unit test for function match
def test_match():
    assert match(Command('sudo ls /'))
    assert not match(Command('ls /'))


# Generated at 2022-06-24 07:25:25.487864
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('sudo foo',
                                    'sudo: foo: command not found\n')) ==
            'sudo env "PATH=$PATH" foo')

# Generated at 2022-06-24 07:25:26.485701
# Unit test for function match
def test_match():
    assert match(Command('sudo', 'echo $PATH', ''))


# Generated at 2022-06-24 07:25:28.139358
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(u'sudo test', u'sudo: test: command not found')
    assert get_new_command(command) == u'env "PATH=$PATH" test'

# Generated at 2022-06-24 07:25:30.756145
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', '', ''))
    assert not match(Command('sudo vim', '', 'command not found'))



# Generated at 2022-06-24 07:25:34.846156
# Unit test for function match
def test_match():
    assert match(Command('run_app not_found', '')) == None
    assert match(Command('sudo run_app', 'sudo: run_app: command not found')) == True
    assert match(Command('sudo run_app', 'sudo: run_app: command found')) == None


# Generated at 2022-06-24 07:25:37.342678
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo lolsh',
                                  'sudo: lolsh: command not found')) == 'sudo env "PATH=$PATH" lolsh'


enabled_by_default = True

# Generated at 2022-06-24 07:25:41.340848
# Unit test for function match
def test_match():
    assert match(Command("sudo add-apt-repository ppa:k-s-a/kde-plasma-testing",
        "sudo: add-apt-repository: command not found\n"))
    assert not match(Command("sudo add-apt-repository ppa:k-s-a/kde-plasma-testing",
        "", ""))


# Generated at 2022-06-24 07:25:44.125708
# Unit test for function get_new_command
def test_get_new_command():
    script = Script('sudo apt-get update', 'sudo: apt-get: command not found')
    assert str(get_new_command(script)) == 'env "PATH=$PATH" apt-get update'

# Generated at 2022-06-24 07:25:45.562419
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', '')) == False
    assert match(Command('sudo abc', 'sudo: abc: command not found')) == True

# Generated at 2022-06-24 07:25:46.904914
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim', '')) == 'env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:25:49.281459
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo cat /etc/passwd', 'sudo: cat: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" cat /etc/passwd'


enabled_by_default = True

# Generated at 2022-06-24 07:25:53.597870
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.tests.utils import Command

    assert get_new_command(Command('echo hi ; sudo ls ; echo ho'))
    assert get_new_command(Command('sudo abc')) == 'sudo env "PATH=$PATH" abc'

# Generated at 2022-06-24 07:25:57.098947
# Unit test for function match
def test_match():
    assert match(Command('sudo asdf', 'sudo: asdf: command not found'))
    assert match(Command('sudo  asdf', 'sudo:  asdf: command not found'))
    assert match(Command('sudo asdf', 'sudo: asdf: command nope')) is None

# Generated at 2022-06-24 07:26:02.233735
# Unit test for function match
def test_match():
    command = Command('sudo apt-get install python3-pip',
		      output='sudo: apt-get: command not found')
    assert match(command)
    command = Command('sudo apt-get install python3-pip',
		      output='sudo: apt-get: command not found, who cares?')
    assert not match(command)
    command = Command('echo "echo success"', output='echo success')
    assert not match(command)


# Generated at 2022-06-24 07:26:03.777761
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo python app.py'
    command = Command(script, 'sudo: python: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" python app.py'

# Generated at 2022-06-24 07:26:05.555151
# Unit test for function match
def test_match():
    command = Command(script='sudo apt-get install git',
                      output='[sudo] password for spk: sudo: apt-get: command not found')
    assert match(command)


# Generated at 2022-06-24 07:26:08.626177
# Unit test for function get_new_command
def test_get_new_command():
    assert 'env "PATH=$PATH" ls' == get_new_command('sudo ls').script
    assert 'env "PATH=$PATH" rm -rf file' in get_new_command('sudo rm -rf file').script

# Generated at 2022-06-24 07:26:11.899510
# Unit test for function match
def test_match():
    assert match(Command('sudo ran',
                         'sudo: ran: command not found'))
    assert not match(Command('sudo ran', 'this is output of command ran'))
    assert not match(Command('ran', 'sudo: ran: command not found'))

# Generated at 2022-06-24 07:26:18.367538
# Unit test for function match
def test_match():
    command = Command('sudo ls', 'sudo: ls: command not found')
    assert match(command)
    command = Command('sudo', 'sudo: ls: command not found')
    assert match(command)
    command = Command('sud', 'sud: ls: command not found')
    assert not match(command)
    command = Command('sudo', 'sudo: ls: not found')
    assert not match(command)



# Generated at 2022-06-24 07:26:21.269960
# Unit test for function match
def test_match():
    assert match("sudo: hello: command not found")
    assert not match("su: hello: command not found")


# Generated at 2022-06-24 07:26:24.797472
# Unit test for function match
def test_match():
    assert match(Command('sudo nothing', 'sudo: nothing: command not found'))
    assert not match(Command('sudo nothing', ''))
    assert not match(Command('sudo nothing', 'sudo: something: command not found'))
    assert not match(Command('nothing', 'sudo: nothing: command not found'))


# Generated at 2022-06-24 07:26:30.767789
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command('sudo uname', '')) \
           == 'env "PATH=$PATH" uname'
    assert get_new_command(Command('sudo pwd', '')) \
           == 'env "PATH=$PATH" pwd'
    assert get_new_command(Command('sudo ls', '')) \
           == 'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:26:33.841404
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo foo', '',
                                   'sudo: foo: command not found')) == 'env "PATH=$PATH" sudo foo'

# Generated at 2022-06-24 07:26:37.392534
# Unit test for function match
def test_match():
    assert not match(Command('sudo ls', stderr='foo'))
    assert match(Command('sudo ls', stderr='sudo: ls: command not found'))
    assert match(Command('sudo ls', stderr='sudo: ls: command not found'))


# Generated at 2022-06-24 07:26:45.409338
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ifconfig', 'sudo: ifconfig: command not found')) == u'env "PATH=$PATH" ifconfig'
    assert get_new_command(Command('sudo ls -lah', 'sudo: ls: command not found')) == u'env "PATH=$PATH" ls -lah'
    assert get_new_command(Command('sudo foo -bar', 'sudo: foo: command not found')) == u'env "PATH=$PATH" foo -bar'
    assert get_new_command(Command('sudo env PATH=foo bar', 'sudo: bar: command not found')) == u'env "PATH=foo" bar'


# Generated at 2022-06-24 07:26:47.095451
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim', 'sudo: apt-get: command not found'))


# Generated at 2022-06-24 07:26:49.983290
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('sudo fuck', 'fuck: command not found')) == "env 'PATH=$PATH' fuck"

# Generated at 2022-06-24 07:26:56.681600
# Unit test for function match
def test_match():
    assert not match(Command('sudo yum'))
    assert not match(Command('sudo yum', ''))
    assert not match(Command('sudo yum', '', stderr='sudo: yum: command not found',
                             error_code=1))
    assert match(Command('sudo yum', '', stderr='sudo: yum: command not found',
                             error_code=1))

# Generated at 2022-06-24 07:26:59.099962
# Unit test for function match
def test_match():
    assert match(Command('test', stderr='sudo: sudo: command not found'))



# Generated at 2022-06-24 07:27:02.559714
# Unit test for function match
def test_match():
    assert match(Command('sudo sds', None, "sudo: sds: command not found"))
    assert not match(Command('sudo -l', None, 'Needed arguments: user command'))


# Generated at 2022-06-24 07:27:05.457664
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install vim', "sudo: apt-get: command not found\n")) == 'env "PATH=$PATH" sudo apt-get install vim'

# Generated at 2022-06-24 07:27:10.438051
# Unit test for function match
def test_match():
    assert match(Command(script='sudo ls',
                         stderr='sudo: ls: command not found'))
    assert not match(Command(script='ls',
                             stderr='sudo: ls: command not found'))
    assert not match(Command(script='sudo ls',
                             stderr='ls: command not found'))


# Generated at 2022-06-24 07:27:14.395518
# Unit test for function get_new_command
def test_get_new_command():
    pass_command = Command('sudo chmod 777 test.txt', '', '')
    return_command = get_new_command(pass_command)
    assert return_command == 'env "PATH=$PATH" chmod 777 test.txt'


# Generated at 2022-06-24 07:27:16.541747
# Unit test for function match
def test_match():
    assert match(Command('sudo git', None))
    assert not match(Command('sudo ls', None))



# Generated at 2022-06-24 07:27:19.707372
# Unit test for function match
def test_match():
    assert match(Command('sudo test', ''))
    assert not match(Command('test', ''))
    assert not match(Command('test', 'sudo: test: command not found'))


# Generated at 2022-06-24 07:27:21.837582
# Unit test for function match
def test_match():
    assert match('sudo ls -l foo') == False
    assert match('sudo: ls: command not found') == which('ls')



# Generated at 2022-06-24 07:27:27.282092
# Unit test for function match
def test_match():
    assert match(Command('sudo foo', 'sudo: foo: command not found'))
    assert match(Command('sudo foo --bar', 'sudo: foo: command not found'))
    assert match(Command('sudo foo --bar baz', 'sudo: foo: command not found'))
    assert match(Command('sudo foo --bar=baz', 'sudo: foo: command not found'))
    assert not match(Command('sudo foo --bar baz', ''))
    assert not match(Command('sudo env "PATH=$PATH" foo', ''))


# Generated at 2022-06-24 07:27:33.224153
# Unit test for function match
def test_match():
    assert(match('sudo iptabls -v') == which('iptabls'))
    assert(match('sudo iptabls -v') != which('ls'))
    assert(match('sudo iptabls -v') != which('sudo'))
    assert(match('sudo iptabls -v') != which('g++'))
    assert(match('sudo iptabls -v') != which('clear'))
    assert(match('sudo iptabls -v') != which('cat'))
    assert(match('sudo iptabls -v') != which('pwd'))
    assert(match('sudo iptabls -v') != which('cp'))
    assert(match('sudo iptabls -v') != which('mkdir'))


# Generated at 2022-06-24 07:27:35.321747
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo rm foo').script == 'env "PATH=$PATH" rm foo'

# Generated at 2022-06-24 07:27:37.798095
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo ls', '')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:27:40.180664
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo apt-get install git')
    assert get_new_command(command) == 'sudo env "PATH=$PATH" apt-get install git'

# Generated at 2022-06-24 07:27:43.323891
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found\nsudo: pwd: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:27:46.024611
# Unit test for function match
def test_match():
    assert match(Command('sudo mikh', 'sudo: mikh: command not found'))
    assert not match(Command('sudo mikh', ''))



# Generated at 2022-06-24 07:27:52.812362
# Unit test for function match
def test_match():
    # test for no sudo output
    assert match(Command('ls', '')) is None

    # test for no command not found in output
    assert match(Command('sudo apt-get install', 'no such package')) is None

    # test for command not found in output
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert _get_command_name(Command('sudo ls', 'sudo: ls: command not found')) == 'ls'



# Generated at 2022-06-24 07:27:54.727568
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get', 'sudo: apt-get'))


# Generated at 2022-06-24 07:27:57.726834
# Unit test for function match
def test_match():
    assert match(Command('sudo pacman -Syu',
                         'sudo: pacman: command not found')) == which('pacman')
    assert match(Command('sudo pacman -Syu',
                         'sudo: pacman: aaaaaaa')) is None

# Generated at 2022-06-24 07:28:05.238356
# Unit test for function get_new_command