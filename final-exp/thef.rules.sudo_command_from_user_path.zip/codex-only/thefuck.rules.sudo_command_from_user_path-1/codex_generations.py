

# Generated at 2022-06-24 07:18:07.249638
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo import get_new_command
    command = Command('sudo echo test',
                      'sudo: echo: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" echo test'

# Generated at 2022-06-24 07:18:08.808050
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo echo test').script == 'env "PATH=$PATH" echo test'

# Generated at 2022-06-24 07:18:11.966071
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    command = Command('sudo vim /etc/hosts', 'sudo: vim: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" vim /etc/hosts'

# Generated at 2022-06-24 07:18:15.373682
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo python file.py').script == u'python file.py'
    assert get_new_command('sudo rm file').script == u'rm file'

# Generated at 2022-06-24 07:18:17.735637
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))



# Generated at 2022-06-24 07:18:19.426138
# Unit test for function match
def test_match():
    command = Command("sudo ll", "sudo: ll: command not found")
    assert match(command)



# Generated at 2022-06-24 07:18:23.686453
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', '')) == False
    assert _get_command_name(Command('sudo apt update', 'sudo: apt: command not found')) == 'apt'
    assert match(Command('sudo apt update', 'sudo: apt: command not found')) == '/usr/bin/apt'


# Generated at 2022-06-24 07:18:34.862765
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim test.txt', 'sudo: vim: command not found\n')) == 'env "PATH=$PATH" vim test.txt'
    assert get_new_command(Command('sudo vimtest.txt', 'sudo: vimtest.txt: command not found\n')) == 'env "PATH=$PATH" vimtest.txt'
    assert get_new_command(Command('sudo ls test.txt', 'sudo: ls: command not found\n')) == 'env "PATH=$PATH" ls test.txt'
    assert get_new_command(Command('sudo ls   test.txt', 'sudo: ls: command not found\n')) == 'env "PATH=$PATH" ls   test.txt'

# Generated at 2022-06-24 07:18:36.205978
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo ls').script == 'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:18:37.862522
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))



# Generated at 2022-06-24 07:18:39.965795
# Unit test for function get_new_command
def test_get_new_command():
    command = 'sudo git status'
    assert get_new_command(Command(script='sudo git status')) == u'env "PATH=$PATH" git status'

# Generated at 2022-06-24 07:18:41.614839
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', ''))
    assert not match(Command('ls', ''))

# Generated at 2022-06-24 07:18:45.997557
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo ls') == 'env "PATH=$PATH" ls'
    assert get_new_command('sudo -s ls') == 'env "PATH=$PATH" ls'
    assert get_new_command('sudo git config') == 'env "PATH=$PATH" git config'
    assert get_new_command('sudo  git config') == 'env "PATH=$PATH"  git config'


# Generated at 2022-06-24 07:18:50.257885
# Unit test for function match
def test_match():
    assert match(Command('sudo rm -fr test',
                         'sudo: rm: command not found\n'))
    assert not match(Command('rm -fr test', 'rm: command not found\n'))


# Generated at 2022-06-24 07:18:52.351726
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update'))
    assert not match(Command('apt-get update'))



# Generated at 2022-06-24 07:18:54.800310
# Unit test for function match
def test_match():
    assert (match(Command('sudo noexist', 'sudo: noexist: command not found')))
    assert (not match(Command('cd', 'sudo: cd: command not found')))


# Generated at 2022-06-24 07:18:57.353104
# Unit test for function match
def test_match():
    assert match(Command("sudo rm -rf /this/that", "", "sudo: rm: command not found"))
    assert not match(Command("sudo rm -rf /this/that", "", ""))


# Generated at 2022-06-24 07:19:01.647024
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    new_command = get_new_command(Command('sudo git status',
                                          'sudo: git: command not found',
                                          ''))
    assert new_command == 'env "PATH=$PATH" git status'

# Generated at 2022-06-24 07:19:04.431725
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("sudo test.py file1 file2 file3 file4", "test.py file1 file2 file3 file4") == "env \"PATH=$PATH\" test.py file1 file2 file3 file4"

# Generated at 2022-06-24 07:19:07.480118
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('sudo htop', 'sudo: htop: command not found')) == u'env "PATH=$PATH" htop'

# Generated at 2022-06-24 07:19:09.717983
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'sudo: vim: command not not found'))


# Generated at 2022-06-24 07:19:18.560298
# Unit test for function get_new_command
def test_get_new_command():
    # First the test cases with single arguments
    assert get_new_command(Command('sudo ls')).script == 'sudo env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo -u user ls')).script == 'sudo -u user env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo --user user ls')).script == 'sudo --user user env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo ls -l')).script == 'sudo env "PATH=$PATH" ls -l'
    assert get_new_command(Command('sudo -l ls')).script == 'sudo -l env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo -l ls -l')).script == 'sudo -l env "PATH=$PATH" ls -l'

# Generated at 2022-06-24 07:19:20.640188
# Unit test for function match
def test_match():
    assert not match(Command('ls', ''))
    assert match(Command('sudo ls', 'sudo: ls: command not found'))


# Generated at 2022-06-24 07:19:28.849325
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get update', 'sudo: apt-get: command not found')) == 'env \"PATH=$PATH\" apt-get update'
    assert get_new_command(Command('sudo apt-get update', 'sudo: apt-get: command not found\nfoo')) == 'env \"PATH=$PATH\" apt-get update'
    assert get_new_command(Command('sudo apt-get update', 'sudo: apt-get: command not found\nsudo: foo: command not found')) == 'env \"PATH=$PATH\" apt-get update'

# Generated at 2022-06-24 07:19:31.719060
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo hello world',
                                   "sudo: echo: command not found\n")) == "env 'PATH=$PATH' echo hello world"

# Generated at 2022-06-24 07:19:41.501090
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo import get_new_command

    command = Command('sudo cal 2018',
                      'sudo: cal: command not found')
    assert get_new_command(command) == \
           u'env "PATH=$PATH" cal 2018'

    command = Command('sudo -E cal 2018',
                      'sudo: cal: command not found')
    assert get_new_command(command) == \
           u'env "PATH=$PATH" -E cal 2018'

    command = Command('sudo -E cal 2018',
                      'sudo: cal: command not found')
    assert get_new_command(command) == \
           u'env "PATH=$PATH" -E cal 2018'

# Generated at 2022-06-24 07:19:47.041481
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import shell
    assert get_new_command(shell.and_('sudo test', 'sudo: test: command not found')) == 'sudo env "PATH=$PATH" test'
    assert get_new_command(shell.and_('sudo vim test', 'sudo: vim: command not found')) == 'sudo env "PATH=$PATH" vim test'
    assert get_new_command(shell.and_('sudo env "PATH=$PATH" vim test', 'sudo: env PATH=$PATH vim: command not found')) == 'sudo env "PATH=$PATH" vim test'



# Generated at 2022-06-24 07:19:55.497496
# Unit test for function match
def test_match():
    """Test the function match."""
    from thefuck.shells import Bash
    from thefuck.types import Command

    # If the command does not contain 'command not found',
    # then return False for match.
    assert not match(Command('sudo ls -al', '', Bash()))

    # If the command does not contain sudo,
    # then return False for match.
    assert not match(Command('ls -al', 'sudo: ls: command not found', Bash()))

    # If the command contains 'sudo' and 'command not found'
    # and the command exist in $PATH,
    # then return True for match.
    assert match(Command('sudo ls -al', 'sudo: ls: command not found', Bash()))



# Generated at 2022-06-24 07:19:56.938668
# Unit test for function match
def test_match():
    assert match(Command('sudo notfound', 'sudo: notfound: command not found'))


# Generated at 2022-06-24 07:19:59.010188
# Unit test for function match
def test_match():
    assert match(Command(script = 'sudo python', output = 'sudo: python: command not found'))
    assert not match(Command(script = 'sudo python', output = 'sudo: python'))

# Generated at 2022-06-24 07:20:03.333452
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command(script='sudo ls -l', output='sudo: ls: command not found')
    assert get_new_command(command) == u'env "PATH=$PATH" sudo ls -l'

# Generated at 2022-06-24 07:20:06.848374
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'sudo apt-get install git', 'output': 'sudo: apt-get: command not found'})
    assert get_new_command(command) == u'env "PATH=$PATH" apt-get install git'

# Generated at 2022-06-24 07:20:11.244067
# Unit test for function match
def test_match():
    assert match(Command('sudo command', 'sudo: command: command not found'))
    assert match(Command('sudo blabla', 'sudo: blabla: command not found'))
    assert not match(Command('sudo which', 'sudo which', ''))
    assert not match(Command('foo', '', ''))


# Generated at 2022-06-24 07:20:14.180276
# Unit test for function match
def test_match():
    assert match(Command('sudo apt update',
                u'sudo: apt: command not found\n'))
    assert not match(Command('sudo apt update',
                u'sudo: apt: command not found\n'))

# Generated at 2022-06-24 07:20:17.512722
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo ls', 'sudo: ls: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:20:20.420460
# Unit test for function get_new_command
def test_get_new_command():
    assert which('ls')
    assert 'command not found' in check_output(['sudo', 'ls'],
                                               stderr=STDOUT)
    assert get_new_command(Command('sudo ls', '')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:20:23.454046
# Unit test for function get_new_command
def test_get_new_command():
    assert 'env "PATH=$PATH" git commit' == get_new_command('sudo git commit')

# Generated at 2022-06-24 07:20:25.150167
# Unit test for function match
def test_match():
    command = Command('sudo ifconfig', None)
    assert match(command)



# Generated at 2022-06-24 07:20:26.384788
# Unit test for function match
def test_match():
    assert match(Command(script='sudo: ls: command not found'))


# Generated at 2022-06-24 07:20:28.589536
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command('sudo fc-cache -f -v')
    assert new_command == u'env "PATH=$PATH" fc-cache -f -v'

# Generated at 2022-06-24 07:20:30.490218
# Unit test for function get_new_command
def test_get_new_command():
    assert u'sudo env "PATH=$PATH" git' == get_new_command(Command('sudo git', 'sudo: git: command not found'))

# Generated at 2022-06-24 07:20:33.084753
# Unit test for function get_new_command
def test_get_new_command():
    output = "sudo: pip: command not found"
    command = Command(script='sudo pip install thefuck', output=output)
    assert get_new_command(command) == "env \"PATH=$PATH\" pip install thefuck"

# Generated at 2022-06-24 07:20:38.932049
# Unit test for function match
def test_match():
	# test for check that 'sudo' was used as command
    assert match(Command('sudo ag --color=always', '', 'sudo: ag: command not found'))
    assert not match(Command('ag --color=always', '', 'sudo: ag: command not found'))
    
	# test for check that the error message is correct
    assert match(Command('sudo apt-get', '', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get', '', 'sudo: apt-get: command found'))
    
    assert match(Command('sudo ls', '', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', '', 'sudo: ls: command found'))


# Generated at 2022-06-24 07:20:42.706974
# Unit test for function get_new_command
def test_get_new_command():
    script = u'sudo ls -l -a'
    command = Command(script, u'sudo: command not found\n')
    assert get_new_command(command) == u'env "PATH=$PATH" sudo ls -l -a'

# Generated at 2022-06-24 07:20:47.951155
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo omg',
                                   'sudo: omg: command not found')) == \
                                   u'env "PATH=$PATH" omg'

    assert get_new_command(Command('sudo yolo',
                                   'sudo: yolo: command not found')) == \
                                   u'env "PATH=$PATH" yolo'

# Generated at 2022-06-24 07:20:51.584548
# Unit test for function match
def test_match():
    assert match(Command('sudo lskdf', 'sudo: lskdf: command not found'))
    assert not match(Command('ls', ''))

# Generated at 2022-06-24 07:20:53.899831
# Unit test for function match
def test_match():
    assert match(Command('sudo apachectl', 'sudo: apachectl: command not found\n'))
    assert not match(Command('sudo apachectl', 'sudo: apachectl: command not found'))


# Generated at 2022-06-24 07:20:58.692098
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo mumen', 'sudo: mumen: command not found')) \
        == u'env "PATH=$PATH" mumen'
    assert get_new_command(Command('sudo mumen', 'sudo: /bin/mumen: command not found')) \
        == u'env "PATH=$PATH" /bin/mumen'

# Generated at 2022-06-24 07:21:01.583370
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install thefuck',
                                   'sudo: apt-get: command not found')) == u'env "PATH=$PATH" apt-get install thefuck'

# Generated at 2022-06-24 07:21:03.595985
# Unit test for function match
def test_match():
    assert match(Command('sudo command', '', 'sudo: command: command not found'))
    assert not match(Command('sudo command', ''))

# Generated at 2022-06-24 07:21:05.802704
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo lol', 'sudo: lol: command not found')) == 'env "PATH=$PATH" lol'

# Generated at 2022-06-24 07:21:11.647881
# Unit test for function get_new_command
def test_get_new_command():
    # Test1: command_name should be not None
    command = Command('sudo ls /var', stderr='sudo: ls: command not found')
    assert get_new_command(command) == u'env "PATH=$PATH" sudo ls /var'
    # Test2: command_name should be None
    command = Command('sudo ls /var', stderr='sudo: command not found')
    assert get_new_command(command) is None

# Generated at 2022-06-24 07:21:13.375799
# Unit test for function match
def test_match():
    assert match(Command('sudo xxxx', 'sudo: xxxx: command not found'))


# Generated at 2022-06-24 07:21:15.642472
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get', '', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', '', ''))


# Generated at 2022-06-24 07:21:19.067445
# Unit test for function match
def test_match():
    assert match(Command('sudo xyz', output='sudo: xyz: command not found'))
    assert not match(Command('sudo xyz', output='command not found'))
    assert not match(Command('xyz', output='command not found'))


# Generated at 2022-06-24 07:21:21.054651
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command = Command('sudo xxx', 'sudo: xxx: command not found')

    assert get_new_command(command) == 'env "PATH=$PATH" xxx'

# Generated at 2022-06-24 07:21:27.452673
# Unit test for function get_new_command
def test_get_new_command():
  command = Command('sudo abc')
  command.output = "sudo: abc: command not found"
  assert get_new_command(command) == 'env "PATH=$PATH" sudo abc'

  command = Command('sudo abc')
  command.output = "sudo: abc: command not found \n sudo: def: command not found"
  assert get_new_command(command) == 'env "PATH=$PATH" sudo abc'

# Generated at 2022-06-24 07:21:30.781594
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo ls').script == 'sudo env "PATH=$PATH" ls'
    assert get_new_command('sudo apt-get install vim').script == 'sudo env "PATH=$PATH" apt-get install vim'

# Generated at 2022-06-24 07:21:36.276681
# Unit test for function get_new_command
def test_get_new_command():
    command_test = Command(
        script='sudo apt-get install',
        output='sudo: apt-get: command not found',
        env={}
    )
    assert get_new_command(command=command_test) == u'env "PATH=$PATH" apt-get install'



# Generated at 2022-06-24 07:21:46.579311
# Unit test for function match
def test_match():
    assert match(Command('sudo whoami', '')) is None
    assert match(Command('sudo whoami')) is None
    assert match(Command(
        'sudo search --update',
        'sudo: search: command not found')) is None
    # sudo: /etc/sudoers is mode 0777, should be 0440
    assert match(
        Command('sudo search --update',
                'sudo: /etc/sudoers is mode 0777, should be 0440')) is None
    assert match(Command(
        'sudo search --update',
        'sudo: search: command not found\n'
        'sudo: /etc/sudoers is mode 0777, should be 0440')) is None
    assert match(Command('sudo search --update',
                         'sudo: search: command not found\n')) is None
    assert _get_command

# Generated at 2022-06-24 07:21:49.062672
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo', 'foo', 'sudo: foo: command not found')) == 'env "PATH=$PATH" foo'

# Generated at 2022-06-24 07:21:51.519560
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Shell
    assert get_new_command(Shell('sudo apt-get install', 'sudo: apt-get: command not found', '', 
        '', '', '', '', '')) == u'env "PATH=$PATH" apt-get install'



# Generated at 2022-06-24 07:21:55.274081
# Unit test for function get_new_command
def test_get_new_command():
    ret = get_new_command(Command(script='sudo gedit'))
    assert ret.script == 'sudo env "PATH=$PATH" gedit'
    assert ret.env == {'PATH': '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin'}
    ret = get_new_command(Command(script='sudo /some/other/path/gedit'))
    assert ret.script == 'sudo env "PATH=$PATH" /some/other/path/gedit'

# Generated at 2022-06-24 07:21:59.824819
# Unit test for function match
def test_match():
    command = Command('sudo apt-get install testtest',
                      'sudo: testtest: command not found')
    assert match(command)
    command = Command('sudo apt-get install testtest',
                      'sudo: command not found')
    assert not match(command)


# Generated at 2022-06-24 07:22:02.555189
# Unit test for function match
def test_match():
    assert match(Command('sudo asd', '', 'sudo: asd: command not found'))
    assert match(Command('sudo asd', '', 'sudo: asd: command not found'))


# Generated at 2022-06-24 07:22:05.277927
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vi',
                                   'sudo: vi: command not found', '')) ==\
        u'env "PATH=$PATH" sudo vi'

# Generated at 2022-06-24 07:22:09.025893
# Unit test for function match
def test_match():
    # Tests that match returns TRUE when there is a command not found.
    assert match(Command('sudo echo foo',
                         'sudo: echo: command not found\n'))

    # Tests that match returns FALSE when there is no command not found.
    assert not match(Command('sudo echo foo', ''))



# Generated at 2022-06-24 07:22:12.128224
# Unit test for function match
def test_match():
    command = Command('sudo echo foo', u'sudo: echo: command not found')
    assert not match(command)

    command = Command('sudo no_such_command -no_such_param',
                      u'sudo: no_such_command: command not found')
    assert which('no_such_command')
    assert match(command)



# Generated at 2022-06-24 07:22:14.464967
# Unit test for function match
def test_match():
    command = Command('sudo chomod', '', 'ls: command not found')
    assert match(command)


# Generated at 2022-06-24 07:22:18.846670
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="sudo echo Hello World", output="sudo: echo: command not found")
    assert (get_new_command(command) == "sudo env \"PATH=$PATH\" echo Hello World")

# Generated at 2022-06-24 07:22:20.512178
# Unit test for function match
def test_match():
    assert match(Command(script='sudo ls /root/',
                         output='sudo: ls: command not found'))


# Generated at 2022-06-24 07:22:25.326669
# Unit test for function get_new_command
def test_get_new_command():
    c = Command('sudo lssd',
                u'sudo: lssd: command not found\n')
    assert get_new_command(c) == 'env "PATH=$PATH" sudo lssd'

# Generated at 2022-06-24 07:22:29.558095
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo apt-get update'
    command = type('Command', (object,), {'script': script})
    output = 'sudo: apt-get: command not found'
    command.output = output
    assert get_new_command(command) == u'env "PATH=$PATH" sudo apt-get update'

# Generated at 2022-06-24 07:22:36.406261
# Unit test for function match
def test_match():
    assert match(Command('$ sudo git push origin master', '$ sudo: git: command not found'))
    assert match(Command('$ sudo git push origin master', '$ sudo: git: command not found', '/bin/bash'))
    assert not match(Command('$ sudo git push origin master', '$ sudo: git: command not found', '/bin/foo'))
    assert not match(Command('$ sudo git push origin master', 'git: command not found'))
    assert not match(Command('$ ls', '$ sudo: git: command not found', '/bin/bash'))
    assert not match(Command('$', '$ sudo: git: command not found', '/bin/bash'))
    assert not match(Command('$ sudo', '$ sudo: git: command not found', '/bin/bash'))

# Generated at 2022-06-24 07:22:39.224616
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo xyz', "sudo: echo: command not found")) == u'env "PATH=$PATH" echo xyz'

# Generated at 2022-06-24 07:22:42.011679
# Unit test for function match
def test_match():
    assert match(Command('sudo apt', 'sudo: apt: command not found\n'))
    assert match(Command('sudo apt-get myapp', 'sudo: apt-get: command not found\n'))


# Generated at 2022-06-24 07:22:44.699100
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = "sudo apt-get install 'foo'", output = "sudo: apt-get: command not found")
    assert get_new_command(command) == "sudo env 'PATH=$PATH' apt-get install 'foo'"

# Generated at 2022-06-24 07:22:47.251042
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', output='sudo: ls: command not found'))
    assert not match(Command('sudo ls'))



# Generated at 2022-06-24 07:22:50.238773
# Unit test for function match
def test_match():
    assert match(Command('sudo ll', 'sudo: ll: command not found'))
    assert not match(Command('sudo ll', 'sudo: ll: command found'))

# Generated at 2022-06-24 07:22:51.684251
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_comman

# Generated at 2022-06-24 07:22:55.658075
# Unit test for function match
def test_match():
    # case of error
    stderr = u'sudo: apt-get: command not found\n'
    # case of no error
    stderr1 = u'sudo: apt-get: no passwd entry for user "atget"\n'
    assert(match(Command('apt-get install', stderr=stderr)) != None)
    assert(match(Command('apt-get install', stderr=stderr1)) == None)


# Generated at 2022-06-24 07:22:58.864109
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('sudo tic', 'sudo: tic: command not found')) == u'env "PATH=$PATH" tic'
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == u'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:23:02.044182
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', output='sudo: ls: command not found')) == 'env "PATH=$PATH" ls'


# Generated at 2022-06-24 07:23:04.979601
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(
        'zsh', 'sudo: rsync: command not found\n')) == ('env "PATH=$PATH" zsh')

# Generated at 2022-06-24 07:23:09.521953
# Unit test for function match
def test_match():
    assert not match(Command('sudo rmdir /tmp/dir', ''))
    assert not match(Command('sudo rmdir /tmp/dir', '', stderr=''))
    assert match(Command('sudo rmdir /tmp/dir', 'sudo: rmdir: command not found'))



# Generated at 2022-06-24 07:23:11.624369
# Unit test for function match
def test_match():
    assert match(Command('sudo yay'))
    assert not match(Command('sudo ls'))

# Generated at 2022-06-24 07:23:14.173211
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo cp /tmp/foo /tmp/bar') == 'env "PATH=$PATH" cp /tmp/foo /tmp/bar'


enabled_by_default = True

# Generated at 2022-06-24 07:23:16.592826
# Unit test for function get_new_command
def test_get_new_command():
    assert 'env "PATH=$PATH" python3' == get_new_command(Command(script='sudo python3', output='sudo: python3: command not found'))


# Generated at 2022-06-24 07:23:18.410947
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == u'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:23:24.896401
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Posix, Bash
    assert get_new_command(Posix('sudo update-alternatives --config editor',
                                 'sudo: update-alternatives: command not found')) == \
                           'env "PATH=$PATH" update-alternatives --config editor'
    assert get_new_command(Bash('sudo update-alternatives --config editor',
                                'bash: sudo: command not found')) == \
                           'env "PATH=$PATH" sudo update-alternatives --config editor'


# Generated at 2022-06-24 07:23:26.785246
# Unit test for function match
def test_match():
    assert match(Command('sudo zypper'))
    assert not match(Command('ls'))


# Generated at 2022-06-24 07:23:33.312550
# Unit test for function match
def test_match():
    """The output for which is different for different OS.
       So I am doing this here in the unit test and not in the match function
       since it is easier here to mock the dev/null and get the output directly"""
    from mock import patch
    with patch('os.devnull', new='/dev/null'):
        assert match(Command('sudo sud', 'sudo: sud: command not found'))

# Unit tests for function get_new_command

# Generated at 2022-06-24 07:23:35.718025
# Unit test for function match
def test_match():
    assert match(Command('sudo foo', output='sudo: foo: command not found'))
    assert not match(Command('sudo foo'))


# Generated at 2022-06-24 07:23:38.883169
# Unit test for function match
def test_match():
    assert match(Command('sudo INPUT_COMMAND',
                         'sudo: INPUT_COMMAND: command not found', 1))
    assert not match(Command('sudo ls', '', 1))


# Generated at 2022-06-24 07:23:41.897213
# Unit test for function get_new_command
def test_get_new_command():
    script = "sudo echo Hello"
    output = "sudo: echo: command not found"
    command = Command(script=script, output=output)

    assert(get_new_command(command) == u"env \"PATH=$PATH\" echo Hello")

# Generated at 2022-06-24 07:23:47.131432
# Unit test for function match
def test_match():
    
    # Correct output should match
    command = type('Command', (object,),
            {'script': 'sudo sudo', 'output': 'sudo: sudo: command not found'})
    assert match(command)

    # Wrong output should not match
    command = type('Command', (object,),
            {'script': 'sudo sudo', 'output': 'sudo: command not found'})
    assert not match(command)



# Generated at 2022-06-24 07:23:57.549015
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    # No sudo in command
    assert get_new_command(Command('foo')) == 'foo'

    # No command found in output
    assert get_new_command(Command('sudo foo')) == 'sudo foo'

    # Command not found in output
    assert (get_new_command(Command('sudo foo',
                                    u'sudo: foo: command not found'))
            == u'env "PATH=$PATH" foo')

    # Command not found in output with more text
    assert (get_new_command(Command('sudo foo',
                                    'sudo: foo: command not found\n'
                                    'bar: command not found'))
            == u'env "PATH=$PATH" foo')

# Generated at 2022-06-24 07:24:02.251819
# Unit test for function match
def test_match():
    # test match
    command = Command('sudo hello_world', 'sudo: hello_world: command not found')
    assert match(command)
    # test not match
    command = Command('sudo hello_world', 'sudo: hello_world: command not found' +
                                          '\nhello_world is a command')
    assert not match(command)


# Generated at 2022-06-24 07:24:05.380877
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    from thefuck.types import Command
    assert get_new_command(Command('sudo id', 'sudo: id: command not found')) == u'env "PATH=$PATH" id'

# Generated at 2022-06-24 07:24:08.571402
# Unit test for function get_new_command
def test_get_new_command():
    output = "sudo: hello: command not found"
    script = "sudo hello yay"
    assert get_new_command(Command(script, output)) == "env \"PATH=$PATH\" sudo hello yay"
    assert get_new_command(Command("sudo echo yay", output)) == "env \"PATH=$PATH\" sudo echo yay"
    assert get_new_command(Command("hello yay", output)) == "env \"PATH=$PATH\" hello yay"

# Generated at 2022-06-24 07:24:11.842820
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim', '')) == u'env "PATH=$PATH" vim'
    assert get_new_command(Command('sudo vim', '')) != u'env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:24:13.489756
# Unit test for function match
def test_match():
	assert match(Command('sudo htop', '/usr/bin/sudo: htop: command not found'))


# Generated at 2022-06-24 07:24:15.952573
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo test_cmd')) == 'env "PATH=$PATH" test_cmd'

# Generated at 2022-06-24 07:24:21.349661
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    script = u"sudo ls $HOME -a"
    new_command = get_new_command(Bash(script, "sudo: ls: command not found"))
    assert new_command == u'sudo env "PATH=$PATH" "ls $HOME -a"'

# Generated at 2022-06-24 07:24:24.810676
# Unit test for function match
def test_match():
    assert not match(Command('', ''))
    assert not match(Command('sudo git', ''))
    assert match(Command('sudo bogus-command', u'''bogus-command: command not found'''))



# Generated at 2022-06-24 07:24:26.872454
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls qq', \
                                   "sudo: ls: command not found\n")) == u'env "PATH=$PATH" ls qq'

# Generated at 2022-06-24 07:24:28.585354
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('ls --foo')
    command.output = 'sudo: ls: command not found'
    asser

# Generated at 2022-06-24 07:24:33.002941
# Unit test for function match
def test_match():
    assert match(Command('sudo fukk', '/bin/sudo: fukk: command not found'))
    assert not match(Command('sudo fukk', 'sudo: fukk: command not found'))


# Generated at 2022-06-24 07:24:36.198920
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("sudo sudo", "sudo: sudo: command not found")
    assert get_new_command(command) == 'env "PATH=$PATH" sudo sudo'

# Generated at 2022-06-24 07:24:44.207818
# Unit test for function match
def test_match():
    assert(match(Command(script='sudo apt-get install nodejs',
                         output='sudo: apt-get: command not found')) ==
           'apt-get')
    assert(match(Command(script='sudo apt-get install nodejs',
                         output='sudo: not found')) == None)
    assert(match(Command(script='sudo apt-get install nodejs',
                         output='')) == None)
    assert(match(Command(script='sudo apt-get install nodejs')) == None)
    assert(match(Command(script='',
                         output='sudo: apt-get: command not found')) == None)


# Generated at 2022-06-24 07:24:45.581093
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))



# Generated at 2022-06-24 07:24:47.142419
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("sudo sudofoo") == 'env "PATH=$PATH" sudofoo'

# Generated at 2022-06-24 07:24:50.000293
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo foo',
                                   output='sudo: foo: command not found')) == u'env "PATH=$PATH" foo'

# Generated at 2022-06-24 07:24:58.879383
# Unit test for function get_new_command
def test_get_new_command():
    # Check get_new_command("sudo oh no") == "oh no"
    assert get_new_command("sudo oh no") == "oh no"

    # Check get_new_command("sudo a b c") == "sudo a b c"
    assert get_new_command("sudo a b c") == "sudo a b c"

    # Check get_new_command("sudo git push heroku") == "git push heroku"
    #assert get_new_command("sudo git push heroku") == "git push heroku"

    # Check get_new_command("sudo python") == "python"
    #assert get_new_command("sudo python") == "python"

# Generated at 2022-06-24 07:25:02.191442
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    command = Command('sudo ls',
                      'sudo: ls: command not found')
    assert get_new_command(command) == \
           "env PATH='' ls"

# Generated at 2022-06-24 07:25:04.389334
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    script = Command('sudo -s', 'sudo: /bin/bash: command not found\n')
    assert get_new_command(script) == 'env "PATH=$PATH" /bin/bash '

# Generated at 2022-06-24 07:25:05.334188
# Unit test for function match
def test_match():
    assert match(Command('sudo nmap', ''))
    assert not match(Command('ssudo nmap', ''))



# Generated at 2022-06-24 07:25:07.095818
# Unit test for function match
def test_match():
    assert match(Command('sudo some_not_existing_command', ''))
    assert not match(Command('ls', ''))



# Generated at 2022-06-24 07:25:09.178965
# Unit test for function match
def test_match():
    assert match(Command('sudo fuck',
                         output='sudo: fuck: command not found'))


# Generated at 2022-06-24 07:25:12.581445
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ww',
                                   'sudo: ww: command not found')) == 'env "PATH=$PATH" ww'

# Generated at 2022-06-24 07:25:17.419918
# Unit test for function match
def test_match():
    assert match(Command('sudo foo', 'sudo: foo: command not found'))
    assert match(Command('sudo foo -u bar', 'sudo: foo: command not found'))
    assert not match(Command('sudo foo', 'sudo: foo: foo: command not found'))
    assert not match(Command('sudo foo', ''))



# Generated at 2022-06-24 07:25:17.930131
# Unit test for function match

# Generated at 2022-06-24 07:25:20.738567
# Unit test for function match
def test_match():
    assert match(Command('sudo sudo', stderr='sudo: sudo: command not found'))
    assert not match(Command('sudo sudo', stderr='sudo: command not found'))


# Generated at 2022-06-24 07:25:23.903160
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command('sudo ls -la')
    assert new_cmd == 'sudo env "PATH=$PATH" ls -la'

# Generated at 2022-06-24 07:25:26.658050
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('sudo echo "42"', 'sudo: echo: command not found')) == u'env "PATH=$PATH" echo "42"')

# Generated at 2022-06-24 07:25:29.447520
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("sudo dmesg | tail") == \
        "env \"PATH=$PATH\" dmesg | tail"

# Generated at 2022-06-24 07:25:33.079636
# Unit test for function match
def test_match():
    assert match(Command('cowsay -f', 'sudo: cowsay: command not found\n'))
    assert not match(Command('which cowsay', 'sudo: cowsay: command not found\n'))



# Generated at 2022-06-24 07:25:35.118295
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command("sudo find /", "sudo: find: command not found")) == \
           "env \"PATH=$PATH\" find /")

# Generated at 2022-06-24 07:25:38.836299
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install *', 'sudo: apt-get: command not found', '')) == 'env "PATH=$PATH" apt-get install *'
    assert get_new_command(Command('sudo apt-get install', 'sudo: apt-get: command not found', '')) == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-24 07:25:43.598707
# Unit test for function match
def test_match():
    assert match(Command(script='sudo emacs'))
    assert not match(Command(script='sudo apt-get install emacs'))
    assert _get_command_name(Command(script='sudo emacs', output='sudo: emacs: command not found')) == 'emacs'



# Generated at 2022-06-24 07:25:45.905644
# Unit test for function match
def test_match():
    assert match(Command('', None)) == False
    assert match(Command('sudo apt-get', 'sudo: apt-get: command not found\n'))
    assert match(Command('sudo apt-get', '')) == False



# Generated at 2022-06-24 07:25:48.185826
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('sudo apt-get update', 'sudo: apt-get: command not found')) == u'env "PATH=$PATH" apt-get update'

# Generated at 2022-06-24 07:25:50.743906
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
            == 'env "PATH=$PATH" apt-get update')

# Generated at 2022-06-24 07:25:55.552851
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    from thefuck.types import Command
    assert get_new_command(Command('sudo vim', 'sudo: vim: command not found', '')) == 'env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:25:56.993673
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("sudo ls", "")) == u"sudo env \"PATH=$PATH\" ls"

# Generated at 2022-06-24 07:26:00.326607
# Unit test for function match
def test_match():
    assert not match(Command('sudo cd /home', ''))
    assert match(Command('sudo cd /homes', 'sudo: cd: command not found'))
    assert not match(Command('sudo cd /home', 'sudo: cd: command not found'))



# Generated at 2022-06-24 07:26:04.125710
# Unit test for function match
def test_match():
    out_match = "sudo: node: command not found"
    assert match(Command("sudo node -v", out_match))
    out_not_match = "sudo: aaa: command not found"
    assert not match(Command("sudo aaa", out_not_match))


# Generated at 2022-06-24 07:26:08.919803
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo virsh start server1',
                                   'sudo: virsh: command not found')) == \
        u'sudo env "PATH=$PATH" virsh start server1'

    assert not get_new_command(Command('sudo virsh start server1',
                                       'sudo: vish: command not found'))

# Generated at 2022-06-24 07:26:10.389693
# Unit test for function match
def test_match():
    cmd = type('Command', (object,), {'output': 'sudo: env: command not found'})
    assert match(cmd)


# Generated at 2022-06-24 07:26:13.653007
# Unit test for function match
def test_match():
    # Test invalid case
    invalid_case = Command('sudo ls', '')
    assert not match(invalid_case)
    # Test valid case
    ls_output = 'sudo: ls: command not found'
    valid_case = Command('ls -l', ls_output)
    assert match(valid_case)



# Generated at 2022-06-24 07:26:18.323227
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'sudo vi', 'output': 'sudo: vi: command not found'})
    assert get_new_command(command) == 'env "PATH=$PATH" vi'

# Generated at 2022-06-24 07:26:25.550810
# Unit test for function match
def test_match():
    up = u'$ sudo apt get install'
    down = u'sudo: apt: command not found'
    assert _get_command_name(down) == 'apt'
    assert _get_command_name(up) == None
    assert match(Command(up, down)) is None
    assert match(Command(u'$ sudo apt-get install',
                         u'sudo: apt-get: command not found')) is None
    assert match(Command(u'$ sudo apt-get install',
                         u'sudo: apt-get: command not found')) is None



# Generated at 2022-06-24 07:26:26.675172
# Unit test for function match
def test_match():
    assert match(Command('sudo ls'))


# Generated at 2022-06-24 07:26:31.593742
# Unit test for function get_new_command
def test_get_new_command():
    command = type('', (), {})()
    command.script = "sudo foo"
    command.output = "sudo: foo: command not found"
    assert get_new_command(command) == "env 'PATH=$PATH' foo"

# Generated at 2022-06-24 07:26:35.176778
# Unit test for function match
def test_match():
    assert match(Command("sudo brew install thepackage",
               "sudo: brew: command not found"))
    assert match(Command("sudo apt-get install thepackage",
               "sudo: apt-get: command not found"))



# Generated at 2022-06-24 07:26:38.576163
# Unit test for function match
def test_match():
    assert which('apt') is not None
    assert _get_command_name('sudo: apt: command not found').lower() == 'apt'
    assert _get_command_name('sudo: apt: abcd not found').lower() == 'apt'


# Generated at 2022-06-24 07:26:41.217628
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('sudo ls', 'sudo: ls: command not found\n'))
    assert new_command == 'env "PATH=$PATH" sudo ls'

# Generated at 2022-06-24 07:26:43.417113
# Unit test for function match
def test_match():
    assert match(Command('this-command-does-not-exist', ''))



# Generated at 2022-06-24 07:26:48.039592
# Unit test for function match
def test_match():
    # If a command exists, it should suggest to run it without sudo
    assert match(Command('sudo ls', ''))
    # If a command doesn't exist, it shouldn't suggest anything
    assert not match(Command('sudo howdydo', 'sudo: howdydo: command not' +
                             'found'))



# Generated at 2022-06-24 07:26:52.562433
# Unit test for function get_new_command
def test_get_new_command():
    script = ['sudo', 'echo "Hello World"']
    output = 'sudo: echo: command not found'
    command = type('Command', (object,), {'script': script, 'output': output})
    assert get_new_command(command) == ['sudo', 'env "PATH=$PATH" echo "Hello World"']

# Generated at 2022-06-24 07:27:03.479312
# Unit test for function get_new_command
def test_get_new_command():
    # Case - 1
    command = Command("sudo not_exit_command", "sudo: not_exit_command: command not found")
    # Should be return "sudo env \"PATH=$PATH\" not_exit_command"
    assert(get_new_command(command) == "sudo env \"PATH=$PATH\" not_exit_command")
    # Case - 2
    command = Command("sudo not_exit_command --test", "sudo: not_exit_command: command not found")
    # Should be return "sudo env \"PATH=$PATH\" not_exit_command --test"
    assert(get_new_command(command) == "sudo env \"PATH=$PATH\" not_exit_command --test")



# Generated at 2022-06-24 07:27:04.847320
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('sudo test') == 'env "PATH=$PATH" test')

# Generated at 2022-06-24 07:27:08.424874
# Unit test for function match
def test_match():
    assert match(Command('foo', 'sudo: foo: command not found', ''))
    assert not match(Command('foo', '', ''))
    assert not match(Command('foo', 'sudo: foo', ''))


# Generated at 2022-06-24 07:27:11.363029
# Unit test for function match
def test_match():
    assert match(Command('sudo swagastick --version',
                         'sudo: swagastick: command not found'))
    assert not match(Command('sudo apt-get -f install', ''))


# Generated at 2022-06-24 07:27:22.822833
# Unit test for function get_new_command

# Generated at 2022-06-24 07:27:26.973500
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', ''))
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo echo foo', ''))
    assert not match(Command('sudo echo foo', 'sudo: echo: command not found'))


# Generated at 2022-06-24 07:27:29.493087
# Unit test for function get_new_command
def test_get_new_command():
    command_name = 'com'
    command = 'sudo com'
    assert get_new_command(command) == u'env "PATH=$PATH" com'

# Generated at 2022-06-24 07:27:39.268386
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'sudo: vim: Permisson denied'))
    assert not match(Command('sudo vim', 'sudo: vim: something goes wrong'))
    assert not match(Command('sudo vim', 'sudo: vim: something goes wrong'))
    assert match(Command('sudo vim', 'sudo: vim: command not found\n'
                         'sudo: environment: command not found'))
    assert not match(Command('sudo vim', 'Command not found'))


# Generated at 2022-06-24 07:27:45.381911
# Unit test for function match
def test_match():
    command = Command(script='sudo ls',
                      output='sudo: ls: command not found')
    assert match(command)

    command = Command(script='sudo apachectl start',
                      output='sudo: apachectl: command not found')
    assert match(command)

    command = Command(script='sudo apachectl start', output='help')
    assert not match(command)



# Generated at 2022-06-24 07:27:47.559447
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(
        Command('sudo vim', 'sudo: vim: command not found'))
    assert new_command == 'env "PATH=$PATH" sudo vim'

# Generated at 2022-06-24 07:27:51.164580
# Unit test for function match
def test_match():
    assert match(Command('sudo anything',
                "sudo: anything: command not found")) and\
                match(Command('sudo fubar',
                "sudo: fubar: command not found"))

# Generated at 2022-06-24 07:27:57.364989
# Unit test for function match
def test_match():
    command = Command('sudo test',
                      'sudo: test: command not found\n')
    assert not match(command)

    command = Command('sudo test',
                      'password: sudo: test: command not found\n')
    assert not match(command)

    command = Command('sudo test',
                      'sudo: test: command not found\n')
    assert match(command)

    command = Command('sudo /usr/bin/test',
                      'sudo: /usr/bin/test: command not found\n')
    assert not match(command)

    command = Command('sudo /usr/bin/test -xx',
                      'sudo: /usr/bin/test: command not found\n')
    assert not match(command)

    command = Command('sudo test -xx',
                      'sudo: test: command not found\n')

# Generated at 2022-06-24 07:27:58.480603
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))


# Generated at 2022-06-24 07:28:03.512785
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo git ls-files') == 'sudo env "PATH=$PATH" git ls-files'
    assert get_new_command('sudo git foo --bar') == 'sudo env "PATH=$PATH" git foo --bar'
    assert get_new_command('sudo git foo bar') == 'sudo env "PATH=$PATH" git foo bar'
    assert get_new_command('sudo git foo bar --baz dol') == 'sudo env "PATH=$PATH" git foo bar --baz dol'


# Generated at 2022-06-24 07:28:06.232970
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo reboot',
                                   output=u'sudo: reboot: command not found')) == u'env "PATH=$PATH" reboot'