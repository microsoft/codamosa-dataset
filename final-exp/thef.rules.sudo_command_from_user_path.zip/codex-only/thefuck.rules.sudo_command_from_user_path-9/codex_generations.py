

# Generated at 2022-06-24 07:18:04.100829
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found\n'))


# Generated at 2022-06-24 07:18:08.521803
# Unit test for function match
def test_match():
    assert which('ls')
    assert which('vim')
    assert not which('vom')
    assert match(Command('sudo vim', 'sudo: vom: command not found'))
    assert match(Command('sudo ls', 'sudo: vom: command not found'))
    assert not match(Command('sudo vom', 'sudo: vom: command not found'))


# Generated at 2022-06-24 07:18:11.477941
# Unit test for function get_new_command
def test_get_new_command():
    script = "sudo ls --help"
    output = "sudo: ls: command not found\n"
    assert get_new_command(Command(script, output)) == "sudo env \"PATH=$PATH\" ls --help"

# Generated at 2022-06-24 07:18:15.414740
# Unit test for function match
def test_match():
    assert match(Command('sudo ls /root', 'sudo: root: command not found'))
    assert not match(Command('sudo ls /root', 'sudo: /root: Is a directory'))


# Generated at 2022-06-24 07:18:18.031162
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo nmap', output='sudo: nmap: command not found')) == 'env "PATH=$PATH" nmap'

# Generated at 2022-06-24 07:18:19.993399
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('sudo vim','sudo: vim: command not found','','','')).script == 'env "PATH=$PATH" vim')

# Generated at 2022-06-24 07:18:22.930329
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(_get_dummy_command(
        script="sudo python",
        output="sudo: python: command not found")).script == u'env "PATH=$PATH" python'



# Generated at 2022-06-24 07:18:29.789273
# Unit test for function get_new_command
def test_get_new_command():
    # Match
    command = 'sudo ls /'
    output = 'sudo: ls: command not found'
    assert get_new_command(Command(command, output)) == 'env "PATH=$PATH" ls /'

    # Not match
    command = 'sudo ls /'
    output = 'command not found'
    assert get_new_command(Command(command, output)) == 'env "PATH=$PATH" ls /'

# Generated at 2022-06-24 07:18:31.862604
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls /root/', '')) == 'env "PATH=$PATH" ls /root/'

# Generated at 2022-06-24 07:18:33.363770
# Unit test for function match
def test_match():
    assert not match(Command('vim', ''))
    assert match(Command('sudo vim', 'sudo: vim: command not found'))


# Generated at 2022-06-24 07:18:37.564508
# Unit test for function match
def test_match():
    assert match(Command('sudo ga', 'sudo: ga: command not found\n'))
    assert match(Command('sudo gg', 'sudo: gg: command not found\n'))
    assert not match(Command('git', 'sudo: git: command not found\n'))


# Generated at 2022-06-24 07:18:40.950136
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo 7z a mi.tar.7z mi', 'sudo: 7z: command not found')) == 'env "PATH=$PATH" 7z a mi.tar.7z mi'

# Generated at 2022-06-24 07:18:42.010152
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command("sudo: command: command not found")
    assert new_command == 'env "PATH=$PATH" command'

# Generated at 2022-06-24 07:18:44.229132
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'You shall not pass!'))


# Generated at 2022-06-24 07:18:45.579611
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo pacman -S git') == u'env "PATH=$PATH" pacman -S git'

# Generated at 2022-06-24 07:18:54.898991
# Unit test for function match
def test_match():
    # match should return none if the error is not sudo command not found
    wrong_output = "sudo: /this/is/the/wrong/command: command not found"
    assert match(Command('sudo /this/is/the/wrong/command', wrong_output)) is None
    # match should return none if the command is correct
    correct_output = "sudo: /this/is/the/correct/command: command found"
    assert match(Command('sudo /this/is/the/correct/command', correct_output)) is None
    # match should return the command name of the incorrect command
    wrong_command = "/this/is/the/wrong/command"
    wrong_output = "sudo: {}: command not found".format(wrong_command)
    assert match(Command('sudo {}'.format(wrong_command), wrong_output)) == wrong_command

# Generated at 2022-06-24 07:18:59.865302
# Unit test for function match
def test_match():
    assert match(Command('sudo fuck', 'fuck: command not found'))
    assert match(Command('fuck', 'fuck: command not found'))
    assert not match(Command('fuck', 'sudo: fuck: command not found'))
    assert not match(Command('sudo fuck', 'sudo: fuck: command not found'))


# Generated at 2022-06-24 07:19:02.655143
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("sudo apt-get update", "sudo: apt-get: command not found")
    assert get_new_command(command) == u'env "PATH=$PATH" apt-get update'

# Generated at 2022-06-24 07:19:07.910290
# Unit test for function match
def test_match():
    match = _get_command_name
    from thefuck.types import Command

    assert match(Command('sudo ls', output='sudo: ls: command not found')) == 'ls'
    assert match(Command('sudo apt-get install vim', output='sudo: apt-get: command not found')) == 'apt-get'
    assert match(Command('sudo ls', output='foo')) == None

# Generated at 2022-06-24 07:19:09.912224
# Unit test for function match
def test_match():
    assert match(Command('foo'))
    assert not match(Command('sudo foo'))

# Generated at 2022-06-24 07:19:14.488063
# Unit test for function match
def test_match():
    command = Command('sudo fk')
    assert match(command) is None

    command = Command('sudo fk', 'sudo: fk: command not found')
    assert match(command) == 'fk'

    command = Command('sudo fk', 'sudo: fk: command not found', which('fk'))
    assert match(command) == 'fk'


# Generated at 2022-06-24 07:19:16.767540
# Unit test for function get_new_command
def test_get_new_command():
    output = 'sudo: test: command not found\n'
    script = 'sudo test'
    assert get_new_command({'output': output, 'script': script}) == u'sudo env "PATH=$PATH" test'

# Generated at 2022-06-24 07:19:19.777337
# Unit test for function match
def test_match():
    assert match(Command('sudo xxx', 'sudo: xxx: command not found\n'))
    assert not match(Command('sudo xxx', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 07:19:23.022489
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo find /usr/local/bin', '')
    assert get_new_command(command) == 'env "PATH=$PATH" find /usr/local/bin'

# Generated at 2022-06-24 07:19:30.040289
# Unit test for function match
def test_match():
    assert match(Command('sudo  bad_command', 'sudo: bad_command: command not found'))
    assert match(Command('sudo -u good_user good_command', 'sudo: good_command: command not found'))
    assert match(Command('sudo bad_command "bad arg \"with quotes\""', 'sudo: bad_command: command not found'))
    assert not match(Command('sudo bad_command "bad arg \"with quotes\""', 'sudo: command not found'))


# Generated at 2022-06-24 07:19:34.766936
# Unit test for function match
def test_match():
    assert match(Command('sudo test',
             stderr='sudo: test: command not found'))
    assert not match(Command('sudo test',
             stderr='sudo: command not found'))
    assert not match(Command('test'))
    # assert match(Command(u'sudo ⏎', stderr='sudo: ⏎: command not found'))



# Generated at 2022-06-24 07:19:40.432318
# Unit test for function get_new_command
def test_get_new_command():
    command = 'sudo hg push'
    output = 'sudo: hg: command not found'
    assert get_new_command(SimpleNamespace(script=command, output=output)) == "env \"PATH=$PATH\" hg push"

    command = 'sudo hg push'
    output = 'sudo: hg: command not found\nhg: command not found'
    assert get_new_command(SimpleNamespace(script=command, output=output)) == "env \"PATH=$PATH\" hg push"

# Generated at 2022-06-24 07:19:46.990904
# Unit test for function match
def test_match():
    assert match(Command(script = 'sudo apt-get install', output = 'sudo: apt-get: command not found'))
    assert not match(Command(script = 'sudo apt-get install', output = 'sudo: apt-get: command not found, try again'))
    assert not match(Command(script = 'sudo apt-get install', output = 'sudo: apt-get: command not found, bye!'))
    assert not match(Command(script = 'sudo apt-get install', output = 'sudo: apt-get: command not found, exit now.'))
    assert not match(Command(script = 'sudo apt-get install', output = 'sudo: apt-get: command not found, return now.'))
    assert not match(Command(script = 'sudo apt-get install', output = 'sudo: apt-get: command not found, leave now.'))


# Generated at 2022-06-24 07:19:49.242054
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim', 'sudo: vim: command not found')) == 'env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:19:52.016882
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.main import Command

    assert get_new_command(Command(script='sudo ls foo', output='sudo: ls: command not found')) == 'env "PATH=$PATH" ls foo'

# Generated at 2022-06-24 07:19:53.189344
# Unit test for function match
def test_match():
    assert match(Command('sudo blah blah blah',
                         "sudo: blah: command not found"))



# Generated at 2022-06-24 07:19:58.444403
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command = Command('sudo rp', output='sudo: rp: command not found\n')
    assert get_new_command(command) == 'env "PATH=$PATH" rp rp'
    command = Command('sudo rp', output='sudo: rp: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" rp rp'
    command = Command('sudo rp', output='sudo: rp')
    assert get_new_command(command) == command.script

# Generated at 2022-06-24 07:20:02.753664
# Unit test for function match
def test_match():
    assert not match(Command('apt-get update', ''))
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))

# Generated at 2022-06-24 07:20:06.320101
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo foo'
    output = "sudo: foo: command not found"
    command = Command(script=script, output=output)
    new_command = get_new_command(command)
    assert new_command == u'env "PATH=$PATH" foo'

# Generated at 2022-06-24 07:20:08.060631
# Unit test for function match
def test_match():
    assert match(Command(script='sudo a', output='sudo: a: command not found'))


# Generated at 2022-06-24 07:20:10.544719
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo echo sudo: echo: command not found', '', 0)
    assert get_new_command(command) == 'env "PATH=$PATH" echo'

# Generated at 2022-06-24 07:20:18.454208
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install', '')) == None
    assert match(Command('sudo apt-get install', '')).__class__.__name__ == 'NoneType'
    assert isinstance(match(Command('sudo apt-get install', '')), type(None))
    assert isinstance(match(Command('sudo apt-get install', 'sudo: apt-get: command not found')), type(None))
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found')).__class__.__name__ == 'NoneType'
    assert match(Command('sudo apt-get install', 'sudo: apt-get: command not found')) == None



# Generated at 2022-06-24 07:20:19.954541
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', ''))
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('vim', ''))


# Generated at 2022-06-24 07:20:20.962705
# Unit test for function match
def test_match():
    assert match("sudo s")


# Generated at 2022-06-24 07:20:26.548138
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    command = type('Command', (object,), {
        'script': 'sudo install',
        'output': 'sudo: install: command not found',
    })()
    assert u' env "PATH=$PATH" install' in get_new_command(command)

# Generated at 2022-06-24 07:20:30.420912
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo fduck', 'fduck: command not found')
    assert get_new_command(command) == u'env "PATH=$PATH" fduck'
    command = Command('sudo ls foo', 'ls: foo: command not found')
    assert get_new_command(command) == u'env "PATH=$PATH" ls foo'

# Generated at 2022-06-24 07:20:33.649941
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
        'script': u'sudo apt-get install',
        'output': u'sudo: apt-get: command not found'
    })
    assert u'env "PATH=$PATH" apt-get' in get_new_command(command)

# Generated at 2022-06-24 07:20:36.713949
# Unit test for function match
def test_match():
    assert match(Command('sudo systemctl no-such-command',
                         'sudo: systemctl: command not found'))
    assert not match(Command('sudo systemctl status',
                             'sudo: systemctl: command not found'))


# Generated at 2022-06-24 07:20:38.346794
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo vim') == 'sudo env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:20:42.403873
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'sudo echo foo > file1',
                    'output': 'sudo: echo: command not found'})
    assert get_new_command(command) == "env \"PATH=$PATH\" echo foo > file1"

# Generated at 2022-06-24 07:20:52.075844
# Unit test for function get_new_command
def test_get_new_command():
    # Command with path
    command_f = Command(script='sudo /home/user/foo.run arg1 arg2 arg3',
                        stderr='sudo: /home/user/foo.run: command not found')
    new_command_f = get_new_command(command_f)
    assert new_command_f == 'sudo env "PATH=$PATH" /home/user/foo.run arg1 arg2 arg3'

    # Command without path
    command_w = Command(script='sudo foo.run arg1 arg2 arg3',
                        stderr='sudo: foo.run: command not found')
    new_command_w = get_new_command(command_w)
    assert new_command_w == 'sudo env "PATH=$PATH" foo.run arg1 arg2 arg3'

    # Subcommand
    command_

# Generated at 2022-06-24 07:20:55.806989
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git status") == "sudo env 'PATH=$PATH' git status"
    assert get_new_command("sudo git status") == "sudo env 'PATH=$PATH' git status"
    assert get_new_command("cd gg") == "cd gg"

# Generated at 2022-06-24 07:20:57.871271
# Unit test for function match
def test_match():
    msg = 'sudo: vim: command not found'
    assert match(Command(script='sudo vim', output=msg))


# Generated at 2022-06-24 07:20:58.877083
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo echo test'
    output = 'sudo: echo: command not found'
    command = Command(script, output)
    asser

# Generated at 2022-06-24 07:21:03.920053
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('echo test', 'test: command not found', '')) == u'env "PATH=$PATH" test'
    assert get_new_command(Command('git stash push -m "test"', 'git: \'stash push -m test\': command not found', '')) == u'env "PATH=$PATH" git stash push -m test'

# Generated at 2022-06-24 07:21:09.012989
# Unit test for function get_new_command
def test_get_new_command():
    import os

    script = 'sudo env PATH=$PATH echo'
    output = "sudo: echo: command not found"
    command = type('', (), {'script': script, 'output': output})

    os.environ['PATH'] = 'test/test_env:$PATH'
    assert get_new_command(command) == "sudo env PATH=$PATH echo"

# Generated at 2022-06-24 07:21:11.600007
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules import _get_command_name  # noqa
    assert get_new_command("sudo ls /") == (
        u'env "PATH=$PATH" sudo ls /')

# Generated at 2022-06-24 07:21:16.300778
# Unit test for function match
def test_match():
    assert which('fdisk')
    assert match(Command('sudo fdisk', ''))
    assert not match(Command('sudo fdisk', 'sudo: fdisk: command not found'))
    assert not match(Command('ls', 'ls: command not found'))
    assert not match(Command('sudo man fdisk', 'sudo: fdisk: command not found'))
    assert not match(Command('sudo man fdisk', 'sudo: man: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found'))



# Generated at 2022-06-24 07:21:19.466694
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', "sudo: apt-get: command not found\n"))
    assert not match(Command('sudo apt-get update', "apt-get: command not found\n"))


# Generated at 2022-06-24 07:21:21.710038
# Unit test for function match
def test_match():
    assert match(Command('sudo require', 'sudo: require: command not found'))
    assert not match(Command('sudo apt update',
                             'Hit:1 http://in.archive.ubuntu.com/ubuntu'))


# Generated at 2022-06-24 07:21:26.639236
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', ''))
    assert match(Command('sudo abc', 'sudo: abc: command not found'))

    assert not match(Command('sudo abc', 'abc: command not found'))
    assert not match(Command('sudo abc', 'sudo: command not found'))



# Generated at 2022-06-24 07:21:30.056530
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_matches import get_new_command
    assert get_new_command(Command('sudo apt-get update',
                                   'sudo: apt-get: command not found')) == \
            'env "PATH=$PATH" apt-get update'

# Generated at 2022-06-24 07:21:31.586520
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo test gtest').script == 'env \"PATH=$PATH\" test gtest'

# Generated at 2022-06-24 07:21:35.227526
# Unit test for function match
def test_match():
    assert match(Command('sudo no command',
                         'sudo: no: command not found'))
    assert not match(Command('sudo true', ''))



# Generated at 2022-06-24 07:21:39.013764
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo git')
    command.output = 'sudo: git: command not found'
    new_command = get_new_command(command)
    assert new_command == 'sudo env "PATH=$PATH" git'


enabled_by_default = True

# Generated at 2022-06-24 07:21:40.750333
# Unit test for function match
def test_match():
    command = 'sudo: update-manager: command not found'
    assert match(command)



# Generated at 2022-06-24 07:21:43.645201
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo unit-test --arg1 --arg2',
                                   'sudo: unit-test: command not found')) == \
        'env "PATH=$PATH" "unit-test" --arg1 --arg2'

# Generated at 2022-06-24 07:21:51.147162
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command ("sudo startup.sh", "sudo: startup.sh: command not found")) == "env \"PATH=$PATH\" startup.sh"
    assert get_new_command(
        Command ("sudo apt-get install python-pip", "sudo: apt-get: command not found")) == "env \"PATH=$PATH\" apt-get install python-pip"
    assert get_new_command(
        Command ("sudo service nginx restart", "sudo: service: command not found")) == "env \"PATH=$PATH\" service nginx restart"

# Generated at 2022-06-24 07:21:53.780819
# Unit test for function match
def test_match():
    assert which('python')
    assert match(Command('sudo python', ''))
    assert not match(Command('sudo nopython', 'sudo: nopython: command not found'))
    assert not match(Command('sudo python', 'python: command not found'))
    assert not match(Command('nopython', 'nopython: command not found'))


# Generated at 2022-06-24 07:21:57.024945
# Unit test for function match
def test_match():
    assert match(Command('sudo echoe "fuck"',
                         "sudo: echoe: command not found"))
    assert not match(Command('ls /tmp', ''))

#Unit test for function get_new_command

# Generated at 2022-06-24 07:21:58.509841
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim', 'sudo: vim: command not found')) == 'sudo env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:22:04.111886
# Unit test for function get_new_command
def test_get_new_command():
    # Command for which get_new_command returns a new command script
    test_script = 'sudo: javac: command not found'

    from thefuck.types import Command

    command = Command(script=test_script,
                      stdout=test_script,
                      stderr=None)

    # Assert the new command script is correct
    assert get_new_command(command) == 'env "PATH=$PATH" javac'

# Generated at 2022-06-24 07:22:07.114131
# Unit test for function match
def test_match():
    assert match(Command('sudo aaaabbbbcccccdddd', 'aaabbbcccddd: command not found'))
    assert not match(Command('whoami', 'xxx'))


# Generated at 2022-06-24 07:22:13.071018
# Unit test for function match
def test_match():
    # We should check that the command name is actually in $PATH
    # but unfortunately here it is not the case so we mock it
    import sys
    if sys.version_info.major > 2:
        builtins = 'builtins'
    else:
        builtins = '__builtin__'

    which_mock = mock.MagicMock(name="which", return_value=True)

    with mock.patch('{}.which'.format(builtins), which_mock):
        assert match(Command('sudo some command', 'sudo: some: command not found', None, None, None))
        which_mock.assert_called_once_with('some')



# Generated at 2022-06-24 07:22:15.294721
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo foo'
    new_script = get_new_command(script)
    assert new_script == 'sudo env "PATH=$PATH" foo'

# Generated at 2022-06-24 07:22:19.808279
# Unit test for function match
def test_match():
    command = Command('sudo bad_command',
                      r'sudo: bad_command: command not found\r\n')
    assert match(command)  # Mock which() always return True
    assert _get_command_name(command) == 'bad_command' == get_new_command(command)

# Generated at 2022-06-24 07:22:21.523316
# Unit test for function match
def test_match():
    assert match(Command('sudo apachectl', '', '', '', ''))
    assert not match(Command('sudo systemctl daemon-reload', '', '', '', ''))



# Generated at 2022-06-24 07:22:30.379731
# Unit test for function match
def test_match():
    output = 'sudo: pkgin: command not found'
    assert match(Command('sudo pkgin', output=output))

    output = 'sudo: pip3.5: command not found'
    assert match(Command('sudo pip3.5', output=output))

    output = 'sudo: pip3.5: command not found'
    assert not match(Command('sudo pip3.5', output='blah'))

    output = 'sudo: pip: command not found'
    assert match(Command('sudo pip', output=output))

    output = 'sudo: /usr/local/python3: No such file or directory'
    assert not match(Command('sudo /usr/local/python3', output=output))


# Generated at 2022-06-24 07:22:33.486537
# Unit test for function match
def test_match():
    # Test for match failure
    from tests.utils import Command

    assert match(Command('sudo x')) is None

    # Test for match success with different command
    assert match(Command('sudo ls'))
    assert match(Command('sudo ls', 'sudo: ls: command not found'))



# Generated at 2022-06-24 07:22:39.024350
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('ls', ''))
    assert not match(Command('sudo ls', ''))
    assert not match(Command('sudo ls', 'sudo: ls: command not found\n'
                                          'sudo: ping: command not found'))



# Generated at 2022-06-24 07:22:42.580488
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'sudo not_found',
                    'output': 'sudo: not_found: command not found'})
    assert get_new_command(command) == (
        u'env "PATH=$PATH" not_found')

# Generated at 2022-06-24 07:22:45.167590
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(MagicMock(script="sudo apt-get update",
                                     output='sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get update'

# Generated at 2022-06-24 07:22:47.081918
# Unit test for function match
def test_match():
  assert match(Command('sudo dpkg --configure -a'))
  assert match(Command('sudo dpkg --configure -a', output='sudo: dpkg: command not found'))
  assert not match(Command('sudo git add .'))


# Generated at 2022-06-24 07:22:50.439361
# Unit test for function match
def test_match():
    assert(tuple(match(Command(script = 'sudo lolz'))) == tuple())
    assert(tuple(match(Command(script = 'sudo', output = 'sudo: lolz: command not found'))) == tuple())


# Generated at 2022-06-24 07:22:54.327826
# Unit test for function get_new_command
def test_get_new_command():
    stdout = '''sudo: a: command not found
sudo: effective uid is not 0, is sudo installed setuid root?'''
    command = MagicMock(script='sudo a', output=stdout)
    assert 'env PATH=$PATH sudo a' == get_new_command(command).script


# Generated at 2022-06-24 07:22:57.449933
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', ''))
    assert not match(Command('sudo tbd', ''))
    assert not match(Command('sudo', ''))


# Generated at 2022-06-24 07:23:01.925505
# Unit test for function match
def test_match():
    assert match(Command('sudo cuuuuuuuuuuuuuuuuu', 'sudo: cuuuuuuuuuuuuuuuuu: command not found\n'))
    assert not match(Command('sudo cuuuuuuuuuuuuuuuuu'))

# Generated at 2022-06-24 07:23:05.735112
# Unit test for function match
def test_match():
    assert not match(Command('sudo apt-get update', ''))
    assert match(Command('sudo fuck', 'fuck: command not found'))
    assert match(Command('sudo /usr/bin/fuck', 'fuck: command not found'))



# Generated at 2022-06-24 07:23:07.727042
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))


# Generated at 2022-06-24 07:23:09.948776
# Unit test for function get_new_command
def test_get_new_command():
    """Test get_new_command()"""
    from thefuck.rules.sudo_env_hack import get_new_command
    command = Command('sudo -v', 'sudo: -v: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" -v'

# Generated at 2022-06-24 07:23:15.018243
# Unit test for function match
def test_match():
    assert match(cls_obj(script='sudo ls', output="sudo: ls: command not found"))
    assert match(cls_obj(script='sudo ls', output="sudo: ls: No such file or directory"))
    assert not match(cls_obj(script='sudo ls'))


# Generated at 2022-06-24 07:23:17.868633
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    assert get_new_command(Command('sudo foobar', 'sudo: foobar: command not found', '')) == 'env "PATH=$PATH" foobar'

# Generated at 2022-06-24 07:23:19.673983
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudofuck') == 'sudo env "PATH=$PATH" fuck'

# Generated at 2022-06-24 07:23:21.779458
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo vim', 'sudo: vim: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:23:27.295849
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo vim'
    command = Command(script, 'sudo: vim: command not found')
    assert u'env "PATH=$PATH" vim' == get_new_command(command)

    script = 'sudo vim test.txt'
    command = Command(script, 'sudo: vim: command not found')
    assert u'env "PATH=$PATH" vim test.txt' == get_new_command(command)



# Generated at 2022-06-24 07:23:30.098422
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('ls'))

# Generated at 2022-06-24 07:23:32.135866
# Unit test for function match
def test_match():
    assert match(Command('sudo echo', None))
    assert not match(Command('sudo apt-get install', None))



# Generated at 2022-06-24 07:23:35.724337
# Unit test for function match
def test_match():
    assert match(Command('sudo date --date "1990-10-10"', 'sudo: date: command not found'))
    assert not match(Command('sudo date --date "1990-10-10"', 'sudo: date'))


# Generated at 2022-06-24 07:23:41.061249
# Unit test for function match
def test_match():
    assert match(Command('sudo xlsjfk', stderr='sudo: xlsjfk: command not found'))
    assert not match(Command('sudo su -', stderr='Usage: sudo -h | -K | -k | -V'))
    assert not match(Command('sudo xlsjfk', stderr='Usage: sudo -h | -K | -k | -V'))


# Generated at 2022-06-24 07:23:42.640208
# Unit test for function match
def test_match():
    assert (match(Command('sudo ll', 'sudo: ll: command not found'))) is not None


# Generated at 2022-06-24 07:23:45.078200
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('sudo test', stderr='sudo: test: command not found')) == 'env "PATH=$PATH" test'

# Generated at 2022-06-24 07:23:47.676858
# Unit test for function get_new_command
def test_get_new_command():
    command_name = 'ls'
    command = Command('sudo -u root ' + command_name + ' /foo', 'env: ls: No such file or directory')
    assert get_new_command(command) == 'sudo -u root env $PATH=/bin/ls /foo'

# Generated at 2022-06-24 07:23:49.955364
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'sudo: abc: command not found'))


# Generated at 2022-06-24 07:23:54.492841
# Unit test for function match
def test_match():
    # Test for true case
    output = "sudo: commandname: command not found"
    assert match(Command(script='sudo', output=output))

    # Test for false case
    output = "command not found"
    assert not match(Command(script='sudo', output=output))



# Generated at 2022-06-24 07:23:57.221338
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert which('sudo')
    assert match(Command('sudo foobar', '', 'sudo: foobar: command not found'))
    ass

# Generated at 2022-06-24 07:24:00.381479
# Unit test for function match
def test_match():
    assert(match(Command('sudo apt-get install abc',
                         'sudo: apt-get: command not found')))
    assert(not match(Command('sudo apt-get install abc',
                             'sudo: apt-get: command is found')))


# Generated at 2022-06-24 07:24:04.773867
# Unit test for function match
def test_match():
    user_command = 'sudo yum'
    alias_mock = mock.MagicMock()
    path_mock = mock.MagicMock(return_value='yum')
    with mock.patch('thefuck.rules.which', path_mock):
        assert match(user_command)

    alias_mock = mock.MagicMock()
    path_mock = mock.MagicMock(return_value=None)
    with mock.patch('thefuck.rules.which', path_mock):
        assert match(user_command) is None



# Generated at 2022-06-24 07:24:08.444019
# Unit test for function match
def test_match():
    # unit test for function match
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('echo $PATH', ''))
    assert not match(Command('sudo vim', ''))



# Generated at 2022-06-24 07:24:11.355368
# Unit test for function match
def test_match():
    assert match(Command('sudo test', 'sudo: test: command not found'))
    assert not match(Command('sudo test', 'command not found'))


# Generated at 2022-06-24 07:24:14.764978
# Unit test for function get_new_command
def test_get_new_command():
    command_name = "fuck"
    command = Command(script="sudo " + command_name, output="sudo: fuck: command not found",
        stderr='', stdout='')
    assert get_new_command(command) == u'sudo env "PATH=$PATH" fuck'

# Generated at 2022-06-24 07:24:18.468721
# Unit test for function match
def test_match():
    assert match(Command("sudo thefuck",
                         "sudo: thefuck: command not found"))
    assert match(Command("ls /root",
                         "ls: cannot open directory /root: Permission denied"))



# Generated at 2022-06-24 07:24:21.305001
# Unit test for function match
def test_match():
    assert match(Command('sudo not_found', ''))
    assert not match(Command('sudo uname', ''))


# Generated at 2022-06-24 07:24:28.799902
# Unit test for function get_new_command
def test_get_new_command():
    command = ScriptInfo(script='sudo git',
                         stderr='sudo: git: command not found',
                         environ={
                             'PATH': '/usr/local/bin:/usr/bin:/bin:/sbin'})
    assert get_new_command(command) == "env PATH=/usr/local/bin:/usr/bin:/bin:/sbin git"

    command = ScriptInfo(script='echo "sudo git"',
                         stderr='"sudo: git: command not found"',
                         environ={
                             'PATH': '/usr/local/bin:/usr/bin:/bin:/sbin'})
    assert get_new_command(command) == "echo \"env \"PATH=$PATH\" git\""

# Generated at 2022-06-24 07:24:35.223633
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    shell = Bash()
    new_command = get_new_command(
        Command('sudo apt-get install',
                'sudo: apt-get: command not found',
                ''))
    assert 'sudo env "PATH=$PATH" apt-get install' == new_command
    assert 'env' not in shell.get_alias('sudo')

# Generated at 2022-06-24 07:24:43.473357
# Unit test for function match
def test_match():
	# Check for True(if any)
	def _match(test):
	    command = Command(script=test,
	                      output="sudo: add-apt-repository: command not found")
	    assert match(command) == which(_get_command_name(command))
	_match('sudo add-apt-repository ppa:ubuntu-wine/ppa')
	# Check for False
	def _no_match(test):
	    command = Command(script=test,
	                      output="sudo: add-apt-repository: command not found")
	    assert not match(command)
	_no_match('sudo apt-get update')

# Generated at 2022-06-24 07:24:46.113416
# Unit test for function match
def test_match():
    assert match(Command('sudo abcd', 'sudo: abcd: command not found\n'))
    assert not match(Command('sudo abcd', 'sudo: abcd: command not exist\n'))


# Generated at 2022-06-24 07:24:50.298489
# Unit test for function match
def test_match():
    assert match(Command('sudo abcdef', 'sudo: abcdef: command not found\n'))
    assert not match(Command('sudo abcdef', 'sudo: abcdef: not found\n'))
    assert not match(Command('sudo abcdef', 'sudo: abcdef: command found\n'))



# Generated at 2022-06-24 07:24:55.270641
# Unit test for function match
def test_match():
    # Test for function _get_command_name
    assert _get_command_name(Command('sudo apt-get', '')) == 'apt-get'

    # Test for function match
    assert match(Command('sudo apt-get', '')) == False
    assert match(Command('sudo apt-get', 'sudo: apt-get: command not found')) != False


# Generated at 2022-06-24 07:25:01.087867
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('sudo ls')) == 'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo apt-get install vim')) == 'env "PATH=$PATH" apt-get install vim'
    assert get_new_command(Command('sudo su vim')) == 'env "PATH=$PATH" su vim'


# Generated at 2022-06-24 07:25:09.254709
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('echo hello world', '', '')) == 'sudo echo hello world'
    assert get_new_command(Command('sudo echo hello world', '', '')) == 'sudo echo hello world'
    assert get_new_command(Command('sudo rm -rf /tmp/does/not/exist', '', '')) == 'sudo env "PATH=$PATH" rm -rf /tmp/does/not/exist'
    assert get_new_command(Command('sudo rm -rf /tmp/does/not/exist', '', 'sudo: rm: command not found')) == 'sudo env "PATH=$PATH" rm -rf /tmp/does/not/exist'

# Generated at 2022-06-24 07:25:12.731740
# Unit test for function get_new_command
def test_get_new_command():
    script = "sudo ls"
    new_cmd = get_new_command(script)

# Generated at 2022-06-24 07:25:17.926288
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert (get_new_command(Command('sudo f', 'sudo: f: command not found'))
            == u'env "PATH=$PATH" f')
    assert (get_new_command(Command('sudo f', u'sudo: f: command not found',
                                    'sudo f'))
            == u'env "PATH=$PATH" f')

# Generated at 2022-06-24 07:25:22.099214
# Unit test for function get_new_command
def test_get_new_command():
    print ("Test case 1: ")
    command = Command('sudo apt-get purge kubectl', 'sudo: apt-get: command not found')
    print (get_new_command(command))
    print ("Test case 2: ")
    command = Command('sudo apt-get purge', 'sudo: apt-get: command not found')
    print (get_new_command(command))

# Generated at 2022-06-24 07:25:23.540075
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("sudo apt-get install") == "env \"PATH=$PATH\" apt-get install"

# Generated at 2022-06-24 07:25:32.725600
# Unit test for function match

# Generated at 2022-06-24 07:25:35.575697
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo lskdjfskjd', 'sudo: lskdjfskjd: command not found')) == 'env "PATH=$PATH" lskdjfskjd'

# Generated at 2022-06-24 07:25:37.178954
# Unit test for function match
def test_match():
    assert match(Command('sudo apt install',
                         output='sudo: apt: command not found'))


# Generated at 2022-06-24 07:25:39.217774
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:25:43.850360
# Unit test for function get_new_command
def test_get_new_command():
    script = u'sudo ls -l'
    command = type('Obj', (object, ), {'script': script,
                                       'output': u'sudo: ls: command not found'})
    new_command = get_new_command(command)
    assert u'env "PATH=$PATH" ls' == new_command

# Generated at 2022-06-24 07:25:46.404764
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    assert get_new_command('sudo env "PATH=$PATH" find')\
        == 'sudo find'

# Generated at 2022-06-24 07:25:50.359870
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install fakeroot',
                         '''sudo: apt-get: command not found'''))
    assert not match(Command('sudo apt-get install fakeroot',
                             '''E: Could not open lock file /var/lib/dpkg/lock - open (2: No such file or directory)
E: Unable to lock the administration directory (/var/lib/dpkg/), are you root?'''))



# Generated at 2022-06-24 07:25:54.319803
# Unit test for function match
def test_match():
    assert match(Command('sudo foo', 'sudo: foo: command not found')) == which('foo')
    assert match(Command('fooaddd', 'sudo: fooaddd: command not found')) == None


# Generated at 2022-06-24 07:25:56.278356
# Unit test for function match
def test_match():
    command = Command('sudo apt-get install vim')
    assert match(command)



# Generated at 2022-06-24 07:25:59.209384
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo pip', 'sudo: pip: command not found')) ==  'env "PATH=$PATH" pip'


# Generated at 2022-06-24 07:26:02.401917
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get update', 'sudo: apt-get: command not found')) == u'env "PATH=$PATH" apt-get update'


enabled_by_default = True

# Generated at 2022-06-24 07:26:07.558063
# Unit test for function match
def test_match():
    cmd = Command('sudo ls', 'sudo: ls: command not found', '')
    assert match(cmd)
    cmd = Command('sudo ls -l', 'sudo: ls: command not found', '')
    assert match(cmd)
    cmd = Command('sudo ls', 'sudo: lss: command not found', '')
    assert not match(cmd)


# Generated at 2022-06-24 07:26:09.367342
# Unit test for function match
def test_match():
    assert match(Command('sudo foobar1111', 'sudo: foobar1111: command not found'))


# Generated at 2022-06-24 07:26:11.093935
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get install fish')) == u'env $PATH apt-get install fish'

# Generated at 2022-06-24 07:26:15.344671
# Unit test for function get_new_command
def test_get_new_command():
    script = u"sudo echo 'hi'"
    command = type('', (object,), {'script': script, 'output': u"sudo: echo: command not found"})
    assert get_new_command(command) == u'env "PATH=$PATH" echo \'' + script + u'\''

# Generated at 2022-06-24 07:26:22.280443
# Unit test for function get_new_command
def test_get_new_command():
    assert ('env "PATH=/home/jtaylor/bin:/home/jtaylor/.local/bin'
            ':/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin'
            ':/sbin:/bin:/usr/games:/usr/local/games" something'
            ' --switch') == get_new_command(
        Command('sudo something --switch',
                'sudo: something: command not found\r\n'))

# Generated at 2022-06-24 07:26:25.063349
# Unit test for function match
def test_match():
    assert match(Command('sudo echo', '')) == False
    assert match(Command('sudo echo', 'sudo: echo: command not found')) == True
    assert match(Command('echo', 'sudo: echo: command not found')) == False



# Generated at 2022-06-24 07:26:27.570040
# Unit test for function get_new_command
def test_get_new_command():
    script = u"sudo doing command not found"
    command = Command(script, u"sudo: doing: command not found")
    assert get_new_command(command) == u'env "PATH=$PATH" doing'

# Generated at 2022-06-24 07:26:35.881151
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    class Command(object):
        def __init__(self, script, output):
            self.script = script
            self.output = output
    assert get_new_command(Command('sudo su', 'sudo: su: command not found')) == 'env "PATH=$PATH" su'
    assert get_new_command(Command('sudo', 'sudo: : command not found')) == 'env "PATH=$PATH" '

# Generated at 2022-06-24 07:26:42.716785
# Unit test for function get_new_command
def test_get_new_command():

    from thefuck.types import Command

    command_list = [Command("sudo dockerd", "sudo: dockerd: command not found"),
                    Command("sudo nginx", "sudo: nginx: command not found"),
                    Command("sudo dir", "sudo: dir: command not found")]

    new_command_list = ["env \"PATH=$PATH\" dockerd",
                        "env \"PATH=$PATH\" nginx",
                        "env \"PATH=$PATH\" dir"]

    for command, new_command in zip(command_list, new_command_list):
        assert get_new_command(command) == new_command

# Generated at 2022-06-24 07:26:47.133214
# Unit test for function match
def test_match():
    assert not match(Command('sudo _command_', ''))
    assert not match(Command('sudo _command_', '', stderr='sudo: _command_: command not found'))
    assert match(Command('sudo _command_', '', stderr='sudo: _command_: command not found'))


# Generated at 2022-06-24 07:26:48.466336
# Unit test for function get_new_command

# Generated at 2022-06-24 07:26:52.612326
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found', ''))
    assert match(Command('sudo ls', 'sudo: vim: command not found', ''))
    assert not match(Command('sudo vim', 'sudo: vim: command not found', ''))


# Generated at 2022-06-24 07:27:04.760042
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get', 'sudo: apt-get: command not found'))
    # Test for english output
    assert match(Command('sudo apt-get', 'sudo: apt-get: command not found'))
    # Test for french output
    assert match(Command('sudo apt-get', 'sudo: apt-get: commande introuvable'))
    # Test for german output
    assert match(Command('sudo apt-get', 'sudo: apt-get: Kommando nicht gefunden'))
    # Test for spanish output
    assert match(Command('sudo apt-get' , 'sudo: apt-get: comando no encontrado'))
    assert not match(Command('sudo apt-get', 'usage: sudo [-D level] -h | -K | -k | -V'))

#

# Generated at 2022-06-24 07:27:09.550984
# Unit test for function match
def test_match():
    assert which("which")
    command = "sudo:which:command not found"
    assert match(Command("sudo which", command))

    assert not which("not_installed_command")
    command = "sudo:not_installed_command:command not found"
    assert not match(Command("sudo not_installed_command", command))


# Generated at 2022-06-24 07:27:12.882124
# Unit test for function match
def test_match():
    assert match(Command('sudo vim',
                         'sudo: vim: command not found'))
    assert not match(Command('vim', ''))
    assert not match(Command('sudo vim', ''))


# Generated at 2022-06-24 07:27:17.518047
# Unit test for function match
def test_match():
    assert match(Command('sudo ls',
                     'sudo: ls: command not found'))
    assert match(Command('sudo -s',
                     'sudo: -s: command not found'))
    assert not match(Command('sudo ls', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 07:27:22.330003
# Unit test for function get_new_command
def test_get_new_command():
    user_input = "sudo apt-get install foobar"
    from thefuck.rules.command_not_found import get_new_command
    output = "sudo: apt-get: command not found"
    assert(get_new_command(Command(user_input, output)) == "env \"PATH=$PATH\" apt-get install foobar")

# Generated at 2022-06-24 07:27:24.711373
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo ls')
    command.output = "sudo: ls: command not found"
    assert get_new_command(command) == 'env "PATH=$PATH" sudo ls'

# Generated at 2022-06-24 07:27:28.062006
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('vim', ''))
    assert not match(Command('sudo vim', 'sudo: vim: not found'))


# Generated at 2022-06-24 07:27:31.015263
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo su') == u"env \"PATH=$PATH\" su"
    assert get_new_command('sudo ls') == u"env \"PATH=$PATH\" ls"

# Generated at 2022-06-24 07:27:34.115928
# Unit test for function match
def test_match():
    script = Script('sudo notfound', 'sudo: notfound: command not found')
    assert match(script)

    script = Script('echo hello', 'echo hello')
    assert not match(script)


# Generated at 2022-06-24 07:27:36.289780
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("sudo lalala") == "env 'PATH=$PATH' lalala")

# Generated at 2022-06-24 07:27:40.821751
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found')) == \
        u'env "PATH=$PATH" ls'
    assert get_new_command(Command('sudo lss', 'sudo: lss: command not found')) == \
        u'env "PATH=$PATH" lss'

# Generated at 2022-06-24 07:27:44.821051
# Unit test for function match
def test_match():
    # It matches when command not found in output
    assert match(Command('sudo hello', 'sudo: hello: command not found'))
    # It doesn't match when command not found in output
    assert not match(Command('sudo hello'))

# Generated at 2022-06-24 07:27:47.442075
# Unit test for function match
def test_match():
    assert match(Command('sudo echo', '', 'sudo: echo: command not found'))
    assert not match(Command('sudo echo', '', 'sudo: echo: command found'))



# Generated at 2022-06-24 07:27:52.193210
# Unit test for function match
def test_match():
    assert not match(Command('', ''))
    assert not match(Command('sudo ls', ''))
    assert not match(Command('sudo ls', 'sudo: ls: command not found'))
    assert match(Command('sudo ls', 'sudo: haha: command not found'))


# Generated at 2022-06-24 07:27:56.575129
# Unit test for function match
def test_match():
    assert match(Command('sudo dpkg -i package.deb', 'sudo: dpkg: command not found'))
    assert not match(Command('sudo dpkg -i package.deb', 'sudo: dpkg: command not found', error=True))
    assert not match(Command('ls -l', '', error=True))


# Generated at 2022-06-24 07:27:59.075690
# Unit test for function match
def test_match():
    assert which('echo')
    assert not match(Command('sudo vim', 'sudo: vim: command not found'))
    assert match(Command('sudo echo', 'sudo: echo: command not found'))



# Generated at 2022-06-24 07:28:00.123037
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo command').script == 'env "PATH=$PATH" command'

# Generated at 2022-06-24 07:28:03.160326
# Unit test for function match
def test_match():
    command = Command('sudo vi',
        output = ('sudo: vi: command not found\n'))
    assert match(command)
