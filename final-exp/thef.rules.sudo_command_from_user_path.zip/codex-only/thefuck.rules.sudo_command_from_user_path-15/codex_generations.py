

# Generated at 2022-06-24 07:18:06.227492
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo man',
                                   'sudo: man: command not found\n', '')) == 'env "PATH=$PATH" man'

# Generated at 2022-06-24 07:18:08.015300
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo whoami') == u'env "PATH=$PATH" whoami'



# Generated at 2022-06-24 07:18:10.121331
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install thefuck',
                         'sudo: apt-get: command not found'))
    asser

# Generated at 2022-06-24 07:18:13.212427
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found', None))
    assert not match(Command(
        'sudo ls', 'sudo: not found', None))



# Generated at 2022-06-24 07:18:16.902122
# Unit test for function match
def test_match():
    # This is the command that will be tested.
    command = type('obj', (object,), {'script': 'sudo su', 'output': 'sudo: su: command not found'})
    assert match(command)


# Generated at 2022-06-24 07:18:20.749945
# Unit test for function match
def test_match():
    # If sudo: cd: command not found in command.output
    assert match(Command('sudo cd ~/ham', '', 'sudo: cd: command not found'))
    # Else if sudo: cd: command not found not in command.output
    assert not match(Command('sudo cd ~/ham', '', ''))

# Generated at 2022-06-24 07:18:22.567142
# Unit test for function match
def test_match():
    assert match(Command('echo test', 'echo test')) == which('echo')


# Generated at 2022-06-24 07:18:24.628224
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo missing_command', 'sudo: missing_command: command not found\n')) == 'env "PATH=$PATH" missing_command'

# Generated at 2022-06-24 07:18:28.070148
# Unit test for function get_new_command
def test_get_new_command():
	command_output = "sudo: /bin/mount: Command not found"
	command = Command('sudo /bin/mount', command_output)
	assert "env 'PATH=$PATH' /bin/mount" == get_new_command(command)



# Generated at 2022-06-24 07:18:35.581852
# Unit test for function get_new_command
def test_get_new_command():
    # mock the "which" function in this test
    def mock_which(cmd):
        return cmd

    old_which = which
    which = mock_which

    script = 'sudo cd ~'
    output = 'sudo: cd: command not found'

    command = Command(script, output)
    new_command = get_new_command(command)

    assert new_command == 'env "PATH=$PATH" sudo cd ~'

    which = old_which
    # End of mock the "which" function in this test

enabled_by_default = True

# Generated at 2022-06-24 07:18:39.434321
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_PATH import get_new_command
    from thefuck.types import Command
    assert get_new_command(Command('sudo ls',
                                                 'sudo: ls: command not found')) == Command('env "PATH=$PATH" ls',
            'sudo: ls: command not found')

# Generated at 2022-06-24 07:18:42.885031
# Unit test for function match
def test_match():
    assert match(Command('sudo hello world', 'sudo: hello: command not found'))
    assert not match(Command('sudo hello world', 'hello world'))
    assert match(Command('sudo hello world',
                         'sudo: hello world: command not found'))


# Generated at 2022-06-24 07:18:44.630347
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo kak', '\nsudo: kak: command not found')) == 'env "PATH=$PATH" kak'

# Generated at 2022-06-24 07:18:47.365384
# Unit test for function match
def test_match():
    assert match(Command('sudo bash', 'sudo: bash: command not found'))
    assert not match(Command('su -c id', ''))



# Generated at 2022-06-24 07:18:50.892782
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import shell
    assert get_new_command(shell.and_('sudo apt', 'sudo: apt: command not found')) == 'env "PATH=$PATH" apt'

# Generated at 2022-06-24 07:18:54.762194
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls hello', 'sudo: ls: command not found\n')) == 'sudo env "PATH=$PATH" ls hello'
    assert get_new_command(Command('sudo ls', 'sudo: ls: command not found\n')) == 'sudo env "PATH=$PATH" ls'

# Tests for match function

# Generated at 2022-06-24 07:19:00.559282
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get', '', '')) is None
    assert match(Command('sudo apt', '', 'sudo: apt: command not found'))
    assert match(Command('sudo apt-get update', '', '')) is None
    assert match(Command('sudo apt-get update', '', 'sudo: apt-get: command not found'))


# Generated at 2022-06-24 07:19:04.993042
# Unit test for function match
def test_match():
    # If output has command not found
    assert match(Command('sudo nano', 'sudo: nano: command not found'))
    # If command is not sudo
    assert not match(Command('nano', 'sudo: nano: command not found'))
    # If output has not command not found
    assert not match(Command('sudo nano', 'sudo: unknown command'))

# Generated at 2022-06-24 07:19:13.759307
# Unit test for function match
def test_match():
    assert match(Command('sudo echo abc', 'sudo: echo: command not found\n'))
    assert match(Command('sudo echo abc', 'sudo: echo: No such file or directory\n'))
    assert not match(Command('sudo echo abc', 'sudo: echo: something else\n'))
    assert not match(Command('sudo echo abc', 'sudo: echo: command not found\n'))
    assert not match(Command('sudo echo abc', 'sudo: echo: something else\n'))
    assert match(Command('sudo echo abc', 'sudo: echo: No such file or directory\n'))
    assert not match(Command('sudo echo abc', 'sudo: echo: something else\n'))



# Generated at 2022-06-24 07:19:16.472966
# Unit test for function get_new_command
def test_get_new_command():
    script = "sudo env 'PATH=$PATH' echo test"
    command = Command(script, 'env: sudo: No such file or directory\r\n')
    assert get_new_command(command) == script

# Generated at 2022-06-24 07:19:20.266502
# Unit test for function match
def test_match():
    assert match(Command('sudo a', 'sudo: a: command not found'))
    assert not match(Command('sudo a', 'sudo: a: command not bad'))
    assert not match(Command('sudo a'))
    assert not match(Command('sudo apt-get install python-thefuck'))


# Generated at 2022-06-24 07:19:22.465256
# Unit test for function get_new_command
def test_get_new_command():
    expected = u"env 'PATH=$PATH' sudo echo"
    assert get_new_command("sudo echo") == expected

# Generated at 2022-06-24 07:19:28.274990
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo python /home/abed/lol.py') == 'sudo env "PATH=$PATH" python /home/abed/lol.py'
    assert get_new_command('sudo ok_kk ') == 'sudo env "PATH=$PATH" ok_kk'
    assert get_new_command('sudo --not-ok-k ') == 'sudo --not-ok-k'

# Generated at 2022-06-24 07:19:29.610128
# Unit test for function match
def test_match():
    assert match(Command('sudo meh', 'sudo: meh: command not found'))


# Generated at 2022-06-24 07:19:33.463966
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Cmd', (object,),
    {u'script': u'sudo rm -rf /',
     u'output': u'sudo: rm: command not found'})
    assert get_new_command(command) == 'env "PATH=$PATH" rm -rf /'

# Generated at 2022-06-24 07:19:37.185866
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    assert get_new_command(Bash('sudo apt-get install',
                                'sudo: apt-get: command not found')) \
        == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-24 07:19:38.957510
# Unit test for function match
def test_match():
    assert match(Command('sudo xdg-open hello.txt', ''))
    assert not match(Command('sudo ls', ''))


# Generated at 2022-06-24 07:19:40.839785
# Unit test for function match
def test_match():
    assert match(Command(script='sudo sduo', output='sduo: command not found'))



# Generated at 2022-06-24 07:19:44.520847
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo import get_new_command
    from thefuck.types import Command
    assert get_new_command(Command('sudo cd /usr/bin',
                                   'sudo: cd: command not found')) == 'env "PATH=$PATH" cd /usr/bin'

# Generated at 2022-06-24 07:19:49.430932
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_command_not_found import get_new_command
    command = Command('./install.sh', 'sudo: lspci: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" ./install.sh'

# Generated at 2022-06-24 07:19:53.888641
# Unit test for function match
def test_match():
    assert match(
        Command('sudo apt-get upadte', output='sudo: apt-get: command not found'))
    assert not match(
        Command('sudo apt-get update', output='Get:1 http://archive.ubuntu.com/ubuntu xenial InRelease [247 kB]\n0% [1 InRelease gpgv 247 kB] [Waiting for headers]'))

# Generated at 2022-06-24 07:19:58.931403
# Unit test for function match
def test_match():
    with patch('thefuck.rules.sudo.which', return_value='/usr/bin/ls'):
        assert match(Command('sudo ls', output='sudo: ls: command not found'))
        assert not match(Command('sudo ls', output='foo'))

    with patch('thefuck.rules.sudo.which', return_value=None):
        assert not match(Command('sudo ls', output='sudo: ls: command not found'))


# Generated at 2022-06-24 07:20:04.863689
# Unit test for function match
def test_match():
    from thefuck.types import Command, CorrectedCommand
    assert match(Command('sudo xrandr', 'sudo: xrandr: command not found'))
    assert not match(Command('sudo', ''))
    assert not match(Command('sudo xrandr', whoops='ERROR'))
    assert not match(Command('sudo xrandr', ''))



# Generated at 2022-06-24 07:20:08.873911
# Unit test for function get_new_command
def test_get_new_command():
    assert which('ls')
    assert not which('ll')
    command = Command('sudo ll', 'sudo: ll: command not found')
    assert get_new_command(command) == 'sudo env "PATH=$PATH" ll'



# Generated at 2022-06-24 07:20:15.752588
# Unit test for function match
def test_match():
    def default_match(output):
        return True
    from thefuck.specific.sudo import match
    assert match(Command('sudo ls', 'sudo: ls: command not found',
                         default_match))
    assert match(Command('sudo ls -la', 'sudo: ls: command not found',
                         default_match))
    assert not match(Command('sudo ls', 'E: command not found',
                             default_match))
    assert not match(Command('sudo apt-get', 'sudo: apt-get: command not found',
                             default_match))


# Generated at 2022-06-24 07:20:17.819676
# Unit test for function match
def test_match():
    assert match(Command('sudo htop', ''))
    assert not match(Command('htop', '', ''))



# Generated at 2022-06-24 07:20:21.268992
# Unit test for function match
def test_match():
    assert not match(Command('sudo sudo -h', ''))
    assert not match(Command('sudo ls', ''))
    assert match(Command('sudo sudo -h', 'sudo: sudo: command not found'))
    assert match(Command('sudo ls', 'sudo: ls: command not found'))


# Generated at 2022-06-24 07:20:25.326597
# Unit test for function match
def test_match():
    # assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 07:20:28.862091
# Unit test for function match
def test_match():
    assert match(Command('sudo echo',
                         'sudo echo\n'
                         'sudo: echo: command not found\n'))
    assert not match(Command('sudo echo', 'echo\n'))
    assert not match(Command('sudo echo', 'sudo: echo: command not found\n'))


# Generated at 2022-06-24 07:20:30.419592
# Unit test for function match
def test_match():
    # Test case where command name is found
    # Test case where command name is not found
    return True


# Generated at 2022-06-24 07:20:33.365948
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command(script = 'sudo sl',
                                          output = "sudo: sl: command not found"))
    assert new_command == u'env "PATH=$PATH" sl'


# Generated at 2022-06-24 07:20:38.517761
# Unit test for function get_new_command
def test_get_new_command():
    """
    This tests the output of the get_new_command function.
    """

    # This will simulate the output of the command
    # to test the function.
    output = ["sudo: grep: command not found"]
    on = len(output)

    # Simulate the command
    command = Command(script="sudo grep -r hello *", output = output)

    # This is the expected output, with the new command.
    expected = "sudo env \"PATH=$PATH\" grep -r hello *"

    # Assert that the output of the function
    # is equal to the expected output.
    assert get_new_command(command) == expected


# Generated at 2022-06-24 07:20:41.336425
# Unit test for function match
def test_match():
    assert match(Command(script='sudo apt-get install flac',
                         output='sudo: apt-get: command not found'))
    assert match(Command(script='sudo apt-get -f install',
                         output='sudo: apt-get: command not found'))
    assert not match(Command(script='sudo apt-get -f install',
                             output='sudo: apt-get: not found'))

# Generated at 2022-06-24 07:20:43.595145
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: ls: command not found'))
    assert not match(Command('sudo ls', 'ls'))


# Generated at 2022-06-24 07:20:47.464813
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import BashShell
    command = BashShell().from_raw_script('sudo something_that_does_not_exist')
    assert get_new_command(command) == 'env "PATH=$PATH" something_that_does_not_exist'

# Generated at 2022-06-24 07:20:48.911615
# Unit test for function get_new_command
def test_get_new_command():
    output = u"sudo: pip: command not found"
    new_command = get_new_command("sudo pip install --upgrade pip", output)
    assert "env \"PATH=$PATH\"" in new_command

# Generated at 2022-06-24 07:20:54.398935
# Unit test for function get_new_command
def test_get_new_command():
    command_to_test=Command('sudo mv file.txt /dst/file.txt', 'sudo: mv: command not found')
    assert get_new_command(command_to_test).script == u'sudo env "PATH=$PATH" mv file.txt /dst/file.txt'


# Generated at 2022-06-24 07:20:56.507122
# Unit test for function match
def test_match():
    assert match(Command('sudo bla-bla', ''"sudo: bla-bla: command not found"))


# Generated at 2022-06-24 07:20:58.597177
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', 'sudo: abc: command not found'))
    assert which('sudo')


# Generated at 2022-06-24 07:21:04.050832
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo touch /file',
                                   'sudo: touch: command not found')) == \
        'env "PATH=$PATH" sudo env "PATH=$PATH" touch /file'
    assert get_new_command(Command('sudo touch /file',
                                   'sudo: env: command not found')) == \
        'env "PATH=$PATH" sudo env "PATH=$PATH" touch /file'



# Generated at 2022-06-24 07:21:07.134906
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo echo This command is not found')
    new_command = get_new_command(command)
    assert new_command == 'env "PATH=$PATH" echo This command is not found'

# Generated at 2022-06-24 07:21:09.639554
# Unit test for function match
def test_match():
    assert match(Command('sudo not_found_command', 'sudo: not_found_command: command not found'))
    assert not match(Command('sudo command', ''))


# Generated at 2022-06-24 07:21:10.991884
# Unit test for function match
def test_match():
    assert match(Command('sudo ifconfig', 'sudo: ifconfig: command not found'))



# Generated at 2022-06-24 07:21:13.193654
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo apt-get install', 'sudo: apt-get: command not found')
    assert get_new_command(command).script == 'env "PATH=$PATH" apt-get install'

# Generated at 2022-06-24 07:21:17.487401
# Unit test for function match
def test_match():
    assert not match(Command('sudo test', '', ''))
    assert not match(Command('sudo echo test', '', ''))
    assert match(Command('sudo test', 'sudo: test: command not found\n', ''))
    assert match(
        Command('sudo echo test', 'sudo: echo: command not found\n', ''))
    assert not match(Command('sudo echo test', 'sudo: echo: command not fo', ''))


# Generated at 2022-06-24 07:21:22.256334
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("foo", "sudo: foo: command not found")) == "foo"
    assert get_new_command(Command("foo", "sudo: bar: command not found")) == "foo"
    assert get_new_command(Command("sudo foo", "sudo: foo: command not found")) == "sudo env \"PATH=$PATH\" foo"
    assert get_new_command(Command("sudo foo bar", "sudo: foo: command not found")) == "sudo env \"PATH=$PATH\" foo bar"

# Generated at 2022-06-24 07:21:26.132195
# Unit test for function match
def test_match():
    assert not match(Command('sudo'))
    assert match(Command('sudo ttjfejtjr',
                         output='sudo: ttjfejtjr: command not found'))
    assert not match(Command('sudo ls', output='total 10'))


# Generated at 2022-06-24 07:21:28.650528
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('sudo echo', 'error', 'error'))
    assert new_command == 'env "PATH=$PATH" echo'

# Generated at 2022-06-24 07:21:31.590324
# Unit test for function match
def test_match():
    assert bool(match(Command('sudo apt-get update', ''))) is False
    assert bool(match(Command('sudo apt-get update',
                              'sudo: apt-get: command not found'))) is True



# Generated at 2022-06-24 07:21:40.368759
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    from thefuck.shells import Shell

    shell = Shell()
    shell.system_prefix = '/usr/local/bin:/usr/bin:/bin'
    shell.env = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'EDITOR': 'vim'}
    shell.getoutput = lambda x: 'sudo: vim: command not found'

    assert get_new_command(shell.from_script('sudo vim')) == 'env "PATH=/usr/local/bin:/usr/bin:/bin" vim'

# Generated at 2022-06-24 07:21:43.478924
# Unit test for function match
def test_match():
    """
    Unit test for match
    """
    assert match('sudo apt upgrade')
    assert not match('sudo apt-get upgrade')
    assert not match('sudo apt-get upgrade foo')


# Generated at 2022-06-24 07:21:46.579730
# Unit test for function match
def test_match():
    assert which('ls')
    assert _get_command_name(Command('sudo ls', 'sudo: ls: command not found\n')) == 'ls'
    assert not match(Command('sudo ls', ''))


# Generated at 2022-06-24 07:21:50.744814
# Unit test for function match
def test_match():
    assert match(Command('sudo ls', 'sudo: apt: command not found'))
    assert not match(Command('sudo apt', 'sudo: apt: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command found'))


# Generated at 2022-06-24 07:21:56.395150
# Unit test for function get_new_command
def test_get_new_command():
    command_string = "sudo: no tty present and no askpass program specified"
    command = Command(command_string, None)
    assert get_new_command(command) == command_string
    command_string = "sudo: /sbin/iptables-save: command not found"
    command = Command(command_string, None)
    assert get_new_command(command) == "sudo env PATH=$PATH /sbin/iptables-save"

# Generated at 2022-06-24 07:21:58.918120
# Unit test for function match
def test_match():
    assert match(Command(script = 'sudo python -V',
                         output = 'sudo: python: command not found'))


# Generated at 2022-06-24 07:22:01.691505
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    script = 'sudo ls'
    assert get_new_command(Command(script, 'sudo: ls: command not found\n')) == 'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:22:04.246022
# Unit test for function match
def test_match():
    assert match(Command('sudo command', ''))
    assert not match(Command('command', ''))
    assert not match(Command('sudo command', 'command not found'))


# Generated at 2022-06-24 07:22:08.282315
# Unit test for function match
def test_match():
    command_name = which('ls')  # Assumes 'ls' is always in path
    command = Command('sudo ' + command_name, 
                      'sudo: ls: command not found')
    assert match(command)
    assert not match(Command('sudo ' + command_name))


# Generated at 2022-06-24 07:22:13.766959
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install pkg-name', ''))
    assert not match(Command('sudo apt-get install pkg-name', '',
                             '/bin/bash', '', ''))
    assert not match(Command('apt-get install pkg-name', ''))
    assert not match(Command('sudo apt-get update', ''))


# Generated at 2022-06-24 07:22:15.799507
# Unit test for function match
def test_match():
    assert match(Command('sudo abc', u''))
    assert not match(Command('sudo apt-get install xyz', ''))


# Generated at 2022-06-24 07:22:20.879338
# Unit test for function match
def test_match():
    # Test true
    assert match(Command('sudo gedit', 'sudo: gedit: command not found'))
    #Test false 
    assert not match(Command('sudo gedit'))
    assert not match(Command('sudo gedit', ''))
    assert not match(Command('sudo gedit', 'sudo: command not found'))


# Generated at 2022-06-24 07:22:25.675290
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    command = Command(script=u'sudo ls')
    command.output = u'sudo: ls: command not found'

    assert get_new_command(command) == u'env "PATH=$PATH" sudo ls'

# Generated at 2022-06-24 07:22:28.553670
# Unit test for function match
def test_match():
    assert match(Command("sudo ls", "sudo: ls: command not found"))
    assert not match(Command("ls", "sudo: ls: command not found"))


# Generated at 2022-06-24 07:22:30.833848
# Unit test for function match
def test_match():
    command = type('Command', (), {'output': 'sudo: apt-get: command not found'})

    assert match(command) == which('apt-get')



# Generated at 2022-06-24 07:22:32.514733
# Unit test for function match
def test_match():
    match_output = match(Command('sudo test',
                                 'sudo: test: command not found'))
    assert match_output == True


# Generated at 2022-06-24 07:22:34.717708
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("sudo firefox") == "env 'PATH=$PATH' firefox"

# Generated at 2022-06-24 07:22:44.562302
# Unit test for function get_new_command
def test_get_new_command():
    # Commands that should be tested
    test_command1 = Command('sudo ping localhost', '', 'sudo: ping: command not found')
    test_command2 = Command('sudo ls -l', '', 'sudo: ls: command not found')
    test_command3 = Command('sudo vim xxx', '', 'sudo: vim: command not found')
    test_command4 = Command('sudo minicom', '', 'sudo: minicom: command not found')

    new_command1 = get_new_command(test_command1)
    new_command2 = get_new_command(test_command2)
    new_command3 = get_new_command(test_command3)
    new_command4 = get_new_command(test_command4)

    # Verify that the function get_new_command()
    # works as

# Generated at 2022-06-24 07:22:47.451910
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('sudo ll', 'sudo: ll: command not found'))
    assert result == u'sudo env "PATH=$PATH" ll'

# Generated at 2022-06-24 07:22:50.112487
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo ls', output='sudo: ls: command not found')) == \
        'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:22:54.366751
# Unit test for function match
def test_match():
    """
    Unit test for function match
    """
    # Case 1: command not found
    command = Command('sudo ls', '', 'sudo: ls: command not found\n')
    assert match(command)

    # Case 2: no command not found
    command1 = Command('sudo ls')
    assert not match(command1)

# Generated at 2022-06-24 07:22:57.490630
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("sudo git fetch --all", "sudo: git: command not found")
    assert get_new_command(command) == "env \"PATH=$PATH\" git fetch --all"

# Generated at 2022-06-24 07:22:58.659225
# Unit test for function match
def test_match():
    assert match(Command('sudo echo'))



# Generated at 2022-06-24 07:23:01.270171
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo pip', 'sudo: pip: command not found')) == u'env "PATH=$PATH" pip'

# Generated at 2022-06-24 07:23:01.985209
# Unit test for function match
def test_match():
    asser

# Generated at 2022-06-24 07:23:04.062275
# Unit test for function match
def test_match():
    assert match(Command('sudo test', 'sudo: test: command not found'))


# Generated at 2022-06-24 07:23:06.897879
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo env "PATH=$PATH" foo'
    command = Command(script, 'sudo: baz: command not found')
    assert get_new_command(command) == script

# Generated at 2022-06-24 07:23:15.627164
# Unit test for function match
def test_match():
    assert match(Command('sudo exec /root/test_file',
                         'sudo: exec: command not found\n'))

    assert match(Command('sudo -u nobody exec /root/test_file',
                         'sudo: -u: command not found\n'))

    assert match(Command('sudo -s "echo 1234"',
                         'sudo: test: command not found\n'))

    assert not match(Command('sudo chown root:root /etc/passwd',
                             'chown: changing ownership of ‘/etc/passwd’: Operation not permitted\n'))


# Generated at 2022-06-24 07:23:17.509589
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo update-rc.d default-start 23') == 'sudo env "PATH=$PATH" update-rc.d default-start 23'

# Generated at 2022-06-24 07:23:20.795264
# Unit test for function match
def test_match():
    assert not match(Command(script='toto', output='sudo: tata: command not found'))
    assert match(Command(script='sudo toto', output='sudo: tata: command not found'))

test_match()


# Generated at 2022-06-24 07:23:22.272174
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(r"sudo: pip: command not found") == u"env \"PATH=$PATH\" pip"

# Generated at 2022-06-24 07:23:25.869330
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("sudo ls", "ls: command not found")) == "env \"PATH=$PATH\" ls"
    assert get_new_command(Command("sudo -- command not found", "sudo: --: command not found")) == "env \"PATH=$PATH\" --"
    assert get_new_command(Command("sudo - command not found", "sudo: -: command not found")) == "env \"PATH=$PATH\" -"

# Generated at 2022-06-24 07:23:30.866331
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo_env_path import get_new_command
    assert get_new_command('sudo ls') == 'env "PATH=$PATH" ls'
    assert get_new_command('sudo ls -la') == 'env "PATH=$PATH" ls -la'

# Generated at 2022-06-24 07:23:33.186970
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo edasd', 'sudo: edasd: command not found')) == 'env "PATH=$PATH" edasd'

# Generated at 2022-06-24 07:23:37.732561
# Unit test for function match
def test_match():
    assert match(Command('sudo update-manager', 'sudo: update-manager: command not found'))
    assert not match(Command('sudo update-manager', 'sudo: update-manager-kde: command not found'))
    assert not match(Command('sudo ls', 'sudo: ls: command not found'))


# Generated at 2022-06-24 07:23:39.976770
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install python-dev', 'zsh: command not found: apt-get\n'))


# Generated at 2022-06-24 07:23:41.586651
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls')) == 'sudo env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:23:43.246302
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("sudo make install") == "sudo env 'PATH=$PATH' make install"

# Generated at 2022-06-24 07:23:46.435914
# Unit test for function match
def test_match():
    assert match(Command('sudo rm test 2>&1', '', 'sudo: rm: command not found')).output == 'rm: command not found'
    assert match(Command('sudo rm test 2>&1', '', 'sudo rm: command not found')).output == 'sudo'


# Generated at 2022-06-24 07:23:50.381331
# Unit test for function match
def test_match():
    output = 'sudo: command not found'
    assert match(Command(script='sudo', output=output))
    assert not match(Command(script='sudo', output='command not found'))
    assert not match(Command(script='sudo', output='Key found'))

# Generated at 2022-06-24 07:23:52.823525
# Unit test for function match
def test_match():
    match_result = match(Command('sudo python test.py', '', ''))
    assert which('python')
    assert match_result


# Generated at 2022-06-24 07:23:55.428958
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo lskjfldskj', 'sudo: lskjfldskj: command not found\n')
    assert get_new_command(command) == 'env "PATH=$PATH" lskjfldskj'

# Generated at 2022-06-24 07:23:58.469969
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo bash -c "rm -f a_file"')
    assert get_new_command(command) == 'env "PATH=$PATH" bash -c "rm -f a_file"'

# Generated at 2022-06-24 07:24:06.061605
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo import get_new_command
    from thefuck.types import Command

# Generated at 2022-06-24 07:24:08.185906
# Unit test for function match
def test_match():
    assert match(Command('sudo some_command', 'sudo: some_command: command not found', ''))
    assert not match(Command('sudo some_command', '', ''))
    assert not match(Command('sudo some_command', 'sudo: some_command: command not found'))

# Generated at 2022-06-24 07:24:11.842181
# Unit test for function match
def test_match():
    assert match(Command('sudo foo -h', stderr=('sudo: foo: command not found\n', '')))
    assert not match(Command('sudo foo -h'))
    assert not match(Command('foo -h'))


# Generated at 2022-06-24 07:24:14.083920
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='sudo touch test.txt', output='sudo: touch: command not found')) == 'env "PATH=$PATH" touch test.txt'

# Generated at 2022-06-24 07:24:18.319073
# Unit test for function match
def test_match():
    # assert not match(Command('sudo apt-get install vim', '', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get install vim', '', ''))
    assert match(Command('sudo apt-get install vim', '', 'sudo: apt-get: command not found'))
    assert match(Command('sudo apt-get install vim', '', 'sudo: apt-get: command not found\nsudo: apt-get: command not found'))



# Generated at 2022-06-24 07:24:22.676225
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.sudo import get_new_command
    # Should return env "PATH=$PATH" <command>
    assert get_new_command(Command('sudo mycommand', 'mycommand: command not found')) == 'env "PATH=$PATH" mycommand'


# Generated at 2022-06-24 07:24:25.698643
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo ls --all'
    output = '/usr/bin/sudo: ls: command not found'
    command = Command(script, output)
    assert get_new_command(command) == u'env $PATH ls --all'

# Generated at 2022-06-24 07:24:27.650635
# Unit test for function match
def test_match():
    assert match(Command('sudo command1',
                         'sudo: command1: command not found'))
    assert not match(Command('sudo', ''))


# Generated at 2022-06-24 07:24:30.230976
# Unit test for function get_new_command
def test_get_new_command():
    c = Command('sudo ls', 'sudo: ls: command not found\n')
    assert get_new_command(c) == u'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:24:34.235196
# Unit test for function match
def test_match():
    assert match(Command('sudo rm x',
                         output='sudo: rm: command not found'))
    assert not match(Command('sudo rm x',
                             output='sudo: x: command not found'))


# Generated at 2022-06-24 07:24:39.197750
# Unit test for function match
def test_match():
    assert not match(Command('sudo su',
                             stderr='sudo: su: command not found'))
    assert match(Command('sudo kubectl',
                         stderr='sudo: kubectl: command not found'))
    assert not match(Command('try sudo file',
                             stderr='sudo: file: command not found'))
    assert not match(Command('sudo su -',
                             stderr='sudo: su: command not found'))


# Generated at 2022-06-24 07:24:44.691483
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command, wrap_in_aliases
    new_cmd = get_new_command(Command(script=u'sudo curl http://google.com', output=u'sudo: curl: command not found'))
    assert new_cmd == wrap_in_aliases(u'env "PATH=$PATH" curl http://google.com')


enabled_by_default = True

# Generated at 2022-06-24 07:24:46.369920
# Unit test for function match
def test_match():
    assert match(Command('sudo yum install foobar', 'sudo: yum: command not found'))


# Generated at 2022-06-24 07:24:49.301183
# Unit test for function match
def test_match():
    assert match(Command('mkdir /var/tmp', 'mkdir: cannot create directory \'/var/tmp\': Permission denied'))
    assert not match(Command('ls /root', ''))


# Generated at 2022-06-24 07:24:58.643808
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo apt-get update', '')) == \
        'env "PATH=$PATH" apt-get update'

    assert get_new_command(Command('sudo -E apt-get update', '')) == \
        'sudo -E env "PATH=$PATH" apt-get update'

    assert get_new_command(Command('sudo --preserve-env=PATH apt-get update', '')) == \
        'sudo --preserve-env=PATH env "PATH=$PATH" apt-get update'

    assert get_new_command(Command('sudo apt-get update && sudo apt-get install x', '')) == \
        'env "PATH=$PATH" apt-get update && sudo apt-get install x'

# Generated at 2022-06-24 07:25:02.354585
# Unit test for function match
def test_match():
  assert match(Command('ls', 'ls: command not found', '')) == False
  assert match(Command('sudo ls', 'sudo: ls: command not found', '')) == False
  assert match(Command('sudo ls sdf', 'sudo: ls: command not found', '')) == False



# Generated at 2022-06-24 07:25:05.932351
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo vim') == 'env "PATH=$PATH" vim'
    assert get_new_command('sudo vim file') == 'env "PATH=$PATH" vim file'
    assert get_new_command('sudo vim file -o') == 'env "PATH=$PATH" vim file -o'

# Generated at 2022-06-24 07:25:09.280903
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', u'', u''))
    assert _get_command_name(Command('', 'sudo: apt-get: command not found', '')) == 'apt-get'


# Generated at 2022-06-24 07:25:14.634391
# Unit test for function match
def test_match():
    assert _get_command_name(Command('sudo someprogram', 'sudo: someprogram: command not found\n')) == 'someprogram'
    assert not match(Command('ls', ''))
    assert match(Command('sudo someprogram', 'sudo: someprogram: command not found\n'))


# Generated at 2022-06-24 07:25:16.459388
# Unit test for function match
def test_match():
    assert match(Command('sudo dd', 'sudo: dd: command not found')) == True


# Generated at 2022-06-24 07:25:18.885206
# Unit test for function match
def test_match():
    assert match(Command('echo lol', 'echo lol\nsudo: echo: command not found'))
    assert not match(Command('', ''))


# Generated at 2022-06-24 07:25:23.135105
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command(script=u'sudo ls',
                                   output=u'sudo: ls: command not found')) \
           == u'sudo env "PATH=$PATH" ls'


# Generated at 2022-06-24 07:25:32.389318
# Unit test for function get_new_command
def test_get_new_command():
    # Basic case
    assert get_new_command("sudo acommand").script == "env \"PATH=$PATH\" acommand"
    # Command already exist but sudo does not find it
    assert get_new_command("sudo env \"PATH=$PATH\" acommand") == None
    # Multiple command
    assert get_new_command("sudo acommand bcommand ccommand").script == \
            "env \"PATH=$PATH\" acommand bcommand ccommand"
    # Command already contain 'sudo'
    assert get_new_command("sudo acommand sudo ccommand").script == \
            "env \"PATH=$PATH\" acommand sudo ccommand"
    # Command already contain 'sudo' with 'sudo' at end of command
    assert get_new_command("sudo acommand sudo").script == \
            "env \"PATH=$PATH\" acommand sudo"

# Generated at 2022-06-24 07:25:33.746149
# Unit test for function get_new_command
def test_get_new_command():
    # You need to add the test here.
    print ("You need to add the test here.")

# Generated at 2022-06-24 07:25:35.482363
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo test')
    assert get_new_command(command) == 'env "PATH=$PATH" sudo test'

# Generated at 2022-06-24 07:25:37.924204
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo xyz abc', 'sudo: xyz: command not found')) == 'env "PATH=$PATH" xyz abc'


# Generated at 2022-06-24 07:25:40.709991
# Unit test for function match
def test_match():
	assert match(Command('sudo apt-get update'))
	assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
	assert not match(Command('sudo apt-get update', 'total 0'))


# Generated at 2022-06-24 07:25:42.978839
# Unit test for function match
def test_match():
    assert match(Command('sudo not_found',
                         u'sudo: not_found: command not found\n'))
    assert not match(Command('ls', u''))



# Generated at 2022-06-24 07:25:45.125665
# Unit test for function get_new_command
def test_get_new_command():
    assert 'test' == get_new_command(('sudo test', 'sudo: test: command not found', 0))


# Generated at 2022-06-24 07:25:48.957522
# Unit test for function match
def test_match():
    assert bool(_get_command_name('sudo: backup: command not found')) == True
    assert bool(_get_command_name('sudo: update-grub: command not found')) == True
    assert bool(_get_command_name('sudo: python: command not found')) == True


# Generated at 2022-06-24 07:25:50.694901
# Unit test for function match
def test_match():
    assert match(Command('sudo foo', 'sudo: foo: command not found')) == which('foo')


# Generated at 2022-06-24 07:25:55.951387
# Unit test for function get_new_command
def test_get_new_command():
    command = type('command', (object,), {
        'script': u'sudo ls',
        'output': u'sudo: ls: command not found'
    })
    assert u'env "PATH=$PATH" ls' == get_new_command(command)


enabled_by_default = True

# Generated at 2022-06-24 07:25:59.258694
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo ls', 'sudo: ls: command not found')
    assert get_new_command(Command('sudo ls -l', 'sudo: ls: command not found')) == 'sudo env "PATH=$PATH" ls -l'

# Generated at 2022-06-24 07:26:01.247803
# Unit test for function match
def test_match():
    assert match(Command(script = 'sudo foo', output = 'sudo: foo: command not found'))


# Generated at 2022-06-24 07:26:03.442898
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim', 'sudo: vim: command not found')) == 'env "PATH=$PATH" vim'

# Generated at 2022-06-24 07:26:05.780240
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo vim', '')) == u'sudo env "PATH=$PATH" vim'


# Generated at 2022-06-24 07:26:08.423595
# Unit test for function match
def test_match():
    assert match(Command('sudo sommeothercommand',
                         output='sudo: sommeothercommand: command not found'))
    assert not match(Command('sudo sommeothercommand', ''))

# Generated at 2022-06-24 07:26:11.708101
# Unit test for function get_new_command
def test_get_new_command():
    script = 'sudo ls'
    output = 'sudo: ls: command not found'
    expected = 'sudo env "PATH=$PATH" ls'
    command = Command(script=script, output=output)
    assert expected == get_new_command(command)

# Generated at 2022-06-24 07:26:13.690133
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get update', 'sudo: apt-get: command not found'))
    assert not match(Command('sudo apt-get update', ''))

# Generated at 2022-06-24 07:26:18.697625
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo t',
                'sudo: echo: command not found: \n'
                'sudo: sudo: command not found')) == \
           u'env "PATH=$PATH" echo t'


enabled_by_default = True

# Generated at 2022-06-24 07:26:21.223190
# Unit test for function match
def test_match():
    assert match(Command('sudo vi', ''))
    assert not match(Command('vim', ''))


# Generated at 2022-06-24 07:26:23.166482
# Unit test for function match
def test_match():
    assert match(Command('sudo apt-get install vim',
                         'sudo: apt-get: command not found'))



# Generated at 2022-06-24 07:26:25.253667
# Unit test for function match
def test_match():
    assert match(Command(script='sudo vim'))
    assert not match(Command(script='sudo vim',
                             stderr='sudo: vim: command not found'))

# Generated at 2022-06-24 07:26:27.152251
# Unit test for function match
def test_match():
    assert match(Command('sudo nautilus',
                         'sudo: nautilus: command not found'))
    assert not match(Command('sudo nautilus', ''))

# Generated at 2022-06-24 07:26:30.542489
# Unit test for function match
def test_match():
    assert match(Command(script = 'sudo hello_world',
                         output = 'sudo: hello_world: command not found'))


# Generated at 2022-06-24 07:26:33.025232
# Unit test for function match
def test_match():
    command = Command('sudo apt-get update',
                      "sudo: apt-get: command not found")
    assert match(command)


# Generated at 2022-06-24 07:26:38.855403
# Unit test for function get_new_command
def test_get_new_command():
    # Test 1
    test_command = Command('sudo tux', u'tux: command not found\r\n')
    assert (get_new_command(test_command) == u'env "PATH=$PATH" tux')
    # Test 2
    test_command = Command('sudo tux -i', u'tux: command not found\r\n')
    assert (get_new_command(test_command) == u'env "PATH=$PATH" tux -i')


# Generated at 2022-06-24 07:26:42.498727
# Unit test for function match
def test_match():
    assert which('sudo')
    assert not match(Command(script='sudo', stderr='sudo: command not found'))
    assert match(Command(script='sudo ls', stderr='sudo: ls: command not found'))


# Generated at 2022-06-24 07:26:45.389218
# Unit test for function get_new_command
def test_get_new_command():
    actual = get_new_command(Command("sudo apt-get install bc", ""))
    assert actual == ["env", "PATH=${PATH}", "apt-get", "install", "bc"]

# Generated at 2022-06-24 07:26:47.645415
# Unit test for function match
def test_match():
    assert (match(Command('sudo pythons'))) is not None
    assert (match(Command('sudo python3.5'))) is None


# Generated at 2022-06-24 07:26:51.722756
# Unit test for function match
def test_match():
    assert match(Command('sudo vim', 'sudo: vim: command not found'))
    assert not match(Command('sudo vim', 'sudo: vim: Command not fouind'))
    assert not match(Command('sudo vim', 'sudo: vim: command not'))


# Generated at 2022-06-24 07:26:57.194348
# Unit test for function get_new_command
def test_get_new_command():
    output = u'sudo: terraform: command not found'
    command = type('obj', (object,), {'script': 'sudo terraform',
                                      'output': output})
    new_command = get_new_command(command)
    assert new_command == u'env "PATH=$PATH" sudo terraform'

# Generated at 2022-06-24 07:27:00.075058
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo echo "test"', "sudo: echo: command not found")) == u'env "PATH=$PATH" echo "test"'

# Generated at 2022-06-24 07:27:06.888620
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script='sudo vim',
                                    output='sudo: vim: command not found')).script == 'env "PATH=$PATH" vim')
    assert (get_new_command(Command(script='sudo vim ',
                                    output='sudo: vim: command not found')).script == 'env "PATH=$PATH" vim')
    assert (get_new_command(Command(script=' sudo vim',
                                    output='sudo: vim: command not found')).script == 'env "PATH=$PATH" vim')

# Generated at 2022-06-24 07:27:09.634103
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo cd /etc/', '', 'sudo: cd: command not found')) == "env 'PATH=$PATH' cd /etc/"

# Generated at 2022-06-24 07:27:13.625826
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('sudo vim', '', 'sudo: vim: command not found')) == \
            'env "PATH=$PATH" vim'

enabled_by_default = True

# Generated at 2022-06-24 07:27:24.137605
# Unit test for function get_new_command
def test_get_new_command():
    args = ['sudo', 'ls']

# Generated at 2022-06-24 07:27:29.635020
# Unit test for function match
def test_match():
    assert match(Command('sudo iptables',
                         'sudo: iptables: command not found'))
    assert not match(Command('sudo iptables',
                             'sudo: iptables: command'))
    assert not match(Command('sudo iptables', ''))
    assert not match(Command(''))
    assert not match(Command('sudo iptables'))



# Generated at 2022-06-24 07:27:32.388005
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo up', 'sudo: up: command not found')
    assert get_new_command(command) == u'sudo env "PATH=$PATH" up'

# Generated at 2022-06-24 07:27:35.683614
# Unit test for function match
def test_match():
    assert match(Command('sudo fgrep --line-buffered -v -f /tmp/missing /tmp/missing.log', u'''sudo: fgrep: command not found
'''))


# Generated at 2022-06-24 07:27:39.431204
# Unit test for function match
def test_match():
    assert match(Command('sudo fjajfajfajfj',
                         "sudo: fjajfajfajfj: command not found"))
    assert not match(Command('sudo -u sudouser', ''))


# Generated at 2022-06-24 07:27:42.996932
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo chown ~/.ssh; chmod 600 ~/.ssh/config', 'bash')
    assert get_new_command(command) == 'env "PATH=$PATH" chown ~/.ssh; chmod 600 ~/.ssh/config'

# Generated at 2022-06-24 07:27:44.508153
# Unit test for function get_new_command
def test_get_new_command():
    command = "sudo: git: command not found"
    asser

# Generated at 2022-06-24 07:27:46.893397
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo ls', '', 'sudo: ls: command not found')) == u'env "PATH=$PATH" ls'

# Generated at 2022-06-24 07:27:47.404390
# Unit test for function match
def test_match():
    pass

# Generated at 2022-06-24 07:27:50.954788
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo cd /root', 'sudo: cd: command not found')
    assert get_new_command(command) == 'env "PATH=$PATH" cd /root'

# Generated at 2022-06-24 07:27:56.724874
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo apt-get install')
    command.output = 'sudo: apt-get: command not found'
    assert get_new_command(command) == u'env "PATH=$PATH" apt-get install'
    command = Command('sudo apt-get install')
    command.output = 'sudo: apt-get: command not found'
    assert get_new_command(command) == u'env "PATH=$PATH" apt-get install'
    command = Command('sudo apt-get install system-config-lvm')
    command.output = 'sudo: apt-get: command not found'
    assert get_new_command(command) == u'env "PATH=$PATH" apt-get install system-config-lvm'
    command = Command('sudo -E system-config-lvm')

# Generated at 2022-06-24 07:28:01.192195
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('sudo f')) == 'env "PATH=$PATH" f'
    assert get_new_command(Command('sudo f b')) == 'env "PATH=$PATH" f b'
    assert get_new_command(Command('sudo f g')) == 'env "PATH=$PATH" f g'

# Generated at 2022-06-24 07:28:05.579094
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo strace', 'sudo: strace: command not found')) == 'env "PATH=$PATH" strace'
    assert get_new_command(Command('sudo apt-get install vim', 'sudo: apt-get: command not found')) == 'env "PATH=$PATH" apt-get install vim'
