

# Generated at 2022-06-25 12:39:57.563666
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += lambda: None
    event_source_0 += lambda: None
    event_source_0 += lambda: None
    event_source_0 += lambda: None


# Generated at 2022-06-25 12:39:59.429764
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with pytest.raises(TypeError):
        event_source_0.fire()


# Generated at 2022-06-25 12:40:03.827564
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    handler_0 = lambda: None
    handler_1 = lambda: None
    test_case_0()

    event_source_0 = _EventSource()
    event_source_0 += handler_0
    event_source_0 += handler_1

    assert event_source_0._handlers == {handler_0, handler_1}

    event_source_0.fire()



# Generated at 2022-06-25 12:40:05.828699
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(False, 'X', 'Q', False, False, False, False, False, 'T', 'm', 'v')

# Generated at 2022-06-25 12:40:10.061053
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    func_0 = lambda x: None
    value_0 = event_source_0.__iadd__(func_0)
    assert value_0 is event_source_0


# Generated at 2022-06-25 12:40:15.040605
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    assert event_source_0._handlers == set()

    def handler_0(arg_0, arg_1, arg_2):
        pass

    event_source_0 += handler_0
    assert event_source_0._handlers == {handler_0}



# Generated at 2022-06-25 12:40:18.070773
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(None)
    #assert event_source_0.fire() == None


# Generated at 2022-06-25 12:40:21.655843
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += lambda: None
    event_source_1 += lambda: None
    event_source_1.fire()
    event_source_1 -= lambda: None
    event_source_1.fire()


# Generated at 2022-06-25 12:40:28.901216
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()
    event_source_1 = _EventSource()
    assert event_source_1._handlers == set()

    event_source_1 += lambda: None
    assert event_source_1._handlers == {lambda: None}

    event_source_1 += lambda: None
    assert event_source_1._handlers == {lambda: None}

    handler = lambda: None
    event_source_1 += handler
    assert event_source_1._handlers == {lambda: None, handler}

    event_source_1 += i
    assert event_source_1._handlers == {lambda: None, handler, i}


# Generated at 2022-06-25 12:40:33.719619
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_1 = _EventSource()

    def handler_1a(sender, **kwargs):
        print('Handler 1a')

    def handler_1b(sender, **kwargs):
        print('Handler 1b')

    event_source_1 += handler_1a
    event_source_1 += handler_1b

    print('fired!')
    event_source_1.fire()
    print('fired!')



# Generated at 2022-06-25 12:40:39.676564
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    '''
    Unit test for method fire of class _EventSource
    '''
    global event_source_0
    # Run the method fire of class _EventSource
    # Cleanup the event_source_0
    try:
        event_source_0.__iadd__(lambda x: x + 1)
        event_source_0.fire(2)
    finally:
        del event_source_0

# Generated at 2022-06-25 12:40:44.229467
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def _local(a, b, c):
        return a, b, c

    def _local_alt(a, b, c):
        return b, c, a

    event_source_0 += _local
    event_source_0 += _local_alt

    event_source_0.fire('a', 'b', 'c')



# Generated at 2022-06-25 12:40:46.790055
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(to_text)
    event_source_0.fire('Hello world',)


# Generated at 2022-06-25 12:40:48.370314
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:58.037262
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    path = 'test/lib/ansible_test/_util/target/legacy_collection_loader/_EventSource.py'
    event_source_1 = _EventSource()
    event_source_1 += (lambda: None)
    event_source_1 += lambda: None
    try:
        event_source_1 += (1)
        assert False
    except ValueError:
        pass
    event_source_1.fire()
    try:
        event_source_1.fire(1, 2, 3)
    except:
        pass


# Generated at 2022-06-25 12:40:59.572090
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:41:02.815111
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:41:13.953016
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def _handler_1(arg1, **kwargs):
        try:
            assert arg1 == 1
        except AssertionError:
            raise AssertionError('assert arg1 == 1 failed')

    event_source_0 += _handler_1

    try:
        event_source_0.fire(1)
    except AssertionError:
        raise AssertionError('calling event_source_0.fire(1) raised AssertionError')

    try:
        event_source_0.fire(2)
    except AssertionError:
        pass
    else:
        raise AssertionError('calling event_source_0.fire(2) did not raise AssertionError')



# Generated at 2022-06-25 12:41:17.777213
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    handler_0 = lambda x, y: 0 and print(x, y ** y)
    event_source_0 += handler_0
    event_source_0.fire(42, '>', 4)


# Generated at 2022-06-25 12:41:23.895279
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    handler_0 = lambda: None
    exception_0 = None
    args_0 = ()
    kwargs_0 = dict()
    try:
        event_source_0.fire(handler_0, exception_0, *args_0, **kwargs_0)
    except Exception as exception_1:
        exception_0 = exception_1
    assert exception_0 is None



# Generated at 2022-06-25 12:41:33.620374
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(ex)


# Generated at 2022-06-25 12:41:35.831502
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # set up test
    event_source_0 = _EventSource()
    # test
    event_source_0.fire()


# Generated at 2022-06-25 12:41:47.682395
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import with_metaclass

    test_args = (1, 2, 3)
    test_kwargs = {'a': 1, 'b': 2, 'c': 3}

    class Outer(type):
        def __init__(cls, meta, name, bases):
            cls.__outer = cls()

        def __call__(cls, *args, **kwargs):
            return cls.__outer

    class Inner(with_metaclass(Outer)):
        def __init__(self):
            self.data = []

# Generated at 2022-06-25 12:41:55.464656
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """
    :type event_source: _EventSource
    """
    event_source = test_case_0()

    assert event_source._handlers.__len__() == 0

    def test_callable_0(*args, **kwargs):
        pass

    event_source.on_collection_load += test_callable_0

    event_source.on_collection_load(collection_name='ansible.kubernetes')

    assert event_source._handlers.__len__() == 1
    event_source.on_collection_load -= test_callable_0
    assert event_source._handlers.__len__() == 0


# Generated at 2022-06-25 12:41:58.401027
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler_0(*args, **kwargs):
        pass

    def handler_1(*args, **kwargs):
        pass

    event_source += handler_0
    event_source += handler_1

    event_source.fire()


# Generated at 2022-06-25 12:41:59.402304
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()



# Generated at 2022-06-25 12:42:06.182075
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test code for func_call_handler
    def func_call_handler(*args, **kwargs):
        return
    event_source_0 += func_call_handler
    event_source_0.fire()
    event_source_0 -= func_call_handler

    # Test code for exception_handler
    def exception_handler(*args, **kwargs):
        raise ValueError('Test exception')
    event_source_0 += exception_handler
    try:
        event_source_0.fire()
    except ValueError:
        pass
    else:
        assert False, "unexpected lack of exception"
    event_source_0 -= exception_handler



# Generated at 2022-06-25 12:42:07.573457
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    expected = 5
    actual = event_source.fire()
    if actual != expected:
        raise AssertionError("'fire' method of _EventSource failed")



# Generated at 2022-06-25 12:42:08.463337
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:09.700673
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()



# Generated at 2022-06-25 12:42:23.830504
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:28.633311
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import collections

    expected_result = None

    event_source_0 = _EventSource()

    def handler_0():
        return 'handler_0_result'

    event_source_0 += handler_0

    def handler_1():
        return 'handler_1_result'

    event_source_0 += handler_1

    result = event_source_0.fire()

    assert result is expected_result


# Generated at 2022-06-25 12:42:29.252122
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()



# Generated at 2022-06-25 12:42:31.300662
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda x: None
    event_source += lambda x: event_source.fire('foo')
    event_source.fire('bar')



# Generated at 2022-06-25 12:42:32.277637
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    c = AnsibleCollectionConfig()
    c.collection_paths


# Generated at 2022-06-25 12:42:38.828814
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # Test exception case
    try:
        event_source_0.fire_0()
    except ValueError as error:
        msg = str(error)
        assert(msg == 'handler must be callable')
    # Test exception case
    try:
        event_source_1 = _EventSource()
        event_source_1.fire_1(1)
    except ValueError as error:
        msg = str(error)
        assert(msg == 'handler must be callable')

# Tests of AnsibleCollectionConfig

# Generated at 2022-06-25 12:42:40.842470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # setup
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:41.928967
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass

# Generated at 2022-06-25 12:42:48.134813
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def _EventSource_fire_0_handler(source, event_args):
        pass

    event_source_0 = _EventSource()
    event_source_0 += _EventSource_fire_0_handler
    event_source_0.fire('abc')


# Generated at 2022-06-25 12:42:58.511625
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test fire() with value None
    # Test with function handler
    def handler_func(exc, *args, **kwargs):
        raise Exception('handler_func raised')

    event_source_0 += handler_func
    with pytest.raises(Exception):
        event_source_0.fire()

    event_source_0 -= handler_func
    # Test with method handler
    class HandlerClass:
        def handler_method(self, exc, *args, **kwargs):
            raise Exception('handler_method raised')

    handler_class_0 = HandlerClass()
    event_source_0 += handler_class_0.handler_method
    with pytest.raises(Exception):
        event_source_0.fire()

    # Test fire() with invalid handler name

# Generated at 2022-06-25 12:43:13.329310
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:14.391694
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:43:16.020561
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:43:17.219675
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert var_0 is None



# Generated at 2022-06-25 12:43:19.495146
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # create a test object
    temp_o = _EventSource()

    # fire the method on the test object
    temp_o.fire()



# Generated at 2022-06-25 12:43:21.273969
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:43:22.984644
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:43:25.004348
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    var_0 = event_source_0.fire()

    assert var_0 is None



# Generated at 2022-06-25 12:43:28.263932
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        cls_0 = AnsibleCollectionConfig()
        cls_0.on_collection_load.fire()
        raise AssertionError
    except TypeError:
        pass


# Generated at 2022-06-25 12:43:29.963192
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:16.713495
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:21.111197
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:44:22.346489
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    return event_source_0.fire()


# Generated at 2022-06-25 12:44:23.750127
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 is None


# Generated at 2022-06-25 12:44:25.137222
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:27.513943
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = lambda a, b, *args, **kwargs: True
    event_source_0.fire()


# Generated at 2022-06-25 12:44:33.018156
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Implicit call to class _EventSource
    event_source_0 = _EventSource()
    print('Testing method fire of class _EventSource')
    # Test: No exception is raised
    try:
        event_source_0.fire()
    except Exception as ex:
        print('FAILED: Unexpected exception raised: {}'.format(ex))
        print('Output:')
        test_case_0()



# Generated at 2022-06-25 12:44:33.859242
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# Generated at 2022-06-25 12:44:36.917427
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:44:38.667975
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:28.752955
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:45:33.208917
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += test_case_0
    event_source_0.fire()
    var_0 = event_source_0._handlers
    if var_0.__contains__(test_case_0):
        return 'pass'
    else:
        return 'fail'


# Generated at 2022-06-25 12:45:34.754793
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:36.058677
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 12:45:38.213391
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:40.324516
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # arrange
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    # act
    event_source.fire()

    # assert
    assert len(event_source._handlers) == 0



# Generated at 2022-06-25 12:45:43.353548
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    var_1 = event_source_0.fire()
    # assert that an event source can be fired without a handler


# Generated at 2022-06-25 12:45:46.624528
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:45:48.333108
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    test_case_0()


# Generated at 2022-06-25 12:45:50.030772
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:47:33.505959
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_0 = _EventSource()
    var_0.fire()


# Generated at 2022-06-25 12:47:35.344893
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 is None


# Generated at 2022-06-25 12:47:37.302323
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup
    event_source_0 = _EventSource()
    # Operation
    var_0 = event_source_0.fire()
    # Verification
    assert var_0 is None


# Generated at 2022-06-25 12:47:38.584950
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:47:45.946374
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # test calling no handlers
    var_0 = event_source_0.fire()

    def test_handler():
        pass

    event_source_0 += test_handler

    # test calling a handler which returns
    var_0 = event_source_0.fire()

    def test_handler_1():
        return 123

    event_source_0 -= test_handler
    event_source_0 += test_handler_1

    # test calling a handler which returns a non-zero value
    var_0 = event_source_0.fire()

    def test_handler_2():
        raise ValueError('intentional')

    event_source_0 -= test_handler_1
    event_source_0 += test_handler_2

    # test calling a handler which raises

# Generated at 2022-06-25 12:47:46.806054
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
      test_case_0()

# Generated at 2022-06-25 12:47:50.678470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    cases = [
        #(expected, args, kwargs)
        (None, (), {}),
    ]
    test__EventSource_fire.func_code = cases[0][0].func_code
    for expected, args, kwargs in cases:
        test__EventSource_fire(*args, **kwargs)



# Generated at 2022-06-25 12:47:52.029672
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:47:53.517521
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:47:55.126523
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # event_source_0 = _EventSource()
    # var_0 = event_source_0.fire()
    assert True