

# Generated at 2022-06-25 12:39:57.673006
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_event_source_0 = _EventSource()
    ansible_event_source_0.fire()


# Generated at 2022-06-25 12:39:58.785449
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TODO: implement test
    pass


# Generated at 2022-06-25 12:40:02.531559
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0(*args, **kwargs):
        raise ValueError('ValueError!')

    event_source_0 += handler_0
    try:
        event_source_0.fire()
    except ValueError:
        pass


# Generated at 2022-06-25 12:40:14.048508
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ansible_collection_config_1 = AnsibleCollectionConfig()

    def handler0(a, b):
        pass

    handler_0_0 = handler0
    handler_0_1 = handler0

    # Test for a simple passed case
    event_source_0_0 = ansible_collection_config_1._on_collection_load
    event_source_0_0 += handler_0_0

    # Test for a passed case where the same callable is added twice
    event_source_0_1 = ansible_collection_config_1._on_collection_load
    event_source_0_1 += handler_0_1
    event_source_0_1 += handler_0_1

    # Test for a failed case where we pass in something other than a callable
    event_source_0_2 = ansible_collection_

# Generated at 2022-06-25 12:40:24.658750
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Verify that the method returns normally
    _EventSource_instance_0 = _EventSource()
    _EventSource_instance_0.fire()

    # Verify that the method returns normally
    _EventSource_instance_1 = _EventSource()
    _EventSource_instance_1.fire(1)

    # Verify that the method returns normally
    _EventSource_instance_2 = _EventSource()
    _EventSource_instance_2.fire(1, 2, 3)

    # Verify that the method returns normally
    _EventSource_instance_3 = _EventSource()
    _EventSource_instance_3.fire(1, 2, 3, 4)

    # Verify that the method returns normally
    _EventSource_instance_4 = _EventSource()

# Generated at 2022-06-25 12:40:26.064128
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.fire()


# Generated at 2022-06-25 12:40:28.868097
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()

    def f():
        pass

    x.__iadd__(f)



# Generated at 2022-06-25 12:40:30.402714
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

# Generated at 2022-06-25 12:40:31.643235
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test = _EventSource()
    test.fire()

# Generated at 2022-06-25 12:40:35.964254
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Creating instance of EventSource
    event_source_instance = _EventSource()
    # Creating a handler
    def handler(a, b, c):
        pass
    # Subscribing multiple handler
    event_source_instance += handler
    event_source_instance += handler
    # Removing a handler
    event_source_instance -= handler
    # Firing the event
    event_source_instance.fire(1, 2, 3)


# Generated at 2022-06-25 12:40:43.696284
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # We do not have a test case yet which will actually call fire on the object instance.
    # If we ever do, this test can be uncommented and will verify functionality of the
    # method.
    # print("\n\n\n")
    # event_source_0 = _EventSource()
    # var_0 = event_source_0.fire()
    pass

# Generated at 2022-06-25 12:40:45.441708
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__("not callable")


# Generated at 2022-06-25 12:40:47.725645
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert var_0 == None

if __name__ == "__main__":
    test_case_0()
    test__EventSource_fire()

# Generated at 2022-06-25 12:40:50.224025
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test 0
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:40:54.143838
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # var_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0.__iadd__()


# Generated at 2022-06-25 12:40:56.462820
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:59.305269
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    var_1 = event_source_0.fire(var_0)


# Generated at 2022-06-25 12:41:03.659307
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    # get the function to be tested
    func = getattr(AnsibleCollectionConfig.on_collection_load, '__iadd__')

    # get the class instance to be tested
    instance = AnsibleCollectionConfig()

    # validate that the function is callable
    assert callable(func)

    # create a mock function to be used as the handler
    mock_handler = MagicMock(name='mock_handler')

    # call our function with the mock handler
    func(instance, mock_handler)

    # validate that the handler was added
    assert mock_handler in instance._handlers

    # create a mock function to be used as the handler
    mock_handler_0 = MagicMock(name='mock_handler_0')

    # call our function with the mock handler
    func(instance, mock_handler_0)

    #

# Generated at 2022-06-25 12:41:07.486570
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    var_0 += test_case_0


# Generated at 2022-06-25 12:41:12.274366
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    """Tests the __iadd__ method for the _EventSource class"""
    # Create test objects
    event_source_0 = _EventSource()
    # Test the method
    try:
        event_source_0.__iadd__(1)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 12:41:17.277203
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    test_case_0()

# Generated at 2022-06-25 12:41:19.244438
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

# Generated at 2022-06-25 12:41:21.509669
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:23.453551
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:28.990012
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    event_source_0
    event_source_0 += (vars)

    assert event_source_0._handlers is not None

    # CAUTION: This test was originally auto-generated using a legacy version of the collection loader
    #          and has been manually ported to use with the modern AnsibleCollectionConfig metaclass.
    #          This is to ensure the legacy __metaclass__ functionality continues to work as expected.


# Generated at 2022-06-25 12:41:30.702266
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._handlers = set()
    var_1 = event_source_0.fire()


# Generated at 2022-06-25 12:41:33.663406
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:41:35.548376
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:37.855132
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:40.334318
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    handler_0 = lambda p0: p0._handlers
    event_source_0 += handler_0


# Generated at 2022-06-25 12:41:48.917405
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:41:51.412888
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__()



# Generated at 2022-06-25 12:41:52.977940
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Instantiation and use of a _EventSource object, then call of fire
    test_case_0()


# Generated at 2022-06-25 12:41:56.434956
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import docopt, sys
    import json
    import os.path
    import unittest
    import pytest

    # Set to false to not run live tests
    run_live = False

    class Test_EventSource:

        # Unit tests for _EventSource class.
        def test_01(self):
            test_case_0()
            assert True

    # Test(s)
    Test_EventSource().test_01()


# Generated at 2022-06-25 12:41:58.748385
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# Generated at 2022-06-25 12:42:01.829409
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:42:05.235536
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.utils.collection_loader.test_cases import case__EventSource___iadd__
    case__EventSource___iadd__.test_case()


# Generated at 2022-06-25 12:42:08.580954
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    annotations = dict()
    return_annotation = None
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()
    assert var_1 is None

# Generated at 2022-06-25 12:42:11.212505
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    for i in range(0, 20):
        event_source_1 = _EventSource()
        var_0 = event_source_1.__iadd__("[]")
        assert var_0


# Generated at 2022-06-25 12:42:20.112834
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # (1) event_source_0 - always event_source_0.__iadd__(None).
    # Call function __iadd__.
    event_source_0 = _EventSource()
    event_source_0.__iadd__(None)

    # Call function __iadd__.
    event_source_0 = _EventSource()
    event_source_0.__iadd__(None)
    # (2) event_source_1 - always event_source_1.__iadd__(module_utils.n_filt_tuple).
    # Call function __iadd__.
    event_source_1 = _EventSource()
    event_source_1.__iadd__(module_utils.n_filt_tuple)

    # Call function __iadd__.
    event_source_1

# Generated at 2022-06-25 12:42:28.168347
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:29.633166
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(event_source_0)


# Generated at 2022-06-25 12:42:32.338826
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(event_source_0)
    event_source_0.__iadd__(event_source_0)
    assert var_0 is event_source_0


# Generated at 2022-06-25 12:42:34.727548
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(event_source_0.__iadd__)
    event_source_0.fire()


# Generated at 2022-06-25 12:42:36.267601
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:42:38.486483
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(event_source_0)


# Generated at 2022-06-25 12:42:40.669090
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire(var_0)



# Generated at 2022-06-25 12:42:42.903565
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:48.169519
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire('9', w=1)
    event_source_0.fire()

    event_source_1 = _EventSource()
    event_source_1.fire()



# Generated at 2022-06-25 12:42:50.656872
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(event_source_0)
    return (var_0 is event_source_0)


# Generated at 2022-06-25 12:42:58.996607
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire(event_source_0, event_source_0)


# Generated at 2022-06-25 12:43:08.033036
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Note: the class _EventSource does not expose a __new__ method, so
    # we directly use the type to create the instance
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire('var_0')
    event_source_0.fire(kwargs='var_1')
    event_source_0.fire(kwargs='var_1', var_2='var_2')

    # test that the caller re-raises the exception raised by registered handlers
    # Note: We must register a handler for this, otherwise the call to fire()
    #       should not raise any exception
    class _DummyException(Exception):
        pass

    # Note: registration of the handler must happen after the exception class
    #       has been defined
    event_source_0.__i

# Generated at 2022-06-25 12:43:11.635966
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except Exception:
        pass
    else:
        assert False

    try:
        event_source_0.fire()
    except Exception:
        pass
    else:
        assert False



# Generated at 2022-06-25 12:43:21.314191
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import dict_util
    import pytest


# Generated at 2022-06-25 12:43:24.032378
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Ensure the method returns a result
    expected = 1
    event_source_0 = _EventSource()
    result = event_source_0.fire()
    assert result == expected


# Generated at 2022-06-25 12:43:26.519750
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # EventSource.fire: calls each handler with the specified args and kwargs.
    test_case_0()


# Generated at 2022-06-25 12:43:29.793139
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._handlers.add("text")
    event_source_0._on_exception = lambda: None
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:32.280313
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_0 = _EventSource()
    var_0.fire()


ansible_collection_config = AnsibleCollectionConfig()

# Generated at 2022-06-25 12:43:35.601718
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_1 = _EventSource()
    x = var_1.fire()

# Generated at 2022-06-25 12:43:40.601154
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event_source_0 = _EventSource()
        event_source_0.fire()
    except TypeError as exc:
        # AnsibleCollectionConfig.fire() takes at least 2 arguments (2 given)
        # The above error results from the lack of key and value in the mocks
        # Below is the fix
        event_source_0.fire('key', 'value')

# Generated at 2022-06-25 12:43:52.939733
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:56.675521
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    arg_0 = "ayy"
    arg_1 = "lmao"
    obj = _EventSource()

    # Call method
    # result = obj.fire(arg_0, arg_1)
    # FIXME: this code does not work, the method does not exist
    result = None

    # FIXME: use assert for validity check

# Generated at 2022-06-25 12:43:58.636447
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()
    event_source_0._handlers = set()
    event_source_0._handlers.add(None)
    event_source_0.fire()


# Generated at 2022-06-25 12:44:00.615784
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance_0 = _EventSource()
    var_0 = instance_0.fire(instance_0)


# Generated at 2022-06-25 12:44:01.936149
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    var = event_source.fire()

# Generated at 2022-06-25 12:44:07.733175
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.parsing.convert_bool import boolean

    def handler(exception, *args, **kwargs):
        return True
    event_source_0 = _EventSource()
    event_source_0.__iadd__(handler)
    var_0 = event_source_0._on_exception(handler, None)
    var_1 = event_source_0.fire()


# Generated at 2022-06-25 12:44:09.598083
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:44:13.868848
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test when 'self._handlers' is a set
    event_source = _EventSource()
    var = event_source.fire()

    # Test when 'self._handlers' is not a set
    event_source = _EventSource()
    event_source._handlers = 'foobar'
    var = event_source.fire()


# Generated at 2022-06-25 12:44:15.885746
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:44:21.657718
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(event_source_0)
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:45.087205
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:47.637557
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # calls instance method fire
    event_source_0.fire()



# Generated at 2022-06-25 12:44:49.963993
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__isub__(event_source_0)
    event_source_0.fire()

# Generated at 2022-06-25 12:44:51.780503
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_0 = _EventSource()
    # var_0._on_exception
    var_0.fire()


# Generated at 2022-06-25 12:44:54.967846
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_1 = event_source_0.__iadd__(event_source_0)
    event_source_0.fire()
    event_source_0._on_exception()


# Generated at 2022-06-25 12:45:00.493669
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    
    # Call method fire of class _EventSource
    event_source_0 = _EventSource()

    # Call parameterized constructor of class _AnsibleCollectionConfig
    ansible_collection_config_0 = _AnsibleCollectionConfig(event_source_0, 'AnsibleCollectionConfig', (object, ))

    # Call method fire of class _EventSource
    ansible_collection_config_0._EventSource.fire()
    
    

# Generated at 2022-06-25 12:45:03.478444
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(event_source_0)
    event_source_0.fire(var_0)



# Generated at 2022-06-25 12:45:04.728908
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0.fire()

# Generated at 2022-06-25 12:45:07.281337
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    for i in range(0, 100):
        event_source_0 = _EventSource()
        try:
            event_source_0.fire()
        except KeyError:
            var_0 = True

# Generated at 2022-06-25 12:45:08.288104
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:45:54.949761
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:57.545772
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # expected is exception:
    try:
        event_source_0.fire()
    except NotImplementedError:
        pass



# Generated at 2022-06-25 12:46:00.517016
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = _EventSource._on_exception
    event_source_0._handlers = set()
    event_source_0.fire()

# Generated at 2022-06-25 12:46:07.040782
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

# Generated at 2022-06-25 12:46:08.371371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    obj0 = _EventSource()
    obj0.fire()
    obj0.fire()

# Generated at 2022-06-25 12:46:09.569627
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # event_source = _EventSource()
    pass

# Generated at 2022-06-25 12:46:12.283531
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(event_source_0)
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:20.381992
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    event_source_1 = _EventSource()
    event_source_2 = AnsibleCollectionConfig.on_collection_load
    event_source_3 = None
    event_source_3 = AnsibleCollectionConfig.playbook_paths

    # Act
    var_0 = event_source_2.fire(event_source_1)
    var_1 = event_source_2.fire(event_source_2)
    var_2 = event_source_2.fire(event_source_3)

    # Assert

    assert var_0 == None
    assert var_1 == None
    assert var_2 == None


# Generated at 2022-06-25 12:46:21.559489
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:46:22.719748
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:48:07.082126
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Test case 0
    instance_0 = _EventSource()
    instance_0.fire()

    # Test case 1
    instance_0 = _EventSource()
    instance_0.fire(1)

    # Test case 2
    instance_0 = _EventSource()
    instance_0.fire(1, 1)

    # Test case 3
    instance_0 = _EventSource()
    instance_0.fire(1, 1, 1)

    # Test case 4
    instance_0 = _EventSource()
    instance_0.fire(1, 1, 1, 1)



# Generated at 2022-06-25 12:48:11.844029
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    print('Executing test for method fire of class _EventSource')
    event_source_0 = _EventSource()
    event_source_0.fire(0)

    try:
        event_source_0.fire()
        assert False # Exception not thrown
    except TypeError as e:
        print('Type error thrown: ', e)

    try:
        event_source_0.fire(0, 0)
        assert False # Exception not thrown
    except TypeError as e:
        print('Type error thrown: ', e)


# Generated at 2022-06-25 12:48:14.632348
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source__EventSource = _EventSource()
    # Copy of var_1
    event_source__EventSource_0 = event_source__EventSource
    # Test of event_source__EventSource.fire
    event_source__EventSource_0.fire()


# Generated at 2022-06-25 12:48:20.394592
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    obj = _EventSource()
    try:
        obj.fire()
    except Exception as err:
        print("unexpected exception ({}): {}".format(type(err), str(err)))
        raise
    else:
        print("collections.__init__: PASS")


# Generated at 2022-06-25 12:48:22.173385
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:48:24.294851
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire(event_source_1)


# Generated at 2022-06-25 12:48:27.761778
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire('a', abc=event_source_0)
    event_source_0._on_exception(event_source_0, "test_0", 'a', abc=event_source_0)


# Generated at 2022-06-25 12:48:31.170885
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    obj_0 = lambda : None
    obj_1 = event_source_0.__iadd__(obj_0)
    obj_2 = event_source_0.fire()
    obj_3 = event_source_0.__isub__(obj_0)


# Generated at 2022-06-25 12:48:32.730608
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:48:36.034869
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = lambda handler, exc, *args, **kwargs: True
    var_0 = event_source_0.fire()
