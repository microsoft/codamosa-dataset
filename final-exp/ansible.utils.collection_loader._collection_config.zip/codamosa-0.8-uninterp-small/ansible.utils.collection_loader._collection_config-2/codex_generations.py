

# Generated at 2022-06-25 12:39:57.843163
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    args = [1, 2, 3]
    kwargs = {'a': 1, 'b': 2}
    event_source_0.fire(*args, **kwargs)


# Generated at 2022-06-25 12:40:00.430448
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += lambda x, y: x + y
    result = event_source_1.fire(1, 2)
    assert result is None


# Generated at 2022-06-25 12:40:03.420294
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    expected_0 = NotImplemented
    actual_0 = event_source_0.__iadd__(NotImplemented)
    assert actual_0 is expected_0



# Generated at 2022-06-25 12:40:04.815768
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:40:06.356735
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()



# Generated at 2022-06-25 12:40:09.722522
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    assert event_source_0.__iadd__(handler=None)

    with pytest.raises(ValueError):
        event_source_0.__iadd__(handler='abc')



# Generated at 2022-06-25 12:40:16.950849
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def handler_1(arg_0, arg_1, arg_2):
        print("on_collection_load: {} {} {}".format(arg_0, arg_1, arg_2))

    event_source_1 += handler_1

    # This should go to the first handler
    event_source_1.fire('arg_0', 'arg_1', 'arg_2')
    assert event_source_1._handlers == {handler_1}


collection_config = AnsibleCollectionConfig()



# Generated at 2022-06-25 12:40:23.571687
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    with pytest.raises(ValueError):
        event_source_0 += 1
    assert event_source_0._handlers == set()

    event_source_1 = _EventSource()
    event_source_1 += event_source_0.fire

    assert event_source_1._handlers == {event_source_0.fire}



# Generated at 2022-06-25 12:40:31.311016
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    # Test calling without handlers defined
    assert event_source.fire() is None

    called = []

    def handler():
        called.append(True)

    event_source += handler
    assert event_source.fire() is None
    assert called == [True]
    called.clear()

    # test an exception in the handler doesn't prevent other handlers from running
    exception_handled = False

    def handler1():
        raise Exception('expected')

    def handler2():
        raise Exception('not expected')

    def handler3():
        raise Exception('also not expected')

    def on_exception(handler, ex, *args, **kwargs):
        nonlocal exception_handled
        if handler == handler1:
            exception_handled = True
            return True

    event_source += handler1
    event

# Generated at 2022-06-25 12:40:33.709449
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += lambda: None
    event_source_0 += lambda: None
    event_source_0 += lambda: None


# Generated at 2022-06-25 12:40:43.468351
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += print
    event_source_0 += lambda _: None

    event_source_0.fire(0)
    event_source_0.fire(1)
    event_source_0.fire(2)



# Generated at 2022-06-25 12:40:47.980490
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    def func_0():
        assert True
    event_source_0.__iadd__(func_0)
    def func_1():
        assert True
    event_source_0.__iadd__(func_1)
    def func_2():
        assert True
    event_source_0.__iadd__(func_2)


# Generated at 2022-06-25 12:40:57.409023
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    def func_0(*args, **kwargs):
        try:
            error_msg = 'test of _EventSource.fire failed'
            assert(len(args) == 1)
            assert(args[0] == 1)
            assert(kwargs.get('kwarg0') == 2)
        except AssertionError:
            raise AssertionError(error_msg)
    event_source_1 += func_0
    event_source_1.fire(1, kwarg0=2)


# Generated at 2022-06-25 12:41:02.652590
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.collections import AnsibleCollectionConfig

    event_source_0 = AnsibleCollectionConfig.on_collection_load
    event_source_0.fire()
# Note 1: the target interface and implementation will be expanded as the target module is ported to other target systems.
# Note 2: the target implementation may change as the target module is ported to other target systems.
# Note 3: the test implementation may change as the target module is ported to other target systems.
# Note 4: the test implementation may change as the test module is ported to other test systems.

# Generated at 2022-06-25 12:41:04.350547
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:15.139265
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_1 = _EventSource()

    f1 = lambda x: x
    event_source_1 += f1
    assert(f1 in event_source_1._handlers)

    f2 = lambda *x, **kw: x, kw
    event_source_1 += f2
    assert(f2 in event_source_1._handlers)

    try:
        event_source_1 += 42
    except ValueError:
        pass
    else:
        assert(False)

    try:
        event_source_1 += 42.0
    except ValueError:
        pass
    else:
        assert(False)

    try:
        event_source_1 += 'foo'
    except ValueError:
        pass
    else:
        assert(False)


# Generated at 2022-06-25 12:41:17.232082
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    result = event_source_0.fire()
    assert result is None


# Generated at 2022-06-25 12:41:19.570845
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    # add an event handler
    event_source_0 += test_case_0

    assert event_source_0


# Generated at 2022-06-25 12:41:22.963014
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += lambda x: to_text(x)
    event_source_0 += lambda x: to_text(x)


# Generated at 2022-06-25 12:41:26.010652
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    def func_0(arg_0, arg_1):
        return (arg_0, arg_1)
    event_source_0 += func_0


# Generated at 2022-06-25 12:41:34.197637
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    event_source_0.__iadd__(test_case_0).fire()



# Generated at 2022-06-25 12:41:35.709315
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    meta_0 = _EventSource()
    meta_0.fire()


# Generated at 2022-06-25 12:41:39.591686
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except ValueError as err:
        assert 'handler must be callable' in to_text(err)
    return True


# Generated at 2022-06-25 12:41:43.774932
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def event_source_0_handler():
        pass

    event_source_0 += event_source_0_handler
    event_source_0.fire()
    event_source_0 -= event_source_0_handler



# Generated at 2022-06-25 12:41:54.319501
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_1 = _EventSource()
    event_source_2 = _EventSource()
    event_source_3 = _EventSource()
    event_source_4 = _EventSource()
    event_source_5 = _EventSource()
    event_source_6 = _EventSource()
    event_source_7 = _EventSource()
    event_source_8 = _EventSource()
    event_source_9 = _EventSource()
    event_source_10 = _EventSource()
    event_source_11 = _EventSource()
    event_source_12 = _EventSource()
    event_source_13 = _EventSource()
    event_source_14 = _EventSource()
    event_source_15 = _EventSource()


# Generated at 2022-06-25 12:41:55.722594
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:57.600991
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += test_handler
    event_source_1.fire(1)


# Generated at 2022-06-25 12:42:02.728297
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_1 = _EventSource()
    listener_0 = lambda: None
    result_0 = event_source_1.__iadd__(listener_0)
    assert result_0._handlers == {listener_0}


# Generated at 2022-06-25 12:42:08.844779
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    func_1 = lambda *args, **kwargs: None
    try:
        result = event_source_0.__iadd__(func_1)
    except Exception as ex:
        result = 'Exception: {}: {}'.format(type(ex).__name__, ex)

    assert result is event_source_0
    assert isinstance(event_source_0, _EventSource)


# Generated at 2022-06-25 12:42:12.344929
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += test_case_0
    import types
    assert isinstance(event_source_0._handlers.pop(), types.FunctionType)


# Generated at 2022-06-25 12:42:22.969857
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()



# Generated at 2022-06-25 12:42:29.528105
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # For a single handler, the events works
    v0 = _EventSource()
    def handler_0():
        pass
    v0.fire()
    v0.fire()
    v0.fire()
    v0 += handler_0
    v0.fire(1, 2)
    v0.fire()
    v0.fire(3, 4, 5)
    v0 -= handler_0

    # For multiple handlers, the events works
    v1 = _EventSource()
    def handler_0():
        pass
    def handler_1():
        pass
    def handler_2():
        raise NotImplementedError('Something went wrong')
    v1 += handler_0
    v1 += handler_1
    v1.fire()
    v1 -= handler_0
    v1.fire(1, 2)


# Generated at 2022-06-25 12:42:30.846756
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    es += lambda: print('firing')
    es.fire()


# Generated at 2022-06-25 12:42:34.277194
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    obj = _EventSource()
    test_args = tuple() # set test_args
    test_kwargs = {} # set test_kwargs
    try:
        test_result = obj.fire(*test_args, **test_kwargs)
        assert(True)
    except Exception as ex:
        assert(False)



# Generated at 2022-06-25 12:42:36.122028
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:37.656644
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:39.753697
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.fire()


# Generated at 2022-06-25 12:42:49.040221
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test a simple event handler
    target = _EventSource()
    def handler(sender, value=1):
        assert type(sender) is _EventSource
        assert value == 1
    target += handler
    target.fire()
    target -= handler

    # Test a handler which raises an exception
    target = _EventSource()
    def handler(sender, value=1):
        assert type(sender) is _EventSource
        assert value == 1
        raise ValueError()

    def on_exception(sender, handler, exc, value=1):
        assert type(sender) is _EventSource
        assert value == 1
        assert type(handler) is type(handler)
        assert type(exc) is ValueError

        return False

    target._on_exception = on_exception

    target += handler
    target

# Generated at 2022-06-25 12:42:51.544806
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0.fire() is None


# Generated at 2022-06-25 12:43:01.416125
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Check that no exception is raised when firing an empty event source
    test_case_0()

    # Check that single handlers are fired
    event_source_1 = _EventSource()
    fired_count_1 = 0

    event_source_1 += lambda: fired_count_1.__iadd__(1)

    event_source_1.fire()
    assert fired_count_1 == 1

    # Check that multiple handlers are fired
    event_source_2 = _EventSource()
    fired_count_2_0 = 0
    fired_count_2_1 = 0
    fired_count_2_2 = 0

    event_source_2 += lambda: fired_count_2_0.__iadd__(1)
    event_source_2 += lambda: fired_count_2_1.__iadd__(1)

# Generated at 2022-06-25 12:43:14.192416
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert True


# Generated at 2022-06-25 12:43:19.621381
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = lambda x, y, *a, **kw: True
    event_source_0.fire()  # No handlers
    event_source_0 += lambda *a, **kw: None
    event_source_0.fire()
    event_source_0 += lambda *a, **kw: 1 / 0  # Exception (should not raise)
    event_source_0.fire()

# Generated at 2022-06-25 12:43:21.061460
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:43:22.768932
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:33.253898
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def on_collection_load_handler_0(collection):
        pass

    def on_collection_load_handler_1(collection):
        pass

    def on_collection_load_handler_2(collection):
        raise ValueError('Test exception')

    event_source_0 += on_collection_load_handler_0
    event_source_0 += on_collection_load_handler_1
    event_source_0 += on_collection_load_handler_2

    try:
        event_source_0.fire(None)
        assert False
    except ValueError as ex:
        assert ex.message == 'Test exception'


# Generated at 2022-06-25 12:43:37.633690
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire('a')
    event_source_0 += test__EventSource_fire_event_handler_0
    event_source_0.fire('b')
    event_source_0 -= test__EventSource_fire_event_handler_0
    event_source_0.fire('c')
    event_source_0 += test__EventSource_fire_event_handler_1
    event_source_0.fire('d')


# Generated at 2022-06-25 12:43:45.976460
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0._on_exception = lambda s, x, *ar, **k: False

    # "callable" must be a callable object, not True
    event_source_0._on_exception = lambda s, x, *ar, **k: True

    event_source_0._on_exception = lambda s, x, *ar, **k: True
    event_source_0._handlers.add(list)

    # do not re-raise, no exception was raised
    event_source_0.fire()

    # raise, exception was raised
    event_source_0.fire(True)



# Generated at 2022-06-25 12:43:52.728020
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with pytest.raises(TypeError) as exc_info_0:
        event_source_0.fire()
    exc_info_0.match('fire() takes from 0 to 2 positional arguments but 3 were given')
    with pytest.raises(TypeError) as exc_info_1:
        event_source_0.fire(1)
    exc_info_1.match('fire() takes from 0 to 2 positional arguments but 3 were given')



# Generated at 2022-06-25 12:43:57.365591
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def handler_1_callback_0(*args, **kwargs):
        pass

    handler_1_0 = handler_1_callback_0
    event_source_1 += handler_1_0
    event_source_1 += handler_1_callback_0
    event_source_1 += handler_1_callback_0
    event_source_1.fire()


# Generated at 2022-06-25 12:44:03.677391
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class AS:
        def __init__(self, value):
            self._value = value

        def __call__(self, *_, **__):
            return self._value

    event_source_0 = _EventSource()
    event_source_0 += AS(0)
    event_source_0 += AS(1)
    event_source_0 += AS(2)
    event_source_0 += AS(3)
    event_source_0 += AS(4)
    event_source_0 += AS(5)

    event_source_0.fire()



# Generated at 2022-06-25 12:44:17.144655
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()

    assert var_1 is None


# Generated at 2022-06-25 12:44:18.803193
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += print
    event_source_0.fire('a')


# Generated at 2022-06-25 12:44:23.709117
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Call method fire on object event_source_0
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:25.105523
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:44:29.339807
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event_source_0 = _EventSource()
        try:
            var_0 = event_source_0.fire()
        except NotImplementedError as err:
            error_msg = err.args[0]
        assert error_msg == 'an AnsibleCollectionFinder has not been installed in this process'

    except Exception:
        assert False, 'unexpected exception occurred'

# Generated at 2022-06-25 12:44:31.325144
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:34.451020
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = _unbound_event_source_0__on_exception
    var_0 = event_source_0.fire()
    assert var_0 == None


# Generated at 2022-06-25 12:44:38.057688
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_1 = _EventSource()
    var_2 = var_1.fire()
    return [var_2]


# Generated at 2022-06-25 12:44:40.536334
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += test_case_0
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:43.186870
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()

    # test no handlers
    AnsibleCollectionConfig.on_collection_load += event_source_0.fire

    # test one handler
    # test two handlers


# Generated at 2022-06-25 12:45:08.774993
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    collection_config_1 = AnsibleCollectionConfig
    event_source_1 = _EventSource()
    event_source_1 += test_case_0
    var_1 = event_source_1.fire()

# Generated at 2022-06-25 12:45:11.051185
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()

    func = lambda : None

    event_source_0 += func

    # normal method call
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:16.749617
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def method_0(arg_0):
        return

    def method_1(arg_0):
        return
    event_source_1 += method_0
    event_source_1 += method_1
    var_1 = event_source_1.fire()

    event_source_2 = _EventSource()
    var_2 = event_source_2.fire()

    event_source_3 = _EventSource()

    def method_2(arg_0):
        return
    event_source_3 += method_2
    var_3 = event_source_3.fire()

    event_source_4 = _EventSource()

    def method_3(arg_0):
        return
    event_source_4 += method_3
    var_4 = event_source_

# Generated at 2022-06-25 12:45:17.252809
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:45:18.060844
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:19.487116
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:20.063170
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:45:21.324218
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += test_case_0
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:22.205976
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_3 = event_source_0.fire()


# Generated at 2022-06-25 12:45:26.077017
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import with_metaclass
    class _AnsibleCollectionConfig(type):
        def __init__(cls, meta, name, bases):
            cls._collection_finder = None
            cls._default_collection = None
            cls._on_collection_load = _EventSource()

        @property
        def collection_finder(cls):
            return cls._collection_finder

        @collection_finder.setter
        def collection_finder(cls, value):
            if cls._collection_finder:
                raise ValueError('an AnsibleCollectionFinder has already been configured')

            cls._collection_finder = value

        @property
        def collection_paths(cls):
            cl

# Generated at 2022-06-25 12:46:14.465734
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TODO: maybe provide default argument values
    pass



# Generated at 2022-06-25 12:46:15.827339
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:46:18.524013
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def handler(arg):
        pass

    event_source_0 += handler
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:23.851517
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    func = _EventSource.fire.__func__
    assert func.__defaults__ == (None,), func.__defaults__
    assert func.__kwdefaults__ is None, func.__kwdefaults__
    assert func.__code__.co_varnames == ('self', 'args', 'kwargs'), func.__code__.co_varnames
    assert func.__code__.co_argcount == 2, func.__code__.co_argcount


# Generated at 2022-06-25 12:46:24.869666
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert test_case_0() is None, "test_case_0()"



# Generated at 2022-06-25 12:46:28.547242
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # This test does not require any assertions.
    # It just needs to be runnable to be useful for our purposes.
    test_case_0()



# Generated at 2022-06-25 12:46:30.391783
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:35.207077
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from io import StringIO
    from ansible.module_utils.common.text.converters import to_text

    ansible_module = DummyAnsibleModule("""
        name: my_test
    """)

    event_source_0 = _EventSource()

    if event_source_0.fire() != None:
        ansible_module.fail_json(msg='test_method_fire: unexpected behavior of fire')

    ansible_module.exit_json()

# Generated at 2022-06-25 12:46:36.032471
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:36.837975
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    var = event_source.fire()


# Generated at 2022-06-25 12:48:28.664855
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Call method fire of class _EventSource
    event_source_0.fire()


# Generated at 2022-06-25 12:48:30.270864
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:48:34.465104
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0.on_collection_load += test_case_0
    ansible_collection_config_0.on_collection_load += test_case_0
    ansible_collection_config_0.on_collection_load += test_case_0


# Generated at 2022-06-25 12:48:37.563406
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup
    event_source_0 = _EventSource()

    # Execution
    var_0 = event_source_0.fire()

    # Verification
    # TODO: Verify that the event source fired as expected.


# Generated at 2022-06-25 12:48:38.762361
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert test_case_0() is None

# Generated at 2022-06-25 12:48:40.333540
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:48:41.821607
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:48:43.190151
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:48:49.377090
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test with no handlers
    var_0 = event_source_0.fire(var_0=None, var_1=None)

    # Test with one handler
    def func_0(*args, **kwargs):
        pass
    event_source_0 += func_0
    var_1 = event_source_0.fire(var_0=None, var_1=None)

    # Test with two handlers
    def func_1(*args, **kwargs):
        pass
    event_source_0 += func_1
    var_2 = event_source_0.fire(var_0=None, var_1=None)

    # Test with two handlers, ensure that the data written to the event handler isn't modified
    event_source_0 = _EventSource()

# Generated at 2022-06-25 12:48:50.575757
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
