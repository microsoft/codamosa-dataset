

# Generated at 2022-06-25 12:40:04.543300
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def event_handler_1(val):
        pass

    def event_handler_2(val):
        raise Exception("Test Exception")

    event_source_1 += event_handler_1
    event_source_1.fire("test_string")

    event_source_1 += event_handler_2
    with pytest.raises(Exception) as execinfo:
        event_source_1.fire("test_string")

    assert "Test Exception" in str(execinfo.value)

    # Constructor
    event_source_2 = _EventSource()
    with pytest.raises(NotImplementedError) as execinfo:
        event_source_2.fire("test_string")

    assert "fire method must be overridden" in str(execinfo.value)




# Generated at 2022-06-25 12:40:08.130082
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except Exception:
        assert False, "unexpected Exception"


# Generated at 2022-06-25 12:40:10.010194
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire() # No error expected


# Generated at 2022-06-25 12:40:12.852422
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    #
    # Test #0
    #
    # Test empty event source
    #
    test_case_0()


#

# Generated at 2022-06-25 12:40:17.646587
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += _on_collection_load_handler_0
    assert event_source_1.handler_0 == '0'
    event_source_1.fire()
    assert event_source_1.handler_0 == '1'


    assert event_source_0.handler_0 == '1'

# Unit tests for class _AnsibleCollectionConfig

# Generated at 2022-06-25 12:40:20.111567
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def on_collection(collection):
        pass

    event_source_0 += on_collection

    event_source_0.fire()

# Generated at 2022-06-25 12:40:22.628927
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test = _EventSource()
    event_source_0 = _EventSource()
    test.fire()



# Generated at 2022-06-25 12:40:28.435115
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    assert event_source_0.fire() == None

    def _test(arg):
        return 'test__EventSource___iadd__' + to_text(arg)

    event_source_0 += _test
    exc = None
    try:
        event_source_0 += 1
    except Exception as _exc:
        exc = _exc
    assert type(exc) == TypeError
    assert to_text(exc) == 'handler must be callable'
    assert event_source_0.fire('foo') == None



# Generated at 2022-06-25 12:40:31.290719
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test given
    event_source_0 = _EventSource()
    # Test when
    event_source_0 += 'dummy'
    # Test then
    assert False, 'Expected ValueError not raised'


# Generated at 2022-06-25 12:40:32.835130
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:40.416752
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:40:44.154600
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    try:
        # Test with handler of type int
        event_source_0 = _EventSource()
        event_source_0 += 6
    except ValueError:
        pass

    # Test with handler of type callable
    event_source_0 = _EventSource()
    event_source_0 += lambda: None


# Generated at 2022-06-25 12:40:46.644529
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    kwargs_0 = {}
    args_0 = ()
    event_source_0.fire(*args_0, **kwargs_0)


# Generated at 2022-06-25 12:40:57.449269
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    # Testing that the argument passed to method is a callable

    def _lambda_0(self, *args, **kwargs):
        return False

    try:
        # Testing if the argument is a callable
        event_source_0 += _lambda_0
    except Exception as e:
        try:
            if (e.__class__.__name__ == "ValueError"):
                # Testing if the exception thrown is the one expected
                assert True
            else:
                assert False
        except AssertionError as ae:
            print('Exception thrown: ', ae)
            print('but was expecting: ValueError')
        else:
            assert False



# Generated at 2022-06-25 12:41:02.469421
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1():
        pass

    def handler2():
        pass

    es = _EventSource()
    es += handler1
    assert handler1 in es._handlers
    es += handler2
    assert handler2 in es._handlers
    try:
        es += 1
        assert False, 'handler must be callable'
    except ValueError:
        pass
    try:
        es += handler1
        assert False, 'handler must be callable'
    except ValueError:
        pass


# Generated at 2022-06-25 12:41:04.351217
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:41:08.539195
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def func_lambda_0():
        return
    event_source_0 += func_lambda_0
    event_source_0.fire()
    return


# Generated at 2022-06-25 12:41:11.386074
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    assert True

    event_source_2 = _EventSource()
    assert True



# Generated at 2022-06-25 12:41:12.455399
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:41:14.979250
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    def handler():
        return None
    event_source_0 += handler()


# Generated at 2022-06-25 12:41:22.303490
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 12:41:31.357436
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # See ticket #63595
    event_source_1 = _EventSource()
    event_source_2 = _EventSource()
    event_source_3 = _EventSource()
    event_source_4 = _EventSource()

    def my_handler_1(p1, p2=0, *args, **kwargs):
        assert p1 == 1
        assert p2 == 2
        assert args == (3, 4)
        assert kwargs == dict(kw1=5, kw2=6)

    def my_handler_2(p1, p2=0, *args, **kwargs):
        assert p1 == 7
        assert p2 == 8
        assert args == (9, 10)
        assert kwargs == dict(kw1=11, kw2=12)


# Generated at 2022-06-25 12:41:34.385372
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += lambda: print('hi')
    event_source_1.fire()


# Generated at 2022-06-25 12:41:37.238971
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    event_source += lambda: None

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-25 12:41:41.767534
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()   # create an event source
    import mock

    event_source_1 = _EventSource()

    with mock.patch('ansible.module_utils.common.text.converters.to_text', return_value='file-path'):
        value_1 = mock.Mock(return_value=False)

    with mock.patch('ansible.module_utils.common.text.converters.to_text', return_value='file-path'):
        value_2 = mock.Mock()

    event_source_1.__iadd__(value_1)

    assert len(event_source_1._handlers) == 1


# Generated at 2022-06-25 12:41:44.535883
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    def f(self):
        return "f"
    event_source_0.__iadd__(f)



# Generated at 2022-06-25 12:41:48.448791
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    expected = event_source_0._handlers
    event_source_0 += test_case_0
    assert event_source_0._handlers == expected


# Generated at 2022-06-25 12:41:50.378374
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0.fire()



# Generated at 2022-06-25 12:41:53.313684
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup
    event_source_0 = _EventSource()
    event_source_0 += lambda *args, **kwargs: 1 + 1
    method_0_args = ('a',)
    method_0_kwargs = {'b': True}

    # Exercise
    event_source_0.fire(*method_0_args, **method_0_kwargs)

    # Verify
    assert type(event_source_0) is _EventSource


# Generated at 2022-06-25 12:41:55.370864
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with pytest.raises(ValueError, match='handler must be callable'):
        event_source_0.fire()
    event_source_0 += 2
    with pytest.raises(ValueError, match='handler must be callable'):
        event_source_0.fire()

# Generated at 2022-06-25 12:42:04.058835
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    event_source_0 += event_source_0.fire

    event_source_0 += lambda: 'hello'

    event_source_0 += test_case_0

    return event_source_0



# Generated at 2022-06-25 12:42:14.335345
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # 0
    event_source_0 = _EventSource()
    event_source_0.fire()

    # 1, 2
    event_source_0 = _EventSource()

    def handler_1():
        pass

    event_source_0.fire(handler_1)

    # 3, 4
    event_source_0 = _EventSource()

    def handler_3(text_param, number_param):
        pass

    event_source_0.fire(handler_3, text_param='some text', number_param=3)

    # 5, 6
    event_source_0 = _EventSource()

    def handler_5(text_param, number_param):
        pass

    event_source_0.fire(handler_5)

    # 7, 8
    event_source_0 = _EventSource()



# Generated at 2022-06-25 12:42:17.844069
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with pytest.raises(Exception):
        event_source_0.fire()
    pytest.raises(Exception, event_source_0.fire)
    with pytest.raises(ValueError):
        event_source_0.fire()


# Generated at 2022-06-25 12:42:19.318845
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    try:
        event_source_0 += event_source_0
    except ValueError:
        pass
    else:
        assert False, 'ExpectedValueError'


# Generated at 2022-06-25 12:42:23.713733
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _Handler:
        def __init__(self, name=None):
            self._name = name

        def __call__(self, *args, **kwargs):
            pass

    event_source_0 = _EventSource()
    handler_0 = _Handler()

    event_source_0 += handler_0


# Generated at 2022-06-25 12:42:25.897386
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 -= test_case_0
    event_source_0.fire()



# Generated at 2022-06-25 12:42:33.003148
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += to_text
    event_source_0 += sum
    event_source_0 += int
    event_source_0 -= sum
    event_source_0 += min
    event_source_0 += str
    event_source_0 -= min
    event_source_0 -= to_text
    event_source_0 += max
    event_source_0 -= str
    event_source_0 += reversed
    event_source_0 -= max
    event_source_0 -= int
    event_source_0 += all
    event_source_0 -= reversed
    event_source_0 -= all


# Generated at 2022-06-25 12:42:34.610628
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = test_case_0()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:36.180845
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    # event_source_0 += "a" # will raise ValueError because "a" is not callable
    assert True


# Generated at 2022-06-25 12:42:37.739448
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:00.292687
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    print(event_source_0.fire())
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()
    event_source_0 = _EventSource()

# Generated at 2022-06-25 12:43:01.596217
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    pass


# Generated at 2022-06-25 12:43:06.828187
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Setup test
    event_source_0 = _EventSource()

    with pytest.raises(ValueError):
        event_source_0 += 3
    event_source_0 += test_case_0
    assert event_source_0._handlers == {test_case_0}
    event_source_0 += test_case_0
    assert event_source_0._handlers == {test_case_0}



# Generated at 2022-06-25 12:43:08.608714
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    for i in range(10):
        event_source_0 += lambda x: 0
    event_source_0.fire()



# Generated at 2022-06-25 12:43:10.714625
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    #  First attempt at implementation of fire method
    event_source_0.fire()


# Generated at 2022-06-25 12:43:15.797373
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(lambda: None)

    with typecheck("<lambda>", "<lambda>", ValueError) as e:
        event_source_0.__iadd__("<lambda>")
    assert str(e.value) == 'handler must be callable'



# Generated at 2022-06-25 12:43:17.345483
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0.fire() is None


# Generated at 2022-06-25 12:43:20.845572
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def handler_0(*args, **kwargs):
        pass

    event_source_1 += handler_0

    # FIXME: hard to invoke this because the handler raises an exception
    #event_source_1.fire()


# Generated at 2022-06-25 12:43:24.236155
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_1 = _EventSource()
    event_source_0 += event_source_1
    event_source_0 -= event_source_1
    event_source_0 += test_case_0


# Generated at 2022-06-25 12:43:27.128262
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    handler_0 = lambda *args, **kwargs: None
    event_source_0 += handler_0


# Generated at 2022-06-25 12:43:41.181752
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:44.033285
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance = _EventSource()
    try:
        instance.fire()
    except Exception as e:
        print(e)
        assert True
    else:
        assert False

# Generated at 2022-06-25 12:43:45.643777
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0.fire() is None



# Generated at 2022-06-25 12:43:49.435244
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def a(a0):
        assert a0 == 1

    event_source_0 += a
    event_source_0 += a

    event_source_0.fire(1)



# Generated at 2022-06-25 12:43:51.071433
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:43:52.770302
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:43:54.329615
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:43:55.164768
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# Generated at 2022-06-25 12:43:57.735560
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    test_method_0(event_source_0)
    test_method_1(event_source_0)
    test_method_2(event_source_0)


# Generated at 2022-06-25 12:43:58.962057
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:44:29.875178
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0():
        pass

    event_source_0 += handler_0
    event_source_0.fire()


# Generated at 2022-06-25 12:44:33.149637
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test #0 - ensures that a handler does not raise an exception
    test_case_0 = AnsibleCollectionConfig()
    test_event_source_0 = _EventSource()

    test_event_source_0 += test_case_0.handler
    test_event_source_0.fire()

    assert True

    # Test #1 - ensures that a handler raising an exception is handled
    test_event_source_1 = _EventSource()

    test_event_source_1 += test_case_0.handler
    test_event_source_1.fire()

    assert True



# Generated at 2022-06-25 12:44:36.767740
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += (lambda _: None)
    event_source_0.fire()


# Generated at 2022-06-25 12:44:42.974595
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    expected_results = ['result 1', 'result 2']

    class MockClass:
        def __init__(self, index):
            self.index = index

        def mock_method(self, *args, **kwargs):
            return expected_results[self.index]

    event_source = _EventSource()

    event_source += MockClass(0).mock_method
    event_source += MockClass(1).mock_method

    actual_results = event_source.fire()

    assert expected_results == actual_results

# Generated at 2022-06-25 12:44:44.999681
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    handler_0 = event_source.fire
    handler_0()


# Generated at 2022-06-25 12:44:51.936939
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def f(event):
        assert event.__class__.__name__ == 'Event'
        assert event.args == (1, 2)
        assert event.kwargs == {'a': 'b'}
        event.result = True

    x = AnsibleCollectionConfig()
    event_source_0 = _EventSource()
    x.on_collection_load += (f,)
    x.on_collection_load.fire(Event(1, 2, a='b'))
    event_source_0.fire(Event(1, 2, a='b'))

# Generated at 2022-06-25 12:44:53.290543
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0.fire()



# Generated at 2022-06-25 12:44:56.512596
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with pytest.raises(ValueError):
        result = event_source_0.fire()


# Generated at 2022-06-25 12:44:58.494910
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # case 0
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:45:00.368988
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    method_0 = event_source_0.fire
    assert method_0() is None



# Generated at 2022-06-25 12:45:59.573339
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert to_text(event_source_0.fire) == '<bound method _EventSource.fire of <__main__._EventSource object at 0x7fb8b4e9b978>>'


# Generated at 2022-06-25 12:46:02.993117
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def _dummy_handler(*args, **kwargs):
        print('_dummy_handler')

    event_source += _dummy_handler

    event_source.fire(1)
    event_source.fire(1, 2)
    event_source.fire(1, 2, 3)


# Generated at 2022-06-25 12:46:05.859034
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    import pytest

    event_source_0 = _EventSource()
    with pytest.raises(TypeError) as exec_info_0:
        event_source_0.fire()


# Generated at 2022-06-25 12:46:10.874959
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import sys

    test_case_id = 'unit_test_case_0'
    test_case_0()
    if not sys.exc_info():
        print('%s: PASSED' % test_case_id)
    else:
        print('%s: FAILED' % test_case_id)


if __name__ == '__main__':
    test__EventSource_fire()

# Generated at 2022-06-25 12:46:16.039809
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    target_1 = lambda *args, **kwargs: True

    # verify that target_1 is in the _handlers set
    assert target_1 in event_source_1._handlers

    # verify that when target_1 is called, it returns True
    assert event_source_1.fire()



# Generated at 2022-06-25 12:46:17.673811
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:46:22.525254
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event_source_0 = _EventSource()
        try:
            event_source_0.fire()
        except Exception as ex:
            raise AssertionError("An exception was raised when calling the function 'fire' of class '_EventSource'") from ex
    except Exception as ex:
        raise AssertionError("An exception was raised during calling the function 'test__EventSource_fire'") from ex


# Generated at 2022-06-25 12:46:24.631083
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0._on_exception is not None
    event_source_0.fire()


# Generated at 2022-06-25 12:46:27.580468
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:46:36.258693
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    arg_0 = to_text(None)
    arg_1 = None
    arg_2 = None
    arg_3 = to_text(None)
    arg_4 = to_text(None)
    arg_5 = to_text(None)
    arg_6 = to_text(None)
    arg_7 = to_text(None)
    arg_8 = to_text(None)
    arg_9 = to_text(None)
    if event_source_0.fire(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, arg_7, arg_8, arg_9):
        raise Exception('method fire of class _EventSource failed')


# Generated at 2022-06-25 12:48:40.176583
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    obj = _EventSource()
    # We expect this to work
    obj.fire()


# Generated at 2022-06-25 12:48:41.656180
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0.fire() == None


# Generated at 2022-06-25 12:48:48.166302
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0._handlers == set()
    event_source_0.fire()
    # class ansible_collections.ansible.builtin.plugins.module_utils.compat.CollectionLoader._EventSource:
    # Cannot analyze function fire


# Generated at 2022-06-25 12:48:49.635461
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup
    event_source_0 = _EventSource()

    # Exercise
    result = event_source_0.fire()

    # Verify
    assert result is None


# Generated at 2022-06-25 12:48:56.456679
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    e = event_source_0._on_exception(print, ValueError('hello'))
    event_source_0.fire(5)
    e = event_source_0._on_exception(print, ValueError('hello'))
    event_source_0.fire(6)
    e = event_source_0._on_exception(print, ValueError('hello'))
    event_source_0.fire(7)
    e = event_source_0._on_exception(print, ValueError('hello'))
    event_source_0.fire(8)
    e = event_source_0._on_exception(print, ValueError('hello'))
    event_source_0.fire(9)
    e = event_source_0._on_ex

# Generated at 2022-06-25 12:49:03.825275
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

    event_source_1 = _EventSource()

    def handler_1(arg_1, arg_2, arg_3, **kwargs):
        print('handler_1: %s %s %s' % (arg_1, arg_2, arg_3))

    event_source_1 += handler_1

    event_source_1.fire('a', 'b', 'c')
    event_source_1.fire('%s %s %s' % ('a', 'b', 'c'))
    event_source_1.fire('a', 'b', 'c')



# Generated at 2022-06-25 12:49:05.958430
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

# Generated at 2022-06-25 12:49:08.820768
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def test_event_handler_0(arg_0):
        pass

    event_source_1 += test_event_handler_0

    event_source_1.fire(1)


# Generated at 2022-06-25 12:49:11.148853
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TODO: test 'on_exception'
    assert _EventSource().fire() is None, 'unit test failed'


# Generated at 2022-06-25 12:49:19.135886
# Unit test for method fire of class _EventSource