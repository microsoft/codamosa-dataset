

# Generated at 2022-06-25 12:40:04.580960
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    # Note: The event source handler must be defined before hooking it up to the event source.
    #       This is because the handler will be called with any existing events.
    def event_handler_0(arg0):
        event_handler_0.events.append(arg0)

    event_handler_0.events = []

    # hook up our handler to the event source
    event_source_0.__iadd__(event_handler_0)
    assert len(event_handler_0.events) == 0, "'len(event_handler_0.events)' should have been 0"
    event_source_0.fire('hello')
    assert len(event_handler_0.events) == 1, "'len(event_handler_0.events)' should have been 1"
    event_source

# Generated at 2022-06-25 12:40:08.504810
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += lambda: 0  # <lambda>
    event_source_0 += lambda: 0  # <lambda>


# Generated at 2022-06-25 12:40:10.015065
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:40:15.306319
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test with an event source that was initialized but not configured with any handlers
    event_source_0 = _EventSource()
    event_source_0.fire()

    # Test with an event source that was initialized and configured with a handler
    event_source_1 = _EventSource()
    event_source_1 += lambda: True
    event_source_1.fire()


# Generated at 2022-06-25 12:40:17.132713
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:40:18.475330
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.fire()


# Generated at 2022-06-25 12:40:19.596455
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()



# Generated at 2022-06-25 12:40:24.437495
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def fun(a):
        print("Hello", a)
    event_source_0 += fun
    event_source_0 += fun
    event_source_0 += fun
    event_source_0.fire("World")


# Generated at 2022-06-25 12:40:28.565429
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    try:
        event_source_0 += None
    except ValueError:
        pass
    except Exception as ex:
        assert False, 'Exception raised: {}'.format(type(ex))
    else:
        assert False, 'No exception raised'


# Generated at 2022-06-25 12:40:30.443489
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:34.868275
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    assert True is False, "unimplemented"


# Generated at 2022-06-25 12:40:36.215584
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()


# Generated at 2022-06-25 12:40:39.477008
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

    event_source_0_1 = _EventSource()
    event_source_0_1.fire(2)


# Generated at 2022-06-25 12:40:41.188371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:44.229774
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += event_source_0
    event_source_0 += event_source_0
    try:
        event_source_0 += '0'
    except ValueError:
        pass


# Generated at 2022-06-25 12:40:46.157755
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test case 0
    event_source_0 = _EventSource()
    assert event_source_0.fire() is None


# Generated at 2022-06-25 12:40:47.733247
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0.fire()


# Generated at 2022-06-25 12:40:59.728428
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test case 0
    event_source_0 = _EventSource()
    value_0 = event_source_0.__iadd__(test_case_0)
    # Test case 1
    event_source_1 = _EventSource()
    value_1 = event_source_1.__iadd__()
    # Test case 2
    event_source_2 = _EventSource()
    value_2 = event_source_2.__iadd__(test_case_0)
    # Test case 3
    event_source_3 = _EventSource()
    value_3 = event_source_3.__iadd__(test_case_0)
    # Test case 4
    event_source_4 = _EventSource()
    value_4 = event_source_4.__iadd__(test_case_0)


# Generated at 2022-06-25 12:41:03.570664
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire(test_data_0)
    except ValueError:
        pass


# Generated at 2022-06-25 12:41:09.040079
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 = event_source_0 + (lambda *a, **kw: int())
    event_source_0 = event_source_0 - (lambda *a, **kw: int())
    event_source_0.fire()


# Generated at 2022-06-25 12:41:18.210423
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Testing for ValueError('handler must be callable')
    try:
        event_source_0 = _EventSource()
        event_source_0.__iadd__(1)
        assert False
    except ValueError:
        pass

    # Testing for normal operation
    event_source_0 = _EventSource()
    event_source_1 = event_source_0.__iadd__(lambda: True)
    assert event_source_0 == event_source_1



# Generated at 2022-06-25 12:41:19.126768
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pass


# Generated at 2022-06-25 12:41:21.423657
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:24.073127
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # arrange
    event_source = _EventSource()

    # act
    var = event_source.fire()

    # assert
    assert var is None



# Generated at 2022-06-25 12:41:25.573196
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert _EventSource.fire(None, None) is None



# Generated at 2022-06-25 12:41:27.804971
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = None
    event_source_0 = _EventSource()
    event_source_0.__iadd__(test_case_0)


# Generated at 2022-06-25 12:41:32.899437
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    #
    # _EventSource:
    #    def fire(self, *args, **kwargs):
    #
    # NOTE: class _EventSource has no implementation of method fire.
    #       This is a unit test which may fail if the implementation changes.
    #       The test cannot be automatically generated.
    #
    #       This unit test is provided in order to provide test coverage
    #       for this class and method.
    #
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:34.575169
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:41:36.738118
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire('some string')


# Generated at 2022-06-25 12:41:39.910216
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    event_source_0 += var_0


# Generated at 2022-06-25 12:41:47.644570
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    var_1 = _EventSource()
    var_2 = lambda: None

    var_1 += var_2
    var_3 = var_1._handlers

    assert len(var_3) == 1
    assert var_2 in var_3


# Generated at 2022-06-25 12:41:50.293093
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    # TODO: update to use a real function
    event_source_0.__iadd__(lambda: None)


# Generated at 2022-06-25 12:41:52.086830
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:41:55.504372
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_1 = None
    def handler(self, *args, **kwargs):
        pass
    handler_0 = handler

# Generated at 2022-06-25 12:41:59.691798
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        # Dummy test case to test method fire of class _EventSource
        event_source_0 = _EventSource()
        var_0 = event_source_0.fire()
    except:
        pass


# Generated at 2022-06-25 12:42:02.690947
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:04.704737
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:07.995026
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    func_0 = lambda: None

# Generated at 2022-06-25 12:42:09.921247
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()




# Generated at 2022-06-25 12:42:14.292107
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_1 = event_source_0
    event_source_1 += (lambda: print("{{ print('lambda:') + print(lambda: print('lambda_0')) }}"))
    # Does not raise exception
    var_0 = event_source_1.fire()

# Generated at 2022-06-25 12:42:18.533516
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:42:20.159339
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Setup test: no op
    assert True

    # Execute test: call the method under test
    var_0 = event_source_0.fire()

    # Verify the test: no op
    assert True



# Generated at 2022-06-25 12:42:22.092715
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:23.791771
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:25.533078
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource_obj = _EventSource()

    # Call method fire
    _EventSource_obj.fire()



# Generated at 2022-06-25 12:42:26.811309
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    var = event_source.fire()


# Generated at 2022-06-25 12:42:31.045159
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """Test the method fire of class _EventSource"""
    # Configure the test case
    event_source_0 = _EventSource()
    handler_0 = event_source_0
    Exception_0 = ValueError('abc')
    # Execute the tested code
    var_0 = event_source_0.fire(handler_0, Exception_0)


# Generated at 2022-06-25 12:42:32.410881
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:33.098502
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass  # Nothing to test



# Generated at 2022-06-25 12:42:35.444535
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

test_case_0()
test__EventSource_fire()

# Generated at 2022-06-25 12:42:46.912397
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:55.828583
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Stub
    class Stub(object):
        def __init__(self):
            self.result = None

        def __call__(self, *args, **kwargs):
            self.result = args, kwargs
            return self.result

    # Arrange
    event_source_0 = _EventSource()

    # Act
    stub = Stub()
    event_source_0 += stub
    event_source_0.fire(1, 2, 3, a=4, b=5, c=6)
    event_source_0 -= stub
    event_source_0.fire(1, 2, 3, a=4, b=5, c=6)

    # Assert
    assert stub.result == ((1, 2, 3), {'a': 4, 'b': 5, 'c': 6})



# Generated at 2022-06-25 12:42:57.911191
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:42:59.668263
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:01.328349
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:02.413044
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()


# Generated at 2022-06-25 12:43:04.038679
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:05.638219
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:06.963437
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    expected = None
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert expected == var_0

# Generated at 2022-06-25 12:43:08.260081
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance_variable = _EventSource()
    assert instance_variable.fire() == None


# Generated at 2022-06-25 12:43:28.898650
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:31.803876
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_args_0 = [
        ()]
    test_kwargs_0 = {}
    test_case_0(**test_kwargs_0)


# Generated at 2022-06-25 12:43:41.080434
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # the unit test can be run with "python-m pytest test/unit/utils/collection_loader/test_event_source.py"
    # in the "test/unit/utils/collection_loader" directory
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 == None, "test_case_0 failed:  expected <class 'NoneType'> but got {}".format(type(var_0))

if __name__ == "__main__":
    test__EventSource_fire()

# Generated at 2022-06-25 12:43:44.626902
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        var_0 = event_source_0.fire()
    except Exception as e:
        print("An exception occurred in test__EventSource_fire: {}".format(e))


# Generated at 2022-06-25 12:43:46.178543
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:43:49.286689
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()

    # Unit test for function fire of _EventSource
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:43:50.943680
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:43:52.981038
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # no handlers, should not raise
    event_source_0.fire()



# Generated at 2022-06-25 12:43:56.098872
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event_source_0 = _EventSource()
        var_0 = event_source_0.fire()
    except Exception as ex:
        assert False, 'Unexpected exception raised when calling event_source_0.fire(): %s' % ex


# Generated at 2022-06-25 12:43:57.470868
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:44:26.981360
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# CAUTION: There are two implementations of the collection loader.
#          They must be kept functionally identical, although their implementations may differ.
#
# 1) The controller implementation resides in the "lib/ansible/utils/collection_loader/" directory.
#    It must function on all Python versions supported on the controller.
# 2) The ansible-test implementation resides in the "test/lib/ansible_test/_util/target/legacy_collection_loader/" directory.
#    It must function on all Python versions supported on managed hosts which are not supported by the controller.


# Generated at 2022-06-25 12:44:32.485243
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1._handlers = set()
    event_source_1._handlers.add([])
    event_source_1._handlers.add(set())
    event_source_1._handlers.add(dict())
    event_source_1._handlers.add(lambda: True)
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:44:33.979449
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:35.298090
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert callable(_EventSource.fire)


# Generated at 2022-06-25 12:44:39.416791
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test is dependent on current environment settings
    if not AnsibleCollectionConfig.collection_finder:
        return

    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:44:40.792133
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 12:44:42.394127
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:44.075588
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:45.728240
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:47.817126
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_0 = event_source_1.fire()


# Generated at 2022-06-25 12:45:34.667213
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:45:38.548142
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    #  create an instance of _EventSource
    event_source_0 = _EventSource()
    #  call fire on the instance
    var_0 = event_source_0.fire()

test_case_0()
test__EventSource_fire()

# Generated at 2022-06-25 12:45:39.755668
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:41.882733
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

    # assert var_0 is None



# Generated at 2022-06-25 12:45:46.312364
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # arrange
    event_source_0 = _EventSource()
    # act
    var_0 = event_source_0.fire()
    # assert
    assert var_0 is None



# Generated at 2022-06-25 12:45:48.882968
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ctx = _AnsibleCollectionConfig()
    event_source_0 = _EventSource()
    ctx._EventSource_fire(event_source_0)



# Generated at 2022-06-25 12:45:51.635202
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except TypeError:
        pass
    else:
        raise AssertionError('Unreachable')


# Generated at 2022-06-25 12:45:56.530057
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 is None
    event_source_0 += lambda: None
    var_1 = event_source_0._on_exception(
        lambda: None,
        Exception(),
    )
    assert var_1
    event_source_0 += lambda: None
    event_source_0.fire()
    event_source_0 -= lambda: None


# Generated at 2022-06-25 12:45:58.911408
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Call method fire
    res_0 = event_source_0.fire()
    assert res_0 is None



# Generated at 2022-06-25 12:46:00.574369
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 = event_source_0
    ret_0 = event_source_0.fire()
    assert ret_0 is None
    pass

# Generated at 2022-06-25 12:47:40.341410
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:47:41.026852
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert test_case_0() is None

# Generated at 2022-06-25 12:47:49.087265
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_1 = _EventSource()
    event_source_2 = _EventSource()
    event_source_3 = _EventSource()
    event_source_4 = _EventSource()
    event_source_5 = _EventSource()
    event_source_6 = _EventSource()
    event_source_7 = _EventSource()
    event_source_8 = _EventSource()
    event_source_9 = _EventSource()
    event_source_10 = _EventSource()
    event_source_11 = _EventSource()
    event_source_12 = _EventSource()
    event_source_13 = _EventSource()
    handler_0 = event_source_0.fire
    handler_1 = event_source_1.fire

# Generated at 2022-06-25 12:47:50.461189
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:47:51.273320
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:47:52.522354
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:47:54.306499
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert True


# Generated at 2022-06-25 12:47:55.439614
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_1 = test_case_0()
    assert var_1 is None



# Generated at 2022-06-25 12:47:58.020706
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Parameter int is not used in code, so we suppress warnings using this line
    int = 1
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()
    assert var_1 == None

# Generated at 2022-06-25 12:48:00.211129
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event += print
    var_0 = event.fire("this is the first test")
