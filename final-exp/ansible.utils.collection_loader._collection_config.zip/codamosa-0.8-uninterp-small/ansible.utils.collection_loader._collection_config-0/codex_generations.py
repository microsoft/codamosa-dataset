

# Generated at 2022-06-25 12:39:57.449176
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += lambda : print('thumb')


# Generated at 2022-06-25 12:40:07.608399
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test data
    event_source_0 = _EventSource()
    # 
    event_source_0 += lambda : None
    # 
    event_source_0 -= lambda : None
    # 
    event_source_0 = _EventSource()
    # 
    event_source_0 += lambda : None
    # 
    event_source_0 -= lambda : None
    # 
    event_source_0 += lambda : None
    # 
    event_source_0 -= lambda : None
    # 
    event_source_0 += lambda : None
    # 
    event_source_0 -= lambda : None
    # 
    event_source_0 += lambda : None
    # 
    event_source_0 -= lambda : None
    # 
    event_source_0 += lambda : None
   

# Generated at 2022-06-25 12:40:09.415520
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:40:18.805175
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Test case 0
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 is None

    # Test case 1
    event_source_0 = _EventSource()
    event_source_0 += lambda: None
    var_0 = event_source_0.fire()
    assert var_0 is None

    # Test case 2
    event_source_0 = _EventSource()
    event_source_0 += lambda: None
    event_source_0 += lambda: None
    var_0 = event_source_0.fire()
    assert var_0 is None

    # Test case 3
    event_source_0 = _EventSource()
    event_source_0 += lambda: None
    event_source_0 += lambda: None
    event_source_1

# Generated at 2022-06-25 12:40:20.613445
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj = _EventSource()

    def fake_handler():
        pass

    obj += fake_handler


# Generated at 2022-06-25 12:40:27.008250
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Create instance of class '_EventSource'
    event_source_0 = _EventSource()

    # Call method __iadd__ of event_source_0 with argument event_source_0
    var_0 = event_source_0.__iadd__(event_source_0)

    # Compare var_0 from called method __iadd__ with var_0
    # method __iadd__ should return var_0
    assert var_0 == var_0


# Generated at 2022-06-25 12:40:30.443825
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__
    assert var_0 == event_source_0.__iadd__


# Generated at 2022-06-25 12:40:36.523475
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    handler_0 = lambda x: None
    try:
        event_source_0 += handler_0
        handler_1 = lambda x: None
    except Exception as ex:
        var_1 = isinstance(ex, ValueError)
    else:
        var_1 = False
    finally:
        event_source_0 -= handler_0

    event_source_1 = _EventSource()
    handler_2 = lambda x: None
    event_source_1 += handler_2
    var_2 = event_source_1.fire()
    event_source_1 -= handler_2


# Generated at 2022-06-25 12:40:38.794592
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:40:42.211079
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    print('\n<==== Test: __iadd__ of class _EventSource')
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(1)
    print('====>\n')
    return


# Generated at 2022-06-25 12:40:49.530724
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    handler_0 = lambda *args, **kwargs: print('event_source_0.fire is firing')
    event_source_0 += handler_0
    assert len(event_source_0._handlers) == 1


# Generated at 2022-06-25 12:40:59.000674
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire(1)
    event_source_0.fire(a=1)
    event_source_0.fire(1,2,3,4)
    event_source_0.fire(1,2,a=1,b=2,c=3)
    event_source_0.fire(a=1,b=2,c=3,d=4)
    event_source_0.fire(a=1,b=2,c=3,d=4,e=5)

# Generated at 2022-06-25 12:41:01.260227
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += lambda: None
    try:
        event_source_0 += 'abc'
        assert False
    except ValueError:
        pass


# Generated at 2022-06-25 12:41:07.960159
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire(foo=1)
    event_source_0.fire(1, 2, 3)
    event_source_0.fire(1, 2, 3, foo=1)
    event_source_0.fire(1, 2, 3, foo=1, bar=2)


# Generated at 2022-06-25 12:41:12.658731
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    # call method __iadd__ with suitable arguments
    event_source_0_0 = event_source_0.__iadd__(test_case_0)

    assert event_source_0_0 is event_source_0


# Generated at 2022-06-25 12:41:20.124618
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test method fire of class _EventSource
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils._text import to_bytes, to_text
    from textwrap import dedent
    event_source_0 = _EventSource()

    def fire_handler(x):
        # Convert args to supported types
        x = to_text(x, nonstring='passthru', errors='strict')

    event_source_0 += fire_handler
    event_source_0.fire('foo')


# Generated at 2022-06-25 12:41:21.905987
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:41:24.770774
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += event_source_1.fire
    event_source_1.fire()


# Generated at 2022-06-25 12:41:26.721066
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create an instance of _EventSource and instantiate the event source
    event_source_0 = _EventSource()
    event_source_0.fire("bogus event args", "bogus event kwargs")



# Generated at 2022-06-25 12:41:30.278609
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def handler_0(arg_0, arg_1):
        (arg_0, arg_1)

    event_source_0 += handler_0

    event_source_0.fire('arg_0', 'arg_1')



# Generated at 2022-06-25 12:41:38.780850
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except Exception as ex:
        if False:
            raise
    else:
        assert True


# Generated at 2022-06-25 12:41:40.432819
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    with pytest.raises(ValueError) as excinfo:
        test_case_0()
    assert "handler must be callable" in str(excinfo.value)

if __name__ == '__main__':
    test__EventSource_fire()

# Generated at 2022-06-25 12:41:44.577843
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire(1, 2, 3)
    except TypeError:
        pass

    try:
        event_source_0.fire()
    except TypeError:
        pass


# Generated at 2022-06-25 12:41:51.454935
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Set up test
    # test _EventSource
    event_source_0 = _EventSource()

    def handler_0(event=None, *args, **kwargs):
        pass

    handler_0_collection = (handler_0,)
    handler_0 = handler_0_collection[0]

    # Test body
    event_source_0 += handler_0
    event_source_0.fire()



# Generated at 2022-06-25 12:41:52.584269
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    with pytest.raises(NotImplementedError):
        event_source_0 = _EventSource()


# Generated at 2022-06-25 12:41:54.215606
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(arg):
        handler.called = True

    handler.called = False

    event_source += handler
    event_source.fire('arg')

    assert handler.called is True



# Generated at 2022-06-25 12:41:59.439452
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_1 = _EventSource()

    def test_function_0():
        pass

    def test_function_1():
        raise RuntimeError

    event_source_1 += test_function_0
    event_source_1 += test_function_1

    try:
        event_source_1.fire()

    # TODO: add test for exception
    except Exception:
        pass



# Generated at 2022-06-25 12:42:02.450254
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:08.044252
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire(1)
    event_source_0.fire(False)
    event_source_0.fire(3, 4)
    event_source_0.fire(True, False)
    event_source_0.fire(None, None, None)


# Generated at 2022-06-25 12:42:10.395630
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire(0, 1, 2)


# Generated at 2022-06-25 12:42:19.207792
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_1 = _EventSource()
    var_1 = event_source_1.__iadd__(event_source_1)



# Generated at 2022-06-25 12:42:20.011221
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:25.999811
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_1 = event_source_0.__iadd__(event_source_0)
    var_2 = event_source_0.__iadd__(event_source_0)
    var_3 = event_source_0.__iadd__(event_source_0)
    var_4 = event_source_0.__iadd__(event_source_0)
    var_5 = event_source_0.fire()


# Generated at 2022-06-25 12:42:28.549407
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 = event_source_0.__iadd__(event_source_0)
    event_source_0.fire()


# Generated at 2022-06-25 12:42:30.089213
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:32.891914
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_2 = _EventSource()
    event_source_2.__iadd__(event_source_1)
    event_source_2.fire()


# Generated at 2022-06-25 12:42:38.368845
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()
    event_source_0.fire()
    exception_0 = None
    exception_0 = False
    try:
        event_source_0.__iadd__('')
        exception_0 = True
    except ValueError:
        pass
    if exception_0:
        raise AssertionError('unexpected ValueError')
    exception_0 = None
    exception_0 = False
    try:
        event_source_0.__isub__('')
        exception_0 = True
    except ValueError:
        pass
    if exception_0:
        raise AssertionError('unexpected ValueError')
    # Test for function fire
    # Test for function fire
    # Test for function fire
    # Test for function fire
    pass


# Generated at 2022-06-25 12:42:40.925164
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj = _EventSource()
    try:
        obj.__iadd__()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 12:42:44.936265
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(event_source_0)
    var_1 = event_source_0.fir

# Generated at 2022-06-25 12:42:47.562134
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    value_0 = event_source_0.__iadd__(event_source_0)
    value_1 = event_source_0.fire('str')


# Generated at 2022-06-25 12:43:07.917670
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        # unit test code
        event_source_0._on_exception = lambda *args, **kwargs: False
        try:
            event_source_0.fire()
        except Exception:
            pass

        event_source_0._on_exception = lambda *args, **kwargs: True
        try:
            event_source_0.fire()
        except Exception:
            pass

    except Exception as error_0:
        raise RuntimeError('test failure')


# Generated at 2022-06-25 12:43:09.145761
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:15.936219
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    # CAUTION: The controller implementation of __iadd__ will raise a TypeError if the callable passed to __iadd__ does not have a __call__ method.
    #          The ansible-test implementation of __iadd__ will raise a TypeError if the callable passed to __iadd__ does not have a __call__ method.
    with raises(TypeError):
        var_1 = event_source_0.__iadd__(None)


# Generated at 2022-06-25 12:43:16.813261
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pass


# Generated at 2022-06-25 12:43:17.676967
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance = _EventSource()
    instance.fire()

# Generated at 2022-06-25 12:43:18.943685
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:43:28.849601
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # NOTE: The following is a test-generated stub that emulates
    #       a call to the _EventSource class.
    event_source_0 = _EventSource()

    try:
        var_0 = event_source_0.__iadd__(1)
    except ValueError as e:
        assert True
    else:
        assert False, "Expected Exception but got None."

    # NOTE: The following is a test-generated stub for testing the implementation of
    #       the handler for the __iadd__ method of the EventSource class.
    @event_source_0.__iadd__
    def _handler_0(*args, **kwargs):
        pass

    event_source_0.fire()


# Generated at 2022-06-25 12:43:32.750496
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.__iadd__(event_source_0)
        event_source_0.fire()
    except:
        pass



# Generated at 2022-06-25 12:43:36.427504
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:40.985745
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0._on_exception(
        event_source_0,
        event_source_0,
        event_source_0,
        event_source_0,
        event_source_0,
        event_source_0,
        event_source_0)


# Generated at 2022-06-25 12:44:10.375766
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:44:11.697635
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()


# Generated at 2022-06-25 12:44:14.200943
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    read_0 = event_source_0._on_exception(event_source_0, None)
    var_0 = event_source_0.fire(False, False)

# Generated at 2022-06-25 12:44:18.313855
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.six import assertRaisesRegex
    event_source_0 = _EventSource()
    assertRaisesRegex(AssertionError, 'Argument not callable', event_source_0.__iadd__, 'test_arg_0')
    event_source_0.fire()


# Generated at 2022-06-25 12:44:20.324024
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    if event_source_0.__iadd__(event_source_0) is not None:
        raise AssertionError


# Generated at 2022-06-25 12:44:23.276252
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_2 = event_source_1.fire()


# Generated at 2022-06-25 12:44:31.242105
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    try:
        var_0 = event_source_0.__iadd__(event_source_0)
    except ValueError as e_0:
        assert str(e_0) == 'handler must be callable'

    def function_0():
        pass

    try:
        event_source_0.__iadd__(function_0)
    except Exception as e_1:
        assert False, 'Unexpected exception thrown: {}'.format(e_1)
    try:
        event_source_0.__iadd__(function_0)
    except ValueError as e_2:
        assert str(e_2) == 'handler must be callable'



# Generated at 2022-06-25 12:44:34.964132
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    try:
        event_source_0 = _EventSource()
    except NameError:
        event_source_0 = None
    try:
        var_0 = event_source_0.__iadd__(event_source_0)
    except NameError:
        var_0 = None
    return var_0



# Generated at 2022-06-25 12:44:38.104445
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Function with argument
    # Function without argument
    event_source_0.fire()


# Generated at 2022-06-25 12:44:40.920766
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_1 = event_source_0
    var_1 = event_source_1.__iadd__(42)



# Generated at 2022-06-25 12:45:40.038300
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    with pytest.raises(ValueError, match=r"handler must be callable"):
        event_source_0.__iadd__(None)


# Generated at 2022-06-25 12:45:43.128071
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 12:45:46.511318
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_0 = _EventSource()
    var_1 = var_0.fire()


# Generated at 2022-06-25 12:45:49.035258
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire("\x12\x00\x01\x00\x02\x00")


# Generated at 2022-06-25 12:45:51.798775
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(event_source_0)
    assert var_0 == event_source_0


# Generated at 2022-06-25 12:45:53.940606
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(event_source_0)


# Generated at 2022-06-25 12:45:55.977911
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Locally disable the pylint check, long lines are sometimes preferred
# pylint: disable=C0301

# Generated at 2022-06-25 12:45:59.117299
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # force argument types
    var_0 = event_source_0.__iadd__("")
    event_source_0.fire(args="", kwargs="")


# Generated at 2022-06-25 12:46:00.120215
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:46:01.252283
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:48:09.611402
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # initialize _EventSource object
    event_source_0 = _EventSource()
    # test method fire of class _EventSource
    # raise exception, we want to test handling
    try:
        event_source_0.fire()
    # excpetion raised
    except Exception as exc_0:
        assert type(exc_0) == AttributeError
        assert str(exc_0) == "_handlers not defined"
        return
    # unexpected success
    raise Exception('no exception thrown')


# Generated at 2022-06-25 12:48:10.206323
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()



# Generated at 2022-06-25 12:48:13.009719
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(event_source_0)
    var_0 = event_source_0.fire()


if __name__ == "__main__":
    test_case_0()
    test__EventSource_fire()

# Generated at 2022-06-25 12:48:13.941506
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass



# Generated at 2022-06-25 12:48:16.894670
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    var_0 = _EventSource()

    # Test cases

    var_0.fire()


# Generated at 2022-06-25 12:48:18.637075
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource().__iadd__('test_0')


# Generated at 2022-06-25 12:48:21.065542
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(event_source_0)


# Generated at 2022-06-25 12:48:25.707544
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def event_handler_0(exc, *args, **kwargs):
        if args:
            var_0 = args[0]
            var_1 = args[1]

    event_source_0 = _EventSource()
    event_source_0.on_exception = event_handler_0
    event_source_0.fire(1, 2)


# Generated at 2022-06-25 12:48:28.464753
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1._on_exception(event_source_1, event_source_1)
    event_source_1.fire(event_source_1)


# testing the event source methods

# Generated at 2022-06-25 12:48:29.591346
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()
