

# Generated at 2022-06-25 12:39:58.839974
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += lambda: ...
    try:
        event_source_0 += object
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-25 12:40:00.511634
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 12:40:01.392512
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()


# Generated at 2022-06-25 12:40:02.648797
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# Unit tests for class AnsibleCollectionConfig

# Generated at 2022-06-25 12:40:05.763379
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def handler(self, *args, **kwargs):
        pass

    event_source_0 += handler

    event_source_0.fire()

# Generated at 2022-06-25 12:40:10.387825
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += lambda : print('')
    assert isinstance(event_source_0._handlers, set)
    assert len(event_source_0._handlers) == 1



# Generated at 2022-06-25 12:40:12.851875
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:40:14.514821
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:16.031009
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:26.407889
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    # event_source_0.__iadd__(functools.partial(functools.partial, tempfile._mkstemp_inner, dir)) expected Exception: ValueError('handler must be callable',)
    # event_source_0.__iadd__(os.getcwd) expected Exception: ValueError('handler must be callable',)
    # event_source_0.__iadd__(test__EventSource___iadd__) expected Exception: ValueError('handler must be callable',)
    # event_source_0.__iadd__(_EventSource.__init__) expected Exception: ValueError('handler must be callable',)


# Generated at 2022-06-25 12:40:32.011147
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def func_0():
        return 42

    event_source_0.fire(func_0)


# Generated at 2022-06-25 12:40:36.232317
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    # Test with event handler that has incorrect type
    try:
        event_source_0.__iadd__(None)
    except ValueError as exc:
        ret_val_0 = isinstance(exc, ValueError) and 'handler must be callable' == str(exc)
    else:
        ret_val_0 = False

    assert ret_val_0


# Generated at 2022-06-25 12:40:38.059626
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:40:41.850835
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # calls private method _on_exception
    event_source_0.on_exception = my_on_exception
    # calls private method fire
    event_source_0.fire()
    assert event_source_0._handlers == set()



# Generated at 2022-06-25 12:40:43.283484
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:45.014251
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda: print('handler called')
    event_source.fire()


# Generated at 2022-06-25 12:40:47.645024
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def handler_0_0():
        pass

    event_source_1 += handler_0_0
    event_source_1.fire()


# Generated at 2022-06-25 12:40:51.280409
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    with pytest.raises(ValueError) as excinfo:
        event_source_0.fire()
    assert 'foo' in str(excinfo.value)


# Generated at 2022-06-25 12:40:58.210087
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    entry = []
    event_source_0 += (lambda *args, **kwargs: entry.append((args, kwargs)))

    # FIRE
    event_source_0.fire(1, 2, three=4)
    assert entry == [((1, 2), {'three': 4})]


# Generated at 2022-06-25 12:41:01.922650
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # method args
    event_source_0 = _EventSource()
    test_handler_0 = lambda: None

    # call method
    test_result_0 = event_source_0.__iadd__(test_handler_0)

    # assertions
    assert callable(test_handler_0)
    assert test_result_0 == event_source_0


# Generated at 2022-06-25 12:41:08.994359
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except:
        print('Failed to fire event')
        raise


# Generated at 2022-06-25 12:41:14.092925
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # set _handlers of event_source_0 to a mock function
    event_source_0._handlers = mock_function()
    # call method fire of event_source_0 with mock arguments
    event_source_0.fire()
    # check if the mock was called as expected
    assert mock_function.called


# Generated at 2022-06-25 12:41:16.191760
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:17.470292
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:41:19.080647
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0.fire()


# Generated at 2022-06-25 12:41:29.109193
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    print("Starting test of _EventSource.fire")

    # example of a simple handler
    def handler_0(*args, **kwargs):
        pass

    # example of a handler that takes a while to execute
    def handler_1(*args, **kwargs):
        import time
        time.sleep(1)

    # example of a broken handler
    def handler_2(*args, **kwargs):
        raise ValueError("This is a test of a bad handler")

    # example of a broken handler whose exception is handled
    def handler_3(*args, **kwargs):
        import time
        time.sleep(1)
        raise ValueError("This is a test of an ignored bad handler")

    event_source = _EventSource()
    event_source += handler_0
    event_source += handler_1
    event_source += handler_

# Generated at 2022-06-25 12:41:33.098653
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0(test_arg_0, test_arg_1):
        assert test_arg_0 == 1
        assert test_arg_1 == 2
        assert test_arg_0 + test_arg_1 == 3

    event_source_0 += handler_0
    event_source_0.fire(1, test_arg_1=2)

    event_source_0 -= handler_0
    event_source_0.fire(1, test_arg_1=2)



# Generated at 2022-06-25 12:41:36.000123
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except Exception as exc:
        assert str(exc) == 'handler must be callable'



# Generated at 2022-06-25 12:41:39.209352
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()

    expected = _EventSource()
    expected += lambda: True
    expected.fire()



# Generated at 2022-06-25 12:41:40.803500
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event += lambda *args, **kwargs: None
    event.fire()

# Generated at 2022-06-25 12:41:54.359903
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()

    def f(a, b):
        return a + b

    event_source_0 += f

    assert event_source_0.fire(1, 2) == 3


# Generated at 2022-06-25 12:41:55.949255
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except NotImplementedError:
        pass



# Generated at 2022-06-25 12:42:05.667063
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from test.lib.ansible_test._util.default_loader import _EventSource

    event_source_0 = _EventSource()
    event_source_0 += lambda x: x

    # exception is expected because no argument was passed to callable
    try:
        event_source_0.fire()
        HAS_EXCEPTION[0] = False
    except ValueError:
        HAS_EXCEPTION[0] = True

    assert HAS_EXCEPTION[0]

    event_source_0 = _EventSource()
    event_source_0 += lambda x: x

    # exception is expected because callable expects 5 arguments

# Generated at 2022-06-25 12:42:08.794855
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(lambda *args, **kwargs: None)
    event_source_0.fire()


# Generated at 2022-06-25 12:42:10.394247
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0.fire() is None


# Generated at 2022-06-25 12:42:12.474459
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:14.624207
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    event_source_0 = _EventSource()

    # Act
    event_source_0.fire()



# Generated at 2022-06-25 12:42:16.179492
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire



# Generated at 2022-06-25 12:42:18.045796
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = EventSource()
    with pytest.warns(UserWarning):
        event_source_0.fire()



# Generated at 2022-06-25 12:42:19.133340
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:42:31.739592
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:32.929405
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:36.626104
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0(*args, **kwargs):
        pass

    handler_0.__name__ = 'handler_0'

    event_source_0 += handler_0
    event_source_0.fire()



# Generated at 2022-06-25 12:42:39.037472
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_fire = _EventSource()
    try:
        event_source_fire.fire()
    except Exception as ex:
        pass


# Generated at 2022-06-25 12:42:40.351179
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource_fire_0()


# Generated at 2022-06-25 12:42:42.116315
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()


# Generated at 2022-06-25 12:42:51.350535
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    handler_1 = lambda args, kwargs: print('handler_1: ', args, kwargs)
    handler_2 = lambda args, kwargs: print('handler_2: ', args, kwargs)
    handler_3 = lambda args, kwargs: print('handler_3: ', args, kwargs)

    event_source_1.fire('event_1')

    event_source_1 += handler_1
    event_source_1 += handler_2
    event_source_1 += handler_3
    event_source_1.fire('event_2')

    event_source_1 -= handler_2
    event_source_1.fire('event_3')


# Generated at 2022-06-25 12:42:54.089316
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    def f1():
        return
    def f2():
        return
    e += f1
    e += f2
    e.fire()


# Generated at 2022-06-25 12:42:56.280322
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest
    # _EventSource.fire does not yet raise an exception
    obj = _EventSource()



# Generated at 2022-06-25 12:42:58.466990
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:11.905916
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:16.976754
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    counter = 0
    event_source_1.fire(counter)

    def handler_0(counter):
        counter += 1

    event_source_1 += handler_0

    event_source_1.fire(counter)
    assert counter == 1

    event_source_1.fire(counter)
    assert counter == 2


# Generated at 2022-06-25 12:43:18.228960
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()


# Generated at 2022-06-25 12:43:21.836679
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event_source_0 = _EventSource()
        # this should not raise
        event_source_0.fire()
    except Exception as ex:
        assert False, 'event_source_0.fire() raised exception: %s' % repr(ex)


# Generated at 2022-06-25 12:43:24.472826
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except ValueError as exception_0:
        pass
    else:
        raise Exception()


# Generated at 2022-06-25 12:43:34.732304
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()

    class Target:
        def __init__(self, name):
            self.name = name
            self.events = []

        def handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    args_0 = (1, 2)
    kwargs_0 = dict(a=3, b=4)

    t0 = Target('t0')
    t1 = Target('t1')
    t2 = Target('t2')

    e += t0.handler
    e += t1.handler
    e += t2.handler

    e.fire(*args_0, **kwargs_0)

    assert t0.events == [(args_0, kwargs_0)]

# Generated at 2022-06-25 12:43:36.950648
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(42)

# Generated at 2022-06-25 12:43:46.261063
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test case 1 - normal case
    def callback_func_1(arg_1, arg_2, arg_3):
        return arg_1 + arg_2 + arg_3

    event_source_0 += callback_func_1

    assert event_source_0.fire(1, 2, 3) == 6

    # Test case 2 - with exception
    def callback_func_2(arg_1, arg_2, arg_3):
        raise KeyError('Test exception')

    event_source_0 += callback_func_2

    flag = False
    try:
        event_source_0.fire(1, 2, 3) == 6
    except KeyError:
        flag = True

    assert flag == True



# Generated at 2022-06-25 12:43:47.655415
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:43:48.843172
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    handler_0 = lambda a, b: None
    event_source_0 += handler_0
    event_source_0.fire(1, 2)



# Generated at 2022-06-25 12:44:17.144888
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e0 = _EventSource()
    def mockHandlerFunction(*args, **kwargs):
        if len(args) != 0:
            raise Exception('mockHandlerFunction was passed arguments when a default value or None was specified')
        if len(kwargs) != 0:
            raise Exception('mockHandlerFunction was passed arguments when a default value or None was specified')
        return None
    e0 += mockHandlerFunction
    e0.fire()


# Generated at 2022-06-25 12:44:18.205736
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:44:21.189828
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

    assert True


# Generated at 2022-06-25 12:44:26.440489
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def _on_exception(handler, exc, *args, **kwargs):
        return True

    def _raise_exception():
        raise Exception('this is an expected error')

    source = _EventSource()
    source._on_exception = _on_exception
    source.fire()
    source += _raise_exception
    error_raised = False
    try:
        source.fire()
    except Exception:
        error_raised = True

    source -= _raise_exception
    if not error_raised:
        raise AssertionError('_EventSource.fire did not re-raise exceptions raised by handlers')

# Generated at 2022-06-25 12:44:27.871717
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:44:30.084794
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that with 0 handlers, the call succeeds
    event_source = _EventSource()
    event_source.fire()


# Generated at 2022-06-25 12:44:37.419963
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test assertion
    try:
        event_source_0.fire()
    except Exception as ex:
        if not isinstance(ex, NotImplementedError):
            raise AssertionError('False assertion')

    # Test case 1
    event_source_0 = _EventSource()
    try:
        event_source_0.fire(1, 2, 3)
    except Exception as ex:
        if not isinstance(ex, NotImplementedError):
            raise AssertionError('False assertion')

    # Test case 2
    event_source_0 = _EventSource()
    try:
        event_source_0.fire(1, 2, 3, 4)
    except Exception as ex:
        if not isinstance(ex, NotImplementedError):
            raise

# Generated at 2022-06-25 12:44:47.116532
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source = AnsibleCollectionConfig.on_collection_load

    def handler(n):
        pass

    # We should be able to add a handler using the += operator
    event_source += handler

    # We should be able to remove a handler using the -= operator
    event_source -= handler

    # We should be able to fire a handler
    event_source.fire()

    # An exception should be raised if add a handler that is not callable
    try:
        event_source.add(None)
        raise AssertionError('add should have raised a ValueError')
    except ValueError:
        pass

    # If an exception occurs in the handler, it should not stop the other handlers from being called
    count = [0, 0]

    def handler1(n):
        raise ValueError(n)


# Generated at 2022-06-25 12:44:49.053537
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Initialize a _EventSource object
    event_source_0 = _EventSource()

    # TODO: Add test code for method fire of class _EventSource
    assert True, "Test for method fire of class _EventSource failed"


# Generated at 2022-06-25 12:44:50.541998
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance_0 = _EventSource()
    with pytest.raises(ValueError, match="handler must be callable"):
        instance_0.fire()


# Generated at 2022-06-25 12:45:22.603768
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    for sig in (event_source_0.__iadd__, event_source_0.__isub__):
        try:
            sig(None)
            assert False, "Failed to raise exception for invalid handler"
        except ValueError:
            pass

    for sig in (event_source_0.__iadd__, event_source_0.__isub__):
        try:
            event_source_0.__isub__(None)
            assert False, "Failed to raise exception for invalid handler"
        except KeyError:
            pass

    recorded_events = []

    def exception_callback_0(*args, **kwargs):
        raise RuntimeError

    def exception_callback_1(*args, **kwargs):
        recorded_events.append(True)

    event

# Generated at 2022-06-25 12:45:31.828281
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.text.converters import to_text

    event_source_0 = _EventSource()

    # The first argument accepted by the handler.
    value_0 = to_text('value_0')

    # The second argument accepted by the handler.
    value_1 = to_text('value_1')

    def handler(argument_0, argument_1):
        assert value_0 == argument_0
        assert value_1 == argument_1

    event_source_0 += handler

    # Dispatch the event.
    event_source_0.fire(value_0, value_1)

    from ansible.module_utils.common.text.converters import to_text

    event_source_0 = _EventSource()

    # The first argument accepted by the handler.

# Generated at 2022-06-25 12:45:33.128494
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance = _EventSource()
    instance.fire()


# Generated at 2022-06-25 12:45:37.251249
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()
    event_source_0 = _EventSource()
    def handler_1(*args, **kwargs):
        pass
    event_source_0 += handler_1
    try:
        event_source_0.fire()
    except Exception as ex:
        raise ex


# Generated at 2022-06-25 12:45:38.507774
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:45:39.685896
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    print('Unit test for method fire of class _EventSource')
    test_case_0()



# Generated at 2022-06-25 12:45:49.736453
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """
    Tests _EventSource.fire with multiple handlers.
    """
    def h0():
        raise ZeroDivisionError('test__EventSource_fire')

    def h1():
        raise NameError('test__EventSource_fire')

    def h2():
        return True

    event_source = _EventSource()
    event_source += h0
    event_source += h1

    with pytest.raises(ZeroDivisionError):
        event_source.fire()

    with pytest.raises(NameError):
        event_source.fire()

    event_source.fire()

    event_source += h2
    with pytest.raises(NameError):
        event_source.fire()


# Generated at 2022-06-25 12:45:52.791313
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    target_0 = event_source_0._on_exception
    # This test case does not need asserts
    # We are only testing for coverage
    event_source_0.fire()
    pass


# Generated at 2022-06-25 12:46:01.221513
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    print("test_case_0")
    try:
        event_source_0.fire(True)
    except:
        pass

    print("test_case_1")
    try:
        event_source_0.fire(False)
    except:
        pass

    print("test_case_2")
    try:
        event_source_0.fire('a')
    except:
        pass

    print("test_case_3")
    try:
        event_source_0.fire(1)
    except:
        pass

    print("test_case_4")
    try:
        event_source_0.fire(True)
    except:
        pass

    print("test_case_5")

# Generated at 2022-06-25 12:46:08.622407
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire(b'', b'', b'')
    event_source_0.fire(b'', b'', b'', b'', b'', b'', b'', b'', b'', b'', b'', b'', b'', b'', b'', b'', b'', b'', b'')
    event_source_0.fire(b'', b'', b'', b'', b'')
    event_source_0.fire(b'', b'', b'')


# Generated at 2022-06-25 12:46:34.881948
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup
    event_source = _EventSource()

    # Exercise
    event_source.fire('test-0', 'test-1')

    # Verify
    # nothing to verify



# Generated at 2022-06-25 12:46:37.290156
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    event_source.fire()


# Generated at 2022-06-25 12:46:38.846488
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    e += lambda x: print(x)
    e.fire('hello world')


# Generated at 2022-06-25 12:46:41.269208
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def function_0(*args, **kwargs):
        return
    event_source_0 += function_0
    event_source_0.fire()
    event_source_0 -= function_0



# Generated at 2022-06-25 12:46:42.278611
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:46:45.151839
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    handler_0 = lambda: None
    event_source_0 += handler_0
    event_source_0 += handler_0

    try:
        event_source_0.fire()
    except Exception as caught_exception:
        assert False, 'Raised exception unexpectedly'



# Generated at 2022-06-25 12:46:49.739371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:46:59.903724
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test case where handler raises exception
    def handler_0():
        raise Exception()
    event_source_0 += handler_0
    try:
        event_source_0.fire()
    except Exception:
        pass
    else:
        assert False, 'Expected exception'

    # Test case where handler returns True from _on_exception
    def handler_1():
        raise Exception()
    def _on_exception_handler_1(handler, exc):
        return True
    event_source_0 += handler_1
    event_source_0._on_exception = _on_exception_handler_1
    try:
        event_source_0.fire()
    except Exception:
        pass
    else:
        assert False, 'Expected exception'

    #

# Generated at 2022-06-25 12:47:00.808384
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:47:10.451734
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import unittest

    class TestEventSourceFire(unittest.TestCase):
        def test__on_exception_0(self):
            event_source_0 = _EventSource()
            self.assertRaisesRegexp(ValueError, 'handler must be callable', event_source_0.fire, 42)

        def test__on_exception_1(self):
            args_0 = []

            def create_handler_0():
                def handler_0(*args, **kwargs):
                    args_0[:] = [args, kwargs]

                return handler_0

            handler_0 = create_handler_0()
            event_source_0 = _EventSource()
            event_source_0 += handler_0

            class CreateException0(Exception):
                pass


# Generated at 2022-06-25 12:48:07.988800
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test with '_EventSource' instance 'event_source_0' and parameters:
    event_source_0.fire()  # No exception should be raised

    event_source_0 += lambda *args, **kwargs: args  # No exception should be raised

    # Test with '_EventSource' instance 'event_source_0' and parameters:
    event_source_0.fire('foo', 'bar', kwarg=True)  # No exception should be raised

# Generated at 2022-06-25 12:48:09.623273
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    event_source_0 = _EventSource()

    # Act
    event_source_0.fire()


# Generated at 2022-06-25 12:48:11.795507
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0._on_exception(lambda *args, **kwargs: None, None, *(1, 2, 3), **{'x': 4}) is True


# Generated at 2022-06-25 12:48:13.117948
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:48:17.102891
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0(*args):
        pass

    event_source_0.fire(handler_0)
    event_source_0.fire()


# Generated at 2022-06-25 12:48:19.262662
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:48:24.047059
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0_fire_0
    _EventSource_fire_0 = _EventSource.fire
    _EventSource_fire_0(event_source_0)
    event_source_0._on_exception(event_source_0_fire_0, TypeError('no argument 2'))


# Generated at 2022-06-25 12:48:25.583049
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:48:28.966592
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Call method
    event_source_1 = event_source_0.fire()
    assert event_source_1 is None

    # Call method
    event_source_2 = event_source_0.fire()
    assert event_source_2 is None



# Generated at 2022-06-25 12:48:30.512436
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(None)

