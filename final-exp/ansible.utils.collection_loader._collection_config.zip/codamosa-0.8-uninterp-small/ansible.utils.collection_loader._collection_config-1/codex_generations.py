

# Generated at 2022-06-25 12:39:57.440282
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:39:59.220251
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    def func_0():
        return

    event_source_0 += func_0


# Generated at 2022-06-25 12:40:00.170650
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:40:10.763482
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes

    event_source_0 = _EventSource();

    class C1:
        def __init__(self):
            self.got_event = False

        def f1(self, *args, **kwargs):
            self.got_event = True

    sio = StringIO()
    b_sio = to_bytes(sio)
    c1 = C1()

    event_source_0 += c1.f1
    event_source_0.fire('x1', 'x2', sio=b_sio)

    assert c1.got_event is True

# Generated at 2022-06-25 12:40:14.306020
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

test__EventSource_fire()




# Generated at 2022-06-25 12:40:16.798354
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # event_source_0 is an empty _EventSource. It does not have an on_exception.
    event_source_0.fire()



# Generated at 2022-06-25 12:40:19.088404
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    t = event_source.fire()
    assert t is None


# Generated at 2022-06-25 12:40:23.836940
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    def function_0(*args, **kwargs):
        return

    event_source_0 += function_0

    def function_0(*args, **kwargs):
        return

    event_source_0 += function_0


# Generated at 2022-06-25 12:40:26.227060
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def handler_0(*args, **kwargs):
        pass
    event_source_0 += handler_0
    event_source_0.fire()


# Generated at 2022-06-25 12:40:27.351385
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    pass


# Generated at 2022-06-25 12:40:35.359759
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 12:40:38.513170
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    value = None
    with pytest.raises(ValueError):
        event_source_0 += value


# Generated at 2022-06-25 12:40:40.206536
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:44.858648
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0(*args, **kwargs):
        print('handler_0 called')

    def handler_1(*args, **kwargs):
        print('handler_1 called')
        raise ValueError('handler_1 exception')

    event_source_0 += handler_0
    event_source_0 += handler_1
    event_source_0.fire()



# Generated at 2022-06-25 12:40:55.927341
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Set up test
    event_source_0 = _EventSource()
    event_source_1 = _EventSource()
    args_0 = [2, 1, 3]
    kwargs_0 = {1: True, 2: 1, 3: '1'}

    # Call test method
    event_source_0.fire(*args_0, **kwargs_0)

    # Check results
    assert event_source_0._handlers == set()
    event_source_0 += event_source_1
    assert event_source_0._handlers == {event_source_1}
    assert event_source_0._on_exception(event_source_1, AssertionError('foo'), *args_0, **kwargs_0)

# Generated at 2022-06-25 12:41:00.214295
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:41:06.695991
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    try:
        event_source_0 += None
    except Exception as caught_exc:
        expected_exc = ValueError('handler must be callable')
        assert type(caught_exc) == type(expected_exc) and caught_exc.args == expected_exc.args


# Generated at 2022-06-25 12:41:11.611301
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += sum
    event_source_0 += sum

    try:
        event_source_0 += 1
        assert False
    except ValueError:
        pass

    # TODO: call fire, check results


# Generated at 2022-06-25 12:41:13.646420
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(1, 2, 3)


# Generated at 2022-06-25 12:41:17.060613
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    handler = lambda: print('hi')
    event_source_0.__iadd__(handler)
    event_source_0.__isub__(handler)


# Generated at 2022-06-25 12:41:30.167484
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except Exception:
        pass
    try:
        event_source_0.fire('abcd')
    except Exception:
        pass
    try:
        event_source_0.fire(s='abcd')
    except Exception:
        pass
    try:
        event_source_0.fire('abcd', s='abcd')
    except Exception:
        pass


# Generated at 2022-06-25 12:41:35.794040
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Case 0: empty event source
    try:
        event_source_0.fire()
    except Exception as e:
        assert False, "unexpected exception " + type(e).__name__

    # Case 1: callable
    def test_handler(data):
        pass

    event_source_0 += test_handler
    event_source_0.fire()

    # Case 2: event source, handler throws exception and _on_exception returns true
    def test_handler_2(data):
        raise ValueError('expected exception')

    event_source_0 = _EventSource()
    event_source_0 += test_handler_2

    try:
        event_source_0.fire()
        assert False, 'expected exception'
    except ValueError:
        pass

   

# Generated at 2022-06-25 12:41:39.347757
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


_AnsibleCollectionConfig.collection_finder = None
_AnsibleCollectionConfig.default_collection = None


# Generated at 2022-06-25 12:41:47.506474
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def _event_source_0_handler_0(exc, *args, **kwargs):
        pass
    event_source_0 += _event_source_0_handler_0
    event_source_0 -= _event_source_0_handler_0
    def _event_source_0_handler_1(exc, *args, **kwargs):
        pass
    event_source_0 += _event_source_0_handler_1
    event_source_0.fire()


# Generated at 2022-06-25 12:41:48.436497
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:41:56.671047
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception(lambda *a, **k: None, None, *(1,))
    event_source_0._on_exception(lambda *a, **k: None, None, *(), **{})
    event_source_0._on_exception(lambda *a, **k: None, None)
    event_source_0._on_exception(lambda *a, **k: None, None, *(), **{})
    event_source_0.fire()
    event_source_0.fire(*(), **{})
    event_source_0.fire(*(), **{})
    event_source_0.fire(*(), **{})



# Generated at 2022-06-25 12:41:59.876414
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(0.896772, 0.115976)



# Generated at 2022-06-25 12:42:07.903214
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handle_0(param_0, param_1, param_2=None):
        return param_0 + param_1 * param_2

    event_source_0 += handle_0

    handle_0_0 = event_source_0.fire(2, 3, param_2=4)
    assert handle_0_0 == 14

# Generated at 2022-06-25 12:42:10.184346
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire(x=0)


# Generated at 2022-06-25 12:42:19.305114
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestClass:
        def __init__(self, test_case):
            self._test_case = test_case

        def __call__(self, *args, **kwargs):
            self._test_case.assertTupleEqual(args, (1, 2, 3))
            self._test_case.assertDictEqual(kwargs, {'a': 'b', 'c': 'd'})
            self._test_case.result = True

        def __hash__(self):
            return random.randint(0, 100000)

    event_source_0 = _EventSource()
    test_class_0 = _TestClass(self)

    event_source_0 += test_class_0
    event_source_0.fire(1, 2, 3, a='b', c='d')
    self

# Generated at 2022-06-25 12:42:28.924195
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    expected_0 = None
    var_0 = _EventSource()
    var_1 = var_0.fire()
    assert var_1 == expected_0


# Generated at 2022-06-25 12:42:31.143590
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    event_source_0.fire(var_0)
    event_source_0.fire(var_0)


# Generated at 2022-06-25 12:42:32.458950
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:42.515143
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest
    import tempfile

    def _try_call():
        # Callable that raises expected exception
        return 1 / 0

    def _try_call_no_err():
        # Callable that does not raise expected exception
        pass

    # 0 calls to fire, no handlers
    event_source_0 = _EventSource()
    # Test call to fire: no handlers
    with pytest.raises(TypeError) as exec_info:
        var_0 = event_source_0.fire()

    # 0 calls to fire, one valid handler
    event_source_0 = _EventSource()
    # Test call to fire: no handlers
    with pytest.raises(TypeError) as exec_info:
         var_0 = event_source_0.fire()

    event_source_0 += _try_call_no

# Generated at 2022-06-25 12:42:46.953652
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:42:48.168375
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_1 = event_source_0.fire()
    assert var_1 is None



# Generated at 2022-06-25 12:42:49.671793
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:51.970899
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)


# Generated at 2022-06-25 12:42:53.635914
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert callable(_EventSource.fire)
    assert hasattr(_EventSource, 'fire')



# Generated at 2022-06-25 12:42:55.472995
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_1 = event_source_0.fire()

# Generated at 2022-06-25 12:43:12.494798
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 == None, "Didn't return None"



# Generated at 2022-06-25 12:43:18.648490
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    # Unit test for method setter of property default_collection of class AnsibleCollectionConfig
    def test_AnsibleCollectionConfig_default_collection_setter():
        ansible_collection_config_0 = AnsibleCollectionConfig()
        ansible_collection_config_0.default_collection = "ansible_collections.ansible.builtin"


# Generated at 2022-06-25 12:43:20.221120
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:22.136495
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create an instance of class _EventSource
    # Call method fire
    test_case_0()

# Generated at 2022-06-25 12:43:23.039420
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# Generated at 2022-06-25 12:43:24.236244
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    test_case_0()

# Generated at 2022-06-25 12:43:27.505212
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += lambda *args, **kwargs: print('hello world')
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:43:29.271020
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:31.459262
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:43:36.990654
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0.fire() == None
    assert event_source_0._handlers == set()



# Generated at 2022-06-25 12:44:15.887088
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    (element_0, element_1) = (0, 1)
    (element_2, element_3) = (0.0, 1.0)
    (element_4, element_5) = (element_0, element_1)
    (element_6, element_7) = (element_2, element_3)
    (element_8, element_9) = (element_0, element_1)
    (element_10, element_11) = (element_2, element_3)
    (element_12, element_13) = (element_0, element_1)
    (element_14, element_15) = (element_2, element_3)
    (element_16, element_17) = (element_0, element_1)

# Generated at 2022-06-25 12:44:21.040617
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Declare some variables
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:44:22.288286
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:23.444573
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # expectation: no exception
    test_case_0()


# Generated at 2022-06-25 12:44:26.618551
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._handlers.add(lambda field, values: values)
    event_source_0._handlers.add(lambda field, values: values)
    var_0 = event_source_0.fire(1, 2)


# Generated at 2022-06-25 12:44:28.072019
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    _EventSource_fire_0(event_source_0)



# Generated at 2022-06-25 12:44:31.282553
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert callable(AnsibleCollectionConfig.on_collection_load.fire)
    assert isinstance(AnsibleCollectionConfig.on_collection_load.fire, types.MethodType)



# Generated at 2022-06-25 12:44:32.423023
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource = get_class('_EventSource')
    var_0 = _EventSource()
    var_0.fire()



# Generated at 2022-06-25 12:44:36.618104
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert test_case_0() is None

test__EventSource_fire.to_replay = [{
    "in": {
        "args": [],
        "kwargs": {},
        "call_args": [],
        "call_kwargs": {}
    },
    "out": {
        "result": {
            "type": "NoneType",
            "value": None
        }
    }
}]


# stubs

# Generated at 2022-06-25 12:44:37.675678
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:46:00.582672
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:01.949059
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:46:04.062183
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:46:06.712498
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    # assert var_0 is None
    assert type(var_0) == type(None)


# Generated at 2022-06-25 12:46:08.420558
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:10.948959
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_0 = _EventSource()
    try:
        var_0.fire()
    except Exception as ex:
        print(ex)


# Generated at 2022-06-25 12:46:20.588523
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_0 = _EventSource()
    assert type(var_0) == _EventSource
    assert var_0.__class__.__name__ == "_EventSource"
    var_1 = var_0.__class__
    assert type(var_1) == _AnsibleCollectionConfig
    assert var_1.__class__.__name__ == "_AnsibleCollectionConfig"
    assert hasattr(var_1, "_AnsibleCollectionConfig__init__")
    assert hasattr(var_1, "_AnsibleCollectionConfig__iadd__")
    assert hasattr(var_1, "_AnsibleCollectionConfig__isub__")
    assert hasattr(var_1, "_AnsibleCollectionConfig__on_exception")
    assert hasattr(var_1, "_AnsibleCollectionConfig__fire")
    assert has

# Generated at 2022-06-25 12:46:22.778565
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = lambda handler, exc, *args, **kwargs: None
    event_source_0._handlers = set()
    var_0 = event_source_0.fire()
    assert var_0 is None


# Generated at 2022-06-25 12:46:28.783485
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_2 = event_source_1.__iadd__(None)
    event_source_3 = event_source_2.__isub__(None)
    var_1 = event_source_3.fire()

if __name__ == '__main__':
    test_case_0()
    test__EventSource_fire()

# Generated at 2022-06-25 12:46:31.097960
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test fixture
    obj_0 = _EventSource()

    # Test passes unconditionally
    pass


# Test for method _on_exception

# Generated at 2022-06-25 12:48:41.733143
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    try:
        event_source_0.fire()
    except Exception as e:
        assert False

    try:
        event_source_0.fire()
    except Exception as e:
        assert False


# Generated at 2022-06-25 12:48:46.722251
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0.fire()



# Generated at 2022-06-25 12:48:48.651148
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 is None

# Unit tests for property on_collection_load of class AnsibleCollectionConfig

# Generated at 2022-06-25 12:48:52.016334
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        var_1 = event_source_0.fire()
    except:
        print("!!An exception occurred while trying to test method fire")
        return
    if var_1 != None:
        print("!!The method fire did not return what was expected")
    else:
        print(">>The method fire returned what was expected")


# Generated at 2022-06-25 12:48:55.976970
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create an instance of a class with a _EventSource attribute
    event_source_0 = _TestClass_0._EventSource()
    # Create an instance of Exception
    exception_0 = Exception()
    try:
        # Call method fire of event_source_0 with error
        event_source_0.fire(exception_0)
    except Exception as exception_1:
        assert type(exception_1) is type(exception_0)


# Generated at 2022-06-25 12:48:57.174923
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:49:02.319824
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource__EventSource_fire_checks = [{'parameters': {}, 'expect': {'result': None}}, {'parameters': {}, 'expect': {'result': None}}]
    for check in _EventSource__EventSource_fire_checks:
        try:
            assert func_call(check['parameters'], check['expect'])
        except AssertionError:
            raise


# Generated at 2022-06-25 12:49:11.226860
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import random
    event_source_0 = _EventSource()
    handler_0 = lambda *args, **kwargs: None
    handler_1 = lambda *args, **kwargs: handler_0(args, kwargs)
    handler_2 = lambda *args, **kwargs: handler_1(args, kwargs)
    handler_3 = lambda *args, **kwargs: handler_2(args, kwargs)
    handler_4 = lambda *args, **kwargs: handler_3(args, kwargs)
    handler_5 = lambda *args, **kwargs: handler_4(args, kwargs)
    handler_6 = lambda *args, **kwargs: handler_5(args, kwargs)
    event_source_0 += handler_0


# Generated at 2022-06-25 12:49:13.006747
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event_source_0 = _EventSource()
        event_source_0.fire()
        var_0 = False
    except Exception as exception_1:
        var_0 = True

    assert var_0


# Generated at 2022-06-25 12:49:14.460042
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()