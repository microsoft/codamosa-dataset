

# Generated at 2022-06-25 12:40:02.239509
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    subject = _EventSource()
    def handler_0(self, args, kwargs):
        assert len(args) == 1
        assert kwargs == dict()
        assert args[0] == 'foo'
        subject -= handler_0

    def handler_1(self, args, kwargs):
        assert len(args) == 1
        assert kwargs == dict()
        assert args[0] == 'foo'
        subject -= handler_1

    subject += handler_0
    subject += handler_1
    subject.fire('foo')


# Generated at 2022-06-25 12:40:03.910858
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:09.140353
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj = _EventSource()
    value = True
    result = obj.__iadd__(value)
    assert obj._handlers == {True}, 'Expected {True}, but was: {obj._handlers}'
    assert result == obj, 'Expected: {obj}, but was: {result}'


# Generated at 2022-06-25 12:40:12.750129
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += print
    res = event_source_1.fire("Hello world")
    # res must equal 'Hello world\n'


# Generated at 2022-06-25 12:40:14.047946
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:40:15.912110
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    v0 = event_source_0.fire
    assert callable(v0)


# Generated at 2022-06-25 12:40:21.621922
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Verify _on_exception method call
    def _on_exception_0(handler0, exc0, *args0, **kwargs0):
        assert(isinstance(handler0, _EventSource))
        assert(isinstance(exc0, Exception))
        assert(isinstance(args0, tuple))
        assert(isinstance(kwargs0, dict))
        return True
    _EventSource._on_exception = _on_exception_0
    # Verify call to fire
    try:
        event_source_0.fire()
    except Exception as ex:
        assert(isinstance(ex, Exception))


# Generated at 2022-06-25 12:40:26.765238
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    def handler(self_0, *args, **kwargs):
        pass
    event_source_0 += handler
    def handler_0(self_0, *args, **kwargs):
        pass
    event_source_0 += handler_0
    assert event_source_0._handlers.__len__() == 2


# Generated at 2022-06-25 12:40:29.165154
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:31.012870
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # expectation is that no exception is raised
    event_source_0.fire()


# Generated at 2022-06-25 12:40:36.390713
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += nonexistent_function
    event_source_0 += test__EventSource___iadd__



# Generated at 2022-06-25 12:40:40.161182
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    assert event_source_0._handlers == set()
    event_source_0.__iadd__(list)
    assert event_source_0._handlers == {list}



# Generated at 2022-06-25 12:40:43.283867
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    handler_0 = lambda a: print(a)
    event_source_0 += handler_0
    event_source_0.fire('hello')
    event_source_0.fire('world')


# Generated at 2022-06-25 12:40:45.043534
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except TypeError as exc:
        assert exc.args[0] == 'fire() takes no arguments (1 given)'


# Generated at 2022-06-25 12:40:56.900974
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire(arg_0=True)
    event_source_0.fire(arg_0=True, arg_1=True)
    event_source_0.fire(arg_0=True, arg_1=True, arg_2=object())
    event_source_0.fire(arg_0=True, arg_1=True, arg_2=object(), arg_3=True)
    event_source_0.fire(arg_0=True, arg_1=True, arg_2=object(), arg_3=True, arg_4=object())

# Generated at 2022-06-25 12:40:58.707027
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:41:01.574559
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    param_0 = []
    param_1 = {}
    try:
        event_source_0.fire(param_0, ** param_1)
    except Exception as err:
        assert False, str(err)



# Generated at 2022-06-25 12:41:04.270448
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    __tracebackhide__ = True
    assert event_source_0.fire() == None
    event_source_0.fire()

# Generated at 2022-06-25 12:41:10.820430
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0(arg0, arg1):
        return

    def handler_1():
        return

    event_source_0 += handler_0
    event_source_0 += handler_1

    event_source_0.fire('arg0', arg1='arg1')


# Generated at 2022-06-25 12:41:13.462832
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    # Call method
    event_source_0.__iadd__(lambda: None)

    assert event_source_0 is not None



# Generated at 2022-06-25 12:41:20.707569
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(1, 2)

if __name__ == '__main__':
    # run the tests
    test_case_0()
    test__EventSource_fire()

# Generated at 2022-06-25 12:41:26.730547
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0():
        print("This is event handler 0")

    def handler_1():
        print("This is event handler 1")

    event_source_0 += handler_0
    event_source_0.fire()

    event_source_0 += handler_1
    event_source_0.fire()

    event_source_0 -= handler_0
    event_source_0.fire()



# Generated at 2022-06-25 12:41:28.632264
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

    # after firing once, we should have handlers
    assert event_source_0._handlers



# Generated at 2022-06-25 12:41:30.783058
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except ValueError as err:
        assert False


# Generated at 2022-06-25 12:41:34.385585
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup
    event_source_0 = _EventSource()

    # Test
    event_source_0.fire()

    # Verify
    assert True


# Generated at 2022-06-25 12:41:36.562870
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # No error should be raised on fire
    event_source_0.fire()



# Generated at 2022-06-25 12:41:39.082316
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:42.916961
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Find some example parameters.
    event_source_0 = _EventSource()
    event_source_1 = _EventSource()
    event_source_0.fire()
    event_source_1.fire()



# Generated at 2022-06-25 12:41:44.490191
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_event_source = _EventSource()
    ansible_event_source.fire()


# Generated at 2022-06-25 12:41:46.367345
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:41:55.941732
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # a handler that adds one and one, but throws when called with bad args
    handler_0 = lambda x: x + 1
    event_source_0 = _EventSource()

    # test we got an error when we passed something other than callable
    try:
        event_source_0.fire(handler_0)
    except ValueError as e:
        pass

    # test we got no error when we passed a callable
    event_source_0 += handler_0
    event_source_0.fire(0)



# Generated at 2022-06-25 12:41:59.364425
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0 += event_source_0.fire



# Generated at 2022-06-25 12:42:02.939284
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # call callable_lambda_0 with args
    # verify that callable_lambda_0 was called


# Generated at 2022-06-25 12:42:12.216275
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from test.unit.collection_loader.test_extra_features.conftest import AnsibleCollectionConfig
    from ansible_collections.ansible.misc.plugins.module_utils._text import to_text

    original_AnsibleCollectionConfig = AnsibleCollectionConfig
    try:
        for value in [True, False]:
            AnsibleCollectionConfig = test__EventSource_fire.mock_AnsibleCollectionConfig(value)
            _EventSource_instance = _EventSource()
            _EventSource_instance += test__EventSource_fire.mock_handler
            _EventSource_result = _EventSource_instance.fire(0)
    finally:
        AnsibleCollectionConfig = original_AnsibleCollectionConfig


# Generated at 2022-06-25 12:42:13.701225
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:42:16.594281
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # test: basic usage
    source_0 = _EventSource()
    source_0 += lambda x: print(x)
    source_0.fire('test')


# Generated at 2022-06-25 12:42:18.072355
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:19.235271
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += (lambda self: None)
    event_source_0.fire()


# Generated at 2022-06-25 12:42:21.439388
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.fire()
    event_source_1 += lambda: None
    event_source_1.fire()
    event_source_1 -= lambda: None


# Generated at 2022-06-25 12:42:24.605833
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire(8, a=5, b=4)
    except:
        pass
    else:
        assert False, "unreachable"

# Unit tests for class AnsibleCollectionConfig

# Generated at 2022-06-25 12:42:32.930239
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:36.820114
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    arg = list()

    arg = arg
    kwarg = dict()

    kwarg = kwarg
    try:
        event_source_0.fire(arg, kwarg)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 12:42:39.252884
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test for missing argument 'arg_0'
    with raises(TypeError):
        event_source_0.fire()


# Generated at 2022-06-25 12:42:40.504495
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()



# Generated at 2022-06-25 12:42:43.080836
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except:
        pass

# Generated at 2022-06-25 12:42:47.488895
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def test_case(event_source):
        event_source.fire(1, 2, 3)
    test_case(event_source_0)


# Generated at 2022-06-25 12:42:50.656258
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup
    event_source_0 = _EventSource()

    def func_9(arg_1, arg_2=0):
        pass

    event_source_0 += func_9

    # Teardown
    del func_9

    # Test
    event_source_0.fire()



# Generated at 2022-06-25 12:42:56.006664
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    def func_1(value_0):
        temp_0 = value_0
        return temp_0
    event_source_1 += func_1

    actual = event_source_1.fire(1)
    assert actual is None, '_EventSource.fire: actual: %s' % repr(actual)


# Generated at 2022-06-25 12:42:59.985493
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    test_event_source = _EventSource()

    def handler(a, b, c=42):
        assert a == 1
        assert b == 2
        assert c == 42

    test_event_source += handler
    test_event_source.fire(1, 2)



# Generated at 2022-06-25 12:43:01.641271
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    # Test Pass - No code


# Generated at 2022-06-25 12:43:24.115692
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # create a _EventSource object
    event_source_0 = _EventSource()

    def event_source_0_mock_handler(arg_a, arg_b, arg_c):
        if arg_a != "a":
            raise AssertionError()
        if arg_b != "b":
            raise AssertionError()
        if arg_c != "c":
            raise AssertionError()
        return "result"

    event_source_0.fire(arg_a="a", arg_b="b", arg_c="c")
    event_source_0 += event_source_0_mock_handler
    event_source_0_mock_handler_return_value = event_source_0.fire(arg_a="a", arg_b="b", arg_c="c")
    assert event

# Generated at 2022-06-25 12:43:26.059347
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:29.536349
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def function_0(arg_0, arg_1, **args):
        pass

    event_source_0 += function_0
    event_source_0.fire('foo', 'bar')


# Generated at 2022-06-25 12:43:30.426267
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:43:38.160946
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    try:
        event_source_1.fire(1, 2, 3)
    except:
        pass

    def event_handler_0(a, b, c):
        return


    event_source_2 = _EventSource()

    event_source_2 += event_handler_0
    try:
        event_source_2.fire(1, 2, 3)
    except:
        pass

    def event_handler_1(a, b, c):
        raise RuntimeError('oops')


    event_source_2 = _EventSource()

    event_source_2 += event_handler_1

    try:
        event_source_2.fire(1, 2, 3)
    except:
        pass

    event_source_3 = _EventSource()
   

# Generated at 2022-06-25 12:43:40.003031
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:43:50.386237
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Prepare test data
    event_source = _EventSource()
    event_source_ex = _EventSource()
    event_source_ex._on_exception = lambda handler, exc, *args, **kwargs: False

    def test_handler(arg1, arg2, kwarg1=None, kwarg2=None):
        return arg1, arg2, kwarg1, kwarg2

    event_source += test_handler
    event_source_ex += test_handler

    # Execute the method under test
    actual_result = event_source.fire('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')

# Generated at 2022-06-25 12:43:51.761738
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:43:53.317315
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:54.529053
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:44:10.178420
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:44:13.463405
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    event_source_0 = _EventSource()
    # Act
    # Assert
    try:
        event_source_0.fire()
    except:
        raise AssertionError


# Generated at 2022-06-25 12:44:21.246317
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test with no handlers
    event_source_0.fire()

    # Test with a single handler
    calls = []

    def handler_0():
        calls.append(0)

    event_source_0 += handler_0
    event_source_0.fire()

    assert calls == [0]

    # Test with multiple handlers
    calls = []

    def handler_1():
        calls.append(1)

    event_source_0 += handler_1
    event_source_0.fire()

    assert calls == [0, 1]

    # Test with multiple handlers that raise
    calls = []

    def handler_2():
        calls.append(2)
        raise Exception()

    def handler_3():
        calls.append(3)
        raise Exception()

   

# Generated at 2022-06-25 12:44:24.689652
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test state before call
    event_source_0 = _EventSource()
    def func_0(*args, **kwargs):
        assert args[0] == 1
        assert args[1] == 2
        assert kwargs['a'] == 'b'

    event_source_0 += func_0
    event_source_0.fire(1, 2, a='b')



# Generated at 2022-06-25 12:44:25.674572
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:44:33.781241
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()

    def test_func_0():
        pass

    event_source_0 += test_func_0

    def test_func_1(a, b):
        pass

    event_source_0 += test_func_1

    def test_func_2(a, b, c):
        pass

    event_source_0 += test_func_2

    # execute all handlers with no arguments
    event_source_0.fire()

    # execute all handlers with some arguments
    event_source_0.fire(1, 2)

    # execute all handlers with some arguments
    event_source_0.fire(1, 2, 3)



# Generated at 2022-06-25 12:44:38.475470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    hello = None
    def handler(x):
        nonlocal hello
        hello = x

    event_source += handler

    event_source.fire('world')
    assert hello == 'world'

# Generated at 2022-06-25 12:44:42.308166
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(None)
    with pytest.raises(ValueError):
        event_source_0.__iadd__()
    # FIRE EVENT
    event_source_0.fire()



# Generated at 2022-06-25 12:44:50.848187
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # This test requires a collection finder to be set up.  We are assuming that the test loader
    # has already done that for us.

    # This test requires a handler to be set up.  We will use the default handler provided by the
    # test loader.  The handler will set up the AnsibleCollectionConfig.collection_paths and
    # AnsibleCollectionConfig.playbook_paths properties to useful values.

    # verify that handler was called
    assert len(AnsibleCollectionConfig.collection_paths) > 0
    assert len(AnsibleCollectionConfig.playbook_paths) > 0


if __name__ == '__main__':
    test_case_0()
    test__EventSource_fire()

# Generated at 2022-06-25 12:44:54.286772
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()

    # Call method on_collection_load of class AnsibleCollectionConfig
    AnsibleCollectionConfig.on_collection_load.fire()

    event_source_0.fire()

    on_collection_load_0 = AnsibleCollectionConfig.on_collection_load

    on_collection_load_0.fire()

# Generated at 2022-06-25 12:45:10.124291
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert getattr(_EventSource, 'fire', None) is not None



# Generated at 2022-06-25 12:45:11.491794
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:45:12.795328
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_0 = event_source_1.fire()


# Generated at 2022-06-25 12:45:14.448200
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:45:15.328428
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:45:23.536806
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Dynamic import of our module since test_utils.run_python_module() currently does not use the collection loader
    import lib.ansible_collections.ansible.builtin.plugins.module_utils.legacy_collection_loader._event_sources as module
    _EventSource = module._EventSource

    def handler_0():
        nonlocal event_args_0
        event_args_0 = tuple(['test_arg_0'])

    def handler_1():
        nonlocal event_args_1
        event_args_1 = tuple(['test_arg_0'])

    event_source_0 = _EventSource()
    event_args_0 = None
    event_args_1 = None

    event_source_0.fire(*['test_arg_0'])

    event_source_0 += handler_0


# Generated at 2022-06-25 12:45:25.657995
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 is None
    assert True


# Generated at 2022-06-25 12:45:27.295770
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:45:29.544322
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:31.257307
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:08.790304
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:46:18.638285
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class event_handler_setter:
        def __init__(self):
            self.event_handler = None
        def __call__(self, *args, **kwargs):
            self.event_handler(*args, **kwargs)

    class Dummy_EventSource(_EventSource):
        def __init__(self):
            self._handlers = set()
            self.expect_handlers = None
            self.event_handler_setters = None
            self.events_fired = 0


# Generated at 2022-06-25 12:46:20.175541
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:46:21.693121
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_0 = _EventSource()
    event_source_0 = var_0.fire()


# Generated at 2022-06-25 12:46:23.838353
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    global args, kwargs
    args = []
    kwargs = {}
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire(*args, **kwargs)


# Generated at 2022-06-25 12:46:25.046058
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:29.762151
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event_source_0 = _EventSource()
        event_source_0.fire()
    except ValueError as e:
        assert False, "Unexpected exception " + str(e)
    except Exception as e:
        assert False, "Unexpected exception " + str(e)



# Generated at 2022-06-25 12:46:30.951134
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:46:35.241926
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ev = _EventSource()
    def func_0(*args, **kwargs):
        return 'foo'

    # Adds a handler to the _handlers set
    ev += func_0

    # Invoke the fire method to trigger the handler func_0
    # We are using a set to store the handlers and set doesn't preserve the
    # insertion order, so the assertion below fails.
    assert ev.fire() == 'foo'


# Generated at 2022-06-25 12:46:35.799773
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:47:32.053785
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:47:36.221406
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # call method of class _EventSource
    test_case_0()


# Generated at 2022-06-25 12:47:38.416554
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0._handlers
    var_1 = {event_source_0.fire}
    assert var_0 == var_1


# Generated at 2022-06-25 12:47:39.548401
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:47:40.963385
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # testing that event_source_0.fire() is called
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:47:43.112546
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event_source_0 = _EventSource()
        var_0 = event_source_0.fire()
    except Exception as exc:
        print(exc)

# Generated at 2022-06-25 12:47:45.519342
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

    event_source_1 = _EventSource()
    event_source_1.fire()



# Generated at 2022-06-25 12:47:47.572522
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    cls = AnsibleCollectionConfig
    cls._require_finder()


try:
    test__EventSource_fire()
except Exception as inst:
    print(inst)

# Generated at 2022-06-25 12:47:48.409247
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:47:50.088442
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test [0]
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:49:40.378920
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    expected = None

    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

    assert var_0 == expected


# Generated at 2022-06-25 12:49:45.637592
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = lambda handler, exc, *args, **kwargs: pytest.fail(exc)

    def handler_0():
        var_0 = pytest.fail('handler_0 failed')

    event_source_0 += handler_0
    var_0 = event_source_0.fire()
    event_source_0 -= handler_0



# Generated at 2022-06-25 12:49:49.239020
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 12:49:55.726453
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # ------------------------------------------------------------------
    #
    # Description:
    #   Verify the fire function of class _EventSource correctly
    #   dispatches events to multiple handlers.
    #
    # ------------------------------------------------------------------
    event_source = _EventSource()
    foo_bar_call_count = 0
    foo_bar_called = False
    foo_baz_call_count = 0
    foo_baz_called = False

    def foo_bar():
        nonlocal foo_bar_called
        foo_bar_called = True

    def foo_baz():
        nonlocal foo_baz_called
        foo_baz_called = True

    event_source += foo_bar
    event_source += foo_baz
    event_source.fire()

    assert foo_bar_called and foo_baz_called