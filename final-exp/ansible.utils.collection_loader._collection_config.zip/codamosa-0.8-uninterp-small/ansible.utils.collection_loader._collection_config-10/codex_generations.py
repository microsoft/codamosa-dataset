

# Generated at 2022-06-25 12:39:59.399874
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except:
        print('\nUnexpected exception thrown!!!')

test_case_0()

# Generated at 2022-06-25 12:40:03.102558
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def handler_0(self, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, arg_7, arg_8, arg_9, arg_10, arg_11, arg_12, arg_13, arg_14, arg_15, arg_16, arg_17, arg_18, arg_19, arg_20, arg_21, arg_22, arg_23, arg_24, arg_25, arg_26, arg_27, arg_28, arg_29):
        pass


# Generated at 2022-06-25 12:40:05.215629
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    for test_case in [test_case_0]:
        yield test__EventSource___iadd__, test_case


# Generated at 2022-06-25 12:40:11.141354
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    assert callable(event_source_0.__iadd__)

    event_source_0 += lambda: None

    caught_exception = False
    try:
        event_source_0 += 1
    except ValueError:
        caught_exception = True

    assert caught_exception == True

    assert event_source_0._handlers != None



# Generated at 2022-06-25 12:40:16.283182
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()
    def h(a, b, c=None, e=None, d=None):
        return (a, b, c, d, e)

    event_source_0 += h
    assert event_source_0.fire('a', 'b') == (('a', 'b', None, None, None),)



# Generated at 2022-06-25 12:40:19.109384
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    def handler_0(arg_0):
        return arg_0
    try:
        event_source_0.__iadd__(handler_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 12:40:20.967423
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:40:26.444380
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    def handler_0(event_source_0):
        global __event_source_0__
        __event_source_0__ = event_source_0

    event_source_0 += handler_0

    global __event_source_0__
    assert(__event_source_0__ == event_source_0)


# Generated at 2022-06-25 12:40:28.825623
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += to_text('')


# Generated at 2022-06-25 12:40:30.693590
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    str_0 = to_text('callback')
    event_source_0 += str_0


# Generated at 2022-06-25 12:40:37.875286
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        var_0 = event_source_0.fire((lambda var_0, var_1: var_1.items()), 'abc')
        assert var_0 == None
    except Exception as e:
        print("AnsibleCollectionConfig._EventSource.fire(): 'var_0 == None' assertion failed; {}.format(e)")


# Generated at 2022-06-25 12:40:39.811261
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    t = _EventSource()
    t += lambda: None
    assert len(t._handlers) == 1


# Generated at 2022-06-25 12:40:41.525399
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:40:43.288857
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(test_case_0)


# Generated at 2022-06-25 12:40:44.748917
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:40:45.994757
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0.fire()

# Generated at 2022-06-25 12:40:47.559076
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:40:49.710503
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += test_case_0


# Generated at 2022-06-25 12:40:51.426230
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TODO: not sure yet how to get an instance of an inner class like _EventSource
    pass


# Generated at 2022-06-25 12:40:55.978432
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # initialize instance of type _EventSource
    event_source_0 = _EventSource()
    event_source_0.__iadd__(var_0)


# Generated at 2022-06-25 12:41:09.090487
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def var_1(*var_2, **var_3):
        var_2.append(1)
        pass
    event_source_0 += var_1
    var_4 = event_source_0.fire()


# Generated at 2022-06-25 12:41:12.573492
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    additional_handler_0 = event_source_0.__iadd__(1)
    assert (additional_handler_0 == 1)



# Generated at 2022-06-25 12:41:13.723903
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass



# Generated at 2022-06-25 12:41:19.612916
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    with pytest.raises(ValueError) as error_0:
        var_0 = event_source_0.__iadd__(str)
    assert str(error_0.value) == 'handler must be callable'
    handler_0 = lambda: None
    event_source_0.__iadd__(handler_0)
    assert handler_0 in event_source_0._handlers


# Generated at 2022-06-25 12:41:22.613831
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0_instance = _EventSource()

    def function_0():
        var_0 = 1

    event_source_0_instance += function_0


# Generated at 2022-06-25 12:41:27.149653
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    var_0 = _EventSource()
    if not callable(var_0.__iadd__):
        raise AssertionError("Method '__iadd__' not defined")
    if not var_0.__iadd__ is not True:
        raise AssertionError("Function '__iadd__' failed")


# Generated at 2022-06-25 12:41:28.383662
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:41:29.698274
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert var_0 is None

# Generated at 2022-06-25 12:41:41.057344
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # specialize _EventSource._on_exception to avoid needing to install a handler that raises
    event_source_0._on_exception = lambda self, handler, exc, *args, **kwargs: False
    event_source_0.fire()

    try:
        # specialize _EventSource._on_exception to raise
        event_source_0._on_exception = lambda self, handler, exc, *args, **kwargs: True

        event_source_0.fire()
    except Exception as ex:
        ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule().fail_json(msg='unexpected exception: %s' % to_text(ex))



# Generated at 2022-06-25 12:41:43.859130
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 is None



# Generated at 2022-06-25 12:41:54.149661
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def handler_0(self_0, *args_0, **kwargs_0):
        pass
    event_source_0 += handler_0
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:56.399788
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # AssertionError raised as expected
    with pytest.raises(AssertionError):
        event_source_0 = _EventSource()
        var_0 = event_source_0.fire(1, 'two', 3.0)


# Generated at 2022-06-25 12:41:59.545877
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:02.208132
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    my_test_case = test_case_0()
    assert var_0 is None

# Generated at 2022-06-25 12:42:03.803092
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:42:05.443154
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:42:07.265201
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    target = _EventSource()
    assert target.fire() == ()


# Generated at 2022-06-25 12:42:08.584768
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case = _EventSource()
    test_case.fire()


# Generated at 2022-06-25 12:42:10.184966
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:12.259386
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:32.246922
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.handler_0 = lambda *args, **kwargs: print(args)
    event_source_1.handler_1 = lambda *args, **kwargs: print(kwargs)
    var_1 = event_source_1.fire(1, 2)


# Generated at 2022-06-25 12:42:36.948945
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    try:
        event_source.fire()
    except Exception as ex:
        if not isinstance(ex, ValueError):
            raise
    event_source_1 = _EventSource()
    try:
        event_source_1.fire()
    except Exception as ex:
        if not isinstance(ex, ValueError):
            raise


# Generated at 2022-06-25 12:42:47.421482
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    # event_source_1 = _EventSource()
    event_source_1.__iadd__(lambda x: print(x))  # lambda function with single parameters
    event_source_1.__iadd__(lambda x, y: print(x + y))  # lambda function with more than one parameters
    event_source_1.__iadd__(lambda x, y=0: print(x + y))  # lambda function with default value for parameter
    event_source_1.__iadd__(lambda x: print(x))  # lambda function with single parameters
    var_1 = event_source_1.fire("Hello world")
    event_source_1.__iadd__(lambda x, y=0: print(x + y))  # lambda function with default value for parameter


# Generated at 2022-06-25 12:42:48.560682
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:52.292863
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._handlers.add(lambda : test_case_0())
    var_0 = event_source_0.fire()


# Utility method for determining which collection directories to search

# Generated at 2022-06-25 12:42:53.952795
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:56.506959
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

test__EventSource_fire()


# Generated at 2022-06-25 12:43:04.867364
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def test_func_0(q):
        q += 1
    def test_func_1(q):
        q += 1
    event_source_0 += test_func_0
    event_source_0 += test_func_1
    event_source_0.fire(1)
    event_source_0 -= test_func_0
    event_source_0 -= test_func_1
    event_source_0.fire(1)
    event_source_0 += test_func_0
    event_source_0 -= test_func_1
    event_source_0.fire(1)


# Generated at 2022-06-25 12:43:05.407974
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:43:06.448960
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()

# Generated at 2022-06-25 12:43:41.187274
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:43.374371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:51.846959
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    method_name = "_EventSource._on_exception"
    args = (None, None, "abc", 123)
    kwargs = {}
    event_source_0 = _EventSource()
    try:
        var_0 = event_source_0.fire(*args, **kwargs)
        assert True
    except TypeError as exc:
        # if we get here, test has failed
        raise AssertionError(method_name + '() raised TypeError unexpectedly') from exc
    except AssertionError as exc:
        raise AssertionError(method_name + '() raised AssertionError unexpectedly' ) from exc
    except AssertionError:
        pass



# Generated at 2022-06-25 12:43:53.402204
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:43:55.563020
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # input
    event_source_obj = _EventSource()

    # invocation
    rv = event_source_obj.fire()

    # validation
    assert(rv == None)

# Generated at 2022-06-25 12:43:56.976826
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:57.980127
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Test for method fire of class EventSource

# Generated at 2022-06-25 12:43:58.669108
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:44:00.337981
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # No handler registered
    test_case_0()



# Generated at 2022-06-25 12:44:03.246152
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 is None
    var_1 = event_source_0.fire()
    assert var_1 is None



# Generated at 2022-06-25 12:45:11.884891
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = lambda handler, exc, *args, **kwargs: True
    event_source_0.fire()


# Generated at 2022-06-25 12:45:14.408180
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = lambda *args, **kwargs: True
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:45:15.248032
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:45:23.472314
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



from ansible.errors import AnsibleError, AnsibleOptionsError
from ansible.module_utils._text import to_bytes, to_native, to_text
from ansible.module_utils.common._collections_compat import Sequence
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play_context import PlayContext
from ansible.playbook.play import Play
from ansible.plugins.loader import action_loader
from ansible.template import Templar
from ansible.utils.collection_loader import AnsibleCollectionFinder
from ansible.utils.plugin_docs import get_docstring
from ansible.utils.display import Display
from ansible.utils.hashing import secure_hash




# Generated at 2022-06-25 12:45:25.020297
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup test case
    x = _EventSource()
    # Exercise code under test
    # Verify results
    x.fire()


# Generated at 2022-06-25 12:45:26.853647
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()



# Generated at 2022-06-25 12:45:29.116241
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass
    # event_source_0 = _EventSource()
    # var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:45:30.643025
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()



# Generated at 2022-06-25 12:45:34.706648
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # This testcase is not used for the collection loader implementation.
    # The implementation may be partially or fully mocked.
    testcase_0 = test_case_0
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    # Validate that no exception is thrown
    assert var_0 is None


# Generated at 2022-06-25 12:45:36.397830
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.fire()


# Generated at 2022-06-25 12:48:00.736612
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:48:01.513358
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass



# Generated at 2022-06-25 12:48:03.660015
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += lambda *args : print(args)
    event_source_0.fire(1,2)
    return event_source_0


# Generated at 2022-06-25 12:48:04.161617
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert foo.bar

# Generated at 2022-06-25 12:48:11.816000
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    import sys
    import imp
    import pprint
    import os


    fixture_path = os.path.join(os.path.dirname(__file__), '_target_libs')
    fixture_lib = os.path.join(fixture_path, 'ansible_test/_util/target/legacy_collection_loader/')

    if sys.version_info[0] < 3:
        real_loader = imp.load_source
    else:
        real_loader = imp.load_source

    code, filename = real_loader('_EventSource', os.path.join(fixture_lib, '_EventSource.py'))

    fixture = sys.modules.pop('_EventSource', None)
    if fixture is not None:
        del fixture

    sys.modules['_EventSource'] = code

    test_

# Generated at 2022-06-25 12:48:14.300716
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 == None, "event_source_0.fire() returned a non-None value: %s" % var_0


# Generated at 2022-06-25 12:48:18.876658
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # test case 0
    event_source_0 = _EventSource()

    # call method fire on object event_source_0 of class _EventSource
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:48:20.251074
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    assert event_source.fire() == None

# Generated at 2022-06-25 12:48:22.356584
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    return var_0

# Generated at 2022-06-25 12:48:24.792649
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    # Verify the value of the return value
    assert var_0 == None