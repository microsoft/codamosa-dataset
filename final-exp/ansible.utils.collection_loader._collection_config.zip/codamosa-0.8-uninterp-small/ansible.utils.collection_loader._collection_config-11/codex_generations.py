

# Generated at 2022-06-25 12:40:02.485292
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def test_handler():
        pass

    ansible_collection_config_0 = AnsibleCollectionConfig()
    # Get the _on_collection_load property
    _on_collection_load = ansible_collection_config_0.on_collection_load
    # Add the test_handler and store the result in the _on_collection_load property
    _on_collection_load.__iadd__(test_handler)
    # Test that method __iadd__ returns the _on_collection_load property
    assert _on_collection_load is ansible_collection_config_0.on_collection_load


# Generated at 2022-06-25 12:40:09.140061
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_event_source = _EventSource()

    # Verify precedence of class over instance method
    def class_method(args):
        return [args, 'class handler']

    def instance_method(args):
        return [args, 'instance handler']

    test_event_source.fire = instance_method
    test_event_source += class_method

    assert [None, 'class handler'] == test_event_source.fire()



# Generated at 2022-06-25 12:40:14.569189
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    test_func_0 = lambda: None
    try:
        ansible_collection_config_0._EventSource__iadd__(test_func_0)
    except ValueError:
        pass
    except Exception as ex:
        print("unexpected exception raised")
        raise ex



# Generated at 2022-06-25 12:40:19.608513
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()

    def handler1(a, b):
        handler1.a = a
        handler1.b = b

    def handler2(a, b):
        handler2.a = a
        handler2.b = b

    s += handler1
    s += handler2

    s.fire('x', 'y')

    assert handler1.a == 'x'
    assert handler1.b == 'y'
    assert handler2.a == 'x'
    assert handler2.b == 'y'

# Generated at 2022-06-25 12:40:26.940145
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    local__EventSource_fire = _EventSource()
    class __EventSource_fire_mock_1:
        def __call__(self, *args, **kwargs):
            raise ValueError('event handler raised exception')

    local__EventSource_fire += __EventSource_fire_mock_1()

    try:
        local__EventSource_fire.fire()
        assert False, 'unhandled Exception'
    except ValueError as ex:
        assert ex.args[0] == 'event handler raised exception'



# Generated at 2022-06-25 12:40:30.695221
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test method_call_0 of class _EventSource
    try:
        event_source_0.fire()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 12:40:34.438331
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    # Test that it succeeds when it _handlers is callable
    _handlers = set([1, 2, 3])
    e = _EventSource()
    e._handlers = _handlers

    assert e.__iadd__(callable) == e
    assert e._handlers == _handlers.union([callable])


# Generated at 2022-06-25 12:40:36.979167
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    func_0 = lambda r: print(r)
    event_source_0 += func_0

    event_source_0.fire('hello')



# Generated at 2022-06-25 12:40:46.158167
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    # handler #1
    def _handler_1(arg, kwarg=None):
        raise ValueError(arg)

    # handler #2
    def _handler_2(arg, kwarg=None):
        raise RuntimeError(kwarg)

    event += _handler_1
    event += _handler_2

    # Exception should be raised by the first handler
    try:
        event.fire('arg #1', kwarg='kwarg #1')
    except ValueError as e:
        assert str(e) == 'arg #1'
    else:
        assert False, 'ValueError was not raised'

    # Exception should be raised by the second handler

# Generated at 2022-06-25 12:40:54.092988
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    on_collection_load_0 = ansible_collection_config_0.on_collection_load
    assert on_collection_load_0._handlers == set()
    handler_0 = print
    on_collection_load_0 += handler_0
    on_collection_load_0.fire(1)
    on_collection_load_0 -= handler_0
    on_collection_load_0.fire(2)


# Generated at 2022-06-25 12:41:12.868338
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0.on_collection_load += ansible_collection_config_0
    ansible_collection_config_0.on_collection_load = 'hxl'
    ansible_collection_config_0.on_collection_load = ansible_collection_config_0.__init__
    ansible_collection_config_0.on_collection_load += 'wzv'
    ansible_collection_config_0.on_collection_load += ansible_collection_config_0.__init__
    ansible_collection_config_0.on_collection_load = ansible_collection_config_0.on_collection_load
    ansible_collection_config_0.on_collection_load += 'hxl'
    ansible

# Generated at 2022-06-25 12:41:18.778862
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # ctor
    event_source_0 = _EventSource()
    # fire
    event_source_0.fire()
    try:
        # fire
        event_source_0.fire()
    except AttributeError:
        pass
    else:
        try:
            # trigger exception to come out of else block
            assert False
        except AssertionError:
            # catch AssertionError and return from function (no need to re-raise)
            return


# Generated at 2022-06-25 12:41:22.125979
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0.on_collection_load.__iadd__(lambda *args, **kwargs: 1)


# Generated at 2022-06-25 12:41:27.724868
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()

    # Test for when handlers are not callable
    try:
        try:
            ansible_collection_config_0._EventSource.fire('name', 'value')
        except ValueError as e:
            if not isinstance(e, ValueError):
                raise Exception('incorrect exception type')
    except Exception as e:
        raise Exception('unexpected exception: %s' % e)

# Generated at 2022-06-25 12:41:34.517238
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0(_, _0):
        pass

    def handler_1(_, _0):
        raise Exception('foo')

    def handler_2(_, _0, **kwargs):
        pass

    event_source_0 += handler_0
    event_source_0 += handler_1

    try:
        event_source_0.fire()
    except Exception as ex:
        assert str(ex) == 'foo'
    finally:
        event_source_0 -= handler_1

    event_source_0.fire(1, 2, c=3)
    event_source_0 += handler_2

    try:
        event_source_0.fire(1, 2, c=3)
    except Exception as ex:
        assert str(ex) == 'foo'

# Generated at 2022-06-25 12:41:41.017099
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _event_source_0 = _EventSource()
    # test with no handlers
    _event_source_0.fire('arg1', 'arg2')
    # test with handlers
    def handler_func(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
    _event_source_0 += handler_func
    _event_source_0.fire('arg1', 'arg2')


# Generated at 2022-06-25 12:41:45.610967
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire('test_0')
    except:
        # Exception thrown when handler not callable
        print('test__EventSource_fire() failed')
    else:
        print('test__EventSource_fire() passed')


# Generated at 2022-06-25 12:41:48.746417
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    src = _EventSource()

    def foo():
        pass

    src += foo
    assert foo in src._handlers


# Generated at 2022-06-25 12:41:52.253755
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def on_load(param1, param2, param3):
        # do something
        pass
    event_source_0.fire(on_load, "1", "2", "3")


# Generated at 2022-06-25 12:41:57.359485
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config__event_source_1 = _EventSource()
    def _test__EventSource_fire_report_0(**kwargs):
        print(kwargs)
    ansible_collection_config__event_source_1._on_exception = _test__EventSource_fire_report_0
    ansible_collection_config__event_source_1 += _test__EventSource_fire_report_0
    ansible_collection_config__event_source_1.fire()


# Generated at 2022-06-25 12:42:12.433586
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0._on_collection_load.fire()


# Generated at 2022-06-25 12:42:16.931598
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    test_class_0 = type('test_class_0', (object,), {'test_method_0': lambda self: None})

    event_source_0 += test_class_0.test_method_0
    assert test_class_0.test_method_0 in event_source_0._handlers


# Generated at 2022-06-25 12:42:19.506778
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Setup
    ansible_collection_config_1 = AnsibleCollectionConfig()
    ansible_collection_config_1.on_collection_load += lambda *args, **kwargs: args
    handler = lambda *args, **kwargs: args
    # Exercise
    ansible_collection_config_1.on_collection_load += handler
    # Verify
    assert len(ansible_collection_config_1.on_collection_load._handlers) == 2
    # Teardown


# Generated at 2022-06-25 12:42:20.523151
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    es.fire()


# Generated at 2022-06-25 12:42:23.765915
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    handler_0 = to_text

    # call event source 0 fire method
    event_source_0.fire(handler_0)



# Generated at 2022-06-25 12:42:26.604798
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # type: () -> None
    ansible_collection_config_0 = AnsibleCollectionConfig()
    try:
        ansible_collection_config_0.on_collection_load += 'hello world'
    except ValueError:
        pass


# Generated at 2022-06-25 12:42:34.669171
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ansible_collection_config_1 = AnsibleCollectionConfig()
    assert None != ansible_collection_config_1.on_collection_load
    assert '<type \'set\'>' == repr(ansible_collection_config_1.on_collection_load._handlers)
    ansible_collection_config_2 = AnsibleCollectionConfig()
    assert '<type \'set\'>' == repr(ansible_collection_config_2.on_collection_load._handlers)
    assert '<type \'set\'>' == repr(ansible_collection_config_2.on_collection_load._handlers)
    ansible_collection_config_3 = AnsibleCollectionConfig()
    assert '<type \'set\'>' == repr(ansible_collection_config_3.on_collection_load._handlers)

# Generated at 2022-06-25 12:42:37.203805
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    handler = None
    e = _EventSource()
    e.fire(handler)



# Generated at 2022-06-25 12:42:44.886618
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    class Test_1:
        def __init__(self):
            self.event_call_count = 0

        def on_event(self):
            self.event_call_count += 1

    test_1 = Test_1()
    event_source += test_1.on_event

    event_source.fire()
    assert test_1.event_call_count == 1

    event_source.fire()
    assert test_1.event_call_count == 2



# Generated at 2022-06-25 12:42:49.930100
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # This method tests if event has been fired
    # The input reset_value will be set to 0 before firing the event.
    # The function function_with_event will be fired after firing the event.
    # The function function_with_event will set reset_value to 1.
    # If reset_value was set to 0 by event, then test passed.
    def function_with_event(reset_value):
        reset_value = 1

    reset_value = 2
    test_event = _EventSource()
    test_event += function_with_event
    test_event.fire(reset_value)
    assert reset_value == 1

# Generated at 2022-06-25 12:43:18.522769
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0._EventSource.__iadd__(test__EventSource___iadd___0)

# Utility function for test__EventSource___iadd__

# Generated at 2022-06-25 12:43:20.084115
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:43:25.727917
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()

    assert len(s._handlers) == 0

    s += lambda *args, **kwargs: (args, kwargs)
    assert len(s._handlers) == 1

    with pytest.raises(ValueError):
        s += 'not a callable'

    s += lambda *args, **kwargs: (args, kwargs)
    assert len(s._handlers) == 2



# Generated at 2022-06-25 12:43:28.849667
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test '_handler' method. Should not raise.
    ansible_collection_config_1 = AnsibleCollectionConfig()
    ansible_collection_config_1.on_collection_load += _handler


# Generated at 2022-06-25 12:43:31.416824
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    event_source_0 = _EventSource()



# Generated at 2022-06-25 12:43:36.989256
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0._EventSource__iadd__(None)


# Generated at 2022-06-25 12:43:46.628740
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test case with handler that has no parameters
    class HandlerNoParams:
        def __init__(self):
            pass

        def __call__(self):
            pass
    handler = HandlerNoParams()

    es = _EventSource()
    es += handler

    if not hasattr(es, '_handlers'):
        print('Attribute "_handlers" not found')
        return 1

    if handler not in es._handlers:
        print('Handler not found in event source')
        return 1

    # Test case with handler that has parameters
    class HandlerWithParams:
        def __init__(self, param):
            self.param = param

        def __call__(self):
            pass
    handler = HandlerWithParams(7)

    es = _EventSource()
    es += handler


# Generated at 2022-06-25 12:43:52.307817
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()

    # mock
    class Mock:
        def __init__(self):
            self._handlers = None

        def __iadd__(self, handler):
            return self

    mock_instance = Mock()

    # test
    # on Exception, returns True
    assert(ansible_collection_config_0._on_exception(mock_instance, None) is True)


# Generated at 2022-06-25 12:43:54.846530
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0():
        pass

    event_source_0 += handler_0
    event_source_0.fire()



# Generated at 2022-06-25 12:43:56.596514
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    callback = lambda val: print(val)

    source += callback

    source.fire('Hello World')


# Generated at 2022-06-25 12:44:26.682473
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    assert _EventSource()._handlers == set(), 'Test should start with empty handlers.'
    x = _EventSource()
    assert callable(x.__iadd__(int)), 'x.__iadd__(int) should be callable.'
    assert callable(x.__iadd__(list)), 'x.__iadd__(list) should be callable.'
    assert x._handlers == set([int, list]), 'x._handlers should be [int, list].'
    assert x._handlers != set(), 'x._handlers should not be empty.'


# Generated at 2022-06-25 12:44:34.706939
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    ok = False
    def handler0(value):
        nonlocal ok
        ok = (value == "Hello World")

    def handler1(value):
        raise Exception("doh")

    def handler2(value):
        raise Exception("doh")

    event_source += handler0
    event_source += handler1
    event_source += handler2
    event_source.fire("Hello World")
    assert ok

    ok = False
    try:
        event_source.fire("Hello World")
    except Exception:
        ok = True
    assert ok


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 12:44:45.277787
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    # source: source: class _EventSource(object):
    # source:     def __init__(self):
    # source:         self._handlers = set()
    # source:
    # source:     def __iadd__(self, handler):
    # source:         if not callable(handler):
    # source:             raise ValueError('handler must be callable')
    # source:         self._handlers.add(handler)
    # source:         return self
    # source:
    event_source_0 = _EventSource()
    event_source_0 = event_source_0.__iadd__(ansible_collection_config_0)

# Generated at 2022-06-25 12:44:48.533785
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ansible_collection_config_1 = AnsibleCollectionConfig()
    # ansible_collection_config_1._on_collection_load += lambda event: event.who_ami(None)



# Generated at 2022-06-25 12:44:53.869844
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Verify that the handler is added
    event_source_0 = _EventSource()
    event_source_0 += lambda event: event_source_0.fire(event)
    assert len(event_source_0._handlers) == 1, 'handler was not added'

    # Verify that a non-callable handler cannot be added
    event_source_1 = _EventSource()
    try:
        event_source_1 += 'unexpected'
        assert False, 'ValueError was not raised'
    except ValueError:
        assert True



# Generated at 2022-06-25 12:44:56.597485
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    event_source += lambda *args, **kwargs: None
    event_source.fire()

# Generated at 2022-06-25 12:44:58.577682
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    add = event_source.__iadd__(lambda: None)



# Generated at 2022-06-25 12:45:01.159809
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    handler_000 = lambda *args, **kwargs: None
    event_source_0 += handler_000
    event_source_0.fire()

# Generated at 2022-06-25 12:45:10.577750
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    obj = _EventSource()
    # test that _EventSource does not throw an error if you fire without any handlers attached
    obj.fire()
    # add a handler and make sure it gets called
    handler_called = [False]

    def handler():
        handler_called[0] = True

    obj += handler
    obj.fire()
    assert(handler_called[0] is True)
    # remove the handler and make sure it is no longer called
    obj -= handler
    handler_called[0] = False
    obj.fire()
    assert(handler_called[0] is False)
    # add the handler back and make sure it gets called when arguments are passed
    obj += handler
    handler_called[0] = False
    obj.fire(1, 2, 3)
    assert(handler_called[0] is True)


# Generated at 2022-06-25 12:45:18.627544
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _event_source_0 = _EventSource()
    _event_source_1 = _EventSource()
    _event_source_2 = _EventSource()
    _event_source_3 = _EventSource()
    _event_source_4 = _EventSource()
    _event_source_5 = _EventSource()
    _event_source_6 = _EventSource()
    def _handler():
        _int = 0
        _int = 1
        _int = 2
        _int = 3
        _int = 4
        _int = 5
    _event_source_0 += _handler
    _event_source_1 += _handler
    _event_source_2 += _handler
    _event_source_3 += _handler
    _event_source_4 += _handler
    _event_source_5 += _handler


# Generated at 2022-06-25 12:45:50.211315
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    class _Handler:
        def __init__(self):
            self.invoked = False

        def handler(self):
            self.invoked = True

    h = _Handler()
    es += h.handler

    es.fire()

    if not h.invoked:
        raise AssertionError()

test__EventSource_fire()


# Generated at 2022-06-25 12:45:52.299942
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    obj = _EventSource()
    try:
        obj.fire()
    except Exception as ex:
        pass


# Generated at 2022-06-25 12:45:53.788642
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_eventsource_0 = _EventSource()
    test_eventsource_0.fire()



# Generated at 2022-06-25 12:45:56.156600
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def _handler(self, *args, **kwargs):
        pass
    event_source_0.fire()
    event_source_0 += _handler
    event_source_0.fire()


# Generated at 2022-06-25 12:45:58.189164
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    obj = _EventSource()
    obj.fire()

# Generated at 2022-06-25 12:46:05.566796
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_10 = AnsibleCollectionConfig()

    # This is the _EventSource instance
    class _EventSource_Test0:
        _handlers = set()

        def __iadd__(self, handler):
            if not callable(handler):
                raise ValueError('handler must be callable')
            self._handlers.add(handler)
            return self

        def __isub__(self, handler):
            try:
                self._handlers.remove(handler)
            except KeyError:
                pass

            return self

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True


# Generated at 2022-06-25 12:46:07.601794
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0._EventSource.fire()


# Generated at 2022-06-25 12:46:14.248433
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_1 = AnsibleCollectionConfig()

    target_obj = _EventSource()

    # Test: no handler

    target_obj.fire()

    # Test: handler without exception

    def handler_2():
        pass

    target_obj += handler_2
    target_obj.fire()

    # Test: handler with exception

    def handler_3():
        raise Exception('something bad happened')

    target_obj += handler_3
    with pytest.raises(Exception):
        target_obj.fire()



# Generated at 2022-06-25 12:46:15.679047
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource().fire()



# Generated at 2022-06-25 12:46:18.721335
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    source += lambda x: print(x)
    source += lambda y: print(y + 1)
    source += lambda z: print(z + 2)

    source.fire(100)



# Generated at 2022-06-25 12:46:49.946423
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    def handler(source, args=[], kwargs={}):
        assert(source is event_source)
        assert(args == [10, 20, 30])
        assert(kwargs == {'a': 'A', 'b': 'B', 'c': 'C'})

    event_source += handler
    event_source.fire(10, 20, 30, a='A', b='B', c='C')

# Generated at 2022-06-25 12:46:56.166437
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler_0(a, b):
        pass

    event_source_0 += handler_0
    event_source_0.fire(1, 2)

    def handler_1(a, b):
        raise ValueError('test')

    event_source_0 += handler_1
    event_source_0.fire(1, 2)



# Generated at 2022-06-25 12:46:58.062969
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda x: None
    event_source.fire()


# Generated at 2022-06-25 12:47:02.522023
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evt_src_0 = _EventSource()

    def h_0(*args, **kwargs):
        pass

    def h_1(*args, **kwargs):
        pass

    def h_2(*args, **kwargs):
        pass

    evt_src_0 += h_0
    evt_src_0 += h_1
    evt_src_0 += h_2

    evt_src_0.fire()



# Generated at 2022-06-25 12:47:04.047137
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire()

# Generated at 2022-06-25 12:47:05.344195
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:47:11.447521
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def test_handler_0(old, new):
        print((old, new))

    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0.on_collection_load += test_handler_0
    ansible_collection_config_0.on_collection_load.fire(0, 1)


if __name__ == '__main__':
    test_case_0()
    test__EventSource_fire()

# Generated at 2022-06-25 12:47:15.650233
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0.on_collection_load += lambda event: print("Hello from the event handler")
    ansible_collection_config_0.on_collection_load.fire("loaded")
    ansible_collection_config_0.on_collection_load -= lambda event: print("Hello from the event handler")


# Generated at 2022-06-25 12:47:18.009675
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:47:23.649505
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    event_source_0 = ansible_collection_config_0._EventSource()
    try:
        event_source_0.fire()
    except RuntimeError:
        event_source_0 = 'Success'
    else:
        event_source_0 = 'Failure'
    return event_source_0


# Generated at 2022-06-25 12:48:46.371719
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _event_source = _EventSource()


# Generated at 2022-06-25 12:48:48.060050
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common._collections_compat import _EventSource
    es = _EventSource()
    es.fire()


# Generated at 2022-06-25 12:48:49.938238
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    def handler(*args, **kwargs):
        pass

    es.fire()
    es += handler
    es.fire()
    es -= handler
    es.fire()


# Generated at 2022-06-25 12:48:52.752711
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    arg_handlers = ['handlers']
    arg_args = ['args']
    arg_kwargs = {'kwargs': 'kwargs'}
    event_source = _EventSource()
    event_source.fire(arg_handlers, arg_args, arg_kwargs)


# Generated at 2022-06-25 12:48:54.289978
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_event_source_0 = _EventSource()
    ansible_event_source_0.fire()


# Generated at 2022-06-25 12:48:58.897330
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def _h1(*args, **kwargs):
        pass

    def _h2(value, **kwargs):
        if value != '_a21_':
            raise ValueError('args[0] was not expected value')

    event_source = _EventSource()
    event_source += _h1
    event_source += _h2

    event_source.fire('_a11_', arg2='_a12_')
    event_source.fire('_a21_', arg2='_a22_')



# Generated at 2022-06-25 12:49:02.922470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()

    # on_collection_load is the name of an _EventSource, which is the class that contains fire
    # Both _EventSource and fire are defined in this file and both are tested by this method
    ansible_collection_config_0.on_collection_load.fire(*())


# Generated at 2022-06-25 12:49:06.815810
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0.on_collection_load += lambda *a: None
    ansible_collection_config_0.on_collection_load += lambda *a: None
    result = ansible_collection_config_0.on_collection_load.fire()
    assert result is None

# Generated at 2022-06-25 12:49:09.341845
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    test_function_0 = lambda x: None
    event_source_0 += test_function_0
    event_source_0.fire()


# Generated at 2022-06-25 12:49:11.910370
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0._on_collection_load.fire()
