

# Generated at 2022-06-25 12:39:57.505124
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    handler_0 = lambda *x: None
    event_source_0 += handler_0
    del event_source_0, handler_0


# Generated at 2022-06-25 12:40:04.241093
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config = AnsibleCollectionConfig()
    on_collection_load = ansible_collection_config.on_collection_load

    # Test fire(self)
    def event_handler():
        pass

    on_collection_load += event_handler

    # Test fire(self, *args, **kwargs)
    def event_handler_with_args(a, b, c=None, *args, **kwargs):
        pass

    on_collection_load += event_handler_with_args
    on_collection_load.fire(1, 2, 3, 4, b=5, c=6)

# Generated at 2022-06-25 12:40:07.517916
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0._EventSource().fire()



# Generated at 2022-06-25 12:40:17.429531
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    # Verify that the event source is still callable
    assert event_source_0._on_exception == _EventSource._on_exception
    assert event_source_0.fire == _EventSource.fire

    def test_case_0(handler):
        event_source_1 = _EventSource()
        event_source_1 += handler
        return event_source_1._handlers

    def test_case_1():
        try:
            results = test_case_0(None)
            assert False
        except ValueError:
            assert True
        else:
            assert False

    test_case_1()

    # Verify that we don't add the same handler multiple times

# Generated at 2022-06-25 12:40:22.778186
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def handler_0(**kwargs):
        pass
    handler_0_copy = handler_0
    event_source_0 += handler_0
    event_source_0_copy = event_source_0
    event_source_0_copy.fire()


# Generated at 2022-06-25 12:40:27.105011
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_subject = _EventSource()

    def test_handler_1(*args, **kwargs):
        return

    def test_handler_2(*args, **kwargs):
        raise ValueError('TEST_VALUE_ERROR')

    test_subject += test_handler_1
    test_subject += test_handler_2
    test_subject.fire()



# Generated at 2022-06-25 12:40:30.856096
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    e.fire()

    e += lambda: None
    e.fire()

    e += lambda: 1 / 0
    try:
        e.fire()
    except ZeroDivisionError:
        pass



# Generated at 2022-06-25 12:40:37.875703
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    # the base case where we want to add a valid handler to an empty set of handlers
    def test_handler_0(event_source, *args, **kwargs):
        pass

    event_source_0 += test_handler_0

    assert event_source_0._handlers == set([test_handler_0])

    # one more case where we want to add a handler to an already populated set of handlers
    def test_handler_1(event_source, *args, **kwargs):
        pass

    event_source_0 += test_handler_1

    assert event_source_0._handlers == set([test_handler_0, test_handler_1])

    # test case where we try to add a non-callable handler

# Generated at 2022-06-25 12:40:39.134783
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    handler = object()
    es = _EventSource()
    es += handler
    es -= handler
    es += handler
    es.fire()
    es -= handler



# Generated at 2022-06-25 12:40:41.849564
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ansible_collection_config_1 = AnsibleCollectionConfig()
    ansible_collection_config_1._EventSource.__iadd__(ansible_collection_config_1,None)


# Generated at 2022-06-25 12:40:47.044411
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0.fire() is None


# Generated at 2022-06-25 12:40:49.482096
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Initialization
    event_source_0 = _EventSource()
    # Execution
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:41:01.081606
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # testing if the _on_exception method raises ValueError when the handler is not callable
    try:
        event_source_0._on_exception('handler', 'exc', 'args', 'kwargs')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # testing if the __iadd__ method raises ValueError when the handler is not callable
    try:
        event_source_0.__iadd__('handler')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # testing if the __isub__ method pass when the handler is not in the set

# Generated at 2022-06-25 12:41:06.906268
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1._on_exception = lambda a1, a2, a3, a4, a5=None, a6=None, a7=None: None
    var_1 = event_source_1.fire()

ANSIBLE_COLLECTION_CONFIG = AnsibleCollectionConfig()

# Generated at 2022-06-25 12:41:08.795908
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:14.454112
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert str(event_source_0.fire()) == "<bound method _EventSource.fire of <ansible.module_utils.common._collections_compat.legacy_collection_loader._EventSource object at 0x7f7f5b8e5eb8>>"
    # Test event_source_0.fire() raises an exception when trying to fire an event with no handlers
    


# Generated at 2022-06-25 12:41:17.146373
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += event_source_0.fire
    event_source_0 += event_source_0.fire



# Generated at 2022-06-25 12:41:18.083424
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# Generated at 2022-06-25 12:41:18.989832
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass


# Generated at 2022-06-25 12:41:21.290648
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:25.659432
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# Generated at 2022-06-25 12:41:27.232208
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:30.227375
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_1 = _EventSource()
    var_2 = event_source_1.__iadd__(lambda x: x)
    if var_2 is None:
        raise Exception('Test failed: var_2 is None.')
    else:
        print('Test passed: var_2 is not None.')


# Generated at 2022-06-25 12:41:33.615451
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:41:35.503996
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:37.812033
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:39.252157
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:41:41.181284
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    var_0 = event_source_0.__iadd__(int)


# Generated at 2022-06-25 12:41:43.005325
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()



# Generated at 2022-06-25 12:41:44.577726
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()

if __name__ == '__main__':
    test__EventSource___iadd__()

# Generated at 2022-06-25 12:41:49.658981
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:51.462929
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:52.345564
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:41:52.975835
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:41:54.164672
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance = _EventSource()

    instance.fire()
    return


# Generated at 2022-06-25 12:41:55.009577
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:41:56.209358
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:59.438763
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:03.217186
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += method_0
    var_0 = event_source_0.fire()

    def method_0():
        pass


# Generated at 2022-06-25 12:42:05.362355
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    del event_source_0


# Generated at 2022-06-25 12:42:13.441191
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        test_case_0()
    except Exception as ex:
        raise AssertionError(ex)


# Generated at 2022-06-25 12:42:14.998920
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:16.552353
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source__0 = _EventSource()
    event_source__0.fire()



# Generated at 2022-06-25 12:42:18.034638
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:19.098076
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# class _AnsibleCollectionConfig

# Generated at 2022-06-25 12:42:21.261831
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # No Handler
    es = _EventSource()
    es.fire()

    # Inline Handler
    es = _EventSource()

    def handler():
        pass

    es += handler
    es.fire()

    # Handler Defined On Source
    class C:
        es = _EventSource()

        def handler(self):
            pass

    c = C()
    c.es += c.handler
    c.es.fire()


# Generated at 2022-06-25 12:42:23.396114
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
  event_source_0 = _EventSource()

  # Call method fire of event_source_0
  event_source_0.fire()

# Generated at 2022-06-25 12:42:24.465735
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()


# Generated at 2022-06-25 12:42:25.392295
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:42:33.814068
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += lambda *args, **kwargs: (print(args), print(kwargs))
    event_source_0 += lambda *args, **kwargs: (print(args), print(kwargs))
    event_source_0 += lambda *args, **kwargs: (print(args), print(kwargs))
    var_0 = event_source_0.fire()
    event_source_0 -= lambda *args, **kwargs: (print(args), print(kwargs))
    var_1 = event_source_0.fire()
    event_source_0 -= lambda *args, **kwargs: (print(args), print(kwargs))
    var_2 = event_source_0.fire()

# Generated at 2022-06-25 12:42:46.206557
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()

# Generated at 2022-06-25 12:42:47.610712
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:42:49.292477
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except:
        raise AssertionError('unexpected failure')


# Generated at 2022-06-25 12:42:57.778093
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict()

    result = dict(
        changed=False,
        ansible_facts=dict(
            ansible_collection_config=dict(
                on_collection_load=dict(
                    fire=AnsibleCollectionConfig.on_collection_load.fire.__name__,
                ),
            ),
        ),
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )

    module.exit_json(**result)



# Generated at 2022-06-25 12:42:59.535677
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:00.121470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass

# Generated at 2022-06-25 12:43:01.053821
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    return True



# Generated at 2022-06-25 12:43:05.979488
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    config = AnsibleCollectionConfig()
    config.collection_finder = None
    config.default_collection = None
    config.on_collection_load = None
    config.playbook_paths = None

    # Variable declarations
    event_source = config.on_collection_load
    event_source.fire()

    # Assertions
    assert isinstance(event_source, _EventSource)



# Generated at 2022-06-25 12:43:07.841353
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # instance of class with declaration template
    obj = _EventSource()

    # Call method on class with template
    # No error
    obj.fire()

# Generated at 2022-06-25 12:43:09.053332
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:36.352609
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:43:37.862887
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:39.705644
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:43:41.381355
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:43:42.798735
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    value_0 = test_case_0()



# Generated at 2022-06-25 12:43:45.095773
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0._handlers == set()
    assert event_source_0.fire() is None


# Generated at 2022-06-25 12:43:52.855552
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create a set of instances of _EventSource
    event_sources = [_EventSource() for _ in range(10)]

    # Subscribe the event handlers to each instance
    for handler in (test_case_0,):
        for event_source in event_sources:
            event_source += handler

    # Remove the event handlers from each instance
    for handler in (test_case_0,):
        for event_source in event_sources:
            event_source -= handler

    # Fire the event on each instance
    for event_source in event_sources:
        event_source.fire()



# Generated at 2022-06-25 12:43:54.399002
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert var_0 is None



# Generated at 2022-06-25 12:43:56.010298
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    if event_source_0.fire():
        raise ValueError('unexpected return value of fire')


# Generated at 2022-06-25 12:43:56.828746
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert var_0 is None

# Generated at 2022-06-25 12:44:41.610529
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:43.229486
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:52.526390
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    ansible_collections_loader_config_0 = AnsibleCollectionConfig()

    test_case_1_arguments = {'ansible_collections_loader_config_0': ansible_collections_loader_config_0}
    test_case_1_result = test_case_1(**test_case_1_arguments)
    test_case_2_arguments = {'ansible_collections_loader_config_0': ansible_collections_loader_config_0}
    test_case_2_result = test_case_2(**test_case_2_arguments)
    test_case_3_arguments = {'ansible_collections_loader_config_0': ansible_collections_loader_config_0}

# Generated at 2022-06-25 12:44:55.169642
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Preconditions
    event_source_0 = _EventSource()
    # Test a failure case
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:44:57.233867
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TODO: update this test case to use real arguments
    test_case_0()


# Generated at 2022-06-25 12:44:58.870225
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:00.074391
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    test_case_0()

# Generated at 2022-06-25 12:45:01.654622
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:04.686594
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    var_1 = event_source_0.fire()
    assert var_0 == var_1


# Generated at 2022-06-25 12:45:06.602428
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_2 = event_source_1.fire()
    assert var_2 is None


# Generated at 2022-06-25 12:46:34.540431
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# define a new method for _EventSource

# Generated at 2022-06-25 12:46:36.388821
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance = _EventSource()
    assert None == instance.fire()


# Generated at 2022-06-25 12:46:37.771334
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 == None


# Generated at 2022-06-25 12:46:38.522397
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass


# Generated at 2022-06-25 12:46:39.806226
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()


# Generated at 2022-06-25 12:46:41.043781
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:46:41.842245
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:43.626442
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += test_case_0
    event_source_0.fire()
    
    # No way to test other cases.


# Generated at 2022-06-25 12:46:45.089016
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    actual_0 = test_case_0()
    expected_1 = None
    assert actual_0 == expected_1


# Generated at 2022-06-25 12:46:49.627198
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    var = event_source.fire()

