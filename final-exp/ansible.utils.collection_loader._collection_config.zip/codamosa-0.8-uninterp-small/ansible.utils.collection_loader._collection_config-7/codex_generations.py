

# Generated at 2022-06-25 12:39:57.631351
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += lambda: set()
    event_source_1.fire()


# Generated at 2022-06-25 12:40:07.422311
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # There is a bug in Python 2.7 which prevents the proper propagation of exceptions
    # from within a try/except block which catches an inner exception.
    # The work around for this bug is to assume that any exception thrown from
    # the call to fire will result in an AssertionException.
    # ref: https://bugs.python.org/issue1856
    # ref: https://stackoverflow.com/questions/1093322/how-do-i-check-what-exception-was-thrown-in-python
    try:
        event_source_0.fire()
    except AssertionError:
        pass

if __name__ == '__main__':
    test_case_0()
    test__EventSource_fire()

# Generated at 2022-06-25 12:40:11.173502
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0 += lambda: None
    event_source_0.fire()
    event_source_0 -= lambda: None
    event_source_0.fire()


# Generated at 2022-06-25 12:40:20.024396
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    exception_except_0 = None
    try:
        event_source_0.fire(1, 2, 3)
    except Exception as e:
        exception_except_0 = e
    if exception_except_0 is not None:
        raise AssertionError(exception_except_0)

    exception_except_1 = None
    try:
        event_source_0 += (lambda *_args, **_kwargs: None)
        event_source_0.fire(1, 2, 3)
    except Exception as e:
        exception_except_1 = e
    if exception_except_1 is not None:
        raise AssertionError(exception_except_1)

    exception_except_2 = None

# Generated at 2022-06-25 12:40:24.293845
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test for method fire of class _EventSource
    event_source_1 = _EventSource()
    event_source_1 += event_source_handler_0
    event_source_1.fire(in_0)


# Generated at 2022-06-25 12:40:31.678139
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# CAUTION: There are two implementations of the collection loader.
#          They must be kept functionally identical, although their implementations may differ.
#
# 1) The controller implementation resides in the "lib/ansible/utils/collection_loader/" directory.
#    It must function on all Python versions supported on the controller.
# 2) The ansible-test implementation resides in the "test/lib/ansible_test/_util/target/legacy_collection_loader/" directory.
#    It must function on all Python versions supported on managed hosts which are not supported by the controller.

# Generated at 2022-06-25 12:40:33.521085
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    try:
        event_source_0.fire()
    except Exception:
        pass


# Generated at 2022-06-25 12:40:36.831538
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    def my_handler_0(*args, **kwargs):
        print('my_handler_0() called')
    e += my_handler_0
    my_signal = e.fire
    my_signal()
    # There should be no output from this test case as no exceptions should be raised
    print('test__EventSource_fire() completed without exception')

# Generated at 2022-06-25 12:40:39.143406
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:41.536347
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    event_source_0 += lambda: None

    event_source_0 += event_source_0.fire



# Generated at 2022-06-25 12:40:47.302559
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    # Setup the test
    event_source_0 = _EventSource()

    # Test the method
    event_source_0.__iadd__(lambda: None)


# Generated at 2022-06-25 12:40:59.333766
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    handler_0 = mock_handler_0 = mock.Mock()
    handler_1 = mock_handler_1 = mock.Mock()
    handler_1._on_exception = None

    # Attempts to add handlers that are not callable are ignored
    event_source += None
    event_source += to_text

    # Add two event handlers with different behavior for on_exception
    event_source += handler_0
    event_source += handler_1

    # If neither handler raises an exception, all handlers should be called
    event_source.fire('foo', 'bar')
    mock_handler_0.assert_called_once_with('foo', 'bar')
    mock_handler_1.assert_called_once_with('foo', 'bar')

    # Reset the mock objects
    mock

# Generated at 2022-06-25 12:41:01.039171
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_source_0 += lambda x: x
    # Success if no exception is raised
    return


# Generated at 2022-06-25 12:41:08.539623
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # test case 0
    event_source_0 = _EventSource()
    assert event_source_0 is not None
    # test case 1
    event_source_1 = _EventSource()
    assert event_source_1 is not None
    try:
        event_source_1 += 'not callable'
    except ValueError as err:
        assert 'handler must be callable' in str(err)
    else:
        raise AssertionError('Unexpected success')

# Generated at 2022-06-25 12:41:16.839932
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_case_0()

    test_obj = _EventSource()
    with pytest.raises(Exception, match='handler must be callable'):
        test_obj.__iadd__(None, )
    with pytest.raises(Exception, match='handler must be callable'):
        test_obj.__iadd__('test_str', )
    with pytest.raises(Exception, match='handler must be callable'):
        test_obj.__iadd__(123, )
    with pytest.raises(Exception, match='handler must be callable'):
        test_obj.__iadd__(['test_str'], )

# Generated at 2022-06-25 12:41:19.171811
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    handler_0 = lambda: None
    event_source_0 += handler_0
    event_source_0.fire()


# Generated at 2022-06-25 12:41:21.119132
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:41:23.409202
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    with raises(ValueError):
        event_source_0 += 1


# Generated at 2022-06-25 12:41:25.265781
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:26.182600
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    instance = test_case_0()



# Generated at 2022-06-25 12:41:33.886197
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire(1, 2)
    except:
        pass



# Generated at 2022-06-25 12:41:40.494657
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def on_exception(handler, exc, *args, **kwargs):
        return True

    event_source_1._on_exception = on_exception

    def handler_0(param_0):
        pass

    event_source_1 += handler_0

    event_source_1.fire()

    event_source_1 -= handler_0

    event_source_1.fire()



# Generated at 2022-06-25 12:41:44.332471
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def func0(*args, **kwargs):
        return
    event_source_0.fire()
    event_source_0 += func0
    event_source_0.fire()


# Generated at 2022-06-25 12:41:45.207226
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# Generated at 2022-06-25 12:41:50.460452
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()

    def source_event_handler_0(*args, **kwargs):
        print('unit test of method fire of class _EventSource passed.')
    event_source_0 += source_event_handler_0

    event_source_0.fire()



# Generated at 2022-06-25 12:41:58.461768
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()

    state = []

    def handler1(*args, **kwargs):
        state.append((1, args, kwargs))

    def handler2(*args, **kwargs):
        state.append((2, args, kwargs))

    def handler3(x, *args, **kwargs):
        state.append((3, x, args, kwargs))

    def handler4(x, y, *args, **kwargs):
        state.append((4, x, y, args, kwargs))

    e += handler1
    e += handler2
    e += handler3
    e += handler4

    e.fire(1, 2, 3, a=4, b=5)

# Generated at 2022-06-25 12:42:02.873354
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def empty_handler_0(*args, **kwargs):
        pass
    event_source_0 += empty_handler_0
    event_source_0.fire()


# Generated at 2022-06-25 12:42:04.777230
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:14.999634
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    is_test_0_success = True

    try:
        event_source_0 = _EventSource()
        def handler_0(*args, **kwargs):
            if not (isinstance(args, list)) or not isinstance(kwargs, dict):
                raise AssertionError('Method _EventSource.fire invoked with wrong argument types')

        event_source_0 += handler_0
        event_source_0.fire({})
    except AssertionError as exc:
        is_test_0_success = False
        print('Test case method fire of class _EventSource failed with exception ' + str(exc), end='\n\n')


# Generated at 2022-06-25 12:42:15.411488
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_source = _EventSource()



# Generated at 2022-06-25 12:42:27.832264
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:30.710850
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Prepare test objects
    event_source_0 = _EventSource()
    target = lambda: True
    event_source_0 += target
    # Perform the test
    event_source_0.fire()
    # Verify the results


# Generated at 2022-06-25 12:42:32.855501
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    handler = lambda x: x
    event_source += handler

    handler(None)
    event_source.fire(None)



# Generated at 2022-06-25 12:42:35.124171
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def handler_0(value):
        print('%s' % value)

    event_source_1.fire(handler_0)


test_case_0()
test__EventSource_fire()

# Generated at 2022-06-25 12:42:36.415204
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # invoke fire
    event_source_0.fire()
    assert True


# Generated at 2022-06-25 12:42:42.993029
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def handler_0():
        pass

    def handler_1():
        raise Exception('exception thrown in event handler')

    event_source_1 += handler_0
    event_source_1 += handler_1

    try:
        event_source_1.fire()
    except Exception:
        pass

    event_source_1 -= handler_0

    try:
        event_source_1.fire()
    except Exception:
        pass

# Generated at 2022-06-25 12:42:45.642490
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire() # will raise an exception if handlers are added


# Generated at 2022-06-25 12:42:49.224437
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Arrange
    event_source = _EventSource()

    # Create a dummy handler that does nothing.
    def dummy_handler(value):
        #print('dummy_handler: {}'.format(value))
        pass

    # Act
    event_source += dummy_handler
    event_source.fire(value=42)

    # Assert
    assert len(event_source._handlers) == 1



# Generated at 2022-06-25 12:42:59.985457
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Test case 0
    event_source_0 = _EventSource()
    a_0 = 1
    b_0 = 2
    c_0 = ("this", "is", "a", "test")
    d_0 = {}
    e_0 = {"a", "b", "c"}

    def f_0(*args, **kwargs):
        if len(args) != 1 or args[0] != 1:
            raise ValueError('expected 1 as the first argument')
        if kwargs.get('b', 2) != 2:
            raise ValueError('expected 2 as the b keyword argument')
        if kwargs.get('c', None) != ("this", "is", "a", "test"):
            raise ValueError('expected ("this", "is", "a", "test") as the c keyword argument')

# Generated at 2022-06-25 12:43:02.501504
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # raise if handler is not callable
    with raises(ValueError):
        event_source_0 += 1


# Generated at 2022-06-25 12:43:13.843703
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += test__EventSource_fire_handler_0
    event_source_1 += test__EventSource_fire_handler_1
    event_source_1 += test__EventSource_fire_handler_2

    event_source_1.fire()
    try:
        event_source_1.fire(1, 2, 3)
    except Exception:
        pass
    except:
        raise AssertionError('test__EventSource_fire did not catch the expected exception')

    event_source_1 -= test__EventSource_fire_handler_1
    event_source_1.fire(1, 2, 3)



# Generated at 2022-06-25 12:43:15.488895
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = lambda handler, exc, *args, **kwargs: True
    event_source_0.fire()


# Generated at 2022-06-25 12:43:17.055884
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:43:19.998371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    def event_handler_2(x):
        return x
    event_source_1 += event_handler_2
    event_source_1.fire(y=42)


# Generated at 2022-06-25 12:43:22.263027
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = AnsibleCollectionConfig.on_collection_load
    event_source_0.fire()


# Generated at 2022-06-25 12:43:32.779415
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """
    Test the fire method of the _EventSource class
    """
    event_source_instance_0 = _EventSource()

    # in this unit test we will pass a single argument to the event handler.
    # This is a function that we will create with a wrapper to capture the arguments passed
    # to the handler.

    _test_handler_args = None

    def test_handler(arg_0):
        nonlocal _test_handler_args
        _test_handler_args = (arg_0)

    event_source_instance_0 += test_handler

    # expect no arguments
    if _test_handler_args is not None:
        raise AssertionError('Expected None and got {}'.format(_test_handler_args))

    event_source_instance_0.fire(('argument_0', 'argument_1'))



# Generated at 2022-06-25 12:43:37.739251
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource_fire_source = _EventSource()

    try:
        _EventSource_fire_source.fire()
    except Exception as _EventSource_fire_exception:
        return False

    return True


# Generated at 2022-06-25 12:43:47.555891
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # the default _EventSource does nothing, and should not raise an exception of any kind
    _EventSource().fire()

    def on_error_fire_1(exception, handler, *args, **kwargs):
        raise ValueError('the handler should not have been called with any arguments')

    def on_error_fire_2(exception, handler, *args, **kwargs):
        if exception is None:
            raise ValueError('the exception must be set')

    for test_case in (on_error_fire_1, on_error_fire_2):
        event_source_0 = _EventSource()
        event_source_0.fire(1, 2, 3)

        event_source_0._on_exception = test_case
        event_source_0.fire(1)

        # _on_exception can be

# Generated at 2022-06-25 12:43:49.878470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:53.612636
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # We need to create an instance of EventSource
    event_source = _EventSource()
    event_source += one_handler
    event_source += two_handler
    event_source += three_handler

    # Check if the handlers are fired in a correct order
    event_source.fire()


# Generated at 2022-06-25 12:44:15.519206
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def func_0(**kwargs):
        event_source_0._handlers.add(func_0)
        func_0.count = 0
        func_0.accumulator = []
        for arg in kwargs.values():
            func_0.count += 1
            func_0.accumulator.append(arg)

    def func_1(**kwargs):
        event_source_0._handlers.add(func_1)
        func_1.count = 0
        func_1.accumulator = []
        for arg in kwargs.values():
            func_1.count += 1
            func_1.accumulator.append(arg)


# Generated at 2022-06-25 12:44:26.297251
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    def handle_event_1(arg_1, arg_2, arg_3):
        pass
    event_source_1 += handle_event_1
    event_source_1 -= handle_event_1

    event_source_2 = _EventSource()
    def handle_event_2(arg_1, arg_2):
        pass
    event_source_2 += handle_event_2

    event_source_3 = _EventSource()
    def handle_event_3(arg_1, arg_2, arg_3):
        raise Exception('test exception raised')
    event_source_3 += handle_event_3

    event_source_4 = _EventSource()

# Generated at 2022-06-25 12:44:28.928966
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def _handler_0(*args, **kwargs):
        pass

    event_source_0 += _handler_0
    event_source_0.fire()




# Generated at 2022-06-25 12:44:32.575470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()
    event_source += AnsibleCollectionConfig.on_collection_load
    event_source.fire()
    event_source -= AnsibleCollectionConfig.on_collection_load
    event_source.fire()


# Generated at 2022-06-25 12:44:42.610660
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create an instance of class _EventSource
    event_source_0 = _EventSource()

    # Call method fire of event_source_0
    # TypeError: 'set' object is not callable
    #   at line of "event_source_0.fire()" in test__EventSource_fire()

    # TypeError: 'set' object is not callable
    #   at line of "cls._on_collection_load.fire()" in _AnsibleCollectionConfig.setter.default_collection()
    #   at line of "cls._default_collection = value" in _AnsibleCollectionConfig.setter.default_collection()
    #   at line of "AnsibleCollectionConfig.default_collection = value" in test__AnsibleCollectionConfig_default_collection_setter()



# Generated at 2022-06-25 12:44:48.047955
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    print("Unit test for method fire of class _EventSource")
    event_source_0 = AnsibleCollectionConfig.on_collection_load

    def handler_0(*args, **kwargs):
        print('handler_0 called')

    event_source_0 += handler_0
    assert len(event_source_0._handlers) == 1
    event_source_0.fire()



# Generated at 2022-06-25 12:44:55.134104
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import with_metaclass

    class _AnsibleCollectionConfig_0(type):
        def __init__(cls, meta, name, bases):
            cls._collection_finder = None
            cls._default_collection = None
            cls._on_collection_load = _EventSource()

        @property
        def collection_finder(cls):
            return cls._collection_finder

        @collection_finder.setter
        def collection_finder(cls, value):
            if cls._collection_finder:
                raise ValueError('an AnsibleCollectionFinder has already been configured')

            cls._collection_finder = valu

# Generated at 2022-06-25 12:44:57.192890
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0.fire() is None


# Generated at 2022-06-25 12:45:03.650870
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # These tests are intended for code coverage only,
    # this metaclass does nothing but define and init the class properties.
    #
    # When we instantiate the class, we should see the event source in __init__
    #
    # Set and get the collection finder.
    #
    # Set and get the default collection
    #
    # Set and get the on_collection_load event source
    #
    # We can set and get the collection paths and playbook paths but we get a NotImplementedError if no finder is installed.
    pass

# Generated at 2022-06-25 12:45:05.931977
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except Exception as e:
        assert False, to_text(str(e))

# Generated at 2022-06-25 12:45:20.070256
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def f(x):
        return x
    event_source_0 += f
    var_0 = event_source_0.fire(10)



# Generated at 2022-06-25 12:45:21.132436
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:45:23.919931
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Parameters:
    #   args:
    #     Type: Tuple[Any]
    #   kwargs:
    #     Type: Dict[str, Any]

    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:45:24.920710
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()

# Generated at 2022-06-25 12:45:27.477294
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += test_case_0
    var_1 = event_source_0.fire()


# Generated at 2022-06-25 12:45:32.067926
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # noinspection PyProtectedMember
    event_source_0 = AnsibleCollectionConfig._on_collection_load
    var_0 = event_source_0.fire()
    # noinspection PyProtectedMember
    assert AnsibleCollectionConfig._on_collection_load._handlers is event_source_0._handlers



# Generated at 2022-06-25 12:45:33.329110
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_1 = _EventSource()
    var_1.fire()


# Generated at 2022-06-25 12:45:37.469605
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_1 = _EventSource()
    event_source_2 = _EventSource()
    event_source_3 = _EventSource()
    event_source_2._handlers = set()
    event_source_3._handlers = set()


# Generated at 2022-06-25 12:45:39.668907
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += _EventSource.fire
    event_source_0.fire()


# Generated at 2022-06-25 12:45:41.063052
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:46:06.923443
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:08.622308
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:10.456054
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:12.965278
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += lambda *args, **kwargs: None
    event_source_1.fire()


# Generated at 2022-06-25 12:46:16.204501
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = AnsibleCollectionConfig
    with raises(ValueError):
        var_0 = event_source_0._on_exception(handler,'ex', *args, **kwargs)



# Generated at 2022-06-25 12:46:18.168938
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    ''':type: None'''



# Generated at 2022-06-25 12:46:19.758905
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:46:22.246997
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    _EventSource.fire(event_source_0)  # this is just to support the coverage report
    _EventSource.fire(event_source_0, None)



# Generated at 2022-06-25 12:46:24.227426
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    event_source_1 = _EventSource()


# Generated at 2022-06-25 12:46:25.671473
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.fire()


# Generated at 2022-06-25 12:47:27.825362
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event_source_0 = _EventSource()
        var_0 = event_source_0.fire()
    except ValueError:
        pass
    try:
        event_source_0 = _EventSource()
        var_0 = event_source_0.fire('_27')
    except ValueError:
        pass
    try:
        event_source_0 = _EventSource()
        var_0 = event_source_0.fire('_27')
    except ValueError:
        pass
    try:
        event_source_0 = _EventSource()
        var_0 = event_source_0.fire('_16')
    except ValueError:
        pass

# Generated at 2022-06-25 12:47:29.084431
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """Test for the _EventSource fire() method."""
    test_case_0()

# Generated at 2022-06-25 12:47:30.414516
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:47:32.346320
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += test_case_0
    event_source_0.fire()



# Generated at 2022-06-25 12:47:33.849714
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()

# Generated at 2022-06-25 12:47:36.634454
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:47:43.581020
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()
    event_source_2 = _EventSource()
    var_2 = event_source_2.fire()
    event_source_3 = _EventSource()
    var_3 = event_source_3.fire()
    event_source_4 = _EventSource()
    var_4 = event_source_4.fire()
    event_source_5 = _EventSource()
    var_5 = event_source_5.fire()
    event_source_6 = _EventSource()
    var_6 = event_source_6.fire()
    event_source_7 = _EventSource()

# Generated at 2022-06-25 12:47:45.999008
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    event_source_0 = _EventSource()

    # Act
    var_0 = event_source_0.fire()

    # Assert
    assert True



# Generated at 2022-06-25 12:47:47.146078
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    with pytest.raises(Exception):
        test_case_0()



# Generated at 2022-06-25 12:47:48.293285
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert_0 = 'error'
    return assert_0


# Generated at 2022-06-25 12:49:39.441906
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()



# Generated at 2022-06-25 12:49:41.202561
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    print('test__EventSource_fire')
    event_source_1 = _EventSource()
    event_source_1.fire()


# Generated at 2022-06-25 12:49:42.546940
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()



# Generated at 2022-06-25 12:49:45.027886
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test case 0
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:49:49.238448
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
