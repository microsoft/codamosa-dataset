

# Generated at 2022-06-25 12:39:56.918877
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0.fire()



# Generated at 2022-06-25 12:40:02.912132
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    counter = [0]
    def inc(inc_by=1):
        counter[0] += inc_by
    event_source_1 += inc
    event_source_1.fire()
    assert counter[0] == 1, 'Failed callable did not increment counter.'
    event_source_1.fire(inc_by=2)
    assert counter[0] == 3, 'Failed callable did not increment counter by specified value.'
    event_source_1 = None


# Generated at 2022-06-25 12:40:04.201083
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:40:07.076981
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:11.173695
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    assert event_source_0._handlers == set()
    with pytest.raises(ValueError, match=r"handler must be callable"):
        event_source_0 += "handler"
    assert event_source_0._handlers == set()


# Generated at 2022-06-25 12:40:19.535593
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    expected = True

    # Try a good case
    try:
        event_source_0.fire()
    except Exception:
        assert False

    # Try a bad case (should raise exception)
    try:
        event_source_0._on_exception = lambda h, ex, *args, **kwargs: False
        event_source_0.fire(None)
        assert False
    except:
        pass

    # Try a bad case (should not raise exception)
    try:
        event_source_0._on_exception = lambda h, ex, *args, **kwargs: True
        event_source_0.fire(None)
        assert True
    except:
        assert False



# Generated at 2022-06-25 12:40:23.131096
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    config_0 = AnsibleCollectionConfig()
    event_source_0 = _EventSource()
    assert event_source_0._on_exception(callable, ) == True

# Generated at 2022-06-25 12:40:30.529201
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class CollectionFinder(object):
        def __init__(self, collection_paths):
            self._n_collection_paths = collection_paths
            self._n_playbook_paths = []

        def set_playbook_paths(self, paths):
            self._n_playbook_paths.extend(paths)

    class Foo(object):
        def my_handler(self, v1, v2):
            self.v1 = v1
            self.v2 = v2

    AnsibleCollectionConfig.collection_finder = CollectionFinder(['/foo', '/bar'])

    AnsibleCollectionConfig.on_collection_load += Foo().my_handler
    AnsibleCollectionConfig.on_collection_load.fire('a', 'b')

    assert Foo.v1 == 'a'
    assert Foo

# Generated at 2022-06-25 12:40:32.712084
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.utils.collection_loader._event_source import _EventSource

    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:40:33.559711
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pass



# Generated at 2022-06-25 12:40:40.673680
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    with pytest.raises(ValueError) as excinfo:
        event_source_0 += 1
    assert 'must be callable' in str(excinfo.value)


# Generated at 2022-06-25 12:40:42.281594
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0.fire() is None



# Generated at 2022-06-25 12:40:51.428419
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert hasattr(event_source_0, '_handlers')
    event_source_0._handlers = set()
    handler_0 = lambda : None
    event_source_0 += handler_0
    assert hasattr(event_source_0, '_on_exception')
    assert event_source_0.fire(()) is None

# Generated at 2022-06-25 12:40:56.386025
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    try:
        event_source_0 = _EventSource()
        event_source_0 += str

        assert False, "Expected exception not raised"
    except ValueError as e:
        pass

# Generated at 2022-06-25 12:41:00.214282
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:41:03.566383
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj = _EventSource()
    with pytest.raises(ValueError, match=r'handler must be callable'):
        obj.__iadd__(None)


# Generated at 2022-06-25 12:41:04.765768
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:41:06.447540
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    def func__EventSource___iadd__(var_0):
        return
    event_source_0.__iadd__(func__EventSource___iadd__)


# Generated at 2022-06-25 12:41:12.144175
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    def function_handler_0(x):
        return x + 1

    var_0 = event_source_0.__iadd__(function_handler_0)
    var_1 = event_source_0.fire(1)

    assert var_1 == 2, 'test__EventSource___iadd__() failed'



# Generated at 2022-06-25 12:41:14.933461
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test for positive case
    event_source_1 = _EventSource()
    func_1 = event_source_1.fire()
    assert func_1 == None


# Generated at 2022-06-25 12:41:21.684920
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_1 = _EventSource()
    event_source_2 = _EventSource()
    var_1 = event_source_2.__iadd__(event_source_1)


# Generated at 2022-06-25 12:41:23.282961
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:41:24.260851
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:41:27.764813
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(event_source_0)
    try:
        event_source_0.fire()
    except Exception as e:
        print('Caught exception: ', repr(e), sep='')

# Generated at 2022-06-25 12:41:31.160455
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    # Test with exception
    handlers = [lambda: None,
                None,
                lambda: raise_exception(),
                lambda: None]
    event_source._handlers = handlers
    try:
        event_source.fire()
    except Exception:
        pass



# Generated at 2022-06-25 12:41:34.385986
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    '''Test that we can fire an event successfully'''
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:36.182524
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_1 = _EventSource()
    var_1.fire()


config = AnsibleCollectionConfig()

# Generated at 2022-06-25 12:41:38.172813
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    first_test_case = 1
    test_case_0()

# Generated at 2022-06-25 12:41:39.252237
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert(True)


# Generated at 2022-06-25 12:41:40.845708
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:50.501683
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    try:
        event_source_0 = _EventSource()
        var_0 = event_source_0.__iadd__(event_source_0)

    except ValueError:
        assert True

# Generated at 2022-06-25 12:41:53.964744
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_0 = None
    var_1 = _EventSource()
    var_1._handlers = {var_0}
    var_0 = None
    var_1.__iadd__(var_0)
    var_1.fire()



# Generated at 2022-06-25 12:41:55.936419
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(_make_bound_method(test_case_0))
    event_source_0.fire()


# Generated at 2022-06-25 12:41:58.820775
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:02.300602
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire(event_source_0)


# Generated at 2022-06-25 12:42:05.850120
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_1 = event_source_0.__iadd__(event_source_0)
    event_source_0.fire()


# Generated at 2022-06-25 12:42:08.580999
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(event_source_0.fire)
    event_source_0.fire()



# Generated at 2022-06-25 12:42:14.333623
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # We create instance of _EventSource
    event_source_0 = _EventSource()
    # We try to add an event source to itself.
    # This should raise an error
    try:
        event_source_0.__iadd__(event_source_0)
        # We shouldn't reach this because the previous line should raise an Exception.
        assert False
    except ValueError:
        # This is expected, we continue
        pass


# Generated at 2022-06-25 12:42:15.052787
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:42:17.253112
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0._on_exception(print, Exception(), to_text(''))


# Generated at 2022-06-25 12:42:28.882022
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.fire()


# Generated at 2022-06-25 12:42:35.800295
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # setup test
    event_source_0 = _EventSource()
    event_source_0.__iadd__(event_source_0)
    event_source_0.__iadd__(event_source_0)
    event_source_0.__iadd__(event_source_0)

    # assert that the _on_exception method returns a bool
    assert isinstance(event_source_0.fire(), bool)

    # assert that the _on_exception method returns a bool
    assert isinstance(event_source_0.fire(), bool)

    # assert that the _on_exception method returns a bool
    assert isinstance(event_source_0.fire(), bool)

    print('test__EventSource_fire complete')



# Generated at 2022-06-25 12:42:38.491286
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1
    event_source_1.__init__()
    var_1 = event_source_1


# Generated at 2022-06-25 12:42:40.669869
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:45.027207
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config_0 = AnsibleCollectionConfig()
    ansible_collection_config_0.default_collection = "foo"
    assert ansible_collection_config_0.default_collection == "foo"


# Generated at 2022-06-25 12:42:48.820424
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup test objects
    event_source_0 = _EventSource()
    # Verify results
    assert event_source_0._on_exception(event_source_0,event_source_0,"")
    assert not event_source_0.__iadd__(event_source_0)
    assert not event_source_0.__isub__(event_source_0)


# Generated at 2022-06-25 12:42:49.829266
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

# Generated at 2022-06-25 12:42:52.875659
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(event_source_0)
    event_source_0.fire()


# Generated at 2022-06-25 12:42:53.812269
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:42:58.239405
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(event_source_0.__init__)
    event_source_0.__iadd__(event_source_0.__init__)
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:21.143871
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()

# Generated at 2022-06-25 12:43:23.530444
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.__iadd__(event_source.fire)
    var_0 = event_source.fire()


# Generated at 2022-06-25 12:43:25.249269
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:35.228856
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_1 = _EventSource()
    var_0 = event_source_0.__iadd__(event_source_1)
    event_source_2 = _EventSource()
    event_source_3 = _EventSource()
    event_source_4 = _EventSource()
    event_source_5 = _EventSource()
    event_source_6 = _EventSource()
    event_source_7 = _EventSource()
    event_source_8 = _EventSource()
    var_1 = event_source_2.__iadd__(event_source_3)
    event_source_9 = _EventSource()
    event_source_10 = _EventSource()
    event_source_11 = _EventSource()
    event_source_12 = _Event

# Generated at 2022-06-25 12:43:38.238863
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    event_source_1.fire()

    event_source_1 += test__EventSource_fire_callback
    event_source_1.fire()



# Generated at 2022-06-25 12:43:42.236706
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0.fire('foo')
    event_source_0.fire()
    event_source_0.fire(None)
    event_source_0.fire(bar='foo')



# Generated at 2022-06-25 12:43:46.422912
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with raises(ValueError):
        event_source_0.__iadd__(list)
    event_source_0._on_exception = None
    event_source_0.fire(1, 2, 3, 4)
    event_source_0 -= event_source_0


# Generated at 2022-06-25 12:43:48.302152
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:55.047427
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire(event_source_0)
    assert var_0 is None
    event_source_1 = _EventSource()
    event_source_2 = _EventSource()
    event_source_2.__iadd__(event_source_1)
    event_source_2.__iadd__(event_source_2)
    var_1 = event_source_2.fire()
    assert var_1 is None


# Generated at 2022-06-25 12:44:00.421733
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    config = AnsibleCollectionConfig()
    config.default_collection = ""
    config.on_collection_load.fire()

    # our event source to test firing of
    event_source = _EventSource()

    # this is a handler we will test firing against
    def handler_0(this, *args, **kwargs):
        var_0 = this.fire()

    # assign the handler to our event source
    event_source += handler_0

    # call our event source, this should call our handler_0 function
    event_source.fire(event_source, "arg_1", kwarg_0="kwarg_0")

# Generated at 2022-06-25 12:44:43.943176
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_1 = _EventSource()
    # _on_exception not implemented
    var_1.fire()

# Generated at 2022-06-25 12:44:45.594686
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:44:48.840245
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()
    event_source_0.__iadd__(lambda *args, **kwargs: None)
    event_source_0.fire()


# Generated at 2022-06-25 12:44:50.543824
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = lambda a, b: False
    event_source_0.fire('foo')


# Generated at 2022-06-25 12:44:53.144434
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # event_source_0 is an instance of the _EventSource class.
    event_source_0 = _EventSource()
    # We use the fire method of the event_source_0 object.
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:57.697053
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Find the event source class
    var_1 = getattr(AnsibleCollectionConfig, '_on_collection_load', None)
    var_2 = _EventSource()
    var_3 = var_1.__iadd__(lambda: None)
    var_1.fire()


# Generated at 2022-06-25 12:45:01.036814
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # call method call with valid arguments
    method_call_valid = event_source_0.fire()

    # call method call with invalid arguments
    method_call_invalid = event_source_0.fire(None)



# Generated at 2022-06-25 12:45:03.332862
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance_0 = _EventSource()
    instance_0._handlers = set()
    instance_0.fire()


# Generated at 2022-06-25 12:45:05.975500
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_1 = event_source_0.fire()
    if var_1 != None:
        raise AssertionError('var_1 != None')


# Generated at 2022-06-25 12:45:07.792982
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # fire 0 calls
    assert event_source_0.fire() == None



# Generated at 2022-06-25 12:46:39.341401
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # from ansible.module_utils.common._collections_compat import _EventSource

    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:46:40.299593
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()


# Generated at 2022-06-25 12:46:41.078544
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:42.077987
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:43.643847
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.__iadd__(event_source_0)
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:46:53.391143
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # initialize the event_source object
    event_source_1 = _EventSource()

    # verify the event_source object is initialized properly
    assert isinstance(event_source_1, _EventSource)

    handlers = set()
    handlers.add(event_source_1)

    # call the fire method with args and kwargs, and verify the number of handlers
    assert len(event_source_1._handlers) == 0

    event_source_1.fire(handlers)
    assert len(event_source_1._handlers) == 1


# Generated at 2022-06-25 12:46:55.302901
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:46:59.221485
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.__iadd__(_EventSource())
    event_source_1.__iadd__(_EventSource())
    event_source_1.__iadd__(_EventSource())
    event_source_1.__iadd__(_EventSource())


# Generated at 2022-06-25 12:47:00.693339
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:47:02.623619
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with pytest.raises(ValueError):
        event_source_0.__iadd__(object)

