

# Generated at 2022-06-25 12:40:01.642635
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class test_class_0(object):

        def function_0(self, *args, **kwargs):
            return 'function_0 called'

        def function_1(self, *args, **kwargs):
            return 'function_1 called'

    obj_0 = test_class_0()
    event_source_0 = _EventSource()
    event_source_0 += obj_0.function_0
    event_source_0 += obj_0.function_1
    event_source_0.fire()


# Generated at 2022-06-25 12:40:03.286423
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:40:06.357802
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

if __name__ == "__main__":
    test_case_0()
    test__EventSource_fire()

# Generated at 2022-06-25 12:40:08.461036
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire('<str>')


# Generated at 2022-06-25 12:40:12.946934
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def func_0(arg_0, arg_1):
        pass

    event_source_0 += func_0
    event_source_0.fire(arg_0=0, arg_1=1)


# Generated at 2022-06-25 12:40:20.630380
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY3
    import types
    _EventSource()
    event_source_1 = _EventSource()
    event_

# Generated at 2022-06-25 12:40:24.570795
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    def handler_0(*args, **kwargs):
        print('it works')
    event_source_0 += handler_0


# Generated at 2022-06-25 12:40:25.731845
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:40:29.657617
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_1 = _EventSource()
    event_source_1.fire()


test_case_0()
test__EventSource_fire()

# Generated at 2022-06-25 12:40:32.175178
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test for expected exception during method fire of class _EventSource
    with pytest.raises(Exception):
        event_source_0.fire()



# Generated at 2022-06-25 12:40:38.512482
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    def handler(event):
        pass

    event_source_0 += handler


# Generated at 2022-06-25 12:40:46.361431
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Configure parameters and expected values
    obj = _EventSource()
    func = lambda *args, **kwargs: args[0] + args[1]
    arg_0 = 1
    arg_1 = 2
    arg_kwarg_0 = 'a'
    arg_kwarg_1 = 'b'
    exp_event_source_1 = 3

    # Perform the test
    obj += func
    act_event_source_1 = obj.fire(arg_0, arg_1, arg_kwarg_0=arg_kwarg_0, arg_kwarg_1=arg_kwarg_1)

    # Verify the results
    assert exp_event_source_1 == act_event_source_1


# Generated at 2022-06-25 12:40:49.047176
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_0(arg_0):
        pass
    event_source_0 = _EventSource()
    event_source_0.fire(handler_0)


# Generated at 2022-06-25 12:40:58.284281
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def fire1(x):
        pass

    def fire2(x):
        pass

    def fire3(x):
        pass

    def fire4(x):
        pass

    event_source_0.fire = lambda f: f(2)
    event_source_0 += fire1
    event_source_0 += fire2
    event_source_0 += fire3
    event_source_0 += fire4
    event_source_0.fire(2)
    assert 2*4 == 8


# Generated at 2022-06-25 12:40:59.803386
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:08.382410
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    args_0 = tuple()
    kwargs_0 = dict()

    try:
        event_source_1.fire(*args_0, **kwargs_0)
    except Exception as ex:
        assert isinstance(ex, TypeError)
        assert ex.args == ("'NoneType' object is not callable",)
        assert str(ex) == "'NoneType' object is not callable"


# Generated at 2022-06-25 12:41:10.869084
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:13.455365
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    lambda_0 = lambda x: x
    event_source_0.__iadd__(lambda_0)
    assert True


# Generated at 2022-06-25 12:41:15.798064
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    t = _EventSource()
    for i in range(5):
        t.__iadd__((lambda x: x))


# Generated at 2022-06-25 12:41:17.058938
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # test case 0
    test_case_0()


# Generated at 2022-06-25 12:41:22.261066
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += lambda : None
    event_source_1.fire()


# Generated at 2022-06-25 12:41:26.859674
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # call fire with correct arguments
    event_source_0.fire()
    # call fire with incorrect arguments
    try:
        event_source_0.fire('a')
    except TypeError:
        pass
    else:
        raise AssertionError('An expected exception has not been raised.')



# Generated at 2022-06-25 12:41:32.662628
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    args_0 = ()
    kwargs_0 = {}
    event_source_0.fire(*args_0, **kwargs_0)

    event_source_0 = _EventSource()
    args_0 = (1)
    kwargs_0 = {}
    event_source_0.fire(*args_0, **kwargs_0)

    event_source_0 = _EventSource()
    args_0 = (1, 2)
    kwargs_0 = {}
    event_source_0.fire(*args_0, **kwargs_0)

# Generated at 2022-06-25 12:41:43.606520
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test when there are no event handlers registered
    try:
        event_source_0.fire('arg_0', kwarg_0='kwarg_0')
    except:
        assert False, 'unexpected exception raised'

    # Test a normal call with no arguments
    call_counter_0 = 0
    def handler_0():
        nonlocal call_counter_0
        call_counter_0 += 1
    event_source_0 += handler_0
    try:
        event_source_0.fire()
    except:
        assert False, 'unexpected exception raised'
    assert len(event_source_0._handlers) == 1 and event_source_0._handlers.pop() is handler_0, 'bad handler set'

# Generated at 2022-06-25 12:41:47.506572
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()
    event_source_0 = _EventSource()
    assert event_source_0
    event_source_0.fire()
    assert event_source_0


# Generated at 2022-06-25 12:41:49.490979
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:41:50.379268
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:41:51.374318
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    assert event_source_0.fire() is None



# Generated at 2022-06-25 12:41:53.596585
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def handler(event_source_0):
        pass
    event_source_0.fire()


# Generated at 2022-06-25 12:41:57.359697
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0 += lambda x, y: print(x, y)

    event_source_0.fire(1, 2)
    event_source_0 += lambda x: print(x)

    event_source_0 -= lambda x: print(x)

    event_source_0.fire(1)


# Generated at 2022-06-25 12:42:11.341040
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_2 = _EventSource()
    handler_0 = lambda *args, **kwargs: args + kwargs
    handler_1 = lambda *args, **kwargs: args + kwargs
    handler_2 = lambda *args, **kwargs: args + kwargs
    handler_3 = lambda *args, **kwargs: args + kwargs
    event_source_2 += handler_0
    event_source_2(to_text('arg_1'), to_text('arg_2'), kwarg_0=to_text('kwarg_0'), kwarg_1=to_text('kwarg_1'))

# Generated at 2022-06-25 12:42:12.966930
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()
    source.fire()

# Generated at 2022-06-25 12:42:15.207502
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # the event source is empty so nothing should happen
    test_case_0 = _EventSource()
    assert test_case_0.fire() == None


# Generated at 2022-06-25 12:42:17.102039
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(arg_0='foo', arg_1=1)


# Generated at 2022-06-25 12:42:19.098128
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_1 = _EventSource()
    event_source_1.fire('foo')


# Generated at 2022-06-25 12:42:19.848834
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# Generated at 2022-06-25 12:42:20.782039
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()


# Generated at 2022-06-25 12:42:22.324341
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(1)
    event_source_1 = _EventSource()



# Generated at 2022-06-25 12:42:23.423690
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:42:24.851223
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.fire()



# Generated at 2022-06-25 12:42:47.112438
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # Test with 0 args
    event_source_0.fire()

    # Test with 1 arg
    event_source_0.fire(1)

    # Test with 2 args
    event_source_0.fire(1, 2)

    # Test with 3 args
    event_source_0.fire(1, 2, 3)

    # Test with 4 args
    event_source_0.fire(1, 2, 3, 4)

    # Test with 5 args
    event_source_0.fire(1, 2, 3, 4, 5)

    # Test with 6 args
    event_source_0.fire(1, 2, 3, 4, 5, 6)

    # Test with 7 args

# Generated at 2022-06-25 12:42:56.237680
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    sys_argv_0 = ["main.py", "test/units/module_utils/tests/legacy_collection_loader/test__EventSource_fire.json"]
    parse_args_0 = {}
    parse_args_0['args'] = sys_argv_0[1:]
    parse_args_0['include'] = []
    parse_args_0['passwords'] = {}
    parse_args_0['inventory'] = None
    parse_args_0['subset'] = None
    parse_args_0['module_path'] = None
    parse_args_0['extra_vars'] = []
    parse_args_0['forks'] = None
    parse_args_0['ask_vault_pass'] = False
    parse_args_0['vault_password_files'] = []
    parse_

# Generated at 2022-06-25 12:42:58.419753
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:43:01.143878
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1.fire()
    event_source_2 = _EventSource()
    event_source_2.fire()


# Generated at 2022-06-25 12:43:07.724864
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TEST_CASE_1: empty event source
    test_case_0()

    # TEST_CASE_2: add callables
    event_source_0 = _EventSource()
    event_source_0 += lambda: None
    event_source_0 += lambda: None
    event_source_0.fire()

    # TEST_CASE_3: raise exception
    event_source_0 = _EventSource()
    event_source_0 += lambda: 1 + '1'
    event_source_0.fire()


test__EventSource_fire()

# Generated at 2022-06-25 12:43:10.280416
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # test_0: no exception
    event_source_0.fire()

if __name__ == '__main__':
    test_case_0()
    test__EventSource_fire()

# Generated at 2022-06-25 12:43:15.459115
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    def handler_0(x):
        if x == 0:
            return
        raise NotImplementedError

    event_source_1 += handler_0
    test_parameter_0 = 0
    result = event_source_1.fire(test_parameter_0)
    assert result is None


# Generated at 2022-06-25 12:43:17.017521
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert event_source_0.fire() == None



# Generated at 2022-06-25 12:43:18.606914
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:43:19.834007
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()
    es = _EventSource()


# Generated at 2022-06-25 12:43:35.731418
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    error = RuntimeError(to_text(''))

    try:
        event_source_0.fire()
    except RuntimeError as ex:
        if str(ex) != str(error):
            raise AssertionError('exception thrown: {}'.format(ex))



# Generated at 2022-06-25 12:43:41.381841
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()

    event_source_0.fire()

    event_source_0 += str
    event_source_0.fire()

    event_source_0 += lambda: None
    event_source_0.fire()

    event_source_0 += str
    event_source_0.fire()

    event_source_0 -= str
    event_source_0.fire()



# Generated at 2022-06-25 12:43:44.585618
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with pytest.raises(AttributeError) as e:
        # This event source is empty, so it should raise an exception
        event_source_0.fire()


# Generated at 2022-06-25 12:43:48.649872
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_handler_0 = test__EventSource_fire

    try:
        event_source_0.fire()
    except ValueError:
        return

    # Expecting ValueError exception raised
    raise ValueError('Expecting ValueError exception raised')


# Generated at 2022-06-25 12:43:51.328936
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()
    test_case_1()

# FIXME: this is a placeholder to verify that AnsibleCollectionConfig's metaclass methods are called

# Generated at 2022-06-25 12:43:57.365606
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    global Item
    Item = 0
    event_source_0 += lambda: setattr(globals(), 'Item', 10)
    event_source_0.fire()
    assert Item == 10
    event_source_0 -= lambda: setattr(globals(), 'Item', 10)
    event_source_0.fire()
    assert Item == 10
    event_source_0 += lambda: setattr(globals(), 'Item', 10)
    event_source_0.fire()
    assert Item == 10


# Generated at 2022-06-25 12:44:04.916608
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test with a handler that does not raise
    event_source_0 = _EventSource()

    # Test with a handler that raises but is not intercepted
    event_source_1 = _EventSource()
    event_source_1.on_exception = lambda handler, exc, *args, **kwargs: None

    def handler_0(*args, **kwargs):
        pass

    event_source_1 += handler_0

    # Test with a handler that raises and is intercepted
    event_source_2 = _EventSource()

    def handler_1(*args, **kwargs):
        raise RuntimeError('A problem was encountered')

    event_source_2 += handler_1
    event_source_2.fire()

# Generated at 2022-06-25 12:44:14.731102
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler_0(a, b, c):
        assert a == 1
        assert b == 'abc'
        assert c.d == 4
        return a

    event_source += handler_0

    # test: call event handler that returns values
    event_source.fire(1, 'abc', c=dict(d=4))

    # test: call event handler that raises an exception
    def handler_1():
        raise Exception()
    event_source += handler_1
    # expect: re-raised exception
    try:
        event_source.fire()
    except Exception as ex:
        assert ex

    # test: call event handler that returns True (to re-raise)
    def handler_2(ex):
        on_exception_called[0] = True
        return True
   

# Generated at 2022-06-25 12:44:16.990522
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    print('printing in _EventSource.fire')
    event_source_0.fire()



# Generated at 2022-06-25 12:44:21.110420
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0.fire()



# Generated at 2022-06-25 12:44:46.801454
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:44:49.318605
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with pytest.raises(NotImplementedError):
        event_source_0.fire()


# Generated at 2022-06-25 12:44:50.375275
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:44:53.514424
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except Exception:
        raise AssertionError('expected _EventSource.fire() to raise an exception')


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-25 12:44:56.764351
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception(lambda x: None, None)
    event_source_0.fire()


# Generated at 2022-06-25 12:44:58.411056
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:45:00.658324
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except Exception as e:
        assert False
    assert True


# Generated at 2022-06-25 12:45:05.040451
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def mock_1(arg_0):
        if arg_0 == 'arg 0':
            return True
        else:
            return False
    event_source_0 += mock_1
    event_source_0.fire('arg 0')
    event_source_0 -= mock_1


# Generated at 2022-06-25 12:45:06.637459
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    e.fire(1, 2, 3)



# Generated at 2022-06-25 12:45:09.204599
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_collections.ansible.community.plugins.module_utils.collection_loader import _EventSource

    # Test case 0: The event source has no handlers registered
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except ValueError as e:
        raise AssertionError("Unexpected exception raised")


# Generated at 2022-06-25 12:45:59.779331
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:46:01.114962
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()

    event_source_0.fire(to_text(''))


# Generated at 2022-06-25 12:46:10.457856
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    # This can be used to assert fire is implemented correctly, but
    # we want to avoid throwing an exception for easier integration testing.
    #def assert_handler(self, *args, **kwargs):
    #    self.assertEqual(args, (0, 1, 2, 3))
    #    self.assertEqual(kwargs, {'a': 1, 'b': 2, 'c': 3})

    def assert_handler(self, *args, **kwargs):
        pass

    event_source_0 += assert_handler
    assert_handler(0, 1, 2, 3, a=1, b=2, c=3)

    # Unhandled exception should be raised.
    #def unhandled_exception_handler(self, *args, **kwargs):
    #   

# Generated at 2022-06-25 12:46:15.627753
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    loader_config = AnsibleCollectionConfig()
    event_source_1 = AnsibleCollectionConfig._on_collection_load
    assert hasattr(event_source_1, 'fire')
    assert isinstance(event_source_1.fire, callable)
    assert len(inspect.getargspec(event_source_1.fire).args) == 1



# Generated at 2022-06-25 12:46:24.096236
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collections_mock = 'ansible-collections'
    ansible_mod_mock = 'ansible.module_utils.legacy_collection_loader'
    with patch.multiple(ansible_collections_mock, AnsibleCollectionLoader=DEFAULT, AnsibleCollectionNotFound=DEFAULT,
                        AnsibleCollectionSet=DEFAULT, AnsibleCollectionMetadata=DEFAULT) as mock_collection_loader_mock:
        event_source_0 = _EventSource()
        assert event_source_0.fire() is None

# Generated at 2022-06-25 12:46:27.950571
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    args = []
    kwargs = {}
    result = event_source_0.fire(*args, **kwargs)
    assert result is None



# Generated at 2022-06-25 12:46:29.517256
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()
    source += lambda self: None
    source += lambda self: None
    source.fire()


# Generated at 2022-06-25 12:46:36.212960
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event_source_0 = _EventSource()
        try:
            # call fire with a set of arguments that may trigger an exception
            event_source_0.fire()

        # catch and validate exceptions
        except KeyError as ex:
            assert False, 'Exception raised: ' + str(ex)
        except ValueError as ex:
            assert False, 'Exception raised: ' + str(ex)
        except TypeError as ex:
            assert False, 'Exception raised: ' + str(ex)
        except Exception as ex:
            assert False, 'Exception raised: ' + str(ex)

    # cleanup routine for test case
    finally:
        pass



# Generated at 2022-06-25 12:46:38.811594
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    event_source_0 = _EventSource()
    with pytest.raises(Exception):
        event_source_0.fire()

    def on_load_handler_0(collection_path):
        assert collection_path == 'collection_path'

    AnsibleCollectionConfig.on_collection_load += on_load_handler_0

    with pytest.raises(Exception):
        AnsibleCollectionConfig.on_collection_load.fire('collection_path')


# Generated at 2022-06-25 12:46:40.734977
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire('abc', 'abc')
    except NotImplementedError:
        pass

test_case_0()

# Generated at 2022-06-25 12:48:30.930229
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda:None
    event_source.fire()

# Generated at 2022-06-25 12:48:32.529081
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:48:34.786921
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(4, 2)  # Expected to pass


# Generated at 2022-06-25 12:48:39.439980
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    got_error = False
    try:
        event_source_0.fire('test', msg='test')
    except ValueError:
        got_error = True
    if not got_error:
        raise AssertionError('Expected call of method fire to raise ValueError but it was not raised.')


# Generated at 2022-06-25 12:48:41.003973
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()

    # call fire function without any event handler set
    e.fire()



# Generated at 2022-06-25 12:48:46.687156
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:48:47.877156
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:48:49.534713
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # Verify that the method fire returns None
    assert event_source_0.fire() is None


# Generated at 2022-06-25 12:48:50.632841
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:48:52.108944
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # create a parameter value
    event_source_0 = _EventSource()

    # call fire()
    event_source_0.fire()
