

# Generated at 2022-06-25 12:40:01.303541
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def check_0_0(handler, exc, *args, **kwargs):
        return True

    event_source._on_exception = check_0_0

    def check_0_1(*args, **kwargs):
        raise ValueError()

    event_source += check_0_1

    try:
        event_source.fire()
    except:
        pass

    def check_1_1(*args, **kwargs):
        raise RuntimeError()

    event_source += check_1_1

    try:
        event_source.fire()
    except:
        pass

    def check_2_0(handler, exc, *args, **kwargs):
        return False

    event_source._on_exception = check_2_0

    event_source.fire()

# Generated at 2022-06-25 12:40:03.631253
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    event_handler_0 = lambda: None
    event_source_0 += event_handler_0


# Generated at 2022-06-25 12:40:06.785058
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    # Test for expected behavior
    event_source_0 += print
    event_source_0.fire('test_case_0')
    # Test for expected behavior
    event_source_0 = _EventSource()
    event_source_0 += print
    event_source_0.fire('test_case_1')


# Generated at 2022-06-25 12:40:16.884892
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0 = _EventSource()
    event_source_0.fire(None)
    event_source_0 = _EventSource()
    event_source_0.fire(None, None)
    event_source_0 = _EventSource()
    event_source_0.fire(None, None, None)
    event_source_0 = _EventSource()
    event_source_0.fire(None, None, None, None)
    event_source_0 = _EventSource()
    event_source_0.fire(None, None, None, None, None)
    event_source_0 = _EventSource()
    event_source_0.fire(None, None, None, None, None, None)
    event_

# Generated at 2022-06-25 12:40:19.089829
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:40:20.518621
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire(
    )
    return event_source_0


# Generated at 2022-06-25 12:40:23.130066
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    assert callable(event_source_0.fire)



# Generated at 2022-06-25 12:40:24.956600
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:40:28.216230
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    assert callable(event_source_0._on_exception)
    assert event_source_0.__class__ is _EventSource



# Generated at 2022-06-25 12:40:30.114259
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_result_1 = event_source_1.fire()


# Generated at 2022-06-25 12:40:38.671427
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

    event_source_0 = _EventSource()
    with pytest.raises(ValueError):
        event_source_0 += lambda: 'value'
        event_source_0 -= None
    event_source_1 = _EventSource()
    event_source_1 += lambda: 'value'
    event_source_1 -= event_source_1._on_exception
    event_source_1.fire()


# Generated at 2022-06-25 12:40:47.224558
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test cases for class _EventSource
    def test_case_1(event_source):
        event_source.__iadd__('str')

    def test_case_2(event_source):
        event_source.__iadd__(event_source.__init__)

    def test_case_3(event_source):
        event_source.__iadd__(event_source.__iadd__)

    def test_case_4(event_source):
        event_source.__iadd__(event_source.__isub__)

    def test_case_5(event_source):
        event_source.__iadd__(event_source._on_exception)

    def test_case_6(event_source):
        event_source.__iadd__(event_source.fire)


# Generated at 2022-06-25 12:40:49.298421
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()
    del event_source_0


# Generated at 2022-06-25 12:41:00.659285
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source_0 = _EventSource()

    def test_target_0(a, b):
        return to_text(a + b)

    event_source_0 += test_target_0

    result = event_source_0.fire(1, 2)

    assert result == '12'

    def test_target_1(a, b):
        return to_text(a - b)

    event_source_0 += test_target_1

    result = event_source_0.fire(3, 4)

    assert result == '12-3-4'

    def test_target_2(a, b):
        return to_text(a * b)

    event_source_0 += test_target_2

    result = event_source_0.fire(5, 6)


# Generated at 2022-06-25 12:41:03.986677
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    def func_0():
        print('arg1', 'arg2', sep='\n')

    event_source_0.fire(func_0)



# Generated at 2022-06-25 12:41:07.854205
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test the addition of a new event handler.

    event_source_0 = _EventSource()

    handler_0 = lambda: None

    event_source_0 += handler_0

# Generated at 2022-06-25 12:41:11.156954
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with pytest.raises(TypeError):
        event_source_0.fire(None, None)


# Generated at 2022-06-25 12:41:14.060183
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    handlers = [lambda: None, lambda: None]
    e += handlers[0]
    e += handlers[1]
    e.fire()
    e -= handlers[0]
    e.fire()

# Generated at 2022-06-25 12:41:16.148882
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:18.470196
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj_0 = _EventSource()
    obj_1 = obj_0.__iadd__(lambda x: None)

    assert obj_0 is obj_1


# Generated at 2022-06-25 12:41:23.849221
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:26.393553
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    event_source_1 += test_case_0
    event_source_1.fire()



# Generated at 2022-06-25 12:41:28.577716
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    args=[]
    kwargs={}
    event_source_1.fire(*args, **kwargs)



# Generated at 2022-06-25 12:41:30.173023
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    pass

# Generated at 2022-06-25 12:41:38.393373
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def handler1(event):
        pass

    def handler2(event):
        pass

    event_source_0 += handler1
    assert len(event_source_0._handlers) == 1

    event_source_0 += handler2
    assert len(event_source_0._handlers) == 2

    event_source_0.fire(42)
    assert len(event_source_0._handlers) == 2



# Generated at 2022-06-25 12:41:40.166414
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()


# Generated at 2022-06-25 12:41:51.663552
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    def on_collection_load_0(collection):
        print('collection name: %s', collection.collection_name)

    AnsibleCollectionConfig.on_collection_load += on_collection_load_0

    collection_0 = AnsibleCollectionConfig.collection_paths

    assert AnsibleCollectionConfig.collection_paths == collection_0

    AnsibleCollectionConfig.on_collection_load.fire(collection_0)

    event_source_0.fire()

    assert AnsibleCollectionConfig.default_collection is None

    AnsibleCollectionConfig.default_collection = None
    collection_1 = AnsibleCollectionConfig.default_collection

    assert AnsibleCollectionConfig.default_collection == collection_1

    playbook_0 = AnsibleCollectionConfig.playbook_paths

    assert AnsibleCollectionConfig.play

# Generated at 2022-06-25 12:41:59.150170
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    event_args = [1, 2, 3]
    event_kwargs = {'a': 4, 'b': 5}

    def handler_0(arg1, arg2, arg3, arg4, arg5):
        if arg4 != event_kwargs['a'] or arg5 != event_kwargs['b']:
            raise Exception('failure')

    def handler_1(arg1, arg2, arg3, arg4, arg5):
        if arg1 != event_args[0] or arg2 != event_args[1] or arg3 != event_args[2]:
            raise Exception('failure')

    event_source += handler_0
    event_source += handler_1

    event_source.fire(*event_args, **event_kwargs)


# Generated at 2022-06-25 12:42:02.438506
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire(4)
    except Exception as e:
        assert False

# Generated at 2022-06-25 12:42:04.627224
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:21.196545
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # tests that fire on _EventSource instance event_source_0 calls handler
    # with added args and kwargs
    handler = lambda *args, **kwargs: (args, kwargs)
    event_source_0 = _EventSource()
    event_source_0 += handler
    event_arg = 'event_arg'
    event_kwarg = {'event_kwarg': 'event_kwarg'}
    (args, kwargs) = event_source_0.fire(event_arg, event_kwarg=event_kwarg)
    assert args == (event_arg,)
    assert kwargs == event_kwarg


from ansible_collections.ansible.internal.collections.loader import CollectionsFinder as ControllerCollectionsFinder
from ansible_collections.ansible.internal.collections.loader import _

# Generated at 2022-06-25 12:42:22.780278
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()

# Generated at 2022-06-25 12:42:27.573715
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # event_source_0 of type _EventSource
    event_source_0 = AnsibleCollectionConfig.on_collection_load

    def fire_event_0(*args, **kwargs):
        print('\n>>> fire_event_0: args={} kwargs={}'.format(args, kwargs))

    event_source_0 += fire_event_0

    event_source_0.fire(event='Test event')



# Generated at 2022-06-25 12:42:28.771730
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # Call method fire on the instansiated object
    event_source_0.fire()



# Generated at 2022-06-25 12:42:30.487117
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0._on_exception = _on_exception_0
    event_source_0.fire()



# Generated at 2022-06-25 12:42:31.768662
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()



# Generated at 2022-06-25 12:42:33.655835
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    f_0 = lambda: 1
    event_source_1 += f_0
    event_source_1.fire()


# Generated at 2022-06-25 12:42:44.681562
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # build our event source
    event_source = _EventSource()

    # define our event handlers
    def handler_0(x, y):
        return x + y

    def handler_1(x, y):
        return x - y

    def handler_2(x, y):
        return x * y

    # hook up our event handlers
    event_source += handler_0
    event_source += handler_1
    event_source += handler_2

    # fire the event
    result = event_source.fire(2, 3)

    # verify the result
    assert result is None

    # verify the handlers were called
    assert handler_0.__defaults__[0] == 5
    assert handler_1.__defaults__[0] == -1
    assert handler_2.__defaults__[0] == 6



# Generated at 2022-06-25 12:42:48.118671
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import random

    event_source = _EventSource()

    num_iter = random.randint(0, 100)
    for i in range(num_iter):
        event_source += lambda: i

    vals = []
    idx = 0
    for i in range(num_iter):
        event_source.fire()



# Generated at 2022-06-25 12:42:53.099100
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0.fire()
    event_source_0 += object()
    try:
        event_source_0.fire()
    except ValueError:
        pass
    except Exception as ex:
        assert False, 'Unexpected exception raised: {}'.format(ex)
    event_source_0 -= object()


# Generated at 2022-06-25 12:43:01.099462
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    with raises(ValueError):
        event_source_0.fire(event_source_0, event_source_0)



# Generated at 2022-06-25 12:43:04.305642
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_subject_0 = _EventSource()
    test_handler_0 = lambda x: print(x)
    test_subject_0 += test_handler_0
    test_subject_0.fire(1)


# Generated at 2022-06-25 12:43:07.879299
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        handler_0 = "def handler(exc, *args, **kwargs):\n    return True\n"
        # event_source_0.fire()
        assert True
    except Exception as ex:
        assert False
        

# Generated at 2022-06-25 12:43:09.617412
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fixme_message = 'AnsibleCollectionConfig._on_collection_load.fire() not tested'
    raise NotImplementedError(fixme_message)



# Generated at 2022-06-25 12:43:11.984616
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()

    event_source_0 += _EventSource._on_exception


# Generated at 2022-06-25 12:43:16.062942
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire(int(), float())
    except (NotImplementedError, SystemError, SyntaxError, ValueError):
        pass
    except:
        raise RuntimeError('Unexpected exception was raised')

# Generated at 2022-06-25 12:43:18.355985
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
    except:
        return False
    return True


# Generated at 2022-06-25 12:43:19.236838
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass



# Generated at 2022-06-25 12:43:22.178705
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()

    def on_1(foo):
        pass

    event_source_1 += on_1

    event_source_1.fire('duck')



# Generated at 2022-06-25 12:43:24.073751
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()
    result = event_source_0.fire(1, 2)
    assert result is None



# Generated at 2022-06-25 12:43:35.231178
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_collections.ansible.controller.tests.unit.compat.mock import Mock, MagicMock
    with Mock() as m:
        event_source_0 = _EventSource()
        event_source_0._handlers = MagicMock()
        event_source_0._on_exception = MagicMock()
        result = event_source_0.fire()
        assert m._mock_call_count == 0



# Generated at 2022-06-25 12:43:45.355140
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import sys
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_text

    def test_handler(*args, **kwargs):
        try:
            raise Exception('boom')
        except Exception as ex:
            if ex.args[0] != 'boom':
                raise Exception('expected Exception "boom" to be raised')

    # create _EventSource instance
    event_source_0 = _EventSource()

    # add 'test_handler' function as a handler to the _EventSource instance
    event_source_0.on_collection_load += test_handler

    # fire the test_handler using the _EventSource instance

# Generated at 2022-06-25 12:43:49.101894
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Initialize an instance of _EventSource class
    event_source_0 = _EventSource()
    # Invoke method fire of class _EventSource with arguments tuple(), dict
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:43:50.816133
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:43:53.861372
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_1 = event_source_0.fire(('lots', 'of', 'args'))
    var_2 = event_source_0.fire()


# Generated at 2022-06-25 12:44:00.615111
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test with one event handler (no exception)
    def eventsource_handler_0(arg_0, arg_1):
        pass
    event_source_0 = _EventSource()
    event_source_0 += eventsource_handler_0
    event_source_0.fire(1, 2)

    # Test with one event handler (return value)
    def eventsource_handler_1(arg_0, arg_1):
        return arg_0
    event_source_1 = _EventSource()
    event_source_1 += eventsource_handler_1
    result_1 = event_source_1.fire(1, 2)
    assert result_1 == 1

    # Test with one event handler (exception)

# Generated at 2022-06-25 12:44:09.275551
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # NOTE: We can write unit tests for the loader in this file because they are tested on each supported
    #       Python interpreter by ansible-test (the tests will not be executed by ansible-test).
    #       To run the unit tests which use the collection loader:
    #       $ ansible-test units -v --python 3.5 collection_loader
    event_source_1 = _EventSource()
    event_source_1 += test_case_0
    var_1 = event_source_1.fire()
    event_source_1 -= test_case_0
    var_2 = event_source_1.fire()
    event_source_1 -= test_case_0

# Unit tests for class _AnsibleCollectionConfig

# Generated at 2022-06-25 12:44:10.469081
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TODO: Add test logic here
    raise Exception("Not implemented")



# Generated at 2022-06-25 12:44:13.093672
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        event_source_0.fire()
        pass
    except ValueError as value_err:
        pass

# Generated at 2022-06-25 12:44:14.608002
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0_0 = event_source_0.fire()

# Generated at 2022-06-25 12:44:27.513149
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:44:29.706701
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    # Calling fire with correct arguments
    event_source_0.fire()


# Generated at 2022-06-25 12:44:31.573933
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:33.102164
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_1 = _EventSource()
    var_1 = event_source_1.fire()



# Generated at 2022-06-25 12:44:34.506387
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:44:38.057235
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test case 0
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:44:40.182297
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    value = event_source_0.fire()
    assert value is None



# Generated at 2022-06-25 12:44:41.141344
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:42.746806
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:44:45.504040
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    if event_source_0.fire() is None:
        raise AssertionError('event_source_0.fire() should not return None')


# Generated at 2022-06-25 12:45:10.538470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_1 = event_source_0.fire(None, None)
    # assert var_1 is None


# Generated at 2022-06-25 12:45:12.468194
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    print("in test_case_1")
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:45:13.439745
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:45:14.604688
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

test__EventSource_fire()

# Generated at 2022-06-25 12:45:15.457101
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:45:16.673950
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    event_source_0 += lambda: None
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:45:19.918419
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    try:
        var_1 = event_source_0.fire()
    except ValueError:
        # Tolerate the exception
        pass
    try:
        var_2 = event_source_0.fire()
    except ValueError:
        # Tolerate the exception
        pass
    except Exception as var_3:
        pass
    try:
        var_4 = event_source_0.fire()
    except ValueError:
        # Tolerate the exception
        pass
    except Exception as var_5:
        pass




# Generated at 2022-06-25 12:45:20.769709
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    print('unit test for _EventSource.fire')



# Generated at 2022-06-25 12:45:22.433439
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_0 = _EventSource()
    var_0.__init__()
    event_source_0 = var_0
    var_0.__iadd__(test_case_0)
    var_1 = event_source_0.fire()

# Generated at 2022-06-25 12:45:24.019699
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Single test case
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:18.007182
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    with open('test/unit/test_data/test_collection_loader_data_0.txt', 'r') as f:
        test_data = f.readlines()

    test_case_id = 0
    for line in test_data:
        test_case_id += 1
        if not line.startswith('#'):
            try:
                exec (line)
            except:
                print('test case failed: ' + str(test_case_id))



# Generated at 2022-06-25 12:46:19.262797
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test setup

    # Test execution
    test_case_0()

# Generated at 2022-06-25 12:46:20.788445
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:21.681455
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()



# Generated at 2022-06-25 12:46:23.145550
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:24.790778
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:46:27.861639
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:46:29.849961
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var_0 = _EventSource()
    var_1 = var_0.fire()



# Generated at 2022-06-25 12:46:37.234959
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch, MagicMock

    # Setup mock objects
    m_h = MagicMock()
    m_h_return = MagicMock()

    # Patch the call to the mock method
    with patch.object(m_h, "__call__", return_value=m_h_return):
        # Patch the call to the set method
        with patch.object(set, "__iter__", return_value=[m_h]):
            # Patch the call to the handler method
            with patch.object(_EventSource, "_on_exception", return_value=True):
                # Setup
                event_source_0 = _EventSource()

                # Exercise
                with pytest.raises(Exception):
                    event_source_0.fire()

# Generated at 2022-06-25 12:46:38.445850
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:48:28.702693
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()

# Generated at 2022-06-25 12:48:30.280836
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert 0, "Run test_case_0():to verify  _EventSource.fire is working"



# Generated at 2022-06-25 12:48:31.825950
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()

# Generated at 2022-06-25 12:48:34.006740
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()
    assert var_0 is None


# Generated at 2022-06-25 12:48:35.641065
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:48:36.587319
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_case_0()


# Generated at 2022-06-25 12:48:38.285654
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()



# Generated at 2022-06-25 12:48:40.036652
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source_0 = _EventSource()
    var_0 = event_source_0.fire()


# Generated at 2022-06-25 12:48:41.234729
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    target_instance_0 = _EventSource()
    target_instance_0.fire()

# Generated at 2022-06-25 12:48:42.537156
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # No assertion
    test_case_0()