

# Generated at 2022-06-17 14:43:21.302211
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0

    es += handler
    assert len(es._handlers) == 1

    es -= handler

# Generated at 2022-06-17 14:43:31.708703
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException()

    def handler3(*args, **kwargs):
        raise Exception()

    def handler4(*args, **kwargs):
        raise TestException()

    def handler5(*args, **kwargs):
        raise Exception()

    def handler6(*args, **kwargs):
        raise TestException()

    def handler7(*args, **kwargs):
        raise Exception()

    def handler8(*args, **kwargs):
        raise TestException()

    def handler9(*args, **kwargs):
        raise Exception()

    def handler10(*args, **kwargs):
        raise TestException()

    def handler11(*args, **kwargs):
        raise Exception

# Generated at 2022-06-17 14:43:37.669779
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException()

    def handler3(*args, **kwargs):
        raise Exception()

    def handler4(*args, **kwargs):
        return True

    def handler5(*args, **kwargs):
        return False

    def handler6(*args, **kwargs):
        raise TestException()

    def handler7(*args, **kwargs):
        raise Exception()

    def handler8(*args, **kwargs):
        return True

    def handler9(*args, **kwargs):
        return False

    def handler10(*args, **kwargs):
        raise TestException()

    def handler11(*args, **kwargs):
        raise Exception()


# Generated at 2022-06-17 14:43:46.690040
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exceptions.append((handler, exc, args, kwargs))
            return False

    tes = _TestEventSource()
    tes.fire(1, 2, 3, 4)

    assert tes._exceptions == []

    def handler1(a, b, c, d):
        assert a == 1
        assert b == 2
        assert c == 3
        assert d == 4

    def handler2(a, b, c, d):
        assert a == 1
        assert b == 2
        assert c == 3
        assert d == 4
       

# Generated at 2022-06-17 14:43:55.783563
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    tes = _TestEventSource()
    tes += handler1
    tes += handler2

    try:
        tes.fire()
    except Exception as ex:
        assert ex.args[0] == 'handler1'
        assert tes._on_exception_called is True

# Generated at 2022-06-17 14:44:03.325198
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2
    assert handler in es._handlers
    assert handler2 in es._handlers



# Generated at 2022-06-17 14:44:06.664658
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:16.305291
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True

    def handler1(a, b, c):
        return a + b + c

    def handler2(a, b, c):
        raise ValueError('test')

    def handler3(a, b, c):
        return a + b + c

    def handler4(a, b, c):
        raise ValueError('test')

    def handler5(a, b, c):
        return a + b + c

    def handler6(a, b, c):
        raise Value

# Generated at 2022-06-17 14:44:24.295375
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def fire(self, *args, **kwargs):
            self.fired_count += 1
            super(TestEventSource, self).fire(*args, **kwargs)

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        pass

    def handler4(*args, **kwargs):
        pass

    def handler5(*args, **kwargs):
        pass

    def handler6(*args, **kwargs):
        pass



# Generated at 2022-06-17 14:44:35.672334
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            self.handler1_called = True

        def handler2(self, *args, **kwargs):
            self.handler2_called = True

        def handler3(self, *args, **kwargs):
            self.handler3_called = True

    test = _EventSourceTest()
    test.event_source.fire()
    assert test.handler1_called
    assert test.handler2_called
    assert test.handler3_called

# Generated at 2022-06-17 14:44:43.958480
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:44:53.919287
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self):
            super(EventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    event_source = EventSource()

    def handler_1(*args, **kwargs):
        raise ValueError('handler_1')

    def handler_2(*args, **kwargs):
        raise ValueError('handler_2')

    event_source += handler_1
    event_source += handler_2

    event_source.fire()

    assert event_source.exception_count == 2

# Generated at 2022-06-17 14:45:06.341368
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

   

# Generated at 2022-06-17 14:45:13.797556
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:45:19.746062
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:45:29.718768
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3
            self.event_source += self.handler_4
            self.event_source += self.handler_5
            self.event_source += self.handler_6
            self.event_source += self.handler_7
            self.event_source += self.handler_8
            self.event_source += self.handler_9
            self.event_source += self.handler_10
            self.event_source += self.handler_11
            self.event_source += self.handler_12
            self.event_source += self.handler_13

# Generated at 2022-06-17 14:45:33.637787
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:45:46.125582
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def fire(self, *args, **kwargs):
            self._fired = True
            super(_TestEventSource, self).fire(*args, **kwargs)

    class _TestEventHandler:
        def __init__(self):
            self._handled = False

        def __call__(self, *args, **kwargs):
            self._handled = True

    event_source = _TestEventSource()
    event_handler = _TestEventHandler()

    event_source += event_handler

    assert not event_handler._handled
    assert not event_source

# Generated at 2022-06-17 14:45:54.256336
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    tes = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        raise Exception('test')

    tes += handler1
    tes += handler2
    tes += handler3

    tes.fire()

    assert tes.exception_count == 2

# Generated at 2022-06-17 14:46:00.783339
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest(_EventSource):
        def __init__(self):
            super(EventSourceTest, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = EventSourceTest()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:46:17.244799
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    tes = TestEventSource()

    def handler1(*args, **kwargs):
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    tes += handler1
    tes += handler2

    tes.fire()

    assert tes.exception_count == 2

# Generated at 2022-06-17 14:46:24.842604
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    test = _EventSourceTest()
    test.event_source.fire('a', 'b', 'c', d='d', e='e')

    assert test.handler1_args == ('a', 'b', 'c')

# Generated at 2022-06-17 14:46:33.999096
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(event):
        raise Exception('handler1')

    def handler2(event):
        raise Exception('handler2')

    def handler3(event):
        raise Exception('handler3')

    event = _EventSource()
    event += handler1
    event += handler2
    event += handler3

    try:
        event.fire()
    except Exception as ex:
        assert ex.args[0] == 'handler1'

    event -= handler1

    try:
        event.fire()
    except Exception as ex:
        assert ex.args[0] == 'handler2'

    event -= handler2

    try:
        event.fire()
    except Exception as ex:
        assert ex.args[0] == 'handler3'

    event -= handler3

    event.fire()

# Generated at 2022-06-17 14:46:41.463169
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler
            self.event_source += self.handler_exception
            self.event_source += self.handler_exception_reraise
            self.event_source += self.handler_exception_reraise_false
            self.event_source += self.handler_exception_reraise_true
            self.event_source += self.handler_exception_reraise_true_reraise
            self.event_source += self.handler_exception_reraise_true_reraise_false
            self.event_source += self.handler_exception_reraise_true_reraise_true
            self.event_source += self.handler_exception_reraise_true

# Generated at 2022-06-17 14:46:47.907854
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            pass

    event_source_test = EventSourceTest()
    event_source_test.event_source.fire()

# Generated at 2022-06-17 14:46:58.108815
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_calls.append((handler, exc, args, kwargs))
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test exception')

    def handler3(*args, **kwargs):
        raise RuntimeError('test exception')

    def handler4(*args, **kwargs):
        raise ValueError('test exception')

    def handler5(*args, **kwargs):
        raise RuntimeError('test exception')


# Generated at 2022-06-17 14:47:00.242207
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:12.540167
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:47:15.040851
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:24.763958
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        print('handler1: args=%s, kwargs=%s' % (args, kwargs))

    def handler2(*args, **kwargs):
        print('handler2: args=%s, kwargs=%s' % (args, kwargs))

    def handler3(*args, **kwargs):
        print('handler3: args=%s, kwargs=%s' % (args, kwargs))
        raise ValueError('handler3 exception')

    def handler4(*args, **kwargs):
        print('handler4: args=%s, kwargs=%s' % (args, kwargs))
        raise ValueError('handler4 exception')


# Generated at 2022-06-17 14:47:47.703092
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class _TestException(Exception):
        pass

    def _test_handler(arg1, arg2, kwarg1=None, kwarg2=None):
        if arg1 == 'raise':
            raise _TestException()

    event_source = _TestEventSource()
    event_source += _test_handler

    event_source.fire('raise', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')
    assert event_source._

# Generated at 2022-06-17 14:47:51.247955
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    event_source = _EventSource()
    handler = lambda: None

    # Act
    event_source += handler

    # Assert
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:47:57.578954
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0



# Generated at 2022-06-17 14:48:09.115568
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler3')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler4')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler5')


# Generated at 2022-06-17 14:48:17.317790
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSource(_EventSource):
        pass

    def handler1(a, b):
        pass

    def handler2(a, b):
        pass

    event_source = EventSource()

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:48:23.445567
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:48:26.868915
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    event = _EventSource()
    event += handler
    event.fire(1, 2, 3)



# Generated at 2022-06-17 14:48:30.216353
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(arg):
        handler.arg = arg

    handler.arg = None

    event = _EventSource()
    event += handler

    event.fire('foo')

    assert handler.arg == 'foo'



# Generated at 2022-06-17 14:48:38.422576
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append(('exception', handler, exc, args, kwargs))
            return False

    tes = TestEventSource()

    def handler1(*args, **kwargs):
        tes.events.append(('handler1', args, kwargs))

    def handler2(*args, **kwargs):
        tes.events.append(('handler2', args, kwargs))
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        tes.events.append(('handler3', args, kwargs))



# Generated at 2022-06-17 14:48:43.091907
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.events = []

        def handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    event_source = _EventSource()
    test = _EventSourceTest()

    event_source += test.handler
    event_source.fire(1, 2, 3, a=4, b=5, c=6)

    assert test.events == [((1, 2, 3), dict(a=4, b=5, c=6))]



# Generated at 2022-06-17 14:49:23.497847
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:49:28.846136
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def fire(self, *args, **kwargs):
            self.fired = True

    test_event_source = TestEventSource()
    assert not test_event_source.fired
    test_event_source.fire()
    assert test_event_source.fired

# Generated at 2022-06-17 14:49:38.482148
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._exception_count = 0
            self._exception_handler = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exception_count += 1
            if self._exception_handler:
                return self._exception_handler(handler, exc, *args, **kwargs)
            return True

        def set_exception_handler(self, handler):
            self._exception_handler = handler

    def _handler1(a, b, c):
        return a + b + c

    def _handler2(a, b, c):
        raise ValueError('handler2')


# Generated at 2022-06-17 14:49:48.558362
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        raise Exception('test')

    def handler4(*args, **kwargs):
        raise Exception('test')

    def handler5(*args, **kwargs):
        raise Exception('test')

    def handler6(*args, **kwargs):
        raise Exception('test')

    def handler7(*args, **kwargs):
        raise Exception('test')

    def handler8(*args, **kwargs):
        raise Exception('test')

    def handler9(*args, **kwargs):
        raise Exception('test')

    def handler10(*args, **kwargs):
        raise Exception('test')


# Generated at 2022-06-17 14:49:51.298423
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:49:58.092789
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:50:00.195955
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()

    assert tes.fired

# Generated at 2022-06-17 14:50:07.170131
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:50:16.602333
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # test that __iadd__ raises ValueError when handler is not callable
    event_source = _EventSource()
    try:
        event_source += 'not callable'
    except ValueError:
        pass
    else:
        raise AssertionError('__iadd__ did not raise ValueError when handler is not callable')

    # test that __iadd__ does not raise ValueError when handler is callable
    event_source = _EventSource()
    try:
        event_source += lambda: None
    except ValueError:
        raise AssertionError('__iadd__ raised ValueError when handler is callable')



# Generated at 2022-06-17 14:50:21.713968
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:51:33.172272
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler1.called = True

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler2.called = True

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler3.called = True
        raise Exception('handler3 exception')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler4.called = True
        raise Exception('handler4 exception')

    event_source = _EventSource()
    event_source += handler1
    event_

# Generated at 2022-06-17 14:51:38.489763
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1
    assert callable(event_source._handlers.pop())


# Generated at 2022-06-17 14:51:45.181957
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self):
            super(EventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = EventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:51:52.721784
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert es._handlers == set()

    def handler1():
        pass

    es += handler1
    assert es._handlers == {handler1}

    def handler2():
        pass

    es += handler2
    assert es._handlers == {handler1, handler2}

    es += handler1
    assert es._handlers == {handler1, handler2}

    es += handler2
    assert es._handlers == {handler1, handler2}

    with pytest.raises(ValueError):
        es += 'not callable'



# Generated at 2022-06-17 14:52:02.557100
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            raise ValueError('handler2')

        def handler3(self, *args, **kwargs):
            raise ValueError('handler3')

        def handler4(self, *args, **kwargs):
            raise ValueError('handler4')

        def handler5(self, *args, **kwargs):
            raise Value

# Generated at 2022-06-17 14:52:12.008697
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        handler1.called = True
        handler1.arg1 = arg1
        handler1.arg2 = arg2

    def handler2(arg1, arg2):
        handler2.called = True
        handler2.arg1 = arg1
        handler2.arg2 = arg2

    handler1.called = False
    handler2.called = False

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire('arg1', 'arg2')

    assert handler1.called
    assert handler1.arg1 == 'arg1'
    assert handler1.arg2 == 'arg2'

    assert handler2.called
    assert handler2.arg1 == 'arg1'

# Generated at 2022-06-17 14:52:14.460785
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:52:24.811447
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler3')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler4')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler5')


# Generated at 2022-06-17 14:52:33.709509
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_impl

        def _on_exception_impl(self, handler, exc, *args, **kwargs):
            self._exception = exc
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        raise Exception('handler3 exception')

    event_source = TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

# Generated at 2022-06-17 14:52:42.997663
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14
