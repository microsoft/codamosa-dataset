

# Generated at 2022-06-17 14:43:17.575304
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def fire(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source.fire()
    assert event_source.fired is True



# Generated at 2022-06-17 14:43:22.833387
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += None


# Generated at 2022-06-17 14:43:27.271734
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    event_source = _EventSource()
    event_source += handler

    event_source.fire('arg1', 'arg2')

# Generated at 2022-06-17 14:43:35.021705
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            pass

        def handler3(self, *args, **kwargs):
            raise ValueError('handler3 exception')

        def handler4(self, *args, **kwargs):
            raise ValueError('handler4 exception')


# Generated at 2022-06-17 14:43:46.129785
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    test = EventSourceTest()
    test.event_source.fire('a', 'b', 'c', d='d', e='e')
    assert test.handler1_args == ('a', 'b', 'c')

# Generated at 2022-06-17 14:43:53.619473
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler

        def handler(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    test = _EventSourceTest()
    test.event_source.fire('a', 'b', 'c', d='e', f='g')
    assert test.args == ('a', 'b', 'c')
    assert test.kwargs == dict(d='e', f='g')



# Generated at 2022-06-17 14:44:02.542704
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import PY3

    def handler(a, b):
        pass

    event_source = _EventSource()
    event_source += handler

    assert handler in event_source._handlers

    if PY3:
        with pytest.raises(ValueError):
            event_source += to_bytes(u'not callable')
    else:
        with pytest.raises(ValueError):
            event_source += to_bytes(u'not callable')



# Generated at 2022-06-17 14:44:13.717780
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            raise ValueError('handler2')

        def handler3(self, *args, **kwargs):
            raise ValueError('handler3')

        def handler4(self, *args, **kwargs):
            raise ValueError('handler4')


# Generated at 2022-06-17 14:44:23.379524
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception = self._on_exception_impl

        def _on_exception_impl(self, handler, exc, *args, **kwargs):
            return False

    event_source = _TestEventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3')

    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()

# Generated at 2022-06-17 14:44:29.230412
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.event_fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.event_fired



# Generated at 2022-06-17 14:44:41.059392
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler(arg):
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1



# Generated at 2022-06-17 14:44:52.704328
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b):
        assert a == 1
        assert b == 2
        return

    def handler2(a, b):
        assert a == 1
        assert b == 2
        raise Exception('handler2')

    def handler3(a, b):
        assert a == 1
        assert b == 2
        raise Exception('handler3')

    def handler4(a, b):
        assert a == 1
        assert b == 2
        raise Exception('handler4')

    def handler5(a, b):
        assert a == 1
        assert b == 2
        raise Exception('handler5')

    def handler6(a, b):
        assert a == 1
        assert b == 2
        raise Exception('handler6')

    def handler7(a, b):
        assert a == 1
        assert b == 2
        raise

# Generated at 2022-06-17 14:44:59.890556
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2
    assert handler in es._handlers
    assert handler2 in es._handlers

    es += handler2
    assert len(es._handlers) == 2
    assert handler in es._handlers
    assert handler2 in es._handlers

    es += handler2

# Generated at 2022-06-17 14:45:09.260179
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    test = _EventSourceTest()
    test.event_source.fire('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')

    assert test.handler1_args == ('arg1', 'arg2')
    assert test.handler1

# Generated at 2022-06-17 14:45:13.142503
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def handler(arg):
        pass

    event += handler
    assert handler in event._handlers



# Generated at 2022-06-17 14:45:21.951391
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._exception_handler_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exception_handler_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    def handler5(*args, **kwargs):
        raise ValueError('test')

    def handler6(*args, **kwargs):
        raise ValueError('test')



# Generated at 2022-06-17 14:45:31.767270
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append(('exception', handler, exc, args, kwargs))
            return False

    def handler1(*args, **kwargs):
        events.append(('handler1', args, kwargs))

    def handler2(*args, **kwargs):
        events.append(('handler2', args, kwargs))
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        events.append(('handler3', args, kwargs))

    events = []
    es = TestEventSource()
    es += handler1

# Generated at 2022-06-17 14:45:35.299075
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:43.423128
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:45:52.794544
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    es += handler1
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es += handler1
    assert len(es._handlers) == 2

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0

    try:
        es += 1
        assert False, 'expected ValueError'
    except ValueError:
        pass


# Generated at 2022-06-17 14:45:59.654782
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:46:11.945762
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True

    class _TestException(Exception):
        pass

    class _TestHandler:
        def __init__(self, exception_to_raise=None):
            self._exception_to_raise = exception_to_raise

        def __call__(self, *args, **kwargs):
            if self._exception_to_raise:
                raise self._exception_to_raise

    test_event_source = _TestEventSource()

    test_event_source.fire()

    test_event_

# Generated at 2022-06-17 14:46:20.670409
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler
            self.event_source += self.handler_exception
            self.event_source += self.handler_exception_reraise
            self.event_source += self.handler_exception_reraise_false
            self.event_source += self.handler_exception_reraise_true
            self.event_source += self.handler_exception_reraise_true_with_args
            self.event_source += self.handler_exception_reraise_true_with_kwargs
            self.event_source += self.handler_exception_reraise_true_with_args_and_kwargs
            self.event_source += self.handler_exception

# Generated at 2022-06-17 14:46:29.221407
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event = _EventSource()
            self.event += self._handler1
            self.event += self._handler2
            self.event += self._handler3
            self.event += self._handler4

        def _handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def _handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

        def _handler3(self, *args, **kwargs):
            self.handler3_args = args
            self.handler3_kwargs = kwargs
            raise Exception('handler3 exception')


# Generated at 2022-06-17 14:46:42.894645
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True

    class TestException(Exception):
        pass

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise TestException()

    def handler_3(*args, **kwargs):
        raise ValueError()

    def handler_4(*args, **kwargs):
        raise TestException()

    def handler_5(*args, **kwargs):
        raise ValueError()


# Generated at 2022-06-17 14:46:52.048282
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        raise Exception('test')

    def handler4(*args, **kwargs):
        raise Exception('test')

    def handler5(*args, **kwargs):
        raise Exception('test')

    def handler6(*args, **kwargs):
        raise Exception('test')

    def handler7(*args, **kwargs):
        raise Exception('test')

    def handler8(*args, **kwargs):
        raise Exception('test')

    def handler9(*args, **kwargs):
        raise Exception('test')

    def handler10(*args, **kwargs):
        raise Exception('test')


# Generated at 2022-06-17 14:47:02.073432
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    test_event_source = _TestEventSource()
    test_event_source += handler1
    test_event_source += handler2

    try:
        test_event_source.fire()
    except Exception as ex:
        assert str(ex) == 'handler1'
        assert test_event_source._on

# Generated at 2022-06-17 14:47:10.842667
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that the method fire of class _EventSource works as expected
    #
    # Arrange
    #
    # Create a _EventSource object
    event_source = _EventSource()

    # Create a list of handlers
    handlers = [
        lambda: None,
        lambda: None,
        lambda: None,
    ]

    # Act
    #
    # Add the handlers to the event source
    for handler in handlers:
        event_source += handler

    # Fire the event source
    event_source.fire()



# Generated at 2022-06-17 14:47:21.745428
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:47:23.833061
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()

    assert event_source.fired

# Generated at 2022-06-17 14:47:34.813395
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:39.461946
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(a, b):
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:47:41.192995
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:48.392572
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2, kwarg1=None, kwarg2=None):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        assert kwarg1 == 'kwarg1'
        assert kwarg2 == 'kwarg2'

    def handler2(arg1, arg2, kwarg1=None, kwarg2=None):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        assert kwarg1 == 'kwarg1'
        assert kwarg2 == 'kwarg2'

    def handler3(arg1, arg2, kwarg1=None, kwarg2=None):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

# Generated at 2022-06-17 14:47:50.531008
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:59.152896
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    test = _EventSourceTest()
    test.event_source.fire('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')
    assert test.handler1_args == ('arg1', 'arg2')
    assert test.handler1

# Generated at 2022-06-17 14:48:02.550639
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:04.944611
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:07.170621
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:48:09.691295
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:21.405791
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:48:27.899377
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(a, b, c):
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source -= handler
    assert len(event_source._handlers) == 0

    event_source -= handler
    assert len(event_source._handlers) == 0



# Generated at 2022-06-17 14:48:29.857645
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:34.858326
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:48:47.828175
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    es += handler1
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es += handler1
    assert len(es._handlers) == 2

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0

    es -= handler2
    assert len(es._handlers) == 0

    def handler3():
        pass

    es += handler3
    assert len(es._handlers) == 1

    es -= handler3

# Generated at 2022-06-17 14:48:58.540918
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('test exception')

    def handler_3(*args, **kwargs):
        pass

    def handler_4(*args, **kwargs):
        raise Exception('test exception')

    event_source = _TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3
    event_

# Generated at 2022-06-17 14:49:02.656593
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = _TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:49:03.812979
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda: None
    event_source.fire()

# Generated at 2022-06-17 14:49:09.295953
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            pass

        def handler3(self, *args, **kwargs):
            raise ValueError('test')

    event_source_test = _EventSourceTest()
    try:
        event_source_test.event_source.fire()
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')



# Generated at 2022-06-17 14:49:19.762195
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    es = MyEventSource()
    es += handler1
    es += handler2
    es += handler3

    es.fire()

    assert es.exception_count == 2

# Generated at 2022-06-17 14:49:46.917324
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler in event_source._handlers
    assert handler2 in event_source._handlers

    event_source += handler2

# Generated at 2022-06-17 14:49:56.983547
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    test_event_source = _TestEventSource()
    test_event_source += handler1
    test_event_source += handler2
    test_event_source += handler3

    test_event_source.fire()

    assert test_event_source

# Generated at 2022-06-17 14:50:07.924021
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_test

        def _on_exception_test(self, handler, exc, *args, **kwargs):
            self.on_exception_test_handler = handler
            self.on_exception_test_exc = exc
            self.on_exception_test_args = args
            self.on_exception_test_kwargs = kwargs
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test exception')

    event_source = TestEventSource()
    event_source += handler_1

# Generated at 2022-06-17 14:50:18.575191
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1():
        raise TestException('handler1')

    def handler2():
        raise TestException('handler2')

    def handler3():
        raise TestException('handler3')

    def handler4():
        raise TestException('handler4')

    def handler5():
        raise TestException('handler5')

    def handler6():
        raise TestException('handler6')

    def handler7():
        raise TestException('handler7')

    def handler8():
        raise TestException('handler8')

    def handler9():
        raise TestException('handler9')

    def handler10():
        raise TestException('handler10')

    def handler11():
        raise TestException('handler11')

    def handler12():
        raise TestException('handler12')

    def handler13():
        raise

# Generated at 2022-06-17 14:50:20.391326
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:25.789235
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == {'a': 3, 'b': 4}

    def handler2(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == {'a': 3, 'b': 4}

    event_source += handler1
    event_source += handler2
    event_source.fire(1, 2, a=3, b=4)



# Generated at 2022-06-17 14:50:29.428646
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:50:37.957292
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('test')

    def handler_3(*args, **kwargs):
        raise Exception('test')

    event_source = _TestEventSource()
    event_source += handler_1

# Generated at 2022-06-17 14:50:45.067563
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:50:55.801927
# Unit test for method fire of class _EventSource

# Generated at 2022-06-17 14:51:31.870954
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        handler1.arg1 = arg1
        handler1.arg2 = arg2

    def handler2(arg1, arg2):
        handler2.arg1 = arg1
        handler2.arg2 = arg2

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire('a', 'b')

    assert handler1.arg1 == 'a'
    assert handler1.arg2 == 'b'
    assert handler2.arg1 == 'a'
    assert handler2.arg2 == 'b'

# Generated at 2022-06-17 14:51:42.217359
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def fire(self, *args, **kwargs):
            self.fired = True
            super(TestEventSource, self).fire(*args, **kwargs)

    event_source = TestEventSource()
    assert not event_source.fired

    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:51:48.981121
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True

    def handler1(arg1, arg2, kwarg1=None, kwarg2=None):
        pass

    def handler2(arg1, arg2, kwarg1=None, kwarg2=None):
        raise Exception('handler2 exception')

    def handler3(arg1, arg2, kwarg1=None, kwarg2=None):
        raise Exception('handler3 exception')


# Generated at 2022-06-17 14:51:52.217049
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:52:02.234960
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es += handler2
    assert len(es._handlers) == 2

    es += handler2
    assert len(es._handlers) == 2

    es += handler2
    assert len(es._handlers) == 2

    es += handler2
    assert len(es._handlers) == 2

    es += handler

# Generated at 2022-06-17 14:52:11.863294
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False
            self.exception_handler_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            self.exception_handler_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('test exception')

    def handler_3(*args, **kwargs):
        pass

    test_event_source = _TestEventSource()
    test_event_source += handler_1
    test_event_source += handler_2

# Generated at 2022-06-17 14:52:19.265069
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        raise ValueError('handler_1')

    def handler_2(*args, **kwargs):
        raise ValueError('handler_2')

    def handler_3(*args, **kwargs):
        raise ValueError('handler_3')

    test_event_source = _TestEventSource()
    test_event_source += handler_1
    test_event_source += handler_2
    test_event_source += handler_3



# Generated at 2022-06-17 14:52:29.412698
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._calls.append(('_on_exception', handler, exc, args, kwargs))
            return False

    def handler1(*args, **kwargs):
        calls.append(('handler1', args, kwargs))

    def handler2(*args, **kwargs):
        calls.append(('handler2', args, kwargs))
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        calls.append(('handler3', args, kwargs))

    calls = []
    event_source = TestEventSource

# Generated at 2022-06-17 14:52:35.094782
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:52:40.506660
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

