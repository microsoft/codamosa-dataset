

# Generated at 2022-06-17 14:43:14.888394
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b):
        assert a == 1
        assert b == 2
        return 'handler1'

    def handler2(a, b):
        assert a == 1
        assert b == 2
        return 'handler2'

    def handler3(a, b):
        assert a == 1
        assert b == 2
        return 'handler3'

    def handler4(a, b):
        assert a == 1
        assert b == 2
        return 'handler4'

    def handler5(a, b):
        assert a == 1
        assert b == 2
        return 'handler5'

    def handler6(a, b):
        assert a == 1
        assert b == 2
        return 'handler6'

    def handler7(a, b):
        assert a == 1
        assert b == 2

# Generated at 2022-06-17 14:43:20.538712
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += None



# Generated at 2022-06-17 14:43:25.055216
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    def handler3(arg1, arg2):
        pass

    event_source = _EventSource()

    event_source += handler1
    event_source += handler2
    event_source += handler3

    assert len(event_source._handlers) == 3
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers
    assert handler3 in event_source._handlers



# Generated at 2022-06-17 14:43:30.184150
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    test_event_source = TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()
    assert test_event_source.fired

# Generated at 2022-06-17 14:43:35.049915
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler_1():
        pass

    def handler_2():
        pass

    es += handler_1
    assert len(es._handlers) == 1
    assert handler_1 in es._handlers

    es += handler_2
    assert len(es._handlers) == 2
    assert handler_2 in es._handlers

    try:
        es += 'not callable'
        assert False
    except ValueError:
        pass



# Generated at 2022-06-17 14:43:44.683182
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.event_fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.event_fired

# Generated at 2022-06-17 14:43:46.656802
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:43:49.694763
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler():
        pass

    es += handler
    assert handler in es._handlers

    es += handler
    assert len(es._handlers) == 1



# Generated at 2022-06-17 14:43:54.248177
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:44:04.052390
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2

    try:
        event_source.fire()
    except Exception as ex:
        assert str(ex) == 'handler2'

    assert event_source._on_exception_called

# Unit test

# Generated at 2022-06-17 14:44:14.526758
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('test')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('test')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('test')

    event_source = _EventSource()

# Generated at 2022-06-17 14:44:16.155897
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:44:21.930803
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    es += handler1
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0



# Generated at 2022-06-17 14:44:28.031327
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    es = _TestEventSource()

    def handler1(*args, **kwargs):
        raise ValueError('handler1')

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    es += handler1
    es += handler2

    try:
        es.fire()
    except ValueError as ex:
        assert ex.args[0] == 'handler1'

    try:
        es.fire()
    except ValueError as ex:
        assert ex.args[0] == 'handler2'

    es -= handler1


# Generated at 2022-06-17 14:44:38.629648
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        pass

    test_event_source = TestEventSource()
    test_event_source += handler1
    test_event_source += handler2
    test_event_source += handler3

    test_event_source.fire()

    assert test_event_source.exception_raised is True


# Unit

# Generated at 2022-06-17 14:44:46.282005
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    def handler_3(*args, **kwargs):
        raise ValueError('test')

    event_source = _TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3


# Generated at 2022-06-17 14:44:55.408836
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(x):
        assert x == 1

    def handler2(x):
        assert x == 1
        raise ValueError('test')

    def handler3(x):
        assert x == 1
        raise ValueError('test')

    def handler4(x):
        assert x == 1
        raise ValueError('test')

    def handler5(x):
        assert x == 1
        raise ValueError('test')

    def handler6(x):
        assert x == 1
        raise ValueError('test')

    def handler7(x):
        assert x == 1
        raise ValueError('test')

    def handler8(x):
        assert x == 1
        raise ValueError('test')

    def handler9(x):
        assert x == 1
        raise ValueError('test')


# Generated at 2022-06-17 14:45:06.891673
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    tes = _TestEventSource()
    tes.fire()
    assert not tes.exception_raised

    def handler():
        raise ValueError('test')

    tes += handler
    tes.fire()
    assert tes.exception_raised

    tes.exception_raised = False
    tes -= handler
    tes.fire()
    assert not tes.exception_raised

# Generated at 2022-06-17 14:45:13.960755
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2


# Generated at 2022-06-17 14:45:16.495396
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:45:33.175559
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exception_count += 1
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    def handler3(*args, **kwargs):
        raise ValueError('handler3')

    test_event_source = _TestEventSource()
    test_event_source += handler1
    test_event_source += handler2
    test_event_source += handler3

    test_event_source.fire()
    assert test_event_source._ex

# Generated at 2022-06-17 14:45:38.322808
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1
    assert callable(event_source._handlers.pop())


# Generated at 2022-06-17 14:45:48.136895
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    test_event_source = _TestEventSource()
    test_event_source.fire()
    assert test_event_source.exception_count == 0

    def handler1(*args, **kwargs):
        raise ValueError('handler1')

    test_event_source += handler1
    test_event_source.fire()
    assert test_event_source.exception_count == 1

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    test_event

# Generated at 2022-06-17 14:45:50.088718
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:54.386261
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test that an exception is raised if the handler is not callable
    event_source = _EventSource()
    try:
        event_source += 'not callable'
        assert False
    except ValueError:
        pass

    # Test that the handler is added to the set of handlers
    def handler():
        pass
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:46:00.270515
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    test = Test()
    event_source = _EventSource()
    event_source += test
    event_source.fire()
    assert test.called

# Generated at 2022-06-17 14:46:07.241120
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:46:17.958910
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3
            self.event_source += self.handler_4
            self.event_source += self.handler_5
            self.event_source += self.handler_6
            self.event_source += self.handler_7
            self.event_source += self.handler_8
            self.event_source += self.handler_9
            self.event_source += self.handler_10
            self.event_source += self.handler_11
            self.event_source += self.handler_12
            self.event_source += self.handler_13

# Generated at 2022-06-17 14:46:20.412500
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:46:27.748467
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2



# Generated at 2022-06-17 14:46:37.535839
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:46:45.755756
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self):
            self.value = 0

        def handler(self, value):
            self.value += value

    t = Test()
    e = _EventSource()
    e += t.handler
    e.fire(1)
    assert t.value == 1
    e.fire(2)
    assert t.value == 3
    e -= t.handler
    e.fire(4)
    assert t.value == 3


# Generated at 2022-06-17 14:46:51.912485
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:47:00.006767
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es += handler2
    assert len(es._handlers) == 2

    es += handler2
    assert len(es._handlers) == 2

    es += handler
    assert len(es._handlers) == 2

    es += handler
    assert len(es._handlers) == 2

    es += handler
    assert len(es._handlers) == 2

    es += handler2


# Generated at 2022-06-17 14:47:12.312275
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception = exc
            return False

    event_source = TestEventSource()

    def handler1(*args, **kwargs):
        raise ValueError('handler1')

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    event_source += handler1
    event_source += handler2

    event_source.fire()

    assert event_source.exception is not None
    assert isinstance(event_source.exception, ValueError)
    assert event_source.exception.args[0] == 'handler1'




# Generated at 2022-06-17 14:47:14.818512
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:17.235816
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:26.124700
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception = None

    def _on_exception(handler, exc, *args, **kwargs):
        return False

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise Exception('test')

    def _handler_3(*args, **kwargs):
        raise Exception('test')

    event_source = _TestEventSource()
    event_source._on_exception = _on_exception

    event_source += _handler_1
    event_source += _handler_2
    event_source += _handler_3

    event_source.fire()

    event_source -= _handler

# Generated at 2022-06-17 14:47:28.792920
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-17 14:47:34.447114
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler3 exception')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler4 exception')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler5 exception')


# Generated at 2022-06-17 14:47:49.185042
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException()

    def handler3(*args, **kwargs):
        raise ValueError()

    def handler4(*args, **kwargs):
        raise TestException()

    def handler5(*args, **kwargs):
        raise ValueError()

    def handler6(*args, **kwargs):
        raise ValueError()

    def handler7(*args, **kwargs):
        raise ValueError()

    def handler8(*args, **kwargs):
        raise ValueError()

    def handler9(*args, **kwargs):
        raise ValueError()

    def handler10(*args, **kwargs):
        raise ValueError()


# Generated at 2022-06-17 14:47:58.550395
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exception_count += 1
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')

    tes = TestEventSource()
    tes += handler1
    tes += handler2
    tes += handler3
    tes += handler4

    tes.fire()
   

# Generated at 2022-06-17 14:48:10.679250
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    def handler_3(*args, **kwargs):
        pass

    def handler_4(*args, **kwargs):
        raise ValueError('test')

    test_event_source = _TestEventSource()

    test_event_source += handler_1
    test_event_source += handler_2
    test_event_source

# Generated at 2022-06-17 14:48:14.045571
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:23.118202
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    test_event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    test_event_source += handler1
    test_event_source += handler2
    test_event_source += handler3

    test_event_source.fire()

    assert test_event_source.exception_

# Generated at 2022-06-17 14:48:32.284623
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler
            self.event_source += self.handler_exception

        def handler(self, *args, **kwargs):
            self.handler_args = args
            self.handler_kwargs = kwargs

        def handler_exception(self, *args, **kwargs):
            raise Exception('test exception')

    test = _EventSourceTest()
    test.event_source.fire('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')

    assert test.handler_args == ('arg1', 'arg2')

# Generated at 2022-06-17 14:48:47.009573
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest:
        def __init__(self):
            self.events = []

        def event_handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    event_source = _EventSource()
    event_source += _EventSourceTest().event_handler
    event_source.fire(1, 2, 3, a=4, b=5, c=6)
    assert event_source._handlers
    assert len(event_source._handlers) == 1
    assert event_source._handlers.pop()
    assert not event_source._handlers
    assert event_source._handlers == set()
    assert len(event_source._handlers) == 0
    assert event_source._handlers is not None
    assert event_source._handlers is not False


# Generated at 2022-06-17 14:48:58.448665
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    event_source_test = _EventSourceTest()
    event_source_test.event_source.fire('a', 'b', 'c', d='e', f='g')
    assert event_source_test.handler1_args == ('a', 'b', 'c')

# Generated at 2022-06-17 14:49:04.463690
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        pass

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

    assert event_source.exception_raised



# Generated at 2022-06-17 14:49:11.841512
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    try:
        event_source += None
        assert False
    except ValueError:
        pass

    assert event_source._handlers == {handler}



# Generated at 2022-06-17 14:49:37.543337
# Unit test for method fire of class _EventSource

# Generated at 2022-06-17 14:49:47.994680
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException('test')

    def handler3(*args, **kwargs):
        raise Exception('test')

    def handler4(*args, **kwargs):
        raise TestException('test')

    def on_exception(handler, exc, *args, **kwargs):
        if isinstance(exc, TestException):
            return False
        return True

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3
    event_source += handler4
    event_source._on_exception = on_exception


# Generated at 2022-06-17 14:49:52.157201
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:49:59.986102
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_test

        def _on_exception_test(self, handler, exc, *args, **kwargs):
            self.exception_handler = handler
            self.exception = exc
            self.args = args
            self.kwargs = kwargs
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        pass

    test_event_source = TestEventSource()
    test_event_source += handler1
    test_event_source += handler2
    test_event_

# Generated at 2022-06-17 14:50:02.567544
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:50:08.412583
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:50:10.882766
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:50:20.499810
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:50:25.598833
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:50:32.917528
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return isinstance(exc, TestException)

    event_source = TestEventSource()

    def handler1(*args, **kwargs):
        raise TestException()

    def handler2(*args, **kwargs):
        raise ValueError()

    event_source += handler1
    event_source += handler2

    try:
        event_source.fire()
    except TestException:
        pass
    else:
        assert False, 'expected TestException'

    assert event_source

# Generated at 2022-06-17 14:50:51.239140
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            pass

    _EventSourceTest()


# Generated at 2022-06-17 14:51:02.663073
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler
            self.event_source += self.handler_with_exception
            self.event_source += self.handler_with_exception_and_reraise
            self.event_source += self.handler_with_exception_and_no_reraise
            self.event_source += self.handler_with_exception_and_reraise_and_no_reraise
            self.event_source += self.handler_with_exception_and_reraise_and_reraise
            self.event_source += self.handler_with_exception_and_reraise_and_reraise_and_reraise
            self.event_source += self.handler_with_ex

# Generated at 2022-06-17 14:51:11.056798
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    test = _EventSourceTest()
    test.event_source.fire(1, 2, 3, a=4, b=5, c=6)

    assert test.handler1_args == (1, 2, 3)

# Generated at 2022-06-17 14:51:19.270973
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('test')

    def handler_3(*args, **kwargs):
        pass

    test_event_source = _TestEventSource()
    test_event_source += handler_1
    test_event_source += handler_2
    test_event_source += handler_3


# Generated at 2022-06-17 14:51:28.218298
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3')

    event_source = _TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()

    assert event_source._on_ex

# Generated at 2022-06-17 14:51:32.181116
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:51:40.670790
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:51:48.290175
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.calls.append(('_on_exception', handler, exc, args, kwargs))
            return False

    def handler1(*args, **kwargs):
        calls.append(('handler1', args, kwargs))

    def handler2(*args, **kwargs):
        calls.append(('handler2', args, kwargs))
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        calls.append(('handler3', args, kwargs))

    calls = []
    es = _TestEventSource

# Generated at 2022-06-17 14:51:56.228362
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        handler1.arg1 = arg1
        handler1.arg2 = arg2

    def handler2(arg1, arg2):
        handler2.arg1 = arg1
        handler2.arg2 = arg2

    event = _EventSource()
    event += handler1
    event += handler2

    event.fire('arg1', 'arg2')

    assert handler1.arg1 == 'arg1'
    assert handler1.arg2 == 'arg2'
    assert handler2.arg1 == 'arg1'
    assert handler2.arg2 == 'arg2'

# Generated at 2022-06-17 14:51:58.363941
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:52:32.848137
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:52:42.638003
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_return = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return self._on_exception_return

    def _handler_one(*args, **kwargs):
        pass

    def _handler_two(*args, **kwargs):
        raise Exception('handler two raised an exception')

    def _handler_three(*args, **kwargs):
        raise Exception('handler three raised an exception')

    def _handler_four(*args, **kwargs):
        raise Exception('handler four raised an exception')


# Generated at 2022-06-17 14:52:47.044429
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1
    assert callable(event_source._handlers.pop())


# Generated at 2022-06-17 14:52:50.778848
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(arg):
        assert arg == 'foo'

    event_source = _EventSource()
    event_source += handler
    event_source.fire('foo')

# Generated at 2022-06-17 14:52:53.484884
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    es += lambda: None
    es += lambda: None
    assert len(es._handlers) == 3


# Generated at 2022-06-17 14:52:59.672149
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert len(e._handlers) == 0

    def handler1():
        pass

    e += handler1
    assert len(e._handlers) == 1

    e += handler1
    assert len(e._handlers) == 1

    def handler2():
        pass

    e += handler2
    assert len(e._handlers) == 2

    e += handler1
    assert len(e._handlers) == 2

    e += handler2
    assert len(e._handlers) == 2



# Generated at 2022-06-17 14:53:01.913982
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-17 14:53:04.155455
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1
