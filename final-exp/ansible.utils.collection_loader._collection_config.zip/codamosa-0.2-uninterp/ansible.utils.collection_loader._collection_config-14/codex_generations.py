

# Generated at 2022-06-17 14:43:14.377952
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:43:21.337249
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:43:24.792298
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    es += lambda: None
    es += lambda: None
    assert len(es._handlers) == 3


# Generated at 2022-06-17 14:43:27.726277
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:43:29.579953
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:43:36.345027
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append(('exception', handler, exc, args, kwargs))
            return False

    tes = TestEventSource()

    def handler1(*args, **kwargs):
        tes.events.append(('handler1', args, kwargs))

    def handler2(*args, **kwargs):
        tes.events.append(('handler2', args, kwargs))
        raise ValueError('handler2 exception')

    def handler3(*args, **kwargs):
        tes.events.append(('handler3', args, kwargs))

# Generated at 2022-06-17 14:43:46.500659
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3
            self.event_source += self.handler_4
            self.event_source += self.handler_5
            self.event_source += self.handler_6
            self.event_source += self.handler_7
            self.event_source += self.handler_8
            self.event_source += self.handler_9
            self.event_source += self.handler_10
            self.event_source += self.handler_11
            self.event_source += self.handler_12
            self.event_source += self.handler_13

# Generated at 2022-06-17 14:43:53.927850
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test that __iadd__ raises a ValueError if the handler is not callable
    event_source = _EventSource()
    with pytest.raises(ValueError):
        event_source += 'not callable'

    # Test that __iadd__ adds the handler to the set of handlers
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers

    # Test that __iadd__ does not add the handler to the set of handlers if the handler is already in the set
    event_source += handler
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:43:55.783341
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:43:58.216928
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:08.812489
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    def handler2():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler2
    assert len(es._handlers) == 2

    es -= handler
    assert len(es._handlers) == 1

    es -= handler2

# Generated at 2022-06-17 14:44:13.165976
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:23.282404
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3
            self.event_source += self.handler_4
            self.event_source += self.handler_5
            self.event_source += self.handler_6
            self.event_source += self.handler_7
            self.event_source += self.handler_8
            self.event_source += self.handler_9
            self.event_source += self.handler_10
            self.event_source += self.handler_11
            self.event_source += self.handler_12
            self.event_source += self.handler_13

# Generated at 2022-06-17 14:44:29.144990
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        handler1.arg1 = arg1
        handler1.arg2 = arg2

    def handler2(arg1, arg2):
        handler2.arg1 = arg1
        handler2.arg2 = arg2

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire('a', 'b')

    assert handler1.arg1 == 'a'
    assert handler1.arg2 == 'b'
    assert handler2.arg1 == 'a'
    assert handler2.arg2 == 'b'

# Generated at 2022-06-17 14:44:35.785480
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(arg1, arg2):
        print('handler1: arg1=%s, arg2=%s' % (arg1, arg2))

    def handler2(arg1, arg2):
        print('handler2: arg1=%s, arg2=%s' % (arg1, arg2))

    event_source += handler1
    event_source += handler2

    event_source.fire('foo', 'bar')



# Generated at 2022-06-17 14:44:47.912710
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException()

    def handler3(*args, **kwargs):
        raise Exception()

    def handler4(*args, **kwargs):
        raise TestException()

    def handler5(*args, **kwargs):
        raise Exception()

    def handler6(*args, **kwargs):
        raise TestException()

    def handler7(*args, **kwargs):
        raise Exception()

    def handler8(*args, **kwargs):
        raise TestException()

    def handler9(*args, **kwargs):
        raise Exception()

    def handler10(*args, **kwargs):
        raise TestException()

    def handler11(*args, **kwargs):
        raise Exception

# Generated at 2022-06-17 14:44:51.504659
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(a, b, c):
        return a, b, c

    event = _EventSource()
    event += handler

    assert event.fire(1, 2, 3) == (1, 2, 3)

# Generated at 2022-06-17 14:44:57.837975
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest(object):
        def __init__(self):
            self.event = _EventSource()
            self.event += self.handler
            self.event += self.handler2
            self.handler_called = False
            self.handler2_called = False

        def handler(self, *args, **kwargs):
            self.handler_called = True

        def handler2(self, *args, **kwargs):
            self.handler2_called = True

    e = EventSourceTest()
    e.event.fire()
    assert e.handler_called
    assert e.handler2_called

# Generated at 2022-06-17 14:45:08.632489
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler_2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler_3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler_3')

    def handler_4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler_4')

    def handler_5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler_5')


# Generated at 2022-06-17 14:45:20.358418
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test that the event source fires all handlers
    event_source = _EventSource()
    event_source += lambda: None
    event_source += lambda: None
    event_source.fire()

    # test that the event source fires all handlers even if one raises an exception
    event_source = _EventSource()
    event_source += lambda: None
    event_source += lambda: None
    event_source += lambda: 1 / 0
    event_source.fire()

    # test that the event source does not fire handlers after one raises an exception
    event_source = _EventSource()
    event_source += lambda: None
    event_source += lambda: 1 / 0
    event_source += lambda: None
    try:
        event_source.fire()
    except ZeroDivisionError:
        pass
    else:
        raise Assertion

# Generated at 2022-06-17 14:45:30.265566
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(a, b):
        pass

    def handler2(a, b):
        pass

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:45:35.836575
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def handler1(a, b):
        assert a == 1
        assert b == 2

    def handler2(a, b):
        assert a == 1
        assert b == 2
        raise ValueError('test')

    def handler3(a, b):
        assert a == 1
        assert b == 2
        raise ValueError('test')

    event += handler1
    event += handler2
    event += handler3

    try:
        event.fire(1, 2)
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

# Generated at 2022-06-17 14:45:46.906459
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise ValueError('test')

    def _handler_3(*args, **kwargs):
        raise ValueError('test')

    def _handler_4(*args, **kwargs):
        raise ValueError('test')

    def _handler_5(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:45:48.907766
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:56.515416
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        handler1.args = (arg1, arg2)

    def handler2(arg1, arg2):
        handler2.args = (arg1, arg2)

    def handler3(arg1, arg2):
        handler3.args = (arg1, arg2)

    def handler4(arg1, arg2):
        handler4.args = (arg1, arg2)
        raise Exception('handler4 exception')

    def handler5(arg1, arg2):
        handler5.args = (arg1, arg2)
        raise Exception('handler5 exception')

    def handler6(arg1, arg2):
        handler6.args = (arg1, arg2)
        raise Exception('handler6 exception')


# Generated at 2022-06-17 14:45:59.389731
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:46:06.646653
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    def handler2():
        pass

    es += handler1
    assert len(es._handlers) == 1
    assert handler1 in es._handlers

    es += handler2
    assert len(es._handlers) == 2
    assert handler2 in es._handlers

    # handler1 is already in the set, so adding it again should have no effect
    es += handler1
    assert len(es._handlers) == 2
    assert handler1 in es._handlers

    # handler3 is not callable, so adding it should raise an exception
    def handler3():
        pass

    handler3.__call__ = None

# Generated at 2022-06-17 14:46:12.154352
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-17 14:46:16.611492
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:46:20.999891
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.fired = True
            return False

    event = _TestEventSource()
    event.fire()
    assert event.fired is True



# Generated at 2022-06-17 14:46:41.567094
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    def handler5(*args, **kwargs):
        raise ValueError('test')

    def handler6(*args, **kwargs):
        raise ValueError('test')

    def handler7(*args, **kwargs):
        raise ValueError('test')

    def handler8(*args, **kwargs):
        raise ValueError('test')

    def handler9(*args, **kwargs):
        raise ValueError('test')

    def handler10(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:46:49.134066
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        pass

    event_source += handler_1
    event_source += handler_2
    event_source.fire()

    event_source -= handler_1
    event_source.fire()

    def handler_3(*args, **kwargs):
        raise Exception('test exception')

    event_source += handler_3
    try:
        event_source.fire()
    except Exception:
        pass
    else:
        assert False, 'expected exception'

# Generated at 2022-06-17 14:46:51.899885
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:46:54.323782
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:47:05.173630
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    tes = _TestEventSource()

    def handler1(*args, **kwargs):
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        pass

    tes += handler1
    tes += handler2
    tes += handler3

    tes.fire()

    assert tes.exception_raised is True

# Generated at 2022-06-17 14:47:16.766969
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

        def handler3(self, *args, **kwargs):
            self.handler3_args = args
            self.handler3_kwargs = kwargs

    event_source_test = _EventSourceTest()
    event_source_

# Generated at 2022-06-17 14:47:22.183881
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler

    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:47:28.019468
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:47:34.039065
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self):
            super(EventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.fired = True
            return False

    event_source = EventSource()

    def handler():
        raise ValueError('test')

    event_source += handler
    event_source.fire()

    assert event_source.fired


# Generated at 2022-06-17 14:47:38.579856
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(a, b):
        pass

    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-17 14:47:54.507313
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:56.386797
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:58.775667
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:10.899843
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_calls.append((handler, exc, args, kwargs))
            return True

    def _handler1(*args, **kwargs):
        pass

    def _handler2(*args, **kwargs):
        raise ValueError('test')

    def _handler3(*args, **kwargs):
        raise RuntimeError('test')

    def _handler4(*args, **kwargs):
        raise ValueError('test')

    def _handler5(*args, **kwargs):
        raise RuntimeError('test')


# Generated at 2022-06-17 14:48:21.654847
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_impl

        def _on_exception_impl(self, handler, exc, *args, **kwargs):
            self.exception = exc
            return False

    def handler1(*args, **kwargs):
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')

    def handler5(*args, **kwargs):
        raise Exception('handler5')


# Generated at 2022-06-17 14:48:28.623302
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    assert handler1 in event_source._handlers

    event_source += handler2
    assert handler2 in event_source._handlers

    event_source += handler1
    assert handler1 in event_source._handlers

    event_source += handler2
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:48:38.023661
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(sender, *args, **kwargs):
        assert sender is event_source
        assert args == (1, 2)
        assert kwargs == {'a': 3, 'b': 4}
        handler1.called = True

    def handler2(sender, *args, **kwargs):
        assert sender is event_source
        assert args == (1, 2)
        assert kwargs == {'a': 3, 'b': 4}
        handler2.called = True

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    handler1.called = False
    handler2.called = False
    event_source.fire(1, 2, a=3, b=4)
    assert handler1.called
    assert handler2.called

# Unit

# Generated at 2022-06-17 14:48:48.908028
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    test = _EventSourceTest()
    test.event_source.fire(1, 2, 3, a=4, b=5, c=6)

    assert test.handler1_args == (1, 2, 3)

# Generated at 2022-06-17 14:48:58.678885
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')

    def handler5(*args, **kwargs):
        raise Exception('handler5')

    def handler6(*args, **kwargs):
        raise Exception('handler6')

    def handler7(*args, **kwargs):
        raise Exception('handler7')

    def handler8(*args, **kwargs):
        raise Exception('handler8')

    def handler9(*args, **kwargs):
        raise Exception('handler9')

    def handler10(*args, **kwargs):
        raise Exception('handler10')


# Generated at 2022-06-17 14:49:00.204794
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:49:19.316668
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:49:25.814095
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:49:35.479617
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test exception')

    def handler3(*args, **kwargs):
        pass

    event_source = TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

    assert event_source.exception_raised

# Generated at 2022-06-17 14:49:47.262803
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class TestException(Exception):
        pass

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise TestException()

    def handler_3(*args, **kwargs):
        pass

    event_source = TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3


# Generated at 2022-06-17 14:49:53.777456
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler1():
        pass

    event_source += handler1
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler1
    assert len(event_source._handlers) == 2



# Generated at 2022-06-17 14:50:04.963853
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    def handler1(*args, **kwargs):
        raise ValueError('handler1')

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    event_source = MyEventSource()
    event_source += handler1
    event_source += handler2

    try:
        event_source.fire()
    except ValueError:
        assert False, '_EventSource.fire() should not raise ValueError'


# Generated at 2022-06-17 14:50:07.578969
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    event_source = _EventSource()

    # Act
    event_source += lambda: None

    # Assert
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:18.504817
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    test_event_source = _TestEventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2 raised an exception')

    def handler_3(*args, **kwargs):
        pass

    test_event_source += handler_1
    test_event_source += handler_2
    test_event_source += handler_3

    test_event_source.fire()

    assert test_event_

# Generated at 2022-06-17 14:50:23.864007
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:50:28.010608
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:51:00.414625
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:09.921878
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append((handler, exc, args, kwargs))
            return False

    tes = TestEventSource()

    def handler1(*args, **kwargs):
        raise ValueError('handler1')

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    tes += handler1
    tes += handler2

    try:
        tes.fire(1, 2, 3)
    except ValueError:
        pass

    assert len(tes.events) == 2
    assert tes.events[0][0] == handler

# Generated at 2022-06-17 14:51:12.784390
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:23.550967
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.calls.append((handler, exc, args, kwargs))
            return False

    tes = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    def handler3(*args, **kwargs):
        raise ValueError('handler3')

    tes += handler1
    tes += handler2
    tes += handler3

    tes.fire(1, 2, 3)

    assert len(tes.calls) == 2

# Generated at 2022-06-17 14:51:26.314848
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:33.604522
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_raised = False
            self.exception_raised_by_handler = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            self.exception_raised_by_handler = handler
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test exception')

    def handler3(*args, **kwargs):
        pass

    event_source = TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()



# Generated at 2022-06-17 14:51:47.334715
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class MyEventSource(_EventSource):
        pass

    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    def handler3(arg1, arg2):
        pass

    def handler4(arg1, arg2):
        pass

    def handler5(arg1, arg2):
        pass

    def handler6(arg1, arg2):
        pass

    def handler7(arg1, arg2):
        pass

    def handler8(arg1, arg2):
        pass

    def handler9(arg1, arg2):
        pass

    def handler10(arg1, arg2):
        pass

    def handler11(arg1, arg2):
        pass

    def handler12(arg1, arg2):
        pass


# Generated at 2022-06-17 14:51:51.950700
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:52:02.067532
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler1.called = True

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler2.called = True

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler3.called = True
        raise ValueError('handler3')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler4.called = True
        raise ValueError('handler4')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'

# Generated at 2022-06-17 14:52:04.950354
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:52:45.135409
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    try:
        event_source.fire()
    except ValueError:
        pass

    assert event_

# Generated at 2022-06-17 14:52:50.075967
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create an instance of _EventSource
    event_source = _EventSource()

    # Create a handler function
    def handler(a, b):
        return a + b

    # Add the handler to the event source
    event_source += handler

    # Fire the event source
    result = event_source.fire(1, 2)

    # Assert that the handler was called
    assert result is None



# Generated at 2022-06-17 14:52:59.670928
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_handler_called = False
            self.exception_handler_args = None
            self.exception_handler_kwargs = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_handler_called = True
            self.exception_handler_args = args
            self.exception_handler_kwargs = kwargs
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    def handler3(*args, **kwargs):
        raise ValueError('handler3')


# Generated at 2022-06-17 14:53:05.564026
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

