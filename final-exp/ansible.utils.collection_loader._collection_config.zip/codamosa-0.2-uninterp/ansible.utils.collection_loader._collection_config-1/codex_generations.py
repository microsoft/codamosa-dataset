

# Generated at 2022-06-17 14:43:17.355223
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(a, b):
        assert a == 1
        assert b == 2

    def handler2(a, b):
        assert a == 1
        assert b == 2

    event_source += handler1
    event_source += handler2

    event_source.fire(1, 2)



# Generated at 2022-06-17 14:43:21.954127
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:43:25.201869
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:43:33.869050
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3

        def handler_1(self, *args, **kwargs):
            self.handler_1_args = args
            self.handler_1_kwargs = kwargs

        def handler_2(self, *args, **kwargs):
            self.handler_2_args = args
            self.handler_2_kwargs = kwargs

        def handler_3(self, *args, **kwargs):
            self.handler_3_args = args
            self.handler_3_kwargs = kwargs

    event_source_test

# Generated at 2022-06-17 14:43:43.832630
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def fire(self, *args, **kwargs):
            self.fired = True
            super(TestEventSource, self).fire(*args, **kwargs)

    def handler(*args, **kwargs):
        pass

    event_source = TestEventSource()
    event_source += handler
    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:43:53.501541
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 1
        assert arg2 == 2

    def handler2(arg1, arg2):
        assert arg1 == 1
        assert arg2 == 2

    def handler3(arg1, arg2):
        assert arg1 == 1
        assert arg2 == 2

    def handler4(arg1, arg2):
        assert arg1 == 1
        assert arg2 == 2

    def handler5(arg1, arg2):
        assert arg1 == 1
        assert arg2 == 2

    def handler6(arg1, arg2):
        assert arg1 == 1
        assert arg2 == 2

    def handler7(arg1, arg2):
        assert arg1 == 1
        assert arg2 == 2


# Generated at 2022-06-17 14:44:04.024878
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

        def handler3(self, *args, **kwargs):
            self.handler3_args = args
            self.handler3_kwargs = kwargs

    test = _EventSourceTest()

# Generated at 2022-06-17 14:44:15.163132
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test exception')

    def handler_3(*args, **kwargs):
        pass

    event_source = _TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()

    assert event_source._on_exception_called

# Generated at 2022-06-17 14:44:20.264228
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestClass:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler
            self.event_source += self.handler_exception
            self.event_source += self.handler_exception_reraise
            self.event_source += self.handler_exception_reraise_reraise
            self.event_source += self.handler_exception_reraise_reraise_reraise
            self.event_source += self.handler_exception_reraise_reraise_reraise_reraise
            self.event_source += self.handler_exception_reraise_reraise_reraise_reraise_reraise
            self.event_source += self.handler_exception_reraise_reraise_reraise_reraise_reraise_reraise


# Generated at 2022-06-17 14:44:28.178876
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    tes = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test exception')

    tes += handler1
    tes += handler2

    tes.fire()

    assert tes.exception_count == 1

# Generated at 2022-06-17 14:44:39.498669
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1



# Generated at 2022-06-17 14:44:42.638130
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:53.889755
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(x, y):
        return x + y

    def handler2(x, y):
        raise TestException()

    def handler3(x, y):
        return x - y

    def handler4(x, y):
        raise ValueError()

    def handler5(x, y):
        return x * y

    def handler6(x, y):
        raise TestException()

    def handler7(x, y):
        return x / y

    def handler8(x, y):
        raise ValueError()

    def handler9(x, y):
        return x % y

    def handler10(x, y):
        raise TestException()

    def handler11(x, y):
        return x ** y

    def handler12(x, y):
        raise

# Generated at 2022-06-17 14:45:06.342413
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    test_event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        pass

    test_event_source += handler1
    test_event_source += handler2
    test_event_source += handler3

    test_event_source.fire()

    assert test_event_source._on_exception

# Generated at 2022-06-17 14:45:08.766172
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(a, b, c):
        pass

    es = _EventSource()
    es += handler
    es.fire(1, 2, 3)

# Generated at 2022-06-17 14:45:20.448374
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    def handler_3(*args, **kwargs):
        raise ValueError('test')

    test_event_source = _TestEventSource()
    test_event_source += handler_1
    test_event_source += handler_2
    test_event_source += handler_3

    test_event_source.fire()

   

# Generated at 2022-06-17 14:45:28.704041
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler3(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire(1, 2, 3)



# Generated at 2022-06-17 14:45:34.195124
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self):
            self.events = []

        def handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    t = Test()
    s = _EventSource()
    s += t.handler

    s.fire(1, 2, 3, a=4, b=5, c=6)

    assert t.events == [((1, 2, 3), dict(a=4, b=5, c=6))]



# Generated at 2022-06-17 14:45:44.115098
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self):
            super(EventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = EventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:45:51.388628
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:46:03.240484
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    es = _TestEventSource()
    es += es.handler
    es.fire()
    assert es.fired

# Generated at 2022-06-17 14:46:06.498743
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:46:10.142887
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:46:19.530416
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    def handler5(*args, **kwargs):
        raise ValueError('test')

    def handler6(*args, **kwargs):
        raise ValueError('test')

    def handler7(*args, **kwargs):
        raise ValueError('test')

    def handler8(*args, **kwargs):
        raise ValueError('test')

    def handler9(*args, **kwargs):
        raise ValueError('test')

    def handler10(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:46:27.916566
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler in event_source._handlers
    assert handler2 in event_source._handlers

    event_source += handler2

# Generated at 2022-06-17 14:46:32.438352
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()

    assert event_source.fired

# Generated at 2022-06-17 14:46:36.722248
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def fire(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    assert not event_source.fired
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:46:41.304795
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0



# Generated at 2022-06-17 14:46:48.426970
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = lambda handler, exc, *args, **kwargs: False

    test_event_source = TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    test_event_source += handler1
    test_event_source += handler2

    test_event_source.fire()



# Generated at 2022-06-17 14:46:58.656216
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class TestException(Exception):
        pass

    def handler_1(*args, **kwargs):
        raise TestException()

    def handler_2(*args, **kwargs):
        raise TestException()

    def handler_3(*args, **kwargs):
        raise TestException()

    def handler_4(*args, **kwargs):
        raise TestException()

    def handler_5(*args, **kwargs):
        raise TestException()


# Generated at 2022-06-17 14:47:23.944450
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler3')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler4')

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3
    event_source += handler4


# Generated at 2022-06-17 14:47:34.177615
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    test_event_source = _TestEventSource()
    test_event_source.fire()
    assert not test_event_source.exception_raised

    def handler1():
        raise Exception('handler1 exception')

    def handler2():
        raise Exception('handler2 exception')

    test_event_source += handler1
    test_event_source += handler2
    test_event_source.fire()
    assert test_event_source.exception_raised

    test_event_source -= handler1

# Generated at 2022-06-17 14:47:46.713373
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    tes = _TestEventSource()
    tes.fire()
    assert not tes.exception_raised

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test exception')

    tes += handler1
    tes.fire()
    assert not tes.exception_raised

    tes += handler2
    tes.fire()
    assert tes.exception_raised

    tes -= handler2


# Generated at 2022-06-17 14:47:51.606010
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2



# Generated at 2022-06-17 14:47:56.631792
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    test_event_source = TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()
    assert test_event_source.fired

# Generated at 2022-06-17 14:48:08.217837
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1(a, b):
        pass

    es += handler1
    assert len(es._handlers) == 1

    def handler2(a, b):
        pass

    es += handler2
    assert len(es._handlers) == 2

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0

    try:
        es += None
        assert False, 'expected ValueError'
    except ValueError:
        pass

    try:
        es += 'not callable'
        assert False, 'expected ValueError'
    except ValueError:
        pass


# Unit

# Generated at 2022-06-17 14:48:20.215674
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception = exc
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        raise Exception('handler3 exception')

    event_source = TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

    assert event_source.event_fired
    assert isinstance(event_source.exception, Exception)

# Generated at 2022-06-17 14:48:26.825175
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    event_source += handler1
    event_source += handler2

    event_source.fire('arg1', 'arg2')



# Generated at 2022-06-17 14:48:34.460407
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg):
        assert arg == 'foo'

    def handler2(arg):
        assert arg == 'foo'

    def handler3(arg):
        assert arg == 'foo'
        raise Exception('test')

    def handler4(arg):
        assert arg == 'foo'
        raise Exception('test')

    def handler5(arg):
        assert arg == 'foo'
        raise Exception('test')

    def handler6(arg):
        assert arg == 'foo'
        raise Exception('test')

    def handler7(arg):
        assert arg == 'foo'
        raise Exception('test')

    def handler8(arg):
        assert arg == 'foo'
        raise Exception('test')

    def handler9(arg):
        assert arg == 'foo'
        raise Exception('test')


# Generated at 2022-06-17 14:48:38.075300
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:59.333168
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:49:09.790142
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.events = _EventSource()
            self.events += self.handler1
            self.events += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    test = EventSourceTest()
    test.events.fire(1, 2, 3, a=4, b=5, c=6)
    assert test.handler1_args == (1, 2, 3)
    assert test.handler1_kwargs == {'a': 4, 'b': 5, 'c': 6}

# Generated at 2022-06-17 14:49:19.656593
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.event_count += 1

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.event_count == 1
    tes -= tes.handler
    tes.fire()
    assert tes.event_count == 1

# Generated at 2022-06-17 14:49:25.350206
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:49:35.843912
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3')

    event_source = _TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3


# Generated at 2022-06-17 14:49:41.956385
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        pass

    event_source += handler_1
    event_source += handler_2

    event_source.fire()

# Generated at 2022-06-17 14:49:45.831908
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:49:56.354931
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(a, b, c):
        raise Exception('handler_1')

    def handler_2(a, b, c):
        raise Exception('handler_2')

    def handler_3(a, b, c):
        raise Exception('handler_3')

    def handler_4(a, b, c):
        raise Exception('handler_4')

    def handler_5(a, b, c):
        raise Exception('handler_5')


# Generated at 2022-06-17 14:50:04.299407
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:50:12.235162
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.fired.append(('exception', handler, exc, args, kwargs))
            return False

    e = TestEventSource()
    e += lambda: e.fired.append(('handler1',))
    e += lambda: e.fired.append(('handler2',))
    e += lambda: e.fired.append(('handler3',))
    e += lambda: e.fired.append(('handler4',))
    e += lambda: e.fired.append(('handler5',))
    e += lambda: e.fired.append(('handler6',))
   

# Generated at 2022-06-17 14:50:29.591003
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:38.092901
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler3')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler4')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler5')


# Generated at 2022-06-17 14:50:41.225068
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:50:48.357899
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.event_count += 1

    test_event_source = TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()
    assert test_event_source.event_count == 1

# Generated at 2022-06-17 14:50:53.607291
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    event_source = TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    try:
        event_source.fire()
    except ValueError:
        pass

    assert event_source._

# Generated at 2022-06-17 14:51:04.543356
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler3(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        raise Exception('test')

    def handler4(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        raise Exception('test')

    def handler5(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        raise Exception('test')

    def handler6(a, b, c):
        assert a == 1
        assert b == 2

# Generated at 2022-06-17 14:51:11.382508
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_handler

        def _on_exception_handler(self, handler, exc, *args, **kwargs):
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        raise Exception('test')

    def handler4(*args, **kwargs):
        raise Exception('test')

    def handler5(*args, **kwargs):
        raise Exception('test')

    def handler6(*args, **kwargs):
        raise Exception('test')


# Generated at 2022-06-17 14:51:15.935342
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    test_event_source = TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()
    assert test_event_source.fired

# Generated at 2022-06-17 14:51:26.316315
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    # test that a handler which raises an exception is not re-raised
    test_event_source = _TestEventSource()
    test_event_source += lambda: 1 / 0
    test_event_source.fire()
    assert not test_event_source._on_exception_called

    # test that a handler which raises an exception is re-raised
    test_event_source = _TestEventSource()
    test_event_source += lambda: 1 / 0

# Generated at 2022-06-17 14:51:30.512244
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    test_event_source = TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()

    assert test_event_source.fired

# Generated at 2022-06-17 14:52:07.038242
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test that adding a non-callable handler raises an exception
    event_source = _EventSource()
    try:
        event_source += 'not callable'
        assert False, 'Expected ValueError'
    except ValueError:
        pass

    # Test that adding a callable handler does not raise an exception
    event_source = _EventSource()
    try:
        event_source += lambda: None
    except ValueError:
        assert False, 'Unexpected ValueError'


# Generated at 2022-06-17 14:52:11.581794
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:52:15.625510
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-17 14:52:23.272253
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_handler_called = False

        def event_handler(self, *args, **kwargs):
            self.event_handler_called = True

    test_event_source = TestEventSource()
    test_event_source += test_event_source.event_handler
    test_event_source.fire()
    assert test_event_source.event_handler_called



# Generated at 2022-06-17 14:52:31.288258
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class _TestException(Exception):
        pass

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise _TestException()

    def _handler_3(*args, **kwargs):
        raise _TestException()

    def _handler_4(*args, **kwargs):
        raise _TestException()

    def _handler_5(*args, **kwargs):
        raise _TestException()


# Generated at 2022-06-17 14:52:38.589941
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:52:46.700718
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def fire(self, *args, **kwargs):
            self._fired = True
            super(_TestEventSource, self).fire(*args, **kwargs)

    def _handler(arg1, arg2, kwarg1=None, kwarg2=None):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        assert kwarg1 == 'kwarg1'
        assert kwarg2 == 'kwarg2'


# Generated at 2022-06-17 14:52:52.751136
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:52:57.140770
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event = _EventSource()
            self.handler_called = False

        def handler(self, *args, **kwargs):
            self.handler_called = True

    test = _EventSourceTest()
    test.event += test.handler
    test.event.fire()
    assert test.handler_called

# Generated at 2022-06-17 14:53:02.372032
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    try:
        event_source += 'not callable'
        assert False
    except ValueError:
        pass

    assert event_source._handlers == {handler}
