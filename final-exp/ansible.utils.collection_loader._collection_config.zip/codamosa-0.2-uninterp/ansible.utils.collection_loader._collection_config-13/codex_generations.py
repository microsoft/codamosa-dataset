

# Generated at 2022-06-17 14:43:22.659739
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_handler = None
            self._on_exception_ex = None
            self._on_exception_args = None
            self._on_exception_kwargs = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_handler = handler
            self._on_exception_ex = exc
            self._on_exception_args = args
            self._on_exception_kwargs = kwargs
            return False

    def _handler1(*args, **kwargs):
        pass

# Generated at 2022-06-17 14:43:28.799673
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:43:32.762614
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:43:41.354278
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            pass

    _EventSourceTest()

# Generated at 2022-06-17 14:43:46.483683
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    es = TestEventSource()
    es += es.handler
    es.fire()
    assert es.fired



# Generated at 2022-06-17 14:43:54.244681
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True

    event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    event_source += handler1
    event_source += handler2

    event_source.fire()

    assert event_source.exception_raised

# Generated at 2022-06-17 14:43:57.429271
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:04.930273
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(x):
        raise TestException('handler1')

    def handler2(x):
        raise TestException('handler2')

    def handler3(x):
        raise TestException('handler3')

    def handler4(x):
        raise TestException('handler4')

    def handler5(x):
        raise TestException('handler5')

    def handler6(x):
        raise TestException('handler6')

    def handler7(x):
        raise TestException('handler7')

    def handler8(x):
        raise TestException('handler8')

    def handler9(x):
        raise TestException('handler9')

    def handler10(x):
        raise TestException('handler10')

    def handler11(x):
        raise TestException('handler11')

   

# Generated at 2022-06-17 14:44:13.324460
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        handler1.called = True
        handler1.args = (a, b, c)

    def handler2(a, b, c):
        handler2.called = True
        handler2.args = (a, b, c)

    source = _EventSource()
    source += handler1
    source += handler2

    source.fire(1, 2, 3)

    assert handler1.called
    assert handler1.args == (1, 2, 3)
    assert handler2.called
    assert handler2.args == (1, 2, 3)



# Generated at 2022-06-17 14:44:19.391627
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:44:35.634275
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert not event_source._handlers

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_

# Generated at 2022-06-17 14:44:39.460209
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-17 14:44:42.044851
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:44:43.715529
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:44:46.764127
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:49.840989
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:44:52.408801
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:44:59.424094
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    assert event_source._handlers == {handler1}

    event_source += handler2
    assert event_source._handlers == {handler1, handler2}

    event_source += handler1
    assert event_source._handlers == {handler1, handler2}

    event_source += handler2
    assert event_source._handlers == {handler1, handler2}

    try:
        event_source += 'not callable'
        assert False, 'expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-17 14:45:09.139184
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:45:18.091606
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test that __iadd__ raises ValueError if handler is not callable
    event_source = _EventSource()
    try:
        event_source += 'not callable'
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test that __iadd__ does not raise ValueError if handler is callable
    event_source = _EventSource()
    try:
        event_source += lambda: None
    except ValueError:
        assert False, 'Unexpected ValueError'



# Generated at 2022-06-17 14:45:32.232704
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler(a, b):
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler

# Generated at 2022-06-17 14:45:43.536727
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2



# Generated at 2022-06-17 14:45:46.972952
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:45:55.191489
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise ValueError('test')

    def _handler_3(*args, **kwargs):
        pass

    event_source = _TestEventSource()
    event_source += _handler_1
    event_source += _handler_2
    event_source += _handler_3

    event_source.fire()

    assert event_source._on_exception

# Generated at 2022-06-17 14:46:00.485118
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler1(a, b):
        return a + b

    def handler2(a, b):
        return a - b

    es += handler1
    es += handler2

    assert es.fire(1, 2) == 3
    assert es.fire(1, 2) == -1



# Generated at 2022-06-17 14:46:06.689431
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:46:17.528109
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_calls.append((handler, exc, args, kwargs))
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise RuntimeError('handler2')

    def handler3(*args, **kwargs):
        raise RuntimeError('handler3')

    def handler4(*args, **kwargs):
        raise RuntimeError('handler4')

    def handler5(*args, **kwargs):
        raise RuntimeError('handler5')


# Generated at 2022-06-17 14:46:25.046466
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda: 1
    event_source += lambda: 2
    event_source += lambda: 3
    event_source += lambda: 4
    event_source += lambda: 5
    event_source += lambda: 6
    event_source += lambda: 7
    event_source += lambda: 8
    event_source += lambda: 9
    event_source += lambda: 10
    event_source += lambda: 11
    event_source += lambda: 12
    event_source += lambda: 13
    event_source += lambda: 14
    event_source += lambda: 15
    event_source += lambda: 16
    event_source += lambda: 17
    event_source += lambda: 18
    event_source += lambda: 19
    event_source += lambda: 20
    event_source += lambda: 21


# Generated at 2022-06-17 14:46:30.545428
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:46:35.015094
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event = TestEventSource()
    event += event.handler
    event.fire()
    assert event.fired



# Generated at 2022-06-17 14:46:48.845680
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1():
        pass

    def handler2():
        pass

    def handler3():
        pass

    event_source = _EventSource()

    event_source += handler1
    event_source += handler2
    event_source += handler3

    assert len(event_source._handlers) == 3
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers
    assert handler3 in event_source._handlers



# Generated at 2022-06-17 14:46:58.384233
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event = _EventSource()
            self.event += self.handler1
            self.event += self.handler2
            self.event += self.handler3

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            pass

        def handler3(self, *args, **kwargs):
            raise Exception('test exception')

    event_source_test = EventSourceTest()
    try:
        event_source_test.event.fire()
    except Exception as ex:
        assert ex.args[0] == 'test exception'
    else:
        assert False, 'expected exception'

# Generated at 2022-06-17 14:47:00.539870
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(event):
        pass

    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:47:12.807696
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler1(a, b):
        pass

    def handler2(a, b):
        pass

    event_source += handler1
    assert len(event_source._handlers) == 1
    assert handler1 in event_source._handlers

    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers

    event_source += handler1
    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-17 14:47:22.941248
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True

    s = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        raise Exception('test')

    s += handler1
    s += handler2
    s += handler3

    try:
        s.fire()
    except Exception:
        pass

    assert s._on_exception_called

# Generated at 2022-06-17 14:47:29.040428
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.fired = True
            return False

    event = _TestEventSource()
    event.fire()
    assert event.fired is True

# Generated at 2022-06-17 14:47:30.208513
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:32.405924
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:46.106154
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self._event_source = _EventSource()
            self._event_source += self._handler1
            self._event_source += self._handler2
            self._event_source += self._handler3

        def _handler1(self, *args, **kwargs):
            self._handler1_args = args
            self._handler1_kwargs = kwargs

        def _handler2(self, *args, **kwargs):
            self._handler2_args = args
            self._handler2_kwargs = kwargs

        def _handler3(self, *args, **kwargs):
            self._handler3_args = args
            self._handler3_kwargs = kwargs


# Generated at 2022-06-17 14:47:57.290917
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_handler

        def _on_exception_handler(self, handler, exc, *args, **kwargs):
            self._exception_handler_called = True
            self._exception_handler_args = (handler, exc, args, kwargs)
            return False

    test_event_source = TestEventSource()
    test_event_source.fire()

    assert not hasattr(test_event_source, '_exception_handler_called')

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('test exception')

    test_event_source

# Generated at 2022-06-17 14:48:15.584162
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:48:20.360236
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:48:26.467544
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:48:34.275721
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self._handler1
            self.event_source += self._handler2
            self.event_source += self._handler3
            self.event_source += self._handler4
            self.event_source += self._handler5
            self.event_source += self._handler6
            self.event_source += self._handler7
            self.event_source += self._handler8
            self.event_source += self._handler9
            self.event_source += self._handler10
            self.event_source += self._handler11
            self.event_source += self._handler12
            self.event_source += self._handler13
            self.event_source += self._handler14


# Generated at 2022-06-17 14:48:47.720861
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise TestException()

    def handler_3(*args, **kwargs):
        raise Exception()

    def handler_4(*args, **kwargs):
        raise TestException()

    def handler_5(*args, **kwargs):
        raise Exception()

    def handler_6(*args, **kwargs):
        raise TestException()

    def handler_7(*args, **kwargs):
        raise Exception()

    def handler_8(*args, **kwargs):
        raise TestException()

    def handler_9(*args, **kwargs):
        raise Exception()

    def handler_10(*args, **kwargs):
        raise TestException()


# Generated at 2022-06-17 14:48:58.511126
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return

    def handler3(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return

    def handler4(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return

    def handler5(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return

    def handler6(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return

   

# Generated at 2022-06-17 14:49:01.027264
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:49:10.329157
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestHandler:
        def __init__(self, name):
            self.name = name
            self.call_count = 0
            self.exception_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1
            if self.call_count == 2:
                raise TestException('test exception')

        def on_exception(self, exc, *args, **kwargs):
            self.exception_count += 1
            if self.exception_count == 2:
                return False

    event_source = _EventSource()
    handler1 = TestHandler('handler1')
    handler2 = TestHandler('handler2')
    event_source += handler1
    event_source += handler2

    event_source.fire()

# Generated at 2022-06-17 14:49:14.520662
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException()

    def handler3(*args, **kwargs):
        raise Exception()

    def handler4(*args, **kwargs):
        return True

    def handler5(*args, **kwargs):
        return False

    def handler6(*args, **kwargs):
        raise TestException()

    def handler7(*args, **kwargs):
        raise Exception()

    def handler8(*args, **kwargs):
        return True

    def handler9(*args, **kwargs):
        return False

    def handler10(*args, **kwargs):
        return False

    def handler11(*args, **kwargs):
        return True


# Generated at 2022-06-17 14:49:19.161681
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:49:47.562987
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b):
        assert a == 1
        assert b == 2

    def handler2(a, b):
        assert a == 1
        assert b == 2

    def handler3(a, b):
        assert a == 1
        assert b == 2
        raise RuntimeError('handler3')

    def handler4(a, b):
        assert a == 1
        assert b == 2
        raise RuntimeError('handler4')

    def handler5(a, b):
        assert a == 1
        assert b == 2
        raise RuntimeError('handler5')

    def handler6(a, b):
        assert a == 1
        assert b == 2
        raise RuntimeError('handler6')

    def handler7(a, b):
        assert a == 1
        assert b == 2
        raise RuntimeError('handler7')



# Generated at 2022-06-17 14:49:55.538607
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.event_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.event_fired = True

    test_event_source = _TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()
    assert test_event_source.event_fired



# Generated at 2022-06-17 14:49:59.031565
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler

    event_source.fire()

    assert event_source.fired

# Generated at 2022-06-17 14:50:09.859076
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception = self._on_exception_handler

        def _on_exception_handler(self, handler, exc, *args, **kwargs):
            self._exception_handler = handler
            self._exception = exc
            self._exception_args = args
            self._exception_kwargs = kwargs
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        raise Exception('test')

    test_event_source = _TestEventSource()
    test_event_source += handler1
    test_

# Generated at 2022-06-17 14:50:15.734923
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    test_event_source = TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()

    assert test_event_source.fired

# Generated at 2022-06-17 14:50:25.076056
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('handler2 exception')

    def handler3(*args, **kwargs):
        raise ValueError('handler3 exception')

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()


# Generated at 2022-06-17 14:50:31.886205
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class _TestException(Exception):
        pass

    class _TestHandler:
        def __init__(self, raise_exception):
            self._raise_exception = raise_exception

        def __call__(self, *args, **kwargs):
            if self._raise_exception:
                raise _TestException()

    test_event_source = _TestEventSource()

    test_event_source += _TestHandler(False)
    test_event_source += _Test

# Generated at 2022-06-17 14:50:45.348170
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

        def handler3(self, *args, **kwargs):
            self.handler3_args = args
            self.handler3_kwargs = kwargs

    event_source_test = _EventSourceTest()
    event_source_

# Generated at 2022-06-17 14:50:54.669868
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    assert handler1 in event_source._handlers

    event_source += handler2
    assert handler2 in event_source._handlers

    event_source += handler1
    assert handler1 in event_source._handlers

    event_source += handler2
    assert handler2 in event_source._handlers

    event_source += handler1
    assert handler1 in event_source._handlers

    event_source += handler2
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:51:05.462740
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_handler_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_handler_called = True
            return False

    es = _TestEventSource()
    es += lambda: None
    es += lambda: None
    es += lambda: None
    es.fire()
    assert len(es._handlers) == 3
    es -= lambda: None
    es.fire()
    assert len(es._handlers) == 2
    es -= lambda: None
    es -= lambda: None
    es.fire()
    assert len(es._handlers) == 0
    es += lambda: None

# Generated at 2022-06-17 14:51:49.188807
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException('test')

    def handler3(*args, **kwargs):
        raise Exception('test')

    def handler4(*args, **kwargs):
        raise TestException('test')

    def on_exception(handler, exc, *args, **kwargs):
        if isinstance(exc, TestException):
            return False

        return True

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3
    event_source += handler4
    event_source._on_exception = on_exception


# Generated at 2022-06-17 14:51:56.421852
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception = lambda handler, exc, *args, **kwargs: False

    event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    event_source += handler1
    event_source += handler2

    event_source.fire()

    event_source -= handler1

    event_source.fire()

# Generated at 2022-06-17 14:52:01.130987
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    event_source += handler1
    assert handler1 in event_source._handlers

    event_source += handler2
    assert handler2 in event_source._handlers

    event_source += handler1
    assert handler1 in event_source._handlers
    assert len(event_source._handlers) == 2



# Generated at 2022-06-17 14:52:04.177994
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 0



# Generated at 2022-06-17 14:52:10.641668
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.event_fired = True

    test_event_source = TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()
    assert test_event_source.event_fired

# Generated at 2022-06-17 14:52:18.247062
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_calls.append((handler, exc, args, kwargs))
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')

    def handler5(*args, **kwargs):
        raise Exception('handler5')


# Generated at 2022-06-17 14:52:21.329136
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:52:31.509829
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.handler_called = False
            self.handler_exception = None

        def handler(self, *args, **kwargs):
            self.handler_called = True

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.handler_exception = exc
            return False

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()

    assert tes.handler_called
    assert tes.handler_exception is None

    tes.handler_called = False
    tes.handler_exception = None

    def bad_handler(*args, **kwargs):
        raise ValueError('bad handler')

# Generated at 2022-06-17 14:52:43.205062
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        raise Exception('test')

    es = _TestEventSource()
    es += handler1
    es += handler2
    es += handler3

    try:
        es.fire()
    except Exception:
        assert False, '_EventSource.fire() should not raise an exception'


# Generated at 2022-06-17 14:52:52.977244
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exceptions.append((handler, exc, args, kwargs))
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        raise Exception('test2')

    tes = _TestEventSource()
    tes += handler1
    tes += handler2
    tes += handler3

    tes.fire(1, 2, 3)

    assert len(tes._exceptions) == 2