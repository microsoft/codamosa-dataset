

# Generated at 2022-06-17 14:43:12.508500
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:43:17.975600
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    es = TestEventSource()
    es += es.handler
    es.fire()
    assert es.fired

# Generated at 2022-06-17 14:43:25.424186
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')


# Generated at 2022-06-17 14:43:33.901014
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exceptions.append((handler, exc, args, kwargs))
            return False

    event_source = TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire('a', 'b', 'c', d='e')


# Generated at 2022-06-17 14:43:39.873116
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event = _EventSource()
            self.event += self.handler1
            self.event += self.handler2
            self.event += self.handler3

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            pass

        def handler3(self, *args, **kwargs):
            raise Exception('handler3')

    test = _EventSourceTest()
    try:
        test.event.fire()
    except Exception as ex:
        assert str(ex) == 'handler3'
    else:
        assert False, 'Exception not raised'

# Generated at 2022-06-17 14:43:44.354490
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not a callable'



# Generated at 2022-06-17 14:43:49.174772
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:43:54.467576
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:44:00.076067
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler_1(value):
        pass

    def handler_2(value):
        pass

    event_source += handler_1
    event_source += handler_2

    assert len(event_source._handlers) == 2
    assert handler_1 in event_source._handlers
    assert handler_2 in event_source._handlers



# Generated at 2022-06-17 14:44:02.658669
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:08.803240
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:14.881932
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:44:21.433221
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append(('exception', handler, exc, args, kwargs))
            return False

    def handler_1(*args, **kwargs):
        events.append(('handler_1', args, kwargs))

    def handler_2(*args, **kwargs):
        events.append(('handler_2', args, kwargs))
        raise Exception('handler_2 exception')

    def handler_3(*args, **kwargs):
        events.append(('handler_3', args, kwargs))
        raise Exception('handler_3 exception')



# Generated at 2022-06-17 14:44:26.592335
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:44:30.993369
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:39.274285
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    es = TestEventSource()
    es += es.handler
    es.fire()
    assert es.fired



# Generated at 2022-06-17 14:44:42.004623
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:44:49.935700
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # test that we can add a handler
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers

    # test that we can add a handler multiple times
    event_source += handler
    assert handler in event_source._handlers

    # test that we can add multiple handlers
    handler2 = lambda: None
    event_source += handler2
    assert handler2 in event_source._handlers

    # test that we can add a handler with a different signature
    handler3 = lambda x: None
    event_source += handler3
    assert handler3 in event_source._handlers

    # test that we can add a handler with a different signature
    handler4 = lambda x, y: None
    event_source += handler4
    assert handler4 in event_source._hand

# Generated at 2022-06-17 14:44:53.573159
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(a, b):
        assert a == 1
        assert b == 2
        return a + b

    es = _EventSource()
    es += handler

    assert es.fire(1, 2) == 3



# Generated at 2022-06-17 14:44:56.068804
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:08.406378
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    event_source = _EventSource()
    event_source += handler
    event_source.fire(1, 2, c=3)

# Generated at 2022-06-17 14:45:19.876062
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:45:29.875848
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        raise Exception('handler3 exception')

    def handler4(*args, **kwargs):
        raise Exception('handler4 exception')


# Generated at 2022-06-17 14:45:35.561389
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es += handler2
    assert len(es._handlers) == 2

    es += handler2
    assert len(es._handlers) == 2



# Generated at 2022-06-17 14:45:43.828802
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:45:52.524251
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('test')

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire('arg1', 'arg2')

    event_source -= handler3
    event_source.fire('arg1', 'arg2')



# Generated at 2022-06-17 14:45:58.926737
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        raise Exception('test')

    def handler4(*args, **kwargs):
        raise Exception('test')

    def handler5(*args, **kwargs):
        raise Exception('test')

    def handler6(*args, **kwargs):
        raise Exception('test')

    def handler7(*args, **kwargs):
        raise Exception('test')

    def handler8(*args, **kwargs):
        raise Exception('test')

    def handler9(*args, **kwargs):
        raise Exception('test')

    def handler10(*args, **kwargs):
        raise Exception('test')


# Generated at 2022-06-17 14:46:00.685305
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:46:12.603593
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False
            self.args = None
            self.kwargs = None

        def handler(self, *args, **kwargs):
            self.fired = True
            self.args = args
            self.kwargs = kwargs

    event_source = TestEventSource()
    event_source += event_source.handler

    event_source.fire(1, 2, 3, a=4, b=5)

    assert event_source.fired
    assert event_source.args == (1, 2, 3)
    assert event_source.kwargs == dict(a=4, b=5)



# Generated at 2022-06-17 14:46:19.685432
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3

        def handler_1(self, *args, **kwargs):
            pass

        def handler_2(self, *args, **kwargs):
            raise ValueError('test exception')

        def handler_3(self, *args, **kwargs):
            pass

    event_source_test = EventSourceTest()
    event_source_test.event_source.fire()

# Generated at 2022-06-17 14:46:37.227531
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:46:44.056795
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

        def handler3(self, *args, **kwargs):
            self.handler3_args = args
            self.handler3_kwargs = kwargs

    test = EventSourceTest()

# Generated at 2022-06-17 14:46:45.341922
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:46:55.140762
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        raise Exception('handler3 exception')

    def handler4(*args, **kwargs):
        raise Exception('handler4 exception')

    def handler5(*args, **kwargs):
        raise Exception('handler5 exception')

    event_source = _TestEventSource()

# Generated at 2022-06-17 14:47:00.982543
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:47:13.289923
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(arg):
        raise TestException('handler1')

    def handler2(arg):
        raise TestException('handler2')

    def handler3(arg):
        raise TestException('handler3')

    def handler4(arg):
        raise TestException('handler4')

    def handler5(arg):
        raise TestException('handler5')

    def handler6(arg):
        raise TestException('handler6')

    def handler7(arg):
        raise TestException('handler7')

    def handler8(arg):
        raise TestException('handler8')

    def handler9(arg):
        raise TestException('handler9')

    def handler10(arg):
        raise TestException('handler10')

    def handler11(arg):
        raise TestException('handler11')

   

# Generated at 2022-06-17 14:47:23.632371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_one(*args, **kwargs):
        pass

    def handler_two(*args, **kwargs):
        raise ValueError('test')

    def handler_three(*args, **kwargs):
        raise ValueError('test')

    event_source = _TestEventSource()
    event_source += handler_one
    event_source += handler_two
    event_source += handler_three

    event_source.fire()

    assert event_source._on_exception_

# Generated at 2022-06-17 14:47:29.724977
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:47:37.153771
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    def handler2():
        pass

    es += handler1
    assert len(es._handlers) == 1
    assert handler1 in es._handlers

    es += handler2
    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._handlers

    es += handler1
    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._handlers

    try:
        es += 'not callable'
        assert False, 'expected ValueError'
    except ValueError:
        pass

    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler

# Generated at 2022-06-17 14:47:46.281533
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestClass:
        def __init__(self):
            self.events = []

        def handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    test_obj = TestClass()
    event_source = _EventSource()
    event_source += test_obj.handler
    event_source.fire('a', 'b', 'c', d='e', f='g')
    assert test_obj.events == [((('a', 'b', 'c'),), {'d': 'e', 'f': 'g'})]



# Generated at 2022-06-17 14:48:07.121854
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-17 14:48:09.574232
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:20.878086
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

# Generated at 2022-06-17 14:48:24.124409
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    es += lambda: None
    es += lambda: None
    assert len(es._handlers) == 3


# Generated at 2022-06-17 14:48:32.843346
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class _TestEventHandler:
        def __init__(self):
            self._called = False

        def __call__(self, *args, **kwargs):
            self._called = True

    event_source = _TestEventSource()

    handler1 = _TestEventHandler()
    handler2 = _TestEventHandler()
    handler3 = _TestEventHandler()

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_

# Generated at 2022-06-17 14:48:38.076055
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1
    es += lambda: None
    assert len(es._handlers) == 2


# Generated at 2022-06-17 14:48:44.320818
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3
            self.event_source += self.handler_4
            self.event_source += self.handler_5
            self.event_source += self.handler_6
            self.event_source += self.handler_7
            self.event_source += self.handler_8
            self.event_source += self.handler_9
            self.event_source += self.handler_10
            self.event_source += self.handler_11
            self.event_source += self.handler_12
            self.event_source += self.handler_13

# Generated at 2022-06-17 14:48:49.339588
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_test

        def _on_exception_test(self, handler, exc, *args, **kwargs):
            self.exception = exc
            return False

    def handler_1(arg1, arg2):
        handler_1.args = (arg1, arg2)

    def handler_2(arg1, arg2):
        handler_2.args = (arg1, arg2)
        raise Exception('handler_2 exception')

    def handler_3(arg1, arg2):
        handler_3.args = (arg1, arg2)

    event_source = TestEventSource()
    event_source += handler_1


# Generated at 2022-06-17 14:48:55.972030
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes += tes.handler
    tes.fire()

    assert tes.fired

# Generated at 2022-06-17 14:49:05.006776
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    es = TestEventSource()
    es += lambda: None
    es.fire()

    es = TestEventSource()
    es += lambda: 1 / 0
    es.fire()

    es = TestEventSource()
    es += lambda: 1 / 0
    es += lambda: 1 / 0
    es.fire()

    es = TestEventSource()
    es += lambda: 1 / 0
    es += lambda: 1 / 0
    es += lambda: 1 / 0
    es.fire()

    es = TestEventSource()
    es += lambda: 1 / 0
    es += lambda: 1 / 0
    es += lambda: 1 / 0
    es += lambda: 1 / 0
    es

# Generated at 2022-06-17 14:49:44.961477
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self):
            self.events = []

        def handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    test = Test()
    event = _EventSource()
    event += test.handler
    event.fire(1, 2, 3, a=4, b=5, c=6)
    assert test.events == [((1, 2, 3), dict(a=4, b=5, c=6))]



# Generated at 2022-06-17 14:49:54.781371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b):
        assert a == 1
        assert b == 2
        return 'handler1'

    def handler2(a, b):
        assert a == 1
        assert b == 2
        return 'handler2'

    def handler3(a, b):
        assert a == 1
        assert b == 2
        return 'handler3'

    def handler4(a, b):
        assert a == 1
        assert b == 2
        return 'handler4'

    def handler5(a, b):
        assert a == 1
        assert b == 2
        return 'handler5'

    def handler6(a, b):
        assert a == 1
        assert b == 2
        return 'handler6'

    def handler7(a, b):
        assert a == 1
        assert b == 2

# Generated at 2022-06-17 14:49:57.831740
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:50:07.810131
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    tes = _TestEventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    tes += handler_1
    tes += handler_2

    tes.fire()

    assert tes._on_exception_called



# Generated at 2022-06-17 14:50:18.585396
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(arg):
        raise TestException('handler1')

    def handler2(arg):
        raise TestException('handler2')

    def handler3(arg):
        raise TestException('handler3')

    def handler4(arg):
        raise TestException('handler4')

    def handler5(arg):
        raise TestException('handler5')

    def handler6(arg):
        raise TestException('handler6')

    def handler7(arg):
        raise TestException('handler7')

    def handler8(arg):
        raise TestException('handler8')

    def handler9(arg):
        raise TestException('handler9')

    def handler10(arg):
        raise TestException('handler10')

    def handler11(arg):
        raise TestException('handler11')

   

# Generated at 2022-06-17 14:50:22.433828
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    test = TestEventSource()
    test += test.handler
    test.fire()
    assert test.fired

# Generated at 2022-06-17 14:50:31.798172
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        raise Exception('test')

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    try:
        event_source.fire()
    except Exception:
        pass

    assert event_source._on

# Generated at 2022-06-17 14:50:35.701884
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:44.009704
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest(_EventSource):
        def __init__(self):
            super(EventSourceTest, self).__init__()
            self.event_fired = False

        def handler(self, *args, **kwargs):
            self.event_fired = True

    event_source = EventSourceTest()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.event_fired

# Generated at 2022-06-17 14:50:47.510534
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    t = TestEventSource()
    t += t.handler
    t.fire()
    assert t.fired

# Generated at 2022-06-17 14:51:28.712307
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:51:32.415497
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    es = TestEventSource()
    es += es.handler
    es.fire()
    assert es.fired

# Generated at 2022-06-17 14:51:46.751307
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception = self._on_exception_handler

        def _on_exception_handler(self, handler, exc, *args, **kwargs):
            self._exception = exc
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test exception')

    def handler_3(*args, **kwargs):
        pass

    event_source = _TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()


# Generated at 2022-06-17 14:51:53.484019
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def handler(self, *args, **kwargs):
            self.event_fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.event_fired

# Generated at 2022-06-17 14:51:59.312677
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:52:05.612521
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b):
        assert a == 1
        assert b == 2

    def handler2(a, b):
        assert a == 1
        assert b == 2

    def handler3(a, b):
        assert a == 1
        assert b == 2
        raise ValueError('test')

    def handler4(a, b):
        assert a == 1
        assert b == 2
        raise ValueError('test')

    def handler5(a, b):
        assert a == 1
        assert b == 2
        raise ValueError('test')

    def handler6(a, b):
        assert a == 1
        assert b == 2
        raise ValueError('test')

    def handler7(a, b):
        assert a == 1
        assert b == 2
        raise ValueError('test')


# Generated at 2022-06-17 14:52:11.700555
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:52:23.048943
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.events = _EventSource()
            self.events += self._handler
            self.events += self._handler2
            self.events += self._handler3
            self.events += self._handler4
            self.events += self._handler5
            self.events += self._handler6
            self.events += self._handler7
            self.events += self._handler8
            self.events += self._handler9
            self.events += self._handler10
            self.events += self._handler11
            self.events += self._handler12
            self.events += self._handler13
            self.events += self._handler14
            self.events += self._handler15
            self.events += self._handler16
            self.events += self._handler17
           

# Generated at 2022-06-17 14:52:31.140143
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

   

# Generated at 2022-06-17 14:52:33.913047
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def handler():
        pass

    event += handler
    assert handler in event._handlers

