

# Generated at 2022-06-17 14:43:10.910999
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:43:14.202187
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:43:16.984742
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:43:24.661657
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            if isinstance(exc, TestException):
                return False
            return True

    def handler1(*args, **kwargs):
        raise TestException()

    def handler2(*args, **kwargs):
        raise Exception()

    def handler3(*args, **kwargs):
        pass

    def handler4(*args, **kwargs):
        raise TestException()

    def handler5(*args, **kwargs):
        raise Exception()

    def handler6(*args, **kwargs):
        pass

    def handler7(*args, **kwargs):
        raise TestException()

    def handler8(*args, **kwargs):
        raise Exception()


# Generated at 2022-06-17 14:43:29.580124
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    es = MyEventSource()
    es += es.handler
    es.fire()
    assert es.fired

# Generated at 2022-06-17 14:43:35.302272
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes

    # Test that __iadd__ raises ValueError when handler is not callable
    event_source = _EventSource()
    with pytest.raises(ValueError) as excinfo:
        event_source += 'not callable'
    assert 'handler must be callable' in to_bytes(excinfo.value)

    # Test that __iadd__ does not raise ValueError when handler is callable
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:43:40.474660
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    event_source = _EventSource()
    handler = lambda: None

    # Act
    event_source += handler

    # Assert
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:43:46.316281
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler1.called = True

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler2.called = True

    handler1.called = False
    handler2.called = False

    event = _EventSource()
    event += handler1
    event += handler2

    event.fire(1, 2, 3)

    assert handler1.called
    assert handler2.called

# Generated at 2022-06-17 14:43:55.498315
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return False

        def fire(self, *args, **kwargs):
            self.fired = True
            super(_TestEventSource, self).fire(*args, **kwargs)

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        pass

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2

# Generated at 2022-06-17 14:44:04.244059
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestHandler:
        def __init__(self, name):
            self.name = name
            self.call_count = 0
            self.exception_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1
            if self.call_count == 2:
                raise TestException('test exception')

        def on_exception(self, exc):
            self.exception_count += 1
            if self.exception_count == 2:
                return False

    event_source = _EventSource()
    handler1 = TestHandler('handler1')
    handler2 = TestHandler('handler2')
    event_source += handler1
    event_source += handler2

    event_source.fire()
    assert handler1.call

# Generated at 2022-06-17 14:44:14.552733
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return True

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return True

    def handler3(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return True

    def handler4(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return True

    def handler5(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return True

    def handler6(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

# Generated at 2022-06-17 14:44:18.362131
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:44:24.993237
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:44:33.879030
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2



# Generated at 2022-06-17 14:44:45.054630
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.events = _EventSource()
            self.events += self.handler1
            self.events += self.handler2
            self.events += self.handler3

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

        def handler3(self, *args, **kwargs):
            self.handler3_args = args
            self.handler3_kwargs = kwargs

    test = _EventSourceTest()
    test.events.fire('arg1', arg2='kwarg2')

# Generated at 2022-06-17 14:44:47.377027
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:53.815450
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:45:06.341421
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class _TestException(Exception):
        pass

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise _TestException()

    def _handler_3(*args, **kwargs):
        raise _TestException()

    event_source = _TestEventSource()
    event_source += _handler_1
    event_source += _handler_2
    event_source += _handler_3


# Generated at 2022-06-17 14:45:13.798183
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_handler = None
            self._on_exception_exception = None
            self._on_exception_args = None
            self._on_exception_kwargs = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_handler = handler
            self._on_exception_exception = exc
            self._on_exception_args = args
            self._on_exception_kwargs = kwargs
            return False


# Generated at 2022-06-17 14:45:18.793090
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)
            return False

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise ValueError('test')

    def _handler_3(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:45:30.459226
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()

    assert event_source.fired

# Generated at 2022-06-17 14:45:37.350497
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')

    def handler5(*args, **kwargs):
        raise Exception('handler5')

    def handler6(*args, **kwargs):
        raise Exception

# Generated at 2022-06-17 14:45:47.332775
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(arg1, arg2):
        raise Exception('handler1')

    def handler2(arg1, arg2):
        raise Exception('handler2')

    def handler3(arg1, arg2):
        raise Exception('handler3')

    def handler4(arg1, arg2):
        raise Exception('handler4')

    def handler5(arg1, arg2):
        raise Exception('handler5')

    def handler6(arg1, arg2):
        raise Exception

# Generated at 2022-06-17 14:45:52.125508
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:45:59.925465
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:46:12.094783
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b):
        assert a == 1
        assert b == 2
        return

    def handler2(a, b):
        assert a == 1
        assert b == 2
        return

    def handler3(a, b):
        assert a == 1
        assert b == 2
        raise Exception('test')

    def handler4(a, b):
        assert a == 1
        assert b == 2
        raise Exception('test')

    def handler5(a, b):
        assert a == 1
        assert b == 2
        raise Exception('test')

    def handler6(a, b):
        assert a == 1
        assert b == 2
        raise Exception('test')

    def handler7(a, b):
        assert a == 1
        assert b == 2
        raise Exception('test')


# Generated at 2022-06-17 14:46:17.959808
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # test that adding a non-callable handler raises a ValueError
    event_source = _EventSource()
    try:
        event_source += 'not callable'
    except ValueError as ex:
        assert str(ex) == 'handler must be callable'
    else:
        assert False, 'expected ValueError'

    # test that adding a callable handler succeeds
    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}



# Generated at 2022-06-17 14:46:22.037275
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:46:24.602993
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(x):
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:46:33.428694
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        handler1.called = True
        handler1.args = (arg1, arg2)

    def handler2(arg1, arg2):
        handler2.called = True
        handler2.args = (arg1, arg2)

    handler1.called = False
    handler2.called = False

    event = _EventSource()
    event += handler1
    event += handler2

    event.fire('arg1', 'arg2')

    assert handler1.called
    assert handler1.args == ('arg1', 'arg2')

    assert handler2.called
    assert handler2.args == ('arg1', 'arg2')



# Generated at 2022-06-17 14:46:52.806775
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:46:59.536500
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:47:06.834593
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire('arg1', 'arg2')



# Generated at 2022-06-17 14:47:16.659776
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test exception')

    event_source += handler1
    event_source += handler2

    event_source.fire()

    assert event_source._on_exception_called

# Generated at 2022-06-17 14:47:19.712384
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes

    def handler(a, b):
        pass

    event_source = _EventSource()
    event_source += handler

    assert handler in event_source._handlers

    with pytest.raises(ValueError):
        event_source += to_bytes('not callable')



# Generated at 2022-06-17 14:47:31.995631
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler3')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler4')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler5')


# Generated at 2022-06-17 14:47:46.052112
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_return_value = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_return_value = super(_TestEventSource, self)._on_exception(handler, exc, *args, **kwargs)
            return self._on_exception_return_value

    def _handler_1(arg1, arg2):
        pass

    def _handler_2(arg1, arg2):
        raise ValueError('test exception')


# Generated at 2022-06-17 14:47:49.546006
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:47:58.718201
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')

    def handler5(*args, **kwargs):
        raise Exception('handler5')

    def handler6(*args, **kwargs):
        raise Exception('handler6')

    def handler7(*args, **kwargs):
        raise Exception('handler7')

    def handler8(*args, **kwargs):
        raise Exception('handler8')

    def handler9(*args, **kwargs):
        raise Exception('handler9')

    def handler10(*args, **kwargs):
        raise Exception('handler10')

# Generated at 2022-06-17 14:48:10.423498
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    tes = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    tes += handler1
    tes += handler2
    tes += handler3

    tes.fire()

    assert tes.exception_count == 2

# Generated at 2022-06-17 14:48:33.313705
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append(('exception', handler, exc, args, kwargs))
            return True

    tes = TestEventSource()
    tes += lambda *args, **kwargs: tes.events.append(('handler1', args, kwargs))
    tes += lambda *args, **kwargs: tes.events.append(('handler2', args, kwargs))
    tes += lambda *args, **kwargs: tes.events.append(('handler3', args, kwargs))

# Generated at 2022-06-17 14:48:43.421074
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg):
        assert arg == 'arg'
        handler1.called = True

    def handler2(arg):
        assert arg == 'arg'
        handler2.called = True

    handler1.called = False
    handler2.called = False

    es = _EventSource()
    es += handler1
    es += handler2

    es.fire('arg')

    assert handler1.called
    assert handler2.called



# Generated at 2022-06-17 14:48:50.516068
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    def handler2():
        pass

    es += handler1
    assert len(es._handlers) == 1
    assert handler1 in es._handlers

    es += handler2
    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._handlers

    es += handler1
    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._handlers

    try:
        es += 'not callable'
        assert False, 'expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-17 14:48:57.991781
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler

        def handler(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    test = _EventSourceTest()
    test.event_source.fire(1, 2, 3, a=4, b=5, c=6)
    assert test.args == (1, 2, 3)
    assert test.kwargs == {'a': 4, 'b': 5, 'c': 6}

# Generated at 2022-06-17 14:49:04.237355
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:49:08.416320
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:49:11.627723
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:49:16.697909
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def fire(self, *args, **kwargs):
            self.fired = True

    e = TestEventSource()
    e.fire()
    assert e.fired

# Generated at 2022-06-17 14:49:24.757306
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3
            self.event_source += self.handler_4
            self.event_source += self.handler_5
            self.event_source += self.handler_6
            self.event_source += self.handler_7
            self.event_source += self.handler_8
            self.event_source += self.handler_9
            self.event_source += self.handler_10
            self.event_source += self.handler_11
            self.event_source += self.handler_12
            self.event_source += self.handler_13

# Generated at 2022-06-17 14:49:27.077753
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:49:46.127486
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:49:48.994708
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:49:51.698102
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:49:59.784287
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:50:10.288633
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # test that adding a non-callable handler raises a ValueError
    es = _EventSource()
    try:
        es += 'not callable'
    except ValueError:
        pass
    else:
        raise AssertionError('expected ValueError')

    # test that adding a callable handler does not raise an exception
    es = _EventSource()
    try:
        es += lambda: None
    except ValueError:
        raise AssertionError('unexpected ValueError')

    # test that adding a callable handler does not raise an exception
    es = _EventSource()
    try:
        es += lambda: None
    except ValueError:
        raise AssertionError('unexpected ValueError')

    # test that adding the same callable handler twice does not raise an exception
    es = _EventSource()
    handler = lambda: None

# Generated at 2022-06-17 14:50:13.165913
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:14.670248
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:22.213954
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            raise ValueError('test')

        def handler3(self, *args, **kwargs):
            pass

    event_source_test = _EventSourceTest()
    event_source_test.event_source.fire()

# Generated at 2022-06-17 14:50:25.401832
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:32.795463
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_test

        def _on_exception_test(self, handler, exc, *args, **kwargs):
            self._exception = exc
            return True

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3')

    test_event_source = TestEventSource()
    test_event_source += handler_1
    test_event_source += handler_2
    test_event_source += handler_3


# Generated at 2022-06-17 14:50:56.973935
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException()

    def handler3(*args, **kwargs):
        raise Exception()

    def handler4(*args, **kwargs):
        raise TestException()

    def handler5(*args, **kwargs):
        raise Exception()

    def handler6(*args, **kwargs):
        raise TestException()

    def handler7(*args, **kwargs):
        raise Exception()

    def handler8(*args, **kwargs):
        raise TestException()

    def handler9(*args, **kwargs):
        raise Exception()

    def handler10(*args, **kwargs):
        raise TestException()

    def handler11(*args, **kwargs):
        raise Exception

# Generated at 2022-06-17 14:50:59.859571
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:51:01.825236
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:10.945136
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise ValueError('test')

    def _handler_3(*args, **kwargs):
        pass

    def _handler_4(*args, **kwargs):
        raise ValueError('test')

    def _handler_5(*args, **kwargs):
        pass


# Generated at 2022-06-17 14:51:19.118141
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that the event source calls all handlers
    def handler1(arg):
        handler1.called = True
        handler1.arg = arg

    def handler2(arg):
        handler2.called = True
        handler2.arg = arg

    handler1.called = False
    handler2.called = False

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire('test')

    assert handler1.called
    assert handler1.arg == 'test'
    assert handler2.called
    assert handler2.arg == 'test'

    # Test that the event source does not call handlers that have been removed
    handler1.called = False
    handler2.called = False

    event_source -= handler1

    event_source.fire('test')


# Generated at 2022-06-17 14:51:28.150532
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler_1.called = True

    def handler_2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler_2.called = True

    def handler_3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler_3.called = True
        raise Exception('test')

    def handler_4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler_4.called = True
        raise Exception('test')

    def handler_5(arg1, arg2):
        assert arg1

# Generated at 2022-06-17 14:51:38.222951
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    # test that handlers are called
    tes = _TestEventSource()
    tes += lambda: None
    tes.fire()

    # test that exceptions are handled
    tes = _TestEventSource()
    tes += lambda: 1 / 0
    tes.fire()
    assert tes.exception_raised

    # test that exceptions are re-raised
    tes = _TestEventSource()
    tes += lambda: 1 / 0

# Generated at 2022-06-17 14:51:48.755894
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self._on_exception = self._on_exception_handler

        def _on_exception_handler(self, handler, exc, *args, **kwargs):
            self._exception_handler_called = True
            self._exception_handler_exception = exc
            self._exception_handler_args = args
            self._exception_handler_kwargs = kwargs
            return False

    def handler1(arg1, arg2, kwarg1=None, kwarg2=None):
        handler1_called.append(True)
        handler1_args.append((arg1, arg2))

# Generated at 2022-06-17 14:51:56.340226
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    try:
        event_source.fire()
    except ValueError:
        pass

    assert event_

# Generated at 2022-06-17 14:52:03.537278
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler3(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler4(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler5(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler6(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler7(a, b, c):
        assert a == 1
       

# Generated at 2022-06-17 14:52:28.011869
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler_2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler_3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler_4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler_4')

    def handler_5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler_5')


# Generated at 2022-06-17 14:52:37.901198
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    def handler_3(*args, **kwargs):
        raise ValueError('test')

    es = _TestEventSource()
    es += handler_1
    es += handler_2
    es += handler_3

    try:
        es.fire()
        assert False, 'expected exception'
    except ValueError:
        pass

# Generated at 2022-06-17 14:52:40.289410
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(arg):
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:52:47.644150
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler(x):
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    def handler2(x):
        pass

    es += handler2
    assert len(es._handlers) == 1

    es += handler

# Generated at 2022-06-17 14:52:53.223952
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:53:02.040719
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    test_event_source = _TestEventSource()
    test_event_source += handler1
    test_event_source += handler2

# Generated at 2022-06-17 14:53:12.559538
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_handler = None
            self._on_exception_exception = None
            self._on_exception_args = None
            self._on_exception_kwargs = None
            self._on_exception_return_value = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_handler = handler
            self._on_exception_exception = exc
            self._on_exception_args = args
            self._on_exception_kwargs = kwargs
            return self