

# Generated at 2022-06-17 14:43:12.233974
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:43:22.660215
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exception_count += 1
            return False

    def handler1(*args, **kwargs):
        raise ValueError('handler1')

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    def handler3(*args, **kwargs):
        raise ValueError('handler3')

    def handler4(*args, **kwargs):
        raise ValueError('handler4')

    def handler5(*args, **kwargs):
        raise ValueError('handler5')

    def handler6(*args, **kwargs):
        raise

# Generated at 2022-06-17 14:43:26.589444
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:43:30.624918
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def fire(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:43:34.673144
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler

    assert not event_source.fired
    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:43:45.214941
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    es += handler1
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0

    try:
        es += None
        assert False
    except ValueError:
        pass

    try:
        es += 'not callable'
        assert False
    except ValueError:
        pass



# Generated at 2022-06-17 14:43:52.828769
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test that the method __iadd__ of class _EventSource raises ValueError if the handler is not callable
    event_source = _EventSource()
    try:
        event_source += None
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # Test that the method __iadd__ of class _EventSource does not raise ValueError if the handler is callable
    event_source = _EventSource()
    try:
        event_source += lambda: None
    except ValueError:
        raise AssertionError('ValueError raised')



# Generated at 2022-06-17 14:44:03.968162
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_handler = None
            self._on_exception_exception = None
            self._on_exception_args = None
            self._on_exception_kwargs = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_handler = handler
            self._on_exception_exception = exc
            self._on_exception_args = args
            self._on_exception_kwargs = kwargs
            return False


# Generated at 2022-06-17 14:44:12.286711
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:44:22.639345
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception = self._on_exception_test

        def _on_exception_test(self, handler, exc, *args, **kwargs):
            self._on_exception_test_called = True
            self._on_exception_test_handler = handler
            self._on_exception_test_exc = exc
            self._on_exception_test_args = args
            self._on_exception_test_kwargs = kwargs
            return False

    def _handler1(*args, **kwargs):
        pass

    def _handler2(*args, **kwargs):
        raise Exception('test exception')


# Generated at 2022-06-17 14:44:36.338998
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2



# Generated at 2022-06-17 14:44:45.493502
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers

    event_source += handler1
    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers

    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:44:54.975975
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b):
        assert a == 1
        assert b == 2

    def handler2(a, b):
        assert a == 1
        assert b == 2

    def handler3(a, b):
        assert a == 1
        assert b == 2
        raise Exception('test')

    def handler4(a, b):
        assert a == 1
        assert b == 2
        raise Exception('test')

    def handler5(a, b):
        assert a == 1
        assert b == 2
        raise Exception('test')

    def handler6(a, b):
        assert a == 1
        assert b == 2
        raise Exception('test')

    def handler7(a, b):
        assert a == 1
        assert b == 2
        raise Exception('test')


# Generated at 2022-06-17 14:44:57.946615
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:45:01.538804
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:06.422896
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    es = MyEventSource()
    es += es.handler
    es.fire()
    assert es.fired



# Generated at 2022-06-17 14:45:12.082518
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    es = TestEventSource()
    es += es.handler
    es.fire()
    assert es.fired

# Generated at 2022-06-17 14:45:16.718861
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    es += handler1
    es += handler2

    assert handler1 in es._handlers
    assert handler2 in es._handlers



# Generated at 2022-06-17 14:45:27.209574
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception = exc
            return False

    test_event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        raise Exception('handler3 exception')

    test_event_source += handler1
    test_event_source += handler2
    test_event_source += handler3

    test_event_source.fire()

    assert test_event_source.exception.args[0] == 'handler2 exception'

    test_event_source -= handler2

    test_event_source.fire()


# Generated at 2022-06-17 14:45:32.142501
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    test_event_source = _TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()
    assert test_event_source.fired

# Generated at 2022-06-17 14:45:44.111017
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:45:53.399824
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None
            self._on_exception_kwargs = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = args
            self._on_exception_kwargs = kwargs
            return False

    def _handler_1(arg1, arg2, kwarg1=None, kwarg2=None):
        pass

    def _handler_2(arg1, arg2, kwarg1=None, kwarg2=None):
        raise RuntimeError

# Generated at 2022-06-17 14:46:04.453890
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    event_source = _TestEventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2 exception')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3 exception')

    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()

    event_source -= handler_2

    event_source.fire()

    event_source -= handler_3

    event_source.fire()

    event_source -= handler_1

    event_source.fire()

# Generated at 2022-06-17 14:46:16.064432
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:46:23.334311
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    es += handler1
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0

    try:
        es += 'not callable'
        assert False, 'expected ValueError'
    except ValueError:
        pass

    try:
        es -= 'not callable'
        assert False, 'expected KeyError'
    except KeyError:
        pass



# Generated at 2022-06-17 14:46:29.087628
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.events = _EventSource()
            self.events += self.handler
            self.events += self.handler_exception
            self.events += self.handler_exception_reraise
            self.events += self.handler_exception_reraise_return_false
            self.events += self.handler_exception_reraise_return_true
            self.events += self.handler_exception_reraise_return_none

        def handler(self, *args, **kwargs):
            pass

        def handler_exception(self, *args, **kwargs):
            raise Exception('handler_exception')


# Generated at 2022-06-17 14:46:38.041571
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2
    assert handler in es._handlers
    assert handler2 in es._handlers

    es += handler2
    assert len(es._handlers) == 2
    assert handler in es._handlers
    assert handler2 in es._handlers

    es += handler2

# Generated at 2022-06-17 14:46:45.708644
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest(_EventSource):
        def __init__(self):
            super(EventSourceTest, self).__init__()
            self.event_fired = False

        def event_handler(self):
            self.event_fired = True

    event_source = EventSourceTest()
    event_source += event_source.event_handler
    event_source.fire()
    assert event_source.event_fired


# Generated at 2022-06-17 14:46:55.140568
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3
            self.event_source += self.handler_4
            self.event_source += self.handler_5
            self.event_source += self.handler_6
            self.event_source += self.handler_7
            self.event_source += self.handler_8
            self.event_source += self.handler_9
            self.event_source += self.handler_10
            self.event_source += self.handler_11
            self.event_source += self.handler_12
            self.event_source += self.handler_13

# Generated at 2022-06-17 14:46:58.880538
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def handler():
        pass
    es += handler
    assert handler in es._handlers


# Generated at 2022-06-17 14:47:14.219879
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestClass:
        def __init__(self):
            self.event = _EventSource()
            self.event += self.handler

        def handler(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    test = TestClass()
    test.event.fire(1, 2, 3, a=4, b=5, c=6)
    assert test.args == (1, 2, 3)
    assert test.kwargs == {'a': 4, 'b': 5, 'c': 6}



# Generated at 2022-06-17 14:47:19.621814
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler

    event_source.fire()

    assert event_source.fired

# Generated at 2022-06-17 14:47:26.638868
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:47:31.689710
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:47:45.982946
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_calls.append((handler, exc, args, kwargs))
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')

    def handler5(*args, **kwargs):
        raise Exception('handler5')


# Generated at 2022-06-17 14:47:57.254829
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2 exception')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3 exception')

    event_source = TestEventSource()
    event_source += handler_1
   

# Generated at 2022-06-17 14:48:08.663499
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)
            return True

    def handler1(*args, **kwargs):
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')

   

# Generated at 2022-06-17 14:48:20.503335
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler in event_source._handlers
    assert handler2 in event_source._handlers

    event_source += handler2

# Generated at 2022-06-17 14:48:28.092120
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:48:34.878085
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()

        def test_fire(self):
            self.event_source.fire()

        def test_fire_with_args(self):
            self.event_source.fire('arg1', 'arg2')

        def test_fire_with_kwargs(self):
            self.event_source.fire(kwarg1='kwarg1', kwarg2='kwarg2')

        def test_fire_with_args_and_kwargs(self):
            self.event_source.fire('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')


# Generated at 2022-06-17 14:48:51.049368
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda *args, **kwargs: None
    assert len(event._handlers) == 1


# Generated at 2022-06-17 14:49:02.118048
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler(arg):
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    def handler2(arg):
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler
    assert len(event_source._handlers) == 2

    event_source

# Generated at 2022-06-17 14:49:10.925393
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    def handler2():
        pass

    es += handler1
    assert len(es._handlers) == 1
    assert handler1 in es._handlers

    es += handler2
    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._handlers

    es += handler1
    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._handlers

    try:
        es += 1
        assert False, 'expected ValueError'
    except ValueError:
        pass

    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._

# Generated at 2022-06-17 14:49:20.559250
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that the handler is called
    def handler(arg):
        handler.called = True
        assert arg == 'arg'

    handler.called = False
    event = _EventSource()
    event += handler
    event.fire('arg')
    assert handler.called

    # Test that the handler is called multiple times
    handler.called = False
    event = _EventSource()
    event += handler
    event += handler
    event.fire('arg')
    assert handler.called

    # Test that the handler is not called after it is removed
    handler.called = False
    event = _EventSource()
    event += handler
    event -= handler
    event.fire('arg')
    assert not handler.called

    # Test that the handler is not called after it is removed multiple times
    handler.called = False
    event = _EventSource()

# Generated at 2022-06-17 14:49:27.088866
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise ValueError('test')

    def _handler_3(*args, **kwargs):
        pass

    def _handler_4(*args, **kwargs):
        raise ValueError('test')

    def _handler_5(*args, **kwargs):
        pass

    def _handler_6(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:49:35.719824
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2



# Generated at 2022-06-17 14:49:47.384239
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            raise ValueError('handler2')

        def handler3(self, *args, **kwargs):
            raise ValueError('handler3')


# Generated at 2022-06-17 14:49:54.709817
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    try:
        es += 'not callable'
        assert False, 'expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-17 14:50:02.482709
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler1.called = True

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler2.called = True

    handler1.called = False
    handler2.called = False

    event = _EventSource()
    event += handler1
    event += handler2

    event.fire(1, 2, 3)

    assert handler1.called
    assert handler2.called

# Generated at 2022-06-17 14:50:11.688759
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    tes = _TestEventSource()
    tes += handler1
    tes += handler2
    tes += handler3


# Generated at 2022-06-17 14:50:28.240331
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:30.099468
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(x):
        pass

    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:50:38.358521
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    test = _EventSourceTest()
    test.event_source.fire('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')

    assert test.handler1_args == ('arg1', 'arg2')
    assert test.handler1

# Generated at 2022-06-17 14:50:41.265793
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:50:47.570122
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = MyEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:50:57.055859
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    event_source_test = EventSourceTest()
    event_source_test.event_source.fire(1, 2, 3, kwarg1='a', kwarg2='b')
    assert event_source_test.handler1_args == (1, 2, 3)
    assert event_

# Generated at 2022-06-17 14:51:01.981253
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:51:05.895709
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:08.360575
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:51:14.232008
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:51:38.121612
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3
            self.event_source += self.handler_4
            self.event_source += self.handler_5
            self.event_source += self.handler_6
            self.event_source += self.handler_7
            self.event_source += self.handler_8
            self.event_source += self.handler_9
            self.event_source += self.handler_10
            self.event_source += self.handler_11
            self.event_source += self.handler_12
            self.event_source += self.handler_13
            self

# Generated at 2022-06-17 14:51:47.667989
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler_1():
        pass

    event_source += handler_1
    assert event_source._handlers == {handler_1}

    def handler_2():
        pass

    event_source += handler_2
    assert event_source._handlers == {handler_1, handler_2}

    event_source += handler_2
    assert event_source._handlers == {handler_1, handler_2}

    event_source += handler_1
    assert event_source._handlers == {handler_1, handler_2}



# Generated at 2022-06-17 14:51:55.990686
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_count += 1
            return False

    tes = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    tes += handler1
    tes += handler2
    tes += handler3

    tes.fire()

    assert tes._on_exception_count == 2

# Generated at 2022-06-17 14:52:02.177184
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def event_handler(self, *args, **kwargs):
            self.event_count += 1

    test_event_source = TestEventSource()
    test_event_source += test_event_source.event_handler
    test_event_source.fire()
    assert test_event_source.event_count == 1

# Generated at 2022-06-17 14:52:05.052076
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:52:11.064204
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:52:14.266293
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda: None
    event_source.fire()


# Generated at 2022-06-17 14:52:24.640935
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class TestException(Exception):
        pass

    class TestHandler:
        def __init__(self):
            self._called = False

        def __call__(self, *args, **kwargs):
            self._called = True

    def test_handler(es, handler):
        es.fire()
        assert handler._called

    def test_handler_exception(es, handler):
        try:
            es.fire()
        except TestException:
            pass

# Generated at 2022-06-17 14:52:29.627272
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    e = _TestEventSource()
    e += e.handler
    e.fire()
    assert e.fired

# Generated at 2022-06-17 14:52:33.092592
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:53:08.675545
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    assert event_source._handlers == {handler1}

    event_source += handler2
    assert event_source._handlers == {handler1, handler2}

    event_source += handler1
    assert event_source._handlers == {handler1, handler2}
