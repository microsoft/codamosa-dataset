

# Generated at 2022-06-17 14:43:21.159122
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler
    assert len(event_source._handlers) == 2

    event_source += handler2


# Generated at 2022-06-17 14:43:31.710558
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3
            self.event_source += self.handler_4
            self.event_source += self.handler_5
            self.event_source += self.handler_6
            self.event_source += self.handler_7
            self.event_source += self.handler_8
            self.event_source += self.handler_9
            self.event_source += self.handler_10
            self.event_source += self.handler_11
            self.event_source += self.handler_12
            self.event_source += self.handler_13

# Generated at 2022-06-17 14:43:35.404499
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:43:41.284537
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that the method fire of class _EventSource works as expected
    #
    # Arrange
    #
    # Create a _EventSource object
    event_source = _EventSource()

    # Create a list of handlers
    handlers = [
        lambda: None,
        lambda: None,
        lambda: None,
    ]

    # Act
    #
    # Add the handlers to the event source
    for handler in handlers:
        event_source += handler

    # Fire the event source
    event_source.fire()

    # Assert
    #
    # Check that the handlers have been called
    for handler in handlers:
        assert handler.called

# Generated at 2022-06-17 14:43:52.136399
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exceptions.append((handler, exc, args, kwargs))
            return False

    test_event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    test_event_source += handler1
    test_event_source += handler2

    test_event_source.fire('a', 'b', 'c')

    assert len(test_event_source._exceptions) == 1
    assert test_event_source._exceptions

# Generated at 2022-06-17 14:43:58.765698
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test that the handler is called
    class _TestHandler:
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    handler = _TestHandler()
    event = _EventSource()
    event += handler
    event.fire()
    assert handler.called

    # test that the handler is called with the correct arguments
    class _TestHandler:
        def __init__(self):
            self.args = None
            self.kwargs = None

        def __call__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    handler = _TestHandler()
    event = _EventSource()
    event += handler

# Generated at 2022-06-17 14:44:03.967978
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self):
            self.fired = False

        def fire(self, *args, **kwargs):
            self.fired = True

    test = Test()
    event = _EventSource()
    event += test.fire
    event.fire()
    assert test.fired



# Generated at 2022-06-17 14:44:08.988448
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1
    es += lambda: None
    assert len(es._handlers) == 2
    es += lambda: None
    assert len(es._handlers) == 3


# Generated at 2022-06-17 14:44:12.615278
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def handler(self):
            self.event_fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.event_fired

# Generated at 2022-06-17 14:44:22.867813
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler3')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler4')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler5')

    def handler6(arg1, arg2):
        assert arg

# Generated at 2022-06-17 14:44:30.944756
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda x: x
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:44:35.195057
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:40.642087
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(arg):
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:44:42.479129
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:45.606390
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:47.640436
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:53.855108
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:45:02.832936
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:45:10.203080
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(a, b):
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source -= handler
    assert len(event_source._handlers) == 0

    try:
        event_source += 'not callable'
        assert False, 'Expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-17 14:45:16.630697
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:45:32.699435
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class _TestHandler:
        def __init__(self, raise_exception):
            self._raise_exception = raise_exception

        def __call__(self, *args, **kwargs):
            if self._raise_exception:
                raise Exception('test exception')

    event_source = _TestEventSource()
    event_source += _TestHandler(False)
    event_source += _TestHandler(True)
    event_source += _TestHandler(False)



# Generated at 2022-06-17 14:45:36.137680
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:43.792757
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:45:52.166330
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    es = _TestEventSource()
    es.fire()
    assert not es.exception_raised

    def handler():
        raise Exception('test')

    es += handler
    es.fire()
    assert es.exception_raised

    es.exception_raised = False
    es -= handler
    es.fire()
    assert not es.exception_raised

# Generated at 2022-06-17 14:45:56.957969
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler3')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler4')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler5')


# Generated at 2022-06-17 14:46:00.344629
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    event_source = _EventSource()

    # Act
    event_source += lambda: None

    # Assert
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:46:04.331572
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert event_source._handlers == {handler1, handler2}



# Generated at 2022-06-17 14:46:15.978994
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    def handler3(arg1, arg2):
        pass

    def handler4(arg1, arg2):
        pass

    event_source = _EventSource()

    event_source += handler1
    event_source += handler2
    event_source += handler3

    assert len(event_source._handlers) == 3

    event_source += handler4
    assert len(event_source._handlers) == 4

    event_source += handler1
    assert len(event_source._handlers) == 4

    event_source += handler2
    assert len(event_source._handlers) == 4

    event_source += handler3
    assert len(event_source._handlers) == 4

    event_

# Generated at 2022-06-17 14:46:23.763081
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b):
        assert a == 1
        assert b == 2
        return

    def handler2(a, b):
        assert a == 1
        assert b == 2
        return

    def handler3(a, b):
        assert a == 1
        assert b == 2
        raise ValueError('test')

    def handler4(a, b):
        assert a == 1
        assert b == 2
        raise ValueError('test')

    def on_exception(handler, exc, *args, **kwargs):
        assert handler == handler4
        assert isinstance(exc, ValueError)
        assert exc.args[0] == 'test'
        assert args == (1, 2)
        assert kwargs == {}
        return False

    event_source = _EventSource()
    event_source += handler1

# Generated at 2022-06-17 14:46:27.760848
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    def handler():
        pass
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:46:48.842888
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_impl

        def _on_exception_impl(self, handler, exc, *args, **kwargs):
            self._exception_handler = handler
            self._exception = exc
            self._exception_args = args
            self._exception_kwargs = kwargs
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    es = TestEventSource()
    es += handler_1
    es += handler_2

    es.fire(1, 2, 3, a=4, b=5)

   

# Generated at 2022-06-17 14:46:54.875438
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def fire(self, *args, **kwargs):
            self.fired = True
            super(TestEventSource, self).fire(*args, **kwargs)

    event_source = TestEventSource()
    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:47:06.266559
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return 'handler1'

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return 'handler2'

    def handler3(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return 'handler3'

    def handler4(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return 'handler4'

    def handler5(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        return 'handler5'


# Generated at 2022-06-17 14:47:09.926818
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    es = MyEventSource()
    es += es.handler
    es.fire()
    assert es.fired



# Generated at 2022-06-17 14:47:20.198890
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    test_event_source = _TestEventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test exception')

    test_event_source += handler_1
    test_event_source += handler_2

    test_event_source.fire()

    assert test_event_source.exception_raised



# Generated at 2022-06-17 14:47:27.963520
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def handler1(arg1, arg2):
        print('handler1: %s, %s' % (arg1, arg2))

    def handler2(arg1, arg2):
        print('handler2: %s, %s' % (arg1, arg2))

    event += handler1
    event += handler2

    event.fire('arg1', 'arg2')


# Generated at 2022-06-17 14:47:36.220599
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:47:47.241762
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    def handler5(*args, **kwargs):
        raise ValueError('test')

    def handler6(*args, **kwargs):
        raise ValueError('test')



# Generated at 2022-06-17 14:47:57.433776
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0

    es -= handler2
   

# Generated at 2022-06-17 14:48:08.970410
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_default

        def _on_exception_default(self, handler, exc, *args, **kwargs):
            return True

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('handler2 exception')

    def handler3(*args, **kwargs):
        raise ValueError('handler3 exception')

    def handler4(*args, **kwargs):
        raise ValueError('handler4 exception')

    def handler5(*args, **kwargs):
        raise ValueError('handler5 exception')


# Generated at 2022-06-17 14:48:48.272597
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class _TestException(Exception):
        pass

    class _TestHandler:
        def __init__(self, raise_exception=False):
            self._raise_exception = raise_exception

        def __call__(self, *args, **kwargs):
            if self._raise_exception:
                raise _TestException()

    test_event_source = _TestEventSource()
    test_handler = _TestHandler()
    test_event_source += test_handler


# Generated at 2022-06-17 14:48:51.414523
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:49:02.520323
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that the event source can be fired without any handlers
    event_source = _EventSource()
    event_source.fire()

    # Test that the event source can be fired with a single handler
    event_source = _EventSource()
    handler_called = False

    def handler():
        nonlocal handler_called
        handler_called = True

    event_source += handler
    event_source.fire()
    assert handler_called

    # Test that the event source can be fired with multiple handlers
    event_source = _EventSource()
    handler_called = [False, False]

    def handler1():
        nonlocal handler_called
        handler_called[0] = True

    def handler2():
        nonlocal handler_called
        handler_called[1] = True

    event_source += handler1
    event_source += handler

# Generated at 2022-06-17 14:49:11.002130
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event = _EventSource()
            self.event += self.handler1
            self.event += self.handler2

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    test = _EventSourceTest()
    test.event.fire('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')

    assert test.handler1_args == ('arg1', 'arg2')

# Generated at 2022-06-17 14:49:17.963068
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self._fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes._fired


# Generated at 2022-06-17 14:49:21.816041
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    es += handler1
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2



# Generated at 2022-06-17 14:49:23.120294
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda: None
    event_source.fire()

# Generated at 2022-06-17 14:49:28.809553
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    e = _TestEventSource()
    e += e.handler
    e.fire()
    assert e.fired

# Generated at 2022-06-17 14:49:38.481986
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True

    def handler_a(*args, **kwargs):
        raise ValueError('handler_a')

    def handler_b(*args, **kwargs):
        raise ValueError('handler_b')

    def handler_c(*args, **kwargs):
        raise ValueError('handler_c')

    def handler_d(*args, **kwargs):
        raise ValueError('handler_d')

    def handler_e(*args, **kwargs):
        raise ValueError('handler_e')


# Generated at 2022-06-17 14:49:48.285329
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('test')

    def handler_3(*args, **kwargs):
        pass

    event_source = TestEventSource()

    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()

    assert event_source.exception_raised



# Generated at 2022-06-17 14:50:48.291891
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    es += handler1
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0



# Generated at 2022-06-17 14:50:54.029324
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:50:56.037912
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda: None
    event_source.fire()

# Generated at 2022-06-17 14:50:58.828561
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:51:08.539558
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exceptions.append(exc)
            return False

    def handler1(*args, **kwargs):
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

# Generated at 2022-06-17 14:51:14.561675
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:51:20.133836
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:51:25.246852
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = _EventSource()
    event_source += _EventSourceTest().handler
    event_source.fire()

    assert event_source._handlers
    assert event_source._handlers.pop().fired

# Generated at 2022-06-17 14:51:29.865695
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:51:38.980530
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14
