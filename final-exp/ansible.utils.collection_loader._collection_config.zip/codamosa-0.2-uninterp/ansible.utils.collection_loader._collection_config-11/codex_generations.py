

# Generated at 2022-06-17 14:43:14.445327
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestHandler:
        def __init__(self, raise_exception=False):
            self.raise_exception = raise_exception

        def __call__(self, *args, **kwargs):
            if self.raise_exception:
                raise TestException()

    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True
            return False

    # test that a handler that raises an exception does not cause the fire method to raise
    event_source = TestEventSource()

# Generated at 2022-06-17 14:43:20.538559
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:43:22.415556
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-17 14:43:27.116406
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    event = _EventSource()
    event += handler
    event.fire(1, 2, 3)



# Generated at 2022-06-17 14:43:29.617508
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:43:32.621759
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    event_source += handler1
    event_source += handler2

    event_source.fire()



# Generated at 2022-06-17 14:43:45.319065
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:43:53.228219
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            raise ValueError('test')

        def handler3(self, *args, **kwargs):
            pass

        def test(self):
            self.event_source.fire()

    _EventSourceTest().test()

# Generated at 2022-06-17 14:44:04.001234
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('test')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('test')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('test')

    event_source = _EventSource()
    event_source += handler1


# Generated at 2022-06-17 14:44:14.022149
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_count += 1
            return False

    event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    event_source += handler1
    event_source += handler2

    event_source.fire()

    assert event_source._on_exception_count == 1

# Generated at 2022-06-17 14:44:28.249369
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:44:34.690041
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def handler(self):
            self.event_fired = True

    event_source = TestEventSource()
    event_source += event_source.handler

    event_source.fire()
    assert event_source.event_fired

# Generated at 2022-06-17 14:44:42.422198
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:44:53.735207
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.events = []

        def handler1(self, *args, **kwargs):
            self.events.append(('handler1', args, kwargs))

        def handler2(self, *args, **kwargs):
            self.events.append(('handler2', args, kwargs))

        def handler3(self, *args, **kwargs):
            self.events.append(('handler3', args, kwargs))

    event_source = _EventSource()
    test = _EventSourceTest()

    event_source += test.handler1
    event_source += test.handler2
    event_source += test.handler3


# Generated at 2022-06-17 14:45:00.745285
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler_1(arg1, arg2):
        pass

    def handler_2(arg1, arg2):
        pass

    event_source += handler_1
    event_source += handler_2

    assert handler_1 in event_source._handlers
    assert handler_2 in event_source._handlers


# Generated at 2022-06-17 14:45:05.774418
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(a, b):
        pass

    def handler2(a, b):
        pass

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:45:08.154219
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:17.900185
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.call_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    tes = TestEventSource()

# Generated at 2022-06-17 14:45:24.330961
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:45:30.265888
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self):
            super(EventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = EventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:45:47.332291
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14
            self

# Generated at 2022-06-17 14:45:53.895363
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()

    def handler(a, b):
        assert a == 1
        assert b == 2

    event_source += handler
    event_source.fire(1, 2)

    def handler_raises(a, b):
        raise ValueError('test')

    event_source += handler_raises
    try:
        event_source.fire(1, 2)
        assert False, 'expected exception'
    except ValueError:
        pass

    event_source -= handler_raises
    event_source.fire(1, 2)



# Generated at 2022-06-17 14:46:04.489433
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler
            self.event_source += self.handler_exception
            self.event_source += self.handler_exception_reraise
            self.event_source += self.handler_exception_reraise_2
            self.event_source += self.handler_exception_reraise_3
            self.event_source += self.handler_exception_reraise_4
            self.event_source += self.handler_exception_reraise_5
            self.event_source += self.handler_exception_reraise_6
            self.event_source += self.handler_exception_reraise_7
            self.event_source += self.handler_ex

# Generated at 2022-06-17 14:46:07.238942
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:46:17.959939
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append(('exception', handler, exc, args, kwargs))
            return False

    tes = TestEventSource()

    def handler1(*args, **kwargs):
        tes.events.append(('handler1', args, kwargs))

    def handler2(*args, **kwargs):
        tes.events.append(('handler2', args, kwargs))

    def handler3(*args, **kwargs):
        tes.events.append(('handler3', args, kwargs))
        raise ValueError('handler3')



# Generated at 2022-06-17 14:46:20.413510
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:46:24.973312
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:46:32.812984
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:46:40.050888
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self):
            super(EventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = EventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:46:50.549287
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_impl

        def _on_exception_impl(self, handler, exc, *args, **kwargs):
            self._exception_handler = handler
            self._exception = exc
            self._exception_args = args
            self._exception_kwargs = kwargs
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        raise Exception('handler3 exception')

    event_source = TestEventSource()
    event_source += handler1

# Generated at 2022-06-17 14:47:09.828824
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2
    assert handler in es._handlers
    assert handler2 in es._handlers

    es += handler2
    assert len(es._handlers) == 2
    assert handler in es._handlers
    assert handler2 in es._handlers

    es += handler
    assert len(es._handlers) == 2
    assert handler in es._handlers
    assert handler2 in es._handlers



# Generated at 2022-06-17 14:47:20.967084
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockHandler:
        def __init__(self, name):
            self.name = name
            self.args = []
            self.kwargs = []

        def __call__(self, *args, **kwargs):
            self.args.append(args)
            self.kwargs.append(kwargs)

    mock_handler1 = MockHandler('mock_handler1')
    mock_handler2 = MockHandler('mock_handler2')
    mock_handler3 = MockHandler('mock_handler3')

    event_source = _EventSource()
    event_source += mock_handler1
    event_source += mock_handler2
    event_source += mock_handler3

    event_source.fire('foo', bar='baz')

    assert mock_handler1.args == [(('foo',), {})]

# Generated at 2022-06-17 14:47:27.235478
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-17 14:47:32.615838
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def handler(self):
            self.event_fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.event_fired

# Generated at 2022-06-17 14:47:46.199666
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('test')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('test')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('test')

    event_source = _EventSource()
    event_source += handler1


# Generated at 2022-06-17 14:47:49.542020
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:58.721169
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler1.called = True

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler2.called = True

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler3.called = True
        raise Exception('handler3 exception')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler4.called = True
        raise Exception('handler4 exception')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'

# Generated at 2022-06-17 14:48:08.327896
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test that __iadd__ raises ValueError when handler is not callable
    event_source = _EventSource()
    try:
        event_source += 'not callable'
    except ValueError:
        pass
    else:
        raise AssertionError('__iadd__ did not raise ValueError when handler is not callable')

    # Test that __iadd__ does not raise ValueError when handler is callable
    event_source = _EventSource()
    try:
        event_source += lambda: None
    except ValueError:
        raise AssertionError('__iadd__ raised ValueError when handler is callable')


# Generated at 2022-06-17 14:48:20.324996
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    def handler5(*args, **kwargs):
        raise ValueError('test')

    def handler6(*args, **kwargs):
        raise ValueError('test')

    def handler7(*args, **kwargs):
        raise ValueError('test')

    def handler8(*args, **kwargs):
        raise ValueError('test')

    def handler9(*args, **kwargs):
        raise ValueError('test')

    def handler10(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:48:26.420759
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:48:47.645104
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException()

    def handler3(*args, **kwargs):
        raise Exception()

    def handler4(*args, **kwargs):
        raise TestException()

    def handler5(*args, **kwargs):
        raise Exception()

    def handler6(*args, **kwargs):
        raise TestException()

    def handler7(*args, **kwargs):
        raise Exception()

    def handler8(*args, **kwargs):
        raise TestException()

    def handler9(*args, **kwargs):
        raise Exception()

    def handler10(*args, **kwargs):
        raise TestException()

    def handler11(*args, **kwargs):
        raise Exception

# Generated at 2022-06-17 14:48:58.481960
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._events.append((handler, exc, args, kwargs))
            return True

    test_event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        raise RuntimeError('handler1')

    def handler2(*args, **kwargs):
        raise RuntimeError('handler2')

    test_event_source += handler1
    test_event_source += handler2

    try:
        test_event_source.fire(1, 2, 3, a=4, b=5)
    except RuntimeError:
        pass


# Generated at 2022-06-17 14:49:03.412912
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:49:09.242184
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exceptions.append((handler, exc, args, kwargs))
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3')

    def handler_4(*args, **kwargs):
        raise Exception('handler_4')

    def handler_5(*args, **kwargs):
        raise Exception('handler_5')


# Generated at 2022-06-17 14:49:16.023099
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:49:22.929148
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(arg1, arg2):
        print('handler1: arg1=%s, arg2=%s' % (arg1, arg2))

    def handler2(arg1, arg2):
        print('handler2: arg1=%s, arg2=%s' % (arg1, arg2))

    event_source += handler1
    event_source += handler2

    event_source.fire('arg1', 'arg2')

    event_source -= handler1

    event_source.fire('arg1', 'arg2')



# Generated at 2022-06-17 14:49:28.346530
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    test_event_source = TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()
    assert test_event_source.fired

# Generated at 2022-06-17 14:49:37.772890
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise Exception('Test exception')

    def _handler_3(*args, **kwargs):
        pass

    event_source = _TestEventSource()
    event_source += _handler_1
    event_source += _handler_2
    event_source += _handler_3

    try:
        event_source.fire()
    except Exception:
        pass


# Generated at 2022-06-17 14:49:45.450829
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        pass

    def handler4(*args, **kwargs):
        raise ValueError('test')

    def handler5(*args, **kwargs):
        pass

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_

# Generated at 2022-06-17 14:49:49.548644
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    t = TestEventSource()
    t += t.handler
    t.fire()
    assert t.fired



# Generated at 2022-06-17 14:50:08.668418
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:50:19.029083
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    # test that no handlers raises no exceptions
    event_source = _TestEventSource()
    event_source.fire()

    # test that a single handler raises no exceptions
    event_source = _TestEventSource()
    event_source += handler1
   

# Generated at 2022-06-17 14:50:20.746424
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:26.393540
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = MyEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:50:28.142690
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:31.964895
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event = TestEventSource()
    event += event.handler
    event.fire()
    assert event.fired

# Generated at 2022-06-17 14:50:40.425653
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:50:48.666818
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    test_event_source = _TestEventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('test')

    test_event_source += handler_1
    test_event_source += handler_2

    test_event_source.fire()

    assert test_event_source._on_exception_called



# Generated at 2022-06-17 14:50:54.465444
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()

    assert event_source.fired

# Generated at 2022-06-17 14:50:57.223746
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:28.081631
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:51:34.079737
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest(_EventSource):
        def __init__(self):
            super(EventSourceTest, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = EventSourceTest()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:51:40.748973
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that the event source fires all handlers
    def handler1():
        handler1.fired = True

    def handler2():
        handler2.fired = True

    handler1.fired = False
    handler2.fired = False

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire()

    assert handler1.fired
    assert handler2.fired

    # Test that the event source ignores exceptions raised by handlers
    def handler3():
        raise ValueError('handler3 exception')

    def handler4():
        raise ValueError('handler4 exception')

    event_source = _EventSource()
    event_source += handler3
    event_source += handler4

    event_source.fire()

    # Test that the event source re-raises exceptions raised by handlers
   

# Generated at 2022-06-17 14:51:46.913194
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:51:56.017770
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        handler1.call_count += 1
        handler1.args = (arg1, arg2)

    def handler2(arg1, arg2):
        handler2.call_count += 1
        handler2.args = (arg1, arg2)

    handler1.call_count = 0
    handler2.call_count = 0

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire('arg1', 'arg2')

    assert handler1.call_count == 1
    assert handler2.call_count == 1
    assert handler1.args == ('arg1', 'arg2')
    assert handler2.args == ('arg1', 'arg2')



# Generated at 2022-06-17 14:51:58.162431
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:52:00.487910
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:52:10.428335
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            raise Exception('handler2')

        def handler3(self, *args, **kwargs):
            raise Exception('handler3')

    event_source_test = _EventSourceTest()

    try:
        event_source_test.event_source.fire()
    except Exception as ex:
        assert str(ex) == 'handler2'

    event_source_test.event_source -= event_source_test.handler

# Generated at 2022-06-17 14:52:14.373975
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()

    assert event_source.fired

# Generated at 2022-06-17 14:52:16.790642
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1
