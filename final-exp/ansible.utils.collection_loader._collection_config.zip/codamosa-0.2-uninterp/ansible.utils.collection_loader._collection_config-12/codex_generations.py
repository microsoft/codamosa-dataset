

# Generated at 2022-06-17 14:43:16.626154
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:43:24.475315
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that a handler is called
    called = False

    def handler():
        nonlocal called
        called = True

    event_source = _EventSource()
    event_source += handler
    event_source.fire()
    assert called

    # Test that a handler is not called after it is removed
    called = False
    event_source -= handler
    event_source.fire()
    assert not called

    # Test that an exception in a handler is re-raised
    called = False

    def handler():
        nonlocal called
        called = True
        raise Exception()

    event_source += handler
    try:
        event_source.fire()
        assert False, 'expected exception'
    except Exception:
        assert called

    # Test that an exception in a handler is not re-raised if _on_exception returns False

# Generated at 2022-06-17 14:43:29.425767
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired is True



# Generated at 2022-06-17 14:43:31.521579
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:43:44.910710
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3')

    event_source = _TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()

    assert event_source._on_ex

# Generated at 2022-06-17 14:43:49.001663
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:43:57.079248
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test with no handlers
    es = _EventSource()
    es.fire()

    # test with one handler
    es = _EventSource()
    es += lambda: None
    es.fire()

    # test with two handlers
    es = _EventSource()
    es += lambda: None
    es += lambda: None
    es.fire()

    # test with one handler that raises
    es = _EventSource()
    es += lambda: 1 / 0
    try:
        es.fire()
    except ZeroDivisionError:
        pass
    else:
        raise AssertionError('expected ZeroDivisionError')

    # test with two handlers, one that raises
    es = _EventSource()
    es += lambda: None
    es += lambda: 1 / 0

# Generated at 2022-06-17 14:44:04.822690
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    def handler5(*args, **kwargs):
        raise ValueError('test')

    def handler6(*args, **kwargs):
        raise ValueError('test')

    def handler7(*args, **kwargs):
        raise ValueError('test')

    def handler8(*args, **kwargs):
        raise ValueError('test')

    def handler9(*args, **kwargs):
        raise ValueError('test')

    def handler10(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:44:07.689063
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:11.685264
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    test_event_source = TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()
    assert test_event_source.fired

# Generated at 2022-06-17 14:44:20.775435
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source -= handler
    assert len(event_source._handlers) == 0

    event_source -= handler
    assert len(event_source._handlers) == 0



# Generated at 2022-06-17 14:44:23.566908
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:28.643959
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:44:35.438466
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    event = TestEventSource()
    event += event.handler
    event.fire()

    assert event.fired

# Generated at 2022-06-17 14:44:41.478159
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    t = TestEventSource()
    t += t.handler
    t.fire()
    assert t.fired



# Generated at 2022-06-17 14:44:53.041991
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that the event source can be fired without any handlers
    event_source = _EventSource()
    event_source.fire()

    # Test that the event source can be fired with a single handler
    event_source = _EventSource()
    event_source += lambda: None
    event_source.fire()

    # Test that the event source can be fired with multiple handlers
    event_source = _EventSource()
    event_source += lambda: None
    event_source += lambda: None
    event_source.fire()

    # Test that the event source can be fired with multiple handlers and arguments
    event_source = _EventSource()
    event_source += lambda x: None
    event_source += lambda x: None
    event_source.fire(1)

    # Test that the event source can be fired with multiple handlers and keyword arguments
    event

# Generated at 2022-06-17 14:45:00.656922
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:45:02.926111
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:12.014432
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    es = TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test exception')

    def handler3(*args, **kwargs):
        pass

    es += handler1
    es += handler2
    es += handler3

    es.fire()

    assert es._on_exception_called

# Generated at 2022-06-17 14:45:17.018358
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:45:27.209383
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    t = _TestEventSource()
    t += t.handler
    t.fire()
    assert t.fired



# Generated at 2022-06-17 14:45:36.842687
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that the method fire of class _EventSource calls all handlers
    # and that it does not raise an exception if one of the handlers raises an exception
    # and that it does raise an exception if the handler raises an exception and the method _on_exception returns True
    # and that it does not raise an exception if the handler raises an exception and the method _on_exception returns False

    class _EventSource_test(object):
        def __init__(self):
            self._handlers = set()

        def __iadd__(self, handler):
            if not callable(handler):
                raise ValueError('handler must be callable')
            self._handlers.add(handler)
            return self


# Generated at 2022-06-17 14:45:47.205940
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception = self._on_exception_test

        def _on_exception_test(self, handler, exc, *args, **kwargs):
            self._exception = exc
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3')

    event_source = _TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()

    assert event_source._

# Generated at 2022-06-17 14:45:52.947686
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:46:04.416834
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.calls.append((handler, exc, args, kwargs))
            return False

    tes = _TestEventSource()

    def handler1(*args, **kwargs):
        raise RuntimeError('handler1')

    def handler2(*args, **kwargs):
        raise RuntimeError('handler2')

    tes += handler1
    tes += handler2

    tes.fire('a', 'b', 'c', d='e')

    assert len(tes.calls) == 2
    assert tes.calls[0][0] == handler1

# Generated at 2022-06-17 14:46:14.624797
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source -= handler
    assert len(event_source._handlers) == 0

    event_source -= handler
    assert len(event_source._handlers) == 0

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source -= handler
    assert len(event_source._handlers) == 0



# Generated at 2022-06-17 14:46:17.918417
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1
    es += lambda: None
    assert len(es._handlers) == 2
    es += lambda: None
    assert len(es._handlers) == 3


# Generated at 2022-06-17 14:46:25.364027
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3')

    def handler_4(*args, **kwargs):
        raise Exception('handler_4')

    def handler_5(*args, **kwargs):
        raise Exception('handler_5')


# Generated at 2022-06-17 14:46:30.061071
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-17 14:46:35.569183
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self._on_exception = lambda handler, exc, *args, **kwargs: False

    event_source = MyEventSource()
    event_source += lambda: None
    event_source += lambda: None
    event_source += lambda: None

    event_source.fire()



# Generated at 2022-06-17 14:46:45.139559
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:46:53.009053
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:46:57.067754
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    t = TestEventSource()
    t += t.handler
    t.fire()
    assert t.fired



# Generated at 2022-06-17 14:47:04.353452
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    def handler2():
        pass

    event_source += handler2
    assert event_source._handlers == {handler, handler2}

    event_source += handler2
    assert event_source._handlers == {handler, handler2}

    event_source += handler2
    assert event_source._handlers == {handler, handler2}

    event_source += handler2


# Generated at 2022-06-17 14:47:12.198265
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    def handler4(*args, **kwargs):
        raise Exception('handler4')

    def handler5(*args, **kwargs):
        raise Exception('handler5')

    def handler6(*args, **kwargs):
        raise Exception('handler6')

    def handler7(*args, **kwargs):
        raise Exception('handler7')

    def handler8(*args, **kwargs):
        raise Exception('handler8')

    def handler9(*args, **kwargs):
        raise Exception('handler9')

    def handler10(*args, **kwargs):
        raise Exception('handler10')


# Generated at 2022-06-17 14:47:22.818529
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test exception')

    def handler3(*args, **kwargs):
        raise Exception('test exception')

    def handler4(*args, **kwargs):
        raise Exception('test exception')


# Generated at 2022-06-17 14:47:28.119754
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    es = MyEventSource()
    es += es.handler
    es.fire()
    assert es.fired

# Generated at 2022-06-17 14:47:36.304894
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise TestException()

    def handler_3(*args, **kwargs):
        raise Exception()

    def handler_4(*args, **kwargs):
        raise TestException()

    def handler_5(*args, **kwargs):
        raise Exception()

    def handler_6(*args, **kwargs):
        raise TestException()

    def handler_7(*args, **kwargs):
        raise Exception()

    def handler_8(*args, **kwargs):
        raise TestException()

    def handler_9(*args, **kwargs):
        raise Exception()

    def handler_10(*args, **kwargs):
        raise TestException()


# Generated at 2022-06-17 14:47:40.406728
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:47:43.814324
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:48:08.218762
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self._handler_1
            self.event_source += self._handler_2
            self.event_source += self._handler_3
            self.event_source += self._handler_4
            self.event_source += self._handler_5
            self.event_source += self._handler_6
            self.event_source += self._handler_7
            self.event_source += self._handler_8
            self.event_source += self._handler_9
            self.event_source += self._handler_10
            self.event_source += self._handler_11
            self.event_source += self._handler_12
            self.event_source += self._handler_13

# Generated at 2022-06-17 14:48:10.899760
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda: None
    assert len(event._handlers) == 1


# Generated at 2022-06-17 14:48:19.140024
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest(_EventSource):
        def __init__(self):
            super(EventSourceTest, self).__init__()
            self.called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.called = True

    event_source = EventSourceTest()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.called

# Generated at 2022-06-17 14:48:22.341813
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:28.106194
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:48:36.026805
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestHandler:
        def __init__(self):
            self.call_count = 0
            self.exception_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1
            if self.call_count == 1:
                raise TestException()

    event_source = _EventSource()
    handler = TestHandler()
    event_source += handler

    try:
        event_source.fire()
    except TestException:
        pass

    assert handler.call_count == 2
    assert handler.exception_count == 1

# Generated at 2022-06-17 14:48:39.633324
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:49.455012
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5
            self.event_source += self.handler6
            self.event_source += self.handler7
            self.event_source += self.handler8
            self.event_source += self.handler9
            self.event_source += self.handler10
            self.event_source += self.handler11
            self.event_source += self.handler12
            self.event_source += self.handler13
            self.event_source += self.handler14


# Generated at 2022-06-17 14:48:51.812087
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:49:02.738162
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_one
            self.event_source += self.handler_two
            self.event_source += self.handler_three
            self.event_source += self.handler_four
            self.event_source += self.handler_five

        def handler_one(self, *args, **kwargs):
            pass

        def handler_two(self, *args, **kwargs):
            raise ValueError('handler_two')

        def handler_three(self, *args, **kwargs):
            raise ValueError('handler_three')

        def handler_four(self, *args, **kwargs):
            raise ValueError('handler_four')


# Generated at 2022-06-17 14:49:37.572226
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            raise ValueError('handler2')

        def handler3(self, *args, **kwargs):
            raise ValueError('handler3')

        def _on_exception(self, handler, exc, *args, **kwargs):
            if handler == self.handler2:
                return False
            return True

    event_source_test = _EventSourceTest()
    event_source_test.event_source._on_

# Generated at 2022-06-17 14:49:38.730083
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler():
        pass

    es += handler

    assert handler in es._handlers


# Generated at 2022-06-17 14:49:48.759076
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_handler = None
            self._on_exception_exception = None
            self._on_exception_args = None
            self._on_exception_kwargs = None
            self._on_exception_return_value = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_handler = handler
            self._on_exception_exception = exc
            self._on_exception_args = args
            self._on_exception_kwargs = kwargs
            return self

# Generated at 2022-06-17 14:49:52.004557
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:49:54.780361
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:50:05.179803
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    es += handler1
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0

    try:
        es += 'not callable'
        assert False, 'expected ValueError'
    except ValueError:
        pass

    assert len(es._handlers) == 0



# Generated at 2022-06-17 14:50:12.749718
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = lambda handler, exc, *args, **kwargs: False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3')

    def handler_4(*args, **kwargs):
        raise Exception('handler_4')


# Generated at 2022-06-17 14:50:21.772346
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        handler1.called = True
        handler1.args = (a, b, c)

    def handler2(a, b, c):
        handler2.called = True
        handler2.args = (a, b, c)

    def handler3(a, b, c):
        handler3.called = True
        handler3.args = (a, b, c)

    def handler4(a, b, c):
        handler4.called = True
        handler4.args = (a, b, c)
        raise Exception('handler4 exception')

    def handler5(a, b, c):
        handler5.called = True
        handler5.args = (a, b, c)
        raise Exception('handler5 exception')


# Generated at 2022-06-17 14:50:28.117145
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:50:29.681671
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:51:26.703361
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        pass

    def handler_3(*args, **kwargs):
        raise Exception('test exception')

    event_source = _EventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()

# Generated at 2022-06-17 14:51:29.879134
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event = TestEventSource()
    event += event.handler
    event.fire()
    assert event.fired

# Generated at 2022-06-17 14:51:36.097487
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired is True



# Generated at 2022-06-17 14:51:46.058883
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler1.called = True

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler2.called = True

    handler1.called = False
    handler2.called = False

    source = _EventSource()
    source += handler1
    source += handler2

    source.fire(1, 2, 3)

    assert handler1.called
    assert handler2.called

# Generated at 2022-06-17 14:51:49.594236
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self):
            self.events = []

        def handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    test = Test()
    event_source = _EventSource()
    event_source += test.handler
    event_source.fire(1, 2, 3, a=4, b=5, c=6)
    assert test.events == [((1, 2, 3), dict(a=4, b=5, c=6))]

    test.events = []
    event_source -= test.handler
    event_source.fire(1, 2, 3, a=4, b=5, c=6)
    assert test.events == []

    test.events = []
    event_source -= test.handler
    event_

# Generated at 2022-06-17 14:51:54.886615
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0

    es -= handler
    assert len(es._handlers) == 0


# Generated at 2022-06-17 14:52:00.306507
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:52:06.224873
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:52:11.463387
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    e = TestEventSource()
    e += e.handler
    e.fire()
    assert e.fired

# Generated at 2022-06-17 14:52:18.969550
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self._handler1
            self.event_source += self._handler2
            self.event_source += self._handler3

        def _handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def _handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

        def _handler3(self, *args, **kwargs):
            self.handler3_args = args
            self.handler3_kwargs = kwargs

    event_source_test = _EventSourceTest()
    event