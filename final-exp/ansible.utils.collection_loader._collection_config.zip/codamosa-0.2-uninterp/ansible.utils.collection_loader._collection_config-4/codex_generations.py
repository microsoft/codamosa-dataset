

# Generated at 2022-06-17 14:43:14.445327
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test exception')

    def handler3(*args, **kwargs):
        raise Exception('test exception')

    es = _TestEventSource()
    es += handler1
    es += handler2
    es += handler3

# Generated at 2022-06-17 14:43:20.233256
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:43:25.206316
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler1.called = True

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler2.called = True

    handler1.called = False
    handler2.called = False

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire(1, 2, 3)

    assert handler1.called
    assert handler2.called

# Generated at 2022-06-17 14:43:27.764545
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:43:35.190965
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception = lambda handler, exc, *args, **kwargs: False

    class _TestException(Exception):
        pass

    class _TestHandler:
        def __init__(self):
            self._call_count = 0

        def __call__(self, *args, **kwargs):
            self._call_count += 1

    event_source = _TestEventSource()
    handler1 = _TestHandler()
    handler2 = _TestHandler()
    handler3 = _TestHandler()

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

    assert handler1._call_count == 1


# Generated at 2022-06-17 14:43:39.769834
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(arg):
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:43:44.846589
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:43:54.358411
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        print('handler1: arg1=%s, arg2=%s' % (arg1, arg2))

    def handler2(arg1, arg2):
        print('handler2: arg1=%s, arg2=%s' % (arg1, arg2))

    def handler3(arg1, arg2):
        print('handler3: arg1=%s, arg2=%s' % (arg1, arg2))

    def handler4(arg1, arg2):
        print('handler4: arg1=%s, arg2=%s' % (arg1, arg2))

    def handler5(arg1, arg2):
        print('handler5: arg1=%s, arg2=%s' % (arg1, arg2))


# Generated at 2022-06-17 14:43:55.873232
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:01.498054
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:44:15.318376
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def _handler1(*args, **kwargs):
        pass

    def _handler2(*args, **kwargs):
        raise ValueError('test')

    def _handler3(*args, **kwargs):
        raise ValueError('test')

    event_source = _TestEventSource()
    event_source += _handler1
    event_source += _handler2
    event_source += _handler3

    event_source.fire()

    assert event_source._on_exception_

# Generated at 2022-06-17 14:44:17.004691
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:27.860699
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception = self._on_exception_test

        def _on_exception_test(self, handler, exc, *args, **kwargs):
            self._exception_handler = handler
            self._exception = exc
            self._exception_args = args
            self._exception_kwargs = kwargs
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    event_source = TestEventSource()
    event_source += handler1
    event_source += handler2

# Generated at 2022-06-17 14:44:31.876835
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:44.741753
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True

    def handler1(*args, **kwargs):
        raise ValueError()

    def handler2(*args, **kwargs):
        raise ValueError()

    def handler3(*args, **kwargs):
        raise ValueError()

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    try:
        event_source.fire()
    except ValueError:
        pass

    assert event_source

# Generated at 2022-06-17 14:44:49.345995
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:44:51.547486
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:53.854824
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:06.341425
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1():
        raise ValueError('handler_1')

    def handler_2():
        raise ValueError('handler_2')

    def handler_3():
        raise ValueError('handler_3')

    event_source = TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    try:
        event_source.fire()
    except ValueError:
        pass

    assert event_source._on

# Generated at 2022-06-17 14:45:10.932160
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = _EventSource()
    event_source += _EventSourceTest().handler
    event_source.fire()

    assert event_source._handlers
    assert event_source._handlers[0].fired

# Generated at 2022-06-17 14:45:22.447496
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:45:27.731445
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    es = TestEventSource()
    es += es.handler
    es.fire()
    assert es.fired

# Generated at 2022-06-17 14:45:31.966122
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:45:35.522998
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:39.300073
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:49.706210
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.fired.append((handler, exc, args, kwargs))
            return False

    tes = TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    tes += handler1
    tes += handler2
    tes += handler3


# Generated at 2022-06-17 14:45:52.641201
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1
    event_source += lambda: None
    assert len(event_source._handlers) == 2


# Generated at 2022-06-17 14:46:00.232313
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()

    assert event_source.fired

# Generated at 2022-06-17 14:46:02.750862
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-17 14:46:06.969388
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:46:27.195034
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source -= handler
    assert len(event_source._handlers) == 0

    event_source -= handler
    assert len(event_source._handlers) == 0

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source -= handler
    assert len(event_source._handlers) == 0



# Generated at 2022-06-17 14:46:33.513038
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b):
        assert a == 1
        assert b == 2

    def handler2(a, b):
        assert a == 1
        assert b == 2

    def handler3(a, b):
        assert a == 1
        assert b == 2

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire(1, 2)



# Generated at 2022-06-17 14:46:35.790964
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:46:42.496930
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler3')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler4')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler5')

    event_source = _EventSource()

# Generated at 2022-06-17 14:46:45.139480
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:46:51.911463
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # test that __iadd__ works
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1

    # test that __iadd__ does not allow non-callable values
    es = _EventSource()
    try:
        es += 'not callable'
        assert False, 'expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-17 14:46:57.032436
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler_1.called = True

    def handler_2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler_2.called = True

    handler_1.called = False
    handler_2.called = False

    event_source = _EventSource()
    event_source += handler_1
    event_source += handler_2

    event_source.fire(1, 2, 3)

    assert handler_1.called
    assert handler_2.called


# Generated at 2022-06-17 14:47:04.332145
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    def handler5(*args, **kwargs):
        raise ValueError('test')

    def handler6(*args, **kwargs):
        raise ValueError('test')

    def handler7(*args, **kwargs):
        raise ValueError('test')

    def handler8(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:47:09.825736
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    test_event_source = TestEventSource()
    test_event_source += test_event_source.handler
    test_event_source.fire()
    assert test_event_source.fired



# Generated at 2022-06-17 14:47:20.921907
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exceptions.append((handler, exc, args, kwargs))
            return False

    def handler1(arg1, arg2):
        raise ValueError('handler1')

    def handler2(arg1, arg2):
        raise ValueError('handler2')

    def handler3(arg1, arg2):
        raise ValueError('handler3')

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire('arg1', 'arg2')

# Generated at 2022-06-17 14:47:57.443734
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True

    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException()

    def handler3(*args, **kwargs):
        raise Exception()

    def handler4(*args, **kwargs):
        raise TestException()

    def handler5(*args, **kwargs):
        raise Exception()

    def handler6(*args, **kwargs):
        raise TestException()


# Generated at 2022-06-17 14:48:08.964577
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    def handler5(*args, **kwargs):
        raise ValueError('test')

    def handler6(*args, **kwargs):
        raise ValueError('test')

    def handler7(*args, **kwargs):
        raise ValueError('test')

    def handler8(*args, **kwargs):
        raise ValueError('test')

    def handler9(*args, **kwargs):
        raise ValueError('test')

    def handler10(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:48:20.751843
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        raise TestException('handler1')

    def handler2(*args, **kwargs):
        raise TestException('handler2')

    def handler3(*args, **kwargs):
        raise TestException('handler3')

    def handler4(*args, **kwargs):
        raise TestException('handler4')

    def handler5(*args, **kwargs):
        raise TestException('handler5')

    def handler6(*args, **kwargs):
        raise TestException('handler6')

    def handler7(*args, **kwargs):
        raise TestException('handler7')

    def handler8(*args, **kwargs):
        raise TestException('handler8')

    def handler9(*args, **kwargs):
        raise TestException('handler9')

# Generated at 2022-06-17 14:48:31.107596
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.call_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('test exception')

    def handler_3(*args, **kwargs):
        pass

    def handler_4(*args, **kwargs):
        raise Exception('test exception')

    event_source = TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3
    event_source

# Generated at 2022-06-17 14:48:41.006048
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    event_source += handler1
    event_source += handler2

    event_source.fire(1, 2, 3)



# Generated at 2022-06-17 14:48:49.944915
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise TestException()

    def handler_3(*args, **kwargs):
        raise ValueError()

    def handler_4(*args, **kwargs):
        raise TestException()

    def handler_5(*args, **kwargs):
        raise ValueError()

    def handler_6(*args, **kwargs):
        raise ValueError()

    def handler_7(*args, **kwargs):
        raise ValueError()

    def handler_8(*args, **kwargs):
        raise ValueError()

    def handler_9(*args, **kwargs):
        raise ValueError()

    def handler_10(*args, **kwargs):
        raise ValueError()

   

# Generated at 2022-06-17 14:48:51.941189
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:55.495698
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:49:04.694135
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise Exception('test')

    def _handler_3(*args, **kwargs):
        raise Exception('test')

    test_event_source = _TestEventSource()
    test_event_source += _handler_1
    test_event_source += _handler_2
    test_event_source += _handler_3


# Generated at 2022-06-17 14:49:15.615925
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_return_value = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return self._on_exception_return_value

    def _handler_1(*args, **kwargs):
        pass

    def _handler_2(*args, **kwargs):
        raise ValueError('test')

    def _handler_3(*args, **kwargs):
        raise ValueError('test')

    def _handler_4(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:49:44.461595
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:49:54.044934
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    def handler_3(*args, **kwargs):
        raise ValueError('test')

    event_source = _TestEventSource()

    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()

    assert event_source._on_exception_

# Generated at 2022-06-17 14:50:05.227502
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest:
        def __init__(self):
            self.events = []

        def handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    event_source = _EventSource()
    test = _EventSourceTest()

    event_source += test.handler
    event_source.fire(1, 2, 3, a=4, b=5, c=6)
    assert test.events == [((1, 2, 3), dict(a=4, b=5, c=6))]

    event_source -= test.handler
    event_source.fire(1, 2, 3, a=4, b=5, c=6)

# Generated at 2022-06-17 14:50:09.693495
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test that __iadd__ raises a ValueError if the handler is not callable
    event_source = _EventSource()
    with pytest.raises(ValueError):
        event_source += 'not callable'

    # Test that __iadd__ does not raise an exception if the handler is callable
    event_source += lambda: None



# Generated at 2022-06-17 14:50:16.486034
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = _TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:50:19.575892
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:27.597881
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    def handler5(*args, **kwargs):
        raise ValueError('test')

    def handler6(*args, **kwargs):
        raise ValueError('test')


# Generated at 2022-06-17 14:50:33.803956
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    def handler2():
        pass

    event_source += handler2
    assert event_source._handlers == {handler, handler2}

    event_source += handler2
    assert event_source._handlers == {handler, handler2}

    event_source += handler2
    assert event_source._handlers == {handler, handler2}

    event_source += handler
    assert event_source._handlers == {handler, handler2}


# Generated at 2022-06-17 14:50:37.077704
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = _EventSource()
    test = _EventSourceTest()
    event_source += test.handler
    event_source.fire()
    assert test.fired

# Generated at 2022-06-17 14:50:47.889625
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_handler = None
            self._on_exception_exc = None
            self._on_exception_args = None
            self._on_exception_kwargs = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_handler = handler
            self._on_exception_exc = exc
            self._on_exception_args = args
            self._on_exception_kwargs = kwargs
            return True

    def _handler1(*args, **kwargs):
        pass

# Generated at 2022-06-17 14:51:16.916263
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1():
        pass

    def handler2():
        pass

    es = _EventSource()
    es += handler1
    es += handler2

    assert handler1 in es._handlers
    assert handler2 in es._handlers


# Generated at 2022-06-17 14:51:26.835896
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler in event_source._handlers
    assert handler2 in event_source._handlers

    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-17 14:51:28.485853
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:34.994535
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False
            self.event_args = None
            self.event_kwargs = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return False

        def handler(self, *args, **kwargs):
            self.event_fired = True
            self.event_args = args
            self.event_kwargs = kwargs

    event_source = TestEventSource()
    event_source += event_source.handler

    event_source.fire(1, 2, 3, a=4, b=5, c=6)

    assert event_source

# Generated at 2022-06-17 14:51:41.146604
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3
            self.event_source += self.handler4
            self.event_source += self.handler5

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            pass

        def handler3(self, *args, **kwargs):
            raise ValueError('handler3')

        def handler4(self, *args, **kwargs):
            raise ValueError('handler4')

        def handler5(self, *args, **kwargs):
            raise ValueError('handler5')



# Generated at 2022-06-17 14:51:46.004773
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:51:48.145317
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:51:51.350696
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:57.822946
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def handler(self):
            self.event_fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.event_fired

# Generated at 2022-06-17 14:51:59.862742
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:52:34.294969
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:52:36.341948
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:52:39.232637
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:52:45.957818
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self._handler1
            self.event_source += self._handler2
            self.event_source += self._handler3

        def _handler1(self, *args, **kwargs):
            pass

        def _handler2(self, *args, **kwargs):
            raise Exception('test exception')

        def _handler3(self, *args, **kwargs):
            pass

    test_obj = _EventSourceTest()
    test_obj.event_source.fire()

# Generated at 2022-06-17 14:52:52.986242
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:52:59.848092
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return False

        def handler(self, *args, **kwargs):
            self.event_fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.event_fired



# Generated at 2022-06-17 14:53:05.615433
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired