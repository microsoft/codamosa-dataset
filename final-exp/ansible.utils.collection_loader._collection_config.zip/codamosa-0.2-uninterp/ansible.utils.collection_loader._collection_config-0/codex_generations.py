

# Generated at 2022-06-17 14:43:14.404146
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    def handler4(*args, **kwargs):
        raise ValueError('test')

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

# Generated at 2022-06-17 14:43:22.188514
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

    event_source = TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    event_source += handler1
    event_source += handler2

    try:
        event_source.fire()
    except Exception:
        pass

    event_source -= handler1
    event_source -= handler2

# Generated at 2022-06-17 14:43:29.503586
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    t = _TestEventSource()
    t += t.handler
    t.fire()
    assert t.fired

# Generated at 2022-06-17 14:43:33.316593
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:43:35.337976
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    es += lambda: None
    es.fire()

# Generated at 2022-06-17 14:43:38.682271
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:43:46.949353
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler3')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler4')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise ValueError('handler5')


# Generated at 2022-06-17 14:43:50.882729
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:43:58.165281
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(x, y):
        assert x == 1
        assert y == 2

    def handler2(x, y):
        assert x == 1
        assert y == 2
        raise Exception('test exception')

    def handler3(x, y):
        assert x == 1
        assert y == 2
        raise Exception('test exception')

    def handler4(x, y):
        assert x == 1
        assert y == 2
        raise Exception('test exception')

    def handler5(x, y):
        assert x == 1
        assert y == 2
        raise Exception('test exception')

    def handler6(x, y):
        assert x == 1
        assert y == 2
        raise Exception('test exception')

    def handler7(x, y):
        assert x == 1
        assert y == 2

# Generated at 2022-06-17 14:44:07.328510
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler
    assert len(event_source._handlers) == 2

    event_source += handler2


# Generated at 2022-06-17 14:44:14.986186
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda: None
    assert len(e._handlers) == 1


# Generated at 2022-06-17 14:44:21.513112
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise TestException()

    def handler3(*args, **kwargs):
        raise Exception()

    def handler4(*args, **kwargs):
        raise TestException()

    def handler5(*args, **kwargs):
        raise Exception()

    def handler6(*args, **kwargs):
        raise TestException()

    def handler7(*args, **kwargs):
        raise Exception()

    def handler8(*args, **kwargs):
        raise TestException()

    def handler9(*args, **kwargs):
        raise Exception()

    def handler10(*args, **kwargs):
        raise TestException()

    def handler11(*args, **kwargs):
        raise Exception

# Generated at 2022-06-17 14:44:26.665901
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:44:37.454318
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    # test that handlers are called
    tes = _TestEventSource()
    handler_called = [False]

    def handler(*args, **kwargs):
        handler_called[0] = True

    tes += handler
    tes.fire()
    assert handler_called[0]

    # test that exceptions are handled
    tes = _TestEventSource()
    handler_called = [False]

    def handler(*args, **kwargs):
        handler_called[0]

# Generated at 2022-06-17 14:44:50.056420
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that a handler is called with the expected arguments
    def handler(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    event_source = _EventSource()
    event_source += handler
    event_source.fire('arg1', 'arg2')

    # Test that a handler is called with the expected keyword arguments
    def handler(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    event_source = _EventSource()
    event_source += handler
    event_source.fire(arg1='arg1', arg2='arg2')

    # Test that a handler is called with the expected arguments and keyword arguments
    def handler(arg1, arg2, kwarg1, kwarg2):
        assert arg1

# Generated at 2022-06-17 14:44:54.202647
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-17 14:44:56.355762
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:59.768868
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:06.170329
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def handler(self):
            self.event_fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.event_fired



# Generated at 2022-06-17 14:45:08.572283
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:45:19.536690
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:45:29.512094
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler1(self, *args, **kwargs):
            self.count += 1

        def handler2(self, *args, **kwargs):
            self.count += 2

        def handler3(self, *args, **kwargs):
            self.count += 3

    tes = TestEventSource()
    tes += tes.handler1
    tes += tes.handler2
    tes += tes.handler3

    tes.fire()

# Generated at 2022-06-17 14:45:36.972865
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.event_fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.event_fired

# Generated at 2022-06-17 14:45:47.233389
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        raise ValueError('handler1')

    def handler2(arg1, arg2):
        raise ValueError('handler2')

    def handler3(arg1, arg2):
        raise ValueError('handler3')

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    try:
        event_source.fire('arg1', 'arg2')
    except ValueError as ex:
        assert ex.args[0] == 'handler3'
    else:
        assert False, 'ValueError not raised'

    event_source -= handler3


# Generated at 2022-06-17 14:45:49.539809
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:45:53.399186
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:45:57.846055
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:46:05.788454
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._calls.append(('exception', handler, exc, args, kwargs))
            return False

    tes = _TestEventSource()

    def handler1(*args, **kwargs):
        tes._calls.append(('handler1', args, kwargs))

    def handler2(*args, **kwargs):
        tes._calls.append(('handler2', args, kwargs))
        raise ValueError('test')


# Generated at 2022-06-17 14:46:16.865785
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)
            return False

    def handler1(*args, **kwargs):
        raise ValueError('handler1')

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    def handler3(*args, **kwargs):
        raise ValueError('handler3')

    test_event_source = _TestEventSource()
    test_event_

# Generated at 2022-06-17 14:46:20.922593
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:46:37.083752
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    es += handler1
    es += handler2

    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._handlers



# Generated at 2022-06-17 14:46:43.970241
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestHandler:
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    class TestHandlerWithException(TestHandler):
        def __call__(self, *args, **kwargs):
            super(TestHandlerWithException, self).__call__(*args, **kwargs)
            raise TestException()

    class TestHandlerWithExceptionAndReraise(TestHandlerWithException):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return True

    class TestHandlerWithExceptionAndSwallow(TestHandlerWithException):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False


# Generated at 2022-06-17 14:46:48.255351
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:46:58.525537
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    def handler2():
        pass

    es += handler1
    assert len(es._handlers) == 1
    assert handler1 in es._handlers

    es += handler2
    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._handlers

    es += handler1
    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._handlers

    try:
        es += 'not callable'
        assert False, 'expected ValueError'
    except ValueError:
        pass

    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler

# Generated at 2022-06-17 14:47:04.353430
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    tes = TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    tes += handler1
    tes += handler2
    tes += handler3

    tes.fire()

    assert tes.exception_count == 2

# Generated at 2022-06-17 14:47:10.577601
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:47:12.966927
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:23.395681
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    assert handler1 in event_source._handlers

    event_source += handler2
    assert handler2 in event_source._handlers

    event_source += handler1
    assert handler1 in event_source._handlers

    event_source += handler2
    assert handler2 in event_source._handlers

    event_source -= handler1
    assert handler1 not in event_source._handlers

    event_source -= handler2
    assert handler2 not in event_source._handlers

    event_source -= handler1
    assert handler1 not in event_source._handlers

    event_source -= handler2
    assert handler2 not in event_source._handlers


# Generated at 2022-06-17 14:47:26.694355
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:47:33.689365
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler1.called = True

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler2.called = True

    handler1.called = False
    handler2.called = False

    event = _EventSource()
    event += handler1
    event += handler2

    event.fire(1, 2, 3)

    assert handler1.called
    assert handler2.called


# Generated at 2022-06-17 14:47:48.820976
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:47:58.348081
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1():
        raise Exception('handler1')

    def handler2():
        raise Exception('handler2')

    def handler3():
        raise Exception('handler3')

    event_source = _TestEventSource()

    event_source += handler1
    event_source += handler2
    event_source += handler3

    try:
        event_source.fire()
    except Exception:
        pass

    assert event_source._on_exception_called



# Generated at 2022-06-17 14:48:02.042948
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:48:07.495702
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:48:14.047319
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test with a callable
    event_source = _EventSource()
    event_source += lambda: None

    # Test with a non-callable
    event_source = _EventSource()
    try:
        event_source += 'not callable'
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'


# Generated at 2022-06-17 14:48:17.846713
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    event_source = _EventSource()

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:48:21.803418
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = MyEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired



# Generated at 2022-06-17 14:48:31.797587
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    test_event_source = _TestEventSource()
    test_event_source += handler1
    test_event_source += handler2
    test_event_source += handler3

    test_event_source.fire()
    assert test_event_source

# Generated at 2022-06-17 14:48:46.828485
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

        def handler3(self, *args, **kwargs):
            self.handler3_args = args
            self.handler3_kwargs = kwargs

    event_source_test = EventSourceTest()
    event_source_test.event_

# Generated at 2022-06-17 14:48:58.192255
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event = _EventSource()
            self.event += self.handler1
            self.event += self.handler2
            self.event += self.handler3

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            raise ValueError('handler2')

        def handler3(self, *args, **kwargs):
            raise ValueError('handler3')

        def _on_exception(self, handler, exc, *args, **kwargs):
            if handler == self.handler2:
                return False
            return True

    test = EventSourceTest()

# Generated at 2022-06-17 14:49:14.220542
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True

    test_event_source = TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test exception')

    test_event_source += handler1
    test_event_source += handler2

    test_event_source.fire()

    assert test_event_source.exception_raised

# Generated at 2022-06-17 14:49:23.498389
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestClass:
        def __init__(self):
            self.events = _EventSource()
            self.events += self.handler1
            self.events += self.handler2
            self.events += self.handler3
            self.events += self.handler4
            self.events += self.handler5
            self.events += self.handler6

            self.handler1_called = False
            self.handler2_called = False
            self.handler3_called = False
            self.handler4_called = False
            self.handler5_called = False
            self.handler6_called = False

        def handler1(self, *args, **kwargs):
            self.handler1_called = True


# Generated at 2022-06-17 14:49:33.557317
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True

    test_event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test exception')

    test_event_source += handler1
    test_event_source += handler2

    test_event_source.fire()

    assert test_event_source.exception_raised

# Generated at 2022-06-17 14:49:46.656643
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1(arg):
        assert arg == 'arg'
        return 'handler_1'

    def handler_2(arg):
        assert arg == 'arg'
        return 'handler_2'

    def handler_3(arg):
        assert arg == 'arg'
        return 'handler_3'

    def handler_4(arg):
        assert arg == 'arg'
        return 'handler_4'

    def handler_5(arg):
        assert arg == 'arg'
        return 'handler_5'

    def handler_6(arg):
        assert arg == 'arg'
        return 'handler_6'

    def handler_7(arg):
        assert arg == 'arg'
        return 'handler_7'

    def handler_8(arg):
        assert arg == 'arg'
        return 'handler_8'

# Generated at 2022-06-17 14:49:49.880972
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:49:54.398549
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def fire(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:49:56.775898
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(a, b, c):
        pass

    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-17 14:50:07.773817
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_args = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_args = (handler, exc, args, kwargs)
            return False

    def handler1(*args, **kwargs):
        raise ValueError('handler1')

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    def handler3(*args, **kwargs):
        raise ValueError('handler3')


# Generated at 2022-06-17 14:50:18.503103
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that a handler which raises an exception is removed from the set of handlers
    def handler_1(arg):
        raise Exception('handler_1')

    def handler_2(arg):
        raise Exception('handler_2')

    def handler_3(arg):
        raise Exception('handler_3')

    def handler_4(arg):
        raise Exception('handler_4')

    def handler_5(arg):
        raise Exception('handler_5')

    def handler_6(arg):
        raise Exception('handler_6')

    def handler_7(arg):
        raise Exception('handler_7')

    def handler_8(arg):
        raise Exception('handler_8')

    def handler_9(arg):
        raise Exception('handler_9')

    def handler_10(arg):
        raise Exception('handler_10')

   

# Generated at 2022-06-17 14:50:29.074714
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception()

    def handler3(*args, **kwargs):
        pass

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

    assert event_source._on_exception_called



# Generated at 2022-06-17 14:51:05.512180
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        raise ValueError('handler1')

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    def handler3(*args, **kwargs):
        raise ValueError('handler3')

    def handler4(*args, **kwargs):
        raise ValueError('handler4')

    def handler5(*args, **kwargs):
        raise ValueError('handler5')


# Generated at 2022-06-17 14:51:07.795052
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:14.376712
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += None


# Generated at 2022-06-17 14:51:22.516933
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def handler1(*args, **kwargs):
        raise TestException('handler1')

    def handler2(*args, **kwargs):
        raise TestException('handler2')

    def handler3(*args, **kwargs):
        raise TestException('handler3')

    def handler4(*args, **kwargs):
        raise TestException('handler4')

    def handler5(*args, **kwargs):
        raise TestException('handler5')

    def handler6(*args, **kwargs):
        raise TestException('handler6')

    def handler7(*args, **kwargs):
        raise TestException('handler7')

    def handler8(*args, **kwargs):
        raise TestException('handler8')

    def handler9(*args, **kwargs):
        raise TestException('handler9')

# Generated at 2022-06-17 14:51:30.294746
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_count += 1
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    test_event_source = TestEventSource()
    test_event_source += handler1
    test_event_source += handler2
    test_event_source += handler3

    test_event_source.fire()


# Generated at 2022-06-17 14:51:33.784348
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(arg):
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:51:37.775617
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:46.602854
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.fired = True

    es = MyEventSource()
    es += es.handler
    es.fire()
    assert es.fired

# Generated at 2022-06-17 14:51:52.940891
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:51:56.604247
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    event = _EventSource()
    event += handler
    event.fire(1, 2, 3)



# Generated at 2022-06-17 14:52:59.093543
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += handler
    assert event_source._handlers == {handler}

    def handler2():
        pass

    event_source += handler2
    assert event_source._handlers == {handler, handler2}

    event_source += handler2
    assert event_source._handlers == {handler, handler2}

    event_source += handler2
    assert event_source._handlers == {handler, handler2}

    event_source += handler
    assert event_source._handlers == {handler, handler2}


# Generated at 2022-06-17 14:53:06.978171
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = _TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

