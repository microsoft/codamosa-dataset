

# Generated at 2022-06-17 14:43:21.921468
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_handler_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_handler_called = True

    test_event_source = _TestEventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        raise Exception('handler_3')

    test_event_source += handler_1
    test_event_source += handler_2
    test_event_source += handler_3


# Generated at 2022-06-17 14:43:27.272068
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler_1():
        pass

    def handler_2():
        pass

    event_source += handler_1
    event_source += handler_2

    assert handler_1 in event_source._handlers
    assert handler_2 in event_source._handlers



# Generated at 2022-06-17 14:43:31.562997
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler_1(arg1, arg2):
        pass

    def handler_2(arg1, arg2):
        pass

    event_source += handler_1
    event_source += handler_2

    assert handler_1 in event_source._handlers
    assert handler_2 in event_source._handlers



# Generated at 2022-06-17 14:43:44.937726
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('handler2 exception')

    def handler3(*args, **kwargs):
        raise ValueError('handler3 exception')

    def handler4(*args, **kwargs):
        raise ValueError('handler4 exception')

    def handler5(*args, **kwargs):
        raise ValueError('handler5 exception')

    def handler6(*args, **kwargs):
        raise ValueError('handler6 exception')

    def handler7(*args, **kwargs):
        raise ValueError('handler7 exception')

    def handler8(*args, **kwargs):
        raise ValueError

# Generated at 2022-06-17 14:43:46.934898
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:43:51.946579
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # test that adding a non-callable handler raises a ValueError
    event_source = _EventSource()
    try:
        event_source += 'not callable'
    except ValueError:
        pass
    else:
        raise AssertionError('expected ValueError')

    # test that adding a callable handler does not raise an exception
    event_source += lambda: None


# Generated at 2022-06-17 14:43:54.392643
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    event_source = _EventSource()
    handler = lambda: None

    # Act
    event_source += handler

    # Assert
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:44:00.888226
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        pass

    def handler_3(*args, **kwargs):
        raise ValueError('test')

    def handler_4(*args, **kwargs):
        raise ValueError('test')

    def handler_5(*args, **kwargs):
        raise ValueError('test')

    def handler_6(*args, **kwargs):
        raise ValueError('test')

    def handler_7(*args, **kwargs):
        raise ValueError('test')

    def handler_8(*args, **kwargs):
        raise ValueError('test')

    def handler_9(*args, **kwargs):
        raise ValueError('test')

    def handler_10(*args, **kwargs):
        raise ValueError('test')

# Generated at 2022-06-17 14:44:08.248910
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test that __iadd__ raises ValueError when handler is not callable
    event_source = _EventSource()
    try:
        event_source += 'not callable'
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')

    # Test that __iadd__ does not raise ValueError when handler is callable
    event_source = _EventSource()
    try:
        event_source += lambda: None
    except ValueError:
        raise AssertionError('Expected no ValueError')

    # Test that __iadd__ adds handler to set
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    if handler not in event_source._handlers:
        raise AssertionError('Expected handler to be in set')


#

# Generated at 2022-06-17 14:44:14.699618
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append(('exception', handler, exc, args, kwargs))
            return False

    tes = _TestEventSource()

    def handler1(*args, **kwargs):
        tes.events.append(('handler1', args, kwargs))

    def handler2(*args, **kwargs):
        tes.events.append(('handler2', args, kwargs))
        raise ValueError('handler2')


# Generated at 2022-06-17 14:44:28.707597
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg):
        assert arg == 'test'
        raise Exception('test')

    def handler2(arg):
        assert arg == 'test'

    def handler3(arg):
        assert arg == 'test'
        raise Exception('test')

    def handler4(arg):
        assert arg == 'test'

    def handler5(arg):
        assert arg == 'test'

    def handler6(arg):
        assert arg == 'test'
        raise Exception('test')

    def handler7(arg):
        assert arg == 'test'

    def handler8(arg):
        assert arg == 'test'

    def handler9(arg):
        assert arg == 'test'
        raise Exception('test')

    def handler10(arg):
        assert arg == 'test'

    def handler11(arg):
        assert arg

# Generated at 2022-06-17 14:44:38.720334
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler3 exception')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler4 exception')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler5 exception')


# Generated at 2022-06-17 14:44:44.514744
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1():
        pass

    es += handler1
    assert len(es._handlers) == 1

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler1
    assert len(es._handlers) == 1

    es -= handler2
    assert len(es._handlers) == 0



# Generated at 2022-06-17 14:44:46.967740
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()

    assert event_source._handlers == set()

    event_source += handler

    assert event_source._handlers == {handler}

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-17 14:44:50.384359
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda x: x
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:57.082789
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler1.called = True

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        handler2.called = True

    handler1.called = False
    handler2.called = False

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire('arg1', 'arg2')

    assert handler1.called
    assert handler2.called

# Generated at 2022-06-17 14:45:07.574509
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        handler1.called = True
        handler1.args = (arg1, arg2)

    def handler2(arg1, arg2):
        handler2.called = True
        handler2.args = (arg1, arg2)

    handler1.called = False
    handler2.called = False

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire('foo', 'bar')

    assert handler1.called
    assert handler2.called
    assert handler1.args == ('foo', 'bar')
    assert handler2.args == ('foo', 'bar')


# Generated at 2022-06-17 14:45:09.674796
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(a, b):
        pass

    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:45:16.541120
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self):
            super(EventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = EventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:45:19.374727
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:45:33.279998
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    def handler_3(*args, **kwargs):
        raise ValueError('test')

    test_event_source = _TestEventSource()
    test_event_source += handler_1
    test_event_source += handler_2
    test_event_source += handler_3

    test_event_source.fire()

   

# Generated at 2022-06-17 14:45:45.979207
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.call_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

    def handler(arg):
        if arg == 'raise':
            raise ValueError('test')
        elif arg == 'return':
            return
        else:
            raise ValueError('unexpected arg: %s' % arg)

    tes = TestEventSource()
    tes += handler

    tes.fire('return')
    tes.fire('raise')

    try:
        tes.fire('unexpected')
    except ValueError:
        pass

# Generated at 2022-06-17 14:45:54.698932
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exceptions.append(exc)
            return False

    def handler1(*args, **kwargs):
        raise ValueError('handler1')

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    def handler3(*args, **kwargs):
        raise ValueError('handler3')

    event_source = TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

    assert len(event_source.exceptions) == 3

# Generated at 2022-06-17 14:46:00.003029
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test for callable handler
    event_source = _EventSource()
    event_source += lambda: None

    # Test for non-callable handler
    try:
        event_source += None
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')


# Generated at 2022-06-17 14:46:12.211721
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(arg):
        assert arg == 'foo'

    def handler_exception(arg):
        raise Exception('foo')

    def handler_exception_return_false(arg):
        raise Exception('foo')

    def handler_exception_return_true(arg):
        raise Exception('foo')

    def on_exception(handler, exc, arg):
        assert handler == handler_exception_return_true
        assert isinstance(exc, Exception)
        assert arg == 'foo'
        return True

    event = _EventSource()
    event += handler
    event += handler_exception
    event += handler_exception_return_false
    event += handler_exception_return_true
    event._on_exception = on_exception

    event.fire('foo')


# Generated at 2022-06-17 14:46:18.690243
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler1.called = True

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        handler2.called = True

    handler1.called = False
    handler2.called = False

    e = _EventSource()
    e += handler1
    e += handler2

    e.fire(1, 2, 3)

    assert handler1.called
    assert handler2.called

# Generated at 2022-06-17 14:46:21.698091
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:46:26.235145
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired


# Generated at 2022-06-17 14:46:34.814407
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def _handler1(*args, **kwargs):
        pass

    def _handler2(*args, **kwargs):
        raise ValueError('test')

    def _handler3(*args, **kwargs):
        raise ValueError('test')

    event_source = _TestEventSource()
    event_source += _handler1
    event_source += _handler2
    event_source += _handler3

    event_source.fire()

    assert event_source._on_exception_

# Generated at 2022-06-17 14:46:38.375010
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def __call__(self):
            self.fired = True

    event_source = TestEventSource()
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:47:00.942480
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self._handler_1
            self.event_source += self._handler_2
            self.event_source += self._handler_3
            self.event_source += self._handler_4
            self.handler_1_fired = False
            self.handler_2_fired = False
            self.handler_3_fired = False
            self.handler_4_fired = False

        def _handler_1(self, *args, **kwargs):
            self.handler_1_fired = True

        def _handler_2(self, *args, **kwargs):
            self.handler_2_fired = True


# Generated at 2022-06-17 14:47:13.306612
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestHandler:
        def __init__(self):
            self.invoked = False

        def __call__(self, *args, **kwargs):
            self.invoked = True

    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            if isinstance(exc, TestException):
                return False
            return True

    event_source = TestEventSource()

    handler1 = TestHandler()
    handler2 = TestHandler()
    handler3 = TestHandler()

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

    assert handler1.invoked
    assert handler2.invoked
    assert handler3.invoked



# Generated at 2022-06-17 14:47:20.094288
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            pass

    event_source_test = _EventSourceTest()
    event_source_test.event_source.fire()

# Generated at 2022-06-17 14:47:28.792362
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:47:36.652466
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

# Generated at 2022-06-17 14:47:44.243975
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_args = None
            self.event_kwargs = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.event_args = args
            self.event_kwargs = kwargs
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    event_source = TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3


# Generated at 2022-06-17 14:47:51.509298
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:47:56.913854
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def handler(self, *args, **kwargs):
            self.event_fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.event_fired

# Generated at 2022-06-17 14:48:00.639201
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # arrange
    event_source = _EventSource()
    handler = lambda: None

    # act
    event_source += handler

    # assert
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:48:12.317749
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_handler = None
            self._on_exception_exception = None
            self._on_exception_args = None
            self._on_exception_kwargs = None
            self._on_exception_return_value = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_handler = handler
            self._on_exception_exception = exc
            self._on_exception_args = args
            self._on_exception_kwargs = kwargs
            return self

# Generated at 2022-06-17 14:48:48.037190
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('handler2 exception')

    def handler3(*args, **kwargs):
        raise Exception('handler3 exception')

    event_source = _TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

    assert event_source._on_exception_called


#

# Generated at 2022-06-17 14:48:58.541124
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self._handler1
            self.event_source += self._handler2

        def _handler1(self, *args, **kwargs):
            self.handler1_args = args
            self.handler1_kwargs = kwargs

        def _handler2(self, *args, **kwargs):
            self.handler2_args = args
            self.handler2_kwargs = kwargs

    test = _EventSourceTest()
    test.event_source.fire('a', 'b', 'c', d='d', e='e')
    assert test.handler1_args == ('a', 'b', 'c')

# Generated at 2022-06-17 14:49:01.072486
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:49:06.822029
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:49:16.119838
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_handler_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_handler_called = True

    test_event_source = TestEventSource()

    def test_handler_1(*args, **kwargs):
        pass

    def test_handler_2(*args, **kwargs):
        raise Exception('test_handler_2')

    def test_handler_3(*args, **kwargs):
        raise Exception('test_handler_3')

    test_event_source += test_handler_1
    test_event_source += test_handler_2
    test_event_source += test_handler_3

# Generated at 2022-06-17 14:49:24.442956
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1(a, b):
        assert a == 'a'
        assert b == 'b'

    def handler_2(a, b):
        assert a == 'a'
        assert b == 'b'

    def handler_3(a, b):
        assert a == 'a'
        assert b == 'b'

    def handler_4(a, b):
        assert a == 'a'
        assert b == 'b'
        raise Exception('handler_4')

    def handler_5(a, b):
        assert a == 'a'
        assert b == 'b'
        raise Exception('handler_5')

    def handler_6(a, b):
        assert a == 'a'
        assert b == 'b'
        raise Exception('handler_6')


# Generated at 2022-06-17 14:49:33.503704
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self._handler_1
            self.event_source += self._handler_2
            self.event_source += self._handler_3

        def _handler_1(self, *args, **kwargs):
            self.handler_1_called = True

        def _handler_2(self, *args, **kwargs):
            self.handler_2_called = True

        def _handler_3(self, *args, **kwargs):
            self.handler_3_called = True

    event_source_test = _EventSourceTest()
    event_source_test.event_source.fire()

    assert event_source_test.handler_1_called
    assert event_

# Generated at 2022-06-17 14:49:44.532535
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def handler(self, *args, **kwargs):
            self.fired += 1

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired == 1

# Generated at 2022-06-17 14:49:54.310537
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True

    def handler1(*args, **kwargs):
        raise Exception()

    def handler2(*args, **kwargs):
        raise Exception()

    def handler3(*args, **kwargs):
        raise Exception()

    def handler4(*args, **kwargs):
        raise Exception()

    def handler5(*args, **kwargs):
        raise Exception()

    def handler6(*args, **kwargs):
        raise Exception()


# Generated at 2022-06-17 14:50:05.481233
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    def handler_3(*args, **kwargs):
        raise ValueError('test')

    def handler_4(*args, **kwargs):
        raise ValueError('test')

    def handler_5(*args, **kwargs):
        raise ValueError('test')

    def handler_6(*args, **kwargs):
        raise

# Generated at 2022-06-17 14:51:12.584607
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:51:23.368903
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        raise Exception('test')

    def handler4(*args, **kwargs):
        raise Exception('test')

    def handler5(*args, **kwargs):
        raise Exception('test')

    def handler6(*args, **kwargs):
        raise Exception('test')

    def handler7(*args, **kwargs):
        raise Exception('test')

    def handler8(*args, **kwargs):
        raise Exception('test')

    def handler9(*args, **kwargs):
        raise Exception('test')

    def handler10(*args, **kwargs):
        raise Exception('test')


# Generated at 2022-06-17 14:51:29.620857
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:51:37.637423
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.event_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def _handler(self, *args, **kwargs):
            self.event_fired = True

    tes = _TestEventSource()
    tes += tes._handler
    tes.fire()
    assert tes.event_fired

# Generated at 2022-06-17 14:51:44.347229
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:51:54.198566
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler2(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    def handler3(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler3 exception')

    def handler4(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler4 exception')

    def handler5(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        raise Exception('handler5 exception')


# Generated at 2022-06-17 14:51:56.604493
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:52:00.508701
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    assert handler1 in event_source._handlers
    event_source += handler2
    assert handler2 in event_source._handlers
    event_source += handler1
    assert len(event_source._handlers) == 2


# Generated at 2022-06-17 14:52:09.146786
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

    def handler2():
        pass

    es += handler2
    assert len(es._handlers) == 2
    assert handler in es._handlers
    assert handler2 in es._handlers

    try:
        es += 'not a callable'
        assert False, 'expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-17 14:52:14.448044
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

