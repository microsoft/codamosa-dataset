

# Generated at 2022-06-17 14:43:16.600114
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception = self._on_exception_default

        def _on_exception_default(self, handler, exc, *args, **kwargs):
            return True

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('handler_2')

    def handler_3(*args, **kwargs):
        raise ValueError('handler_3')

    def handler_4(*args, **kwargs):
        raise ValueError('handler_4')

    def handler_5(*args, **kwargs):
        raise ValueError('handler_5')


# Generated at 2022-06-17 14:43:21.085542
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:43:31.596402
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    event_source = TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

    assert event_source._on_exception_called



# Generated at 2022-06-17 14:43:38.551129
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self):
            self.called = False

        def __call__(self):
            self.called = True

    test = Test()
    event = _EventSource()
    event += test

    event.fire()

    assert test.called



# Generated at 2022-06-17 14:43:41.713123
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:43:44.557376
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:43:54.079126
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append(('exception', handler, exc, args, kwargs))
            return False

    def handler_1(*args, **kwargs):
        events.append(('handler_1', args, kwargs))

    def handler_2(*args, **kwargs):
        events.append(('handler_2', args, kwargs))
        raise Exception('handler_2')

    def handler_3(*args, **kwargs):
        events.append(('handler_3', args, kwargs))
        raise Exception('handler_3')

    events

# Generated at 2022-06-17 14:43:58.860568
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event = _EventSource()
            self.event += self.on_event

        def on_event(self, *args, **kwargs):
            pass

    _EventSourceTest()



# Generated at 2022-06-17 14:44:07.586510
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler_2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler_3(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler_4(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler_5(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler_6(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3


# Generated at 2022-06-17 14:44:12.274416
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired

# Generated at 2022-06-17 14:44:18.394134
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:28.550754
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        raise Exception('handler2')

    def handler3(arg1, arg2):
        raise Exception('handler3')

    def handler4(arg1, arg2):
        raise Exception('handler4')

    def handler5(arg1, arg2):
        raise Exception('handler5')

    def handler6(arg1, arg2):
        raise Exception('handler6')

    def handler7(arg1, arg2):
        raise Exception('handler7')

    def handler8(arg1, arg2):
        raise Exception('handler8')

    def handler9(arg1, arg2):
        raise Exception('handler9')

    def handler10(arg1, arg2):
        raise Exception('handler10')


# Generated at 2022-06-17 14:44:31.431760
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event += lambda: None
    event.fire()

# Generated at 2022-06-17 14:44:35.745903
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def handler():
        pass
    es += handler
    assert handler in es._handlers


# Generated at 2022-06-17 14:44:38.884716
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:44:41.257645
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-17 14:44:52.881550
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False
            self._on_exception_return_value = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            self._on_exception_return_value = super(TestEventSource, self)._on_exception(handler, exc, *args, **kwargs)
            return self._on_exception_return_value

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise Exception('handler_2')


# Generated at 2022-06-17 14:45:00.171662
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler
            self.event_source += self.handler_exception
            self.event_source += self.handler_exception_reraise
            self.event_source += self.handler_exception_reraise_reraise
            self.event_source += self.handler_exception_reraise_reraise_reraise
            self.event_source += self.handler_exception_reraise_reraise_reraise_reraise
            self.event_source += self.handler_exception_reraise_reraise_reraise_reraise_reraise
            self.event_source += self.handler_exception_reraise_reraise_reraise_reraise_reraise

# Generated at 2022-06-17 14:45:07.150276
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:45:12.407898
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest:
        def __init__(self):
            self.events = []

        def handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    event_source = _EventSource()
    test = _EventSourceTest()

    event_source += test.handler
    event_source.fire(1, 2, 3, a=4, b=5, c=6)

    assert test.events == [((1, 2, 3), dict(a=4, b=5, c=6))]

# Generated at 2022-06-17 14:45:30.748982
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('handler2')

    def handler3(*args, **kwargs):
        raise ValueError('handler3')

    test_event_source = TestEventSource()
    test_event_source += handler1
    test_event_source += handler2
    test_event_source += handler3

    test_event_source.fire()

    assert test_event_source

# Generated at 2022-06-17 14:45:38.610289
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    def handler3(*args, **kwargs):
        pass

    event_source = TestEventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()

    assert event_source.exception_raised

# Generated at 2022-06-17 14:45:44.433929
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    es = TestEventSource()
    es += es.handler
    es.fire()
    assert es.fired

# Generated at 2022-06-17 14:45:53.689690
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append(('exception', handler, exc, args, kwargs))
            return False

    tes = TestEventSource()

    def handler1(*args, **kwargs):
        tes.events.append(('handler1', args, kwargs))

    def handler2(*args, **kwargs):
        tes.events.append(('handler2', args, kwargs))
        raise ValueError('handler2 exception')

    def handler3(*args, **kwargs):
        tes.events.append(('handler3', args, kwargs))

# Generated at 2022-06-17 14:46:04.488941
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    def handler3(*args, **kwargs):
        raise ValueError('test')

    event_source = MyEventSource()

    # test adding a handler
    event_source += handler1
    assert handler1 in event_source._handlers

    # test adding a handler that is already present
    event_source += handler1

# Generated at 2022-06-17 14:46:16.064011
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    class _TestHandler:
        def __init__(self, raise_exception):
            self._raise_exception = raise_exception

        def __call__(self, *args, **kwargs):
            if self._raise_exception:
                raise ValueError('test exception')

    test_event_source = _TestEventSource()

    test_event_source += _TestHandler(False)
    test_event_source += _TestHandler(True)
    test_event_

# Generated at 2022-06-17 14:46:24.674153
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler1():
        pass

    event_source += handler1
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source -= handler1
    assert len(event_source._handlers) == 1

    event_source -= handler1
    assert len(event_source._handlers) == 1

    event_source -= handler2
    assert len(event_source._handlers) == 0


# Generated at 2022-06-17 14:46:33.139054
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    event_source = TestEventSource()

    def handler1(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == {'a': 3, 'b': 4}

    def handler2(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == {'a': 3, 'b': 4}

    event_source += handler1
    event_source += handler2

    event_source.fire(1, 2, a=3, b=4)



# Generated at 2022-06-17 14:46:40.691914
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2
            self.event_source += self.handler_3
            self.event_source += self.handler_4
            self.event_source += self.handler_5
            self.event_source += self.handler_6
            self.event_source += self.handler_7
            self.event_source += self.handler_8
            self.event_source += self.handler_9
            self.event_source += self.handler_10
            self.event_source += self.handler_11
            self.event_source += self.handler_12
            self.event_source += self.handler_13

# Generated at 2022-06-17 14:46:42.060527
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:01.963346
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-17 14:47:07.527057
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler_1():
        pass

    def handler_2():
        pass

    event_source += handler_1
    event_source += handler_2

    assert handler_1 in event_source._handlers
    assert handler_2 in event_source._handlers



# Generated at 2022-06-17 14:47:15.449220
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler1
            self.event_source += self.handler2
            self.event_source += self.handler3

        def handler1(self, *args, **kwargs):
            pass

        def handler2(self, *args, **kwargs):
            pass

        def handler3(self, *args, **kwargs):
            pass

    _EventSourceTest()


# Generated at 2022-06-17 14:47:25.008741
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler3(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler4(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler5(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler6(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler7(a, b, c):
        assert a == 1
       

# Generated at 2022-06-17 14:47:27.624189
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1



# Generated at 2022-06-17 14:47:32.927700
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:47:33.999050
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:47:41.869342
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire()

    event_source -= handler1
    event_source.fire()

# Generated at 2022-06-17 14:47:46.704582
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self.fired = True

    tes = _TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.fired



# Generated at 2022-06-17 14:47:50.050143
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(a, b=None):
        assert a == 1
        assert b == 2

    def handler2(a, b=None):
        assert a == 3
        assert b == 4

    event_source += handler1
    event_source += handler2

    event_source.fire(1, 2)
    event_source.fire(3, 4)



# Generated at 2022-06-17 14:48:26.280953
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:32.025448
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:48:40.590642
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired

# Generated at 2022-06-17 14:48:46.713829
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self, *args, **kwargs):
            self.fired = True

    es = TestEventSource()
    es += es.handler
    es.fire()
    assert es.fired

# Generated at 2022-06-17 14:48:50.376776
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:48:56.353785
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test with a valid handler
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers

    # Test with an invalid handler
    event_source = _EventSource()
    handler = 'not callable'
    try:
        event_source += handler
        assert False, 'Expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-17 14:49:05.219496
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return False

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    def handler_3(*args, **kwargs):
        raise ValueError('test')

    event_source = _TestEventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    event_source.fire()

    assert event_source._on_exception_

# Generated at 2022-06-17 14:49:09.632705
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-17 14:49:13.134888
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:49:18.591318
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def handler(self):
            self.fired = True

    event_source = TestEventSource()
    event_source += event_source.handler
    event_source.fire()
    assert event_source.fired


# Generated at 2022-06-17 14:50:34.808965
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fired = False

        def handler(self):
            self.event_fired = True

    tes = TestEventSource()
    tes += tes.handler
    tes.fire()
    assert tes.event_fired


# Generated at 2022-06-17 14:50:39.138896
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-17 14:50:48.315604
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        pass

    def handler2(a, b, c):
        pass

    def handler3(a, b, c):
        pass

    def handler4(a, b, c):
        pass

    def handler5(a, b, c):
        pass

    def handler6(a, b, c):
        pass

    def handler7(a, b, c):
        pass

    def handler8(a, b, c):
        pass

    def handler9(a, b, c):
        pass

    def handler10(a, b, c):
        pass

    def handler11(a, b, c):
        pass

    def handler12(a, b, c):
        pass

    def handler13(a, b, c):
        pass


# Generated at 2022-06-17 14:50:53.470808
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(a, b):
        pass

    def handler2(a, b):
        pass

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-17 14:50:56.088139
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-17 14:50:59.302056
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-17 14:51:01.669162
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-17 14:51:10.828947
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.exception_raised = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_raised = True

    tes = _TestEventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        raise ValueError('test')

    def handler_3(*args, **kwargs):
        pass

    tes += handler_1
    tes += handler_2
    tes += handler_3

    tes.fire()

    assert tes.exception_raised
    assert len(tes._handlers) == 3

# Generated at 2022-06-17 14:51:14.792298
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest

    # test that adding a non-callable raises a ValueError
    es = _EventSource()
    with pytest.raises(ValueError):
        es += 'not callable'

    # test that adding a callable does not raise an exception
    es += lambda: None



# Generated at 2022-06-17 14:51:22.622835
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.events = []

        def handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    event_source = _EventSource()
    test = _EventSourceTest()

    event_source += test.handler
    event_source.fire(1, 2, 3, a=4, b=5, c=6)

    assert test.events == [((1, 2, 3), dict(a=4, b=5, c=6))]