

# Generated at 2022-06-21 08:01:28.611298
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler1():
        pass

    def handler2():
        pass

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    assert event_source._handlers == {handler1, handler2}
    event_source -= handler1
    assert event_source._handlers == {handler2}
    event_source -= handler1
    assert event_source._handlers == {handler2}


# Generated at 2022-06-21 08:01:32.823072
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def foo():
        pass

    def bar():
        pass

    # Remove a handler which is not registered
    event -= bar

    # Remove a handler which is registered
    event += foo
    event -= foo

    assert foo not in event._handlers
    assert bar not in event._handlers



# Generated at 2022-06-21 08:01:35.846973
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler():
        return 5

    assert handler not in es._handlers
    es += handler
    assert handler in es._handlers



# Generated at 2022-06-21 08:01:48.243347
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig()
    except Exception as ex:
        assert False, 'Failed to create instance of AnsibleCollectionConfig'

    actual = AnsibleCollectionConfig.collection_finder
    expected = None
    assert actual == expected, 'Expected collection_finder to be None'

    actual = AnsibleCollectionConfig.collection_paths
    expected = []
    assert actual == expected, 'Expected collection_paths to be empty list'

    actual = AnsibleCollectionConfig.default_collection
    expected = None
    assert actual == expected, 'Expected default_collection to be None'

    actual = AnsibleCollectionConfig.on_collection_load
    expected = AnsibleCollectionConfig._on_collection_load
    assert actual == expected, 'Expected on_collaction_load to be _on_collection_load'

    actual = AnsibleCollection

# Generated at 2022-06-21 08:01:54.984945
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    # Test invalid use cases for method __iad__
    event_source = _EventSource()
    try:
        event_source.__iadd__(1)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError for non callable input')

    # Ensure adding handler does not raise exceptions
    event_source += lambda: None

    # Ensure adding handler a second time does not raise exceptions
    event_source += lambda: None


# Unit tests for method __isub__ of class _EventSource

# Generated at 2022-06-21 08:01:56.027319
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    pass


# Generated at 2022-06-21 08:01:58.788513
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # assert
    es = _EventSource()

    # act
    es -= lambda: None

    # assert
    assert not es._handlers


# Generated at 2022-06-21 08:01:59.954761
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig

# Generated at 2022-06-21 08:02:04.131452
# Unit test for constructor of class _EventSource
def test__EventSource():
    class EventSourceTester(object):
        def test(self):
            event_source = _EventSource()
            assert isinstance(event_source, _EventSource)

    tester = EventSourceTester()
    tester.test()


# Generated at 2022-06-21 08:02:10.019389
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    instance = _EventSource()

    def f1(arg1, arg2):
        pass

    def f2(*args, **kwargs):
        pass

    instance += f1
    assert f1 in instance._handlers

    instance -= f1
    assert f1 not in instance._handlers

    instance -= f2
    assert f2 not in instance._handlers

# Generated at 2022-06-21 08:02:17.666312
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source -= handler
    assert len(event_source._handlers) == 0
    assert handler not in event_source._handlers



# Generated at 2022-06-21 08:02:25.471665
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not AnsibleCollectionConfig._collection_finder  # collection_finder is None
    assert not AnsibleCollectionConfig._default_collection  # default_collection is None
    assert isinstance(AnsibleCollectionConfig.collection_finder,
                      property)  # collection_finder is a property object (property or property)
    assert isinstance(AnsibleCollectionConfig.default_collection,
                      property)  # default_collection is a property object (property or property)



# Generated at 2022-06-21 08:02:30.284848
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    mock_callable = object()
    event_source = _EventSource()
    event_source += mock_callable
    assert event_source._handlers == {mock_callable}
    # test that it allows duplicates
    event_source += mock_callable
    assert event_source._handlers == {mock_callable}


# Generated at 2022-06-21 08:02:31.813251
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)


# Generated at 2022-06-21 08:02:39.536312
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEvent:
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    event_source = _EventSource()

    event = TestEvent()
    assert not event.called
    event_source.fire()
    assert not event.called

    event_source += event
    event_source.fire()
    assert event.called

# Generated at 2022-06-21 08:02:43.766069
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda x: x + 1
    event += lambda x: x + 2
    assert len(event._handlers) == 2
    assert callable(event._handlers.pop())


# Generated at 2022-06-21 08:02:56.109034
# Unit test for constructor of class _EventSource
def test__EventSource():
    class TestEventSource(_EventSource):
        def _on_exception(self, exc):
            return False

    # event handler is callable
    event = TestEventSource()
    assert(isinstance(event, TestEventSource))
    assert(isinstance(event, _EventSource))

    def f1():
        pass

    def f2():
        raise Exception("test exception")

    def f3():
        raise Exception("test exception")

    def f4():
        raise Exception("test exception")

    # adding event handlers
    event += f1
    assert(len(event._handlers) == 1)
    assert(f1 in event._handlers)

    # event handler is not callable
    try:
        event += 123
    except ValueError:
        pass
    else:
        assert(False)

# Generated at 2022-06-21 08:03:01.380346
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)

# Generated at 2022-06-21 08:03:02.414663
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:03:05.610601
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    obj = AnsibleCollectionConfig()

    assert isinstance(obj._on_collection_load, _EventSource)
    assert obj._collection_finder is None
    assert obj._default_collection is None

# Generated at 2022-06-21 08:03:14.857914
# Unit test for constructor of class _EventSource
def test__EventSource():
    if not isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource):
        raise AssertionError('AnsibleCollectionConfig._on_collection_load is not an instance of _EventSource')


# Generated at 2022-06-21 08:03:16.728657
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler():
        pass

    event = _EventSource()
    event += handler

    assert handler in event._handlers

    event -= handler

    assert handler not in event._handlers

# Generated at 2022-06-21 08:03:28.139058
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class Handler:
        def handle(self, *args, **kwargs):
            pass

    n_handlers = 3

    handlers = []
    for _ in range(n_handlers):
        handlers.append(Handler())

    # Install a handler which raises an exception
    event_source = _EventSource()

    for handler in handlers:
        event_source += handler.handle

    # Remove handlers
    for handler in handlers[1:]:
        event_source -= handler.handle

    # Ensure that a handler that is not installed cannot be removed
    removed_handler = handlers[0]
    event_source -= removed_handler.handle

    # The remaining handler is the second one
    remaining_handler = handlers[1]

    # Fire the event
    event_source.fire()

    # Ensure the correct handler was called

# Generated at 2022-06-21 08:03:32.800500
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1():
        print('handler1')

    def handler2():
        print('handler2')

    event_source += handler1
    event_source += handler2

    event_source.fire()


# Generated at 2022-06-21 08:03:37.394508
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2

    event_source -= handler2

    assert len(event_source._handlers) == 1



# Generated at 2022-06-21 08:03:40.388922
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    s += lambda x: print(x)
    assert len(s._handlers) == 1
    s += lambda x: print(x)
    assert len(s._handlers) == 1



# Generated at 2022-06-21 08:03:43.661846
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    eventsource = _EventSource()
    eventsource += (lambda: 'foo')
    eventsource -= (lambda: 'foo')
    assert not eventsource._handlers
    eventsource -= (lambda: 'foo')
    assert not eventsource._handlers

# Generated at 2022-06-21 08:03:54.866565
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def dummy_handler():
        pass

    def dummy_handler_that_raises_exception(ex):
        raise ex

    dummy_exception = Exception('dummy')

    es += dummy_handler
    assert dummy_handler in es._handlers

    es -= dummy_handler
    assert dummy_handler not in es._handlers

    es += dummy_handler_that_raises_exception
    assert dummy_handler_that_raises_exception in es._handlers

    es -= dummy_handler_that_raises_exception
    assert dummy_handler_that_raises_exception not in es._handlers

    es += dummy_handler_that_raises_exception
    assert dummy_handler_that_raises_exception in es._handlers


# Generated at 2022-06-21 08:03:56.281160
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()
    assert ev._handlers == set()



# Generated at 2022-06-21 08:04:05.631249
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    e.fire()
    def f1():
        f1.was_called = True
    def f2(x):
        f2.was_called = True
        f2.was_called_with = x
    def f3(*a, **kwa):
        f3.was_called = True
        f3.was_called_with = (a, kwa)
    e += f1
    e += f2
    e += f3
    e.fire(1, a=2, b=3)
    assert f1.was_called
    assert f2.was_called
    assert f2.was_called_with == 1
    assert f3.was_called
    assert f3.was_called_with == ((1,), {'a': 2, 'b': 3})

# Generated at 2022-06-21 08:04:22.293239
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()

    def handler():
        pass

    e += handler

    e -= handler

    assert len(e._handlers) == 0



# Generated at 2022-06-21 08:04:26.889366
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MyCollectionConfig(AnsibleCollectionConfig):
        pass
    assert MyCollectionConfig.collection_finder is None
    assert MyCollectionConfig.default_collection is None
    assert isinstance(MyCollectionConfig.on_collection_load, _EventSource)
    assert MyCollectionConfig.collection_paths is None
    assert MyCollectionConfig.playbook_paths is None

# Generated at 2022-06-21 08:04:39.846778
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible.module_utils.common.collections import AnsibleCollectionConfig
    from ansible.module_utils.common.text.converters import to_bytes
    import shutil
    import tempfile
    import os

    def tempdir():
        # AnsibleCollectionConfig may be used in ansible-test code, which may run on an old Python
        # where tempfile.mkdtemp() returns bytes and not unicode.
        return os.path.normpath(to_bytes(tempfile.mkdtemp()))

    def init_ansible_config(path):
        paths = [path]
        AnsibleCollectionConfig.collection_finder = LocalAnsibleCollectionFinder(paths)
        assert AnsibleCollectionConfig.collection_paths == paths
        assert len(AnsibleCollectionConfig.playbook_paths) == 0
       

# Generated at 2022-06-21 08:04:43.746798
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()
    source += raise_exc_event
    source += do_nothing_event
    source += do_nothing_event
    try:
        source.fire()
    except ValueError:
        pass



# Generated at 2022-06-21 08:04:55.144534
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    class DummyHandler:
        def __init__(self, name, exp_args, exp_kwargs):
            self._name = name
            self._exp_args = exp_args
            self._exp_kwargs = exp_kwargs

        def __call__(self, *args, **kwargs):
            assert self._exp_args == args
            assert self._exp_kwargs == kwargs

    class DummyException(Exception):
        pass

    class TestClass(_EventSource):
        def __init__(self):
            super(TestClass, self).__init__()

            self.foo = 'bar'

    events = TestClass()

    handler1 = DummyHandler('handler1', (), {})
    events += handler1


# Generated at 2022-06-21 08:04:56.647940
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()



# Generated at 2022-06-21 08:05:08.435846
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    working_e = [0]

    def handler():
        working_e[0] += 1

    def bad_handler():
        working_e[0] += 1
        raise RuntimeError('bad handler')

    def bad_handler_2():
        working_e[0] += 1
        raise RuntimeError('bad handler 2')

    def bad_handler_3():
        working_e[0] += 1
        raise RuntimeError('bad handler 3')

    e += handler
    e += handler
    e += bad_handler
    e += handler

    e.fire()
    assert working_e[0] == 4

    working_e[0] = 0

    e -= handler
    e -= bad_handler

    # good handlers should still fire
    e += handler
    # bad handler is removed so we should

# Generated at 2022-06-21 08:05:09.845111
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = _AnsibleCollectionConfig('testmeta', 'testname', 'testbases')



# Generated at 2022-06-21 08:05:11.082945
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    a = _AnsibleCollectionConfig()

# Generated at 2022-06-21 08:05:16.186974
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    meta = type('meta', (object,), {})
    name = 'name'
    bases = (object,)
    type.__init__(meta, name, bases)
    assert meta._collection_finder is None
    assert meta._default_collection is None

# Generated at 2022-06-21 08:05:55.321261
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible_test.mock.collection_loader import mock_collection_config as mc
    from ansible_test.mock.collection_loader import mock_collection_config_event_handler as mcheh

    mc.collection_finder = mcheh.get_collection_finder()

    my_event_source = mc._on_collection_load
    assert my_event_source is not None

    # test invalid input
    try:
        my_event_source -= 7
        assert False, 'AnsibleCollectionConfig._EventSource.__isub__() should have thrown a ValueError'
    except ValueError:
        pass  # expected
    except:
        assert False, 'AnsibleCollectionConfig._EventSource.__isub__() should have thrown a ValueError, but instead threw: {}'.format(sys.exc_info())

    #

# Generated at 2022-06-21 08:05:58.604252
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler = lambda: 1
    event_source += handler
    event_source -= handler
    assert len(event_source._handlers) == 0


# Generated at 2022-06-21 08:06:09.418091
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import lib.ansible.utils.collection_loader.collection_finder

    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

    cf = lib.ansible.utils.collection_loader.collection_finder.AnsibleCollectionFinder('')
    AnsibleCollectionConfig.collection_finder = cf

    assert isinstance(AnsibleCollectionConfig.collection_finder,
                      lib.ansible.utils.collection_loader.collection_finder.AnsibleCollectionFinder)
    assert isinstance(AnsibleCollectionConfig.collection_paths, list)
    assert isinstance(AnsibleCollectionConfig.default_collection, str)

# Generated at 2022-06-21 08:06:14.252297
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evt = _EventSource()
    def func(): pass
    def func2(): raise Exception('')

    evt += func
    evt.fire()
    evt -= func
    evt += func2
    try:
        evt.fire()
    except Exception:
        pass
    else:
        raise AssertionError('_EventSource.fire failed to re-raise an exception from one of its handlers')



# Generated at 2022-06-21 08:06:15.378678
# Unit test for constructor of class _EventSource
def test__EventSource():
    obj = _EventSource()

# Generated at 2022-06-21 08:06:26.020049
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import tempfile
    from ansible.module_utils.collection_loader._collection_finder.filesystem import AnsibleFilesystemCollectionFinder

    test_dir = tempfile.mkdtemp()
    try:
        finder = AnsibleFilesystemCollectionFinder(test_dir)
        AnsibleCollectionConfig.collection_finder = finder
        AnsibleCollectionConfig.default_collection = 'ansible_namespace.collection_name'
    finally:
        import shutil
        shutil.rmtree(test_dir)

    assert AnsibleCollectionConfig.collection_finder == finder
    assert AnsibleCollectionConfig.default_collection == 'ansible_namespace.collection_name'

# Generated at 2022-06-21 08:06:35.821201
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest(object):
        def __init__(self):
            self._on_collection_load = _EventSource()

        def fire(self):
            self._on_collection_load.fire('test_string')

    class _CollectionListener:
        def __init__(self):
            self.arg = None

        def __call__(self, arg):
            self.arg = arg

    listener1 = _CollectionListener()
    listener2 = _CollectionListener()

    test_obj = EventSourceTest()
    test_obj._on_collection_load += listener1
    test_obj._on_collection_load += listener2

    test_obj.fire()

    assert listener1.arg == 'test_string'
    assert listener2.arg == 'test_string'



# Generated at 2022-06-21 08:06:48.414065
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler_a():
        pass
    def handler_b():
        pass

    event_source += handler_a
    event_source += handler_b
    assert handler_a in event_source._handlers
    assert handler_b in event_source._handlers

    event_source -= handler_a
    assert handler_a not in event_source._handlers
    assert handler_b in event_source._handlers

    event_source -= handler_a  # removing a handler that is not present should not fail
    assert handler_a not in event_source._handlers
    assert handler_b in event_source._handlers

    event_source -= handler_b
    assert handler_a not in event_source._handlers
    assert handler_

# Generated at 2022-06-21 08:06:54.345336
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollectionConfig._on_collection_load
    assert AnsibleCollectionConfig._on_collection_load is not None


# Generated at 2022-06-21 08:07:08.107104
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Test:
        pass

    test = Test()
    assert isinstance(test, Test)
    assert not isinstance(test, _AnsibleCollectionConfig)
    assert not hasattr(test, 'collection_finder')
    assert not hasattr(test, 'collection_paths')
    assert not hasattr(test, 'default_collection')
    assert not hasattr(test, 'on_collection_load')
    assert not hasattr(test, 'playbook_paths')

    class Test(_AnsibleCollectionConfig, Test):
        pass

    test = Test()
    assert isinstance(test, Test)
    assert isinstance(test, _AnsibleCollectionConfig)
    assert hasattr(test, 'collection_finder')
    assert hasattr(test, 'collection_paths')

# Generated at 2022-06-21 08:07:40.959506
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.on_collection_load._handlers == set()


# the singleton instance of the class we have defined
_ansible_collection_config = AnsibleCollectionConfig()

# export the singleton so it is directly accessible via the module

# Generated at 2022-06-21 08:07:50.810803
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    def handler_1(*args, **kwargs):
        print('handler_1: args=%s kwargs=%s' % (args, kwargs))

    def handler_2(*args, **kwargs):
        print('handler_2: args=%s kwargs=%s' % (args, kwargs))

    def handler_3(*args, **kwargs):
        print('handler_3: args=%s kwargs=%s' % (args, kwargs))

    def handler_4(*args, **kwargs):
        raise ValueError('test exception')

    def handler_5(*args, **kwargs):
        raise Exception('test exception')

    es += handler_1
    es += handler_2
    es += handler_2  # duplicate handler

# Generated at 2022-06-21 08:07:52.860896
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    try:
        cls = _AnsibleCollectionConfig('test', ('a', 'b'), {'test': 'test'})
    except Exception:
        raise AssertionError('Failed _AnsibleCollectionConfig constructor')

# Generated at 2022-06-21 08:07:54.766085
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)
    assert not AnsibleCollectionConfig._collection_finder
    assert not AnsibleCollectionConfig._default_collection

# Generated at 2022-06-21 08:07:58.093296
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    message = dict(hello='world')

    class EventSource(_EventSource):
        def _on_exception(self, handler, exception, *args, **kwargs):
            raise AssertionError('exception should not be raised: %s' % exception)

    es = EventSource()

    def handler1(msg):
        assert msg == message

    def handler2(msg):
        assert msg == message

    es += handler1
    es += handler2

    es.fire(message)



# Generated at 2022-06-21 08:08:03.779418
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Create a test handler
    def test_handler(param):
        assert param == 'test_param'

    # Construct an _EventSource
    event_source = _EventSource()

    # Add it to the event source
    event_source += test_handler

    # Firing the event should call the handler
    event_source.fire('test_param')


# Generated at 2022-06-21 08:08:05.249736
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert type(config) is AnsibleCollectionConfig

# Generated at 2022-06-21 08:08:08.197331
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventSource = _EventSource()
    eventSource += lambda: print('test0')
    eventSource += lambda: print('test1')

    eventSource.fire()

# Generated at 2022-06-21 08:08:17.619331
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths.fset, property)

    # cannot assign AnsibleCollectionConfig.collection_finder more than once
    AnsibleCollectionConfig.collection_finder = 1
    try:
        AnsibleCollectionConfig.collection_finder = 2
    except ValueError:
        pass
    else:
        raise Exception('Assigning to AnsibleCollectionConfig.collection_finder twice did not raise ValueError')

   

# Generated at 2022-06-21 08:08:21.553119
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig('meta', 'TestClass', tuple())
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert isinstance(cls._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:09:24.945268
# Unit test for constructor of class _EventSource
def test__EventSource():
    def f():
        pass

    assert hasattr(_EventSource(), '__iadd__')
    assert hasattr(_EventSource(), '__isub__')

    a = _EventSource()
    a += f

    b = _EventSource()
    b -= f

    c = _EventSource()
    c += f

    e = _EventSource()
    with pytest.raises(ValueError):
        e += 1
    

# Generated at 2022-06-21 08:09:27.492864
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:09:31.511790
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    assert e._handlers == set()

    def f():
        pass

    e += f
    assert e._handlers == {f}

    e -= f
    assert e._handlers == set()

    e -= f
    assert e._handlers == set()



# Generated at 2022-06-21 08:09:34.658081
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-21 08:09:37.566633
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.playbook_paths == []

# Generated at 2022-06-21 08:09:39.818128
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class X(_AnsibleCollectionConfig):
        pass

    # instantiate class
    X()



# Generated at 2022-06-21 08:09:47.764186
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        event_args.append(args)
        event_kwargs.append(kwargs)

    def handler2(*args, **kwargs):
        raise NotImplementedError()

    event_args = []
    event_kwargs = []

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire(1, 2, 3, arg1='a', arg2='b', arg3='c')

    assert event_args == [(1, 2, 3)]
    assert event_kwargs == [{'arg1': 'a', 'arg2': 'b', 'arg3': 'c'}]


# Generated at 2022-06-21 08:09:49.667314
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert len(event._handlers) == 0
    assert callable(event)


# Generated at 2022-06-21 08:09:53.914436
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    es -= 'foo'
    try:
        es -= es
    except:
        raise AssertionError('Unit test for method __isub__ of class _EventSource failed')


# Generated at 2022-06-21 08:09:57.781629
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    expected_index = 0
    actual_index = 0
    event = _EventSource()

    # Act
    event += lambda index: expected_index
    event.fire()

    # Assert
    assert actual_index == expected_index