

# Generated at 2022-06-21 08:01:23.622462
# Unit test for constructor of class _EventSource
def test__EventSource():
    obj = _EventSource()
    assert obj is not None
    assert obj._handlers is not None

# Generated at 2022-06-21 08:01:31.627055
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    calls = []

    def handler1(foo='foo'):
        calls.append(('handler1', foo))

    def handler2(foo='foo'):
        calls.append(('handler2', foo))
        raise Exception('expected test exception')

    es += handler1
    es += handler2

    try:
        es.fire(foo='bar')
        assert False, 'expected exception'
    except Exception as ex:
        assert ex.args == ('expected test exception',)

    assert calls == [('handler1', 'bar'), ('handler2', 'bar')]

# Generated at 2022-06-21 08:01:43.769560
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def run_method(actual, expected, exc=None):
        if exc:
            raise exc
        assert actual == expected

    def handler_1(first, second):
        run_method(first, first)
        run_method(second, second)

    def handler_2(third):
        run_method(third, third)

    def handler_3(fourth):
        run_method(fourth, fourth)

    def handler_4(fifth):
        run_method(fourth, fifth, TestException())

    source = _EventSource()
    source += handler_1
    source += handler_2
    source += handler_3
    source += handler_4

    source.fire(1, 2, 3, 4)

    raised_exception = False

# Generated at 2022-06-21 08:01:48.089822
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _event_source = _EventSource()

    def test_handler(*args, **kwargs):
        pass

    _event_source += test_handler

    assert len(_event_source._handlers) == 1



# Generated at 2022-06-21 08:01:55.086198
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class DummyClass:
        pass

    dummy = DummyClass()
    dummy.method = DummyClass()
    dummy.method.__call__ = DummyClass()
    dummy.method.__call__.__call__ = DummyClass()
    dummy.method.__call__.__call__.__call__ = lambda: None

    event_source = _EventSource()
    event_source += dummy.method
    event_source -= dummy.method.__call__.__call__
    event_source -= dummy.method.__call__.__call__

    assert not _EventSource._handlers

# Generated at 2022-06-21 08:01:59.647636
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    class TestException(Exception):
        pass

    def handler():
        pass

    event_source += handler
    event_source += handler
    event_source -= handler
    event_source -= handler

    try:
        handler()
    except TestException:
        pass

# Generated at 2022-06-21 08:02:02.360458
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config.collection_finder is None
    assert config.default_collection is None



# Generated at 2022-06-21 08:02:04.031266
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda: None



# Generated at 2022-06-21 08:02:07.513675
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Use as context manager for EventSource
    class EventContext:
        def __init__(self, s, *args, **kwargs):
            self._s = s
            self._args = args
            self._kwargs = kwargs

        def __enter__(self):
            self._fired = False

        def __exit__(self, exc_type, exc_val, exc_tb):
            self._s.fire(*self._args, **self._kwargs)
            self._fired = True

    class Handler:
        def __init__(self):
            self._handled = False

        def __call__(self):
            self._handled = True

    def test_handler(exc=None, *args, **kwargs):
        return True

    s = _EventSource()
    h = Handler()


# Generated at 2022-06-21 08:02:09.190777
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # test that we can create a class instance
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:02:18.811621
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    handler1 = lambda: None
    handler2 = lambda: None

    calls = [0, 0]

    def anon_handler1():
        calls[0] += 1

    def anon_handler2():
        calls[1] += 1

    event = _EventSource()
    event += anon_handler1
    event += anon_handler2

    assert calls[0] == 0
    assert calls[1] == 0

    event.fire()
    assert calls[0] == 1
    assert calls[1] == 1

    event.fire()
    assert calls[0] == 2
    assert calls[1] == 2


# Generated at 2022-06-21 08:02:26.754976
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Initialize an EventSource object
    es = _EventSource()

    # Initialize event handlers
    def event_handler_1():
        pass

    def event_handler_2():
        pass

    # Add event handlers
    es += event_handler_1
    es += event_handler_2

    # Remove all event handlers
    es -= event_handler_1
    es -= event_handler_2

    # Set of handlers should be empty
    assert len(es._handlers) == 0


# Generated at 2022-06-21 08:02:27.895876
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_event_source = _EventSource()
    assert isinstance(test_event_source, _EventSource)


# Generated at 2022-06-21 08:02:31.324617
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    assert len(source._handlers) == 0
    handler = lambda: None
    source += handler
    assert len(source._handlers) == 1
    source -= handler
    assert len(source._handlers) == 0

# Generated at 2022-06-21 08:02:34.165847
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.playbook_paths is None

# Generated at 2022-06-21 08:02:42.846638
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    h = lambda: None

    es += h
    assert h in es._handlers
    assert len(es._handlers) == 1

    es += h
    assert h in es._handlers
    assert len(es._handlers) == 1

    es -= h
    assert h not in es._handlers
    assert len(es._handlers) == 0

    try:
        es += None
        assert False, 'Expected exception'
    except ValueError:
        pass



# Generated at 2022-06-21 08:02:49.118449
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')
    assert not hasattr(AnsibleCollectionConfig, '_on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')



# Generated at 2022-06-21 08:02:55.586085
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    test = []

    def handler(*args, **kwargs):
        test.append((args, kwargs))

    event += handler
    event.fire('this', 'is', 'my', 'args', foo='bar', bar='baz')

    assert test == [((), {'args': ('this', 'is', 'my', 'args'), 'foo': 'bar', 'bar': 'baz'})]



# Generated at 2022-06-21 08:02:56.816582
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-21 08:02:57.874671
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-21 08:03:08.531417
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Given a variable e_s with value instance of _EventSource
    e_s = _EventSource()
    # And a handler
    def handler():
        pass
    # When I add the handler in e_s
    e_s += handler
    # And I remove the handler in e_s
    e_s -= handler
    # Then the handlers of e_s is empty list
    assert not e_s._handlers


# Generated at 2022-06-21 08:03:17.863860
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def f1():
        return 1

    def f2():
        return 2

    def f3():
        return 3

    def f4():
        return 4

    def f5():
        return 5

    def f6():
        return 6

    es = _EventSource()
    assert es._handlers == set()
    es += f1
    es += f2
    es += f3
    assert es._handlers == {f1, f2, f3}
    es += f1
    es += f2
    es += f3
    assert es._handlers == {f1, f2, f3}
    es += f4
    es += f5
    es += f6
    assert es._handlers == {f1, f2, f3, f4, f5, f6}
    es += f

# Generated at 2022-06-21 08:03:22.360578
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Unit tests for properties of class AnsibleCollectionConfig
# (except for on_collection_load)

# Generated at 2022-06-21 08:03:24.600731
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    handler = lambda: None
    event += handler



# Generated at 2022-06-21 08:03:25.287630
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:03:27.879045
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None


# Generated at 2022-06-21 08:03:32.099899
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    assert len(e._handlers) == 0

    def test_func():
        pass

    e += test_func
    e -= test_func
    assert len(e._handlers) == 0


# Generated at 2022-06-21 08:03:34.762853
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0
    es += lambda: None
    assert len(es._handlers) == 1



# Generated at 2022-06-21 08:03:39.858554
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler1():
        raise RuntimeError('handler1 called')

    def handler2():
        raise RuntimeError('handler2 called')

    def handler3():
        raise RuntimeError('handler3 called')

    es = _EventSource()
    es += handler1
    es += handler2
    es += handler3

    len(es._handlers) == 3

    es -= handler2

    len(es._handlers) == 2

# Generated at 2022-06-21 08:03:50.818572
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def raise_exception(*args, **kwargs):
        raise Exception('oops')
    def return_false(*args, **kwargs):
        return False  # pragma: no cover

    def do_test(expect, *handlers):
        fired = []
        for h in handlers:
            fired.append(False)

        class MySource(_EventSource):
            def _on_exception(source, handler, ex, *args, **kwargs):
                fired[handlers.index(handler)] = True
                return False

        source = MySource()

        for handler in handlers:
            source += handler

        try:
            source.fire()
        except Exception as ex:
            pass

        if fired != expect:
            raise AssertionError(fired)

    yield do_test, [True], raise_exception
    yield

# Generated at 2022-06-21 08:04:06.219781
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    class TestException(Exception):
        pass

    class TestException2(Exception):
        pass

    def handler2(msg):
        raise TestException2(msg)

    def handler1(msg):
        raise TestException(msg)

    event_source += handler1
    event_source += handler2

    try:
        event_source.fire('test')
        assert False, 'TestException expected'
    except TestException as e:
        # Test that the exception raised by handler2 is propagated
        assert isinstance(e.__cause__, TestException2)

    event_source -= handler2


# Generated at 2022-06-21 08:04:07.399681
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, type)
    assert issubclass(AnsibleCollectionConfig, object)

# Generated at 2022-06-21 08:04:11.545667
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=unused-variable, invalid-name
    test_instance = object.__new__(_AnsibleCollectionConfig)
    assert test_instance._collection_finder is None
    assert test_instance._default_collection is None
    assert test_instance._on_collection_load

# Generated at 2022-06-21 08:04:23.761550
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []

    def f1(a, b, c='d', **kwargs):
        calls.append(('f1', a, b, c, kwargs))

    def f2(a, b, c='d', **kwargs):
        calls.append(('f2throw', a, b, c, kwargs))
        raise ValueError('f2throw')

    def f3(a, b, c='d', **kwargs):
        calls.append(('f3throw', a, b, c, kwargs))
        raise ValueError('f3throw')

    def f4(a, b, c='d', **kwargs):
        calls.append(('f4', a, b, c, kwargs))

    i = _EventSource()
    i += f1
    i += f2


# Generated at 2022-06-21 08:04:26.928708
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import ansible.utils.collection_loader.legacy._ansible_collection_config
    assert issubclass(_AnsibleCollectionConfig, type(ansible.utils.collection_loader.legacy._ansible_collection_config.AnsibleCollectionConfig))

# Generated at 2022-06-21 08:04:30.697448
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # setup
    event_source = _EventSource()
    handler = lambda: None

    # test
    event_source -= handler

    # assert
    assert handler not in event_source._handlers


# Generated at 2022-06-21 08:04:33.950350
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(value):
        assert value == 'value'

    event_source = _EventSource()
    event_source += handler

    event_source.fire('value')



# Generated at 2022-06-21 08:04:37.711240
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import ansible.utils.collection_loader
    assert issubclass(ansible.utils.collection_loader.AnsibleCollectionConfig, with_metaclass(_AnsibleCollectionConfig))



# Generated at 2022-06-21 08:04:38.895919
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()



# Generated at 2022-06-21 08:04:50.281137
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Handler:
        def __init__(self):
            self._errors = []

        def __call__(self, *args, **kwargs):
            if args:
                raise Exception(args[0])
            else:
                raise Exception()

        def _on_exception(self, exc):
            self._errors.append(exc)
            return True

    class Source(_EventSource):
        def __init__(self):
            super(Source, self).__init__()
            self.handler1 = Handler()
            self.handler2 = Handler()
            self.handler3 = Handler()
            self += self.handler1
            self += self.handler2
            self += self.handler3
            self.fired = False

    source = Source()
    source.fire('foo')
    assert len(source.handler1._errors)

# Generated at 2022-06-21 08:05:09.200900
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        pass

    event_source = TestEventSource()


    class TestCollectionLoadEventHandler:
        def __init__(self, event_source):
            self._triggered = False

            event_source += self.on_event

        def on_event(self):
            self._triggered = True

    handler = TestCollectionLoadEventHandler(event_source)

    event_source.fire()

    assert handler._triggered

# Generated at 2022-06-21 08:05:10.871635
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(type(AnsibleCollectionConfig), _AnsibleCollectionConfig)

# Generated at 2022-06-21 08:05:14.218066
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source += lambda: None
    assert len(source._handlers) == 1


# Generated at 2022-06-21 08:05:23.702097
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    on_collection_load = AnsibleCollectionConfig.on_collection_load
    assert len(on_collection_load._handlers) == 0

    def handler1():
        pass
    on_collection_load += handler1
    assert len(on_collection_load._handlers) == 1
    on_collection_load -= handler1
    assert len(on_collection_load._handlers) == 0

    def handler2():
        pass
    on_collection_load += handler2
    assert len(on_collection_load._handlers) == 1
    on_collection_load -= handler2
    assert len(on_collection_load._handlers) == 0

# Generated at 2022-06-21 08:05:27.519823
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert len(AnsibleCollectionConfig.on_collection_load._handlers) == 0
    assert AnsibleCollectionConfig.playbook_paths == []
    # assert setattr(AnsibleCollectionConfig, 'collection_finder', 1) raises ValueError
    # assert setattr(AnsibleCollectionConfig, 'default_collection', 1) raises ValueError
    # assert setattr(AnsibleCollectionConfig, 'on_collection_load', 1) raises ValueError
    # assert setattr(AnsibleCollectionConfig, 'playbook_paths', 1) raises ValueError

# Generated at 2022-06-21 08:05:28.779307
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    print(e)



# Generated at 2022-06-21 08:05:32.785138
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    m = _AnsibleCollectionConfig('meta', 'name', 'bases')

    assert isinstance(m, _AnsibleCollectionConfig)
    assert m._collection_finder is None
    assert m._default_collection is None
    assert isinstance(m._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:05:38.158970
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    callback = lambda: 'callback'

    if event_source._on_exception(callback, Exception(), 'arg1', 'arg2'):
        raise Exception('illegal state')

    if event_source.fire('arg1', 'arg2'):
        raise Exception('illegal state')

    event_source += callback

    if event_source.fire('arg1', 'arg2') != 'callback':
        raise Exception('illegal state')

    event_source -= callback

    if event_source.fire('arg1', 'arg2'):
        raise Exception('illegal state')



# Generated at 2022-06-21 08:05:42.500628
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # _AnsibleCollectionConfig.__init__
    try:
        t = AnsibleCollectionConfig()
    except TypeError:
        # base class of AnsibleCollectionConfig cannot be instantiated
        pass
    else:
        raise AssertionError('expected TypeError')


# Generated at 2022-06-21 08:05:44.343602
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event += lambda *args: None
    event.fire()

# Generated at 2022-06-21 08:06:13.721358
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert not AnsibleCollectionConfig.collection_paths
    assert not AnsibleCollectionConfig.playbook_paths
    assert not AnsibleCollectionConfig.on_collection_load._handlers



# Generated at 2022-06-21 08:06:23.645168
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class S(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return True

    def a(*args, **kwargs):
        assert args == (2, 3)
        assert kwargs == {'x': 4, 'y': 5}
        return 10

    def b(*args, **kwargs):
        assert False

    s = S()
    s += a
    s += b
    s -= b
    assert s.fire(2, 3, x=4, y=5) == 10

# Generated at 2022-06-21 08:06:34.677087
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    # Test no handler
    event_source.fire()

    # Test single handler
    calls = []
    event_source += lambda: calls.append(1)
    event_source.fire()
    assert calls == [1]

    # Test multiple handlers
    calls = []
    event_source += lambda: calls.append(2)
    event_source.fire()
    assert calls == [1, 2]

    # Test exception in handler
    calls = []
    event_source = _EventSource()
    event_source._on_exception = lambda handler, exc, *args, **kwargs: False
    event_source += lambda: calls.append(1)
    event_source += lambda: 1/0
    event_source.fire()
    assert calls == [1]

    # Test exception

# Generated at 2022-06-21 08:06:40.555361
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    handler = lambda: None

    event_source += handler

    assert handler in event_source._handlers

    with pytest.raises(ValueError) as err:
        event_source += ''

    assert "handler must be callable" in to_text(err)



# Generated at 2022-06-21 08:06:42.136273
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()



# Generated at 2022-06-21 08:06:53.744569
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.utils.collection_loader import _EventSource

    def handler():
        pass

    e = _EventSource()
    e += handler

    # this happens as part of the load process
    e.fire()

    # remove the handler, refiring should produce no output
    e -= handler
    stdout = cStringIO()
    with open('/dev/null', 'ab') as devnull:
        if PY3:
            import sys
            fake_stdout = sys.stdout
            sys.stdout = stdout


# Generated at 2022-06-21 08:06:58.630022
# Unit test for constructor of class _EventSource
def test__EventSource():
    expected_value = "expected_value"

    class TestEvent(_EventSource):
        pass

    def test_method(result):
        assert result == expected_value, "incorrect result in test_method"

    event = TestEvent()
    event += test_method
    event.fire(expected_value)

    # test subtracting same handler
    event -= test_method
    event -= test_method

    # test subtracting different handler
    event += test_method
    event -= test_method
    event -= test_method

# Generated at 2022-06-21 08:07:09.525393
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Hunter(AnsibleCollectionConfig):
        pass

    assert isinstance(Hunter._collection_finder, _EventSource)
    assert Hunter._default_collection is None

    assert callable(Hunter.collection_finder.__get__(None, Hunter))
    assert callable(Hunter.collection_finder.__set__(None, Hunter, None))
    try:
        Hunter.collection_finder.__set__(None, Hunter, None)
        assert False, 'Expected exception did not happen'
    except ValueError:
        pass

    assert callable(Hunter.default_collection.__get__(None, Hunter))
    assert callable(Hunter.default_collection.__set__(None, Hunter, None))

    assert callable(Hunter.on_collection_load.__get__(None, Hunter))

# Generated at 2022-06-21 08:07:19.386653
# Unit test for constructor of class _EventSource
def test__EventSource():
    import numbers

    _EventSource()

    def func():
        pass

    s = _EventSource()

    s += func

    assert func in s._handlers, 'func not in handlers'

    s -= func

    assert func not in s._handlers, 'func still in handlers'

    def handler(self, instance, exc, *args, **kwargs):
        return True

    class HandlerClass:
        @classmethod
        def handler(cls, instance, exc, *args, **kwargs):
            return True

    s._on_exception = handler
    assert s._on_exception(handler, None, 1, 2, 3, a=1, b=2, c=3)

# Generated at 2022-06-21 08:07:22.199697
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    obj = AnsibleCollectionConfig()
    assert obj.on_collection_load is obj._on_collection_load
    assert obj.default_collection is None
    assert obj.collection_finder is None


# Generated at 2022-06-21 08:07:51.228545
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    x = _AnsibleCollectionConfig()
    assert x._collection_finder is None
    assert x._default_collection is None
    assert isinstance(x._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:07:57.655674
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def callable_function(who):
        print('calls function: {0}'.format(who))

    def callable_method(who, self):
        print('calls method: {0} {1}'.format(who, self))

    # do not use EventHandler(cls) or object.__new__(cls)
    # because of a Python bug: https://bugs.python.org/issue34194
    # and because the class is a metaclass
    obj = _EventSource()

    # test function registration
    obj += callable_function
    assert len(obj._handlers) == 1

    # test method registration
    obj += callable_method
    assert len(obj._handlers) == 2

    # test duplicate registration equivalent to no registration
    obj += callable_function

# Generated at 2022-06-21 08:08:08.900620
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Event:
        def __init__(self, name=None, value=None):
            self.name = name
            self.value = value

    class _Receiver:
        def __init__(self):
            self.events = []

        def handler(self, event):
            self.events.append(event)

    e = _EventSource()
    r1 = _Receiver()
    r2 = _Receiver()
    e += r1.handler
    e += r2.handler
    e.fire(_Event('name', 'value'))
    assert len(r1.events) == 1
    assert len(r2.events) == 1
    assert r1.events[0].name == 'name'
    assert r1.events[0].value == 'value'
    assert r2.events[0].name

# Generated at 2022-06-21 08:08:18.141500
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fired = []

    class Foo:
        def __init__(self, x):
            self.x = x

        def __call__(self, value):
            fired.append((self.x, value))

    foo1 = Foo('foo1')
    foo2 = Foo('foo2')
    foo3 = Foo('foo3')

    event_source = _EventSource()
    event_source += foo1
    event_source += foo2

    event_source.fire('bar')
    assert fired == [('foo1', 'bar'), ('foo2', 'bar')]

    event_source -= foo1
    event_source.fire('baz')
    assert fired == [('foo1', 'bar'), ('foo2', 'bar'), ('foo2', 'baz')]

    event_source = _EventSource()
    event_

# Generated at 2022-06-21 08:08:23.913832
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def dummy1(param):
        assert param == 'dummy1'

    def dummy2(param):
        assert param == 'dummy2'

    my_event_source = _EventSource()
    my_event_source += dummy1
    my_event_source += dummy2
    my_event_source.fire('dummy1')
    my_event_source.fire('dummy2')

# Generated at 2022-06-21 08:08:28.025340
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.collection_paths is None
    assert config.default_collection is None
    assert config.on_collection_load is not None
    assert config.playbook_paths is None

# Generated at 2022-06-21 08:08:29.256247
# Unit test for constructor of class _EventSource
def test__EventSource():
    actual = _EventSource()

    assert not actual._handlers


# Generated at 2022-06-21 08:08:33.360393
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert isinstance(ac._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:08:43.821470
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Exercise the following cases:
    #
    # 1) Add a method / function
    # 2) Add a non-callable
    # 3) Add a callable with the wrong number of parameters
    # 4) Add the same method / function twice

    class TestClass:
        def test_meth(self):
            pass

    tc = TestClass()
    es = _EventSource()

    import functools
    # case 1
    es += tc.test_meth
    es += functools.partial(tc.test_meth)

    # case 2
    try:
        es += tc
        assert False
    except ValueError:
        pass

    # case 3
    try:
        es += functools.partial(tc.test_meth, 1)
        assert False
    except ValueError:
        pass



# Generated at 2022-06-21 08:08:49.628880
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler1(*args, **kwargs):
        raise ValueError('Test exception')

    def handler2(*args, **kwargs):
        raise RuntimeError('Test exception')

    def handler3(*args, **kwargs):
        raise RuntimeError('Test exception')

    event_source = _EventSource()
    event_source += handler1 + handler2 + handler3
    event_source.fire()

# Generated at 2022-06-21 08:09:47.937844
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    __test__ = True

    src = _EventSource()
    arr = []

    def handler(x):
        arr.append(x)

    src += handler
    src.fire(5)
    assert arr == [5]

    src -= handler
    src.fire(10)
    assert arr == [5]



# Generated at 2022-06-21 08:09:49.215203
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Mock for C extension that provides functions for testing

# Generated at 2022-06-21 08:09:58.506617
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    execution_context = dict(
        executions=0,
        handler_error=None,
    )

    def handler1(arg):
        execution_context['executions'] += 1
        assert arg == 'foo'

    def handler2(arg):
        execution_context['executions'] += 1
        assert arg == 'foo'
        raise AttributeError('boom')

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    try:
        event_source.fire('foo')
    except AttributeError as ex:
        assert str(ex) == 'boom'
    else:
        assert False
    assert execution_context['executions'] == 2
    execution_context['executions'] = 0
    event_source -= handler2
    event_source.fire('foo')


# Generated at 2022-06-21 08:10:03.041800
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class SimpleEvent(_EventSource):
        def __init__(self):
            _EventSource.__init__(self)

        def fire(self):
            _EventSource.fire(self)

    def handler(*args, **kwargs):
        pass

    event = SimpleEvent()
    assert event._on_exception is _EventSource._on_exception
    event += handler
    event.fire()


# Generated at 2022-06-21 08:10:11.286644
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # test removing a handler that does not exist
    event = _EventSource()
    bad_handler = lambda: None
    event -= bad_handler

    # test removing a handler that does exist
    def handler1():
        return 1
    def handler2():
        return 2

    event += handler1
    event += handler2

    event -= handler2
    assert handler1 in event._handlers
    assert handler2 not in event._handlers
    assert len(event._handlers) == 1

    # test on_collection_load can be deleted properly
    handler1_obj = handler1
    handler2_obj = handler2

    AnsibleCollectionConfig.on_collection_load += handler1_obj
    AnsibleCollectionConfig.on_collection_load += handler2_obj

    AnsibleCollectionConfig.on_collection_load -= handler2_obj
   

# Generated at 2022-06-21 08:10:19.386420
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    dispatcher = _EventSource()
    fired = False

    def on_event(b):
        assert b

    dispatcher += on_event
    assert on_event in dispatcher._handlers

    dispatcher += on_event
    assert on_event in dispatcher._handlers

    def on_event_exc(b):
        assert b
        raise ValueError('x')

    with pytest.raises(ValueError):
        dispatcher += on_event_exc

    dispatcher.fire(True)
    assert fired


# Generated at 2022-06-21 08:10:20.369779
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig()

# Generated at 2022-06-21 08:10:22.615234
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def handler(event, value):
        pass

    event += handler



# Generated at 2022-06-21 08:10:23.535011
# Unit test for constructor of class _EventSource
def test__EventSource():
    x = _EventSource()


# Generated at 2022-06-21 08:10:24.177992
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()