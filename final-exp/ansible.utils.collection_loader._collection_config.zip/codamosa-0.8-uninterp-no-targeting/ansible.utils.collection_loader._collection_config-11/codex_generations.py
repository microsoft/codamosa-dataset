

# Generated at 2022-06-21 08:01:23.584841
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler1(): pass
    es += handler1
    assert handler1 in es._handlers


# Generated at 2022-06-21 08:01:31.207031
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler1(*args, **kwargs):
        pass
    def handler2(*args, **kwargs):
        pass

    event_source = _EventSource()
    assert 0 == len(event_source._handlers)

    event_source += handler1
    assert 1 == len(event_source._handlers)

    event_source -= handler1
    assert 0 == len(event_source._handlers)

    event_source += handler2
    assert 1 == len(event_source._handlers)

    event_source -= handler2
    assert 0 == len(event_source._handlers)

# Generated at 2022-06-21 08:01:36.474868
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class MyAnsibleCollectionConfig(AnsibleCollectionConfig):
        pass

    if MyAnsibleCollectionConfig.collection_finder:
        raise ValueError('collection_finder should be None')

    if MyAnsibleCollectionConfig.default_collection:
        raise ValueError('default_collection should be None')



# Generated at 2022-06-21 08:01:41.365342
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Setup
    event_handler = lambda *args, **kwargs: None
    source = _EventSource()

    # Test
    source += event_handler
    assert event_handler in source._handlers

    source -= event_handler
    assert event_handler not in source._handlers


# Generated at 2022-06-21 08:01:52.613423
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def h1(*args, **kwargs):
        assert args[0] == 'arg1'
        assert args[1] == 'arg2'
        assert kwargs['kwarg1'] == 'kwarg1'
        assert kwargs['kwarg2'] == 'kwarg2'
        kwargs['h1_ran'] = True

    def h2(*args, **kwargs):
        assert args[0] == 'arg1'
        assert args[1] == 'arg2'
        assert kwargs['kwarg1'] == 'kwarg1'
        assert kwargs['kwarg2'] == 'kwarg2'
        kwargs['h2_ran'] = True

    def h3(*args, **kwargs):
        assert args[0] == 'arg1'

# Generated at 2022-06-21 08:01:54.671726
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert isinstance(e, _EventSource)
    assert callable(e.fire)


# Generated at 2022-06-21 08:01:55.679810
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()

# Generated at 2022-06-21 08:02:07.660986
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import tests.unit.lib.ansible_test._util.target.legacy_collection_loader.fixtures.ansible_collections as fixtures

    # Unit test for the constructor of class _AnsibleCollectionConfig
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')
    assert not hasattr(AnsibleCollectionConfig, '_on_collection_load')

    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

    # Unit test that the _AnsibleCollectionConfig metaclass is working as expected.
    assert AnsibleCollectionConfig is not fixtures.class_AnsibleCollectionConfig

# Generated at 2022-06-21 08:02:10.976029
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    es += lambda: 'foo'

    assert len(es._handlers) == 1
    assert es._handlers.pop()() == 'foo'


# Generated at 2022-06-21 08:02:15.142119
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert isinstance(event_source._handlers, set)
    assert callable(event_source) is False
    assert callable(event_source._on_exception) is True
    assert callable(event_source.fire) is True


# Generated at 2022-06-21 08:02:23.647567
# Unit test for constructor of class _EventSource
def test__EventSource():
    def test_callable(arg):
        pass

    o = _EventSource()
    o += test_callable
    o -= test_callable
    o += test_callable
    o -= test_callable

python2_only = None
python3_only = None

# Generated at 2022-06-21 08:02:24.799017
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()

# Generated at 2022-06-21 08:02:31.813115
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def foo():
        pass

    es += foo
    assert len(es._handlers) == 1
    assert foo in es._handlers

    es += foo
    assert len(es._handlers) == 1
    assert foo in es._handlers

    def bar():
        pass

    es += bar
    assert len(es._handlers) == 2
    assert foo in es._handlers
    assert bar in es._handlers



# Generated at 2022-06-21 08:02:35.545165
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def event_handler(event):
        pass

    x = _EventSource()

    x += event_handler

    assert event_handler in x._handlers



# Generated at 2022-06-21 08:02:44.135781
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = _AnsibleCollectionConfig('meta', 'name', 'bases')
    c._collection_finder = '_collection_finder'
    c._default_collection = '_default_collection'
    c._on_collection_load = '_on_collection_load'

    assert c._collection_finder == '_collection_finder'
    assert c._default_collection == '_default_collection'
    assert c._on_collection_load == '_on_collection_load'

# Unit tests for getters and setters on class AnsibleCollectionConfig

# Generated at 2022-06-21 08:02:46.210946
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    source -= source.fire
    assert source._handlers == set()


# Generated at 2022-06-21 08:02:53.911992
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    target = _EventSource()
    assert len(target._handlers) == 0

    def handler1(x):
        pass

    def handler2(x):
        pass

    target += handler1
    target += handler2
    assert len(target._handlers) == 2

    target -= handler2
    assert len(target._handlers) == 1

    target -= handler2
    assert len(target._handlers) == 1



# Generated at 2022-06-21 08:03:01.762621
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    # via method __iadd__, add handler1 to source.
    source += handler1

    # via method __iadd__, add handler2 to source.
    source += handler2

    # via method __isub__, remove handler1 from source.
    source -= handler1

    # via method _fire, fire source, handler1 should not be called.
    # handler2 should be called with arg1, arg2, and kwarg3=3.
    source.fire('arg1', 'arg2', kwarg3=3)



# Generated at 2022-06-21 08:03:10.381053
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    def handler1(event):
        pass

    def handler2(event):
        pass

    source.fire()

    source += handler1
    source.fire()

    source += handler2
    source.fire()

    source += handler1
    source.fire()

    source -= handler1
    source.fire()

    source -= handler2
    source.fire()

    source -= handler2
    source.fire()

    source -= handler1
    source.fire()

    source -= handler1
    source.fire()

# Generated at 2022-06-21 08:03:11.886494
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)

# Generated at 2022-06-21 08:03:18.840293
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac_config = AnsibleCollectionConfig()
    assert ac_config.collection_finder is None
    assert ac_config.default_collection is None
    assert isinstance(ac_config.on_collection_load, _EventSource)
    assert ac_config.playbook_paths is None

# Generated at 2022-06-21 08:03:20.034777
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig is not None

# Generated at 2022-06-21 08:03:22.832453
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config.collection_finder is None
    assert config.on_collection_load is config._on_collection_load



# Generated at 2022-06-21 08:03:26.882234
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()
    assert ansible_collection_config.collection_finder is None
    assert ansible_collection_config.default_collection is None
    assert ansible_collection_config.on_collection_load is not None

# Generated at 2022-06-21 08:03:38.045072
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # assert: class has no _collection_finder property set
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')

    # assert: class has no _default_collection property set
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')

    # assert: class has no _on_collection_load property set
    assert not hasattr(AnsibleCollectionConfig, '_on_collection_load')

    # NOTE: properties cannot be directly set, they must be set using the "property.setter"
    # assert: cannot directly set '_collection_finder'
    #assert: cannot directly set '_default_collection'
    #assert: cannot directly set '_on_collection_load'

# Generated at 2022-06-21 08:03:44.855269
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class C(object):
        def __init__(self):
            self.called = []

        def __call__(self, *args, **kwargs):
            self.called.append((args, kwargs))

    ev = _EventSource()
    # add a callable
    c = C()
    ev += c
    # add the same callable again
    ev += c
    # add a non callable
    try:
        ev += 42
    except ValueError:
        pass
    else:
        raise AssertionError('expected ValueError')

    ev.fire('a', foo='bar')

    assert len(c.called) == 1
    assert c.called[0][0] == ('a',)
    assert c.called[0][1] == {'foo': 'bar'}



# Generated at 2022-06-21 08:03:46.299697
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-21 08:03:57.063302
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class SomeException(Exception):
        pass

    def handler_one(arg1, arg2):
        print('handler_one invoked with', arg1, arg2)

    def handler_two(arg1, arg2):
        print('handler_two invoked with', arg1, arg2)
        raise SomeException('some error')

    def handler_three(arg1, arg2):
        print('handler_three invoked with', arg1, arg2)

    def handler_on_exception(handler, exc, *args, **kwargs):
        print('handler_on_exception invoked with', handler, exc, args, kwargs)
        return False

    source = _EventSource()
    source._on_exception = handler_on_exception
    source += handler_one
    source += handler_two
    source += handler_three


# Generated at 2022-06-21 08:03:59.922124
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def f():
        pass
    es += f
    assert f in es._handlers
    es += f
    assert f in es._handlers



# Generated at 2022-06-21 08:04:03.979211
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class A(object):
        def __init__(self, finder, config):
            if not config:
                raise Exception('config is not defined')

            if str(config.__class__) != "abc.AnsibleCollectionConfig":
                raise Exception('config is not an instance of AnsibleCollectionConfig')

    A(1, AnsibleCollectionConfig)

# Generated at 2022-06-21 08:04:19.437121
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def dummy_1():
        pass

    def dummy_2():
        pass

    def dummy_3():
        pass

    def dummy_4():
        pass

    def dummy_5():
        pass

    def dummy_6():
        pass

    # we expect this to be called
    def assert_1(eventsource, handler, exc, *args, **kwargs):
        assert handler is dummy_1
        assert exc == ValueError
        assert args == ()
        assert kwargs == {'foo': 'bar'}
        return True

    # we expect this to not be called
    def assert_2(eventsource, handler, exc, *args, **kwargs):
        assert False

    # we expect this to not be called, as it is not callable

# Generated at 2022-06-21 08:04:26.326690
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source.fire()

    try:
        source += 'a string'
        assert False, "expected a ValueError"
    except ValueError:
        pass

    def handler():
        assert False, 'the handler should not have been called'

    source += handler
    source += handler

    def handler_removed():
        assert False, 'the removed handler should not have been called'

    source += handler_removed

    source -= handler_removed

    source.fire()

# Generated at 2022-06-21 08:04:34.923060
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test _EventSource.fire() with a handler that returns True after the second call
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.count = 0

        def handler(self, *args, **kwargs):
            if self.count == 0:
                self.count += 1
            else:
                return True

    test = MyEventSource()
    test += test.handler
    test.fire()
    test.fire()
    assert test.count == 1

# Generated at 2022-06-21 08:04:38.902857
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source._handlers == set()
    assert event_source._on_exception(None, None, None) is True
    assert event_source.fire() is None


# Generated at 2022-06-21 08:04:44.596521
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    event_source += event_source.__isub__
    event_source += event_source.__isub__
    event_source -= event_source.__isub__
    assert list(event_source._handlers) == [event_source.__isub__]


# Generated at 2022-06-21 08:04:48.629459
# Unit test for constructor of class _EventSource
def test__EventSource():
    # type: () -> None

    class test_EventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    e = test_EventSource()
    assert e._handlers == set()



# Generated at 2022-06-21 08:04:49.481172
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cls = AnsibleCollectionConfig()
    assert isinstance(cls, _AnsibleCollectionConfig)


# Generated at 2022-06-21 08:04:54.203210
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac._collection_finder is None
    assert ac.collection_finder is None
    assert ac.collection_paths == []
    assert ac.default_collection is None
    assert ac.on_collection_load == ac._on_collection_load
    assert ac.playbook_paths == []

# Generated at 2022-06-21 08:04:56.488066
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    func = lambda x: x
    ev = _EventSource()

    ev += func



# Generated at 2022-06-21 08:04:58.342713
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source
    return event_source


# Generated at 2022-06-21 08:05:09.947615
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    # Test 1
    es += "abc"
    es -= "abc"
    assert not es._handlers
    # Test 2
    es += "abc"
    es -= "def"
    assert es._handlers == {"abc"}


# These are the methods which are to be publicly available in the Ansible.
COLLECTION_CONFIG = AnsibleCollectionConfig

# Generated at 2022-06-21 08:05:11.715081
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda: None


# Generated at 2022-06-21 08:05:21.019689
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    assert event._handlers == set()
    event += 'hello'
    assert event._handlers == set()
    event += 'hello'  # test that trying to add twice doesn't succeed
    assert event._handlers == set()

    def handler1(*args, **kwargs): pass
    def handler2(*args, **kwargs): pass
    event += handler1
    assert event._handlers == {handler1}
    event += handler2
    assert event._handlers == {handler1, handler2}


# Generated at 2022-06-21 08:05:31.935386
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder

    finder = AnsibleCollectionFinder()

    # test ValueError for non-callable value
    try:
        AnsibleCollectionConfig.on_collection_load += (1, 2, 3)
    except ValueError:
        pass

    # test ValueError for non-callable value
    def _handler(collection):
        pass

    AnsibleCollectionConfig.on_collection_load += _handler

    try:
        AnsibleCollectionConfig.on_collection_load -= _handler
    except Exception:
        pass

    finder = AnsibleCollectionFinder()
    AnsibleCollectionConfig.collection_finder = finder

    try:
        AnsibleCollectionConfig.collection_finder = finder
    except ValueError:
        pass

    finder.set_play

# Generated at 2022-06-21 08:05:33.318747
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config._collection_finder is None
    assert config._default_collection is None

# Generated at 2022-06-21 08:05:40.613975
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    there_were_no_exceptions = True

    def exception(cls):
        raise Exception()

    def no_exception(cls):
        pass

    event = _EventSource()

    # handler that raises exception
    event += exception

    # handler that does not raise exception
    event += no_exception

    try:
        event.fire()
    except:
        there_were_no_exceptions = False

    return there_were_no_exceptions


# Generated at 2022-06-21 08:05:42.526590
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()
    x += 5
    assert x._handlers == set()


# Generated at 2022-06-21 08:05:48.310897
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    def on_collection_load_handler(collection):
        pass

    class Subclass(AnsibleCollectionConfig):
        pass

    c = Subclass()
    c.on_collection_load += on_collection_load_handler

    config = AnsibleCollectionConfig()

    config.on_collection_load += on_collection_load_handler

# Generated at 2022-06-21 08:05:53.448608
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # Constructor AnsibleCollectionConfig()
    config = AnsibleCollectionConfig()

    assert config.collection_finder is None
    assert config.collection_paths == []
    assert config.default_collection is None
    assert config.on_collection_load is not None
    assert config.playbook_paths == []

# Generated at 2022-06-21 08:06:04.775502
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():  # pragma: no cover
    import os
    import sys

    # test constructor
    class TestMeta(_AnsibleCollectionConfig):
        pass

    class TestClass(with_metaclass(TestMeta)):
        pass

    assert TestClass.__name__ == 'TestClass'
    assert TestClass.collection_finder is None
    assert TestClass.default_collection is None
    try:
        TestClass.collection_finder = os
        raise AssertionError('should have failed to set collection_finder because it is already set')
    except ValueError:
        pass
    try:
        TestClass.default_collection = 'asdf'
        raise AssertionError('should have failed to set default_collection because it is already set')
    except ValueError:
        pass

# Generated at 2022-06-21 08:06:21.267736
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()



# Generated at 2022-06-21 08:06:24.003049
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, _AnsibleCollectionConfig)
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)

# Generated at 2022-06-21 08:06:29.562147
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance = _EventSource()

    def f(a, b=None, c=None):
        print("called f")

    instance += f

    instance.fire("abc", "def", c="ghi")

    instance -= f
    instance.fire("abc", "def", c="ghi")


# Generated at 2022-06-21 08:06:31.300312
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.__class__ == AnsibleCollectionConfig


# Generated at 2022-06-21 08:06:34.986366
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    test_class = _AnsibleCollectionConfig('test_name', (object,), {})
    assert test_class._collection_finder is None
    assert test_class._default_collection is None
    assert isinstance(test_class._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:06:39.025841
# Unit test for constructor of class _EventSource
def test__EventSource():
    with pytest.raises(ValueError):
        _EventSource() + 1


# Unit tests for property "on_collection_load" of class AnsibleCollectionConfig

# Generated at 2022-06-21 08:06:43.270129
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()

    def h1():
        return True

    def h2():
        return False

    ev.__iadd__(h1)
    ev.__iadd__(h2)
    assert len(ev._handlers) == 2


# Generated at 2022-06-21 08:06:54.857046
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible.module_utils._text import to_bytes
    from ansible.errors import AnsibleError

    class TestAnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    def test_collection_finder():
        # The property collection_finder should not be directly settable
        finder = object()
        with pytest.raises(ValueError):
            TestAnsibleCollectionConfig.collection_finder = finder
        assert TestAnsibleCollectionConfig._collection_finder is None

        # After a finder is created, the property should be read-only
        TestAnsibleCollectionConfig.collection_finder = finder
        with pytest.raises(ValueError):
            TestAnsibleCollectionConfig.collection_finder = finder

    test_collection_finder()


# Generated at 2022-06-21 08:07:00.499076
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.playbook_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load != []



# Generated at 2022-06-21 08:07:03.061441
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Arrange
    test = _EventSource()

    # Assert
    assert test._handlers == set()



# Generated at 2022-06-21 08:07:39.519012
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    """
    The __iadd__ method is used by the on_collection_load property to assign an event handler.
    """
    def event_handler(event):
        pass

    AnsibleCollectionConfig.on_collection_load += event_handler
    assert event_handler in AnsibleCollectionConfig.on_collection_load._handlers



# Generated at 2022-06-21 08:07:49.704385
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def my_handler(*args, **kwargs):
        # test that we can receive and pass arguments
        assert args == (1, 2, 3)
        assert kwargs == {'alpha': 1, 'beta': 2}

        # test that the handler can modify arguments
        args[0] = 4
        args.append(5)
        kwargs['gamma'] = 6

    event = _EventSource()

    # verify that the event doesn't fire if there are no handlers
    event.fire(1, 2, 3, alpha=1, beta=2)

    # verify that the event fires with a single handler
    event += my_handler
    event.fire(1, 2, 3, alpha=1, beta=2)

    # verify that the event fires with multiple handlers

# Generated at 2022-06-21 08:07:51.272538
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)


# Generated at 2022-06-21 08:07:54.934764
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Test basic handler removal
    es = _EventSource()
    handler = lambda x: 1
    es += handler
    es -= handler
    assert handler not in es._handlers

    # Test handler removal when handler is not in handlers
    es = _EventSource()
    handler = lambda x: 1
    es -= handler
    assert handler not in es._handlers



# Generated at 2022-06-21 08:07:59.096439
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler = lambda *args, **kwargs: None
    assert handler not in event_source._handlers
    event_source += handler
    assert handler in event_source._handlers
    event_source -= handler
    assert handler not in event_source._handlers



# Generated at 2022-06-21 08:08:00.794519
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert e is not None


# Generated at 2022-06-21 08:08:02.138679
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    raise NotImplementedError

# Generated at 2022-06-21 08:08:04.090535
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()
    x += lambda x: x
    assert len(x._handlers) == 1

# Generated at 2022-06-21 08:08:12.602186
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # Test with metaclass
    ac = AnsibleCollectionConfig()
    assert ac.collection_finder == None
    assert ac.default_collection == None
    assert isinstance(ac.on_collection_load, _EventSource)

    # Test without metaclass
    class TestConfig(object):
        collection_finder = None
        default_collection = None
        on_collection_load = _EventSource()
    tc = TestConfig()
    assert tc.collection_finder == None
    assert tc.default_collection == None
    assert isinstance(tc.on_collection_load, _EventSource)

# Generated at 2022-06-21 08:08:13.611063
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()


# Generated at 2022-06-21 08:08:46.416389
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # setup
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    # test
    event_source -= handler
    # assert
    assert not event_source._handlers


# Generated at 2022-06-21 08:08:58.003738
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible.errors import AnsibleError
    from ansible_collections.ansible.builtin.plugins.module_utils.collection_loader._finder import AnsibleCollectionFinder

    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

    f1 = AnsibleCollectionFinder()
    AnsibleCollectionConfig.collection_finder = f1

    try:
        AnsibleCollectionConfig.collection_finder = f1
        assert False
    except AnsibleError:
        assert True

    try:
        AnsibleCollectionConfig.default_collection = 'name'
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-21 08:08:59.952548
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    e += lambda: None
    e -= lambda: None
    assert e._handlers == set()


# Generated at 2022-06-21 08:09:02.086210
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:09:09.950373
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyTestObj:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.event_handler

        def event_handler(self, *args, **kwargs):
            self.event_firing = True

    obj = MyTestObj()
    assert not hasattr(obj, 'event_firing')
    obj.event_source.fire()
    assert getattr(obj, 'event_firing', False) is True

test__EventSource_fire()

# Generated at 2022-06-21 08:09:13.987634
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def fake_handler():
        pass

    event_source += fake_handler
    event_source -= fake_handler
    event_source -= fake_handler


if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-21 08:09:18.212945
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    conf = AnsibleCollectionConfig()
    assert conf.on_collection_load
    assert conf.collection_finder is None
    assert conf.default_collection is None
    assert conf.collection_paths == []
    assert conf.playbook_paths == []
    return conf

# Generated at 2022-06-21 08:09:24.944770
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    assert len(e._handlers) == 0

    # subtract an item that is not in the handlers
    e -= (lambda: None)
    assert len(e._handlers) == 0

    # subtract the only item in the handlers
    e += (lambda: None)
    e -= (lambda: None)
    assert len(e._handlers) == 0

    # subtract the second of two items in the handlers
    e += (lambda: None)
    e += (lambda: None)
    e -= (lambda: None)
    assert len(e._handlers) == 1

    # subtract the first of two items in the handlers
    e -= (lambda: None)
    assert len(e._handlers) == 0



# Generated at 2022-06-21 08:09:30.158975
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class Handler:
        def __call__(self, *args, **kwargs):
            pass

    class NotHandler:
        pass

    es = _EventSource()
    h = Handler()

    es += h
    assert h in es._handlers

    try:
        es += NotHandler()
    except ValueError:
        pass
    else:
        assert False, 'expected ValueError to be raised'


# Generated at 2022-06-21 08:09:31.554547
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert not es._handlers



# Generated at 2022-06-21 08:10:05.801235
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')
    assert not hasattr(AnsibleCollectionConfig, '_on_collection_load')

# Generated at 2022-06-21 08:10:11.570093
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

    try:
        AnsibleCollectionConfig.collection_finder = None
    except Exception as e:
        assert 'already been configured' == to_text(e)

    try:
        AnsibleCollectionConfig.on_collection_load = None
    except Exception as e:
        assert 'not directly settable' == to_text(e)

# Generated at 2022-06-21 08:10:12.708595
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _EventSource.__iadd__(None, None)  # should not throw an exception

# Generated at 2022-06-21 08:10:20.033878
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestAnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    # This is a private class and we're only testing it for type safety.
    # pylint: disable=protected-access
    instance = TestAnsibleCollectionConfig()

    assert instance._collection_finder is None
    assert isinstance(instance._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:10:23.707546
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ev = _EventSource()

    res = []
    ev += lambda: res.append('a')
    ev += lambda: res.append('b')
    ev.fire()

    assert res == ['a', 'b']


# Generated at 2022-06-21 08:10:24.040573
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:10:26.756384
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()
    assert isinstance(ansible_collection_config.on_collection_load, _EventSource)
    assert not hasattr(ansible_collection_config, 'collection_finder')

# Generated at 2022-06-21 08:10:28.824647
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source += test__EventSource___iadd__
    source -= test__EventSource___iadd__


# Generated at 2022-06-21 08:10:33.701501
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = _AnsibleCollectionConfig(meta='meta', name='name', bases=('bases1', 'bases2', 'bases3'))
    assert c._collection_finder is None
    assert c._default_collection == None
    assert isinstance(c._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:10:39.702471
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()
    eventhandler_1 = lambda: None
    eventhandler_2 = lambda: None
    eventhandler_3 = lambda: None
    eventhandler_4 = lambda: None
    eventsource += eventhandler_1
    eventsource += eventhandler_2
    eventsource += eventhandler_3
    eventsource += eventhandler_4
    eventsource -= eventhandler_3
    eventsource += eventhandler_3
    eventsource.fire()