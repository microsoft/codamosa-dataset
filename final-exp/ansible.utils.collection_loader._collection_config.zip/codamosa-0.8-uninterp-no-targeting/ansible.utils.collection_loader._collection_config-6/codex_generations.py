

# Generated at 2022-06-21 08:01:33.331827
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():

    config = AnsibleCollectionConfig()

    Finder = AnsibleCollectionConfig.collection_finder.__class__
    EventSource = AnsibleCollectionConfig.on_collection_load.__class__

    assert config.__class__ is AnsibleCollectionConfig
    assert config.collection_finder is None
    assert config.default_collection is None
    assert isinstance(config.on_collection_load, EventSource)
    assert config.playbook_paths == []

    finder = Finder()
    config.collection_finder = finder
    assert config.collection_finder is finder

    assert config.collection_paths == finder.collection_paths

    config.default_collection = 'foo'
    assert config.default_collection is 'foo'

    def noop(obj):
        pass

    config.on_collection_load += noop

# Generated at 2022-06-21 08:01:38.677585
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    event_source += handler1
    event_source += handler2

    event_source.fire(a=1, b=2)



# Generated at 2022-06-21 08:01:39.353891
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()

# Generated at 2022-06-21 08:01:42.588630
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:01:51.168060
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    # nothing to remove
    es -= lambda *args, **kwargs: None

    # add handlers so we have something to remove
    h1 = lambda *args, **kwargs: None
    h2 = lambda *args, **kwargs: None
    es += h1
    es += h2

    # remove one
    es -= h1
    assert h1 not in es._handlers
    assert h2 in es._handlers

    # remove other
    es -= h2
    assert h2 not in es._handlers



# Generated at 2022-06-21 08:01:52.485812
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()


# Generated at 2022-06-21 08:01:57.355508
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    test_event_source = _EventSource()
    assert test_event_source._handlers == set()
    def test_handler_1(self):
        pass
    test_event_source += test_handler_1
    assert test_handler_1 in test_event_source._handlers
    test_event_source -= test_handler_1
    assert test_handler_1 not in test_event_source._handlers
    test_event_source -= test_handler_1
    assert test_handler_1 not in test_event_source._handlers


# Generated at 2022-06-21 08:01:58.447107
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    instance = _AnsibleCollectionConfig()

# Generated at 2022-06-21 08:02:01.757716
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None

# Generated at 2022-06-21 08:02:05.816609
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Pass and fail cases for verification of callable
    assert _EventSource()
    try:
        _EventSource().add(5)
        assert False, 'Expected ValueError on _EventSource with non-callable'
    except ValueError:
        pass

# Generated at 2022-06-21 08:02:13.899754
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    l = []

    def handler():
        l.append(0)

    # This will throw an exception if the implementation is wrong
    AnsibleCollectionConfig._on_collection_load += handler
    assert handler not in l

    AnsibleCollectionConfig._on_collection_load.fire()
    assert handler in l

# Generated at 2022-06-21 08:02:15.227262
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert isinstance(c, AnsibleCollectionConfig)

# Generated at 2022-06-21 08:02:20.937979
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # default behavior is to just call the handlers
    my_handler = lambda *args, **kwargs: None
    event_source = _EventSource()
    event_source += my_handler
    event_source.fire()

    # if a handler raises an exception, we wrap it and raise it
    my_handler = lambda *args, **kwargs: 1 / 0
    event_source = _EventSource()
    event_source += my_handler
    try:
        event_source.fire()
        assert False, 'expected an exception'
    except Exception as ex:
        assert type(ex) is ZeroDivisionError

    # if the on_exception hook returns True then we re-raise
    my_handler = lambda *args, **kwargs: 1 / 0

# Generated at 2022-06-21 08:02:23.642207
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc = AnsibleCollectionConfig()
    assert acc.collection_finder is None
    assert acc.default_collection is None
    assert acc._on_collection_load is acc.on_collection_load
    assert isinstance(acc._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:02:28.201957
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.playbook_paths is None



# Generated at 2022-06-21 08:02:29.492911
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # no constructor defined
    pass

# Generated at 2022-06-21 08:02:39.034131
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    """Unit test for method __iadd__ of class _EventSource"""

    es = _EventSource()

    def f(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == dict(kw1='foo', kw2='bar')

    es += f
    es(1, 2, kw1='foo', kw2='bar')

    def g(*args, **kwargs):
        assert args == (3, 4)
        assert kwargs == dict(kw3='baz', kw4='qux')

    es += g
    es(3, 4, kw3='baz', kw4='qux')



# Generated at 2022-06-21 08:02:44.212540
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Test that the method _EventSource.__isub__() can remove a handler.
    source = _EventSource()
    source += lambda: None
    assert len(source._handlers) == 1
    source -= lambda: None
    assert len(source._handlers) == 0


# Generated at 2022-06-21 08:02:45.865407
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None


# Generated at 2022-06-21 08:02:46.471516
# Unit test for constructor of class _EventSource
def test__EventSource():
    pass

# Generated at 2022-06-21 08:03:03.575995
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._on_collection_load
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert not AnsibleCollectionConfig.collection_finder
    assert not AnsibleCollectionConfig.default_collection
    assert callable(AnsibleCollectionConfig.on_collection_load.fire)
    assert callable(AnsibleCollectionConfig.on_collection_load)
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollectionConfig._on_collection_load
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None

# Generated at 2022-06-21 08:03:14.825364
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Test:
        def __init__(self):
            self.counter = 0
            self.last_exception = None

        def handler(self, *args, **kwargs):
            self.counter += 1
            if self.counter == 1:
                raise ZeroDivisionError('test for capturing the exception')

    event_source = _EventSource()
    test = _Test()

    event_source += test.handler

    with pytest.raises(ValueError):
        event_source.fire(1, 'test')

    with pytest.raises(ZeroDivisionError):
        event_source.fire('test', 'test2')

    event_source.fire('test', 'test2')
    assert test.counter == 2

    event_source += test.handler
    event_source.fire('test', 'test2')

# Generated at 2022-06-21 08:03:21.705423
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, 'collection_finder'), 'AnsibleCollectionConfig.collection_finder should not exist'
    assert not hasattr(AnsibleCollectionConfig, 'default_collection'), 'AnsibleCollectionConfig.default_collection should not exist'
    assert not hasattr(AnsibleCollectionConfig, 'on_collection_load'), 'AnsibleCollectionConfig.on_collection_load should not exist'
    assert not hasattr(AnsibleCollectionConfig, 'playbook_paths'), 'AnsibleCollectionConfig.playbook_paths should not exist'


# Generated at 2022-06-21 08:03:33.750922
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []

    def handler1():
        calls.append(1)

    def handler2():
        calls.append(2)
        raise ValueError('test exception')

    def handler3():
        calls.append(3)
        raise RuntimeError('test exception')

    def on_exception(handler, exc):
        calls.append(exc)
        return handler == handler2

    ee = _EventSource()
    ee.on_exception = on_exception
    ee += handler1
    ee += handler2
    ee += handler3

    with pytest.raises(ValueError):
        ee.fire()

    assert calls == [1, 2, handler2.__name__, 2, 'test exception', handler3.__name__, 'test exception']



# Generated at 2022-06-21 08:03:40.312628
# Unit test for constructor of class _EventSource
def test__EventSource():
    class is_callable:
        def __call__(self):
            pass

    assert isinstance(_EventSource(), _EventSource)

    # handlers must be callable
    es = _EventSource()
    try:
        es += None
    except ValueError as ex:
        assert 'handler must be callable' in str(ex)

    try:
        es += is_callable()
    except ValueError as ex:
        assert 'handler must be callable' in str(ex)

    es += is_callable()


# Generated at 2022-06-21 08:03:41.717517
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def test(a):
        pass

    es = _EventSource()
    es += test
    es.fire()

# Generated at 2022-06-21 08:03:43.136774
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:03:53.725511
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    q = _EventSource()
    called = []

    def handler_1(*args, **kwargs):
        called.append('one')

    def handler_2(*args, **kwargs):
        called.append('two')

    def handler_3(*args, **kwargs):
        called.append('three')

    q.fire()
    assert not called

    q += handler_1
    q.fire()
    assert called == ['one']

    q += handler_2
    q += handler_3
    q.fire()
    assert called == ['one', 'one', 'two', 'three']

    q -= handler_1
    q.fire()
    assert called == ['one', 'one', 'two', 'three', 'two', 'three']

# Generated at 2022-06-21 08:04:03.276648
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()

    def es_handler(*args, **kwargs):
        pass

    def es_handler_none(*args, **kwargs):
        return None

    def es_handler_false(*args, **kwargs):
        return False

    es += es_handler
    # += returns a reference to the event source, so we can chain

# Generated at 2022-06-21 08:04:09.534139
# Unit test for constructor of class _EventSource
def test__EventSource():
    # pylint: disable=protected-access

    # test init
    event_source = _EventSource()
    assert event_source._handlers == set()

    # test adding
    assert event_source._on_exception('foo', 'bar', 'baz')
    event_source += 'foo'
    assert 'foo' in event_source._handlers

    # test removing
    event_source -= 'foo'
    assert 'foo' not in event_source._handlers

    # test fire
    event_source._handlers = ['foo']
    event_source.fire('bar', 'baz')



# Generated at 2022-06-21 08:04:26.929336
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Arrange
    def handler():
        pass

    # Act
    event = _EventSource()
    event += handler

    event -= handler

    # Assert
    assert len(event._handlers) == 0



# Generated at 2022-06-21 08:04:31.406483
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def f(): pass
    def g(): pass

    event_source += f
    event_source += g

    assert f in event_source._handlers
    assert g in event_source._handlers


# Generated at 2022-06-21 08:04:35.904073
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _TestConfigMeta (_AnsibleCollectionConfig):
        pass

    assert _TestConfigMeta._collection_finder is None
    assert _TestConfigMeta._on_collection_load._handlers == set()
    assert _TestConfigMeta._default_collection is None


# Generated at 2022-06-21 08:04:37.351253
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():

    # should create object without error
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:04:48.573418
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        nonlocal handler1_invocations
        nonlocal handler1_arg1
        nonlocal handler1_arg2
        handler1_invocations += 1
        handler1_arg1 = arg1
        handler1_arg2 = arg2

    def handler2(arg1, arg2):
        nonlocal handler2_invocations
        nonlocal handler2_arg1
        nonlocal handler2_arg2
        handler2_invocations += 1
        handler2_arg1 = arg1
        handler2_arg2 = arg2

    handler1_invocations = 0
    handler1_arg1 = None
    handler1_arg2 = None
    handler2_invocations = 0
    handler2_arg1 = None
    handler2_arg2 = None

    event_source = _EventSource()

# Generated at 2022-06-21 08:04:53.662206
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler():
        pass

    def handler2():
        pass

    collection_load_event = _EventSource()
    collection_load_event += handler
    collection_load_event += handler2
    collection_load_event -= handler
    assert handler not in collection_load_event._handlers
    assert handler2 in collection_load_event._handlers



# Generated at 2022-06-21 08:04:57.469574
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert hasattr(es, '_handlers')
    assert type(es._handlers) is set
    assert len(es._handlers) == 0


# Generated at 2022-06-21 08:05:04.110090
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    class MyEventSource:
        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            pass

    event_source = _EventSource()
    event_source += MyEventSource
    event_source += MyEventSource
    event_source -= MyEventSource
    event_source -= MyEventSource



# Generated at 2022-06-21 08:05:09.240801
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    source += handler1
    source += handler2

    assert len(source._handlers) == 2

    source -= handler1

    assert len(source._handlers) == 1

    source -= handler1

    assert len(source._handlers) == 1



# Generated at 2022-06-21 08:05:17.783454
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()
    assert a.collection_finder is None
    assert a.collection_paths == []
    assert a.default_collection is None
    assert a.playbook_paths == []


# TODO: split this off into a separate file and make it a unit test for the loader implementation
# This ensures that the ansible-test collection loader is identical to the controller collection loader
# since the two implementations must behave the same for tests to be valid.


# Generated at 2022-06-21 08:05:55.230353
# Unit test for constructor of class _EventSource
def test__EventSource():
    class Foo:
        def __init__(self):
            self._foo = _EventSource()
            self._foo += self.listener

        def listener(self, s, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs

    f = Foo()
    a = object()
    f._foo.fire(a, x=True, y=False)
    assert f._args == (a,)
    assert f._kwargs == {'x': True, 'y': False}

# Generated at 2022-06-21 08:06:00.123556
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    evs = _EventSource()
    h1 = lambda: True
    h2 = lambda: True

    evs += h1
    evs -= h1
    evs += h2
    evs -= h2
    evs -= h1

    assert len(evs._handlers) == 0



# Generated at 2022-06-21 08:06:05.494810
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def test_handler_func_a():
        pass

    def test_handler_func_b():
        pass

    es += test_handler_func_a
    es += test_handler_func_b
    es -= test_handler_func_a
    es -= test_handler_func_b

    assert len(es._handlers) == 0

# Generated at 2022-06-21 08:06:06.906952
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # if we get here, we're good because the constructor doesn't raise
    assert True

# Generated at 2022-06-21 08:06:14.655390
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class C:
        def on_event(self, value):
            self.value = value

    # Test with no parameters
    e = _EventSource()

    c = C()
    e += c.on_event
    e.fire()
    assert c.value is None

    # Test with actual parameters
    e = _EventSource()

    c = C()
    e += c.on_event
    e.fire('foo')
    assert c.value == 'foo'

    # Test unspecified keyword argument
    e = _EventSource()

    c = C()
    e += c.on_event
    e.fire(value='foo')
    assert c.value == 'foo'


# Generated at 2022-06-21 08:06:15.824710
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-21 08:06:18.849214
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    x = _AnsibleCollectionConfig(None, 'x', None)
    assert x._collection_finder is None
    assert x._default_collection is None

# Generated at 2022-06-21 08:06:30.838017
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # is _EventSource running
    a = AnsibleCollectionConfig()
    a.on_collection_load += None
    try:
        a.on_collection_load = None
        assert False, 'Should never get here'
    except ValueError:
        pass

    # is default_collection properly initialized
    try:
        AnsibleCollectionConfig().default_collection = 'a_value'
        assert False, 'Should never get here'
    except ValueError:
        pass

    # is collection_finder properly initialized
    try:
        AnsibleCollectionConfig().collection_finder = 'a_value'
        assert False, 'Should never get here'
    except ValueError:
        pass

# Unit tests for class _AnsibleCollectionConfig

# is the metaclass working

# Generated at 2022-06-21 08:06:34.877975
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler():
        pass

    e = _EventSource()
    e += handler

    # Test for the event source behavior, _EventSource class does not maintain handlers
    assert len(e._handlers) == 1
    assert handler in e._handlers
    e -= handler
    assert len(e._handlers) == 0


# Generated at 2022-06-21 08:06:41.315699
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Arrange
    event_source = _EventSource()
    event_source += lambda: xxx
    event_source += lambda: xxx
    event_source -= lambda: xxx

    # Act
    actual = event_source._handlers

    # Assert
    assert actual == set((lambda: xxx, ))


# Generated at 2022-06-21 08:07:50.090471
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def handler1(arg):
        pass

    def handler2(arg):
        pass

    def handler3(arg):
        pass

    es += handler1
    es += handler2
    es += handler3

    assert es._handlers == set([handler1, handler2, handler3])

    es -= handler2

    assert es._handlers == set([handler1, handler3])

    es -= handler2

    assert es._handlers == set([handler1, handler3])

    es -= handler3

    assert es._handlers == set([handler1])


# Generated at 2022-06-21 08:07:51.973387
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None

# Generated at 2022-06-21 08:07:53.069197
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c.on_collection_load.__class__ == _EventSource

# Generated at 2022-06-21 08:08:03.284717
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible_collections.ansible.community.tests import unit_test

    e = _EventSource()

    @e.on_collection_load
    def handler1():
        pass

    @e.on_collection_load
    def handler2():
        pass

    @e.on_collection_load
    def handler3():
        pass

    unit_test(AnsibleCollectionConfig.on_collection_load, e)
    unit_test(len(AnsibleCollectionConfig.on_collection_load._handlers), 3)

    del handler1
    unit_test(len(AnsibleCollectionConfig.on_collection_load._handlers), 2)

    handler2 = None
    unit_test(len(AnsibleCollectionConfig.on_collection_load._handlers), 1)

    AnsibleCollectionConfig.on_collection

# Generated at 2022-06-21 08:08:14.441650
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler_noexc(event, *args, **kwargs):
        pass

    def handler_ex(event, *args, **kwargs):
        raise RuntimeError('handler_ex throws')

    def handler_except(event, exc, *args, **kwargs):
        return True

    eventsource = _EventSource()
    eventsource += handler_noexc
    assert handler_noexc in eventsource._handlers

    eventsource -= handler_noexc
    assert handler_noexc not in eventsource._handlers

    # with no handlers, just to ensure no error is produced
    eventsource.fire()

    eventsource += handler_noexc
    eventsource.fire()

    # after fire() above, the event source should no longer contain the handler
    assert handler_noexc not in eventsource._handlers

    eventsource = _EventSource()

# Generated at 2022-06-21 08:08:17.205639
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()
    assert ev._handlers == set()

# Generated at 2022-06-21 08:08:23.660109
# Unit test for constructor of class _EventSource
def test__EventSource():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types

    expected = frozenset()
    actual = _EventSource()._handlers

    assert actual == expected, 'expected: %s, actual: %s' % (to_native(expected), to_native(actual))


# Generated at 2022-06-21 08:08:25.124096
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
  assert isinstance(AnsibleCollectionConfig, type)


# Generated at 2022-06-21 08:08:27.628756
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    # remove an item not in the set
    es.__isub__(None)



# Generated at 2022-06-21 08:08:34.246458
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    def first_function():
        pass

    def second_function():
        pass

    event_source = _EventSource()

    # Act
    event_source += first_function
    event_source += second_function

    # Assert
    assert len(event_source._handlers) == 2
    assert first_function in event_source._handlers
    assert second_function in event_source._handlers


# Generated at 2022-06-21 08:11:02.891310
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    _EventSource_obj = _EventSource()
    test__EventSource___isub___function = lambda: None
    _EventSource_obj += test__EventSource___isub___function
    _EventSource_obj -= test__EventSource___isub___function
    _EventSource_obj._on_exception = lambda: True
    _EventSource_obj -= test__EventSource___isub___function


# Generated at 2022-06-21 08:11:08.069055
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        print('event handler')

    event_source += handler

    assert handler in event_source._handlers

    def handler2():
        print('event handler2')

    event_source += handler2

    assert handler in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-21 08:11:13.494741
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)

# Generated at 2022-06-21 08:11:15.382744
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    p = _EventSource()
    p += lambda: None
    p += lambda: None


# Generated at 2022-06-21 08:11:24.379726
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    result = []
    es = _EventSource()
    h1 = lambda x: result.append(1)
    h2 = lambda x, y: result.append(2)
    h3 = lambda x, y, z: result.append(3)

    es += h1
    es += h2
    es += h3

    es.fire()

    assert result == [3, 2, 1]
    result = []

    es.fire(1)

    assert result == [3, 2, 1]
    result = []

    es.fire(1, 2)

    assert result == [3, 2, 1]
    result = []

    es.fire(1, 2, 3)

    assert result == [3, 2, 1]
    result = []