

# Generated at 2022-06-21 08:01:21.429443
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    event += lambda: None
    event -= lambda: None
    assert len(event._handlers) == 0

# Generated at 2022-06-21 08:01:24.502744
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event += lambda x: int(x)
    if event.fire(1.1) != 1:
        raise AssertionError('fire method of EventSource is not working')


# Generated at 2022-06-21 08:01:27.783034
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.default_collection is None
    assert config.on_collection_load == set()
    assert callable(config.on_collection_load.fire)

# Generated at 2022-06-21 08:01:31.036169
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    handler = lambda *args, **kwargs: None
    es += handler
    assert handler in es._handlers
    es -= handler
    assert handler not in es._handlers


# Generated at 2022-06-21 08:01:43.117074
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    a = _EventSource()
    b = []

    def _handler(x):
        b.append(x)

    a += _handler
    a += _handler

    a.fire(1)

    assert b == [1, 1], 'fire only called handler once'

    try:
        a.fire(2)
    except ValueError as e:
        assert b == [1, 1] and str(e) == 'oops', 'exception not trapped by EventSource'
    else:
        assert False, 'exception not raised'

    def _handler(x):
        b.append(x)
        raise ValueError('oops')

    a += _handler


# Generated at 2022-06-21 08:01:45.369979
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    e -= lambda a: None
    e = e


# Generated at 2022-06-21 08:01:47.800818
# Unit test for constructor of class _EventSource
def test__EventSource():
    source = _EventSource()
    assert len(source._handlers) == 0


# Generated at 2022-06-21 08:01:52.358581
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    handler1 = lambda *args, **kwargs: None
    handler2 = lambda *args, **kwargs: None

    e += handler1
    e -= handler1
    e -= handler2

    e += handler1
    e += handler2

    e -= handler1
    e -= handler2


# Generated at 2022-06-21 08:01:54.203389
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    # Verify that the constructor invokes the correct superclass.
    assert issubclass(_AnsibleCollectionConfig, type)


# Generated at 2022-06-21 08:01:56.427584
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)
    assert _AnsibleCollectionConfig('meta', 'name', 'bases') is not None

# Generated at 2022-06-21 08:02:05.980724
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert isinstance(c._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:02:08.259570
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert isinstance(config, AnsibleCollectionConfig)


# Generated at 2022-06-21 08:02:09.765012
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert type(AnsibleCollectionConfig) is _AnsibleCollectionConfig

# Generated at 2022-06-21 08:02:12.551899
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(arg):
        pass

    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-21 08:02:14.218181
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda: None
    event_source.fire()

# Generated at 2022-06-21 08:02:27.345537
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import copy

    # TEST 1: collection_finder property
    collection_finder = 2
    AnsibleCollectionConfig.collection_finder = collection_finder
    assert AnsibleCollectionConfig.collection_finder == collection_finder

    try:
        AnsibleCollectionConfig.collection_finder = 3
        assert False, 'expected to raise ValueError'
    except ValueError:
        pass

    # TEST 2: default_collection property
    default_collection = 2
    AnsibleCollectionConfig.default_collection = default_collection
    assert AnsibleCollectionConfig.default_collection == default_collection

    # TEST 3: on_collection_load property
    on_collection_load_1 = 2
    AnsibleCollectionConfig.on_collection_load = on_collection_load_1
    assert AnsibleCollectionConfig.on_collection_load is on_collection_load_1

    on

# Generated at 2022-06-21 08:02:35.080265
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class Handler:
        def __init__(self, expectation):
            self.expectation = expectation

        def __call__(self, *args, **kwargs):
            assert args == self.expectation['args']
            assert kwargs == self.expectation['kwargs']
            self.expectation['assertion_count'] += 1

    ev = _EventSource()
    exp = {
        'args': (1, 2, 3),
        'kwargs': {'a': 1, 'b': 2},
        'assertion_count': 0
    }

    ev += Handler(exp)
    ev.fire(*exp['args'], **exp['kwargs'])

    assert exp['assertion_count'] == 1



# Generated at 2022-06-21 08:02:37.911836
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    s += lambda: 1
    assert len(s._handlers) == 1



# Generated at 2022-06-21 08:02:38.530448
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:02:48.344923
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # handler=None
    es = _EventSource()
    es.fire()

    # handler=None, args
    es = _EventSource()
    es.fire('arg')

    # handler=None, kwargs
    es = _EventSource()
    es.fire(kw='arg')

    # handler=None, args, kwargs
    es = _EventSource()
    es.fire('arg', kw='arg')

    # handler=callable
    es = _EventSource()

    def handler(*args, **kwargs):
        pass

    es += handler
    es.fire()

    # handler=callable, args
    es = _EventSource()
    es += handler
    es.fire('arg')

    # handler=callable, kwargs
    es = _EventSource()
    es += handler


# Generated at 2022-06-21 08:03:10.073268
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # create object
    es = _EventSource()

    # create handler
    def test_handler(*args, **kwargs):
        pass

    # add handler
    es += test_handler

    # verify added
    assert test_handler in es._handlers

    # remove handler
    es -= test_handler

    # verify removed
    assert test_handler not in es._handlers

    # remove again
    es -= test_handler

    # verify still removed
    assert test_handler not in es._handlers


# Generated at 2022-06-21 08:03:18.696234
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, 'collection_finder'), 'collection_finder not defined'
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load'), 'on_collection_load not defined'

    class Sub(AnsibleCollectionConfig):
        pass

    # pylint: disable=no-member
    #   This is a deliberate test of accessing private data members.
    assert Sub._collection_finder is None, '_collection_finder should be None'
    assert Sub._default_collection is None, '_default_collection should be None'
    assert hasattr(Sub._on_collection_load, 'fire'), '_on_collection_load should be _EventSource'
    assert not Sub._on_collection_load._handlers, '_on_collection_load._handlers should be empty set'



# Generated at 2022-06-21 08:03:22.309209
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load != None

# vim: et sts=4 ts=4 sw=4 ft=python

# Generated at 2022-06-21 08:03:29.106427
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestHandler:
        def __init__(self):
            self.count = 0

        def __call__(self, *args, **kwargs):
            self.count += 1

    test_event = _EventSource()
    handlers = [_TestHandler() for _ in range(3)]
    for h in handlers:
        test_event += h

    test_event.fire()

    for h in handlers:
        assert h.count == 1

# Generated at 2022-06-21 08:03:31.546766
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert isinstance(event, _EventSource)


# Generated at 2022-06-21 08:03:35.738568
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # ensure that fire by default has no side effects
    event = _EventSource()
    event.fire()

    # ensure that we can register a handler that has no side effects
    def handler1():
        pass
    event += handler1
    event.fire()

    # ensure that we can register a handler that does does have side effects
    def handler2(a):
        assert a == 'xyz'
    event += handler2
    event.fire('xyz')

    # ensure that we can remove a handler
    event -= handler2
    event.fire()

    # ensure that we can register a handler that raises an exception
    def handler3():
        raise AssertionError('BOOGA')
    event += handler3

# Generated at 2022-06-21 08:03:38.943296
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    assert len(event._handlers) == 0

    event += lambda: None
    assert len(event._handlers) == 1

    event -= lambda: None
    assert len(event._handlers) == 0



# Generated at 2022-06-21 08:03:41.168011
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(arg1, arg2):
        pass

    # constructor: no arguments
    event = _EventSource()

    # add handler
    event += handler

    # remove handler
    event -= handler


# Generated at 2022-06-21 08:03:52.483558
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import pytest

    with pytest.raises(NotImplementedError):
        AnsibleCollectionConfig.collection_finder

    with pytest.raises(NotImplementedError):
        AnsibleCollectionConfig.default_collection

    AnsibleCollectionConfig.on_collection_load
    AnsibleCollectionConfig.playbook_paths
    AnsibleCollectionConfig.collection_paths

    with pytest.raises(ValueError):
        AnsibleCollectionConfig.on_collection_load = None

    with pytest.raises(ValueError):
        AnsibleCollectionConfig.default_collection = "test"

    with pytest.raises(ValueError):
        AnsibleCollectionConfig.collection_finder = "test"

    with pytest.raises(NotImplementedError):
        AnsibleCollectionConfig.playbook_paths = "test"

# Generated at 2022-06-21 08:03:56.147986
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    o = type('test', (AnsibleCollectionConfig,), {'__module__': __name__})
    assert o.collection_finder is None
    assert o.default_collection is None
    assert isinstance(o.on_collection_load, _EventSource)

# Generated at 2022-06-21 08:04:15.776456
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c.collection_finder is None
    assert c.default_collection is None
    assert isinstance(c.on_collection_load, _EventSource)
    assert c.playbook_paths == []
    assert c.collection_paths == []

# Generated at 2022-06-21 08:04:20.987027
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, _EventSource)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert not AnsibleCollectionConfig._collection_finder
    assert not AnsibleCollectionConfig._default_collection
    assert not AnsibleCollectionConfig._on_collection_load

# Generated at 2022-06-21 08:04:29.142950
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig.collection_finder = 'foo'
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    AnsibleCollectionConfig.collection_finder = None

    AnsibleCollectionConfig.default_collection = 'foo'

    AnsibleCollectionConfig.playbook_paths = ['/foo/bar']

    try:
        AnsibleCollectionConfig.playbook_paths = None
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    try:
        AnsibleCollectionConfig.collection_paths
    except NotImplementedError:
        pass
    else:
        assert False, 'Expected NotImplementedError'



# Generated at 2022-06-21 08:04:37.428123
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import ansible
    from collections import defaultdict

    targets = defaultdict(list)

    handler = lambda href: targets['href'].append(href)

    e = _EventSource()
    e += handler

    e.fire(href='https://galaxy.ansible.com')
    e.fire(href='https://docs.ansible.com')

    assert targets == {'href': ['https://galaxy.ansible.com', 'https://docs.ansible.com']}



# Generated at 2022-06-21 08:04:48.633999
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Dummy:
        def __init__(self, value):
            self._value = value

        @property
        def value(self):
            return self._value

        @value.setter
        def value(self, value):
            self._value = value

    class DummyFailing:
        def __init__(self, value):
            self._value = value

        @property
        def value(self):
            return self._value

        @value.setter
        def value(self, value):
            self._value = value

        def callable(self, *args, **kwargs):
            raise ValueError('dummy exception')

    d = Dummy(0)
    df = DummyFailing(0)

    e = _EventSource()
    e += d

    assert d.value == 0
    assert df

# Generated at 2022-06-21 08:04:51.592863
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class DummyHandler:
        did_fire = False

    handler = DummyHandler()
    event = _EventSource()
    event += handler
    event.fire()
    assert handler.did_fire

# Generated at 2022-06-21 08:04:56.488822
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    source += handler1
    source += handler2

    assert len(source._handlers) == 2

    source -= handler1

    assert len(source._handlers) == 1


# Generated at 2022-06-21 08:04:57.930196
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:05:04.607453
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_result = {'called': False}

    def test_handler(*args, **kwargs):
        test_result['called'] = True

    event = _EventSource()
    event += test_handler
    event.fire()
    assert test_result['called'] is True
    event -= test_handler

    test_result['called'] = False
    event.fire()
    assert test_result['called'] is False

# Generated at 2022-06-21 08:05:09.280498
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler():
        pass

    _event_source = _EventSource()

    assert callable(handler)

    assert handler not in _event_source._handlers

    _event_source += handler

    assert handler in _event_source._handlers

    _event_source += handler

    assert handler in _event_source._handlers



# Generated at 2022-06-21 08:05:47.040018
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test that calling instance.fire with no handlers works
    src = _EventSource()
    src.fire()

    # test that handler is called
    count = [0]

    def handler(*args):
        count[0] += 1

    src += handler
    src.fire()

    assert count[0] == 1

    # test that two handlers are called
    def handler2(*args):
        count[0] += 1

    src += handler2
    src.fire()

    assert count[0] == 3

    # test that handlers called in the order added
    handler_count = [0, 0]

    def handler(*args):
        handler_count[0] += 1

    def handler2(*args):
        handler_count[1] += 1

    src += handler
    src += handler2
    src.fire()


# Generated at 2022-06-21 08:05:54.440728
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(n):
        print(n)

    event = _EventSource()
    event += handler
    event.fire(100)
    event.fire(200)

    # TODO: write unit test
    # We want to raise the exception and see the output.
    def exception_handler(n):
        print(n)
        raise ValueError('expected exception')

    event = _EventSource()
    event += exception_handler
    event.fire(100)


# Generated at 2022-06-21 08:05:55.673759
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig(None, None, None)

# Generated at 2022-06-21 08:05:58.908314
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler(x): pass

    instance = _EventSource()
    instance += handler

    assert len(instance._handlers) == 1

    instance -= handler
    assert len(instance._handlers) == 0



# Generated at 2022-06-21 08:06:04.603494
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import collections
    from ansible.utils.collection_loader import _AnsibleCollectionConfig

    class M(_AnsibleCollectionConfig):
        pass

    assert isinstance(M._on_collection_load, _EventSource)
    assert isinstance(M._on_collection_load, collections.Callable)
    assert M._collection_finder is None
    assert M._default_collection is None

# Generated at 2022-06-21 08:06:06.778045
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    obj = AnsibleCollectionConfig()
    assert obj._collection_finder is None
    assert obj._default_collection is None


# Generated at 2022-06-21 08:06:15.333282
# Unit test for constructor of class _EventSource
def test__EventSource():
    handler_called = False
    handler_exception_caught = False

    def handler(value):
        nonlocal handler_called
        handler_called = True

    def handler_exception(value):
        nonlocal handler_exception_caught
        handler_exception_caught = True
        # raise to make sure the caller of our fire method handles the exception
        raise ValueError('intended exception')

    # test initial event handler set is empty
    event_source = _EventSource()
    event_source.fire()

    # test handler can be added
    event_source += handler
    handler_called = False
    event_source.fire()
    assert handler_called

    # test handler can be removed
    event_source -= handler
    handler_called = False
    event_source.fire()
    assert not handler_called

   

# Generated at 2022-06-21 08:06:27.911910
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestAnsibleCollectionConfigWithEventSource(_AnsibleCollectionConfig):
        _on_collection_load = _EventSource()

    class TestAnsibleCollectionConfig(with_metaclass(TestAnsibleCollectionConfigWithEventSource)):
        pass

    def handle(event, name, **kwargs):
        raise TestException('handler %s, kwargs %s' % (name, kwargs))

    event = TestAnsibleCollectionConfig.on_collection_load

    event += handle
    try:
        event.fire('event', name='event1')
        assert False, 'expected an exception'
    except TestException as e:
        assert str(e) == 'handler event1, kwargs {}'

    event += handle

# Generated at 2022-06-21 08:06:36.769305
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible.utils.collection_loader._legacy_collections_finder import AnsibleCollectionFinder

    c = _AnsibleCollectionConfig('c', 'name', 'bases')
    assert isinstance(c._on_collection_load, _EventSource)

    f = AnsibleCollectionFinder()
    c.collection_finder = f
    assert c.collection_finder == f

    c.default_collection = 'collection'
    assert c.default_collection == 'collection'
    assert c._default_collection == 'collection'

    assert c.on_collection_load is not None
    assert c.on_collection_load == c._on_collection_load

    try:
        c.on_collection_load = None
        assert False
    except ValueError:
        assert True

    assert c.on_collection_load is not None

# Generated at 2022-06-21 08:06:48.563832
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    class Test(MutableMapping):
        def __init__(self):
            self._container = {}

        def __setitem__(self, key, value):
            self._container[key] = value

        def __getitem__(self, key):
            return self._container[key]

        def __delitem__(self, key):
            del self._container[key]

        def __iter__(self):
            return iter(self._container)

        def __len__(self):
            return len(self._container)


# Generated at 2022-06-21 08:07:48.779326
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    target = AnsibleCollectionConfig()


# Generated at 2022-06-21 08:07:50.046731
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()


# Generated at 2022-06-21 08:07:51.609353
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()
    assert ev
    assert len(ev._handlers) == 0



# Generated at 2022-06-21 08:07:57.814206
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    exception = ValueError('test exception')

    def handler1(*args, **kwargs):
        raise exception

    def handler2(*args, **kwargs):
        raise exception

    event += handler1
    event += handler2

    try:
        event.fire()
    except ValueError:
        pass
    else:
        raise AssertionError('_EventSource.fire failed to re-raise exception')

    event -= handler1

    try:
        event.fire()
    except ValueError:
        pass
    else:
        raise AssertionError('_EventSource.fire failed to re-raise exception')

    exception = RuntimeError('test exception')

    def handler3(*args, **kwargs):
        raise exception

    def handler4(*args, **kwargs):
        raise exception


# Generated at 2022-06-21 08:08:02.558029
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    foo = 'foo'
    foo2 = 'foo2'

    e = _EventSource()
    e += foo
    e += foo2

    assert len(e._handlers) == 2

    e -= foo
    assert len(e._handlers) == 1


test__EventSource___isub__()

# Generated at 2022-06-21 08:08:04.145670
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda x: 1 + x


# Generated at 2022-06-21 08:08:05.249769
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-21 08:08:14.325515
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def a(x):
        pass

    def b(x):
        pass

    def c(x):
        pass

    def d(x):
        pass

    event += a
    event += b
    event += c
    event += d

    assert event._handlers == {a, b, c, d}

    event -= b

    assert event._handlers == {a, c, d}

    event -= a

    assert event._handlers == {c, d}

    event -= d

    assert event._handlers == {c}

    event -= c

    assert event._handlers == set()


# Generated at 2022-06-21 08:08:27.005533
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired = False

        def my_on_fire(self, *args, **kwargs):
            assert len(args) == 2
            assert kwargs['kwarg'] == 'kwarg-value'
            self.fired = True

        def _on_exception(self, handler, exc, *args, **kwargs):
            # the exception is handled here, so we do not want the caller to re-raise
            return False

    t = TestEventSource()

    with pytest.raises(ValueError):
        # handler must be callable
        t += None

    t += t.my_on_fire


# Generated at 2022-06-21 08:08:27.982356
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig()


# Generated at 2022-06-21 08:10:43.905282
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler1():
        pass

    ev = _EventSource()
    ev += handler1

    ev -= handler1
    assert len(ev._handlers) == 0


# Generated at 2022-06-21 08:10:46.838719
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    ev = _EventSource()
    assert isinstance(ev, _EventSource)
    ev -= ev.__iadd__(lambda _: None)
    ev -= ev.__iadd__(lambda _: None)
    assert len(ev._handlers) == 0



# Generated at 2022-06-21 08:10:48.371046
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()


# Generated at 2022-06-21 08:10:50.820826
# Unit test for constructor of class _EventSource
def test__EventSource():
    def sample_handler(*a, **kw):
        pass

    x = _EventSource()
    x += sample_handler
    assert len(x._handlers) == 1

# Generated at 2022-06-21 08:10:55.033651
# Unit test for constructor of class _EventSource
def test__EventSource():
    def _event_handler(*args, **kwargs):
        pass
    _event_source = _EventSource()
    _event_source += _event_handler
    assert _event_source._handlers == set([_event_handler])
    _event_source -= _event_handler

# Generated at 2022-06-21 08:11:05.170467
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockHandler:
        def __init__(self):
            self.calls = 0

        def __call__(self, *args, **kwargs):
            self.calls += 1

    input_handlers = [
        MockHandler(),
        MockHandler(),
        MockHandler(),
    ]

    es = _EventSource()
    es._handlers = set(input_handlers)

    # fire the handlers
    es.fire('foo', 'bar', 'baz')

    # verify the handlers were invoked
    assert all(i.calls == 1 for i in input_handlers)

    #
    # verify that if we remove one of the handlers it does not fire
    #
    es._handlers -= input_handlers[1]
    es.fire('foo', 'bar', 'baz')
    assert input_hand

# Generated at 2022-06-21 08:11:15.376816
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import os.path
    from ansible.module_utils.six import PY3

    config = AnsibleCollectionConfig()
    def handler(coll_name):
        if not PY3 and isinstance(coll_name, bytes):
            coll_name = coll_name.decode('utf-8')
        coll_path = os.path.join(coll_name, 'plugins', 'modules')
        if isinstance(coll_path, bytes):
            coll_path = coll_path.decode('utf-8')
        config.collection_paths.append(coll_path)

    config.on_collection_load += handler

    assert len(config._on_collection_load._handlers) == 1

if __name__ == '__main__':
    import sys
    import inspect
    import ansible.module_utils.common
