

# Generated at 2022-06-21 08:01:21.366528
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # To be implemented
    pass


# Generated at 2022-06-21 08:01:25.115410
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, property)
    assert isinstance(AnsibleCollectionConfig._default_collection, property)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, property)


__all__ = ('AnsibleCollectionConfig',)

# Generated at 2022-06-21 08:01:26.927205
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(_AnsibleCollectionConfig, type)
    assert issubclass(_AnsibleCollectionConfig, type)

# Generated at 2022-06-21 08:01:32.184218
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()

    def handler1(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        return None

    def handler4(*args, **kwargs):
        raise ValueError('this is from handler4')

    eventsource += handler1
    eventsource += handler3
    eventsource += handler4

    eventsource.fire()



# Generated at 2022-06-21 08:01:33.521879
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pass



# Generated at 2022-06-21 08:01:40.171767
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert len(e._handlers) == 0

    def handler():
        pass

    # use __iadd__ to add 'handler' to the set
    e += handler
    assert len(e._handlers) == 1

    # ensure adding 'handler' a second time does not grow the set
    e += handler
    assert len(e._handlers) == 1


# Generated at 2022-06-21 08:01:51.665762
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is None

    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')

    assert not hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert not hasattr(AnsibleCollectionConfig, 'default_collection')
    assert not hasattr(AnsibleCollectionConfig, 'on_collection_load')

    class _AnsibleCollectionFinder(object):
        def __init__(self):
            self._n_collection_paths = []
            self._n_playbook_paths = []


# Generated at 2022-06-21 08:01:53.656632
# Unit test for constructor of class _EventSource
def test__EventSource():
    source = _EventSource()
    assert isinstance(source, _EventSource)
    assert isinstance(source, object)
    assert not source._handlers


# Generated at 2022-06-21 08:02:03.506048
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)
    assert _AnsibleCollectionConfig._collection_finder is None
    assert _AnsibleCollectionConfig._default_collection is None
    assert isinstance(_AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert isinstance(_AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(_AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(_AnsibleCollectionConfig.default_collection, property)
    assert isinstance(_AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(_AnsibleCollectionConfig.playbook_paths, property)

# Generated at 2022-06-21 08:02:11.024091
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class NotACallable:
        pass

    source = _EventSource()
    assert source._handlers == set()

    def handler():
        pass

    source += handler
    source += handler
    assert source._handlers == {handler}

    source -= handler
    assert source._handlers == {handler}

    source -= handler
    assert source._handlers == set()

    try:
        source += NotACallable
        assert False, 'ValueError should have been raised'
    except ValueError:
        pass


# Generated at 2022-06-21 08:02:17.793067
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.collection_paths is None
    assert AnsibleCollectionConfig.playbook_paths is None

    AnsibleCollectionConfig.collection_paths = ['/does/not/exist']  # intentionally blow up



# Generated at 2022-06-21 08:02:22.747604
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.__class__.__bases__[0] == super
    assert type(config).__base__ == _AnsibleCollectionConfig
    assert isinstance(config, _AnsibleCollectionConfig)

# Generated at 2022-06-21 08:02:26.165999
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:02:30.879064
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    x = AnsibleCollectionConfig()
    assert x.collection_finder is None
    assert x.default_collection is None
    assert isinstance(x.on_collection_load, _EventSource)
    assert x.collection_paths is x.collection_paths
    assert x.playbook_paths is x.playbook_paths

# Generated at 2022-06-21 08:02:37.059794
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    x = _EventSource()

    def handler1(a, msg):
        assert a == 'bar'
        assert msg == 'zap'
        handler1.called_with = (a, msg)

    def handler2(a, msg):
        assert a == 'bar'
        assert msg == 'zap'
        handler2.called_with = (a, msg)
        raise Exception()

    def handler3(a, msg):
        assert a == 'bar'
        assert msg == 'zap'
        handler3.called_with = (a, msg)

    x += handler1
    x += handler2
    x += handler3

    x.fire('bar', msg='zap')

    assert handler1.called_with == ('bar', 'zap')

# Generated at 2022-06-21 08:02:38.938018
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()

# Generated at 2022-06-21 08:02:46.768233
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    listener = 1

    # Should not allow non-callables
    try:
        event += listener  # test that we can call the += method
        event += listener  # test that we can call the += method a second time
    except ValueError:
        pass
    else:
        assert False, "ValueError should be raised if listener is not callable"

    # Should allow callables
    listener = lambda *args, **kwargs: None
    event += listener
    listener = lambda *args, **kwargs: None
    event += listener



# Generated at 2022-06-21 08:02:58.831542
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def event_handler(arg1, arg2, arg3):
        event_handler.received_fire_args.append((arg1, arg2, arg3))

    event_source = _EventSource()
    event_source += event_handler
    event_handler.received_fire_args = []
    event_source.fire(arg1='a', arg2='b', arg3='c')
    assert event_handler.received_fire_args == [('a', 'b', 'c')], \
        'args in event handler not as expected, event handler received: %s' % event_handler.received_fire_args

    event_source.fire(arg1='a', arg2='b', arg3='c')

# Generated at 2022-06-21 08:03:00.184119
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()



# Generated at 2022-06-21 08:03:07.972894
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler(): pass
    def handler2(): pass

    event_source += handler
    event_source += handler2

    assert handler in event_source._handlers
    assert handler2 in event_source._handlers

    event_source -= handler
    assert handler not in event_source._handlers

    event_source -= handler2
    assert handler2 not in event_source._handlers

    del event_source
    del handler, handler2


# Generated at 2022-06-21 08:03:13.196235
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler():
        raise ValueError('handler')
    event = _EventSource()
    event += handler
    event -= handler


# Generated at 2022-06-21 08:03:15.049626
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert len(es._handlers) == 0
    assert es._on_exception(None, None, None) == True


# Generated at 2022-06-21 08:03:17.164178
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # test removing a non-existent handler
    e = _EventSource()
    def handle_event(a):
        pass
    e -= handle_event


# Generated at 2022-06-21 08:03:24.426816
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # It should add handler to EventSouce instance
    src = _EventSource()
    h = lambda x: None
    src += h
    assert len(src._handlers) == 1

    # It should raise ValueError if handler is not callable
    src = _EventSource()
    h = 'a non-callable'
    with pytest.raises(ValueError) as exc_info:
        src += h
    assert exc_info.value.args[0] == 'handler must be callable'



# Generated at 2022-06-21 08:03:32.371481
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert config._on_collection_load is not None
    assert config.on_collection_load is config._on_collection_load
    assert config.collection_finders is config._collection_finder
    assert config.collection_paths is config._collection_finder._n_collection_paths
    assert config.playbook_paths is config._collection_finder._n_playbook_paths

# Generated at 2022-06-21 08:03:38.860280
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()

    # Call method twice to check that it is safe to call with the same handler
    event_source += handler
    event_source += handler

    # Check that the handler has been added only once
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    # Call method with non callable argument
    with pytest.raises(ValueError):
        event_source += lambda: None



# Generated at 2022-06-21 08:03:40.073767
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    _EventSource.__isub__("")


# Generated at 2022-06-21 08:03:45.757478
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)

    assert hasattr(AnsibleCollectionConfig, "collection_finder")
    assert hasattr(AnsibleCollectionConfig, "collection_paths")
    assert hasattr(AnsibleCollectionConfig, "default_collection")
    assert hasattr(AnsibleCollectionConfig, "playbook_paths")

    # Class attribute on_collection_load is not directly settable
    assert not hasattr(AnsibleCollectionConfig, "on_collection_load")
    assert hasattr(AnsibleCollectionConfig, "_on_collection_load")

    # Attempting to set the AnsibleCollectionFinder more than once is an error
    with pytest.raises(ValueError) as error:
        AnsibleCollectionConfig.collection_finder = None

# Generated at 2022-06-21 08:03:56.669591
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource_test(_EventSource):
        def __init__(self):
            self._log = []
            super(EventSource_test, self).__init__()

        def _on_exception(self, handler, ex, *args, **kwargs):
            self._log.append((handler, ex, args, kwargs))
            return True

    t = EventSource_test()
    t.fire(1, 2, 3)
    assert t._log == []

    def handler1(*args, **kwargs):
        raise TypeError('broken')

    def handler2(*args, **kwargs):
        raise TypeError('broken')

    t += handler1
    t += handler2

    t.fire(4, 5, 6)
    assert len(t._log) == 2

# Generated at 2022-06-21 08:04:05.965319
# Unit test for constructor of class _EventSource
def test__EventSource():
    from ansible.module_utils._text import to_bytes

    def handler1(param1=None):
        assert param1 == 'value'

    def handler2(param1=None):
        assert param1 == 'value'

    event_source = _EventSource()

    event_source += handler1
    event_source += handler2

    # handling a parameter
    event_source.fire(param1='value')

    event_source -= handler1

    # handling a parameter
    event_source.fire(param1='value')

    def bad_handler1(param1=None):
        raise ValueError()

    def bad_handler2(param1=None):
        raise ValueError()

    event_source = _EventSource()

    event_source += bad_handler1


# Generated at 2022-06-21 08:04:16.090910
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    # Given
    e = _EventSource()

    # When
    with pytest.raises(ValueError):
        e.__iadd__(None)

    e += None

    # Then
    assert e._handlers == set()


# Generated at 2022-06-21 08:04:26.929746
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler1(arg1, arg2=None):
        pass

    def handler2(arg1, arg2=None):
        pass

    event_source += handler1
    event_source += handler2

    event_source -= handler1
    assert handler1 not in event_source._handlers
    assert handler2 in event_source._handlers

    event_source -= handler2
    assert handler1 not in event_source._handlers
    assert handler2 not in event_source._handlers

    event_source += handler1
    event_source -= handler2
    assert handler1 in event_source._handlers
    assert handler2 not in event_source._handlers

    # Test that error is raised if handler argument value is not callable.

# Generated at 2022-06-21 08:04:29.329907
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder == None
    assert AnsibleCollectionConfig.default_collection == None

# Generated at 2022-06-21 08:04:36.407484
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    h1 = lambda: 1
    h2 = lambda: 2

    e += h1
    e += h2

    assert len(e._handlers) == 2

    e -= h1
    assert len(e._handlers) == 1

    e -= h1
    assert len(e._handlers) == 1

    e -= h2
    assert len(e._handlers) == 0


# Generated at 2022-06-21 08:04:42.857390
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # all attribute values are None
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

    # setter tests
    cfc = AnsibleCollectionConfig()
    assert cfc.collection_finder is None
    assert cfc.default_collection is None

    assert len(AnsibleCollectionConfig.playbook_paths) == 0

    pb_paths = AnsibleCollectionConfig.playbook_paths
    assert len(pb_paths) == 0


# Generated at 2022-06-21 08:04:45.115481
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    evs = _EventSource()
    evs += lambda x: None
    assert evs._handlers


# Generated at 2022-06-21 08:04:48.365043
# Unit test for constructor of class _EventSource
def test__EventSource():

    from ansible_collections.ansible.community.tests.unit.ansible_collections.ansible.community.plugins.module_utils.collection_loader._EventSource import test__EventSource as ts
    ts()

# Generated at 2022-06-21 08:04:59.231008
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    AnsibleCollectionConfig()

    # default_collection is an instance property
    assert AnsibleCollectionConfig.default_collection is None
    AnsibleCollectionConfig.default_collection = 'foo'
    assert AnsibleCollectionConfig.default_collection == 'foo'

    # collection_finder is an instance property
    assert AnsibleCollectionConfig.collection_finder is None
    AnsibleCollectionConfig.collection_finder = 'foo'
    assert AnsibleCollectionConfig.collection_finder == 'foo'

    # on_collection_load is an instance property
    assert AnsibleCollectionConfig.on_collection_load is None
    AnsibleCollectionConfig.on_collection_load += 'foo'
    assert AnsibleCollectionConfig.on_collection_load == 'foo'

    # collection_paths is a class property
    assert AnsibleCollectionConfig.collection_paths is None

    # playbook

# Generated at 2022-06-21 08:05:02.904824
# Unit test for constructor of class _EventSource
def test__EventSource():
    # event source initialization
    local_event = _EventSource()

    # check that the event object has been correctly initialized
    assert not local_event._handlers



# Generated at 2022-06-21 08:05:09.321020
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def f():
        pass

    def g():
        pass

    es += f
    assert 1 == len(es._handlers)

    es += f
    assert 1 == len(es._handlers)

    es -= g
    assert 1 == len(es._handlers)

    es -= f
    assert 0 == len(es._handlers)

    es += g
    assert 1 == len(es._handlers)


# Generated at 2022-06-21 08:05:24.734168
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig("meta", "name", "bases")
    assert ac.collection_paths is None
    assert ac.on_collection_load is not None
    assert ac.default_collection is None
    assert ac.playbook_paths is None


# Generated at 2022-06-21 08:05:30.300239
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest

    # test that handler is added
    e = _EventSource()
    handler = lambda: None
    e += handler
    assert handler in e._handlers

    # test that ValueError is raised if handler is not callable
    e = _EventSource()
    with pytest.raises(ValueError):
        e += None



# Generated at 2022-06-21 08:05:31.534215
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    handler = lambda: None

    event += handler

    event -= handler

    assert not event._handlers

# Generated at 2022-06-21 08:05:34.134310
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Test 1
    event = _EventSource()
    to_remove = lambda x: True
    event += to_remove
    # Improperly removing an event handler (not callable) should be ignored (without KeyError)
    event -= to_remove
    assert to_remove in event._handlers

# Generated at 2022-06-21 08:05:45.118721
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import os
    import tempfile

    # Gather a list of directories that may contain ansible collections.
    collection_parent_dirs = {
        os.path.dirname(x) for x in os.getenv('ANSIBLE_COLLECTIONS_PATHS', '').split(':')
        if x
    }

    # If a collection was specified on the command line (ie: ansible-playbook foo.yml), use that collection name
    # as the default collection.  Otherwise, use the default collection for the ansible-playbook script, if it exists.
    # For ansible-galaxy, the default collection is 'ansible_galaxy', in the absence of args.
    # For ansible-inventory, the default collection is 'ansible_inventory', in the absence of args.
    # For ansible-console (which may not be

# Generated at 2022-06-21 08:05:46.710507
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # TODO: create unit tests
    pass


# Generated at 2022-06-21 08:05:48.530791
# Unit test for constructor of class _EventSource
def test__EventSource():
    foo = _EventSource()
    assert foo._handlers == set()


# Generated at 2022-06-21 08:06:00.422212
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    # Empty event source, no exceptions
    event_source.fire()

    # Firing with one handler
    handled = []

    def handler(value):
        handled.append(value)

    event_source.fire(123)
    assert handled == []

    event_source += handler
    event_source.fire(123)
    assert handled == [123]

    # Firing with one handler returning True
    handled = []
    event_source = _EventSource()

    def handler(value):
        handled.append(value)
        return True

    event_source += handler
    event_source.fire(123)
    assert handled == [123]

    # Firing with handler raising exception
    handled = []
    event_source = _EventSource()


# Generated at 2022-06-21 08:06:07.692054
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class Parent:
        pass

    def handler_1():
        p.counter += 1

    def handler_2():
        q.counter += 1

    p = Parent()
    p.counter = 0

    q = Parent()
    q.counter = 0

    es = _EventSource()
    es += handler_1
    es += handler_1
    assert len(es._handlers) == 1

    es -= handler_2
    assert len(es._handlers) == 1

    es -= handler_1
    assert len(es._handlers) == 0

# Generated at 2022-06-21 08:06:15.840335
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import collections
    import types

    # test default state
    a = _AnsibleCollectionConfig('meta', 'name', 'bases')

    if a._collection_finder is not None:
        raise AssertionError("Failed to initialize '_collection_finder' to None")

    if a._default_collection is not None:
        raise AssertionError("Failed to initialize '_default_collection' to None")

    expected_on_collection_load_result_type = collections.abc.Set
    actual_on_collection_load_result_type = type(a._on_collection_load._handlers)
    if expected_on_collection_load_result_type != actual_on_collection_load_result_type:
        raise AssertionError("Failed to initialize '_on_collection_load' to an empty set")

   

# Generated at 2022-06-21 08:06:36.770217
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        raise RuntimeError()

    def handler2(*args, **kwargs):
        raise ValueError()

    es = _EventSource()

    # test when no handlers have been registered
    es.fire()

    # test when a handler raises a RuntimeError
    es += handler1

    try:
        es.fire()
    except RuntimeError:
        pass
    else:
        assert False, 'RuntimeError not raised'

    # test when a handler raises a ValueError
    es += handler2

    try:
        es.fire()
    except RuntimeError:
        assert False, 'RuntimeError raised'
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

    # test when the first handler raises an exception
    es -= handler1


# Generated at 2022-06-21 08:06:41.575349
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None

    def handler1(ex):
        pass

    def handler2(ex):
        pass

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 3



# Generated at 2022-06-21 08:06:53.674283
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.six import PY3

    class EventSourceTest(object):
        def __init__(self):
            self.on_event_fired = _EventSource()
            self.on_event_fired += self.handler1
            self.on_event_fired += self.handler2

        def handler1(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            return True

        def handler2(self, *args, **kwargs):
            raise ValueError('test exception')

    event_source_test = EventSourceTest()

    event_source_test.on_event_fired.fire('arg1', my='kwargs')

    assert event_source_test.args == ('arg1',)

# Generated at 2022-06-21 08:06:56.834395
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c.collection_finder is None
    assert c.collection_paths == []
    assert c.default_collection is None
    assert c.on_collection_load is not None
    assert c.playbook_paths == []

# Generated at 2022-06-21 08:07:01.381403
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    """
    :type target: _EventSource
    """
    import pytest

    target = _EventSource()

    def handler(x):
        pass

    with pytest.raises(ValueError):
        target += 1
    target += handler



# Generated at 2022-06-21 08:07:03.060914
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(type, _AnsibleCollectionConfig)


# Generated at 2022-06-21 08:07:11.585788
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_handler = lambda: None

    # create an event source and ensure it's empty
    evt_source = _EventSource()
    assert len(evt_source._handlers) == 0

    # add a handler to the event source and ensure it's there
    evt_source += test_handler
    assert len(evt_source._handlers) == 1
    assert test_handler in evt_source._handlers

    # remove the handler from the event source and ensure it's gone
    evt_source -= test_handler
    assert len(evt_source._handlers) == 0
    assert test_handler not in evt_source._handlers



# Generated at 2022-06-21 08:07:15.476794
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # GIVEN
    class AnsibleCollectionConfig(AnsibleCollectionConfig):
        def __init__(self):
            self.on_collection_load = _EventSource()
    # WHEN
    a = AnsibleCollectionConfig()
    # THEN
    assert a.on_collection_load == _EventSource()

# Generated at 2022-06-21 08:07:19.429225
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    handler = lambda x: print('x')

    event += handler
    assert handler in event._handlers

    event -= handler
    assert handler not in event._handlers

    # silent discard of unknown handler
    event -= handler
    assert handler not in event._handlers

# Generated at 2022-06-21 08:07:28.640512
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    obj = _EventSource()

    def handler1(x):
        return x

    def handler2(x):
        return x ** 2

    obj += handler1
    obj += handler2

    try:
        obj -= handler1
        assert handler1 not in obj._handlers
        assert handler2 in obj._handlers
    except AssertionError:
        raise

    try:
        obj -= handler2
        assert handler1 not in obj._handlers
        assert handler2 not in obj._handlers
    except AssertionError:
        raise

    try:
        obj -= handler2
        assert handler1 not in obj._handlers
        assert handler2 not in obj._handlers
    except AssertionError:
        raise


# Generated at 2022-06-21 08:07:57.001414
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')
    assert not hasattr(AnsibleCollectionConfig, '_on_collection_load')

# Generated at 2022-06-21 08:08:05.916430
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    # fire with no registered handlers
    event_source.fire(1, 2, 3)

    args_seq = []

    # register a handler
    def handler(a, b, c):
        args_seq.append((a, b, c))

    event_source += handler

    # fire with no arguments
    event_source.fire()

    # dispatch handled with arguments
    event_source.fire(1, 2, 3)

    # ensure handler was called once for each fire
    assert args_seq == [(1, 2, 3)]

# Generated at 2022-06-21 08:08:11.942767
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        print('handler1 called')
    def handler2(*args, **kwargs):
        print('handler2 called')

    # Create an instance of _EventSource
    es = _EventSource()

    # Add functions to the event source
    es += handler1
    es += handler2

    # Fire the event
    es.fire('args1', 'args2')

# Generated at 2022-06-21 08:08:15.285679
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    obj = _EventSource()
    h1 = lambda : True
    h2 = lambda : True
    obj += h1
    obj += h2
    obj -= h1
    assert h1 not in obj._handlers
    assert h2 in obj._handlers



# Generated at 2022-06-21 08:08:27.222552
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestException(Exception):
        pass

    def test_handler(a, b):
        pass

    def test_exception_handler(*args, **kwargs):
        raise TestException()

    _t = _EventSource()

    _t = _t.__iadd__(test_handler)

    assert test_handler in _t._handlers
    assert test_exception_handler not in _t._handlers

    try:
        _t.__iadd__(test_exception_handler)
        assert False
    except ValueError:
        assert True

    _t.__iadd__(test_handler)
    assert len(_t._handlers) == 2

    _t = _t.__isub__(test_exception_handler)
    assert len(_t._handlers) == 2

    _t = _

# Generated at 2022-06-21 08:08:38.095192
# Unit test for constructor of class _EventSource
def test__EventSource():

    def handler1(x, y):
        pass

    def handler2(x, y):
        pass

    # test constructor
    es = _EventSource()

    assert len(es._handlers) == 0

    assert not callable(es)

    # test add operator
    es += handler1

    assert len(es._handlers) == 1

    assert call(es)

    # test remove operator
    es -= handler1

    assert len(es._handlers) == 0

    assert not callable(es)

    # test exception handler
    es += handler2

    assert len(es._handlers) == 1

    assert es._on_exception(None, None)

    es.fire(1, 2)

    assert len(es._handlers) == 1

    assert es._on_exception(None, "")




# Generated at 2022-06-21 08:08:41.560476
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    with open('/dev/null', 'w') as fp:
        es = _EventSource()
        es += fp.write

        assert fp.write in es._handlers
        assert len(es._handlers) == 1



# Generated at 2022-06-21 08:08:53.034019
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import unittest
    import unittest.mock

    class test__EventSource__isub(unittest.TestCase):
        def setUp(self):
            self._es = _EventSource()
            self._es_handler = unittest.mock.MagicMock()
            self._es += self._es_handler

        def test__EventSource__isub__success(self):
            self._es -= self._es_handler
            self._es.fire()
            self.assertEqual(self._es_handler.called, False)

        def test__EventSource__isub__nonexistent(self):
            self._es -= unittest.mock.MagicMock()
            self._es.fire()
            self.assertEqual(self._es_handler.called, True)
            self._es -= self

# Generated at 2022-06-21 08:08:55.258459
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # It should initialize the _collection_finder property to None
    assert AnsibleCollectionConfig._collection_finder is None


# Generated at 2022-06-21 08:08:58.819739
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cfg = AnsibleCollectionConfig()
    assert cfg.collection_finder is None
    assert cfg.default_collection is None
    assert cfg.playbook_paths == []
    assert cfg.collection_paths == []

# Generated at 2022-06-21 08:10:01.554892
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    # The config object should have the class properties
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')

    # The config object should not have the class methods
    assert not hasattr(AnsibleCollectionConfig, '_require_finder')

    # class should not have any attributes
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')
    assert not hasattr(AnsibleCollectionConfig, '_on_collection_load')

# Generated at 2022-06-21 08:10:02.958923
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert not e._handlers



# Generated at 2022-06-21 08:10:04.873584
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig().collection_finder is None
    assert AnsibleCollectionConfig().default_collection is None
    assert AnsibleCollectionConfig().on_collection_load is not None

# Generated at 2022-06-21 08:10:13.416519
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class test(object):
        pass

    AnsibleCollectionConfig()

    test_config = test()
    flag = False
    try:
        test_config.collection_finder = 'test'
    except AttributeError:
        flag = True
    assert flag

    flag = False
    try:
        test_config.collection_paths = 'test'
    except AttributeError:
        flag = True
    assert flag

    flag = False
    try:
        test_config.default_collection = 'test'
    except AttributeError:
        flag = True
    assert flag

    flag = False
    try:
        test_config.on_collection_load = 'test'
    except AttributeError:
        flag = True
    assert flag

    flag = False

# Generated at 2022-06-21 08:10:24.094266
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSourceSubclass(_EventSource):
        def __init__(self):
            super(EventSourceSubclass, self).__init__()
            self.subclass_attribute = 'test attribute'

    event_source = EventSourceSubclass()

    def handler():
        pass

    # this should work
    event_source += handler

    assert handler in event_source._handlers

    # this should raise a ValueError
    try:
        event_source += 'This is not callable'
        assert False
    except ValueError:
        assert True

    # this should work
    event_source -= handler

    assert handler not in event_source._handlers



# Generated at 2022-06-21 08:10:25.963033
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1



# Generated at 2022-06-21 08:10:31.176025
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # check that the metaclass was applied as expected
    assert '_AnsibleCollectionConfig' in str(type(AnsibleCollectionConfig)), \
        'AnsibleCollectionConfig failed to get _AnsibleCollectionConfig metaclass'

    # check support for named instance variables
    acc = AnsibleCollectionConfig()
    assert hasattr(acc, '_collection_finder'), \
        'AnsibleCollectionConfig failed to get _collection_finder instance variable'
    assert hasattr(acc, '_default_collection'), \
        'AnsibleCollectionConfig failed to get _default_collection instance variable'
    assert hasattr(acc, '_on_collection_load'), \
        'AnsibleCollectionConfig failed to get _on_collection_load instance variable'

    # smoke
    acc.collection_finder
    acc.collection_paths
    acc

# Generated at 2022-06-21 08:10:32.038582
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()


# Generated at 2022-06-21 08:10:36.377964
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    def handler():
        pass

    source += handler
    assert handler in source._handlers
    source -= handler
    assert handler not in source._handlers

    # verify a second attempt to remove a handler doesn't explode
    source -= handler


# Generated at 2022-06-21 08:10:37.871267
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    es -= 'foo'
    es -= _EventSource()

