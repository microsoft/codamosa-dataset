

# Generated at 2022-06-21 08:01:27.688630
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None

    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None


# Generated at 2022-06-21 08:01:31.584744
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    def handler():
        pass

    e += handler
    e -= handler

    with pytest.raises(ValueError):
        e += 'not callable'

    with pytest.raises(KeyError):
        e -= handler



# Generated at 2022-06-21 08:01:43.714846
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test_EventSource(object):
        def test_fire(self):
            event_source = _EventSource()

            def handler1(arg1, arg2):
                event_source.counter += 1
                assert len(arg1) == 4
                assert arg2 == 12
                if event_source.counter == 1:
                    raise IOError('Something wrong')

            def handler2(arg1, arg2):
                event_source.counter += 1
                assert len(arg1) == 4
                assert arg2 == 12

            event_source += handler1
            event_source += handler2
            event_source.counter = 0
            event_source.fire(arg1=[1, 2, 3, 4], arg2=12)
            assert event_source.counter == 2

    _ = Test_EventSource()
    assert _.test_

# Generated at 2022-06-21 08:01:50.124658
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    test_count = 0

    def test_event_handler(*args, **kwargs):
        nonlocal test_count
        test_count += 1

    event_source = _EventSource()
    event_source._handlers = {test_event_handler, test_event_handler}
    event_source -= test_event_handler
    event_source.fire()

    assert test_count == 1


# Generated at 2022-06-21 08:01:52.254562
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def my_callable():
        pass

    source = _EventSource()
    source += my_callable
    source.fire()

    source -= my_callable
    source.fire()


# Generated at 2022-06-21 08:01:55.767843
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.playbook_paths == []

# Generated at 2022-06-21 08:01:58.501023
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    ac = AnsibleCollectionConfig()

    assert ac.collection_paths == []
    assert ac.playbook_paths == []
    assert ac.default_collection is None


# Generated at 2022-06-21 08:02:05.653413
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler(msg):
        pass

    event_source = _EventSource()
    assert handler not in event_source._handlers

    event_source -= handler
    assert handler not in event_source._handlers

    event_source += handler
    assert handler in event_source._handlers

    event_source -= handler
    assert handler not in event_source._handlers

    event_source -= handler
    assert handler not in event_source._handlers

# Generated at 2022-06-21 08:02:16.244346
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Handler:
        def __init__(self):
            self._calls = []

        def __call__(self, *args, **kwargs):
            self._calls.append((args, kwargs))

    event_source = _EventSource()
    handler1 = _Handler()
    handler2 = _Handler()

    event_source += handler1
    event_source += handler2

    event_source.fire(1, 2, c=3)
    assert handler1._calls == [((1, 2), {'c': 3})]
    assert handler2._calls == [((1, 2), {'c': 3})]

    event_source -= handler1

    event_source.fire(4, 5, c=6)

# Generated at 2022-06-21 08:02:23.642750
# Unit test for constructor of class _EventSource
def test__EventSource():
    def dummy_handler(x):
        return x

    dummy_event = _EventSource()
    dummy_event += dummy_handler
    assert len(dummy_event._handlers) == 1
    assert dummy_handler in dummy_event._handlers
    assert dummy_event._on_exception(dummy_handler, ValueError, 1) == True



# Generated at 2022-06-21 08:02:29.982258
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # arrange
    obj = _EventSource()

    # act
    obj += _add
    obj += _add

    # assert
    # no exception raised
    pass


# Generated at 2022-06-21 08:02:33.897096
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import mock
    import pytest

    x = _EventSource()

    mock_handler = mock.Mock()
    x += mock_handler

    assert mock_handler in x._handlers

    with pytest.raises(ValueError) as error:
        x += None

    assert 'handler must be callable' in str(error.value)



# Generated at 2022-06-21 08:02:45.437679
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class B:
        pass
    class A(B, AnsibleCollectionConfig):
        pass

    assert not A.collection_finder
    assert not A.default_collection
    assert A.on_collection_load._handlers == set()

    assert isinstance(A.collection_paths, list)
    assert isinstance(A.playbook_paths, list)
    assert isinstance(A.on_collection_load, _EventSource)

    A.collection_finder = 1
    A.default_collection = 2
    A.on_collection_load += object()

    # Immutables
    assert A.collection_finder == 1
    assert A.default_collection == 2
    assert len(A.on_collection_load._handlers) == 1

# Generated at 2022-06-21 08:02:48.620827
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    events = _EventSource()
    events += lambda: None
    events += lambda s: None

    events.fire()
    events.fire('foo')

# Generated at 2022-06-21 08:02:53.000718
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c1 = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert c1._collection_finder is None
    assert c1._default_collection is None
    assert isinstance(c1._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:03:03.300145
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(x):
        nonlocal calls
        calls.append(('handler1', x))

    def handler2(x):
        nonlocal calls
        calls.append(('handler2', x))
        raise RuntimeError('handler2 exception')

    calls = []
    event_source += handler1
    event_source += handler2

    event_source.fire(1)
    assert calls == [('handler1', 1), ('handler2', 1)]

    calls = []
    event_source -= handler2
    event_source.fire(2)
    assert calls == [('handler1', 2)]

    calls = []
    event_source.fire(3)
    assert calls == [('handler1', 3)]

# Generated at 2022-06-21 08:03:13.146806
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def event_handler1(arg1, arg2):
        pass

    event_source += event_handler1
    assert len(event_source._handlers) == 1

    def event_handler2(arg1, arg2):
        pass

    event_source += event_handler2
    assert len(event_source._handlers) == 2

    event_source += event_handler1
    event_source += event_handler2
    assert len(event_source._handlers) == 2

    for handler in event_source._handlers:
        assert callable(handler)


# Generated at 2022-06-21 08:03:14.471000
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert hasattr(AnsibleCollectionConfig, '__init__')

# Generated at 2022-06-21 08:03:15.716959
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += 1
    assert False

# Generated at 2022-06-21 08:03:20.163841
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            self.fired = False

        def _fire(self):
            self.fired = True

    source = MyEventSource()
    source += source._fire
    assert not source.fired
    source.fire()
    assert source.fired



# Generated at 2022-06-21 08:03:31.367861
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestClass(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert TestClass._collection_finder is None
    assert TestClass._default_collection is None
    assert isinstance(TestClass._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:03:33.797498
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    def dummy():
        pass
    source += dummy
    source -= dummy
    source.fire()

# Generated at 2022-06-21 08:03:39.657162
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():

    config = AnsibleCollectionConfig()

    assert config.collection_finder is None
    assert config.default_collection is None
    assert config.on_collection_load is not None

    assert config.on_collection_load is config.on_collection_load
    assert config.on_collection_load is config.on_collection_load

    try:
        config.on_collection_load = 'abc'
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-21 08:03:45.575085
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Handler:
        def __init__(self, value):
            self.value = value
            self.invoked = False

        def __call__(self, *args, **kwargs):
            self.invoked = True

    event_source = _EventSource()

    handler1 = _Handler(1)
    handler2 = _Handler(2)
    handler3 = _Handler(3)

    event_source += handler1
    event_source += handler2
    event_source += handler3

    assert not handler1.invoked
    assert not handler2.invoked
    assert not handler3.invoked

    # cause handler1 to be invoked
    event_source.fire()

    assert handler1.invoked
    assert handler2.invoked
    assert handler3.invoked

    # remove handler1

# Generated at 2022-06-21 08:03:56.520192
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    # we must be able to add and remove handlers multiple times
    es += lambda: None # noqa
    es -= lambda: None # noqa
    es += lambda: None # noqa
    es -= lambda: None # noqa

    def handler2(ex):
        raise ValueError('handler2 expected exception not raised')

    try:
        es.__iadd__('a string')
        raise AssertionError('__iadd__ with a non-callable value did not raise')
    except ValueError:
        pass

    try:
        es.__isub__('a string')
        raise AssertionError('__isub__ with a non-callable value did not raise')
    except ValueError:
        pass

    es += handler2
    es -= handler2


# Generated at 2022-06-21 08:04:01.555295
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def dummy_handler(a, b, c):
        pass

    es += dummy_handler
    es += dummy_handler
    es += dummy_handler
    es += dummy_handler
    es += dummy_handler
    es += dummy_handler
    es += dummy_handler
    es += dummy_handler
    es += dummy_handler
    es += dummy_handler



# Generated at 2022-06-21 08:04:09.828001
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    """Unit test for method __isub__ of class _EventSource"""

    def _on_exception(handler, exc, *args, **kwargs):
        # if we return True, we want the caller to re-raise
        return True

    # ensure we can remove a handler that has never been registered
    class TestHandler:
        def __call__(self, *args, **kwargs):
            pass

    test_handler = TestHandler()
    event_source = _EventSource()
    event_source._on_exception = Mock(return_value=True)
    event_source -= test_handler

    # ensure we can remove a registered handler
    with patch.object(test_handler, '__call__') as m:
        event_source += test_handler
        event_source -= test_handler
        event_source.fire()
       

# Generated at 2022-06-21 08:04:21.896298
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def test_callable():
        pass

    try:
        _EventSource.__iadd__(None, test_callable)
        assert False, 'Expected ValueError'
    except ValueError as ex:
        assert str(ex) == 'handler must be callable'

    test_event_source = _EventSource()

    try:
        test_event_source += 1
        assert False, 'Expected ValueError'
    except ValueError as ex:
        assert str(ex) == 'handler must be callable'

    test_event_source += test_callable
    assert test_callable in test_event_source._handlers


# Generated at 2022-06-21 08:04:29.987345
# Unit test for constructor of class _EventSource
def test__EventSource():
    # test with good handler
    s = _EventSource()
    assert len(s._handlers) is 0
    assert callable(_EventSource.__iadd__)
    assert callable(_EventSource.__isub__)
    assert callable(_EventSource.fire)
    sentinel = object()
    def handler():
        assert sentinel is args[0]

    s += handler
    event_args = (sentinel,)
    event_kwargs = {'kw': 'kwargs'}

    s.fire(*event_args, **event_kwargs)
    assert len(s._handlers) is 1
    s -= handler
    assert len(s._handlers) is 0

    # test with invalid handler
    try:
        s += 42
        assert False, 'expected ValueError'
    except ValueError:
        pass


# Generated at 2022-06-21 08:04:33.464846
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._on_exception(None, None, None)


# Monkey-patch to support testing with ansible-test

# Generated at 2022-06-21 08:04:48.629664
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource()


# Generated at 2022-06-21 08:04:54.509151
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)
    assert len(AnsibleCollectionConfig.on_collection_load._handlers) == 0
    assert AnsibleCollectionConfig.playbook_paths == []
    assert '_AnsibleCollectionConfig' in repr(AnsibleCollectionConfig)



# Generated at 2022-06-21 08:04:58.501642
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler(arg, kwarg=None):
        return arg

    event_source += handler
    event_source -= handler
    assert event_source._handlers == set()


# Generated at 2022-06-21 08:05:04.831627
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()

    assert a.collection_finder is None

    assert a.collection_paths == []

    assert a.default_collection is None

    assert a.on_collection_load is not None
    assert a.on_collection_load.__class__.__name__ == '_EventSource'

    assert a.playbook_paths == []

# Generated at 2022-06-21 08:05:10.236876
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not AnsibleCollectionConfig._collection_finder
    assert hasattr(AnsibleCollectionConfig, '_default_collection')
    assert not AnsibleCollectionConfig._default_collection
    assert hasattr(AnsibleCollectionConfig, '_on_collection_load')
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:05:22.927810
# Unit test for constructor of class _EventSource
def test__EventSource():
    obj = _EventSource()

    assert obj._handlers == set()

    def handler(a, b, c=0, d=0):
        return a, b, c, d

    obj += handler

    assert len(obj._handlers) == 1

    del obj._handlers

    try:
        obj.fire(1, 2, 3, 4)
    except AttributeError:
        pass
    else:
        assert False, 'Mandatory AttributeError not raised'

    try:
        obj.fire(1, 2, 3, 4, d=5)
    except AttributeError:
        pass
    else:
        assert False, 'Mandatory AttributeError not raised'

    try:
        obj.fire(1, 2, 3, d=5)
    except AttributeError:
        pass

# Generated at 2022-06-21 08:05:24.844551
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert isinstance(event, _EventSource)


# Generated at 2022-06-21 08:05:30.008090
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.playbook_paths == []

# Generated at 2022-06-21 08:05:33.711535
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_event = _EventSource()

    def handler():
        pass

    test_event += handler
    test_event -= handler

    with pytest.raises(ValueError) as excinfo:
        test_event += 1
    assert 'handler must be callable' in str(excinfo.value)


# Generated at 2022-06-21 08:05:42.938128
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableSet

    e = _EventSource()
    try:
        e -= None
    except ValueError as err:
        assert "callable" in to_text(err)

    def f():
        pass

    assert f not in e._handlers
    e += f
    assert f in e._handlers
    e -= f
    assert f not in e._handlers

    assert isinstance(e._handlers, MutableSet)



# Generated at 2022-06-21 08:06:17.806916
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    # mock handler
    class MockHandler:
        def __init__(self, name):
            self._name = name
            self._call_count = 0

        def __call__(self):
            self._call_count += 1

        @property
        def name(self):
            return self._name

        @property
        def call_count(self):
            return self._call_count

    # initialize test
    h1 = MockHandler('h1')
    h2 = MockHandler('h2')
    h3 = MockHandler('h3')
    es += h1
    es += h2
    es += h3

    # test
    es-=h1
    es-=h2
    es-=h3
    es-=h3


# Generated at 2022-06-21 08:06:21.323926
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MyCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    config = MyCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None

# Generated at 2022-06-21 08:06:23.161491
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es



# Generated at 2022-06-21 08:06:34.280433
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_paths == []

    assert config.default_collection is None
    assert config.playbook_paths == []

    # try to set these attributes
    try:
        config.collection_finder = None
    except ValueError:
        pass
    else:
        assert False, "setting collection_finder should have caused ValueError"

    try:
        config.default_collection = None # pylint: disable=attribute-defined-outside-init
    except ValueError:
        assert False, "setting default_collection should not have caused ValueError"

    try:
        config.on_collection_load = None # pylint: disable=attribute-defined-outside-init
    except ValueError:
        assert False, "setting on_collection_load should not have caused ValueError"


# Generated at 2022-06-21 08:06:37.502733
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(event):
        pass
    es = _EventSource()
    es += handler
    es -= handler

# Generated at 2022-06-21 08:06:43.794529
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def test_1(a, b):
        assert False

    def test_2(a, b):
        assert False

    def test_3(a, b):
        assert False

    es = _EventSource()

    es += test_1
    es += test_2
    es += test_3

    es -= test_1
    es -= test_2
    es -= test_3

    es -= test_2

    assert not es._handlers

# Generated at 2022-06-21 08:06:46.796008
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def test_callback(source, event):
        pass

    source = _EventSource()
    source += test_callback



# Generated at 2022-06-21 08:06:56.943568
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class MyError(Exception):
        pass

    class MyExceptionHandler:
        def __init__(self):
            self._exception = None
            self._traceback = None

        def handled_exception(self):
            return self._exception

        def exception_traceback(self):
            return self._traceback

        def __call__(self, exception):
            self._exception = exception
            self._traceback = exception.__traceback__

    event_source = _EventSource()
    called_count = [0]

    def handler1(arg, kwarg=None):
        called_count[0] += 1

    def handler2(arg, kwarg=None):
        raise MyError("my handler2 failure")


# Generated at 2022-06-21 08:06:59.064587
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()
    print(ansible_collection_config)



# Generated at 2022-06-21 08:07:05.893865
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import sys

    es = _EventSource()
    assert isinstance(es, _EventSource)

    results = []

    def handle_event(obj, result):
        results.append(result)

    es += handle_event

    es.fire('hello world')
    es.fire('second hello world')
    assert results == ['hello world', 'second hello world']

    del es

    sys.exit(0)


# Generated at 2022-06-21 08:07:39.050775
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:07:46.161515
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)
    assert _AnsibleCollectionConfig.__name__ == '_AnsibleCollectionConfig'
    ansible_collection_config = _AnsibleCollectionConfig('name', (object,), {})
    assert isinstance(ansible_collection_config, type)
    assert ansible_collection_config.__name__ == '_AnsibleCollectionConfig'
    assert ansible_collection_config.__bases__ == (object,)


# Generated at 2022-06-21 08:07:47.976358
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    def handler(x):
        return x
    es += handler
    result = es.fire('hello')
    assert result is None


# Generated at 2022-06-21 08:07:50.727360
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    _AnsibleCollectionConfig.__init__(AnsibleCollectionConfig, 'meta', 'name', ('bases'))


__all__ = ('AnsibleCollectionConfig', 'test_AnsibleCollectionConfig')

# Generated at 2022-06-21 08:07:56.422614
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fired = []
    e = _EventSource()

    assert fired == []
    e.fire()
    assert fired == []

    def handler1():
        fired.append(1)

    def handler2():
        fired.append(2)

    e += handler1
    assert fired == []
    e.fire()
    assert fired == [1]

    e += handler2
    assert fired == [1]
    e.fire()
    assert fired == [1, 1, 2]

    e -= handler1
    assert fired == [1, 1, 2]
    e.fire()
    assert fired == [1, 1, 2, 2]



# Generated at 2022-06-21 08:07:59.801306
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.on_collection_load._handlers == set()
    assert AnsibleCollectionConfig.default_collection is None

# Generated at 2022-06-21 08:08:04.727663
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ansible_collection_config = _AnsibleCollectionConfig()
    assert isinstance(ansible_collection_config._collection_finder, None)
    assert isinstance(ansible_collection_config._default_collection, None)
    assert isinstance(ansible_collection_config._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:08:12.410935
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    def handler3():
        pass

    event_source += handler1
    event_source += handler2
    event_source += handler3

    # first removal
    event_source -= handler2

    assert event_source._handlers == {handler1, handler3}

    # second removal
    event_source -= handler2

    assert event_source._handlers == {handler1, handler3}

# Generated at 2022-06-21 08:08:17.140264
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler1(a):
        return a

    def handler2(a):
        return a

    event_source += handler1
    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source -= handler1
    assert len(event_source._handlers) == 1

    event_source -= handler2
    assert len(event_source._handlers) == 0



# Generated at 2022-06-21 08:08:20.473967
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert isinstance(config._on_collection_load, _EventSource)

# Unit tests for property collection_paths

# Generated at 2022-06-21 08:09:21.942807
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.collection_paths == []
    assert config.default_collection is None
    assert config.on_collection_load is config._on_collection_load
    assert config.playbook_paths == []

# Generated at 2022-06-21 08:09:24.945610
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

# Generated at 2022-06-21 08:09:27.538315
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    def handler(arg1, arg2):
        pass
    event += handler
    event -= handler
    assert handler not in event._handlers

# Generated at 2022-06-21 08:09:32.214554
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    actual = list()

    def handler_one(value):
        actual.append(value + 1)

    def handler_two(value):
        actual.append(value + 2)

    source += handler_one
    source += handler_two

    source.fire(1)

    expected = [2, 3]

    assert actual == expected

# Generated at 2022-06-21 08:09:43.293931
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Unittest for method _EventSource.__isub__
    # Ensures that a handler is removed from the list of handlers
    # when calling __isub__
    # Creates an instance of the class AnsibleCollectionConfig
    ansible_config = AnsibleCollectionConfig()

    # Installs a finder in the config
    class Finder:
        def find_collection_file(self, *args, **kwargs):
            pass
    ansible_config.collection_finder = Finder()

    # Sets a handler
    def handler():
        pass
    ansible_config.on_collection_load += handler

    # Removes the handler
    ansible_config.on_collection_load -= handler

    # Ensures that there is no more handlers
    assert len(ansible_config.on_collection_load._handlers) == 0


#

# Generated at 2022-06-21 08:09:49.976839
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyClass:
        pass

    instance = MyClass()

    instance.on_event = _EventSource()
    instance.on_event_exception = _EventSource()

    def handler1(msg):
        print(msg)
        raise Exception('exception in handler1')

    def handler2(msg):
        print(msg)
        raise Exception('exception in handler2')

    instance.on_event += handler1
    instance.on_event += handler2

    def handler_exception(handler, exc, msg):
        print(msg, 'exception in handler', handler)

    instance.on_event_exception += handler_exception

    instance.on_event._on_exception = handler_exception

    instance.on_event.fire('hello')

# Generated at 2022-06-21 08:09:53.446624
# Unit test for constructor of class _EventSource
def test__EventSource():
    if isinstance(getattr(AnsibleCollectionConfig, '_EventSource'), _EventSource):
        return "__init__() of AnsibleCollectionConfig._EventSource is a callable object"
    else:
        return "__init__() of AnsibleCollectionConfig._EventSource is not a callable object"


# Generated at 2022-06-21 08:10:02.749395
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    assert es.fire(1, 2) is None

    def h1(*args, **kwargs):
        raise ValueError('test')

    def h2(*args, **kwargs):
        raise ValueError('test')

    es += h1
    es += h2

    try:
        es.fire()
    except ValueError:
        pass
    else:
        raise AssertionError

    es -= h1
    try:
        es.fire()
    except ValueError:
        raise AssertionError

    assert es.fire(1) is None

    def h3(*args, **kwargs):
        raise ValueError('test')

    es += h3

    try:
        es.fire()
    except ValueError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-21 08:10:07.466023
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    if AnsibleCollectionConfig.collection_finder is None:
        assert True
    else:
        assert False

    if AnsibleCollectionConfig.default_collection is None:
        assert True
    else:
        assert False

    if AnsibleCollectionConfig.on_collection_load is not None:
        assert True
    else:
        assert False

    if AnsibleCollectionConfig.playbook_paths is None:
        assert True
    else:
        assert False


# Generated at 2022-06-21 08:10:12.336287
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # test 1
    es = _EventSource()
    def handler(a):
        pass
    es.fire(1)
    es += handler
    es -= handler
    es.fire(1)  # should not fail

    # test 2
    es = _EventSource()
    my_ex = Exception()
    def handler(a):
        raise my_ex
    es += handler
    es -= handler
    es.fire(1)  # should not fail