

# Generated at 2022-06-21 08:01:20.799504
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _IT:

        def t1(self, *args, **kwargs):
            pass

        def t2(self, *args, **kwargs):
            pass

        def t3(self, *args, **kwargs):
            pass

    es = _EventSource()

    i = _IT()

    es += i.t1
    es += i.t2
    es += i.t3

    es -= i.t2

    assert(len(es._handlers) == 2)
    assert(i.t1 in es._handlers)
    assert(i.t2 not in es._handlers)
    assert(i.t3 in es._handlers)


# Generated at 2022-06-21 08:01:23.622586
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:01:31.585397
# Unit test for constructor of class _EventSource
def test__EventSource():
    # testing __init__
    test_1 = _EventSource()
    assert test_1._handlers == set()

    # Test __iadd__
    test_1 += int

    test_1.fire(5)

    assert test_1._handlers == {int}

    # Test __isub__
    test_1 -= int
    assert test_1._handlers == set()

    test_1 -= int
    assert test_1._handlers == set()

    # Test _on_exception
    try:
        test_1.fire(5)
    except TypeError:
        pass

# Generated at 2022-06-21 08:01:43.715025
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class TestInvocationWarning(UserWarning):
        pass

    def handler_that_invokes_warning(x):
        # To test this, we will cause a warning to be logged.
        # This is the simplest way to cause a warning to be logged.
        # Note that we are not testing the warning or whether it was logged.
        warnings.warn('TestInvocationWarning', TestInvocationWarning)
        return x

    logger = logging.getLogger(__name__)
    logger.addHandler(logging.NullHandler())
    logger.propagate = False

    es = _EventSource()
    es += handler_that_invokes_warning

    es_size = len(es._handlers)

    es -= handler_that_invokes_warning


# Generated at 2022-06-21 08:01:51.970177
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a1 = AnsibleCollectionConfig()

    # We don't need a full test here, just see that the instance is created.
    # This test is really for the metaclass to catch missing overrides.
    assert a1._collection_finder is None
    assert a1._default_collection is None
    assert a1.collection_finder is None
    assert a1.collection_paths == []
    assert a1.default_collection is None
    assert a1.on_collection_load == a1._on_collection_load
    assert a1.playbook_paths == []



# Generated at 2022-06-21 08:01:54.468321
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')
# <<: unit test


collection_config = AnsibleCollectionConfig()

# Generated at 2022-06-21 08:02:06.195089
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import types
    import inspect

    def verify(cls):
        assert isinstance(cls, types.TypeType)

        assert isinstance(cls._collection_finder, property)
        assert isinstance(cls._default_collection, property)
        assert isinstance(cls._on_collection_load, property)
        assert isinstance(cls.collection_finder, property)
        assert isinstance(cls.collection_paths, property)
        assert isinstance(cls.default_collection, property)
        assert isinstance(cls.on_collection_load, property)
        assert isinstance(cls.playbook_paths, property)

        assert inspect.isfunction(cls._collection_finder.fget)
        assert inspect.isfunction(cls.collection_paths.fget)
        assert inspect.isf

# Generated at 2022-06-21 08:02:11.376197
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config_meta = type('AnsibleCollectionConfigMeta', (type,), {})
    config_meta.__init__('AnsibleCollectionConfig', 'name', 'bases')
    config_meta._collection_finder is None
    config_meta._default_collection is None
    config_meta._on_collection_load is not None



# Generated at 2022-06-21 08:02:12.109198
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    pass

# Generated at 2022-06-21 08:02:16.600402
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class FakeHandler:
        def __init__(self):
            self.invocation_count = 0

        def __call__(self):
            self.invocation_count += 1

    # Sanity
    handler = FakeHandler()
    es = _EventSource()
    es += handler
    es.fire()
    assert handler.invocation_count == 1



# Generated at 2022-06-21 08:02:31.442402
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventHandler1:
        def __init__(self):
            self._call_count = 0

        def __call__(self, *args, **kwargs):
            self._call_count += 1

        @property
        def call_count(self):
            return self._call_count

    class EventHandler2:
        def __init__(self):
            self._call_count = 0

        def __call__(self, *args, **kwargs):
            self._call_count += 1

            if kwargs.get('raise_exception', False):
                raise Exception('exception for testing')

        @property
        def call_count(self):
            return self._call_count

    on_event_1 = EventHandler1()
    on_event_2 = EventHandler2()

# Generated at 2022-06-21 08:02:34.498691
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')

# Generated at 2022-06-21 08:02:46.294381
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    source.__isub__(lambda: None)
    assert source._handlers == set()

    # add some handlers
    h0 = lambda: None
    h1 = lambda: 'h1'
    h2 = lambda: 'h2'
    h3 = lambda: 'h3'
    source += h0
    source += h1
    source += h2
    source += h3

    # remove them
    source.__isub__(h0)
    assert source._handlers == {h1, h2, h3}
    source.__isub__(h1)
    assert source._handlers == {h2, h3}
    source.__isub__(h2)
    assert source._handlers == {h3}
    source.__isub__(h3)

# Generated at 2022-06-21 08:02:56.944632
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler_a(a):
        pass

    def handler_b(b):
        pass

    es += handler_a
    es += handler_b

    assert handler_a in es._handlers
    assert handler_b in es._handlers

    # since handler_a and handler_b are defined twice, we expect them to only be in the set once
    assert len(es._handlers) == 2

    # test ValueError is raised when handler passed to __iadd__ isn't callable
    try:
        es += 'handler'
        assert False, 'Expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-21 08:03:09.113189
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from test.lib.ansible_test._internal.common.tempdir import TemporaryDirectory
    import logging
    import shutil
    import tempfile

    with TemporaryDirectory(suffix='-collection-loader_unit') as temp_dir:

        def write_file(path, content):
            with open(path, 'wb') as f:
                f.write(content)

        def read_file(path):
            with open(path, 'rb') as f:
                return f.read()

        def create_collection(directory, collection_name, content):
            # test case with a single item in the collection to make the test more straightforward
            collection_path = os.path.join(directory, collection_name)
            os.makedirs(collection_path)


# Generated at 2022-06-21 08:03:15.205900
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)


# For now, only the controller implementation has a requirement to install the finder via this function.
# We do not install it for the ansible-test implementation.

# Generated at 2022-06-21 08:03:16.838445
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def f():
        pass

    # should not raise
    es += f


# Generated at 2022-06-21 08:03:20.077453
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def f(text):
        print(text)

    queue = _EventSource()
    queue += f
    assert f in queue._handlers

    queue -= f
    assert f not in queue._handlers


# Generated at 2022-06-21 08:03:32.101663
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    handler_count = 0
    def handler(text):
        nonlocal handler_count
        handler_count += 1
        if text == 'raise':
            raise ValueError('test exception')

    e = _EventSource()
    e += handler
    e += handler
    e.fire('foo')
    assert handler_count == 2
    e.fire('foo')
    assert handler_count == 4
    e -= handler
    e.fire('bar')
    assert handler_count == 5
    e -= object()
    e.fire('bar')
    assert handler_count == 6

    e -= handler
    e._on_exception = lambda handler, ex, *args: False


# Generated at 2022-06-21 08:03:41.253752
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class MockException(Exception):
        pass

    class MockCollectionLoader:
        def __init__(self):
            self._calls = []

        def __call__(self, *args, **kwargs):
            self._calls.append((args, kwargs))
            raise MockException()

    source = _EventSource()
    loader = MockCollectionLoader()

    source += loader

    try:
        source.fire()
    except MockException:
        pass

    assert loader._calls == [((), {})]

    try:
        source.fire(1, 2, three='four')
    except MockException:
        pass

    assert loader._calls == [((), {}), ((1, 2), {'three': 'four'})]



# Generated at 2022-06-21 08:03:45.760425
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:03:49.533731
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: "foo"
    assert len(es._handlers) == 1
    es += lambda: "bar"
    assert len(es._handlers) == 2


# Generated at 2022-06-21 08:03:53.379855
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    handler = lambda x: x + 10
    es += handler
    assert handler in es._handlers

    es -= handler
    assert handler not in es._handlers

    es -= handler
    assert handler not in es._handlers



# Generated at 2022-06-21 08:03:54.697342
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += None



# Generated at 2022-06-21 08:04:01.040007
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    pass


# Install singleton into the module namespace
_ansible_collection_config = AnsibleCollectionConfig()

collection_finder = _ansible_collection_config.collection_finder
collection_paths = _ansible_collection_config.collection_paths
default_collection = _ansible_collection_config.default_collection
on_collection_load = _ansible_collection_config.on_collection_load
playbook_paths = _ansible_collection_config.playbook_paths



# Generated at 2022-06-21 08:04:02.657051
# Unit test for constructor of class _EventSource
def test__EventSource():
    eventsource = _EventSource()

# Unit tests for class _AnsibleCollectionConfig

# Generated at 2022-06-21 08:04:03.935745
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()

    assert isinstance(es, _EventSource)

# Generated at 2022-06-21 08:04:07.789427
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def handler():
        pass
    event_source += handler
    assert len(event_source._handlers) == 1
    event_source -= handler
    assert len(event_source._handlers) == 0
    # now try removing the handler again with no errors
    event_source -= handler


# Generated at 2022-06-21 08:04:09.916839
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:04:15.722067
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible_collections.collection_loader._event_source import _EventSource
    from ansible_collections.collection_loader.collections.ansible_meta.v000 import AnsibleCollectionConfig
    a = AnsibleCollectionConfig()
    assert a._collection_finder is None
    assert isinstance(a._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:04:21.746218
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cfg = AnsibleCollectionConfig()
    assert cfg._collection_finder is None
    assert cfg._default_collection is None

# Generated at 2022-06-21 08:04:23.454902
# Unit test for constructor of class _EventSource
def test__EventSource():
    src = _EventSource()
    assert src._handlers == set()



# Generated at 2022-06-21 08:04:28.316262
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def handler1(a):
        return a * 2
    def handler2(a):
        return a * a
    event_source += handler1
    event_source -= handler2
    event_source -= handler1
    event_source += handler2
    assert (event_source.fire(2) == 4)
    assert (event_source.fire(3) == 9)


# Generated at 2022-06-21 08:04:31.028214
# Unit test for constructor of class _EventSource
def test__EventSource():
    def on_event(arg1):
        pass

    source = _EventSource()
    source += on_event

    assert on_event in source._handlers

# Generated at 2022-06-21 08:04:32.705602
# Unit test for constructor of class _EventSource
def test__EventSource():
    x = _EventSource()

    assert x._handlers is not None

# Generated at 2022-06-21 08:04:33.952927
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource()


# Generated at 2022-06-21 08:04:37.763009
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_paths == []
    assert config.default_collection is None
    assert config.on_collection_load is None
    assert config.playbook_paths == []

# Generated at 2022-06-21 08:04:48.923511
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # prepare the test class
    class TestClass:
        def __init__(self):
            self._event_source = _EventSource()

        @property
        def event_source(self):
            return self._event_source

        @event_source.setter
        def event_source(self, value):
            if value is not self._event_source:
                raise ValueError('event_source is not directly settable (use +=)')

        def my_handler(self):
            pass

    # test event handler assignment
    c = TestClass()
    c.event_source += c.my_handler

    # test exception behavior
    c = TestClass()
    try:
        c.event_source += 42
    except ValueError:
        pass

# Generated at 2022-06-21 08:04:51.863613
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc = AnsibleCollectionConfig()
    assert acc.default_collection is None
    assert isinstance(acc.on_collection_load, _EventSource)

# TODO: replace this with something more meaningful
test_AnsibleCollectionConfig()

# Generated at 2022-06-21 08:05:03.959575
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def d1(x, y=10):
        print(x, y)

    def d2(x, y=20):
        print(x, y)

    def d3():
        raise Exception('d3')

    es = _EventSource()
    # test callable
    es += d1
    es.fire('a', y=20)
    assert d1 in es._handlers
    es += d2
    es.fire('b', y=20)
    assert d2 in es._handlers
    es -= d2
    try:
        es += d3
    except ValueError:
        assert True
    else:
        assert False
    try:
        es += 'bad'
    except ValueError:
        assert True
    else:
        assert False
    assert d3 not in es._handlers
   

# Generated at 2022-06-21 08:05:15.188029
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig()
    except TypeError as ex:
        # sanity check that we didn't forget to override the __init__ method
        assert 'object() takes no parameters' in str(ex)

# Generated at 2022-06-21 08:05:17.172980
# Unit test for constructor of class _EventSource
def test__EventSource():
    s = _EventSource()
    assert len(s) == 0



# Generated at 2022-06-21 08:05:28.808343
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # init
    event_source = _EventSource()

    # add a handler that is not a callable
    try:
        event_source += 1
        assert False, 'expected exception'
    except ValueError:
        pass

    # add and remove a handler
    handler = lambda: None
    event_source += handler
    event_source -= handler

    # add and remove a handler using __isub__ and __iadd__, respectively
    event_source.__isub__(handler)
    event_source += handler

    # add and remove a handler, removing one that has not been added
    event_source -= handler
    event_source += handler
    event_source -= handler

    # add multiple handlers
    handler1 = lambda: 'handler1'
    handler2 = lambda: 'handler2'
    event_source += handler1
    event

# Generated at 2022-06-21 08:05:31.345900
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class Test(AnsibleCollectionConfig):
        pass

    assert Test.collection_finder is None
    assert Test.collection_paths == []
    assert Test.default_collection is None
    assert Test.on_collection_load == Test._on_collection_load
    assert Test.playbook_paths == []

# Generated at 2022-06-21 08:05:32.580278
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _Dummy:
        pass

    _AnsibleCollectionConfig('meta', 'name', (_Dummy,))


# Generated at 2022-06-21 08:05:39.651016
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    def __init__(self, meta, name, bases):
        super(_AnsibleCollectionConfig, self).__init__(meta, name, bases)
        self._collection_finder = None
        self._default_collection = None
        self._on_collection_load = _EventSource()
        self.collection_finder = None
        self.collection_paths = None
        self.default_collection = None
        self.on_collection_load = None
        self.playbook_paths = None


# Generated at 2022-06-21 08:05:43.321101
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    t1 = type('Test1', (_AnsibleCollectionConfig,), {})
    instance = t1()
    assert isinstance(instance, _AnsibleCollectionConfig)
    assert isinstance(instance, t1)


# Generated at 2022-06-21 08:05:45.670317
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_source = _EventSource()
    assert test_source.fire() is None



# Generated at 2022-06-21 08:05:50.865159
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(_AnsibleCollectionConfig(), _AnsibleCollectionConfig)
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)
    assert isinstance(AnsibleCollectionConfig(), AnsibleCollectionConfig)
    assert AnsibleCollectionConfig is not None

# Generated at 2022-06-21 08:05:53.634734
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    event_source += lambda: 1
    event_source -= lambda: 1
    event_source -= lambda: 1



# Generated at 2022-06-21 08:06:08.541636
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    es = _EventSource()

    es += handler1
    assert handler1 in es._handlers

    es += handler2
    assert handler1 in es._handlers
    assert handler2 in es._handlers

    es -= handler2
    assert handler1 in es._handlers
    assert handler2 not in es._handlers

    es -= handler1
    assert handler1 not in es._handlers
    assert handler2 not in es._handlers


# Generated at 2022-06-21 08:06:10.959128
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def test_handler(arg1):
        pass

    es = _EventSource()
    es += test_handler
    assert es._handlers == {test_handler}


# Generated at 2022-06-21 08:06:16.697677
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler1():
        pass

    def handler2():
        pass

    def handler3():
        pass

    event = _EventSource()
    event += handler1
    event += handler2
    event += handler3
    original_handlers_count = len(event._handlers)

    event -= handler2
    event -= handler2
    event -= handler2
    event -= handler2
    event -= handler2
    event -= handler2
    event -= handler2

    assert len(event._handlers) == original_handlers_count - 1
    assert handler1 in event._handlers
    assert handler2 not in event._handlers
    assert handler3 in event._handlers

# Generated at 2022-06-21 08:06:18.580485
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    es -= lambda x: x


# Generated at 2022-06-21 08:06:22.790101
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, type)
    assert issubclass(AnsibleCollectionConfig, with_metaclass(_AnsibleCollectionConfig))
    assert not hasattr(AnsibleCollectionConfig, '__init__')


# Generated at 2022-06-21 08:06:24.308201
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource()._handlers == set()


# Generated at 2022-06-21 08:06:30.985516
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    times_called = [0]

    def handler1(source, **kwargs):
        times_called[0] += 1

    def handler2(source, **kwargs):
        times_called[0] *= 2

    e = _EventSource()
    e += handler1
    e += handler2
    e.fire()

    assert times_called[0] == 2


# Generated at 2022-06-21 08:06:33.408334
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MyClass(with_metaclass(_AnsibleCollectionConfig)):
        pass
    assert MyClass.collection_finder is None
    assert MyClass.default_collection is None

# Generated at 2022-06-21 08:06:38.818409
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # verify that a no-op works
    # and that adding a handler is idempotent
    es = _EventSource()
    es += lambda: None
    es += lambda: None
    es.fire()
    es.fire()

    # verify that adding two handlers works
    count = []
    es += lambda: count.append('A')
    es += lambda: count.append('B')
    es.fire()
    assert count == ['A', 'B']
    count[:] = []  # reinitialize

    # verify that an exception in a handler doesn't stop other handlers from running
    es = _EventSource()
    es += lambda: count.append('A')
    es += lambda: 1 / 0
    es += lambda: count.append('B')
    es.fire()
    assert count == ['A', 'B']


# Generated at 2022-06-21 08:06:47.094959
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler1():
        pass
    def handler2():
        pass

    # missing handler
    src = _EventSource()
    src += handler1
    src -= handler2

    # self.handlers is set, expected to be set with handler1
    assert len(src._handlers) == 1
    assert handler1 in src._handlers

    # unsubscribe handler1
    src -= handler1

    # self.handlers is empty, expected to have no any handlers
    assert len(src._handlers) == 0


# Generated at 2022-06-21 08:07:11.211862
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.utils.collection_loader._event_sources import _EventSource
    from ansible.utils.collection_loader._event_sources import _EventSourceException
    from ansible.utils.collection_loader._event_sources import _EventSourceBaseException

    def handler1(exc):
        raise RuntimeError('test')

    def handler2(exc):
        raise RuntimeError('test')

    def handler3(exc):
        raise RuntimeError('test')

    def handler4(exc):
        raise RuntimeError('test')

    def handler5(exc):
        raise RuntimeError('test')

    def handler6(exc):
        raise RuntimeError('test')

    def handler7(exc):
        raise RuntimeError('test')

    es = _EventSource()
    es += handler1
    es += handler2
    es += handler

# Generated at 2022-06-21 08:07:15.770641
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    metaclass = _AnsibleCollectionConfig('fake meta', 'name', 'bases')

    assert metaclass._collection_finder is None
    assert metaclass._default_collection is None
    assert isinstance(metaclass._on_collection_load, _EventSource)


# vim: autoindent expandtab tabstop=4 shiftwidth=4 softtabstop=4

# Generated at 2022-06-21 08:07:17.760175
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class test___AnsibleCollectionConfig(_AnsibleCollectionConfig):
        pass



# Generated at 2022-06-21 08:07:19.262961
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert isinstance(config, AnsibleCollectionConfig)

# Generated at 2022-06-21 08:07:29.435167
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evt = _EventSource()

    class _Exception(Exception):
        pass

    class _Substitute:
        def __init__(self, name, raise_exception=False):
            self._name = name
            self._raise_exception = raise_exception

        def __call__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs

            if self._raise_exception:
                raise _Exception()

        def __eq__(self, other):
            return (type(self) == type(other) and self._name == other._name)

    # trivial case
    a = _Substitute('a')
    evt += a
    evt.fire()
    assert a._args == ()
    assert a._kwargs == {}

    # handle exception


# Generated at 2022-06-21 08:07:34.380924
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    class MyMeta(type):
        def __init__(self, meta, name, bases):
            raise RuntimeError('oops')

    class MyClass(with_metaclass(MyMeta)):
        pass

    try:
        cls = MyClass()
        raise AssertionError('failed to raise exception')
    except RuntimeError as ex:
        if 'oops' not in str(ex):
            raise AssertionError('failed to raise exception containing "oops"')

# Generated at 2022-06-21 08:07:41.337823
# Unit test for constructor of class _EventSource
def test__EventSource():
    mock_handler = MockHandler(1)
    event_source = _EventSource()
    event_source += mock_handler

    # Callable mock handler should be added to the event_source
    assert len(event_source._handlers) == 1

    # Test to add the same mock handler again
    try:
        event_source += mock_handler
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-21 08:07:44.460565
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


_ansible_collection_config = AnsibleCollectionConfig()


# Generated at 2022-06-21 08:07:47.078989
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert isinstance(cls._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:07:49.832545
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += None
    es += lambda: None
    es += lambda x: None
    es += lambda x, y: None
    es += lambda x, y, z: None



# Generated at 2022-06-21 08:08:13.610737
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def test_callable(arg):
        return arg is not None

    event_source = _EventSource()

    assert not event_source._handlers

    event_source += test_callable
    assert test_callable in event_source._handlers

    event_source += test_callable  # should not raise
    assert test_callable in event_source._handlers

    try:
        event_source += None
        assert False, 'did not get expected ValueError'
    except ValueError:
        pass

    try:
        event_source += 'value'
        assert False, 'did not get expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-21 08:08:18.756253
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    added = False
    def noop():
        nonlocal added
        added = True
    source = _EventSource()
    source += noop
    source.fire()
    assert added



# Generated at 2022-06-21 08:08:20.776287
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

# Generated at 2022-06-21 08:08:31.021958
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def handler1(x):
        raise ValueError("handler1")

    def handler2(x):
        raise ValueError("handler2")

    event += handler1
    event += handler2

    try:
        event.fire("initial")
    except Exception as e:
        assert str(e) == "handler1"

    event -= handler1

    try:
        event.fire("after remove 1")
    except Exception as e:
        assert str(e) == "handler2"

    event += handler1

    try:
        event.fire("after add 1")
    except Exception as e:
        assert str(e) == "handler1"

    event -= handler1
    event -= handler2

    try:
        event.fire("after both remove")
    except Exception as e:
        assert True

# Generated at 2022-06-21 08:08:36.533380
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # setup
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler

    # verify
    assert handler in event_source._handlers

    # execute
    event_source -= handler

    # verify
    assert handler not in event_source._handlers


# Generated at 2022-06-21 08:08:38.321474
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda *a, **kw: print("Called lambda function")
    event_source.fire()

# Generated at 2022-06-21 08:08:46.012022
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from tempfile import NamedTemporaryFile

    def _create_temp_file():
        temp_file = NamedTemporaryFile(mode='w+', encoding='utf-8')

        def write_temp_file(event):
            temp_file.write(u'-')

        event_source = _EventSource()
        event_source += write_temp_file

        event_source.fire()

        return temp_file

    with _create_temp_file() as temp_file:
        temp_file.seek(0)

        assert temp_file.read() == u'-'



# Generated at 2022-06-21 08:08:49.145807
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import inspect
    assert inspect.isclass(_AnsibleCollectionConfig)
    assert '_AnsibleCollectionConfig' == _AnsibleCollectionConfig.__name__



# Generated at 2022-06-21 08:08:50.549094
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac._collection_finder is None



# Generated at 2022-06-21 08:08:54.980175
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class M(_AnsibleCollectionConfig):
        pass

    m = M()
    assert m._collection_finder is None
    assert m._default_collection is None


# Generated at 2022-06-21 08:09:31.715863
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert len(e._handlers) == 0
    assert e.__iadd__(lambda x, y: x+y) is e
    assert len(e._handlers) == 1
    assert e._handlers.pop()(1, 2) == 3
    assert len(e._handlers) == 0
    try:
        e.__iadd__(None)
        assert False, 'ValueError should have been raised'
    except ValueError:
        pass


# Generated at 2022-06-21 08:09:42.803176
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    def on_foo(a, b, c):
        print("on_foo invoked with arguments: %s %s %s" % (a, b, c))

    def on_bar(a, b, c):
        print("on_bar invoked with arguments: %s %s %s" % (a, b, c))

    x = _EventSource()

    # test adding handler
    x += on_foo
    x.fire("a", "b", "c")

    # test removing handler
    x -= on_foo
    x.fire("a", "b", "c")

    # test exception handling
    def on_fail(a, b, c):
        raise ValueError("foo")

    x += on_fail
    x += on_bar


# Generated at 2022-06-21 08:09:46.193560
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _MyEventSource(_EventSource):
        pass

    def handler_method(arg):
        pass

    test_os = _MyEventSource()
    test_os += handler_method

    assert test_os._handlers

    test_os -= handler_method

    assert not test_os._handlers

# Generated at 2022-06-21 08:09:47.509256
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc = AnsibleCollectionConfig()


# Generated at 2022-06-21 08:09:48.813147
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()



# Generated at 2022-06-21 08:09:51.056297
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Note: Functions in this file are especially sensitive to test order

    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1

# Generated at 2022-06-21 08:09:53.961694
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible.module_utils._text import to_bytes

    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    event_source -= handler

    assert event_source._handlers == set()


# Generated at 2022-06-21 08:10:01.415246
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockHandler1:
        def __call__(self, *args, **kwargs):
            pass

    class MockHandler2:
        def __call__(self, *args, **kwargs):
            raise Exception()

    class MockHandler3:
        def __call__(self, *args, **kwargs):
            raise Exception()

        def _on_exception(self, exc, *args, **kwargs):
            return False

    event_source = _EventSource()
    event_source += MockHandler1()
    event_source += MockHandler2()
    event_source += MockHandler3()

    event_source.fire()

# Generated at 2022-06-21 08:10:05.228067
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cc = AnsibleCollectionConfig()
    assert cc.collection_finder is None, 'collection_finder should be None'
    assert cc.on_collection_load._handlers == set(), 'on_collection_load should be empty'
    assert not hasattr(cc, '_AnsibleCollectionConfig__dict__'), 'AnsibleCollectionConfig should not have __dict__'

# Generated at 2022-06-21 08:10:09.034531
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.playbook_paths is None

# Generated at 2022-06-21 08:11:07.385344
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source_fired = []

    def handler1(*args, **kwargs):
        event_source_fired.append((1, args, kwargs))

    def handler2(*args, **kwargs):
        event_source_fired.append((2, args, kwargs))

    def handler3(*args, **kwargs):
        event_source_fired.append((3, args, kwargs))
        raise Exception('handler3 raised an exception')

    def handler4(handler, ex, *args, **kwargs):
        event_source_fired.append((4, handler, ex, args, kwargs))
        return False

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source._on_exception += handler4

# Generated at 2022-06-21 08:11:10.984968
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestClass(_AnsibleCollectionConfig):
        def __init__(self):
            super(TestClass, self).__init__('Meta', 'TestClass', ())

    assert isinstance(TestClass(), TestClass)

# Generated at 2022-06-21 08:11:14.440609
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()
    assert not x._handlers

    def f(x, y):
        pass
    x += f
    assert x._handlers == {f}

    x += f
    assert x._handlers == {f}
