

# Generated at 2022-06-21 08:01:28.959530
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # test instantiation
    assert not hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert not hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert not hasattr(AnsibleCollectionConfig, 'default_collection')
    assert not hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert not hasattr(AnsibleCollectionConfig, 'playbook_paths')

# Generated at 2022-06-21 08:01:35.206096
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    # one
    def one(a):
        assert a == 1
    e += one
    e.fire(1)

    # other
    def other(a):
        assert a == 2
    e += other
    e.fire(2)

    # replace one
    def one(a):
        assert a == 3
    e += one
    e.fire(3)

    # remove other
    e -= other
    with raises(AssertionError):
        e.fire(2)

    # one
    e.fire(1)

    # add and remove non-existent
    e += other
    e -= other



# Generated at 2022-06-21 08:01:36.265580
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:01:41.260738
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler

    assert handler in event_source._handlers

    event_source -= handler

    assert handler not in event_source._handlers

    event_source -= handler

    assert handler not in event_source._handlers

# Generated at 2022-06-21 08:01:41.893511
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource

# Generated at 2022-06-21 08:01:44.916807
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert isinstance(cls._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:01:46.519462
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()


# Generated at 2022-06-21 08:01:48.866202
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None



# Generated at 2022-06-21 08:01:50.474630
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert not config._on_collection_load._handlers


# Generated at 2022-06-21 08:02:00.207312
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()

    handler1 = lambda: None
    handler2 = lambda: None
    handler3 = lambda: None

    e += handler1
    assert handler1 in e._handlers
    assert handler2 not in e._handlers
    assert handler3 not in e._handlers

    e += handler2
    assert handler1 in e._handlers
    assert handler2 in e._handlers
    assert handler3 not in e._handlers

    e -= handler1
    assert handler1 not in e._handlers
    assert handler2 in e._handlers
    assert handler3 not in e._handlers

    e -= handler2
    assert handler1 not in e._handlers
    assert handler2 not in e._handlers
    assert handler3 not in e._handlers

    e -= handler3
    assert handler1 not in e._hand

# Generated at 2022-06-21 08:02:07.064909
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    instance = _EventSource()
    instance.__iadd__(lambda: None)
    instance.__isub__(lambda: None)
    assert len(instance._handlers) == 0

# Generated at 2022-06-21 08:02:17.270571
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    from ansible.utils.collection_loader import _AnsibleCollectionConfig

    # _AnsibleCollectionConfig is an _AnsibleCollectionConfig
    assert issubclass(_AnsibleCollectionConfig, type)

    _AnsibleCollectionConfig._collection_finder = 'abc'
    _AnsibleCollectionConfig._default_collection = 'def'

    try:
        # second call raises an exception
        _AnsibleCollectionConfig.collection_finder = 'ghi'
        assert False
    except ValueError:
        pass

    try:
        # second call raises an exception
        _AnsibleCollectionConfig.default_collection = 'ghi'
        assert False
    except ValueError:
        pass

    assert _AnsibleCollectionConfig._collection_finder == 'abc'
    assert _AnsibleCollectionConfig._default_collection == 'def'

# Generated at 2022-06-21 08:02:29.936616
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()

    assert isinstance(c.on_collection_load, _EventSource)
    assert isinstance(c._on_collection_load, _EventSource)
    assert c.on_collection_load is c._on_collection_load

    # ensure handler is callable
    try:
        c.on_collection_load += 'not callable'
    except ValueError:
        pass
    else:
        assert False, "on_collection_load did not raise an exception"

    try:
        c.on_collection_load = 'not callable'
    except ValueError:
        pass
    else:
        assert False, "on_collection_load did not raise an exception"

    # ensure handler is callable

# Generated at 2022-06-21 08:02:33.086418
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.on_collection_load._handlers == set()

# Generated at 2022-06-21 08:02:41.858177
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSource_T(_EventSource):
        def __init__(self):
            super(EventSource_T, self).__init__()
            self.event_arg = None

        def fire(self, arg):
            self.event_arg = arg

    # The first handler should take precedence
    s = EventSource_T()
    s += lambda arg: 'First'
    s += lambda arg: 'Second'
    s.fire('Test')
    assert s.event_arg == 'First'



# Generated at 2022-06-21 08:02:48.675400
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    evt = _EventSource()
    test_results = []

    def test_handler(*args, **kwargs):
        test_results.append((args, kwargs))

    evt += test_handler
    evt += test_handler

    assert evt._handlers == set([test_handler, test_handler])

    evt.fire(1, 2, 3, four=4, five=5)

    assert test_results == [
        ((1, 2, 3), dict(four=4, five=5)),
        ((1, 2, 3), dict(four=4, five=5)),
    ]



# Generated at 2022-06-21 08:03:00.274635
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    # test that an event source registered with itself is a no-op
    assert event_source == event_source + event_source
    assert not event_source._handlers
    # test that registering a callable works
    test_func = lambda *args, **kwargs: None
    assert test_func in event_source._handlers
    assert test_func == event_source + test_func
    assert test_func in event_source._handlers
    # test that registering an invalid event handler fails
    event_source._handlers.clear()
    assert 'non_callable' not in event_source._handlers
    try:
        event_source += 'non_callable'
        assert False
    except ValueError:
        assert True
    assert 'non_callable' not in event_source._hand

# Generated at 2022-06-21 08:03:12.309906
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def foo(bar):
        return "%s" % bar

    def bam(bar, baz):
        return "%s %s" % (bar, baz)

    test_event = _EventSource()
    test_event += foo
    test_event += bam

    assert test_event.fire("foo") == None

    class FakeException(RuntimeError):
        pass

    def fake_on_exception(handler, exc, *args, **kwargs):
        # if we return True, we want the caller to re-raise
        return True

    test_event._on_exception = fake_on_exception

    try:
        test_event.fire("raise", "exception")
        assert False, "Should've thrown an exception"
    except FakeException:
        pass

    # method fire of class _EventSource uses the

# Generated at 2022-06-21 08:03:14.781053
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:03:17.383953
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    s = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    s += handler1
    s += handler2

    assert s._handlers == {handler1, handler2}


# Generated at 2022-06-21 08:03:22.825846
# Unit test for constructor of class _EventSource
def test__EventSource():
    src = _EventSource()
    assert src._handlers == set()



# Generated at 2022-06-21 08:03:29.153252
# Unit test for constructor of class _EventSource
def test__EventSource():
    def call_one():
        pass

    def call_two():
        pass

    def call_three():
        raise RuntimeError()

    event = _EventSource()
    event += call_one
    event += call_two
    event += call_three

    try:
        event.fire()
        assert False, 'Exception did not raise'
    except Exception:
        pass

    event -= call_one


# Generated at 2022-06-21 08:03:32.506236
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class RemoveHandler(_ExceptionHandler):
        def on_exception(self, handler, exc, *args, **kwargs):
            handler_removed[0] = handler
            return False

    handler_removed = [None]
    events = _EventSource()
    handler_1 = RemoveHandler(0)
    handler_2 = _ExceptionHandler(1)
    events += handler_1
    events += handler_2
    events -= handler_1
    assert handler_removed == [handler_1]
    events.fire()
    assert handler_1.exc is None
    assert handler_2.exc


# Generated at 2022-06-21 08:03:41.822665
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ev = _EventSource()
    results = []

    def handler1(*args, **kwargs):
        results.append('handler1 called with args=%s kwargs=%s' % (args, kwargs))

    def handler2(*args, **kwargs):
        results.append('handler2 called with args=%s kwargs=%s' % (args, kwargs))

    def handler3(*args, **kwargs):
        raise RuntimeError('unexpected exception from handler3')

    ev += handler1
    ev += handler2

    ev.fire()
    assert results == [
        'handler1 called with args=() kwargs={}',
        'handler2 called with args=() kwargs={}',
    ]

    results.clear()

# Generated at 2022-06-21 08:03:53.203535
# Unit test for constructor of class _EventSource
def test__EventSource():

    def _test_handler(arg1, arg2):
        return arg1 + arg2

    ev = _EventSource()
    assert not ev._handlers

    def _test_bad_handler():
        _ = ev + 1

    try:
        _test_bad_handler()
    except ValueError:
        pass
    else:
        assert False, 'failure to raise ValueError for non-callable handler'

    ev += _test_handler
    assert ev._handlers == set([_test_handler])

    ev -= _test_handler
    assert not ev._handlers

    ev -= _test_handler
    assert not ev._handlers

    assert ev._on_exception(_test_handler, Exception('test'))

    ev += _test_handler
    ev.fire('a', 'b')



# Generated at 2022-06-21 08:03:57.777664
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()

    assert ansible_collection_config.collection_finder is None
    assert ansible_collection_config.default_collection is None
    assert ansible_collection_config.on_collection_load is not None
    assert ansible_collection_config.playbook_paths is None



# Generated at 2022-06-21 08:04:06.770255
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, object)
    assert type(AnsibleCollectionConfig) == _AnsibleCollectionConfig
    assert issubclass(_AnsibleCollectionConfig, type)
    assert '_collection_finder' in AnsibleCollectionConfig.__dict__
    assert '_default_collection' in AnsibleCollectionConfig.__dict__
    assert '_on_collection_load' in AnsibleCollectionConfig.__dict__
    assert 'collection_finder' in AnsibleCollectionConfig.__dict__
    assert 'collection_paths' in AnsibleCollectionConfig.__dict__
    assert 'default_collection' in AnsibleCollectionConfig.__dict__
    assert 'on_collection_load' in AnsibleCollectionConfig.__dict__
    assert 'playbook_paths' in AnsibleCollectionConfig.__dict__

# Generated at 2022-06-21 08:04:13.595995
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    def foo(result):
        result.append(1)

    def bar(result):
        raise ValueError('bar raised an exception')

    def baz(result):
        result.append(3)
        raise ValueError('baz raised an exception')

    result = []
    es += foo
    es += bar
    es += baz

    try:
        es.fire(result)
    except:
        pass

    return True, 1

# Generated at 2022-06-21 08:04:15.830679
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig.__init__(_AnsibleCollectionConfig, None, None, None)


# Generated at 2022-06-21 08:04:19.324019
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(a, b):
        pass

    es = _EventSource()
    es.handler = handler
    es += handler
    es += handler

    len(es._handlers) == 2

# Generated at 2022-06-21 08:04:36.343314
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    # tests when handler is callable
    assert event_source.__iadd__ == event_source.__iadd__(handler)
    assert handler in event_source._handlers
    assert event_source._handlers == set([handler])

    # tests when handler is not callable
    with pytest.raises(ValueError):
        event_source.__iadd__ == event_source.__iadd__('not callable')


# Generated at 2022-06-21 08:04:42.839957
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    def test_method(self):
        pass

    class TestConfig:
        __metaclass__ = _AnsibleCollectionConfig

    t = TestConfig()

    # read-only properties should be present
    assert not hasattr(t, 'other')
    assert hasattr(t, 'collection_paths')
    assert hasattr(t, 'default_collection')
    assert hasattr(t, 'on_collection_load')
    assert hasattr(t, 'playbook_paths')

    # read-only properties should be of the correct type
    assert isinstance(t.collection_paths, property)
    assert isinstance(t.default_collection, property)
    assert isinstance(t.on_collection_load, property)
    assert isinstance(t.playbook_paths, property)

    # read-only properties should

# Generated at 2022-06-21 08:04:44.783896
# Unit test for constructor of class _EventSource
def test__EventSource():
    instance = _EventSource()
    assert instance._handlers == set()


# Generated at 2022-06-21 08:04:49.588598
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class Test(object):
        def test(self, evt):
            evt += self.on_event
            evt -= self.on_event

        def on_event(self, *args, **kwargs):
            pass

    t = Test()

    evt = _EventSource()

    t.test(evt)



# Generated at 2022-06-21 08:04:57.210044
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Source(_EventSource):
        def __init__(self):
            super(Source, self).__init__()

            self._handler_exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._handler_exception_count += 1

    source = Source()

    def handler(*args, **kwargs):
        raise RuntimeError()

    source += handler

    try:
        source.fire()
    except RuntimeError:
        pass

    assert source._handler_exception_count == 1

# Generated at 2022-06-21 08:04:58.770385
# Unit test for constructor of class _EventSource
def test__EventSource():
    s = _EventSource()
    assert s._handlers == set()



# Generated at 2022-06-21 08:05:01.958011
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_event = _EventSource()
    assert test_event._on_exception is _EventSource._on_exception


# Generated at 2022-06-21 08:05:08.307542
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    this_module = sys.modules[__name__]
    metacls = getattr(this_module, '_AnsibleCollectionConfig')
    metacls = metacls.__new__(metacls)
    obj = metacls(str, 'Foo', (object,))
    assert isinstance(obj, _AnsibleCollectionConfig)
    assert obj._collection_finder is None
    assert obj._default_collection is None

# Generated at 2022-06-21 08:05:10.505621
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda: None
    e += lambda x: None
    e += lambda x, y: None
    e += lambda x, y, z: None


# Generated at 2022-06-21 08:05:11.972365
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()



# Generated at 2022-06-21 08:05:32.868058
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config.on_collection_load is not None
    assert isinstance(config.on_collection_load, _EventSource)

# Generated at 2022-06-21 08:05:36.963572
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    handler1 = object()
    handler2 = object()
    es = _EventSource()
    es += handler1
    es += handler2
    assert len(es._handlers) == 2
    es -= handler1
    assert len(es._handlers) == 1
    es -= handler1
    assert len(es._handlers) == 1
    es -= handler2
    assert len(es._handlers) == 0

# Generated at 2022-06-21 08:05:44.147682
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    source += handler1
    source += handler2

    assert len(source._handlers) == 2
    assert handler1 in source._handlers
    assert handler2 in source._handlers

    source -= handler1

    assert len(source._handlers) == 1
    assert handler1 not in source._handlers
    assert handler2 in source._handlers



# Generated at 2022-06-21 08:05:56.153415
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return bool(args or kwargs)

    es = _TestEventSource()

    results = []

    def handler1(*args, **kwargs):
        results.append(('handler1', args, kwargs))

    def handler2(*args, **kwargs):
        results.append(('handler2', args, kwargs))

    es += handler1
    es += handler2
    es.fire()

    assert results == [
        ('handler1', (), {}),
        ('handler2', (), {}),
    ]

    results = []
    es.fire(1, 2, b=4)

# Generated at 2022-06-21 08:06:07.246768
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    assert hasattr(AnsibleCollectionConfig, '_on_collection_load')
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert not hasattr(AnsibleCollectionConfig._on_collection_load, 'string')
    assert not hasattr(AnsibleCollectionConfig._on_collection_load, 'list')

    def func1(self):
        pass

    def func2(self):
        pass

    def func3(self):
        pass

    # add func1 to _on_collection_load
    AnsibleCollectionConfig._on_collection_load += func1
    assert hasattr(AnsibleCollectionConfig._on_collection_load, '_handlers')
    assert func1 in AnsibleCollectionConfig._on_collection_load._handlers
    assert func2 not in AnsibleCollectionConfig

# Generated at 2022-06-21 08:06:10.475527
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert len(AnsibleCollectionConfig.__mro__) == 3
    assert AnsibleCollectionConfig.__mro__[1] is _AnsibleCollectionConfig
    assert AnsibleCollectionConfig.__mro__[2] is object



# Generated at 2022-06-21 08:06:17.114173
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert len(event._handlers) == 0
    assert callable(event.__iadd__)
    assert callable(event.__isub__)
    assert callable(event._on_exception)
    assert callable(event.fire)

    # Add a handler to the collection of handlers
    def f_handler(x):
        pass
    event += f_handler
    assert len(event._handlers) == 1
    assert f_handler in event._handlers

    # Remove a handler that was never added should not raise exception
    event -= f_handler
    assert len(event._handlers) == 0

    # Adding a handler that isn't callable
    try:
        event += 'a_non_callable'
    except ValueError:
        assert len(event._handlers) == 0

# Generated at 2022-06-21 08:06:19.323788
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)


# Generated at 2022-06-21 08:06:19.945416
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:06:31.987833
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _Foo(_EventSource):
        pass

    foo = _Foo()

    foo += lambda: None

    foo.fire()

    try:
        foo += 'not callable'
        raise Exception("foo += 'not callable' should raise ValueError")
    except ValueError:
        pass

    # should raise TypeError
    try:
        foo += lambda: 1 + 'string'
    except TypeError:
        pass

    foo += lambda: 1 + 'string'

    try:
        foo.fire()
        raise Exception("foo.fire() should raise TypeError")
    except TypeError:
        pass

    # should have removed the previous lambda
    foo.fire()

    # check on_exception logic


# Generated at 2022-06-21 08:06:56.137256
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Foo(AnsibleCollectionConfig):
        pass

    foo = Foo()  # default constructor
    assert foo._collection_finder is None
    assert foo._default_collection is None
    assert foo._on_collection_load is foo.on_collection_load



# Generated at 2022-06-21 08:06:57.930606
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc = AnsibleCollectionConfig()
    assert acc.__class__._on_collection_load

# Generated at 2022-06-21 08:07:02.911343
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    # test removing a non-existent handler
    event.__isub__(None) # nothing should happen
    event.__isub__(Exception()) # nothing should happen
    event.__isub__('this will not match any handler') # nothing should happen



# Generated at 2022-06-21 08:07:12.925534
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestFailedException(Exception):
        pass

    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._handler_call_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            raise _TestFailedException('handler {0} raised exception {1}'.format(handler, exc))

        def handler_a(self, *args, **kwargs):
            self._handler_call_count += 1
            if self._handler_call_count == 2:
                raise ValueError('test exception')

    tes = _TestEventSource()
    tes += tes.handler_a


# Generated at 2022-06-21 08:07:18.652705
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    source = _EventSource()

    source += handler
    assert source._handlers == {handler}, source._handlers

    source += handler
    assert source._handlers == {handler}, source._handlers

    source += handler
    assert source._handlers == {handler}, source._handlers

    try:
        source += 1
    except Exception as ex:
        assert type(ex) is ValueError



# Generated at 2022-06-21 08:07:25.674245
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def mocked_handler_1(*args, **kwargs):
        assert args == ('a',)
        assert kwargs == {'b': 2}
        return omitted_return_value

    def mocked_handler_2(*args, **kwargs):
        assert args == ('a',)
        assert kwargs == {'b': 2}
        return omitted_return_value

    event_source = _EventSource()

    event_source += mocked_handler_1
    event_source += mocked_handler_2

    omitted_return_value = event_source.fire('a', b=2)

# Generated at 2022-06-21 08:07:26.778481
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()



# Generated at 2022-06-21 08:07:33.621173
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_collections.test.unit.test_utils.mock import Mock

    source = _EventSource()

    handler_1 = Mock()
    handler_2 = Mock()

    source += handler_1
    source.fire()
    handler_1.assert_called_once_with()

    source += handler_2
    source.fire()
    handler_1.assert_called_with()
    handler_2.assert_called_with()

    handler_1.assert_called_once()
    handler_2.assert_called_once()



# Generated at 2022-06-21 08:07:35.338027
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    x = AnsibleCollectionConfig()

# Generated at 2022-06-21 08:07:45.351903
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _MockEventFiringClass:
        def __init__(self):
            self.on_event_fired = _EventSource()

        def fire_event(self, arg):
            self.on_event_fired.fire(arg)

        def register_handler(self, handler):
            self.on_event_fired += handler

    def test_function(arg):
        return arg

    # Arrange
    instance = _MockEventFiringClass()
    instance.register_handler(test_function)
    expected = 'foo'

    # Act
    instance.fire_event(expected)

    # Assert
    assert test_function(expected) == expected

# Generated at 2022-06-21 08:08:34.714542
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # GIVEN
    def handler_a(*args, **kwargs):
        # raise Exception('foo')
        raise ValueError('exception')

    def handler_b(x, y):
        pass

    event = _EventSource()
    event += handler_a
    event += handler_b

    # WHEN
    with pytest.raises(ValueError):
        event.fire('value', y='kwarg')

    # THEN
    pass



# Generated at 2022-06-21 08:08:38.168790
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig('dummy_meta', 'dummy_name', 'dummy_bases')
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert isinstance(cls._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:08:46.190736
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler():
        pass

    es = _EventSource()
    es += handler
    assert handler in es._handlers
    es += handler
    assert len(es._handlers) == 1

    def handler_fail():
        import math
        x = math.log(-1)

    try:
        es += handler_fail
    except ValueError:
        pass
    else:
        assert False, "ValueError should have been raised"

    try:
        es += None
    except ValueError:
        pass
    else:
        assert False, "ValueError should have been raised"



# Generated at 2022-06-21 08:08:50.285983
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    mm = _AnsibleCollectionConfig

    # no errors means it works
    assert mm._collection_finder is None
    assert mm._default_collection is None
    assert len(mm.on_collection_load._handlers) == 0



# Generated at 2022-06-21 08:09:00.716941
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Mock():
        def calls(self):
            return self._calls

        def __init__(self):
            self._calls = []

        def __call__(self, *args, **kwargs):
            self._calls.append((args, kwargs))

    e = _EventSource()
    m1 = Mock()
    m2 = Mock()

    e += m1
    e += m2

    e.fire('a')
    assert m1._calls == [('a',)]
    assert m2._calls == [('a',)]

    e.fire(arg='a')
    assert m1._calls == [('a',), ({'arg': 'a'},)]
    assert m2._calls == [('a',), ({'arg': 'a'},)]

    e -= m1


# Generated at 2022-06-21 08:09:01.747409
# Unit test for constructor of class _EventSource
def test__EventSource():
    s = _EventSource()
    assert s._handlers == set()

# Generated at 2022-06-21 08:09:06.710121
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler_1(a, b):
        print(a, b)

    def handler_2(a, b):
        print(a + b)

    def handler_3(a, b):
        print(a[b])

    event_source = _EventSource()
    assert isinstance(event_source, _EventSource)


# Generated at 2022-06-21 08:09:09.661223
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # use the concrete property on_collection_load to invoke __iadd__
    AnsibleCollectionConfig.on_collection_load += print



# Generated at 2022-06-21 08:09:14.445122
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()

    def f1(x):
        return 'f1 got value: %s' % x

    def f2(x):
        return 'f2 got value: %s' % x

    s += f1
    s += f2

    r = s.fire('test_value')
    assert r is None



# Generated at 2022-06-21 08:09:17.309105
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()

    assert a.collection_finder is None
    assert a.default_collection is None
    assert a.on_collection_load is a._on_collection_load

# Generated at 2022-06-21 08:11:02.718412
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.default_collection is None



# Generated at 2022-06-21 08:11:05.640213
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event += lambda: print("#1 called")
    event += lambda: print("#2 called")
    event += lambda: print("#3 called")
    event.fire()



# Generated at 2022-06-21 08:11:08.691373
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def _handler(*args, **kwargs):
        pass

    test = _EventSource()
    test += _handler
    test.fire('hello')
    test -= _handler

# Generated at 2022-06-21 08:11:15.720869
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # noinspection PyMissingTypeHints
    def handler1(*args, **kwargs):
        # noinspection PyUnresolvedReferences
        print(args, kwargs)

    def handler2(*args, **kwargs):
        raise Exception('handler2')

    # noinspection PyMissingTypeHints
    def handler3(*args, **kwargs):
        # noinspection PyUnresolvedReferences
        print(args, kwargs)

    s = _EventSource()
    s += handler1
    s += handler2
    s += handler3

    s.fire(1, 2, a=3)

# Generated at 2022-06-21 08:11:25.321139
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.basic import do_nothing
    # On Python 2, callable() returns true for classes and instances of classes.
    # On Python 3, __call__ is an abstract method of the ABC (abstract base class) 'Callable', so an instance
    # of a non-abstract class that does not implement __call__ is not callable.
    # Neither class is implemented in this file.
    event = _EventSource()
    # event should start with empty handlers
    assert event._handlers == set()
    # add a function
    event += do_nothing
    # add a callable class
    event += CallableClass
    # add a non-callable class (should raise error)