

# Generated at 2022-06-21 08:01:31.668275
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def called(s):
        called.s = s  # pylint: disable=attribute-defined-outside-init

    def called_kwargs(**kwargs):
        called_kwargs.kwargs = kwargs  # pylint: disable=attribute-defined-outside-init

    def called_args(*args):
        called_args.args = args  # pylint: disable=attribute-defined-outside-init

    called.s = None
    called_kwargs.kwargs = None
    called_args.args = None

    s = _EventSource()
    s += called
    s += called_args
    s += called_kwargs
    s.fire('test', 1, 2, a=3, b=4)

    assert called.s == 'test'

# Generated at 2022-06-21 08:01:34.236342
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    evt = _EventSource()
    evt += lambda: None
    assert len(evt._handlers) == 1



# Generated at 2022-06-21 08:01:41.312656
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # GIVEN:
    #    An instance of _EventSource (es)
    #    A handler
    es = _EventSource()
    handler = lambda: None

    # WHEN:
    #    We add the handler
    es += handler

    # THEN:
    assert len(es._handlers) == 1

    # WHEN:
    #    We remove the handler
    es -= handler

    # THEN:
    assert len(es._handlers) == 0

# Generated at 2022-06-21 08:01:47.859548
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def h1():
        pass

    def h2():
        pass

    def h3():
        pass

    es += h1
    es += h2
    es += h3

    es -= h1
    es -= h3

    assert h1 not in es._handlers
    assert h2 in es._handlers
    assert h3 not in es._handlers


# Generated at 2022-06-21 08:01:50.225380
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()

    def handler():
        pass

    source += handler
    assert handler in source._handlers



# Generated at 2022-06-21 08:01:59.748908
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def s(*args, **kwargs):
        ans = args[0] + args[1]
        for k in kwargs:
            ans = ans + kwargs[k]
        return ans

    def e(*args, **kwargs):
        raise TestException('good times')

    def f1(*args, **kwargs):
        ans = args[0] + args[1]
        for k in kwargs:
            ans = ans + kwargs[k]
        return ans

    def f2(*args, **kwargs):
        ans = args[0] + args[1]
        for k in kwargs:
            ans = ans + kwargs[k]
        return ans

    # Instantiate event source, add 4 handlers, and call event source fire method with arguments

# Generated at 2022-06-21 08:02:11.870450
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ansible_collection_config_obj = AnsibleCollectionConfig()
    ansible_collection_config_obj.collection_finder = 1
    assert ansible_collection_config_obj.collection_finder == 1
    # assert ansible_collection_config_obj.collection_paths == []
    ansible_collection_config_obj.default_collection = 'abc'
    assert ansible_collection_config_obj.default_collection == 'abc'
    def err_1():
        ansible_collection_config_obj.collection_paths
    def err_2():
        ansible_collection_config_obj.playbook_paths

    def err_3():
        ansible_collection_config_obj.on_collection_load = 12

    assert err_1().message == 'an AnsibleCollectionFinder has not been installed in this process'


# Generated at 2022-06-21 08:02:14.256826
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac.collection_finder is None
    assert ac.collection_paths == []
    assert ac.default_collection is None
    assert ac.playbook_paths == []
    assert ac.on_collection_load is not None


# Generated at 2022-06-21 08:02:17.952187
# Unit test for constructor of class _EventSource
def test__EventSource():
    obj = _EventSource()
    assert not obj._handlers
    assert type(obj._handlers) is set
    assert dir(obj) == ['_EventSource__iadd__', '_EventSource__isub__', '_EventSource__on_exception', '_EventSource_fire', '_handlers']


# Generated at 2022-06-21 08:02:22.605021
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def f1(arg1, arg2):
        raise ValueError('f1')

    def f2(arg1, arg2, **kwargs):
        return

    def f3(arg1, arg2):
        raise Exception('f3')

    def f4(arg1, arg2, **kwargs):
        raise ValueError('f4')

    def f5(arg1, arg2):
        raise ValueError('f5')

    def f6(arg1, arg2, **kwargs):
        return

    def f7(arg1, arg2):
        raise Exception('f7')

    def f8(arg1, arg2, **kwargs):
        raise ValueError('f8')

    event_source = _EventSource()

    event_source += f1
    event_source += f2
    event_

# Generated at 2022-06-21 08:02:34.974647
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    calls = []

    def foo(*args, **kwargs):
        calls.append(('foo', args, kwargs))

    def bar(*args, **kwargs):
        calls.append(('bar', args, kwargs))

    event_source += foo
    event_source += bar

    event_source.fire(1, 2, foo='foo', bar='bar')
    assert calls == [
        ('foo', (1, 2), dict(foo='foo', bar='bar')),
        ('bar', (1, 2), dict(foo='foo', bar='bar'))
    ]

    calls = []
    event_source -= foo
    event_source.fire(1, 2, foo='foo', bar='bar')

# Generated at 2022-06-21 08:02:38.631481
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    test = _EventSource()

    test += lambda: None

    assert len(test._handlers) == 1

    test -= lambda: None

    assert len(test._handlers) == 0


# Generated at 2022-06-21 08:02:45.650529
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MyCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert isinstance(MyCollectionConfig.collection_finder, property)
    assert isinstance(MyCollectionConfig.collection_paths, property)
    assert isinstance(MyCollectionConfig.default_collection, property)
    assert isinstance(MyCollectionConfig.on_collection_load, property)
    assert isinstance(MyCollectionConfig.playbook_paths, property)


# Generated at 2022-06-21 08:02:55.422878
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    meta = type('FakeName', (object,), dict(__name__='FakeName'))
    name = 'SomeName'
    bases = (object,)
    ansible_collection_config = _AnsibleCollectionConfig(meta, name, bases)
    assert ansible_collection_config._collection_finder is None
    assert ansible_collection_config._on_collection_load is not None
    assert callable(ansible_collection_config._on_collection_load.fire)

# Generated at 2022-06-21 08:02:58.178101
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    evt = _EventSource()
    with pytest.raises(ValueError):
        evt += 'invalid'



# Generated at 2022-06-21 08:03:10.328589
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()

        def _on_exception(self, handler, ex, *args, **kwargs):
            # ignore all exceptions
            return False

    eventsource = MyEventSource()

    class MyException(Exception):
        pass

    def handler1(*args, **kwargs):
        raise MyException()

    try:
        eventsource.fire += handler1
        eventsource.fire(1234)
    except MyException:
        assert False, 'handler with exception not ignored'
    except:
        assert False, 'unexpected exception raised'

    def handler2(*args, **kwargs):
        assert False, 'handler should never have been called'


# Generated at 2022-06-21 08:03:13.450823
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def f():
        pass

    try:
        AnsibleCollectionConfig.on_collection_load += f
    except ValueError:
        pass


__all__ = ('AnsibleCollectionConfig',)

# Generated at 2022-06-21 08:03:20.215173
# Unit test for constructor of class _EventSource
def test__EventSource():
    def test_handler1(v):
        return v

    def test_handler2(v):
        return v

    e = _EventSource()

    assert e._handlers == set()
    assert len(e._handlers) == 0

    e.fire(1)

    assert e._handlers == set()
    assert len(e._handlers) == 0

    e += test_handler1
    e += test_handler2

    assert e._handlers == set([test_handler1, test_handler2])
    assert len(e._handlers) == 2

    e.fire(2)

    assert e._handlers == set([test_handler1, test_handler2])
    assert len(e._handlers) == 2

    e -= test_handler2

    assert e._handlers == set([test_handler1])


# Generated at 2022-06-21 08:03:30.767504
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    f1 = type('Finder2', (), dict(a=2))
    c1 = type('Config1', (_AnsibleCollectionConfig,), dict())
    assert c1._collection_finder is None
    assert c1._default_collection is None
    assert c1._on_collection_load is not None

    # can set the collection finder by constructor init
    # it must be an instance of AnsibleCollectionFinder
    c1.collection_finder = f1
    assert c1._collection_finder is f1

    # collection_finder is read-only
    try:
        c1.collection_finder = f1
        assert False, 'Expected AttributeError'
    except AttributeError:
        pass


# Generated at 2022-06-21 08:03:32.427732
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    _EventSource.__isub__(None, None)



# Generated at 2022-06-21 08:03:42.530695
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    evt = _EventSource()

    def f():
        pass

    def g():
        nonlocal f
        raise RuntimeError()

    evt += f
    evt += g

    with pytest.raises(RuntimeError):
        evt.fire()



# Generated at 2022-06-21 08:03:43.902858
# Unit test for constructor of class _EventSource
def test__EventSource():
    src = _EventSource()
    assert not src._handlers



# Generated at 2022-06-21 08:03:44.930559
# Unit test for constructor of class _EventSource
def test__EventSource():
    pass


# Generated at 2022-06-21 08:03:55.082576
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cls = AnsibleCollectionConfig
    assert isinstance(cls._collection_finder, property)
    assert isinstance(cls._default_collection, property)
    assert isinstance(cls._on_collection_load, property)
    assert isinstance(cls.collection_finder, property)
    assert isinstance(cls.collection_paths, property)
    assert isinstance(cls.default_collection, property)
    assert isinstance(cls.on_collection_load, property)
    assert isinstance(cls.playbook_paths, property)

# Generated at 2022-06-21 08:04:04.469146
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig
    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert isinstance(ac._on_collection_load, _EventSource)
    try:
        ac._collection_finder = 'foo'
        assert False, 'expected ValueError due to _collection_finder already being set'
    except ValueError:
        pass
    try:
        ac.on_collection_load = 'bar'
        assert False, 'expected ValueError due to on_collection_load not being directly settable'
    except ValueError:
        pass
    try:
        ac.collection_paths
        assert False, 'expected NotImplementedError due to _collection_finder not being set'
    except NotImplementedError:
        pass

# Generated at 2022-06-21 08:04:11.560687
# Unit test for constructor of class _EventSource
def test__EventSource():

    # Initializes an object with no handlers
    obj = _EventSource()

    # Adds handler to object
    assert len(obj._handlers) == 0
    obj += None
    assert len(obj._handlers) == 1

    # Adds another handler to object
    def handler():
        pass
    obj += handler
    assert len(obj._handlers) == 2

    # Subtracts handler from object
    obj -= handler
    assert len(obj._handlers) == 1

    # Subtracts non-existent handler from object
    obj -= handler
    assert len(obj._handlers) == 1

    # Fires a listener (no exception).
    def handler():
        pass
    obj.fire()

    # Fires a listener (expected exception).
    def handler():
        raise Exception
    obj.fire()

    # Fires a listener (

# Generated at 2022-06-21 08:04:13.010410
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    foo = AnsibleCollectionConfig()



# Generated at 2022-06-21 08:04:14.926974
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source.__iadd__(lambda: None)


# Generated at 2022-06-21 08:04:21.337787
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    class Foo(object):

        def __init__(self):
            self.count = 0

        def handler(self, arg):
            self.count += arg

    foo = Foo()
    event_source += foo.handler
    event_source.fire(5)

    assert foo.count == 5
    assert event_source._handlers == {foo.handler}

# Generated at 2022-06-21 08:04:21.947957
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:04:37.763098
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def handler_0():
        pass

    def handler_1():
        pass

    event += handler_0
    event -= handler_0

    assert handler_0 not in event._handlers

    # this should also produce no error
    event -= handler_0

    event += handler_1

    event -= handler_0

    assert handler_0 not in event._handlers
    assert handler_1 in event._handlers


# Generated at 2022-06-21 08:04:42.615007
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert callable(AnsibleCollectionConfig.on_collection_load.fire)
    assert AnsibleCollectionConfig.playbook_paths == []


# Generated at 2022-06-21 08:04:54.034185
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestConfig:
        pass

    t = TestConfig()

    assert isinstance(t._collection_finder, type(None))
    assert isinstance(t._default_collection, type(None))
    assert isinstance(t._on_collection_load, _EventSource)

    assert isinstance(t.collection_finder, type(None))
    assert isinstance(t.default_collection, type(None))
    assert isinstance(t.on_collection_load, _EventSource)

    assert isinstance(t.collection_paths, list)
    assert isinstance(t.playbook_paths, list)

    assert isinstance(t.on_collection_load, type(None))
    assert isinstance(t.collection_finder, type(None))
    assert isinstance(t.default_collection, type(None))



# Generated at 2022-06-21 08:04:57.984879
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)
    assert AnsibleCollectionConfig.playbook_paths == []

# Generated at 2022-06-21 08:05:09.469044
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import print_

    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            print_('an exception occurred in {}'.format(handler.__name__), end=':')
            print_(to_text(exc))
            print_('*args={}'.format(args))
            print_('**kwargs={}'.format(kwargs))

            return False

    def _handler(*args, **kwargs):
        print_('invoked _handler with args={} and kwargs={}'.format(args, kwargs))
        raise ValueError('oops')

    _test_event_source = _TestEventSource()

    # add _handler (should not

# Generated at 2022-06-21 08:05:14.825782
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None


# Module-level instance of our class to facilitate access
COLLECTION_CONFIG = AnsibleCollectionConfig()


# create a noop that is available to the collection loader.

# Generated at 2022-06-21 08:05:26.777635
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    ESC = _EventSource()

    def handlerA(x):
        return x

    def handlerB(x, y):
        return x, y

    ESC += handlerA
    ESC += handlerB

    assert len(ESC._handlers) == 2
    assert handlerA in ESC._handlers
    assert handlerB in ESC._handlers

    ESC -= handlerA
    assert len(ESC._handlers) == 1
    assert handlerA not in ESC._handlers
    assert handlerB in ESC._handlers

    ESC -= handlerA
    assert len(ESC._handlers) == 1
    assert handlerA not in ESC._handlers
    assert handlerB in ESC._handlers

    ESC -= handlerB
    assert len(ESC._handlers) == 0
    assert handlerA not in ESC._handlers
    assert handlerB not in ESC._

# Generated at 2022-06-21 08:05:29.353909
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()

    def callback(*args):
        pass

    e += callback
    e -= callback


# Generated at 2022-06-21 08:05:33.831035
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load._handlers == set()
    assert type(AnsibleCollectionConfig._on_collection_load) is _EventSource
    assert callable(AnsibleCollectionConfig._on_collection_load.fire)



# Generated at 2022-06-21 08:05:41.689372
# Unit test for constructor of class _EventSource
def test__EventSource():
    class Test(object):
        def __init__(self, assert_fired):
            self.assert_fired = assert_fired

        def handler(self):
            self.assert_fired.set()

    es = _EventSource()
    assert_fired = set()
    handler = Test(assert_fired).handler
    es += handler
    es.fire()
    assert assert_fired
    es -= handler
    assert_fired.clear()
    es.fire()
    assert not assert_fired



# Generated at 2022-06-21 08:06:15.613588
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    E = _EventSource()

    class A:
        def __init__(self):
            self.call_count = 0
        def __call__(self):
            self.call_count += 1

    # Test no handlers
    E.fire()

    # Test 1: Test exception handling in handler
    a = A()
    E += a
    try:
        E.fire()
        assert False, 'Expected runtime exception to be raised by handler'
    except RuntimeError as e:
        assert e.args[0] == 'Re-throwing', 'Expected _EventSource._on_exception to re-raise exception'
    assert a.call_count == 1, 'Expected handler to have been called once, but was called %u times' % a.call_count

    # Test 2: Test exception handling in handler.  This time the

# Generated at 2022-06-21 08:06:20.043905
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    collection_config = AnsibleCollectionConfig()
    assert callable(collection_config.on_collection_load)  # EventSource object
    assert collection_config.collection_finder is None
    assert collection_config.default_collection is None

# Generated at 2022-06-21 08:06:32.075294
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import unittest
    from ansible.module_utils._text import to_text

    class _TestCase(unittest.TestCase):
        def test_properties(self):
            self.assertIsInstance(AnsibleCollectionConfig.collection_finder, property)
            self.assertIsInstance(AnsibleCollectionConfig.collection_paths, property)
            self.assertIsInstance(AnsibleCollectionConfig.default_collection, property)
            self.assertIsInstance(AnsibleCollectionConfig.on_collection_load, property)
            self.assertIsInstance(AnsibleCollectionConfig.playbook_paths, property)

        def test_methods(self):
            self.assertIsInstance(AnsibleCollectionConfig.playbook_paths.fset, property)

        def test_playbook_setter(self):
            Ans

# Generated at 2022-06-21 08:06:43.885903
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import sys

    class _TestEventSource(_EventSource):
        def fire(self, *args, **kwargs):
            _actual_args.append((args, kwargs))

    _actual_args = []
    t = _TestEventSource()

    def _event_handler1(*args, **kwargs):
        _actual_args.append((args, kwargs))

    t += _event_handler1
    t += _event_handler1

    try:
        t -= _event_handler1
    except Exception as ex:
        _actual_ex = ex

    _actual_exc_info = sys.exc_info()

    assert _actual_args == [], 'actual args: %r' % (_actual_args,)
    assert _actual_ex == None, 'actual ex: %r' % (_actual_ex,)
   

# Generated at 2022-06-21 08:06:45.708388
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()

    # test that the event source is created correctly in the first place
    assert es is not None
    assert es._handlers is not None
    assert isinstance(es._handlers, set)



# Generated at 2022-06-21 08:06:50.774511
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_paths is None
    assert config.collection_finder is None
    assert config.default_collection is None
    assert config.playbook_paths is None

    assert config.on_collection_load is not None
    assert isinstance(config.on_collection_load, _EventSource)

# Generated at 2022-06-21 08:06:57.570729
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler_1(a, b=10, c=20):
        pass

    def handler_2(a, b=10, c=20):
        pass

    def handler_3(a, b=10, c=20):
        pass

    event_source = _EventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3
    event_source -= handler_1
    event_source -= handler_2
    event_source -= handler_3

    assert len(event_source._handlers) == 0

# Generated at 2022-06-21 08:07:03.766205
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test with a valid handler
    es = _EventSource()
    es += lambda x, y: x + y
    assert len(es._handlers) == 1
    assert es.fire(1, y=2) is None

    # Test with an invalid handler
    try:
        es += 'abc'
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-21 08:07:07.584217
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(event):
        pass

    es = _EventSource()
    assert es._handlers == set()

    es += handler
    assert es._handlers == {handler}

    es -= handler
    assert es._handlers == set()

# Generated at 2022-06-21 08:07:11.378605
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    instance = _EventSource()
    def handler0():
        return 0
    def handler1():
        return 1
    instance += handler0
    instance += handler1
    instance -= handler1
    assert len(instance._handlers) == 1
    assert handler0 in instance._handlers
    assert handler1 not in instance._handlers

# Generated at 2022-06-21 08:07:40.486271
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    event_source.fire()

    event_source += lambda: None
    event_source.fire()

    event_source -= lambda: None
    event_source.fire()



# Generated at 2022-06-21 08:07:44.460356
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert callable(AnsibleCollectionConfig._on_collection_load.fire)


# Generated at 2022-06-21 08:07:47.399288
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, _AnsibleCollectionConfig)
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, '_collection_finder')


# Generated at 2022-06-21 08:07:51.893854
# Unit test for constructor of class _EventSource
def test__EventSource():
    def firstSubscriber():
        pass

    def secondSubscriber():
        pass

    eventSource = _EventSource()

    assert eventSource._handlers == set()

    eventSource += firstSubscriber

    assert eventSource._handlers == {firstSubscriber}

    eventSource -= firstSubscriber

    assert eventSource._handlers == set()



# Generated at 2022-06-21 08:07:55.252325
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    test_object = _EventSource()

    def test_function1():
        pass

    def test_function2():
        pass

    test_object += test_function1
    test_object += test_function2

    test_object -= test_function1
    assert len(test_object._handlers) == 1

# Generated at 2022-06-21 08:08:06.915245
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class A(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert A._collection_finder is None
    assert A._default_collection is None

    handler = object()
    A._on_collection_load += handler
    assert A._on_collection_load._handlers == set([handler])

    try:
        A._on_collection_load.fire()
    except AttributeError:
        assert False, 'AnsibleCollectionConfig.on_collection_load callback handlers must be callable'

    try:
        A._on_collection_load.fire(2, 3)
    except TypeError:
        assert False, 'AnsibleCollectionConfig.on_collection_load callback handlers must be callable with variable args'


# Generated at 2022-06-21 08:08:10.277134
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    class TestMeta(_AnsibleCollectionConfig):
        pass

    class TestClass(with_metaclass(TestMeta)):
        pass

    assert TestClass._on_collection_load is not None

# Generated at 2022-06-21 08:08:10.994105
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()

# Generated at 2022-06-21 08:08:18.870404
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.__metaclass__, type)
    assert issubclass(AnsibleCollectionConfig.__metaclass__, type)
    assert isinstance(AnsibleCollectionConfig.__metaclass__, _AnsibleCollectionConfig)
    assert issubclass(AnsibleCollectionConfig.__metaclass__, _AnsibleCollectionConfig)

    assert hasattr(AnsibleCollectionConfig, '_AnsibleCollectionConfig__init__')
    assert hasattr(AnsibleCollectionConfig, '__init__')
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')

# Generated at 2022-06-21 08:08:21.354755
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    h = lambda *args, **kwargs: None
    es += h
    es -= h
    assert not es._handlers

# Generated at 2022-06-21 08:09:15.762912
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _AnsibleCollectionConfig_Class(_AnsibleCollectionConfig):
        pass
    assert _AnsibleCollectionConfig_Class.collection_finder is None
    assert _AnsibleCollectionConfig_Class.on_collection_load
    assert _AnsibleCollectionConfig_Class.on_collection_load._handlers == set()



# Generated at 2022-06-21 08:09:19.925445
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(s):
        print("test1:", s)

    def handler2(a, b):
        print("test2:", a + b)

    es = _EventSource()
    es += handler1
    es += handler2

    es.fire("test")
    es.fire(4, 6)



# Generated at 2022-06-21 08:09:24.813406
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    handler1 = lambda *args, **kwargs: print('handler1', args, kwargs)
    handler2 = lambda *args, **kwargs: print('handler2', args, kwargs)

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source -= handler1
    event_source -= handler1
    event_source -= handler2
    event_source -= handler2

    # noinspection PyProtectedMember
    assert event_source._handlers == set()

# Generated at 2022-06-21 08:09:28.632204
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evt = _EventSource()
    events = []
    evt += (lambda a: events.append(a))

    evt.fire(5)
    evt.fire(6)

    assert len(events) == 2
    assert events[0] == 5
    assert events[1] == 6


# Generated at 2022-06-21 08:09:33.804127
# Unit test for constructor of class _EventSource
def test__EventSource():
    try:
        x = _EventSource()
        if not hasattr(x, '_on_exception'):
            raise Exception('expected _EventSource class to have an _on_exception method')
    except Exception as e:
        raise Exception("unit test of _EventSource failed: " + str(e))


# Generated at 2022-06-21 08:09:44.046482
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    a = _EventSource()
    b = _EventSource()
    assert a != b
    assert a._handlers != b._handlers
    b1 = a._handlers
    a -= b
    assert a == b
    assert a._handlers == b._handlers
    assert a._handlers == b1
    a -= b
    assert a == b
    assert a._handlers == b._handlers
    assert a._handlers == b1
    a -= b1
    assert a == b
    assert a._handlers == b._handlers
    assert a._handlers == b1
    b._handlers.add(1)
    assert a != b
    assert a._handlers != b._handlers
    a -= 1
    assert a == b
    assert a._handlers == b._handlers
    assert a._

# Generated at 2022-06-21 08:09:48.147022
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(x, y=None):
        return x + (1 if y is None else y)

    s = _EventSource()

    s += handler

    assert handler in s._handlers

    try:
        s += 7
        assert False  # _EventSource.__iadd__ did not throw exception
    except ValueError:
        pass

    s -= handler

    assert handler not in s._handlers


# Generated at 2022-06-21 08:09:57.253463
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def func1(a, b, c):
        return a+b+c
    def func2(d, e, f):
        return d*e*f
    def func3(k, j, h):
        return (k+j+h)*2

    _EventSource_test = _EventSource()

    # __iadd__() should work
    _EventSource_test += func1
    _EventSource_test += func2
    _EventSource_test += func3

    # __iadd__() with the same function again should do nothing
    _EventSource_test += func1

    # __iadd__() should not accept non-callable function
    try:
        _EventSource_test += None
    except ValueError:
        pass



# Generated at 2022-06-21 08:09:57.784890
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:10:04.949405
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass
    assert callable(handler)

    event_source += handler

    assert len(event_source._handlers) == 1

    class NotCallable:
        pass

    not_callable = NotCallable()
    assert not callable(not_callable)

    try:
        event_source += not_callable
    except ValueError:
        pass
    else:
        assert False, 'expected ValueError'

    # negative test
    try:
        event_source += 42
    except ValueError:
        pass
    else:
        assert False, 'expected ValueError'
