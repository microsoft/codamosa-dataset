

# Generated at 2022-06-21 08:01:33.424652
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    def handler_ok(event_args):
        handler_ok.fired_ok = True
    handler_ok.fired_ok = False

    def handler_fail(event_args):
        handler_fail.fired_fail = True
        raise Exception('fail')
    handler_fail.fired_fail = False

    @property
    def handler_fail_on_attempt(self):
        handler_fail_on_attempt.fired_fail_on_attempt = True
        raise Exception('fail')
    handler_fail_on_attempt.fired_fail_on_attempt = False

    event_source = _EventSource()
    event_source += handler_ok
    event_source += handler_fail
    event_source += handler_fail_on_attempt

    # Act
    event_source.fire()



# Generated at 2022-06-21 08:01:36.774226
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def handler():
        pass

    event += handler
    event -= handler

    assert len(event._handlers) == 0


# Generated at 2022-06-21 08:01:40.171697
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from test.lib.util.events import EventListener

    s = _EventSource()
    l = EventListener()

    s += l.notify
    s.fire('test')

    assert l.events == ['test']

# Generated at 2022-06-21 08:01:43.551520
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def func1(p1, p2):
        return str(p1) + str(p2)

    def func2(p1, p2):
        return int(p1) * int(p2)

    event_source = _EventSource()
    event_source += func1
    event_source += func2

    result = event_source.fire(1, 2)

    assert result is None, "result={0}".format(result)

    assert func1(1, 2) == "12", "func1(1, 2)={0}".format(func1(1, 2))
    assert func2(1, 2) == 2, "func2(1, 2)={0}".format(func2(1, 2))

# Generated at 2022-06-21 08:01:48.671211
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Arrange
    e = _EventSource()
    e_count = len(e._handlers)
    handler = lambda a: a
    e += handler

    # Act
    e -= handler

    # Assert
    assert len(e._handlers) == e_count



# Generated at 2022-06-21 08:01:52.699767
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    a = _AnsibleCollectionConfig('meta', 'name', 'bases')

    # Check that the variables on an instance of _AnsibleCollectionConfig are initialized correctly
    assert a._collection_finder is None
    assert a._default_collection is None
    assert a._on_collection_load._handlers == set()

# Generated at 2022-06-21 08:01:55.978269
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    callback = lambda *args, **kwargs: None
    source = _EventSource()
    source += callback
    source.fire(1, 2, 3)
    source -= callback
    source.fire(1, 2, 3)



# Generated at 2022-06-21 08:01:57.857931
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()
    assert isinstance(ev, _EventSource)
    assert ev._handlers == set()

# Generated at 2022-06-21 08:02:10.068458
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, '_AnsibleCollectionConfig__all_variables')
    assert hasattr(AnsibleCollectionConfig, '_AnsibleCollectionConfig__fqcn')
    assert hasattr(AnsibleCollectionConfig, '_AnsibleCollectionConfig__collection_finder')
    assert hasattr(AnsibleCollectionConfig, '_AnsibleCollectionConfig__default_collection')
    assert hasattr(AnsibleCollectionConfig, '_AnsibleCollectionConfig__on_collection_load')
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

    # setter
    AnsibleCollectionConfig.on_collection_load = AnsibleCollectionConfig.on_collection_load

    # getter
    assert type(AnsibleCollectionConfig.collection_finder) == property

    # set

# Generated at 2022-06-21 08:02:18.760638
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__(): # pylint: disable=redefined-outer-name
    '''Unit test for method __iadd__ of class _EventSource'''
    import pytest
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes

    class TestClass:
        def __init__(self, event_source):
            self.handle_event = event_source
            self.handle_event += self.handle_event1

        @staticmethod
        def handle_event1(*args, **kwargs):
            # pylint: disable=unused-argument
            # print('handle_event1 called')
            pass

    class OtherClass:
        pass

    event_source = _EventSource()
    test_object = TestClass(event_source)


    # Test callable


# Generated at 2022-06-21 08:02:32.458792
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def method1(state):
        state.append("method1")

    def method2(state):
        state.append("method2")

    def raise_ValueError(state):
        raise ValueError("uh oh")

    def raise_NotImplementedError(state):
        raise NotImplementedError("uh oh")

    event_source += method1
    event_source += method2

    state = []
    event_source.fire(state)

    assert state == ["method1", "method2"]

    state = []
    event_source += raise_ValueError
    try:
        event_source.fire(state)
        assert False, "expected ValueError"
    except ValueError:
        pass

    state = []
    event_source += raise_NotImplementedError
   

# Generated at 2022-06-21 08:02:35.645041
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, None)
    assert isinstance(AnsibleCollectionConfig._default_collection, None)

# Generated at 2022-06-21 08:02:46.874498
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    """ Unit test to validate creation of class AnsibleCollectionConfig."""
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load == AnsibleCollectionConfig.on_collection_load
    assert AnsibleCollectionConfig.playbook_paths == []
    try:
        AnsibleCollectionConfig.collection_finder = 'testfinder'
        assert False
    except ValueError:
        pass
    try:
        AnsibleCollectionConfig.on_collection_load = 'test'
        assert False
    except ValueError:
        pass

# Generated at 2022-06-21 08:02:58.874442
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # check that the class properties are initialized properly
    def _assert():
        assert isinstance(AnsibleCollectionConfig._collection_finder, None.__class__)
        assert isinstance(AnsibleCollectionConfig._default_collection, None.__class__)
        assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

    # check that the class properties are initialized properly when this unit test function is included in the loader
    _assert()

    # check that the class properties are initialized properly when this unit test function is included in the ansible-test loader
    # noinspection PyUnresolvedReferences
    from ansible.module_utils.ansible_galaxy.api.collection_loader._ansible_collection_config import _AnsibleCollectionConfig
    _AnsibleCollectionConfig()
    _assert()

# Generated at 2022-06-21 08:03:03.576097
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc = AnsibleCollectionConfig()
    assert acc.collection_finder is None
    assert acc.default_collection is None
    assert acc.on_collection_load is acc._on_collection_load
    assert acc.playbook_paths is None


# Generated at 2022-06-21 08:03:07.537153
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert isinstance(ac.on_collection_load, _EventSource)
    assert ac.collection_finder is None
    assert ac.default_collection is None



# Generated at 2022-06-21 08:03:17.272801
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    has_fired = False
    event_source = _EventSource()

    def handler(a, b, c=None, d=None):
        nonlocal has_fired, event_source

        if event_source is not event_source:
            raise AssertionError('event_source has changed')
        if a != 1:
            raise AssertionError('value of a was not 1')
        if b != 2:
            raise AssertionError('value of b was not 2')
        if c != 3:
            raise AssertionError('value of c was not 3')
        if d != 4:
            raise AssertionError('value of d was not 4')

        has_fired = True

    # Exercise
    event_source += handler
    event_source.fire(1, 2, c=3, d=4)


# Generated at 2022-06-21 08:03:21.753945
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    class Config(AnsibleCollectionConfig):
        pass

    assert Config.collection_finder is None
    assert Config.default_collection is None
    assert Config.on_collection_load

    # assert _AnsibleCollectionConfig.__init__(Config, None, None, None) == NotImplementedError

# Generated at 2022-06-21 08:03:32.532098
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class AError(Exception):
        pass

    def handler1(*args, **kwargs):
        print("handler1 called", args, kwargs)

    def handler2(*args, **kwargs):
        print("handler2 called", args, kwargs)
        raise AError()

    def handler3(*args, **kwargs):
        print("handler3 called", args, kwargs)
        raise ValueError()

    es = _EventSource()
    es.on_exception = None
    es += handler1
    es += handler2
    es += handler3
    try:
        es.fire("arg1", arg2=2)
        assert False
    except AError:
        pass


# Generated at 2022-06-21 08:03:41.823028
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert callable(AnsibleCollectionConfig.collection_finder.fget)
    assert callable(AnsibleCollectionConfig.collection_finder.fset)
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert callable(AnsibleCollectionConfig.default_collection.fget)
    assert callable(AnsibleCollectionConfig.default_collection.fset)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)
    assert callable(AnsibleCollectionConfig.on_collection_load.fget)
    assert callable(AnsibleCollectionConfig.on_collection_load.fset)
    assert AnsibleCollectionConfig.playbook_paths == []
    assert callable

# Generated at 2022-06-21 08:03:46.603535
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

# Generated at 2022-06-21 08:03:57.406153
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Use with temp class instances
    class MyClass:
        pass

    # Create an _EventSource
    es1 = _EventSource()

    # Assign a method to the test_inst object
    ins = MyClass()
    ins.test_method = lambda: None
    result = es1.__iadd__(ins.test_method)
    assert result is es1
    assert ins.test_method in es1._handlers

    # Assign a method to the test_inst object
    class MyClass2:
        @staticmethod
        def a_static_method():
            pass

    result = es1.__iadd__(MyClass2.a_static_method)
    assert result is es1
    assert MyClass2.a_static_method in es1._handlers

    # Raise ValueError

# Generated at 2022-06-21 08:04:00.683984
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert hasattr(AnsibleCollectionConfig, '_default_collection')
    assert hasattr(AnsibleCollectionConfig, '_on_collection_load')


# Generated at 2022-06-21 08:04:02.658239
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c.playbook_paths == []
    assert c.collection_paths == []

# Generated at 2022-06-21 08:04:10.562378
# Unit test for constructor of class _EventSource
def test__EventSource():
    def interruptor(*args, **kwargs):
        raise ValueError('event handler interrupted')

    def handler(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    event_source = _EventSource()

    assert event_source._handlers == set()

    event_source += handler
    assert event_source._handlers == {handler}

    event_source += interruptor
    assert event_source._handlers == {handler, interruptor}

    event_source += handler2
    assert event_source._handlers == {handler, interruptor, handler2}

    event_source.fire()
    assert event_source._handlers == {handler, interruptor, handler2}

    event_source -= handler
    assert event_source._handlers == {interruptor, handler2}

    event_

# Generated at 2022-06-21 08:04:22.619696
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    eventsource = _EventSource()

    def h1(*args, **kwargs):
        pass

    def h2(*args, **kwargs):
        raise TestException()

    def h3(*args, **kwargs):
        raise ValueError()

    def h4(*args, **kwargs):
        raise TestException()

    eventsource += h1
    eventsource += h2
    eventsource += h3
    eventsource += h4

    eventsource._on_exception = lambda handler, exc, *args, **kwargs: isinstance(exc, TestException)

    try:
        eventsource.fire()
    except TestException:
        pass
    else:
        assert False, 'fire() should have raised a TestException'

    es2 = _EventSource()

# Generated at 2022-06-21 08:04:25.500689
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert isinstance(event_source, _EventSource)
    assert len(event_source._handlers) == 0


# Generated at 2022-06-21 08:04:30.083967
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _A_CONST = 'A'
    _B_CONST = 'B'
    _C_CONST = 'C'

    def my_handler(event, arg1, arg2=None):
        assert event == _A_CONST
        assert arg1 == _B_CONST
        assert arg2 == _C_CONST

    event_source = _EventSource()
    event_source += my_handler
    event_source.fire(_A_CONST, _B_CONST, arg2=_C_CONST)

# Generated at 2022-06-21 08:04:39.242124
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    class _EventSourceT(AnsibleCollectionConfig):
        pass

    _event_source = _EventSourceT._on_collection_load
    _event_source += lambda: None
    assert len(set(_event_source._handlers)) == 1

    # handler is not callable
    try:
        _event_source += None
        assert False, 'invalid handler added'
    except ValueError:
        pass

    # handler is already added
    try:
        _event_source += lambda: None
    except ValueError:
        assert False, 'invalid exception raised when adding an existing handler'



# Generated at 2022-06-21 08:04:50.700672
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    x = []

    def handler1(arg):
        x.append(arg)

    def handler2(arg):
        x.append(arg + 1)

    def handler3(arg):
        x.append(arg + 2)

    def handler4(arg):
        x.append(arg + 3)

    event_source += handler1
    event_source += handler2
    event_source += handler3
    event_source += handler4

    event_source.fire(1)
    assert x == [1, 2, 3, 4]

    x.clear()

    event_source.fire(3)
    assert x == [3, 4, 5, 6]

    x.clear()

    event_source.fire(5)

# Generated at 2022-06-21 08:04:58.541754
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()



# Generated at 2022-06-21 08:05:00.772383
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()
    assert isinstance(a, AnsibleCollectionConfig)

# Generated at 2022-06-21 08:05:03.285877
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _TestCollectionConfig(object):
        __metaclass__ = _AnsibleCollectionConfig

    _TestCollectionConfig()



# Generated at 2022-06-21 08:05:11.913087
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # __iadd__(self, handler)

    class TestClass:
        def __init__(self):
            self.handler = None

        def handler_method(self, *args, **kwargs):
            self.handler = (args, kwargs)

    es = _EventSource()

    tc = TestClass()

    es += tc.handler_method

    es.fire(1, 2, 3, a=4, b=5)

    assert tc.handler == ((1, 2, 3), {'a': 4, 'b': 5})

    es += tc.handler_method

    es.fire(6, 7, 8, a=9, b=10)

    assert tc.handler == ((6, 7, 8), {'a': 9, 'b': 10})

    es += tc.handler_method

    es -= tc

# Generated at 2022-06-21 08:05:14.050166
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert AnsibleCollectionConfig()._handlers == set()


# Generated at 2022-06-21 08:05:17.456909
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: "handler"
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-21 08:05:21.516162
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    fake_handler = object()

    # check that a nonexistent handler is removed
    event_source -= fake_handler

    # check that a duplicate handler is only removed once
    event_source -= fake_handler


# Generated at 2022-06-21 08:05:32.361111
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Test: single subscription, then unsubscribe
    e = _EventSource()
    handler = lambda *args, **kwargs: None
    e += handler
    assert handler in e._handlers
    e -= handler
    assert handler not in e._handlers

    # Test: multiple subscriptions, then unsubscribe
    e = _EventSource()
    handler1 = lambda *args, **kwargs: None
    handler2 = lambda *args, **kwargs: None
    e += handler1
    e += handler2
    assert handler1 in e._handlers
    assert handler2 in e._handlers
    e -= handler1
    assert handler1 not in e._handlers
    assert handler2 in e._handlers

    # Test: no subscriptions, then unsubscribe
    e = _EventSource()
    handler1 = lambda *args, **kwargs: None

# Generated at 2022-06-21 08:05:38.346239
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    A = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert A._collection_finder is None
    assert A._default_collection is None
    assert callable(A.collection_finder)
    assert callable(A.collection_paths)
    assert callable(A.default_collection)
    assert callable(A.on_collection_load)
    assert callable(A.playbook_paths)



# Generated at 2022-06-21 08:05:45.290672
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    def handler1(x):
        raise Exception('meh')
    def handler2(x):
        print(x)
    event += handler1
    event += handler2
    # Should not throw an exception
    event -= handler1
    # Should not throw an exception
    event -= handler1
    # Should not throw an exception
    event -= handler2
    # Should not throw an exception
    event -= lambda x: None
    # Should throw an exception
    event -= 'meh'


# Generated at 2022-06-21 08:06:09.896597
# Unit test for constructor of class _EventSource
def test__EventSource():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._test_handler = None
        def add_handler(self, h):
            self += h
        def remove_handler(self, h):
            self -= h
        def fire_event(self, *args, **kwargs):
            self.fire(*args, **kwargs)

    tes = _TestEventSource()
    assert len(tes._handlers) == 0

    # Test that we can add a handler
    def handler(data):
        tes._test_handler = data
    tes.add_handler(handler)
    assert len(tes._handlers) == 1

    # Test that we receive the event
    tes.fire_event('test')
    assert tes

# Generated at 2022-06-21 08:06:11.172266
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig(): assert AnsibleCollectionConfig


EOL = '\n'



# Generated at 2022-06-21 08:06:12.368289
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert not event._handlers


# Generated at 2022-06-21 08:06:13.202531
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_event = _EventSource()

# Generated at 2022-06-21 08:06:15.870572
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()

    assert not hasattr(c, "_collection_finder")
    assert not hasattr(c, "_default_collection")


# Generated at 2022-06-21 08:06:20.677201
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def on_collection_load():
        return None

    es += on_collection_load
    assert on_collection_load in es._handlers

    es -= on_collection_load
    assert on_collection_load not in es._handlers

# Generated at 2022-06-21 08:06:29.708986
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    t = _EventSource()

    # test handler add
    _list = []
    t += _list.append
    t.fire('test')
    assert _list == ['test']

    # test handler add duplicates
    t += _list.append
    t.fire('test')
    assert _list == ['test', 'test', 'test']

    # test handler add non-callables
    t += None
    try:
        t.fire('test')
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-21 08:06:36.944247
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    # no handlers
    events = _EventSource()
    assert events.__iadd__ == _EventSource.__iadd__
    assert events._handlers == set()

    # Act/Assert
    # cannot add non-callable
    try:
        events.__iadd__(None)
        assert False  # should never get here
    except ValueError:
        pass

    # can add a function
    def func(): pass
    events += func
    assert events._handlers == {func}

    # can add a method
    class Class:
        def meth(self): pass
    instance = Class()
    events += instance.meth
    assert events._handlers == {func, instance.meth}


# Generated at 2022-06-21 08:06:48.596105
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=assignment-from-no-return
    cls = AnsibleCollectionConfig

    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert callable(cls.collection_finder)
    assert callable(cls.default_collection)
    assert callable(cls.on_collection_load)
    assert cls.collection_finder is cls._collection_finder
    assert cls.default_collection is cls._default_collection
    assert cls.on_collection_load is cls._on_collection_load
    assert cls.on_collection_load.fire is cls._on_collection_load.fire

    # assert idempotent
    assert cls.collection_finder is cls._collection_finder
    assert cls.default_collection is cl

# Generated at 2022-06-21 08:06:56.436692
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Example code:
    import os
    from ansible.module_utils.common.text.converters import to_bytes

    x = to_bytes(os.getcwd(), errors='strict')

    # This is the method that you are testing.
    # Replace the call to NotImplementedError with the actual code you wish to test.
    try:
        raise NotImplementedError()
    except NotImplementedError:
        # Verify the result of the method here.
        # This should be the last call in the test.
        raise AssertionError('Not implemented yet.')



# Generated at 2022-06-21 08:07:33.544772
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.collection_paths is None
    assert AnsibleCollectionConfig.playbook_paths is None


# NOTE: type was defined for class AnsibleCollectionConfig so that we can use the @property.setter decorator to
#       avoid code to be added to the module AnsibleCollectionConfig.
#       Otherwise, we would need to create a separate module to implement the _AnsibleCollectionConfig class.
#       The class AnsibleCollectionConfig is used to define the class properties that are accessible from the outside.
#       It is important that the same class is available for all invocations of the collection loader.
#       This can be ensured by factoring the class definition into the module Ans

# Generated at 2022-06-21 08:07:38.264551
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    handler1 = lambda: None
    handler2 = lambda: None

    event += handler1
    event.fire()

    event += handler2
    event.fire()

    event -= handler1
    event.fire()



# Generated at 2022-06-21 08:07:48.779706
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # This is the first test case. It is designed to be run in the ansible-test environment.
    
    # The first test of the method fire is in this implementation.
    
    # Initialize the event source object.
    event_source = _EventSource()

    # Define a function which is to be called by the event source.
    def event_source_handler(event_source_arg, **kwargs):
        return event_source_arg

    # Add a handler to the event source.
    event_source += event_source_handler

    # Fire the event source, calling the handler with a test string and keyword arguments and return the result.
    event_source_handler_result = event_source.fire('test_arg', keyword_arg='test_kwarg')
    
    assert event_source_handler_result == 'test_arg'

# Generated at 2022-06-21 08:07:50.813679
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    try:
        obj = AnsibleCollectionConfig()
    except Exception as ex:
        assert False, "create AnsibleCollectionConfig object failed. {0}".format(str(ex))

# run test
test__AnsibleCollectionConfig()

# Generated at 2022-06-21 08:07:57.458512
# Unit test for constructor of class _EventSource
def test__EventSource():
    def test_handler(x, y=None):
        if y is not None:
            print('test_handler called with x = {0}, y = {1}'.format(x, y))
        else:
            print('test_handler called with x = {0}'.format(x))

    # exception handlers which do different things
    def handler1(exc):
        print('handled1: {0!s}'.format(exc))
        return True

    def handler2(exc):
        print('handled2: {0!s}'.format(exc))
        return False

    def handler3(exc):
        print('handled3: {0!s}'.format(exc))
        raise RuntimeError('Suppressing original exception')

    # create an event source
    es = _EventSource()
    es += test_handler
    es += test

# Generated at 2022-06-21 08:08:04.940735
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    matching_event = _EventSource()
    unmatching_event = _EventSource()

    def test_handler(arg):
        pass

    matching_event += test_handler
    unmatching_event += test_handler

    assert test_handler in matching_event._handlers
    assert test_handler in unmatching_event._handlers

    matching_event -= test_handler
    assert test_handler not in matching_event._handlers
    assert test_handler in unmatching_event._handlers


# Generated at 2022-06-21 08:08:08.989029
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    item = _EventSource()
    item += lambda: None

    assert len(item._handlers) == 1

    item -= lambda: None

    assert len(item._handlers) == 1

    item -= lambda x: None

    assert len(item._handlers) == 1

# Generated at 2022-06-21 08:08:14.285809
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_events = _EventSource()
    assert not test_events._handlers
    test_events += lambda x:None
    assert len(test_events._handlers) == 1
    try:
        test_events += None
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError expected')



# Generated at 2022-06-21 08:08:26.965275
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.six import add_metaclass
    from ansible.module_utils._text import to_bytes

    class EventSourceTest(_EventSource):
        pass

    @add_metaclass(_EventSource)
    class MetaEventSourceTest:
        pass

    # test EventSource
    es = EventSourceTest()
    assert es._handlers == set()
    es += to_bytes
    assert es._handlers == {to_bytes}
    es += to_bytes
    assert es._handlers == {to_bytes}  # unchanged

    # test MetaEventSource
    es = MetaEventSourceTest()
    assert es._handlers == set()
    es += to_bytes
    assert es._handlers == {to_bytes}
    es += to_bytes

# Generated at 2022-06-21 08:08:29.296222
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    AnsibleCollectionConfig._collection_finder = None
    AnsibleCollectionConfig._default_collection = None
    AnsibleCollectionConfig._on_collection_load = _EventSource()



# Generated at 2022-06-21 08:09:04.581883
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # Assert that the AnsibleCollectionFinder class is properly initialized.
    acf = AnsibleCollectionConfig()
    assert acf._collection_finder is None
    assert acf._default_collection is None
    assert isinstance(acf._on_collection_load, _EventSource)

    # Assert that the collection_finder property is properly set.
    s = set()
    acf.collection_finder = s
    assert acf._collection_finder == s
    # Assert that the collection_finder property cannot be overwritten.
    try:
        acf.collection_finder = set()
        assert False
    except ValueError:
        assert True

    # Assert that the default_collection property is properly set.
    s = set()
    acf.default_collection = s
    assert acf._default_collection == s

    #

# Generated at 2022-06-21 08:09:07.333362
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    def callback():
        pass

    event += callback
    assert callback in event._handlers


# Generated at 2022-06-21 08:09:18.722894
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestHandler:
        def __init__(self, expected_args, expected_kwargs):
            self.expected_args = expected_args
            self.expected_kwargs = expected_kwargs
            self.call_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1
            assert self.expected_args == args
            assert self.expected_kwargs == kwargs

    es1 = _EventSource()
    es2 = _EventSource()
    es1.fire()
    es2.fire(1, two=2, three=3)

    h1 = TestHandler(('abc',), {'def': 'def'})
    h2 = TestHandler(('abc',), {'def': 'def'})

# Generated at 2022-06-21 08:09:23.967794
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, property)
    assert isinstance(AnsibleCollectionConfig._default_collection, property)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)

# Generated at 2022-06-21 08:09:27.161675
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def _event_handler():
        pass

    event_source = _EventSource()
    assert event_source._handlers == set()

    event_source += _event_handler
    assert event_source._handlers == {_event_handler}



# Generated at 2022-06-21 08:09:37.525180
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Verify that no exception is raised when firing an empty _EventSource
    es = _EventSource()
    es.fire()

    # Verify that no exception is raised when firing a _EventSource with a single event handler
    called = [False]

    def handler():
        called[0] = True

    es = _EventSource()
    es += handler
    es.fire()

    assert called[0]

    # Verify that no exception is raised when firing a _EventSource with multiple event handlers
    called = [False, False]

    def handler1():
        called[0] = True

    def handler2():
        called[1] = True

    es = _EventSource()
    es += handler1
    es += handler2
    es.fire()

    assert called[0]
    assert called[1]

    # Verify that an exception is

# Generated at 2022-06-21 08:09:39.256932
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()


# Generated at 2022-06-21 08:09:47.989356
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    assert es._handlers == set()
    assert es.fire() is None

    def h(s):
        raise Exception(s)

    es += h
    assert es._handlers == {h}

    try:
        es.fire('boom')
    except Exception as result:
        assert result.args == ('boom',)
    else:
        assert False, 'expected exception'

    def _on_exception(handler, exc, *args, **kwargs):
        return False

    es._on_exception = _on_exception
    with_handled_exception = [False]

    def h2(s):
        try:
            raise Exception(s)
        except Exception:
            with_handled_exception[0] = True

    es += h2

# Generated at 2022-06-21 08:09:49.558609
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert isinstance(c, _AnsibleCollectionConfig)


# Generated at 2022-06-21 08:09:55.822282
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fails = []
    success = []

    def handler(s):
        if s == 'fail':
            raise Exception('boom')
        success.append(s)

    event = _EventSource()
    event += handler
    event.fire('foo')
    event.fire('fail')
    event.fire('bar')

    # ensure the handler was called once and only once
    assert ['foo'] == success

    # ensure the exception was not re-raised
    assert len(fails) == 0

# Generated at 2022-06-21 08:11:08.556625
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cfg = AnsibleCollectionConfig()
    assert cfg._collection_finder is None
    assert cfg._default_collection is None
    assert cfg._on_collection_load is not None



# Generated at 2022-06-21 08:11:12.346652
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def test_handler():
        pass

    es += test_handler
    es -= test_handler
    assert test_handler not in es._handlers

    # does not error
    es -= test_handler


# Generated at 2022-06-21 08:11:17.075636
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_without_exception(*_args, **_kwargs):
        pass

    def handler_with_exception(*_args, **_kwargs):
        raise RuntimeError('handler_with_exception')

    event = _EventSource()

    event += handler_without_exception
    event += handler_with_exception

    raised = None
    try:
        event.fire()
    except Exception as ex:
        raised = ex

    assert raised is not None
    assert str(raised) == 'handler_with_exception'

# Generated at 2022-06-21 08:11:18.296161
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:11:25.318380
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource.on_exception = lambda _, __: False
    es = _EventSource()
    handler1 = lambda: 1
    handler2 = lambda: 2
    handler3 = lambda: 3

    es += handler1
    es += handler2
    es += handler3

    assert es.fire() is None
    assert es._handlers == {handler1, handler2, handler3}
