

# Generated at 2022-06-21 08:01:30.444418
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():

    # Unit test for constructor of class AnsibleCollectionConfig

    # First, we check the public properties on the class.
    # For each property we check:
    #    - the property must not be settable
    #    - an exception must be thrown when trying to set the property
    #    - a NotImplementedError exception must be thrown when getting the property
    for name in ('collection_finder', 'collection_paths', 'default_collection',
                 'on_collection_load', 'playbook_paths'):
        assert not hasattr(AnsibleCollectionConfig, '__setattr__')
        props = [name]
        if name == 'on_collection_load':
            props.append('_on_collection_load')

        for prop in props:
            prop_obj = getattr(AnsibleCollectionConfig, prop)

# Generated at 2022-06-21 08:01:42.385046
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible_collections.ansible.builtin.plugins.module_utils.legacy_collection_loader._finder import AnsibleCollectionFinder
    from ansible_collections.ansible.builtin.plugins.module_utils.legacy_collection_loader._loader import AnsibleCollectionLoader

    collection_finder = AnsibleCollectionFinder()

    original_paths = collection_finder._n_collection_paths
    original_playbook_paths = collection_finder._n_playbook_paths

    # test the collection_finder setter
    AnsibleCollectionConfig.collection_finder = collection_finder
    assert AnsibleCollectionConfig.collection_finder == collection_finder

    # test the collection_paths property getter
    assert AnsibleCollectionConfig.collection_paths == to_text(original_paths)

    # test the playbook_path

# Generated at 2022-06-21 08:01:53.429312
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()
    assert s._handlers == set()

    def handler1(a, b, c):
        if a != 1:
            raise RuntimeError()
        if b != 2:
            raise RuntimeError()
        if c != 3:
            raise RuntimeError()

    def handler2(a, b, c):
        if a != 1:
            raise RuntimeError()
        if b != 2:
            raise RuntimeError()
        if c != 3:
            raise RuntimeError()

    # test adding one handler
    s.fire(1, 2, 3)

    s += handler1
    s.fire(1, 2, 3)
    # test removing one handler
    s -= handler1
    s.fire(1, 2, 3)

    # test adding two handlers
    s += handler1
    s += handler

# Generated at 2022-06-21 08:01:55.680303
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # Test constructor without arguments
    try:
        AnsibleCollectionConfig()
    except TypeError:
        pass


# Generated at 2022-06-21 08:02:01.110859
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert len(event_source._handlers) == 1

    event_source -= 'invalid parameter type'

    assert len(event_source._handlers) == 1

    event_source -= handler

    assert not event_source._handlers

# Generated at 2022-06-21 08:02:12.380220
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Concrete(_AnsibleCollectionConfig):
        pass

    assert issubclass(Concrete, object)
    assert not isinstance(Concrete, object)

    assert '_AnsibleCollectionConfig' in [m.__name__ for m in Concrete.__mro__]

    try:
        # This is a metaclass instance and should be rejected.
        Concrete.collection_finder = Concrete
        assert False
    except ValueError:
        pass

    # Test for the default attribute values set by the metaclass constructor
    assert Concrete.collection_finder is None
    assert Concrete.collection_paths is None
    assert Concrete.default_collection is None
    assert Concrete.on_collection_load is not None
    assert Concrete.playbook_paths is None

# Generated at 2022-06-21 08:02:24.173163
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # assert fire does nothing when no callbacks registered
    es = _EventSource()
    es.fire()

    called = [0]

    def foo():
        called[0] += 1

    # test registration and firing
    es += foo
    es.fire()
    assert called[0] == 1

    # test deregistration
    es -= foo
    es.fire()
    assert called[0] == 1

    # test that adding a non-callable raises a TypeError
    try:
        es += 'not a callable'
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError adding a non-callable'

    # test that exception handler is invoked and can suppress exception
    es += foo
    es._on_exception = lambda handler, exc, *args, **kwargs: False


# Generated at 2022-06-21 08:02:28.335369
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def handler(*args):
        assert False, 'should not be called'
    es += handler
    assert handler in es._handlers
    assert handler.__name__ in es._handlers
    es.fire()



# Generated at 2022-06-21 08:02:30.327044
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()

    assert len(event_source._handlers) == 0



# Generated at 2022-06-21 08:02:34.409026
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Setup
    event_source = _EventSource()
    handler1 = lambda: None
    handler2 = lambda: None
    handler3 = lambda: None
    event_source += handler1
    event_source += handler2
    event_source += handler3

    # Exercise
    event_source -= handler2

    # Verify
    assert handler2 not in event_source._handlers

    # Cleanup
    # (none)

# Generated at 2022-06-21 08:02:40.184072
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source += lambda x: x
    source += lambda x: x



# Generated at 2022-06-21 08:02:46.658394
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class Test:
        def test_callable(self):
            es = _EventSource()
            func = lambda: None
            es += func

        def test_not_callable(self):
            es = _EventSource()
            with raises(ValueError) as err:
                es += 'abc'

            assert err.value.args == ('handler must be callable',)

    Test().test_callable()
    Test().test_not_callable()


# Generated at 2022-06-21 08:02:53.414313
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # arrange
    sut = _EventSource()
    sut.__iadd__(lambda: None)
    sut._on_exception = lambda orig, ex, *args, **kwargs: False

    # act
    sut.__isub__(lambda: None)

    # assert
    assert len(sut._handlers) == 0



# Generated at 2022-06-21 08:02:54.870016
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    e -= 'foo'



# Generated at 2022-06-21 08:02:56.795341
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += 'handler'


# Generated at 2022-06-21 08:03:08.957619
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import types

    obj = AnsibleCollectionConfig()

    assert obj._collection_finder is None
    assert obj._default_collection is None
    assert isinstance(obj._on_collection_load, _EventSource)

    obj._collection_finder = 1
    with pytest.raises(ValueError):
        obj._collection_finder = 2

    obj.default_collection = 1
    assert obj.default_collection == 1
    obj.default_collection = 'foo'
    assert obj.default_collection == 'foo'
    obj.default_collection = None
    assert obj.default_collection is None

    obj.on_collection_load = 1
    with pytest.raises(ValueError):
        obj.on_collection_load = 2

    assert obj.collection_finder is None

# Generated at 2022-06-21 08:03:09.539923
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig(meta=1, name=2, bases=3)

# Generated at 2022-06-21 08:03:13.050281
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert not e._handlers

    def foo():
        pass

    def bar():
        pass

    e += foo
    e += bar

    assert e._handlers == {foo, bar}



# Generated at 2022-06-21 08:03:15.078769
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert not e._handlers
    assert isinstance(e, _EventSource)


# Generated at 2022-06-21 08:03:25.489852
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import sys

    if sys.version_info < (3, 0):
        def raise_exc(ex_text, ex_value=None):
            if ex_value is None:
                raise Exception(ex_text)

# Generated at 2022-06-21 08:03:36.048718
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from _event_source_test_1 import func1
    from _event_source_test_2 import func2
    from _event_source_test_3 import func3
    from _event_source_test_4 import func4

    es = _EventSource()

    es += func1
    es += func2
    es += func3
    es += func4

    es -= func1

    es.fire(1, 2, 3)



# Generated at 2022-06-21 08:03:42.736466
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    config.default_collection = 'foo.bar:baz'
    assert config.default_collection == 'foo.bar:baz'
    assert config.on_collection_load

    # check that the event source is the correct type
    with config.on_collection_load as x:
        assert x._on_exception is _EventSource._on_exception

    try:
        config.collection_finder = 'not a valid argument'
    except ValueError:
        pass

    try:
        config.default_collection = 'yada'
        config.default_collection = 'yada'
    except ValueError:
        pass

# Generated at 2022-06-21 08:03:55.082816
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # callable function used in this test
    def attach_callable(func):
        attach_callable.called = True
        attach_callable.args = func.__call__()

    def callable_with_exception():
        raise RuntimeError('exception in callable')

    def callable_without_exception_with_result():
        callable_without_exception_with_result.called = True
        return 42

    def callable_without_exception_with_no_result():
        callable_without_exception_with_no_result.called = True

    def on_exception(handler, exc, *args, **kwargs):
        on_exception.called = True
        on_exception.exc = exc
        return True

    # prepare first test data
    eventsource = _EventSource()


# Generated at 2022-06-21 08:03:57.213317
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda x: x
    assert(len(es._handlers) == 1)


# Generated at 2022-06-21 08:04:01.470850
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj = _EventSource()
    assert obj._handlers == set()
    obj += lambda: None
    assert obj._handlers == {lambda: None}
    obj += lambda: None
    assert obj._handlers == {lambda: None}
    obj += lambda: None
    assert obj._handlers == {lambda: None}


# Generated at 2022-06-21 08:04:09.774081
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class HandledException(Exception):
        pass

    class Handler(object):
        def __init__(self, exc_to_raise=None):
            self._exc_to_raise = exc_to_raise

        def handle(self):
            if self._exc_to_raise:
                raise self._exc_to_raise

    class Source(_EventSource):
        def __init__(self):
            super(Source, self).__init__()
            self._handle_exception_call_count = 0

        @property
        def handle_exception_call_count(self):
            return self._handle_exception_call_count

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._handle_exception_call_count += 1

# Generated at 2022-06-21 08:04:13.544628
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.playbook_paths is None

# Generated at 2022-06-21 08:04:21.649290
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSource(_EventSource):
        def _on_exception(self, exc, *args, **kwargs):
            return False

    def handler1(arg1, arg2):
        pass

    def handler2(kwarg1, kwarg2):
        pass

    event_source = EventSource()
    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-21 08:04:27.847445
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Test case where the handler exists
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    event_source -= handler
    assert len(event_source._handlers) == 0
    # Test case where the handler does not exist
    event_source = _EventSource()
    # Ensure that the event_source does not contain a handler
    handler = lambda: None
    event_source -= handler
    assert len(event_source._handlers) == 0


# Generated at 2022-06-21 08:04:33.160867
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()
    handler_1_fired = [False]

    @source.on_collection_load
    def handler_1():
        handler_1_fired[0] = True

    source.fire()

    assert handler_1_fired[0] is True


# Generated at 2022-06-21 08:04:44.628946
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es

    assert not es._handlers
    assert len(es._handlers) == 0

    result = es.fire()
    assert result is None



# Generated at 2022-06-21 08:04:46.920406
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler(foo):
        pass

    e = _EventSource()
    e += handler
    e -= handler
    assert not e._handlers

# Generated at 2022-06-21 08:04:57.830431
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # we expect this to raise since the handler must be callable
    try:
        o = _EventSource()
        o += 'foo'
        raise AssertionError('callable handler expected')
    except ValueError:
        pass

    # we expect this to raise since the handler must be callable
    try:
        o = _EventSource()
        o += 123
        raise AssertionError('callable handler expected')
    except ValueError:
        pass

    # we expect this to raise since the handler must be callable
    try:
        o = _EventSource()
        o += object()
        raise AssertionError('callable handler expected')
    except ValueError:
        pass

    # we expect this to raise since the handler must be callable

# Generated at 2022-06-21 08:05:09.358642
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # assert that we can pass parameters to the event source
    class _Foo():

        def bar(self, width, height):
            self.width = width
            self.height = height

    foo = _Foo()

    event_source = _EventSource()

    event_source += foo.bar

    event_source.fire(width=100, height=200)

    assert foo.width == 100 and foo.height == 200

    # assert that we can unsubscribe from an event source
    class _Bar():

        def __init__(self):
            self.fired = False

        def baz(self, *args, **kwargs):
            self.fired = True

    bar = _Bar()

    event_source += bar.baz

    event_source.fire(width=100, height=200)

    assert bar.fired is True

# Generated at 2022-06-21 08:05:11.087710
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')

# Generated at 2022-06-21 08:05:18.777407
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    result1 = [None]
    result2 = [None]

    def handler1(value):
        result1[0] = value

    def handler2(value):
        result2[0] = value

    event += handler1
    event += handler2

    event.fire(42)

    assert result1[0] == 42
    assert result2[0] == 42

# Generated at 2022-06-21 08:05:30.057512
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    event_source = _EventSource()

    def on_func(arg):
        print(arg)
    def on_func_error(arg):
        raise ValueError('on_func_error')

    event_source += on_func
    assert len(event_source._handlers) == 1
    assert list(event_source._handlers)[0] == on_func

    event_source += on_func_error
    assert len(event_source._handlers) == 2
    assert list(event_source._handlers)[1] == on_func_error

    event_source += 'abc'
    assert len(event_source._handlers) == 3

    try:
        event_source += 123
    except ValueError as e:
        assert 'handler must be callable' in to_text(e)

    event_source -= on

# Generated at 2022-06-21 08:05:31.770420
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler = lambda x: x
    event_source += handler
    event_source -= handler
    assert handler not in event_source._handlers


# Generated at 2022-06-21 08:05:37.345325
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not AnsibleCollectionConfig.collection_finder
    assert not AnsibleCollectionConfig.default_collection
    assert AnsibleCollectionConfig.on_collection_load
    assert not AnsibleCollectionConfig.collection_paths
    assert not AnsibleCollectionConfig.playbook_paths


# -------------------------------------------------------------------------------------------------
# Test implementation of AnsibleCollectionConfig for modules.

# HACK: import from ansible_test/_data/collect_ignore/... because this module is not in a collection.
from ansible_test.unit.collect_ignore._data.collect_ignore import collection_loader



# Generated at 2022-06-21 08:05:47.011922
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # the goal of this test is to verify that the constructor is only run once

    class Meta(type):

        def __init__(meta, name, bases):
            # This assert will fail if test__AnsibleCollectionConfig is run twice
            assert False, 'Meta __init__() should not be called multiple times'

    # To check that the goal of the test is achieved, we verify that Meta.__init__ is called when
    # we instantiate the class _AnsibleCollectionConfig
    _AnsibleCollectionConfig(Meta, 'AnsibleCollectionConfig', None)

    # Create another instance of _AnsibleCollectionConfig (ie same class), which should fail
    try:
        _AnsibleCollectionConfig(Meta, 'AnsibleCollectionConfig', None)
    except AssertionError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-21 08:05:59.913926
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es


# Generated at 2022-06-21 08:06:10.255935
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Foo:
        def __call__(self, *args, **kwargs):
            print("foo{}".format((args, kwargs)))

    class Bar:
        def __init__(self, str):
            self._str = str

        def __call__(self, *args, **kwargs):
            print("{:s}{:s}".format(self._str, str((args, kwargs))))

    event_source = _EventSource()
    foo1 = Foo()
    foo2 = Foo()
    bar1 = Bar("bar1:")
    bar2 = Bar("bar2:")

    event_source += foo1
    event_source += bar1
    event_source += foo2
    event_source += bar2


# Generated at 2022-06-21 08:06:13.459989
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def test_callable():
        pass

    event_source += test_callable
    assert test_callable in event_source._handlers

    event_source -= test_callable

    assert test_callable not in event_source._handlers

# Generated at 2022-06-21 08:06:17.954819
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    # the handler argument of fire must be a callable
    # so the following will raise TypeError
    # event_source.fire([])

    def _handler(*args, **kwargs):
        pass

    event_source.fire()
    event_source += _handler
    event_source.fire()

    def _handler_with_exception():
        raise Exception('This is an exception')

    event_source += _handler_with_exception
    count = 0
    for _ in event_source._handlers:
        if count == 1:
            try:
                event_source.fire()
            except Exception:
                pass
        count += 1



# Generated at 2022-06-21 08:06:24.360162
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # constructor should set the class members to their default values
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

    # constructor should create a new _EventSource object and assign it to the on_collection_load property
    assert AnsibleCollectionConfig._on_collection_load
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:06:35.170804
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def _on_exception(handler, ex, *args, **kwargs):
        return True

    event_source = _EventSource()
    event_source._on_exception = _on_exception

    assert event_source._handlers == set()

    def handler(a, b, c):
        pass

    assert callable(handler)

    event_source += handler
    assert handler in event_source._handlers

    try:
        event_source += None
        assert False
    except ValueError as ve:
        pass
    except Exception as e:
        assert False

    def handler1(a, b, c):
        pass

    assert callable(handler1)

    event_source += handler1
    assert handler1 in event_source._handlers


# Generated at 2022-06-21 08:06:39.548695
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    def f(a, b):
        return a + b
    e += f
    assert e._handlers == set([f])
    e -= f
    assert e._handlers == set()

# Generated at 2022-06-21 08:06:46.184666
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(arg1, arg2):
        pass

    def handler2(arg3, arg4):
        pass

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-21 08:06:48.150634
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # this should not raise
    _AnsibleCollectionConfig(None, '_M', None)


# Generated at 2022-06-21 08:06:54.771598
# Unit test for constructor of class _EventSource
def test__EventSource():
    result = None
    try:
        result = _EventSource()
    except Exception as e:
        print('FAIL: _EventSource() threw exception: {}'.format(e))

    if result is None:
        print('FAIL: _EventSource() did not return')
    elif not isinstance(result, _EventSource):
        print('FAIL: _EventSource() returned a non-object')

    print('PASS: _EventSource()')


# Generated at 2022-06-21 08:07:17.926405
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()


# Generated at 2022-06-21 08:07:21.480128
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def event_handler(x):
        pass

    event_source = _EventSource()
    event_source += event_handler
    assert event_handler in event_source._handlers

    event_source -= event_handler
    assert event_handler not in event_source._handlers

# Generated at 2022-06-21 08:07:24.548049
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_source = _EventSource()
    def test_func(a, b):
        return a + b
    test_source += test_func
    assert len(test_source._handlers) == 1


# Generated at 2022-06-21 08:07:34.032602
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Construct test input values and expected results
    test_handlers = [
        lambda: None,
        lambda: None,
    ]

    # Construct test object
    test_object = _EventSource()

    for handler in test_handlers:
        test_object += handler

    # Remove a handler from the set
    test_object -= test_handlers[1]

    # Check that test_handlers[1] was removed
    assert test_handlers[0] in test_object._handlers
    assert test_handlers[1] not in test_object._handlers

    # Remove all handlers
    for handler in test_handlers:
        test_object -= handler

    # Check that all handlers were removed
    assert all([h not in test_object._handlers for h in test_handlers])



# Generated at 2022-06-21 08:07:45.921249
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    ones = []
    zeros = []

    def one():
        ones.append(1)

    def zero():
        zeros.append(1)

    # no events added
    event_source.fire()
    assert not ones
    assert not zeros

    event_source += one
    event_source.fire()
    assert ones == [1]
    assert not zeros

    event_source += zero
    event_source.fire()
    assert ones == [1, 1]
    assert zeros == [1]

    event_source -= zero
    event_source.fire()
    assert ones == [1, 1, 1]
    assert zeros == [1]

    def exception_one(ex, *args, **kwargs):
        assert ex.args == ('exc one',)

# Generated at 2022-06-21 08:07:49.988293
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_object = _EventSource()
    
    # test adding callable
    func = lambda x: x
    test_object.__iadd__(func)
    assert func in test_object._handlers
    
    # test adding non-callable
    value_error = None
    try:
        test_object.__iadd__(1)
    except ValueError as e:
        value_error = e

    assert value_error is not None


# Generated at 2022-06-21 08:07:57.037263
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class AnsibleCollectionConfigTest(with_metaclass(_AnsibleCollectionConfig)):
        pass

    # Create an instance and check for expected properties
    obj = AnsibleCollectionConfigTest()
    assert obj._collection_finder is None
    assert obj._default_collection is None
    assert isinstance(obj._on_collection_load, _EventSource)

    # Ensure that setting properties on the class properties raises expected exceptions
    # Attempt to set collection_finder
    try:
        obj.collection_finder = 'new value'
        assert False
    except ValueError:
        pass

    # Attempt to set default_collection
    try:
        obj.default_collection = 'new value'
        assert False
    except ValueError:
        pass

    # Attempt to set on_collection_load

# Generated at 2022-06-21 08:08:02.188297
# Unit test for constructor of class _EventSource
def test__EventSource():
    fake_handler = lambda x: x
    event = _EventSource()
    assert fake_handler not in event._handlers

    event += fake_handler
    assert fake_handler in event._handlers

    event -= fake_handler
    assert fake_handler not in event._handlers


# Generated at 2022-06-21 08:08:13.612510
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig.on_collection_load, '_handlers'), 'AnsibleCollectionConfig.on_collection_load should not have _handlers attribute'
    assert not hasattr(AnsibleCollectionConfig.on_collection_load, 'fire'), 'AnsibleCollectionConfig.on_collection_load should not have fire method'
    try:
        AnsibleCollectionConfig.on_collection_load = None
        assert False, 'AnsibleCollectionConfig.on_collection_load setter must throw exception when value is not _EventSource'
    except ValueError:
        pass

    assert not hasattr(AnsibleCollectionConfig, '_collection_finder'), 'AnsibleCollectionConfig._collection_finder should not be defined'

# Generated at 2022-06-21 08:08:23.648619
# Unit test for constructor of class _EventSource
def test__EventSource():
    evt_source = _EventSource()
    assert len(evt_source._handlers) == 0

    # test __iadd__
    evt_source += lambda: None
    assert len(evt_source._handlers) == 1

    # test __isub__
    evt_source -= lambda: None
    assert len(evt_source._handlers) == 0



# Generated at 2022-06-21 08:09:13.635908
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load
    assert AnsibleCollectionConfig.playbook_paths == []

# Generated at 2022-06-21 08:09:17.075056
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    _EventSource___isub__ = _EventSource()
    def sample_function_1(arg1):
        return arg1
    _EventSource___isub__ -= sample_function_1


# Generated at 2022-06-21 08:09:18.581261
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _TestCollectionConfig(_AnsibleCollectionConfig):
        pass

    type = _TestCollectionConfig
    type._collection_finder = 'finder'
    type._default_collection = 'collection'
    assert type.collection_finder == 'finder'
    assert type.default_collection == 'collection'

# Generated at 2022-06-21 08:09:25.583952
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    try:
        _ = AnsibleCollectionConfig.collection_finder
    except ValueError:
        pass
    else:
        raise AssertionError('expected ValueError when calling collection_finder')

    try:
        _ = AnsibleCollectionConfig.playbook_paths
    except NotImplementedError:
        pass
    else:
        raise AssertionError('expected NotImplementedError when calling playbook_paths')

    try:
        AnsibleCollectionConfig.playbook_paths = '/foo'
    except NotImplementedError:
        pass
    else:
        raise AssertionError('expected NotImplementedError when setting playbook_paths')

    try:
        _ = AnsibleCollectionConfig.on_collection_load
    except AttributeError:
        pass

# Generated at 2022-06-21 08:09:32.689853
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

    assert len(AnsibleCollectionConfig._on_collection_load._handlers) == 0
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None

    assert len(AnsibleCollectionConfig.on_collection_load._handlers) == 0
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

# Generated at 2022-06-21 08:09:36.005595
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:09:41.194207
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    assert event._handlers == set()

    def print_args(*args, **kwargs):
        print(args, kwargs)

    event += print_args
    assert event._handlers == {print_args}

    event -= print_args
    assert event._handlers == set()



# Generated at 2022-06-21 08:09:48.083466
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import unittest
    from ansible_test._data import data_loader

    class _Run(unittest.TestCase):
        def test__fire(self):
            # Create _EventSource instance for testing
            _EventSource_instane = _EventSource()

            # Create handler function
            def event_handler_func(arg):
                print("event_handler_func: arg=%s" % arg)

            # Add handler function to event source
            _EventSource_instane += event_handler_func

            # Trigger event
            _EventSource_instane.fire("test")

    data_loader.protect_bypass_cache(globals(), 'test__EventSource_fire')()

# Generated at 2022-06-21 08:09:51.374411
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    acc = _AnsibleCollectionConfig('meta', 'name', 'bases')
    acc._on_collection_load = 'foo'
    assert acc.on_collection_load == 'foo'
    del acc._collection_finder
    del acc._default_collection



# Generated at 2022-06-21 08:09:53.672585
# Unit test for constructor of class _EventSource
def test__EventSource():
    eventsource = _EventSource()
    assert isinstance(eventsource, object)
    assert isinstance(eventsource._handlers, set)
    assert isinstance(eventsource._on_exception, object)

