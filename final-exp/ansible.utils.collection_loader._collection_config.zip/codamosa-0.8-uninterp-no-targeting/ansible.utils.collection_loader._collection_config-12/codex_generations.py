

# Generated at 2022-06-21 08:01:32.290865
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MyAnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    a = MyAnsibleCollectionConfig

    print()
    print(type(a._collection_finder))
    print(type(a._default_collection))
    print(type(a._on_collection_load))

    print()
    print(a._collection_finder)
    print(a._default_collection)
    print(a._on_collection_load)

    print()
    print(a.playbook_paths)
    a.playbook_paths = []

    a.collection_finder = 'foo'
    print()
    print(a.collection_finder)

    print()
    print(a.collection_paths)

    a.default_collection = 'foo'
    print()

# Generated at 2022-06-21 08:01:36.950197
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, _AnsibleCollectionConfig)
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None

# Generated at 2022-06-21 08:01:41.629398
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler1():
        return 1

    def handler2():
        return 2

    event_source += handler1
    event_source += handler2

    event_source -= handler2

    assert event_source._handlers == {handler1}


# Generated at 2022-06-21 08:01:50.404570
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()

    def callable_1():
        pass

    def callable_2():
        pass

    e += callable_1
    assert len(e._handlers) == 1
    assert callable_1 in e._handlers
    e -= callable_1
    assert len(e._handlers) == 0
    assert callable_1 not in e._handlers

    e += callable_1
    e -= callable_2
    assert len(e._handlers) == 1
    assert callable_1 in e._handlers



# Generated at 2022-06-21 08:01:55.501559
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.__name__ == 'AnsibleCollectionConfig'  # pylint: disable=no-member

    # __init__ will only get called once per process, but we drop the instances into a
    # module-level variable to make them accessible to other tests
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert len(AnsibleCollectionConfig._on_collection_load._handlers) == 0



# Generated at 2022-06-21 08:01:59.335671
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ans_coll_conf = AnsibleCollectionConfig()
    assert isinstance(ans_coll_conf.on_collection_load, _EventSource)
    assert ans_coll_conf.collection_finder is None
    assert ans_coll_conf.default_collection is None

# Generated at 2022-06-21 08:02:03.504801
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import unittest
    x = _EventSource()

    def y():
        pass

    x += y
    assert len(x._handlers) == 1

    x -= y
    assert len(x._handlers) == 0


# Generated at 2022-06-21 08:02:08.612753
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config.collection_finder is None
    assert config.collection_paths == []
    assert config.default_collection is None
    assert config.playbook_paths == []

    assert config._collection_finder is None
    assert config._default_collection is None

# Generated at 2022-06-21 08:02:10.485468
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.playbook_paths == []

# Generated at 2022-06-21 08:02:18.957780
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    # pylint: disable=unused-argument
    def handler1(x, y):
        pass

    def handler2(x, y):
        pass

    def handler3(x, y):
        pass

    event_source += handler1
    event_source += handler2
    event_source += handler3

    # pylint: disable=protected-access
    assert len(event_source._handlers) == 3

    event_source -= handler1
    assert len(event_source._handlers) == 2

    event_source -= handler2
    assert len(event_source._handlers) == 1

    event_source -= handler3
    assert len(event_source._handlers) == 0
    # pylint: enable=protected-access,unused-argument


# Unit test

# Generated at 2022-06-21 08:02:26.706209
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert isinstance(ac._on_collection_load, _EventSource)
    assert not ac._on_collection_load._handlers
    # TODO: assert that ac._finders is empty

# Generated at 2022-06-21 08:02:30.958906
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler1(a, b, **c):
        pass

    def handler2(a, b, **c):
        pass

    es += handler1
    es += handler1
    es += handler2

    assert es._handlers == {handler1, handler2}



# Generated at 2022-06-21 08:02:38.937758
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evt = _EventSource()
    assert not evt.fire()
    assert evt.fire()

    evt += lambda *args, **kwargs: 'hello'
    assert evt.fire()

    evt += lambda *args, **kwargs: 'world'
    assert evt.fire()

    evt -= lambda *args, **kwargs: 'hello'
    assert evt.fire()

    evt -= lambda *args, **kwargs: 'hello'


# Generated at 2022-06-21 08:02:48.568868
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEvent(object):

        def __init__(self):
            self.handled = False

        def __call__(self, *args, **kwargs):
            self.handled = True

    import copy

    es = _EventSource()

    # smoke test
    e1 = MyEvent()
    e2 = MyEvent()

    # no handlers, fire should not cause exception
    es.fire()

    # add handlers, fire should call them
    es += e1
    es += e2
    es.fire()
    assert e1.handled is True
    assert e2.handled is True

    # remove handler, fire should not call it
    es -= e1
    es.fire()
    assert e1.handled is True
    assert e2.handled is True

    # handler throwing exception, fire should not stop processing handlers
    e

# Generated at 2022-06-21 08:02:53.409250
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def foo():
        pass

    def bar():
        pass

    # Set up
    e = _EventSource()
    e += foo
    e += bar

    # Test
    e -= foo

    # Verify
    assert bar in e._handlers
    assert foo not in e._handlers

# Generated at 2022-06-21 08:03:00.024139
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config is not None

#####################################################################
# Tests to ensure that the AnsibleCollectionConfig class behaves as expected
#
# TODO:
# - Test that the default_collection and collection_finder properties of AnsibleCollectionConfig raise ValueError when
#   attempting to set them more than once
# - Test that AnsibleColectionConfig.on_collection_load raises ValueError when attempting to set it to anything
#   other than the _EventSource instance
#####################################################################

# Generated at 2022-06-21 08:03:03.090372
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # pylint: disable=no-member
    # These properties are set by the metaclass
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:03:13.774638
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    events = _EventSource()
    sum = 0
    for i in range(0, 10):
        events += lambda x: sum.__iadd__(x)

    events.fire(1)
    assert sum == 1

    events.fire(2)
    assert sum == 3

    events -= lambda x: sum.__iadd__(x)
    events.fire(1)
    assert sum == 4

    class MyError(Exception): pass

    def handler(x):
        raise MyError()

    try:
        events += handler
        events.fire(1)
    except MyError:
        pass

    events -= handler
    try:
        events.fire(1)
    except MyError:
        assert False

# Generated at 2022-06-21 08:03:20.711118
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.common.text.converters import to_text

    e = _EventSource()
    a = lambda x: True
    b = lambda x: x == 1
    c = lambda x: x == 2

    e += a
    assert a in e._handlers

    e += b
    assert a in e._handlers
    assert b in e._handlers

    e += c
    assert a in e._handlers
    assert b in e._handlers
    assert c in e._handlers

    e.fire(1)
    e.fire(2)


# Generated at 2022-06-21 08:03:24.541417
# Unit test for constructor of class _EventSource
def test__EventSource():
    def _handler(*args, **kwargs):
        pass

    es = _EventSource()
    es += _handler
    es += _handler
    es -= _handler
    es._on_exception(None, None)



# Generated at 2022-06-21 08:03:34.049697
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    # because the actual value is an instance of _EventSource,
    # this will fail unless the metaclass magic is working
    config.on_collection_load += lambda: True

# Generated at 2022-06-21 08:03:37.040447
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    @AnsibleCollectionConfig.on_collection_load.__iadd__
    def dummy_handler():
        pass

    assert AnsibleCollectionConfig.on_collection_load._handlers


# Generated at 2022-06-21 08:03:41.326945
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    collection_config = AnsibleCollectionConfig()
    assert not collection_config._collection_finder
    assert not collection_config._default_collection
    assert not collection_config._on_collection_load._handlers
    assert not collection_config.collection_finder
    assert not collection_config.default_collection
    assert not collection_config.on_collection_load



# Generated at 2022-06-21 08:03:52.621433
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, 'collection_finder'), 'class property not implemented: collection_finder'
    assert hasattr(AnsibleCollectionConfig, 'collection_paths'), 'class property not implemented: collection_paths'
    assert hasattr(AnsibleCollectionConfig, 'default_collection'), 'class property not implemented: default_collection'
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths'), 'class property not implemented: playbook_paths'

    assert getattr(AnsibleCollectionConfig, '_on_collection_load') is not None, '_on_collection_load is missing'
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load'), 'class property not implemented: on_collection_load'

    instance = AnsibleCollectionConfig()


# Generated at 2022-06-21 08:03:57.496234
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    handler_count = 0

    def handler():
        nonlocal handler_count
        handler_count += 1

    event_source += handler
    event_source.fire()
    assert handler_count == 1

    event_source -= handler
    event_source.fire()
    assert handler_count == 1


test__EventSource_fire()

# Generated at 2022-06-21 08:04:02.839581
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()

    def dummy_handler1(arg1):
        pass

    def dummy_handler2(arg1):
        pass

    source += dummy_handler1

    assert dummy_handler1 in source._handlers

    source += dummy_handler2

    assert dummy_handler1 in source._handlers
    assert dummy_handler2 in source._handlers

    assert source._on_exception(dummy_handler1, Exception())



# Generated at 2022-06-21 08:04:05.881967
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    a = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert a._collection_finder is None
    assert a._default_collection is None
    assert isinstance(a._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:04:07.338515
# Unit test for constructor of class _EventSource
def test__EventSource():
    s = _EventSource()
    assert isinstance(s, _EventSource)



# Generated at 2022-06-21 08:04:08.708736
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert isinstance(e, _EventSource)


# Generated at 2022-06-21 08:04:20.703428
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return True

    es = TestEventSource()
    assert len(es._handlers) == 0

    # adding a handler works
    def handler1(*args, **kwargs):
        pass

    es += handler1
    assert len(es._handlers) == 1
    assert handler1 in es._handlers

    # adding the same handler more than once has no effect (set semantics)
    es += handler1
    assert len(es._handlers) == 1
    assert handler1 in es._handlers

    # adding another handler works
    def handler2(*args, **kwargs):
        pass

    es += handler2
    assert len(es._handlers) == 2
    assert handler2 in es._hand

# Generated at 2022-06-21 08:04:39.175340
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class Foo(AnsibleCollectionConfig):
        pass

    assert Foo._collection_finder is None
    assert Foo._default_collection is None

    event_source = Foo._on_collection_load

    assert isinstance(event_source, _EventSource)
    assert event_source._handlers == set()
    assert Foo.on_collection_load is event_source

    assert Foo.collection_finder is None
    assert Foo.default_collection is None
    assert Foo.on_collection_load is event_source

    def handler(event):
        pass

    Foo.on_collection_load += handler
    assert event_source._handlers == {handler}

    Foo.on_collection_load -= handler
    assert event_source._handlers == set()


# Generated at 2022-06-21 08:04:50.655052
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    mock_collection_finder = ['collection finder']
    mock_default_collection = ['default collection']
    mock_on_collection_load = ['on collection load']
    mock_playbook_paths = ['playbook paths']

    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.playbook_paths is None

    AnsibleCollectionConfig.collection_finder = mock_collection_finder
    AnsibleCollectionConfig.default_collection = mock_default_collection
    AnsibleCollectionConfig.on_collection_load += mock_on_collection_load
    AnsibleCollectionConfig.playbook_paths = mock_playbook_paths

    assert AnsibleCollectionConfig.collection_finder is not None
   

# Generated at 2022-06-21 08:04:56.269714
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    some_func1 = lambda: None
    some_func2 = lambda: None

    evt = _EventSource()
    evt += some_func1
    evt += some_func2

    evt -= some_func1

    assert some_func1 not in evt._handlers
    assert some_func2 in evt._handlers


# Generated at 2022-06-21 08:05:05.763099
# Unit test for constructor of class _EventSource
def test__EventSource():
    def _on_foo(*args, **kwargs):
        print('yay!')

    def _on_bar(*args, **kwargs):
        print('yo!')

    def _on_baz(*args, **kwargs):
        print('yes?')

    es = _EventSource()

    for name in ('_on_foo', '_on_bar', '_on_baz'):
        es += getattr(__builtins__.__dict__, name)

        for n in range(1, 4):
            es.fire()

        es -= getattr(__builtins__.__dict__, name)

# Generated at 2022-06-21 08:05:13.819609
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _EventSourceTest(AnsibleCollectionConfig):

        def __init__(self):
            super(_EventSourceTest, self).__init__()
            assert len(self._handlers) == 0
            assert self._on_collection_load is not None
            self.handler_a = 1
            self._on_collection_load += self.handler_a
            assert self._on_collection_load._handlers == {self.handler_a}
            assert self.handler_a in self._on_collection_load._handlers

        def test__EventSource___isub__(self):
            assert len(self._on_collection_load._handlers) == 1
            assert self.handler_a in self._on_collection_load._handlers
            self._on_collection_load -= self.handler_a

# Generated at 2022-06-21 08:05:18.102873
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # _EventSource__isub__ can be called with a value that is not in the set
    # and not raise a KeyError exception
    handlers = _EventSource()

    def handler():
        pass

    handlers += handler
    handlers -= handler
    handlers -= handler

# Generated at 2022-06-21 08:05:23.104369
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1():  # noqa
        pass

    def handler_2():  # noqa
        pass

    event_source = _EventSource()
    event_source += handler_1
    event_source += handler_2

    event_source.fire()

    event_source -= handler_2

    event_source.fire()

# Generated at 2022-06-21 08:05:32.868663
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # ------------------------------------------------------------------------------------------------------------------
    # SETUP
    # ------------------------------------------------------------------------------------------------------------------
    event_source = _EventSource()
    def func1():
        pass

    def func2():
        raise ValueError('func2')

    # ------------------------------------------------------------------------------------------------------------------
    # TEST: Remove handler that has not been added
    # ------------------------------------------------------------------------------------------------------------------
    event_source -= func1

    # ------------------------------------------------------------------------------------------------------------------
    # TEST: Remove handler that has been added
    # ------------------------------------------------------------------------------------------------------------------
    event_source += func1
    event_source -= func1

    # ------------------------------------------------------------------------------------------------------------------
    # TEST: Remove handler that throws
    # ------------------------------------------------------------------------------------------------------------------
    event_source += func2
    try:
        event_source -= func2
    except ValueError:
        pass

# Generated at 2022-06-21 08:05:38.858713
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes

    evs = _EventSource()
    def f(x):
        print('hi', x)

    evs += f
    with pytest.raises(ValueError):
        evs += 1

    # Test firing with a byte string
    evs.fire(to_bytes('hello'))



# Generated at 2022-06-21 08:05:43.806763
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert isinstance(config.collection_finder, _AnsibleCollectionConfig)
    assert isinstance(config.default_collection, _AnsibleCollectionConfig)
    assert isinstance(config.on_collection_load, _EventSource)
    assert isinstance(config.playbook_paths, _AnsibleCollectionConfig)

# Generated at 2022-06-21 08:06:06.548382
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def handler_a(x):
        pass

    def handler_b(x):
        pass

    def handler_c(x):
        pass

    # verify that handler_a can be removed when it is not present
    es -= handler_a

    # add two handlers
    es += handler_a
    es += handler_b

    # verify that handler_a can be removed when it is present
    es -= handler_a

    # verify that handler_b can be removed when it is present
    es -= handler_b

    # verify that handler_b cannot be removed when it is not present
    es -= handler_b

    # verify that handler_c cannot be removed when it is not present
    es -= handler_c

# Generated at 2022-06-21 08:06:10.168024
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler(arg):
        return arg

    es += handler
    assert len(es._handlers) == 1

    es += handler
    assert len(es._handlers) == 1



# Generated at 2022-06-21 08:06:11.555463
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source._handlers == set()
    assert not callable(event_source)


# Generated at 2022-06-21 08:06:13.385873
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()
    assert ansible_collection_config._collection_finder == None


# Generated at 2022-06-21 08:06:15.664066
# Unit test for constructor of class _EventSource
def test__EventSource():
    collection = _EventSource()

    def test_function(func_value):
        pass

    collection.__iadd__(handler=test_function)
    assert test_function in collection._handlers
    assert callable(test_function)



# Generated at 2022-06-21 08:06:17.817074
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert not e._handlers


# Generated at 2022-06-21 08:06:20.332841
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    a = _EventSource()
    handler = lambda: None
    a += handler

    assert handler in a._handlers


# Generated at 2022-06-21 08:06:23.161003
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig.collection_finder = 'foo'
        assert 1 == 2
    except ValueError:
        pass

# Generated at 2022-06-21 08:06:34.280393
# Unit test for constructor of class _EventSource
def test__EventSource():
    handler = lambda: None
    assert callable(handler)

    es = _EventSource()

    # add a handler and check it's added
    es += handler
    assert set([handler]) == es._handlers

    # remove an existing handler and check it's removed
    es -= handler
    assert set() == es._handlers

    # remove a non-existing handler
    es -= handler
    assert set() == es._handlers

    # add a non-callable handler
    try:
        es += None
        assert False, 'expected exception'
    except ValueError as ex:
        assert 'must be callable' in to_text(ex)

    # remove a non-callable handler
    try:
        es -= None
        assert False, 'expected exception'
    except KeyError:
        pass

    # on exception is called when firing

# Generated at 2022-06-21 08:06:38.740282
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, _AnsibleCollectionConfig)

# Set a default AnsibleCollectionConfig object for all collection loading operations
_ansible_collections_config = AnsibleCollectionConfig()



# Generated at 2022-06-21 08:06:53.742786
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()
    assert ansible_collection_config.default_collection is None

# Generated at 2022-06-21 08:06:57.413296
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    test_class = _AnsibleCollectionConfig(str("foo"), str("bar"), [])
    assert not hasattr(test_class, '_collection_finder')
    assert not hasattr(test_class, '_default_collection')
    assert not hasattr(test_class, '_on_collection_load')



# Generated at 2022-06-21 08:07:02.455306
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load._handlers == set()
    assert AnsibleCollectionConfig.playbook_paths == []



# Generated at 2022-06-21 08:07:12.562276
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # First, set up a FooEventSource with a handler that just prints the parameters it was called with.
    class FooEventSource(_EventSource):
        def handler(self, s_arg, n_arg):
            print('handler was called with s_arg=%s and n_arg=%d' % (s_arg, n_arg))

    f_es = FooEventSource()
    f_es += f_es.handler
    # Now call the handler, which should print the parameters.
    s_arg = 'a string'
    n_arg = 42
    f_es.fire(s_arg, n_arg=n_arg)
    # Now remove the handler.
    f_es -= f_es.handler
    # Now call the handler again. It should remain silent, even if we pass different parameters.

# Generated at 2022-06-21 08:07:14.637342
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.default_collection is None


# Generated at 2022-06-21 08:07:22.524915
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    se = _EventSource()

    def a():
        pass

    def b():
        pass

    def c():
        pass

    se += a
    se += b

    assert a in se._handlers
    assert b in se._handlers
    assert c not in se._handlers

    se -= a

    assert a not in se._handlers
    assert b in se._handlers
    assert c not in se._handlers

    # test that no exception thrown when key not present
    se -= a

    assert a not in se._handlers
    assert b in se._handlers
    assert c not in se._handlers



# Generated at 2022-06-21 08:07:25.527905
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._collection_finder is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:07:34.536746
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventHandler:
        def __init__(self, name, test_case):
            self.name = name
            self.fired = None
            self.test_case = test_case

        def __call__(self, *args, **kwargs):
            self.fired = True
            self.test_case.assertEqual(self.name, kwargs.get('name', None))

    class TestCase:
        def test__EventSource_fire(self):
            _event_source = _EventSource()

            handler1 = EventHandler('test', self)
            handler2 = EventHandler('test', self)

            _event_source += handler1
            _event_source += handler2

            _event_source.fire(name='test')

            self.assertTrue(handler1.fired)

# Generated at 2022-06-21 08:07:36.720375
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac.collection_finder is None
    assert ac.default_collection is None

# Generated at 2022-06-21 08:07:38.557466
# Unit test for constructor of class _EventSource
def test__EventSource():
    source = _EventSource()
    assert source


# Generated at 2022-06-21 08:08:06.618251
# Unit test for constructor of class _EventSource
def test__EventSource():
    eventsource = _EventSource()
    assert eventsource._handlers == set()


# Generated at 2022-06-21 08:08:16.466855
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()
    # a 'non callable handler must raise ValueError'
    try:
        event.__iadd__('not_a_callable')
        assert False, 'ValueError not raised'
    except ValueError:
        pass
    # a callable handler must be added
    def handler(mystr):
        pass
    event.__iadd__(handler)
    assert event._handlers == {handler}
    # a previously added handler must be removed
    event.__isub__(handler)
    assert event._handlers == set()
    # a 'non existing handler must not raise KeyError'
    try:
        event.__isub__(handler)
    except KeyError:
        assert False, 'KeyError raised'



# Generated at 2022-06-21 08:08:20.264539
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    result = event_source.__isub__(None)
    # test that nothing happened
    assert event_source._handlers == set()
    assert result == event_source


# Generated at 2022-06-21 08:08:23.246081
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert ac._on_collection_load is not None

# Generated at 2022-06-21 08:08:34.855582
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import unittest

    class Test(unittest.TestCase):
        def test_removal_of_single_handler(self):
            e = _EventSource()
            h1 = lambda: None
            e += h1
            self.assertEqual(len(e._handlers), 1)
            e -= h1
            self.assertEqual(len(e._handlers), 0)

        def test_removal_of_multiple_handlers(self):
            e = _EventSource()
            h1 = lambda: None
            e += h1
            h2 = lambda: None
            e += h2
            self.assertEqual(len(e._handlers), 2)
            e -= h1
            self.assertEqual(len(e._handlers), 1)
            e -= h2

# Generated at 2022-06-21 08:08:38.144186
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.default_collection is None
    assert config.collection_paths == []
    assert config.playbook_paths == []

# Generated at 2022-06-21 08:08:42.866945
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def test_handler():
        pass

    event_source.__iadd__(test_handler)
    assert test_handler in event_source._handlers

    event_source.__isub__(test_handler)
    assert test_handler not in event_source._handlers



# Generated at 2022-06-21 08:08:45.267402
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(a, b=None):
        pass

    es = _EventSource()
    es += handler


# Generated at 2022-06-21 08:08:50.862174
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    assert event_source._handlers == set()

    def handler():
        pass

    event_source -= handler

    assert event_source._handlers == set()

    event_source += handler

    assert event_source._handlers == set([handler])

    event_source -= handler

    assert event_source._handlers == set()


# Generated at 2022-06-21 08:09:01.127876
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # GIVEN: An instance of class _EventSource
    instance = _EventSource()

    # WHEN: We add a callable to the instance
    #  AND: We add a non callable to the instance
    #  AND: We add a callable that raises an exception when called
    callable1 = lambda: None
    non_callable = ""

    def callable2(*args, **kwargs):
        raise NotImplementedError()

    instance += callable1
    instance += non_callable
    instance += callable2

    # THEN: The instance must have exactly two handlers
    assert len(instance._handlers) == 2

    # AND: The instance must have exactly two handlers when using += to add an existing handler
    instance += callable1
    assert len(instance._handlers) == 2

    # AND: The instance must have

# Generated at 2022-06-21 08:10:02.959425
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    eventsource = _EventSource()
    assert hasattr(eventsource, '_handlers')
    assert eventsource._handlers == set()

    assert callable(eventsource.__iadd__)
    assert eventsource.__iadd__(lambda: None) is eventsource
    assert eventsource._handlers == {lambda: None}

    assert eventsource.__iadd__(lambda x: x) is eventsource
    assert eventsource._handlers == {lambda: None, lambda x: x}



# Generated at 2022-06-21 08:10:11.225741
# Unit test for constructor of class _EventSource
def test__EventSource():
    import sets

    empty_handler_set = sets.Set()

    # Verify constructor
    event_source = _EventSource()
    assert event_source._handlers == empty_handler_set

    # Verify that we can add and remove a handler
    def test_handler(args):
        pass
    event_source += test_handler
    assert event_source._handlers == sets.Set([test_handler])
    event_source += test_handler
    assert event_source._handlers == sets.Set([test_handler])
    event_source -= test_handler
    assert event_source._handlers == empty_handler_set
    event_source -= test_handler
    assert event_source._handlers == empty_handler_set

    # Verify that we can only add callable objects

# Generated at 2022-06-21 08:10:11.715016
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass

# Generated at 2022-06-21 08:10:15.660858
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_collections.ansible.netcommon.tests.unit.collection_loader.utils import Fake
    e = _EventSource()
    e += Fake._on_call

    assert len(e._handlers) == 1


# Generated at 2022-06-21 08:10:26.486706
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # verify the metaclass can be instantiated
    cls = _AnsibleCollectionConfig('meta', 'AnsibleCollectionConfig', ())
    assert isinstance(cls, type(_AnsibleCollectionConfig))
    assert isinstance(cls, type(AnsibleCollectionConfig))

    # verify the class can be instantiated
    ansible_collection_config = AnsibleCollectionConfig
    assert isinstance(ansible_collection_config, type(AnsibleCollectionConfig))
    assert isinstance(ansible_collection_config, type(_AnsibleCollectionConfig))

    # verify the class' attributes are initialized
    assert not ansible_collection_config._collection_finder
    assert not ansible_collection_config._default_collection
    assert not ansible_collection_config._on_collection_load._handlers



# Generated at 2022-06-21 08:10:28.538985
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    f = lambda a: None

    e += f



# Generated at 2022-06-21 08:10:29.727694
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-21 08:10:32.118797
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda arg: arg

    def test_func(arg):
        arg

    es += test_func

    assert len(es._handlers) == 2

# Generated at 2022-06-21 08:10:36.421485
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(a, b):
        pass

    event_source += handler
    assert(handler in event_source._handlers)

    event_source -= handler
    assert(handler not in event_source._handlers)



# Generated at 2022-06-21 08:10:44.660018
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Without parameters
    test = _EventSource()
    assert callable(test) is False
    assert test._handlers == set()
    assert test.fire() is None
    assert test.on_exception() is True
    class Test:
        def __init__(self, test):
            self.test = test
    # With parameters
    test1 = Test(test)
    assert callable(test1) is False
    assert test1.test._handlers == set()
    assert test1.test.fire() is None
    assert test1.test.on_exception() is True
