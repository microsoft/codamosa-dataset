

# Generated at 2022-06-21 08:01:32.963483
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Setup helper
    class DefaultEvent():
        pass

    def handler():
        pass

    # Success Case
    event = DefaultEvent()
    event += handler
    assert callable(event._handlers.pop())

    # Failure Case (non callable handler)
    event = DefaultEvent()
    try:
        handler = 42
        event += handler
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 08:01:37.462529
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler = object()
    event_source += handler

    assert event_source._handlers == set([handler])
    event_source -= handler
    assert event_source._handlers == set()



# Generated at 2022-06-21 08:01:45.370003
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible_collections.ansible.misc.tests.unit._constants import TestCollectionPaths

    TestCollectionPaths.add_collection_paths()

    try:
        assert AnsibleCollectionConfig._collection_finder is None
        assert AnsibleCollectionConfig._default_collection is None
        assert len(AnsibleCollectionConfig._on_collection_load._handlers) == 0
        assert AnsibleCollectionConfig.on_collection_load == AnsibleCollectionConfig._on_collection_load
    finally:
        TestCollectionPaths.rm_collection_paths()

# Generated at 2022-06-21 08:01:47.322338
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    event -= lambda x: x


# Generated at 2022-06-21 08:01:49.772741
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None


# Generated at 2022-06-21 08:01:51.487338
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    actual = AnsibleCollectionConfig()
    assert isinstance(actual._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:01:59.557663
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=no-member,protected-access

    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

    assert AnsibleCollectionConfig._on_collection_load._handlers == set()

    # pylint: disable=no-member

    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None

    assert AnsibleCollectionConfig.on_collection_load._handlers == set()

    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.playbook_paths == []



# Generated at 2022-06-21 08:02:03.353172
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert not AnsibleCollectionConfig.collection_paths
    assert not AnsibleCollectionConfig.playbook_paths

# Generated at 2022-06-21 08:02:06.713968
# Unit test for constructor of class _EventSource
def test__EventSource():
    class MyEvent(object):
        def __init__(self):
            self.event_source = _EventSource()
    obj = MyEvent()
    assert type(obj.event_source._handlers) is set

# Generated at 2022-06-21 08:02:17.016542
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    num_calls = 0

    def handler1(arg1):
        nonlocal num_calls
        assert arg1 == 'arg1'
        num_calls += 1

    def handler2(arg2):
        nonlocal num_calls
        assert arg2 == 'arg2'
        num_calls += 1

    assert event_source._handlers == set()

    event_source += handler1
    assert event_source._handlers == {handler1}

    event_source += handler1
    assert event_source._handlers == {handler1}

    event_source += handler2
    assert event_source._handlers == {handler1, handler2}

    event_source.fire('arg1')
    assert num_calls == 1

    event_source.fire('arg2')

# Generated at 2022-06-21 08:02:30.918556
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    c = []
    e += lambda: c.append('a')
    e += lambda: c.append('b')
    e += lambda: c.append('c')
    e += lambda: c.append('d')
    e += lambda: c.append('e')
    e += lambda: c.append('f')
    e += lambda: c.append('g')
    e += lambda: c.append('h')
    e += lambda: c.append('i')
    e += lambda: c.append('j')

    e.fire()

    assert c == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']


# Generated at 2022-06-21 08:02:39.480626
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    es = _EventSource()
    es += handler1
    assert handler1 in es._handlers
    assert handler2 not in es._handlers
    es -= handler2
    assert handler1 in es._handlers
    assert handler2 not in es._handlers
    es -= handler1
    assert handler1 not in es._handlers
    assert handler2 not in es._handlers

# Generated at 2022-06-21 08:02:48.780216
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils._text import to_bytes

    event_source = _EventSource()

    # test adding/removing handlers to event source
    def handler1(message):
        assert message == 'hello'
        handler1.calls += 1

    def handler2(message):
        assert message == 'hello'
        handler2.calls += 1

    handler1.calls = 0
    handler2.calls = 0

    event_source += handler1
    event_source += handler2
    event_source.fire('hello')
    event_source -= handler2
    event_source.fire('hello')

    assert handler1.calls == 2
    assert handler2.calls == 1

    # test that exception exits handler and doesn't affect other handlers
    def raise_handler(message):
        assert message == 'hello'

# Generated at 2022-06-21 08:03:00.273614
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # It exists
    assert AnsibleCollectionConfig is not None
    # Attempting to create an instance of it should fail
    try:
        x = AnsibleCollectionConfig()
        assert False, 'AnsibleCollectionConfig is not abstract'
    except TypeError:
        pass
    # It has all our properties so that the unit tests work
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    AnsibleCollectionConfig.collection_finder = 1
    assert AnsibleCollectionConfig.collection_finder == 1
    AnsibleCollectionConfig.default_collection = 'foo'
    assert AnsibleCollectionConfig.default_collection == 'foo'

# Generated at 2022-06-21 08:03:12.310353
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fired = []
    my_event = _EventSource()

    def handler_that_raises(x):
        raise Exception('foo')

    def handler1(x):
        fired.append('handler1')

    def handler2(x):
        fired.append('handler2')

    def handler3(x):
        fired.append('handler3')
        raise Exception('bar')

    def handler4(x):
        fired.append('handler4')
        raise Exception('bar')

    # handler that raises should not cause a problem
    my_event += handler_that_raises
    my_event.fire(True)

    # add a handler that does not raise, verify result
    my_event += handler1
    my_event.fire(True)
    assert fired == ['handler1']

    # add a second handler that does not raise

# Generated at 2022-06-21 08:03:14.147014
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda *args, **kwargs: None
    assert len(e._handlers) == 1

# Generated at 2022-06-21 08:03:21.803433
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.fired_count = 0

        def on_event(self, *args, **kwargs):
            self.fired_count += 1

    es = TestEventSource()
    es.fire()
    assert es.fired_count == 0

    es += es.on_event
    es.fire()
    assert es.fired_count == 1

    es += es.on_event
    es.fire()
    assert es.fired_count == 3

    es -= es.on_event
    es.fire()
    assert es.fired_count == 4

# Generated at 2022-06-21 08:03:29.653582
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    outer = []
    def append(value):
        outer.append(value)

    event_source = _EventSource()

    event_source += append

    event_source.fire(1)
    event_source.fire(2)
    event_source.fire(3)

    assert outer == [1, 2, 3]

    # we are only implementing what's needed to support AnsibleCollectionFinder
    # no need to unit test invalid handlers, exceptions and stuff we don't use
    assert True


# Generated at 2022-06-21 08:03:32.427035
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    o = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert isinstance(o._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:03:34.296999
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler

# Generated at 2022-06-21 08:03:46.847477
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler_a = object()
    handler_b = object()
    event_source += handler_a
    event_source += handler_b
    event_source -= handler_a
    l = list(event_source._handlers)
    assert len(l) == 1
    assert l[0] == handler_b


# Generated at 2022-06-21 08:03:57.589518
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    '''
    _EventSource._on_exception(handler, exc, *args, **kwargs)
    '''

    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception = exc
            return False

    s = MyEventSource()
    test_exception = RuntimeError('test exception')
    s -= lambda: None
    assert len(s._handlers) == 0


# Generated at 2022-06-21 08:04:04.594876
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def add(a, b):
        return a + b

    def bad_add(a, b):
        return a + b + 1

    def bad_add2(a, b):
        raise Exception('KABOOM!')

    events = _EventSource()

    events += add
    assert 1 == events.fire(1, 0)

    events += bad_add
    assert 2 == events.fire(1, 1)

    events += bad_add2
    try:
        events.fire(3, 3)
        assert False, 'event.fire should have raised an exception'
    except Exception:
        pass

# Generated at 2022-06-21 08:04:11.624462
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # attempt to instantiate a class that does not use metaclass _AnsibleCollectionConfig
    class __AnsibleCollectionConfig(object):
        pass

    # constructor of _AnsibleCollectionConfig raises exception on attempt to instatiate a class that does not use metaclass _AnsibleCollectionConfig
    try:
        __AnsibleCollectionConfig()
        assert False, 'Expected exception because __AnsibleCollectionConfig class does not use metaclass _AnsibleCollectionConfig'
    except TypeError:
        pass

    # assert that AnsibleCollectionConfig class uses metaclass _AnsibleCollectionConfig
    assert issubclass(AnsibleCollectionConfig, object), 'Expected issubclass(AnsibleCollectionConfig, object) to evalute to True'

# Generated at 2022-06-21 08:04:18.971528
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test setup
    result = []

    # test execution
    event_source = _EventSource()
    event_source += lambda *a, **k: result.append(1)
    event_source += lambda *a, **k: result.append(2)
    event_source += lambda *a, **k: result.append(3)
    event_source.fire()

    # test validation
    assert result == [1, 2, 3]



# Generated at 2022-06-21 08:04:25.768313
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ev = _EventSource()
    ev += lambda: None
    ev += lambda: False
    ev += lambda: None

    with open(__file__, 'r') as f:
        ev += f.read    # type: ignore

    f_ev = ev # save function handle

    ev -= f.read   # type: ignore

    ev += lambda: 1/0

    f_ev.fire()
    f_ev.fire()
    f_ev.fire()

# Generated at 2022-06-21 08:04:28.071364
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

# Generated at 2022-06-21 08:04:30.108499
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()

    assert event_source._handlers == set()



# Generated at 2022-06-21 08:04:36.281311
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert len(AnsibleCollectionConfig.on_collection_load._handlers) == 0
    assert AnsibleCollectionConfig.playbook_paths == []

# Generated at 2022-06-21 08:04:39.097947
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    AnsibleCollectionConfig._collection_finder = None
    AnsibleCollectionConfig._default_collection = None
    AnsibleCollectionConfig._on_collection_load = _EventSource()

# Generated at 2022-06-21 08:04:56.647256
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = _AnsibleCollectionConfig('meta', 'name', 'bases')
    c.on_collection_load = c._on_collection_load
    return c

# Generated at 2022-06-21 08:05:08.437150
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventHandler:
        def __init__(self):
            self.invoked = False

        def __call__(self, *args, **kwargs):
            self.invoked = True

    source = _EventSource()
    assert not source._handlers

    handler1 = EventHandler()
    source += handler1
    assert handler1 in source._handlers

    handler2 = EventHandler()
    source += handler2
    assert handler2 in source._handlers
    assert len(source._handlers) == 2

    # the function should raise an exception if the handler is not callable
    try:
        source += lambda: None  # pylint: disable=unnecessary-lambda
    except ValueError as ex:
        assert str(ex) == 'handler must be callable'

# Generated at 2022-06-21 08:05:10.594348
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:05:14.937669
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:05:18.985849
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:05:24.583119
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def handlerA(event):
        pass

    def handlerB(event):
        pass

    event += handlerA
    event += handlerB
    assert handlerA in event._handlers
    assert handlerB in event._handlers

    event -= handlerA

    assert handlerA not in event._handlers
    assert handlerB in event._handlers

    event -= handlerA



# Generated at 2022-06-21 08:05:27.519932
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    f = lambda: None
    es += f
    assert f in es._handlers


# Generated at 2022-06-21 08:05:34.669489
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import unittest2 as unittest
    import ansible.module_utils.common.collections.ansible_collections as ac

    class _TestAnsibleCollectionConfig(unittest.TestCase):
        def test__init__(self):
            self.assertIsNone(ac.AnsibleCollectionConfig.collection_finder)
            self.assertIsNone(ac.AnsibleCollectionConfig.default_collection)
            self.assertIsNotNone(ac.AnsibleCollectionConfig.on_collection_load)

    _TestAnsibleCollectionConfig().test__init__()


# Generated at 2022-06-21 08:05:45.627225
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible.module_utils._text import to_text
    event_source = _EventSource()
    event_source.__dict__.update(
        _handlers={
            'h1',
            'h2',
        },
    )

    # call __isub__ with non-callable handler
    result = event_source.__isub__(None)
    assert result._handlers == {'h1', 'h2'}

    # call __isub__ with non-registered callable handler
    result = event_source.__isub__(lambda: None)
    assert result._handlers == {'h1', 'h2'}

    # call __isub__ with registered callable handler
    result = event_source.__isub__('h1')

# Generated at 2022-06-21 08:05:48.479034
# Unit test for constructor of class _EventSource
def test__EventSource():
    try:
        assert _EventSource()
    except Exception:
        assert False, '_EventSource has no __init__ method or fails'


# Generated at 2022-06-21 08:06:24.797883
# Unit test for constructor of class _EventSource
def test__EventSource():

    def handler1(self, *args, **kwargs):
        print("Event Source Handler 1")

    def handler2(self, *args, **kwargs):
        print("Event Source Handler 2")

    event_source = _EventSource()

    event_source += handler1
    event_source += handler2

    event_source.fire()

    event_source -= handler1

    event_source.fire()

    # Noop on non-existent handler
    event_source -= handler1

    event_source.fire()

# Generated at 2022-06-21 08:06:25.630558
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc = AnsibleCollectionConfig()
    assert acc is not None


# Generated at 2022-06-21 08:06:26.693729
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _TestCollectionConfig(_AnsibleCollectionConfig):
        pass

    assert isinstance(_TestCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:06:31.691086
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(a_test):
        print("test")

    evt = _EventSource()
    # The below line should not raise an exception.
    evt += handler
    # The below line should raise a ValueError exception
    invalid = "NonClass"
    evt += invalid



# Generated at 2022-06-21 08:06:38.121845
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Create mock EventSource
    event_source = _EventSource()
    event_source._handlers = set()

    # Create mock handler
    mock_handler = lambda: None
    event_source._handlers.add(mock_handler)

    # Call method under test
    event_source.__isub__(mock_handler)

    # Check _handlers is empty after removing mock handler
    assert len(event_source._handlers) == 0

    # Remove mock handler again and check _handlers is still empty after second remove
    event_source.__isub__(mock_handler)
    assert len(event_source._handlers) == 0



# Generated at 2022-06-21 08:06:49.868965
# Unit test for constructor of class _EventSource
def test__EventSource():
    import pytest
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils._text import to_bytes

    class TestClass:
        def __init__(self):
            self.log = []

        def method(self, args, kwargs):
            self.log.append((args, kwargs))

    source = _EventSource()
    test = TestClass()

    source += test.method

    source.fire(1, k=2)

    assert source._handlers == set([test.method])
    assert test.log == [(tuple([1]), {'kwargs': {'k': 2}})]

    source.fire(2, 3)

    assert len(source._handlers) == 1

# Generated at 2022-06-21 08:06:58.692935
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyLoopIntoHandlers(Exception):
        pass

    def _raise_if_handler_num_is_7(handler_number):
        if handler_number == 7:
            raise MyLoopIntoHandlers()

    def _raise_if_handler_num_is_3(handler_number):
        if handler_number == 3:
            raise RuntimeError()

    def _raise_if_handler_num_is_5(handler_number):
        if handler_number == 5:
            raise ValueError()

    def _loop_into_handlers(handler_number):
        if handler_number == 5:
            # handler_number 5 should be skipped
            raise MyLoopIntoHandlers()
        _raise_if_handler_num_is_7(handler_number)


# Generated at 2022-06-21 08:06:59.863465
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()



# Generated at 2022-06-21 08:07:02.494257
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c._collection_finder is None
    assert c._default_collection is None



# Generated at 2022-06-21 08:07:10.388301
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _DummyEventSource:
        def __init__(self):
            self._handlers = set()
    event_source = _EventSource()
    assert '_on_exception' in dir(event_source)
    assert '_handlers' in dir(event_source)
    assert 'fire' in dir(event_source)
    assert '__iadd__' in dir(event_source)
    assert '__isub__' in dir(event_source)
    def handler():
        pass
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-21 08:07:45.335937
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None


if __name__ == '__main__':
    test_AnsibleCollectionConfig()

# Generated at 2022-06-21 08:07:52.230879
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import unittest

    class _EventSource_Test(unittest.TestCase):
        def _subscriber_func(self, *args, **kwargs):
            pass

        def setUp(self):
            self._event_source = _EventSource()
            self._subscriber = self._subscriber_func

        def test___isub___when_subscribed(self):
            # arrange
            self.assertFalse(self._subscriber in self._event_source._handlers)
            self._event_source += self._subscriber

            # act
            result = self._event_source.__isub__(self._subscriber)

            # assert
            self.assertIs(result, self._event_source)
            self.assertFalse(self._subscriber in self._event_source._handlers)



# Generated at 2022-06-21 08:07:58.084900
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def handler(arg, kwarg='value'):
        return arg, kwarg

    # Non-callable handler
    try:
        event += None
    except ValueError:
        pass
    else:
        assert False, 'ValueError was not raised when adding a non-callable handler'

    # Callable handler
    event += handler
    assert handler in event._handlers

    # Duplicate handler
    event += handler
    assert len(event._handlers) == 1


# Generated at 2022-06-21 08:08:00.542374
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    event_source += lambda: None
    event_source -= lambda: None
    event_source -= lambda: None

# Generated at 2022-06-21 08:08:02.287935
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert isinstance(_EventSource(), _EventSource)



# Generated at 2022-06-21 08:08:09.301097
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    event_source += lambda: print('event_handler_1')
    event_source += lambda: print('event_handler_2')

    assert len(event_source._handlers) == 2

    event_source -= lambda: print('event_handler_1')

    assert len(event_source._handlers) == 1

    event_source -= lambda: print('event_handler_3')

    assert len(event_source._handlers) == 1



# Generated at 2022-06-21 08:08:15.045489
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    assert len(es._handlers) == 0

    h1 = lambda *args, **kwargs: None
    h2 = lambda *args, **kwargs: None

    es += h1
    es += h2

    assert len(es._handlers) == 2
    assert h1 in es._handlers
    assert h2 in es._handlers


# Generated at 2022-06-21 08:08:20.057026
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def func(event_source, event_args, event_kwargs):
        pass

    event_source = _EventSource()
    event_source += func
    event_source.fire('event_args', 'event_kwargs')



# Generated at 2022-06-21 08:08:26.180254
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # CAUTION: The implementation of this method must be kept identical to:
    #          test/lib/ansible_test/_util/target/legacy_collection_loader/test__EventSource___isub__

    def handler(x):
        pass

    e = _EventSource()
    e += handler
    e += handler

    assert len(e._handlers) == 1

    e -= handler

    assert len(e._handlers) == 0


# Generated at 2022-06-21 08:08:30.210752
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig

    assert ac.collection_finder is None
    assert ac.default_collection is None
    assert len(ac.playbook_paths) == 0
    assert len(ac.collection_paths) == 0
    assert isinstance(ac.on_collection_load, _EventSource)

# Generated at 2022-06-21 08:09:33.718569
# Unit test for constructor of class _EventSource
def test__EventSource():
    obj = _EventSource()
    assert obj._handlers == set()


# Generated at 2022-06-21 08:09:39.887800
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    def handler():
        pass

    source -= handler
    assert not source._handlers

    source += handler
    source -= handler
    assert not source._handlers

    source += handler
    source += handler
    source -= handler
    assert len(source._handlers) == 1

    source -= handler
    assert not source._handlers



# Generated at 2022-06-21 08:09:44.802956
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    obj = _EventSource()

    # __isub__ expects 1 argument
    with pytest.raises(TypeError):
        obj.__isub__()

    obj += lambda: None
    obj -= lambda: None

    # __isub__ doesn't raise an exception when the handler is not in the set
    # because we want to be able to remove handlers multiple times
    obj -= lambda: None


# Generated at 2022-06-21 08:09:47.152392
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def foo(arg1, arg2):
        pass
    es = _EventSource()
    es += foo
    assert foo in es._handlers
    es -= foo
    assert foo not in es._handlers



# Generated at 2022-06-21 08:09:48.776488
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert not es._handlers

# Unit test to add handler to class _EventSource

# Generated at 2022-06-21 08:09:58.081798
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ES = _EventSource()
    assert len(ES._handlers) == 0
    assert callable(ES)

    # verify non-callable handler raises ValueError
    try:
        ES += 42
        assert False
    except ValueError:
        pass

    # verify handler can be added
    handler = lambda: None
    ES += handler
    assert handler in ES._handlers

    try:
        ES.fire(1, 2, 3)
    except ValueError:
        assert False

    def on_exception(handler, exc, *args, **kwargs):
        # if we return True, we want the caller to re-raise
        raise ValueError('this method should not have been invoked')

    ES._on_exception = on_exception


# Generated at 2022-06-21 08:10:00.729460
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += 1
    with pytest.raises(ValueError):
        es += {}
    with pytest.raises(ValueError):
        es += "invalid value"



# Generated at 2022-06-21 08:10:02.101384
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert hasattr(_EventSource(), '_handlers')


# Generated at 2022-06-21 08:10:05.052277
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def _handle_event(arg):
        if arg != 'the-event':
            raise ValueError('arg is not the-event')

    event_source = _EventSource()
    event_source += _handle_event

    event_source.fire('the-event')

# Generated at 2022-06-21 08:10:13.607476
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest(object):
        def __init__(self):
            self.called = False

        def handler(self, *args, **kwargs):
            self.called = True

    def handler(a, b):
        return a + b

    es = _EventSource()
    es += handler

    assert not es._handlers
    assert False == es.fire('a', 'b')

    es += EventSourceTest().handler
    assert False == es.fire('a', 'b')
    assert True == es._handlers
    assert es._on_exception

    es -= handler
    assert es._handlers

    # Unit test for property collection_finder of class AnsibleCollectionConfig
    def test_property_collection_finder():
        acc = AnsibleCollectionConfig()

        assert None is acc.collection_finder
        assert hasattr