

# Generated at 2022-06-21 08:01:23.623447
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    aconfig = AnsibleCollectionConfig()


# Generated at 2022-06-21 08:01:25.203327
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)



# Generated at 2022-06-21 08:01:31.820256
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    event_source = _EventSource()

    # test with two callable handlers
    event_source += handler1
    event_source += handler2
    assert len(event_source._handlers) == 2

    # test with non-callable handler
    try:
        event_source += 'hello'
        assert False, 'ValueError not raised'
    except ValueError:
        pass



# Generated at 2022-06-21 08:01:40.832378
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler1(val):
        print('In handler1: {}'.format(val))

    def handler2(val):
        print('In handler2: {}'.format(val))

    def handler3(val):
        print('In handler3: {}'.format(val))

    es = _EventSource()
    es += handler1
    es += handler2
    es -= handler1
    es -= handler1
    assert len(es._handlers) == 1

    es += handler2
    es += handler3
    assert len(es._handlers) == 3



# Generated at 2022-06-21 08:01:45.146214
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig(None, "Test", None)
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert isinstance(cls._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:01:54.984762
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def handler1(x):
        pass
    
    def handler2(x):
        pass

    def handler3(x):
        pass

    event += handler1
    event += handler2
    event += handler3
    assert len(event._handlers) == 3

    event -= handler1
    assert len(event._handlers) == 2, 'handler1 should be deleted'
    assert handler2 in event._handlers
    assert handler3 in event._handlers

    event -= handler2
    assert len(event._handlers) == 1, 'handler2 should be deleted'
    assert handler3 in event._handlers

    event -= handler3
    assert len(event._handlers) == 0, 'handler3 should be deleted'


# Generated at 2022-06-21 08:02:02.557007
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class ExecuteEvent:
        def __init__(self):
            self._event_fired = False

        def _execute(self, *args, **kwargs):
            self._event_fired = True

        @property
        def event_fired(self):
            return self._event_fired

    ee = ExecuteEvent()
    es = _EventSource()
    es += ee._execute

    assert ee.event_fired is False
    es.fire()
    assert ee.event_fired is True

# Generated at 2022-06-21 08:02:07.015692
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    x = AnsibleCollectionConfig()
    assert x.default_collection is None
    x.default_collection = 'my.collection'
    assert x.default_collection == 'my.collection'


if __name__ == '__main__':
    test_AnsibleCollectionConfig()

# Generated at 2022-06-21 08:02:16.942209
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    e = Exception('fail')

    def test1():
        pass

    def test2():
        raise e

    def test3():
        raise RuntimeError('fail')

    event.fire()

    event += test1
    event.fire()

    event += test2

    did_raise = False

    try:
        event.fire()
    except Exception:
        did_raise = True

    assert did_raise
    assert e.args == ('fail',)

    event -= test2

    event += test2
    event += test3

    did_raise = False

    try:
        event.fire()
    except Exception:
        did_raise = True

    assert did_raise
    assert e.args == ('fail',)


# Generated at 2022-06-21 08:02:29.738022
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Event:
        pass

    my_event_source = _EventSource()
    my_event_source.on_event = Event()
    event_handler_call_count = 0

    def event_handler(event):
        nonlocal event_handler_call_count
        event_handler_call_count += 1
        if event_handler_call_count == 2:
            raise RuntimeError

    my_event_source.on_event += event_handler
    my_event_source.on_event += event_handler

    # no exception raised
    my_event_source.fire(my_event_source.on_event)

    # exception raised because event handler fails

# Generated at 2022-06-21 08:02:38.168242
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc = AnsibleCollectionConfig()
    assert not hasattr(acc, '_collection_finder')
    assert not hasattr(acc, '_default_collection')
    assert not hasattr(acc, '_on_collection_load')



# Generated at 2022-06-21 08:02:45.566781
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig.collection_finder = 'foo'
    assert AnsibleCollectionConfig.collection_finder == 'foo'

    AnsibleCollectionConfig.default_collection = 'bar'
    assert AnsibleCollectionConfig.default_collection == 'bar'

    AnsibleCollectionConfig.on_collection_load += 'baz'
    assert AnsibleCollectionConfig.on_collection_load


# This is the specific config object that's used by code that is generic to Python 2 and Python 3.
ansible_collection_config = AnsibleCollectionConfig()

# Generated at 2022-06-21 08:02:48.303552
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig()
    except TypeError:
        pass


collection_config = AnsibleCollectionConfig()

# Generated at 2022-06-21 08:02:59.919914
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _AnsibleCollectionConfigTest(_AnsibleCollectionConfig):
        pass

    # class assert
    ansible_collection_config_class = AnsibleCollectionConfig

    assert isinstance(ansible_collection_config_class().collection_finder, property)
    assert isinstance(ansible_collection_config_class().collection_paths, property)
    assert isinstance(ansible_collection_config_class().default_collection, property)
    assert isinstance(ansible_collection_config_class().on_collection_load, property)
    assert isinstance(ansible_collection_config_class().playbook_paths, property)

    # type assert
    type_assert = _AnsibleCollectionConfigTest()

    assert isinstance(type_assert._collection_finder, type(None))

# Generated at 2022-06-21 08:03:06.289638
# Unit test for constructor of class _EventSource
def test__EventSource():
    # test constructor
    x = _EventSource()
    y = _EventSource()

    # test __iadd__
    x += y
    x += y

    # test __isub__
    x -= y
    x -= y
    x -= y
    x -= y

    # test _on_exception
    x._on_exception(None, None)


# Generated at 2022-06-21 08:03:10.897627
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # define a simple function for testing
    def func():
        pass

    # initialize our event source
    event_source = _EventSource()

    # assign the function to the event source
    event_source += func

    # assert that the function has been added
    assert func in event_source._handlers



# Generated at 2022-06-21 08:03:14.297180
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config._collection_finder is None
    assert config._on_collection_load._handlers == set()
    assert config.collection_finder is None
    assert config.on_collection_load is config._on_collection_load

# Generated at 2022-06-21 08:03:19.235446
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c):
        global called1
        called1 = [a, b, c]

    def handler2(a, b, c):
        global called2
        called2 = [a, b, c]

    called1 = called2 = None
    src = _EventSource()
    src += handler1
    src += handler2
    src.fire(1, 2, c=3)
    assert called1 == [1, 2, 3]
    assert called2 == [1, 2, 3]



# Generated at 2022-06-21 08:03:28.243791
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.playbook_paths == []
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollectionConfig._on_collection_load

# Generated at 2022-06-21 08:03:39.116594
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():

    class TestAnsibleCollectionConfig(AnsibleCollectionConfig):
        pass

    assert isinstance(TestAnsibleCollectionConfig.collection_finder, property)
    assert isinstance(TestAnsibleCollectionConfig.collection_paths, property)
    assert isinstance(TestAnsibleCollectionConfig.default_collection, property)
    assert isinstance(TestAnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(TestAnsibleCollectionConfig.playbook_paths, property)

    try:
        TestAnsibleCollectionConfig.collection_finder = 'Foo'
    except ValueError:
        pass
    else:
        assert False, 'Failed to raise ValueError when collection_finder was already configured'


# Generated at 2022-06-21 08:03:46.751042
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ans_collection_config = AnsibleCollectionConfig()
    handler = lambda *args, **kwargs: print('Dummy event fired!')
    ans_collection_config.on_collection_load += handler
    ans_collection_config.on_collection_load.fire()


# Generated at 2022-06-21 08:03:47.777741
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()

# Generated at 2022-06-21 08:03:52.663703
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()

    @e.on_collection_load
    def fire_handler(value):
        raise ValueError('test exception')

    try:
        e.fire('test')
        raise AssertionError('expected exception')
    except ValueError as ex:
        assert str(ex) == 'test exception'



# Generated at 2022-06-21 08:03:55.082262
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)

# Generated at 2022-06-21 08:03:59.535151
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    assert not event_source._handlers

    def handler():
        pass

    event_source -= handler
    assert not event_source._handlers

    event_source += handler
    assert handler in event_source._handlers
    event_source -= handler
    assert not event_source._handlers

# Generated at 2022-06-21 08:04:02.209418
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    event_source += lambda *args, **kwargs: None
    event_source -= lambda *args, **kwargs: None
    assert not event_source._handlers



# Generated at 2022-06-21 08:04:10.272010
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Scenario: Handler given to the class constructor raises an exception
    # Expected result: The exception is re-raised
    class MyException(Exception):
        pass
    def on_collection_load(collection_name, collection_config):
        raise MyException

    collection_config = AnsibleCollectionConfig()
    collection_config.on_collection_load += on_collection_load
    try:
        collection_config.on_collection_load.fire('collection_name', 'collection_config')
        assert False
    except MyException:
        assert True

    # Scenario: Handler given to the class constructor raises an exception
    # Expected result: No exception is re-raised
    def on_collection_load(collection_name, collection_config):
        raise RuntimeError

    collection_config = AnsibleCollectionConfig()
    collection_config.on_collection

# Generated at 2022-06-21 08:04:12.379876
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()
    source.fire()  # no exceptions

# Generated at 2022-06-21 08:04:16.764462
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c._collection_finder is None
    assert not c.collection_paths
    assert not c.playbook_paths
    assert not c._handlers
    assert c._on_collection_load is c.on_collection_load



# Generated at 2022-06-21 08:04:25.274500
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    from ansible.module_utils._text import to_bytes

    obj = _EventSource()
    assert list(obj._handlers) == []

    def handler_one():
        pass
    obj += handler_one
    assert list(obj._handlers) == [handler_one]

    def handler_two():
        pass
    obj += handler_two
    assert set(obj._handlers) == {handler_one, handler_two}

    obj -= handler_one
    assert set(obj._handlers) == {handler_two}



# Generated at 2022-06-21 08:04:32.878955
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    source += (lambda x: None)

    try:
        source.fire()
    except ValueError as e:
        assert False, "test__EventSource_fire failed with exception: {0}".format(e)

# Generated at 2022-06-21 08:04:36.469650
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert config._on_collection_load._handlers == set()



# Generated at 2022-06-21 08:04:39.485012
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def func():
        pass

    event += func
    event += func

    assert func in event._handlers
    assert len(event._handlers) == 1



# Generated at 2022-06-21 08:04:48.365704
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_a(*args, **kwargs):
        print("handler_a", args, kwargs)

    def handler_b(*args, **kwargs):
        print("handler_b", args, kwargs)

    def handler_c(*args, **kwargs):
        print("handler_c", args, kwargs)

    events = _EventSource()

    events += handler_a
    events += handler_b
    events += handler_c

    events.fire(1, 2, 3)

    events -= handler_b

    events.fire(x=1, y=2, z=3)

# Generated at 2022-06-21 08:04:49.173276
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source += lambda: True
    assert isinstance(source, _EventSource)

# Generated at 2022-06-21 08:04:54.921767
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler1(*args, **kwargs):
        pass

    def handler2(args):
        pass

    def handler3(var1, var2, kvar1=None, kvar2=None):
        pass

    es = _EventSource()
    assert len(es._handlers) == 0

    es += handler1
    assert len(es._handlers) == 1
    es += handler1
    assert len(es._handlers) == 1

    es += handler2
    assert len(es._handlers) == 2
    es += handler2
    assert len(es._handlers) == 2

    es += handler3
    assert len(es._handlers) == 3
    es += handler3
    assert len(es._handlers) == 3


# Generated at 2022-06-21 08:04:57.327468
# Unit test for constructor of class _EventSource
def test__EventSource():
    source = _EventSource()

    # access the event source to load the initial value
    source.fire()



# Generated at 2022-06-21 08:04:58.392725
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert True


# Generated at 2022-06-21 08:05:01.553188
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def handler(evt):
        return evt

    es += handler

    es -= handler



# Generated at 2022-06-21 08:05:06.009583
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    assert not es._handlers
    es -= 1
    assert not es._handlers
    def a():
        pass
    es += a
    assert es._handlers
    es -= a
    assert not es._handlers


# Generated at 2022-06-21 08:05:19.908253
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # constructor test
    '''
    print("AnsibleCollectionConfig.__doc__:", AnsibleCollectionConfig.__doc__)
    print("AnsibleCollectionConfig.__name__:", AnsibleCollectionConfig.__name__)
    print("AnsibleCollectionConfig.__module__:", AnsibleCollectionConfig.__module__)
    print("AnsibleCollectionConfig.__bases__:", AnsibleCollectionConfig.__bases__)
    print("AnsibleCollectionConfig.__dict__:", AnsibleCollectionConfig.__dict__)
    '''
    pass

# Generated at 2022-06-21 08:05:25.535515
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def listener_that_raises(msg):
        raise RuntimeError(msg)

    listener_called = False
    def listener_that_sets_flag(msg):
        global listener_called
        listener_called = True

    event = _EventSource()
    event += listener_that_sets_flag
    event += listener_that_raises

    listener_called = False
    event.fire("foo")
    assert listener_called



# Generated at 2022-06-21 08:05:29.856057
# Unit test for constructor of class _EventSource
def test__EventSource():
    h = lambda *a, **kw: None  # pylint: disable=unused-argument
    es = _EventSource()
    es += h

    assert h in es._handlers
    assert len(es._handlers) == 1

# Generated at 2022-06-21 08:05:37.740549
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = _AnsibleCollectionConfig('meta', 'str', ())

    # collection_finder, default_collection and on_collection_load are initialized to None/empty
    assert c._collection_finder is None
    assert c._default_collection is None
    assert len(c._on_collection_load._handlers) == 0

    # cannot overwrite collection_finder, default_collection and on_collection_load
    with pytest.raises(ValueError):
        c._collection_finder = 1
    with pytest.raises(ValueError):
        c._default_collection = 1
    with pytest.raises(ValueError):
        c._on_collection_load = 2

    # on_collection_load property can only be changed using +=, not =
    handler = lambda: print()
    c._on_collection_load += handler

# Generated at 2022-06-21 08:05:43.500324
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)

# Generated at 2022-06-21 08:05:49.389064
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _SubclassOfAnsibleCollectionConfig(AnsibleCollectionConfig):
        pass
    _subclass = _SubclassOfAnsibleCollectionConfig()
    assert _subclass.collection_finder is None
    assert _subclass.default_collection is None
    assert isinstance(_subclass.on_collection_load, _EventSource)



# Generated at 2022-06-21 08:06:01.019920
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSourceTest:
        def __init__(self):
            self._handlers = set()
            self.on_add = _EventSource()

        def __iadd__(self, handler):
            self.on_add += handler
            return self

        def __isub__(self, handler):
            self.on_add -= handler
            return self

    e = EventSourceTest()

    def handler_a():
        pass

    def handler_b():
        pass

    e += handler_a

    assert handler_a in e.on_add._handlers
    assert handler_b not in e.on_add._handlers

    e += handler_a

    assert handler_a in e.on_add._handlers
    assert handler_b not in e.on_add._handlers

    e += handler_b

   

# Generated at 2022-06-21 08:06:02.940433
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Constructor should not raise an error
    event_source = _EventSource()



# Generated at 2022-06-21 08:06:05.065506
# Unit test for constructor of class _EventSource
def test__EventSource():
    b = _EventSource()

    assert id(b._handlers) is not None


# Generated at 2022-06-21 08:06:08.044573
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    handler = lambda event: None
    es = _EventSource()
    es += handler
    assert len(es._handlers) == 1
    es -= handler
    assert len(es._handlers) == 0

# Generated at 2022-06-21 08:06:27.827025
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    class MyEventSource(_EventSource):
        def __init__(self, handlers=None):
            super(MyEventSource, self).__init__()
            if handlers is not None:
                for handler in handlers:
                    self += handler

    def first():
        pass

    def second():
        pass

    def third():
        pass

    def fourth():
        pass

    source = MyEventSource([first, second, third, fourth])

    source -= first
    assert source._handlers == {second, third, fourth}

    source -= first
    assert source._handlers == {second, third, fourth}

    source -= second
    assert source._handlers == {third, fourth}

    source -= fourth
    assert source._handlers == {third}

    source -= third
    source -= third
    assert source._handlers == set()



# Generated at 2022-06-21 08:06:35.484439
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # 1) An event handler cannot be removed if it is not listed.
    et = _EventSource()
    handler = lambda: print('hello')
    et -= handler

    # 2) An event handler cannot be removed if it is not callable.
    et = _EventSource()
    handler = 1
    try:
        et -= handler
        assert False, 'Removed event handler which is not callable.'
    except ValueError:
        pass

    # 3) An event handler can be removed.
    et = _EventSource()
    handler = lambda: print('hello')
    et += handler
    et -= handler


# Generated at 2022-06-21 08:06:47.583359
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Handler:
        def __init__(self, result):
            self.result = result

        def __call__(self, *args):
            self.result.append(args)

    e = _EventSource()

    r1 = []
    r2 = []
    r3 = []

    h1 = Handler(r1)
    h2 = Handler(r2)
    h3 = Handler(r3)

    e += h1
    e += h2
    e += h2

    e -= h2
    e -= object()
    e += h3
    e -= object()

    e.fire(1, 2, 3)

    assert r1 == [(1, 2, 3)]
    assert r2 == []
    assert r3 == [(1, 2, 3)]



# Generated at 2022-06-21 08:06:50.464555
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    event_source -= handler

    assert handler not in event_source._handlers

# Generated at 2022-06-21 08:06:54.338058
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


# unit test for metaclass methods

# Generated at 2022-06-21 08:06:59.013043
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = _AnsibleCollectionConfig('meta', 'name', 'bases')

    assert c._collection_finder is None
    assert c._default_collection is None
    assert isinstance(c._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:07:03.070257
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Given
    es = _EventSource()

    def handler_1():
        pass

    def handler_2():
        pass

    # When
    es += handler_1

    # Then
    assert handler_1 in es._handlers


# Generated at 2022-06-21 08:07:05.643591
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, '__init__')

# test AnsibleCollectionConfig.collection_finder property

# Generated at 2022-06-21 08:07:15.141184
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder
    from ansible.utils.collection_loader._collection_finder import FauxAnsibleCollectionFinder
    from ansible.utils.collection_loader._collection_resolver import AnsibleCollectionResolver

    finder = AnsibleCollectionFinder()
    resolver = AnsibleCollectionResolver(finder)

    config = AnsibleCollectionConfig()

    # 1) Test __iadd__ with bad handlers
    config.on_collection_load += 'bad'

    # 1) Test __iadd__ with good handlers
    config.on_collection_load += finder.set_playbook_paths
    config.on_collection_load += resolver.on_collection_load

    # 2) Test __isub__ with bad handlers

# Generated at 2022-06-21 08:07:21.480056
# Unit test for constructor of class _EventSource
def test__EventSource():

    def handler(arg, keyword=None):
        pass

    x = _EventSource()
    assert isinstance(x, _EventSource)
    assert isinstance(x.fire, _EventSource._EventSource_fire_type)

    x += 1
    assert x._handlers == set()
    x += handler
    assert x._handlers == {handler}
    x -= handler
    assert x._handlers == set()
    x -= 1
    assert x._handlers == set()


# Generated at 2022-06-21 08:07:39.922864
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange

    # Act
    ansible_collection_config = AnsibleCollectionConfig()

    # Assert
    assert isinstance(ansible_collection_config, AnsibleCollectionConfig)


# Generated at 2022-06-21 08:07:43.158238
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None


# the default collection
AnsibleCollectionConfig.default_collection = 'ansible.builtin'

# Generated at 2022-06-21 08:07:47.502131
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    h = lambda x: print("hello, {}".format(x))
    e += h
    assert h in e._handlers
    e -= h
    assert h not in e._handlers
    try:
        e += None
        assert False
    except ValueError:
        pass


# Generated at 2022-06-21 08:07:49.263344
# Unit test for constructor of class _EventSource
def test__EventSource():
    def func():
        pass

    es = _EventSource()
    es += func
    es -= func


# Generated at 2022-06-21 08:07:50.851849
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class TestAnsibleCollectionConfig(AnsibleCollectionConfig):
        pass

    tacc = TestAnsibleCollectionConfig()

# Generated at 2022-06-21 08:07:57.477403
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import ansible.utils.collection_loader._collection_finder  # pylint: disable=import-error

    class MyCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    # collection_finder
    assert MyCollectionConfig.collection_finder is None
    f = ansible.utils.collection_loader._collection_finder.AnsibleCollectionFinder()
    MyCollectionConfig.collection_finder = f
    assert MyCollectionConfig.collection_finder is f
    try:
        MyCollectionConfig.collection_finder = None
        assert False
    except ValueError:
        pass

    # default_collection
    assert MyCollectionConfig.default_collection is None
    MyCollectionConfig.default_collection = f
    assert MyCollectionConfig.default_collection is f
    MyCollectionConfig.default_collection = None
    assert MyCollectionConfig

# Generated at 2022-06-21 08:08:08.771480
# Unit test for constructor of class _EventSource
def test__EventSource():
    from ansible.utils.emitter import EventSource
    from ansible.utils.emitter import Event
    from ansible.utils.emitter import LoggingEventEmitter

    def test_func(_event, _emitter):
        return None

    event = Event(event_type='test', event_data='test', emitter=LoggingEventEmitter())
    emitter = LoggingEventEmitter()

    event_source = EventSource()
    event_source += test_func

    assert event_source._handlers == {test_func}
    assert callable(event_source._on_exception)

    event_source.fire(event, emitter)

    assert event_source._handlers == {test_func}

    event_source -= test_func

    assert event_source._handlers == set()
    assert event_source._

# Generated at 2022-06-21 08:08:10.279467
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert False, 'Test Not Implemented'

# Generated at 2022-06-21 08:08:13.093759
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, type(None))
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:08:14.341189
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-21 08:08:49.715006
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    evt = _EventSource()

    # TEST: Assert assignment of callable succeeds
    def my_callable():
        pass
    evt += my_callable

    # TEST: Assert assignment of non-callable fails
    try:
        evt += 'foo'
        assert False, "EventSource.__iadd__ should throw ValueError when called with a non-callable argument"
    except ValueError:
        pass



# Generated at 2022-06-21 08:09:00.278894
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    def dummy_callable():
        return None
    event_source += dummy_callable
    assert len(event_source._handlers) == 1
    event_source += dummy_callable  # add dummy_callable a second time
    assert len(event_source._handlers) == 1
    event_source += dummy_callable
    assert len(event_source._handlers) == 1
    def dummy_callable_other():
        return None
    event_source += dummy_callable_other
    assert len(event_source._handlers) == 2
    event_source -= dummy_callable
    assert len(event_source._handlers) == 1
    event_source -= dummy_callable  # remove dummy_callable a second time
    assert len(event_source._handlers)

# Generated at 2022-06-21 08:09:01.819355
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source._handlers == set()



# Generated at 2022-06-21 08:09:08.485475
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1(self, *args, **kwargs):
        print('handler1')

    def handler2(self, *args, **kwargs):
        print('handler2')

    es += handler1
    es += handler2
    assert handler1 in es._handlers
    assert handler2 in es._handlers
    assert len(es._handlers) == 2


# Generated at 2022-06-21 08:09:11.435936
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # noinspection PyUnusedLocal
    class Foo(_AnsibleCollectionConfig):
        pass



# Generated at 2022-06-21 08:09:16.897630
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Create a test event source
    e = _EventSource()

    # Create a test handler and add it to the event source
    test_handler = lambda *a, **kw: None
    e += test_handler

    # Test removing a handler which was added, but do not attempt to re-use the handler
    e -= test_handler
    assert id(test_handler) not in [id(h) for h in e._handlers]

# Generated at 2022-06-21 08:09:24.681425
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ansible_collection_config = AnsibleCollectionConfig()

    # assign a handler that increments a counter for each call
    counter = 0
    def handler1(*args, **kwargs):
        nonlocal counter
        counter += 1

    ansible_collection_config.on_collection_load += handler1

    # assign a handler that throws an exception
    def handler2(*args, **kwargs):
        raise RuntimeError()

    ansible_collection_config.on_collection_load += handler2

    # assign a handler that returns True and throws an exception
    def handler3(*args, **kwargs):
        raise RuntimeError()

    def on_exception(handler, exc, *args, **kwargs):
        nonlocal handler3
        return handler == handler3

    ansible_collection_config.on_collection_load._on_exception = on

# Generated at 2022-06-21 08:09:34.999474
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    count = [0, 0, 0]

    def handler1():
        count[1] += 1

    def handler2():
        count[2] += 1

    # create and install 2 handlers
    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    # test the handlers are called
    event_source.fire()
    assert count == [0, 1, 1]

    # remove a handler, test it's not called
    event_source -= handler1
    event_source.fire()
    assert count == [0, 1, 2]

    # remove a handler that hasn't been installed, test it's not called
    event_source -= handler1
    event_source.fire()
    assert count == [0, 1, 3]

    # add the handler back, test it's called
   

# Generated at 2022-06-21 08:09:42.368147
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import pytest
    from ansible.module_utils._text import to_bytes

    # _on_collection_load is initialized to an instance of _EventSource
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

    # _collection_finder is initialized to None
    assert AnsibleCollectionConfig._collection_finder is None

    # _default_collection is initialized to None
    assert AnsibleCollectionConfig._default_collection is None


# Unit tests for property on_collection_load

# Generated at 2022-06-21 08:09:43.581999
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert _EventSource().fire() is None



# Generated at 2022-06-21 08:10:57.531579
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # verify that the method returns self
    source = _EventSource()
    result = source.__iadd__(lambda: None)
    assert result is source



# Generated at 2022-06-21 08:10:59.444528
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_class = AnsibleCollectionConfig()
    assert test_class._on_exception("", "")

# Generated at 2022-06-21 08:11:00.870679
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig()  # __init__ not implemented

# Generated at 2022-06-21 08:11:02.891093
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    a = _AnsibleCollectionConfig('x', 'y', 'z')
    assert isinstance(a, _AnsibleCollectionConfig)

# Generated at 2022-06-21 08:11:05.432136
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def my_handler(*args, **kwargs):
        pass

    event += my_handler
    assert my_handler in event._handlers



# Generated at 2022-06-21 08:11:13.878214
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    # scenario 1
    def func():
        raise Exception()

    event_source = _EventSource()
    event_source += func
    with pytest.raises(Exception):
        event_source.fire()

    # scenario 2
    def func():
        return 1

    event_source = _EventSource()
    event_source += func
    event_source.fire()

    # scenario 3
    def func():
        return 1

    event_source = _EventSource()
    event_source += func
    with pytest.raises(TypeError):
        event_source += None



# Generated at 2022-06-21 08:11:17.114034
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)