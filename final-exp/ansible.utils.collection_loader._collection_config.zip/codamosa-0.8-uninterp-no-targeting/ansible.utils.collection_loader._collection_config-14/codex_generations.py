

# Generated at 2022-06-21 08:01:24.493461
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c.on_collection_load
    assert c.playbook_paths


# Generated at 2022-06-21 08:01:27.030974
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    tmp = _AnsibleCollectionConfig(None, 'Unused', None)
    assert tmp._collection_finder is None
    assert tmp._default_collection is None



# Generated at 2022-06-21 08:01:34.293884
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    """ansible.utils.collection_loader._EventSource.__isub__
    :param self:
    :param handler:
    """
    # https://github.com/ansible/ansible/blob/1f130d3dcc9e8c42b816fcb0a7ec473568d8c7b2/test/units/plugins/loader/test_collections_loader.py#L41-L45
    es = _EventSource()

    def handler(x):
        pass

    es += handler
    assert len(es._handlers) == 1
    es -= handler
    assert len(es._handlers) == 0



# Generated at 2022-06-21 08:01:36.772864
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert isinstance(e, _EventSource)


# Generated at 2022-06-21 08:01:41.471796
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    src = _EventSource()

    # assign the method handler
    src += lambda event: None

    # make sure it's been added by its name
    assert src._handlers.__contains__(__test__['test__EventSource___iadd__'].__closure__[0].cell_contents)

# Generated at 2022-06-21 08:01:48.867847
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj = _EventSource()

    # test that the handler is stored
    handler = lambda x: x * 2
    obj += handler
    assert handler in obj._handlers

    # test that the handler is not duplicated
    obj += handler
    assert len(obj._handlers) == 1

    # test that ValueError is raised when handler is not callable
    try:
        obj += 'not_callable'
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-21 08:01:50.445886
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es is not None



# Generated at 2022-06-21 08:01:55.793755
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_obj = _EventSource()
    assert len(test_obj._handlers) == 0

    def test_handler(things):
        return things

    test_obj += test_handler
    assert len(test_obj._handlers) == 1

    try:
        test_obj += 'not a real handler'
        assert False, 'expected ValueError to occur'
    except ValueError as e:
        assert "handler must be callable" in to_text(e)

    test_obj += None



# Generated at 2022-06-21 08:01:58.113126
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_source = _EventSource()
    assert test_source._on_exception is _EventSource._on_exception


# Generated at 2022-06-21 08:02:05.707019
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_test._util.target.legacy_collection_loader import _EventSource

    def handler():
        pass

    class Invalid:
        pass

    event = _EventSource()
    assert len(event._handlers) == 0

    event += handler
    assert len(event._handlers) == 1

    with pytest.raises(ValueError):
        event += Invalid()

    event += handler
    assert len(event._handlers) == 2


# Generated at 2022-06-21 08:02:10.881417
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    assert True

# Generated at 2022-06-21 08:02:18.098078
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    event_handler = lambda *args, **kwargs: None

    # Empty set
    event_source -= event_handler
    assert event_source._handlers == set()

    # Original set
    event_source._handlers = {event_handler}
    event_source -= event_handler
    assert event_source._handlers == set()

    # Differing set
    event_source._handlers = {lambda *args, **kwargs: None}
    event_source -= event_handler
    assert event_source._handlers == {lambda *args, **kwargs: None}



# Generated at 2022-06-21 08:02:22.423889
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    src = _EventSource()
    def p():
        pass
    src += p
    assert src._handlers == {p}
    src -= p
    assert src._handlers == set()


# Generated at 2022-06-21 08:02:23.451458
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource()


# Generated at 2022-06-21 08:02:27.680971
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def _handler():
        pass

    event_source = _EventSource()

    event_source += _handler
    assert len(event_source._handlers) == 1

    event_source -= _handler
    assert len(event_source._handlers) == 0


# Generated at 2022-06-21 08:02:35.643384
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create the test instance
    t = _EventSource()
    # Create a list to keep track of events
    l = []

    # Add a method that adds 'a' to the list when fired
    def handler1(*args, **kwargs):
        l.append('a')

    # Add a method that adds 'b' to the list when fired
    def handler2(*args, **kwargs):
        l.append('b')

    # Add two methods as event handlers
    t += handler1
    t += handler2

    # Fire the events
    t.fire()
    t.fire()

    # Check that the handlers are called in order
    assert l == ['a', 'b', 'a', 'b']

    # Remove the first handler
    t -= handler1

    # Fire the events again
    t.fire()

# Generated at 2022-06-21 08:02:38.935361
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._on_collection_load is not None
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

# Generated at 2022-06-21 08:02:43.763404
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert AnsibleCollectionConfig._on_collection_load._handlers == set()

# Generated at 2022-06-21 08:02:45.649176
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source += lambda: True
    assert len(source._handlers) == 1

# Generated at 2022-06-21 08:02:47.394872
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.on_collection_load is not None


# Generated at 2022-06-21 08:02:57.368205
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Setup
    test_event_source = _EventSource()
    expected_value = 'test return'
    def test_handler(val):
        return val
    # Exercise
    test_event_source += test_handler
    test_event_source.fire(expected_value)
    # Verify
    assert test_handler(expected_value)



# Generated at 2022-06-21 08:03:02.668940
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()
    # The handler must be callable
    try:
        x += 5
        assert False
    except ValueError:
        assert True

    # Did += really add the handler
    def my_handler():
        pass

    x += my_handler
    assert my_handler in x._handlers


# Generated at 2022-06-21 08:03:05.142876
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    t = _AnsibleCollectionConfig('foo', 'bar', 'baz')
    assert isinstance(t._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:03:12.363989
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible_collections.community.general.plugins.module_utils.ansible_collections_loader import AnsibleCollectionConfig

    assert AnsibleCollectionConfig._collection_finder is None

    config = AnsibleCollectionConfig()

    assert config.collection_finder is None
    assert config.collection_paths == []
    assert config.default_collection is None
    assert config.on_collection_load is config._on_collection_load
    assert config.playbook_paths == []


# Generated at 2022-06-21 08:03:18.110374
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()

    # value passed in must be callable
    with pytest.raises(ValueError):
        x += 1

    # add a handler
    def handler(x):
        pass
    assert len(x._handlers) == 0
    x += handler
    assert len(x._handlers) == 1
    assert list(x._handlers)[0] == handler

    # adding the same handler again should not raise an exception
    x += handler
    assert len(x._handlers) == 1
    assert list(x._handlers)[0] == handler


# Generated at 2022-06-21 08:03:24.990608
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    # invalid type
    try:
        event += object()
    except ValueError as ex:
        assert 'handler must be callable' in to_text(ex)
    else:
        assert False, 'non-callable handler should have raised ValueError'

    # actual handler
    def handler():
        pass

    event += handler
    assert len(event._handlers) == 1
    assert handler in event._handlers


# Generated at 2022-06-21 08:03:29.957112
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cfg = AnsibleCollectionConfig()

    assert isinstance(cfg._on_collection_load, _EventSource)
    assert cfg.collection_finder is None
    assert cfg.collection_paths is None
    assert cfg.default_collection is None
    assert cfg.playbook_paths is None

# Generated at 2022-06-21 08:03:37.480453
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    def handler2():
        raise RuntimeError()

    event = _EventSource()

    event += handler
    event += handler

    assert len(event._handlers) == 1
    assert event._handlers == set([handler])

    event += handler2

    assert len(event._handlers) == 2
    assert event._handlers == set([handler, handler2])

    event += object()
    assert len(event._handlers) == 2

    assert event.on_exception is event._on_exception


# Generated at 2022-06-21 08:03:43.561153
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    a = [1]
    def handler1(i):
        a[0] += i
    def handler2(i):
        a[0] *= i
    def handler3(i):
        raise Exception

    handlers = _EventSource()
    handlers += handler1
    handlers += handler2

    handlers.fire(1)
    assert a == [2]

    a[0] = 2
    handlers += handler3
    try:
        handlers.fire(1)
        assert False
    except:
        # we expect an exception
        pass

    # handler3 should not have been called
    assert a == [2]



# Generated at 2022-06-21 08:03:54.781110
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # function caller must call to stop test
    def _stop_test():
        raise StopIteration

    # event source being tested
    es = _EventSource()

    # add handler that calls _stop_test
    es += _stop_test

    # add handler that raises exception
    def _raise_exception():
        raise RuntimeError

    es += _raise_exception

    # add handler that returns True
    def _on_exception(handler, exc, *args, **kwargs):
        return True

    # event source being tested
    es._on_exception = _on_exception

    # add handler that raises exception
    def _raise_exception():
        raise RuntimeError

    es += _raise_exception

    # test throws StopIteration
    with pytest.raises(StopIteration):
        es.fire()

# Generated at 2022-06-21 08:04:04.767458
# Unit test for constructor of class _EventSource
def test__EventSource():
    pass


# Generated at 2022-06-21 08:04:11.701794
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        """Custom exception class for test__EventSource_fire"""

    def _handler1(*args, **kwargs):
        """Raise a custom exception"""
        raise TestException()

    def _handler2(*args, **kwargs):
        """Always return"""
        return

    def _handler3(*args, **kwargs):
        """Raise a generic exception"""
        raise Exception()

    _exception_source = _EventSource()

    _exception_source += _handler1
    _exception_source += _handler2
    _exception_source += _handler3

    try:
        _exception_source.fire()
    except TestException:
        pass
    else:
        # test of _handler1 failed.
        assert False


# Generated at 2022-06-21 08:04:13.943880
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None


# Generated at 2022-06-21 08:04:15.022762
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource


# Generated at 2022-06-21 08:04:20.855957
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MyClass(with_metaclass(_AnsibleCollectionConfig)):
        pass
    c = MyClass()
    assert c._collection_finder is None
    assert c._default_collection is None
    assert MyClass._collection_finder is None
    assert MyClass._default_collection is None
    assert isinstance(c._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:04:25.274544
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()

    assert ac.collection_finder is None
    assert ac.collection_paths is None
    assert ac.default_collection is None
    assert ac.playbook_paths is None

# Generated at 2022-06-21 08:04:27.396314
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def test_handler(*args, **kwargs):
        pass

    event_source += test_handler
    event_source -= test_handler

# Generated at 2022-06-21 08:04:38.904342
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # caller is a "mock" of a handler method
    # the function of the mock is to record the arguments it was called with
    called = []
    def caller(a, b, c=None, d=None):
        called.append((a, b, c, d))

    # "make" a new Mock instance that uses the caller to record its call arguments
    # the code under test will call the Mock by using call or "()" syntax
    mock = _EventSource()
    mock += caller

    # fire the mock with some arguments
    mock.fire(1, 2, 3, 4)

    # the value called is set by the caller, so we check called against the expected value
    assert called == [(1, 2, 3, 4)]


# Generated at 2022-06-21 08:04:43.896864
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # tests __init__()
    cls = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert cls.collection_finder is None
    assert cls.default_collection is None


# Generated at 2022-06-21 08:04:52.115976
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, property)
    assert isinstance(AnsibleCollectionConfig._default_collection, property)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, property)
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')

# Generated at 2022-06-21 08:05:15.189739
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():

    c = AnsibleCollectionConfig()

    assert c.collection_finder is None
    assert c.default_collection is None

    assert c._on_collection_load is c.on_collection_load
    assert c._on_collection_load is c.on_collection_load


# Generated at 2022-06-21 08:05:19.908089
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    try:
        class AnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
            pass
    except Exception as ex:
        assert False, 'failed to init class _AnsibleCollectionConfig because ' + str(ex)

# Generated at 2022-06-21 08:05:21.318622
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert e._handlers == set()
    assert e.fire() is None



# Generated at 2022-06-21 08:05:28.222153
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig._default_collection, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)


# Generated at 2022-06-21 08:05:36.902988
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # expected values
    args = ('arg1', 'arg2', 'arg3')
    kwargs = {'kw1': 'arg1', 'kw2': 'arg2', 'kw3': 'arg3'}

    # mock callables
    def mock_handler1(*args, **kwargs):
        mock_handler1.args = args
        mock_handler1.kwargs = kwargs

    def mock_handler2(*args, **kwargs):
        mock_handler2.args = args
        mock_handler2.kwargs = kwargs

    # call fire
    es = _EventSource()
    es += mock_handler1
    es += mock_handler2
    es.fire(*args, **kwargs)

    # assert calls to mock_handler1 and mock_handler2
    assert mock_handler1.args == args

# Generated at 2022-06-21 08:05:39.041382
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()


# Generated at 2022-06-21 08:05:43.590300
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac.collection_finder is None
    assert ac.default_collection is None
    assert isinstance(ac.on_collection_load, _EventSource)
    assert ac.collection_finder is None
    assert ac.playbook_paths is None



# Generated at 2022-06-21 08:05:49.388111
# Unit test for constructor of class _EventSource
def test__EventSource():
    source = _EventSource()
    assert len(source._handlers) == 0
    def handler():
        pass
    source += handler
    source -= handler
    try:
        source -= handler  # should not raise
    except KeyError:
        raise AssertionError('KeyError raised on second removal of handler')


# Generated at 2022-06-21 08:05:53.912989
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig(None, 'AnsibleCollectionConfig', None)
    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert isinstance(ac._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:05:57.903736
# Unit test for constructor of class _EventSource
def test__EventSource():
    def mock_handler(*args, **kwargs):
        pass

    event_source = _EventSource()
    event_source.fire()

    event_source += mock_handler
    event_source -= mock_handler


# Generated at 2022-06-21 08:06:35.151199
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc = AnsibleCollectionConfig()



# Generated at 2022-06-21 08:06:41.476155
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cfg = AnsibleCollectionConfig()

    assert cfg.collection_finder is None
    assert cfg.collection_paths == []
    assert cfg.default_collection is None
    assert cfg.on_collection_load is cfg._on_collection_load
    assert cfg.playbook_paths == []



# Generated at 2022-06-21 08:06:44.767313
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    test_obj = AnsibleCollectionConfig()
    assert test_obj._collection_finder is None
    assert test_obj._default_collection is None
    assert '_AnsibleCollectionConfig' in str(type(test_obj))

# Generated at 2022-06-21 08:06:51.473948
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # _AnsibleCollectionConfig is a metaclass, so we need to create a concrete class to test it
    class MyClass(_AnsibleCollectionConfig):
        pass

    assert issubclass(MyClass, _AnsibleCollectionConfig)
    assert MyClass._collection_finder is None
    assert MyClass._default_collection is None
    assert isinstance(MyClass._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:06:54.729568
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-21 08:07:00.034069
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None

    # on_collection_load is an instance of the EventSource class
    assert isinstance(config._on_collection_load, _EventSource)



# Generated at 2022-06-21 08:07:03.863489
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None
    assert type(AnsibleCollectionConfig._on_collection_load) is _EventSource

# Generated at 2022-06-21 08:07:09.516990
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    call_count = 0
    event_source = _EventSource()
    event_source += lambda a, b: call_count.__iadd__(1)
    event_source += lambda a, b: call_count.__iadd__(2)

    # Act
    event_source.fire()

    # Assert
    assert call_count == 3

# Generated at 2022-06-21 08:07:12.266495
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert type(config._on_collection_load) is _EventSource
    assert config._on_collection_load._handlers == set()

    assert config._collection_finder is None

# Generated at 2022-06-21 08:07:17.487752
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    o = _EventSource()

    def f1(*args, **kwargs):
        pass

    def f2(*args, **kwargs):
        pass

    o1 = o.__iadd__(f1)
    assert o1 is o

    o2 = o.__iadd__(f2)
    assert o2 is o

    assert len(o._handlers) == 2



# Generated at 2022-06-21 08:08:34.791612
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(a, b):
        print(a)
        print(b)

    test1 = _EventSource()
    test1 += handler
    handlers = test1._handlers
    assert len(handlers) == 1
    assert handler in handlers


# Generated at 2022-06-21 08:08:36.613872
# Unit test for constructor of class _EventSource
def test__EventSource():
    source = _EventSource()

    assert(source._handlers == set())



# Generated at 2022-06-21 08:08:42.595790
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def h1():
        k.append(1)

    def h2():
        k.append(2)

    def h3():
        raise ValueError()

    def h4():
        k.append(4)

    k = []
    e = _EventSource()
    e += h1
    e += h2
    e += h3
    e += h4
    e.fire()
    if k != [1, 2]:
        raise AssertionError(k)

# Generated at 2022-06-21 08:08:54.132499
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.errors import AnsibleError

    class _EventSourceTest(object):
        def __init__(self):
            pass

    def handler_callable_test(message):
        pass

    def handler_non_callable_test():
        pass

    # Create test object
    test_obj = _EventSourceTest()

    def test__EventSource___iadd___handler_callable_test(test_obj):
        """Test method with callable handler."""
        test_obj._on_event_source += handler_callable_test

    def test__EventSource___iadd___handler_non_callable_test(test_obj):
        """Test method with non callable handler."""

# Generated at 2022-06-21 08:08:59.098683
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import ansible.utils.collection_loader.ansible_collections.builder_loader as bc

    b = bc.AnsibleCollectionConfig()
    assert type(b) == AnsibleCollectionConfig
    assert b._collection_finder is None
    assert b._default_collection is None
    assert isinstance(b._on_collection_load, _EventSource)


# Generated at 2022-06-21 08:09:02.682597
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    instance = _EventSource()

    def first_event(event_arg):
        pass

    def second_event(event_arg):
        pass

    instance += first_event
    instance += second_event

    assert len(instance._handlers) == 2
    assert first_event in instance._handlers
    assert second_event in instance._handlers



# Generated at 2022-06-21 08:09:08.568683
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # GIVEN: an _EventSource and a sequence of handlers
    event_source = _EventSource()
    handlers = set()

    # WHEN: we assign the handlers to the event source
    for handler in (print, event_source.fire):
        handlers.add(handler)
        event_source += handler

    # THEN: we have the handlers we expect
    assert handlers == event_source._handlers


# Generated at 2022-06-21 08:09:11.969708
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    def f():
        pass
    es += f
    es -= f
    assert len(es._handlers) == 0

# Generated at 2022-06-21 08:09:14.398788
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    eventSource = _EventSource()
    handler = lambda: None
    eventSource += handler
    eventSource -= handler
    assert len(eventSource._handlers) == 0


# Generated at 2022-06-21 08:09:21.598093
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils._text import to_native
    class EventSourceTest(object):
        def __init__(self, test_value):
            self.on_exception = lambda handler, exc, *args, **kwargs: False
            self.event = _EventSource()

            def handler(value):
                assert value == test_value

            self.handler = handler
            self.event += self.handler

        def fire_event(self):
            self.event.fire(self.handler)

    eventsource_test = EventSourceTest(5)
    eventsource_test.fire_event()