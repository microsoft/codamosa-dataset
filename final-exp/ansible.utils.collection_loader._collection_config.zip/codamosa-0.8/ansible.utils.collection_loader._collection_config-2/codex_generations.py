

# Generated at 2022-06-11 17:34:34.949636
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TempHandler:
        def __call__(self, *args, **kwargs):
            raise NotImplementedError()

    es = _EventSource()
    es += TempHandler()
    es += TempHandler()
    es += TempHandler()
    es.fire()


# Generated at 2022-06-11 17:34:43.681252
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_test.lib.resources import data
    from ansible_test.lib.resources.collection_loader import collection_loader_data

    evt_source = _EventSource()

    handled_events = []
    def handler_one(*args, **kwargs):
        handled_events.append(args[0])

    evt_source += handler_one

    test_events = [
        data('ansible.module_utils.basic.AnsibleModule'),
        data('ansible.module_utils.facts.AnsibleFacts'),
    ]

    for test_evt in test_events:
        evt_source.fire(test_evt)

    assert len(handled_events) == 2
    assert handled_events[0] == data('ansible.module_utils.basic.AnsibleModule')

# Generated at 2022-06-11 17:34:44.710056
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pass



# Generated at 2022-06-11 17:34:49.567596
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(*args, **kwargs):
        pass

    es = _EventSource()

    for m in (object, None, handler, es):
        if m == handler:
            es += m

        try:
            es += m
        except ValueError:
            pass
        else:
            assert False

    es1 = _EventSource()
    es2 = _EventSource()

    es1 += handler
    es2 += handler

    es1 += es2

    assert len(es1._handlers) == 1
    assert len(es2._handlers) == 1

# Generated at 2022-06-11 17:34:52.561656
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    t = _EventSource()
    t += test__EventSource___iadd__
    assert test__EventSource___iadd__ in t._handlers


# Generated at 2022-06-11 17:34:55.218738
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    handler = lambda x: None
    event += handler
    assert handler in event._handlers

    try:
        event += None
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-11 17:35:05.718718
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler_1(x):
        print('handler_1: %s' % (x,))

    def handler_2(x):
        print('handler_2: %s' % (x,))
        raise ValueError('foo')

    def handler_3(x):
        print('handler_3: %s' % (x,))
        raise ValueError('bar')

    def handler_4(x):
        print('handler_4: %s' % (x,))
        raise ValueError('baz')

    es = _EventSource()
    es += handler_1
    es += handler_2
    es += handler_3
    es += handler_4

    try:
        es.fire('foo')
    except ValueError as e:
        assert e.args[0] == 'baz'

# Generated at 2022-06-11 17:35:08.306153
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def f():
        pass

    es += f
    assert f in es._handlers

    es += f
    assert f in es._handlers


# Generated at 2022-06-11 17:35:09.935480
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler():
        pass
    event_source += handler

    event_source.fire()



# Generated at 2022-06-11 17:35:19.861166
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    class A(object):
        def __init__(self):
            self.value = 0

        def handle(self):
            self.value += 1

    a1 = A()
    a2 = A()

    event += a1.handle
    event.fire()
    assert(a1.value == 1 and a2.value == 0)

    event += a2.handle
    event.fire()
    assert(a1.value == 2 and a2.value == 1)

    event -= a1.handle
    event.fire()
    assert(a1.value == 2 and a2.value == 2)



# Generated at 2022-06-11 17:35:25.525404
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda *args, **kwargs: None
    event += lambda *args, **kwargs: None


# Generated at 2022-06-11 17:35:33.428968
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    c = _EventSource()
    c.fire()

    def event_handler(m):
        pass

    # add an assert to the event handler to make sure it gets fired
    def event_handler2(m):
        assert True

    c += event_handler
    c.fire()  # make sure the event handler is called

    # add a second event handler, make sure both are called
    c += event_handler2
    c.fire()  # make sure the added event handler is called

    c -= event_handler2  # remove the added handler
    c.fire()  # make sure the original handler is still called, but removed handler is not



# Generated at 2022-06-11 17:35:38.220164
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    events = _EventSource()

    def test_event(*args, **kwargs):
        pass

    # Test with a callable
    events += test_event
    assert test_event in events._handlers

    # Test with a non-callable
    try:
        events += 1
    except ValueError:
        assert 1 not in events._handlers
    else:
        assert False, 'Expected exception with non-callable'



# Generated at 2022-06-11 17:35:49.979458
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def generic_event_handler(event_name, *args, **kwargs):
        raise Exception('This is the generic event handler function')

    def event_handler_1(ev_name, *args, **kwargs):
        raise Exception('This is the first event handler function')

    def event_handler_2(ev_name, *args, **kwargs):
        raise Exception('This is the second event handler function')

    event_source = _EventSource()

    # No handlers are defined for the event, should not assert
    event_source.fire('start')

    # Add a generic handler for all events
    event_source += generic_event_handler

    # An event handler is defined for the event, should assert
    raises(Exception, event_source.fire, 'start')

    # Add the first event handler and remove the generic handler
    event_

# Generated at 2022-06-11 17:35:53.373095
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestEventSource(_EventSource):
        pass

    event_source = TestEventSource()

    def handler():
        pass

    event_source += handler

    assert len(event_source._handlers) == 1



# Generated at 2022-06-11 17:35:58.472401
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    EventSource = _EventSource()

    handler = lambda x: x
    EventSource += handler
    assert handler in EventSource._handlers

    try:
        EventSource += None
        assert False
    except ValueError:
        pass

    EventSource -= handler
    assert handler not in EventSource._handlers

    EventSource -= None
    assert handler not in EventSource._handlers

# Generated at 2022-06-11 17:36:09.785467
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        pass

    # does basic test work
    e = TestEventSource()
    result = []

    def handler(a, b, c):
        result.extend([a, b, c])

    e += handler
    e.fire(1, 2, 3)
    assert result == [1, 2, 3]

    # does it remove handler
    result = []
    e -= handler
    e.fire(1, 2, 3)
    assert result == []

    # does it handle exceptions in handlers
    result = []

    def handler_raising(a, b, c):
        result.extend([a, b, c])
        raise Exception('the example exception')

    e += handler_raising
    assert result == []


# Generated at 2022-06-11 17:36:20.949748
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        class _Event:
            def __init__(self, arg):
                self.arg = arg

            def __repr__(self):
                return 'TestEventSource.TestEvent(%s)' % self.arg

        def __init__(self, testcase):
            super(TestEventSource, self).__init__()
            self.testcase = testcase
            self.events = []

        def fire(self, arg):
            self.events.append(self._Event(arg))
            super(TestEventSource, self).fire(arg)

    # simplest case - fire one event to one handler
    eventsource = TestEventSource()
    eventsource += lambda arg: None
    eventsource.fire('one')
    assert eventsource.events == [eventsource._Event('one')]

    #

# Generated at 2022-06-11 17:36:32.059330
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # __iadd__ of class _EventSource
    def test__EventSource___iadd__(event_source, handler):
        event_source += handler

    # __isub__ of class _EventSource
    def test__EventSource___isub__(event_source, handler):
        event_source -= handler

    on_collection_load_times_called = [0]

    def test_EventSource_handler(arg):
        on_collection_load_times_called[0] += 1

    event_source = _EventSource()
    test__EventSource___iadd__(event_source, test_EventSource_handler)
    event_source.fire()
    assert on_collection_load_times_called[0] == 1
    test__EventSource___isub__(event_source, test_EventSource_handler)
    event_

# Generated at 2022-06-11 17:36:40.660606
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import contextlib

    call_counter = [0]

    @contextlib.contextmanager
    def fake_stream(fake_stream_value):
        yield fake_stream_value

    def event_handler(*args, **kwargs):
        assert args[0].read() == 'ansible-galaxy 5.0.0'
        call_counter[0] += 1

    with open('/tmp/ansible-galaxy') as fake_stream:
        event_source = _EventSource()
        event_source += event_handler
        event_source.fire(fake_stream)
        assert call_counter[0] == 1
        event_source -= event_handler
        event_source.fire(fake_stream)
        assert call_counter[0] == 1

# Generated at 2022-06-11 17:36:51.255470
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def foo1():
        pass

    def foo2():
        pass

    evt = _EventSource()
    evt.__iadd__(foo1)
    evt.__iadd__(foo2)



# Generated at 2022-06-11 17:36:59.977477
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    call_count = 0

    def handler1(*args, **kwargs):
        nonlocal call_count
        call_count += 1

    def handler2(*args, **kwargs):
        raise ValueError('this handler raises an exception')

    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    es = MyEventSource()
    es += handler1
    es += handler2
    es.fire()

    assert call_count == 1



# Generated at 2022-06-11 17:37:05.431736
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._on_exception = lambda *args, **kwargs: False

    evt = _TestEventSource()
    evt += lambda: None
    evt += lambda: None
    evt.fire()



# Generated at 2022-06-11 17:37:08.629898
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def success(*args, **kwargs):
        pass

    def failure(x):
        raise Exception('TestException')

    es = _EventSource()
    es.fire()
    es += success
    es += failure
    es.fire()
    es -= failure
    es.fire()



# Generated at 2022-06-11 17:37:18.505992
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def raise_exception():
        raise Exception('my test exception')

    def raise_exception2():
        raise Exception('my test exception 2')

    def do_nothing():
        pass

    e = _EventSource()
    e += raise_exception
    e += do_nothing
    e += raise_exception2

    try:
        e.fire(1, 2, 3)
        assert False, 'exception should have been raised'
    except Exception as ex:
        assert str(ex) == 'my test exception', 'unexpected exception raised: %s' % str(ex)

    e += do_nothing

# Generated at 2022-06-11 17:37:29.505306
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import unittest

    class DummyHandler:
        def dummy(self, *args, **kwargs):
            pass

    class TestEventSource(unittest.TestCase):

        def test_call_subscriber(self):
            # ensure event is called
            evt = _EventSource()
            dummy_handler = DummyHandler()
            evt += dummy_handler.dummy
            evt.fire('arg1', 'arg2', kwarg='kwarg')
            self.assertTrue(dummy_handler._called)

            # ensure event is called with arguments
            evt = _EventSource()
            dummy_handler = DummyHandler()
            evt += dummy_handler.dummy
            evt.fire('arg1', 'arg2', kwarg='kwarg')

# Generated at 2022-06-11 17:37:33.862818
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(self):
        pass

    def handler2(self):
        pass

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-11 17:37:40.170210
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler1 = object()
    handler2 = object()
    event_source += handler1
    event_source += handler2
    assert event_source._handlers == {handler1, handler2}

    try:
        event_source += object()
        assert False
    except ValueError:
        pass

    event_source += event_source.__iadd__
    assert event_source._handlers == {handler1, handler2}



# Generated at 2022-06-11 17:37:44.850025
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestHandler:
        def __init__(self):
            self.count = 0

        def __call__(self, *args, **kwargs):
            self.count += 1

    source = _EventSource()

    handler = TestHandler()

    source += handler

    source.fire()

    assert handler.count == 1

# Generated at 2022-06-11 17:37:51.005623
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEvent:
        def __init__(self):
            self.args = None
            self.kwargs = None

        def handler(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    event = MyEvent()
    event_source = _EventSource()
    event_source += event.handler
    event_source.fire('hello', 'world', foo='bar')
    assert event.args == ('hello', 'world')
    assert event.kwargs == {'foo': 'bar'}

# Generated at 2022-06-11 17:38:12.391235
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pattern = 123

    class Mock(object):
        def __init__(self):
            self.called = False

        def __call__(self):
            self.called = True

    instance = Mock()

    source = _EventSource()

    source += instance
    source += instance
    source._handlers.add(pattern)

    source.fire()

    assert instance.called
    assert instance in source._handlers
    assert pattern in source._handlers



# Generated at 2022-06-11 17:38:20.403903
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    def ok(sender, *args, **kwargs):
        pass  # caller wants us to execute this handler
    def error1(sender, *args, **kwargs):
        # caller does not want us to execute this handler
        raise TypeError
    def error2(sender, *args, **kwargs):
        # caller does not want us to execute this handler
        raise TypeError('foo')
    def error3(sender, *args, **kwargs):
        # caller wants us to execute this handler
        raise ValueError
    es += ok
    es += error1
    es += error2
    es += error3
    try:
        es.fire()
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError to be raised')
    es

# Generated at 2022-06-11 17:38:24.567730
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    handler = lambda: None

    source = _EventSource()

    source += handler
    assert handler in source._handlers

    source += None
    assert handler in source._handlers

    try:
        source += object()
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-11 17:38:27.845051
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()
    assert not eventsource.fire()
    eventsource += lambda x: x
    assert eventsource.fire(True)
    eventsource -= lambda x: x
    assert not eventsource.fire()

# Generated at 2022-06-11 17:38:30.085899
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda x: print(x)

    event_source.fire("foo")

# Generated at 2022-06-11 17:38:34.507610
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj = _EventSource()
    def handler(ex):
        #print "__iadd__: handler is called with exception: %s" % str(ex)
        assert isinstance(ex, Exception)
    obj += handler
    obj.fire(Exception())


# Generated at 2022-06-11 17:38:47.026030
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest
    from ansible.module_utils._text import to_text

    # Bad handler type

# Generated at 2022-06-11 17:38:51.944901
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    assert len(es._handlers) == 0

    # Register a handler which can handle any number of args and kwargs
    def handler(*args, **kwargs):
        assert len(args) == 3
        assert args[0] == 1
        assert args[1] == 2
        assert args[2] == 3
        assert len(kwargs) == 2
        assert kwargs['kwarg1'] == 'a'
        assert kwargs['kwarg2'] == 'b'

    es += handler

    # Test that handler is called
    es.fire(1, 2, 3, kwarg1='a', kwarg2='b')

    # Test that nothing bad happens when no handlers are registered
    es._handlers = set()

# Generated at 2022-06-11 17:38:58.116170
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    handled = [False]
    def handle(arg):
        handled[0] = True

    def handle_exception(ex):
        handled[0] = True

    event += handle
    event.fire(None)
    assert handled[0]

    handled[0] = False
    event = _EventSource()
    event._on_exception = handle_exception
    event += handle
    try:
        event.fire(None)
    except:
        pass
    assert handled[0]



# Generated at 2022-06-11 17:39:04.515405
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    target = _EventSource()
    def handler1(event_name, event_config):
        assert event_name == 'foo'
        assert event_config['a'] == 'A'

    def handler2(event_name, event_config):
        assert event_name == 'foo'
        assert event_config['b'] == 'B'

    target.fire('foo', dict(a='A'))

    target += handler1
    target += handler2

    target.fire('foo', dict(a='A', b='B'))

    target -= handler1
    target -= handler2


# Generated at 2022-06-11 17:39:45.303882
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def on_exception(handler, exc, *args, **kwargs):
        pass

    event_source._on_exception = on_exception

    class MyException(Exception):
        pass

    def handler1(*args, **kwargs):
        raise MyException('boom')

    def handler2(*args, **kwargs):
        raise IndexError('boom')

    def handler3(*args, **kwargs):
        raise StopIteration('boom')

    def handler4(*args, **kwargs):
        raise IOError('boom')

    def handler5(*args, **kwargs):
        raise ValueError('boom')

    event_source += handler1
    event_source += handler2
    event_source += handler3
    event_source += handler4
    event_

# Generated at 2022-06-11 17:39:51.777935
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler_1(event, a, b):
        pass

    def handler_2(event, a, b):
        pass

    # add handlers
    es += handler_1
    assert len(es._handlers) == 1
    assert handler_1 in es._handlers

    es += handler_2
    assert len(es._handlers) == 2
    assert handler_2 in es._handlers


# Generated at 2022-06-11 17:40:03.263459
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # The following will be used to test that the handler fires and receives the appropriate
    # arguments.
    test_args = per_event_args = None
    test_kwargs = per_event_kwargs = None

    def handler_1(args, kwargs):
        nonlocal test_args, test_kwargs
        test_args = args
        test_kwargs = kwargs

    def handler_2(args, kwargs):
        nonlocal per_event_args, per_event_kwargs
        per_event_args = args
        per_event_kwargs = kwargs

    event = _EventSource()

    event += handler_1
    event += handler_2

    # When there are no arguments, we want to ensure they are all None
    # in the handler.
    event.fire()
    assert test_

# Generated at 2022-06-11 17:40:08.626372
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    # arrange
    def test1(e):
        e.foo.append(1)

    def test2(e):
        e.foo.append(2)

    x = _EventSource()
    x.foo = []

    # act
    x += test1
    x += test2

    # assert
    assert x.foo == []

    # act
    x.fire(x)

    # assert
    assert x.foo == [1, 2]



# Generated at 2022-06-11 17:40:16.058239
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestClass(object):
        def __init__(self):
            self.events = _EventSource()
            self.events += self._handler
            self.flag = False
        def _handler(self):
            self.flag = True

    # set up the test class
    test_class = TestClass()
    assert(not test_class.flag)

    # test that the event is fired
    test_class.events.fire()
    assert(test_class.flag)

# Generated at 2022-06-11 17:40:21.023243
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(arg1, arg2, kwarg1=None, kwarg2=None):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        assert kwarg1 == 'kwarg1'
        assert kwarg2 == 'kwarg2'

    source = _EventSource()

    source.fire('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')

    with source:
        source.fire('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')

    source += handler

    with source:
        source.fire('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')

    source -= handler

    with source:
        source

# Generated at 2022-06-11 17:40:32.524373
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def foo(a, b):
        return a + b
    def bar(a, b, c):
        return a + b + c
    def exception_handler(handler, exception, *args, **kwargs):
        assert handler == baz
        assert exception == ValueError
        assert args == (2,)
        assert kwargs == {'c': 3}
        return True
    def baz(a):
        raise ValueError(a)

    event_source = _EventSource()
    event_source.fire(1, 2)

    event_source._on_exception = exception_handler

    event_source += foo

    assert event_source.fire(1, 2) == 3

    event_source += bar

    assert event_source.fire(1, 2, c=3) == 6

    event_source += baz



# Generated at 2022-06-11 17:40:33.882171
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    assert not es.fire()


# Generated at 2022-06-11 17:40:38.599544
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # define a handler
    def _on_event(arg1, arg2, kwarg1=None):
        # verify args
        assert arg1 == 1
        assert arg2 == 2
        assert kwarg1 == 'bar'

    # initialize event source
    e = _EventSource()

    # add handler
    e += _on_event

    # fire event
    e.fire(1, 2, kwarg1='bar')


# Generated at 2022-06-11 17:40:45.653975
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    results = []
    def handler1(a, b):
        results.append('handler1 called')
    def handler2(a, b):
        results.append('handler2 called')
    def handler3(a, b):
        results.append('handler3 called')
        raise Exception('handler3 exception')

    e += handler1
    e += handler2
    e += handler3

    try:
        e.fire('a', 'b')
    except Exception as ex:
        results.append('handler3 exception caught')

    assert set(results) == set(['handler1 called', 'handler2 called', 'handler3 called', 'handler3 exception caught'])

# Generated at 2022-06-11 17:42:00.684488
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.counter = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.counter += 1
            return False

    es = MyEventSource()
    es += lambda: None
    es += lambda: 'a string'
    with pytest.raises(ValueError):
        es += 'not callable'

    es.fire()
    assert es.counter == 1  # the lambda that raises should not have been called
    assert len(es._handlers) == 1  # the bad lambda should have been removed
    es.fire()  # again to prove that it did not enter an infinite exception/add loop

# Generated at 2022-06-11 17:42:11.241228
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass
    source = _EventSource()

    # test exception in handler
    def handle_1(arg1, arg2, kwarg1='foo'):
        raise TestException('handle_1')

    source += handle_1

    try:
        source.fire('arg1', 'arg2')
        assert False
    except TestException:
        pass

    # test exception while iterating handlers
    def handle_1(arg1, arg2, kwarg1='foo'):
        return arg2 + kwarg1

    def handle_2(arg1, arg2, kwarg1='foo'):
        raise TestException('handle_2')


# Generated at 2022-06-11 17:42:20.180934
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_bytes as _to_bytes

    # the _EventSource class does not depend on AnsibleCollectionConfig, so we can test it by itself
    class _MyEventSource(_EventSource):
        def __init__(self):
            super(_MyEventSource, self).__init__()
            self._bytes = b''

        def _on_exception(self, handler, exc, *args, **kwargs):
            if isinstance(exc, ValueError):
                self._bytes += b'ValueError'
            else:
                self._bytes += b'Exception'
            return False

        def _add(self, text):
            self._bytes += _to_bytes(text)


# Generated at 2022-06-11 17:42:23.259592
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler():
        pass

    es = _EventSource()
    assert len(es._handlers) == 0
    es += handler
    assert len(es._handlers) == 1
    assert handler in es._handlers

# Generated at 2022-06-11 17:42:29.253282
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """
    When an error occurs in a _EventSource, re-throw the exception
    """
    def throw_error(*args, **kwargs):
        raise Exception('bar')

    event = _EventSource()
    event += throw_error

    try:
        event.fire()
        assert False, 'Expected to raise an error.'
    except Exception as error:
        assert error.args[0] == 'bar'


# Generated at 2022-06-11 17:42:37.269192
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    def handler1(*args, **kwargs):
        print('handler1')
        return
    def handler2(*args, **kwargs):
        print('handler2')
        return
    assert event_source._handlers == set()
    assert not event_source._on_exception
    event_source += handler1
    assert event_source._handlers == set([handler1])
    event_source += handler2
    assert event_source._handlers == set([handler1, handler2])


# Generated at 2022-06-11 17:42:40.999721
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    # A sample function for use as a handler
    def f(a, b):
        return a + b

    # A sample instance of _EventSource
    event = _EventSource()

    # Add the sample function to the event
    event += f

    # We expect f to be added to the event
    assert f in event._handlers

# Generated at 2022-06-11 17:42:50.886763
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()

    def handler1(*args, **kwargs):
        if 'fail' in args:
            raise Exception('Sorry, but we failed')
        else:
            print('handler1 called with {} {}'.format(args, kwargs))

    def handler2(*args, **kwargs):
        if 'fail' in kwargs:
            raise Exception('Sorry, but we failed')
        else:
            print('handler2 called with {} {}'.format(args, kwargs))

    def _on_exception(handler, exc, *args, **kwargs):
        if 'fail' in kwargs:
            return True
        else:
            return False

    s += handler1
    s += handler2
    s._on_exception = _on_exception


# Generated at 2022-06-11 17:42:55.296095
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    es += lambda event1, event2: print("{} {}".format(event1, event2))
    es += lambda event1, event2: print("{} {}".format(event2, event1))
    es.fire("event1", "event2")


# Generated at 2022-06-11 17:43:03.129610
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    actual_calls = []

    class _Handler:
        def __init__(self, handler_id):
            self._handler_id = handler_id

        def __call__(self, *args, **kwargs):
            actual_calls.append(self._handler_id)

    handler1 = _Handler('handler1')
    handler2 = _Handler('handler2')

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    assert list(event_source._handlers) == [handler1, handler2]
    event_source.fire()
    assert actual_calls == ['handler1', 'handler2']

