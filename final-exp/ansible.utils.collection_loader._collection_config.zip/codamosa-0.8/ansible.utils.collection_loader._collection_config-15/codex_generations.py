

# Generated at 2022-06-11 17:34:32.484167
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource().fire()

# Generated at 2022-06-11 17:34:41.708564
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    call_count = 0
    last_a = last_b = None

    def on_test_event(a, b):
        nonlocal call_count, last_a, last_b
        call_count += 1
        last_a = a
        last_b = b

    event_source += on_test_event
    assert call_count == 0
    assert last_a is None
    assert last_b is None

    event_source.fire(1, 2)
    assert call_count == 1
    assert last_a == 1
    assert last_b == 2

    event_source.fire(3, 4)
    assert call_count == 2
    assert last_a == 3
    assert last_b == 4


# Generated at 2022-06-11 17:34:45.302513
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventHandler:
        def __init__(self):
            self.fired = False

        def handler(self):
            self.fired = True

    class BrokenEventHandler:
        def handler(self, event_source):
            event_source._handlers.clear()

    handler = EventHandler()
    broken_handler = BrokenEventHandler()

    event_source = _EventSource()
    event_source += handler
    event_source += broken_handler

    # fire event
    event_source.fire()

    # Make sure handler fired
    assert handler.fired is True
    assert broken_handler.fired is not True



# Generated at 2022-06-11 17:34:48.996795
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    num_events = [0]

    def event_handler():
        num_events[0] += 1

    event_source += event_handler
    event_source.fire()

    assert num_events[0] == 1
    event_source -= event_handler
    event_source.fire()

    assert num_events[0] == 1

# Generated at 2022-06-11 17:34:56.266038
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg):
        assert arg == 42
        return 42

    def handler2(arg1, arg2):
        assert arg1 == 1
        assert arg2 == 2
        return None

    es = _EventSource()
    es += handler1
    es += handler2
    es.fire(42)

    # handler1 returns 42 and handler2 returns None
    #  this is an intentional feature of the implementation:
    #  it is recreating the design pattern used in Python's

    result = es.fire(1, 2)
    assert result is None

    es -= handler1
    es -= handler2

    result = es.fire(1)
    assert result is None

# Generated at 2022-06-11 17:35:06.557154
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def assert_arguments(event_source, args, kwargs):
        def test_handler(a, b, c, d):
            assert a == args[0]
            assert b == args[1]
            assert c == args[2]
            assert d == args[3]
            assert 'e' in kwargs
            assert kwargs['e'] == 5

        event_source += test_handler
        event_source.fire(1, 2, 3, 4, e=5)

    def assert_exceptions(event_source):
        raised = False
        try:
            event_source.fire()
        except ValueError as ex:
            raised = True
            assert ex.args[0] == 'handler must be callable'

        event_source += 1

# Generated at 2022-06-11 17:35:08.191528
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda x: None
    event += lambda x: None



# Generated at 2022-06-11 17:35:14.006511
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # 1) No event handler registed
    event_source = _EventSource()
    event_source.fire()

    # 2) Event handler without any argument
    event_handler = lambda : 1
    event_source += event_handler
    event_source.fire()
    assert event_source._handlers == {event_handler}

    # 3) Event handler with one argument
    event_handler = lambda x: 1
    event_source += event_handler
    event_source.fire(1)
    assert event_source._handlers == {event_handler}

    # 4) Event handler with multiple arguments
    event_handler = lambda x, y: 1
    event_source += event_handler
    event_source.fire(1, 2)
    assert event_source._handlers == {event_handler}

    # 5) Event handler with multiple

# Generated at 2022-06-11 17:35:21.824244
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self):
            super(EventSource, self).__init__()
            self.count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    s = EventSource()

# Generated at 2022-06-11 17:35:31.880233
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # On exception, _on_exception is called.
    # The default behavior is to return True, so re-raise the exception.
    def _test_1(_):
        assert False
    es = _EventSource()
    es += _test_1
    try:
        es.fire()
        assert False
    except AssertionError:
        pass

    # On exception, _on_exception is called.
    # When returning False, the exception is swallowed.
    def _test_2(_):
        raise RuntimeError()
    def _on_exception(_, exc, *args, **kwargs):
        assert isinstance(exc, RuntimeError)
        return False
    es = _EventSource()
    es += _test_2
    es._on_exception = _on_exception

# Generated at 2022-06-11 17:35:39.074568
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    src = _EventSource()
    src += lambda: None
    src += lambda: None

    try:
        src += None
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')



# Generated at 2022-06-11 17:35:50.619289
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    from ansible_test._util._mock import Mock
    from ansible_test._util._collection_loader._mock import MockAnsibleCollectionConfig

    handler = Mock()

    # passing a function works
    config = MockAnsibleCollectionConfig()
    config.on_collection_load += handler
    config.on_collection_load.fire(1, 2, 3)
    handler.assert_called_once_with(1, 2, 3)
    handler.reset_mock()

    # passing an object method works
    config = MockAnsibleCollectionConfig()
    config.on_collection_load += handler.mock_method
    config.on_collection_load.fire(1, 2, 3)
    handler.mock_method.assert_called_once_with(1, 2, 3)
   

# Generated at 2022-06-11 17:35:53.632224
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    # test expected successful calls
    event_source += lambda x: print("hello")
    event_source += lambda x: print("goodbye")

    # test unexpected calls
    try:
        event_source += None
        raise Exception("Failed to raise ValueError when adding a non-callable handler")
    except ValueError:
        pass



# Generated at 2022-06-11 17:35:58.972132
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(arg, foo):
        pass

    def handler2(arg, foo):
        pass

    event = _EventSource()
    event += handler1
    assert event._handlers == set([handler1])
    event += handler2
    assert event._handlers == set([handler1, handler2])
    try:
        event += 5
        assert False
    except ValueError:
        pass


# Generated at 2022-06-11 17:36:04.564912
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    global handler_call_count
    handler_call_count = 0
    def handler_0():
        global handler_call_count
        handler_call_count += 1

    es += handler_0
    es.fire()

    assert handler_call_count == 1

test__EventSource_fire()


# Generated at 2022-06-11 17:36:11.105125
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    with open('/tmp/file', 'w') as f:
        f.write('foo')

    def foo(a):
        raise

    es = _EventSource()
    es += foo
    assert foo in es._handlers

    try:
        es.fire(1, 2, 3)
    except Exception as ex:
        assert es._on_exception(foo, ex)
    else:
        raise AssertionError('expected exception')

    es -= foo

    es.fire(1, 2, 3)


test__EventSource___iadd__()

# Generated at 2022-06-11 17:36:15.655678
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Foo:
        pass

    foo_object = Foo()

    def handler():
        pass

    foo_object.handler = handler

    obj = _EventSource()
    obj += handler
    obj += foo_object.handler
    obj += foo_object.handler
    obj.fire()

    assert len(obj._handlers) == 2

# Generated at 2022-06-11 17:36:28.558053
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from unittest import TestCase

    class TestEventSource(TestCase):

        def test_fire_all_good(self):

            def handler_1(*args):
                test_args[0].append(args)

            def handler_2(*args):
                test_args[1].append(args)

            def handler_3(*args):
                test_args[2].append(args)

            test_args = [
                [],
                [],
                []
            ]

            event = _EventSource()
            event += handler_1
            event += handler_2
            event += handler_3

            event.fire('foo', 'bar')

            self.assertEqual([('foo', 'bar')], test_args[0])
            self.assertEqual([('foo', 'bar')], test_args[1])
           

# Generated at 2022-06-11 17:36:35.502632
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    uut = _EventSource()
    assert not uut._handlers

    assert not hasattr(uut, 'test_method')
    uut.test_method = lambda: "test_method"
    assert hasattr(uut, 'test_method')

    uut += uut.test_method
    assert uut._handlers
    assert uut.test_method in uut._handlers

    uut += uut.test_method
    assert len(uut._handlers) == 1



# Generated at 2022-06-11 17:36:39.101173
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert not es._handlers

    def handler1():
        pass

    es += handler1
    assert handler1 in es._handlers

    try:
        es += 'foo'
        assert False, 'Expected ValueError'
    except ValueError:
        pass


# Generated at 2022-06-11 17:36:49.733805
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler1(a):
        pass

    def handler2(a, b):
        pass

    def handler3(a, b=1):
        pass

    def handler4(a, *args, **kwargs):
        pass

    es += handler1

    es += handler2

    es += handler3

    es += handler4

    try:
        es += 'not callable'
        assert False, 'TypeError should have been raised'
    except ValueError:
        pass



# Generated at 2022-06-11 17:36:53.285433
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def func_dummy():
        pass

    event_source = _EventSource()
    assert event_source._handlers == set()

    event_source += func_dummy
    assert event_source._handlers == set([func_dummy])

    event_source += func_dummy
    assert event_source._handlers == set([func_dummy])



# Generated at 2022-06-11 17:36:55.283310
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def test_handler(arg):
        pass

    es += test_handler
    assert test_handler in es._handlers

# Generated at 2022-06-11 17:37:03.597479
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()

    # verify that assignment fails if the handler is not callable
    try:
        s += 1
        raise AssertionError('expected ValueError')
    except ValueError:
        pass

    # verify that assignment succeeds when the handler is callable
    def handler():
        pass
    s += handler
    assert handler in s._handlers

    # verify that assignment succeeds when the handler is callable (but not callable directly)
    class Handler:
        def __call__(self):
            pass
    h = Handler()
    s += h
    assert h in s._handlers


# Generated at 2022-06-11 17:37:08.424587
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    class Handler:
        def __init__(self):
            self.call_count = 0

        def __call__(self):
            self.call_count += 1

    h = Handler()

    es += h

    assert es._handlers == {h}

    es.fire()

    assert h.call_count == 1


# Generated at 2022-06-11 17:37:18.235035
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def one(self, event):
            self._result.append(event)
            if event == 'two':
                raise ValueError('this is an exception')

        def two(self, event):
            self._result.append(event)
            if event == 'one':
                raise ValueError('this is an exception too')

    def _on_exception(handler, exc, *args, **kwargs):
        if 'one' in args:
            raise exc

        return False

    test_object = _EventSourceTest()
    test_object._result = []

    # create event source object and attach (subscribe) handlers
    event_source = _EventSource()
    event_source += test_object.one
    event_source += test_object.two


# Generated at 2022-06-11 17:37:23.657736
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def _callback(a, b=1):
        print('a = {0}, b = {1}'.format(a, b))
    es = _EventSource()
    es += _callback
    es.fire(100, b=200)
    es -= _callback
    es.fire(100, b=200)



# Generated at 2022-06-11 17:37:24.842091
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _unittest_event_source___iadd___helper('ADD', True)



# Generated at 2022-06-11 17:37:26.391632
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda *args, **kwargs: None


# Generated at 2022-06-11 17:37:34.500791
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    handler_call_count = 0
    event_source = _EventSource()

    def handle_event():
        nonlocal handler_call_count
        handler_call_count += 1

    event_source += handle_event
    event_source += handle_event

    event_source.fire()
    assert handler_call_count == 2

    try:
        # Validate that we correctly handle the case where a handler does not pass exceptions

        def handler_with_exception():
            raise RuntimeError('simulate handler throwing exception')

        event_source += handler_with_exception
        event_source.fire()

        raise AssertionError('expected handler to throw exception')
    except RuntimeError as ex:
        assert str(ex) == 'simulate handler throwing exception'

    # Validate that we correctly handle the case where a handler pass exceptions

# Generated at 2022-06-11 17:37:58.948782
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from collections import namedtuple
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes

    Event = namedtuple('Event', 'args kwargs')
    event = Event('value', kwargs=ImmutableDict(a='value'))

    class MyConfig(object):
        pass

    config = MyConfig()

    # Simulate the configuration used by Ansible 2.8, 2.9 and 2.10
    def my_handler_28_29_210(*args, **kwargs):
        config.args = args
        config.kwargs = kwargs

    # Simulate the configuration used by Ansible 2.11

# Generated at 2022-06-11 17:38:03.462953
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    called = []

    class MyException(Exception):
        pass

    def handler(x):
        called.append(x)

    def failer():
        raise MyException('my exception')

    s = _EventSource()
    s += handler
    s += failer

    s.fire(1)

    assert called == [1]
    assert to_text(s) == "EventSource(1 listeners)"

# Generated at 2022-06-11 17:38:13.887992
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(object):
        def __init__(self):
            self.original_count = 0
            self.invoke_count = 0

        def __call__(self, original_count, invoke_count):
            self.original_count = original_count
            self.invoke_count = invoke_count

    my_event_source = MyEventSource()

    def on_collection_load(original_count, invoke_count):
        my_event_source(original_count, invoke_count)

    my_event_source_set = _EventSource()
    my_event_source_set += on_collection_load
    my_event_source_set.fire(original_count=3, invoke_count=2)
    assert my_event_source.original_count == 3

# Generated at 2022-06-11 17:38:22.049042
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []

    def receiver(arg):
        calls.append(arg)

    source = _EventSource()
    source += receiver
    source.fire()
    assert calls == [None]

    calls.clear()
    source += receiver
    source.fire('hello')
    assert calls == ['hello']

    calls.clear()
    source -= receiver
    source.fire('hello')
    assert calls == []


# Unit test method property on_collection_load of class AnsibleCollectionConfig

# Generated at 2022-06-11 17:38:32.563297
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler_one(source, **kwargs):
        pass
    def handler_two(source, **kwargs):
        pass

    event_source = _EventSource()

    # The first call to __iadd__ should not raise an exception
    event_source.__iadd__(handler_one)

    # The second call to __iadd__ should not raise an exception
    event_source.__iadd__(handler_two)

    # The third call to __iadd__ should raise an exception
    #
    # NOTE: In the future, we want to raise a different exception here
    try:
        event_source.__iadd__(handler_one)
    except:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-11 17:38:35.507230
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    def handler(arg):
        handler.arg = arg
    es.fire('foo')
    assert handler.arg == 'foo'


# Generated at 2022-06-11 17:38:41.695129
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class BadValue(object):
        pass

    class Handler(object):
        pass

    source = _EventSource()
    source += Handler()
    source += Handler()

    with pytest.raises(ValueError) as ex:
        source += BadValue()

    assert str(ex.value) == 'handler must be callable'



# Generated at 2022-06-11 17:38:52.447124
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest
    from ansible_collections.community.general.plugins.module_utils.collection_loader.event_handlers import _EventSource

    class ExceptionOne(Exception):
        pass

    class ExceptionTwo(Exception):
        pass

    event_handler_one = ExceptionOne()
    event_handler_two = ExceptionTwo()
    event_source = _EventSource()
    event_source += event_handler_one
    event_source += event_handler_two

    # raise ExceptionOne
    with pytest.raises(ExceptionOne):
        event_source.fire()

    # don't raise ExceptionTwo
    event_source._on_exception = lambda self, handler, exc, *args, **kwargs: handler == event_handler_two

    event_source.fire()

# Generated at 2022-06-11 17:38:56.984352
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    result = []

    event += lambda a: result.append(a)
    event += lambda a: result.append(a)

    event.fire(True)
    assert result == [True, True]

    result = []
    event -= lambda a: result.append(a)

    event.fire(True)
    assert result == [True]

# Generated at 2022-06-11 17:39:04.668776
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types

    def check_handler_output(handler_out):
        if handler_out is not None:
            if not isinstance(handler_out, string_types):
                raise AssertionError('Handler output must be a string or None.')

    event_source = _EventSource()

    def handler(*args, **kwargs):
        return None

    event_source.fire()

    event_source += handler
    event_source.fire()

    event_source -= handler
    event_source.fire()

    def exception_throwing_handler(*args, **kwargs):
        raise ValueError('Intentional exception.')

    event_source += exception_throwing_handler


# Generated at 2022-06-11 17:39:42.699370
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockHandler(object):
        def __init__(self, val):
            self.val = val

        def __call__(self, *args, **kwargs):
            return self.val

    mock_handler_1 = MockHandler(1)
    mock_handler_2 = MockHandler(2)
    mock_handler_3 = MockHandler(3)
    event_source = _EventSource()
    event_source += mock_handler_1
    event_source += mock_handler_2

    # fire all handlers
    assert event_source.fire() == 1
    assert event_source.fire() == 2

    # remove handler and fire again
    event_source -= mock_handler_1
    assert event_source.fire() == 2

    # add a handler and fire
    event_source += mock_handler_3
    assert event

# Generated at 2022-06-11 17:39:46.720878
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Handler(object):
        value = 0

        def __call__(self, *args, **kwargs):
            self.value += 1

    handler = Handler()
    event = _EventSource()
    event += handler
    event.fire()
    assert handler.value == 1

    event.fire()
    assert handler.value == 2


# Generated at 2022-06-11 17:39:53.478472
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    def fire_handler1(a, b):
        assert a == 42
        assert b == 43

    def fire_handler2(a, b):
        assert a == 42
        assert b == 43

    source += fire_handler1
    source += fire_handler2

    try:
        source.fire(42, 43)
    except Exception:
        assert False, 'fire_handler1 and fire_handler2 should not raise exceptions'


# Generated at 2022-06-11 17:40:04.507947
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    on_collection_load = _EventSource()

    def callback(x):
        raise ValueError(x)

    on_collection_load += callback

    # we should be allowed to fire this event without any callbacks registered
    on_collection_load.fire()

    # No exception should be raised, even though a calledback raised an exception
    on_collection_load.fire('foo')

    on_collection_load -= callback
    on_collection_load.fire()

    counter = 0

    def callback(x):
        nonlocal counter
        counter += 1

    on_collection_load += callback
    on_collection_load += callback

    # We should only see the callback called once
    on_collection_load.fire()
    assert counter == 1

    counter = 0

    def callback(x):
        nonlocal counter
        counter += 1


# Generated at 2022-06-11 17:40:06.796318
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda x, y: x + y
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-11 17:40:15.459784
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # handle that handles the event by setting a flag
    class Handle:
        def __init__(self, flag):
            self._flag = flag

        def __call__(self, *args, **kwargs):
            self._flag = True

    # event source (handle container)
    event = _EventSource()

    # initialize the flag to False, then add the handler to the event source
    flag = False
    event += Handle(flag)

    # fire the event, then assert that the flag was set by the handler
    event.fire()
    assert flag is True



# Generated at 2022-06-11 17:40:23.217966
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Create an event source
    events = _EventSource()

    # function to fire (multiple times)
    def fireme(arg):
        assert arg.lower() == 'foo'
        fireme.times_called += 1

    # fire multiple times
    fireme.times_called = 0
    events += fireme
    events.fire('Foo')
    events.fire('FOO')
    assert fireme.times_called == 2

    # remove function and fire again
    fireme.times_called = 0
    events -= fireme
    events.fire('Foo')
    events.fire('FOO')
    assert fireme.times_called == 0

# Generated at 2022-06-11 17:40:26.384502
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    called = [False]

    def handler():
        called[0] = True

    event_source += handler
    event_source.fire()
    assert called[0]



# Generated at 2022-06-11 17:40:37.043404
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    x = _EventSource()
    assert list(x._handlers) == []

    triggered = []

    def handler1(arg):
        triggered.append('handler1')
        return arg

    def handler2(arg):
        triggered.append('handler2')
        return arg

    def handler3(arg):
        triggered.append('handler3')
        return arg

    x += handler1
    assert list(x._handlers) == [handler1]
    x += handler2
    assert list(x._handlers) == [handler1, handler2]
    x += handler3
    assert list(x._handlers) == [handler1, handler2, handler3]
    x -= handler1
    assert list(x._handlers) == [handler2, handler3]
    x -= handler2
    assert list(x._handlers)

# Generated at 2022-06-11 17:40:45.619225
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Dummy parent class and child class for testing
    class DummyParent:
        pass

    class DummyChild(DummyParent):
        pass

    passed = ['ParentClassPassed', 'ChildClassPassed']
    failed = ['ParentClassFailed', 'ChildClassFailed']

    def parent_passed_handler(*args, **kwargs):
        # Verify the arguments passed
        assert kwargs['obj'] == 'DummyParent'
        passed.remove('ParentClassPassed')

    def parent_failed_handler(*args, **kwargs):
        assert False

    def child_passed_handler(*args, **kwargs):
        # Verify the arguments passed
        assert kwargs['obj'] == 'DummyChild'
        passed.remove('ChildClassPassed')


# Generated at 2022-06-11 17:41:51.587395
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    function = lambda x: print(x)
    event_source += function
    assert function in event_source._handlers


# Generated at 2022-06-11 17:42:02.429233
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import sys

    if sys.version_info >= (3,):
        # The ability to unbound methods was removed in 3.0
        raise SkipTest

    class __TestEvent:
        def __init__(self):
            self.assert_exception = None
            self.__args = None
            self.__kwargs = None
            self._raises_exception = False

        @property
        def args(self):
            return self.__args

        @property
        def kwargs(self):
            return self.__kwargs

        def handler(self, *args, **kwargs):
            self.__args = args
            self.__kwargs = kwargs

            if self.assert_exception:
                raise self.assert_exception


# Generated at 2022-06-11 17:42:11.316093
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    results = []
    def f1(*args, **kwargs):
        results.append(('f1', args, kwargs))
    def f2(*args, **kwargs):
        results.append(('f2', args, kwargs))

    target = _EventSource()
    target += f1
    target += f2
    target.fire('a1', a2='b1')
    target -= f2
    target.fire('a2', a2='b2')

    assert results == [('f1', ('a1',), dict(a2='b1')), ('f2', ('a1',), dict(a2='b1')), ('f1', ('a2',), dict(a2='b2'))]



# Generated at 2022-06-11 17:42:20.180789
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    foo = 'a'
    bar = 'b'
    bat = 'c'

    # validate that a single event handler is called
    e = _EventSource()

# Generated at 2022-06-11 17:42:24.167116
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class A:
        called = False

        def a(self, x):
            self.called = True
            return x

    obj = A()

    s = _EventSource()

    s += obj.a

    s.fire(1)
    assert obj.called


# Generated at 2022-06-11 17:42:31.532413
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    # missing callable
    handler = 3
    try:
        event_source += handler
    except ValueError as ex:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # callable
    def handler():
        pass

    event_source += handler

    # duplicate handler
    try:
        event_source += handler
    except ValueError as ex:
        pass
    else:
        raise AssertionError('ValueError not raised')


# Generated at 2022-06-11 17:42:36.624045
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1

    event_source += handler
    assert len(event_source._handlers) == 1



# Generated at 2022-06-11 17:42:43.903956
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.count = 0

        def handler(self):
            self.count += 1

        def _on_exception(self, handler, ex, *args, **kwargs):
            # do not permit exceptions to escape
            return False

    es = MyEventSource()
    es.fire()
    assert es.count == 0

    es += es.handler
    es.fire()
    assert es.count == 1

    es += es.handler
    es.fire()
    assert es.count == 3

    es -= es.handler
    es.fire()
    assert es.count == 4

    es.handler = None
    es.fire()
    assert es.count == 4


# Unit test

# Generated at 2022-06-11 17:42:50.530821
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # this tests that the __iadd__ method correctly adds a callable to the handlers set
    # the handler function for use in this test
    def foo():
        pass
    # make an instance of _EventSource
    es = _EventSource()
    # assert the handler is not currently in the handlers set
    assert foo not in es._handlers
    # add the handler via the += operator
    es += foo
    # assert the handler is now in the handlers set
    assert foo in es._handlers


# Generated at 2022-06-11 17:42:59.078925
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _FakeHandler(object):
        def __init__(self):
            self.call_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1

    src = _EventSource()

    # If 'handler' is not callable, raise ValueError
    handler_not_callable = 'bad handler'
    try:
        src += handler_not_callable
    except ValueError:
        pass
    else:
        assert False, "expected ValueError exception"

    # If 'handler' is callable, add it to the _handlers list
    handler1 = _FakeHandler()
    src += handler1
    assert handler1 in src._handlers

    # If 'handler' is already in the _handlers list, do not attempt to re-add it
    src += handler1