

# Generated at 2022-06-11 17:34:35.120869
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fired = []

    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    e = MyEventSource()

    def default(*args, **kwargs):
        fired.append(('default', args, kwargs))

    def custom(name, *args, **kwargs):
        fired.append(('custom', name, args, kwargs))

    e += default
    e += custom

    e.fire()
    assert fired == [
        ('default', (), {}),
        ('custom', None, (), {}),
    ]

    del fired[:]
    e.fire(1, 2, 3, foo='bar')

# Generated at 2022-06-11 17:34:43.826076
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    events_seen = 0

    def handler(a, b, c):
        nonlocal events_seen
        assert a == 1
        assert b == 'abc'
        assert c
        events_seen += 1

    event_source += handler

    # the handler should be invoked exactly once
    event_source.fire(1, 'abc', True)
    assert events_seen == 1

    events_seen = 0

    # if we remove the handler and invoke the event source, no events should be seen
    event_source -= handler
    event_source.fire(1, 'abc', True)
    assert events_seen == 0

    # removing an event handler that is not present should not fail
    event_source -= handler

    events_seen = 0

    import re

    # if the handler raises an exception, it should

# Generated at 2022-06-11 17:34:50.614396
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_test.unit.compat.mock import patch

    def test_body():
        event_source = _EventSource()

        test_handlers = []

        for i in range(10):
            handler = patch('tempobj%d' % i)
            test_handlers.append(handler)

            event_source += handler

            assert handler in event_source._handlers

    test_body()

    def test_exception():
        event_source = _EventSource()

        with patch.object(event_source, '_on_exception') as on_exception:
            class TestException(Exception):
                pass
            handler = patch('tempobj')
            event_source += handler

            on_exception.side_effect = TestException()
            handler.side_effect = TestException()


# Generated at 2022-06-11 17:34:57.885239
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class A:
        def f1(self):
            self.foo = 1

        def f2(self):
            self.foo = 2

    def g1(*args, **kwargs):
        args[0].foo = 1

    def g2(*args, **kwargs):
        args[0].foo = 2

    events = _EventSource()
    a = A()
    events += a.f1
    events += g1
    events += a.f2
    events += g2

    events.fire(a)
    assert a.foo == 2

    events -= a.f1
    events.fire(a)
    assert a.foo == 2

    events -= g1
    events.fire(a)
    assert a.foo == 2

    events -= a.f2
    events.fire(a)

# Generated at 2022-06-11 17:35:01.999232
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    result = []

    def handle(msg):
        result.append(msg)

    event += handle

    event.fire('foo')
    event.fire('bar')
    assert result == ['foo', 'bar']


# Generated at 2022-06-11 17:35:10.483053
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class CustomEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            if isinstance(exc, RuntimeError):
                return False
            return True

    src = CustomEventSource()

    class _ExceptionHandler:
        def __call__(self, *args, **kwargs):
            raise RuntimeError('foo')

    def _raiser(ex):
        def _handler(*args, **kwargs):
            raise ex

        return _handler

    def _handler(*args, **kwargs):
        pass

    src += _raiser(RuntimeError('foo'))
    src += _raiser(RuntimeError('bar'))
    src += _raiser(KeyError('baz'))
    src += _handler

    src.fire()

# Generated at 2022-06-11 17:35:16.001747
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()

    # lambda function with assert statement
    def test(a,b):
        assert a == "foo"
        assert b == "bar"

    # add lambda function to event source
    s += test

    # call fire method on event source
    s.fire("foo", "bar")

# Generated at 2022-06-11 17:35:25.651303
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.errors import AnsibleError

    def my_handler(event_source, *args, **kwargs):
        if not isinstance(event_source, _EventSource) or event_source is not test_event_source:
            raise AnsibleError(msg='event_source is not an instance of _EventSource')

        test_event_source._on_exception_test_data.append(('my_handler', event_source, args, kwargs))

    test_event_source = _EventSource()

    test_event_source._on_exception_test_data = []

    def my_exception(_, exc, *args, **kwargs):
        test_event_source._on_exception_test_data.append(('my_exception', exc, args, kwargs))
        return False

    test_

# Generated at 2022-06-11 17:35:30.417698
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()

    def event1():
        event2()
        raise Exception()
    def event2():
        raise Exception()

    eventsource += event1
    eventsource += event2
    eventsource -= event2

    assert True is not False, 'sanity'
    eventsource.fire()

# Generated at 2022-06-11 17:35:36.393660
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def _handler(x, y):
        pass

    event_source = _EventSource()
    assert 0 == len(event_source._handlers)

    # call __iadd__
    event_source += _handler
    assert 1 == len(event_source._handlers)

    # call __iadd__ again
    event_source += _handler
    assert 1 == len(event_source._handlers)


# Generated at 2022-06-11 17:35:48.569164
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Sender:
        def send(self, val1, val2):
            return val1, val2

    s = Sender()
    evt = _EventSource()
    evt += s.send

    evt.fire('foo', 'bar')

    evt -= s.send
    evt.fire('foo', 'bar')


# Generated at 2022-06-11 17:35:51.123686
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from collections import namedtuple

    es = _EventSource()
    es += namedtuple('Test', 'test').test  # type: ignore



# Generated at 2022-06-11 17:35:59.488842
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class fire_EventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    class FooException(Exception):
        pass

    class BarException(Exception):
        pass

    foo = [0]
    bar = [0]

    def handler1():
        foo[0] += 1

    def handler2():
        foo[0] += 1
        raise FooException

    def handler3():
        foo[0] += 1
        raise BarException

    def handler4():
        bar[0] += 1

    event_source = fire_EventSource()
    event_source += handler1
    event_source += handler1
    event_source += handler2
    event_source += handler3


# Generated at 2022-06-11 17:36:10.658087
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class MockEventSource(_EventSource):
        def __init__(self):
            super(MockEventSource, self).__init__()
            self.fired = []
            self.raised = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.raised.append((handler, exc, args, kwargs))
            return False

    class MockHandler:
        def __init__(self):
            self.fired = []

        def __call__(self, *args, **kwargs):
            self.fired.append((args, kwargs))

    # test with empty event source
    es = MockEventSource()
    es.fire(1, 2, 3)
    assert es.fired == []
    assert es.raised == []

    h1 = MockHandler()

    # test

# Generated at 2022-06-11 17:36:22.437331
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSource_Tester(object):
        def __init__(self):
            self._fire_result = False

        def __call__(self, *args, **kwargs):
            self._fire_result = True

    tester = _EventSource_Tester()
    event = _EventSource()
    event += tester

    with pytest.raises(ValueError):
        event += 'not_callable'

    with pytest.raises(ValueError) as excinfo:
        event += tester

    assert 'has already been added' in str(excinfo.value)

    event.fire()
    assert tester._fire_result is True
    tester._fire_result = False

    event -= 'not_callable'
    event.fire()
    assert tester._fire_result is True
    tester

# Generated at 2022-06-11 17:36:32.625228
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventArgs:
        pass

    args = EventArgs()

    def handler1(args):
        args.result1 = 1

    def handler2(args):
        args.result2 = 2
        raise Exception

    def handler3(args):
        args.result3 = 3

    def handler4(args):
        args.result4 = 4
        raise Exception

    e = _EventSource()
    e += handler1
    e += handler2
    e += handler3
    e += handler4
    e.fire(args)

    assert hasattr(args, 'result1')
    assert args.result1 == 1
    assert hasattr(args, 'result2')
    assert args.result2 == 2
    assert hasattr(args, 'result3')
    assert args.result3 == 3

# Generated at 2022-06-11 17:36:40.033838
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Target(object):
        def __init__(self):
            self.call_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1

    target = Target()

    events = _EventSource()
    events += target

    assert target.call_count == 0
    events.fire('test_arg', test_kwarg='test_arg')
    assert target.call_count == 1

    events -= target

    # no handlers, so no calls
    events.fire('test_arg', test_kwarg='test_arg')
    assert target.call_count == 1



# Generated at 2022-06-11 17:36:45.832470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    # validation step
    assert not event_source._handlers

    def handler(value):
        return value
    event_source += handler

    # validation step
    assert event_source._handlers

    value = 'foo'
    assert event_source.fire(value) == value

    # validation step
    event_source -= handler

    # validation step
    assert not event_source._handlers



# Generated at 2022-06-11 17:36:48.238185
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _event = _EventSource()
    _event += lambda *args, **kwargs: None
    _event.fire()



# Generated at 2022-06-11 17:36:53.164518
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    with pytest.raises(ValueError):
        event_source += 'not_callable'

    def dummy_handler():
        pass

    assert dummy_handler not in event_source._handlers

    assert event_source._handlers == set()

    event_source += dummy_handler

    assert dummy_handler in event_source._handlers

    assert event_source._handlers == {dummy_handler}



# Generated at 2022-06-11 17:37:14.409080
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def handler():
        return 'foo'

    assert event._handlers == set()

    event += handler

    assert event._handlers == {handler}

    # can't add the same handler twice
    try:
        event += handler
    except ValueError:
        pass
    else:
        raise AssertionError('did not raise ValueError adding the same handler twice')

    assert event._handlers == {handler}

    # can't add a non-callable
    try:
        event += 'foo'
    except ValueError:
        pass
    else:
        raise AssertionError('did not raise ValueError adding a non-callable')

    assert event._handlers == {handler}



# Generated at 2022-06-11 17:37:15.657897
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _EventSource().__iadd__(lambda x: 42)


# Generated at 2022-06-11 17:37:22.684782
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Wrapper:
        def __init__(self, value):
            self.value = value

        def __call__(self, *args, **kwargs):
            return self.value

    a = Wrapper(1)
    b = Wrapper(2)
    c = Wrapper(3)

    source = _EventSource()
    source += a
    source += b
    source += c

    assert source.fire() == [1, 2, 3]



# Generated at 2022-06-11 17:37:26.901141
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    # add a callable function
    def handler(x):
        pass
    es += handler

    # should raise ValueError
    with pytest.raises(ValueError):
        es += 'notcallable'



# Generated at 2022-06-11 17:37:34.593114
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1():
        raise ZeroDivisionError()

    def handler2():
        raise RuntimeError()

    def handler3():
        raise SyntaxError()

    source = _EventSource()

    source += handler1
    source += handler2
    source += handler3

    try:
        source.fire()
    except ZeroDivisionError:
        pass
    else:
        raise AssertionError('Expected ZeroDivisionError not raised')

    try:
        source.fire()
    except RuntimeError:
        pass
    else:
        raise AssertionError('Expected RuntimeError not raised')

    try:
        source.fire()
    except SyntaxError:
        pass
    else:
        raise AssertionError('Expected SyntaxError not raised')

# Generated at 2022-06-11 17:37:35.489325
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TODO: Add test
    assert False

# Generated at 2022-06-11 17:37:46.719704
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    global __test_handler_idx
    global __test_handlers
    __test_handler_idx = 0
    __test_handlers = []

    def __test_handler(*args, **kwargs):
        __test_handlers.append((__test_handler_idx, args, kwargs))

    event_source = _EventSource()
    args = ('foo', 'bar')
    kwargs = {'baz': 'qux'}
    for i in range(2):
        __test_handler_idx = i
        event_source += __test_handler
        event_source.fire(*args, **kwargs)
        event_source -= __test_handler
    assert __test_handlers == [(0, args, kwargs), (1, args, kwargs)]



# Generated at 2022-06-11 17:37:56.070241
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler1(*args, **kwargs):
        print('handler1', args, kwargs)

    def handler2(*args, **kwargs):
        print('handler2', args, kwargs)

    es = _EventSource()
    es += handler1
    es += handler2

    es.fire('arg1', 'arg2', 'arg3', key1='value1', key2='value2', key3='value3')

    es -= handler2

    es.fire('arg1', 'arg2', 'arg3', key1='value1', key2='value2', key3='value3')

# Generated at 2022-06-11 17:37:59.390926
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def func_to_call(a, b):
        fired.append((a, b))

    fired = []
    event_source = _EventSource()
    event_source += func_to_call

    event_source.fire(1, 2)
    assert (1, 2) in fired, 'invalid arguments not passed'

    event_source -= func_to_call
    event_source.fire(3, 4)
    assert (3, 4) not in fired, 'event should not have fired'


# Generated at 2022-06-11 17:38:06.870780
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_collections.ansible.builtin.plugins.module_utils.common import _EventSource

    class FakeHandler:
        def __init__(self):
            self._invocation_count = 0

        def __call__(self, *args, **kwargs):
            self._invocation_count += 1

        @property
        def invocation_count(self):
            return self._invocation_count

    class MyException(Exception):
        pass

    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return exc.__class__ is not MyException

    h1 = FakeHandler()
    h2 = FakeHandler()
    h3 = FakeHandler()

    sut = MyEventSource()
    sut += h1
    sut += h

# Generated at 2022-06-11 17:38:26.232625
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # type: () -> None

    from unittest import TestCase

    class _EventSourceTest(TestCase):
        def test_callback_exception(self):
            # type: () -> None

            event_source = _EventSource()

            def raise_value_error(*args, **kwargs):
                # type: (*Any, **Any) -> None
                raise ValueError('test function called correctly')

            event_source += raise_value_error

            with self.assertRaises(ValueError):
                event_source.fire()

    _ = _EventSourceTest()
    _EventSourceTest('test_callback_exception').test_callback_exception()

# Generated at 2022-06-11 17:38:29.291277
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    # Ensure that a ValueError is raised if the handler is not a callable
    try:
        event_source += 1
    except ValueError:
        pass

# Generated at 2022-06-11 17:38:38.636702
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """
    Verify that _EventSource works as expected
    :return: None
    """
    class TestEvent(object):

        def __init__(self):
            self.events_fired = []

        def handler(self, event, *args, **kwargs):
            self.events_fired.append(event)

    test_event = TestEvent()
    es = _EventSource()

    # test nothing to see here, move along
    es.fire('test')
    assert len(es._handlers) == 0
    assert test_event.events_fired == []

    # test single handler works
    es += test_event.handler
    es.fire('test')
    assert len(es._handlers) == 1
    assert test_event.events_fired == ['test']

    # test double handler works

# Generated at 2022-06-11 17:38:43.020419
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler(*args):
        pass

    es = _EventSource()
    es += handler
    es.fire()

    es -= handler
    es.fire()
    es += handler
    es.fire()

# Generated at 2022-06-11 17:38:53.684656
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class RecordableException(Exception):
        pass

    class CustomEventSource(_EventSource):

        def __init__(self, records):
            super(CustomEventSource, self).__init__()
            self._records = records

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._records.append((handler, exc, args, kwargs))
            if isinstance(exc, RecordableException):
                return False

        # This is a new method to support the unit test.  It is not part of the regular EventSource API.
        def _add_bad_handler(self, handler):
            self._handlers.add(handler)

    records = []
    e = CustomEventSource(records)

    # test simple case
    e.fire(1)

    # test multiply handlers


# Generated at 2022-06-11 17:39:01.865581
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class foo:
        def __init__(self):
            self.passed = False
            self.handled = False

        def handler(self, *args, **kwargs):
            self.passed = True
            return self.passed

    f = foo()
    event_source = _EventSource()
    event_source += f.handler
    event_source.fire()
    assert f.passed

    f = foo()
    event_source = _EventSource()
    event_source += f.handler
    event_source -= f.handler
    event_source.fire()
    assert not f.passed

    f = foo()
    event_source = _EventSource()
    event_source += f.handler
    try:
        event_source.fire()
    except Exception:
        f.handled = True

# Generated at 2022-06-11 17:39:11.761685
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    a = []
    def fn_1():
        a.append(1)
    def fn_x(x):
        a.append(x)
    def fn_xx(x, y):
        a.append(x)
        a.append(y)
    def fn_ex(x, y):
        raise Exception('test exception')

    es = _EventSource()
    es += fn_1
    es += fn_x
    es += fn_xx
    es += fn_ex

    es.fire()
    assert a == [1, None, None, None]

    es.fire(1)
    assert a == [1, None, None, None, 1, 1, None]

    es.fire(1, 2)

# Generated at 2022-06-11 17:39:22.617468
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import unittest
    import sys

    if sys.version_info >= (3, 4):
        class TestClass(unittest.TestCase):
            def test_fire(self):
                # Test for normal use
                def test_handler(x, y):
                    self.assertEqual(x, 42)
                    self.assertEqual(y, 'value')
                    self.assertTrue(handler_called)

                source = _EventSource()
                source += test_handler
                handler_called = False

                source.fire(42, y='value')
                handler_called = True

                # Test for exception in handler
                def test_handler_exception(x, y):
                    self.assertEqual(x, 42)
                    self.assertEqual(y, 'value')
                    raise RuntimeError('test exception')

                source

# Generated at 2022-06-11 17:39:27.447879
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import os
    from ansible_collections.ansible.builtin import load_collections

    # finder = load_collections()

    # def ppp(s):
    #     print(s)

    # AnsibleCollectionConfig.on_collection_load += ppp

    # finder.load_collections()

    # AnsibleCollectionConfig.on_collection_load -= ppp

# Generated at 2022-06-11 17:39:30.124678
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest

    class A:
        pass

    e = _EventSource()
    e += A
    assert A in e._handlers
    with pytest.raises(ValueError):
        e += A


# Generated at 2022-06-11 17:40:01.988648
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # No handlers
    class TestClass(object):
        pass
    cls = TestClass()
    cls.es = _EventSource()
    cls.es.fire()

    # No exceptions
    def handler():
        pass
    cls.es += handler
    cls.es.fire()

    # Exception that is not handled
    def handler_exception():
        raise AssertionError('Handler should not raise an exception')
    cls.es += handler_exception
    try:
        # Should raise
        cls.es.fire()
    except Exception as e:
        if str(e) != 'Handler should not raise an exception':
            raise Exception('Wrong exception raised: %s' % str(e))

    # Exception that is handled

# Generated at 2022-06-11 17:40:11.231344
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def f():
        pass

    def g():
        pass

    subject = _EventSource()

    subject += f
    assert len(subject._handlers) == 1
    assert f in subject._handlers
    assert g not in subject._handlers

    subject += g
    assert len(subject._handlers) == 2
    assert f in subject._handlers
    assert g in subject._handlers

    subject += f
    assert len(subject._handlers) == 2
    assert f in subject._handlers
    assert g in subject._handlers

    # if we use __iadd__ and do not catch exceptions,
    # we expect the exception to propagate and cause the test to fail
    def raises():
        raise Exception()

    subject += raises


# Generated at 2022-06-11 17:40:22.043413
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Test:
        def __init__(self):
            self.arg1 = None
            self.arg2 = None
            self.kwargs = None

        def handler1(self, arg1, arg2='bar', **kwargs):
            self.arg1 = arg1
            self.arg2 = arg2
            self.kwargs = kwargs

        def handler2(self, arg1, arg2='bar', **kwargs):
            self.arg1 = arg1
            self.arg2 = arg2
            self.kwargs = kwargs
            raise Exception

    evt = _EventSource()
    evt += _Test().handler1
    evt += _Test().handler2
    evt.fire('foo', 'bar', baz=True)

# Generated at 2022-06-11 17:40:26.428538
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def mybad_handler(event, arg):
        raise ValueError('%r' % arg)

    es = _EventSource()
    es += mybad_handler

    try:
        es.fire('foo')
    except ValueError:
        pass
    else:
        raise AssertionError('expected ValueError')

# Generated at 2022-06-11 17:40:37.072194
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test 1: no handlers
    es = _EventSource()
    es.fire()

    # test 2: one handler, no exception
    h1 = lambda: None
    es += h1
    es.fire()

    # test 3: two handlers, no exceptions
    h2 = lambda: None
    es += h2
    es.fire()

    # test 4: one handler, single exception
    es -= h2
    es.fire()
    es += h2

    # test 5: two handlers, one exception
    h2 = lambda: 1 / 0
    es.fire()

    # test 6: one handler, on_exception swallowing exception
    h1 = lambda: 1 / 0
    h2 = lambda: 1 / 0
    es._on_exception = lambda h, e, *a, **kw: False

# Generated at 2022-06-11 17:40:39.653233
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(msg, **kwargs):
        print(msg)

    event_source = _EventSource()
    event_source += handler
    event_source.fire('hello world')



# Generated at 2022-06-11 17:40:41.183706
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0



# Generated at 2022-06-11 17:40:48.639758
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    i = 0

    class _EventSourceTest(object):
        def __init__(self):
            self._handlers = set()

        def __iadd__(self, handler):
            if not callable(handler):
                raise ValueError('handler must be callable')
            self._handlers.add(handler)
            return self

        def __isub__(self, handler):
            try:
                self._handlers.remove(handler)
            except KeyError:
                pass

            return self

        def _on_exception(self, handler, exc, *args, **kwargs):
            return True


# Generated at 2022-06-11 17:40:58.869486
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    counter = 0
    es = _EventSource()

    def inc():
        nonlocal counter
        counter += 1

    def dec():
        nonlocal counter
        counter -= 1

    es += inc
    es += inc
    es += inc
    es += inc
    es += inc
    es += inc
    es += inc
    es += inc
    es += inc
    es += inc

    assert counter == 0
    es.fire()
    assert counter == 10

    es -= inc
    es -= inc
    es -= inc

    assert counter == 10
    es.fire()
    assert counter == 10

    es += dec
    es += dec
    es += dec

    assert counter == 10
    es.fire()
    assert counter == 7

# Generated at 2022-06-11 17:41:07.561854
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def do_nothing(*_args, **_kwargs):
        pass

    event_source += do_nothing
    assert len(event_source._handlers) == 1

    # noinspection PyTypeChecker
    try:
        event_source += 'foo'
    except ValueError:
        pass
    else:
        assert False

    assert len(event_source._handlers) == 1



# Generated at 2022-06-11 17:41:35.969192
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    aec_class = _AnsibleCollectionConfig
    aec_class.on_collection_load += print
    aec_class.on_collection_load.fire('hi')

# Generated at 2022-06-11 17:41:46.596644
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_exception(exc, *args, **kwargs):
        return False

    def handler_no_exception(*args, **kwargs):
        pass

    def handler_exception_raise(exc, *args, **kwargs):
        return True

    def handler_exception_error(*args, **kwargs):
        raise Exception('handler_exception_error')

    src = _EventSource()

    src._on_exception = handler_exception
    src.fire()

    src += handler_no_exception
    src.fire()

    src += handler_exception_error

# Generated at 2022-06-11 17:41:57.363871
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    eventsource = _EventSource()

    class MockEventListener():
        def __init__(self):
            self.called = False

        def handler(self, *args, **kwargs):
            # we should have received the args/kwargs passed to fire
            assert args == (1, 2, 3)
            assert kwargs == {'a': 1, 'b': 2, 'c': 3}

            # we should not yet have been called
            assert self.called is False

            self.called = True

    mock_event_listener = MockEventListener()

    eventsource += mock_event_listener.handler
    eventsource.fire(1, 2, 3, a=1, b=2, c=3)

    # we should have been called
    assert mock_event_listener.called is True



# Generated at 2022-06-11 17:42:06.452213
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def test(verbose):
        def fail_on_call(not_called=True):
            def inner():
                nonlocal not_called
                not_called = False
                raise RuntimeError('raised inside handler')
            return inner

        def always_raise():
            raise RuntimeError('raised inside handler')

        def never_raise():
            return None

        handlers = [fail_on_call(), always_raise, never_raise]
        events = _EventSource()

        for h in handlers:
            events += h

        try:
            events.fire()
        except RuntimeError:
            if not verbose:
                raise AssertionError('exception was raised!')
        if verbose:
            print('exception was raised as expected')


# Generated at 2022-06-11 17:42:08.685048
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    assert len(event._handlers) == 0
    event += lambda: None
    assert len(event._handlers) == 1


# Generated at 2022-06-11 17:42:18.779224
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that the event source does not raise an exception when no listeners have been registered
    event_source = _EventSource()
    event_source.fire('foo')
    event_source.fire('bar')

    # Test that the event source notifies a listener when an event is fired
    notification = []
    event_source += (lambda data: notification.append(data))
    event_source.fire('baz')
    assert notification == ['baz']

    # Test that the event source notifies multiple registered listeners when an event is fired
    notification = []
    event_source += (lambda data: notification.append(data))
    event_source.fire('quux')
    assert notification == ['quux', 'quux']

    # Test that the event source notifies multiple registered listeners when an event is fired
    notification = []

# Generated at 2022-06-11 17:42:25.315880
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Foo():
        def __init__(self):
            self.events = []

        def __call__(self, source, event):
            self.events.append(event)

    foo1 = Foo()
    foo2 = Foo()

    event_source = _EventSource()
    event_source += foo1
    event_source += foo2

    event_source.fire('event1')

    assert foo1.events == ['event1']
    assert foo2.events == ['event1']

# Generated at 2022-06-11 17:42:29.616609
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source = _EventSource()

    def handler1(x):
        print('handler1', x)

    def handler2(x):
        print('handler2', x)

    event_source += handler1
    event_source += handler2

    event_source.fire('foo')



# Generated at 2022-06-11 17:42:40.205144
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _Tester:
        def __init__(self):
            self._event_source = _EventSource()

        @property
        def on_event(self):
            return self._event_source

        def fire_event(self):
            self._event_source.fire()

    tester = _Tester()

    class _Handler:
        def __init__(self, name):
            self.name = name
            self.calls = []

        def __call__(self, *args, **kwargs):
            self.calls.append((args, kwargs))

    handler_A = _Handler('handler A')
    handler_B = _Handler('handler B')

    tester.on_event += handler_A
    tester.on_event += handler_B

    assert handler_A.calls == []


# Generated at 2022-06-11 17:42:42.209740
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e1 = _EventSource()
    e2 = _EventSource()
    e1 += e2
    assert e1 is e2


# Generated at 2022-06-11 17:43:48.363512
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _DummyEventSource(_EventSource):
        def __init__(self):
            super(_DummyEventSource, self).__init__()
            self.event_log = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.event_log.append(('on_exception', handler, exc))
            return True

    def handler_a(*args, **kwargs):
        pass

    def handler_b(*args, **kwargs):
        raise RuntimeError('test')

    def handler_c(*args, **kwargs):
        raise ValueError('test')

    source = _DummyEventSource()

    source.fire()
    assert source.event_log == []

    source += handler_a
    source.fire()
    assert source.event_log == []

   

# Generated at 2022-06-11 17:43:55.073490
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def _mock():
        pass

    # check that we can add a handler and it is called
    mock_called = []
    event = _EventSource()
    event += _mock
    event.fire(mock_called=mock_called)
    assert mock_called == [_mock]

    # check that trying to add a non-callable does not work
    try:
        event += 1
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 17:44:02.222650
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class E:
        def f1(self):
            self.g1 = True

        def f2(self):
            self.g2 = True
            raise ValueError('f2')

        def f3(self, arg):
            self.g3 = arg

        def f4(self, *args):
            self.g4 = args

        def f5(self, **kwargs):
            self.g5 = kwargs

        def f6(self, *args, **kwargs):
            self.g6 = args
            self.g7 = kwargs

    e = E()

    evt = _EventSource()

    evt += e.f1
    evt += e.f2
    evt += e.f3
    evt += e.f4
    evt += e.f5
   

# Generated at 2022-06-11 17:44:11.917715
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    x = _EventSource()

    result = []

    def handler1(a, b, c=None):
        result.append('handler1')
        result.append(a)
        result.append(b)
        result.append(c)

    def handler2(a, b, c=None):
        result.append('handler2')
        result.append(a)
        result.append(b)
        result.append(c)

    x += handler1
    x += handler2

    # positional args
    x.fire(1, 2, c=3)

    assert result == ['handler1', 1, 2, 3, 'handler2', 1, 2, 3]

    # named args
    result = []
    x.fire(b=2, a=1, c=3)


# Generated at 2022-06-11 17:44:15.883705
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def _handler0():
        pass

    def handler():
        pass

    target = _EventSource()
    target += _handler0

    assert target._handlers == {_handler0}

    target += handler

    assert target._handlers == {_handler0, handler}



# Generated at 2022-06-11 17:44:26.925010
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # test that __iadd__ requires that handler be callable
    es = _EventSource()
    def throw():
        raise Exception()
    es += throw
    try:
        es += None
        assert False
    except ValueError:
        pass

    # test that __iadd__ cannot be called twice on the same handler
    es = _EventSource()
    es += throw
    try:
        es += throw
        assert False
    except ValueError:
        pass

    # test that __isub__ does not fail for non-existent handler
    es = _EventSource()
    es -= throw

    # test that _on_exception works
    class Subclass(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    es = Subclass()
    es += throw