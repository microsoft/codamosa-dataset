

# Generated at 2022-06-11 17:34:34.777510
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()
    assert eventsource.fire() is None

    def f():
        pass
    eventsource += f
    assert eventsource.fire() is None

    def g(x):
        pass
    eventsource += g
    assert eventsource.fire() is None
    assert eventsource.fire(x='x') is None

    def h():
        raise RuntimeError("h")
    eventsource += h
    try:
        eventsource.fire()
        assert False
    except RuntimeError as ex:
        assert str(ex) == "h"

    # This is how we actually test the _on_exception method.
    # Subclasses can override it to do something interesting.
    class Foo(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

# Generated at 2022-06-11 17:34:37.041694
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += "foobar"
    assert event_source._handlers == set(['foobar'])


# Generated at 2022-06-11 17:34:40.426204
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler1 = lambda: None
    handler2 = lambda: None

    event_source += handler1
    event_source += handler2

    assert event_source._handlers == set([handler1, handler2])


# Generated at 2022-06-11 17:34:43.608445
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_frame = {}
    event_source = _EventSource()
    event_source += test_frame.update

    event_source.fire(a=1, b=2, c=3)
    assert test_frame == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-11 17:34:49.596804
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test value returned by event handler
    class Handler1:
        def __call__(self, *args, **kwargs):
            return None

    handler1 = Handler1()
    event = _EventSource()
    with event:
        event += handler1
        event.fire()

    # test Exception raised by event handler
    class Handler2:
        def __call__(self, *args, **kwargs):
            raise AttributeError()

    handler2 = Handler2()
    event = _EventSource()
    with event:
        event += handler2
        try:
            event.fire()
            assert False
        except AttributeError:
            pass



# Generated at 2022-06-11 17:34:55.595029
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    class CountEvents:
        def __init__(self):
            self.events = 0
        def inc(self):
            self.events += 1
    c = CountEvents()
    event_source.fire()
    assert c.events == 0
    event_source += c.inc
    event_source.fire()
    assert c.events == 1
    event_source -= c.inc
    event_source.fire()
    assert c.events == 1


# Generated at 2022-06-11 17:35:00.276338
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Given
    class Callback:
        def __init__(self):
            self.value = None

        def callback(self, value):
            self.value = value

    callback = Callback()
    my_event = _EventSource()
    my_event += callback.callback

    # given a callable whi

# Generated at 2022-06-11 17:35:09.796822
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self, a):
            self.a = a

        def foo(self, *args, **kwargs):
            return self.a

    def do_test(_EventSource, expected_result, expected_warning=None):
        a = Test('foo')
        b = Test('bar')

        _EventSource += a.foo

        result = _EventSource.fire()
        assert result == expected_result, "Unexpected result %s, expected result %s" % (result, expected_result)

        _EventSource += b.foo

        result = _EventSource.fire()
        assert result == expected_result, "Unexpected result %s, expected result %s" % (result, expected_result)

        _EventSource -= a.foo

        result = _EventSource.fire()
        assert result == expected

# Generated at 2022-06-11 17:35:18.200385
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()

    def handler(arg):
        pass

    def exception_handler(arg):
        raise ValueError('exception')

    class exception_handler_class(object):
        @classmethod
        def handler(cls, arg):
            raise ValueError('exception')

    e.fire()

    e += handler
    e.fire()

    e += exception_handler
    e.fire()

    e -= exception_handler
    e.fire()

    e += exception_handler_class.handler
    e.fire()

# Generated at 2022-06-11 17:35:27.943805
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    handlers = {}
    event = _EventSource()
    for i in range(10):
        def h(x, y): return x + y
        h.__name__ = 'h%d' % i
        handlers[h] = h
        event += h
    assert set(handlers.values()) == event._handlers

    event += event  # adding an EventSource has no effect
    assert set(handlers.values()) == event._handlers

    def h(x): return x
    h.__name__ = 'h'
    event += h
    handlers[h] = h
    assert set(handlers.values()) == event._handlers

    event += 123  # adding a non-callable raises the expected ValueError
    event += 'abc'  # adding a non-callable raises the expected ValueError


# Generated at 2022-06-11 17:35:40.082498
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import mock
    import pytest
    import sys
    import traceback

    #
    # handler is always callable
    #
    event_source = _EventSource()
    event_source += lambda: None
    event_source.fire()
    #
    # handler is not callable
    #
    with pytest.raises(ValueError):
        event_source += 5
    #
    # handler throws exception
    #
    handler_mock = mock.Mock()
    event_source += handler_mock
    # exception from handler is not swallowed
    with pytest.raises(Exception):
        handler_mock.side_effect = Exception('I am an exception')
        event_source.fire()
    #
    # handler throws exception and on_exception returns true
    #

# Generated at 2022-06-11 17:35:50.022368
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Exercise
    event_source = _EventSource()
    a = []

    def handler1(*args, **kwargs):
        a.extend(args)
        a.extend(kwargs.values())

    def handler2(*args, **kwargs):
        raise ValueError()

    def handler3(*args, **kwargs):
        a.append('FILLER')

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire(1, key1='val1')

    # Verify
    assert sorted(a) == [1, 'FILLER', 'val1']


# Generated at 2022-06-11 17:35:50.546375
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    es.fire()

# Generated at 2022-06-11 17:35:59.180610
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def increment(c):
        c[0] += 1

    def decrement(c):
        c[0] -= 1

    def raise_exception(c):
        raise Exception('expected')

    def handler(c, h, exc):
        # if we return True, we want the caller to re-raise
        return False

    c = [0]
    es = _EventSource()

    es._on_exception = handler

    # no handlers queued yet
    es.fire(c)
    assert 0 == c[0]

    # single handler
    es += increment
    es.fire(c)
    assert 1 == c[0]

    # multiple handlers
    es += decrement
    es.fire(c)
    assert 0 == c[0]

    # remove handler
    es -= decrement
    es.fire

# Generated at 2022-06-11 17:36:10.357386
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def fire_handler():
        nonlocal fire_handler_invokes
        fire_handler_invokes += 1

    def fire_handler_exception():
        nonlocal fire_handler_exception_invokes
        fire_handler_exception_invokes += 1
        raise Exception('fire')

    fire_handler_invokes = 0
    fire_handler_exception_invokes = 0

    ansible_collection_config = AnsibleCollectionConfig()

    ansible_collection_config._on_collection_load += fire_handler
    ansible_collection_config._on_collection_load += fire_handler_exception
    ansible_collection_config._on_collection_load += fire_handler

    assert ansible_collection_config._on_collection_load._handlers == {fire_handler, fire_handler_exception}

    ansible_

# Generated at 2022-06-11 17:36:14.329846
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler(*args, **kwargs):
        pass

    e = _EventSource()
    assert e._handlers == set()

    e += handler
    assert e._handlers == {handler}

    e += handler
    assert e._handlers == {handler}


# Generated at 2022-06-11 17:36:18.870675
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    counter = []
    event = _EventSource()

    def event_handler(x):
        counter.append(x)

    event += event_handler

    event.fire(1)
    event.fire(2)
    event.fire(3)

    assert counter == [1, 2, 3]


# Generated at 2022-06-11 17:36:27.769297
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def foo(event_source, *args, **kwargs):
        assert event_source is mock_event_source
        assert args == ('bar',)
        assert kwargs == {'baz': None}

    mock_event_source = _EventSource()
    mock_event_source.fire('bar', baz=None)

    mock_event_source += foo
    mock_event_source.fire('bar', baz=None)

# Test the two collection load event functions in the collection loader.

# Generated at 2022-06-11 17:36:34.995857
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(a, b):
        pass

    def handler2(a, b, c):
        pass

    function_result = event_source.__iadd__(handler1)
    assert event_source._handlers == set([handler1])
    assert function_result is event_source

    with_metaclass_result = event_source.__iadd__(handler2)
    assert event_source._handlers == set([handler1, handler2])
    assert with_metaclass_result is event_source


# Generated at 2022-06-11 17:36:44.272838
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test that exceptions are properly handled and re-raised (or not)
    test_event_source = _EventSource()
    def exc_handler(exc, *args, **kwargs):
        if not isinstance(exc, Exception):
            raise NotImplementedError('invalid type for exc: %s' % exc)
        if not isinstance(args, tuple):
            raise NotImplementedError('invalid type for args: %s' % args)
        if not isinstance(kwargs, dict):
            raise NotImplementedError('invalid type for kwargs: %s' % kwargs)
        if isinstance(exc, RuntimeError):
            return False

        return True

    test_event_source._on_exception = exc_handler


# Generated at 2022-06-11 17:37:01.743700
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # first handler is called
    it_reached_1 = False
    def handler_1(*args, **kwargs):
        assert tuple(args) == (1, 2)
        assert dict(kwargs) == dict(a=3, b=4)
        nonlocal it_reached_1
        it_reached_1 = True

    # second handler is called
    it_reached_2 = False
    def handler_2(*args, **kwargs):
        assert tuple(args) == (1, 2)
        assert dict(kwargs) == dict(a=3, b=4)
        nonlocal it_reached_2
        it_reached_2 = True

    # third handler is called but raises an exception
    it_reached_3 = False

# Generated at 2022-06-11 17:37:09.018689
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # arrange
    event = _EventSource()

    stub_handler_1 = lambda s, msg: None  # noqa: E731
    stub_handler_2 = lambda s, msg: None  # noqa: E731
    stub_handler_3 = lambda s, msg: None  # noqa: E731

    event += stub_handler_1
    event += stub_handler_2
    event += stub_handler_3

    # act
    event.fire('test message 1')
    event.fire('test message 2')

    # assert

if __name__ == '__main__':
    test__EventSource_fire()

# Generated at 2022-06-11 17:37:18.281933
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler_1(*args, **kwargs):
        print('handler_1:', args, kwargs)

    def handler_2(*args, **kwargs):
        print('handler_2:', args, kwargs)

    event_source = _EventSource()
    event_source += handler_1
    event_source += handler_2

    event_source.fire(category='playbook', data='playbook_data')
    event_source.fire(category='playbook', data='playbook_data')

    # remove handler_1 from the set of handlers
    event_source -= handler_1

    print('===' * 10)
    event_source.fire(category='playbook', data='playbook_data')


# Generated at 2022-06-11 17:37:26.858225
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def test_handler():
        pass

    event_source = _EventSource()

    # test with good handler
    event_source += test_handler
    assert len(event_source._handlers) == 1
    assert test_handler in event_source._handlers

    # test with non-callable
    msg = 'handler must be callable'
    try:
        event_source += 'test_handler'
    except ValueError as err:
        assert str(err) == msg
    else:
        assert False, 'ValueError should be raised'



# Generated at 2022-06-11 17:37:30.150249
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def test(*args, **kwargs):
        print('args=%s, kwargs=%s' % (args, kwargs))

    es = _EventSource()
    es += test

    es.fire(1,2,3, a=1, b=2)

# Generated at 2022-06-11 17:37:33.382899
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    e = _EventSource()
    e += Test()
    e.fire()



# Generated at 2022-06-11 17:37:34.227169
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    raise NotImplementedError()


# Generated at 2022-06-11 17:37:40.400624
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    def test_handler():
        pass

    event_source += test_handler
    assert test_handler in event_source._handlers

    event_source += test_handler
    assert len(event_source._handlers) == 1

    event_source -= test_handler
    assert len(event_source._handlers) == 0

    with_metaclass(type, _EventSource)


# Generated at 2022-06-11 17:37:48.246824
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    events = _EventSource()

    result1 = [0]
    def event1(value):
        result1[0] += value

    result2 = [0]
    def event2(value):
        result2[0] += value

    events += event1
    events += event2

    events.fire(value=1)
    assert result1[0] == 1
    assert result2[0] == 1

    events -= event1
    events.fire(value=1)
    assert result1[0] == 1
    assert result2[0] == 2


# Generated at 2022-06-11 17:37:55.739713
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create a _EventSource object
    events = _EventSource()

    # Create a mock handler
    calls = []
    def mock_handler(*args, **kwargs):
        calls.append((args, kwargs))

    # Add the mock handler to the object
    events += mock_handler

    # Fire the mock handler with arguments 'a' and 'b'
    events.fire('a', 'b')

    # Verify the mock handler was called correctly
    assert calls == [(('a', 'b'), {})]



# Generated at 2022-06-11 17:38:12.704325
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    n = 0
    es += lambda: setattr(test__EventSource_fire, 'n', n + 1)
    es += lambda: setattr(test__EventSource_fire, 'n', n + 2)
    es.fire()
    assert test__EventSource_fire.n == 2


# Generated at 2022-06-11 17:38:17.647898
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def foo(bar, baz='blah', bam='baz'):
        pass

    event += foo
    event.fire(bar=1, baz=2, bam=3)
    assert len(event._handlers) == 1
    event -= foo
    assert len(event._handlers) == 0
    event.fire(bar=1, baz=2, bam=3)



# Generated at 2022-06-11 17:38:26.457589
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Method fire is called and handlers are called, nothing happens
    def test__EventSource_fire_normal():
        event_source = _EventSource()

        def handler1(value):
            return value

        def handler2(value):
            return value

        event_source += handler1
        event_source += handler2

        value = 1

        result = event_source.fire(value)

        assert result is None

    # Method fire is called and one of handler throws Exception, exception will be re-raised
    def test__EventSource_fire_raise_exception():
        event_source = _EventSource()

        exception = Exception()

        def handler1(value):
            raise exception

        def handler2(value):
            return value

        event_source += handler1
        event_source += handler2

        value = 1


# Generated at 2022-06-11 17:38:36.213768
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(*args, **kwargs):
        args[0]['handled'] = args[0].get('handled', [])
        args[0]['handled'].append(handler)

    def handler_with_exception(*args, **kwargs):
        raise

    def handler_that_swallows_exception(*args, **kwargs):
        pass

    def on_exception(handler, exc, *args, **kwargs):
        args[0]['on_exception'] = args[0].get('on_exception', [])
        args[0]['on_exception'].append(handler)
        return False

    s = _EventSource()
    s += handler
    s._on_exception = on_exception

    d = {}
    s.fire(d)

# Generated at 2022-06-11 17:38:48.190483
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Consumer(object):
        _fired = None

        def __call__(self, value):
            self._fired = value

        def get_fired(self):
            return self._fired

    source = _EventSource()

    # test that nothing happens if no handlers are registered
    source.fire('alpha')

    # adding a handler
    consumer = _Consumer()
    source += consumer

    # test that the handler gets called
    source.fire('beta')
    assert consumer.get_fired() == 'beta'

    # test that a handler is only called once, even when added twice
    source += consumer
    source.fire('gamma')
    assert consumer.get_fired() == 'gamma'

    # test that removing a handler no longer causes it to receive events
    source -= consumer
    source.fire('delta')
    assert consumer

# Generated at 2022-06-11 17:38:58.272858
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class F(object):
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    e = _EventSource()

    f1 = F()
    f2 = F()
    f3 = F()
    f4 = F()
    f5 = F()
    f6 = F()

    e += f1
    e += f2
    e += f3

    e.fire()
    assert f1.called
    assert f2.called
    assert f3.called
    assert not f4.called
    assert not f5.called
    assert not f6.called

    f1.called = False
    f2.called = False
    f3.called = False
    f4.called = False
    f

# Generated at 2022-06-11 17:39:03.136520
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _h1 = lambda: None
    _h2 = lambda: None
    _event_source = _EventSource()
    _event_source += _h1
    _event_source += _h1
    _event_source += _h2

    assert len(_event_source._handlers) == 2
    assert _h1 in _event_source._handlers
    assert _h2 in _event_source._handlers



# Generated at 2022-06-11 17:39:05.525500
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler(a, b):
        return a + b

    event = _EventSource()

    event += handler

    result = event.fire(1, 2)

    assert result == 3, result

# Generated at 2022-06-11 17:39:08.127365
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    events = _EventSource()
    events += lambda x: x
    events += lambda x: x

    assert len(events._handlers) == 2

# Generated at 2022-06-11 17:39:14.488858
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(a, b, exc=None):
        return a, b

    event = _EventSource()
    event += handler
    assert event.fire(1, 2) == (1, 2)

    def handler(a, b, exc=None):
        raise ValueError()

    event += handler
    try:
        event.fire(1, 2)
    except ValueError:
        pass
    else:
        assert 0


# Generated at 2022-06-11 17:39:47.924092
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()
    event1_counter = [0]
    event2_counter = [0]

    def event1_handler(one, two, three, four=None):
        assert one == 1
        assert two == 2
        assert three == 3
        assert four == 4
        event1_counter[0] += 1

    def event2_handler(one):
        assert one == 1
        event2_counter[0] += 1

    eventsource += event1_handler
    eventsource += event2_handler

    eventsource.fire(1, 2, 3, four=4)
    assert event1_counter == [1]
    assert event2_counter == [1]



# Generated at 2022-06-11 17:39:52.894040
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    # validate that the correct error is raised when the parameter is not callable
    try:
        event_source.__iadd__('invalid handler')
    except ValueError as ex:
        assert str(ex) == 'handler must be callable'



# Generated at 2022-06-11 17:39:59.348133
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    on_collection_load_handlers = set()

    def handler(*args, **kwargs):
        on_collection_load_handlers.add((args, kwargs))
        return handler

    event_source = _EventSource()
    event_source += handler
    event_source.fire(1, 2, arg=3)

    assert len(on_collection_load_handlers) == 1
    assert on_collection_load_handlers == {((1, 2), {'arg': 3})}



# Generated at 2022-06-11 17:40:03.442998
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    def handler(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
    e += handler
    e.fire(1, 2, 3)

# Generated at 2022-06-11 17:40:05.500558
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def f():
        pass
    x = _EventSource()

    assert callable(f)
    x += f


# Generated at 2022-06-11 17:40:12.119671
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockHandler(object):
        def __init__(self):
            self.log = []

        def handle(self, *args, **kwargs):
            self.log.append((args, kwargs))

    es = _EventSource()

    mh1 = MockHandler()
    mh2 = MockHandler()
    mh3 = MockHandler()

    es += mh1.handle
    es += mh2.handle
    es += mh3.handle

    es.fire(1, 2, foo='bar')

    assert mh1.log == [(tuple(), {'foo': 'bar'})]
    assert mh1.log == mh2.log
    assert mh1.log == mh3.log

    es -= mh1.handle


# Generated at 2022-06-11 17:40:22.804679
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _Foo:
        def __init__(self):
            self._handler_called = False

        def _bar(self, x):
            self._handler_called = True

    def _on_exception(handler, exc, *args, **kwargs):
        handler_ex = None
        return handler_ex

    foo = _Foo()

    # test no handlers
    es = _EventSource()
    es._on_exception = _on_exception
    es.fire('foo', bar='baz')

    # test no exceptions
    es += foo._bar
    es.fire('foo', bar='baz')
    assert foo._handler_called

    # test exception in handler
    foo._handler_called = False


# Generated at 2022-06-11 17:40:26.739998
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    events = []

    test_handler = lambda x: events.append(x)

    event_source += test_handler

    event_source.fire('test_arg')

    assert events == ['test_arg']



# Generated at 2022-06-11 17:40:37.292396
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_that_raises(exc):
        def handler(*args, **kwargs):
            raise exc

        return handler

    # we want to verify that the _on_exception callback gets called and
    # returns True to re-raise the exception from the handler
    def on_exception(self, handler, exc, *args, **kwargs):
        self._on_exception_called = True
        return True

    exc = Exception('test exception')

    s = _EventSource()
    s.on_exception = on_exception

    s += handler_that_raises(exc)

    try:
        s.fire()
    except Exception as ex:
        assert ex == exc
        assert s._on_exception_called
    else:
        raise AssertionError('no exception was raised')

# Generated at 2022-06-11 17:40:45.801182
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class CalledParameters:
        def __init__(self):
            self.clear()

        def clear(self):
            self.args = None
            self.kwargs = None

    class CalledTimes:
        def __init__(self):
            self.clear()

        def clear(self):
            self.times = 0

    class Target:
        def __init__(self):
            self._called_parameters = CalledParameters()
            self._called_times = CalledTimes()

        def __call__(self, *args, **kwargs):
            self._called_parameters.args = args
            self._called_parameters.kwargs = kwargs
            self._called_times.times += 1


# Generated at 2022-06-11 17:41:24.105196
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class NoopEventHandler(object):
        def __init__(self):
            self.fired = False
        def __call__(self, *args, **kwargs):
            self.fired = True

    class ValueErrorEventHandler(object):
        def __init__(self):
            self.fired = False
            self.fired_on_value_error = False
        def __call__(self, *args, **kwargs):
            self.fired = True
            raise ValueError('expected exception')
        def _on_exception(self, handler, exc, *args, **kwargs):
            self.fired_on_value_error = True
            return False

    # 1: no handler added
    es = _EventSource()
    es.fire()

    # 2: one NoopEventHandler added, should fire

# Generated at 2022-06-11 17:41:35.185672
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class AssertAwareEventSource(_EventSource):
        def __init__(self):
            super(AssertAwareEventSource, self).__init__()
            self.expect_exception = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            if self.expect_exception:
                assert exc == self.expect_exception
                return False

            raise AssertionError('Did not expect exception: %s' % (exc))

    es = AssertAwareEventSource()

    calls = []

    def handler(msg):
        calls.append(msg)

    es += handler
    es.fire('Hello')
    assert calls == ['Hello']

    es.expect_exception = ValueError('test error')

# Generated at 2022-06-11 17:41:43.383637
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import unittest

    class TestEventSource(unittest.TestCase):
        def setUp(self):
            self.event_source = _EventSource()
            self.event_source += self.true_func
            self.event_source += self.false_func

        def tearDown(self):
            del self.event_source

        def true_func(self, *args, **kwargs):
            return True

        def false_func(self, *args, **kwargs):
            return False

    unittest.main()

# Generated at 2022-06-11 17:41:49.015465
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def h1(*args, **kwargs):
        pass

    def h2(*args, **kwargs):
        pass

    def h3(*args, **kwargs):
        pass

    event_source = _EventSource()
    event_source += h1
    event_source += h2
    event_source += h3

    event_source.fire()

    event_source -= h1
    event_source -= h2

    event_source.fire()


# Generated at 2022-06-11 17:41:51.933617
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler(value):
        return value

    event_source = _EventSource()

    event_source += handler

    assert event_source._handlers == {handler}


# Generated at 2022-06-11 17:42:02.688067
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a, b, c, d):
        assert a == 1
        assert b == 2
        assert c == 3
        assert d == 4

    def handler2(a, b, c, d):
        assert a == 1
        assert b == 2
        assert c == 3
        assert d == 4

        raise ValueError('expected')

    def handler3(a, b, c, d):
        assert a == 1
        assert b == 2
        assert c == 3
        assert d == 4

    # This method should not be called, since handler2 raises an exception
    def handler4(a, b, c, d):
        assert False

    e = _EventSource()
    e += handler1
    e += handler2
    e += handler3
    e += handler4

    # remove handler2 and handler4 after testing


# Generated at 2022-06-11 17:42:08.745928
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # handler function
    def h(value):
        data.append(value)

    # instance of class _EventSource
    es = _EventSource()

    # register handler
    es += h
    assert len(es._handlers) == 1
    assert h in es._handlers

    # fire event
    data = []
    es.fire(1)
    assert len(data) == 1
    assert data[0] == 1

    # unregister handler
    es -= h
    assert len(es._handlers) == 0

    # fire event
    data = []
    es.fire(1)
    assert len(data) == 0
    assert data == []

# Generated at 2022-06-11 17:42:18.844888
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import unittest
    import ansible.module_utils.common.text.converters as cv

    class _TestHandler1:
        def __call__(self, *args, **kwargs):
            _TestHandler1.invocations += 1

    class _TestHandler2:
        def __call__(self, *args, **kwargs):
            raise ValueError

    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    class _TestEventSourceReraise(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return True


# Generated at 2022-06-11 17:42:24.684054
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def on_collection_load(collection_name, collection_version, collection_path):
        print("%s:%s:%s" % (collection_name, collection_version, collection_path))

    AnsibleCollectionConfig.on_collection_load += on_collection_load
    AnsibleCollectionConfig.on_collection_load.fire("ns.c1", "1.0.0", "/path/1.0.0")

# Generated at 2022-06-11 17:42:33.510461
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def foo_handlder(s):
        print("foo handler called with " + s)

    def bar_handler(s):
        print("bar handler called with " + s)

    event = _EventSource()
    event += foo_handlder
    event += bar_handler
    event -= foo_handlder
    # only bar_handler should be called
    event.fire("test_string")
    # when foo_handler was removed, bar_handler should still be called
    event.fire("test_string2")
    # expect foo_handler to not be called because it wasn't added back
    event.fire("test_string3")

# Unit tests for class _AnsibleCollectionConfig

# Generated at 2022-06-11 17:43:36.170723
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_source = _EventSource()

    def handler_a():
        print('In handler_a')

    def handler_b():
        print('In handler_b')

    def handler_c():
        raise RuntimeError('In handler_c')

    def handler_d():
        print('In handler_d')

    def handler_e():
        print('In handler_e')

    def handler_f():
        print('In handler_f')

    # test add
    test_source += handler_a
    test_source += handler_b
    test_source += handler_c
    test_source += handler_d
    test_source += handler_e
    test_source += handler_f

    # test call
    test_source.fire()

    # test remove
    test_source -= handler_a

# Generated at 2022-06-11 17:43:46.691694
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Foo:
        def handler(self, *args, **kwargs):
            self.args, self.kwargs = args, kwargs

        def handler_fail(self, *args, **kwargs):
            1 / 0

    foo = Foo()
    es = _EventSource()
    es += foo.handler
    es.fire(1, a=2)

    assert foo.args == (1,)
    assert foo.kwargs == {'a': 2}

    es += foo.handler_fail
    try:
        es.fire(1, a=2)
        assert False, 'expected exception was not raised'
    except ZeroDivisionError:
        pass

# Generated at 2022-06-11 17:43:57.369339
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # No handler
    x = _EventSource()
    assert x._handlers == set()
    x.fire()

    # Single handler
    def handler():
        handler.call_count += 1
    handler.call_count = 0
    x += handler
    assert handler in x._handlers
    x.fire()
    assert handler.call_count == 1

    # Multiple handlers
    def handler2():
        handler2.call_count += 1
    handler2.call_count = 0
    x += handler2
    assert handler2 in x._handlers
    x.fire()
    assert handler.call_count == 2
    assert handler2.call_count == 1

    # Remove a handler
    x -= handler
    assert handler not in x._handlers
    x.fire()
    assert handler.call_count == 2
   

# Generated at 2022-06-11 17:44:07.921371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_one():
        handler_one._count += 1

    handler_one._count = 0

    def handler_two():
        handler_two._count += 1
        return 'handler2'

    handler_two._count = 0

    class HandlerThree:
        def __init__(self):
            self._count = 0

        def __call__(self):
            self._count += 1
            raise ValueError('error in handler3')

    h3 = HandlerThree()

    def handler_four():
        handler_four._count += 1
        raise ValueError('error in handler4')

    handler_four._count = 0

    def on_exception(handler, exc, *args, **kwargs):
        return False

    # Instance setUp
    event = _EventSource()
    event += handler_one
    event += handler

# Generated at 2022-06-11 17:44:12.285781
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    event_source = _EventSource()

    event_source += handler1
    event_source += handler2

    event_source.fire(1, 2, 3)


# Generated at 2022-06-11 17:44:23.086516
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class testee:
        def __init__(self):
            # this is the tested _EventSource
            self.fired = _EventSource()

            # test that the more common += operator works for defining handlers
            self.fired += self.handle_fired
            self.fired += self.handle_fired_with_exc

        def handle_fired(self, a, b):
            self.called = a, b

        def handle_fired_with_exc(self, a, b):
            raise ValueError('handled')

    fired = testee()
    fired.fired.fire(5, b=3)
    assert fired.called == (5, 3)
    del fired.called

    try:
        fired.fired.fire(5, b=4)
    except ValueError:
        pass
