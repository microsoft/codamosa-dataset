

# Generated at 2022-06-11 17:34:40.938827
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSource(_EventSource):
        def __init__(self):
            self.invocations = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.invocations.append(('_on_exception', handler, exc, args, kwargs))
            return True

    # test basic logic
    e = EventSource()
    events_fired = []
    def handler(*args, **kwargs):
        events_fired.append(('handler', args, kwargs))
    e += handler
    e.fire(1, 2, b=3)
    assert events_fired == [('handler', (1, 2), {'b': 3})]

    # check that exceptions in handler fire the on_exception logic
    e = EventSource()
    events_fired = []

# Generated at 2022-06-11 17:34:48.676304
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class MockOnCollectionLoad:
        def __init__(self, exc=None):
            self._exec = False
            self._exc = exc


        def __call__(self, collection, path):
            self._exec = True
            if self._exc:
                raise self._exc

    class MockCollectionConfig(_AnsibleCollectionConfig):
        def _on_exception(cls, handler, exc, *args, **kwargs):
            cls._last_exception = exc
            return False


    MockOnCollectionLoad._on_exception = MockCollectionConfig._on_exception

    config = MockCollectionConfig('foo', (object,), {})
    handler = MockOnCollectionLoad()
    config.on_collection_load += handler

# Generated at 2022-06-11 17:34:53.034714
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Foo():
        def __init__(self):
            self.x = 1

    # should not raise
    es = _EventSource()
    es += Foo().__init__

    # should not raise
    es = _EventSource()
    es += Foo().__init__
    es.fire()

    # should not raise
    es = _EventSource()
    es += Foo().__init__
    es.fire(1, 2, 3, four=4)

    # should raise ValueError because no handler is callable
    es = _EventSource()
    es += Foo()
    try:
        es.fire()
        raise AssertionError('expected ValueError')
    except ValueError:
        pass

# Generated at 2022-06-11 17:34:56.446875
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(*args, **kwargs):
        called.append((args, kwargs))

    called = []
    event = _EventSource()
    event += handler

    event.fire('a', c=1)
    assert len(called) == 1
    assert called[0] == ((('a',),), {'kwargs': {'c': 1}})

# Generated at 2022-06-11 17:35:02.646755
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    eventsource = _EventSource()

    class TestClass(object):
        def __init__(self):
            self.count = 0

        def call_back(self, *args, **kwargs):
            self.count += 1

    test_instance = TestClass()
    eventsource += test_instance.call_back
    # Act
    eventsource.fire()
    # Assert
    assert test_instance.count == 1



# Generated at 2022-06-11 17:35:06.596842
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    handler_called = False

    def handler(*args, **kwargs):
        nonlocal handler_called
        handler_called = True

    event = _EventSource()
    event.fire()
    assert not handler_called
    event += handler
    event.fire()
    assert handler_called

# Generated at 2022-06-11 17:35:13.047827
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    assert len(s._handlers) == 0

    try:
        s += 5
        assert False, 'expected ValueError'
    except ValueError:
        pass

    def h1(*args, **kwargs):
        pass

    s += h1
    assert len(s._handlers) == 1
    assert h1 in s._handlers

    def h2(*args, **kwargs):
        pass

    s += h2
    assert len(s._handlers) == 2
    assert h1 in s._handlers
    assert h2 in s._handlers

    s += h1
    assert len(s._handlers) == 2
    assert h1 in s._handlers
    assert h2 in s._handlers



# Generated at 2022-06-11 17:35:21.490703
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """
    Test to fire event handlers when an event fires
    """
    def on_collection_load(collection_name, collection_version, collection_path):
        print("Execution of the function")

    on_collection_load_handle = AnsibleCollectionConfig.on_collection_load.fire
    # Test the method by firing event handlers with some dummy data
    on_collection_load_handle(collection_name="collection_name", collection_version="collection_version",
                              collection_path="collection_path")


if __name__ == "__main__":
    test__EventSource_fire()

# Generated at 2022-06-11 17:35:31.630072
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    success_count = [0]

    def success_handlers(value):
        assert value == "fired"
        success_count[0] += 1

    def failure_handlers(value):
        assert value == "fired"
        assert False

    def exception_handlers(value):
        assert value == "fired"
        raise Exception("bad")

    source = _EventSource()
    source.fire("fired")

    source += success_handlers
    source.fire("fired")
    assert success_count[0] == 1

    source += failure_handlers
    try:
        source.fire("fired")
        assert False
    except AssertionError:
        pass

    source += exception_handlers
    try:
        source.fire("fired")
        assert False
    except Exception:
        pass

    assert success_count

# Generated at 2022-06-11 17:35:40.272613
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    result = []
    es += result.append
    es.fire(1, 2, 3)
    assert result == [1, 2, 3]
    result.clear()
    es += result.append
    es.fire(4, 5, 6, 7)
    assert result == [4, 5, 6, 7]
    es -= result.append
    es.fire(8, 9, 10)
    assert not result

    class MyError(Exception):
        pass

    result.clear()
    es = _EventSource()

    def handler(p1, p2, p3):
        assert p1 == 4
        assert p2 == 5
        assert p3 == 6
        result.append('handler')


# Generated at 2022-06-11 17:35:54.176340
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self, *args, **kwargs):
            super(_TestEventSource, self).__init__(*args, **kwargs)
            self._handlers = list()

    source = _TestEventSource()
    assert not source.fire()

    h1_runs = []
    def h1(*args, **kwargs):
        h1_runs.append((args, kwargs))

    source += h1
    assert not h1_runs
    assert not source.fire()
    assert (list(), dict()) in h1_runs
    assert None not in h1_runs

    h1_runs.clear()
    assert not h1_runs
    assert not source.fire(a=1)
    assert (list(), {'a': 1}) in h1_runs


# Generated at 2022-06-11 17:36:01.086568
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Collector:
        def __init__(self):
            self.events = []

        def handler(self, *args, **kwargs):
            self.events.append((args, kwargs))

    collector = Collector()
    event_source = _EventSource()
    event_source += collector.handler
    event_source.fire(1, 2, foo='bar')

    # verify we got the exact args and kwargs that were passed in
    assert collector.events == [(tuple(), dict(args=(1, 2), kwargs=dict(foo='bar')))]



# Generated at 2022-06-11 17:36:12.049342
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # On python < 2.7, the following won't work
    # class Foo(metaclass=AnsibleCollectionConfig): ...
    #
    # So if we're using python2, don't actually declare a new class
    if False:
        class Foo(AnsibleCollectionConfig):
            pass

    sut = _EventSource()

    def handler(x, y, z=None):
        return x + y + z

    sut += handler

    assert (Foo.on_collection_load.fire(1, y=2, z=3) == 6)

    x = object()

    def handler2(x, y, z=None):
        return x - y - z

    sut += handler2

    assert (sut.fire(x=10, y=6, z=1) == x-16)

    s

# Generated at 2022-06-11 17:36:23.636790
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ev = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    ev += handler1
    ev += handler2
    ev.fire()


if __name__ == '__main__':
    import sys
    import unittest

    class Test_EventSource_fire(unittest.TestCase):
        def test_no_handlers(self):
            ev = _EventSource()
            ev.fire()

        def test_one_handler(self):
            ev = _EventSource()
            results = dict(handler1_called=False)

            def handler1():
                results['handler1_called'] = True

            ev += handler1
            ev.fire()

            self.assertTrue(results['handler1_called'], 'handler1 did not fire')


# Generated at 2022-06-11 17:36:33.261516
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler1(*args, **kwargs):
        return 1

    def handler2(*args, **kwargs):
        raise Exception("Oops")

    # handler2 will be called.
    eventsource = _EventSource()
    eventsource += handler1
    eventsource += handler2

    with pytest.raises(Exception) as exc:
        eventsource.fire()

    assert str(exc.value) == 'Oops'

    def handler3(*args, **kwargs):
        raise Exception("oh no")

    # handler3 will be called, but handler2 won't
    eventsource += handler2
    eventsource.fire()

    eventsource += handler3
    with pytest.raises(Exception) as exc:
        eventsource.fire()
    assert str(exc.value) == 'oh no'


# Generated at 2022-06-11 17:36:41.902218
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        pass

    value = []
    def handler(a):
        value.append(a)

    # default behavior
    handler.side_effect = ValueError('test')
    src = MyEventSource()
    src += handler
    src.fire('a')
    assert value == ['a']

    # exception
    value[:] = []
    try:
        src.fire('b')
        assert False, 'should not reach'
    except ValueError:
        assert value == ['b']

    # _on_exception returns True, so exception is re-raised
    value[:] = []
    try:
        src.fire('c')
        assert False, 'should not reach'
    except ValueError:
        assert value == ['c']

    # _on_exception returns False, so exception

# Generated at 2022-06-11 17:36:49.383959
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # initialize a test object
    event = _EventSource()
    # test normal case of adding a function
    def test_func():
        pass
    event += test_func
    assert event._handlers
    # test adding a non-callable object
    non_callable = 'non_callable'
    try:
        event += non_callable
        raise AssertionError()
    except ValueError as e:
        assert 'handler must be callable' in to_text(e)


# Generated at 2022-06-11 17:36:55.668172
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Arrange

    class IntEventSource(_EventSource):
        @property
        def on_exception(self):
            return self._on_exception

        @on_exception.setter
        def on_exception(self, value):
            self._on_exception = value

    event_source = IntEventSource()

    def event_handler_1(null, null2):
        globals()['event_handler_1_call_count'] += 1

    def event_handler_2(null, null2):
        globals()['event_handler_2_call_count'] += 1

    globals().update(event_handler_1_call_count=0, event_handler_2_call_count=0)

    event_source += event_handler_1
    event_source += event_handler_2

    #

# Generated at 2022-06-11 17:37:04.910540
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource1(_EventSource):
        def __init__(self, *args, **kwargs):
            super(_TestEventSource1, self).__init__(*args, **kwargs)
            self.count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            # capture the exception if it is raised and return True so the caller re-raises
            self.exception = exc
            return True

        def handler_0(self):
            self.count += 1

        def handler_1(self):
            self.count += 2

        def handler_2(self):
            self.count += 4

    s = _TestEventSource1()
    s -= s.handler_0
    s -= s.handler_1
    s += s.handler_0
    s += s

# Generated at 2022-06-11 17:37:06.325090
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    evt = _EventSource()
    evt += 1


# Generated at 2022-06-11 17:37:19.884308
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    s = set()

    def handler_1(x):
        s.add(1)

    es += handler_1

    es.fire()

    assert s == {1}, s

    def handler_2(x):
        s.add(2)

    es += handler_2
    es.fire()

    assert s == {1, 2}, s

    def handler_3(x):
        s.add(3)

    es += handler_3
    es -= handler_2
    es.fire()

    assert s == {1, 2, 3}, s

    def handler_4(x):
        return 5 / 0

    es += handler_4

    try:
        es.fire()
    except ZeroDivisionError:
        pass

    assert s == {1, 2, 3}, s

# Generated at 2022-06-11 17:37:24.197156
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    called = [False]  # use a list so callback can modify it

    def callback():
        called[0] = True

    evt = _EventSource()
    evt += callback
    evt.fire()
    assert called[0]

# Generated at 2022-06-11 17:37:26.400754
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()

    def handler(arg):
        pass

    ev += handler
    assert handler in ev._handlers



# Generated at 2022-06-11 17:37:29.467057
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler(arg, arg2, arg3):
        pass

    event_source = _EventSource()

    event_source += handler

    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers


# Generated at 2022-06-11 17:37:39.074918
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest
    import collections

    result = collections.deque()

    def handler_one(s, *args, **kwargs):
        result.append(s)

    def handler_two(*args, **kwargs):
        result.append('two')

    def handler_three(*args, **kwargs):
        result.append('three')

    # Even though our event source is defined above in the class, we create a new one for our test
    event = _EventSource()

    event += handler_one
    assert result == collections.deque()

    event.fire('first', one='1')
    assert result == collections.deque(['first'])

    event += handler_two
    result.clear()
    event.fire('second')
    assert result == collections.deque(['second', 'two'])


# Generated at 2022-06-11 17:37:49.624978
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    raiser = lambda *args, **kwargs: None

    raiser.__name__ = 'raiser'

    event = _EventSource()
    event += raiser
    event += raiser

    try:
        event += None
        raise AssertionError('event += None did not raise a ValueError')
    except ValueError:
        pass

    try:
        event += 1
        raise AssertionError('event += 1 did not raise a ValueError')
    except ValueError:
        pass

    try:
        event += 'not a callable'
        raise AssertionError('event += "not a callable" did not raise a ValueError')
    except ValueError:
        pass


# Generated at 2022-06-11 17:37:54.470905
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []

    def my_handler(*args, **kwargs):
        calls.append((args, kwargs))

    evt = _EventSource()
    evt += my_handler
    evt.fire('foo', 'bar')

    assert calls == [((('foo', 'bar'),), {})]

# Generated at 2022-06-11 17:38:00.812766
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self):
            self.event_handlers_called = []

        def event_handler_one(self, *args, **kwargs):
            assert all(['arg1' in args, 'arg2' in args])
            assert all(['kwarg1' in kwargs, 'kwarg2' in kwargs])
            self.event_handlers_called.append('event_handler_one')

        def event_handler_two(self, *args, **kwargs):
            assert all(['arg1' in args, 'arg2' in args])
            assert all(['kwarg1' in kwargs, 'kwarg2' in kwargs])
            self.event_handlers_called.append('event_handler_two')

    # Verify that the handlers are

# Generated at 2022-06-11 17:38:11.155429
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def handler1(arg, kwarg='default'):
        print('handler1 called: arg=%s, kwarg=%s' % (arg, kwarg))

    def handler2(arg, kwarg='default'):
        print('handler2 called: arg=%s, kwarg=%s' % (arg, kwarg))

    def handler3(arg, kwarg='default'):
        print('handler3 called: arg=%s, kwarg=%s' % (arg, kwarg))

    event += handler1
    event += handler2
    event += handler3

    event.fire('test value')


# Generated at 2022-06-11 17:38:19.589604
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(with_metaclass(_AnsibleCollectionConfig)):
        def __init__(self):
            self._handlers = set()
            self.count = 0

    class _TestHandler:
        def __init__(self, c):
            self._config = c

        def __call__(self):
            self._config.count += 1

    test_event_source = _EventSourceTest()
    handler_1 = _TestHandler(test_event_source)
    handler_2 = _TestHandler(test_event_source)

    test_event_source += handler_1
    test_event_source += handler_2

    assert test_event_source.count == 0

    test_event_source.fire()
    assert test_event_source.count == 2


# Generated at 2022-06-11 17:38:32.431550
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    target = _EventSource()

    events = []

    def handler1(message):
        events.append('handler1: %s' % message)

    def handler2(message):
        events.append('handler2: %s' % message)
        return 'test'

    def handler3(message):
        events.append('handler3: %s' % message)
        raise Exception('test error')

    target += handler1
    target += handler2
    target += handler3

    target.fire('test')

    assert len(events) == 2
    assert 'handler1: test' in events
    assert 'handler2: test' in events



# Generated at 2022-06-11 17:38:45.313534
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    result = []

    def handler_1(*args, **kwargs):
        result.append('handler_1')

    def handler_2(*args, **kwargs):
        result.append('handler_2')

    def handler_3(*args, **kwargs):
        result.append('handler_3')

    e += handler_1

    e.fire()
    assert result == ['handler_1']

    e += handler_2
    e.fire()
    assert result == ['handler_1', 'handler_1', 'handler_2']

    e -= handler_1
    e.fire()
    assert result == ['handler_1', 'handler_1', 'handler_2', 'handler_2']

    e += handler_3
    e.fire()

# Generated at 2022-06-11 17:38:55.283314
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import PY3
    from ansible.utils.collection_loader import _EventSource
    es = _EventSource()

    def f1(arg1, kw1=1):
        pass

    def f2(arg2, kw2=2):
        pass

    es += f1
    es += f2

    if PY3:
        # Python 2 string type is like unicode in Python 3.
        # Python 3 string type is like bytes in Python 2.
        # This is the same in Python 2 and Python 3.
        assert type(es._handlers) is set
        assert len(es._handlers) == 2

# Generated at 2022-06-11 17:39:03.008318
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_bytes

    class _EventSourceTester(object):
        def __init__(self):
            self.s = _EventSource()

        @property
        def value(self):
            return self._value

        def _fail(self, *args, **kwargs):
            raise ValueError('fail')

        def _value_changed(self, value):
            self._value = value

        def add_handlers(self):
            self.s += self._value_changed
            self.s += self._fail

        def remove_handlers(self):
            self.s -= self._fail

        def fire(self, value):
            self.s.fire(value)

    # check the basics
    s = _EventSourceTester()


# Generated at 2022-06-11 17:39:04.780539
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler():
        pass

    es += handler
    assert handler in es._handlers



# Generated at 2022-06-11 17:39:15.977397
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import shutil
    import tempfile

    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return type(exc) is FirstException

    def _callback(path):
        raise FirstException()

    def _callback2(path):
        raise SecondException()

    class FirstException(Exception):
        pass

    class SecondException(Exception):
        pass

    tempdir = tempfile.mkdtemp()


# Generated at 2022-06-11 17:39:26.418262
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import types
    import unittest

    class test(unittest.TestCase):
        def test__EventSource_fire(self):
            class EventSourceSubclass(_EventSource):
                def _on_exception(self, handler, exc, *args, **kwargs):
                    return False

                def dummy_method(self, *args, **kwargs):
                    pass

            # ensure that a handler which does not declare a method to handle exceptions is removed
            #   when an exception is raised
            eventsource = EventSourceSubclass()
            with self.assertRaises(Exception):
                eventsource.fire(handler=self.dummy_method)
            self.assertEqual(set(), eventsource._handlers)

            self.called = False
            called_args = None
            called_kwargs = None

            # ensure that each handler is

# Generated at 2022-06-11 17:39:30.124559
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(name):
        assert name == 'Ansible'
        return

    def handler2(name):
        assert name == 'Ansible'
        return

    event_source += handler1
    event_source += handler2

    event_source.fire('Ansible')

# Generated at 2022-06-11 17:39:34.587855
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    c = _EventSource()
    c += lambda x: x * x  # FYI: Functions are callable

    assert c._handlers
    assert(len(c._handlers) == 1)
    assert(c._handlers.pop()(5) == 25) # 25 == 5*5


# Generated at 2022-06-11 17:39:42.624515
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    assert not e._handlers

    def h1(a, b):
        raise ValueError("h1")

    def h2(a, b):
        raise ValueError("h2")

    # Verify the set operations work
    e += h1
    assert len(e._handlers) == 1
    assert h1 in e._handlers
    assert e._handlers == {h1}

    e += h2
    assert len(e._handlers) == 2
    assert h1 in e._handlers
    assert h2 in e._handlers
    assert e._handlers == {h1, h2}

    e += h2
    assert len(e._handlers) == 2
    assert h1 in e._handlers
    assert h2 in e._handlers
    assert e._handlers

# Generated at 2022-06-11 17:39:52.983877
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += callable
    assert callable in es._handlers
    assert len(es._handlers) == 1


# Generated at 2022-06-11 17:40:01.603297
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Foo:
        def handler1(self, *args, **kwargs):
            self.events.append(('handler1', args, kwargs))

        def handler2(self, *args, **kwargs):
            self.events.append(('handler2', args, kwargs))

    foo = Foo()
    event_source = _EventSource()
    foo.events = []

    event_source += foo.handler1
    event_source += foo.handler2
    event_source.fire()

    assert foo.events == [('handler1', (), {}), ('handler2', (), {})]



# Generated at 2022-06-11 17:40:08.628048
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    test_exception = RuntimeError()
    def test_func(*args, **kwargs):
        raise test_exception

    def on_exception(handler, exc, *args, **kwargs):
        return False

    event_source._on_exception = on_exception

    event_source += test_func

    with pytest.raises(RuntimeError):
        event_source.fire()

    event_source._on_exception = lambda *args, **kwargs: True

    with pytest.raises(RuntimeError):
        event_source.fire()

# Generated at 2022-06-11 17:40:16.418173
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler_no_exception(*args, **kwargs):
        return True

    def handler_exception(*args, **kwargs):
        raise Exception('test exception')

    source = _EventSource()
    source.fire(1, 2, arg=3)

    source += handler_no_exception

    source.fire(1, 2, arg=3)

    source += handler_exception

    try:
        source.fire(1, 2, arg=3)
        assert False
    except Exception:
        pass

# Generated at 2022-06-11 17:40:24.896207
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from unittest.mock import Mock, call

    event_source = _EventSource()
    handler = Mock()

    # no exceptions, no return values
    event_source += handler
    event_source.fire()
    handler.assert_called_once()

    # no exceptions, return False
    handler.reset_mock()
    handler.return_value = False
    event_source.fire()
    handler.assert_called_once()

    # no exceptions, return True
    handler.reset_mock()
    handler.return_value = True
    event_source.fire()
    handler.assert_called_once()

    # exceptions, return False
    class TestException(Exception):
        pass

    handler.reset_mock()
    handler.side_effect = TestException()
    handler.return_value = False
   

# Generated at 2022-06-11 17:40:36.055340
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_var = {}

    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            assert args == (1, 2, 3)
            assert kwargs == {
                'kwargs1': 'a',
                'kwargs2': 'b',
                'kwargs3': 'c'
            }
            test_var['exception'] = str(exc)
            return False

    es = TestEventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('my exception')

    es += handler1
    es += handler2

    es.fire(1, 2, 3, kwargs1='a', kwargs2='b', kwargs3='c')



# Generated at 2022-06-11 17:40:43.523929
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def event_handler1(s, *args, **kwargs):
        assert s == 's1'
        assert args == []
        assert kwargs == {'foo': 'bar'}

    def event_handler2(s, *args, **kwargs):
        assert s == 's2'
        assert args == ['a1', 'a2']
        assert kwargs == {'bar': 'baz'}

    event += event_handler1
    event += event_handler2

    event.fire('s1', foo='bar')
    event.fire('s2', 'a1', 'a2', bar='baz')



# Generated at 2022-06-11 17:40:49.529703
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    global test_value

    test_value = 0

    def test_handler():
        global test_value
        test_value += 1

    def test_exception_handler(handler, exc, *args, **kwargs):
        print(exc)
        global test_value
        test_value += 2
        return True

    event = _EventSource()
    event._on_exception = test_exception_handler
    event += test_handler

    try:
        raise Exception('this is an exception')
    except Exception:
        event.fire(exc=Exception)

    if test_value != 3:
        raise AssertionError('test_value should be 3 but was %d' % test_value)

# Generated at 2022-06-11 17:40:52.080979
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    assert EventSource() == EventSource()
    es = EventSource()
    es += EventSource
    assert EventSource() == es
    es += '123'
    assert len(es) == 0


# Generated at 2022-06-11 17:41:02.197065
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()
    assert ev._handlers == set()

    def foo():
        foo.count += 1

    foo.count = 0
    ev += foo
    assert ev._handlers == set([foo])
    ev.fire()
    assert foo.count == 1

    ev += foo
    assert ev._handlers == set([foo])
    ev.fire()
    assert foo.count == 2

    def bar():
        bar.count += 1

    bar.count = 0
    ev += bar
    assert ev._handlers == set([foo, bar])
    ev.fire()
    assert foo.count == 3
    assert bar.count == 1

    ev -= bar
    assert ev._handlers == set([foo])
    ev.fire()
    assert foo.count == 4
    assert bar.count == 1




# Generated at 2022-06-11 17:41:21.083761
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def event_handler(x):
        return x

    event_source = _EventSource()
    event_source += event_handler
    assert event_source.fire(4) == 4

if __name__ == '__main__':
    import pytest

    pytest.main(['-v', __file__])

# Generated at 2022-06-11 17:41:32.122123
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # pylint: disable=protected-access
    _event_source = _EventSource()

    # attach a function that takes no arguments which returns True
    _first_result = [None]

    def first():
        _first_result[0] = True
        return True

    # attach a function that takes no arguments which returns False
    _second_result = [None]

    def second():
        _second_result[0] = True
        return False

    # attach a function that takes arguments but ignores them
    _third_result = [None]

    def third(*args, **kwargs):
        _third_result[0] = True
        return True

    _event_source += first
    _event_source += second
    _event_source += third

    _event_source.fire()

    assert _first_result[0]

# Generated at 2022-06-11 17:41:34.607134
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_event = _EventSource()
    test_event_handler = lambda: None

    test_event += test_event_handler

    test_event.fire()

# Generated at 2022-06-11 17:41:45.684227
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    message = None

    def handler1(m):
        global message
        message = m

    def handler2(m):
        raise Exception('handler2')

    def handler3(m):
        raise Exception('handler3')

    def handler4(m):
        raise Exception('handler4')

    def handler5(m):
        raise Exception('handler5')

    def handler6(m):
        raise Exception('handler6')

    def handler7(m):
        raise Exception('handler7')

    def handler8(m):
        raise Exception('handler8')

    def handler9(m):
        raise Exception('handler9')

    def handler10(m):
        raise Exception('handler10')

    def handler11(m):
        raise Exception('handler11')

    def handler12(m):
        raise Exception('handler12')

   

# Generated at 2022-06-11 17:41:56.051624
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_fired = []

    def test_func1(*args, **kwargs):
        test_fired.append('test_func1')

    def test_func2(*args, **kwargs):
        test_fired.append('test_func2')
        raise ValueError('Test exception')

    def test_func3(*args, **kwargs):
        test_fired.append('test_func3')
        raise ValueError('Test exception')

    def test_func4(*args, **kwargs):
        test_fired.append('test_func4')

    def test_func5(*args, **kwargs):
        test_fired.append('test_func5')

    es = _EventSource()
    es += test_func1
    es += test_func2
    es += test_func3
    es += test_func4

# Generated at 2022-06-11 17:42:00.338416
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    source = _EventSource()
    source += EventHandler(bool(True))
    source.fire()

    source = _EventSource()
    source += EventHandler(bool(False))
    source.fire()


# Class used for testing method fire of class _EventSource

# Generated at 2022-06-11 17:42:09.244892
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert not event_source._handlers

    value = object()

    def func(value):
        pass

    event_source += func
    assert len(event_source._handlers) == 1
    assert func in event_source._handlers

    event_source += func
    assert len(event_source._handlers) == 1
    assert func in event_source._handlers

    event_source -= func
    assert len(event_source._handlers) == 0
    event_source -= func
    assert len(event_source._handlers) == 0



# Generated at 2022-06-11 17:42:19.376403
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # event source with single handler
    event_source = _EventSource()
    def event_source_handler1(foo, bar):
        if foo == 'foo' and bar == 'bar':
            return
        else:
            raise ValueError('event_source_handler1: invalid args')

    event_source += event_source_handler1

    event_source.fire('foo', bar='bar')

    # event source with two handlers
    event_source = _EventSource()
    def event_source_handler1(foo, bar):
        if foo == 'foo' and bar == 'bar':
            return
        else:
            raise ValueError('event_source_handler1: invalid args')

    def event_source_handler2(foo, bar):
        if foo == 'foo' and bar == 'bar':
            return

# Generated at 2022-06-11 17:42:23.710752
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    source += source._on_exception

    source += lambda: None
    source.fire()

    source.fire()

    try:
        source.fire()
    except ValueError:
        pass
    else:
        raise AssertionError('no exception fired for non-callable')

# Generated at 2022-06-11 17:42:34.753231
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    got = []

    def handler1(*args, **kwargs):
        got.append('handler1 %s %s' % (args, kwargs))

    def handler2(*args, **kwargs):
        got.append('handler2 %s %s' % (args, kwargs))

    es += handler1
    es += handler2

    es.fire(1, 2, 3, 4)

    assert got == ['handler1 (1, 2, 3, 4) {}', 'handler2 (1, 2, 3, 4) {}']

    got[:] = []

    es.fire(foo='bar')

    assert got == ['handler1 () {\'foo\': \'bar\'}', 'handler2 () {\'foo\': \'bar\'}']

    got[:] = []

    es.fire

# Generated at 2022-06-11 17:43:14.676502
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(message):
        nonlocal message_handler1
        message_handler1 = message

    def handler1_error(message):
        nonlocal message_handler1_error
        message_handler1_error = message

    def handler2(message, number):
        nonlocal message_handler2
        nonlocal number_handler2
        message_handler2 = message
        number_handler2 = number

    def handler2_error(message, number):
        nonlocal message_handler2_error
        nonlocal number_handler2_error
        message_handler2_error = message
        number_handler2_error = number

    message_handler1 = None
    message_handler1_error = None
    message_handler2 = None
    number_handler2 = None
    message_handler2_error = None
    number_handler2_error

# Generated at 2022-06-11 17:43:22.806616
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(x):
        print(x)

    def handler1(x):
        raise RuntimeError(x)

    es = _EventSource()
    es += handler
    es += handler1

    es.fire('hello')  # should print hello and raise RuntimeError

    try:
        es.fire('hello')
    except Exception as ex:
        assert isinstance(ex, RuntimeError)
        assert ex.args[0] == 'hello'
    else:
        raise AssertionError('expected event source to raise RuntimeError')

    es -= handler1
    es.fire('world')  # should print world

test__EventSource_fire()

# Generated at 2022-06-11 17:43:33.259088
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    def handler1(*args, **kwargs):
        raise RuntimeError('handler1')
    event_source += handler1

    def handler2(*args, **kwargs):
        raise RuntimeError('handler2')
    event_source += handler2

    def handler3(*args, **kwargs):
        return
    event_source += handler3

    try:
        event_source.fire()
    except:
        pass

    def handler4(*args, **kwargs):
        return
    event_source += handler4
    event_source.fire()

    event_source -= handler4
    try:
        event_source.fire()
    except:
        pass



# Generated at 2022-06-11 17:43:39.194210
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def mock_handler_1(arg):
        mock_handler_1.call_args.append((arg,))

    def mock_handler_2(arg):
        mock_handler_2.call_args.append((arg,))

    mock_handler_1.call_args = []
    mock_handler_2.call_args = []

    event_source = _EventSource()
    event_source += mock_handler_1
    event_source += mock_handler_2
    event_source.fire('foo')

    assert mock_handler_1.call_args == [('foo',)]
    assert mock_handler_2.call_args == [('foo',)]


# Generated at 2022-06-11 17:43:51.283793
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(self):
        return 'handler1'

    def handler2(self):
        return 'handler2'

    event_source = _EventSource()

    assert len(event_source._handlers) == 0

    # test that we can add a handler correctly
    event_source += handler1

    assert len(event_source._handlers) == 1

    # test that we only get the correct handlers out
    assert event_source.fire() == 'handler1'

    # test adding another handler
    event_source += handler2

    # test that we get both handlers out
    assert event_source.fire() == 'handler2'

    # test that we can't add the same handler twice
    event_source += handler1

    assert len(event_source._handlers) == 2



# Generated at 2022-06-11 17:43:56.738054
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # fail if not callable
    es = _EventSource()
    with pytest.raises(ValueError) as e:
        es += 5
    assert "handler must be callable" in to_text(e.value)

    # success
    def _fail():
        raise Exception("This should not be called")
    es += _fail
    assert _fail in es._handlers


# Generated at 2022-06-11 17:44:03.591713
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test fire
    es = _EventSource()

    call_count = [0]
    def callback():
        call_count[0] += 1

    es += callback
    es += callback

    es.fire()

    assert call_count[0] == 2, 'did not fire twice'

    es -= callback
    es.fire()

    assert call_count[0] == 3, 'did not fire thrice'

    # test that we can remove a non-existent handler and not error out
    es -= callback

# unit test for method __init__ of class _AnsibleCollectionConfig

# Generated at 2022-06-11 17:44:12.560794
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # initialize a collection loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    loader = AnsibleCollectionLoader()

    # create an event source
    event_source = _EventSource()

    # create a mock listener that prints the event source & the event
    class MockListener:
        def __call__(self, event_source, *args, **kwargs):
            print('MockListener: event_source: %s, event: %s' % (event_source, args, kwargs))

    # create an instance of the mock listener and add it to the event source
    mock_listener = MockListener()
    event_source += mock_listener

    # fire an event and make sure the mock listener is called
    event_source.fire('event_name', 'event_payload')

    # remove the mock listener from the

# Generated at 2022-06-11 17:44:15.925761
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()
    f = lambda: None
    ev += f
    assert len(ev._handlers) == 1
    assert ev._handlers == {f}


# Generated at 2022-06-11 17:44:21.076497
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    counter = 0

    def handler(x):
        nonlocal counter
        counter += x

    events = _EventSource()

    events += handler
    events.fire(1)
    events.fire(2)
    assert counter == 3

    events -= handler
    events.fire(1)
    assert counter == 3

