

# Generated at 2022-06-11 17:34:32.023523
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            # we expect the exception to be raised
            raise
        # 

    def func1(arg1, arg2):
        pass
    # func1

    def func2(arg1, arg2, arg3):
        pass
    # func2

    s = MyEventSource()
    s += func1
    s += func2

    with pytest.raises(TypeError):
        s.fire('a', 'b', 'c', 'd', 'e')
    #
    with pytest.raises(TypeError):
        s.fire('a', 'b', 'c', d='e')
    #

# Generated at 2022-06-11 17:34:41.316452
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Test:
        def __init__(self):
            self.calls = []

        def handler(self, *args, **kwargs):
            self.calls.append((args, kwargs))

        def unusable_handler(self, *args, **kwargs):
            raise Exception('oops')

    events = _EventSource()

    t1 = _Test()
    t2 = _Test()
    t3 = _Test()

    events += t1.handler
    events += t1.unusable_handler
    events += t2.handler
    events += t3.handler

    events.fire('myarg', foo='bar')
    assert len(t1.calls) == 1
    assert len(t2.calls) == 1
    assert len(t3.calls) == 1

    events -= t

# Generated at 2022-06-11 17:34:43.857736
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    handler_function = lambda *args, **kwargs: None

    event_source += handler_function

    assert handler_function in event_source._handlers


# Generated at 2022-06-11 17:34:46.596599
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _event_source = _EventSource()
    def _handler(data):
        print(data)

    _event_source += _handler
    for h in _event_source._handlers:
        assert h == _handler



# Generated at 2022-06-11 17:34:49.853537
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass
    # Plus sign is implemented by method __iadd__ of class _EventSource
    event_source = AnsibleCollectionConfig.on_collection_load
    event_source += handler
    event_source.fire()

    # Test add the same handler twice
    event_source += handler
    event_source.fire()


# Generated at 2022-06-11 17:34:57.564436
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(x):
        raise Exception('this was expected')

    counter = {'failure': 0, 'success': 0}

    def on_exception(handler, ex, *args, **kwargs):
        counter['failure'] += 1
        assert handler is handler
        assert ex.args[0] == 'this was expected'
        assert args == (1,)
        assert kwargs == {'b': 2}
        return False

    def success_handler(x):
        counter['success'] += 1

    s = _EventSource()
    s.fire()

    s += handler
    s += success_handler
    s._on_exception = on_exception

    s.fire(1, b=2)

    assert len(s._handlers) == 2
    assert counter['failure'] == 1
    assert counter

# Generated at 2022-06-11 17:35:00.672299
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def _test_handler():
        pass

    event_source = _EventSource()
    event_source += _test_handler

    assert _test_handler in event_source._handlers



# Generated at 2022-06-11 17:35:10.006421
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    target = []

    assert target == []

    source += lambda: target.append('foo')

    source.fire()

    assert target == ['foo']

    try:
        source += lambda x: target.append(x)

        source.fire(1)

        assert target == ['foo', 1]

        source += lambda x: x

        source.fire(1)

        assert target == ['foo', 1, 1]

        try:
            source += lambda: None()

            source.fire()
        except:
            assert target == ['foo', 1, 1]
        else:
            raise AssertionError('expected exception not raised')
    except:
        assert target == ['foo', 1]
    else:
        raise AssertionError('expected exception not raised')

    assert target == ['foo', 1]

# Generated at 2022-06-11 17:35:14.477424
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    foo = False

    def handler(x):
        global foo
        foo = x

    event += handler
    assert not foo
    event.fire(True)
    assert foo



# Generated at 2022-06-11 17:35:17.687980
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    called = False

    def handler():
        nonlocal called
        called = True

    event += handler
    event.fire()

    assert called



# Generated at 2022-06-11 17:35:31.201634
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # pylint: disable=redefined-outer-name
    def handler(event_source, arg1, arg2, arg3, kwarg1, kwarg2, kwarg3):
        assert event_source is es
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        assert arg3 == 'arg3'
        assert kwarg1 == 'kwarg1'
        assert kwarg2 == 'kwarg2'
        assert kwarg3 == 'kwarg3'

    es = _EventSource()
    es += handler
    es.fire('arg1', 'arg2', 'arg3', kwarg1='kwarg1', kwarg2='kwarg2', kwarg3='kwarg3')



# Generated at 2022-06-11 17:35:40.106814
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test1:
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    class Test2:
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    source = _EventSource()

    t1 = Test1()
    source += t1
    source.fire()
    assert t1.called

    t2 = Test2()
    source += t2
    assert len(source._handlers) == 2
    source.fire()
    assert t1.called
    assert t2.called

    source -= t1
    assert len(source._handlers) == 1
    t1.called = False
    t

# Generated at 2022-06-11 17:35:44.517253
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    s = _EventSource()
    h = lambda *args, **kwargs: (args, kwargs)

    # Act
    s += h

    # Assert
    assert h in s._handlers


# Generated at 2022-06-11 17:35:53.373901
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup
    _EventSource.fire = _EventSource.fire.__func__
    event_source = _EventSource()
    one_called = False
    two_called = False
    three_called = False
    def one():
        nonlocal one_called
        one_called = True
    def two():
        nonlocal two_called
        two_called = True
    def three():
        nonlocal three_called
        three_called = True
    event_source += one
    event_source += two
    event_source += three

    # Execute
    event_source.fire()

    # Verify
    assert one_called
    assert two_called
    assert three_called

# Generated at 2022-06-11 17:36:00.592590
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockHandler:
        def __init__(self):
            self._calls = []

        def __call__(self, *args, **kwargs):
            self._calls.append((args, kwargs))

    mock = MockHandler()

    events = _EventSource()
    events += mock

    events.fire(1, 2, x=3, y=4)

    assert mock._calls == [(
        (1, 2),
        {'x': 3, 'y': 4}
    ), ]

    events -= mock

    events.fire(1, 2, x=3, y=4)

    assert mock._calls == [(
        (1, 2),
        {'x': 3, 'y': 4}
    ), ]


# Generated at 2022-06-11 17:36:03.598993
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    js = _EventSource()
    def event_handler(arg):
        pass

    js += event_handler

    js.fire()

# Generated at 2022-06-11 17:36:13.761738
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible_test.legacy_collection_loader.tests.conftest import MockLegacyFinder
    import argparse
    import textwrap
    import unittest

    class _TestEventSource(unittest.TestCase):
        def setUp(self):
            self._finder_configure_value = to_bytes('configure', 'ascii')
            self._mock_finder = MockLegacyFinder(None)
            self.configure_handler = lambda finder: self.assertIs(self._mock_finder, finder)

        def test__EventSource___iadd__(self):
            event_source = _EventSource()
            event_source += self.configure_handler

# Generated at 2022-06-11 17:36:17.255011
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    results = []
    source = _EventSource()

    source += lambda *args, **kwargs: results.append('a')
    source += lambda *args, **kwargs: results.append('b')

    source.fire(1, 2)

    assert results == ['a', 'b']

# Generated at 2022-06-11 17:36:22.802611
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_one(*args, **kwargs):
        pass

    def handler_two(self, *args, **kwargs):
        pass

    event_source = _EventSource()
    event_source += handler_one
    event_source += handler_two
    event_source.fire()


# Generated at 2022-06-11 17:36:25.367889
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    h = lambda: None
    e += h
    assert h in e._handlers



# Generated at 2022-06-11 17:36:33.385023
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # helper function which can be called by the fire method
    def handler(a, b, c):
        print('handler:', a, b, c, end=' ')

    # register the handler
    e = _EventSource()
    e += handler

    # invoke the handler
    e.fire(1, 2, 3)

# Generated at 2022-06-11 17:36:41.137707
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._call_count = 0

        @property
        def call_count(self):
            return self._call_count

    def _handler_1(*args, **kwargs):
        raise ValueError('_handler_1 was called with {} and {}'.format(args, kwargs))

    EVENT_SOURCE = _TestEventSource()
    EVENT_SOURCE += _handler_1
    EVENT_SOURCE += _handler_1

    try:
        EVENT_SOURCE.fire()
    except ValueError:
        pass

    assert EVENT_SOURCE.call_count == 2



# Generated at 2022-06-11 17:36:43.989117
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-11 17:36:51.407066
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    call_count = 0
    called_with = []
    source = _EventSource()

    source += lambda *a, **kw: called_with.append(('h1', a, kw))
    source += lambda *a, **kw: called_with.append(('h2', a, kw))

    source.fire(a=1)

    assert len(called_with) == 2
    assert called_with[0] == ('h1', (), {'a': 1})
    assert called_with[1] == ('h2', (), {'a': 1})

# Generated at 2022-06-11 17:37:02.533774
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(object):
        def __init__(self):
            self._handlers = set()

        def __iadd__(self, handler):
            self._handlers.add(handler)
            return self

        def fire(self, *args, **kwargs):
            for h in self._handlers:
                h(*args, **kwargs)

    def handler_1(message):
        print('handler 1: ' + message)

    def handler_2(message):
        print('handler 2: ' + message)

    def handler_3(message):
        print('handler 3: ' + message)

    def handler_4(message):
        raise ValueError('unexpected')

    def handler_5(message):
        print('handler 5: ' + message)


# Generated at 2022-06-11 17:37:09.335776
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class FakeEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            self.handler = handler
            self.exc = exc
            self.args = args
            self.kwargs = kwargs
            return True

    es = FakeEventSource()
    ev = lambda: None
    es += ev
    assert es._handlers == {ev}
    es._handlers = {ev}

    es += 42
    assert isinstance(es.exc, ValueError)
    assert es.exc.args[0] == 'handler must be callable'



# Generated at 2022-06-11 17:37:17.912506
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    def call_me(item):
        item.append(2)

    def raise_error(item):
        raise RuntimeError('test')

    def filter_error(handler, exc, item):
        item.append(3)
        return False

    es.fire([1])
    es += call_me
    es += raise_error

    try:
        es.fire([1])
    except RuntimeError:
        pass

    es.fire([1])
    es -= call_me
    es.fire([1])
    es += call_me
    es += raise_error
    es._on_exception = filter_error
    es.fire([1])

# Generated at 2022-06-11 17:37:28.959981
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource_fire(unittest.TestCase):
        def test_no_callables(self):
            es = _EventSource()
            es.fire()

        def test_with_args(self):
            es = _EventSource()
            fired = []

            def a(*args, **kwargs):
                fired.append('a: %s' % (args,))

            def b(*args, **kwargs):
                fired.append('b: %s' % (args,))

            a = a
            b = b
            es += a
            es += b
            es.fire('foo', 'bar')
            self.assertEqual(fired, ['a: (\'foo\', \'bar\')', 'b: (\'foo\', \'bar\')'])


# Generated at 2022-06-11 17:37:31.449870
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    assert handler not in event_source._handlers
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-11 17:37:33.185249
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: True
    for handler in es._handlers:
        assert callable(handler)


# Generated at 2022-06-11 17:37:44.552223
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource_for_test__EventSource_fire(_EventSource):
        def __init__(self):
            super(EventSource_for_test__EventSource_fire, self).__init__()
            self.event_fired = False

        def event_handler(self, *args, **kwargs):
            self.event_fired = True

    es = EventSource_for_test__EventSource_fire()
    es += es.event_handler
    es.fire()
    assert es.event_fired is True



# Generated at 2022-06-11 17:37:48.725718
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    x = []

    def handler():
        x.append(1)

    assert x == []

    s += handler

    s.fire()

    assert x == [1]

    s -= handler

    s.fire()

    assert x == [1]



# Generated at 2022-06-11 17:37:58.800479
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.urls import open_url

    # create a '_EventSource' instance and add a function
    eventsource = _EventSource()
    eventsource += open_url

    # Check that 'eventsource' is callable with the same parameters as 'open_url'
    result = eventsource('https://example.com')

    # Verify that 'open_url' is called when calling 'eventsource'
    if not result:
        raise AssertionError("Failed to 'open_url': %s" % to_bytes(result.read()))

    # Check that adding a function with

# Generated at 2022-06-11 17:38:06.513703
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fired = {}

    def handler1(event, **kwargs):
        fired[event] = kwargs.get('foo', None)

    def handler2(event, **kwargs):
        fired[event] = kwargs.get('foo', None)

    def handler3(event, **kwargs):
        fired[event] = kwargs.get('foo', None)

    events = _EventSource()
    events += handler1
    events += handler2
    events += handler3

    assert len(events._handlers) == 3

    assert 'one' not in fired

    events.fire(event='one', foo='bar')
    assert fired['one'] == 'bar'

    events -= handler1
    assert len(events._handlers) == 2

    events -= handler1
    assert len(events._handlers) == 2

# Generated at 2022-06-11 17:38:11.057625
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    # check that we can successfully register callables
    def callable_1():
        pass

    def callable_2(arg_1, arg_2):
        pass

    es += callable_1
    es += callable_2

    # check that we can successfully register callables with incorrect definitions
    def callable_3():
        pass

    es += callable_3

    # check that we can successfully add the same callable more than once
    es += callable_1

    # check that we raise an exception when a non-callable is registered
    try:
        es += 'not_a_callable'
        raise AssertionError('Addition of string to _EventSource should throw an exception but did not.')
    except ValueError:
        pass



# Generated at 2022-06-11 17:38:19.529320
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Header(object):
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return self.name == other.name

        def __hash__(self):
            return hash(self.name)

    def _handler1(message):
        _saved_message.append(message)

    def _handler2(message):
        _saved_message.append(message)

    _saved_message = []

    header = Header('test')
    event_source = _EventSource()
    event_source += _handler1
    event_source += _handler2
    event_source.fire(header, message='hello')

    assert len(_saved_message) == 2

# Generated at 2022-06-11 17:38:22.567544
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler(*args, **kwargs):
        print(args, kwargs)

    event_source += handler
    event_source.fire(1, 2, 3)



# Generated at 2022-06-11 17:38:24.113403
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _EventSource.__iadd__(None, None)


# Generated at 2022-06-11 17:38:34.919448
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self):
            super(EventSource, self).__init__()
            self.calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.calls.append((handler, exc, args, kwargs))
            # do not re-raise
            return False

    es = EventSource()

    def handler1(*args, **kwargs):
        assert args == ('arg1', 'arg2')
        assert kwargs == dict(kwarg1='kwarg1', kwarg2='kwarg2')
        raise Exception('handler1')

    def handler2(*args, **kwargs):
        assert args == ('arg1', 'arg2')

# Generated at 2022-06-11 17:38:38.205338
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1():
        pass

    def handler2():
        pass

    es = _EventSource()
    es += handler1
    es += handler2
    es.fire()

# Generated at 2022-06-11 17:38:51.050243
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    class _Handler:
        def __init__(self, name, result):
            self.name = name
            self.result = result

        def __call__(self, *args, **kwargs):
            return self.result

    handler_one = _Handler('one', True)
    handler_two = _Handler('two', False)
    handler_three = _Handler('three', None)
    handler_bad = _Handler('bad', False)
    handler_bad.__call__ = lambda *args, **kwargs: 'bad'

    event += handler_one
    event += handler_two
    event += handler_three

    event.fire(1, 'a')

    event += handler_bad
    with pytest.raises(Exception) as ex:
        event.fire(2, 'a')

# Generated at 2022-06-11 17:38:57.238192
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Object:
        def __init__(self):
            self.foo = None

        def __repr__(self):
            return "_Object(foo=%r)" % (self.foo,)

    def _handler(a, b):
        obj.foo = (a, b)

    obj = _Object()
    ev = _EventSource()
    ev += _handler
    ev.fire("hello", "world")

    assert obj.foo == ("hello", "world"), "EventSource did not fire handler"

# Generated at 2022-06-11 17:39:00.778958
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    handler = 'handler'

    es = _EventSource()

    if handler in es:
        raise AssertionError('Event handler must not be added until __iadd__ is called')

    es += handler

    if handler not in es:
        raise AssertionError('Event handler must be added after __iadd__ is called')



# Generated at 2022-06-11 17:39:02.986300
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    def call_hello(param):
        print('hello ' +str(param))
    event += call_hello
    event.fire('world')

# Generated at 2022-06-11 17:39:13.248581
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Test that all handlers are executed
    def test1():
        def handler1():
            assert False
        def handler2():
            assert False

        event = _EventSource()
        event += handler1
        event += handler2

        try:
            event.fire()
        except AssertionError:
            assert False

    test1()

    # Test that exception handlers are executed
    def test2():
        def handler1():
            raise Exception('handler1 fired')
        def handler2():
            raise Exception('handler2 fired')
        def exception_handler(handler, exc):
            assert isinstance(exc, Exception)
            assert exc.args[0] == 'handler1 fired'
            return False

        event = _EventSource()
        event += handler1
        event += handler2
        event._on_exception = exception_handler



# Generated at 2022-06-11 17:39:17.447737
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()
    eventsource += raise_exception

    try:
        eventsource.fire()
        assert False, 'should have raised an exception'
    except RuntimeError:
        pass

    eventsource += do_nothing
    eventsource.fire()


# Generated at 2022-06-11 17:39:27.691248
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class OnCollectionLoadTester:

        def __init__(self, value):
            self._value = value
            self._events = 0

        def __call__(self, foo):
            assert foo == self._value
            self._events += 1

    # test one handler
    tester = OnCollectionLoadTester('bar')
    config = AnsibleCollectionConfig()
    config.on_collection_load += tester
    config.on_collection_load.fire('bar')
    assert tester._events == 1

    # test multiple handlers, one which fails
    tester_a = OnCollectionLoadTester('foo')
    tester_b = OnCollectionLoadTester('bar')

    # noinspection PyUnusedLocal
    def failing_handler(foo):
        raise RuntimeError('raised by failing_handler')

    config.on_

# Generated at 2022-06-11 17:39:38.742996
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class EventSourceTest(_EventSource):
        pass

    class FakeHandler:
        def __init__(self, value):
            self.value = value
            self.call_count = 0

        def __call__(self):
            self.call_count += 1

    def test_event_handlers_fired():
        event = EventSourceTest()
        handler = FakeHandler(None)

        event += handler
        event.fire()

        assert handler.call_count == 1

    def test_handler_exception():
        class MyException(Exception):
            pass

        class EventSourceTest(_EventSource):
            def _on_exception(self, handler, exc, *args, **kwargs):
                if isinstance(exc, MyException):
                    return False

                return True

        event = EventSourceTest()
        handler = FakeHandler

# Generated at 2022-06-11 17:39:43.506755
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert isinstance(event_source, _EventSource)
    event_source += lambda: None
    assert len(event_source._handlers) == 1
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-11 17:39:49.954106
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    event = _EventSource()
    events = []

    def handlerA(x, y):
        events.append('A-%s-%s' % (x, y))

    def handlerB(x, y):
        events.append('B-%s-%s' % (x, y))

    # Act
    event += handlerA
    event += handlerB

    event.fire('X', 'Y')

    # Assert
    assert events == ['A-X-Y', 'B-X-Y']

# Generated at 2022-06-11 17:40:11.082813
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()
    eventsource.fire()

    recorded_events = []

    def handler1(event):
        recorded_events.append(1)

    def handler2(event):
        raise ValueError('boom')

    def handler3(event):
        raise NotImplementedError('bam')

    def handler4(event):
        raise StopIteration('biff')

    eventsource += handler1
    eventsource += handler2
    eventsource += handler3
    eventsource += handler4
    eventsource += handler1
    eventsource += handler2
    eventsource += handler3
    eventsource += handler4

    try:
        eventsource.fire()
        assert False, 'event source failed to re-raise an exception'
    except ValueError as ex:
        assert 'boom' in str(ex)


# Generated at 2022-06-11 17:40:21.927111
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_exception_raised = False
    test_args = None
    test_kwargs = None

    def test_callback(*args, **kwargs):
        nonlocal test_args
        nonlocal test_kwargs
        test_args = args
        test_kwargs = kwargs

    def test_callback_raise_exception(*args, **kwargs):
        nonlocal test_exception_raised
        test_exception_raised = True
        raise Exception()

    assert _EventSource.fire.__func__(None, *('arg1', 'arg2'), **{'kw1': 1, 'kw2': 2}) is None

    event_source = _EventSource()
    event_source += test_callback
    event_source += test_callback_raise_exception
    event_source += test_callback
    assert event_

# Generated at 2022-06-11 17:40:33.637855
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    fail = [False]

    def handler1(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == {'a': 'b'}

        # break the chain
        return

    def handler2(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == {'a': 'b'}

        # break the chain
        return

    def handler3(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == {'a': 'b'}

        fail[0] = True

    es += handler1
    es += handler2
    es += handler3

    es.fire(1, 2, a='b')

    # only handler3 should have been fired

# Generated at 2022-06-11 17:40:38.403377
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class DidFire(Exception):
        pass
    def on_event(*args, **kwargs):
        raise DidFire()
    def on_event_bad(*args, **kwargs):
        raise ValueError('bad')

    e = _EventSource()
    e += on_event
    e += on_event_bad

    try:
        e.fire()
    except DidFire:
        pass
    else:
        assert False, 'DidFire not raised'

# Generated at 2022-06-11 17:40:44.214589
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    # input validation
    try:
        es += None
        assert (False)
    except ValueError:
        pass

    # initial state
    assert (es._handlers == set())

    def a(): pass
    def b(): pass

    es += a
    assert (es._handlers == {a})

    es += b
    assert (es._handlers == {a, b})

    es += a  # should be ignored
    assert (es._handlers == {a, b})



# Generated at 2022-06-11 17:40:47.251908
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}
    event_source += handler
    assert event_source._handlers == {handler}



# Generated at 2022-06-11 17:40:51.088383
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils._text import to_bytes

    def my_handler(x, y):
        my_handler.calls.append((x, y))

    my_handler.calls = []
    events = _EventSource()
    events += my_handler
    events.fire(1, to_bytes('2'))
    events.fire('three', 'four')

    assert tuple(my_handler.calls) == ((1, to_bytes('2')), ('three', 'four'))

# Generated at 2022-06-11 17:40:58.034303
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup
    es = _EventSource()
    counter = [0]
    def inc(*args, **kwargs):
        counter[0] += 1
        return

    es += inc

    # Test
    for i in range(4):
        es.fire()
    assert counter[0] == 4, \
        "t__EventSource_fire: expected counter[0] to be 4 but got {0}".format(counter[0])



# Generated at 2022-06-11 17:41:05.182343
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_test.test_util.target.test_lib.test_common.unit import _TestEventSource

    _TestEventSource.assert_EventSource_iadd__handler_must_be_callable()
    _TestEventSource.assert_EventSource_iadd__handler_must_be_callable_not_callable(1)
    _TestEventSource.assert_EventSource_iadd__handler_must_be_callable_not_callable([])
    _TestEventSource.assert_EventSource_iadd__handler_must_be_callable_not_callable({})
    _TestEventSource.assert_EventSource_iadd__handler_must_be_callable_not_callable('foo')
    _TestEventSource.assert_EventSource_iadd__handler_must_be_callable_callable

# Generated at 2022-06-11 17:41:12.603718
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def _handler_one(*args, **kwargs):
        pass

    def _handler_two(*args, **kwargs):
        pass

    def _handler_three(*args, **kwargs):
        pass

    event_source += _handler_one
    event_source += _handler_two
    event_source += _handler_three
    event_source += _handler_two
    event_source += _handler_three

    assert event_source._handlers == set([_handler_one, _handler_two, _handler_three])


# Generated at 2022-06-11 17:41:32.074821
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    handler = None

    with pytest.raises(ValueError, match='handler must be callable'):
        es += handler

    with pytest.raises(ValueError, match='handler must be callable'):
        es += 'foo'

    def foo():
        pass

    es += foo



# Generated at 2022-06-11 17:41:35.225429
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def dummy(x, y):
        return x, y

    def dummy2(x, y):
        return x, y

    source = _EventSource()
    source += dummy
    source += dummy2
    source.fire(1, 2)

# Generated at 2022-06-11 17:41:45.973415
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def say_hello(who):
        print('Hello %s' % who)

    def bad_hello(who):
        print('Hello %s' % 1/0)

    # Create an instance of _EventSource
    ev = _EventSource()

    # Attach a function to the event
    ev += say_hello

    # Fire the event
    ev.fire('world')

    # Remove the function from the event
    ev -= say_hello

    # Fire the event again and nothing should be printed
    ev.fire('world')

    # Attach a function which raises an exception to the event
    try:
        ev += bad_hello
    except ValueError:
        pass

    # Fire the event and expect to catch the exception
    try:
        ev.fire('world')
    except ZeroDivisionError:
        pass

# Generated at 2022-06-11 17:41:56.539243
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockHandler:

        def __init__(self):
            self.call_count = 0
            self.call_args = None

        def handler(self, *args, **kwargs):
            self.call_count += 1
            self.call_args = (args, kwargs)

    handler_1 = MockHandler()
    handler_2 = MockHandler()

    src = _EventSource()
    src += handler_1.handler
    src += handler_2.handler

    args = (1, 2, 3)
    kwargs = dict(foo='bar', this='that')

    src.fire(*args, **kwargs)

    assert handler_1.call_count == 1
    assert handler_1.call_args == (args, kwargs)

    assert handler_2.call_count == 1
    assert handler

# Generated at 2022-06-11 17:42:02.491390
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(source, a, b, c):
        handler.called = True
        handler.a = a
        handler.b = b
        handler.c = c

    source = _EventSource()
    source += handler

    handler.called = False
    source.fire(1, 2, 3)
    assert handler.called is True
    assert handler.a == 1
    assert handler.b == 2
    assert handler.c == 3

# Generated at 2022-06-11 17:42:12.133706
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Handler1:
        def __init__(self, events_rcv):
            self.events_rcv = events_rcv

        def handle(self, *args, **kwargs):
            self.events_rcv.append(('handle', args, kwargs))

    class Handler2:
        def handle(self, *args, **kwargs):
            raise ValueError('test__EventSource_fire(): exception from handler 2')

    class Handler3:
        def handle(self, *args, **kwargs):
            raise AttributeError('test__EventSource_fire(): exception from handler 3')

    class Handler4:
        def handle(self, *args, **kwargs):
            return

    events_rcv = []

    events = _EventSource()
    events += Handler1(events_rcv).handle

    # fire

# Generated at 2022-06-11 17:42:16.430120
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(arg):
        arg.append(1)

    es = _EventSource()
    es += handler

    assert len(es._handlers) == 1

    arg = []
    es.fire(arg)
    assert arg == [1]

    es -= handler
    assert len(es._handlers) == 0


# Generated at 2022-06-11 17:42:19.660407
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda *_, **__: None
    e += lambda *_, **__: None
    assert len(e._handlers) == 2


# Generated at 2022-06-11 17:42:24.826787
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    on_collection_load = AnsibleCollectionConfig.on_collection_load
    on_collection_load += AnsibleModule.dump_autodoc
    on_collection_load += AnsibleModule.dump_opts
    on_collection_load.fire()



# Generated at 2022-06-11 17:42:36.166829
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from . import mazer_fixture

    test_counter = 0

    def on_collection_load_handler(collection_name, collection_path):
        global test_counter
        test_counter = test_counter + 1

    # add a handler and verify the value of test_counter
    AnsibleCollectionConfig.on_collection_load += on_collection_load_handler
    assert test_counter == 0

    # fire test and verify the value of test_counter
    AnsibleCollectionConfig.on_collection_load.fire(mazer_fixture.collection_name, mazer_fixture.collection_path)
    assert test_counter == 1

    # remove the handler and verify the value of test_counter
    AnsibleCollectionConfig.on_collection_load -= on_collection_load_handler
    assert test_counter == 1

# Generated at 2022-06-11 17:43:08.213646
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    def handler(event_source, a, b):
        return a + b

    event_source += handler
    assert event_source.fire(1, 2) == 3


# Generated at 2022-06-11 17:43:13.989477
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    x = ANSIBLE_COLLECTION_CONFIG.on_collection_load()

    with pytest.raises(ValueError, match='handler must be callable'):
        event_source += 'not_callable'

    event_source += lambda: 'handler'
    assert(event_source._handlers)


# Generated at 2022-06-11 17:43:17.489862
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda: None

    with pytest.raises(ValueError):
        e += object()

# Unit tests for method __isub__ of class _EventSource

# Generated at 2022-06-11 17:43:23.583764
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # AnsibleCollectionConfig._on_collection_load is a _EventSource subclass,
    # so we can use it to ensure that _on_exception is used properly
    _on_exception_called = [False]

    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            _on_exception_called[0] = True

    test = MyEventSource()
    test._handlers.add(lambda: 1/0)
    try:
        test.fire()
    except ZeroDivisionError:
        pass
    assert _on_exception_called[0], '_on_exception() must be called when an exception occurs'

# Generated at 2022-06-11 17:43:35.023313
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # we have a mock class which we can use to catch the firing of events
    class MockHandler:
        def __init__(self):
            self._fired = False
            self._args = ()
            self._kwargs = {}

        def __call__(self, *args, **kwargs):
            self._fired = True
            self._args = args
            self._kwargs = kwargs

    # create an event source
    source = _EventSource()

    # add the mock handler to the event source
    handler = MockHandler()
    source += handler

    # fire the event
    source.fire()

    # test the handler was fired
    assert handler._fired is True

    # test the handler received the signal
    assert handler._args == ()
    assert handler._kwargs == {}

# Generated at 2022-06-11 17:43:47.874031
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler_callable_1(arg1, arg2):
        pass

    def handler_callable_2(arg1):
        pass

    def handler_callable_3():
        pass

    def handler_callable_4(arg1, arg2, arg3, arg4):
        pass

    event_source = _EventSource()

    # Check adding handler callables with different argument lists.
    event_source += handler_callable_1
    event_source += handler_callable_2
    event_source += handler_callable_3
    event_source += handler_callable_4

    assert [handler_callable_1, handler_callable_2, handler_callable_3, handler_callable_4] == list(event_source._handlers)

    # Check adding the same handler callable with different argument lists

# Generated at 2022-06-11 17:43:53.073758
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    from ansible_collections.ansible.builtin import load_plugins
    from ansible_collections.ansible.collection_loader.tests.unit.test_plugin_loader import _load_plugins_path_mock

    plugin_loader = load_plugins()
    plugin_loader._load_plugins_path = _load_plugins_path_mock

# Generated at 2022-06-11 17:43:59.669436
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    cb_called = 0

    def callback(a, b):
        nonlocal cb_called
        cb_called += 1
        return a + b

    source = _EventSource()
    source += callback
    assert source.fire(1, 2) == 3, 'should have called the callback and returned 3'
    assert cb_called == 1, 'should have called the callback once'
    source -= callback
    assert source.fire(1, 2) == 0, 'should not have called the callback and returned 0'
    assert cb_called == 1, 'should have called the callback once'

# Generated at 2022-06-11 17:44:03.055116
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    result = []
    handler = lambda: result.append(0)
    event = _EventSource()
    event += handler
    event += handler
    event += handler
    event.fire()
    assert result == [0, 0, 0]

# Generated at 2022-06-11 17:44:12.286110
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Ensure event handlers are invoked in FIFO order
    def handler1(*args, **kwargs):
        assert args == (1,)
        assert kwargs == {}
        history.append(1)

    def handler2(*args, **kwargs):
        assert args == (1,)
        assert kwargs == {}
        history.append(2)

    history = []
    event = _EventSource()
    event.fire(1)

    event += handler1
    event.fire(1)
    event += handler2
    event.fire(1)
    assert history == [1, 1, 2]

    # Ensure event handlers are not invoked after removal
    event -= handler1
    event.fire(1)
    assert history == [1, 1, 2, 2]

    # Ensure exceptions raised by event handlers do not prevent other handlers from