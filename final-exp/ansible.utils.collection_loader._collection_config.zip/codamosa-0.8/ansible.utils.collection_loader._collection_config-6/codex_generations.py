

# Generated at 2022-06-11 17:34:32.776664
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0
    event_source += lambda: None
    assert len(event_source._handlers) == 1
    event_source += lambda: None
    assert len(event_source._handlers) == 1
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-11 17:34:36.168435
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    try:
        event_source += 1
        raise AssertionError('ValueError not raised')
    except ValueError:
        pass
    finally:
        event_source -= 1


# Generated at 2022-06-11 17:34:44.995498
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    assert not event.fire()

    # handler returns nothing
    call_count = [0]
    handler_1 = lambda: call_count.__setitem__(0, call_count.__getitem__(0) + 1)
    event += handler_1
    assert event.fire()
    assert call_count.__getitem__(0) == 1

    # handler returns something
    handler_2 = lambda: 'not None'
    event += handler_2
    assert event.fire()

    # handler raises an exception
    def handler_3():
        raise RuntimeError('fail')

    event += handler_3
    try:
        event.fire()
        assert False, 'expected fire() to raise expection'
    except RuntimeError as ex:
        assert to_text(ex) == 'fail'

# Generated at 2022-06-11 17:34:51.222526
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_no_exc(*args, **kwargs):
        handler_no_exc.fired = True

    def handler_with_no_chaining_exc(*args, **kwargs):
        handler_with_no_chaining_exc.fired = True
        raise RuntimeError('DOH!')

    def handler_with_chaining_exc(*args, **kwargs):
        handler_with_chaining_exc.fired = True
        raise RuntimeError('DOH!')

    class _EventSourceWithChainingExc(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    es = _EventSource()
    es += handler_no_exc
    es += handler_with_no_chaining_exc
    es += handler_with_chaining_exc

    es

# Generated at 2022-06-11 17:34:53.450518
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    handler = lambda: None

    source = _EventSource()

    source += handler

    assert source._handlers == {handler, }


# Generated at 2022-06-11 17:35:03.961699
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler_1():
        handler_1.events = handler_1.events + 1

    def handler_2(x, y):
        handler_2.events = handler_2.events + 1
        return x + y

    def handler_3():
        raise RuntimeError('error')

    def handler_4():
        raise ValueError('error')

    def on_exception_1(handler, ex, *args, **kwargs):
        on_exception_1.events = on_exception_1.events + 1
        return isinstance(ex, RuntimeError)

    def on_exception_2(handler, ex, *args, **kwargs):
        on_exception_2.events = on_exception_2.events + 1
        return False


# Generated at 2022-06-11 17:35:06.636626
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    called = [0]
    def handler():
        called[0] += 1
    event += handler
    event.fire()
    assert called == [1]

# Generated at 2022-06-11 17:35:13.258123
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test that calling fire() with no handlers does not raise
    event = _EventSource()
    event.fire(3)

    # test that calling fire() with a handler that returns 1 does not raise
    collection_paths = set()
    handler = lambda *args, **kwargs: collection_paths.add(1)
    event += handler
    event.fire(2)
    assert 1 in collection_paths

    # test that calling fire() with a handler that returns None does not raise
    collection_paths.clear()
    event += lambda *args, **kwargs: None
    event.fire(3)
    assert 1 in collection_paths

    # test that calling fire() with a handler that raises IOError does not cause fire() to bubble the exception
    collection_paths.clear()

# Generated at 2022-06-11 17:35:21.491707
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # mock handlers
    var = 0

    def handler0(value):
        global var
        var = var + 2 * value

    def handler1(value):
        raise RuntimeError('test')

    # create event source for test
    source = _EventSource()
    source += handler0
    source += handler1
    source += handler0

    # test expected behavior
    source.fire(1)

    assert var == 4

    # test unexpected behavior
    try:
        source.fire(2)
    except RuntimeError:
        assert var == 8
    else:
        assert False, 'RuntimeError was not raised'

# Generated at 2022-06-11 17:35:25.298956
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_one(event_args):
        event_args.append('one')

    def handler_two(event_args, additional_arg='two'):
        event_args.append(additional_arg)

    def handler_three(event_args):
        raise ValueError

    event_source = _EventSource()
    event_source += handler_one
    event_source += handler_two
    event_source += handler_three

    event_args = []
    event_source.fire(event_args, additional_arg='handler_two')
    assert event_args == ['one', 'handler_two', 'two']

    event_source -= handler_one
    event_args = []
    event_source.fire(event_args)
    assert event_args == ['two']

    event_source -= handler_three
    event

# Generated at 2022-06-11 17:35:39.036642
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def assert_event_source_raises_value_error(event_source, handler):
        error_msg = 'handler must be callable'
        try:
            event_source += handler
        except ValueError as ex:
            assert error_msg == str(ex)
        else:
            assert False, 'should have raised ValueError'

    from ansible.module_utils._text import to_text

    es = _EventSource()
    h1 = None
    h2 = None

    # add type handler to event source twice
    h1 = lambda: None
    es += h1
    es += h1
    assert es._handlers == set([h1])

    # add handler of incorrect type to event source
    h2 = to_text('hello world')

# Generated at 2022-06-11 17:35:50.576374
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Create a _EventSource object and test it's _handlers attribute
    es = _EventSource()
    assert isinstance(es._handlers, set)

    # Test adding a handler that is callable
    def handler_1(foo, bar=None):
        return foo
    assert callable(handler_1)
    es += handler_1
    handlers = es._handlers
    assert handler_1 in handlers
    assert len(handlers) == 1

    # Test adding a handler that is not callable
    def handler_2():
        return es
    assert callable(handler_2)
    # Remove handler_2 from handlers, so it doesn't cause next test to pass
    # i.e., handler_2
    handlers.remove(handler_2)

# Generated at 2022-06-11 17:35:58.655070
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_collections.ansible_collections_clipboard.clipboard.tests.unit.compat.mock import patch

    test_Event = _EventSource()

    def mock_exec_handler(*args, **kwargs):
        return args[2] * 3

    with patch.object(test_Event, '_on_exception') as mock_on_exception:
        # Failed test call
        mock_on_exception.return_value = False
        test_Event += mock_exec_handler
        assert 'foo' == test_Event.fire('foo')

        # Succeeded test call
        mock_on_exception.return_value = True
        assert 'foofoofoo' == test_Event.fire('foo')



# Generated at 2022-06-11 17:36:04.119799
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.common.text.converters import to_bytes

    method = lambda: to_bytes('foo')

    s = _EventSource()
    assert method not in s._handlers
    s += method
    assert s._handlers == {method}
    assert method in s._handlers



# Generated at 2022-06-11 17:36:11.160598
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def _handler1(a, b, c):
        assert a == 'a'
        assert b == 'b'
        assert c == 'c'

    def _handler2(a, b, c):
        assert a == 'a'
        assert b == 'b'
        assert c == 'c'

    s = _EventSource()
    s += _handler1
    assert _handler1 in s._handlers
    s += _handler2
    assert _handler2 in s._handlers

    s.fire('a', 'b', 'c')

# Generated at 2022-06-11 17:36:16.445009
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2):
        result.append('handler1')

    def handler2(arg1, arg2):
        result.append('handler2')

    result = []

    event = _EventSource()
    event += handler1
    event += handler2

    event.fire('arg1', 'arg2')
    assert result == ['handler1', 'handler2']

# Generated at 2022-06-11 17:36:23.178103
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class MyEventSource(_EventSource):
        pass

    e = MyEventSource()

    # try adding a callable
    def test(a, b, c):
        pass
    e += test

    # try adding a non-callable object
    try:
        e += 'I am not callable'
        assert False, 'expected ValueException to be raised'
    except ValueError:
        pass


# Generated at 2022-06-11 17:36:33.034160
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Handler:
        def __init__(self, test_case):
            self.test_case = test_case

        def __call__(self, *args, **kwargs):
            if self.test_case.counter == 0:
                self.test_case.assertEqual(args, (1, 2, 3))
                self.test_case.assertEqual(kwargs, {'a': 'b'})
            else:
                self.test_case.assertEqual(args, ())
                self.test_case.assertEqual(kwargs, {})
            self.test_case.counter += 1

    class ExceptionHandler:
        def __init__(self, test_case):
            self.test_case = test_case

        def __call__(self, *args, **kwargs):
            self.test

# Generated at 2022-06-11 17:36:38.494843
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    tes = TestEventSource()

    class CustomException(Exception):
        pass

    def handler_one():
        raise CustomException

    def handler_two(*args, **kwargs):
        pass

    tes += handler_one
    tes += handler_two

    tes.fire()

# Generated at 2022-06-11 17:36:48.078153
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(message):
        pass

    def handler2(message):
        pass

    if __name__ == '__main__':
        # unit test code
        import pytest
        import unittest.mock

        # test handler1 and handler2 are added
        event_source = _EventSource()
        event_source += handler1
        assert handler1 in event_source._handlers

        event_source += handler2
        assert handler2 in event_source._handlers

        # test duplicate handler is rejected
        event_source += handler1
        assert len(event_source._handlers) == 2

        # test non-callable handler is rejected
        with pytest.raises(ValueError):
            event_source += 'bad'


# Generated at 2022-06-11 17:36:59.890761
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    assert event_source._handlers == set()
    assert event_source.fire(1, 2, 3) == None



# Generated at 2022-06-11 17:37:08.091269
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # the method __iadd__ is only called for the following statement:
    # AnsibleCollectionConfig.on_collection_load += <handler>
    inner_handler_called = False

    def inner_handler():
        nonlocal inner_handler_called
        inner_handler_called = True

    def outer_handler(event_source):
        event_source += inner_handler

    event = _EventSource()
    # event += <handler>
    outer_handler(event)

    assert event._handlers
    assert inner_handler in event._handlers

    # fire the event
    event.fire()
    assert inner_handler_called



# Generated at 2022-06-11 17:37:13.692771
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    def foo():
        pass

    e += foo

    try:
        e += 1
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised for invalid handler')

    assert foo in e._handlers

    e += foo

    assert len(e._handlers) == 1, 'duplicate handlers should be ignored'

    e -= foo
    assert not e._handlers



# Generated at 2022-06-11 17:37:22.330334
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create class a which is a subclass of _EventSource
    class a(_EventSource):
        def __init__(self):
            super(a, self).__init__()

    # Create object event of class a
    event = a()
    # Create empty array handlers
    handlers = []
    # Add 5 handlers to array handlers
    for i in range(1, 6):
        # Add handler to array handlers
        handlers.append(lambda x=i: print(x))
    # Add handlers to object event
    for h in handlers:
        event += h
    # Call method fire of object event
    event.fire()

# Generated at 2022-06-11 17:37:29.466254
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test with an exception
    def handler_1(name='', verbose=True):
        raise ValueError('foo')

    # test with an unsupported type
    def handler_2(name='', verbose=True):
        return 'foo'

    # test with a callable
    def handler_3(name='', verbose=True):
        pass

    # test with a missing parameter
    def handler_4(verbose=True):
        pass

    evt = _EventSource()
    evt += handler_1
    evt += handler_2
    evt += handler_3
    evt += handler_4

    # evt.fire('bar', True)
    try:
        evt.fire('bar', True)
    except ValueError:
        assert True

# Generated at 2022-06-11 17:37:39.021523
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class test_handler:
        def __init__(self, trace=None):
            if trace:
                self.trace = trace
            else:
                self.trace = []
            self.trace += ['__init__']

        def handler(self, *args, **kwargs):
            self.trace += ['handler']
            return self.trace

    event_source = _EventSource()

    handler1 = test_handler()
    assert event_source._handlers == set()
    event_source += handler1.handler
    assert event_source._handlers == {handler1.handler}

    handler2 = test_handler()
    event_source += handler2.handler
    assert event_source._handlers == {handler1.handler, handler2.handler}

    handler3 = test_handler()
    assert handler3.handler not in event_

# Generated at 2022-06-11 17:37:43.425326
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert es.fire(1, 2, 3) is None
    def handler(*args):
        assert args == (1, 2, 3)

    es += handler
    assert es.fire(1, 2, 3) is None


# Generated at 2022-06-11 17:37:48.468172
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    foo = False
    bar = False
    def foo_handler(*args, **kwargs):
        nonlocal foo
        foo = True

    def bar_handler(*args, **kwargs):
        nonlocal bar
        bar = True

    es = _EventSource()
    es += foo_handler
    es += bar_handler
    es.fire()

    assert foo
    assert bar

# Generated at 2022-06-11 17:37:58.626448
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _EventSourceTest(object):
        def initiate(self):
            self._event_source = _EventSource()

        def add_handler(self):
            self._handler_count += 1
            self._event_source += self._handler

        def remove_handler(self):
            self._event_source -= self._handler

        def test_no_handlers(self):
            event_source = _EventSource()
            event_source.fire()

        def test_single_handler(self):
            self._handler_count = 0
            self._handler = self._handler1
            self._event_source.fire()
            assert self._handler_count == 1

        def test_two_handlers(self):
            self._handler_count = 0
            self._handler = self._handler1
            self.add_handler()
            self

# Generated at 2022-06-11 17:38:02.521439
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    observed = []

    def handler(sender, *args, **kwargs):
        observed.extend(args)
        observed.extend(kwargs.values())

    event = _EventSource()

    event += handler

    event.fire(1, 2, three=3)

    assert observed == [1, 2, 3]



# Generated at 2022-06-11 17:38:23.888141
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

    def foo(a, b):
        assert a == 1
        assert b == 2

    def bar(a, b):
        assert a == 1
        assert b == 2

    AnsibleCollectionConfig.on_collection_load += foo
    AnsibleCollectionConfig.on_collection_load += bar
    AnsibleCollectionConfig.on_collection_load.fire(1, 2)


# Generated at 2022-06-11 17:38:34.795806
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Unit: Called handler raises exception, default exception handling does not re-raise
    def _test__EventSource_fire_raise_default_handler(event_source):
        class ExceptionLogic(Exception):
            pass

        # mock out default exception handling processing
        old_default_on_exception = event_source._on_exception

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        event_source._on_exception = _on_exception

        def _build_handler():
            def _handler(*args, **kwargs):
                raise ExceptionLogic('dummy exception')

            return _handler

        handler = _build_handler()

        event_source += handler
        event_source.fire()

        event_source -= handler

        # restore default exception handling processing
        event_

# Generated at 2022-06-11 17:38:47.226501
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []

    def handler1(arg1, arg2):
        calls.append(('handler1', arg1, arg2))

    def handler2(arg1, arg2):
        if arg1 == 'call2':
            raise ValueError('expected')

    def handler3(arg1, arg2):
        calls.append(('handler3', arg1, arg2))

    es = _EventSource()

    es += handler1
    es += handler2
    es += handler3

    # handler2 raises exception so handler1 and handler3 are called
    es.fire('call1', 'call1')
    assert calls == [
        ('handler1', 'call1', 'call1'),
        ('handler3', 'call1', 'call1')
    ]
    calls[:] = []

    # handler2 raises exception but is not called

# Generated at 2022-06-11 17:38:57.401857
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class ObjDummy(object):
        def __init__(self, val):
            self.val = val

        def method(self, *args, **kwargs):
            print("called method with args=%s, kwargs=%s" % (args, kwargs))
            if self.val == 5:
                raise TestException("fail on %s" % self.val)

    class FireTest(object):
        def __init__(self):
            self.fire_event = None

        def __call__(self, *args, **kwargs):
            self.fire_event = args[0]

    def test_fire():
        test_list = [ObjDummy(i) for i in range(10)]
        fire_result = FireTest()
        evt_src

# Generated at 2022-06-11 17:39:02.492915
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Test_AnsibleCollectionConfig(_AnsibleCollectionConfig):
        @property
        def on_collection_load(self):
            return self._on_collection_load

        def is_fire_called(self):
            self._fire_called = True

    event_source = Test_AnsibleCollectionConfig()
    event_source.on_collection_load += event_source.is_fire_called
    event_source.on_collection_load.fire()

    assert event_source._fire_called

# Generated at 2022-06-11 17:39:08.691194
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler_1():
        pass

    def handler_2():
        pass

    es += handler_1
    assert handler_1 in es._handlers

    es += handler_2
    assert handler_2 in es._handlers

    es += handler_1
    assert len(es._handlers) == 2  # should be ignoring duplicates

    def handler_3():
        pass

    es += handler_3
    assert len(es._handlers) == 3


# Generated at 2022-06-11 17:39:19.092614
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    '''
    function __iadd__ will add an event handler
    '''

    class EventA(_EventSource):
        def __init__(self):
            self._handlers = set()

    a = EventA()
    assert len(a._handlers) == 0

    def test_handler(a):
        a = a + 1

    a += test_handler
    assert len(a._handlers) == 1

    def test_handler_2(a):
        a = a + 1

    a += test_handler_2
    assert len(a._handlers) == 2

    a -= test_handler
    assert len(a._handlers) == 1

    a -= test_handler_2
    assert len(a._handlers) == 0


# Generated at 2022-06-11 17:39:24.512340
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(param1, param2):
        raise Exception('not implemented')

    def handler2(param1, param2):
        raise Exception('not implemented')

    source = _EventSource()
    source += handler1
    source += handler2

    source.fire(1, 2)

    source -= handler1
    source.fire(1, 2)


# Generated at 2022-06-11 17:39:27.021909
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()

    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-11 17:39:34.723668
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # This is the simplest case of an event handler, it takes no parameters
    def handler1(value):
        handler1_fired.append(value)

    def handler2(value):
        handler2_fired.append(value)

    # Test firing an event with no handlers
    handler1_fired = []
    handler2_fired = []
    event = _EventSource()
    event.fire(1)
    assert len(handler1_fired) == 0
    assert len(handler2_fired) == 0

    # Test firing an event with one handler
    handler1_fired = []
    handler2_fired = []
    event = _EventSource()
    event += handler1
    event.fire(2)
    assert len(handler1_fired) == 1
    assert handler1_fired == [2]

# Generated at 2022-06-11 17:40:10.092629
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self):
            self._fired = False

        def fire(self, *args, **kwargs):
            self._fired = True

        def assert_fired(self):
            assert self._fired

    test_event = _EventSource()
    obj1 = Test()
    obj2 = Test()

    test_event += obj1.fire
    test_event += obj2.fire

    fired = test_event.fire()
    fired = test_event.fire()

    obj1.assert_fired()
    obj2.assert_fired()



# Generated at 2022-06-11 17:40:21.263466
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    set_called = False

    def handler1(*args, **kwargs):
        raise Exception('test exception')

    def handler2(*args, **kwargs):
        raise ValueError('test value error')

    def handler3(*args, **kwargs):
        nonlocal set_called
        set_called = True

    # test a single handler that raises an exception
    es1 = _EventSource()
    es1 += handler1
    try:
        es1.fire()
        assert False
    except Exception as ex:
        if 'test exception' not in to_text(ex):
            raise
    except:
        assert False

    # test multiple handlers that raise an exception
    es2 = _EventSource()
    es2 += handler1
    es2 += handler2
    es2 += handler3

# Generated at 2022-06-11 17:40:32.699007
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class FireTest(with_metaclass(_AnsibleCollectionConfig)):
        def __init__(self):
            self.executed_handlers = []

        def fire(self, handler, exc, *args, **kwargs):
            self.executed_handlers.append((handler, exc, args, kwargs))
            return False

    test_obj = FireTest()

    def handler1(arg1):
        return arg1 + 1

    test_obj.on_collection_load += handler1
    test_obj.fire(handler1, 'exception string', 1)

    assert len(test_obj.executed_handlers) == 1
    assert test_obj.executed_handlers[0][0][0](1) == 2

# Generated at 2022-06-11 17:40:40.170426
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()
    y = _EventSource()

    def handler1(a, b, c='c'):
        print('handler1', a, b, c)

    def handler2(a, b, c='c'):
        print('handler2', a, b, c)

    # make sure that our __iadd__ implementation puts the handler in the set
    x += handler1
    assert(handler1 in x._handlers)
    assert(len(x._handlers) == 1)

    # make sure that our __iadd__ implementation puts the handler in the set
    x += handler2
    assert(handler2 in x._handlers)
    assert(len(x._handlers) == 2)

    # make sure that adding a non-callable raises an exception

# Generated at 2022-06-11 17:40:47.934257
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Foo(object):
        def __init__(self, expected_exc=None):
            self.event_handler_exc = expected_exc

        def event_handler(self, extra_arg1, extra_arg2, **kwargs):
            if self.event_handler_exc is not None:
                raise self.event_handler_exc

        def event_handler_exception_handler(self, handler, ex, *args, **kwargs):
            return self.event_handler_exc is not None and handler == self.event_handler

    class Bar(Foo):
        def event_handler(self, *args, **kwargs):
            super(Bar, self).event_handler(*args, **kwargs)
            raise Exception('boom')


# Generated at 2022-06-11 17:40:50.647364
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda: (1/0)
    try:
        event.fire()
    except ZeroDivisionError:
        pass
    else:
        assert False


# Generated at 2022-06-11 17:41:01.169505
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import sys
    import pytest

    class MyClass:
        def __init__(self):
            self.called = 0

        def __call__(self):
            self.called += 1

    mc1 = MyClass()
    mc2 = MyClass()

    ev = _EventSource()
    assert ev.fire()

    ev += mc1
    ev += mc2

    assert ev.fire()
    assert mc1.called == 1
    assert mc2.called == 1

    ev += mc1
    assert ev.fire()
    assert mc1.called == 2
    assert mc2.called == 2

    with pytest.raises(ValueError):
        ev += 123

    ev -= mc1
    assert ev.fire()
    assert mc1.called == 2
    assert mc2.called == 3

    ev -= mc1

# Generated at 2022-06-11 17:41:08.339410
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(a, b=None):
        print(a, b)

    es = _EventSource()
    assert(len(es._handlers) == 0)
    assert(callable(handler))
    es.__iadd__(handler)
    assert(len(es._handlers) == 1)
    es.__iadd__(handler)
    assert(len(es._handlers) == 1)



# Generated at 2022-06-11 17:41:13.837154
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()
    x += lambda x: x
    x += lambda y, z: y + z

    def add(y, z=3):
        return y + z

    x += add

    if hasattr(x._handlers, '__iter__'):
        x._handlers = set(x._handlers)
    assert x._handlers == {lambda x: x, lambda y, z: y + z, add}, 'x._handlers must contain the three function references'

# Generated at 2022-06-11 17:41:23.160668
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # We invoke EventSource.fire with a set of handlers that raise and one that
    # does not.  We catch the exception and check the traceback.  The traceback
    # should point to the correct exception.

    class MyException(Exception):
        pass

    def raise_e():
        raise MyException()

    def dont_raise():
        pass

    # The set of handlers to test
    handlers = [raise_e, dont_raise, raise_e]

    # Call fire and catch the exception
    o = _EventSource()
    o._handlers = handlers

    try:
        o.fire()
    except MyException as e:
        tb = e.__traceback__

    while tb.tb_next:
        tb = tb.tb_next

    assert tb.tb_frame.f_

# Generated at 2022-06-11 17:41:55.809685
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0
    es += lambda: None
    assert len(es._handlers) == 1
    es += lambda: None
    assert len(es._handlers) == 2


# Generated at 2022-06-11 17:42:00.097640
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    called = []

    es += lambda: called.append('one')
    es += lambda: called.append('two')
    es += lambda: called.append('three')

    es.fire()

    assert called == ['one', 'two', 'three']

# Generated at 2022-06-11 17:42:05.601037
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evt = _EventSource()
    calls = []

    def handle(a, b, c=''):
        calls.append((a, b, c))

    evt += handle
    evt.fire(1, 2)
    evt += handle
    evt.fire(1, 2, c='hello')

    if calls != [(1, 2, ''), (1, 2, ''), (1, 2, 'hello'), (1, 2, 'hello')]:
        raise AssertionError()

# Generated at 2022-06-11 17:42:14.714675
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self._on_exception = self.on_exception

        def on_exception(self, handler, exc, *args, **kwargs):
            if type(exc) is ValueError:
                return False
            return True

    ms = MyEventSource()
    result = []

    def handler1(s, *args, **kwargs):
        result.append(('h1_args', args, kwargs))

    def handler2(s, *args, **kwargs):
        result.append(('h2_args', args, kwargs))
        raise ValueError('foo')


# Generated at 2022-06-11 17:42:21.388257
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    assert event_source.fire() is None

    class TestException(Exception):
        pass

    class TestContextManager(object):
        def __enter__(self):
            pass

        def __exit__(self, exc_type, value, traceback):
            return exc_type is TestException

    test_context_manager = TestContextManager()

    def test_handler(a, b=None, c=None):
        assert a == 1
        assert b == 2
        assert c == 3

    def test_handler_with_context_manager():
        with test_context_manager:
            raise TestException()

    def test_handler_with_exception(a, b=None, c=None):
        assert a == 1
        assert b == 2
        assert c == 3
        raise TestException

# Generated at 2022-06-11 17:42:31.938788
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestException(Exception):
        def __init__(self, prefix, value):
            self.prefix = prefix
            self.value = value

    def func_raises(ex):
        def do_raise(*_args, **_kwargs):
            raise ex
        return do_raise

    def silent_func(_a, _k):
        pass

    # first, test to make sure unhandled exceptions are re-raised by default
    es = _EventSource()
    es += silent_func
    es += func_raises(TestException('a', 1))

    try:
        es.fire()
        raise Exception('Expected exception')
    except TestException as ex:
        assert ex.prefix == 'a'
        assert ex.value == 1

    # now we'll test handling the exception by overriding _on_exception in a method


# Generated at 2022-06-11 17:42:41.791507
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestObject:
        def __init__(self):
            self.count = 0

        def inc(self, amount=1):
            self.count += amount
            return self.count

        @staticmethod
        def raise_exc(exc):
            raise exc

    import unittest

    class Test_EventSource(unittest.TestCase):
        def test_handlers(self):
            obj1 = TestObject()
            obj2 = TestObject()
            source = _EventSource()
            source += obj1.inc
            source += obj2.inc

            source.fire(amount=2)

            self.assertEqual(obj1.count, 2)
            self.assertEqual(obj2.count, 2)

        def test_exception_is_not_caught(self):
            source = _EventSource()

# Generated at 2022-06-11 17:42:47.727301
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest(with_metaclass(_AnsibleCollectionConfig)):
        on_collection_load = _EventSource()

    # mock handler
    handler = lambda *args, **kwargs : args

    # create the object
    obj = EventSourceTest()

    # add the handler
    obj.on_collection_load += handler

    # fire the event
    obj.on_collection_load.fire('foo', 'bar', 'baz')


# Generated at 2022-06-11 17:42:50.164992
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    event_source = _EventSource()
    event_handler = lambda: None

    event_source += event_handler

    assert event_handler in event_source._handlers


# Generated at 2022-06-11 17:42:56.975812
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    count_a = [0]
    count_b = [0]
    event_source += lambda *a, **kw: count_a.__setitem__(0, count_a[0] + 1)
    event_source += lambda *a, **kw: count_b.__setitem__(0, count_b[0] + 1)
    event_source.fire()
    assert count_a[0] == 1
    assert count_b[0] == 1


# Generated at 2022-06-11 17:44:02.895396
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler1(x):
        print('handler1: %s' % x)

    def handler2(x):
        print('handler2: %s' % x)
        raise ValueError('simulated exception')

    def handler3(x):
        print('handler3: %s' % x)

    event = _EventSource()
    event += handler1
    event += handler2
    event += handler3

    event.fire('hello')

# Generated at 2022-06-11 17:44:12.165925
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    bool_handler_called = False
    bool_handler_1_called = False
    bool_handler_2_called = False
    int_handler_called = False
    int_handler_3_called = False
    str_handler_called = False
    obj_handler_called = False
    int_arg_1 = 3
    int_arg_2 = 5
    str_key_arg_1 = 'a'
    str_val_arg_1 = 'A'
    str_key_arg_2 = 'b'
    str_val_arg_2 = 'B'
    int_key_arg_1 = 'x'
    int_val_arg_1 = 123
    int_key_arg_2 = 'y'
    int_val_arg_2 = 456


# Generated at 2022-06-11 17:44:21.119251
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    on_collection_load = event

    def test_func(arg1, arg2):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'

    assert event._handlers == set()
    on_collection_load += test_func
    assert event._handlers == {test_func}
    on_collection_load += test_func
    assert event._handlers == {test_func}
    on_collection_load -= test_func
    assert event._handlers == {test_func}
    on_collection_load -= test_func
    assert event._handlers == set()

# Generated at 2022-06-11 17:44:23.125635
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestClass:
        pass

    source = _EventSource()
    source.__iadd__(TestClass())
