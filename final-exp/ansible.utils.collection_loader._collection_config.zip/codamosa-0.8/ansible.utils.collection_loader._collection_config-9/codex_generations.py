

# Generated at 2022-06-11 17:34:34.481413
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class _TestEventSource(AnsibleCollectionConfig):
        def _on_exception(self, handler, exc, *args, **kwargs):
            if isinstance(exc, TestException):
                return False  # swallow the exception
            return True  # re-raise the exception

    test_event_source = _TestEventSource()

    def _bad_handler():
        raise TestException('this exception is swallowed')

    def _good_handler():
        raise Exception('this exception is re-raised')

    def _exception_handler():
        raise Exception('this exception is ignored')

    test_event_source += _bad_handler
    test_event_source += _good_handler
    test_event_source += _exception_handler

    test_event_source.fire()


# Unit

# Generated at 2022-06-11 17:34:37.091811
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    callback = lambda : 'ok'
    result = event.fire()

    assert result is None

    event += callback
    result = event.fire()

    assert result is None

    event -= callback

# Generated at 2022-06-11 17:34:39.457239
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    handler = _EventSource()
    def sample_callable():
        pass
    handler += sample_callable
    assert sample_callable in handler._handlers


# Generated at 2022-06-11 17:34:41.938840
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: True
    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers



# Generated at 2022-06-11 17:34:49.394012
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test event handler that (1) increments a counter, (2) returns the passed arguments
    class _TestEventHandler:
        def __init__(self, counter):
            self.counter = counter
            self.invoke_count = 0
            self.args = None
            self.kwargs = None

        def __call__(self, *args, **kwargs):
            self.counter.increment()
            self.invoke_count += 1
            self.args = args
            self.kwargs = kwargs

    # Test event handler with an exception handler
    class _TestEventHandlerException:
        def __init__(self, counter, exc):
            self.counter = counter
            self.exc = exc
            self.invoke_count = 0
            self.args = None
            self.kwargs = None


# Generated at 2022-06-11 17:34:57.298669
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    # test case #1: handler returns normally
    class MockHandler:
        def __call__(self, *args, **kwargs):
            pass

    e = _EventSource()
    e += MockHandler()
    e.fire(1, 2, 3)

    # test case #2: handler raises an exception
    class MockException(Exception):
        pass

    class MockHandler:
        def __call__(self, *args, **kwargs):
            raise MockException()

    e = _EventSource()
    e += MockHandler()
    with pytest.raises(MockException):
        e.fire(1, 2, 3)

    # test case #2.1: handler raises an exception, but is not re-raised
    class MockException(Exception):
        pass


# Generated at 2022-06-11 17:35:04.275503
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()

    def handler1(x, y, z): pass
    x += handler1

    def handler2(x, y, z):
        raise ValueError('some error')
    x += handler2

    def handler3(x, y, z): pass
    x += handler3

    called = []

    def handler4(x, y, z):
        called.append(x)

    x += handler4

    x.fire(1, 2, 3)

    assert called == [1]


# Generated at 2022-06-11 17:35:08.715190
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evt = _EventSource()

    def test_handler_1(value):
        assert value == 13

    def test_handler_2(value):
        assert value == 13

    evt += test_handler_1
    evt += test_handler_2
    evt.fire(13)

test__EventSource_fire()


# Generated at 2022-06-11 17:35:12.861297
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == {'a': 1, 'b': 2}

    event = _EventSource()
    event += handler

    event.fire(1, 2, a=1, b=2)

# Generated at 2022-06-11 17:35:17.068126
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_collections.ansible.community.plugins.module_utils.collection_loader.collection_finder import _EventSource

    event_source = _EventSource()

    def handler(x):
        return x

    event_source += handler



# Generated at 2022-06-11 17:35:24.467125
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.errors import AnsibleError

    a = AnsibleError('test message')

    raised_exception = False

    evt = _EventSource()

    # first handler will NOT raise an exception
    def handler1(*args, **kwargs):
        pass

    evt += handler1

    # second handler will raise an exception
    def handler2(*args, **kwargs):
        raise AnsibleError('test message')

    evt += handler2

    # third handler will raise an exception but our on_exception handler
    # will return False causing a new version of the same exception to be raised
    def handler3(*args, **kwargs):
        raise AnsibleError('test message')

    evt += handler3


# Generated at 2022-06-11 17:35:33.157759
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler1(x):
        pass

    def handler2(x):
        raise ValueError

    def handler3(x):
        return True

    e = _EventSource()
    e += handler1
    e += handler2
    e += handler3

    with pytest.raises(ValueError):
        e.fire(1)

    e -= handler2

    with pytest.raises(ValueError):
        e.fire(1)

    e -= handler3

    e.fire(1)

    e += handler2
    e += handler3

    with pytest.raises(ValueError):
        e.fire(1)

    e -= handler3

    e.fire(1)


# Generated at 2022-06-11 17:35:40.638534
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # create event source
    eventsrc = _EventSource()

    # create event handlers
    def handler_unexpected_exception_reraise():
        raise RuntimeError()

    def handler_unexpected_exception_dont_reraise():
        raise RuntimeError()

    def handler_expected_exception_reraise():
        raise ValueError()

    def handler_expected_exception_dont_reraise():
        raise ValueError()

    class CustomException(Exception):
        pass

    def handler_custom_exception_reraise():
        raise CustomException()

    def handler_custom_exception_dont_reraise():
        raise CustomException()

    def handler_ok():
        pass

    # override method on_exception

# Generated at 2022-06-11 17:35:44.099629
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def _raise_exception_always(handler, exc, *args, **kwargs):
        raise TestException()

    def _raise_exception_never(handler, exc, *args, **kwargs):
        return False

    def _raise_exception_once(handler, exc, *args, **kwargs):
        handler._on_exception = _raise_exception_never
        return True

    def _do_something():
        pass

    event = _EventSource()
    event._do_something = _do_something

    # no handler
    event.fire()

    # single handler
    event += _do_something
    event.fire()

    # single handler which raises, but not re-raised
    event._on_exception = _raise_exception_never
    event

# Generated at 2022-06-11 17:35:54.431801
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(x):
        # print("EventHandler called {}".format(x))
        h_called.append(x)

    es = _EventSource()

    # test no handlers
    try:
        es.fire("Hi")
    except Exception as ex:
        print("test FAILED - unexpected exception when no handlers {}".format(repr(ex)))
    except Exception:
        print("test FAILED - unexpected exception when no handlers")

    try:
        es.fire("Hi")
    except Exception as ex:
        print("test FAILED - unexpected exception when no handlers {}".format(repr(ex)))
    except Exception:
        print("test FAILED - unexpected exception when no handlers")

    # test simple handler
    h_called = []
    es += handler

# Generated at 2022-06-11 17:35:55.207047
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource.fire()

# Generated at 2022-06-11 17:36:01.322264
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    def handler1(*args, **kwargs):
        raise Exception("Exception in handler1")
    def handler2(*args, **kwargs):
        raise Exception("Exception in handler2")
    event_source += handler1
    event_source += handler2
    try:
        event_source.fire("foo", "bar")
    except Exception as e:
        assert "Exception in handler1" in str(e)


# Generated at 2022-06-11 17:36:10.184786
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Handler:
        def __init__(self):
            self.received = []

        def __call__(self, *args, **kwargs):
            self.received.append((args, kwargs))

    source = _EventSource()

    h1 = Handler()
    source += h1
    source.fire(1, 2, 3, a=4, b=5, c=6)

    assert len(h1.received) == 1
    assert h1.received[0] == ((1, 2, 3), dict(a=4, b=5, c=6))



# Generated at 2022-06-11 17:36:13.458864
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    def handler_0(*args, **kwargs):
        pass
    event_source += handler_0
    assert handler_0 in event_source._handlers


# Generated at 2022-06-11 17:36:21.420460
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler1(*args, **kwargs):
        print('handler1 called with args={} kwargs={}'.format(args, kwargs))

    def handler2(*args, **kwargs):
        print('handler2 called with args={} kwargs={}'.format(args, kwargs))

    def handler3(*args, **kwargs):
        print('handler3 called with args={} kwargs={}'.format(args, kwargs))

    # adding handlers
    event_source += handler1
    event_source += handler2
    event_source += handler3

    # firing the event
    event_source.fire(1, 2, x=3, y=4)

    # removing handlers
    event_source -= handler3
    event_source -= handler1

    #

# Generated at 2022-06-11 17:36:31.024564
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    sut = _EventSource()
    handler = lambda: None
    sut += handler
    assert len(sut._handlers) == 1
    sut += handler
    assert len(sut._handlers) == 1
    sut += handler
    assert len(sut._handlers) == 1


# Generated at 2022-06-11 17:36:36.153850
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        pass

    x += handler_1
    x += handler_2

    assert handler_1 in x._handlers
    assert handler_2 in x._handlers



# Generated at 2022-06-11 17:36:41.032579
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fired = []

    def handler(*args, **kwargs):
        fired.append((args, kwargs))

    es = _EventSource()

    es += handler
    es.fire(1, 2, 3, a='x', b='y', c='z')

    assert fired == [(
        (1, 2, 3), {
            'a': 'x',
            'b': 'y',
            'c': 'z',
        }
    )]

# Generated at 2022-06-11 17:36:51.407343
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test callable handler
    def _test_callable_handler():
        pass

    x = _EventSource()
    x += _test_callable_handler
    assert _test_callable_handler in x._handlers

    # test non-callable handler
    def _test_non_callable_handler():
        pass

    _test_non_callable_handler.__call__ = None

    x = _EventSource()
    try:
        x += _test_non_callable_handler
        assert False, 'Expected ValueError'
    except ValueError:
        pass

    # test no exception
    x = _EventSource()
    x += _test_callable_handler
    x.fire()

    # test exception

# Generated at 2022-06-11 17:36:58.295285
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    assert isinstance(e, _EventSource)
    events = []

    def x(*args, **kwargs):
        events.append((args, kwargs))

    e += x
    e.fire('hello', 'world', spam=42)
    assert events == [((to_text('hello'), to_text('world')), {'spam': 42})]



# Generated at 2022-06-11 17:36:59.933648
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _EventSource.__iadd__(None, None)



# Generated at 2022-06-11 17:37:02.304140
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source.__iadd__('abc')


# Generated at 2022-06-11 17:37:10.550070
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils._text import to_bytes
    import os
    import sys

    # If Python 2.7 then we need to make sure that events are propagated to listeners encoded using UTF-8.
    if sys.version_info < (3, 0):
        encoding = 'utf-8'
        def py27_assert_is_bytes(s):
            assert isinstance(s, bytes)
    else:
        encoding = None
        def py27_assert_is_bytes(s):
            pass

    a = AnsibleCollectionConfig()
    a.on_collection_load += lambda x: print('added handler 1')
    a.on_collection_load += lambda x: print('added handler 2')
    a.on_collection_load += lambda x: print('added handler 3')


# Generated at 2022-06-11 17:37:14.493868
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def h1(msg):
        print('h1 %s' % msg)

    def h2(msg):
        print('h2 %s' % msg)

    es += h1
    es += h2

    es.fire('hello')



# Generated at 2022-06-11 17:37:25.792959
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def assert_raises(func, exc_type, *args, **kwargs):
        try:
            func(*args, **kwargs)
            raise AssertionError('did not raise exception')
        except exc_type as ex:
            pass

    event_source = _EventSource()

    def handler_one(*args, **kwargs):
        pass

    def handler_two(*args, **kwargs):
        raise TestException()

    def handler_three(*args, **kwargs):
        raise TestException()

    def handler_exception_handler(handler, exc, *args, **kwargs):
        assert isinstance(exc, TestException)
        return False

    event_source += handler_one
    event_source += handler_two
    event_source += handler_three
   

# Generated at 2022-06-11 17:37:34.939321
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler(*args, **kwargs):
        handler.num_fired += 1

    handler.num_fired = 0

    es += handler
    es.fire()

    assert handler.num_fired == 1



# Generated at 2022-06-11 17:37:38.489371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evt = _EventSource()

    results = []
    evt += lambda: results.append('first')
    evt += lambda: results.append('second')

    evt.fire()
    assert results == ['first', 'second']


# Generated at 2022-06-11 17:37:40.989586
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()
    target = []

    def appender(arg):
        target.append(arg)

    source += appender
    source += appender
    source += appender
    source.fire('test1')
    source.fire('test2')

    assert target == ['test1', 'test1', 'test1', 'test2', 'test2', 'test2']

# Generated at 2022-06-11 17:37:46.489619
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    # test that ValueError is raised for invalid handler
    raised = False
    try:
        es += 'not callable'
    except ValueError:
        raised = True
    assert raised

    def handler():
        pass

    assert handler not in es._handlers
    es += handler
    assert handler in es._handlers



# Generated at 2022-06-11 17:37:50.116185
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1

# Generated at 2022-06-11 17:37:58.875633
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Bunch:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    event = _EventSource()

    def f0():
        event.fire(Bunch(event_name='f0'))

    def f1(bunch):
        bunch.a = 'f1'
        if bunch.event_name.startswith('f0'):
            f0()

    def f2(bunch):
        bunch.a += ', f2'

    event += f1
    event += f2

    bunch = Bunch(event_name='top')
    bunch.a = ''
    event.fire(bunch)
    assert bunch.a == 'f1, f2'

# Generated at 2022-06-11 17:38:03.462849
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda *args, **kwargs: True

    try:
        event_source += 'not callable'
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-11 17:38:04.735705
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TODO: Write unit test
    pass


# Generated at 2022-06-11 17:38:15.381402
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()

    # no error
    def f1():
        pass

    s += f1

    # ValueError on non-callable
    def f2():
        s += None

    try:
        f2()
    except ValueError:
        pass
    else:
        raise AssertionError('expected ValueError')

    # handler captured
    h = []
    def f3():
        h.append(1)

    s += f3
    s.fire()

    if h != [1]:
        raise AssertionError('expected [1]')

    # Fire with event arguments
    h = []
    def f4(a, b):
        h.append((a, b))

    s += f4
    s.fire(1, 2)


# Generated at 2022-06-11 17:38:21.911660
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers
    event_source += handler
    assert len(event_source._handlers) == 1

    try:
        event_source += 1
        assert False
    except ValueError:
        pass


# Generated at 2022-06-11 17:38:36.925075
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def f():
        pass
    es += f
    assert f in es._handlers


# Generated at 2022-06-11 17:38:44.397028
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert callable(es)

    def handler():
        pass

    es += handler
    assert es._handlers == {handler}

    # no duplicate handlers
    es += handler
    assert es._handlers == {handler}

    # non-callable object
    try:
        es += 'not a callable'
        assert False
    except ValueError:
        pass



# Generated at 2022-06-11 17:38:49.856578
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Foo:
        def f1(self, arg1):
            return arg1

        def f2(self, arg1):
            return arg1

    c = _AnsibleCollectionConfig()
    on_collection_load = c.on_collection_load

    res_list = []

    def handler1(arg):
        res_list.append(arg)

    def handler2(arg):
        res_list.append(-arg)

    on_collection_load += handler1
    on_collection_load += handler2

    on_collection_load.fire(1)

    assert res_list == [1, -1]

# Generated at 2022-06-11 17:38:54.771546
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1
    es += lambda: None
    assert len(es._handlers) == 1
    es += lambda: None
    assert len(es._handlers) == 1


if __name__ == '__main__':
    test__EventSource___iadd__()

# Generated at 2022-06-11 17:38:58.504604
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # create an instance of class EventSource
    my_event_source = _EventSource()

    # create a handler to add to the event
    def handler(sender, *args, **kwargs):
        pass

    # exercise method __iadd__
    my_event_source += handler


# Generated at 2022-06-11 17:39:02.594121
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def dummy_event_handler_1(sender, **kwargs):
        pass

    def dummy_event_handler_2(sender, **kwargs):
        pass

    dummy_event_source = _EventSource()

    dummy_event_source += dummy_event_handler_1
    dummy_event_source += dummy_event_handler_2

    # note: no exception will be thrown
    dummy_event_source.fire()

# Generated at 2022-06-11 17:39:12.774416
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event_fire_count = 0
            self.event_args = None
            self.event_kwargs = None

        def __call__(self, *args, **kwargs):
            self.event_fire_count += 1
            self.event_args = args
            self.event_kwargs = kwargs

    e = TestEventSource()

    assert len(e._handlers) == 0

    def handler():
        pass

    e += handler
    assert len(e._handlers) == 1

    assert e.event_fire_count == 0
    assert e.event_args is None
    assert e.event_kwargs is None


# Generated at 2022-06-11 17:39:23.658295
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    # test a non-callable handler is rejected
    try:
        event_source.__iadd__({})
    except ValueError:
        pass
    else:
        assert False, 'expected ValueError'

    # test a callable handler is accepted
    try:
        event_source.__iadd__(lambda: None)
    except ValueError:
        assert False, 'unexpected ValueError'

    # test the return value
    assert event_source.__iadd__(lambda: None) is event_source

    # test a handler is added to this event_source
    handler = lambda: None
    event_source.__iadd__(handler)

    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers


# Generated at 2022-06-11 17:39:29.527473
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class LoggingEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    e = LoggingEventSource()

    def handle1(*args, **kwargs):
        pass

    def handle2(*args, **kwargs):
        pass

    e += handle1
    e += handle2

    e.fire()
    e.fire()

    e -= handle1
    e -= handle1

    e.fire()



# Generated at 2022-06-11 17:39:34.791484
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_handler = lambda: print('hello')
    source = _EventSource()

    source += test_handler
    assert source._handlers == {test_handler}

    source += test_handler
    assert source._handlers == {test_handler}

    source += 4
    assert source._handlers == {test_handler}


# Generated at 2022-06-11 17:40:03.983172
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Arrange
    ar = []
    es = _EventSource()
    es += lambda x: ar.append(x)

    # Act
    es.fire(42)

    # Assert
    assert ar == [42]

# Generated at 2022-06-11 17:40:07.289645
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    source += lambda value: print('lambda: %s' % value)
    source += foo

    source.fire(1, 2, 3)

    source -= foo
    source.fire(4, 5, 6)



# Generated at 2022-06-11 17:40:19.141821
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.counter = 0

        def __call__(self):
            self.counter += 1

    event_source = _EventSource()
    event_source += EventSourceTest()
    event_source.fire()
    event_source.fire()
    event_source.fire()

    assert event_source._handlers.__len__() == 1

    for h in event_source._handlers:
        assert h.counter == 3

    event_source += EventSourceTest()
    event_source += EventSourceTest()
    event_source += EventSourceTest()

    assert event_source._handlers.__len__() == 4

    for h in event_source._handlers:
        assert h.counter == 3

    event_source.fire()

    assert event_source._

# Generated at 2022-06-11 17:40:26.069107
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler(s, *args, **kwargs):
        print('handler1: {} {} {}'.format(s, args, kwargs))

    def handler2(s, *args, **kwargs):
        print('handler2: {} {} {}'.format(s, args, kwargs))
        raise Exception('some exception in handler')

    def handler3(s, *args, **kwargs):
        print('handler3: {} {} {}'.format(s, args, kwargs))

    event_source += handler
    event_source += handler2
    event_source += handler3
    event_source.fire('event 1', 'pos1', kwarg1='kwarg 1')


# Generated at 2022-06-11 17:40:36.811413
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class test_EventSource:
        def __init__(self):
            self.on_added = _EventSource()
            self.on_added += self.on_added_handler
            self.on_added -= self.on_added_handler

        def on_added_handler(self, item):
            pass

    test_event_source = test_EventSource()
    assert len(test_event_source.on_added._handlers) == 0
    assert test_event_source.on_added._handlers == set()

    test_event_source.on_added += test_event_source.on_added_handler
    assert len(test_event_source.on_added._handlers) == 1
    assert test_event_source.on_added._handlers == set([test_event_source.on_added_handler])



# Generated at 2022-06-11 17:40:45.393996
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def add_handler(event_handler):
        event_source += event_handler

    def remove_handler(event_handler):
        event_source -= event_handler

    def fire_event():
        event_source.fire()

    class MyHandler:
        def __init__(self):
            self.call_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1

    handler = MyHandler()
    add_handler(handler)

    fire_event()
    assert handler.call_count == 1

    fire_event()
    assert handler.call_count == 2

    fire_event()
    assert handler.call_count == 3

    remove_handler(handler)

    fire_event()

# Generated at 2022-06-11 17:40:55.167352
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    class MockHandler:
        def __init__(self):
            self._is_called = False

        def __call__(self, *args, **kwargs):
            self._is_called = True

        @property
        def is_called(self):
            return self._is_called

    def fhandler(exp_args, exp_kwargs):
        def _fhandler(*args, **kwargs):
            assert args == exp_args
            assert kwargs == exp_kwargs

        return _fhandler

    mock_handler = MockHandler()

    # Test binding valid handler
    event_source += mock_handler
    event_source.fire()
    assert mock_handler.is_called

    # Test binding valid method handler
    exp_args = (1, 2)
    exp_kw

# Generated at 2022-06-11 17:40:58.328610
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert handler in event_source._handlers



# Generated at 2022-06-11 17:41:10.833773
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    class _Handler(object):
        def __init__(self):
            self.event_name = None
            self.args = None
            self.kwargs = None

        def __call__(self, event_name, *args, **kwargs):
            self.event_name = event_name
            self.args = args
            self.kwargs = kwargs

    handler = _Handler()
    event_source += handler

    event_name = u'test_event'
    args = (u'arg1', u'arg2')
    kwargs = {u'kw1': u'kwarg1', u'kw2': u'kwarg2'}
    event_source.fire(event_name, *args, **kwargs)

    assert handler.event_name == event_

# Generated at 2022-06-11 17:41:19.773794
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # given
    class Dummy:
        def __init__(self, expected_value):
            self.expected_value = expected_value

        def __call__(self, value, **kwargs):
            if value != self.expected_value:
                raise ValueError('Received unexpected value: %s' % value)

    class DummySource(_EventSource):
        def _on_exception(self, handler, ex, *args, **kwargs):
            return False

    source = DummySource()
    source += Dummy('expected_value1')
    source += Dummy('expected_value2')

    # when
    source.fire('expected_value1')
    source.fire('expected_value2')

    # then no exception


# Generated at 2022-06-11 17:42:14.084983
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def _handler():
        pass

    event = _EventSource()

    event += _handler

    assert len(event._handlers) == 1


# Generated at 2022-06-11 17:42:19.438316
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    f1 = lambda *args, **kwargs: None
    f2 = lambda *args, **kwargs: None
    assert e._handlers == set()
    e += f1
    assert e._handlers == {f1}
    e += f2
    assert e._handlers == {f1, f2}
    # I can add the same callback multiple times and it will only be called once
    e += f2
    assert e._handlers == {f1, f2}


# Generated at 2022-06-11 17:42:30.093441
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import collections
    import mock

    # --- test fire method ----------------------------------------------------

    event_source = _EventSource()

    counter = collections.Counter()
    event_source += lambda: counter.update(['handler_1_called'])
    event_source += lambda: counter.update(['handler_2_called'])

    event_source.fire()

    assert counter['handler_1_called'] == 1
    assert counter['handler_2_called'] == 1

    # --- test limited firing -------------------------------------------------

    counter = collections.Counter()
    event_source = _EventSource()

    handler = mock.MagicMock(side_effect=Exception('test'))
    event_source += handler

    with mock.patch('ansible.module_utils.common.text.collection_loader._warn') as warn:
        event_source.fire()

   

# Generated at 2022-06-11 17:42:35.798553
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()

    def f():
        pass

    def g():
        pass

    x += f
    x += f
    x += f

    x += g

    assert len(x._handlers) == 2
    assert f in x._handlers
    assert g in x._handlers
    assert f in x._handlers


# Generated at 2022-06-11 17:42:43.484242
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler1(x, y):
        nonlocal handler1_call_count
        handler1_call_count += 1
        nonlocal handler1_args
        handler1_args = (x, y)

    def handler2(x, y):
        nonlocal handler2_call_count
        handler2_call_count += 1
        nonlocal handler2_args
        handler2_args = (x, y)

    def handler3(x, y):
        nonlocal handler3_call_count
        handler3_call_count += 1
        nonlocal handler3_args
        handler3_args = (x, y)
        raise RuntimeError('handler3 exception')

    handler1_call_count = 0
    handler2_call_count = 0
    handler3_call_count = 0

    s = _EventSource()

   

# Generated at 2022-06-11 17:42:45.566894
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    handler = lambda: None

    source = _EventSource()
    source += handler
    assert source._handlers == {handler}



# Generated at 2022-06-11 17:42:55.413561
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert id(event_source) == id(event_source.__iadd__(None)) # test __iadd__ singleton behavior

    def handler_1():
        raise RuntimeError('1')

    def handler_2():
        raise RuntimeError('2')

    event_source += handler_1
    event_source += handler_2
    assert len(event_source._handlers) == 2
    event_source += handler_1
    assert len(event_source._handlers) == 2

    try:
        event_source.fire()
        assert False, 'RuntimeError not raised'
    except RuntimeError as ex:
        assert '2' == to_text(ex)


# Generated at 2022-06-11 17:42:57.261766
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def handler():
        return 5
    es += handler
    assert handler in es._handlers


# Generated at 2022-06-11 17:43:07.786804
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()

    def test_func1(arg):
        nonlocal t1
        t1 = arg

    def test_func2(arg):
        nonlocal t2
        t2 = arg

    def test_func3(arg):
        nonlocal t3
        t3 = (arg, arg)

    e += test_func1
    e += test_func2

    t1 = None
    t2 = None
    t3 = None

    e.fire(42)

    assert t1 == 42
    assert t2 == 42
    assert t3 is None
    assert len(e._handlers) == 2

    e -= test_func2
    e += test_func3

    e.fire(42)

    assert t1 == 42
    assert t2 is None

# Generated at 2022-06-11 17:43:11.846281
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()
    assert len(ev._handlers) == 0

    def handler_func():
        pass

    ev += handler_func
    assert len(ev._handlers) == 1
    assert handler_func in ev._handlers

