

# Generated at 2022-06-11 17:34:35.826905
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    handler_callable_1 = lambda: 0
    event_source += handler_callable_1
    assert handler_callable_1 in event_source._handlers

    handler_callable_2 = lambda: 0
    event_source += handler_callable_2
    assert handler_callable_2 in event_source._handlers



# Generated at 2022-06-11 17:34:43.927841
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj = _EventSource()
    def handler():
        pass

    obj += handler
    assert handler in obj._handlers

    # exception is handled
    obj._on_exception = lambda self, handler, exc, *args, **kwargs: False
    remaining_handlers = obj._handlers.copy()
    def failing_handler():
        raise RuntimeError
    obj += failing_handler
    assert handler in obj._handlers
    assert failing_handler in obj._handlers

    # exception is not handled
    obj._on_exception = lambda self, handler, exc, *args, **kwargs: True
    obj += failing_handler
    assert handler in obj._handlers
    assert failing_handler in obj._handlers



# Generated at 2022-06-11 17:34:50.690773
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class A:
        def foo(self, x):
            pass

    class B:
        def foo(self, x):
            raise RuntimeError('bar')

    class C:
        def foo(self, x):
            raise ValueError('baz')

    def fire_and_expect(firer, expected_exception, expected_traceback):
        import traceback

        try:
            firer()
            assert False, 'Expected %s' % expected_exception
        except expected_exception as ex:
            tb = ex.__traceback__
            while tb.tb_next:
                tb = tb.tb_next
            assert tb.tb_frame.f_code.co_name == expected_traceback


# Generated at 2022-06-11 17:34:57.923897
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest
    from io import StringIO
    buf = StringIO()
    def handler1(m):
        print('handler1', m, file=buf)
    def handler2(m):
        print('handler2', m, file=buf)
    def handler3(m):
        raise RuntimeError('handler3')
    handler4 = lambda m: print('handler4', m, file=buf)

# Generated at 2022-06-11 17:35:08.076899
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    class Handler:
        def __init__(self):
            self.exceptions = []

        def handle(self, *args, **kwargs):
            raise ValueError('expected exception')

        def handle_arg(self, *args, **kwargs):
            pass

    handler = Handler()
    event += handler.handle
    event += handler.handle_arg

    try:
        event.fire('arg', kwarg='kwarg')
    except ValueError:
        pass

    try:
        event.fire(arg='arg', kwarg='kwarg')
    except ValueError:
        pass

    try:
        event.fire()
    except ValueError:
        pass

    try:
        event.fire(kwarg='kwarg')
    except ValueError:
        pass

# Generated at 2022-06-11 17:35:13.437940
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # create an event source that counts the calls to handler
    count = {'value': 0}

    def handler(key, value):
        count['value'] = count['value'] + 1
        return count

    es = _EventSource()
    es += handler

    # ensure that it is called once with the (event) args (1, 2)
    es.fire(1, 2)
    assert count['value'] == 1

    # and the same with args (3, 4)
    es.fire(3, 4)
    assert count['value'] == 2

    # and that adding the same handler is only counted once
    es += handler
    es.fire(5, 6)
    assert count['value'] == 3

# Generated at 2022-06-11 17:35:22.090086
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def throw_exception():
        raise ValueError('expected')

    def return_false(handler, exc, *args, **kwargs):
        return False

    def return_true(handler, exc, *args, **kwargs):
        return True

    source = _EventSource()
    source._on_exception = return_false
    source += throw_exception

    source.fire()

    source = _EventSource()
    source._on_exception = return_true
    source += throw_exception

    try:
        source.fire()
    except ValueError as ex:
        if str(ex) != 'expected':
            raise AssertionError()

# Generated at 2022-06-11 17:35:26.447805
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def foo():
        pass

    es = _EventSource()
    es += foo
    assert len(es._handlers) == 1
    es += foo
    assert len(es._handlers) == 1
    es -= foo
    assert len(es._handlers) == 0
    es -= foo
    assert len(es._handlers) == 0


# Generated at 2022-06-11 17:35:32.530324
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_1(s):
        return '1:' + s

    def handler_2(s):
        return '2:' + s

    es = _EventSource()
    es += handler_1
    es += handler_2

    assert ['1:foo', '2:foo'] == list(es.fire('foo'))

    es -= handler_1

    assert ['2:foo'] == list(es.fire('foo'))

# Generated at 2022-06-11 17:35:36.845553
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    @event_source.fire
    def test_event(source, **params):
        return source, params['foo']

    assert test_event() == (event_source, 'bar')
    assert test_event(foo='baz') == (event_source, 'baz')



# Generated at 2022-06-11 17:35:51.860733
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    event_source += event_handler

    event_source.fire()
    assert event_handler.call_count == 1
    assert event_handler.args == ()
    assert event_handler.kwargs == {}

    event_source.fire(1, 2, 3)
    assert event_handler.call_count == 2
    assert event_handler.args == (1, 2, 3)
    assert event_handler.kwargs == {}

    event_source.fire(a=1, b=2, c=3)
    assert event_handler.call_count == 3
    assert event_handler.args == ()
    assert event_handler.kwargs == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-11 17:35:55.208340
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    es += lambda x: x
    assert len(es._handlers) == 1

    es += lambda x: x
    assert len(es._handlers) == 2



# Generated at 2022-06-11 17:36:00.103518
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    value = {}

    def handler1(data):
        value['message'] = data

    def handler2(data):
        value['message'] += data

    event_source += handler1
    event_source += handler2

    event_source.fire('hello')

    assert value['message'] == 'helloworld'



# Generated at 2022-06-11 17:36:11.201749
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()
    index = 0

    def handler1(param):
        assert param == index
        index += 1

    def handler2(param):
        assert param == index
        raise Exception()

    def handler3(param):
        assert param == index
        index += 1

    def handler4(param):
        assert param == index
        index += 1

    def handler5(param):
        assert param == index
        raise Exception()

    eventsource += handler1
    eventsource += handler2
    eventsource += handler3
    eventsource += handler4
    eventsource += handler5

    try:
        eventsource.fire(index)
    except Exception:
        pass

    assert index == 2

    eventsource -= handler3
    eventsource -= handler4
    eventsource -= handler5


# Generated at 2022-06-11 17:36:13.549784
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda a: print(a)
    assert len(event_source._handlers) == 1

# Generated at 2022-06-11 17:36:21.446956
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestSource(_EventSource):
        def __init__(self):
            self._events = []
            super(_TestSource, self).__init__()

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._events.append((handler, exc, args, kwargs))

    source = _TestSource()
    source += lambda: source.append(1)
    source += lambda: source.append(1)
    source += lambda: source.append(1)
    source += lambda: 1 / 0
    source += lambda: 1 / 0.0

    # no events should have fired yet
    assert len(source._events) == 0

    # after firing, we should have 2 events and, we should not have an exception
    assert source.fire() is None
    assert len(source._events)

# Generated at 2022-06-11 17:36:26.850052
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class MyEventSource:
        handler = None

        def __init__(self):
            self._handlers = set()

        def __iadd__(self, handler):
            if not callable(handler):
                raise ValueError('handler must be callable')
            self._handlers.add(handler)
            return self

        def __isub__(self, handler):
            try:
                self._handlers.remove(handler)
            except KeyError:
                pass

            return self

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True


# Generated at 2022-06-11 17:36:28.114939
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    h = lambda:None

    e += h
    assert h in e._handlers


# Generated at 2022-06-11 17:36:37.950722
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(x, y):
        pass

    def handler2(z):
        pass

    def handler3(k, l, m, n):
        pass

    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    with pytest.raises(ValueError):
        event_source.__iadd__(5)

    event_source.__iadd__(handler1)
    assert len(event_source._handlers) == 1
    assert handler1 in event_source._handlers

    event_source.__iadd__(handler2)
    event_source.__iadd__(handler3)
    assert len(event_source._handlers) == 3
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers
    assert handler

# Generated at 2022-06-11 17:36:43.527175
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import unittest

    e = _EventSource()
    h = lambda: None

    e += h  # we can add this function

    # we should not be able to add this function twice
    with unittest.TestCase().assertRaises(ValueError):
        e += h

    # we should not be able to add something else
    with unittest.TestCase().assertRaises(ValueError):
        e += 'hello test'


# Generated at 2022-06-11 17:36:54.543027
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventListener:
        def __init__(self):
            self._events = []

        def __call__(self, *args, **kwargs):
            self._events.append((args, kwargs))

    # a simple handler
    listener = EventListener()
    event_source = _EventSource()
    event_source += listener
    event_source.fire('foo', bar='baz')
    assert listener._events == [((('foo',), {'bar': 'baz'}),)]

    # add a second handler
    listener = EventListener()
    event_source += listener
    event_source.fire('foo', bar='baz')
    assert listener._events == [((('foo',), {'bar': 'baz'}),)]

    # add a handler that raises an exception
    listener = EventListener()
   

# Generated at 2022-06-11 17:37:01.096288
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def f():
        log.append('initial')
    def g():
        log.append('first')
    def h():
        raise Exception()

    log = []

    e = _EventSource()
    e += f
    e += g
    e += h

    e.fire()
    assert log == ['initial', 'first']



# Generated at 2022-06-11 17:37:09.928712
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evs = _EventSource()

    class Args:
        def __init__(self):
            self.first_arg = None
            self.second_arg = None

    arg_obj = Args()

    def handler1(arg1, arg2):
        arg_obj.first_arg = to_text(arg1)
        arg_obj.second_arg = to_text(arg2)

    def handler2(arg):
        arg_obj.first_arg = arg_obj.second_arg = to_text(arg)

    evs += handler1
    evs += handler2

    evs.fire('foo', 'bar')

    assert arg_obj.first_arg == 'foo'
    assert arg_obj.second_arg == 'foo'

    arg_obj.first_arg = arg_obj.second_arg

# Generated at 2022-06-11 17:37:12.180814
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda x: x + 1
    assert len(e._handlers) == 1



# Generated at 2022-06-11 17:37:17.862542
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(value):
        return 'handler1({})'.format(value)

    def handler2(value):
        return 'handler2({})'.format(value)

    event_source += handler1
    event_source += handler2

    assert len(event_source._handlers) == 2
    assert 'handler1(11), handler2(11)' == event_source.fire(11)



# Generated at 2022-06-11 17:37:23.205622
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def foo1(x, y):
        print('foo1', x, y)
    def foo2(x, y):
        print('foo2', x, y)

    es = _EventSource()
    es += foo1
    es += foo2
    es.fire(1, 2)
    es.fire(3, 4)



# Generated at 2022-06-11 17:37:32.604571
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_event_source = _EventSource()

    class Callable:
        def __init__(self, raise_exception=False):
            self._raise_exception = raise_exception

        def __call__(self, *args, **kwargs):
            if self._raise_exception:
                raise RuntimeError('Unit test _EventSource exception')

    # test case: handler is not callable
    test_callable = Callable(False)

    try:
        test_event_source.fire(test_callable)
        assert False
    except Exception:
        assert True

    # test case: handler is callable but does not raise exception
    test_callable = Callable(False)
    test_event_source += test_callable

# Generated at 2022-06-11 17:37:43.138208
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _Dummy:
        pass

    es = _EventSource()
    x = _Dummy()

    def f1(o):
        o.calls.append((1,))

    def f2(o):
        o.calls.append((2,))

    def f3(o):
        raise ValueError('unknown')

    x.calls = []
    es += f1
    es += f2
    es += f3
    es.fire(x)
    assert x.calls == [(1,), (2,)]

    x.calls = []
    es -= f2
    es += f3
    es.fire(x)
    assert x.calls == [(1,)]


# Generated at 2022-06-11 17:37:52.153363
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def precondition(self):
            self.seen = []
            self.seen_exceptions = []

        def handler_1(self, arg):
            self.seen.append("handler_1(%s)" % arg)

        def handler_2(self, arg):
            self.seen.append("handler_2(%s)" % arg)

        def handler_3(self, arg):
            self.seen.append("handler_3(%s)" % arg)
            raise NotImplementedError("handler_3 raises NotImplementedError")

        def _on_exception(self, _, ex, *args, **kwargs):
            self.seen_exceptions.append(ex)

        def fire_with_handlers_1_2_3(self):
            event_source = _Event

# Generated at 2022-06-11 17:37:54.427513
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    func = lambda: None
    event_source += func
    assert func in event_source._handlers

# Generated at 2022-06-11 17:38:11.253353
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    evt = _EventSource()

    def foo(a, b, c=None):
        pass

    # passing a function should add it
    evt += foo

    # passing something other than a function should raise a ValueError
    with pytest.raises(ValueError):
        evt += 5

    # passing a function should add it
    evt += foo

    # passing something other than a function should raise a ValueError
    with pytest.raises(ValueError):
        evt += 5

    # passing a function that has been added before should be ignored
    evt += foo

    assert len(evt._handlers) == 1
    assert foo in evt._handlers



# Generated at 2022-06-11 17:38:21.606605
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(event_name, *args, **kwargs):
        print("handler1 event name %s" % event_name)
        print("handler1 args %s" % args)
        print("handler1 kwargs %s" % kwargs)
        print("handler1 called")

    def handler2(*args, **kwargs):
        print("handler2 args %s" % args)
        print("handler2 kwargs %s" % kwargs)
        print("handler2 called")

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire("event_name", "test", name="test event")


# Generated at 2022-06-11 17:38:24.697096
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    def handler(value):
        pass
    event += handler
    assert handler in event._handlers
    event -= handler
    assert handler not in event._handlers


# Generated at 2022-06-11 17:38:27.240434
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    target = _EventSource()
    handler = lambda: None

    target += handler

    assert handler in target._handlers



# Generated at 2022-06-11 17:38:33.050819
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def b(param1):
        print(param1)
        raise RuntimeError('something went wrong')

    def c(param1):
        print(param1)

    evt = _EventSource()

    evt += a
    evt += b
    evt += c

    evt.fire('hello')
    evt -= a
    evt -= b
    evt -= c

# Generated at 2022-06-11 17:38:43.667675
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    from ansible.module_utils.common.collections import _EventSource

    es = _EventSource()
    assert es._handlers == set()

    def handler():
        pass

    es += handler
    assert es._handlers == set([handler])

    try:
        es += handler
    except ValueError:
        pytest.fail("calling __iadd__ with a function that has already been added should not raise a ValueError")

    try:
        es += 'a string'
    except ValueError:
        pass
    else:
        pytest.fail("calling __iadd__ with a non-callable object should raise a ValueError")



# Generated at 2022-06-11 17:38:47.104960
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def handler(value):
        nonlocal handled_value
        handled_value = value

    event += handler
    assert handled_value is None

    event.fire(1)
    assert handled_value == 1



# Generated at 2022-06-11 17:38:51.961575
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventTest:
        def __init__(self, call_count, exception):
            self._call_count = call_count
            self._exception = exception

        def __call__(self, *args, **kwargs):
            if self._exception and self._call_count == 0:
                raise self._exception
            self._call_count += 1

    s = _EventSource()
    assert s._handlers == set()

    h1 = _EventTest(call_count=0, exception=False)
    s += h1
    assert h1._call_count == 0
    s.fire()
    assert h1._call_count == 1

    h2 = _EventTest(call_count=0, exception=True)
    s += h2
    assert h2._call_count == 0

# Generated at 2022-06-11 17:39:00.560388
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Handler:
        def __init__(self, name):
            self._name = name
            self._calls = 0

        def __call__(self, *args, **kwargs):
            self._calls += 1

    class _EventSource1(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    # no exceptions should be thrown, they should be ignored
    es = _EventSource1()
    h1 = _Handler('h1')
    h2 = _Handler('h2')
    es += h1
    es += h2
    raise_ex = False

    try:
        es.fire(1, a=2)
    except Exception:
        raise_ex = True

    assert not raise_ex

# Generated at 2022-06-11 17:39:04.209056
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def test_handler(self, *args, **kwargs):
        print('Hello, World!')

    handler = test_handler

    event_source = _EventSource()
    event_source += handler

    assert handler in event_source._handlers
    assert callable(handler)


# Generated at 2022-06-11 17:39:24.332225
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(a, b):
        assert a == 1
        assert b == 2
        handlers.append(handler)

    handlers = []
    e = _EventSource()
    e += handler
    e += handler
    e.fire(1, 2)
    assert handlers == [handler, handler]

    e -= handler
    e.fire(1, 2)
    assert handlers == [handler, handler, handler]

# Generated at 2022-06-11 17:39:33.090023
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestListener:
        def handle(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class TestException(Exception):
        pass

    def on_exception(handler, exc, *args, **kwargs):
        assert isinstance(exc, TestException)
        assert handler == listener
        assert args == (1, 2)
        assert kwargs == {'three': 3}
        nonlocal on_exception_calls
        on_exception_calls += 1
        return False

    es = _EventSource()
    listener = TestListener()

    es.fire(1, 2, three=3)
    assert listener.args is None
    assert listener.kwargs is None

    es += listener.handle
    es.fire(1, 2, three=3)

# Generated at 2022-06-11 17:39:36.378950
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source += lambda: None

    try:
        source += 'not a function'
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-11 17:39:43.369205
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def f(x):
        return x * x

    def g(x):
        s = x + x
        raise RuntimeError(" %s %s" % (x, s))

    def h(x):
        s = x * x
        raise RuntimeError(" %s %s" % (x, s))

    # create event source
    se = _EventSource()
    se += f
    se += g
    se += h

    # fire event
    se.fire(10)

# Generated at 2022-06-11 17:39:46.884939
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    handler = 'handler_1'
    event += handler
    assert handler in event._handlers

    # str is not callable
    try:
        event += 'handler_2'
    except ValueError:
        assert 'handler_2' not in event._handlers


# Generated at 2022-06-11 17:39:49.052540
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()
    with open('/dev/null') as f:
        ev += f.write
        ev.fire('hello')

# Generated at 2022-06-11 17:39:59.993496
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def f1(a, b):
        print('f1: ', a, b)

    def f2(a, b):
        print('f2: ', a, b)
        raise Exception('exception raised in f2')

    def f3(a, b):
        print('f3: ', a, b)

    def f4(a, b):
        print('f4: ', a, b)
        raise Exception('exception raised in f4')

    def f5(a, b):
        print('f5: ', a, b)

    d = _EventSource()
    d += f1
    d += f2
    d += f3
    d += f4
    d += f5
    d -= f2


# Generated at 2022-06-11 17:40:09.446653
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEvent(_EventSource):
        def __init__(self):
            super(_TestEvent, self).__init__()
            self._event_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def handler(self, *args, **kwargs):
            self._event_fired = True

    e = _TestEvent()
    e.fire()
    assert not e._event_fired
    e += e.handler
    e.fire()
    assert e._event_fired

if __name__ == '__main__':
    import sys

    test_name = sys.argv.pop()
    test_func = globals().get(test_name, lambda: 'no test "%s"' % test_name)
    test_func()

# Generated at 2022-06-11 17:40:20.783913
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    class Handler:
        def test_handler(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    # Test that each handler is called with the correct arguments
    h1 = Handler()
    h2 = Handler()
    source = _EventSource()
    source += h1.test_handler
    source += h2.test_handler

    source.fire(1, 2, 3, a='A', b='B')

    assert h1.args == (1, 2, 3)
    assert h1.kwargs == {'a': 'A', 'b': 'B'}
    assert h2.args == (1, 2, 3)
    assert h2.kwargs == {'a': 'A', 'b': 'B'}

    # Test that handlers

# Generated at 2022-06-11 17:40:31.726953
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if the exc is 'pass', then the caller should not re-raise
            return exc != 'pass'

        def handler1(self, *args, **kwargs):
            self.calls.append('handler1')

        def handler2(self, *args, **kwargs):
            self.calls.append('handler2')

        def handler_raise(self, *args, **kwargs):
            self.calls.append('handler_raise')
            raise ValueError

        def handler_raise_pass(self, *args, **kwargs):
            self.c

# Generated at 2022-06-11 17:41:13.336994
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    counter = []
    def f1(x):
        counter.append(1)
    def f2(x, y=None):
        counter.append(2)
    def f3(x, y=None, *args):
        counter.append(3)
    def f4(x, y=None, *args, **kwargs):
        counter.append(4)

    # add a single handler
    e = _EventSource()
    e += f1
    e.fire()
    assert counter == [1]

    # add multiple handlers
    counter = []
    e = _EventSource()
    e += f2
    e += f3
    e += f4
    e.fire(x=1, y=2)
    assert counter == [2, 3, 4]

    # re-add existing handler
    counter

# Generated at 2022-06-11 17:41:22.643486
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler1():
        raise ValueError()

    def handler2():
        raise TypeError()

    def handler3(exc):
        handler3.exc = exc

    handler3.handled = False

    def on_exception(handler, exc, *args, **kwargs):
        handler(exc)
        return handler3.handled

    def test_exception_not_reraised():
        handler3.handled = False

        src = _EventSource()
        src._on_exception = on_exception

        src += handler1
        src += handler2
        src += handler3

        src.fire()

    def test_exception_reraised():
        handler3.handled = True

        src = _EventSource()
        src._on_exception = on_exception

        src += handler1
        src += handler2
       

# Generated at 2022-06-11 17:41:33.754272
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # init
    tester = _EventSource()
    mock_handler = "mock_handler"
    mock_handler_exception = Exception("mock_handler_exception!")
    tester += mock_handler

    # mock
    class MockHandler(object):
        def __call__(self, *args, **kwargs):
            raise mock_handler_exception

    mock_handler = MockHandler()
    tester += mock_handler

    # assert
    def on_exception(handler, exception, *args, **kwargs):
        assert(handler == mock_handler)
        assert(exception == mock_handler_exception)
        assert(args == ('foo', 'bar'))
        assert(kwargs == {'a': 'b', 'c': 'd'})
        return True

    tester._on_ex

# Generated at 2022-06-11 17:41:37.176652
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    flag = 0

    def on_collection_load_mock(e):
        global flag
        flag += 1
        assert e == 'event'

    event_source = _EventSource()
    event_source += on_collection_load_mock
    event_source.fire('event')

    assert flag == 1

# Generated at 2022-06-11 17:41:47.355882
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Handler:
        def __init__(self, expected_args, expected_kwargs):
            self._expected_args = expected_args
            self._expected_kwargs = expected_kwargs
            self._actual_args = None
            self._actual_kwargs = None

        def __call__(self, *args, **kwargs):
            self._actual_args = args
            self._actual_kwargs = kwargs

        @property
        def actual_args(self):
            return self._actual_args

        @property
        def actual_kwargs(self):
            return self._actual_kwargs

        @property
        def expected_args(self):
            return self._expected_args

        @property
        def expected_kwargs(self):
            return self._expected_kwargs


# Generated at 2022-06-11 17:41:58.454170
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        assert args == (1, 2, 3)
        assert kwargs == {'a': 4, 'b': 5}

    def handler2(*args, **kwargs):
        assert args == (1, 2, 3)
        assert kwargs == {'a': 4, 'b': 5}

    def handler3(*args, **kwargs):
        raise ValueError('handler 3')

    def handler4(*args, **kwargs):
        assert args == (1, 2, 3)
        assert kwargs == {'a': 4, 'b': 5}

    def handler5(*args, **kwargs):
        assert args == (1, 2, 3)
        assert kwargs == {'a': 4, 'b': 5}


# Generated at 2022-06-11 17:42:01.950029
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    triggered = []

    def handler():
        triggered.append(True)

    event = _EventSource()

    event += handler

    assert len(triggered) == 0

    event.fire()

    assert len(triggered) == 1

# Generated at 2022-06-11 17:42:09.910676
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # note: the firing of an event may cause errors and exceptions in receivers of those events.
    #       those errors and exceptions are allowed to propagate up the stack to the caller of fire
    #       without the exception being caught by fire.

    def func0():
        pass

    def func1(arg):
        pass

    def func2(arg, keyarg=None):
        pass

    event = _EventSource()

    event += func0
    event += func1
    event += func2

    event.fire()

    event.fire(1)

    event.fire(1, keyarg='foo')



# Generated at 2022-06-11 17:42:13.826626
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    func = lambda: None
    es += func
    assert func in es._handlers


# Generated at 2022-06-11 17:42:15.427265
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    assert set() == source._handlers

# Generated at 2022-06-11 17:43:15.592315
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        return 0

    event = _EventSource()

    event += handler()
    assert len(event._handlers) == 1
    assert handler == list(event._handlers)[0]

    event += handler
    assert len(event._handlers) == 1
    assert handler == list(event._handlers)[0]



# Generated at 2022-06-11 17:43:21.607160
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def f():
        pass

    # test adding a handler
    es += f
    assert f in es._handlers

    # test adding handler multiple times
    es += f
    es += f
    assert f in es._handlers

    # test adding a non-callable handler
    try:
        es += [1, 2, 3]
    except ValueError:
        pass


# Generated at 2022-06-11 17:43:23.781014
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source += lambda: 1
    assert len(source._handlers) == 1

# Generated at 2022-06-11 17:43:35.461429
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def handler(i):
        pass

    def handler2(i):
        pass

    def handler3(i):
        raise ValueError()

    def handler4(i):
        raise RuntimeError()

    event += handler
    event += handler2
    event += handler3
    event += handler4

    # all good
    event.fire(1)

    # one exception
    try:
        event.fire(2)
    except ValueError:
        pass
    else:
        assert False

    # another exception
    try:
        event.fire(2)
    except RuntimeError:
        pass
    else:
        assert False

    # of course, when it's not handled, it's not handled
    try:
        event.fire(2)
    except KeyError:
        pass
   

# Generated at 2022-06-11 17:43:47.332703
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    exc = None
    def good_handler(*args, **kwargs):
        return

    def bad_handler(*args, **kwargs):
        raise Exception(1)

    def on_exception(handler, exc, *args, **kwargs):
        return False

    event = _EventSource()
    event += good_handler
    event += bad_handler
    event -= bad_handler

    try:
        event.fire()
    except Exception as e:
        exc = e

    assert exc is None, 'handles should not have received exception'

    event.fire(1, 2, 3, 4)

    try:
        event.fire()
    except Exception as e:
        exc = e

    assert exc is not None, 'handler should have received exception'

# Generated at 2022-06-11 17:43:56.219541
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSink:
        def __init__(self):
            self.args = None
            self.kwargs = None

        def __call__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    event = _EventSource()
    sinks = [_EventSink() for _ in range(3)]

    for s in sinks:
        event += s

    event.fire(0, 1, 2, foo='bar')

    for s in sinks:
        assert s.args == (0, 1, 2)
        assert s.kwargs == {'foo': 'bar'}



# Generated at 2022-06-11 17:43:57.842003
# Unit test for method fire of class _EventSource

# Generated at 2022-06-11 17:44:08.340832
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class Foo:
        def __init__(self):
            self.bar = False

        def handler(self):
            self.bar = True

    # Verify that the handler is successfully added
    foo = Foo()
    event_source = _EventSource()
    event_source += foo.handler
    assert len(event_source._handlers) == 1
    event_source.fire()
    assert foo.bar

    # Verify that the handler is not successfully added if it is not callable
    event_source += 'foo'
    assert len(event_source._handlers) == 1  # the callable handler should still be the only handler present

    # Verify that the handler is not successfully added if it is already added
    event_source += foo.handler
    assert len(event_source._handlers) == 1  # the callable handler should still be the

# Generated at 2022-06-11 17:44:14.790743
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # On systems with Python < 2.7.9 where the ssl module does not default to using TLSv1.2,
    # importing the requests module brings in the urllib3 module which prints a warning to the
    # console.  The warning is suppressed in Ansible's test suites.  We replicate the suppression
    # of the warning here so that the tests can be run without the console warning.
    from ansible.module_utils.requests import urllib3
    urllib3.disable_warnings()

    src = _EventSource()
    assert len(src._handlers) == 0

    def handler1(x):
        pass

    def handler2(x):
        raise Exception('oops')

    src += handler1
    src += handler2

    assert len(src._handlers) == 2



# Generated at 2022-06-11 17:44:22.171957
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler1(a, b, c=1):
        pass

    def handler2(d, e, f=2):
        pass

    es += handler1

    try:
        es += 'not a callable'
        assert False, "should have raised ValueError"
    except ValueError:
        pass

    es += handler2
    es -= handler1

    handlers = set()
    handlers.add(handler1)
    handlers.add(handler2)

    assert handlers == es._handlers
