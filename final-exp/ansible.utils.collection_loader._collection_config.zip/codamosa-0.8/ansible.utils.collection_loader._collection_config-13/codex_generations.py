

# Generated at 2022-06-11 17:34:31.807197
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda x: x
    assert len(event_source._handlers) == 1
    assert callable(event_source._handlers.pop())


# Generated at 2022-06-11 17:34:34.950044
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def listener(x, y):
        return x + y
    s = _EventSource()
    s += listener
    assert s.fire(1, y=2) == 3



# Generated at 2022-06-11 17:34:35.491454
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _EventSource()

# Generated at 2022-06-11 17:34:37.397419
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def f():
        pass

    es += f

    assert es._handlers == set([f])



# Generated at 2022-06-11 17:34:40.144130
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class Foo:
        def __call__(self, *args, **kwargs):
            pass

    foo = Foo()

    event = _EventSource()
    event += foo
    event += foo



# Generated at 2022-06-11 17:34:48.074853
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest
    eventSource = _EventSource()
    calls = []

    def handler(x):
        calls.append(x)

    eventSource += handler
    eventSource.fire(x=3)
    assert calls == [3]

    eventSource.fire(x=4)
    assert calls == [3, 4]

    eventSource -= handler
    eventSource.fire(x=5)
    assert calls == [3, 4]

    with pytest.raises(ValueError, match='handler must be callable'):
        eventSource += 'not-callable'

    _EventSource()._on_exception(None, Exception('something went wrong'), '', k='v')

# Generated at 2022-06-11 17:34:51.806986
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    value = []

    def fire(x):
        nonlocal value
        value.append(x)

    event = _EventSource()

    event += fire

    event.fire(1)
    event.fire(2)

    assert value == [1, 2]

# Generated at 2022-06-11 17:34:56.596059
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class SomeObject:
        def bar(self):
            pass

    o = SomeObject()
    o_bar = o.bar
    o_bar_called = 0

    def o_bar_wrapper():
        nonlocal o_bar_called
        o_bar_called += 1
        return o_bar()

    ev = _EventSource()
    ev += o.bar
    ev += o_bar_wrapper
    ev.fire()

    assert o_bar_called == 1


# Generated at 2022-06-11 17:34:57.852485
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert False, 'No unit test for method fire of class _EventSource'


# Generated at 2022-06-11 17:35:08.036429
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # This is an example module that different ansible-test tests should be testing.

    class ProvidedEvent:
        pass

    class HandledEvent:
        pass

    class ConcreteEventSource(_EventSource):
        pass

    provided_events = []

    def handler_throw(provided_event, handled_event):
        # throw an exception
        handled_events.append(handled_event)
        raise ValueError('This is a test exception')

    def handler(provided_event, handled_event):
        provided_events.append(provided_event)
        handled_events.append(handled_event)

    handled_events = []

    concrete_event_source = ConcreteEventSource()
    ces_throw = concrete_event_source
    ces_throw += handler_throw
    provided_event = ProvidedEvent()
    handled_event = Handled

# Generated at 2022-06-11 17:35:22.986826
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test setup
    called = []

    class TestEventSource(_EventSource):
        def _on_exception(self, handler, ex, *args, **kwargs):
            return not isinstance(ex, ValueError)

    evt = TestEventSource()

    def fire_handler(value):
        called.append('fire_handler')
        if value.startswith('bad'):
            raise ValueError('unexpected value')

    def fire_handler2(value):
        called.append('fire_handler2')

    evt += fire_handler
    evt += fire_handler2

    # test 2 expected handlers called
    evt.fire('good_value')
    assert called == ['fire_handler', 'fire_handler2']

    # test that the ValueError exception is caught, but not re-raised
    evt.fire

# Generated at 2022-06-11 17:35:28.367161
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    observed_count = [0]

    def handler_1(*args, **kwargs):
        observed_count[0] = 1

    def handler_2(*args, **kwargs):
        observed_count[0] = 2

    es += handler_1
    es.fire()
    assert observed_count[0] == 1

    es += handler_2
    es.fire()
    assert observed_count[0] == 2

# Generated at 2022-06-11 17:35:33.663205
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(a):
        handler1.rc.append(a)

    handler1.rc = list()

    def handler2(b):
        handler2.rc.append(b)

    handler2.rc = list()

    es = _EventSource()
    es += handler1
    es += handler2

    es.fire(1, 2)

    assert [1] == handler1.rc
    assert [2] == handler2.rc

# Generated at 2022-06-11 17:35:36.584067
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    result = _EventSource()
    result += lambda x: print('hello')
    result += lambda x: print('world')
    assert result._handlers == {lambda x: print('hello'), lambda x: print('world')}


# Generated at 2022-06-11 17:35:39.310621
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    assert event._handlers == set()
    event += lambda: None
    assert len(event._handlers) == 1



# Generated at 2022-06-11 17:35:44.663427
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda: None
    assert len(event._handlers) == 1
    event += event._handlers.pop()
    assert len(event._handlers) == 0
    assert len(event.on_collection_load._handlers) == 0


# Generated at 2022-06-11 17:35:54.899000
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class on_exception_callback:
        def __call__(self, handler, exc, *args, **kwargs):
            self.handler = handler
            self.exc = exc
            self.args = args
            self.kwargs = kwargs
            return True

    event_source = _EventSource()

    listener1 = object()
    listener2 = object()
    listener3 = object()

    event_source += listener1
    event_source += listener2
    event_source += listener3

    on_exception_cb = on_exception_callback()
    event_source._on_exception = on_exception_cb

    listener2 = object()
    event_source -= listener2

    # listener1 and listener3 throw exceptions to test handling

# Generated at 2022-06-11 17:36:02.363446
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class Event:
        def __init__(self, test_case):
            Event.test_case = test_case

        def handler(self):
            # test raises exception
            raise TestException('Test Exception')

    event = EventSource()

    event += Event.handler
    event._on_exception = Event.test_case.exception_handler

    with Event.test_case.assertRaises(TestException):
        event.fire()

    event -= Event.handler
    event.fire()



# Generated at 2022-06-11 17:36:12.520041
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    # test add a function
    class _TestFunction:
        def __init__(self):
            self.fired = False
        def fire(self, *args, **kwargs):
            self.fired = True
    test_function = _TestFunction()
    event_source = _EventSource()
    event_source += test_function
    event_source.fire()
    assert test_function.fired
    # test adding a class
    class _TestClass:
        def __init__(self):
            self.fired = False
        def fire(self, *args, **kwargs):
            self.fired = True
    test_class = _TestClass()
    event_source = _EventSource()
    event_source += test_class.fire
    event_source.fire()
    assert test_class.fired


# Generated at 2022-06-11 17:36:20.488701
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    assert not event._handlers

    def callback_1(x):
        pass

    def callback_2(a, b, c):
        pass

    with tempfile.NamedTemporaryFile() as f:
        event += callback_1
        event += callback_2
        assert event._handlers == {callback_1, callback_2}

        event.fire(f.name)

        event -= callback_1
        assert event._handlers == {callback_2}

        event.fire(a=1, b=3, c=3)


# Generated at 2022-06-11 17:36:37.115626
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestSource(object):
        def __init__(self, value):
            self.value = value

    result = []

    def on_change(obj):
        result.append(obj.value)

    src = _TestSource(1)
    evt = _EventSource()
    evt += on_change
    evt.fire(src)

    assert len(result) == 1 and result[0] == 1

    result.clear()
    evt.fire(src)
    evt -= on_change
    evt.fire(src)
    assert len(result) == 1 and result[0] == 1 # this should still work since it was added before we called -=

    # custom on_exception
    result.clear()

# Generated at 2022-06-11 17:36:47.290459
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    ev1 = _EventSource()
    ev2 = _EventSource()

    # Act
    ev1.fire()
    ev2.fire()

    # Assert
    assert ev1._handlers == set()
    assert ev2._handlers == set()

    def f():
        pass
    # Act
    ev1 += f
    ev2 += f

    # Assert
    assert ev1._handlers == {f}
    assert ev2._handlers == {f}

    # Act
    ev1.fire()
    ev2.fire()

    # Assert
    assert ev1._handlers == {f}
    assert ev2._handlers == {f}

    # Act
    ev1 += f

    # Assert
    assert ev1._handlers == {f}



# Generated at 2022-06-11 17:36:49.808998
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler(evt):
        pass

    es = _EventSource()
    assert callable(handler)
    es += handler
    assert handler in es._handlers



# Generated at 2022-06-11 17:36:52.618436
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    mock_handler = mock_handler = Mock()
    ansible_collection_config = AnsibleCollectionConfig()
    ansible_collection_config.on_collection_load += mock_handler
    assert mock_handler in ansible_collection_config.on_collection_load._handlers


# Generated at 2022-06-11 17:37:00.470989
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Test: function target fired with correct arguments
    def test_function(x, y):
        test_function.called = True
        test_function.args = (x, y)
    test_function.called = False
    test_function.args = tuple()

    event_source = _EventSource()
    event_source += test_function

    event_source.fire(1, 2)
    assert test_function.called
    assert test_function.args == (1, 2)

# Generated at 2022-06-11 17:37:05.106060
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSource(_EventSource):
        pass

    event_source = EventSource()
    handler = lambda: None

    # check that adding succeeds
    result = event_source.__iadd__(handler)

    assert event_source is result
    assert event_source._handlers == {handler}



# Generated at 2022-06-11 17:37:12.014538
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.collections import ImmutableDict

    # The provided test parameters have no real value
    test_args = (1, 2)
    test_kwargs = dict(a=7, b=8)

    # an example handler
    def _on_load(args, kwargs):
        # this is the expected test output to be used as the first index of the tuple
        # that is part of the output list
        return (args, kwargs)

    # create event source
    event_source = _EventSource()

    # Add the test handler to the event source
    event_source += _on_load

    # fire the test handler
    actual = event_source.fire(*test_args, **test_kwargs)

    # expected result
    expected = (test_args, test_kwargs)

# Generated at 2022-06-11 17:37:22.833743
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest

    # use pytest fixtures to verify the properties
    # of the _EventSource object
    #
    # this is a little weird but we need to
    # ensure that we are testing the same
    # _EventSource object across tests
    @pytest.fixture(scope="module")
    def _es():
        return _EventSource()

    @pytest.fixture(scope="module")
    def _good_handler():
        def _goodhand1(arg1):
            pass
        return _goodhand1

    @pytest.fixture(scope="module")
    def _bad_handler():
        def _badhand1():
            pass
        return _badhand1

    # handler is not callable

# Generated at 2022-06-11 17:37:27.755544
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Given
    called = False
    def handler(a, b):
        nonlocal called
        assert a == 1
        assert b == 2
        called = True
    eventsource = _EventSource()
    eventsource += handler

    # When
    eventsource.fire(1, 2)

    # Then
    assert called


# Generated at 2022-06-11 17:37:33.922025
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class IntEvent:
        def __init__(self):
            self.on_event_source = _EventSource()

        def fire(self, n):
            self.on_event_source.fire(n)

    class SpyHandler:
        def __init__(self):
            self.called_with = None

        def __call__(self, n):  # pylint: disable=missing-docstring
            self.called_with = n

    int_event = IntEvent()
    spy_handler = SpyHandler()
    int_event.on_event_source += spy_handler
    int_event.fire(5)
    assert spy_handler.called_with == 5
    int_event.fire(6)
    assert spy_handler.called_with == 6



# Generated at 2022-06-11 17:37:58.624451
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # class MyHandler:
    #     def __init__(self, index):
    #         self.index = index
    #         self.fired = 0
        
    #     def __call__(self):
    #         self.fired += 1

    def handler(x):
        handler.value += 1

    handler.value = 0

    event = _EventSource()
    event += handler

    event.fire()
    assert handler.value == 1

    event.fire()
    assert handler.value == 2

    event -= handler

    event.fire()
    assert handler.value == 2

    # test on_exception
    class Exc(Exception):
        pass

    def handler(x):
        raise Exc()
    def on_exception(handler, exc, *args, **kwargs):
        assert exc.__class__ is Exc

# Generated at 2022-06-11 17:38:05.210247
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyException(Exception):
        pass

    def handler(*args, **kwargs):
        raise MyException('unexpected')

    source = _EventSource()
    source += handler

    try:
        source.fire()
        assert False, 'Exception not raised'
    except MyException:
        assert True, 'Exception correctly raised'

    # now we add the handler, raise a different exception, and the handler is removed automatically
    source += handler
    try:
        source.fire()
        assert False, 'Exception not raised'
    except Exception as ex:
        assert ex.__class__ != MyException, 'Exception incorrectly raised'



# Generated at 2022-06-11 17:38:15.704890
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Since the handlers are set in the class, can't be reset for each time the test is run
    # so this test must be the first test run
    if AnsibleCollectionConfig.on_collection_load._handlers:
        assert False, 'AnsibleCollectionConfig.on_collection_load._handlers is unexpectedly not empty'

    def first_handler(event):
        event.count += 1

    def second_handler(event):
        event.count += 1

    def third_handler(event):
        event.count += 1

    event = type('event', (), {'count': 0})()
    AnsibleCollectionConfig.on_collection_load += first_handler
    AnsibleCollectionConfig.on_collection_load += second_handler
    AnsibleCollectionConfig.on_collection_load += third_handler
    AnsibleCollectionConfig.on_collection_

# Generated at 2022-06-11 17:38:21.954552
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    """
    Verify that _EventSource.__iadd__ raises an exception if non-callable argument passed
    """
    es = _EventSource()
    try:
        es += 2
    except ValueError as e:
        assert str(e) == 'handler must be callable'
    else:
        assert False, 'Expected ValueError not thrown'

# Generated at 2022-06-11 17:38:26.733452
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.utils.collection_loader import _EventSource
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    def _handler(a, b):
        pass

    AnsibleCollectionConfig.on_collection_load += _handler

    mock_eventsource = _EventSource()
    mock_eventsource += _handler



# Generated at 2022-06-11 17:38:28.269033
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()

# Generated at 2022-06-11 17:38:31.094546
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class AddHandler:

        def __call__(self, *_, **__):
            pass

    class NotAddHandler:
        pass

    e1 = _EventSource()
    h1 = AddHandler()
    e1 += h1

    assert e1._handlers == {h1}

    with pytest.raises(ValueError):
        e1 += NotAddHandler()



# Generated at 2022-06-11 17:38:43.275352
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    # check that we can add a custom handler
    handler = lambda *args, **kwargs: ["handler triggered"]
    assert not event_source._handlers
    event_source += handler
    assert event_source._handlers
    assert len(event_source._handlers) == 1

    # check that we can't re-add a custom handler
    try:
        event_source += handler
        assert False
    except ValueError:
        assert True

    # check that the handler is triggered
    assert event_source.fire() == ["handler triggered"]

    # check that handler is not triggered after removal
    event_source -= handler
    assert event_source.fire() == []

    # check that we don't fail when removing twice
    event_source -= handler


# Generated at 2022-06-11 17:38:53.903409
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        exceptions = []  # FIXME: ugly side-effect :(
        def fire(self, a, b, c, d='d'):
            super(TestEventSource, self).fire(a, b, c, d=d)
            return a, b, c, d

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exceptions.append((handler, exc))

    source = TestEventSource()
    result = source.fire('a', 'b', 'c', 'd')
    assert result == ('a', 'b', 'c', 'd')

    def h1(*args, **kwargs):
        assert args == ('a', 'b', 'c',)
        assert kwargs == {'d': 'd'}


# Generated at 2022-06-11 17:38:57.678996
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    test_value = None

    def test_handler(handler_arg):
        nonlocal test_value
        test_value = handler_arg

    event_source += test_handler
    event_source.fire('handler test value')

    assert test_value == 'handler test value'

# Generated at 2022-06-11 17:39:30.776250
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def h1(x):
        h1.called = True

    def h2(x):
        h2.called = True

    event = AnsibleCollectionConfig._on_collection_load
    event += h1
    event += h2

    event.fire(x=42)
    assert h1.called
    assert h2.called

# Generated at 2022-06-11 17:39:40.372418
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test raising exception from handler
    inner_called = False
    outer_called = False
    def inner(a, b, c, d='default'):
        nonlocal inner_called
        inner_called = True
        raise Exception('inner exception')

    def outer(a, b, c, d='default'):
        nonlocal outer_called
        outer_called = True

    es = _EventSource()
    es += inner
    es += outer
    # if this fails to raise an error, the test would fail
    with pytest.raises(Exception):
        es.fire('a', 'b', 'c')

    assert inner_called
    assert not outer_called

    # Test return value of _on_exception
    inner_called = False
    outer_called = False

# Generated at 2022-06-11 17:39:42.221679
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    raise NotImplementedError('test__EventSource_fire must be implemented in the target-specific class')


# Generated at 2022-06-11 17:39:50.212379
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    callback_data = []

    class _FakeHandler:
        def __init__(self, fn):
            self._fn = fn

        def __eq__(self, other):
            return self is other

        def __call__(self, *args, **kwargs):
            self._fn(args, kwargs)

    handler1 = _FakeHandler(lambda args, kwargs: callback_data.extend([(args, kwargs)]))
    handler2 = _FakeHandler(lambda args, kwargs: callback_data.extend([(args, kwargs)]))

    event_source = _EventSource()

    event_source += handler1
    assert handler1 in event_source._handlers
    event_source += handler2
    assert handler2 in event_source._handlers


# Generated at 2022-06-11 17:40:01.657981
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    error_messages = []

    def handler_a(message):
        error_messages.append('handler_a: ' + message)

    def handler_b(message):
        error_messages.append('handler_b: ' + message)
        raise RuntimeError()

    def handler_c(message):
        error_messages.append('handler_c: ' + message)

    def handler_d(message):
        raise KeyError()

    def handler_e():
        raise Exception('handler_e raised an exception')

    def handler_f(message):
        error_messages.append(message)

    event_source = _EventSource()

    event_source += handler_a
    event_source += handler_b
    event_source += handler_c
    event_source += handler_d
    event_source += handler_

# Generated at 2022-06-11 17:40:08.050896
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert(e._handlers == set())
    e += lambda: None
    assert(e._handlers == {lambda: None})
    try:
        e += lambda: None
    except ValueError:
        pass
    else:
        raise AssertionError('A lambda function should not be added twice.')
    try:
        e += 'this is not a function'
    except ValueError:
        pass
    else:
        raise AssertionError('A string should not be added as a lambda function.')


# Generated at 2022-06-11 17:40:09.414180
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert False



# Generated at 2022-06-11 17:40:12.196459
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert not e._handlers

    e += 'a'

    assert len(e._handlers) == 1



# Generated at 2022-06-11 17:40:22.842841
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class test_source(_EventSource):
        def __init__(self):
            super(test_source, self).__init__()
            self._test_event_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

        def test_handler(self, *args, **kwargs):
            self._test_event_fired = True

    class test_exception(Exception):
        def __init__(self, *args, **kwargs):
            super(test_exception, self).__init__(*args, **kwargs)
            self._on_exception_called = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_called = True
            return True


# Generated at 2022-06-11 17:40:31.862487
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    results = []

    def on_event(value, context=None):
        results.append((value, context))

    e += on_event
    with pytest.raises(KeyError):
        e += on_event
    e -= on_event
    e += on_event

    e.fire(5, context='test')
    assert results == [(5, 'test')]

    def on_event_fail():
        raise KeyError

    e += on_event_fail

    with pytest.raises(KeyError):
        e.fire(10, context='test2')

# Generated at 2022-06-11 17:41:45.722952
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Foo:
        def __init__(self):
            self.num = 0

        def increment(self, x=1):
            self.num += x

    on_collection_load = _EventSource()

    f1 = Foo()
    f2 = Foo()

    on_collection_load += f1.increment
    on_collection_load += f2.increment

    on_collection_load.fire()
    assert f1.num == 1
    assert f2.num == 1

    on_collection_load.fire(10)
    assert f1.num == 11
    assert f2.num == 11

    on_collection_load -= f1.increment

    on_collection_load.fire(10)
    assert f1.num == 11
    assert f2.num == 21


# Generated at 2022-06-11 17:41:47.097771
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += "test"
    assert False



# Generated at 2022-06-11 17:41:53.701033
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self):
            self._events = _EventSource()
            self._events += self._handler
            self.test = False

        def _handler(self, *args, **kwargs):
            self.test = True

        def fire(self, *args, **kwargs):
            self._events.fire(*args, **kwargs)

    t = Test()
    t.fire()
    assert t.test



# Generated at 2022-06-11 17:41:59.837213
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    def h1(arg1, arg2):
        return arg1, arg2

    def h2(arg1, arg2):
        return arg1, arg2

    e += h1
    e += h2

    assert len(e._handlers) == 2
    assert h1 in e._handlers
    assert h2 in e._handlers


# Generated at 2022-06-11 17:42:02.890150
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def my_handler(*args, **kwargs):
        pass

    es = _EventSource()
    es += my_handler
    assert len(es._handlers) == 1
    assert my_handler in es._handlers


# Generated at 2022-06-11 17:42:09.508597
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create the EventSource, event_source
    event_source = _EventSource()

    # Create the event handler, handler
    handler_executed = [False]

    def handler(*args, **kwargs):
        handler_executed[0] = True

    # Register the event handler, handler, with the event source, event_source
    event_source += handler

    # Fire the event on the event source, event_source
    event_source.fire()

    # Assert the event handler, handler, was executed
    assert handler_executed[0] is True

# Generated at 2022-06-11 17:42:18.677826
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    assert __name__ == '__main__'

    class _H(object):
        def __init__(self, val):
            self.val = val

        def __call__(self, *args, **kwargs):
            print(self.val)

    es = _EventSource()
    h1 = _H('foo')
    h2 = _H('bar')
    assert h1 not in es._handlers
    assert h2 not in es._handlers
    es += h1
    assert h1 in es._handlers
    assert h2 not in es._handlers
    es += h2
    assert h1 in es._handlers
    assert h2 in es._handlers

# Generated at 2022-06-11 17:42:21.224541
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    def handler():
        pass

    e += handler

    assert len(e._handlers) == 1



# Generated at 2022-06-11 17:42:27.577752
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Introduction
    events = _EventSource()
    results = []
    events += lambda *args, **kwargs: results.append('handler one')
    events += lambda *args, **kwargs: results.append('handler two')
    events += lambda *args, **kwargs: results.append('handler three')

    # When:
    events.fire(False)

    # Then:
    assert results == ['handler one', 'handler two', 'handler three']


# Generated at 2022-06-11 17:42:37.269441
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []
    on_load = _EventSource()

    def handler1(arg):
        calls.append('handler1: ' + arg)

    def handler2():
        calls.append('handler2')

    def handler3(arg1, arg2):
        calls.append('handler3: ' + arg1 + ':' + arg2)
        
    on_load += handler1
    on_load += handler2
    on_load += handler3

    on_load.fire('hello')
    on_load.fire('world', 'moon')

    assert calls == ['handler1: hello', 'handler2', 'handler3: world:moon']
