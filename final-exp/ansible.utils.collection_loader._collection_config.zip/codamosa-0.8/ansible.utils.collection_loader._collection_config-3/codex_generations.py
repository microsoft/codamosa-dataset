

# Generated at 2022-06-11 17:34:35.714107
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # result
    here = []

    # function to be called as event handler
    def handler(a, b, c, d, e):
        here.extend([a, b, c, d, e])

    # set up
    source = _EventSource()
    source += handler

    # test
    source.fire(1, 2, 3, 4, 5)

    # verify
    assert here == [1, 2, 3, 4, 5]



# Generated at 2022-06-11 17:34:44.640124
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create an instance of _EventSource
    evt = _EventSource()

    # To test the method fire, we simulate handlers that should be called
    # by the method fire, and then we check that these handlers were
    # actually called
    handler_1 = None
    handler_2 = None
    handler_3 = None
    handler_4 = None
    handler_5 = None
    handler_6 = None
    handler_7 = None
    handler_8 = None

    def handler_1(x):
        raise KeyError('handler_1')

    def handler_2(x):
        raise KeyError('handler_2')

    def handler_3(x):
        return x

    def handler_4(x):
        return x

    def handler_5(x):
        raise KeyError('handler_5')


# Generated at 2022-06-11 17:34:50.998113
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import unittest

    class EventSource_TestCase(unittest.TestCase):
        def test_bad_handler(self):
            es = _EventSource()
            self.assertRaises(ValueError, es.__iadd__, 'handler')

        def test_single_handler(self):
            es = _EventSource()

            handler_calls = []

            def func(*args, **kwargs):
                handler_calls.append((args, kwargs))

            es += func
            es.fire(1, 'b', c='c')

            self.assertEqual(len(handler_calls), 1)
            self.assertEqual(handler_calls[0][0], (1, 'b'))

# Generated at 2022-06-11 17:34:57.925207
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEvent(object):
        def __init__(self, source):
            self.val = source.val
            self.triggered = False

        def handler(self, event):
            self.triggered = True
            assert event.val == 'val'

    class MySource(object):
        @property
        def event(self):
            return self.__event

        @event.setter
        def event(self, value):
            self.__event = value

        def __init__(self):
            self.event = MyEvent(self)
            self.val = 'val'

    es = _EventSource()
    ms = MySource()

    es += ms.event.handler
    es.fire(ms.event)

    assert ms.event.triggered

    es -= ms.event.handler
    es

# Generated at 2022-06-11 17:34:58.749978
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass

# Generated at 2022-06-11 17:35:08.531222
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTester(_EventSource):
        def __init__(self):
            self._called = 0

        def handler(self, *args):
            self._called += 1

        def _on_exception(self, handler, exception, *args):
            return False

    handler = EventSourceTester().handler
    es = EventSourceTester()
    es.fire(1, 2, 3)
    assert es._called == 0

    es += handler
    es.fire(1, 2, 3)
    assert es._called == 1
    es.fire(1, 2, 3)
    assert es._called == 2

    es -= handler
    es.fire(1, 2, 3)
    assert es._called == 2

    es = EventSourceTester()
    es += handler
    es += handler
    es -= handler


# Generated at 2022-06-11 17:35:09.768846
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    foo = _EventSource()
    foo += print
    assert callable(foo)


# Generated at 2022-06-11 17:35:15.052769
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += object()
    assert len(es._handlers) == 1
    assert len(set(es._handlers)) == 1
    assert hasattr(es, '__iadd__')
    assert not hasattr(es, '__isub__')



# Generated at 2022-06-11 17:35:18.376166
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    h = lambda x: x

    e += h

    assert len(e._handlers) == 1
    assert list(e._handlers)[0] == h



# Generated at 2022-06-11 17:35:22.947266
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    events = _EventSource()

    assert not events._handlers

    def _event_handler():
        pass

    assert callable(_event_handler)

    events += _event_handler
    assert _event_handler in events._handlers

    events += _event_handler
    assert _event_handler in events._handlers



# Generated at 2022-06-11 17:35:35.306937
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class NotEventSource(_EventSource):
        pass

    called = []

    def handler(arg1, arg2, kwarg=None):
        called.append((arg1, arg2, kwarg))

    def handler2(arg1, arg2, kwarg=None):
        called.append('handler2')
        raise ValueError

    es = NotEventSource()
    es += handler
    es += handler2

    es.fire(1, 2)
    assert called == [(1, 2, None)]

    es.fire(1, 2, kwarg=3)
    assert called == [(1, 2, None), (1, 2, 3)]

    try:
        es.fire(1, 2, kwarg=3)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 17:35:38.275352
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1



# Generated at 2022-06-11 17:35:47.329812
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler(a, b=None):
        pass

    # handler must be callable
    event_source = _EventSource()
    try:
        event_source += 123
    except ValueError:
        pass
    else:
        raise AssertionError('invalid data type was not rejected')

    # valid handler is accepted
    event_source += handler
    try:
        event_source += handler
    except ValueError:
        pass
    else:
        raise AssertionError('duplicate handler was not rejected')

    # exception handling is tested below



# Generated at 2022-06-11 17:35:49.546855
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def noop_handler(o):
        pass

    es += noop_handler

    assert(noop_handler in es._handlers)



# Generated at 2022-06-11 17:35:58.445466
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    #
    # Make sure Class _EventSource is initialized
    AnsibleCollectionConfig()

    # Create our instance of class _EventSource
    event_source = _EventSource()

    # Create variables for assert_called_once_with method
    args = ()
    kwargs_list = [{}, {'foo': 'bar'}]

    # Create our mock method and add it to our event_source
    mock_method_1 = AnsibleCollectionConfig._on_collection_load.__iadd__(mock.MagicMock(return_value=None))

    # Loop over our kwargs list and call our fire method
    for kwargs in kwargs_list:
        event_source.fire(**kwargs)

        # Check that our mock_method was called as expected
        mock_method_1.assert_called_once_

# Generated at 2022-06-11 17:36:09.738858
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        # overwrite this method to adjust behavior when an exception is raised from a handler
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    # test that the event is fired for each handler (no exceptions)
    es = _TestEventSource()
    calls = [0, 0]

    def handler1(name):
        calls[0] += 1

    def handler2(name):
        calls[1] += 1

    es += handler1
    es += handler2
    es.fire(name='x')

    assert calls == [1, 1], 'did not fire event for each handler'

    # test that handlers which raise an exception are skipped
    es = _TestEventSource()
    calls = [0, 0, 0]


# Generated at 2022-06-11 17:36:17.246953
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def _handler(arg, **kwargs):
        pass

    def _handler2(arg, **kwargs):
        pass

    def _handler3(arg, **kwargs):
        raise Exception('ignore me')

    source = _EventSource()
    source += _handler
    source += _handler2
    source += _handler3
    source.fire(arg='foo')

    # order is not guaranteed, so test both ways
    source -= _handler
    source.fire(arg='foo')
    source -= _handler2
    source.fire(arg='foo')

# Generated at 2022-06-11 17:36:29.634742
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []
    source = _EventSource()

    def handler_1(*args, **kwargs):
        calls.append('handler_1')

    def handler_2(*args, **kwargs):
        calls.append('handler_2')
        raise Exception

    source += handler_1
    list(source._handlers)  # forces handler_1 to be a weak reference
    source += handler_2
    list(source._handlers)  # forces handler_2 to be a weak reference

    source.fire()
    assert calls == ['handler_1', 'handler_2']

    calls.clear()
    source -= handler_1
    source.fire()
    assert calls == ['handler_2']

    calls.clear()
    source -= handler_2
    source.fire()
    assert calls == []


# Generated at 2022-06-11 17:36:31.471324
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source.__iadd__('foo')


# Generated at 2022-06-11 17:36:35.884261
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def OnCollectionLoad(collection):
        print('collection has been loaded: "' + str(collection) + '"')

    AnsibleCollectionConfig.on_collection_load += OnCollectionLoad

    AnsibleCollectionConfig.on_collection_load.fire('my_collection')


# Generated at 2022-06-11 17:36:50.019179
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _EventHandler:
        def __init__(self, arg):
            self.arg = arg

        def __call__(self, *args, **kwargs):
            return self.arg

    event = _EventSource()

    handler = _EventHandler('foo')
    event += handler
    assert handler in event._handlers
    handler.arg = 'bar'

    assert handler in event._handlers
    assert event.fire() == 'bar'


# Generated at 2022-06-11 17:36:55.129054
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class CollectionConfig(_AnsibleCollectionConfig):
        def __init__(cls, meta, name, bases):
            super(CollectionConfig, cls).__init__(meta, name, bases)
            cls._on_collection_load = _EventSource()
            cls._on_collection_load += cls._raise

        @staticmethod
        def _raise(*args, **kwargs):
            raise TestException('test exception')

    class AnsibleCollectionConfig(with_metaclass(CollectionConfig)):
        pass

    AnsibleCollectionConfig.on_collection_load.fire()



# Generated at 2022-06-11 17:37:01.777349
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.utils.collection_loader import _EventSource

    myHandler = _EventSource()
    with test._AssertNotRaises(TypeError):
        myHandler += lambda: None
        myHandler += lambda x: x
    with test._AssertNotRaises(TypeError):
        myHandler -= lambda: None
        myHandler -= lambda x: x


# Generated at 2022-06-11 17:37:08.461153
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def f():
        pass
    def g():
        pass

    es += f
    es += f
    es += g
    assert len(es._handlers) == 2
    assert f in es._handlers
    assert g in es._handlers

    # A function can be added only once
    es += f
    assert len(es._handlers) == 2

    # Adding a non-callable triggers an exception
    try:
        es += 5
        assert False, "Expected exception"
    except ValueError:
        pass


# Generated at 2022-06-11 17:37:14.666007
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TODO: Tests added to test the functionality of __EventSource__fire
    # Arrange
    def dummy_handler(arg1, arg2=None):
        return arg1
    dummy_handler2 = dummy_handler
    es = _EventSource()
    es += dummy_handler
    es += dummy_handler2
    # Act
    es.fire(1)
    es.fire(2)
    # Assert
    assert es.fire(1) == 1
    assert es.fire(2) == 2

# Generated at 2022-06-11 17:37:18.922393
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class A:
        def __init__(self):
            self.a = 1

        def f(self, a):
            self.a += a

    e = _EventSource()
    a = A()
    e += a.f
    e.fire(2)
    assert a.a == 3

# Generated at 2022-06-11 17:37:27.404992
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Scenario: The method __iadd__ is tested by calling it with a
    # callable object and checking if the callable object is stored
    # in the set of handlers.

    # Setup
    event_source = _EventSource()
    # Exercise
    event_source += lambda x: x
    # Verify
    handlers = event_source._handlers
    assert len(handlers) == 1
    # Verify
    event_source += lambda x: x
    # Verify
    handlers = event_source._handlers
    assert len(handlers) == 1


# Generated at 2022-06-11 17:37:33.969483
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        pass

    def foo(*args, **kwargs):
        raise ValueError('expected')

    def bar(*args, **kwargs):
        raise TypeError('expected')

    def baz(*args, **kwargs):
        raise KeyError('expected')

    m = MyEventSource()
    m += foo
    m += bar
    m += baz
    with pytest.raises(ValueError) as exc:
        m.fire(1, 2, 3)
    assert str(exc.value) == 'expected'
    with pytest.raises(TypeError) as exc:
        m.fire(4, 5, 6)
    assert str(exc.value) == 'expected'

# Generated at 2022-06-11 17:37:44.896436
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    assert event._handlers == set()

    results = []

    def handler1(*args, **kwargs):
        results.append((args, kwargs))

    def handler2(*args, **kwargs):
        raise Exception('exception from handler 2')

    def handler3(*args, **kwargs):
        raise OSError('exception from handler 3')

    def handler4(*args, **kwargs):
        raise KeyboardInterrupt('exception from handler 4')

    event += handler1
    event += handler1
    event += handler2
    event += handler3
    event += handler4

    assert len(event._handlers) == 4


# Generated at 2022-06-11 17:37:53.292857
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    def on_handler_1(*args, **kwargs):
        assert len(args) == 1 and len(kwargs) == 0
        assert args[0] == 123

    def on_handler_2(*args, **kwargs):
        assert len(args) == 0 and len(kwargs) == 1
        assert kwargs['bar'] == 456

    def on_handler_3(*args, **kwargs):
        assert len(args) == 1 and len(kwargs) == 1
        assert args[0] == 345 and kwargs['baz'] == 678

    es += on_handler_1
    es += on_handler_2
    es += on_handler_3

    es.fire(123, bar=456, baz=678)

    es -= on_handler_2
   

# Generated at 2022-06-11 17:38:12.928416
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()
    assert x._handlers == set()

    with pytest.raises(ValueError):
        x += 1

    def handler():
        pass

    x += handler
    assert x._handlers == {handler}

    with pytest.raises(ValueError):
        x += handler


# Generated at 2022-06-11 17:38:20.673576
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils._text import to_text

    class _TestHandler:
        def __call__(self, *args, **kwargs):
            if len(args) > 0:
                self.args = args

            if len(kwargs) > 0:
                self.kwargs = kwargs

            self._on_call_args = args
            self._on_call_kwargs = kwargs

        def reset(self):
            self.args = None
            self.kwargs = None
            self._on_call_args = None
            self._on_call_kwargs = None

    es = _EventSource()
    h = _TestHandler()
    es += h

    args = tuple('abcde')
    kwargs = {'a': 'b', 'c': 'd'}


# Generated at 2022-06-11 17:38:31.669739
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSource_test(_EventSource):
        def __init__(self):
            super(_EventSource_test, self).__init__()
            self.calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.calls.append((handler, exc, args, kwargs))
            return True

    es = _EventSource_test()

    def handler1(*a, **kw):
        1 / 0

    def handler2(*a, **kw):
        1 / 0

    def handler3(*a, **kw):
        raise RuntimeError('test')

    es += handler1
    es += handler2
    es += handler3

    try:
        es.fire('hello', world='world')
    except ZeroDivisionError:
        pass


# Generated at 2022-06-11 17:38:33.592923
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler():
        pass

    es = _EventSource()
    es += handler
    es.fire()

# Generated at 2022-06-11 17:38:37.012350
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_test._util.target.legacy_collection_loader.event_handler import EventHandler
    EventHandler.test__EventSource___iadd__(lambda: _EventSource())



# Generated at 2022-06-11 17:38:40.002521
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test = _EventSource()
    test += lambda: None
    assert len(test._handlers) == 1



# Generated at 2022-06-11 17:38:45.692490
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def foo():
        return

    def bar():
        return

    def baz(a, b, c):
        return

    def bam(a, b, c, d=None, e=None):
        return

    es = _EventSource()

    es += foo

    assert foo in es._handlers



# Generated at 2022-06-11 17:38:49.954244
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Assign
    event_source = _EventSource()

    # Act
    event_source.fire(item=1)

    def handler1(item=None):
        assert item == 2

    event_source += handler1

    event_source.fire(item=2)

    # Assert

# Generated at 2022-06-11 17:38:59.269872
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestHandler:
        def __init__(self):
            self.was_called = False
            self.call_count = 0
            self.was_called_with_name = None
            self.was_called_with_kwargs = None

        def __call__(self, name, **kwargs):
            self.was_called = True
            self.call_count += 1
            self.was_called_with_name = name
            self.was_called_with_kwargs = kwargs

    test_handler_1 = TestHandler()
    test_handler_2 = TestHandler()
    test_handler_3 = TestHandler()

    es = _EventSource()
    es += test_handler_1
    es += test_handler_2
    es += test_handler_3


# Generated at 2022-06-11 17:39:02.947165
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert callable(es)

    def addtwo(value):
        return value + 2

    es += addtwo
    assert es._handlers == { addtwo }

    es += addtwo
    assert es._handlers == { addtoo }



# Generated at 2022-06-11 17:39:37.713712
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def add_one(value):
        return value + 1

    def concat(value):
        return ''.join(value)

    event_source = _EventSource()
    event_source += add_one
    event_source += concat
    result = event_source.fire('abc')
    assert result == 'abcabc'


# Generated at 2022-06-11 17:39:47.853904
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceSubclass(_EventSource):
        def _on_exception(self, handler, exc, a, b):
            # call the superclass' _on_exception
            return super(EventSourceSubclass, self)._on_exception(handler, exc, a, b)

    def handler1(a, b):
        handler1_call_args.append((a, b))
    def handler2(a, b):
        handler2_call_args.append((a, b))

    es = EventSourceSubclass()
    es += handler1
    es += handler2

    handler1_call_args = []
    handler2_call_args = []
    es.fire(1, 2)
    assert handler1_call_args == [(1, 2)]
    assert handler2_call_args == [(1, 2)]

# Generated at 2022-06-11 17:39:56.468457
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def my_handler(self, *args, **kwargs):
        global my_handler_args
        global my_handler_kwargs
        my_handler_args = args
        my_handler_kwargs = kwargs

    my_handler_args = None
    my_handler_kwargs = None
    event_source = _EventSource()
    event_source += my_handler
    event_source.fire('first1', 'first2', third='third')
    assert my_handler_args == ('first1', 'first2')
    assert my_handler_kwargs == {'third': 'third'}

# Generated at 2022-06-11 17:39:58.985639
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    p = lambda x: x
    assert p not in s._handlers
    s += p
    assert p in s._handlers


# Generated at 2022-06-11 17:40:03.969903
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestFoo:
        pass

    foo = TestFoo()
    foo.on_event += lambda: print('my event fired')
    assert foo.on_event._handlers
    assert callable(foo.on_event._handlers.pop())



# Generated at 2022-06-11 17:40:15.190975
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from unittest import TestCase, main


    class EventSourceTestCase(TestCase):
        def setUp(self):
            self.es = _EventSource()

        def test__EventSource___iadd__add(self):
            self.es += self._handler()
            self.assertEquals(1, len(self.es._handlers))

        def test__EventSource___iadd__add_func_not_callable(self):
            with self.assertRaises(ValueError):
                self.es += None

        def test__EventSource___iadd__add_same_twice(self):
            self.es += self._handler()
            self.es += self._handler()
            self.assertEquals(1, len(self.es._handlers))


# Generated at 2022-06-11 17:40:18.201792
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class Test:
        def foo(self):
            pass

    test = Test()
    event_source = _EventSource()
    event_source += test.foo


# Generated at 2022-06-11 17:40:20.738406
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert not event_source._handlers
    event_source += lambda: None
    assert event_source._handlers


# Generated at 2022-06-11 17:40:24.168758
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def ok(self, result):
        self.result = result

    e = _EventSource()
    x = Callable()
    x.result = None
    e += ok
    e += x
    e.fire('ok')
    assert x.result == 'ok'



# Generated at 2022-06-11 17:40:33.509430
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest

    event_source = _EventSource()

    def handler1(arg1, arg2):
        return arg1

    event_source += handler1

    with pytest.raises(ValueError):
        event_source += None

    def handler2(arg1, **kwargs):
        return arg1 + kwargs['value']

    event_source += handler2

    args = ['arg1']
    kwargs = {'arg2': 'arg2', 'value': 'value'}
    assert event_source.fire(*args, **kwargs) == 'arg1value'



# Generated at 2022-06-11 17:41:12.163115
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Using the following class to test __iadd__ method
    class _TestClass:
        def my_function(self):
            pass

    test_obj = _EventSource()
    test_obj += _TestClass().my_function
    assert callable(test_obj._handlers.pop())
    assert len(test_obj._handlers) == 0


# Generated at 2022-06-11 17:41:17.992965
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()
    assert len(source._handlers) == 0

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise ValueError('test')

    source += handler1
    source += handler2

    assert len(source._handlers) == 2
    source.fire()

    source -= handler1
    source -= handler2

    assert len(source._handlers) == 0

# Generated at 2022-06-11 17:41:27.153454
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class FireTest:
        def __init__(self):
            self.pre = []
            self.post = []

        def __call__(self, *args, **kwargs):
            self.pre = args
            self.post = kwargs

    test = FireTest()
    src = AnsibleCollectionConfig.on_collection_load

    src += test
    src.fire(1, 2, 3)
    assert test.pre == (1, 2, 3)
    assert test.post == {}

    src.fire(a=1, b=2, c=3)
    assert test.pre == ()
    assert test.post == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-11 17:41:36.965600
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()
    assert x._handlers == set()

    # handler must be callable
    try:
        x += None
    except ValueError:
        pass
    else:
        assert False, 'handler must be callable'
    assert x._handlers == set()

    # adding a handler to the set
    x += lambda: None
    assert x._handlers == {lambda: None}
    x += lambda: None
    assert x._handlers == {lambda: None}

    # removing a handler from the set
    x -= lambda: None
    assert x._handlers == set()

    x += lambda: None
    assert x._handlers == {lambda: None}

    x -= lambda: None
    assert x._handlers == set()

    # removing a nonexistent handler
    x -= lambda: None

    # adding

# Generated at 2022-06-11 17:41:47.292761
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from unittest import TestCase

    class Foo(TestCase):
        def test(self):
            es = _EventSource()
            calls = []

            def handle_exception(handler, exc, *args, **kwargs):
                calls.append((handler, exc, args, kwargs))
                return False

            es._on_exception = handle_exception

            def handler1(a, b, c):
                calls.append((handler1, a, b, c))
                raise ValueError()

            def handler2(a, b, c):
                calls.append((handler2, a, b, c))
                raise ValueError()

            def handler3(a, b, c):
                calls.append((handler3, a, b, c))
                # don't raise an exception, let this one pass

            es += handler

# Generated at 2022-06-11 17:41:58.377388
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    args = []
    kwargs = {}

    def handler(arg, kwarg=None):
        args.append(arg)
        kwargs[kwarg] = kwarg

    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    # We can add an instance method as a handler
    event_source += handler
    assert len(event_source._handlers) == 1

    # We can add a function as a handler
    def function():
        pass
    event_source += function
    assert len(event_source._handlers) == 2

    # We cannot add a string as a handler
    try:
        event_source += 'abc'
    except ValueError:
        pass
    else:
        assert False, 'string added as event handler'

# Generated at 2022-06-11 17:42:03.477344
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # init
    event_source = _EventSource()
    result_event_1 = None
    result_event_2 = None
    # execute
    event_source += on_event_1
    event_source += on_event_2
    event_source.fire('parameter')
    # check
    assert result_event_1 == 'parameter'
    assert result_event_2 == 'parameter'


# Generated at 2022-06-11 17:42:12.962964
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(*args, **kwargs):
        handler_args.append(args)
        handler_kwargs.append(kwargs)

    event_source = _EventSource()
    event_source += handler

    handler_args = []
    handler_kwargs = []
    expected_handler_args = [
        (),
    ]
    expected_handler_kwargs = [
        {}
    ]
    event_source.fire()
    assert handler_args == expected_handler_args
    assert handler_kwargs == expected_handler_kwargs

    handler_args = []
    handler_kwargs = []
    expected_handler_args = [
        ((1, 2, 3),),
        (('a', 'b', 'c'),)
    ]
    expected_handler_kwargs = [
        {}
    ] * 2
   

# Generated at 2022-06-11 17:42:20.151410
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from collections import namedtuple

    call_data = []

    def func(a, b, c='c'):
        call_data.append(namedtuple('call', ['a', 'b', 'c'])(a, b, c))

    event = _EventSource()
    event += func
    event.fire(1, 2)
    event.fire(3, 4, c=5)

    assert len(call_data) == 2
    assert call_data[0].a == 1
    assert call_data[0].b == 2
    assert call_data[0].c == 'c'
    assert call_data[1].a == 3
    assert call_data[1].b == 4
    assert call_data[1].c == 5

# Generated at 2022-06-11 17:42:30.896373
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class MockEventSource(_EventSource):
        def __init__(self):
            self.iadd_handlers = set()
            super(MockEventSource, self).__init__()

        def __iadd__(self, handler):
            self.iadd_handlers.add(handler)
            return super(MockEventSource, self).__iadd__(handler)

    handler1 = lambda: None
    handler2 = lambda: None

    EventSource = MockEventSource()
    EventSource += handler1
    assert handler1 in EventSource._handlers
    assert handler1 in EventSource.iadd_handlers
    EventSource += handler1
    assert handler1 in EventSource._handlers
    assert handler1 in EventSource.iadd_handlers
    EventSource += handler2
    assert handler2 in EventSource._handlers
   

# Generated at 2022-06-11 17:43:40.242710
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils._text import to_bytes

    import unittest2 as unittest

    class Test(object):
        class TestError(Exception):
            pass

        def test_method(self, method, args, kwargs):
            args_expected = (to_bytes(b'a'), to_bytes(b'b'), 12, to_bytes(b'c'), to_bytes(b'd'))

# Generated at 2022-06-11 17:43:49.533883
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def e1(a, b):
        assert a == 1
        assert b == 2
        return 'e1'

    def e2(x):
        assert x == 'a'
        raise TestException('expected exception')

    events = _EventSource()
    events += e1
    events += e2

    s = events.fire(1, 2)
    assert 'e1' in s

    try:
        events.fire('a')
    except TestException:
        pass
    else:
        assert False, 'expected TestException'

# Generated at 2022-06-11 17:43:59.183381
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # On Python 2.7, unittest.skipTest is not a function.
    # This causes the test collection to fail on Python 2.7.
    # Workaround is to call a no-op unittest.skipTest method.
    def skipTest(*args, **kwargs):
        pass

    class TestException(Exception):
        pass

    class TestCallable(object):
        def __call__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs
            raise TestException()

    assert len(AnsibleCollectionConfig.on_collection_load._handlers) == 0

    callback1 = lambda x: None
    callback2 = lambda x: None

    AnsibleCollectionConfig.on_collection_load += callback1
    assert AnsibleCollectionConfig.on_collection_load._hand

# Generated at 2022-06-11 17:44:03.263248
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_event_source = _EventSource()
    test_count = [0]

    def test_handler(value):
        test_count[0] += value

    test_event_source += test_handler
    test_event_source.fire(10)

    assert test_count[0] == 10



# Generated at 2022-06-11 17:44:11.117374
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    called = []

    def callback(*argv, **kwargs):
        called.append((argv, kwargs))

    event_source = _EventSource()
    event_source += callback

    event_source.fire('a', 'b', 'c')
    assert called == [((('a', 'b', 'c'),), {})]

    called = []
    event_source.fire(foo='bar', baz='bax')
    assert called == [(((),), {'foo': 'bar', 'baz': 'bax'})]

    called = []
    event_source.fire()
    assert called == [(((),), {})]

# Generated at 2022-06-11 17:44:21.849955
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._fired = False
            self._args = None
            self._kwargs = None

        def __iadd__(self, handler):
            super(TestEventSource, self).__iadd__(handler)
            # validate the test setup
            assert len(self._handlers) == 1
            assert handler in self._handlers
            return self

        def fire(self, *args, **kwargs):
            self._fired = True
            self._args = args
            self._kwargs = kwargs
            return super(TestEventSource, self).fire(*args, **kwargs)

    def handler(*args, **kwargs):
        pass

    test_event_source = TestEventSource()


# Generated at 2022-06-11 17:44:30.677604
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_test.lib.test_loader.test_data import EXAMPLE_ANSIBLE_COLLECTION_CONFIG, EXAMPLE_ANSIBLE_COLLECTION_CONFIG_2
    import ansible_collections.test.basic
    import ansible_collections.test.utils
    import collections

    # collection_loader is the module under test
    import ansible_collections.ansible.community.plugins.module_utils.collection_loader

    def _on_collection_load_handler(*args, **kwargs):
        pass

    def _on_collection_load_handler_that_raises(*args, **kwargs):
        raise Exception('Expected exception')

    assert AnsibleCollectionConfig.on_collection_load == _EventSource()

    # No handler registered
    AnsibleCollectionConfig.on_collection_load.fire