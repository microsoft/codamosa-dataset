

# Generated at 2022-06-11 17:34:34.824839
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    handler_count = 0  # Handler count
    handler_args_list = []  # Handler args list

    def handler_1(arg1, arg2='abc'):
        nonlocal handler_count
        handler_count += 1
        handler_args_list.append((handler_1, arg1, arg2))

    def handler_2(arg1, arg2='def'):
        nonlocal handler_count
        handler_count += 1
        handler_args_list.append((handler_2, arg1, arg2))

    event_source = _EventSource()
    event_source.fire(None)

    assert handler_count == 0
    assert handler_args_list == []

    event_source += handler_1
    event_source += handler_2

    event_source.fire(None)

    assert handler_count == 2


# Generated at 2022-06-11 17:34:36.338735
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()

    def foo():
        pass

    x += foo



# Generated at 2022-06-11 17:34:39.457154
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    es += 1
    assert len(es._handlers) == 0

    es += lambda: True
    assert len(es._handlers) == 1



# Generated at 2022-06-11 17:34:47.556225
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventA:
        def __init__(self, msg=None):
            self.msg = msg

        def __call__(self, *args, **kwargs):
            pass

    class EventB:
        def __init__(self, msg=None):
            self.msg = msg

        def __call__(self, *args, **kwargs):
            pass

    class TestEventSource(_EventSource):
        pass

    test_event_source_instance = TestEventSource()

    event_a_instance = EventA()
    event_b_instance = EventB()

    test_event_source_instance += event_a_instance
    test_event_source_instance += event_b_instance

    test_event_source_instance.fire()

    assert event_a_instance in test_event_source_instance._handlers

# Generated at 2022-06-11 17:34:53.674503
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(*args, **kwargs):
        return

    def handler2(*args, **kwargs):
        return

    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    event_source += handler1
    assert len(event_source._handlers) == 1
    assert handler1 in event_source._handlers

    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler2 in event_source._handlers


# Generated at 2022-06-11 17:34:59.319740
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    assert len(event._handlers) == 0

    def handler(*args, **kwargs):
        pass

    event += handler
    assert len(event._handlers) == 1
    assert handler in event._handlers

    event += handler
    assert len(event._handlers) == 1

    event += handler
    assert len(event._handlers) == 1



# Generated at 2022-06-11 17:35:05.758823
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ex_event_source = _EventSource()

    def handler_one():
        raise ValueError('handler_one')

    def handler_two():
        raise RuntimeError('handler_two')

    ex_event_source += handler_one
    ex_event_source += handler_two

    try:
        ex_event_source.fire()
    except Exception as ex:
        assert('handler_one' in to_text(ex))
        assert('handler_two' in to_text(ex))

# Generated at 2022-06-11 17:35:11.041328
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import threading
    import time

    es = _EventSource()
    finished = threading.Event()

    def handler():
        finished.set()

    es += handler

    def event_source_tester():
        es.fire()

    t = threading.Thread(target=event_source_tester)
    t.setDaemon(True)
    t.start()

    if not finished.wait(timeout=5.0):
        raise AssertionError('handler method did not execute within 5.0 seconds')



# Generated at 2022-06-11 17:35:18.332782
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler1(num, text='pig'):
        assert num == 34
        assert text == 'cat'

    def handler2(num, text='dog'):
        assert num == 34
        assert text == 'cat'

    e = _EventSource()
    e += handler1
    e += handler2
    e.fire(34, text='cat')
    e -= handler1
    e.fire(34, text='cat')


# Generated at 2022-06-11 17:35:22.222771
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    es = _EventSource()
    h1 = lambda: None

    # Act
    es += h1

    # Assert
    if h1 not in es._handlers:
        raise AssertionError('handler not added')



# Generated at 2022-06-11 17:35:35.198245
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def _callback1(s):
        _callbacks.append(s)

    def _callback2(s):
        if s == 'raise':
            raise Exception('no')

    _event_source = _EventSource()
    _event_source.on_exception = lambda x: None
    _callbacks = []

    _event_source += _callback1
    _event_source += _callback2

    _event_source.fire('ok')
    _event_source.fire('ok1')
    _event_source.fire('ok2')
    _event_source.fire('raise')

    assert _callbacks == ['ok', 'ok1', 'ok2']

# Generated at 2022-06-11 17:35:46.955778
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventTest(object):
        def __init__(self):
            self.event = _EventSource()
            self.counter = 0

        def handler(self, *args, **kwargs):
            assert args == (1, 2)
            assert kwargs == {'three': 3}
            self.counter += 1

        def test_fire(self):
            self.event += self.handler
            self.event.fire(1, 2, three=3)
            assert self.counter == 1
            self.event.fire(1, 2, three=3)
            assert self.counter == 2

        def test_exception(self):
            def raise_exception(*args, **kwrags):
                raise Exception()

            self.event += raise_exception

# Generated at 2022-06-11 17:35:49.217549
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()

    a = []
    e += lambda: a.append('one')
    e += lambda: a.append('two')
    e.fire()

    assert a == ['one', 'two']

# Generated at 2022-06-11 17:35:51.767387
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    cls = _EventSource()
    foo = lambda: None
    assert foo not in cls._handlers

    cls += foo
    assert foo in cls._handlers

# Generated at 2022-06-11 17:35:52.777300
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    raise NotImplementedError()

# Generated at 2022-06-11 17:35:58.799950
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup test
    # __init__
    target = _EventSource()

    handler1 = (lambda *args, **kwargs: print('handler1: args=%s, kwargs=%s' % (args, kwargs)))
    handler2 = (lambda *args, **kwargs: print('handler2: args=%s, kwargs=%s' % (args, kwargs)))

    target += handler1
    target += handler2

    # Execute the method under test
    target.fire('arg1', 'arg2')

    # Verify the results


# Generated at 2022-06-11 17:36:01.035937
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    target = _EventSource()

    def handler():
        pass

    target += handler
    assert handler in target._handlers


# Generated at 2022-06-11 17:36:12.010202
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventObject:
        def __init__(self, handler):
            self.handler = handler

        def fire(self, event, *args, **kwargs):
            self.handler(event, *args, **kwargs)

    event = EventObject('event')
    es = _EventSource()

    # check ValueError
    try:
        es += 'not callable'
    except ValueError:
        pass
    else:
        assert False, "ValueError is not raised when handler is not callable"

    # check __iadd__ and __isub__
    es += event.fire
    assert len(es._handlers) is 1

    es -= event.fire
    assert len(es._handlers) is 0

    # check event

# Generated at 2022-06-11 17:36:23.636604
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_object = _EventSource()
    test_subject = _EventSource()

    def callable_function():
        pass

    def callable_method(self):
        pass

    def callable_lambda():
        pass

    def callable_class():
        pass

    callable_method = callable_method.__get__(object())

    assert test_object is not test_subject
    assert test_object == test_subject
    assert test_object != callable_function
    assert callable_function != test_object
    assert test_object != callable_method
    assert callable_method != test_object
    assert test_object != callable_lambda
    assert callable_lambda != test_object
    assert test_object != callable_class
    assert callable_class != test_object

    test_subject += call

# Generated at 2022-06-11 17:36:30.763056
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert e._handlers == set()

    def __on_collection_load__(collection):
        pass
    e.__iadd__(__on_collection_load__)
    assert e._handlers == {__on_collection_load__}

    e += __on_collection_load__
    assert e._handlers == {__on_collection_load__}

    try:
        e += None
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-11 17:36:50.375137
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Success
    event_source = _EventSource()
    assert not event_source._handlers

    def my_handler():
        pass

    event_source += my_handler
    assert my_handler in event_source._handlers

    # Failure
    event_source = _EventSource()
    try:
        event_source += 'not a handler'
    except ValueError as ex:
        assert str(ex) == 'handler must be callable'
    else:
        assert False


# Generated at 2022-06-11 17:36:59.377460
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Recorder:
        def __init__(self):
            self.handled = []

        def handler(self, *args, **kwargs):
            self.handled.append((args, kwargs))

    class Sender:
        def __init__(self):
            self.on_event = _EventSource()

    r = Recorder()
    s = Sender()

    s.on_event += r.handler
    s.on_event.fire(0, 1, two=2)
    assert r.handled == [((0, 1), {'two': 2})]

# Generated at 2022-06-11 17:37:06.234305
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def raise_exception(exc_type, exc_msg):
        def f(*args, **kwargs):
            raise exc_type(exc_msg)
        return f

    class RecordingException:
        pass

    # no exceptions happen
    e = _EventSource()
    e.fire()
    e += lambda: None
    e.fire()

    # exceptions are consumed by the fire() method
    e += raise_exception(Exception, 'foobar')
    e += raise_exception(RecordingException, 'baz')

    e.fire()

    # exceptions are re-raised
    e.on_exception = lambda self, handler, exc, *args, **kwargs: isinstance(exc, RecordingException)

# Generated at 2022-06-11 17:37:09.093416
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler
    assert event_source._handlers
    assert handler in event_source._handlers
    event_source += handler
    assert len(event_source._handlers) == 1


# Generated at 2022-06-11 17:37:10.609661
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: True


# Generated at 2022-06-11 17:37:14.920209
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    num_events = 0

    def handler(event_num):
        nonlocal num_events
        num_events = event_num

    # initialize the event source
    s = _EventSource()
    # register handler
    s += handler

    # trigger event
    s.fire(1)
    assert num_events == 1


# Generated at 2022-06-11 17:37:26.303661
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    invocations = []

    def handler1(*args, **kwargs):
        invocations.append((handler1, args, kwargs))

    def handler2(*args, **kwargs):
        invocations.append((handler2, args, kwargs))

    def handler3(*args, **kwargs):
        invocations.append((handler3, args, kwargs))

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire("foo", "bar", baz="baz")


# Generated at 2022-06-11 17:37:34.500274
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self, events):
            super(_TestEventSource, self).__init__()
            self.events = events

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append({'handler': handler, 'exception': exc, 'args': args, 'kwargs': kwargs})

    def func_raise_exc(*args, **kwargs):
        raise ValueError('func_raise_exc')

    def func_raise_exc_ignore(*args, **kwargs):
        raise ValueError('func_raise_exc_ignore')

    def func2_raise_exc(*args, **kwargs):
        raise ValueError('func2_raise_exc')

    def func3(*args, **kwargs):
        pass



# Generated at 2022-06-11 17:37:40.652065
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    assert len(s._handlers) == 0

    def handler_1():
        pass

    s += handler_1
    assert len(s._handlers) == 1
    assert handler_1 in s._handlers

    def handler_2():
        pass

    s += handler_2
    assert len(s._handlers) == 2
    assert handler_2 in s._handlers



# Generated at 2022-06-11 17:37:48.114043
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()
    class Handler:
        def __init__(self):
            self.called = 0
        def __call__(self):
            self.called += 1
    handler1 = Handler()
    handler2 = Handler()
    s += handler1
    s += handler2
    s.fire()
    assert handler1.called == 1
    assert handler2.called == 1

    s -= handler1
    s.fire()
    assert handler1.called == 1
    assert handler2.called == 2


# Generated at 2022-06-11 17:38:06.067320
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils._text import to_text

    source = _EventSource()
    source += to_text
    assert to_text in source._handlers
    source += to_text
    assert to_text in source._handlers
    assert len(source._handlers) == 1



# Generated at 2022-06-11 17:38:16.381287
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Handler:
        def __init__(self):
            self._call_count = 0

        def __call__(self, *args, **kwargs):
            self._call_count += 1

    obj = _EventSource()
    assert len(obj._handlers) == 0

    handler = Handler()
    obj += handler
    assert len(obj._handlers) == 1

    obj.fire()
    assert handler._call_count == 1

    obj -= handler
    assert len(obj._handlers) == 0

    obj.fire()
    assert handler._call_count == 1

    def bad_handler():
        raise RuntimeError('oops')

    try:
        obj += bad_handler
        assert False
    except ValueError:
        pass

    obj += handler
    obj -= bad_handler
    obj.fire()

# Generated at 2022-06-11 17:38:25.362420
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class DummyEventSource(_EventSource):
        def __init__(self):
            super(DummyEventSource, self).__init__()
            self.fired_with = None

        def __call__(self, *args, **kwargs):
            self.fired_with = args, kwargs

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    dummy_event_source = DummyEventSource()
    dummy_event_source += dummy_event_source
    dummy_event_source.fire(1, 2, 3, keyword='argument')
    assert dummy_event_source.fired_with == ((1, 2, 3), {'keyword': 'argument'})

# Generated at 2022-06-11 17:38:34.214080
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestEvent(object):
        def __init__(self, f):
            self.call_count = 0
            self.f = f

        def __call__(self, *args, **kwargs):
            self.call_count += 1
            self.f(*args, **kwargs)

    event = _EventSource()
    handler = TestEvent(lambda x: x)
    event.fire(1, 2)
    assert handler.call_count == 0
    event += handler
    assert len(event._handlers) == 1
    event.fire(1, 2)
    assert handler.call_count == 1

# Generated at 2022-06-11 17:38:46.862118
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(exc, *args, **kwargs):
        raise ValueError

    def handler2(exc, *args, **kwargs):
        return True

    def handler3():
        raise IndexError

    def handler4():
        return True

    s = _EventSource()
    s.fire()

    s += handler1
    try:
        s.fire()
    except ValueError:
        pass

    s = _EventSource()
    s += handler2
    try:
        s.fire()
    except ValueError:
        pass

    s = _EventSource()
    s += handler3
    try:
        s.fire()
    except IndexError:
        pass

    s = _EventSource()
    s += handler4
    try:
        s.fire()
    except IndexError:
        pass

# Generated at 2022-06-11 17:38:50.190876
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    events = _EventSource()
    assert events._handlers == set()

    def test_handler():
        pass

    events += test_handler
    assert events._handlers == {test_handler}
    events += test_handler
    assert events._handlers == {test_handler}

    def another_handler():
        pass

    events += another_handler
    assert events._handlers == {test_handler, another_handler}


# Generated at 2022-06-11 17:38:59.494464
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    
    safe_event = _EventSource()
    results = []

    def handler_1(x, y):
        results.append('1:%s,%s' % (x, y))

    def handler_2(x, y, z):
        results.append('2:%s,%s,%s' % (x, y, z))

    def handler_bad_1(x, y):
        1 / 0

    def handler_bad_2(x, y, z):
        raise RuntimeError('bad handler')

    def handle_error(handler, exc, *args, **kwargs):
        # we expect an exception and want to keep the process going
        results.append('exception from %s (%s)' % (handler, exc))
        return False

    safe_event._on_exception = handle_error
   

# Generated at 2022-06-11 17:39:02.909627
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Create an EventSource object.
    a = _EventSource()

    # Declare a callable object.
    def callable_handler():
        pass

    # Call the __iadd__ method.
    a += callable_handler



# Generated at 2022-06-11 17:39:08.433422
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    global fired
    class MockEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return True

    def assert_fired(x):
        global fired
        fired = x

    mock_event_source = MockEventSource()
    mock_event_source += assert_fired
    fired = False
    mock_event_source.fire(True)
    assert fired



# Generated at 2022-06-11 17:39:17.721601
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    i = _EventSource()

    def f():
        pass

    i += f
    assert f in i._handlers

    # we are using set() so adding a second time is ok
    i += f
    assert f in i._handlers

    # try adding a non-function - expect ValueError
    try:
        i += None
    except ValueError:
        pass # expected
    else:
        raise AssertionError('ValueError not raised')

    # we expect set() to remove f
    i -= f
    assert f not in i._handlers

    # try removing a non-function - expect no exception
    i -= None
    assert f not in i._handlers


# Generated at 2022-06-11 17:39:38.578332
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    class _MockEventSource(_EventSource):
        def __init__(self):
            super(_MockEventSource, self).__init__()
            self._handlers = list(self._handlers)

    def _handler(arg):
        pass

    events = _MockEventSource()

    # add with +=
    events += _handler

    assert len(events._handlers) == 1
    assert _handler in events._handlers

    # add with __iadd__
    events.__iadd__(_handler)

    assert len(events._handlers) == 2
    assert _handler in events._handlers
    assert _handler in events._handlers

# Generated at 2022-06-11 17:39:47.741869
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler(arg1, arg2, arg3):
        pass

    def handler2(arg1, arg2, arg3):
        raise RuntimeError('handler2 fired')

    # handler added but not fired
    event_source += handler

    # handler2 added and fired
    event_source += handler2

    # handler added and fired
    event_source += handler

    # handler2 removed before fired
    event_source -= handler2

    # handler3 added, but unable to be removed due to use of += on the handler
    event_source += handler

    # now fire the event
    event_source.fire(1, 2, 3)

    # handler3 should still be in the set
    assert handler in event_source._handlers

# Generated at 2022-06-11 17:39:53.971590
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    evt = _EventSource()
    evt.fire = lambda : None
    evt += evt.fire
    assert 1 == len(evt._handlers)
    assert 1 == len(set(evt._handlers))
    evt += evt.fire
    assert 1 == len(evt._handlers)
    assert 1 == len(set(evt._handlers))


# Generated at 2022-06-11 17:40:04.934598
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestHandler(object):
        def __init__(self, event_source):
            self._event_source = event_source

            self._args = None
            self._kwargs = None
            self._fired = False

        def assert_fired(self, args=None, kwargs=None):
            if not self._fired:
                if args is None:
                    args = tuple()

                if kwargs is None:
                    kwargs = {}

                raise AssertionError('handler has not fired, expected: [{0}], [{1}]'.format(args, kwargs))

            elif args and tuple(args) != self._args:
                raise AssertionError('handler arguments do not match, expected: [{0}], actual: [{1}]'.format(args, self._args))

            el

# Generated at 2022-06-11 17:40:12.970423
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def handler_one(value, foo=None):
        assert value == 'bar'
        assert foo == 'baz'
        handler_one.called = True

    def handler_two(value, foo=None):
        assert value == 'bar'
        assert foo == 'baz'
        handler_two.called = True

    handler_one.called = False
    handler_two.called = False

    event += handler_one
    event += handler_two
    event.fire('bar', foo='baz')

    assert handler_one.called
    assert handler_two.called

# Generated at 2022-06-11 17:40:19.189070
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    target = _EventSource()

    def foo(a, b, c=3):
        pass

    def bar(a, b, c=3):
        pass

    target += foo
    target += bar

    assert foo in target._handlers
    assert bar in target._handlers

    target += 1

    assert len(target._handlers) == 2



# Generated at 2022-06-11 17:40:25.111623
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source = _EventSource()

    count = {'raise': 0, 'call': 0}

    # define two functions, one raises an error, one just increments the counter.
    def raise_error(*args, **kwargs):
        raise Exception('error')

    def increment(*args, **kwargs):
        count['call'] += 1

    event_source += raise_error
    event_source += increment

    try:
        event_source.fire()
        assert False, 'expected exception'
    except Exception:
        count['raise'] += 1

    assert count['raise'] == 1
    assert count['call'] == 1



# Generated at 2022-06-11 17:40:33.965201
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    try:
        import pytest
    except ImportError:
        raise Exception('pytest is required to run this unit test')

    es = _EventSource()

    def handler():
        raise Exception('handler called')

    es += handler
    with pytest.raises(Exception) as exc_info:
        es.fire()
    assert str(exc_info.value) == 'handler called'

    with pytest.raises(ValueError) as exc_info:
        es += "foo"
    assert str(exc_info.value) == 'handler must be callable'


# Generated at 2022-06-11 17:40:38.636574
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2=None):
        pass

    def handler2(arg1, arg2):
        raise ValueError

    source = _EventSource()
    source += handler1

    source.fire('foo', arg2='bar')

    # Test handler2 raises exception and should re-raise by _EventSource
    source += handler2
    try:
        source.fire('foo', arg2='bar')
    except ValueError:
        pass

# Generated at 2022-06-11 17:40:46.784590
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    raised_exc = RuntimeError('xyz')

    def check(event_source, handler, *args, **kwargs):
        msg = 'handler is not callable'
        with pytest.raises(TypeError, message=msg) as exc_info:
            event_source.fire(handler, *args, **kwargs)
        assert 'fire() takes exactly 2' not in str(exc_info)

    event_source = _EventSource()
    with pytest.raises(TypeError, message='handler is not callable') as exc_info:
        event_source.fire(None)
    assert 'fire() takes exactly 2' not in str(exc_info)

    event_source = _EventSource()
    class Class:
        def __call__(self):
            raise raised_exc
    event_source += Class

# Generated at 2022-06-11 17:41:26.637671
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class FooException(Exception):
        pass

    class BarException(Exception):
        pass

    def on_exception(handler, exception, *args, **kwargs):
        if isinstance(exception, FooException):
            return False

        return True

    e = _EventSource()

    e._on_exception = on_exception

    def func1(*args, **kwargs):
        raise FooException()

    def func2(*args, **kwargs):
        raise BarException()

    e += func1

    try:
        e.fire()
    except FooException:
        pass
    else:
        raise AssertionError('FooException not raised')

    e += func2

    try:
        e.fire()
    except:
        pass

# Generated at 2022-06-11 17:41:30.123139
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    assert len(source._handlers) == 0
    source += lambda: None
    assert len(source._handlers) == 1
    source += lambda: None
    assert len(source._handlers) == 2



# Generated at 2022-06-11 17:41:36.483573
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._expected = 1

    class _TestHandler:
        def __init__(self):
            self._state = []

        def test_function(self, event):
            self._state.append(event)

        def test_function_fail(self, event):
            raise NotImplementedError

        def test_function_exception(self, event):
            raise RuntimeError

    test__EventSource_fire = _TestEventSource()

    test__EventSource_fire += _TestHandler().test_function
    test__EventSource_fire += _TestHandler().test_function_fail
    test__EventSource_fire += _TestHandler().test_function_exception

    test__EventSource_fire

# Generated at 2022-06-11 17:41:38.122318
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source += 1



# Generated at 2022-06-11 17:41:39.255840
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass

# Generated at 2022-06-11 17:41:47.445657
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    def event_handler(arg1, arg2):
        nonlocal last_arg1
        nonlocal last_arg2
        last_arg1 = arg1
        last_arg2 = arg2

    last_arg1 = None
    last_arg2 = None

    arg1 = 'arg1'
    arg2 = 'arg2'

    event_source += event_handler
    event_source.fire(arg1, arg2=arg2)

    assert event_source._handlers == set([event_handler])
    assert last_arg1 == arg1
    assert last_arg2 == arg2

    event_source -= event_handler
    assert event_source._handlers == set()

# Generated at 2022-06-11 17:41:55.910725
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """Unit test to make sure method fire in class _EventSource works.

    Raises:
        ValueError on failure
    """
    e = _EventSource()
    assert (e._handlers) == set()
    e += lambda: None
    assert (len(e._handlers)) == 1
    def f():
        return 'foo'
    e += f
    assert (len(e._handlers)) == 2
    assert (e.fire()) == None
    e -= f
    assert (e._handlers) == set([None])
    assert (e.fire()) == None


test__EventSource_fire()

# Generated at 2022-06-11 17:42:00.973410
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        pass

    e = _TestEventSource()

    def _handler(arg1, arg2, **kwargs):
        print(arg1, arg2, kwargs)
        return True

    e += _handler

    e.fire('a', arg2='b', c='c')

# Generated at 2022-06-11 17:42:04.294518
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    x = _EventSource()
    x += lambda *a, **kw: None
    x.fire()

# Generated at 2022-06-11 17:42:13.427587
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import types

    def test_handler():
        pass

    # The exception of type ValueError should be triggered

# Generated at 2022-06-11 17:42:42.455172
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += kw_handler
    event_source += kw_handler
    assert kw_handler in event_source._handlers
    assert event_source._handlers == set((kw_handler,))



# Generated at 2022-06-11 17:42:47.725928
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    result = ''

    event += (lambda *a, **kwargs: None)
    event += (lambda *a, **kwargs: None)
    event += (lambda *a, **kwargs: None)

    try:
        event -= (lambda *a, **kwargs: None)
    except ValueError:
        pass

    event.fire()



# Generated at 2022-06-11 17:42:53.161861
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(*args):
        pass

    source = _EventSource()

    source += handler

    try:
        source.fire()
    except ValueError:
        raise AssertionError('_EventSource().fire() raised ValueError unexpectedly!')
    except:
        raise AssertionError('_EventSource().fire() raised an unexpected exception!')


# Generated at 2022-06-11 17:42:55.098243
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += 'not a callable'
    raise AssertionError('__iadd__ did not raise ValueError')



# Generated at 2022-06-11 17:43:03.684939
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(s):
        return handler1.result

    def handler2(s):
        return handler2.result

    def handler3(s):
        return handler3.result

    handler1.result = 'result1'
    handler2.result = 'result2'
    handler3.result = 'result3'

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    results = [r for r in event_source.fire('a string')]
    assert len(results) == 3
    assert results[0] == 'result1'
    assert results[1] == 'result2'
    assert results[2] == 'result3'



# Generated at 2022-06-11 17:43:15.059724
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Tester:
        def __init__(self):
            self.count = 0

        def handler1(self):
            self.count += 1

        def handler2(self, *args, **kwargs):
            self.count += args[0]

    test_obj = Tester()

    es = _EventSource()

    # handler1 is registered with the event source
    es += test_obj.handler1

    # handler1 is called
    es.fire()

    # count should be 1
    assert test_obj.count == 1

    # handler2 is registered with the event source
    es += test_obj.handler2

    # handler1 and handler2 are called
    es.fire(3)

    # count should be 4
    assert test_obj.count == 4

# Generated at 2022-06-11 17:43:24.237257
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()

    def f1(arg1, arg2):
        pass

    def f2(arg1, arg2):
        pass

    def g1(arg1, arg2):
        raise RuntimeError()

    def g2(arg1, arg2):
        raise RuntimeError()

    e += f1
    e += f2
    e += g1
    e += g2

    try:
        e.fire(1, 2)
    except RuntimeError:
        assert False

    e -= g2
    e -= g1
    try:
        e.fire(1, 2)
    except RuntimeError:
        assert False

    e -= f2
    e -= f1
    try:
        e.fire(1, 2)
    except RuntimeError:
        assert False

# Generated at 2022-06-11 17:43:26.945778
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    events = _EventSource()

    def test_handler(msg):
        return msg

    events += test_handler



# Generated at 2022-06-11 17:43:35.189521
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        pass

    event_source = _EventSource()

    event_source += handler1
    event_source += handler2
    event_source += handler3
    event_source += handler2
    event_source += handler1

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers
    assert handler3 in event_source._handlers


# Generated at 2022-06-11 17:43:48.079370
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestClass:
        def __init__(self, value):
            self.value = value

    def handler_a(i, tc):
        assert i == 42
        assert isinstance(tc, TestClass)
        cls.num_fired += 1

    def handler_b(i, tc):
        assert i == 42
        assert isinstance(tc, TestClass)
        cls.num_fired += 1

    cls = _EventSource()

    cls.num_fired = 0
    cls += handler_a
    cls.fire(42, TestClass(42))
    assert cls.num_fired == 1

    cls.num_fired = 0
    cls += handler_b
    cls.fire(42, TestClass(42))
    assert cls.num_fired == 2