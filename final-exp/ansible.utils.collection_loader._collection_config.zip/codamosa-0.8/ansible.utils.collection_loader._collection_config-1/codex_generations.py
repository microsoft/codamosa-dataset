

# Generated at 2022-06-11 17:34:33.320598
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Tests with valid handler.
    event = _EventSource()
    assert len(event._handlers) == 0
    event += lambda x: x
    assert len(event._handlers) == 1

    # Tests with not callable handler.
    event = _EventSource()
    exception_raised = False
    try:
        event += 'not callable'
    except ValueError:
        exception_raised = True
    assert exception_raised



# Generated at 2022-06-11 17:34:39.381395
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler1 = lambda *args, **kwargs: None
    handler2 = lambda *args, **kwargs: None

    event_source += handler1
    assert(handler1 in event_source._handlers)

    assert(handler2 not in event_source._handlers)
    event_source += handler2
    assert(handler2 in event_source._handlers)

    with pytest.raises(ValueError):
        event_source += 'not callable'



# Generated at 2022-06-11 17:34:44.709683
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        eventsource = _EventSource()

        def handler0(*args, **kwargs):
            pass

        def handler1(*args, **kwargs):
            pass

        eventsource += handler0
        eventsource += handler1

        eventsource.fire()

        eventsource -= handler0

        eventsource.fire()

    except Exception as error:
        assert False, "test__EventSource_fire() exception '{0}'".format(error)



# Generated at 2022-06-11 17:34:47.690229
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    found = []

    def on_load(collection):
        found.append(collection)
        pass

    event_source = _EventSource()
    event_source += on_load

    event_source.fire('my_col')

    assert len(found) == 1
    assert found[0] == 'my_col'

# Generated at 2022-06-11 17:34:56.130455
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handle1(a, b, c):
        pass

    def handle2(a, b, c):
        pass

    def handle3(a, b, c):
        raise ValueError('test_exception')

    ev = _EventSource()

    ev += handle1
    ev += handle2
    ev.fire(1, 2, 3)

    ev += handle3
    try:
        ev.fire(1, 2, 3)
        assert False, 'fire did not raise an exception when it should have'
    except ValueError as ex:
        assert str(ex) == 'test_exception', 'fire did not raise the correct exception'
    except Exception as ex:
        assert False, 'fire raised the wrong exception'

    ev -= handle1

# Generated at 2022-06-11 17:35:06.157734
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == dict(a=1, b=2)

    def handler2(*args, **kwargs):
        handler2._args = args
        handler2._kwargs = kwargs
        handler2._called = True

    def handler3(*args, **kwargs):
        raise RuntimeError('handler3 exception')

    e = _EventSource()
    e += handler1
    e += handler2
    e += handler3

    e.fire(1, 2, a=1, b=2)
    assert handler2._args == (1, 2)
    assert handler2._kwargs == dict(a=1, b=2)
    assert handler2._called is True



# Generated at 2022-06-11 17:35:10.140260
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    def func_one(*args, **kwargs):
        print(args, kwargs)
    def func_two(*args, **kwargs):
        print(args, kwargs)
    event_source += func_one
    event_source += func_two
    event_source.fire('one', 'two', three=3, four=4)

# Generated at 2022-06-11 17:35:21.687552
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Given an event source
    ev = _EventSource()

    # And a list of handlers
    hs = list()

    # When there are no handlers
    # Then none are called
    ev.fire()

    # When the handlers raise no exceptions
    # Then the handlers are called
    hs.append(lambda: None)
    ev += hs[-1]
    ev.fire()

    # When the handlers raise exceptions
    # Then the exceptions are re-raised to the caller
    hs.append(lambda: raise_exception(1))
    ev += hs[-1]
    try:
        ev.fire()
    except MyException as ex:
        assert ex.value is 1

    # When we handle a specific exception
    # Then the exception is caught

# Generated at 2022-06-11 17:35:31.774292
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import mock

    def f1():
        f1.called = True

    def f2():
        f2.called = True

    es = _EventSource()
    es += f1
    es += f2

    f1.called = False
    f2.called = False

    es.fire()

    assert f1.called is True
    assert f2.called is True

    f1.called = False
    f2.called = False

    es -= f1

    es.fire()

    assert f1.called is False
    assert f2.called is True

    f1.called = False
    f2.called = False

    class CustomException(Exception):
        pass

    def f3():
        f3.called = True
        raise CustomException


# Generated at 2022-06-11 17:35:35.693405
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    def handler(number, name):
        print(number)
        print(name)

    event += handler
    try:
        event.fire(1, name="joy")
    except:
        pass

# Generated at 2022-06-11 17:35:53.239423
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    class Base(metaclass=_AnsibleCollectionConfig):
        pass

    class Foo(Base):
        pass

    class Bar(Base):
        pass

    assert Foo.collection_finder is None
    assert Bar.collection_finder is None

    # test the exception conditions
    err_msg = 'handler must be callable'
    try:
        Foo.on_collection_load += 5
    except ValueError as ex:
        assert str(ex) == err_msg
    except Exception as ex:
        assert False, "Unexpected exception raised: %s" % ex

    try:
        Foo.on_collection_load += Foo
    except ValueError as ex:
        assert str(ex) == err_msg

# Generated at 2022-06-11 17:36:00.517265
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.counter = 0

        def handler(self):
            self.counter += 1

    event_source = _TestEventSource()

    assert event_source.counter == 0

    event_source += event_source.handler
    event_source.fire()

    assert event_source.counter == 1

    event_source -= event_source.handler
    event_source.fire()

    assert event_source.counter == 1

    # cannot overwrite the event source handler

# Generated at 2022-06-11 17:36:11.644202
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # create the event source
    events = _EventSource()

    # configure callbacks
    callbacks = []
    raise_exception = False

    def callback(ctx):
        callbacks.append(ctx)
        if raise_exception:
            raise RuntimeError('Exception is raised by second callback')

    events += callback
    events += callback

    # fire the event
    events.fire('test')
    assert len(callbacks) == 2
    assert callbacks[0] == 'test'
    assert callbacks[1] == 'test'

    # reset callbacks
    callbacks = []

    # fire the event, the second callback raises exception
    raise_exception = True
    try:
        events.fire('test')
    except RuntimeError as e:
        assert str(e) == 'Exception is raised by second callback'

   

# Generated at 2022-06-11 17:36:18.108230
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            raise RuntimeError('should not have fired')

    # This should not fail
    es = _TestEventSource()
    es += 1
    es += lambda: None

    # This should fail
    try:
        es += None
        raise AssertionError('should have failed')
    except ValueError:
        pass



# Generated at 2022-06-11 17:36:22.225322
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    src = TestSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise RuntimeError

    def handler3(*args, **kwargs):
        pass

    src += handler1
    src += handler2
    src += handler3

    # we should not throw on event 2
    src.fire()

    src.__isub__(handler2)
    src.__isub__(handler2)

    # we should not throw on event 2
    src.fire()

# Generated at 2022-06-11 17:36:32.272773
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # when
    source = _EventSource()
    source += _event_handler_1
    source += _event_handler_2
    source += _event_handler_3

    # given
    args = dict(a=1, b=2, c=3)

    # when
    source.fire(**args)

    # then
    assert _event_handler_1.call_count == 1
    assert _event_handler_1.call_args.kwargs == args
    assert _event_handler_2.call_count == 1
    assert _event_handler_2.call_args.kwargs == args
    assert _event_handler_3.call_count == 1
    assert _event_handler_3.call_args.kwargs == args



# Generated at 2022-06-11 17:36:41.428765
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(x):
        if x not in (1, 2):
            raise ValueError('invalid value')

    def handler_exception(x):
        raise RuntimeError('stop')

    counter = {'c': 0}

    def handler_counter(x):
        counter['c'] += 1

    source = _EventSource()
    source += handler
    source.fire(1)
    source += handler_exception
    try:
        source.fire(2)
    except RuntimeError:
        # correct
        pass
    else:
        raise ValueError('Exception failed to propagate')

    source -= handler_exception
    source += handler_counter
    source.fire(3)  # handler_counter is called but its exception is not propagated
    assert counter['c'] == 1



# Generated at 2022-06-11 17:36:45.232737
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Run code to be tested
    et = _EventSource()
    def event_handler(ev_data):
        pass
    et += event_handler
    # Check results
    assert et._handlers == {event_handler}


# Generated at 2022-06-11 17:36:48.666516
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handle(value):
        raise NotImplementedError

    handle(3)

    es += handle

    assert handle in es._handlers



# Generated at 2022-06-11 17:36:55.407803
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # pylint: disable=protected-access

    # 1. called without handlers
    source = _EventSource()
    source.fire()

    # 2. called with 1 handler that raises an exception
    def bar(a, b, c=None):
        raise Exception('bar')

    source = _EventSource()
    source += bar
    try:
        source.fire(0, 1, 2)
        # pylint: disable=unreachable
        assert False
    except Exception as ex:
        assert ex.args == ('bar',)

    # 3. called with 1 handler that raises an exception and a handler that returns true
    def foo(a, b, c=None):
        return True

    source = _EventSource()
    source += bar
    source += foo

# Generated at 2022-06-11 17:37:17.268289
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MySource(object):

        def __init__(self):
            self.events = [0, 0, 0]

        def handler1(self, *args, **kwargs):
            self.events[0] += 1

        def handler2(self, *args, **kwargs):
            self.events[1] += 1

        def handler3(self, *args, **kwargs):
            self.events[2] += 1
            raise Exception('this is handled')

    m = MySource()
    e = _EventSource()
    e += m.handler1
    e += m.handler2
    e += m.handler3

    e.fire()
    assert m.events == [1, 1, 1]

# Generated at 2022-06-11 17:37:28.395472
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class on_exception_count(object):
        count = 0
        def __call__(self, *args, **kwargs):
            self.count += 1
            super(on_exception_count, self).__call__(*args, **kwargs)

    evt_src = _EventSource()

    # Make sure that no exception is raised if the event source is empty
    evt_src.fire()

    # Fire 2 functions with the event source. One function should raise an exception.
    # This should not derail the second function being called.
    # The on_exception handler should have been called once.
    on_exception_handler = on_exception_count()
    evt_src._on_exception = on_exception_handler
    def foo():
        return None

    evt_src += foo

# Generated at 2022-06-11 17:37:33.541830
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    class Process:
        def __init__(self):
            self.exitcode = None

        def mock_call(self, value):
            self.exitcode = value
            if value == 1:
                raise OSError('Test Error')

    event_source = _EventSource()
    process = Process()

    # Act
    event_source += lambda value: process.mock_call(0)
    event_source += lambda value: process.mock_call(1)
    event_source += lambda value: process.mock_call(2)

    event_source.fire(0)

    # Assert
    assert process.exitcode == 2

# Generated at 2022-06-11 17:37:44.348904
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest
    from ansible.module_utils.common.collection_loader._an_sible_collection_config import _EventSource
    import sys

    class Event(_EventSource):
        pass

    event = Event()

    def handler1(*args, **kwargs):
        event_args.append(args)
        event_kwargs.append(kwargs)

    def handler2(*args, **kwargs):
        handler_exception.append(True)
        return False

    def handler3(*args, **kwargs):
        handler_exception.append(True)
        return True

    def handler4(*args, **kwargs):
        pass

    event_args = []
    event_kwargs = []
    handler_exception = []

    event += handler1
    event += handler2
    event += handler3
   

# Generated at 2022-06-11 17:37:52.967520
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _SomeCallable:
        def __init__(self, f):
            self._f = f

        def __call__(self, *args, **kwargs):
            self._f(*args, **kwargs)

    class _Err(Exception):
        pass

    called = []
    es = _EventSource()

    def c1(*args, **kwargs):
        called.append('c1')

    def c2(*args, **kwargs):
        called.append('c2')
        raise _Err('expected')

    es += c1
    es += _SomeCallable(c2)
    es += c1

    try:
        es.fire()
    except _Err as e:
        assert 'expected' in to_text(e)

# Generated at 2022-06-11 17:38:00.311136
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # arrange
    event_source = _EventSource()
    handler_count = 0
    handler_args = []

    def handler1(*args, **kwargs):
        nonlocal handler_count
        handler_count += 1
        handler_args.append(args)
        handler_args.append(kwargs)

    def handler2(*args, **kwargs):
        nonlocal handler_count
        handler_count += 5
        handler_args.append(args)
        handler_args.append(kwargs)

    # act
    event_source += handler1
    event_source += handler2

    event_source.fire(1, kwarg=2)

    # assert
    assert handler_count == 6
    assert handler_args[0][0] == 1
    assert handler_args[0][1] == 2

    assert handler

# Generated at 2022-06-11 17:38:12.167888
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    args_1 = (1, 2, 3)
    args_2 = (4, 5, 6)
    kwargs_1 = {'a': 1, 'b': 2, 'c': 3}
    kwargs_2 = {'d': 4, 'e': 5, 'f': 6}

    def handler_1(*args, **kwargs):
        assert args_1 == args
        assert kwargs_1 == kwargs

    def handler_2(*args, **kwargs):
        assert args_2 == args
        assert kwargs_2 == kwargs

    def handler_3(*args, **kwargs):
        assert args_1 == args
        assert kwargs_1 == kwargs
        assert args_2 == args
        assert kwargs_2 == kwargs

    ts = _EventSource

# Generated at 2022-06-11 17:38:23.280243
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import iteritems

    def handler(name, *args, **kwargs):
        print('handler: name=%s args=%s kwargs=%s' % (repr(name), repr(args), repr(kwargs)))

    eventSource = _EventSource()
    eventSource += handler
    eventSource.fire('collection is loaded', name='ansible_collections.my.my_collection', display_path='/path/to/ansible_collections/my/my_collection')

    class PlayContextSubClass(PlayContext):
        pass

    playContextSubClass = PlayContextSubClass()


# Generated at 2022-06-11 17:38:33.050213
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup: EventSource object
    event_source = _EventSource()

    # Setup: Handler to be called
    def handler(fired_arg, kwarg1=None):
        assert fired_arg == arg
        assert kwarg1 == kwarg

    arg = object()
    kwarg = object()

    # Setup: Add handler to be called
    event_source += handler

    # Exercise: Fire event, handler should be called
    event_source.fire(arg, kwarg1=kwarg)

    # Exercise: Remove handler and fire event again
    event_source -= handler
    event_source.fire(arg, kwarg1=kwarg)



# Generated at 2022-06-11 17:38:45.650594
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    assert not s._handlers

    # add an item
    s += lambda: None
    assert s._handlers
    assert len(s._handlers) == 1
    assert callable(s._handlers.pop())

    # add the same item again
    s += lambda: None
    assert s._handlers
    assert len(s._handlers) == 1
    assert callable(s._handlers.pop())

    # add another item
    s += lambda: None
    assert s._handlers
    assert len(s._handlers) == 1
    assert callable(s._handlers.pop())

    # add a non-callable item
    try:
        s += None
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')




# Generated at 2022-06-11 17:39:22.246100
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Counter:
        def __init__(self, value):
            self.value = value

        def __call__(self):
            self.value += 1
    counter = _Counter(0)

    class _EventSource:
        def __init__(self):
            self._on_collection_load += counter

        def __iadd__(self, handler):
            if not callable(handler):
                raise ValueError('handler must be callable')
            self._handlers.add(handler)
            return self

        def __isub__(self, handler):
            try:
                self._handlers.remove(handler)
            except KeyError:
                pass

            return self


# Generated at 2022-06-11 17:39:31.126612
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.test_arg = None
            self.test_kwarg = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            # do not re-raise
            return False

    class MyException(Exception):
        pass

    handler_called = False
    handler_exception = None

    def handler(*args, **kwargs):
        nonlocal handler_called
        nonlocal handler_exception

        handler_called = True

        try:
            if args and args[0]:
                raise MyException(args[0])
        except MyException as ex:
            # Inject the exception captured in the handler into the method fire
            raise ex

    event_source

# Generated at 2022-06-11 17:39:34.481398
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fail_count = 0
    fail_count += test__EventSource_fire_exception_handler()
    if fail_count:
        raise Exception('%d tests failed' % (fail_count))


# Generated at 2022-06-11 17:39:42.573639
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # case 1: no exceptions
    counter = 0
    def inc_1(i):
        global counter
        counter += i

    ev = _EventSource()
    ev += inc_1
    ev.fire(5)
    assert counter == 5

    # case 2: one exception
    counter = 0
    def inc_2(i):
        global counter
        counter += i
        raise RuntimeError()

    ev = _EventSource()
    ev += inc_1
    ev += inc_2
    ev.fire(5)
    assert counter == 5

    # case 3: one exception with throw
    counter = 0
    def inc_3(i):
        global counter
        counter += i
        raise RuntimeError()

    def on_exception(handler, exc, *args, **kwargs):
        return True

    ev = _

# Generated at 2022-06-11 17:39:44.962465
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # The method is tested by use in the class AnsibleCollectionConfig, which uses += to add
    # event handlers onto the _EventSource.
    pass


# Generated at 2022-06-11 17:39:55.261216
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def handler_who_throws(*args, **kwargs):
        raise RuntimeError('handler_who_throws called')

    def handler_who_re_raises_exception(*args, **kwargs):
        raise RuntimeError('handler_who_re_raises_exception called')

    def handler_who_returns_false(*args, **kwargs):
        raise RuntimeError('handler_who_returns_false called')
        return False

    def handler_who_returns_true(*args, **kwargs):
        raise RuntimeError('handler_who_returns_true called')
        return True

    event.fire()

    event += handler_who_throws

# Generated at 2022-06-11 17:40:01.155544
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(x, y):
        pass

    def handler2(x, y, z):
        pass

    def handler3(x, y, z, a, b=42, c=42):
        pass

    def handler4():
        pass

    event_source = _EventSource()

    event_source += handler1
    event_source += handler2
    event_source += handler3
    event_source += handler4

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers
    assert handler3 in event_source._handlers
    assert handler4 in event_source._handlers

# Generated at 2022-06-11 17:40:03.209616
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()
    eventsource += lambda: None
    eventsource.fire()

# Generated at 2022-06-11 17:40:08.014964
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    tracker = []

    def test_func(a, b):
        tracker.append((a, b))

    event_source = _EventSource()
    event_source += test_func

    event_source.fire(1, 2)
    assert tracker == [(1, 2)]

    event_source.fire(3, 4)
    assert tracker == [(1, 2), (3, 4)]



# Generated at 2022-06-11 17:40:19.892515
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test_EventSource(_EventSource):
        def __init__(self):
            super(Test_EventSource, self).__init__()
            self.handler_ex_call_counter = 0
            self.handler_ex_args = None
            self.handler_ex_kwargs = None
            self.handler_ex_ex = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.handler_ex_call_counter += 1
            self.handler_ex_args = args
            self.handler_ex_kwargs = kwargs
            self.handler_ex_ex = exc

        def handler_no_exception(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 17:40:53.087772
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        raise Exception()

    def handler2(*args, **kwargs):
        raise Exception()

    es = _EventSource()
    es += handler1
    es += handler2

    try:
        es.fire()
        raise AssertionError('Expected last exception not raised')
    except Exception:
        pass

    def handler3(*args, **kwargs):
        raise Exception()

    def handler4(*args, **kwargs):
        raise Exception()

    es = _EventSource()
    es += handler3
    es += handler4
    es._on_exception = lambda handler, exc, *args, **kwargs: False

    try:
        es.fire()
    except Exception:
        raise AssertionError('Expected no exception to be raised')



# Generated at 2022-06-11 17:41:00.814467
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def func_a(*args, **kwargs):
        pass

    def func_b(*args, **kwargs):
        pass

    def func_c(*args, **kwargs):
        raise RuntimeError('this is a test exception')

    ev = _EventSource()
    ev += func_a
    ev += func_b
    ev += func_c
    ev += func_a
    ev += func_b
    ev += func_c

    ev.fire()

    ev -= func_a
    ev.fire()

    ev -= func_c
    ev.fire()

# Generated at 2022-06-11 17:41:05.329547
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    count = [0]
    def handler():
        count[0] += 1

    event += handler
    event += handler
    event.fire()
    assert count[0] == 1



# Generated at 2022-06-11 17:41:13.374036
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    # raises exception when handler is not callable
    with pytest.raises(ValueError):
        event += None

    event += lambda *args, **kwargs: None

    # event successfully fires without exception
    event.fire()

    failure_handler = Mock(return_value=False)
    event += failure_handler

    # event successfully fires with exceptions and handler swallowing exception
    event.fire()

    reraise_handler = Mock(return_value=True)
    event += reraise_handler

    # event raises exception even though handler is swallowing exception
    with pytest.raises(Exception):
        event.fire()


# Generated at 2022-06-11 17:41:22.643409
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    '''This is a unit test for the method fire of class _EventSource.'''

    import sys

    def _on_exception(handler, exc, *args, **kwargs):
        print('TEST FAILURE: on_exception handler was called unexpectedly with exc=%s' % str(exc))
        sys.exit(1)

    # create source
    source = _EventSource()

    # add handlers
    source += lambda: print('handler 1')
    source += lambda: print('handler 2')
    source += lambda: 1 / 0

    # set exception handler
    source._on_exception = _on_exception

    # install comparable reference implementation

# Generated at 2022-06-11 17:41:33.753273
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self.counter = 0

        def inc(self, amount):
            self.counter += amount

        def inc_by_two(self, amount):
            self.counter += amount * 2

        def raise_exception(self, amount):
            raise Exception(to_text(amount))
    test_source = _EventSourceTest()
    test_event = _EventSource()

    test_event += test_source.inc
    test_event.fire(10)
    assert test_source.counter == 10

    test_event += test_source.inc_by_two
    test_event.fire(10)
    assert test_source.counter == 30

    test_event -= test_source.inc
    test_event.fire(10)
    assert test_

# Generated at 2022-06-11 17:41:38.420755
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    r = []
    s = _EventSource()

    def handler_one(arg1, arg2):
        r.append((1, arg1, arg2))

    def handler_two(arg1, arg2):
        r.append((2, arg1, arg2))

    s += handler_one
    s += handler_two

    s.fire(1, 2)

    assert r == [(1, 1, 2), (2, 1, 2)]



# Generated at 2022-06-11 17:41:42.625876
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Expect: ValueError if value not callable
    es = _EventSource()
    with pytest.raises(ValueError):
        es += 'nothing'

# Unit tests for method fire of class _EventSource

# Generated at 2022-06-11 17:41:46.450808
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _EventSource___iadd__ = _EventSource.__iadd__

    class E(_EventSource):
        def __iadd__(self, handler):
            return _EventSource___iadd__(self, handler)

    e = E()
    f = lambda: None
    e += f
    assert f in e._handlers



# Generated at 2022-06-11 17:41:46.950633
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass

# Generated at 2022-06-11 17:42:41.996455
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def fire_handler(event, handler, event_source):
        event.fire()

    event_source = _EventSource()
    event_source += fire_handler
    event_source('', event_source)

# Generated at 2022-06-11 17:42:48.010364
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():  # This function is never called; it is tested using ansible-test
    def test():
        pass

    es = _EventSource()
    assert len(es._handlers) == 0
    try:
        es += 'foo'
        assert False, 'Expected ValueError when attempting to add non-callable'
    except ValueError:
        pass
    assert len(es._handlers) == 0
    es += test
    assert len(es._handlers) == 1



# Generated at 2022-06-11 17:42:53.073077
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1():
        pass

    def handler2():
        pass

    a = _EventSource()
    assert not a._handlers

    a += handler1
    assert a._handlers == set([handler1])

    a += handler2
    assert a._handlers == set([handler1, handler2])



# Generated at 2022-06-11 17:42:55.984655
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise Exception('test')

    source = _EventSource()

    source += handler1
    source += handler2

    source.fire()

# Generated at 2022-06-11 17:43:01.748716
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    my_source = _EventSource()
    my_source += lambda x: print('Argument: %s' % x)
    my_source += lambda x: print('Argument: %s' % x)
    my_source.fire('one')
    my_source.fire('two')
    my_source.fire('three')
    #my_source = _EventSource()
    #my_source += lambda x: x
    #my_source.fire(None)


# Generated at 2022-06-11 17:43:11.971512
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    cls = AnsibleCollectionConfig
    # Start with no handlers
    assert 0 == len(cls._on_collection_load._handlers)

    # Fire an event, no exception expected
    cls._on_collection_load.fire()

    # Add a handler, then fire another event, expect no exception
    def handler1(arg):
        assert arg == 'one'

    cls._on_collection_load += handler1
    cls._on_collection_load.fire('one')

    # Add a second handler, then fire another event, expect no exception
    def handler2(arg):
        assert arg == 'two'

    cls._on_collection_load += handler2
    cls._on_collection_load.fir

# Generated at 2022-06-11 17:43:21.873692
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def foo():
        foo.called = True

    def bar():
        bar.called = True
        raise RuntimeError('testing')

    def baz():
        baz.called = True
        raise ValueError('testing')

    ansible_collections_config = AnsibleCollectionConfig()
    ansible_collections_config.on_collection_load += foo
    ansible_collections_config.on_collection_load += bar
    ansible_collections_config.on_collection_load += baz

    foo.called = False
    bar.called = False
    baz.called = False
    ansible_collections_config.on_collection_load.fire()
    assert foo.called
    assert bar.called
    assert not baz.called

# Generated at 2022-06-11 17:43:25.599394
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(_, a, kw=None):
        return a, kw

    event_source = _EventSource()
    assert id(event_source) == id(event_source)



# Generated at 2022-06-11 17:43:36.450272
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _MockEventSource(_EventSource):
        def __init__(self, *args, **kwargs):
            super(_MockEventSource, self).__init__(*args, **kwargs)
            self.exceptions = []

        def _on_exception(self, exc, *args, **kwargs):
            self.exceptions.append(exc)
            return False

    es = _MockEventSource()

    def func1(i, j):
        return i + j

    def func2(i, j):
        return i - j
        # raise RuntimeError('foo')

    def func3(i, j):
        raise RuntimeError('bar')
        # return i * j
        # return i / j

    es += func1
    es += func2
    es += func3


# Generated at 2022-06-11 17:43:37.907180
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source.fire()