

# Generated at 2022-06-11 17:34:38.049363
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    def handler_a(*args, **kwargs):
        es.a_called = True

    def handler_b(*args, **kwargs):
        es.b_called = True
        raise ValueError('this is a test exception')

    def handler_c(*args, **kwargs):
        es.c_called = True
        raise RuntimeError('this is a test exception')

    es.a_called = False
    es.b_called = False
    es.c_called = False

    es += handler_a
    es += handler_b
    es += handler_c

    es.fire()
    assert es.a_called and es.b_called and es.c_called

# Generated at 2022-06-11 17:34:46.525823
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class Handler(list):
        def __call__(self, *args, **kwargs):
            self.append((args, kwargs))

        def raise_(self, exception_type):
            raise exception_type

    event = _EventSource()
    handler1 = Handler()
    handler2 = Handler()

    event += handler1
    event += handler2

    event.fire('one', two='two')
    assert handler1 == [((('one',), {'two': 'two'}),)]
    assert handler2 == [((('one',), {'two': 'two'}),)]

    handler1.raise_(TestException)
    try:
        event.fire('three', four='four')
        assert False, 'Failed to raise exception'
    except TestException:
        pass

# Generated at 2022-06-11 17:34:49.202871
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def foo(event, stuff):
        return "'{}' '{}'".format(event, stuff)

    e = _EventSource()
    e += foo

    assert e.fire('zombo', 'com') == "'zombo' 'com'"


# Generated at 2022-06-11 17:34:53.174616
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def a():
        global result
        result = True

    def b():
        global result
        raise Exception()

    event_source += a
    event_source += b
    event_source.fire()
    assert result is None

# Generated at 2022-06-11 17:34:55.151715
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1
    event_source.fire()


# Generated at 2022-06-11 17:35:05.638012
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.text.converters import to_bytes
    import collections

    events = []

    def handler1(a):
        events.append(a)

    def handler2(a):
        events.append(to_bytes(a, encoding='utf-8').upper())

    def handler3(a):
        events.append(to_text(a, encoding='utf-8'))

    def handler4(a):
        events.append(to_text(a).replace('-', '+'))

    es = _EventSource()
    es += handler1
    es += handler2
    es += handler3
    es += handler4

    es.fire('hello-world')
    assert events == ['hello-world', u'HELLO-WORLD', 'hello-world', 'hello+world']

# Generated at 2022-06-11 17:35:12.266390
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyException(Exception):
        pass

    # Verify that an exception thrown from a handler is not caught
    es = _EventSource()
    es.fire()

    captured_exceptions = []

    def handler1():
        raise MyException()

    es += handler1

    with pytest.raises(MyException):
        es.fire()

    # Verify that an exception thrown from a handler is not caught
    es = _EventSource()
    es.fire()

    captured_exceptions = []

    def handler1(ex):
        captured_exceptions.append(ex)

    es.on_exception = handler1

    with pytest.raises(MyException):
        es.fire()

    assert captured_exceptions == [MyException]

# Generated at 2022-06-11 17:35:22.987406
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            assert handler == h3
            assert exc.args == (1, 2, 3)
            assert args == (4, 5, 6)
            assert kwargs == {'a': 7, 'b': 8}
            return False

    v1 = []
    v2 = []
    v3 = []

    def h1(*args, **kwargs):
        v1.extend([args, kwargs])

    def h2(*args, **kwargs):
        v2.extend([args, kwargs])

    def h3(*args, **kwargs):
        v3.extend([args, kwargs])
        raise ValueError(1, 2, 3)

    es = My

# Generated at 2022-06-11 17:35:32.794855
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def foo():
        raise NotImplementedError('foo')

    def bar():
        raise NotImplementedError('bar')

    def baz():
        raise NotImplementedError('baz')

    def norf(fun, exc):
        return True

    src = _EventSource()
    src += foo
    src += bar
    src += baz

    try:
        src.fire()
    except NotImplementedError as ex:
        if ex.args != ('foo',):
            return '1'

    src._on_exception = norf
    try:
        src.fire()
    except NotImplementedError as ex:
        if ex.args != ('foo',):
            return '2'

    src -= foo

# Generated at 2022-06-11 17:35:39.128744
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()
    def a(*args, **kwargs):
        print('a called with %s %s' % (args, kwargs))
    def b(*args, **kwargs):
        print('b called with %s %s' % (args, kwargs))
    def c(*args, **kwargs):
        print('c called with %s %s' % (args, kwargs))

    s += a
    s += b
    s += c

    s.fire('foo', 'bar')


if __name__ == '__main__':
    test__EventSource_fire()

# Generated at 2022-06-11 17:35:55.146629
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()

    calls = []

    def h1(*args, **kwargs):
        calls.append(('h1', args, kwargs))

    def h2(*args, **kwargs):
        calls.append(('h2', args, kwargs))

    e += h1
    e += h2

    e.fire(1, 2, 3)
    e.fire(4, 5, 6)

    assert calls == [
        ('h1', (1, 2, 3), {}),
        ('h2', (1, 2, 3), {}),
        ('h1', (4, 5, 6), {}),
        ('h2', (4, 5, 6), {}),
    ]

# Generated at 2022-06-11 17:36:06.310888
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    def handler1(a, b, c=5):
        res.append(a)
        res.append(b)
        res.append(c)

    def handler2(a, b, c=5):
        res.append(a)
        res.append(b)
        res.append(c)

    res = []
    event = _EventSource()
    event += handler1
    event += handler2
    event.fire(1, 2)
    assert res == [1, 2, 5, 1, 2, 5]

    res = []
    event -= handler1
    event.fire(1, 2)
    assert res == [1, 2, 5]

    res = []
    event -= handler1
    event.fire(1, 2)
    assert res == [1, 2, 5]

# Generated at 2022-06-11 17:36:16.130390
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exception_raised = exc
            return True

    e = _TestEventSource()

    def handler1(*args, **kwargs):
        pass
    e += handler1

    def handler2(*args, **kwargs):
        pass
    e += handler2

    def handler3(*args, **kwargs):
        pass
    e += handler3

    e.fire(1, 2, 3)

    try:
        def handler1(*args, **kwargs):
            raise Exception()
        e.fire(1, 2, 3)
        assert False
    except Exception as e:
        assert e is e._exception_raised


# Generated at 2022-06-11 17:36:23.294827
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Source1(object):
        def h1(self, *args, **kwargs):
            pass

        def h2(self, *args, **kwargs):
            raise ValueError('my exception')

    s = _EventSource()
    s += Source1().h1
    s += Source1().h2

    try:
        s.fire()
        assert False  # should not get here
    except ValueError:
        assert True



# Generated at 2022-06-11 17:36:33.092856
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    called = [0]
    def handler1(arg1, arg2):
        assert arg1 == 123
        assert arg2 == 'xyz'
        called[0] += 1

    def handler2(arg1, arg2):
        assert arg1 == 123
        assert arg2 == 'xyz'
        called[0] += 1

    def handler3(arg1, arg2):
        assert arg1 == 123
        assert arg2 == 'xyz'
        called[0] += 1

    source = _EventSource()
    source += handler1
    source.fire(123, arg2='xyz')
    assert called[0] == 1

    source += handler2
    source.fire(123, arg2='xyz')
    assert called[0] == 3

    source += handler3

# Generated at 2022-06-11 17:36:41.796135
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _MyEvent(Exception):
        pass

    class _MyHandler(object):
        def __init__(self, exception_class):
            self._exception_class = exception_class

        def __call__(self, *args, **kwargs):
            raise self._exception_class()

    class _MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            if isinstance(exc, handler._exception_class) and len(self._handlers) > 1:
                return False
            return True

    m = _MyEventSource()
    h1 = _MyHandler(_MyEvent)
    h2 = _MyHandler(_MyEvent)
    m += h1
    m += h2

    assert len(m._handlers) == 2


# Generated at 2022-06-11 17:36:52.119038
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    # verify that we raise for non-callable objects
    for x in (None, 1, [], object()):
        try:
            event_source.__iadd__(x)
        except ValueError:
            pass
        else:
            assert False, '__iadd__ should have raised'
    # verify that we accept callable objects
    def handler():
        pass
    assert len(event_source._handlers) == 0
    event_source.__iadd__(handler)
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers
    # verify that we don't raise if we add an already added handler
    event_source.__iadd__(handler)
    assert len(event_source._handlers) == 1

# Generated at 2022-06-11 17:36:58.220427
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    def foo():
        pass

    assert callable(foo)

    e += foo

    assert foo in e._handlers

    with pytest.raises(ValueError) as error:
        e += 2

    assert error.value.args[0] == 'handler must be callable'



# Generated at 2022-06-11 17:37:00.843787
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_source += lambda x: x + 1
    event_source += lambda x: x + 2
    event_source.fire(10)

# Generated at 2022-06-11 17:37:08.676504
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Tick:
        def __init__(self):
            self.on_tick = _EventSource()

        def tick(self):
            self.on_tick.fire()

    class Ticker:
        def __init__(self):
            self.tick_count = 0

        def tick(self):
            self.tick_count += 1

    tick = Tick()
    ticker = Ticker()

    tick.on_tick += ticker.tick

    tick.tick()
    assert ticker.tick_count == 1

    tick.on_tick -= ticker.tick

    tick.tick()
    assert ticker.tick_count == 1

# Generated at 2022-06-11 17:37:32.492440
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def foo(a):
        return a

    def bar(a, b=None):
        return a + b

    es = _EventSource()
    es += foo
    es += bar

    # validate the fire method with no kwargs
    assert foo(1) == es.fire(1)
    assert bar(1) == es.fire(1)

    # validate the fire method with one kwarg
    assert bar(1, b=2) == es.fire(1, b=2)

    # validate the fire method with multiple kwargs
    assert foo(b=2) == es.fire(b=2)
    assert bar(1, 2) == es.fire(1, 2)
    assert bar(1, b=2) == es.fire(1, b=2)

# Generated at 2022-06-11 17:37:35.024052
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    on_load = _EventSource()
    def handler():
        pass
    on_load += handler
    assert handler in on_load._handlers, 'handler was not added to _handlers'


# Generated at 2022-06-11 17:37:37.650587
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def test_handler_1(*args, **kwargs):
        pass

    a = _EventSource()
    a += test_handler_1

    a.fire()

# Generated at 2022-06-11 17:37:48.683166
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()

    class MyHandler:
        def __init__(self, expected_args, expected_kwargs):
            self.expected_args = expected_args
            self.expected_kwargs = expected_kwargs
            self.on_call = lambda: None
            self.exception = None

        def __call__(self, *args, **kwargs):
            self.on_call(*args, **kwargs)
            if args != self.expected_args:
                raise AssertionError('args %s not equal to expected %s' % (args, self.expected_args))

# Generated at 2022-06-11 17:37:52.658798
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source += set()
    source += len
    source += test__EventSource___iadd__

    with pytest.raises(ValueError):
        source += ''


# Generated at 2022-06-11 17:38:00.161282
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class test_handler:
        def __init__(self, name, exception=None):
            self.name = name
            self.exception = exception
            self.called = False
            self.was_raised = False

        def __call__(self, *args, **kwargs):
            self.called = True
            self.args = args
            self.kwargs = kwargs

            if self.exception:
                self.was_raised = True
                raise self.exception

    class test_event_source(_EventSource):
        def __init__(self):
            super(test_event_source, self).__init__()
            self.exception_calls = []


# Generated at 2022-06-11 17:38:03.702840
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()
    source += print
    assert source._handlers == {print}


# Generated at 2022-06-11 17:38:10.163824
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    evs = _EventSource()

    def handler(x):
        x += 1

    evs += handler
    assert handler in evs._handlers

    # Test invalid handler
    try:
        evs += 1
    except ValueError:
        pass
    else:
        assert False, 'invalid handler type should have been rejected'

    # Test re-adding an already added handler
    evs += handler
    assert handler in evs._handlers



# Generated at 2022-06-11 17:38:19.637521
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyException(Exception):
        pass

    class MyError(Exception):
        pass

    class MySuccess(Exception):
        pass

    def handler1(item):
        raise MyException()

    def handler2(item):
        raise MyError()

    def handler3(item):
        raise MySuccess()

    def error_handler(handler, exc, *args, **kwargs):
        if not isinstance(exc, MyException):
            return False

        if handler == handler1:
            raise MySuccess()

        return True

    source = _EventSource()

    source._on_exception = error_handler
    source += handler1
    source += handler2
    source += handler3

    source.fire('foo')

# Generated at 2022-06-11 17:38:27.517297
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def handler1(arg1, arg2):
        handler1.fired = True
        handler1.arg1 = arg1
        handler1.arg2 = arg2

    def handler2(arg1, arg2):
        handler2.fired = True
        handler2.arg1 = arg1
        handler2.arg2 = arg2

    event += handler1
    event += handler2

    arg1 = 'myarg1'
    arg2 = 'myarg2'
    event.fire(arg1, arg2=arg2)

    assert handler1.fired
    assert handler1.arg1 == arg1
    assert handler1.arg2 == arg2

    assert handler2.fired
    assert handler2.arg1 == arg1
    assert handler2.arg2 == arg2



# Generated at 2022-06-11 17:38:52.966344
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self, on_exception):
            _EventSource.__init__(self)
            self._on_exception = on_exception

    # the event handlers will append to these, rather than mutate them
    args = [None, dict()]
    kwargs = [None, dict()]
    def _handler_one(*arg_list, **kwargs_dict):
        args[0] = arg_list
        kwargs[0] = kwargs_dict

    def _handler_two(*arg_list, **kwargs_dict):
        args[1] = arg_list
        kwargs[1] = kwargs_dict
        raise ValueError('testing')

    sut = _TestEventSource(_on_exception)

# Generated at 2022-06-11 17:39:00.814765
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Event:
        def __init__(self):
            self.num = 0

        def __call__(self, *args, **kwargs):
            self.num += 1

    # basic test of event firing
    a = _Event()
    b = _Event()
    c = _Event()
    es = _EventSource()
    es += a
    es += b
    es += c
    es.fire()
    assert a.num == 1
    assert b.num == 1
    assert c.num == 1

    # base test of event handler removal
    es -= b
    es += b
    es -= b
    es.fire()
    assert a.num == 2
    assert b.num == 1
    assert c.num == 2

# Generated at 2022-06-11 17:39:08.268084
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Successfully add callable handler
    test_event_source = _EventSource()
    def test_handler(*args, **kwargs):
        pass
    test_event_source += test_handler

    # Successfully add callable object
    test_event_source = _EventSource()
    test_event_source += test_handler

    # Raise a ValueError when trying to add non-callable handler
    class TestObject:
        pass

    test_event_source = _EventSource()
    test_object = TestObject()
    with pytest.raises(ValueError):
        test_event_source += test_object



# Generated at 2022-06-11 17:39:12.369079
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0
    assert not callable(es)
    assert callable(es.fire)
    es += lambda x: None
    assert len(es._handlers) == 1


# Generated at 2022-06-11 17:39:16.232106
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    mock_handler = Mock()

    test_event_source = _EventSource()
    test_event_source.__iadd__(mock_handler)

    assert test_event_source._handlers == {mock_handler}



# Generated at 2022-06-11 17:39:26.635233
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def error_callable(*args):
        raise ValueError("Unhandled Callable Error")

    def success_callable(*args):
        pass

    # create an event
    event = _EventSource()

    # add registered callable to the event
    event += success_callable

    # test whether successful execution of callable registered to an event
    event.fire()

    # add registered callable to the event
    event += error_callable

    # test whether exception can be handled
    try:
        event.fire()
    except ValueError:
        pass
    else:
        assert False, "Exception is not handled"

    # add the same callable more than once
    event += error_callable

    # test whether successful execution of callable registered to an event
    try:
        event.fire()
    except ValueError:
        pass

# Generated at 2022-06-11 17:39:37.382469
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(object):
        def __init__(self):
            self._events = _EventSource()
            self.events = _EventSource()

        def run(self):
            self.events.fire()

    class _Handler(object):
        def __init__(self):
            self._called = False

        def __call__(self, *args, **kwargs):
            if not self._called:
                self._called = True
                raise ValueError('boom')

    handler = _Handler()
    event_source_test = _EventSourceTest()

    # ensure that adding a non-callable handler raises a ValueError
    try:
        event_source_test._events += 'bogus'
    except ValueError:
        pass

# Generated at 2022-06-11 17:39:47.592553
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    #
    # When not given a callable, we expect a ValueError to be raised.
    #
    event_source = _EventSource()
    try:
        event_source += 'not-callable'
    except Exception as e:
        assert type(e) == ValueError
        assert str(e) == 'handler must be callable'
    else:
        assert False

    #
    # When given a callable, we expect the callable to be added.
    #
    event_source = _EventSource()
    state = dict()
    def handler():
        state['added'] = True
    event_source += handler
    assert state == dict()
    event_source.fire()
    assert state == dict(added=True)

    #
    # When given the same callable twice, we expect a KeyError to be raised the

# Generated at 2022-06-11 17:39:57.913258
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._calls = []

        def add_handler_a(self):
            self._calls.append('add_handler_a')

    tes = TestEventSource()

    assert len(tes._handlers) == 0

    # verify that __iadd__ saves the callable
    tes += tes.add_handler_a
    assert len(tes._handlers) == 1

    # verify that __iadd__ does not save a non-callable
    try:
        tes += None
    except ValueError:
        pass
    else:
        assert 1 == 0, 'Expected __iadd__ to raise a ValueError'



# Generated at 2022-06-11 17:40:04.764388
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    evt = _EventSource()

    # Test passing an event handler (which is callable) to method __iadd__
    def evt_handler():
        pass
    evt += evt_handler

    # Test passing a non-callable value to method __iadd__
    try:
        evt += 'string'
    except ValueError:
        pass
    else:
        raise AssertionError('Failed to raise ValueError')



# Generated at 2022-06-11 17:40:41.076195
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class MockClass():
        def __init__(self, counter):
            self.counter = counter

        def call(self):
            self.counter += 1

    @AnsibleCollectionConfig.on_collection_load
    def on_load(coll_mgr):
        pass

    # event source has no handlers
    event_source = _EventSource()
    event_source.fire()

    # event source has two handlers
    mock1 = MockClass(0)
    mock2 = MockClass(0)
    event_source += mock1.call
    event_source += mock2.call
    event_source.fire()
    assert mock1.counter == 1
    assert mock2.counter == 1

    # event source has two handlers, one throws exception
    mock1 = MockClass(0)
    mock2 = MockClass(0)


# Generated at 2022-06-11 17:40:49.244897
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Test:
        def __init__(self):
            self.on_event = _EventSource()
            self.invocations = []

        def handle_event(self, name, *args, **kwargs):
            self.invocations.append((name, args, kwargs))

        def fire(self, name, *args, **kwargs):
            self.on_event.fire(name, *args, **kwargs)

    test = Test()

    class Logger:
        def __init__(self):
            self.invocations = []

        def log(self, *args, **kwargs):
            self.invocations.append((args, kwargs))

    logger = Logger()

    test.on_event += test.handle_event


# Generated at 2022-06-11 17:40:53.138705
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()

        @staticmethod
        def cb1(arg):
            raise ValueError('test')

        @staticmethod
        def cb2(arg):
            assert arg == 'test'

    est = EventSourceTest()
    est.event_source += est.cb1
    est.event_source += est.cb2

    # the second callback should never be called
    est.event_source.fire('test')

# Generated at 2022-06-11 17:41:00.219569
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    # Check _EventSource.__iadd__ with a valid handler
    handler = lambda: None
    event_source += handler

    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    # Check _EventSource.__iadd__ with an invalid handler
    handler = 'invalid'
    try:
        event_source += handler
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-11 17:41:11.879072
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    class _Handler:
        def __init__(self):
            self.arg1 = None
            self.arg2 = None

        def __call__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    handler = _Handler()

    event_source += handler
    assert len(event_source._handlers) == 1
    event_source.fire('first', 'second')
    assert len(event_source._handlers) == 1
    assert handler.arg1 == 'first'
    assert handler.arg2 == 'second'

    class _ErrorHandler(_Handler):
        def __call__(self, arg1, arg2):
            arg1 = 'modified'
            raise TypeError('bad')

    error_handler = _ErrorHandler

# Generated at 2022-06-11 17:41:16.602644
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    instance = _EventSource()
    def handler(x, y=1):
        return x + y

    # testing the __iadd__ method
    instance += handler
    instance += handler
    assert handler in instance._handlers
    assert instance.fire(5) == None
    assert instance.fire(5, y=2) == None



# Generated at 2022-06-11 17:41:21.603027
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()
    assert ev._handlers == set()

    def h1(x):
        pass

    def h2(x):
        pass

    ev += h1
    assert ev._handlers == {h1}
    ev += h1
    assert ev._handlers == {h1}
    ev += h2
    assert ev._handlers == {h1, h2}



# Generated at 2022-06-11 17:41:26.236094
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def f(x):
        pass

    # param is callable
    es = _EventSource()
    es += f

    # param is not callable
    es = _EventSource()
    try:
        es += 's'
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-11 17:41:31.697046
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Declaration
    e = _EventSource()

    # Test Raises error if handler is not callable
    try:
        e += 'not callable'
        raise AssertionError('expected ValueError')
    except ValueError:
        pass

    # Test Adds handler if handler is callable
    e += to_text
    assert to_text in e._handlers



# Generated at 2022-06-11 17:41:39.434032
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fire_event = _EventSource()
    called = []

    def handler1(a, b, c=None):
        called.append("handler1({!r}, {!r}, {!r})".format(a, b, c))

    def handler2(a, b, c=None, d=None):
        called.append("handler2({!r}, {!r}, {!r}, {!r})".format(a, b, c, d))

    def handler3(a, b=None):
        called.append("handler3({!r}, {!r})".format(a, b))
        return True

    def handler4(e=None, f=None):
        called.append("handler4({!r}, {!r})".format(e, f))
        return False

    fire_event += handler1


# Generated at 2022-06-11 17:42:42.418805
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    def event_handler_1():
        pass
    def event_handler_2():
        pass
    # Subscription to event should not raise exceptions
    event += event_handler_1
    event += event_handler_2
    event += event_handler_2
    event += event_handler_1
    assert len(event._handlers) == 2
    assert event_handler_1 in event._handlers
    assert event_handler_2 in event._handlers


# Generated at 2022-06-11 17:42:52.931859
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            event_source_tester.on_exception_called = True
            return super(EventSource, self)._on_exception(handler, exc, *args, **kwargs)

    def a_handler(x, y, z=1):
        event_source_tester.handler_called = (x, y, z)

    def a_handler_with_exception(x, y, z=1):
        raise Exception()

    event_source_tester = type('EventSourceTester', (), {
        'on_exception_called': False,
        'handler_called': None,
    })

    es = EventSource()

    # Not callable

# Generated at 2022-06-11 17:42:57.843394
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    event_source += handler
    assert event_source._handlers == {handler}

    def not_a_callable():
        pass

    try:
        event_source += not_a_callable
    except ValueError:
        pass
    else:
        assert False

    assert event_source._handlers == {handler}



# Generated at 2022-06-11 17:43:05.736308
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    import mock
    m = mock.MagicMock()

    # Test: handler is callable
    es += m
    es.fire()
    m.assert_called_once()

    # Test: handler is not callable
    _ = m.reset_mock()
    m.return_value = None

    try:
        es += {}
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

    es.fire()
    m.assert_called_once()



# Generated at 2022-06-11 17:43:12.149911
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # callable param
    def handler(event):
        pass
    sut = _EventSource()
    sut += handler
    assert handler in sut._handlers
    # non-callable param
    sut = _EventSource()
    try:
        sut += 'notcallable'
        assert(False)
    except ValueError as ve:
        assert "handler must be callable" in str(ve)


# Generated at 2022-06-11 17:43:20.367959
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert_exception_raised(event_source, AssertionError, "1 does not equal 2")
    assert_exception_raised(event_source, AssertionError, "1 does not equal 2")
    assert_exception_raised(event_source, AssertionError, "3 does not equal 4")
    assert_exception_raised(event_source, AssertionError, "3 does not equal 4")
    assert_exception_raised(event_source, AssertionError, "5 does not equal 6")

    print("Success")


# Generated at 2022-06-11 17:43:30.013539
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    assert event._handlers == set()

    event += lambda x: None
    assert event._handlers == {lambda x: None}

    event += lambda x: None
    assert event._handlers == {lambda x: None}

    event += lambda y: None
    assert event._handlers == {lambda x: None, lambda y: None}

    try:
        event += 'test'
    except ValueError:
        pass
    else:
        assert False

    assert event._handlers == {lambda x: None, lambda y: None}



# Generated at 2022-06-11 17:43:35.087321
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _FakeHandler:
        def __init__(self):
            self.call_count = 0

        def __call__(self, *args):
            self.call_count += 1

    event_source = _EventSource()

    handler_a = _FakeHandler()
    handler_b = _FakeHandler()

    event_source += handler_a
    event_source += handler_b

    # Smoke test
    event_source.fire()

    assert handler_a.call_count == 1
    assert handler_b.call_count == 1

    # Test that removing an event handler works
    event_source -= handler_a

    event_source.fire()

    assert handler_a.call_count == 1
    assert handler_b.call_count == 2

    # Test that re-adding an event handler works

# Generated at 2022-06-11 17:43:47.460886
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    assert len(AnsibleCollectionConfig.on_collection_load._handlers) == 0

    data = set()

    def add(x):
        data.add(x)

    AnsibleCollectionConfig.on_collection_load += add
    assert len(AnsibleCollectionConfig.on_collection_load._handlers) == 1

    AnsibleCollectionConfig.on_collection_load.fire('hello')
    assert len(data) == 1
    assert 'hello' in data

    AnsibleCollectionConfig.on_collection_load -= add
    assert len(AnsibleCollectionConfig.on_collection_load._handlers) == 0

    data.clear()
    AnsibleCollectionConfig.on_collection_load.fire('hello')
    assert len(data) == 0

# Generated at 2022-06-11 17:43:51.094830
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    x = _EventSource()
    called = [0]

    def f1(x):
        called[0] += 1

    x += f1
    x.fire()

    assert called[0] == 1

