

# Generated at 2022-06-11 17:34:28.746267
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()
    source += lambda x: print(x)
    source += lambda x: print(x)
    source += lambda x: print(x)
    source.fire('foo')
    source -= lambda x: print(x)
    source -= lambda x: print(x)
    source -= lambda x: print(x)
    source.fire('bar')

# Generated at 2022-06-11 17:34:30.868027
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventSource = _EventSource()
    def customHandler(*args, **kwargs):
        pass
    eventSource += customHandler
    eventSource.fire()

# Generated at 2022-06-11 17:34:35.199836
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    source = _EventSource()
    source += lambda: 0
    with pytest.raises(TypeError):
        source += 'abc'
    source += lambda x: x

    source.fire(1, 2)

    source -= source._handlers.pop()
    source.fire(1, 2)

# Generated at 2022-06-11 17:34:43.895621
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Test:
        def __init__(self, name):
            self._name = name

        def __call__(self, *args, **kwargs):
            print('%s.__call__(%s, %s)' % (self._name, args, kwargs))

    def test_func(*args, **kwargs):
        print('test_func(%s, %s)' % (args, kwargs))

    test_obj = _Test('test_obj')
    es = _EventSource()

    # test empty handlers list
    es.fire('test_arg1', test_kwarg1='test_kwarg1')

    # test raise exception with flag set to True
    es += test_func
    es += test_obj
    es += lambda *args, **kwargs: {}


# Generated at 2022-06-11 17:34:50.666826
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    handler_invocations = []
    handler_values = []

    event.on_exception = lambda handler, exc, *args, **kwargs: handler_values.append((handler, exc, args, kwargs))

    def handler1(v):
        handler_invocations.append(1)

    def handler2(v):
        handler_invocations.append(2)

    event += handler1
    event += handler2

    event.fire(1)
    # should have 2 handlers that were called, both with the same arguments
    assert handler_invocations == [1, 2]
    assert handler_values == []

    event = _EventSource()
    event.on_exception = lambda handler, exc, *args, **kwargs: handler_values.append((handler, exc, args, kwargs))

# Generated at 2022-06-11 17:34:56.265515
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def event_handler(arg, *args, **kwargs):
        return arg

    assert False == event_handler(False)
    assert 2 == event_handler(2)
    assert 'abc' == event_handler('abc')

    event_source = _EventSource()

    event_source += event_handler

    assert 'test__EventSource_fire' == event_source.fire('test__EventSource_fire')

    event_source -= event_handler

    assert '' == event_source.fire('')


# Generated at 2022-06-11 17:35:00.152534
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.actual_args = None
            self.actual_kwargs = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            raise exc

        def handler(self, *args, **kwargs):
            self.actual_args = args
            self.actual_kwargs = kwargs

    event = MyEventSource()
    event.fire(1, 2, a=1, b=2)
    assert event.actual_args == (1, 2)
    assert event.actual_kwargs == dict(a=1, b=2)

# Generated at 2022-06-11 17:35:09.728224
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _TestEventSource(object):
        def __init__(self):
            self._events = _EventSource()

        def add(self, handler):
            self._events += handler

        def fire(self, *args, **kwargs):
            self._events.fire(*args, **kwargs)

    def test_handler1(*args, **kwargs):
        assert args == ('x', 'y')
        assert kwargs == {'a': 1, 'b': 2}

    def test_handler2(*args, **kwargs):
        assert args == ('x', 'y')
        assert kwargs == {'a': 1, 'b': 2}

    test_object = _TestEventSource()
    test_object.add(test_handler1)
    test_object.add(test_handler2)
    test_

# Generated at 2022-06-11 17:35:19.545662
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Setup
    test_object = _EventSource()

    class TestClass:
        def __init__(self):
            self.counter = 0

        def dec(self):
            self.counter -= 1

        def increment(self):
            self.counter += 1

    test_instance = TestClass()

    # Execute
    test_object += test_instance.increment
    test_object.fire()

    # Verify
    assert test_instance.counter == 1

    # Execute
    test_object -= test_instance.increment
    test_object += test_instance.dec
    test_object.fire()

    # Verify
    assert test_instance.counter == 0

# Generated at 2022-06-11 17:35:29.904602
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    events = _EventSource()
    calls = 0
    def incr(n):
        global calls
        calls += n

    # this should not be called - handler removed
    events += lambda n: incr(n)
    events -= events._handlers.pop()

    # this should be called - it is the only handler
    events += lambda n: incr(n)
    events.fire(2)

    # this should not be called - exception is suppressed by the handler
    events += lambda n: incr(n)
    events += lambda n: 1 / 0
    events.fire(2)

    # this should be called - exception is re-raised by the handler
    events += lambda n: incr(n)
    events += lambda n: raise_one_zero_exception

# Generated at 2022-06-11 17:35:40.722272
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler_a(arg1, arg2):
        pass

    def handler_b(arg1, arg2):
        pass

    # callable
    event_source = _EventSource()
    event_source += handler_a
    if event_source._handlers != {handler_a}:
        raise AssertionError('expected %s to be %s' % (event_source._handlers, {handler_a}))

    # not callable
    event_source = _EventSource()
    try:
        event_source += 1
    except ValueError:
        pass
    else:
        raise AssertionError('expected ValueError')
    if event_source._handlers != set():
        raise AssertionError('expected %s to be %s' % (event_source._handlers, set()))

    # handler added only

# Generated at 2022-06-11 17:35:44.816598
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    call_count = [0]

    def handler():
        call_count[0] += 1

    source = _EventSource()
    source += handler

    source.fire()

    assert call_count[0] == 1



# Generated at 2022-06-11 17:35:49.020410
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handle1():
        pass

    es += handle1
    assert len(es._handlers) == 1


# Unit tests for method __isub__ of class _EventSource

# Generated at 2022-06-11 17:35:58.027530
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import logging
    import sys

    class ExceptionFilter:
        def __init__(self, name):
            self.name = name
            self.call_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1

            if self.call_count % 2 == 0:
                raise Exception('%s exception' % self.name)

    class LoggingFilter:
        def __call__(self, *args, **kwargs):
            return True  # swallow every exception

    my_event_source = _EventSource()

    filter1 = ExceptionFilter(name='filter1')
    filter2 = ExceptionFilter(name='filter2')
    filter3 = LoggingFilter()

    my_event_source += filter1
    my_event_source += filter2

    # the events should be processed

# Generated at 2022-06-11 17:35:59.401786
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    events = _EventSource()
    events += lambda: None
    events.fire()

# Generated at 2022-06-11 17:36:07.144538
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.six import print_
    from ansible_test._util.target.legacy_collection_loader.test_fixtures import foo, bar

    # need to set the handler to a function that can be called with no arguments, to avoid TypeError
    test_event_source = _EventSource()
    test_event_source += foo
    test_event_source += bar
    test_event_source.fire()
    # if we reach this point without an exception, the test was successful

# Generated at 2022-06-11 17:36:16.806709
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_collections.ansible.community.tests.unit.compat.mock import call, MagicMock
    from ansible_collections.ansible.community.tests.unit.compat.unittest import TestCase

    class DummyEventSourceTester(TestCase):
        def foo(self, a, b):
            self.assertEqual(a, [1, 2, 3])
            self.assertEqual(b, {'1': '1'})

        def bar(self, a, b):
            self.assertEqual(a, [1, 2, 3])
            self.assertEqual(b, {'1': '1'})

    tester = DummyEventSourceTester()
    event_source = _EventSource()
    event_source += tester.foo
    event_source += t

# Generated at 2022-06-11 17:36:19.210638
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # verify that the event source can be called with no handlers bound to it
    _EventSource().fire('foo')



# Generated at 2022-06-11 17:36:22.938751
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Setup
    es = _EventSource()
    foo = []

    # Exercise
    es += foo.append

    # Verify
    assert len(es._handlers) == 1


# Generated at 2022-06-11 17:36:32.881390
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    es = _EventSource()
    handler1_expected_args = []
    handler1_expected_kwargs = []
    handler1_actual_args = []
    handler1_actual_kwargs = []

    def handler1(*args, **kwargs):
        handler1_actual_args.extend(args)
        handler1_actual_kwargs.update(kwargs)

    es += handler1

    args = (1, 2, 3)
    kwargs = dict(a=1, b=2, c=3)
    handler1_expected_args.extend(args)
    handler1_expected_kwargs.update(kwargs)

    es.fire(*args, **kwargs)

    assert handler1_expected_args == handler1_actual_args
    assert handler1_expected_kwargs == handler1_actual

# Generated at 2022-06-11 17:36:50.337413
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import mock
    f = _EventSource()

    # Create handlers that will raise exceptions
    class CustomException(Exception):
        pass

    def zero_args_raises(e):
        raise e

    def one_arg_raises(a, e):
        raise e

    def two_args_raises(a, b, e):
        raise e

    def three_args_raises(a, b, c, e):
        raise e

    def zero_args_raises_custom(e):
        raise e

    def one_arg_raises_custom(a, e):
        raise e

    def two_args_raises_custom(a, b, e):
        raise e

    def three_args_raises_custom(a, b, c, e):
        raise e


# Generated at 2022-06-11 17:37:01.709420
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event1 = _EventSource()
    event2 = _EventSource()

    def handler1(a, b):
        global handler1_fired
        handler1_fired = (a, b)

    def handler2(c, d):
        global handler2_fired
        handler2_fired = (c, d)

    event1 += handler1
    event2 += handler2
    event1 += handler2

    event1.fire(1, 'a')
    assert handler1_fired == (1, 'a')
    assert handler2_fired == (1, 'a')

    handler1_fired = None
    event2.fire(2, 'b')
    assert handler1_fired is None
    assert handler2_fired == (2, 'b')

    event1 -= handler2
    handler2_fired = None

# Generated at 2022-06-11 17:37:03.476118
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda: None
    assert len(event_source._handlers) == 1


# Generated at 2022-06-11 17:37:11.396291
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(x, y):
        handler1.call_count += 1
        handler1.x = x
        handler1.y = y

    handler1.call_count = 0
    handler1.x = None
    handler1.y = None

    def handler2(x, y):
        handler2.call_count += 1
        handler2.x = x
        handler2.y = y

    handler2.call_count = 0
    handler2.x = None
    handler2.y = None

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    event_source.fire(2, 3)

    assert handler1.call_count == 1
    assert handler1.x == 2
    assert handler1.y == 3

    assert handler2.call_count

# Generated at 2022-06-11 17:37:14.579345
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def _handler(a, b=None):
        if b is None:
            raise AssertionError('b was None')

    event = _EventSource()
    event += _handler

    event.fire(1, b=2)

# Generated at 2022-06-11 17:37:21.107524
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    event_arg = []
    event_kwarg = {}

    def event_handler(arg, kwarg):
        event_arg.append(arg)
        event_kwarg['handler'] = kwarg

    es += event_handler

    es.fire('arg', kwarg='kwarg')
    assert event_arg == ['arg']
    assert event_kwarg['handler'] == 'kwarg'



# Generated at 2022-06-11 17:37:31.021565
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _TestEventSource:
        def __init__(self):
            self._fired = 0

        def fire(self, *args, **kwargs):
            self._fired += 1

    def _test_handler(test_event_source):
        if test_event_source._fired:
            raise ValueError('unexpected test_event_source fired')

    event_source = _EventSource()
    test_event_source = _TestEventSource()

    for i in range(4):
        event_source += _test_handler

    event_source += test_event_source.fire

    event_source.fire()

    event_source -= _test_handler

    event_source.fire()
    event_source.fire()

    event_source -= _test_handler

    event_source += _test_handler

# Generated at 2022-06-11 17:37:34.622218
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += len

    assert len in e._handlers

    # if we try to add a non-callable object, we expect a ValueError
    try:
        e += 'not-callable'
        assert False
    except ValueError as e:
        assert str(e) == 'handler must be callable'



# Generated at 2022-06-11 17:37:39.395158
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTestClass(_EventSource):
        '''
        EventSourceTestClass inherits from _EventSource
        '''
        pass
    event = EventSourceTestClass()
    assert isinstance(event, _EventSource)
    assert event.__class__.__name__ == 'EventSourceTestClass'
    event.fire()



# Generated at 2022-06-11 17:37:49.846030
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import ansible.module_utils.common.text.converters as to_text

    def _check(should_raise, expected_message):
        if should_raise:
            raised = False
            try:
                es += event_handler
            except ValueError as ex:
                raised = True
                actual_message = to_text(ex)
                assert expected_message == actual_message
            assert raised

        else:
            es += event_handler

    expected_message = 'handler must be callable'

    es = _EventSource()
    event_handler = None
    _check(should_raise=True, expected_message=expected_message)

    es = _EventSource()
    event_handler = object()
    _check(should_raise=True, expected_message=expected_message)

    es = _EventSource()
   

# Generated at 2022-06-11 17:38:14.084284
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    called = [0]  # use list to work around plain integer being local to function
    def handler():
        called[0] += 1
    s = _EventSource()
    s += handler
    s.fire()
    return called[0]

if __name__ == '__main__':
    # Execute as a test
    # This code is not used at runtime
    import sys
    import unittest

    class TestFoo(unittest.TestCase):
        def test__EventSource_fire(self):
            self.assertEqual(1, test__EventSource_fire())

    suite = unittest.TestLoader().loadTestsFromTestCase(TestFoo)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())

# Generated at 2022-06-11 17:38:25.328872
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # unit test for _EventSource.fire
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._calls = []
            self._exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exceptions.append((handler, exc, args, kwargs))
            return False

        def on_test_event(self, *args, **kwargs):
            self._calls.append((args, kwargs))

    source = _TestEventSource()
    source += source.on_test_event

    source.fire(1, 2, 3, a='a', b='b', c='c')

# Generated at 2022-06-11 17:38:33.520371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    # test that exception is raised when handler is None
    try:
        event.fire()
        assert False
    except Exception:
        pass

    # test that exception is raised when handler is not callable
    try:
        event += 'not callable'
        event.fire()
        assert False
    except Exception:
        pass

    # test that exception is raised when handler raises an exception
    try:
        event += Exception()
        event.fire()
        assert False
    except Exception:
        pass


# Generated at 2022-06-11 17:38:40.399421
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventTarget:
        def __init__(self):
            self._fired = False

        def set_fired(self, value):
            self._fired = value

        def handler(self):
            self._fired = True

    event_source = _EventSource()
    event_target = _EventTarget()
    event_source += event_target.handler
    event_source.fire()
    assert event_target._fired

# Generated at 2022-06-11 17:38:43.071419
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    m = _EventSource()
    m += lambda: None
    m += lambda: None
    m += lambda: None
    m.fire()

# Generated at 2022-06-11 17:38:45.747620
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    eventsource = _EventSource()
    eventsource.__iadd__("str")
    eventsource.__iadd__("str")


# Generated at 2022-06-11 17:38:49.999030
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(arg):
        pass

    event_source = _EventSource()

    assert handler not in event_source._handlers

    event_source += handler

    assert handler in event_source._handlers

    event_source -= handler

    assert handler not in event_source._handlers


# Generated at 2022-06-11 17:38:54.554745
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def noop(*args, **kwargs):
        pass

    es += noop
    assert len(es._handlers) == 1
    assert noop in es._handlers

    es += noop
    assert len(es._handlers) == 1
    assert noop in es._handlers



# Generated at 2022-06-11 17:38:58.509351
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler1():
        pass

    event_source += handler1
    assert len(event_source._handlers) == 1

    def handler2():
        pass

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler2
    assert len(event_source._handlers) == 2

    try:
        event_source += 'str'
        assert False, 'expecting a ValueError for a non-callable value'
    except ValueError as ex:
        assert str(ex) == 'handler must be callable'



# Generated at 2022-06-11 17:39:01.667686
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    callback_value = 0

    def increment(value):
        nonlocal callback_value
        callback_value += value

    callback = _EventSource()
    callback += increment

    callback.fire(1)
    assert callback_value == 1



# Generated at 2022-06-11 17:39:38.742671
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    assert handler1 not in event._handlers
    assert handler2 not in event._handlers

    event += handler1

    assert handler1 in event._handlers
    assert handler2 not in event._handlers

    event += handler2

    assert handler1 in event._handlers
    assert handler2 in event._handlers

    event += handler1

    assert handler1 in event._handlers
    assert handler2 in event._handlers

    event += handler2

    assert handler1 in event._handlers
    assert handler2 in event._handlers


# Generated at 2022-06-11 17:39:46.252276
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda x: print('{}+{}={}'.format(x, x, x + x))
    event.fire(33)
    event += lambda x: print('{}+{}={}'.format(x, x, x + x))
    event.fire(66)
    event -= lambda x: print('{}+{}={}'.format(x, x, x + x))
    event.fire(99)

if __name__ == "__main__":
    test__EventSource___iadd__()

# Generated at 2022-06-11 17:39:52.056802
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    event = _EventSource()
    fired = [0]

    def handler0():
        fired[0] += 1

    def handler1():
        raise ValueError('test')

    def handler2():
        raise ValueError('test2')

    event += handler0
    event += handler1
    event += handler2

    with pytest.raises(ValueError):
        event.fire()

    assert fired[0] == 1

# Generated at 2022-06-11 17:40:01.251454
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()

    def a():
        raise ValueError('a')

    def b():
        raise ValueError('b')

    def c():
        raise ValueError('c')

    eventsource += a
    eventsource += b
    eventsource += c
    try:
        eventsource.fire()
    except Exception as ex:
        assert 'a' == ex.args[0]

    eventsource -= a
    eventsource -= b
    try:
        eventsource.fire()
    except Exception as ex:
        assert 'c' == ex.args[0]

    eventsource -= c
    eventsource.fire()

# Generated at 2022-06-11 17:40:07.012890
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Test function without events
    e = _EventSource()
    e.fire()

    # Test function with event
    e = _EventSource()
    e += lambda msg: print(msg)
    e.fire('Hello')

    # Test function with events
    e = _EventSource()
    e += lambda msg: print(msg)
    e += lambda msg: print('Bye')
    e.fire('Hello')


# Generated at 2022-06-11 17:40:18.934540
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class C(object):
        def __init__(self, num):
            self.num = num

        def handle_event(self, **kwargs):
            self.num += 1

    e = _EventSource()
    # test basic event handler
    c1 = C(1)
    e += c1.handle_event
    e.fire()
    assert c1.num == 2

    # test removal of event handler
    c2 = C(2)
    e -= c1.handle_event
    e.fire()
    assert c1.num == 2
    e += c2.handle_event
    e += c1.handle_event
    e.fire()
    assert c1.num == 3
    assert c2.num == 3

    # test exception from event handler

# Generated at 2022-06-11 17:40:22.267116
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    callback_called = [False]

    def callback(value):
        callback_called[0] = value

    event_source = _EventSource()
    event_source += callback
    event_source.fire(True)

    assert callback_called[0]



# Generated at 2022-06-11 17:40:27.701733
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _Handler:
        def __init__(self):
            self.msg = None

        def __call__(self, msg):
            self.msg = msg

    handler = _Handler()
    event_source = _EventSource()
    event_source += handler
    event_source.fire('test message')
    assert handler.msg == 'test message'



# Generated at 2022-06-11 17:40:31.625430
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    called = [False]

    def handler1(*args, **kwargs):
        called[0] = True

    e = _EventSource()
    e += handler1

    e.fire()

    assert called[0] is True



# Generated at 2022-06-11 17:40:39.191900
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from unittest import TestCase

    # parameterized test data that can be used to test the method
    test_data_fire = ((5, ), (5, 6), (5, 6, 7))

    # parameterized test data that can be used to test the method
    # for failures due to exceptions
    test_data_on_exception = ((5, ), (5, 6), (5, 6, 7))

    def no_op_handler(*args, **kwargs):
        pass

    def no_op_on_exception(*args, **kwargs):
        pass

    # parameterized test data that can be used to test the method
    # for failures due to exceptions
    test_data_fire_exception = ((5, ), (5, 6), (5, 6, 7))


# Generated at 2022-06-11 17:41:48.098641
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    handler = 'handler'
    exc = 'exc'
    args = 'args'
    kwargs = 'kwargs'

    def on_exception(handler, exc, *m_args, **m_kwargs):
        assert exc is exc
        assert handler is handler
        assert args is m_args
        assert kwargs is m_kwargs

    fire = _EventSource().fire

    class TestException(Exception):
        pass

    def handler1(*m_args, **m_kwargs):
        assert args is m_args
        assert kwargs is m_kwargs

    def handler2(arg1, arg2='default'):
        assert arg1 == args
        assert arg2 == kwargs

        raise TestException('test')

    def handler3():
        raise TestException('test')


# Generated at 2022-06-11 17:41:57.073453
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    call_count = 0

    def handler1(*args, **kwargs):
        nonlocal call_count
        assert args == ('a', 'b')
        assert kwargs == {'c': 'd'}
        call_count += 1

    def handler2(*args, **kwargs):
        nonlocal call_count
        assert args == ('a', 'b')
        assert kwargs == {'c': 'd'}
        call_count += 1

    event = _EventSource()

    event += handler1
    event += handler2

    event.fire('a', 'b', c='d')

    assert call_count == 2

# Generated at 2022-06-11 17:42:06.222451
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._exception = None

        @property
        def exception(self):
            return self._exception

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exception = exc
            return False

    def handler1(*args, **kwargs):
        return True

    def handler2(*args, **kwargs):
        raise ValueError('testing_exception')

    e = TestEventSource()
    e += handler1
    e += handler2

    assert e.exception is None


# Generated at 2022-06-11 17:42:15.222451
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_a(a, b, c):
        assert a == 1 and b == 2 and c == 3
        return 'a'

    def handler_b(a, b, c):
        assert a == 1 and b == 2 and c == 3
        return 'b'

    def on_exception(handler, exc):
        raise

    e = _EventSource()

    # no handlers
    assert e.fire(1, 2, 3) == []

    # add handlers
    e += handler_a
    e += handler_b

    # fire with result
    assert e.fire(1, 2, 3) == ['a', 'b']

    # remove handler
    e.on_exception = on_exception
    e += handler_a
    e += handler_b
    e -= handler_b

# Generated at 2022-06-11 17:42:21.423897
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._call_count = 0

        def add_handler(self, handler):
            self.__iadd__(handler)

        def add_on_exception_handler(self, handler):
            self._on_exception = handler

    import itertools
    import random

    num_handlers = 10
    num_events = 10

    # this will call the handlers in the order they were added
    def test_fire():
        for num in range(0, num_events):
            es.fire(num)

    test_list = list(range(0, num_handlers))

    random.shuffle(test_list)
    es = TestEventSource()
    es.add_handler

# Generated at 2022-06-11 17:42:28.751428
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    called = []
    def handler_true(value):
        called.append(value)
        return True

    def handler_false(value):
        called.append(value)
        return False

    event_source += handler_true
    event_source += handler_false

    event_source.fire(True)
    assert [True, True] == called

    called.clear()
    event_source -= handler_false
    event_source.fire(False)
    assert [False] == called

# Generated at 2022-06-11 17:42:31.110899
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    def handler(event_arg):
        pass

    e += handler

    assert handler in e._handlers



# Generated at 2022-06-11 17:42:41.178885
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    result = []

    def handler1(*args, **kwargs):
        result.append(('handler1', args, dict(kwargs)))

    def handler2(*args, **kwargs):
        result.append(('handler2', args, dict(kwargs)))

    def handler3(*args, **kwargs):
        result.append(('handler3', args, dict(kwargs)))

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3
    event_source.fire('arg1', arg2='kwarg2')


# Generated at 2022-06-11 17:42:45.660589
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    e = _EventSource()
    assert len(e._handlers) == 0
    with pytest.raises(ValueError):
        e += 'not callable'
    def f():
        pass
    e += f
    assert len(e._handlers) == 1
    e += f
    assert len(e._handlers) == 1


# Generated at 2022-06-11 17:42:56.060343
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class test_EventSource(_EventSource):
        def __init__(self):
            super(test_EventSource, self).__init__()
            self.context = None

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.context = {
                'exc': type(exc),
                'args': args,
                'kwargs': kwargs,
            }
            return True

    test = 'example'
    exception = RuntimeError('test exception')

    event_source = test_EventSource()

    def test_handler():
        raise exception

    event_source += test_handler

    try:
        event_source.fire(test)
    except RuntimeError as ex:
        assert ex is exception, 'Expected exception should be re-raised'
