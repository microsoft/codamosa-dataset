

# Generated at 2022-06-11 17:34:34.578357
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event += lambda *args, **kwargs: None

    event.fire(1)



# Generated at 2022-06-11 17:34:43.270118
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class DummyAnsibleCollectionConfig(_AnsibleCollectionConfig):
        pass

    class DummyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    class DummyHandler:
        def __init__(self):
            self._fire_count = 0
            self._last_exception_caught = None

        def __call__(self, *args, **kwargs):
            self._fire_count += 1

            if kwargs.get('should_raise', False):
                raise RuntimeError('test exception')

        def fire_count(self):
            return self._fire_count

        def last_exception_caught(self):
            return self._last_exception_caught

    dummy_handler_1 = DummyHandler()
   

# Generated at 2022-06-11 17:34:50.277227
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class EventSourceTest(AnsibleCollectionConfig):

        def __init__(self):
            self.called = False
            self.exception = None

        def handler(self, *args, **kwargs):
            self.called = True

        def exception_handler(self, *args, **kwargs):
            self.exception = True

        def test_fire(self):
            # Call without handlers
            AnsibleCollectionConfig.on_collection_load.fire()
            assert not self.called

            # Install handlers
            AnsibleCollectionConfig.on_collection_load += self.handler
            AnsibleCollectionConfig.on_collection_load += self.exception_handler

            # Call with handlers
            AnsibleCollectionConfig.on_collection_load.fire()
            assert self.called
            assert self.exception

            # Clear handlers
           

# Generated at 2022-06-11 17:34:55.564204
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    import pytest

    class _EventSourceTest(object):
        def __init__(self):
            self.count = 0

        def handler(self, *args, **kwargs):
            self.count += 1

    test = _EventSourceTest()

    es = _EventSource()

    es += test.handler

    es.fire()

    assert test.count == 1

    es.fire()

    assert test.count == 2



# Generated at 2022-06-11 17:34:59.902088
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(value):
        print('handler1: {}'.format(value))

    def handler2(value):
        print('handler2: {}'.format(value))

    handlers = _EventSource()
    handlers += handler1
    handlers += handler2
    handlers.fire('event')

# Generated at 2022-06-11 17:35:09.587297
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # verify that our test class behaves as we expect it to for tests.
    class _EventSourceSubclass(_EventSource):
        def __init__(self, event_data):
            super(_EventSourceSubclass, self).__init__()
            self.event_data = event_data

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.event_data.add(('_on_exception', handler, exc, args, kwargs))
            return False

    class _EventHandler1:
        def __init__(self, event_data):
            self._event_data = event_data

        def __call__(self, *args, **kwargs):
            self._event_data.add(('EventHandler1', args, kwargs))


# Generated at 2022-06-11 17:35:14.330034
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    es = _EventSource()
    assert len(es._handlers) == 0
    es += lambda: None
    assert len(es._handlers) == 1
    with pytest.raises(ValueError):
        es += 'a'


# Generated at 2022-06-11 17:35:18.068080
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    with pytest.raises(ValueError) as err:
        es += 'not callable'
    assert str(err.value) == 'handler must be callable'

    es += lambda: None


# Generated at 2022-06-11 17:35:21.591619
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    es += lambda: None
    assert len(es._handlers) == 1

    es += lambda: None
    assert len(es._handlers) == 2



# Generated at 2022-06-11 17:35:25.844302
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    def add_one(value):
        return value + 1
    def add_two(value):
        return value + 2
    event_source += add_one
    event_source += add_two
    assert 3 == event_source.fire(1)

# Unit tests for the methods of class _AnsibleCollectionConfig

# Generated at 2022-06-11 17:35:36.313437
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Handler:
        def __init__(self, on_exception_retval):
            self.on_exception_retval=on_exception_retval

        def __call__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def _on_exception(self, handler, exc, *args, **kwargs):
            return self.on_exception_retval

    class Collector:
        def __init__(self):
            self.handled_by = list()

        def __call__(self, *args, **kwargs):
            return self.handled_by.append(kwargs['handled_by'])


    event_source = _EventSource()
    exception_handled = Handler(True)
    exception_unhandled = Handler(False)


# Generated at 2022-06-11 17:35:48.087033
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []
    def handler_1():
        calls.append('handler_1')

    def handler_2():
        calls.append('handler_2')

    def handler_3(x):
        assert x == 42
        calls.append('handler_3')

    def handler_4(x):
        raise ValueError('expected')

    def handler_5(x):
        raise RuntimeError('unexpected')

    source = _EventSource()
    source += handler_1
    source += handler_2
    source += handler_3
    source += handler_4

    source.fire(42)
    source -= handler_2
    source += handler_5

    try:
        source.fire(42)
        assert False, "unexpected"
    except RuntimeError:
        pass


# Generated at 2022-06-11 17:35:55.702979
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    eventSource = _EventSource()
    assert not eventSource._handlers
    handler1 = lambda: None
    assert callable(handler1)
    eventSource += handler1
    assert eventSource._handlers == set([handler1])
    handler2 = lambda: None
    assert callable(handler2)
    eventSource += handler2
    assert eventSource._handlers == set([handler1, handler2])

    def handler3():
        raise Exception('handler3 exception')

    with pytest.raises(Exception) as exception:
        eventSource += handler3
    assert str(exception.value) == 'handler3 exception'


# Generated at 2022-06-11 17:35:57.724346
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()
    x += lambda x: print(x)
    x.fire(3)

# Generated at 2022-06-11 17:36:00.597421
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def target_fire(*args, **kwargs):
        raise Exception('should not have raised exception')

    event_source += target_fire
    event_source.fire()

# Generated at 2022-06-11 17:36:08.439668
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0
    h1 = lambda: 42  # create a lambda that returns 42
    es += h1
    assert len(es._handlers) == 1
    assert any(h1 is h for h in es._handlers)
    h2 = lambda: 21  # create a lambda that returns 21
    es += h2
    assert len(es._handlers) == 2
    assert any(h2 is h for h in es._handlers)


# Generated at 2022-06-11 17:36:09.792978
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(p1, p2):
        pass
    
    test_object = _EventSource()
    test_object += handler1
    assert len(test_object._handlers) == 1
    assert test_object._handlers == {handler1}


# Generated at 2022-06-11 17:36:15.656913
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(m, n):
        pass

    def handler_with_exception(m, n):
        raise Exception('incorrect inputs %d and %d' % (m, n))

    subject = _EventSource()
    subject += handler
    subject += handler_with_exception
    subject += handler
    my_a = 1
    my_b = 1
    subject.fire(my_a, my_b)


# Generated at 2022-06-11 17:36:22.738693
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSourceTest1(object):
        def __init__(self):
            self._handlers = set()

        # This is the method to test
        def __iadd__(self, handler):
            if not callable(handler):
                raise ValueError('handler must be callable')
            self._handlers.add(handler)
            return self

        def __isub__(self, handler):
            try:
                self._handlers.remove(handler)
            except KeyError:
                pass
            return self

        def fire(self, *args, **kwargs):
            for h in self._handlers:
                h(*args, **kwargs)

    # Test 1: event source and event handler are valid
    event_source_test_1 = EventSourceTest1()

# Generated at 2022-06-11 17:36:32.485587
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # set up fixture
    event_source = _EventSource()

    # test
    assert event_source._handlers == set()
    # add a handler
    event_source += lambda: None

    assert event_source._handlers == {lambda: None}
    # add a second handler
    event_source += lambda: None

    assert len(event_source._handlers) == 2
    for handler in event_source._handlers:
        assert callable(handler)

    # test failure
    event_source = _EventSource()
    assert event_source._handlers == set()

    try:
        event_source += 0
    except ValueError as e:
        assert len(event_source._handlers) == 0
    else:
        assert False


# Generated at 2022-06-11 17:36:40.093739
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    es = TestEventSource()
    called = [0]
    def f():
        called[0] += 1

    es += f

    es.fire()

    assert called[0] == 1

# Generated at 2022-06-11 17:36:49.506367
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    log = list()
    event_source = _EventSource()

    def handler_1():
        log.append('handler_1')

    def handler_2():
        log.append('handler_2')

    event_source += handler_1
    event_source += handler_2
    event_source += handler_2

    assert log == []

    event_source.fire()

    assert log == ['handler_1', 'handler_2', 'handler_2']

    log.clear()
    event_source -= handler_1
    event_source -= handler_1
    event_source -= handler_2
    event_source -= handler_2

    event_source.fire()

    assert log == []



# Generated at 2022-06-11 17:36:54.661640
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def event_handler(arg1, arg2):
        pass

    event_source.fire(1, 2)

    event_source += event_handler

    event_source.fire(1, 2)

    # assertion: event_handler was called with the provided arguments
    event_handler.assert_called_once_with(1, 2)
    event_handler.reset_mock()

    event_source -= event_handler

    event_source.fire()

    # assertion: event_handler was not called
    event_handler.assert_not_called()


# Generated at 2022-06-11 17:37:03.379890
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def fire_test(s, t, **k):
        k['source'] = s
        k['target'] = t
        print(s, t, k)

    assert AnsibleCollectionConfig._EventSource.fire == _EventSource.fire

    s = AnsibleCollectionConfig._EventSource()
    assert len(s._handlers) == 0

    s += fire_test
    assert len(s._handlers) == 1

    s.fire('foo', 'bar', a=1, b=2)

    s -= fire_test
    assert len(s._handlers) == 0


# Generated at 2022-06-11 17:37:08.817044
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    with pytest.raises(ValueError):
        event_source += "VALUE_MUST_BE_CALLABLE"
    event_source += lambda x: x
    # add it again?  nothing should change
    num_handlers = len(event_source._handlers)
    event_source += lambda x: x
    assert num_handlers == len(event_source._handlers)


# Generated at 2022-06-11 17:37:15.133882
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _exc(Exception):
        pass

    def _handler_1(event_source):
        raise _exc()

    def _handler_2(event_source):
        raise _exc()

    event_source = _EventSource()

    event_source += _handler_1
    event_source += _handler_2

    try:
        event_source.fire()
    except _exc:
        pass
    except Exception as e:
        # Expecting the event source to re-raise the exception
        assert False



# Generated at 2022-06-11 17:37:17.118507
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def f():
        pass

    es += f



# Generated at 2022-06-11 17:37:28.223522
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class MyEvent(_EventSource):
        pass

    mock_handler = lambda *args, **kwargs: None
    mock_exception = Exception()

    # fire with no handlers should succeed
    MyEvent().fire()

    # fire with a handler that does not raise should succeed

# Generated at 2022-06-11 17:37:33.462622
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Callable():
        def __init__(self):
            self.was_called = False

        def __call__(self, *args, **kwargs):
            self.was_called = args[0]

    callable_1 = Callable()
    callable_2 = Callable()

    event_source = _EventSource()

    event_source += callable_1
    event_source += callable_2

    event_source.fire('callable_meta_data')

    assert callable_1.was_called == 'callable_meta_data'
    assert callable_2.was_called == 'callable_meta_data'



# Generated at 2022-06-11 17:37:44.247835
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test raising exception in handler
    fired = [0]

    def handler1(*args, **kwargs):
        fired[0] += 1

    def handler2(*args, **kwargs):
        fired[0] += 1
        raise RuntimeError('oops')

    def on_exception(handler, exc, *args, **kwargs):
        if handler is handler2:
            return False

        return True

    def handler3(*args, **kwargs):
        fired[0] += 1

    event_source = _EventSource()
    event_source._on_exception = on_exception
    event_source += handler1
    event_source += handler2
    event_source += handler3


# Generated at 2022-06-11 17:37:58.305801
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    handle_exception = False
    results = []
    event_source = _EventSource()

    def handler1(a, b):
        results.append('handler1 {0} {1}'.format(a, b))

    def handler2(a, b):
        results.append('handler2 {0} {1}'.format(a, b))
        if handle_exception:
            raise Exception('testing exception handling')

    event_source += handler1
    event_source += handler2

    # handler1 and handler2 should both be called
    event_source.fire('a', 'b')
    assert len(results) == 2
    assert results[0] == 'handler1 a b'
    assert results[1] == 'handler2 a b'
    results.pop()
    results.pop()

    # handler2 should be called

# Generated at 2022-06-11 17:38:03.929488
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    assert not es._handlers

    es += (lambda *a, **kw: None)
    es += (lambda *a, **kw: dict())
    assert len(es._handlers) == 2

    es.fire()

    def _throw(*a, **kw):
        raise Exception("thrown")

    es += _throw
    try:
        es.fire()
        assert False, "should have thrown an exception"
    except Exception as ex:
        assert isinstance(ex, Exception)

# Generated at 2022-06-11 17:38:12.705465
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # _iadd__ should be able to add a single callable to the handlers set
    def callable_func():
        print("Called!")

    event_source = _EventSource()
    event_source += callable_func
    assert callable_func in event_source._handlers
    assert len(event_source._handlers) == 1

    # _iadd__ should raise ValueError when the parameter is not callable
    class cls:
        pass

    try:
        event_source += cls
    except ValueError:
        pass
    else:
        assert False, "Doesn't raise ValueError when the parameter is not callable"


# Generated at 2022-06-11 17:38:19.135706
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var = 'initial'
    def handler1(sender, *args, **kwargs):
        nonlocal var
        var = 'handler1'
    def handler2(sender, *args, **kwargs):
        nonlocal var
        var = 'handler2'

    event = _EventSource()
    event += handler1
    event += handler2
    event.fire()
    assert var == "handler2"  # handler2 has been called last

    var = 'initial'
    event -= handler1
    event.fire()
    assert var == "handler2"  # handler1 has been removed



# Generated at 2022-06-11 17:38:24.703486
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    result = []

    def handler(arg):
        result.append(arg)

    for i in range(0, 3):
        AnsibleCollectionConfig.on_collection_load += handler

    AnsibleCollectionConfig.on_collection_load.fire('foo')
    AnsibleCollectionConfig.on_collection_load.fire(arg=1)

    assert result[0] == 'foo'
    assert result[1] == 1
    assert len(result) == 2


# Generated at 2022-06-11 17:38:35.307565
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    exc = None
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        raise RuntimeError('this is test exception')

    def handler3(*args, **kwargs):
        raise Exception('this is test exception')

    def handler4(*args, **kwargs):
        raise Exception('this is test exception')

    def handler5(*args, **kwargs):
        raise RuntimeError('this is test exception')

    def event_on_exception(handler, ex, *args, **kwargs):
        nonlocal exc
        exc = ex
        raise ex

    s = _EventSource()
    s += handler1
    s += handler2
    s += handler3
    s._on_exception = event_on_exception
    s += handler4
    s._on_exception

# Generated at 2022-06-11 17:38:40.702688
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def dummy_handler(param1, param2):
        pass

    event_source = _EventSource()
    event_source += dummy_handler
    assert len(event_source._handlers) == 1
    assert dummy_handler in event_source._handlers


# Generated at 2022-06-11 17:38:52.010396
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event += lambda: print('first handler')
    event += lambda: print('second handler')

    event.fire()  # output should be "first handler" and "second handler"

    # ------------------
    # now test exception handling

    error_handling_results = []

    def handler_throws_exception(sender, *args, **kwargs):
        raise RuntimeError('fake exception')

    event += lambda: print('third handler')
    event += handler_throws_exception
    event += lambda: print('fourth handler')

    try:
        event.fire()  # output should be "third handler" and "fourth handler"
        error_handling_results.append('test failed')
    except RuntimeError:
        error_handling_results.append('test passed')

    # ------------------
   

# Generated at 2022-06-11 17:38:55.734139
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    o = _EventSource()
    def handler():
        raise ValueError('handler exception')

    o += handler
    try:
        o.fire()
        raise AssertionError()
    except ValueError:
        pass

if __name__ == '__main__':
    test__EventSource_fire()

# Generated at 2022-06-11 17:39:03.066230
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    on_load_counter = []

    def on_load1(collection_name):
        on_load_counter.append(1)

    def on_load2(collection_name):
        on_load_counter.append(2)

    def on_load3(collection_name):
        on_load_counter.append(3)

    event_source = _EventSource()
    event_source += on_load1
    event_source += on_load2
    event_source += on_load3

    event_source.fire('namespace.collection')

    assert on_load_counter == [1, 2, 3], \
        "event_source.fire did not fire all events - on_load_counter is %s" % on_load_counter

test__EventSource_fire()

# Generated at 2022-06-11 17:39:15.522095
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    called = False

    def handler1(arg1):
        nonlocal called
        called = True

    event = _EventSource()
    event.fire('foo')
    event += handler1
    event.fire('foo')
    assert called

    called = False
    event -= handler1
    event.fire('foo')
    assert not called



# Generated at 2022-06-11 17:39:26.157193
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def noargs():
        pass

    def withdict(**kwargs):
        pass

    def withargs(*args):
        pass

    def withargsanddict(*args, **kwargs):
        pass

    def withkwargs(kwargs):
        pass

    # Call noargs()
    e = _EventSource()
    e.fire()

    # Call noargs() and withdict()
    e = _EventSource()
    e += noargs
    e += withdict
    e.fire()

    # Call noargs(), withdict() and withargs()
    e = _EventSource()
    e += noargs
    e += withdict
    e += withargs
    e.fire()

    # Call noargs(), withdict() and withargs() and withargsanddict()
    e = _EventSource()
    e += no

# Generated at 2022-06-11 17:39:32.989338
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestEvents:
        def __init__(self):
            self.collection_loaded_event = _EventSource()

    def handler1(collection, cache, *args, **kwargs):
        print('in handler1')

    def handler2(collection, cache, *args, **kwargs):
        print('in handler2')
        return 100  # not raising an exception which means we are not re-raising

    test_events = TestEvents()
    test_events.collection_loaded_event += handler1
    test_events.collection_loaded_event += handler2

    test_events.collection_loaded_event.fire('ansible.netcommon', None, None)

# Generated at 2022-06-11 17:39:37.295551
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()

    r = []
    e += lambda *args, **kwargs: r.append('handler1')
    e += lambda *args, **kwargs: r.append('handler2')
    e.fire()
    assert r == ['handler1', 'handler2']



# Generated at 2022-06-11 17:39:39.685773
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()
    source += lambda: 'abc'

    assert source.fire() == [None]

# Generated at 2022-06-11 17:39:43.849470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create an instance of _EventSource
    import threading
    es = _EventSource()
    es += lambda: print('foo')
    es += lambda: print('bar')

    # Add tasks to the list
    tasks = []
    tasks.append(threading.Thread(target=lambda: es.fire()))
    tasks.append(threading.Thread(target=lambda: es.fire()))

    # Start the threads
    for t in tasks:
        t.start()


# Generated at 2022-06-11 17:39:47.099679
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(*args, **kwargs):
        pass
    event = _EventSource()
    event += handler
    event.fire(42)

    # TODO: add tests for on_exception after we get on_exception support in the test runner


# Generated at 2022-06-11 17:39:55.381677
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_handlers = [lambda x: print("Handler 1"), lambda x: print("Handler 2")]

    def print_handler(value):
        print("Handler: " + value)

    es = _EventSource()
    es.fire("testing", "event", "source")

    es += test_handlers[0]
    es += test_handlers[1]
    es.fire("testing", "event", "source")

    es -= test_handlers[1]
    es.fire("testing", "event", "source")

    es += print_handler
    es.fire("print_handler")

# Generated at 2022-06-11 17:40:06.471144
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    test_list = list()
    test_list.append("test_list")

    # Test event handler with 0 argument
    def test_handler_0(test_list):
        test_list.append("test_handler_0")

    AnsibleCollectionConfig.on_collection_load += test_handler_0
    AnsibleCollectionConfig.on_collection_load.fire(test_list)
    assert len(test_list) == 2, test_list

    # Test event handler with 1 argument
    def test_handler_1(test_list, event_arg):
        test_list.append("test_handler_1 ({})".format(event_arg))

    AnsibleCollectionConfig.on_collection_load += test_handler_1

# Generated at 2022-06-11 17:40:10.574296
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    mock_fire = Mock()
    e = _EventSource()
    e += mock_fire
    e.fire('hello', 'world')
    assert mock_fire.call_args == call('hello', 'world')


# Generated at 2022-06-11 17:40:35.680661
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _EventSource_Subclass(_EventSource):
        def __init__(self):
            super(_EventSource, self).__init__()
            self._exception_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._exception_count += 1
            return False

    event_source = _EventSource_Subclass()

    class _EventHandler:
        def __init__(self):
            self._call_count = 0

        def __call__(self, *args, **kwargs):
            self._call_count += 1
            raise Exception('test exception')

    event_handler = _EventHandler()

    event_source += event_handler
    event_source.fire()

    assert event_handler._call_count == 1
    assert event_source._exception

# Generated at 2022-06-11 17:40:44.371781
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def h1(*args, **kwargs):
        nonlocal h1_args
        nonlocal h1_kwargs

        h1_args = args
        h1_kwargs = kwargs

    def h2(*args, **kwargs):
        nonlocal h2_args
        nonlocal h2_kwargs

        h2_args = args
        h2_kwargs = kwargs

    h1_args = None
    h1_kwargs = None
    h2_args = None
    h2_kwargs = None
    _on_exception_called = False

    def _on_exception(handler, exc, *args, **kwargs):
        nonlocal _on_exception_called

        # if we return False, we want the caller to not re-raise
        _on_exception_called = True

# Generated at 2022-06-11 17:40:45.800597
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_event_source = _EventSource()
    test_event_source += "TEST_EVENT_STRING"

# Generated at 2022-06-11 17:40:48.273469
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    def handler(s, i, j):
        pass

    event_source += handler
    event_source.fire('string', 1, j=2)

    assert event_source.fire('string', 1, j=2) == None

# Generated at 2022-06-11 17:40:55.168042
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test1:
        def __init__(self):
            self.event_source = _EventSource()
            self.event_source += self.handler_1
            self.event_source += self.handler_2

        def handler_1(self):
            raise ValueError('handler_1 was called')

        def handler_2(self):
            raise ValueError('handler_2 was called')


    with Test1() as test1:
        test1.event_source.fire()



# Generated at 2022-06-11 17:41:03.548748
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _MyEventSource(_EventSource):
        def __init__(self):
            self.fired_count = 0
            super(_MyEventSource, self).__init__()

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.failure = exc
            return False

    def handler_1():
        raise Exception('handler 1 failed')

    def handler_2():
        raise Exception('handler 2 failed')

    def handler_3():
        raise Exception('handler 3 failed')

    def handler_4():
        raise Exception('handler 4 failed')

    es = _MyEventSource()
    es += handler_1
    es += handler_2
    es += handler_3
    es += handler_4
    es.fire()

    assert es.fired_count == 4

# Generated at 2022-06-11 17:41:12.841310
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    obj = _EventSource()

    def _handler_a(a):
        pass

    def _handler_b(b):
        pass

    def _handler_a_and_b(a, b):
        pass

    def _handler_exception(c):
        raise Exception('test exception')

    obj += _handler_a
    obj += _handler_b
    obj += _handler_a_and_b
    obj += _handler_exception

    obj.fire(1)
    obj.fire(2)
    obj.fire(1, 2)

    with pytest.raises(Exception):
        obj.fire(3)

    obj -= _handler_exception

    obj.fire(3)

# Generated at 2022-06-11 17:41:19.437946
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    assert event._handlers == set()

    def add_two(a, b):
        return a + b

    event += add_two
    assert event._handlers == {add_two}

    sum = event.fire(1, 2)
    assert sum == 3

    event.fire(1, 2, 3)

    event -= add_two
    assert event._handlers == set()

    event += add_two
    try:
        event += add_two
    except ValueError:
        pass



# Generated at 2022-06-11 17:41:30.125295
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # capture events fired by a _EventSource
    events = []

    # define three handler types
    # one that always raises
    def raising_handler(arg):
        raise Exception('foo')

    # another that captures each argument
    def capturing_handler(arg):
        events.append(arg)

    # and a third that captures each argument and then raises
    def capturing_raising_handler(arg):
        events.append(arg)
        raise Exception('foo')

    source = _EventSource()

    # fire the source, adding handlers to it
    # and testing the events fired

    source.fire(1, 2, 3)
    assert events == []

    source += capturing_handler
    source.fire(1, 2, 3)
    assert events == [1]

    source += raising_handler

# Generated at 2022-06-11 17:41:32.056445
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(sender, **kwargs):
        raise NotImplementedError()

    es = _EventSource()
    es += handler
    assert handler in es._handlers
    es -= handler


# Generated at 2022-06-11 17:42:08.112770
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert es._handlers == set()

    def on_event():
        pass

    es += on_event
    assert es._handlers == set([on_event])

    def on_event():
        pass

    es += on_event
    assert es._handlers == set([on_event])  # note the previous on_event is replaced

    es += 1
    assert es._handlers == set([on_event, 1])



# Generated at 2022-06-11 17:42:11.354988
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    assert es._handlers == set()

    def handler(x):
        pass

    es += handler
    assert es._handlers == {handler}
    es += handler
    assert es._handlers == {handler}

    assert es._on_exception(handler, ValueError('foo'))

# Generated at 2022-06-11 17:42:19.789085
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # eventsource.fire calls all associated handlers in turn
    handler_called = [0]

    def first_handler():
        handler_called[0] += 1

    eventsource = _EventSource()
    eventsource += first_handler
    eventsource.fire()
    assert handler_called[0] == 1

    def second_handler():
        handler_called[0] += 1

    eventsource += second_handler
    eventsource.fire()
    assert handler_called[0] == 3

    # handler will be removed, but not called
    eventsource -= first_handler
    eventsource.fire()
    assert handler_called[0] == 4

    # exception raised by handler not in handler list will not be reraised
    def handler_raises_exception():
        raise SyntaxError('handler raised exception')


# Generated at 2022-06-11 17:42:23.756844
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handle_event(val):
        pass

    def handle_event_raise(val):
        raise ValueError(val)

    event_source = _EventSource()
    event_source += handle_event
    event_source += handle_event_raise
    event_source.fire('test')

# Generated at 2022-06-11 17:42:29.965494
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _Test():
        def __init__(self):
            self.x = 0

        def __call__(self, *args, **kwargs):
            pass

    t = _Test()
    e = _EventSource()
    e.__iadd__(t)
    assert t in e._handlers
    e.__iadd__(lambda x: x)
    assert len(e._handlers) == 2


# Generated at 2022-06-11 17:42:40.316850
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_class = _EventSource()

    # test no-op
    test_class.fire()

    # test single handler
    results = list()
    test_class += lambda *args, **kwargs: results.append('called')
    test_class.fire()
    assert results == ['called']

    # test many handlers
    results.clear()
    test_class += lambda *args, **kwargs: results.append('called2')
    test_class.fire()
    assert results == ['called', 'called2']

    # test exception
    results.clear()
    test_class += lambda *args, **kwargs: results.append('called3')

# Generated at 2022-06-11 17:42:49.986116
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    def foo1(x):
        pass

    def foo2(x):
        raise Exception()

    def foo3(x):
        pass

    def foo4():
        pass

    e = EventSource()
    e += foo1
    e += foo2
    e += foo3

    assert len(e._handlers) == 3

    e += foo2
    assert len(e._handlers) == 3

    assert e.fire(1) is None

    try:
        e += foo4
        assert False
    except ValueError:
        pass

    e -= foo1
    e -= foo1

    assert len(e._handlers) == 2


# Generated at 2022-06-11 17:42:58.857905
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def f1(*args, **kwargs):
        print('f1: args=%s, kwargs=%s' % (args, kwargs))

    def f2(*args, **kwargs):
        print('f2: args=%s, kwargs=%s' % (args, kwargs))
        raise Exception('f2 exception')

    def f3(*args, **kwargs):
        print('f3: args=%s, kwargs=%s' % (args, kwargs))
        return kwargs['value']

    evt = _EventSource()

    evt += f1
    evt += f2
    evt += f3

    assert evt.fire(1, 2, arg=3) == None
    assert evt.fire(value=4) == 4

    ev

# Generated at 2022-06-11 17:43:10.064746
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # if any exceptions occur they should not bubble out
    event_source = _EventSource()
    event_source += lambda: 1 / 0
    event_source.fire()

    # if we have multiple handlers, any unhandled exceptions from one should propagate to the next
    def handler(ex):
        raise ex

    event_source = _EventSource()
    event_source += lambda: 1 / 0
    event_source += handler
    with pytest.raises(ZeroDivisionError):
        event_source.fire()

    # if we have multiple handlers, and one handles an exception, it should not propagate to the next
    handled = False

    def handler(ex):
        nonlocal handled
        handled = True
        assert ex

    event_source = _EventSource()
    event_source += lambda: 1 / 0
    event_source += handler
   

# Generated at 2022-06-11 17:43:17.889530
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()
    assert len(s._handlers) == 0

    events = []

    def handle1(a, b):
        events.append((1, a, b))

    def handle2(a, b):
        events.append((2, a, b))

    s += handle1
    s += handle2

    s.fire(3, 4)

    assert len(events) == 2
    assert events[0] == (1, 3, 4)
    assert events[1] == (2, 3, 4)

# Generated at 2022-06-11 17:44:28.370089
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Counter(object):

        def __init__(self):
            self.count = 0

        def increment(self):
            self.count += 1

    class DummyException(Exception):
        pass

    class MySource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            assert(exc is e)
            return False

    counter = Counter()
    e = DummyException()

    try:
        my_source = MySource()
        my_source += counter.increment
        my_source += lambda: 1/0
        my_source.fire()
        assert False, 'should have raised exception'
    except DummyException:
        assert counter.count == 1

    counter = Counter()
    my_source = MySource()
    my_source += counter.increment
