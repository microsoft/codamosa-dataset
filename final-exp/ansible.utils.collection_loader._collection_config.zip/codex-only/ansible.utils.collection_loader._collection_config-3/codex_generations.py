

# Generated at 2022-06-23 13:33:13.871609
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:33:20.915362
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []

    def handler1(a, *args, **kwargs):
        if a is None:
            raise TypeError('a missing in handler1')
        calls.append(('handler1', a, args, kwargs))

    def handler2(b, *args, **kwargs):
        if b is None:
            raise TypeError('b missing in handler2')
        calls.append(('handler2', b, args, kwargs))

    source = _EventSource()
    source += handler1
    source += handler2

    source.fire('a', 'args', k='kwargs')

# Generated at 2022-06-23 13:33:23.126971
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # event = _EventSource()
    # event -= 1
    event = _EventSource()
    event += 1
    event -= 1
    assert len(event._handlers) == 0



# Generated at 2022-06-23 13:33:24.010096
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:33:24.556558
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:33:32.355425
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_test.unit.utils.mock import patch

    with patch('ansible.module_utils.common.text.converters.to_bytes', to_text):
        eventsource = _EventSource()

        def handler():
            pass

        eventsource += handler
        assert handler in eventsource._handlers
        eventsource += handler
        assert handler in eventsource._handlers

        def handler2():
            pass

        eventsource += handler2
        assert handler2 in eventsource._handlers
        eventsource += handler2
        assert handler2 in eventsource._handlers
        eventsource -= handler
        assert handler not in eventsource._handlers
        eventsource -= handler2
        assert handler2 not in eventsource._handlers
        eventsource -= handler2
        assert handler2 not in eventsource._handlers



# Generated at 2022-06-23 13:33:34.524750
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert not event._handlers



# Generated at 2022-06-23 13:33:43.808431
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(_AnsibleCollectionConfig, type)
    assert issubclass(_AnsibleCollectionConfig, type)
    assert issubclass(AnsibleCollectionConfig, object)

    # make sure our metaclass worked properly
    assert hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert hasattr(AnsibleCollectionConfig, '_default_collection')
    assert hasattr(AnsibleCollectionConfig, '_on_collection_load')

    # make sure our metaclass methods worked properly
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert callable(AnsibleCollectionConfig.collection_finder)

    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert callable(AnsibleCollectionConfig.default_collection)


# Generated at 2022-06-23 13:33:49.644546
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')

# Generated at 2022-06-23 13:33:52.607835
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    counter = 0

    def increment_counter():
        nonlocal counter
        counter += 1

    event = _EventSource()
    event += increment_counter
    event += increment_counter
    event += increment_counter
    event.fire()

    assert counter == 3

# Generated at 2022-06-23 13:34:03.422945
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test function handler
    def _handler(arg1, arg2):
        return arg1, arg2
    # test handler that raises exception
    def _handler_exception(arg1, arg2):
        raise ValueError('exc')
    # test handler that returns True to indicate exception should be re-raised
    def _handler_exception_reraise(arg1, arg2):
        raise ValueError('exc')
    # test event source with different options for _on_exception
    def _test_event_source(on_exception):
        event_source = _EventSource()
        event_source._on_exception = on_exception

        # fire an event with no handlers
        event_source.fire()

        # fire an event with handlers
        event_source += _handler

# Generated at 2022-06-23 13:34:13.572355
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class error(Exception):
        pass

    event_source = _EventSource()

    def handler_1(*args, **kwargs):
        assert args == ('foo',)
        assert kwargs == {'bar': 'baz', 'bat': 'ball'}
        raise error()

    def handler_2(*args, **kwargs):
        assert args == ('foo',)
        assert kwargs == {'bar': 'baz', 'bat': 'ball'}

    event_source += handler_1
    event_source += handler_2

    try:
        event_source.fire('foo', bar='baz', bat='ball')
    except error:
        pass
    except Exception:
        assert False, 'unexpected error'
    else:
        assert False, 'expected error'



# Generated at 2022-06-23 13:34:17.145644
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def test():
        pass

    for i in range(5):
        es += test

    assert len(es._handlers) == 5


# Generated at 2022-06-23 13:34:26.298961
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.six.moves import cStringIO as StringIO

    out = StringIO()
    es = _EventSource()

    def handler1(str):
        out.write(str)

    def handler2(str):
        out.write(str + str)

    es += handler1
    es += handler2

    print('test__EventSource___iadd__:', str(es._handlers))
    assert len(es._handlers) == 2
    assert handler1 in es._handlers
    assert handler2 in es._handlers
    assert handler2 in es._handlers

    es.fire('hello')
    assert out.getvalue() == 'hellohello'


# Generated at 2022-06-23 13:34:28.009155
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()



# Generated at 2022-06-23 13:34:33.950548
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    if isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource):
        # test for single event handler
        def on_load_test_1(value):
            assert value == 'test'

        AnsibleCollectionConfig.on_collection_load.fire(value='test')

        # test for multiple event handlers
        def on_load_test_2(value):
            assert value == 'test'

        def on_load_test_n(value):
            assert value == 'test'

        AnsibleCollectionConfig.on_collection_load += on_load_test_1
        AnsibleCollectionConfig.on_collection_load += on_load_test_2
        AnsibleCollectionConfig.on_collection_load += on_load_test_n
        AnsibleCollectionConfig.on_collection_load.fire(value='test')

# Generated at 2022-06-23 13:34:38.220267
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.playbook_paths == []
    assert AnsibleCollectionConfig.on_collection_load is not None

# Generated at 2022-06-23 13:34:40.034227
# Unit test for constructor of class _EventSource
def test__EventSource():
    events = _EventSource()
    assert events._handlers is None
    assert events._on_exception is None

# Generated at 2022-06-23 13:34:43.492218
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda: None
    assert len(event._handlers) == 1


# Generated at 2022-06-23 13:34:46.971662
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    cb = lambda: None
    cb2 = lambda: None

    event = _EventSource()
    event += cb
    assert cb in event._handlers
    assert cb2 not in event._handlers



# Generated at 2022-06-23 13:34:47.827862
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-23 13:34:50.629102
# Unit test for constructor of class _EventSource
def test__EventSource():
    with pytest.raises(ValueError):
        _EventSource() + 1


# For backwards compatibility, we also define a singleton in the global namespace
ansible_collection_config = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:34:53.544782
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)
    assert _AnsibleCollectionConfig('meta_name', (AnsibleCollectionConfig,), {})

# Generated at 2022-06-23 13:34:58.218750
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    handler1 = lambda: None
    event_source += handler1
    assert len(event_source._handlers) == 1
    assert handler1 in event_source._handlers

    handler2 = lambda: None
    event_source += handler2
    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers

    # adding a second time doesn't change anything
    event_source += handler1
    assert len(event_source._handlers) == 2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers

    # non-callable raises ValueError
    import keyword

# Generated at 2022-06-23 13:35:10.151936
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class mock_handler:
        def __init__(self, name):
            self.name = name
            self.call_cnt = 0
            self.expected_args = ()
            self.expected_kwargs = {}
            self.err = None
            self.re_raise = False

        def __call__(self, *args, **kwargs):
            self.call_cnt += 1
            if args != self.expected_args:
                self.err = 'args %s do not match expected args %s' % (args, self.expected_args)
            if kwargs != self.expected_kwargs:
                self.err = 'kwargs %s do not match expected kwargs %s' % (kwargs, self.expected_kwargs)


# Generated at 2022-06-23 13:35:20.316507
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=no-member
    import os

    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

    def on_collection_load(*args, **kwargs):
        pass

    AnsibleCollectionConfig.on_collection_load += on_collection_load

    assert AnsibleCollectionConfig._on_collection_load._handlers
    assert on_collection_load in AnsibleCollectionConfig._on_collection_load._handlers

    AnsibleCollectionConfig.on_collection_load -= on_collection_load

    assert AnsibleCollectionConfig._on_collection_load._handlers
    assert on_collection_load not in AnsibleCollectionConfig._on_collection_load._handlers

    from ansible.utils.collection_list import AnsibleCollectionFinder

    AnsibleCollectionConfig.collection_finder = AnsibleCollection

# Generated at 2022-06-23 13:35:22.820600
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    event += lambda: None
    event -= lambda: None


# Generated at 2022-06-23 13:35:28.748550
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert AnsibleCollectionConfig._collection_finder is None
    assert hasattr(AnsibleCollectionConfig, '_default_collection')
    assert AnsibleCollectionConfig._default_collection is None
    assert hasattr(AnsibleCollectionConfig, '_on_collection_load')
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:35:31.911314
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:35:44.115955
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, property)
    assert isinstance(AnsibleCollectionConfig._default_collection, property)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, property)
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

    # test property setters
    AnsibleCollectionConfig.on_collection_load = None
    AnsibleCollectionConfig.default_collection = None
    AnsibleCollectionConfig.collection_finder = None

    # test the property getters
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollection

# Generated at 2022-06-23 13:35:54.740094
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class O:
        def m(self, *args, **kwargs):
            O.result = 'm called with %r, %r' % (args, kwargs)

    o = O()
    s = _EventSource()

    def h1(*args, **kwargs):
        O.result = 'h1 called with %r, %r' % (args, kwargs)
        raise RuntimeError('test exception')

    def h2(*args, **kwargs):
        O.result = 'h2 called with %r, %r' % (args, kwargs)

    def h3(*args, **kwargs):
        O.result = 'h3 called with %r, %r' % (args, kwargs)


# Generated at 2022-06-23 13:35:55.522992
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._on_collection_load



# Generated at 2022-06-23 13:36:01.892742
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # Test: constructor sets defaults and __init__ is called
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


collection_config = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:36:03.646423
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:36:10.659827
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert TestCollectionConfig._collection_finder is None
    assert TestCollectionConfig.collection_finder
    assert TestCollectionConfig._default_collection is None
    assert TestCollectionConfig.default_collection is None

    # Test on_collection_load
    assert TestCollectionConfig.on_collection_load
    assert TestCollectionConfig.on_collection_load == TestCollectionConfig._on_collection_load


# Test properties of class AnsibleCollectionConfig

# Generated at 2022-06-23 13:36:15.266035
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import ansible_test._util.target.legacy_collection_loader
    assert isinstance(ansible_test._util.target.legacy_collection_loader.collection_config, AnsibleCollectionConfig)

# Generated at 2022-06-23 13:36:16.275163
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert(_EventSource())

# Generated at 2022-06-23 13:36:20.062232
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def handler():
        pass
    event_source.__iadd__(handler)

    assert(handler in event_source._handlers)
    event_source.__isub__(handler)
    assert(handler not in event_source._handlers)

# Generated at 2022-06-23 13:36:21.629540
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()

    def x():
        pass

    event += x
    event += x

    assert len(event._handlers) == 1

# Generated at 2022-06-23 13:36:23.252432
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    print(AnsibleCollectionConfig._collection_finder)


# Generated at 2022-06-23 13:36:26.598976
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class M(_AnsibleCollectionConfig):
        pass

    assert M._collection_finder is None
    assert M._default_collection is None


ansible_collection_config = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:36:36.156083
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that the test_function is called
    def test_function():
        test_variable[0] = True

    test_variable = [False]
    eventsource = _EventSource()
    # Add our test function to the event source
    eventsource += test_function

    # Check if our test_function was called
    eventsource.fire()
    assert test_variable[0] is True

    # Remove our test function from the event source
    eventsource -= test_function

    # Check if our test_function is no longer called
    eventsource.fire()
    assert test_variable[0] is False



# Generated at 2022-06-23 13:36:39.547968
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(s, w):
        print('handler: %s %s' % (s, w))

    es = _EventSource()
    es.fire('foo', 'bar')
    es += handler
    es.fire('foo', 'bar')
    es -= handler
    es.fire('foo', 'bar')



# Generated at 2022-06-23 13:36:44.225996
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    assert handler not in event_source._handlers
    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-23 13:36:56.351282
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evt_source = _EventSource()

    def handler(x=None):
        return x

    # handler is not called
    assert evt_source.fire() == None

    # handler is called with default parameters
    evt_source += handler
    assert evt_source.fire('hello') == 'hello'
    assert evt_source.fire() == None

    # make handler throw exception
    def handler_exception(x):
        raise x
    evt_source += handler_exception

    # exception is suppressed
    try:
        evt_source.fire(ValueError('error'))
    except ValueError:
        raise AssertionError('exception was not suppressed')

    # exception is not suppressed

# Generated at 2022-06-23 13:36:59.484824
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _EventSource.__init__ = lambda x: None
    _EventSource._on_exception = lambda x, y, z, **kwargs: False
    _EventSource._handlers = ['a', 'b', 'c']
    assert _EventSource().fire() is None

# Generated at 2022-06-23 13:37:05.471157
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    result = []

    def event_handler(x):
        result.append(x)

    event += event_handler
    event.fire('a')
    event.fire('b')
    event.fire('c')

    assert result == ['a', 'b', 'c']



# Generated at 2022-06-23 13:37:10.611237
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # ensure we can construct our class
    c = AnsibleCollectionConfig()

    # ensure our class is properly defaulted
    assert c._collection_finder is None
    assert c._default_collection is None
    assert c._on_collection_load is not None
    assert len(c._on_collection_load._handlers) == 0



# Generated at 2022-06-23 13:37:14.808462
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            MockEventSource.exception_handler = handler
            MockEventSource.exception_exc = exc
            MockEventSource.exception_args = args
            MockEventSource.exception_kwargs = kwargs
            return False

    def handler_a(*args, **kwargs):
        MockEventSource.handler_a_args = args
        MockEventSource.handler_a_kwargs = kwargs

        return 'handler_a_return'

    def handler_b(*args, **kwargs):
        MockEventSource.handler_b_args = args
        MockEventSource.handler_b_kwargs = kwargs

        raise Exception('handler_b_exception_message')


# Generated at 2022-06-23 13:37:20.952362
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # setup
    test_event_source = _EventSource()
    test_event_handler = lambda x: 0
    test_event_source += test_event_handler
    test_event_source += test_event_handler

    # precondition
    assert len(test_event_source._handlers) == 2

    # exercise
    test_event_source -= test_event_handler

    # verify
    assert len(test_event_source._handlers) == 1

# Module test cases


# Generated at 2022-06-23 13:37:28.119244
# Unit test for constructor of class _EventSource
def test__EventSource():
    class EventSource(_EventSource):
        def __init__(self):
            # explicitly test non-callable values
            self._handlers.add(4)
            # explicitly test callable value
            self._handlers.add(lambda: None)
            # explicitly test raise ValueError on non-callable
            try:
                self += 'not callable'
                assert False, "expected an exception"
            except ValueError as e:
                pass
            # explicitly test raise ValueError on callable
            try:
                self += lambda: None
                assert False, "expected an exception"
            except ValueError as e:
                pass
            # explicitly test that None is allowed
            self -= lambda: None
    o = EventSource()
    assert len(o._handlers) == 1


# Generated at 2022-06-23 13:37:29.848033
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')


# Generated at 2022-06-23 13:37:34.554067
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig(object, "_AnsibleCollectionConfig", None)

    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert cls._on_collection_load._handlers == set()



# Generated at 2022-06-23 13:37:44.241906
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    assert hasattr(AnsibleCollectionConfig, 'on_collection_load'), "the _AnsibleCollectionConfig.__init__() function failed to add the 'on_collection_load' attribute to the AnsibleCollectionConfig class"
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource), "the AnsibleCollectionConfig.on_collection_load attribute is not of type _EventSource"

    # exercise code path: __isub__(handler) with handler which is a member of the _handlers set
    AnsibleCollectionConfig.on_collection_load -= 'handler in the set'

    # exercise code path: __isub__(handler) with handler which is not a member of the _handlers set
    AnsibleCollectionConfig.on_collection_load -= 'handler not in the set'

# Generated at 2022-06-23 13:37:45.537218
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():  # pylint: disable=redefined-outer-name
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:37:57.364133
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # verify ValueError exception is raised if value not callable
    event = _EventSource()
    event_list = [1, 2, 3, 4]
    with pytest.raises(ValueError):
        event += event_list

    # verify ValueError exception is raised if value not callable
    event = _EventSource()
    i = 1
    with pytest.raises(ValueError):
        event += i

    # verify return value not re-raised if on_exception handler returns False
    event = _EventSource()
    mock_handler = MagicMock(return_value=False)

    mock_event_one = MagicMock(side_effect=ValueError)
    mock_event_two = MagicMock(side_effect=ZeroDivisionError)

    event += mock_handler
    event += mock_event_one
   

# Generated at 2022-06-23 13:38:01.173619
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-23 13:38:10.893864
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(arg1, arg2, kwarg1=None, kwarg2=None):
        return arg1 * arg2 * kwarg1 * kwarg2

    def handler2(arg1, arg2, kwarg1=None, kwarg2=None):
        if arg1 == 0 or kwarg1 == 0:
            return 0
        return 100 / (arg1 * kwarg1)

    def handler3(arg1, arg2, kwarg1=None, kwarg2=None):
        raise Exception()

    event_source = _EventSource()

    assert event_source.fire(1, 2, kwarg1=3, kwarg2=4) is None

    event_source += handler1

# Generated at 2022-06-23 13:38:12.627306
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()



# Generated at 2022-06-23 13:38:18.914949
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # we get an exception if we try to set the collection_finder property us on this class directly
    with pytest.raises(AttributeError):
        AnsibleCollectionConfig.collection_finder = None
    # the constructor checks if we have already defined a collection_finder property.  We should get an exception.
    with pytest.raises(AttributeError):
        AnsibleCollectionConfig().collection_finder = None

# Generated at 2022-06-23 13:38:21.728411
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')
    assert not hasattr(AnsibleCollectionConfig, '_on_collection_load')



# Generated at 2022-06-23 13:38:31.140651
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler1 = lambda: None
    handler2 = lambda: None
    event_source += handler1
    event_source += handler2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers

    event_source -= handler1
    assert handler1 not in event_source._handlers
    assert handler2 in event_source._handlers

    event_source -= lambda: None
    assert handler1 not in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-23 13:38:40.041830
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    def handler1(*args, **kwargs):
        handler1.fired += 1
        return 42

    handler1.fired = 0
    es += handler1

    ret = es.fire('a', b=1)
    assert handler1.fired == 1

    # the value of the return value isn't preserved at the call site
    assert ret is None

    def handler2(*args, **kwargs):
        handler2.fired += 1
        if handler2.fire_exception:
            raise Exception()

    handler2.fired = 0
    handler2.fire_exception = False
    es += handler2

    ret = es.fire('a', b=1)
    assert handler1.fired == 2
    assert handler2.fired == 1

    handler2.fire_exception = True

# Generated at 2022-06-23 13:38:41.517460
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:38:42.140494
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:38:42.947683
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig()._on_collection_load



# Generated at 2022-06-23 13:38:49.485615
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.six.moves import StringIO

    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            self._raised.append(exc)
            return True

    original_stdout = sys.stdout
    buffer = StringIO()
    try:
        sys.stdout = buffer

        print('Setup')
        raised = []
        emitter = MyEventSource()
        emitter._raised = raised
        emitter += handler_valid

        handler_valid.fire()

        print('Tear Down')
    finally:
        sys.stdout = original_stdout

    assert raised == []
    assert 'output' == buffer.getvalue().strip()


# Generated at 2022-06-23 13:38:54.747373
# Unit test for constructor of class _EventSource
def test__EventSource():
    class Foo:
        pass

    e = _EventSource()
    e += Foo()
    e -= Foo()
    e._on_exception(Foo(), Exception())
    assert e.fire() is None



# Generated at 2022-06-23 13:38:57.419598
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler():
        pass
    source = _EventSource()

    source += handler

    assert handler in source._handlers

    source.fire()
    source -= handler

    assert handler not in source._handlers


# Generated at 2022-06-23 13:39:02.136045
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config.collection_finder is None
    assert config.collection_paths == []
    assert config.default_collection is None
    assert config.playbook_paths == []



# Generated at 2022-06-23 13:39:08.808830
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestClass:
        def __init__(self):
            self._fired = False
            self._value = None

    def handler(value):
        return value

    test1 = TestClass()

    source = _EventSource()
    source += handler

    source.fire(test1)
    assert test1._fired is True
    assert test1._value == test1

    # reset
    test1._fired = False
    test1._value = None

    test2 = TestClass()
    test2._fired = True

    source.fire(test2)
    assert test2._fired is True
    assert test2._value == test2


# Generated at 2022-06-23 13:39:09.207385
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource

# Generated at 2022-06-23 13:39:10.348864
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig()


# Generated at 2022-06-23 13:39:13.908517
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    es -= handler
    assert len(es._handlers) == 0

# Generated at 2022-06-23 13:39:16.655573
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(event, **kwargs):
        pass

    ev = _EventSource()
    ev += handler
    ev -= handler

# Generated at 2022-06-23 13:39:19.354889
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    a = _AnsibleCollectionConfig('meta', 'name', 'bases')

    assert a._collection_finder is None

    assert isinstance(a._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:39:25.874814
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance = _EventSource()

    def foo(a, b):
        # raise an exception
        raise Exception('foo')

    def bar(a, b):
        # return True
        return True

    instance += foo
    instance += bar

    try:
        instance.fire(1, 2)
    except:
        return True

    raise Exception('_EventSource.fire failed to raise an exception')

# Generated at 2022-06-23 13:39:32.035549
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    my_source = _EventSource()
    decrementer = [0]
    decrementing_handler = lambda: decrementer.__setitem__(0, decrementer[0] - 1)

    my_source += decrementing_handler

    assert decrementer[0] == 0
    my_source.fire()
    assert decrementer[0] == -1

    my_source -= decrementing_handler
    my_source.fire()
    assert decrementer[0] == -1

# Generated at 2022-06-23 13:39:42.676422
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from test.lib.ansible_test._util.target.legacy_collection_loader._collection_finder import AnsibleCollectionFinder
    from test.lib.ansible_test._util.target.legacy_collection_loader._config_loader import AnsibleConfigLoader

    cls = _AnsibleCollectionConfig('', '', ())
    # Note that we cannot test AnsibleCollectionConfig because it is marked abstract in its module.

    # collection_finder
    assert cls.collection_finder is None
    finder = AnsibleCollectionFinder()
    cls.collection_finder = finder
    assert cls.collection_finder is finder
    try:
        cls.collection_finder = finder
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"

    # collection_paths

# Generated at 2022-06-23 13:39:45.379780
# Unit test for constructor of class _EventSource
def test__EventSource():
    from ansible.utils.collection_loader import _EventSource
    _EventSource()

# Generated at 2022-06-23 13:39:51.240686
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # TestCase #1: removing handler that has not been added
    source = _EventSource()
    source -= 'handler'

    # TestCase #2: removing handler that has been added
    source += 'handler'
    source -= 'handler'
    assert len(source._handlers) == 0



# Generated at 2022-06-23 13:39:58.020323
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event += handler1
    event += handler2
    assert len(event._handlers) == 2

    event -= handler1
    assert len(event._handlers) == 1
    assert handler1 not in event._handlers

    event -= handler2
    assert len(event._handlers) == 0


# unit test for method fire of class _EventSource

# Generated at 2022-06-23 13:40:01.814943
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    class Event:
        def __init__(self):
            self.fired = False
        def fire(self, *args, **kwargs):
            self.fired = True
    event = Event()
    event_source += event.fire
    event_source.fire()
    assert event.fired



# Generated at 2022-06-23 13:40:03.225517
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')


# Generated at 2022-06-23 13:40:08.189719
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1

    with pytest.raises(ValueError) as ex:
        es += True
    assert str(ex.value).startswith('handler must be callable')



# Generated at 2022-06-23 13:40:10.080547
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')


# Generated at 2022-06-23 13:40:11.426813
# Unit test for constructor of class _EventSource
def test__EventSource():
    pass


# Generated at 2022-06-23 13:40:18.932765
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test_handler_should_not_be_called
    es = _EventSource()
    es.fire()

    # test_handler_should_be_called
    called = False
    def handler(*args, **kwargs):
        nonlocal called
        called = True

    es += handler
    es.fire()

    assert called

    # test_handler_should_be_called
    called = False

    def handler(*args, **kwargs):
        nonlocal called
        called = True

    es -= handler
    es.fire()

    assert not called

# Generated at 2022-06-23 13:40:30.393075
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import os
    import tempfile


# Generated at 2022-06-23 13:40:33.700274
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert not event_source._handlers

    def handler():
        pass

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers



# Generated at 2022-06-23 13:40:35.091353
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    s += lambda: None
    assert len(s._handlers) == 1



# Generated at 2022-06-23 13:40:45.078151
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class dummy:
        def func(self, cb_arg1, cb_arg2):
            if self.cb_arg1 == cb_arg1 and self.cb_arg2 == cb_arg2 and not self.raised:
                self.triggered = True

        def error(self, cb_arg1, cb_arg2):
            if self.cb_arg1 == cb_arg1 and self.cb_arg2 == cb_arg2:
                self.raised = True
                raise Exception('test')

    subject = _EventSource()
    subject += dummy.func
    subject += dummy.error

    expected_cb_arg1 = 'test'
    expected_cb_arg2 = ('test1', 'test2')
    d = dummy()
    d.cb_arg1 = expected_cb_arg

# Generated at 2022-06-23 13:40:49.937042
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Derp(object):
        __metaclass__ = _AnsibleCollectionConfig

    assert Derp._collection_finder is None
    assert Derp._default_collection is None
    assert isinstance(Derp._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:40:50.582577
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:40:52.620461
# Unit test for constructor of class _EventSource
def test__EventSource():
    handler = lambda x: x
    event = _EventSource()
    event += handler
    event -= handler

# Generated at 2022-06-23 13:41:00.042199
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    results = []

    def handler1(arg1, arg2, **kwargs):
        results.extend([arg1, arg2])
        raise ValueError('test error')

    def handler2(arg1, arg2, **kwargs):
        results.extend([arg1, arg2])
        raise ValueError('test error')

    def handler3(arg1, arg2, **kwargs):
        results.extend([arg1, arg2])

    event_source = _EventSource()

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire(1, 2)

    assert results == [1, 2, 1, 2, 1, 2]

    results[:] = []

    # if a handler raises an exception, that should not prevent the firing of other handlers

# Generated at 2022-06-23 13:41:01.293908
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()



# Generated at 2022-06-23 13:41:03.150310
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    eventsource = _EventSource()

    def testcase(value):
        eventsource += value

    testcase(u'foo')

    eventsource -= u'foo'

    assert u'foo' not in eventsource._handlers, "Unit test for method __isub__ of class _EventSource has failed"

# Generated at 2022-06-23 13:41:04.535827
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    raise NotImplementedError('test is not implemented')


# Generated at 2022-06-23 13:41:07.824192
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    def f(a, b):
        assert a == 'foo'
        assert b == 'bar'

    es += f
    es.fire('foo', 'bar')
    es -= f
    es.fire('foo', 'bar')



# Generated at 2022-06-23 13:41:09.757018
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()



# Generated at 2022-06-23 13:41:13.837590
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, property)
    assert isinstance(AnsibleCollectionConfig._collection_paths, property)
    assert isinstance(AnsibleCollectionConfig._default_collection, property)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig._playbook_paths, property)

# Generated at 2022-06-23 13:41:15.977564
# Unit test for constructor of class _EventSource
def test__EventSource():
    # testing __init__ method
    cls = _EventSource
    assert getattr(cls, '_handlers') == set()


# Generated at 2022-06-23 13:41:20.791968
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    raised_exception = None
    try:
        event_handlers = _EventSource()
        event_handlers += 'not callable'
    except Exception as e:
        raised_exception = e

    assert isinstance(raised_exception, ValueError)
    assert raised_exception.args == ('handler must be callable',)


# Generated at 2022-06-23 13:41:21.851799
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:41:24.386836
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    source.__isub__(None)


collection_config = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:41:35.129744
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that calling fire doesn't call any handlers
    event_source = _EventSource()
    event_source.fire()

    # Test that calling fire calls the added handler with arguments
    def handler(*args, **kwargs):
        assert args == (1, 2, 3)
        assert kwargs == {'a': 'b'}

    event_source += handler
    event_source.fire(1, 2, 3, a='b')

    # Test that calling fire does not call a handler that was removed
    event_source -= handler
    event_source.fire()

    # Test that an exception thrown by a handler causes the next handler to be skipped
    handler_invoked = []

    def handler1(cause_exception=False):
        handler_invoked.append(1)
        if cause_exception:
            raise ValueError()

# Generated at 2022-06-23 13:41:42.315206
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def callback_1(*args, **kwargs):
        pass

    def callback_2(*args, **kwargs):
        pass

    event_source = _EventSource()

    event_source += callback_1
    event_source += callback_2

    assert len(event_source._handlers) == 2

    event_source += callback_2

    try:
        event_source += None
        assert False, 'ValueError expected'
    except ValueError:
        pass



# Generated at 2022-06-23 13:41:54.198297
# Unit test for constructor of class _EventSource
def test__EventSource():
    class TestException(Exception):
        pass

    def test_handler_1(a, b, c):
        assert a == 'a'
        assert b == 'b'
        assert c == 'c'

    def test_handler_2(a, b, c):
        assert a == 'a'
        assert b == 'b'
        assert c == 'c'
        raise TestException

    es = _EventSource()
    es += test_handler_1
    es += test_handler_2
    es.fire('a', 'b', 'c')
    try:
        es.fire('a', 'b', 'c')
        raise AssertionError('Expected exception not thrown.')
    except TestException:
        pass
    es -= test_handler_2
    es.fire('a', 'b', 'c')


# Generated at 2022-06-23 13:42:01.637156
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def handler1(x):
        print(x)
    def handler2(x):
        print(x)
    event_source += handler1
    event_source += handler2
    event_source -= handler1
    event_source.fire(1)
    event_source -= handler2
    event_source.fire(2)
    event_source -= handler2


# Generated at 2022-06-23 13:42:04.880087
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class C(AnsibleCollectionConfig):
        pass
    assert isinstance(C._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:42:06.351024
# Unit test for constructor of class _EventSource
def test__EventSource():
    # test that _EventSource constructs without error
    _EventSource()



# Generated at 2022-06-23 13:42:15.369436
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []
    event = _EventSource()

    def handler1(arg1, arg2):
        calls.append((handler1, arg1, arg2))

    def handler2(arg1, arg2):
        """Exception throwing handler"""
        raise Exception('handler2')

    def handler3(arg1, arg2):
        """Exception swallowing handler"""
        if calls:
            return  # calling this handler first always raises an exception

        calls.append((handler3, arg1, arg2))

    event += handler1
    event += handler2
    event += handler3

    # verify that only the first two handlers are called
    event.fire('a1', 'a2')
    assert set(calls) == set([(handler1, 'a1', 'a2'), (handler2, 'a1', 'a2')])

   

# Generated at 2022-06-23 13:42:20.699594
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    result = []
    event = _EventSource()

    def handler1(value):
        result.append('h1')

    def handler2(value):
        result.append('h2')

    event += handler1
    event += handler2

    event.fire()
    assert result == ['h1', 'h2']



# Generated at 2022-06-23 13:42:22.016411
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()


# Generated at 2022-06-23 13:42:26.694150
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert(AnsibleCollectionConfig._collection_finder is None)
    assert(AnsibleCollectionConfig._default_collection is None)
    assert(len(AnsibleCollectionConfig._on_collection_load._handlers) == 0)
    assert(len(AnsibleCollectionConfig._on_collection_load.handlers) == 0)

# Generated at 2022-06-23 13:42:29.528415
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig()
    except TypeError:
        pass
    else:
        raise Exception('constructor of class _AnsibleCollectionConfig should have raised a TypeError')


# Generated at 2022-06-23 13:42:41.493283
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # verify the event is delivered
    evnt = _EventSource()
    called = [False]
    def handler():
        called[0] = True
    evnt += handler
    evnt.fire()
    assert called[0] is True

    # verify the event is delivered to multiple handlers
    called = [False, False]
    def handler0():
        called[0] = True
    def handler1():
        called[1] = True
    evnt += handler0
    evnt += handler1
    evnt.fire()
    assert called[0] is True
    assert called[1] is True

    # verify the event is delivered to handlers in the order registered
    called = [False, False, False]
    def handler0():
        called[0] = True
    def handler1():
        called[1] = True


# Generated at 2022-06-23 13:42:45.339219
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    # setup handlers
    def handler_one():
        pass

    def handler_two():
        pass

    def handler_three():
        pass

    source += handler_one
    source += handler_two
    source += handler_three

    source -= handler_two

    assert set(source._handlers) == set([handler_one, handler_three])



# Generated at 2022-06-23 13:42:50.102704
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    func1 = lambda x:x
    func2 = lambda x:x

    event_source += func1
    event_source -= func1

    assert func1 not in event_source._handlers
    assert func2 not in event_source._handlers



# Generated at 2022-06-23 13:42:51.687072
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:42:57.009321
# Unit test for constructor of class _EventSource
def test__EventSource():
    # 1) EventSource can be constructed
    #
    try:
        event_source = _EventSource()
    except:
        assert(False)

    # 2) EventSource cannot be constructed without arguments
    #
    try:
        event_source = _EventSource(1, 2, 3)
        assert(False)
    except TypeError:
        assert(True)


# Generated at 2022-06-23 13:43:01.346342
# Unit test for constructor of class _EventSource
def test__EventSource():
    import unittest as ut

    class TestEventSource(ut.TestCase):
        def test__init__(self):
            es = _EventSource()
            self.assertIsInstance(es._handlers, set)
            self.assertEqual(0, len(es._handlers))

    suite = ut.TestSuite()
    suite.addTest(ut.TestLoader().loadTestsFromTestCase(TestEventSource))
    return suite


# Generated at 2022-06-23 13:43:09.492197
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    isinstance(AnsibleCollectionConfig._collection_finder, property)
    isinstance(AnsibleCollectionConfig.collection_finder, property)
    isinstance(AnsibleCollectionConfig._default_collection, property)
    isinstance(AnsibleCollectionConfig.default_collection, property)
    isinstance(AnsibleCollectionConfig._on_collection_load, property)
    isinstance(AnsibleCollectionConfig.on_collection_load, property)
    isinstance(AnsibleCollectionConfig._playbook_paths, property)
    isinstance(AnsibleCollectionConfig.playbook_paths, property)


# Generated at 2022-06-23 13:43:13.663724
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    myEvent = _EventSource()

    def add_int(a, b):
        return a + b

    myEvent += add_int
    assert myEvent.fire(2, 3) == 5

    def add_float(a, b):
        return a + b

    myEvent += add_float
    assert myEvent.fire(2, 3.5) == 5.5

