

# Generated at 2022-06-23 13:33:12.760886
# Unit test for constructor of class _EventSource
def test__EventSource():
    try:
        _EventSource()
    except Exception as e:
        pass
    else:
        assert False

ansible_collection_config = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:33:20.057678
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class C:
        pass

    src = C()
    src.evt = _EventSource()

    src.evt += lambda:       hasattr(src, 'a') or setattr(src, 'a', 1)
    src.evt += lambda *args: hasattr(src, 'b') or setattr(src, 'b', args)
    src.evt += lambda **kwargs: hasattr(src, 'c') or setattr(src, 'c', kwargs)
    src.evt += lambda *args, **kwargs: hasattr(src, 'd') or setattr(src, 'd', (args, kwargs))
    src.evt += lambda arg1=1, arg2=2: hasattr(src, 'e') or setattr(src, 'e', (arg1, arg2))

   

# Generated at 2022-06-23 13:33:23.338877
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class Dummy:
        def method(self, *args, **kwargs):
            pass

    dummy = Dummy()
    eventsource = _EventSource()

    eventsource += dummy.method
    eventsource += dummy.method

    assert len(eventsource._handlers) == 2



# Generated at 2022-06-23 13:33:28.402999
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source_iobj = _EventSource()

    def handler():
        pass
    event_source_iobj += handler

    # test when handler is in _handlers
    event_source_iobj -= handler
    assert handler not in event_source_iobj._handlers

    # test when handler is not in _handlers
    event_source_iobj -= handler
    assert handler not in event_source_iobj._handlers


# Generated at 2022-06-23 13:33:37.105141
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    # adding a callable successfully
    def handler(x):
        return x**2
    assert not es._handlers
    es += handler
    assert es._handlers == {handler}

    # adding a non-callable type
    # should raise a TypeError
    try:
        es += 'not  a callable'
    except TypeError:
        # we expect a TypeError to be raised
        pass
    else:
        assert False, 'TypeError not raised for non-callable addition to _EventSource set'


# Generated at 2022-06-23 13:33:43.344509
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    event_source = _EventSource()
    handler = lambda: 123

    with pytest.raises(ValueError) as err:
        # Act
        event_source += 'not callable'

    assert str(err.value) == 'handler must be callable'
    assert len(event_source._handlers) == 0

    # Act
    event_source += handler

    # Assert
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers


# Generated at 2022-06-23 13:33:45.399600
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def handler():
        pass
    es += handler
    assert handler in es._handlers


# Generated at 2022-06-23 13:33:53.936290
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    class A:
        pass

    # create a set
    event_source = _EventSource()
    event_source += A.__new__

    # re-add one that's already there
    event_source += A.__new__
    assert len(event_source._handlers) == 1

    # add two, ensure we can remove one
    event_source += lambda: None
    event_source -= A.__new__
    assert len(event_source._handlers) == 1

    # ensure we can only add callables
    try:
        event_source += 'hello'
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-23 13:33:58.433771
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestPlugin(with_metaclass(_AnsibleCollectionConfig)):
        pass
    instance = TestPlugin()
    assert isinstance(instance._on_collection_load, _EventSource)

test__AnsibleCollectionConfig()  # pylint: disable=no-value-for-parameter

# Generated at 2022-06-23 13:34:04.469633
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestClass(_AnsibleCollectionConfig):
        pass

    cls = TestClass('meta', 'name', 'bases')
    assert cls._collection_finder is None
    assert getattr(cls, 'collection_finder') is None
    assert cls._default_collection is None
    assert cls._on_collection_load is not None
    assert getattr(cls, 'on_collection_load') is not None



# Generated at 2022-06-23 13:34:08.652862
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    # Create a simple handler function
    def handler():
        print('handler')

    event_source += handler
    event_source -= handler
    event_source.fire()
    event_source -= handler
    event_source.fire()


# Generated at 2022-06-23 13:34:16.789026
# Unit test for constructor of class _EventSource
def test__EventSource():

    def handler1(*args, **kwargs):
        return "handler1"

    def handler2(*args, **kwargs):
        return "handler2"

    def handler3(*args, **kwargs):
        raise Exception('handler3')

    es = _EventSource()

    es += handler1
    es += handler2

    result = []
    result.append(es.fire())
    result.append(es.fire())
    assert result == [handler1(), handler2()]

    es -= handler2
    result = []
    result.append(es.fire())
    assert result == [handler1()]

    es += handler3
    try:
        es.fire()
        assert False
    except Exception:
        pass

    es -= handler3
    try:
        es.fire()
    except Exception:
        assert False

# Generated at 2022-06-23 13:34:27.175374
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es1 = _EventSource()
    def f1():
        return 1
    def f2():
        return 2
    def f3():
        return 3
    es1 += f1
    es1 += f1
    es1 += f2
    es1 += f3

    assert len(es1._handlers) == 3
    assert f1 in es1._handlers
    assert f2 in es1._handlers
    assert f3 in es1._handlers

    es1 -= f1
    assert len(es1._handlers) == 2
    assert f1 not in es1._handlers

    es1 -= f2
    assert len(es1._handlers) == 1
    assert f2 not in es1._handlers

    es1 -= f3
    assert len(es1._handlers) == 0

# Generated at 2022-06-23 13:34:29.383147
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # Confirm singleton behavior
    assert AnsibleCollectionConfig is AnsibleCollectionConfig

# Generated at 2022-06-23 13:34:32.300377
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig.__class__
    except TypeError as e:
        assert False, 'Got unexpected exception {0}'.format(e)



# Generated at 2022-06-23 13:34:42.495586
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import pytest

    class X(_AnsibleCollectionConfig):
        pass

    class Y(_AnsibleCollectionConfig):
        pass

    obj = X()
    assert isinstance(obj, X)
    assert isinstance(obj, _AnsibleCollectionConfig)
    assert obj.__class__ is X
    assert obj._collection_finder is None
    assert obj._default_collection is None

    with pytest.raises(ValueError) as err:
        obj._collection_finder = 'foo'
    assert 'an AnsibleCollectionFinder has already been configured' in to_text(err.value)

    test_collection_paths = 'a'
    test_default_collection = 'b'
    test_on_collection_load = 'c'
    test_playbook_paths = 'd'


# Generated at 2022-06-23 13:34:47.950474
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    num_invocations = 0
    s = _EventSource()

    def _inc():
        nonlocal num_invocations
        num_invocations += 1

    s += _inc
    s.fire()
    assert (num_invocations == 1)
    s.fire()
    assert (num_invocations == 2)
    s -= _inc
    s.fire()
    assert (num_invocations == 2)

# Generated at 2022-06-23 13:34:52.189414
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Unregister a handler that has not been registered.
    def handler():
        pass

    es = _EventSource()
    es -= handler

    # Unregister a handler that has been registered.
    def handler():
        pass

    es = _EventSource()
    es += handler
    es -= handler



# Generated at 2022-06-23 13:34:54.010236
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Test constructor
    _EventSource()



# Generated at 2022-06-23 13:34:59.363749
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self._handlers = set()
            self._on_exception = lambda handler, exc, *args, **kwargs: False

    es = MyEventSource()

    def h1(arg):
        return arg

    es += h1

    assert es._handlers == set([h1])



# Generated at 2022-06-23 13:35:06.590913
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c._collection_finder is None
    assert c._on_collection_load._handlers == set()
    assert c.collection_finder is None
    assert c.collection_paths == []
    assert c.default_collection is None
    assert c.on_collection_load == c._on_collection_load
    assert c.playbook_paths == []

# Generated at 2022-06-23 13:35:09.341558
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    @AnsibleCollectionConfig.on_collection_load.fire
    def my_fire(foo):
        print('I am the function that is fired')
        return foo
    assert my_fire(42) == 42

# Generated at 2022-06-23 13:35:14.321143
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def func1():
        pass

    def func2():
        pass

    def func3():
        pass

    es += func1

    def test_exists(es, func):
        assert func in es._handlers

    test_exists(es, func1)

    es += func2
    es += func3
    es += func3

    test_exists(es, func1)
    test_exists(es, func2)
    test_exists(es, func3)



# Generated at 2022-06-23 13:35:19.361911
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    actual = {}
    class FakeAnsibleCollectionConfig(_AnsibleCollectionConfig):
        def __init__(self, meta, name, bases):
            actual['meta'] = meta
            actual['name'] = name
            actual['bases'] = bases

    FakeAnsibleCollectionConfig(1, 2, 3)

    assert actual['meta'] == 1
    assert actual['name'] == 2
    assert actual['bases'] == 3

# Generated at 2022-06-23 13:35:27.137142
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    _EventSource()._on_exception = lambda h, exc, *args, **kwargs: False

    x = 0
    es = _EventSource()
    es += (lambda: setattr(es, 'foo', 1))
    es += (lambda: setattr(es, 'foo', 2))
    es += (lambda: setattr(es, 'foo', x))
    with pytest.raises(ValueError):
        es += 1
    es.fire()
    assert es.foo == 2


# Generated at 2022-06-23 13:35:31.277244
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)
    assert isinstance(_AnsibleCollectionConfig, type)

    instance = _AnsibleCollectionConfig('SomeMeta', 'CollectionConfig', tuple())
    assert isinstance(instance, type)
    assert issubclass(instance, object)

# Generated at 2022-06-23 13:35:36.333540
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_collections.collection_loader._event_source import _EventSource

    es = _EventSource()
    assert len(es._handlers) == 0

    def handler():
        pass

    es += handler
    assert len(es._handlers) == 1


# Generated at 2022-06-23 13:35:47.255150
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # test a real exception
    event_source = _EventSource()
    test_exception = ValueError('testing exception')

    def _test_handler(ex):
        if ex is test_exception:
            return False
        raise ex

    event_source += _test_handler

    try:
        event_source.fire(test_exception)
        assert False, 'the test_handler did not raise an exception it was supposed to'
    except ValueError:
        pass

    event_source -= _test_handler
    event_source.fire(test_exception)
    assert True, 'the test_handler raised an exception it was not supposed to'

    # test a fake exception
    event_source = _EventSource()
    test_exception = ValueError('testing exception')


# Generated at 2022-06-23 13:35:50.014610
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def print_kwargs(self, **kwargs):
            for k, v in kwargs.items():
                print(k, v)

    ev = _EventSource()
    t = Test()

    ev += t.print_kwargs
    ev.fire(foo=1, bar=2)

# Generated at 2022-06-23 13:35:59.155585
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Foo:
        pass

    e = _EventSource()

    # no handlers, fire should not throw exception
    e.fire()

    # handler should be called with args, kwargs
    handler_called = False
    def handler(*args, **kwargs):
        nonlocal handler_called
        handler_called = True
        assert args == (1, 2, 3)
        assert kwargs == {'a': 10, 'b': 20}

    e += handler
    e.fire(1, 2, 3, a=10, b=20)
    assert handler_called

    # handler should be removed
    handler_called = False
    e -= handler
    e.fire(1, 2, 3, a=10, b=20)
    assert not handler_called

    # handler should return True, which causes exception to be re-

# Generated at 2022-06-23 13:36:07.727877
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ev = _EventSource()

    def handler_a(foo, bar):
        assert foo == 1
        assert bar == 'foo'

    def handler_b(foo, bar):
        assert foo == 1
        assert bar == 'foo'
        raise Exception('doh')

    ev += handler_a
    ev += handler_b

    try:
        ev.fire(1, bar='foo')
        assert False
    except Exception as ex:
        assert str(ex) == 'doh'



# Generated at 2022-06-23 13:36:17.351895
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _Meta(_AnsibleCollectionConfig):
        pass

    class _AnsibleCollectionConfigTestDummy(with_metaclass(_Meta)):
        pass

    # test properties
    assert _AnsibleCollectionConfigTestDummy.collection_finder is None
    assert _AnsibleCollectionConfigTestDummy.default_collection is None
    assert isinstance(_AnsibleCollectionConfigTestDummy.on_collection_load, _EventSource)
    assert _AnsibleCollectionConfigTestDummy.playbook_paths is None

    # test methods
    assert hasattr(_AnsibleCollectionConfigTestDummy, '_require_finder')

# Generated at 2022-06-23 13:36:25.613241
# Unit test for constructor of class _EventSource
def test__EventSource():
    E = _EventSource()

    assert E._handlers == set()
    assert E._on_exception is not None

    def handler1(event_info):
        return event_info

    def handler2(event_info):
        return event_info

    def handler3(event_info):
        return event_info

    handlers = [handler1, handler2, handler3]

    E += handler1
    E += handler2
    E += handler3

    assert E._handlers == set(handlers)

    E -= handler2

    assert E._handlers == (set(handlers) - set([handler2]))

    event_info = 'hello'

    assert E.fire(event_info) is None

    def handler4(event_info):
        return event_info


# Generated at 2022-06-23 13:36:35.688757
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    # use default implementation
    assert es._on_exception == _EventSource._on_exception

    def f1(s):
        pass

    def f2(s):
        pass

    es += f1
    es += f2

    assert len(es._handlers) == 2
    assert f1 in es._handlers
    assert f2 in es._handlers

    es -= f1
    es -= f2

    assert len(es._handlers) == 0
    assert f1 not in es._handlers
    assert f2 not in es._handlers



# Generated at 2022-06-23 13:36:38.482422
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    source += 'hello'
    source.fire('world')

    source -= 'hello'
    source.fire('world')



# Generated at 2022-06-23 13:36:41.498765
# Unit test for constructor of class _EventSource
def test__EventSource():
    x = _EventSource()
    assert hasattr(x, "_handlers")



# Generated at 2022-06-23 13:36:44.818772
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    obj = AnsibleCollectionConfig()

    def test():
        raise NotImplementedError
    assert obj._on_collection_load._on_exception(test, NotImplementedError) == True


# Generated at 2022-06-23 13:36:47.027639
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event += lambda: 1
    event += lambda: 2
    event += lambda: 3
    event.fire()

# Generated at 2022-06-23 13:36:51.233004
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None

    # TODO: check default event handlers
    assert config._on_collection_load._handlers is not None



# Generated at 2022-06-23 13:36:59.333051
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    """Unit test for method __isub__ of class _EventSource"""
    import os
    import sys
    import unittest
    from ansible.module_utils._text import to_bytes

    try:
        import __main__  # pylint: disable=unused-import
    except ImportError:
        __main__ = None

    # This is required so that the unit test can access the Ansible collection loader
    # ansible_collections.ansible.builtin
    if __main__ is None:
        sys.modules['__main__'] = os

    # the unit test will attempt to import this Python module
    import ansible_collections.ansible.builtin

    # Once we have the Python module, this will get us the __dict__ for the AnsibleCollectionConfig class

# Generated at 2022-06-23 13:37:11.788723
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    # used to check that expected handlers are executed when firing event
    def _stub_handler_1(*args, **kwargs):
        _stub_handler_1._args = args
        _stub_handler_1._kwargs = kwargs

    def _stub_handler_2(*args, **kwargs):
        # raise TestException('simulated exception')
        _stub_handler_2._args = args
        _stub_handler_2._kwargs = kwargs

    sut = _EventSource()
    sut += _stub_handler_1
    sut += _stub_handler_2

    # event source should call each event handler and detect errors correctly

    args = (1, 2, 3)

# Generated at 2022-06-23 13:37:18.793180
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # type: () -> None
    ev = _EventSource()

    def handler():
        pass

    ev.__iadd__(handler)
    ev.__iadd__(handler)
    assert len(ev._handlers) == 1

    def handler_2():
        pass

    ev.__iadd__(handler_2)
    assert len(ev._handlers) == 2



# Generated at 2022-06-23 13:37:24.567714
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    es = _EventSource()
    assert not es._handlers

    def handler_1():
        pass

    es += handler_1
    assert handler_1 in es._handlers

    es += handler_1
    assert handler_1 in es._handlers

    def handler_2():
        pass

    es += handler_2
    assert handler_1 in es._handlers
    assert handler_2 in es._handlers

    def handler_3():
        pass

    es.fire()



# Generated at 2022-06-23 13:37:28.277863
# Unit test for constructor of class _EventSource
def test__EventSource():
    # doesn't blow up if it successfully constructs
    x = _EventSource()

    # constructor doesn't return x
    assert x is not _EventSource()

# Generated at 2022-06-23 13:37:39.552406
# Unit test for constructor of class _EventSource
def test__EventSource():
    class MockEventSource(_EventSource):
        def __init__(self, *args, **kwargs):
            super(MockEventSource, self).__init__(*args, **kwargs)
            self.on_exception_call_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.on_exception_call_count += 1

        def handler(self):
            pass

    # Test that a handler must be callable
    es = MockEventSource()
    try:
        es += 'string'
        assert False
    except ValueError:
        pass

    assert len(es._handlers) == 0

    es += es.handler
    assert len(es._handlers) == 1

    # Test that no handlers are removed when the handler being removed is not in the set

# Generated at 2022-06-23 13:37:48.533327
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    count = [0]

    def handler():
        count[0] += 1

    # add a handler to a new event source and increment count
    es += handler
    es.fire()
    assert count[0] == 1, 'Expected count to be incremented after firing event source with handler'

    # add the same handler again; handler not called twice
    es += handler
    es.fire()
    assert count[0] == 2, 'Expected count to be incremented by one after firing event source with duplicate handler'

    # add a non-callable handler; ValueError raised
    try:
        es += {}
        assert False, 'Unexpected success adding non-callable handler'
    except ValueError:
        pass



# Generated at 2022-06-23 13:37:56.732362
# Unit test for constructor of class _EventSource
def test__EventSource():
    def dummy_handler_1(a, b):
        pass

    def dummy_handler_2(c, d):
        pass

    es = _EventSource()
    es += dummy_handler_1
    es += dummy_handler_2
    assert len(es._handlers) == 2
    es -= dummy_handler_1
    assert len(es._handlers) == 1
    es -= dummy_handler_1
    assert len(es._handlers) == 1
    es -= dummy_handler_2
    assert len(es._handlers) == 0


# Generated at 2022-06-23 13:38:03.776447
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert isinstance(es, _EventSource)

    def test_function(s):
        pass

    def test_function2(s):
        pass

    es += test_function
    es += test_function2
    assert len(es._handlers) == 2
    assert callable(es._handlers)


# Generated at 2022-06-23 13:38:13.582249
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    calls = [0, 0]

    def handler1(*args, **kwargs):
        calls[0] += 1

    def handler2(*args, **kwargs):
        calls[1] += 1
        if calls[1] == 1:
            return
        raise TestException()

    es = _EventSource()
    es += handler1
    es += handler2

    es.fire()

    assert calls[0] == 1
    assert calls[1] == 2

    try:
        es.fire()
    except TestException:
        pass
    else:
        assert False, 'TestException not raised'

# Generated at 2022-06-23 13:38:19.365853
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    assert not event._handlers

    handler1 = lambda *args, **kwargs: None
    handler2 = lambda *args, **kwargs: None

    event += handler1
    assert handler1 in event._handlers

    event += handler2
    assert handler2 in event._handlers


# Generated at 2022-06-23 13:38:25.037356
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def h1(*args, **kwargs):
        print('h1')
        print('args = ', args)
        print('kwargs = ', kwargs)

    def h2(*args, **kwargs):
        print('h2')
        print('args = ', args)
        print('kwargs = ', kwargs)

    event += h1
    event += h2
    event.fire('a1', 'a2', 'a3', kw1='v1', kw2='v2')

if __name__ == '__main__':
    test__EventSource_fire()

# Generated at 2022-06-23 13:38:35.808630
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.t = _EventSource()

        def test_empty(self):
            self.t.fire()

        def test_exceptions_not_captured(self):
            def handler():
                raise Exception('handler failed')

            self.t += handler

            with self.assertRaises(Exception):
                self.t.fire()

        def test_handlers_called(self):
            mocks = [
                unittest.mock.Mock(),
                unittest.mock.Mock(),
                unittest.mock.Mock(),
            ]

            for m in mocks:
                self.t += m


# Generated at 2022-06-23 13:38:40.646256
# Unit test for constructor of class _EventSource
def test__EventSource():
    """Check that a new _EventSource object is properly initialized (i.e. not null).
    """
    event_source = _EventSource()
    assert isinstance(event_source, _EventSource)
    assert event_source._handlers is not None


# Generated at 2022-06-23 13:38:41.823985
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-23 13:38:47.714218
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig

    # verify that the EventSource was created
    assert AnsibleCollectionConfig._on_collection_load is not None
    assert hasattr(AnsibleCollectionConfig._on_collection_load, 'fire')
    assert hasattr(AnsibleCollectionConfig._on_collection_load, '__iadd__')
    assert hasattr(AnsibleCollectionConfig._on_collection_load, '__isub__')

# Generated at 2022-06-23 13:38:53.113766
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac_config = AnsibleCollectionConfig()
    assert ac_config._collection_finder is None
    assert ac_config._on_collection_load
    assert ac_config._default_collection is None


# Generated at 2022-06-23 13:38:59.665648
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(self):
        self._test.fired += 1

    def handler2(self):
        raise NotImplementedError()

    def handler3(self):
        self._test.fired += 1

    class _Test:
        def __init__(self):
            self.fired = 0
            self.event = _EventSource()
            self.event += handler1
            self.event += handler2
            self.event += handler3
            self.event._on_exception = lambda self, handler, exc, *args, **kwargs: False
    test = _Test()
    test.event.fire(test)
    assert test.fired == 2, test.fired

# Generated at 2022-06-23 13:39:01.904575
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(_AnsibleCollectionConfig(), _AnsibleCollectionConfig)

# Generated at 2022-06-23 13:39:08.705926
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def test1(a1):
        pass

    def test2(a1):
        pass

    es += test1

    added = False
    for h in es._handlers:
        if h is test1:
            added = True

    assert added

    es -= test1

    removed = False
    for h in es._handlers:
        if h is test1:
            removed = True

    assert not removed

    added = False
    es += test2

    for h in es._handlers:
        if h is test2:
            added = True

    assert added


# Generated at 2022-06-23 13:39:10.189237
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # the noops are to store symbols in the code so they don't get stripped out.
    AnsibleCollectionConfig
    _AnsibleCollectionConfig



# Generated at 2022-06-23 13:39:17.058965
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    value = 0
    var_args = 1
    var_kwargs = 2

    def test_function(*args, **kwargs):
        nonlocal value
        value = value * var_args * var_kwargs + args[0] * kwargs['kwargs']

    event_source = _EventSource()
    event_source += test_function
    event_source.fire(1, kwargs=2)
    assert value == 2



# Generated at 2022-06-23 13:39:21.568743
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Test:
        def __init__(self, name, events):
            self.name = name
            self.events = events

        def __call__(self, *args, **kwargs):
            self.events.append((self.name, args, kwargs))

    def _test(args, kwargs, expected):
        events = []

        test1 = _Test('t1', events)
        test2 = _Test('t2', events)
        test3 = _Test('t3', events)

        sut = _EventSource()
        sut += test1
        sut += test2
        sut += test3

        sut.fire(*args, **kwargs)

        assert events == expected

    # Test

# Generated at 2022-06-23 13:39:24.986664
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert isinstance(c._on_collection_load, _EventSource)
    assert c.collection_finder is None
    assert c.collection_paths is None
    assert c.default_collection is None
    assert c.playbook_paths is None

# Generated at 2022-06-23 13:39:25.966880
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-23 13:39:27.646786
# Unit test for constructor of class _EventSource
def test__EventSource():
    c = _EventSource()
    assert len(c._handlers) == 0

# Generated at 2022-06-23 13:39:31.498314
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig('foo', 'bar', 'baz')
    assert ac._collection_finder is None
    assert ac._on_collection_load is not None
    assert ac._default_collection is None
    assert callable(ac.on_collection_load)



# Generated at 2022-06-23 13:39:33.266268
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert isinstance(event_source, _EventSource)


# Generated at 2022-06-23 13:39:37.918902
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    events = _EventSource()
    evt_count = [0]
    def on_load(coll):
        evt_count[0] += 1
    events += on_load
    events.fire('my_collection')
    assert evt_count[0] == 1


# Generated at 2022-06-23 13:39:38.536108
# Unit test for constructor of class _EventSource
def test__EventSource():
    pass

# Generated at 2022-06-23 13:39:42.717973
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestAnsibleCollectionConfig(_AnsibleCollectionConfig):
        pass

    assert TestAnsibleCollectionConfig._collection_finder is None
    assert TestAnsibleCollectionConfig._default_collection is None
    assert isinstance(TestAnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:39:46.634645
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    subject = _EventSource()
    subject += lambda: None
    subject += lambda: None
    assert len(subject._handlers) == 2


# Generated at 2022-06-23 13:39:50.473208
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not AnsibleCollectionConfig._collection_finder
    assert not AnsibleCollectionConfig._default_collection
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:39:54.779214
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event += handler1

    assert event._handlers == {handler1}

    event += handler2

    assert event._handlers == {handler1, handler2}


# Generated at 2022-06-23 13:40:03.312137
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible_collections.ansible.os_migrate.plugins.module_utils._text import to_text
    from ansible_collections.ansible.os_migrate.plugins.module_utils.collection_loader._collection_finder import _AnsibleCollectionFinder

    from ansible_collections.ansible.os_migrate.plugins.module_utils.collection_loader.legacy_collection_loader import _AnsibleCollectionConfig

    _AnsibleCollectionConfig._collection_finder = None

    _collection_finder = _AnsibleCollectionFinder()
    _collection_finder._n_collection_paths.append(to_text('/base/collection/ansible.os_migrate.plugins.module_utils/1.0.0/'))

# Generated at 2022-06-23 13:40:03.878559
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource()

# Generated at 2022-06-23 13:40:15.289825
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _EventSourceTest(object):
        def __init__(self):
            self._handlers = set()

        def __iadd__(self, handler):
            if not callable(handler):
                raise ValueError('handler must be callable')
            self._handlers.add(handler)
            return self

        def __isub__(self, handler):
            try:
                self._handlers.remove(handler)
            except KeyError:
                pass

            return self

    test = _EventSourceTest()
    assert len(test._handlers) == 0

    def foo():
        pass

    test += foo
    assert len(test._handlers) == 1
    test -= foo
    assert len(test._handlers) == 0

    def bar():
        pass

    assert not hasattr(test, 'bar')



# Generated at 2022-06-23 13:40:25.079230
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    class Class(object):
        __metaclass__ = _AnsibleCollectionConfig

    assert isinstance(Class, _AnsibleCollectionConfig)
    assert Class.collection_finder is None
    assert Class.default_collection is None
    assert isinstance(Class.on_collection_load, _EventSource)

    assert isinstance(Class.__dict__['collection_finder'], property)
    assert isinstance(Class.__dict__['default_collection'], property)
    assert isinstance(Class.__dict__['on_collection_load'], property)

    assert hasattr(Class, 'collection_paths')
    assert hasattr(Class, 'playbook_paths')


# Unit tests for the concrete class

# Generated at 2022-06-23 13:40:31.131707
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def event_handler_1():
        pass

    def event_handler_2():
        pass

    event_source += event_handler_1
    event_source += event_handler_2

    event_source -= event_handler_1

    assert event_handler_1 not in event_source._handlers
    assert event_handler_2 in event_source._handlers

# Generated at 2022-06-23 13:40:40.157499
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')

    try:
        AnsibleCollectionConfig.collection_finder = 'foo'
        raise AssertionError('unexpected success')
    except ValueError:
        pass

    try:
        AnsibleCollectionConfig.on_collection_load = 'foo'
        raise AssertionError('unexpected success')
    except ValueError:
        pass


# Generated at 2022-06-23 13:40:47.178943
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    class TestClass:
        def __init__(self):
            self.dummy_method_called = False
            self.dummy_method_args = None
            self.dummy_method_kwargs = None

        def dummy_method(self, *args, **kwargs):
            self.dummy_method_called = True
            self.dummy_method_args = args
            self.dummy_method_kwargs = kwargs

    instance = TestClass()
    event_source += instance.dummy_method
    dummy_args = (1, 2, 3)
    dummy_kwargs = dict(a=4, b=5, c=6)
    event_source.fire(*dummy_args, **dummy_kwargs)
    assert instance.dummy_method_

# Generated at 2022-06-23 13:40:53.865918
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert len(e._handlers) == 0

    def f1():
        pass
    e += f1
    assert len(e._handlers) == 1

    def f2():
        pass
    e += f2
    assert len(e._handlers) == 2

    with pytest.raises(ValueError):
        e += 'not callable'


# Generated at 2022-06-23 13:40:57.126912
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert_func = _EventSource()
    assert not assert_func.__init__

    assert_func.__init__()

    assert not assert_func.fire

    assert not assert_func.fire

    assert assert_func._on_exception


# Generated at 2022-06-23 13:40:59.877965
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()

    assert len(event_source._handlers) == 0



# Generated at 2022-06-23 13:41:03.759315
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    value = 0

    def handler(*args, **kwargs):
        nonlocal value
        value = 1

    event = _EventSource()
    event += handler
    assert value == 0

    event.fire()
    assert value == 1


# Generated at 2022-06-23 13:41:04.399199
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()

# Generated at 2022-06-23 13:41:10.909187
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    handler_1 = lambda: True
    handler_2 = lambda: None

    event_source += handler_1
    assert len(event_source._handlers) == 1
    assert handler_1 in event_source._handlers

    event_source += handler_1
    assert len(event_source._handlers) == 1
    assert handler_1 in event_source._handlers

    event_source += handler_2
    assert len(event_source._handlers) == 2
    assert handler_1 in event_source._handlers
    assert handler_2 in event_source._handlers

    event_source += handler_2
    assert len(event_source._handlers) == 2
    assert handler_1 in event_source._handlers


# Generated at 2022-06-23 13:41:16.488129
# Unit test for constructor of class _EventSource
def test__EventSource():
    # construct an instance of _EventSource
    event_source = _EventSource()
    # construct an event handler
    def handler():
        pass
    # call the += operator
    event_source += handler
    # verify that the event handler was successfully added
    assert handler in event_source._handlers
    # call the -= operator
    event_source -= handler
    # verify that the event handler was successfully removed
    assert handler not in event_source._handlers


# Generated at 2022-06-23 13:41:17.806168
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()

    assert ac.collection_finder is None, ac.collection_finder
    assert ac.playbook_paths is None, ac.playbook_paths

# Generated at 2022-06-23 13:41:25.912657
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        """ A subclass of _EventSource that is only used for testing purpose.
            It allows to throw exceptions.
        """
        def __init__(self):
            super(MyEventSource, self).__init__()

        def _on_exception(self, handler, exc, *args, **kwargs):
            if handler == handler1:
                # raise the exception
                return False

    # The handlers
    def handler1(*args, **kwargs):
        raise RuntimeError('handler1 raised an exception')

    def handler2(*args, **kwargs):
        pass

    # The test code
    event_source = MyEventSource()
    event_source += handler1
    event_source += handler2

    # Fire the event source
    event_source.fire()

    # This test must not fail

# Generated at 2022-06-23 13:41:27.589044
# Unit test for constructor of class _EventSource
def test__EventSource():
    handler = lambda: None
    event_source = _EventSource()
    event_source += handler
    assert handler in event_source._handlers


# Generated at 2022-06-23 13:41:29.753146
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)


# Generated at 2022-06-23 13:41:35.684073
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Test(_EventSource):
        # C0103: Method name does not conform to snake_case naming style (invalid-name)
        # C0111: Missing docstring in public method (missing-docstring)
        def __init__(self):
            self.called = 0

        def on(self, _):
            self.called += 1

    t = _Test()
    t += t.on
    assert t.called == 0
    t.fire()
    assert t.called == 1

# Generated at 2022-06-23 13:41:39.520058
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    def my_handler(a, b):
        print('my_handler')

    es += my_handler

    print(es)
    es.fire(1, 2)

# Generated at 2022-06-23 13:41:41.037846
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    event_source += event_source.fire

    event_source.fire()

# Generated at 2022-06-23 13:41:43.255859
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert e  # verify instance successfully created
    assert not e._handlers  # verify instance has empty set


# Generated at 2022-06-23 13:41:52.773365
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MockAnsibleCollectionConfig(_AnsibleCollectionConfig):
        pass

    assert not hasattr(MockAnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(MockAnsibleCollectionConfig, '_default_collection')
    assert not hasattr(MockAnsibleCollectionConfig, '_on_collection_load')

    config = MockAnsibleCollectionConfig('meta', 'name', ('base',))

    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:42:00.478067
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest

    class _EventHandler:
        def __init__(self):
            self._events = 0

        def handle(self, *args, **kwargs):
            self._events += 1

    source = _EventSource()
    h1 = _EventHandler()
    h2 = _EventHandler()

    source += h1.handle
    source += h2.handle

    source.fire()
    source.fire()

    assert h1._events == 2
    assert h2._events == 2

    source -= h1.handle

    source.fire()

    assert h1._events == 2
    assert h2._events == 3

    with pytest.raises(ValueError, match=r'handler must be callable'):
        source += h1



# Generated at 2022-06-23 13:42:01.955332
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    test_object = _EventSource()
    test_object.fire()

# Generated at 2022-06-23 13:42:13.226671
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class EvilException(Exception):
        pass

    class NoException(Exception):
        pass

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        raise EvilException('oops')

    def handler4(*args, **kwargs):
        raise NoException('noop')

    def on_exception(handler, ex, *args, **kwargs):
        if not isinstance(ex, EvilException):
            return False

    es = _EventSource()

    es += handler1
    es += handler2
    es += handler3
    es += handler4
    es._on_exception = on_exception

    es.fire()

    assert handler1 in es._handlers
    assert handler2 in es._handlers


# Generated at 2022-06-23 13:42:24.875850
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def __init__(self, expected_handler_count=None):
            super(EventSource, self).__init__()
            self.fired_count = 0
            self.expected_handler_count = expected_handler_count

        def fire(self, *args, **kwargs):
            self.fired_count += 1
            super(EventSource, self).fire(*args, **kwargs)

        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    # test that the event source fires
    es = EventSource()
    assert es.fired_count == 0
    assert len(es._handlers) == 0
    es.fire()
    assert es.fired_count == 1
    assert len(es._handlers) == 0

    # capture the

# Generated at 2022-06-23 13:42:29.451572
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def add_one(x):
        return x + 1

    ev = _EventSource()
    try:
        ev += add_one
    except:
        pytest.fail(msg='_EventSource.__iadd__() failed to add a callable')


# Generated at 2022-06-23 13:42:31.376330
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()
    assert ev._handlers == set()


# Generated at 2022-06-23 13:42:34.086196
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    foo = AnsibleCollectionConfig()
    assert foo._collection_finder is None
    assert foo._default_collection is None

    foo.collection_finde

# Generated at 2022-06-23 13:42:40.316903
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_event = _EventSource()
    test_handler = lambda x: None
    test_event += test_handler
    test_event.fire('data')  # should not raise an exception
    try:
        test_event.fire(data='data')  # should raise a TypeError exception
    except TypeError:
        pass
    else:
        assert False, "test__EventSource_fire failed"


# Generated at 2022-06-23 13:42:47.228413
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _EventSource.test = lambda x, y: x + y
    _EventSource.test2 = lambda x, y: x - y
    _EventSource.test3 = lambda x, y: x * y
    _EventSource.test4 = lambda x, y: x / y
    _EventSource.test5 = lambda x, y: x % y
    _EventSource.test6 = lambda a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p: \
        a + b + c + d + e + f + g + h + i + j + k + l + m + n + o + p

    callbacks = _EventSource()

    callbacks += _EventSource.test
    callbacks += _EventSource.test2
    callbacks += _EventSource.test

# Generated at 2022-06-23 13:42:50.101361
# Unit test for constructor of class _EventSource
def test__EventSource():
    source = _EventSource()
    assert not source._handlers
    handler = lambda: None

    source += handler
    assert handler in source._handlers



# Generated at 2022-06-23 13:42:52.908317
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += (lambda x: True)

    with pytest.raises(ValueError):
        event += 45



# Generated at 2022-06-23 13:43:01.373560
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(): pass
    def handler_with_signature(pos_arg, *args, **kwargs): pass

    try:
        _EventSource() + 'not callable'
    except ValueError:
        pass
    else:
        failed('Failed to raise ValueError when adding a non-callable.')

    try:
        _EventSource() - 'not callable'
    except KeyError:
        pass
    else:
        failed('Failed to raise KeyError when removing a non-callable.')

    try:
        _EventSource() - 'not callable'
    except KeyError:
        pass
    else:
        failed('Failed to raise KeyError when removing a non-callable.')

    es = _EventSource()
    es += handler
    es += handler_with_signature


# Generated at 2022-06-23 13:43:06.806228
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Create and set an event source.
    handler = lambda: None
    on_collection_load = AnsibleCollectionConfig.on_collection_load
    on_collection_load += handler

    assert handler in on_collection_load._handlers

    # Remove the event handler.
    on_collection_load -= handler

    assert handler not in on_collection_load._handlers



# Generated at 2022-06-23 13:43:09.014152
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    def handler(a):
        return None

    source += handler
    source.fire(1)



# Generated at 2022-06-23 13:43:18.169579
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, type)
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

    try:
        AnsibleCollectionConfig.collection_finder = None
        assert False
    except ValueError:
        pass  # expected

    try:
        AnsibleCollectionConfig.default_collection = None
        assert False
    except ValueError:
        pass  # expected

    try:
        AnsibleCollectionConfig.on_collection_load = None
        assert False
    except ValueError:
        pass  # expected

    try:
        AnsibleCollectionConfig.collection_paths
        assert False
    except NotImplementedError:
        pass  # expected
