

# Generated at 2022-06-23 13:33:14.997267
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    def foo():
        pass

    with AnsibleCollectionConfig.on_collection_load as handler:
        handler += foo
        handler += foo
        handler -= foo
    # no assert is possible here



# Generated at 2022-06-23 13:33:17.084379
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None



# Generated at 2022-06-23 13:33:25.579269
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    assert not hasattr(s, '_EventSource___iadd__')

    def f1(a):
        print(a)

    s += f1
    assert hasattr(s, '_EventSource___iadd__')
    assert callable(s._EventSource___iadd__)
    assert s._EventSource___iadd__ is f1

    def g1(a):
        print(a)

    s += g1
    assert hasattr(s, '_EventSource___iadd__')
    assert callable(s._EventSource___iadd__)
    assert (s._EventSource___iadd__ is f1) or (s._EventSource___iadd__ is g1)



# Generated at 2022-06-23 13:33:28.604856
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    sources = {
        'missing': _EventSource(),
        'present': _EventSource(),
    }
    sources['present'] += lambda: None
    sources['present'] -= sources['present']
    assert sources['present']._handlers == set()

# Generated at 2022-06-23 13:33:30.316647
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source._handlers == set()

# Generated at 2022-06-23 13:33:34.187785
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    h1 = lambda: None
    es += h1
    assert len(es._handlers) == 1
    es -= h1
    assert len(es._handlers) == 0


# Generated at 2022-06-23 13:33:43.613883
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import copy
    import types

    class _TestEventSource(_EventSource):
        def __init__(self):
            self._handlers = []

    def dummy_handler(arg):
        """ignore"""

    def dummy_handler_exception(arg):
        """Dummy handler that raises an exception."""
        raise RuntimeError('dummy_handler_exception')

    def _on_exception(self, handler, exc, *args, **kwargs):
        """ignore"""

    class _TestOnExceptionEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return True

    class _TestOnExceptionEventSource_Ignore(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            self._handlers.remove

# Generated at 2022-06-23 13:33:51.200427
# Unit test for constructor of class _EventSource
def test__EventSource():
    # This test only verifies that the constructor of class _EventSource
    # dind not change, which means the change of this test needs to
    # consistently reflect in both controller and ansible-test
    def handler():
        pass

    test_event_source = _EventSource()
    assert set() == test_event_source._handlers

    test_event_source += handler
    assert {handler} == test_event_source._handlers

    test_event_source -= handler
    assert set() == test_event_source._handlers



# Generated at 2022-06-23 13:33:53.879943
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler():
        pass

    handlers = _EventSource()
    handlers += handler

    with pytest.raises(KeyError):
        handlers -= handler
        handlers -= handler

# Generated at 2022-06-23 13:33:56.098045
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config is not None

# Generated at 2022-06-23 13:34:03.018847
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def total_count(count):
        def handler(self):
            self.count += count
        return handler

    class EventHandler:
        count = 0
        handler = total_count(1)

    event += EventHandler.handler

    assert EventHandler.count == 0
    event.fire()
    assert EventHandler.count == 1

    event -= EventHandler.handler

    assert EventHandler.count == 1
    event.fire()
    assert EventHandler.count == 1


# Generated at 2022-06-23 13:34:05.825750
# Unit test for constructor of class _EventSource
def test__EventSource():
    def my_handler():
        pass

    event = _EventSource()
    event._handlers = set([my_handler])
    assert event._handlers == {my_handler}
    event = None


# Generated at 2022-06-23 13:34:13.152850
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_test.mock.patch import MockPatch

    event_source = _EventSource()

    import sys
    old_excepthook = sys.excepthook

    def install():
        # prevent any error hanling from being invoked
        sys.excepthook = lambda exctype, value, traceback: None

    def restore():
        sys.excepthook = old_excepthook

    with MockPatch([(__name__ + '.install', install), (__name__ + '.restore', restore)]):
        event_source.fire()

        def handler(a, b):
            if a == 'a':
                if b == 'b':
                    return

            raise ValueError('unexpected')

        event_source += handler
        event_source.fire('a', b='b')

# Generated at 2022-06-23 13:34:24.518801
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(sender, *args, **kwargs):
        pass

    assert callable(handler)

    event_source = _EventSource()
    event_source += handler
    event_source -= handler

    event_source.fire()
    event_source.fire('test_arg')
    event_source.fire(test_kwarg='test_arg')
    event_source.fire('test_arg', test_kwarg='test_arg')

    class TestException(Exception):
        pass

    class TestHandler:
        def __call__(self, sender, *args, **kwargs):
            raise TestException('This exception is intentionally raised')

    on_exception_called = False
    def on_exception(handler, exc, *args, **kwargs):
        nonlocal on_exception_called

# Generated at 2022-06-23 13:34:26.657430
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config is not None

# Unit test that sets _AnsibleCollectionConfig properties

# Generated at 2022-06-23 13:34:30.587341
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load._handlers == set()


# Generated at 2022-06-23 13:34:31.950200
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from . import AnsibleCollectionConfig

# Generated at 2022-06-23 13:34:40.943024
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    es -= None
    assert es._handlers == set()

    es = _EventSource()
    es += None
    es -= None
    assert es._handlers == set()

    def a():
        pass

    es = _EventSource()
    es += None
    es += a
    es -= a
    assert es._handlers == set([None])
    es -= None
    assert es._handlers == set()

    es = _EventSource()
    es += 1
    es += 2
    es -= 1
    assert es._handlers == set([2])
    es -= 2
    assert es._handlers == set()


# Generated at 2022-06-23 13:34:43.962735
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    assert AnsibleCollectionConfig._on_collection_load._on_exception(
        lambda: None,
        RuntimeError('test exception')
    )

# Generated at 2022-06-23 13:34:50.543419
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.test.lib.test_util.test_target.legacy_collection_loader.event_source_test_class import TestClass
    test_obj = TestClass()

    global test_method_fired
    test_method_fired = False
    def test_method(*args, **kwargs):
        global test_method_fired
        test_method_fired = True
        return True

    test_obj.on_collection_load += test_method
    test_obj.on_collection_load.fire()
    assert test_method_fired


# Generated at 2022-06-23 13:34:57.544253
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    instance = _EventSource()
    called = [False]

    def handler(sender, **kwargs):
        assert instance == sender
        assert 'test' in kwargs
        assert kwargs['test'] == 'hello'
        called[0] = True

    instance += handler
    instance.fire(test='hello')
    assert called[0]

    instance -= handler
    called[0] = False
    instance.fire(test='hello')
    assert not called[0]

# Generated at 2022-06-23 13:35:04.694379
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    assert not es._handlers

    event = lambda: None

    es += event
    assert len(es._handlers) == 1
    assert event in es._handlers

    es -= event
    assert not es._handlers
    assert event not in es._handlers

    es -= event
    assert not es._handlers
    assert event not in es._handlers

# Generated at 2022-06-23 13:35:10.076660
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    class TestAnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert hasattr(TestAnsibleCollectionConfig, 'collection_finder')
    assert isinstance(TestAnsibleCollectionConfig.collection_finder, property)

    assert hasattr(TestAnsibleCollectionConfig, 'default_collection')
    assert isinstance(TestAnsibleCollectionConfig.default_collection, property)

    assert hasattr(TestAnsibleCollectionConfig, 'on_collection_load')
    assert isinstance(TestAnsibleCollectionConfig.on_collection_load, property)

    assert hasattr(TestAnsibleCollectionConfig, 'collection_paths')
    assert isinstance(TestAnsibleCollectionConfig.collection_paths, property)

    assert hasattr(TestAnsibleCollectionConfig, 'playbook_paths')

# Generated at 2022-06-23 13:35:16.149123
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _EventSource___iadd__(lambda: None)
    _EventSource___iadd__(lambda x: None)
    _EventSource___iadd__(lambda x, y: None)
    _EventSource___iadd__(lambda x, y, z: None)
    _EventSource___iadd__(lambda a, b, c, d: None)



# Generated at 2022-06-23 13:35:17.943019
# Unit test for constructor of class _EventSource
def test__EventSource():

    class EventSource(_EventSource):
        pass

    assert EventSource()._handlers == set()



# Generated at 2022-06-23 13:35:28.901396
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _TestEventSource(_EventSource):
        def __init__(self):
            self._called = 0
            super(_TestEventSource, self).__init__()

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._called += 1
            return True

    def handler(a, b=1):
        nonlocal call_count
        call_count += 1

    call_count = 0
    ev = _TestEventSource()

    ev += handler
    ev -= handler
    ev.fire()
    assert call_count == 1

    ev.fire('a', b=1)
    assert call_count == 2

    ev.fire(b=1)
    assert call_count == 3

    ev.fire('a')
    assert call_count == 4


# Generated at 2022-06-23 13:35:31.327458
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    instance = _EventSource()
    handler = lambda x, y: None
    instance += handler
    assert instance._handlers == {handler}

# Generated at 2022-06-23 13:35:39.811802
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source_test = _EventSource()
    def handler1():
        pass
    event_source_test.__iadd__(handler1)
    event_source_test.__isub__(handler1)
    def handler2():
        pass
    event_source_test.__isub__(handler2)
    event_source_test.__iadd__(handler2)
    event_source_test.__isub__(handler2)

# Unit tests for class _AnsibleCollectionConfig

# Generated at 2022-06-23 13:35:45.579185
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    assert not event_source._handlers

    handler1 = lambda: None
    handler2 = lambda: None
    event_source += handler1
    event_source += handler2
    assert event_source._handlers == {handler1, handler2}

    event_source -= handler1
    assert event_source._handlers == {handler2}

    event_source -= handler2
    assert not event_source._handlers

# Generated at 2022-06-23 13:35:49.385517
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    m = _EventSource()
    assert m._handlers == set()

    # attempt to remove handler that's not present
    m -= print
    assert m._handlers == set()

    m += print
    assert m._handlers == {print}
    m -= print
    assert m._handlers == set()



# Generated at 2022-06-23 13:35:55.491083
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def h1(*args, **kwargs):
        print('h1 called with %s and %s' % (args, kwargs))

    def h2(*args, **kwargs):
        print('h2 called with %s and %s' % (args, kwargs))
        raise Exception

    event_source = _EventSource()
    event_source += h1
    event_source += h2

    event_source.fire(1, 2)



# Generated at 2022-06-23 13:36:00.009674
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    target = _EventSource()
    def handler():
        pass

    result = target.__iadd__(handler)

    assert result == target
    assert handler in target._handlers



# Generated at 2022-06-23 13:36:03.593427
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert hasattr(event_source, '_handlers')
    assert len(event_source._handlers) == 0



# Generated at 2022-06-23 13:36:08.527199
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def handler(foo, bar):
        pass
    event_source += handler
    assert handler in event_source._handlers
    event_source -= handler
    assert handler not in event_source._handlers
    event_source -= handler  # should not raise KeyError


# Generated at 2022-06-23 13:36:12.451310
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestClass:
        executed = False

        @classmethod
        def handler(cls, *args, **kwargs):
            cls.executed = True

    result = TestClass.executed
    assert result == False

    event = _EventSource()
    event += TestClass.handler
    event.fire()

    result = TestClass.executed
    assert result == True

# Generated at 2022-06-23 13:36:16.502574
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    # Test setup
    test_event_source = _EventSource()
    dummy_handler = lambda: None

    # Test execution
    test_event_source.__iadd__(dummy_handler)
    test_event_source.__isub__(dummy_handler)

    # Test verification
    assert dummy_handler not in test_event_source._handlers



# Generated at 2022-06-23 13:36:18.152162
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None



# Generated at 2022-06-23 13:36:21.250541
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # https://www.python.org/dev/peps/pep-0484/#other-uses-for-type-checking
    assert isinstance(AnsibleCollectionConfig, type)
    assert issubclass(AnsibleCollectionConfig, object)

# Generated at 2022-06-23 13:36:26.314322
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder
    assert config.on_collection_load
    assert config._default_collection is None
    assert config.collection_paths
    assert config.playbook_paths


# TODO: Refactor AnsibleCollectionConfig to not be an implementation of Singleton and then eliminate the need for this module.

# Generated at 2022-06-23 13:36:38.524614
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

    on_coll_load = AnsibleCollectionConfig.on_collection_load
    assert isinstance(on_coll_load, _EventSource)
    assert on_coll_load is AnsibleCollectionConfig._on_collection_load


# --------------------------------------------------------------------------------------


# CAUTION: There are two implementations of the collection loader.
#          They must be kept functionally identical, although their implementations may differ.
#
# 1) The controller implementation resides in the "lib/ansible/utils/collection_loader/" directory.
#    It must function on all Python versions supported on the controller.
# 2) The ansible-test implementation resides in the "test/lib/ansible_test/_util/target/legacy_collection_loader/" directory.
#    It must function on

# Generated at 2022-06-23 13:36:43.558687
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible.utils.collection_loader._event_source import _EventSource

    def handler1(evt):
        pass

    es = _EventSource()
    es += handler1
    es -= handler1
    es -= handler1


# Generated at 2022-06-23 13:36:47.330793
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    s = _EventSource()
    h = lambda: 'foo'
    s += h
    assert h in s._handlers

    s -= h
    assert h not in s._handlers

    s -= h
    assert h not in s._handlers



# Generated at 2022-06-23 13:36:50.006975
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # __iadd__ returns the instance, so we can chain them
    assert _EventSource().__iadd__(None) is not None



# Generated at 2022-06-23 13:36:52.621302
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    obj = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert obj._collection_finder is None
    assert obj._default_collection is None

# Generated at 2022-06-23 13:36:58.701903
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, property)
    assert AnsibleCollectionConfig._collection_finder is not None
    assert isinstance(AnsibleCollectionConfig._default_collection, property)
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)



# Generated at 2022-06-23 13:37:06.313433
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # testcase 1:
    # if no exception occurred, just return
    test_object = _EventSource()
    test_object.fire()

    # testcase 2:
    # if an exception occurred, re-raise it
    test_object = _EventSource()
    test_object += lambda : 1/0
    try:
        test_object.fire()
    except:
        pass


# Generated at 2022-06-23 13:37:10.459533
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig()
    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert ac._on_collection_load is not None
    assert issubclass(ac._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:37:14.755490
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def foo():
        pass

    e = _EventSource()

    assert foo not in e._handlers

    e.__iadd__(foo)

    assert foo in e._handlers

    e.__isub__(foo)

    assert foo not in e._handlers

    e.__isub__(foo)

    assert foo not in e._handlers

# Generated at 2022-06-23 13:37:18.205889
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda x: x
    event += lambda x: x
    assert len(event._handlers) == 2
    event -= event._handlers.pop()
    assert len(event._handlers) == 1



# Generated at 2022-06-23 13:37:23.240185
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    @contextmanager
    def setUp(self):
        self.sec = _EventSource()

    @contextmanager
    def tearDown(self):
        del self.sec

    @contextmanager
    def test_remove_handler(self):
        def event_handler():
            pass

        event_handler in self.sec
        self.sec -= event_handler
        event_handler in self.sec


# Generated at 2022-06-23 13:37:25.064913
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # Creating an instance of the class
    config = AnsibleCollectionConfig()
    # Testing if the _EventSource constructor called
    assert config._on_collection_load._handlers == set()

# Generated at 2022-06-23 13:37:29.108492
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    target = []
    event_source += lambda: target.append(True)
    event_source.fire()
    assert target == [True]

# Generated at 2022-06-23 13:37:34.595557
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def call_me(*args, **kwargs):
        return args, kwargs

    e = _EventSource()
    e += call_me
    args, kwargs = e.fire(1, 2, 3, foo='bar')
    assert args == (1, 2, 3)
    assert kwargs == {'foo': 'bar'}

# Generated at 2022-06-23 13:37:44.644581
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # no exception
    x = _EventSource()
    x.fire()

    # 1 handler
    x = _EventSource()
    calls = []
    handler = lambda: calls.append(1)

    x += handler
    x.fire()

    assert calls == [1]

    # 2 handlers
    x = _EventSource()
    calls = []
    handler1 = lambda: calls.append(1)
    handler2 = lambda: calls.append(2)

    x += handler1
    x += handler2

    x.fire()
    assert calls == [1, 2]

    # 2 handlers, one raises an exception
    x = _EventSource()
    calls = []
    handler1 = lambda: calls.append(1)
    handler2 = lambda: (calls.append(2), 1 / 0)

    x += handler

# Generated at 2022-06-23 13:37:45.581106
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    pass


# Generated at 2022-06-23 13:37:57.404172
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    source = _EventSource()

    class TestException(Exception):
        pass

    def _test_handler(arg):
        return arg

    def _test_handler_raises(arg):
        raise Exception(arg)

    def _test_handler_raises_test_exception(arg):
        raise TestException(arg)

    def _test_handler_raises_test_exception_and_returns_false(arg):
        raise TestException(arg)
        return False

    def _test_handler_raises_test_exception_and_returns_true(arg):
        raise TestException(arg)
        return True

    def _test_handler_returns_false(arg):
        return False

    def _test_handler_returns_true(arg):
        return True

    source += _test_handler


# Generated at 2022-06-23 13:38:04.421554
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_paths == []
    assert config.playbook_paths == []
    assert config.on_collection_load is not None

    # set the collection_paths, playbook_paths and default_collection properties
    collection_paths = ['/path/to/collection']
    config.collection_finder = object()
    config.collection_paths = collection_paths
    playbook_paths = ['/path/to/playbook']
    config.playbook_paths = playbook_paths
    config.default_collection = 'namespace.collection'

    # retrieve the values we previously set
    assert config.collection_paths == collection_paths
    assert config.playbook_paths == playbook_paths
    assert config.default_collection == 'namespace.collection'

# Generated at 2022-06-23 13:38:11.233420
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig = _AnsibleCollectionConfig('test_AnsibleCollectionConfig', (object,), {'__module__': __name__})
    cls = AnsibleCollectionConfig('test_AnsibleCollectionConfig', (object,), {})

    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert cls._on_collection_load


# Generated at 2022-06-23 13:38:23.170406
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    class Handler:
        def __init__(self):
            self.event_count = 0

        def __call__(self, *args, **kwargs):
            self.event_count += 1
            self.args = args
            self.kwargs = kwargs

    def _to_list(x):
        return [x] if x else []

    handler1 = Handler()
    handler2 = Handler()

    event_source += handler1
    event_source += handler2

    event_source.fire(1, 2, 3, a=4)

    assert handler1.event_count == 1
    assert handler1.args == (1, 2, 3)
    assert handler1.kwargs == dict(a=4)

    assert handler2.event_count == 1
    assert handler2

# Generated at 2022-06-23 13:38:24.871904
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig


# Generated at 2022-06-23 13:38:34.884600
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    d = dict()
    _EventSource.__iadd__(d, 'hello')
    _EventSource.__iadd__(d, 'world')
    _EventSource.__iadd__(d, 'hello')
    _EventSource.__iadd__(d, 'world')
    _EventSource.__iadd__(d, 'hello')
    _EventSource.__iadd__(d, 'world')
    _EventSource.__iadd__(d, 'hello')
    _EventSource.__iadd__(d, 'world')
    _EventSource.__iadd__(d, 'hello')
    _EventSource.__iadd__(d, 'world')
    _EventSource.__iadd__(d, 'hello')
    _EventSource.__iadd__(d, 'world')
   

# Generated at 2022-06-23 13:38:46.084864
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_collections.ansible.community.plugins.module_utils.basic import AnsibleModule

    event_source = _EventSource()

    # test an invalid handler
    try:
        event_source += 'not a callable'
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # test a callable handler
    def handler(ansible_module):
        raise ValueError('exception deliberately raised in handler')

    event_source += handler

    # test that the handler is called
    try:
        event_source.fire(AnsibleModule())
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')



# Generated at 2022-06-23 13:38:47.060314
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()



# Generated at 2022-06-23 13:38:52.590301
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common._collections_compat import Mapping

    class _MockEventSource(_EventSource):
        def __init__(self, drop_index):
            super(_MockEventSource, self).__init__()
            self._drop_index = drop_index
            self._call_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            raise Exception('unexpected error')

        def fire(self, *args, **kwargs):
            try:
                self._call_count += 1
                return super(_MockEventSource, self).fire(*args, **kwargs)
            finally:
                self._call_count -= 1


# Generated at 2022-06-23 13:38:55.563181
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)
    assert AnsibleCollectionConfig.playbook_paths == []

# Generated at 2022-06-23 13:38:58.425386
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert isinstance(AnsibleCollectionConfig(), AnsibleCollectionConfig)


# Generated at 2022-06-23 13:39:02.799297
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    test_config = AnsibleCollectionConfig()
    # Python 2 and Python 3 metaclass implementations are the same
    assert isinstance(test_config, _AnsibleCollectionConfig)


# Generated at 2022-06-23 13:39:09.994923
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MyConfig(with_metaclass(_AnsibleCollectionConfig)):
        class _EventSource:
            def __init__(self):
                self._handlers = set()

            def __iadd__(self, handler):
                if not callable(handler):
                    raise ValueError('handler must be callable')
                self._handlers.add(handler)
                return self

            def __isub__(self, handler):
                try:
                    self._handlers.remove(handler)
                except KeyError:
                    pass

                return self

            def _on_exception(self, handler, exc, *args, **kwargs):
                # if we return True, we want the caller to re-raise
                return True


# Generated at 2022-06-23 13:39:11.819757
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert e._handlers == set()



# Generated at 2022-06-23 13:39:13.740246
# Unit test for constructor of class _EventSource
def test__EventSource():
    ES = _EventSource()
    assert(isinstance(ES, object))


# Generated at 2022-06-23 13:39:17.704278
# Unit test for constructor of class _EventSource
def test__EventSource():
    def on_collection_load(collection_name, collection_version):
        pass

    event_source = _EventSource()
    event_source += on_collection_load
    assert on_collection_load in event_source._handlers


# Generated at 2022-06-23 13:39:19.578492
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class AnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass


__all__ = ('AnsibleCollectionConfig',)

# Generated at 2022-06-23 13:39:24.530434
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.playbook_paths is None

# Generated at 2022-06-23 13:39:30.688769
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    """
    _EventSource.__iadd__ should return itself, so you can use += in a chain to add multiple handlers
    """
    count = [0]  # mutable
    event_source = _EventSource()

# Generated at 2022-06-23 13:39:32.360321
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None



# Generated at 2022-06-23 13:39:34.795591
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def testMethod():
        pass

    es = _EventSource()
    es += testMethod
    assert es._handlers == set([testMethod])

# Generated at 2022-06-23 13:39:44.610955
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test 1: fire handlers
    event_source = _EventSource()

    called = False

    def handler(*args, **kwargs):
        nonlocal called
        called = True

    event_source += handler
    event_source.fire()

    assert called

    # test 2: handle exceptions
    event_source = _EventSource()
    called = False

    def handler(*args, **kwargs):
        raise ValueError('the sky is falling')

    def on_exception(exc, handler):
        nonlocal called
        assert isinstance(exc, ValueError)
        assert handler == handler
        called = True
        return False

    event_source._on_exception = on_exception
    event_source += handler
    event_source.fire()

    assert called

    # test 3: re-raise

# Generated at 2022-06-23 13:39:55.141140
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler1(foo):
        pass

    def handler2(foo):
        pass

    handler2_copy = handler2

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers

    event_source -= handler2

    assert handler1 in event_source._handlers
    assert handler2 not in event_source._handlers

    event_source -= handler2_copy

    assert handler1 in event_source._handlers
    assert handler2 not in event_source._handlers


# Generated at 2022-06-23 13:39:56.853775
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class TestAnsibleCollectionConfig(AnsibleCollectionConfig):
        def __init__(self):
            pass
    ac = TestAnsibleCollectionConfig()
    assert ac._collection_finder is None


# Generated at 2022-06-23 13:39:58.625352
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pass


# Generated at 2022-06-23 13:40:11.427607
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(a, b, c):
        nonlocal expected_args
        nonlocal expected_kwargs
        nonlocal orig_handler
        assert (a, b, c) == expected_args, (a, b, c, expected_args)
        assert dict(**kwargs) == dict(**expected_kwargs), (kwargs, expected_kwargs)
        orig_handler(*args, **kwargs)

    orig_handler = lambda a, b, c: True


# Generated at 2022-06-23 13:40:17.329062
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler():
        pass

    evs = _EventSource()
    evs += handler

    assert len(evs._handlers) == 1
    assert handler in evs._handlers

    evs -= handler

    assert len(evs._handlers) == 0
    assert handler not in evs._handlers



# Generated at 2022-06-23 13:40:29.144282
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig.collection_finder is AnsibleCollectionConfig._collection_finder
    assert AnsibleCollectionConfig.default_collection is AnsibleCollectionConfig._default_collection
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollectionConfig._on_collection_load

    try:
        AnsibleCollectionConfig.collection_finder = True
        raise AssertionError('expected ValueError')
    except ValueError:
        pass

    try:
        AnsibleCollectionConfig.default_collection = True
        raise AssertionError('expected ValueError')
    except ValueError:
        pass


# Generated at 2022-06-23 13:40:33.562538
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    var = []
    def handler(a):
        var.append(a)
    event = _EventSource()
    event += handler
    event.fire(1)
    event.fire(2)
    event.fire(3)
    assert var == [1, 2, 3]



# Generated at 2022-06-23 13:40:38.891948
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class EventSourceTest:
        def __init__(self):
            self._on_event = _EventSource()

        @property
        def on_event(self):
            return self._on_event

        def fire(self, *args, **kwargs):
            self._on_event.fire(*args, **kwargs)

    collector1 = []
    collector2 = []

    es = EventSourceTest()

    def handler1(*args, **kwargs):
        collector1.append((args, kwargs))

    def handler2(*args, **kwargs):
        collector2.append((args, kwargs))

    es.on_event += handler1
    es.on_event += handler2
    es.fire('a', 'b', one=1, two=2)


# Generated at 2022-06-23 13:40:42.824732
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Create an object _EventSource
    g = _EventSource()

    # If the given handler is not callable, this function will raise a ValueError.
    try:
        g += 1
    except ValueError as ex:
        assert "must be callable" in to_text(ex)


# Generated at 2022-06-23 13:40:45.496181
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert set() == e._handlers


# Unit test of property collection_finder

# Generated at 2022-06-23 13:40:56.429494
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import pytest

    event_source = _EventSource()

    def event_handler():
        pass

    event_source += event_handler  # use += to add event handler

    assert len(event_source._handlers) == 1
    assert event_handler in event_source._handlers

    event_source -= event_handler  # use -= to remove event handler

    assert len(event_source._handlers) == 0
    assert event_handler not in event_source._handlers

    # attempt to remove event handler again to ensure that this doesn't cause an exception
    event_source -= event_handler  # use -= to remove event handler

    assert len(event_source._handlers) == 0
    assert event_handler not in event_source._handlers



# Generated at 2022-06-23 13:40:59.225831
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    event = _EventSource()

    event += handler

    assert event._handlers, {handler}


# Generated at 2022-06-23 13:41:05.782846
# Unit test for constructor of class _EventSource
def test__EventSource():
    from ansible_collections.ansible.builtin.plugins.module_utils.common.text.converters import to_text
    if not (hasattr(_EventSource, '__module__') and hasattr(_EventSource, '__module__')):
        return

    result = _EventSource()
    if not (result != str(result) == True):
        raise ValueError('result != str(result) != True')



# Generated at 2022-06-23 13:41:10.740154
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        ansible_collection_config = AnsibleCollectionConfig()
        assert ansible_collection_config
    except Exception as ex:
        assert False, 'Failed to construct class AnsibleCollectionConfig: %s' % to_text(ex)


# Generated at 2022-06-23 13:41:12.728624
# Unit test for constructor of class _EventSource
def test__EventSource():
    x = _EventSource()
    assert x._handlers == set()


# Generated at 2022-06-23 13:41:20.191275
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class TestEvent(_EventSource):
        def __init__(self):
            super(TestEvent, self).__init__()
            self.count = 0

        def __call__(self, *args, **kwargs):
            self.count += 1

    def nothing(*args, **kwargs):
        print('nothing')

    event = TestEvent()
    event += nothing
    event()
    assert 1 == event.count

    event -= nothing
    event()
    assert 1 == event.count

    event -= nothing
    event()
    assert 1 == event.count



# Generated at 2022-06-23 13:41:29.754383
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Foo:
        pass

    def foo(a, b, c):
        Foo.a = a
        Foo.b = b
        Foo.c = c

    foo.bar = 'baz'

    es = _EventSource()
    es += foo

    es.fire(1, b='x', c='y')
    assert Foo.a == 1
    assert Foo.b == 'x'
    assert Foo.c == 'y'

    es -= foo
    assert len(es._handlers) == 0



# Generated at 2022-06-23 13:41:32.478888
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    handler = lambda: None
    e += handler
    e -= handler
    assert len(e._handlers) == 0


# Generated at 2022-06-23 13:41:33.630004
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:41:41.663431
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    src = _EventSource()


    def foo(x):
        pass
    src += foo
    src += foo
    assert src._handlers == set([foo])

    def bar():
        pass
    src += bar
    assert src._handlers == set([foo, bar])

    try:
        src += 1
    except ValueError:
        pass
    else:
        assert False

    src -= foo
    assert src._handlers == set([bar])



# Generated at 2022-06-23 13:41:43.623193
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(_AnsibleCollectionConfig, type)
    assert _AnsibleCollectionConfig.__name__ == '_AnsibleCollectionConfig'

# Generated at 2022-06-23 13:41:48.163245
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    did_call = [False]

    def handler(*args, **kwargs):
        did_call.append(True)

    evs = _EventSource()
    evs += handler
    evs.fire()
    assert did_call[-1]


# Generated at 2022-06-23 13:41:50.991327
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    event_source -= handler


# Generated at 2022-06-23 13:41:58.653091
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.text.converters import to_bytes

    class _Target:
        def __init__(self):
            self.result = b''

    target = _Target()
    event_source = _EventSource()

    def _handler(*a, **kw):
        target.result += to_bytes(repr(a) + repr(kw))

    event_source += _handler
    event_source += _handler
    event_source.fire(1, 2, 3, kw1=4, kw2=5)

    assert target.result == to_bytes('((1, 2, 3), {})((1, 2, 3), {})')

# Generated at 2022-06-23 13:42:01.658065
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(type, value, traceback):
        assert type == Exception
        assert value.args[0] == "foo"
        assert len(value.args) == 1
        assert traceback is not None
    e = _EventSource()
    e += handler
    try:
        raise Exception("foo")
    except Exception:
        e.fire()


# Generated at 2022-06-23 13:42:06.943537
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig('AnsibleCollectionConfig', 'AnsibleCollectionConfig', _AnsibleCollectionConfig)
    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert ac.on_collection_load is ac._on_collection_load



# Generated at 2022-06-23 13:42:09.613824
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler1 = lambda: None
    event_source += handler1
    event_source -= handler1


# Generated at 2022-06-23 13:42:11.409767
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type) is True

# Generated at 2022-06-23 13:42:17.505763
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    def handler1(event):
        raise NotImplementedError()

    def handler2(event):
        raise NotImplementedError()

    event += handler1
    event += handler2
    event -= handler1
    assert handler1 not in event._handlers
    event -= handler2
    assert handler2 not in event._handlers


# Generated at 2022-06-23 13:42:24.919610
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    m = dict()
    def handler1(m, a, b):
        m['handler1'] = (a, b)

    def handler2(m, a, b):
        m['handler2'] = (a, b)

    es = _EventSource()
    es += handler1
    es += handler2
    es.fire(m, 3, 4)
    assert m['handler1'] == (3, 4)
    assert m['handler2'] == (3, 4)


# Generated at 2022-06-23 13:42:33.981369
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class DummyEventSource(_EventSource):

        def __init__(self):
            super(DummyEventSource, self).__init__()
            self.exception_occurred = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_occurred = True
            return False


# Generated at 2022-06-23 13:42:36.838129
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    source -= lambda: None
    source += lambda: None
    source -= lambda: None


# Generated at 2022-06-23 13:42:45.402876
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():

    # Create a dummy class with the metaclass
    class AnsibleCollectionConfigDummy(AnsibleCollectionConfig):
        pass

    # Verify dummy class has all of the proper attributes
    assert AnsibleCollectionConfigDummy._collection_finder is None
    assert AnsibleCollectionConfigDummy._default_collection is None
    assert isinstance(AnsibleCollectionConfigDummy._on_collection_load, _EventSource)

    # Verify dummy class has all of the needed properties
    assert hasattr(AnsibleCollectionConfigDummy, 'collection_finder')
    assert hasattr(AnsibleCollectionConfigDummy, 'collection_paths')
    assert hasattr(AnsibleCollectionConfigDummy, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfigDummy, 'playbook_paths')

    # Verify dummy class has the needed methods

# Generated at 2022-06-23 13:42:51.436807
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(arg1, arg2, arg3):
        assert arg1 == 'arg1'
        assert arg2 == 'arg2'
        assert arg3 == 'arg3'

    es = _EventSource()
    assert handler not in es._handlers

    es += handler
    assert handler in es._handlers

    es.fire('arg1', 'arg2', 'arg3')


# Generated at 2022-06-23 13:42:53.206428
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    s = _EventSource()

    def x():
        pass

    assert len(s._handlers) == 0

    s += x

    assert len(s._handlers) == 1
    assert x in s._handlers


# Generated at 2022-06-23 13:42:54.962553
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert AnsibleCollectionConfig._on_collection_load._handlers == set()


# Generated at 2022-06-23 13:42:59.177960
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    obj = _AnsibleCollectionConfig
    # pylint: disable=no-member
    assert obj._collection_finder is None
    assert obj._default_collection is None
    assert isinstance(obj._on_collection_load, _EventSource)
    assert obj._on_collection_load._handlers is not None


# Generated at 2022-06-23 13:43:00.070911
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pass



# Generated at 2022-06-23 13:43:00.699154
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    pass

# Generated at 2022-06-23 13:43:05.273301
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def def_callable(a, b, c=2):
        pass

    es += def_callable
    assert len(es._handlers) == 1
    assert def_callable in es._handlers


# Generated at 2022-06-23 13:43:06.280431
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource



# Generated at 2022-06-23 13:43:12.182400
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # create _EventSource object
    ev1 = _EventSource()
    # define two events
    def e1(a, b):
        pass

    def e2(a, b):
        pass

    # register events
    ev1 += e1
    ev1 += e2

    # fire events
    ev1.fire(1, 2)
    # unregister event e1
    ev1 -= e1
    # fire events
    ev1.fire(1, 2)
