

# Generated at 2022-06-23 13:33:21.437295
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Check that handle that is not callable raises a ValueError exception
    def my_handler(arg1):
        return arg1
    event_source = _EventSource()
    not_callable = 1
    with pytest.raises(ValueError) as exc:
        event_source.__iadd__(not_callable)
    msg = 'handler must be callable'
    assert msg in to_text(exc.value)
    event_source.__iadd__(my_handler)
    assert my_handler in event_source._handlers


# Generated at 2022-06-23 13:33:22.710621
# Unit test for method __iadd__ of class _EventSource

# Generated at 2022-06-23 13:33:23.983945
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None

# Generated at 2022-06-23 13:33:27.241907
# Unit test for constructor of class _EventSource
def test__EventSource():

    def handler():
        pass

    es = _EventSource()
    assert len(es._handlers) == 0
    es += handler
    assert len(es._handlers) == 1
    es -= handler
    assert len(es._handlers) == 0


# Generated at 2022-06-23 13:33:34.090810
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source = _EventSource()

    def handler_one(*args, **kwargs):
        return 'handler_one'

    def handler_two(*args, **kwargs):
        return 'handler_two'

    event_source += handler_one
    event_source += handler_two

    assert event_source.fire() == ['handler_one', 'handler_two']

# Generated at 2022-06-23 13:33:42.478796
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def test_function(a, b, c=3, d=4):
        print((a, b, c, d))

    event_source = _EventSource()

    # Check that adding a callable works
    event_source += test_function
    assert event_source._handlers == {test_function}

    # Check that adding a non-callable fails
    try:
        event_source += 123
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError did not occur'

    # Check that adding a callable a second time does not add it a second time
    event_source += test_function
    assert event_source._handlers == {test_function}



# Generated at 2022-06-23 13:33:46.377113
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # arrange
    class FakeCollectionFinder:
        def __init__(self):
            self._n_collection_paths = []
            self._n_playbook_paths = []

        def set_playbook_paths(self, playbook_paths):
            self._n_playbook_paths = playbook_paths

    config = AnsibleCollectionConfig()

    # act
    config.collection_finder = FakeCollectionFinder()

    # assert
    assert config.collection_finder is not None
    assert isinstance(config.collection_finder, FakeCollectionFinder)

    assert config.collection_paths == []
    assert config.playbook_paths == []


# Generated at 2022-06-23 13:33:49.099774
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None


# Generated at 2022-06-23 13:33:53.027809
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler(_a, _b):
        pass

    event = _EventSource()
    event += handler
    event -= handler
    assert len(event._handlers) == 0

    event2 = _EventSource()
    event2 -= handler
    assert len(event2._handlers) == 0  # removing event not added does not throw

# Generated at 2022-06-23 13:33:54.705638
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None


# Generated at 2022-06-23 13:33:57.343570
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible.utils.collection_loader import _AnsibleCollectionConfig

    _AnsibleCollectionConfig('meta', 'name', 'bases')

# Generated at 2022-06-23 13:34:02.966351
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Test that handler can be set to a function
    def myfunc():
        pass

    es = _EventSource()
    es += myfunc

    # Test that handler can be set to lambda
    es += lambda: None

    # Test error handling when handler is not callable
    try:
        es += "not-callable"
        assert False
    except TypeError:
        pass


# Generated at 2022-06-23 13:34:05.777576
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        # Attempt to use the constructor
        _ = AnsibleCollectionConfig()
    except TypeError:
        # The constructor should raise a TypeError
        return
    raise Exception("Expected TypeError not raised")

# Generated at 2022-06-23 13:34:13.124340
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Call the function under test
    event_source = _EventSource()

    def handler1(message):
        print('1: ' + message)
        return None

    def handler2(message):
        print('2: ' + message)
        return None

    event_source += handler1
    event_source += handler2

    # Assert that the expected methods and properties are defined
    assert hasattr(event_source, '_handlers')
    assert hasattr(event_source, '__iadd__')
    assert hasattr(event_source, '__isub__')
    assert hasattr(event_source, '_on_exception')
    assert hasattr(event_source, 'fire')

    # Assert that the expected methods and properties have the expected values
    assert isinstance(event_source._handlers, set)
   

# Generated at 2022-06-23 13:34:18.323883
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()
    assert a.collection_finder is None
    assert a.default_collection is None
    assert isinstance(a.on_collection_load, _EventSource)
    assert a.collection_paths is None
    assert a.playbook_paths is None



# Generated at 2022-06-23 13:34:20.155170
# Unit test for constructor of class _EventSource
def test__EventSource():
    evt = _EventSource()
    assert evt
    assert evt._handlers == set()

# Generated at 2022-06-23 13:34:31.902297
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    # confirm that the source starts without any handlers
    assert len(event._handlers) == 0

    # confirm adding a handler works
    def foo():
        pass
    event += foo
    assert len(event._handlers) == 1

    # confirm adding another handler works
    def bar():
        pass
    event += bar
    assert len(event._handlers) == 2

    # confirm we can't add our handlers again
    event += foo
    assert len(event._handlers) == 2
    event += bar
    assert len(event._handlers) == 2

    # confirm adding a non-callable fails
    try:
        event += None
    except ValueError:
        pass
    else:
        assert False, 'adding a non-callable to an EventSource should have raised ValueError'


#

# Generated at 2022-06-23 13:34:35.011831
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    src = _EventSource()
    src += lambda: None
    assert len(src._handlers) == 1
    src += lambda: None
    assert len(src._handlers) == 2


# Generated at 2022-06-23 13:34:44.515952
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _MockEventSource(_EventSource):
        def __init__(self):
            super(_MockEventSource, self).__init__()
            self._on_exception_calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._on_exception_calls.append((handler, exc, args, kwargs))
            return super(_MockEventSource, self)._on_exception(handler, exc, *args, **kwargs)

    _a = []
    _b = []
    _exc = Exception()

    def _func_raise():
        raise _exc

    def _func_list_a(*args, **kwargs):
        _a.append((args, kwargs))


# Generated at 2022-06-23 13:34:47.682161
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def func1():
        return 1
    def func2():
        return 2
    def func3():
        return 3

    es = _EventSource()
    es += func1
    es += func2
    es += func3

    res = es.fire()

    # this test is only to make sure we don't get any Exceptions
    assert res == None


# Generated at 2022-06-23 13:34:51.269521
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class T(_EventSource):
        pass

    t = T()

    def increment(x):
        return x + 1

    t += increment

    assert len(t._handlers) == 1
    assert t._handlers == {increment}


# Generated at 2022-06-23 13:34:55.879016
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    with pytest.raises(ValueError):
        es._on_exception = None
        es += 1

    def a():
        pass

    es += a

    assert es._handlers == {a}


# Generated at 2022-06-23 13:35:03.590845
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ev = _EventSource()
    l = []
    def handler():
        l.append('handler')
    ev += handler
    ev.fire()
    assert l == ['handler']

    l = []
    ev.fire()
    assert l == ['handler']

    l = []
    ev -= handler
    ev.fire()
    assert l == []

# Generated at 2022-06-23 13:35:09.515909
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    def foo(a):
        pass
    def bar(b):
        pass
    es += foo
    es += bar
    assert len(es._handlers) == 2
    es -= foo
    assert len(es._handlers) == 1
    es -= bar
    assert len(es._handlers) == 0
    es -= foo
    assert len(es._handlers) == 0


# Generated at 2022-06-23 13:35:15.876475
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    tes = TestEventSource()

    def test_handler1(test, data):
        raise Exception(test)

    def test_handler2(test, data):
        data.append(test)

    def test_handler3(test, data):
        raise Exception(test)

    def test_handler4(test, data):
        data.append(test)

    data = []

    tes += test_handler1
    tes += test_handler2
    tes += test_handler3
    tes += test_handler4

    tes.fire('abc', data=data)
    assert data == ['abc', 'abc']

# Generated at 2022-06-23 13:35:17.985675
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    def handler1(x):
        return x

    source += handler1
    source.fire('foo')

# Generated at 2022-06-23 13:35:19.305561
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()


# Generated at 2022-06-23 13:35:27.088702
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # init
    event = _EventSource()
    handlers = [object(), object(), object()]
    for h in handlers:
        event += h

    # remove handler that is known to have been added
    event -= handlers[1]
    assert set(event._handlers) == set(handlers) - {handlers[1]}

    # remove handler that is known not to have been added
    handler = object()
    event -= handler
    assert set(event._handlers) == set(handlers) - {handlers[1]}


# Generated at 2022-06-23 13:35:28.643264
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert not e._handlers


# Generated at 2022-06-23 13:35:31.426455
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    if isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig):  # this test will fail in Python 2
        pass  # this branch expected to be executed in ansible-test

# Generated at 2022-06-23 13:35:36.110581
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source += handler
    assert len(event_source._handlers) == 1


# Generated at 2022-06-23 13:35:47.083770
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class MyEventSource(_EventSource):
        def __init__(self, *args, **kwargs):
            super(MyEventSource, self).__init__(*args, **kwargs)
            self.handler1_called = False
            self.handler2_called = False
            self.handler3_called = False

        def handler1(self):
            self.handler1_called = True

        def handler2(self):
            self.handler2_called = True

        def handler3(self):
            self.handler3_called = True

    handlers = (
        MyEventSource.handler1,
        MyEventSource.handler2,
        MyEventSource.handler3,
    )

    my_event_source = MyEventSource()

    for handler in handlers:
        my_event_source += handler


# Generated at 2022-06-23 13:35:47.918602
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._on_collection_load



# Generated at 2022-06-23 13:35:49.850467
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_event_source = _EventSource()
    assert test_event_source._handlers == set()


# Generated at 2022-06-23 13:35:51.388458
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    if isinstance(AnsibleCollectionConfig, type):
        AnsibleCollectionConfig()

# Generated at 2022-06-23 13:35:53.904450
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(event_arg):
        pass

    event_source += handler
    assert handler in event_source._handlers



# Generated at 2022-06-23 13:35:58.756126
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _AnsibleCollectionConfig(type):
        def __init__(cls, meta, name, bases):
            cls._collection_finder = None
            cls._default_collection = None
            cls._on_collection_load = _EventSource()

    class AnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        def __new__(cls, *args, **kwargs):
            return super(AnsibleCollectionConfig, cls).__new__(cls)

    ansible_collection_config = AnsibleCollectionConfig()

    assert ansible_collection_config._collection_finder is None
    assert ansible_collection_config._default_collection is None
    assert isinstance(ansible_collection_config._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:36:04.863804
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # constructor must take 3 arguments
    def _test_AnsibleCollectionConfig_args(cls, meta, name, bases):
        pass

    assert callable(_test_AnsibleCollectionConfig_args)

    # constructor must call super
    _AnsibleCollectionConfig(_test_AnsibleCollectionConfig_args, '_AnsibleCollectionConfig', None)

# Generated at 2022-06-23 13:36:10.897888
# Unit test for constructor of class _EventSource
def test__EventSource():
    def func(*args, **kwargs):
        pass

    ev = _EventSource()
    assert ev._handlers == set()
    ev.fire()

    ev += func
    assert func in ev._handlers

    ev -= func
    assert func not in ev._handlers

    with pytest.raises(ValueError):
        ev += 5

    with pytest.raises(ValueError):
        ev -= 5

# Generated at 2022-06-23 13:36:13.320844
# Unit test for constructor of class _EventSource
def test__EventSource():
    try:
        _EventSource()
    except:
        assert False



# Generated at 2022-06-23 13:36:16.941062
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:36:18.360819
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()
    assert AnsibleCollectionConfig.on_collection_load is not None

# Generated at 2022-06-23 13:36:23.724969
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # Ensure that static class properties are properly initialized
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

    on_collection_load = AnsibleCollectionConfig.on_collection_load
    assert on_collection_load is AnsibleCollectionConfig._on_collection_load



# Generated at 2022-06-23 13:36:26.019016
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert type(e) == _EventSource


# Generated at 2022-06-23 13:36:38.353350
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    _es = _EventSource()
    results = []

    def handler1(arg1, arg2, keyword1=None, keyword2=None):
        results.extend([arg1, arg2, keyword1, keyword2])

    def handler2(arg1, arg2, keyword1=None, keyword2=None):
        results.append(">>handler2 fired<<")
        raise ValueError("Bad parameters")

    def handler3(arg1, arg2, keyword1=None, keyword2=None):
        results.append(">>handler3 fired<<")
        raise KeyError("Bad parameters")

    # 1) test basic functionality
    _es += handler1
    _es += handler2
    _es += handler3

    _es.fire(1, 2, keyword1=1000, keyword2=2000)


# Generated at 2022-06-23 13:36:42.482206
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler():
        pass

    x = _EventSource()
    x += handler

    assert handler in x._handlers
    assert len(x._handlers) == 1


# Generated at 2022-06-23 13:36:45.070647
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fired = [False]
    def handler():
        fired[0] = True
    event = _EventSource()
    event += handler
    event.fire()
    assert fired[0]

# Generated at 2022-06-23 13:36:57.018343
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible.utils.collection_loader.utils import get_collection_config
    from ansible.utils.collection_loader.finder import AnsibleCollectionFinder

    config = get_collection_config()
    assert config is not None

    assert config.collection_finder is None
    assert config.collection_paths == list()
    assert config.default_collection is None
    assert config.on_collection_load is not None
    assert len(config.on_collection_load._handlers) == 0
    assert config.playbook_paths == list()

    config.collection_finder = AnsibleCollectionFinder()
    assert config.collection_finder is not None

    config.playbook_paths = ['/playbooks']
    assert config.playbook_paths == ['/playbooks']

    config.on_collection_load += lambda: None

# Generated at 2022-06-23 13:36:59.754100
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig.collection_finder is None

    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig.default_collection is None

    assert AnsibleCollectionConfig._on_collection_load is not None
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollectionConfig._on_collection_load



# Generated at 2022-06-23 13:37:10.855004
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def handler1(x, y, z):
        pass

    def handler2(x, y, z):
        pass

    def handler3(x, y, z):
        pass

    es += handler1
    assert len(es._handlers) == 1
    es += handler2
    assert len(es._handlers) == 2
    es += handler3
    assert len(es._handlers) == 3

    try:
        es += "some_bad_string"
        assert False, "should have produced a ValueError"
    except ValueError as e:
        assert str(e) == "handler must be callable"


# Generated at 2022-06-23 13:37:14.128262
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    event.fire = mock.create_autospec(event.fire)
    handler = mock.MagicMock()
    event += handler
    event -= handler

    # should not call the handler
    event.fire.assert_not_called()


# Generated at 2022-06-23 13:37:24.437077
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    class EventSource_test___isub__(_EventSource):
        def __init__(self):
            super(EventSource_test___isub__, self).__init__()
            self._handlers = set()
            self._event_fired = False

        def __call__(self, *args, **kwargs):
            self._event_fired = True

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

    sut = EventSource_test___isub__()

    sut += sut
    assert len(sut._handlers) == 1

    sut -= sut
    assert len(sut._handlers) == 0


# Generated at 2022-06-23 13:37:28.027223
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    #TODO verify _event_source is created
    assert event_source


# Generated at 2022-06-23 13:37:34.113352
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    '''Tests the method of the class _EventSource'''

    event_source = _EventSource()

    def test_function():
        '''A function to add to the event source'''

    assert event_source._handlers == set()

    event_source += test_function

    assert event_source._handlers == {test_function}


# Generated at 2022-06-23 13:37:35.634763
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    x = _EventSource()
    f = lambda x:x
    g = lambda x:x

    x += f
    x += g

    x -= f
    assert f not in x._handlers

    assert g in x._handlers

# Generated at 2022-06-23 13:37:39.863063
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()
    assert isinstance(a, _AnsibleCollectionConfig)
    assert isinstance(a._on_collection_load, _EventSource)
    assert not a._collection_finder


# Generated at 2022-06-23 13:37:49.415736
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    a = _EventSource()
    b = _EventSource()

    def handler0(a, b, c):
        pass

    def handler1(a, b, c):
        pass

    def handler2(a, b, c):
        pass

    def handler3(a, b, c):
        pass

    a += handler1
    a += handler2
    a += handler1
    a += handler3

    b += handler3

    b += handler3
    b += handler1

    if handler1 not in a._handlers:
        assert False, 'handler1 not in a'

    if handler2 not in a._handlers:
        assert False, 'handler2 not in a'

    if handler3 not in a._handlers:
        assert False, 'handler3 not in a'


# Generated at 2022-06-23 13:37:50.735723
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    s = _EventSource()

    def h():
        pass

    def g():
        pass

    s += h
    s += g

    s -= h
    s -= g

# Generated at 2022-06-23 13:37:54.236941
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    sender = _EventSource()

    def _test_handler(message):
        pass

    sender += _test_handler

    assert _test_handler in sender._handlers



# Generated at 2022-06-23 13:37:55.167904
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    pass

# Generated at 2022-06-23 13:38:02.789546
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Next two lines are used to check the correct instantiation of class _EventSource
    fire = AnsibleCollectionConfig.on_collection_load
    fire_1 = AnsibleCollectionConfig.on_collection_load.fire

    # Create a class to call and test the method fire
    class load:
        def __init__(self):
            self.flags = 0

        def __call__(self, *args, **kwargs):
            self.flags += 1

    # We create a load object, so we can check if the method fire has been called
    load_1 = load()
    load_2 = load()

    # Attach the load method to fire and test the method fire
    fire += load_1
    fire += load_2

    fire()
    assert load_1.flags == 1
    assert load_2.flags == 1

    #

# Generated at 2022-06-23 13:38:09.341763
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    assert event_source._handlers == set()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source += handler2

    assert event_source._handlers == {handler1, handler2}

    event_source -= handler1

    assert event_source._handlers == {handler2}

    event_source -= handler1

    assert event_source._handlers == {handler2}

    event_source -= handler2

    assert event_source._handlers == set()


# Generated at 2022-06-23 13:38:13.419697
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # no arg constructor should succeed
    class TestCollectionConfig(_AnsibleCollectionConfig):
        pass

    assert TestCollectionConfig.collection_finder is None
    assert TestCollectionConfig.default_collection is None


# Generated at 2022-06-23 13:38:23.355266
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    called = [0, 0]

    def handler1(*args, **kwargs):
        assert called[0] == 0
        assert called[1] == 0
        called[0] += 1

    def handler2(*args, **kwargs):
        assert called[0] == 1
        assert called[1] == 0
        called[1] += 1

    event += handler1
    event += handler2
    event.fire()

    assert called[0] == 1
    assert called[1] == 1

    event -= handler1
    event -= handler2
    event.fire()

    assert called[0] == 1
    assert called[1] == 1



# Generated at 2022-06-23 13:38:34.454378
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible_collections.ansible.community.plugins.module_utils.collection_loader._collection_finder import AnsibleCollectionFinder
    from ansible_collections.ansible.community.plugins.module_utils.collection_loader._collection_finder import CollectionFinder
    import os

    def callback1(collection_name):
        return None

    def callback2(collection_name):
        return None

    cc = AnsibleCollectionConfig()

    assert cc.collection_finder is None
    assert cc.default_collection is None

    assert isinstance(cc.on_collection_load, _EventSource)
    cc.on_collection_load += callback1
    assert len(cc.on_collection_load._handlers) == 1
    cc.on_

# Generated at 2022-06-23 13:38:41.619884
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    tests = [
        ('ansible.collection_loader.__init__', 'test__EventSource___iadd__'),
        ('ansible_collections.foo.bar.__init__', 'test__EventSource___iadd__'),
        ('ansible_collections.foo.bar.tasks.main', 'test__EventSource___iadd__'),
    ]

    for test_case in tests:
        event = _EventSource()
        event += test_case[0]
        assert test_case[0] in event._handlers
        if test_case[0] != test_case[1]:
            event += test_case[1]
            assert test_case[1] in event._handlers
        assert event._handlers == {test_case[0], test_case[1]}

# Generated at 2022-06-23 13:38:45.927534
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()

    def handler():
        pass

    e += handler
    assert len(e._handlers) == 1

    e -= handler
    assert len(e._handlers) == 0

    try:
        e -= handler
    except KeyError:
        assert False

# Generated at 2022-06-23 13:38:53.874107
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            # return True and re-raise the exception
            return True

    fire_count = 0
    event_source = _TestEventSource()

    def handler1(*args, **kwargs):
        nonlocal fire_count
        fire_count += 1

    event_source += handler1
    event_source.fire()

    assert fire_count == 1

    def raise_exception(*args, **kwargs):
        raise Exception('raised on purpose')

    event_source += raise_exception

    try:
        event_source.fire()
    except Exception as ex:
        assert to_text(ex) == 'raised on purpose'

    assert fire_count == 2


# Generated at 2022-06-23 13:38:58.188568
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():

    def fake_default_collection():
        return True

    def fake_on_collection_load():
        return True

    AnsibleCollectionConfig.default_collection = fake_default_collection
    AnsibleCollectionConfig.on_collection_load += fake_on_collection_load

    assert AnsibleCollectionConfig.default_collection() == True
    assert AnsibleCollectionConfig.on_collection_load.fire() == True

# Generated at 2022-06-23 13:39:02.186995
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def event_handler():
        pass

    event_source += event_handler

    assert event_handler in event_source._handlers



# Generated at 2022-06-23 13:39:07.947519
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class_AnsibleCollectionConfig = AnsibleCollectionConfig()
    assert isinstance(class_AnsibleCollectionConfig, AnsibleCollectionConfig)
    assert class_AnsibleCollectionConfig._collection_finder == None
    assert class_AnsibleCollectionConfig._collection_paths == None
    assert class_AnsibleCollectionConfig._default_collection == None
    assert class_AnsibleCollectionConfig._on_collection_load == None
    assert class_AnsibleCollectionConfig._playbook_paths == None

# Generated at 2022-06-23 13:39:11.922155
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:39:16.396848
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    """Unit test for AnsibleCollectionConfig constructor."""

    # The empty constructor is not interesting to test.
    obj = AnsibleCollectionConfig()
    assert obj is not None, "Returns None"
    assert isinstance(obj, AnsibleCollectionConfig), "Returns incorrect object type"

# Generated at 2022-06-23 13:39:17.411986
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()


# Generated at 2022-06-23 13:39:22.624703
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_error():
        raise Exception("handler error")

    def handler_print(value):
        print(value)

    event_source = _EventSource()

    event_source += handler_print

    event_source += handler_error

    with pytest.raises(Exception):
        event_source.fire("fire")
    
    event_source -= handler_error

    event_source += handler_error

    with pytest.raises(Exception):
        event_source.fire("fire")


# Generated at 2022-06-23 13:39:32.636282
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    x = _EventSource()

    def handler_f_1():
        pass

    def handler_f_2():
        pass

    x += handler_f_1
    x += handler_f_2

    x -= handler_f_1
    assert handler_f_1 not in x._handlers
    assert handler_f_2 in x._handlers

    x -= handler_f_1
    assert handler_f_1 not in x._handlers
    assert handler_f_2 in x._handlers

    x -= handler_f_2
    assert handler_f_1 not in x._handlers
    assert handler_f_2 not in x._handlers

    x -= handler_f_2
    assert handler_f_1 not in x._handlers
    assert handler_f_2 not in x._handlers


# Unit

# Generated at 2022-06-23 13:39:38.478407
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    f = None
    e = _EventSource()
    e += f

    class _F:
        def __init__(self):
            self.called = False

        def __call__(self):
            self.called = True

    f = _F()
    e += f

    e.fire()
    assert f.called


# Concrete class of our metaclass type that defines the class properties we want

# Generated at 2022-06-23 13:39:46.114065
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    def handler3():
        pass

    es += handler1
    es += handler2
    es += handler3

    assert handler1 in es._handlers
    assert handler2 in es._handlers
    assert handler3 in es._handlers

    es -= handler1
    assert handler1 not in es._handlers
    assert handler2 in es._handlers
    assert handler3 in es._handlers

    es -= handler1  # handler1 is already removed and this should not fail
    assert handler2 in es._handlers
    assert handler3 in es._handlers

    es -= handler2
    assert handler2 not in es._handlers
    assert handler3 in es._handlers

    es -= handler3
    assert handler3 not in es._

# Generated at 2022-06-23 13:39:58.226722
# Unit test for constructor of class _EventSource
def test__EventSource():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.handler_params = []
            self.handler_called = False

        def handler(self, param):
            self.handler_called = True
            self.handler_params.append(param)

    test_event_source = TestEventSource()

    assert not test_event_source._handlers

    test_event_source += test_event_source.handler

    assert test_event_source._handlers

    test_event_source.fire('a')

    assert test_event_source.handler_called is True
    assert test_event_source.handler_params == ['a']

    test_event_source -= test_event_source.handler

    assert not test_event_source._handlers

# Generated at 2022-06-23 13:40:11.118714
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.__metaclass__ == _AnsibleCollectionConfig
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None

    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.on_collection_load.__class__ == _EventSource
    assert hasattr(AnsibleCollectionConfig.on_collection_load, '__iadd__')
    assert hasattr(AnsibleCollectionConfig.on_collection_load, '__isub__')
    assert not hasattr(AnsibleCollectionConfig.on_collection_load, 'append')

    try:
        AnsibleCollectionConfig.collection_finder = 'bar'
    except NotImplementedError:
        pass

# Generated at 2022-06-23 13:40:20.593097
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _EventObject():
        def __init__(self):
            self._events = set()
            self._events.add(EventSource())

        def remove(self, event):
            self._events.remove(event)

    class EventSource(_EventSource):
        def __init__(self):
            _EventSource.__init__(self)

    event_source = EventSource()

    event_object = _EventObject()
    # subtract before addition
    event_object._events.remove(event_source)
    # subtract after addition
    event_source -= event_object
    # subtract after subtraction
    event_source -= event_object
    assert len(event_source._handlers) == 0


# Generated at 2022-06-23 13:40:22.087367
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, type(None))

# Generated at 2022-06-23 13:40:24.251115
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    def x():
        pass
    es += x
    es -= x


# Generated at 2022-06-23 13:40:35.034261
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.args = []
            self.kwargs = []
            self.seen_exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.seen_exceptions.append(exc)
            return False

        def handle(self, *args, **kwargs):
            self.args.append(args)
            self.kwargs.append(kwargs)

    test_event_source = _TestEventSource()
    test_event_source += test_event_source.handle

    assert test_event_source.args == []
    assert test_event_source.kwargs == []
    assert test_event_source.seen_exceptions

# Generated at 2022-06-23 13:40:43.598195
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    source = _EventSource()

    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    def handler3(*args, **kwargs):
        raise RuntimeError('handler3')

    source += handler1
    source += handler2
    source += handler3

    source.fire()

    source -= handler1

    source.fire()

    source -= handler3

    source.fire()

    source += handler3

    try:
        source.fire()
    except RuntimeError:
        pass
    else:
        assert False, 'RuntimeError should have been raised'

# Generated at 2022-06-23 13:40:47.197309
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()
    assert ansible_collection_config.on_collection_load is not None


# Generated at 2022-06-23 13:40:56.026631
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def first():
        print("first")

    def second():
        print("second")

    def third():
        print("third")


    es = _EventSource()
    assert len(es._handlers) == 0
    es += first
    assert es._handlers == {first}
    es += second
    assert es._handlers == {first, second}

    es += third
    assert es._handlers == {first, second, third}

    es += first
    assert es._handlers == {first, second, third}

    assert len(es._handlers) == 3


# Generated at 2022-06-23 13:41:00.048546
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    source += lambda: None
    assert len(source._handlers) == 1
    source -= lambda: None
    assert len(source._handlers) == 0


# Generated at 2022-06-23 13:41:07.751356
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class AnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)

    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None



# Generated at 2022-06-23 13:41:13.138816
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    collection_config = _AnsibleCollectionConfig('meta', 'name', 'base')
    assert collection_config._collection_finder is None
    assert collection_config._default_collection is None
    assert collection_config._on_collection_load


_CACHE = AnsibleCollectionConfig()


# Generated at 2022-06-23 13:41:14.925567
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert len(es._handlers) == 1


# Generated at 2022-06-23 13:41:20.096547
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def my_callback(*args, **kwargs):
        pass

    def my_callback_2(*args, **kwargs):
        pass

    event_source = _EventSource()
    event_source += my_callback
    event_source += my_callback_2

    event_source.fire()

    event_source -= my_callback

    event_source.fire()

# Generated at 2022-06-23 13:41:30.644362
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import pytest

    e = _EventSource()

    def f():
        pass

    e += f

    e -= f
    assert e._handlers == set()

    def g():
        pass

    e += g

    e -= g
    assert e._handlers == set()

    e -= f
    assert e._handlers == set()

    # must not raise an exception if handler was never added
    e -= f

    e += f
    e += f  # can add the same handler more than once without exceptions

    with pytest.raises(ValueError):
        e -= object()


# Generated at 2022-06-23 13:41:31.689123
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pass


# Generated at 2022-06-23 13:41:34.273578
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cfg = AnsibleCollectionConfig()
    assert (cfg._collection_finder is None)
    assert (cfg._default_collection is None)
    assert (cfg._on_collection_load is not None)

# Generated at 2022-06-23 13:41:43.983536
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    # all handlers should be called
    def h1(*args, **kwargs):
        raise NotImplementedError()

    def h2(*args, **kwargs):
        return

    def h3(*args, **kwargs):
        raise NotImplementedError()

    event_source += h1
    event_source += h2
    event_source += h3

    event_source.fire()

    # one of the handlers should have raised an exception
    try:
        event_source.fire()
    except NotImplementedError:
        pass
    else:
        raise AssertionError('one of the handlers should have raised an exception')

# Generated at 2022-06-23 13:41:55.311677
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_bytes, to_native

    def to_native_type(value):
        return to_native(to_text(value, nonstring='passthru', errors='surrogate_then_replace'), errors='surrogate_then_replace')

    def to_bytes_type(value):
        return to_bytes(to_text(value, nonstring='passthru', errors='surrogate_then_replace'), errors='surrogate_then_replace')

    def to_text_type(value):
        return to_text(value, nonstring='passthru', errors='surrogate_then_replace')


# Generated at 2022-06-23 13:42:08.424646
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import inspect

    def _callback(*args, **kwargs):
        pass

    callback = _callback

    source = _EventSource()
    source += callback

    # A ValueError is thrown when a callable handler is missing
    try:
        source.fire()
    except ValueError:
        pass
    else:
        assert False

    # A ValueError is thrown when a callable handler is missing
    try:
        source -= inspect.getsource
        source.fire()
    except ValueError:
        pass
    else:
        assert False

    # No error is raised for a proper handler
    source -= callback
    source += callback
    source.fire()

    # A ValueError is thrown if handler raises an exception that is not
    # caught by _EventSource._on_exception

# Generated at 2022-06-23 13:42:14.591022
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def listener(a, b, c):
        events.append((a, b, c))

    event_source = _EventSource()
    events = []

    event_source.fire('A', 'B', 'C')
    assert events == []

    event_source += listener
    event_source.fire('A', 'B', 'C')
    assert events[0] == ('A', 'B', 'C')

    event_source -= listener
    event_source.fire('A', 'B', 'C')
    assert len(events) == 1

# Generated at 2022-06-23 13:42:18.904187
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class X:
        @classmethod
        def __call__(cls, *args, **kwargs):
            pass

    es = _EventSource()
    assert(es._handlers == set())
    es += X
    assert(es._handlers != set())


# Generated at 2022-06-23 13:42:26.657502
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler_a = lambda: None
    handler_b = lambda: None
    event_source += handler_a
    event_source += handler_b

    event_source -= handler_a
    assert len(event_source._handlers) == 1
    assert handler_b in event_source._handlers

    event_source -= handler_b
    assert len(event_source._handlers) == 0
    assert handler_a not in event_source._handlers
    assert handler_b not in event_source._handlers


# Generated at 2022-06-23 13:42:29.164242
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config.collection_finder is None
    assert config.collection_paths == []
    assert config.playbook_paths == []

# Generated at 2022-06-23 13:42:33.721844
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, property)
    assert isinstance(AnsibleCollectionConfig._default_collection, property)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, property)

# Generated at 2022-06-23 13:42:41.159235
# Unit test for constructor of class _EventSource
def test__EventSource():

    def _raise_error(ex):
        raise ex

    event_source = _EventSource()

    event_source += _raise_error

    try:
        event_source.fire(ValueError('sentinel'))
    except Exception as ex:
        if not isinstance(ex, ValueError):
            raise Exception('unexpected exception type')
        if str(ex) != 'sentinel':
            raise Exception('unexpected exception value')
    else:
        raise Exception('unexpected exception')



# Generated at 2022-06-23 13:42:51.985821
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, type(None))
    assert isinstance(AnsibleCollectionConfig._default_collection, type(None))
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)

# Generated at 2022-06-23 13:42:54.027161
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)


# Generated at 2022-06-23 13:42:57.009416
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler():
        pass

    event = _EventSource()
    event += handler
    assert handler in event._handlers

    event -= handler
    assert handler not in event._handlers



# Generated at 2022-06-23 13:43:05.472440
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()
    calls = []

    def handler(caller):
        assert caller is source
        calls.append(caller)

    # add and remove callables
    source += handler
    source -= handler

    # add a non-callable
    with pytest.raises(ValueError):
        source += 123

    # call with no handlers registered
    source.fire()
    assert not calls

    # call with handlers registered
    source += handler
    source -= handler
    source += handler
    source.fire()
    assert len(calls) == 1

# Generated at 2022-06-23 13:43:06.087199
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pass

# Generated at 2022-06-23 13:43:10.489528
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)



# Generated at 2022-06-23 13:43:18.649797
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def f1(x, y, z):
        assert x == 10
        assert y == 20
        assert z == 30

    def f2(x, y, z):
        assert x == 10
        assert y == 20
        assert z == 30
        raise ValueError('we should see this')

    e = _EventSource()
    e.fire(10, 20, 30)
    e += f1
    e.fire(10, 20, 30)
    e += f2