

# Generated at 2022-06-23 13:33:18.506907
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    orig = _EventSource()

    # try appending a lambda to a normal _EventSource object
    orig += lambda x: x

    # try appending a lambda to a normal _EventSource object
    orig += lambda x: x

    # try appending a normal function to a normal _EventSource object
    def foo(x):
        print(x)
    orig += foo


# Generated at 2022-06-23 13:33:20.928219
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._collection_paths is None
    assert AnsibleCollectionConfig._default_collection is None


# Generated at 2022-06-23 13:33:24.575542
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # create the object to test
    test_object = _EventSource()

    # make sure __isub__ will not barf if no items have been added
    test_object.__isub__(None)

    # add a handler
    test_object += None

    # call __isub__ to remove the handler
    test_object -= None

    # make sure __isub__ doesn't blow up if none of the handlers are callable
    test_object.__isub__(None)

# Generated at 2022-06-23 13:33:32.383084
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Method: fire
    #
    # The code currently being tested is:
    #      for h in self._handlers:
    #          try:
    #              h(*args, **kwargs)
    #          except Exception as ex:
    #              if self._on_exception(h, ex, *args, **kwargs):
    #                  raise

    # Empty set of handlers
    es = _EventSource()
    es.fire('foo')

    # Normal event handling
    state = []
    es = _EventSource()
    es += lambda *args, **kwargs: state.append(('one', args, kwargs))
    es += lambda *args, **kwargs: state.append(('two', args, kwargs))
    es.fire('foo')

# Generated at 2022-06-23 13:33:42.661281
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    x = AnsibleCollectionConfig()
    assert x.collection_finder is None
    assert x.default_collection is None
    assert x.on_collection_load is not None
    assert x.playbook_paths == []
    assert x.collection_paths == []


# CAUTION: There are two implementations of the collection loader.
#          They must be kept functionally identical, although their implementations may differ.
#
# 1) The controller implementation resides in the "lib/ansible/utils/collection_loader/" directory.
#    It must function on all Python versions supported on the controller.
# 2) The ansible-test implementation resides in the "test/lib/ansible_test/_util/target/legacy_collection_loader/" directory.
#    It must function on all Python versions supported on managed hosts which are not supported by the controller.

# Generated at 2022-06-23 13:33:46.018777
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler1():
        pass
    def handler2():
        pass
    s = _EventSource()
    s.fire()
    s += handler1
    s.fire()
    s += handler2
    s.fire()
    s -= handler1
    s.fire()
    s -= handler2
    s.fire()
    s -= handler1
    s.fire()
    s -= handler1
    s.fire()


# Generated at 2022-06-23 13:33:55.859091
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import sys

    class _EventSourceTester(object):

        def test_exception_in_handler(self):
            def handler(bad_parameter):
                raise ValueError('bad parameter')

            def exception_handler(handler, exc, *args, **kwargs):
                assert exc.args[0] == 'bad parameter'
                assert self.args == ()
                assert self.kwargs == {'bad_parameter': 'bad parameter'}

                return False

            self.args = ()
            self.kwargs = {'bad_parameter': 'bad parameter'}
            self.source._on_exception = exception_handler
            self.source += handler
            self.source.fire(*self.args, **self.kwargs)


# Generated at 2022-06-23 13:33:57.137582
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()



# Generated at 2022-06-23 13:33:58.547743
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    raise NotImplementedError('Test not yet implemented')


# Generated at 2022-06-23 13:34:03.825351
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=attribute-defined-outside-init
    class _TestCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        def __init__(self):
            # pylint: disable=no-member
            super(_TestCollectionConfig, self).__init__('meta', 'name', 'bases')

    return _TestCollectionConfig

# Generated at 2022-06-23 13:34:09.967035
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def test_f1(*args, **kwargs):
        print('test_f1 called with', args, kwargs)

    def test_f2(*args, **kwargs):
        print('test_f2 called with', args, kwargs)

    esc = _EventSource()

    esc += test_f1
    esc += test_f2

    esc.fire(1, 2, 3, keyword1='test1', keyword2='test2')

    esc -= test_f1

    esc.fire(4, 5, 6, keyword1='test3', keyword2='test4')

# Generated at 2022-06-23 13:34:14.876768
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    # Create and fire an event
    event = _EventSource()
    event.fire()

    # Install a handler that we can remove
    def handler(event, *args, **kwargs):
        pass
    event += handler

    # Remove nothing
    event -= None

    # Remove the handler
    event -= handler

    # Remove nothing
    event -= False

    # Remove nothing
    event -= 'handler'

    # Remove nothing
    event -= 1

    # Fire the event
    event.fire()

# Generated at 2022-06-23 13:34:18.438476
# Unit test for constructor of class _EventSource
def test__EventSource():

    def test_handler_function():
        pass

    test_event_source = _EventSource()

    assert test_event_source._handlers == set()

    test_event_source += test_handler_function

    assert test_event_source._handlers == set([test_handler_function])

    test_event_source -= test_handler_function

    assert test_event_source._handlers == set()



# Generated at 2022-06-23 13:34:29.865799
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from unittest import TestCase
    import os

    class SubclassWithData(TestCase):
        def __init__(self, caller, value):
            super().__init__()
            self._caller = caller
            self._value = value

        def __call__(self, *args, **kwargs):
            self._caller.assertEqual(len(args), 2)
            self._caller.assertEqual(args[1], self._value)
            self._caller.assertEqual(len(kwargs), 2)
            self._caller.assertEqual(kwargs['second_arg'], self._value)
            self._caller.assertEqual(kwargs['third_arg'], self._value)


# Generated at 2022-06-23 13:34:31.950191
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()

    assert len(event_source._handlers) == 0



# Generated at 2022-06-23 13:34:35.655627
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    x = _EventSource()

    f1 = lambda: None
    f2 = lambda: None

    x += f1
    x += f2

    x -= f1

    assert f1 not in x._handlers


# Generated at 2022-06-23 13:34:38.169735
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load

# Generated at 2022-06-23 13:34:39.220525
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig


# Generated at 2022-06-23 13:34:45.074564
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cc = AnsibleCollectionConfig()
    assert cc.collection_finder is None
    assert cc.collection_paths == []
    assert cc.default_collection is None
    assert cc.on_collection_load == cc._on_collection_load
    assert cc.playbook_paths == []

# Generated at 2022-06-23 13:34:52.703514
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, object)
    assert hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert hasattr(AnsibleCollectionConfig, '_default_collection')
    assert hasattr(AnsibleCollectionConfig, '_on_collection_load')

    # _AnsibleCollectionConfig.__init__

# Generated at 2022-06-23 13:34:54.286612
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # class AnsibleCollectionConfig defined above is not instantiable
    try:
        AnsibleCollectionConfig()
    except TypeError:
        pass
    else:
        assert False, "collection_config class must not be instantiable"


# Generated at 2022-06-23 13:34:57.369334
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler

    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers



# Generated at 2022-06-23 13:34:59.022027
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _EventSource.__iadd__()

# Generated at 2022-06-23 13:35:06.739066
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    x = _EventSource()

    # sanity check
    assert len(x._handlers) == 0

    def my_func():
        pass

    # default case
    x += my_func
    assert len(x._handlers) == 1
    x -= my_func
    assert len(x._handlers) == 0

    # attempt to remove an unknown function
    x -= my_func
    assert len(x._handlers) == 0


# Generated at 2022-06-23 13:35:08.811239
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()
    assert ev._handlers == set()


# Unit tests for property _EventSource.__iadd__

# Generated at 2022-06-23 13:35:11.337018
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert hasattr(c, 'collection_finder')
    assert hasattr(c, 'collection_paths')
    assert hasattr(c, 'default_collection')
    assert hasattr(c, 'on_collection_load')
    assert hasattr(c, 'playbook_paths')



# Generated at 2022-06-23 13:35:13.382509
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, _AnsibleCollectionConfig)

# Generated at 2022-06-23 13:35:22.095075
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    from ansible.module_utils._text import to_text

    def callback():
        pass

    class Dispatcher(object):
        def __init__(self):
            self.handlers = set()
            self.on_something_happened += callback

        on_something_happened = _EventSource()

    d = Dispatcher()
    assert len(d.on_something_happened._handlers) == 1
    assert d.on_something_happened._handlers == set([callback])
    d.on_something_happened -= callback
    assert len(d.on_something_happened._handlers) == 0
    assert d.on_something_happened._handlers == set()
    d.on_something_happened -= callback

# Generated at 2022-06-23 13:35:23.745623
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    def handle_event():
        pass
    event += handle_event
    event -= handle_event
    assert not handle_event in event._handlers

# Generated at 2022-06-23 13:35:33.836050
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def _raise(exc_type=Exception, msg=None, *args, **kwargs):
        raise exc_type(msg, *args, **kwargs)

    def _raise_with_value(exc_type=Exception, msg=None, *args, **kwargs):
        raise exc_type(msg, *args, **kwargs)


# Generated at 2022-06-23 13:35:38.471689
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def handler1(*args, **kwargs):
        return 'handler1'
    event_source += handler1

    event_source -= handler1
    assert len(event_source._handlers) == 0


# Generated at 2022-06-23 13:35:48.681734
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    """
    def __init__(cls, meta, name, bases):
        cls._collection_finder = None
        cls._default_collection = None
        cls._on_collection_load = _EventSource()
    """
    _collection_finder = None
    _default_collection = None
    _on_collection_load = _EventSource()

    # constructor
    config = _AnsibleCollectionConfig('meta', 'name', 'bases')

    # assert the constructor set the instance variables correctly
    if _collection_finder is not None:
        assert False, '_AnsibleCollectionConfig() is not setting _collection_finder correctly.'
    if _default_collection is not None:
        assert False, '_AnsibleCollectionConfig() is not setting _default_collection correctly.'

# Generated at 2022-06-23 13:35:55.925372
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler1(_):
        pass

    def handler2(_):
        pass

    event_source += handler1
    event_source += handler2

    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers

    event_source -= handler1
    assert handler1 not in event_source._handlers
    assert handler2 in event_source._handlers

    event_source -= handler1
    assert handler1 not in event_source._handlers
    assert handler2 in event_source._handlers

# Generated at 2022-06-23 13:36:03.458598
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    calls = []

    def handler_a(*args, **kwargs):
        calls.append('a')

    def handler_b(*args, **kwargs):
        calls.append('b')

    es += handler_a
    es += handler_b

    es.fire()

    assert calls == ['a', 'b']



# Generated at 2022-06-23 13:36:12.954622
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from collections import namedtuple
    from ansible.module_utils.six import assertCountEqual

    # Create an instance of the _EventSource class
    obj = _EventSource()

    # Create a callable
    def func_1():
        pass
    # Create a callable
    def func_2():
        pass
    # Create a callable
    def func_3():
        pass

    # Register the callables to the event source
    obj += func_1
    obj += func_2
    obj += func_3

    # Test that 3 callables were registered with the event source
    assert len(obj._handlers) == 3

    # Unregister a callable from the event source
    obj -= func_2

    # Test that the number of callables registered with the event source was decremented
    assert len(obj._handlers)

# Generated at 2022-06-23 13:36:14.735165
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig()



# Generated at 2022-06-23 13:36:22.502323
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # create _EventSource instance
    my_es = _EventSource()

    # create a function to be used as an event handler
    def tester_func(arg1, arg2):
        return "arg1: " + arg1 + ", arg2: " + arg2

    # add the function to the event source instance
    my_es += tester_func

    # fire the event source, passing in two arguments
    results = my_es.fire("testing", "arguments")

    # assert that no error was raised during firing of the event source
    assert results is None

    # TODO: end of initial unit test; add additional tests

# Generated at 2022-06-23 13:36:23.036240
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()

# Generated at 2022-06-23 13:36:25.721849
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # Constructor should not raise any errors
    _AnsibleCollectionConfig('Meta', 'class_name', ('bases', ))



# Generated at 2022-06-23 13:36:30.946960
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # The following will throw an exception and fail if the class does not have the expected instance attributes
    for attr in ['_collection_finder', '_default_collection', '_on_collection_load']:
        assert hasattr(AnsibleCollectionConfig, attr)



# Generated at 2022-06-23 13:36:33.899120
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _meta = '_meta'
    name = 'name'
    bases = 'bases'
    _AnsibleCollectionConfig(_meta, name, bases)

# Generated at 2022-06-23 13:36:37.625038
# Unit test for constructor of class _EventSource
def test__EventSource():
    '''
    Ensure that the constructor of class _EventSource can be called
    '''
    # Arrange
    # Act
    ep = _EventSource()

    # Assert
    assert isinstance(ep, _EventSource)


# Generated at 2022-06-23 13:36:44.238219
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # use the class attributes directly to ensure we can properly access them
    AnsibleCollectionConfig._collection_finder = None
    AnsibleCollectionConfig._default_collection = None

    # post-conditions
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

# Generated at 2022-06-23 13:36:55.576472
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.default_collection is None

    try:
        config.on_collection_load
        assert False, 'on_collection_load should not be obtainable before a CollectionFinder has been configured'
    except NotImplementedError:
        pass

    try:
        config.playbook_paths
        assert False, 'playbook_paths should not be obtainable before a CollectionFinder has been configured'
    except NotImplementedError:
        pass

    try:
        config.collection_paths
        assert False, 'collection_paths should not be obtainable before a CollectionFinder has been configured'
    except NotImplementedError:
        pass



# Generated at 2022-06-23 13:37:00.050260
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    ev = _EventSource()
    def f():
        pass

    ev += f

    ev -= f

    # check that it's still repeatable and idempotent
    ev -= f
    ev -= f

    # check we don't try to remove anything that isn't a function
    ev -= 2
    ev -= None
    ev -= 'str'
    ev -= ev

# Generated at 2022-06-23 13:37:12.136052
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _TestClass(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return 1
    class _TestException(Exception):
        pass
    class _Tester:
        def __init__(self):
            self.call_count = 0
            self.args = None
            self.kwargs = None
        def __call__(self, *args, **kwargs):
            self.call_count += 1
            self.args = args
            self.kwargs = kwargs
            raise _TestException()
    test_subject = _TestClass()
    t1 = _Tester()
    t2 = _Tester()
    test_subject += t1
    test_subject += t2
    # Test __isub__ on a handler that is not part of the test_

# Generated at 2022-06-23 13:37:16.617009
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    collection_config = AnsibleCollectionConfig()
    assert collection_config.collection_finder is None
    assert isinstance(collection_config.on_collection_load, _EventSource)
    assert collection_config.default_collection is None

# Generated at 2022-06-23 13:37:21.079498
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ansible_collection_config = _AnsibleCollectionConfig(name='Test', bases=(object,), meta='Test')

    assert ansible_collection_config._collection_finder is None
    assert ansible_collection_config._default_collection is None
    assert isinstance(ansible_collection_config._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:37:24.706707
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    collection_config = AnsibleCollectionConfig()

    assert collection_config.collection_finder is None
    assert collection_config.default_collection is None

    assert isinstance(collection_config.on_collection_load, _EventSource)
    assert len(collection_config.on_collection_load._handlers) == 0

# Generated at 2022-06-23 13:37:29.534481
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    es = _EventSource()
    def f(x):
        assert x == 42
    es += f

# Generated at 2022-06-23 13:37:38.979501
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    calls = []

    def handler(*args, **kwargs):
        calls.append(('handler', args, kwargs))

    def failing(*args, **kwargs):
        calls.append(('failing', args, kwargs))
        raise ValueError('oops')

    event += handler

    assert len(calls) == 0
    event.fire(1, 2, three=4)
    assert len(calls) == 1
    assert calls[0] == ('handler', (1, 2), {'three': 4})

    calls.clear()
    event.fire()
    assert len(calls) == 1
    assert calls[0] == ('handler', (), {})

    calls.clear()
    event += failing
    assert len(calls) == 0
    event.fire(1)

# Generated at 2022-06-23 13:37:45.094951
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert len(AnsibleCollectionConfig._on_collection_load._handlers) == 0
    AnsibleCollectionConfig.collection_paths
    AnsibleCollectionConfig.playbook_paths
    AnsibleCollectionConfig.default_collection
    assert AnsibleCollectionConfig.on_collection_load
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollectionConfig._on_collection_load

AnsibleCollectionConfig = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:37:52.310589
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()

    if es._handlers:
        raise AssertionError('_EventSource._handlers is expected to be an empty set')
    if es._on_exception is _EventSource._on_exception:
        raise AssertionError('_EventSource._on_exception is expected to be the default implementation')



# Generated at 2022-06-23 13:37:53.968617
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()


# Generated at 2022-06-23 13:38:01.472702
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def foo(a, b):
        pass

    def bar(a, b):
        raise ValueError('bar')

    def baz(a, b):
        raise KeyError('baz')

    event = _EventSource()
    event += foo
    event += bar
    event += baz

    event -= foo
    assert foo not in event._handlers

    event -= bar
    assert bar not in event._handlers

    # remove something we already removed
    event -= bar
    assert bar not in event._handlers

    # remove something that is not in the set
    event -= baz
    assert baz not in event._handlers

    # now we have nothing left, so ensure this is a no-op
    event -= baz
    assert baz not in event._handlers

# Generated at 2022-06-23 13:38:11.343389
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()
    assert s._handlers == set()

    called = []
    def handler1(arg):
        called.append('handler1 %s' % arg)
    s += handler1
    assert s._handlers == {handler1}

    s.fire('a')
    assert called == ['handler1 a']

    s -= handler1
    assert s._handlers == set()

    called = []
    def handler1(arg):
        called.append('handler1 %s' % arg)
        raise Exception('oops')
    def handler2(arg):
        called.append('handler2 %s' % arg)
    s += handler1
    s += handler2
    assert s._handlers == {handler1, handler2}

    s.fire('a')

# Generated at 2022-06-23 13:38:13.463982
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, _AnsibleCollectionConfig)

# Generated at 2022-06-23 13:38:23.624537
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import unittest
    from ansible_collections.ansible.builtin.plugins.module_utils.ansible_collection_config import AnsibleCollectionConfig

    class ClassUnderTest(with_metaclass(_AnsibleCollectionConfig)):
        def __init__(self):
            self.collection_finder = None
            self.default_collection = None
            self.on_collection_load = None

    class TestMetaclass(_AnsibleCollectionConfig):
        def __init__(self):
            self.collection_finder = None
            self.default_collection = None
            self.on_collection_load = None

    with unittest.TestCase():
        c = ClassUnderTest()
        c = TestMetaclass()



# Generated at 2022-06-23 13:38:34.560719
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.default_collection is None

    # on_collection_load is an _EventSource which exposes a 'fire' method
    assert hasattr(config.on_collection_load, 'fire')

    # verify that we can add and remove handlers
    def handler1(x):
        pass

    def handler2(x):
        pass

    config.on_collection_load += handler1
    assert len(config.on_collection_load._handlers) == 1
    config.on_collection_load += handler2
    assert len(config.on_collection_load._handlers) == 2
    config.on_collection_load -= handler1 # no error if not present
    assert len(config.on_collection_load._handlers) == 1
    config.on

# Generated at 2022-06-23 13:38:36.159191
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)


# Generated at 2022-06-23 13:38:44.316902
# Unit test for constructor of class _EventSource
def test__EventSource():
    fails = []
    a = _EventSource()
    try:
        a += 42
    except ValueError:
        pass
    else:
        fails.append('Failed to detect value error')

    def func():
        pass
    try:
        a += func
    except ValueError:
        fails.append('Failed to detect callable object')

    if fails:
        raise AssertionError('Failed _EventSource() unit test: %s' % ', '.join(fails))



# Generated at 2022-06-23 13:38:47.073408
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()

    def f():
        pass

    e += f
    assert len(e._handlers) == 1

    e -= f
    assert len(e._handlers) == 0

    try:
        e -= f
    except KeyError:
        assert False, 'unexpected KeyError'

# Generated at 2022-06-23 13:38:50.227155
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(x):
        print('handling %s' % x)

    event_source = _EventSource()
    assert event_source._handlers == set()

    event_source += handler
    assert event_source._handlers == set([handler])
    event_source += handler
    assert event_source._handlers == set([handler])


# Generated at 2022-06-23 13:38:56.562998
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert not es._handlers
    assert es._on_exception

    def _on_exception(handler, exc, *args, **kwargs):
        # if we return True, we want the caller to re-raise
        return True
    es._on_exception = _on_exception

    assert es._on_exception



# Generated at 2022-06-23 13:39:06.217913
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # make sure it is instantiated exactly once
    AnsiColCfg1 = type('AnsiColCfg1', (_AnsibleCollectionConfig,), {})
    AnsiColCfg2 = type('AnsiColCfg2', (_AnsibleCollectionConfig,), {})
    try:
        assert AnsiColCfg1 == AnsiColCfg2
    except TypeError:
        pass
    else:
        assert False, 'AnsiColCfg1 and AnsiColCfg2 should be different type objects'
    assert AnsiColCfg1 == _AnsibleCollectionConfig

# Generated at 2022-06-23 13:39:07.791824
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)


# Generated at 2022-06-23 13:39:10.620032
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda x: x
    assert len(event_source._handlers) == 1


# Generated at 2022-06-23 13:39:20.898158
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def test_handler(event_name, *args, **kwargs):
        print("%s: %s %s" % (event_name, args, kwargs))

    not_a_handler = 'this is not a handler'
    event_source = _EventSource()

    event_source += test_handler
    print(event_source)
    print(event_source._handlers)
    print(test_handler in event_source._handlers)

    event_source += not_a_handler
    print(event_source)
    print(event_source._handlers)
    print(test_handler in event_source._handlers)

    event_source -= test_handler
    print(event_source)
    print(event_source._handlers)
    print(test_handler in event_source._handlers)

   

# Generated at 2022-06-23 13:39:23.869420
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event += fire1
    event += fire2
    event += fire3

    event.fire()


counter = 0



# Generated at 2022-06-23 13:39:28.397244
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(name):
        pass

    # Not callable
    with pytest.raises(ValueError):
        event_source += 'not callable'

    # Callable
    event_source += handler

    assert handler in event_source._handlers


#
# Ensure that the collection paths returned by collection_paths are converted to text
#

# Generated at 2022-06-23 13:39:33.571119
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load._handlers == set()
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.playbook_paths == []


# Unit tests for the class properties of _AnsibleCollectionConfig

# Generated at 2022-06-23 13:39:40.857199
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    try:
        assert AnsibleCollectionConfig.collection_paths is None
    except NotImplementedError:
        pass

    try:
        assert AnsibleCollectionConfig.default_collection is None
    except NotImplementedError:
        pass

    try:
        assert AnsibleCollectionConfig.on_collection_load is None
    except NotImplementedError:
        pass

    try:
        assert AnsibleCollectionConfig.playbook_paths is None
    except NotImplementedError:
        pass

# Generated at 2022-06-23 13:39:44.440248
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config.on_collection_load, _EventSource)
    assert isinstance(config._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:39:56.092911
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    evt = _EventSource()

    def handler1(arg1, arg2, kwarg1='a', kwarg2='b'):
        assert arg1 == 1
        assert arg2 == 1.1
        assert kwarg1 == 'c'
        assert kwarg2 == 'b'

    def handler2(arg1, arg2, kwarg1='a', kwarg2='b'):
        assert arg1 == 1
        assert arg2 == 1.1
        assert kwarg1 == 'c'
        assert kwarg2 == 'b'
        raise Exception('fake exception')

    evt += handler1
    evt += handler2

    evt.fire(1, 1.1, kwarg1='c')

# Generated at 2022-06-23 13:39:59.500497
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Unit test that getters are read only

# Generated at 2022-06-23 13:40:12.050108
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert issubclass(AnsibleCollectionConfig, _EventSource)

    # Smoke Test
    value = []
    def handler(x):
        value.append(x)

    AnsibleCollectionConfig.on_collection_load.fire('hello')
    assert value[:] == []

    # Add handler
    AnsibleCollectionConfig.on_collection_load += handler
    AnsibleCollectionConfig.on_collection_load.fire('hello')
    assert value[:] == ['hello']
    value[:] = []

    # Remove handler
    AnsibleCollectionConfig.on_collection_load -= handler
    AnsibleCollectionConfig.on_collection_load.fire('hello')
    assert value[:] == []

    # Exception test
    class _E(Exception):
        pass
    class _E1(_E):
        pass

# Generated at 2022-06-23 13:40:14.077774
# Unit test for constructor of class _EventSource
def test__EventSource():
    src = _EventSource()
    assert src._handlers == set()



# Generated at 2022-06-23 13:40:22.143504
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def dummy_handler1():
        pass

    def dummy_handler2():
        pass

    dummy_event_source_object = _EventSource()

    # Test: unload an unregistered handler
    dummy_event_source_object -= dummy_handler1

    # Test: unload a registered handler
    dummy_event_source_object += dummy_handler1
    dummy_event_source_object -= dummy_handler1
    assert dummy_handler1 not in dummy_event_source_object._handlers

    # Test: unload a registered handler, then re-register the same handler
    dummy_event_source_object += dummy_handler1
    assert dummy_handler1 in dummy_event_source_object._handlers

    # Test: unload a registered handler, then re-register the same handler under a new reference

# Generated at 2022-06-23 13:40:29.561762
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    eventsource = _EventSource()
    def handler(a, b=None):
        assert a == 'a'
        assert b == 'b'
        handler.called = True

    eventsource.fire('a', b='b')
    assert not handler.called

    eventsource += handler
    eventsource.fire('a', b='b')
    assert handler.called

    handler.called = False
    eventsource -= handler
    eventsource.fire('a', b='b')
    assert not handler.called

# Generated at 2022-06-23 13:40:37.619692
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class FakeHandler:
        def __init__(self):
            self.errors = []

        def __call__(self, *args, **kwargs):
            raise Exception('oops')

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.errors.append(exc)

    fake_handler = FakeHandler()

    eventsource = _EventSource()
    eventsource += fake_handler

    try:
        eventsource.fire()
    except Exception:
        pass

    assert len(fake_handler.errors) == 1
    assert isinstance(fake_handler.errors[0], Exception)
    assert fake_handler.errors[0].message == 'oops'

# Generated at 2022-06-23 13:40:39.984547
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    raise NotImplementedError('Test needs to be implemented')

# Generated at 2022-06-23 13:40:45.926534
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    ev_results = []
    def ev_handler1(arg1, arg2):
        ev_results.append('arg1=%s arg2=%s' % (arg1, arg2))

    def ev_handler2(arg1, arg2):
        ev_results.append('arg1=%s arg2=%s' % (arg1, arg2))

    source += ev_handler1
    source += ev_handler2

    source.fire(1, 2)

    assert ev_results == ['arg1=1 arg2=2', 'arg1=1 arg2=2']

# Generated at 2022-06-23 13:40:52.530946
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        raise Exception('handler2 failed')

    def handler3():
        raise NotImplementedError('handler3 is not implemented')

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()


# Generated at 2022-06-23 13:40:54.520938
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    with_metaclass(_AnsibleCollectionConfig, 'meta', 'name', 'bases')



# Generated at 2022-06-23 13:40:58.534029
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    # type: () -> None
    event = _EventSource()

    from ansible.module_utils.common._collections_compat import Mapping

    class MyMapping(Mapping):
        def __getitem__(self, _):
            return None

        def __len__(self):
            return 0

        def __iter__(self):
            return iter(())

    event += MyMapping()



# Generated at 2022-06-23 13:41:07.340570
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # TODO: It might be worthwhile to add a test for AnsibleCollectionConfig here.
    # However, it would have to be a mock implementation of the class, since
    # the functional implementation requires the ansible-galaxy executable
    # to be in your path.
    mock_callback = False

    def callback(*args, **kwargs):
        nonlocal mock_callback
        mock_callback = True

    es = _EventSource()
    es += callback
    es.fire()
    assert mock_callback

    # test that removing callback prevents it from being fired
    mock_callback = False
    es -= callback
    es.fire()
    assert not mock_callback

# Generated at 2022-06-23 13:41:14.963717
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    a = []

    def handler_1(*args, **kwargs):
        a.append(1)

    def handler_2(i, *args, **kwargs):
        a.append(i)

    def handler_3(*args, **kwargs):
        raise Exception('some exception')

    es += handler_1
    es += handler_2
    es += handler_3

    es.fire(i=2)
    assert a == [1, 2]

# Generated at 2022-06-23 13:41:18.588739
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    evt = _EventSource()
    evt += lambda x: None
    evt_len = len(evt._handlers)

    evt -= lambda x: None
    assert len(evt._handlers) == evt_len - 1

# Generated at 2022-06-23 13:41:24.427393
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # class AnsibleCollectionConfig defines 4 properties:
    #   collection_finder
    #   collection_paths
    #   default_collection
    #   on_collection_load
    #   playbook_paths

    a = AnsibleCollectionConfig()
    assert('collection_finder' in dir(a))
    assert('collection_paths' in dir(a))
    assert('default_collection' in dir(a))
    assert('on_collection_load' in dir(a))
    assert('playbook_paths' in dir(a))

# Generated at 2022-06-23 13:41:27.221485
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    acc = _AnsibleCollectionConfig()

    assert acc.collection_finder is None
    assert acc.default_collection is None
    assert acc.on_collection_load is not None

    assert acc.collection_paths == []
    assert acc.playbook_paths == []

    assert acc.on_collection_load is acc.on_collection_load


# Generated at 2022-06-23 13:41:35.794357
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Listener:
        def __init__(self):
            self.fired = False
            self.fired_count = 0

        def __call__(self):
            self.fired = True
            self.fired_count += 1

        def reset(self):
            self.fired = False
            self.fired_count = 0

    listener = _Listener()

    event_source = _EventSource()
    event_source += listener

    assert not listener.fired

    event_source.fire()
    assert listener.fired
    listener.reset()

    event_source.fire()
    assert listener.fired
    listener.reset()

    event_source -= listener

    event_source.fire()
    assert not listener.fired



# Generated at 2022-06-23 13:41:44.405427
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestObj:
        def __init__(self):
            self._event_source = _EventSource()

        @property
        def on_fire(self):
            return self._event_source

        def fire(self, *args, **kwargs):
            self._event_source.fire(*args, **kwargs)

    test_obj = TestObj()

    result = None
    event_source = test_obj.on_fire
    event_source += (lambda x: (setattr(event_source, 'result', x)))

    test_obj.fire(result='foo')

    assert event_source.result == 'foo'



# Generated at 2022-06-23 13:41:47.818895
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac_config = AnsibleCollectionConfig()
    assert ac_config.__class__.__name__ == 'AnsibleCollectionConfig'
    assert ac_config._collection_finder == None


# Generated at 2022-06-23 13:41:58.012658
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def test_cb(cb, err):
        if err:
            raise Exception(err)

    es = _EventSource()
    es.fire()

    cb_called = False
    es += lambda: cb_called.__setitem__(0, True)
    es.fire()
    test_cb(cb_called, 'callback not called')

    cb_called = False
    es -= test_cb
    es.fire()
    test_cb(cb_called, 'callback called')

    cb_called = False
    es += lambda: test_cb(cb_called, 'callback called')
    es += lambda: cb_called.__setitem__(0, True)
    es.fire()
    test_cb(cb_called, 'second callback not called')

    cb_called = False
    es

# Generated at 2022-06-23 13:42:01.021085
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Subclass(object):
        pass

    c = _AnsibleCollectionConfig(Subclass, 'TestCollectionConfig', tuple())

    assert c._collection_finder is None
    assert c._default_collection is None
    assert isinstance(c._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:42:02.811057
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    s = _EventSource()

    h = lambda: None
    s += h

    s -= h



# Generated at 2022-06-23 13:42:13.789264
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    event_source.fire()  # no handlers

    count = [0]

    def handler1(info):
        count[0] += 1

    event_source += handler1
    event_source.fire()  # one handler

    assert count[0] == 1

    def handler2(info):
        count[0] += 1

    event_source += handler2
    event_source.fire(info=123)  # two handlers

    assert count[0] == 3
    event_source -= handler1
    event_source.fire(info=123)  # one handler

    assert count[0] == 4
    event_source -= handler2
    event_source.fire(info=123)  # zero handlers

    assert count[0] == 4

    count[0] = 0
    event

# Generated at 2022-06-23 13:42:21.399453
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig(None, 'test_ac', None)

    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert isinstance(ac._on_collection_load, _EventSource)


# class _AnsibleCollectionConfig
#   - property collection_finder
#   - property collection_paths
#   - property default_collection
#   - property on_collection_load
#   - property playbook_paths
#   - property playbook_paths.setter
#   - property _require_finder

# Generated at 2022-06-23 13:42:29.259300
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert not es._handlers

    def f1(a, b=2):
        pass

    def f2():
        pass

    es += f1
    assert len(es._handlers) == 1
    es += f1
    assert len(es._handlers) == 1
    es += f2
    assert len(es._handlers) == 2
    es += f1
    assert len(es._handlers) == 2
    es -= f1
    assert len(es._handlers) == 1
    es -= f2
    assert len(es._handlers) == 0
    es -= f1
    assert len(es._handlers) == 0

# Generated at 2022-06-23 13:42:32.726188
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    class MyEventSource(_EventSource):
        pass

    es = MyEventSource()

    def method1():
        pass

    def method2():
        pass

    es += method1
    es += method2

    assert es._handlers == set([method1, method2])



# Generated at 2022-06-23 13:42:36.567349
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load._handlers == set()


# Generated at 2022-06-23 13:42:42.510153
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    success = False
    es = _EventSource()

    def handlerA(x):
        pass

    def handlerB(x):
        raise ValueError('an error occurred')

    es += handlerA
    es += handlerB
    es -= handlerA

    try:
        es.fire('an event')
        success = True
    except ValueError:
        pass

    if not success:
        raise AssertionError('unexpected failure in test__EventSource___isub__')

# Generated at 2022-06-23 13:42:48.950744
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    event_value = None

    def handler_one(value):
        global event_value
        event_value = value

    event_source += handler_one

    event_source.fire(True)
    assert event_value

    event_source.fire(123)
    assert event_value == 123


# Generated at 2022-06-23 13:42:59.284632
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class DummyEventSource(_EventSource):
        pass
    obj = DummyEventSource()

    result = []
    obj += lambda: result.append(1)
    obj += lambda: result.append(2)

    obj.fire()
    assert result == [1, 2]

    # Remove first handler and fire
    obj -= lambda: result.append(1)
    obj.fire()
    assert result == [1, 2, 2]

    # Remove all handlers and fire
    obj -= lambda: result.append(2)
    obj.fire()
    assert result == [1, 2, 2]

    # Add a handler which raises an exception
    obj += lambda: result.append(3)

# Generated at 2022-06-23 13:43:04.913793
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # validate that the constructor sets up the class properties as expected
    config_class = AnsibleCollectionConfig
    assert config_class.collection_finder is None
    assert config_class.on_collection_load is config_class._on_collection_load
    assert config_class.default_collection is None
    assert len(config_class._on_collection_load._handlers) == 0

# Generated at 2022-06-23 13:43:07.848469
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()
    assert callable(es) is False
    assert callable(es._on_exception) is True


# Generated at 2022-06-23 13:43:12.869904
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert isinstance(ac._on_collection_load, _EventSource)


# import all classes
from ansible.module_utils.common.collections import AnsibleCollectionFinder, AnsibleFileFinder, FileSystemCollectionFinder, \
    PathEntryFinder, FILESYSTEM_SUFFIXES, PATHS, SETTINGS, DEFAULT_ANSIBLE_MANAGED
