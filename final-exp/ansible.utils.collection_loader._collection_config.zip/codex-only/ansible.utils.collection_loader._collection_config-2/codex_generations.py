

# Generated at 2022-06-23 13:33:18.969637
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ########################################################################
    # arrange
    ########################################################################
    source = _EventSource()
    handler = lambda: None
    source += handler
    source += handler

    ########################################################################
    # act and assert
    ########################################################################
    source.fire()
    source.fire()



# Generated at 2022-06-23 13:33:20.247980
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()
    assert ev._handlers == set()


# Generated at 2022-06-23 13:33:24.110319
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    events = _EventSource()
    assert events == set()
    events += set()
    assert events == set()
    events += ['not callable']
    assert events == {'not callable'}
    events += set()
    assert events == {'not callable'}

    events = _EventSource()
    assert events == set()
    events += 'not callable'
    assert events == {'not callable'}



# Generated at 2022-06-23 13:33:26.701131
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    cls = AnsibleCollectionConfig()
    cls.on_collection_load += lambda: None
    cls.on_collection_load -= lambda: None
    assert cls.on_collection_load._handlers == set()

# Generated at 2022-06-23 13:33:39.121385
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyClass(object):
        def __init__(self, arg):
            self.arg = arg
        def __call__(self, *args, **kwargs):
            return self.arg

    class MySubClass(MyClass):
        def _on_exception(self, handler, exc, *args, **kwargs):
            self.arg = exc
            return False

    event_source = _EventSource()

    with pytest.raises(ValueError):
        event_source += None

    assert event_source.fire() is None

    event_source += MyClass('foo')
    assert event_source.fire() == 'foo'

    event_source += MyClass('bar')
    assert event_source.fire() == ['foo', 'bar']

    event_source = _EventSource()
    event_source += MySub

# Generated at 2022-06-23 13:33:44.378319
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def handler1(sender, *args, **kwargs):
        pass

    def handler2(sender, *args, **kwargs):
        pass

    def handler3(sender, *args, **kwargs):
        pass

    event += handler1
    event += handler2
    event += handler3

    event -= handler2
    event -= handler2

    assert len(event._handlers) == 2
    assert handler1 in event._handlers
    assert handler3 in event._handlers

# Generated at 2022-06-23 13:33:47.830995
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    instance = _EventSource()

    def handler(event):
        pass

    instance += handler
    assert handler in instance._handlers
    instance -= handler
    assert handler not in instance._handlers

# Generated at 2022-06-23 13:33:57.009860
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test function callable implementation
    def _test1():
        pass

    # Test lambda implementation
    test2 = lambda : None

    # Test class method implementation
    class test3:
        def __init__(self):
            self.x = "I am a test 3"

        def foo(self):
            pass

    test3 = test3()

    test_event_source = _EventSource()

    go_for_it = True
    test_event_source += _test1
    test_event_source += test2
    try:
        test_event_source += test3.foo
    except ValueError:
        go_for_it = False
    finally:
        assert go_for_it is True, 'test__EventSource___iadd__ failed : test_event_source += test3.foo'

    go_for

# Generated at 2022-06-23 13:33:58.398740
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig(), AnsibleCollectionConfig)

# Generated at 2022-06-23 13:34:02.815424
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def func1(a, b=1):
        pass

    def func2(a, b=2):
        pass

    es = _EventSource()
    es += func1
    es += func2

    es -= func1

    assert list(es._handlers) == [func2]


# Generated at 2022-06-23 13:34:04.964790
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    def f(x, y):
        print((x, y))

    e += f


# Generated at 2022-06-23 13:34:12.896912
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    # return value is self to allow chaining
    assert source == source - 1

# Generated at 2022-06-23 13:34:16.661467
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def func():
        pass
    assert func not in es._handlers
    es += func
    assert func in es._handlers


# Generated at 2022-06-23 13:34:18.371074
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es
    assert es._handlers == set()



# Generated at 2022-06-23 13:34:19.835852
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Ensure constructor works
    es = _EventSource()


# Generated at 2022-06-23 13:34:26.299481
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    instance = _EventSource()
    def handler1():
        pass
    def handler2():
        pass
    instance += handler1
    instance += handler2
    instance -= handler1
    assert handler1 not in instance._handlers
    assert handler2 in instance._handlers
    instance -= handler1   # handler1 should not exist, so subtracting it should be harmless
    assert handler1 not in instance._handlers
    assert handler2 in instance._handlers


# Generated at 2022-06-23 13:34:29.443386
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import ansible.utils.collection_loader

    assert not hasattr(ansible.utils.collection_loader, '_collection_finder')

# Generated at 2022-06-23 13:34:38.534375
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()

    assert ansible_collection_config.collection_finder is None
    assert ansible_collection_config.default_collection is None
    assert ansible_collection_config.collection_paths is None
    assert ansible_collection_config.playbook_paths is None
    assert ansible_collection_config.on_collection_load is not None
    assert isinstance(ansible_collection_config._on_collection_load, _EventSource)

    ansible_collection_config.on_collection_load += lambda: None

    assert isinstance(ansible_collection_config.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:34:45.664642
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    from ansible.module_utils.six import PY3

    e = _EventSource()

    def handler1(mouse):
        return mouse

    def handler2(mouse):
        return mouse

    e += handler1
    e += handler2

    assert e._handlers == {handler1, handler2}
    assert list(e._handlers) == [handler1, handler2]

    with pytest.raises(TypeError):
        if PY3:
            e += b'mouse'
        else:
            e += 'mouse'

    assert e._handlers == {handler1, handler2}
    assert list(e._handlers) == [handler1, handler2]



# Generated at 2022-06-23 13:34:46.646614
# Unit test for constructor of class _EventSource
def test__EventSource():
    msg = _EventSource()

# Generated at 2022-06-23 13:34:52.103364
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class foo:
        def __call__(self, *args, **kwargs):
            return args[0]

    m = _EventSource()
    f = foo()

    assert f(1) == 1

    m += f

    assert m._handlers == {f}

    # verify that we can add the same handler more than once
    m += f

    assert m._handlers == {f}

    try:
        m += set()
    except ValueError as e:
        assert "handler must be callable" in to_text(e)



# Generated at 2022-06-23 13:34:58.932566
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible.module_utils._text import to_native

    def handler(*args, **kwargs):
        print('handler called')

    source = _EventSource()

    source += handler

    source -= handler

    source -= handler

    try:
        source -= 'not callable'
    except ValueError as e:
        assert to_native(e) == 'handler must be callable', 'unexpected exception message'
    else:
        assert False, 'exception not raised'



# Generated at 2022-06-23 13:35:02.175609
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


# Unit tests for class _AnsibleCollectionConfig

# Generated at 2022-06-23 13:35:07.949199
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    events = _EventSource()
    assert events._handlers == set()
    events -= None
    assert events._handlers == set()
    events -= object()
    assert events._handlers == set()

    def myfunc():
        pass

    events += myfunc
    assert events._handlers == {myfunc}
    events -= myfunc
    assert events._handlers == set()



# Generated at 2022-06-23 13:35:12.067793
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestEventSource(_EventSource):
        def __init__(self):
            self.call_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1

    es = TestEventSource()
    assert len(es._handlers) == 0
    es += TestEventSource()
    assert len(es._handlers) == 1
    es += TestEventSource()
    assert len(es._handlers) == 2

    assert es.call_count == 0
    es.fire()
    assert es.call_count == 2


# Generated at 2022-06-23 13:35:16.349328
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def foo(bar):
        pass

    event_source.__iadd__(foo)

    if foo not in event_source._handlers:
        raise AssertionError('event source does not contain handler')



# Generated at 2022-06-23 13:35:18.430316
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('Test', ('Test',), {})

# Generated at 2022-06-23 13:35:23.750519
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    result = []

    def _target(event):
        result.append(event)

    event_source = _EventSource()
    event_source += _target
    event_source.fire(1)
    event_source.fire(2)
    event_source.fire(3)

    assert result == [1, 2, 3]


# Generated at 2022-06-23 13:35:25.744159
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible.module_utils.common.text.formats.ini import AnsibleIniConfig
    assert AnsibleCollectionConfig._collection_finder is None

# Generated at 2022-06-23 13:35:33.596625
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # setup
    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    event_source = MyEventSource()
    event_source += handler_first
    event_source += handler_second
    event_source += handler_exception
    event_source += handler_last

    # execute
    event_source.fire(1, 2, 3)

    # verify
    assert exception_raised

    result = '|'.join(result)
    assert result == 'handler_first|handler_second|handler_last'



# Generated at 2022-06-23 13:35:45.083603
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()

    def handler1(exc):
        raise exc

    def handler2(exc):
        pass

    def handler3(exc):
        return True

    def handler4(exc):
        raise ValueError()

    es += handler1
    es += handler2
    es += handler3
    es += handler4

    try:
        es.fire(ValueError('testing'))
        assert False, 'expected exception'
    except ValueError:
        pass

    es -= handler3

    try:
        es.fire(ValueError('testing'))
        assert False, 'expected exception'
    except ValueError:
        pass

    es -= handler1
    es -= handler2


# Generated at 2022-06-23 13:35:47.071177
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source._handlers == set()


# Generated at 2022-06-23 13:35:56.978277
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import collections
    import traceback

    def test_repr(obj):
        """
        Return a string representation as returned by repr().

        :param obj: an object
        :return: str
        """
        try:
            return repr(obj)
        except Exception as ex:
            tb = '\n'.join([('  ' + line) for line in traceback.format_exc().splitlines()])
        return "Exception occurred in repr():\n%s" % tb

    def contains(left, right):
        """
        Return True if a is contained in b.

        :param left: iterable
        :param right: iterable
        :return: bool
        """
        return all([(elem in right) for elem in left])


# Generated at 2022-06-23 13:36:08.951943
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class MyClass(object):
        def __init__(self):
            self.data = {'foo': False, 'bar': False}

        def my_handler(self, event_arg, **kwargs):
            self.data['foo'] = True

        def my_handler_raising(self, **kwargs):
            self.data['bar'] = True
            raise ValueError()

    my_class = MyClass()
    event_source = _EventSource()

    event_source += my_class.my_handler
    event_source += my_class.my_handler_raising

    event_source.fire('expected arg')

    assert my_class.data['foo']
    assert my_class.data['bar']

# Generated at 2022-06-23 13:36:11.654386
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    handler_names = [
        'handler1',
        'handler2',
        'handler3',
    ]
    handlers = dict(
        [(n, lambda: None) for n in handler_names]
    )

    event = _EventSource()

    for name in handler_names:
        event += handlers[name]
        assert handlers[name] in event._handlers
    assert len(event._handlers) == len(handler_names)



# Generated at 2022-06-23 13:36:14.581788
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert not event._handlers


# Generated at 2022-06-23 13:36:20.702766
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c1 = AnsibleCollectionConfig()
    assert c1._collection_finder is None
    assert c1._default_collection is None
    assert isinstance(c1._on_collection_load, _EventSource)

    c2 = AnsibleCollectionConfig()
    assert c2._collection_finder is None
    assert c2._default_collection is None
    assert isinstance(c2._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:36:25.459810
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()
    assert a.collection_finder is None
    assert a.default_collection is None
    assert a.on_collection_load == a._on_collection_load
    assert a.playbook_paths == []
    assert a.collection_paths == []



# Generated at 2022-06-23 13:36:38.135086
# Unit test for method fire of class _EventSource
def test__EventSource_fire():  # noqa: F811
    # pylint: disable=protected-access

    # Parameters for test
    args = ('test_args_1', 'test_args_2', 'test_args_3')
    kwargs = {'key1': 'test_kwargs_1',
              'key2': 'test_kwargs_2',
              'key3': 'test_kwargs_3'}

    # Increase the static count and verify that it is set to the
    #   value we expect
    count = [0]
    def event_handler_1(*args, **kwargs):
        '''Handle the event by increasing a count'''
        count[0] += 1

    # Verify that the event handler is called with the arguments we expect
    handler_arguments = []

# Generated at 2022-06-23 13:36:48.218515
# Unit test for constructor of class _AnsibleCollectionConfig

# Generated at 2022-06-23 13:36:51.906729
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig(None, 'fake', ())

    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert isinstance(ac._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:36:53.036103
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    def config():
        return AnsibleCollectionConfig()
    config()



# Generated at 2022-06-23 13:36:57.792153
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(p1, p2):
        assert p1 == p1_value
        assert p2 == p2_value

    es = _EventSource()
    es += handler

    p1_value = 'p1'
    p2_value = 'p2'
    es.fire(p1_value, p2_value)



# Generated at 2022-06-23 13:37:04.226505
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # Note that this is NOT the same as testing a subclass as it is the class' meta-class that
    # defines the properties.
    AnsibleCollectionConfig()

# Used by ansible-test to inject a 'Mock' implementation of AnsibleCollectionConfig
mock_ansible_collection_config = None


# Generated at 2022-06-23 13:37:08.037805
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Test(_AnsibleCollectionConfig):
        pass

    try:
        Test()
    except TypeError as ex:
        assert True
        return

    assert False, '_AnsibleCollectionConfig.__init__() required for all classes'

# Generated at 2022-06-23 13:37:11.440997
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1():
        print('handler1')

    def handler2():
        print('handler2')

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source.fire()

# Generated at 2022-06-23 13:37:20.490312
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    class TestException(Exception):
        pass

    def handle_1(*args, **kwargs):
        return None

    def handle_2(*args, **kwargs):
        raise TestException()

    event_source += handle_1
    event_source += handle_2
    event_source += handle_1

    try:
        event_source.fire()
        assert False, 'expected TestException'
    except TestException:
        pass
    assert event_source._handlers == {handle_1, handle_2}


test__EventSource_fire()

# Generated at 2022-06-23 13:37:21.398386
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource() is not None

# Generated at 2022-06-23 13:37:28.543712
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Handler:
        def __init__(self, event_source):
            self.event_source = event_source
            self.args = []
            self.kwargs = []
            self.count = 0
            event_source += self.handler

        def handler(self, *args, **kwargs):
            self.args.append(args)
            self.kwargs.append(kwargs)
            self.count += 1
            if self.count == 1:
                raise ValueError

    event_source = _EventSource()
    Handler(event_source)

    event_source.fire()
    assert len(event_source._handlers) == 1
    assert event_source._handlers.pop()
    assert len(event_source._handlers) == 0

    event_source.fire(1, a=1)

# Generated at 2022-06-23 13:37:31.425219
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    def handler(arg):
        raise RuntimeError('bleh')

    e += handler
    e -= handler

# Generated at 2022-06-23 13:37:34.750412
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:37:37.505404
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()

    # ensure initial state of event source
    assert len(e._handlers) == 0


# Unit tests for class _EventSource

# Generated at 2022-06-23 13:37:41.310693
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _AnsibleCollectionConfigTest(with_metaclass(_AnsibleCollectionConfig)):
        pass
    assert _AnsibleCollectionConfigTest._collection_finder is None
    assert _AnsibleCollectionConfigTest._default_collection is None
    assert isinstance(_AnsibleCollectionConfigTest._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:37:41.937796
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    pass

# Generated at 2022-06-23 13:37:44.134812
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')

# Generated at 2022-06-23 13:37:51.075423
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Record:
        def __init__(self):
            self.records = []

        def handler(self, one, two, three=3, four=4):
            self.records.append((one, two, three, four))

    record = Record()

    events = _EventSource()
    events += record.handler

    # fire the event, the handler should be called
    events.fire(1, 2, four=5)
    assert record.records == [(1, 2, 3, 5)]

    # fire a different event
    events.fire(2, 3, four=6)
    assert record.records == [(1, 2, 3, 5), (2, 3, 3, 6)]


# Generated at 2022-06-23 13:37:56.066695
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    func1 = lambda: print('func1')
    func2 = lambda: print('func2')

    event = _EventSource()
    event += func1
    event += func2

    assert func1 in event._handlers
    assert func2 in event._handlers



# Generated at 2022-06-23 13:38:03.174815
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    f1 = lambda x: x
    assert f1 is not None  # satisfy pyflakes about unused variables
    event_source = _EventSource()
    event_source += f1
    event_source -= f1
    try:
        event_source -= f1
    except KeyError:
        pass
    else:
        assert False, 'should of thrown KeyError'


# Generated at 2022-06-23 13:38:14.387410
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    class _MyEventSource(_EventSource):
        def __init__(self):
            super(_MyEventSource, self).__init__()
            self._events_fired = set()
            self._events_handlers = set()

        def fire(self, event, *args, **kwargs):
            self._events_fired.add(event)
            super(_MyEventSource, self).fire(event, *args, **kwargs)

        def events_fired(self):
            return self._events_fired.copy()

        def events_handlers(self):
            return self._events_handlers.copy()

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._events_handlers.add((handler, exc, args, kwargs))
            return True

    ev_src = _

# Generated at 2022-06-23 13:38:19.230336
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.collection_paths is None
    assert config.default_collection is None
    assert config.on_collection_load is not None
    assert config.playbook_paths is None

# Generated at 2022-06-23 13:38:21.227865
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestClass(_AnsibleCollectionConfig):
        pass
    assert TestClass._collection_finder is None
    assert TestClass._default_collection is None



# Generated at 2022-06-23 13:38:25.370786
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Foo(_AnsibleCollectionConfig):
        bar = 'baz'

    assert Foo._collection_finder is None
    assert isinstance(Foo._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:38:36.117009
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def handler0(*args, **kwargs):
        pass

    def handler1(a, *args, **kwargs):
        pass

    def handler2(a, b, *args, **kwargs):
        pass

    # [TEST] Test assignment of a handler function
    event += handler0
    assert len(event._handlers) == 1
    assert handler0 in event._handlers

    # [TEST] Test assignment of a handler function taking 1 parameter
    event += handler1
    assert len(event._handlers) == 2
    assert handler1 in event._handlers

    # [TEST] Test assignment of a handler function taking 2 parameters
    event += handler2
    assert len(event._handlers) == 3
    assert handler2 in event._handlers

    # [TEST] Test assignment of

# Generated at 2022-06-23 13:38:38.841840
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def handler():
        pass
    event_source += handler
    event_source -= handler


# Generated at 2022-06-23 13:38:42.877108
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible_test.unit.utils.legacy_collection_loader.test_event_source import test__EventSource___isub__
    test__EventSource___isub__(EventSource=_EventSource)


# Generated at 2022-06-23 13:38:48.603084
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert isinstance(cls._on_collection_load, _EventSource)
    assert hasattr(cls, 'collection_finder')
    assert hasattr(cls, 'collection_paths')
    assert hasattr(cls, 'default_collection')
    assert hasattr(cls, 'on_collection_load')
    assert hasattr(cls, 'playbook_paths')
    assert hasattr(cls, '_require_finder')

# Generated at 2022-06-23 13:38:53.610380
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:38:56.097891
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert type(AnsibleCollectionConfig._on_collection_load) is _EventSource

# Generated at 2022-06-23 13:39:07.946979
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # A test class which implements the handler
    class DummyHandlerClass:
        def __init__(self):
            self._invocation_count = 0

        def __call__(self, *args, **kwargs):
            self._invocation_count += 1

    # Create a class instance, a handler, and three event sources
    handler = DummyHandlerClass()
    source1 = _EventSource()
    source2 = _EventSource()
    source3 = _EventSource()

    # Add the handler to all three event sources
    source1 += handler
    source2 += handler
    source3 += handler

    # Fire each event source to ensure that the handler is called once per event source
    source1.fire()
    source2.fire()
    source3.fire()
    assert handler._invocation_count == 3



# Generated at 2022-06-23 13:39:11.301233
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def f():
        pass

    def g():
        raise ValueError('foo')

    ev = _EventSource()
    ev += f
    ev += g

    try:
        ev.fire()
        assert False

    except ValueError:
        pass

    assert len(ev._handlers) == 2

    # g should be removed from the list of handlers
    ev.fire()
    assert len(ev._handlers) == 1

# Generated at 2022-06-23 13:39:17.461517
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    test_event_source = _EventSource()
    assert test_event_source._handlers == set()

    test_event_source.__iadd__(lambda x: 1)
    assert test_event_source._handlers == set([lambda x: 1])

    test_event_source.__isub__(lambda x: 1)
    assert test_event_source._handlers == set()


# Generated at 2022-06-23 13:39:18.406378
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource()


# Generated at 2022-06-23 13:39:20.801936
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Test(_AnsibleCollectionConfig):
        pass
    Test()

# Generated at 2022-06-23 13:39:30.257024
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, 'collection_finder'), 'AnsibleCollectionConfig.collection_finder is not defined'
    assert hasattr(AnsibleCollectionConfig, 'collection_paths'), 'AnsibleCollectionConfig.collection_paths is not defined'
    assert hasattr(AnsibleCollectionConfig, 'default_collection'), 'AnsibleCollectionConfig.default_collection is not defined'
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load'), 'AnsibleCollectionConfig.on_collection_load is not defined'
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths'), 'AnsibleCollectionConfig.playbook_paths is not defined'

# Generated at 2022-06-23 13:39:37.425260
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig()
        assert False, 'CollectionConfig should not be instantiatable'
    except TypeError:
        pass

    # collection_paths
    AnsibleCollectionConfig.collection_paths = ['foo', 'bar']
    assert AnsibleCollectionConfig.collection_paths == ['foo', 'bar']

    try:
        AnsibleCollectionConfig.collection_paths = 'foo'
        assert False, 'collection_paths must be sequence'
    except ValueError:
        pass

    # default_collection
    AnsibleCollectionConfig.default_collection = 'this.is.a.collection'
    assert AnsibleCollectionConfig.default_collection == 'this.is.a.collection'


# Generated at 2022-06-23 13:39:39.421656
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:39:43.903247
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # view is an instance of _EventSource
    view = _EventSource()
    # first we create an empty handler
    def handler():
        pass
    # Add the handler to the _EventSource
    view += handler
    # This method is not to be discovered in the method fire of _EventSource
    def error():
        return IAmAnError()
    # The method error is to be discovered in the method fire of _EventSource
    view.fire(error)

# Generated at 2022-06-23 13:39:53.141439
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def f(s, kw):
        pass

    def g(s, kw):
        raise Exception('Test exception.')

    def h(s, kw):
        raise Exception('Another test exception.')

    def oracle(handler, exc, *args, **kwargs):
        return False

    s = _EventSource()
    s += f
    s += g
    s._on_exception = oracle

    s.fire('a', 'b')
    s.fire('a', 'b')

# Generated at 2022-06-23 13:40:02.304883
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    event_source = _EventSource()
    handler_outputs = []
    handler_exceptions = []
    handler_names = []
    def handler(name):
        def _handler(*args, **kwargs):
            handler_outputs.append('({}, {}, {}, {})'.format(name, args, kwargs, to_text(exc)))
            handler_names.append(name)
            if handler_exceptions:
                to_raise = handler_exceptions.pop(0)
                raise to_raise
        return _handler

    handler1 = handler('handler1')
    handler2 = handler('handler2')
    handler3 = handler('handler3')
    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2, 'c': 3}
   

# Generated at 2022-06-23 13:40:04.399410
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler1 = object()
    handler2 = object()
    event_source += handler1
    event_source += handler2

    event_source -= handler1
    event_source -= handler2
    event_source -= handler2


# Generated at 2022-06-23 13:40:15.728225
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Import this module to initialize AnsibleCollectionConfig from its metaclass
    from ansible_collections.ansible.community.plugins.module_utils.collection_loader import _AnsibleCollectionConfig

    _event_source = _EventSource()
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

    def _handler_1(event, *args, **kwargs):
        assert event == 'on collection load'
        assert args == (1, 2, 3)
        assert kwargs == {'a': 1, 'b': 2}

    def _handler_2(*args, **kwargs):
        assert args == (1, 2, 3)
        assert kwargs == {'a': 1, 'b': 2}
        raise Exception('handler 2 exception')

    _event_source += _handler_

# Generated at 2022-06-23 13:40:18.667491
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_paths is None
    assert config.playbook_paths is None
    assert config.collection_finder is None

# Generated at 2022-06-23 13:40:25.811086
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    class EventHandler:
        def __call__(self, *args, **kwargs):
            pass

    assert Callable(type(EventHandler()))

    event += EventHandler()
    event += EventHandler()
    event += EventHandler()
    event += EventHandler()
    event += EventHandler()

    assert len(event._handlers) == 5
    event -= EventHandler()
    assert len(event._handlers) == 0


# Generated at 2022-06-23 13:40:27.730105
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert isinstance(c._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:40:30.161915
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._on_collection_load._handlers == set()

# Generated at 2022-06-23 13:40:39.221677
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    class _TestException(Exception):
        pass

    class _TestHandler:
        def __init__(self, fire_handlers, on_exception_handlers, raise_exception=False):
            self.fire_handlers = fire_handlers
            self.on_exception_handlers = on_exception_handlers
            self.raise_exception = raise_exception

        def __call__(self, *args, **kwargs):
            self.fire_handlers.append(repr(self))
            if self.raise_exception:
                raise _TestException()

        def _on_exception(self, *args, **kwargs):
            self.on_exception_handlers.append(repr(self))
            return False


# Generated at 2022-06-23 13:40:41.736529
# Unit test for constructor of class _EventSource
def test__EventSource():
    instance = _EventSource()

    assert isinstance(instance, _EventSource)
    assert isinstance(instance._on_exception, MethodType)


# Generated at 2022-06-23 13:40:47.008449
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible_test._internal.utils.target_collection_loader import AnsibleCollectionConfig

    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.on_collection_load is not None

# Generated at 2022-06-23 13:40:57.671624
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class ACF(object):
        pass

    test_config = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert not test_config.collection_finder
    assert not test_config.collection_paths
    assert not test_config.default_collection
    assert not test_config.playbook_paths
    assert test_config.on_collection_load

    test_config.collection_finder = ACF()
    test_config.default_collection = 'my_collection'
    test_config.playbook_paths = ['/playbook/path']

    assert isinstance(test_config.collection_finder, ACF)
    assert test_config.collection_paths == []
    assert test_config.default_collection == 'my_collection'

# Generated at 2022-06-23 13:41:04.670539
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler1():
        pass

    def handler2():
        pass

    def handler3():
        pass

    event = _EventSource()
    event -= handler1
    event += handler2
    event += handler3
    assert handler1 not in event._handlers
    assert handler2 in event._handlers
    assert handler3 in event._handlers
    event -= handler2
    assert handler2 not in event._handlers
    assert handler3 in event._handlers

# Generated at 2022-06-23 13:41:09.857390
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    seen_args = []
    seen_kwargs = []

    def handler(*args, **kwargs):
        seen_args.append(args)
        seen_kwargs.append(kwargs)

    events = _EventSource()
    events += handler

    events.fire(1, 2, 3)
    events.fire(x=42)

    assert seen_args == [(1, 2, 3), ()], 'seen args were %s' % seen_args
    assert seen_kwargs == [{}, {'x': 42}], 'seen kwargs were %s' % seen_kwargs

# Generated at 2022-06-23 13:41:11.030698
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:41:14.182949
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None

# Generated at 2022-06-23 13:41:15.388412
# Unit test for constructor of class _EventSource
def test__EventSource():
    sut = _EventSource()
    assert sut


# Generated at 2022-06-23 13:41:24.607594
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class Foo(AnsibleCollectionConfig):
        pass

    f = Foo()
    assert not f.collection_finder
    assert not f.default_collection
    assert f.on_collection_load is f._on_collection_load

    # should be able to set the collection finder
    from ansible.errors import AnsibleError
    import ansible_collections.ansible.foo.plugins.module_utils.module_common as mc

    f.collection_finder = mc.CollectionFinder()

    # should not be possible to set again
    with pytest.raises(AnsibleError):
        f.collection_finder = mc.CollectionFinder()

    # should not be possible to set directly on the on_collection_load property

# Generated at 2022-06-23 13:41:28.250899
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    test_obj = _EventSource()

    def test_handler():
        pass

    test_obj += test_handler
    test_obj -= test_handler

    assert test_obj._handlers == set()



# Generated at 2022-06-23 13:41:33.126016
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        cls = AnsibleCollectionConfig()
    except Exception as e:
        pytest.fail("Failed creating object: "+str(e))
    assert cls._collection_finder == None
    assert cls._default_collection == None
    assert isinstance(cls._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:41:38.924726
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cfg = AnsibleCollectionConfig()
    # pylint: disable=no-member
    cfg.collection_finder = 'AnsibleCollectionFinder'
    assert not cfg.collection_paths
    assert not cfg.default_collection
    # pylint: enable=no-member


# Generated at 2022-06-23 13:41:44.403597
# Unit test for constructor of class _EventSource
def test__EventSource():

    def foo(x, y):
        assert x == 'bar'
        assert y == 42

    s = _EventSource()
    assert len(s._handlers) == 0

    try:
        s.__iadd__(foo)
        s.fire('bar', y=42)
    finally:
        s.__isub__(foo)

    # TODO: test exc handling

    assert len(s._handlers) == 0



# Generated at 2022-06-23 13:41:47.386805
# Unit test for constructor of class _EventSource
def test__EventSource():
    import doctest

    failed, tested = doctest.testmod(verbose=True)

    if failed:
        raise AssertionError("Doctest failed")



# Generated at 2022-06-23 13:41:57.687855
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        pass

    class EventNotHandled(Exception):
        pass

    event_source = EventSource()
    event_source.fire(1)

    def handler1(a):
        print('handler1:', a)

    def handler2(*args, **kwargs):
        print('handler2:', args, kwargs)

    def handler3(*args, **kwargs):
        print('handler3:', args, kwargs)
        return True

    def handler4(*args, **kwargs):
        print('handler4:', args, kwargs)
        raise EventNotHandled(kwargs['exc'])

    event_source += handler1
    event_source.fire(1)
    event_source += handler2
    event_source.fire(1, b=2)
   

# Generated at 2022-06-23 13:42:05.701193
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    # this one should not throw an exception
    event_source.fire()

    def handler(exc):
        # this one should throw an exception
        raise exc

    event_source += handler
    try:
        event_source.fire(Exception('boom'))
        assert False
    except Exception:
        pass

    event_source -= handler
    # this one should not throw an exception
    event_source.fire()

# Generated at 2022-06-23 13:42:08.694297
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.__name__ == 'AnsibleCollectionConfig'
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.on_collection_load


# Generated at 2022-06-23 13:42:11.730247
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()  # pylint: disable=invalid-name

    def handler(arg):
        assert arg == 0
    event_source += handler

    event_source.fire(0)

# Generated at 2022-06-23 13:42:23.342179
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert type(AnsibleCollectionConfig._on_collection_load) is _EventSource
    assert not AnsibleCollectionConfig._on_collection_load._handlers
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None

    # ensure that the metaclass properly defines the events
    class CollectionConfig(AnsibleCollectionConfig):
        pass

    CollectionConfig.default_collection = 'foo.bar'
    assert CollectionConfig.default_collection == 'foo.bar'
    CollectionConfig.collection_finder = object()
    assert CollectionConfig.collection_finder

    assert isinstance(CollectionConfig.on_collection_load, _EventSource)
    assert CollectionConfig.on_collection_load is not AnsibleCollectionConfig.on_collection_load
    assert CollectionConfig.on_collection_load._handlers == set()

# Generated at 2022-06-23 13:42:24.012071
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder == None

# Generated at 2022-06-23 13:42:29.682167
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    handler = lambda: None
    event_source = _EventSource()

    # We can add callable objects to the event source
    event_source += handler

    try:
        # We cannot add non-callable objects to the event source
        event_source += None
        assert False
    except ValueError:
        pass


# Generated at 2022-06-23 13:42:36.415304
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    '''
    _EventSource.fire calls each handler in the set, passing in the arguments provided
    and ignoring Exceptions raised.
    '''

    def handler(a, b):
        return (a, b)

    event_source = _EventSource()
    event_source += handler
    out = event_source.fire('a', 'b')

    assert out is None


# Generated at 2022-06-23 13:42:41.450871
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def add_one(arg):
        return arg + 1

    es += add_one

    assert add_one in es._handlers

    def add_two(arg):
        return arg + 2

    es += add_two

    assert add_one in es._handlers
    assert add_two in es._handlers


# Generated at 2022-06-23 13:42:43.658004
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()



# Generated at 2022-06-23 13:42:47.960530
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert c._collection_finder is None
    assert c._default_collection is None

    assert isinstance(c._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:42:52.155410
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert config._on_collection_load
    assert config.on_collection_load is config._on_collection_load
    assert config._on_collection_load != 120

# Generated at 2022-06-23 13:42:53.781455
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()


# Generated at 2022-06-23 13:43:01.643908
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')

    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

    with AnsibleCollectionConfig() as cfg:
        assert cfg.collection_finder is None
        assert cfg.default_collection is None
        assert isinstance(cfg.on_collection_load, _EventSource)


# Generated at 2022-06-23 13:43:05.064413
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:43:09.826713
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    try:
        es += None
        assert False, "expected ValueError"
    except ValueError:
        pass

    es += lambda: None

    f = lambda: None

    es += f

    try:
        es += f
        assert False, "expected ValueError"
    except ValueError:
        pass


# Generated at 2022-06-23 13:43:13.115072
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.__dict__.get('_AnsibleCollectionConfig__init__') is not None


if __name__ == "__main__":
    import sys
    sys.stderr.write('use the test harness')
    sys.exit(0)