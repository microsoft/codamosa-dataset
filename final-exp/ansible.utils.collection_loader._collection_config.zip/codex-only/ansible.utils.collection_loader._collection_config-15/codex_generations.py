

# Generated at 2022-06-23 13:33:24.370595
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    error_msg = 'on_error handler called during fire of _EventSource'

    def on_error(handler, exc, *args, **kwargs):
        assert False, error_msg

    def handler1(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3

    def handler2(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        raise ValueError()

    event = _EventSource()
    event._on_error = on_error
    event += handler1
    event += handler2
    event += handler1

    try:
        event.fire(1, 2, c=3)
    except ValueError:
        pass
    else:
        assert False, error_msg

# Generated at 2022-06-23 13:33:32.212259
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source = _EventSource()

    def handler_one(arg1, arg2=None, arg3=None):
        assert arg1 == 1
        assert arg2 == 2
        assert arg3 == 3

    event_source += handler_one
    event_source.fire(1, 2, arg3=3)

    def handler_two(arg1, arg2=None, arg3=None):
        assert arg1 == 1
        assert arg2 == 2
        assert arg3 == 3
        raise Exception('bad handler')

    event_source += handler_two
    try:
        event_source.fire(1, 2, arg3=3)
        assert False
    except Exception:
        # expect the exception from handler_two to be raised
        assert True


# Generated at 2022-06-23 13:33:37.612604
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def on_load(msg):
        print('on_load called with msg: {}'.format(msg))

    def on_exception(handler, exc, *args, **kwargs):
        print('on_exception called with handler: {}, exc: {}, args: {}, kwargs: {}'.format(handler, exc, args, kwargs))
        return True

    events = _EventSource()
    events._on_exception = on_exception
    events += on_load

    events.fire('hello')
    events -= on_load
    events.fire('world')
    #events += None
    #events.fire('again')

# Generated at 2022-06-23 13:33:38.831698
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig is not None
    ansible_collection_config = AnsibleCollectionConfig()
    assert ansible_collection_config._collection_finder is None


# Generated at 2022-06-23 13:33:42.110856
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _Foo:
        pass

    class _Bar:
        pass

    event_source = _EventSource()

    event_source += _Foo
    event_source += _Bar

    assert event_source._handlers == {_Foo, _Bar}



# Generated at 2022-06-23 13:33:44.270032
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert isinstance(event, _EventSource)


# Generated at 2022-06-23 13:33:46.016469
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig(None, 'AnsibleCollectionConfig', (AnsibleCollectionConfig,))

# Generated at 2022-06-23 13:33:53.206308
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def callback():
        pass

    event = _EventSource()
    event += callback
    try:
        event -= callback  # call to __isub__
    except Exception as ex:
        assert False, '__isub__ should be successful when removing existing callback'
    else:
        assert True

    try:
        event -= callback  # call to __isub__ 
    except KeyError as ex:
        assert True
        return

    assert False, '__isub__ should throw an exception when no handlers are present'



# Generated at 2022-06-23 13:34:03.659206
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import mock

    mock_handler = mock.Mock()
    mock_handler.return_value = None

    event_source = _EventSource()
    event_source += mock_handler

    assert mock_handler.call_count == 0

    event_source.fire()
    mock_handler.assert_called_with()

    event_source.fire(1)
    mock_handler.assert_called_with(1)
    mock_handler.assert_any_call(1)

    event_source.fire(2, 3)
    mock_handler.assert_called_with(2, 3)
    mock_handler.assert_any_call(2, 3)

    event_source.fire(a='a')
    mock_handler.assert_called_with(a='a')

# Generated at 2022-06-23 13:34:11.707616
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def f1(a, b):
        pass

    def f2(x, y):
        pass

    es = _EventSource()

    # add the first event handler
    es += f1
    assert f1 in es._handlers

    # add the second event handler
    es += f2
    assert f2 in es._handlers

    # attempt to add a non-callable as a handler
    try:
        es += 1
    except ValueError:
        pass
    else:
        assert False, 'Adding a non-callable should have caused an exception'


# Generated at 2022-06-23 13:34:14.252376
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)


# Generated at 2022-06-23 13:34:20.330346
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()

    class Handler:
        def __call__(self, *args, **kwargs):
            pass

    handler = Handler()

    event_source += handler
    event_source += handler

    assert len(event_source._handlers) == 1

    event_source -= handler
    event_source -= handler

    assert len(event_source._handlers) == 0



# Generated at 2022-06-23 13:34:24.008267
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Test(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert Test._collection_finder is None
    assert Test._default_collection is None
    assert isinstance(Test._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:34:25.271995
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()



# Generated at 2022-06-23 13:34:37.143759
# Unit test for constructor of class _EventSource
def test__EventSource():
    def f(): pass
    def h(*args, **kwargs): pass

    es = _EventSource()

    assert len(es._handlers) == 0

    es += f
    assert len(es._handlers) == 1
    assert f in es._handlers

    es += h
    assert len(es._handlers) == 2
    assert f in es._handlers
    assert h in es._handlers

    # check for errors
    try:
        es += None
        assert False, 'should have raised a ValueError'
    except ValueError:
        pass

    # check for multi-add of same handler
    es += f
    assert len(es._handlers) == 2

    es -= None
    assert len(es._handlers) == 2

    es -= f
    assert len(es._handlers) == 1

   

# Generated at 2022-06-23 13:34:42.068275
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)


# Generated at 2022-06-23 13:34:44.092873
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.on_collection_load == _EventSource()



# Generated at 2022-06-23 13:34:48.546721
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    def func():
        pass
    e += func
    assert len(e._handlers) == 1
    e -= func
    assert len(e._handlers) == 0
    e += '', func
    assert len(e._handlers) == 1
    e -= ''
    assert len(e._handlers) == 0

# Generated at 2022-06-23 13:34:51.469423
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    assert len(event._handlers) == 0

    def test():
        pass

    event += test

    event -= test

    assert len(event._handlers) == 0



# Generated at 2022-06-23 13:35:00.884245
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.not_a_real_module import EventSourceTestHelper

    event_source = _EventSource()
    test_helper1 = EventSourceTestHelper()
    test_helper2 = EventSourceTestHelper()
    event_source.on_collection_load += test_helper1.on_collection_load
    event_source.on_collection_load += test_helper2.on_collection_load

    event_source.fire(event='event')

    assert test_helper1.event == 'event'
    assert test_helper1.kwargs == dict()
    assert test_helper2.event == 'event'
    assert test_helper2.kwargs == dict()


# Generated at 2022-06-23 13:35:03.750296
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    instance = AnsibleCollectionConfig()  # noqa: F841 pylint: disable=unused-variable

# Generated at 2022-06-23 13:35:12.987340
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def raise_exception(ex):
        raise ex

    def multiply(a, b, c):
        return a * b * c

    def on_exception(handler, ex, *args, **kwargs):
        # raise the exception after each handler has run and it has been caught
        raise ex

    event_source = _EventSource()
    event_source.on_exception = on_exception
    event_source += multiply
    event_source += raise_exception
    event_source += multiply
    event_source += lambda x, y: x + y
    event_source += multiply

    # No exception
    try:
        event_source.fire(2, 3, 4)
    except Exception as e:
        assert False, 'An exception was raised: %s' % e
    else:
        assert True

    # Exception

# Generated at 2022-06-23 13:35:16.155697
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(data):
        pass
    es = _EventSource()
    es += handler
    es += handler
    es += handler
    assert len(es._handlers) == 1


# Generated at 2022-06-23 13:35:19.343027
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._on_collection_load is not None
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None

# Generated at 2022-06-23 13:35:24.382475
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    i = 0

    def handler():
        nonlocal i
        i += 1

    event = _EventSource()
    event += handler

    assert i == 0

    event.fire()

    assert i == 1

    event += handler
    event.fire()

    assert i == 3


# Generated at 2022-06-23 13:35:26.940995
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    e += lambda *a, **kw: 1  # no exception
    assert len(e._handlers) == 1


# Generated at 2022-06-23 13:35:29.713320
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        config = AnsibleCollectionConfig()
    except:
        assert False, '_AnsibleCollectionConfig constructor failed'
    assert True, '_AnsibleCollectionConfig constructor passed'

# Generated at 2022-06-23 13:35:32.959589
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    did_it = [False]

    def make_one(i):
        def one(sender, *args, **kwargs):
            assert i == 1
            assert sender == event
            assert args == ('arg',)
            assert kwargs == {'kwarg': 'kwarg'}
            did_it[0] = True

        return one

    event += make_one(1)

    event.fire('arg', kwarg='kwarg')

    assert did_it[0]



# Generated at 2022-06-23 13:35:34.384240
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()

# Generated at 2022-06-23 13:35:40.541027
# Unit test for method __iadd__ of class _EventSource

# Generated at 2022-06-23 13:35:43.713655
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def test_handler(a): pass
    event_source += test_handler
    event_source -= test_handler
    assert event_source._handlers == set()

# Generated at 2022-06-23 13:35:45.397062
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig(object, 'Test', object)

# Generated at 2022-06-23 13:35:47.783812
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # simple test
    event_source = _EventSource()
    event_source += lambda: True
    event_source += lambda: False


# Generated at 2022-06-23 13:35:50.506098
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(_AnsibleCollectionConfig, type)
    assert issubclass(_AnsibleCollectionConfig, type)
    assert issubclass(__class__, type)

# Generated at 2022-06-23 13:35:53.584329
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # The only meaningful thing we can test is that the 'collections' attribute
    # is set to the correct value
    assert AnsibleCollectionConfig.collections == AnsibleCollectionConfig.collections


# Generated at 2022-06-23 13:35:56.516500
# Unit test for constructor of class _EventSource
def test__EventSource():
    # test default constructor
    ev = _EventSource()
    assert not ev._handlers
    # test adding a handler
    my_handler = lambda: None
    ev += my_handler
    assert my_handler in ev._handlers


# Generated at 2022-06-23 13:36:01.376658
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    def handler(message):
        print(message)

    assert handler not in event._handlers
    event += handler
    assert handler in event._handlers



# Generated at 2022-06-23 13:36:08.076809
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    '''
    Test that method __iadd__() of class _EventSource
    raises correct exception when the parameter is not callable.
    '''

    eventsource = _EventSource()

    try:
        eventsource.__iadd__('notcallable')
    except ValueError:
        pass
    else:
        raise AssertionError('Raised an exception when the parameter is not callable')


# Generated at 2022-06-23 13:36:10.973415
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None, 'collection_finder property was not initialized'
    assert config.collection_paths is None, 'collection_paths property was not initialized'
    assert config.default_collection is None, 'default_collection property was not initialized'
    assert config.on_collection_load is None, 'on_collection_load property was not initialized'
    assert config.playbook_paths is None, 'playbook_paths property was not initialized'



# Generated at 2022-06-23 13:36:18.150471
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    called_functions = []
    def on_load(name):
        called_functions.append(name)

    config = AnsibleCollectionConfig()
    config.on_collection_load += on_load
    config.on_collection_load.fire('foo')
    config.on_collection_load -= on_load
    config.on_collection_load.fire('bar')
    assert called_functions == ['foo']



# Generated at 2022-06-23 13:36:19.854091
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)


# Generated at 2022-06-23 13:36:27.002788
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class SomeException(Exception):
        def __init__(self, expected, real):
            super(SomeException, self).__init__('expected %s, but was %s' % (expected, real))

    class SomeHandler1(object):
        def __init__(self, expected_args, expected_kwargs):
            self.expected_args = expected_args
            self.expected_kwargs = expected_kwargs

        def __call__(self, *args):
            if self.expected_args != args:
                raise SomeException(self.expected_args, args)

    class SomeHandler2(object):
        def __init__(self, expected_args, expected_kwargs):
            self.expected_args = expected_args
            self.expected_kwargs = expected_kwargs


# Generated at 2022-06-23 13:36:37.914801
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def _add_one(x):
        return x + 1

    def _multiply_by_two(x):
        return x * 2

    def _incapacitate(x):
        raise Exception('can\'t handle number')

    events = _EventSource()

    events += _add_one
    events += _multiply_by_two
    events += _incapacitate

    assert events.fire(0) == 2
    try:
        events.fire(0)
        assert False, 'should not be able to fire on incapacitated events'
    except Exception:
        pass

    events -= _incapacitate
    assert events.fire(0) == 2


# Generated at 2022-06-23 13:36:48.211590
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    my_fired = []

    def handler1(arg):
        my_fired.append(('handler1', arg))

    def handler2(arg):
        my_fired.append(('handler2', arg))

    def handler3(arg):
        my_fired.append(('handler3', arg))

    def handler4(arg):
        my_fired.append(('handler4', arg))
        raise RuntimeError('oops')

    value = 'some value'

    source = _EventSource()
    source += handler1
    source += handler2
    source += handler3
    source += handler4
    source.fire(value)

    expected_fired = [
        ('handler1', value),
        ('handler2', value),
        ('handler3', value),
        ('handler4', value),
    ]


# Generated at 2022-06-23 13:36:59.341413
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_no_exception(*args, **kwargs):
        pass

    def handler_exception(*args, **kwargs):
        raise Exception

    es = _EventSource()
    assert not es._handlers
    es += handler_no_exception
    es += handler_exception
    assert len(es._handlers) == 2

    es.fire()
    assert len(es._handlers) == 2

    assert es._on_exception == _EventSource._on_exception
    _EventSource._on_exception = None

    try:
        es.fire()
    except:
        pass

    assert len(es._handlers) == 2

    try:
        es.fire()
    except:
        pass

    assert len(es._handlers) == 1
    es.fire()

# Generated at 2022-06-23 13:37:03.460894
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac.collection_paths == []
    assert ac.default_collection is None
    assert ac.playbook_paths == []

# Generated at 2022-06-23 13:37:08.490566
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class CustomCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert CustomCollectionConfig._collection_finder is None
    assert CustomCollectionConfig._default_collection is None
    assert isinstance(CustomCollectionConfig._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:37:15.751276
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    s = _EventSource()
    def handler1():
        pass

    def handler2():
        pass

    def handler3():
        pass

    s += handler1
    s += handler2
    s += handler3
    assert len(s._handlers) == 3

    s -= handler1
    assert len(s._handlers) == 2

    s -= handler2
    assert len(s._handlers) == 1

    s -= handler3
    assert len(s._handlers) == 0

    # make sure removing an item not in the list doesn't throw an exception
    s -= handler3
    assert len(s._handlers) == 0

# Generated at 2022-06-23 13:37:23.041615
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    class EventHandler:
        def __init__(self):
            self.call_count = 0
            self.args = None
        def __call__(self, *args):
            self.call_count += 1
            self.args = args

    event_handler0 = EventHandler()
    event_handler0.call_count = 0

    event_source += event_handler0
    assert event_handler0.call_count == 0

    event_source.fire('abc')

    assert event_handler0.call_count == 1
    assert event_handler0.args == ('abc', )

# Generated at 2022-06-23 13:37:29.994981
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    func_h1 = lambda x: None
    func_h2 = lambda x: None

    assert event_source._handlers == set()
    event_source += func_h1
    assert event_source._handlers == set([func_h1])
    event_source += func_h2
    assert event_source._handlers == set([func_h1, func_h2])
    # ensure duplicate attempts to add function are ignored
    event_source += func_h2
    assert event_source._handlers == set([func_h1, func_h2])
    # ensure set does not contain a non-function
    event_source += 'this is an invalid event handler'
    assert event_source._handlers == set([func_h1, func_h2])

# Generated at 2022-06-23 13:37:35.996920
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(event, data):
        pass

    ev = _EventSource()
    assert ev._handlers == set()

    ev += handler
    assert ev._handlers == {handler}

    ev -= handler
    assert ev._handlers == set()

    ev = _EventSource()
    ev += handler
    ev += handler
    assert ev._handlers == {handler}

# Generated at 2022-06-23 13:37:41.896762
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # Method __init__()
    # Reloading the module will ensure that class properties are created again
    from ansible.module_utils.common._collections_compat import (AnsibleCollectionConfig)

    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None

# Unit tests for the class AnsibleCollectionConfig

# Generated at 2022-06-23 13:37:42.826088
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-23 13:37:45.229656
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert len(AnsibleCollectionConfig.collection_paths) == 0
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None

# Generated at 2022-06-23 13:37:53.322006
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler_one(*args, **kwargs):
        print('handler_one (*args, **kwargs)')

    def handler_two(*args, **kwargs):
        print('handler_two (*args, **kwargs)')

    e = _EventSource()
    e += handler_one
    e += handler_two
    e.fire()


test__EventSource()


# Generated at 2022-06-23 13:37:55.550964
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    collection_config = AnsibleCollectionConfig()
    assert isinstance(collection_config, AnsibleCollectionConfig)

# Generated at 2022-06-23 13:38:00.400239
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()

    # be sure the python3 class variables have been initialized
    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert ac._on_collection_load is not None


# Generated at 2022-06-23 13:38:07.409612
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert isinstance(c, AnsibleCollectionConfig)
    assert isinstance(c, _AnsibleCollectionConfig)
    assert issubclass(c.__class__, AnsibleCollectionConfig)
    assert hasattr(c, 'collection_finder')
    assert hasattr(c, 'collection_paths')
    assert hasattr(c, 'default_collection')
    assert hasattr(c, 'on_collection_load')
    assert hasattr(c, 'playbook_paths')



# Generated at 2022-06-23 13:38:12.040320
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class AnsibleCollectionConfig2(with_metaclass(_AnsibleCollectionConfig)):
        pass
    assert AnsibleCollectionConfig2._collection_finder is None
    assert AnsibleCollectionConfig2._default_collection is None
    assert AnsibleCollectionConfig2._on_collection_load is not None


# Generated at 2022-06-23 13:38:18.409594
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # create class manually to avoid __init__ method
    class TestEventSource(with_metaclass(_EventSource)):
        pass

    event = TestEventSource()

    # assign a function to the even
    def handler():
        return

    event += handler

    # remove it
    event -= handler

    # make sure it is gone
    assert handler not in event._handlers

# Generated at 2022-06-23 13:38:19.324717
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source



# Generated at 2022-06-23 13:38:23.778257
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)

    # instantiate the class
    t = _AnsibleCollectionConfig('meta', 'AnsibleCollectionConfigBase', ())
    assert isinstance(t, _AnsibleCollectionConfig)

    # test the class properties
    assert not t.collection_finder
    assert not t.default_collection
    assert isinstance(t.on_collection_load, _EventSource)
    assert not t.playbook_paths



# Generated at 2022-06-23 13:38:34.659198
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockedClass():
        def mockedCallable1(self, *args, **kwargs):
            return 0

        def mockedCallable2(self, *args, **kwargs):
            return

    mockedObject = MockedClass()

    # create an _EventSource instance
    source = _EventSource()

    # add mocked callables
    source += mockedObject.mockedCallable1
    source += mockedObject.mockedCallable2

    # call fire with some arguments
    source.fire(1, 2, arg='value')

    # remove mocked callables
    source -= mockedObject.mockedCallable1
    source -= mockedObject.mockedCallable2

    # call fire with some arguments
    source.fire(1, 2, arg='value')

    # remove mocked callables again
    source -= mockedObject.mockedCallable1

# Generated at 2022-06-23 13:38:46.640300
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def event1_cb(arg1, arg2, kwarg1=None, kwarg2=None):
        pass

    def event2_cb(arg1, arg2, kwarg1=None, kwarg2=None):
        pass

    event = _EventSource()

    # Test firing of empty event list. This is the normal case.
    event.fire(arg1=1, arg2=2, kwarg1=3, kwarg2=4)

    # Test firing an event list containing a single item.
    event += event1_cb
    event.fire(arg1=1, arg2=2, kwarg1=3, kwarg2=4)
    event -= event1_cb

    # Test firing an event list containing multiple items.
    event += event1_cb
    event += event

# Generated at 2022-06-23 13:38:51.711924
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
        es = _EventSource()
        def handler_one(a, b=2, c=3):
            print('in 1:', a, b, c)
        def handler_two(a, b=2, c=3):
            print('in 2:', a, b, c)
        es += handler_one
        es += handler_two

        es.fire(b=2)
        es.fire('foo', 3, 4)

# test_EventSource_fire()

# Generated at 2022-06-23 13:38:57.062168
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Setup
    es = _EventSource()
    handler = lambda: None

    assert handler not in es._handlers

    # Test missing handler
    es.__isub__(handler)
    assert handler not in es._handlers

    # Test existing handler
    es._handlers.add(handler)
    es.__isub__(handler)
    assert handler not in es._handlers

# Generated at 2022-06-23 13:39:00.684027
# Unit test for constructor of class _EventSource
def test__EventSource():
    s = _EventSource()
    assert isinstance(s, _EventSource)
    assert s._handlers == set()


# Generated at 2022-06-23 13:39:06.139096
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    """Unit test for method __isub__ of class _EventSource."""

    def foo():
        pass

    def bar():
        raise ValueError("Bar was called")

    event_source = _EventSource()
    event_source += foo
    event_source += bar

    event_source -= foo
    assert set(event_source._handlers) == set([bar])

# Generated at 2022-06-23 13:39:10.792754
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    class Method1(object):
        def __init__(self, obj):
            self.obj = obj
        def __call__(self, *args, **kwargs):
            self.obj.called = True

    class Method2(object):
        def __init__(self, obj):
            self.obj = obj
        def __call__(self, *args, **kwargs):
            raise ValueError('this error cannot be handled')

    obj = Method1(obj=object())
    assert not obj.called

    obj2 = Method1(obj=obj)
    assert not obj.called

    event_source += obj
    assert not obj.called
    event_source += obj2
    event_source.fire()
    assert obj.called
    assert not obj2.called


# Generated at 2022-06-23 13:39:15.996457
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1():
        pass

    def handler2():
        pass

    def handler3():
        pass

    event = _EventSource()

    event += handler1
    event += handler2
    event += handler3

    assert event._handlers == {handler1, handler2, handler3}


# Generated at 2022-06-23 13:39:20.865900
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    assert event._handlers is not None

    event += lambda x: x
    assert len(event._handlers) == 1

    try:
        event += 7
        assert False, 'Expected ValueError'
    except ValueError:
        pass

    try:
        event += 'bad function'
        assert False, 'Expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-23 13:39:24.178750
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    obj = AnsibleCollectionConfig()
    assert obj.default_collection is None
    obj.default_collection = 'test'
    assert obj.default_collection == 'test'

# Generated at 2022-06-23 13:39:33.724831
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """
    API Ref: https://docs.python.org/2/library/unittest.html#basic-example
    """
    import unittest
    class Handler:
        def __init__(self, htype):
            self._htype = htype

        def handle(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs
            if self._htype == 'exception':
                raise Exception('handler exception')
            elif self._htype == 'no_exception':
                pass

        def __repr__(self):
            return '<Handler %s>' % self._htype

    # from unittest import TestCase

# Generated at 2022-06-23 13:39:40.667320
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    testcase = AnsibleCollectionConfig()

    def handler():
        pass

    assert isinstance(testcase.on_collection_load + handler, _EventSource)

    # we only have one handler, so the event source should contain only one element
    assert len(testcase.on_collection_load._handlers) == 1
    # the element should be the handler we added above
    assert next(iter(testcase.on_collection_load._handlers)) is handler


# Generated at 2022-06-23 13:39:43.235676
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:39:48.444542
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c.__class__.__name__ == AnsibleCollectionConfig.__name__
    assert isinstance(c, AnsibleCollectionConfig)
    assert c.on_collection_load
    assert c.collection_finder is None

# Generated at 2022-06-23 13:39:59.741073
# Unit test for constructor of class _EventSource
def test__EventSource():
    evs = _EventSource()

    def _handler(q):
        q.append(1)

    def _handler_args(a, b, *args, **kwargs):
        assert len(args) == 1
        assert args[0] == 3
        assert len(kwargs) == 2
        assert kwargs['c'] == 4
        assert kwargs['d'] == 5

    def _handler_noncallable():
        pass

    def _fail(x):
        raise ValueError('unexpected')

    # value is not callable
    try:
        evs += _handler_noncallable()
        _fail(1)
    except ValueError:
        pass

    # call a handler
    q = []
    evs += _handler
    evs.fire(q)
    assert len(q) == 1

# Generated at 2022-06-23 13:40:01.578590
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:40:13.262388
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # _on_exception always re-raises exceptions
    my_source = _EventSource()
    def good_handler(*args, **kwargs):
        return
    def bad_handler(*args, **kwargs):
        raise RuntimeError("bad handler")
    # without handlers, fire should return without exception
    my_source.fire()
    # with good handler, fire should return without exception
    my_source += good_handler
    my_source.fire()
    # with bad handler, fire should re-raise exception
    my_source += bad_handler
    with pytest.raises(RuntimeError) as ex:
        my_source.fire()
    assert "bad handler" in str(ex.value)
    # with good handler and bad handler, final handler should re-raise exception
    my_source += good_handler

# Generated at 2022-06-23 13:40:17.665929
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MyConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass
    x = MyConfig()
    assert x._collection_finder is None
    assert x._on_collection_load._handlers == set()
    assert x.default_collection is None

# Generated at 2022-06-23 13:40:29.349797
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _EventSourceTest(object):
        def __init__(self):
            self._es = _EventSource()
            self._fired = False
            self._handled = False

        def handler(self, *args, **kwargs):
            self._handled = True

        def fire(self, *args, **kwargs):
            self._fired = True
            self._es.fire(*args, **kwargs)

        def assert_fired(self, raise_exception=None, **kwargs):
            if not self._fired:
                raise AssertionError('expected fire')

            if self._handled:
                raise AssertionError('unexpected handler')

            if raise_exception is not None:
                self._raised = False

# Generated at 2022-06-23 13:40:37.770881
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    # null handler
    handler = lambda: None
    event_source += handler
    assert len(event_source._handlers) == 1

    # duplicate handler
    event_source += handler
    assert len(event_source._handlers) == 1

    # non-callable handler
    try:
        event_source += 'not a callable'
    except ValueError as ex:
        assert 'handler must be callable' in str(ex)

    # callable handler
    handler2 = lambda: None
    event_source += handler2
    assert len(event_source._handlers) == 2


# Generated at 2022-06-23 13:40:44.047727
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    event_source = _EventSource()

    def handler_one(arg):
        event_source.one_handler_arg = arg

    def handler_two(arg):
        event_source.two_handler_arg = arg

    event_source += handler_one
    event_source += handler_two

    event_source.fire('foo')

    assert event_source.one_handler_arg == 'foo'
    assert event_source.two_handler_arg == 'foo'

# Generated at 2022-06-23 13:40:56.269958
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=unused-variable
    assert isinstance(AnsibleCollectionConfig._collection_finder, _AnsibleCollectionConfig.__dict__['collection_finder'].fget)
    assert isinstance(AnsibleCollectionConfig._default_collection, _AnsibleCollectionConfig.__dict__['default_collection'].fget)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _AnsibleCollectionConfig.__dict__['on_collection_load'].fget)
    # pylint: enable=unused-variable

    # a singleton doesn't need to be instantiated
    assert isinstance(AnsibleCollectionConfig.collection_finder, type(None))
    assert isinstance(AnsibleCollectionConfig.default_collection, type(None))

# Generated at 2022-06-23 13:41:00.356773
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()
    assert a._collection_finder is None
    assert a._default_collection is None
    assert a.on_collection_load == a._on_collection_load



# Generated at 2022-06-23 13:41:04.146722
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    evs = _EventSource()
    a = lambda x, y: None
    evs += a

    evs -= a
    evs -= a
    evs -= a
    evs -= 'test'


AC = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:41:07.165083
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def event_handler():
        pass

    event_source += event_handler

    event_source -= event_handler

    assert len(event_source._handlers) == 0


# Generated at 2022-06-23 13:41:12.619969
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler():
        pass

    event_source += handler
    assert handler in event_source._handlers

    event_source -= handler
    assert handler not in event_source._handlers

    event_source -= handler
    assert handler not in event_source._handlers



# Generated at 2022-06-23 13:41:21.298272
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def func1(sender, *args, **kwargs):
        pass

    def func2(sender, *args, **kwargs):
        pass

    event = _EventSource()
    event += func1
    event += func2
    assert len(event._handlers) == 2
    event -= func1
    assert len(event._handlers) == 1
    assert len(event._handlers.difference(set([func1]))) == 1
    assert len(event._handlers.difference(set([func2]))) == 0
    event -= func1
    assert len(event._handlers) == 1
    event -= func2
    assert len(event._handlers) == 0



# Generated at 2022-06-23 13:41:27.562581
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    def foo():
        pass
    def bar():
        pass
    es += foo
    es += bar
    assert len(es._handlers) == 2
    es -= foo
    assert len(es._handlers) == 1
    es -= bar
    assert len(es._handlers) == 0


# Generated at 2022-06-23 13:41:29.327324
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    _EventSource().__isub__('abc')


# Generated at 2022-06-23 13:41:38.433600
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def test_handler1(evt):
        evt.called_handlers.append(1)

    def test_handler2(evt):
        evt.called_handlers.append(2)

    firing_event = _EventSource()
    firing_event.called_handlers = []
    firing_event += test_handler1
    firing_event += test_handler2
    firing_event.fire(firing_event)
    assert firing_event.called_handlers == [1, 2], '_EventSource.fire should call all attached handlers'
    firing_event -= test_handler1
    firing_event.fire(firing_event)
    assert firing_event.called_handlers == [1, 2, 2], '_EventSource.fire should call remaining attached handlers only'



# Generated at 2022-06-23 13:41:44.546708
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler_1():
        pass

    def handler_2():
        pass

    def handler_3():
        pass

    event_source = _EventSource()
    event_source += handler_1
    event_source += handler_2
    event_source += handler_3

    assert event_source._handlers == {handler_1, handler_2, handler_3}, "Unexpected set of handlers"
    event_source -= handler_3
    assert event_source._handlers == {handler_1, handler_2}, "Unexpected set of handlers"
    event_source -= handler_2
    assert event_source._handlers == {handler_1}, "Unexpected set of handlers"
    event_source -= handler_1
    assert event_source._handlers == set(), "Unexpected set of handlers"


# Generated at 2022-06-23 13:41:51.295693
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    class Handler1:
        def __call__(self, *args, **kwargs):
            pass
    class Handler2:
        def __call__(self, *args, **kwargs):
            pass
    event_source += Handler1()
    event_source += Handler2()

    event_source -= Handler2()

    assert len(event_source._handlers) == 1


# Generated at 2022-06-23 13:41:52.366369
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig()


# Generated at 2022-06-23 13:41:56.189272
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()
    assert ansible_collection_config._collection_finder is None
    assert ansible_collection_config._default_collection is None
    assert isinstance(ansible_collection_config._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:42:07.458944
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class EventSourceTester(object):
        def __init__(self):
            self.event_source = _EventSource()
            self.fired = False

        def __call__(self):
            self.event_source.fire(self)

        def handler(self, src):
            self.fired = True

    t1 = EventSourceTester()
    t2 = EventSourceTester()

    t1.event_source += t1.handler
    t1.event_source += t2.handler

    assert t1.fired is False
    assert t2.fired is False

    t1()

    assert t1.fired is True
    assert t2.fired is True

# Generated at 2022-06-23 13:42:11.192564
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.playbook_paths is not None



# Generated at 2022-06-23 13:42:22.768448
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def third_handler(event, arg2, **kwargs):
        raise TestException('test__EventSource_fire handler 3')

    config = AnsibleCollectionConfig()

    def first_handler(event, arg1, **kwargs):
        assert event is config
        assert arg1 == 'handler_arg_1'
        return 1

    def second_handler(event, arg2, **kwargs):
        assert event is config
        assert arg2 == 'handler_arg_2'
        return 2

    config.on_collection_load += first_handler  # add the same handler more than once
    config.on_collection_load += first_handler
    config.on_collection_load += second_handler

    config.on_collection_load += third_handler  # add a handler that raises an exception



# Generated at 2022-06-23 13:42:26.320110
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    t = _AnsibleCollectionConfig(None, 't', None)
    assert t._collection_finder is None
    assert t._default_collection is None
    assert isinstance(t._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:42:29.833661
# Unit test for constructor of class _EventSource
def test__EventSource():
    def test_handler():
        pass
    e = _EventSource()
    assert not e._handlers
    e += test_handler
    assert test_handler in e._handlers
    e -= test_handler
    assert not e._handlers


# Generated at 2022-06-23 13:42:41.733946
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    # property collection_finder is not settable
    try:
        config.collection_finder = 'value'
        assert False
    except ValueError:
        pass

    # property default_collection is not settable
    try:
        config.default_collection = 'value'
        assert False
    except ValueError:
        pass

    # property on_collection_load is not settable
    try:
        config.on_collection_load = 'value'
        assert False
    except ValueError:
        pass

    # property playbook_paths is not readable
    try:
        value = config.playbook_paths
        assert False
    except NotImplementedError:
        pass

    # property playbook_paths is not settable

# Generated at 2022-06-23 13:42:54.574405
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Foo(_EventSource):
        def __init__(self, exc_handler=None):
            self.args = []
            self.kwargs = []
            self.exc_handler = exc_handler
            _EventSource.__init__(self)

        def _on_exception(self, handler, exc, *args, **kwargs):
            if self.exc_handler is not None:
                return self.exc_handler(handler, exc, *args, **kwargs)

        def handler_one(self, *args, **kwargs):
            self.args.append(args)
            self.kwargs.append(kwargs)

        def handler_two(self, *args, **kwargs):
            self.args.append(args)
            self.kwargs.append(kwargs)

# Generated at 2022-06-23 13:42:58.890165
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(a, b='b'):
        print(a, b)

    def handler2(c, d='d'):
        print(c, d)

    event_source += handler1
    event_source += handler2

    event_source.fire('foo', d='bar')

# Generated at 2022-06-23 13:43:09.574106
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    def event_handler(a, b, c, d):
        pass
    event_source += event_handler

    # Test with no arguments
    event_source.fire()

    # Test with 4 arguments
    event_source.fire('a', 'b', 'c', 'd')

    # Test with named arguments
    event_source.fire(a='a', b='b', c='c', d='d')

    # Test with some arguments and some named arguments
    event_source.fire('a', c='c', d='d')

    # Test with invalid number of arguments
    failed = False
    try:
        event_source.fire('a', 'b', 'c')
    except TypeError:
        failed = True
    assert failed

    # Test with invalid number of arguments (named argument)

# Generated at 2022-06-23 13:43:12.768877
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()
    def handler_1(*args, **kwargs):
        pass
    def handler_2(*args, **kwargs):
        pass
    s += handler_1
    s += handler_2
    s.fire()


# Generated at 2022-06-23 13:43:17.894683
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    # pylint: disable=no-member
    assert issubclass(_AnsibleCollectionConfig, type)
    assert isinstance(_AnsibleCollectionConfig(), type)

    assert _AnsibleCollectionConfig._collection_finder is None
    assert _AnsibleCollectionConfig._default_collection is None

    assert isinstance(_AnsibleCollectionConfig._on_collection_load, _EventSource)

