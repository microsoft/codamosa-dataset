

# Generated at 2022-06-23 13:33:13.492591
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert len(es._handlers) == 0
    assert es.fire() is None

# Generated at 2022-06-23 13:33:23.970227
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class Test1(object):
        def __call__(self, *args, **kwargs):
            assert (args == ('test1',))
            assert (kwargs == {'a': 123})
            raise ValueError('ignore me')

    class Test2(object):
        def __call__(self, *args, **kwargs):
            assert (args == ('test2',))
            assert (kwargs == {'b': 234})
            return 'test2'

    test1 = Test1()
    test2 = Test2()

    test = _EventSource()
    test += test1
    test += test2

    result = test.fire('test1', a=123)
    assert (result is None)

    result = test.fire('test2', b=234)
    assert (result is None)

# Generated at 2022-06-23 13:33:26.869444
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    # Validate that an AnsibleCollectionFinder has not already been configured
    try:
        c.collection_finder = None
    except ValueError:
        assert True, 'CollectionFinder already set'


# Generated at 2022-06-23 13:33:39.493641
# Unit test for constructor of class _EventSource
def test__EventSource():

    def test_handler_1():
        pass

    def test_handler_2():
        pass

    def test_handler_3():
        pass

    def test_handler_error():
        raise RuntimeError()

    obj = _EventSource()

    assert obj._handlers == set()

    # Add handlers and check they are in the right order
    obj += test_handler_1
    assert list(obj._handlers) == [test_handler_1]

    obj += test_handler_2
    assert list(obj._handlers) == [test_handler_1, test_handler_2]

    obj += test_handler_3
    assert list(obj._handlers) == [test_handler_1, test_handler_2, test_handler_3]

    # Ensure duplicate handlers are ignored
    obj += test_handler_2
   

# Generated at 2022-06-23 13:33:51.760779
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    aconfig = AnsibleCollectionConfig()
    assert not aconfig.collection_finder
    assert not aconfig._default_collection

    assert len(aconfig._on_collection_load._handlers) == 0
    assert aconfig._on_collection_load.fire() is None

    assert aconfig.collection_paths == []
    assert aconfig.playbook_paths == []

    aconfig.default_collection = 'default_collection'
    assert aconfig.default_collection == 'default_collection'

    with pytest.raises(ValueError):
        aconfig.collection_finder = 'value'
    with pytest.raises(NotImplementedError):
        aconfig.collection_paths

    with pytest.raises(ValueError):
        aconfig.on_collection_load

# Generated at 2022-06-23 13:33:58.916168
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Test:
        def __init__(self, name):
            self._name = name

        def __call__(self, msg):
            self._msg = msg

        def __repr__(self):
            return "'" + self._name + "'"

    es = _EventSource()

    handler = Test('handler')
    es += handler

    es.fire('message')
    assert handler._msg == 'message'

    es -= handler
    es.fire('other message')



# Generated at 2022-06-23 13:34:02.965930
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.collection_paths == []
    assert config.default_collection is None
    assert config.on_collection_load._handlers == set()
    assert config.playbook_paths == []

# Generated at 2022-06-23 13:34:04.999153
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()
    f = lambda: 42
    ev += f

    assert f in ev._handlers



# Generated at 2022-06-23 13:34:06.577786
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import ansible.utils.display as display
    display.Display().warning('Did not test AnsibleCollectionConfig constructor')

# Generated at 2022-06-23 13:34:15.392700
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from unit import ModuleTestCase

    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self.remove_calls = []

        def remove(self, handler):
            self.remove_calls.append(handler)
            super(_TestEventSource, self).__isub__(handler)

    class TestEventSource(ModuleTestCase):
        def test__sub__(self):
            sut = _TestEventSource()
            func1 = lambda *args, **kwargs: None
            func2 = lambda *args, **kwargs: None
            func3 = lambda *args, **kwargs: None
            sut += func1
            sut += func2
            sut += func3

            sut -= func2


# Generated at 2022-06-23 13:34:22.197850
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    """
        ensures that method __isub__ of class _EventSource removes a handler from the handler list
        and does nothing if the handler is not present in the handler list.

        The function is disabled in production so that it does not add a unit test for the production
        version of the Ansible Collection Loader.
    """

    class _EventSourceTest(_EventSource):
        def __init__(self):
            super(_EventSourceTest, self).__init__()
            self._handlers = set()

    event_source = _EventSourceTest()

    def handler1(x):  # pylint: disable=unused-variable
        pass

    def handler2(x):  # pylint: disable=unused-variable
        pass

    event_source += handler1
    event_source -= handler1
    assert handler1 not in event_source

# Generated at 2022-06-23 13:34:25.136455
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # when
    es = _EventSource()
    es += lambda: None

    # then
    assert len(es._handlers) == 1


# Generated at 2022-06-23 13:34:25.575665
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:34:27.891885
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    s = _EventSource()
    f = lambda x, y: x + y
    s += f
    s -= f


# Generated at 2022-06-23 13:34:30.065916
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:34:39.902290
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def callable1():
        pass

    def callable2():
        pass

    event_source = _EventSource()
    event_source += callable1
    event_source += callable2

    events = event_source._handlers
    event_source -= callable1
    event_source -= callable2

    assert len(events) == 2
    assert len(event_source._handlers) == 0

    event_source += callable1
    event_source += callable2

    events = event_source._handlers
    event_source -= callable2
    event_source -= callable1

    assert len(events) == 2
    assert len(event_source._handlers) == 0

# Generated at 2022-06-23 13:34:50.542965
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible_test.utils.target.legacy_collection_loader.finder import AnsibleCollectionFinder

    # We don't want the tests to use the real collection finder
    AnsibleCollectionConfig._collection_finder = None

    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollectionConfig._on_collection_load

    # Test when a collection finder is configured
    collection_finder = AnsibleCollectionFinder(None)
    AnsibleCollectionConfig.collection_finder = collection_finder

    assert AnsibleCollectionConfig.collection_finder == collection_finder
    assert AnsibleCollectionConfig.collection_paths == collection_finder.collection_paths
    assert AnsibleCollectionConfig.playbook_paths == collection_finder.playbook_

# Generated at 2022-06-23 13:34:55.569844
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_event = _EventSource()
    assert test_event._handlers == set()

    test_event += lambda: None
    assert len(test_event._handlers) == 1

    test_event += lambda: None
    assert len(test_event._handlers) == 2



# Generated at 2022-06-23 13:35:01.765068
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import with_metaclass

    class _AnsibleCollectionConfig(type):
        def __init__(cls, meta, name, bases):
            cls._collection_finder = None
            cls._default_collection = None
            cls._on_collection_load = _EventSource()

    class AnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    def handler():
        pass

    ev = AnsibleCollectionConfig.on_collection_load
    ev += handler
    ev -= handler
    ev -= handler  # should not throw an error


# Generated at 2022-06-23 13:35:12.061653
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestEventSource(_EventSource):
        def __init__(self, handler_exception=None):
            super(TestEventSource, self).__init__()
            self._handler_exception = handler_exception

        def _on_exception(self, handler, ex, *args, **kwargs):
            assert ex is self._handler_exception
            # signals to the test that the handler has been called
            self._handler_exception = None
            # swallow the exception
            return False

    s = TestEventSource()
    ex = ValueError('test exception')

    def handler1(**kwargs):
        raise ex

    def handler2(**kwargs):
        raise ex

    def handler3(**kwargs):
        pass

    s += handler1
    s += handler2
    s += handler3


# Generated at 2022-06-23 13:35:15.689904
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def foo():
        pass

    assert len(event._handlers) == 0

    event += foo

    assert len(event._handlers) == 1



# Generated at 2022-06-23 13:35:26.279151
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    emitted = []

    def emit1(arg):
        emitted.append(arg)

    def emit2(arg):
        arg.append(5)

    test_event_source = _EventSource()

    # Argument is emitted to emit1
    test_event_source += emit1
    test_event_source.fire('hello')
    assert 'hello' in emitted

    # Argument is modified by emit2
    test_event_source += emit2
    test_event_source.fire([1, 2, 3, 4])
    assert [1, 2, 3, 4, 5] == emitted[1]

    # emit1 is removed from test_event_source
    # only emit2 is called
    test_event_source -= emit1
    test_event_source.fire('another hello')

# Generated at 2022-06-23 13:35:29.984752
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    collection_config = AnsibleCollectionConfig()
    assert collection_config.collection_finder is None
    assert collection_config.collection_paths == []
    assert collection_config.default_collection is None
    assert collection_config.playbook_paths == []

# Generated at 2022-06-23 13:35:31.863825
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    type.__init__(_AnsibleCollectionConfig, None, 'AnsibleCollectionConfig', obj=None)

# Generated at 2022-06-23 13:35:34.382298
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    event += lambda *args, **kwargs: None


# Generated at 2022-06-23 13:35:45.636079
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    def event1(*args, **kwargs):
        event1.args = args
        event1.kwargs = kwargs

    def event2(*args, **kwargs):
        event2.args = args
        event2.kwargs = kwargs

    def event3(*args, **kwargs):
        raise TestException('test exception')

    es = _EventSource()

    es += event1
    es += event2
    es += event3

    es.fire('arg1', 'arg2', kwarg1='val1', kwarg2='val2')

    assert event1.args == ('arg1', 'arg2')
    assert event1.kwargs == dict(kwarg1='val1', kwarg2='val2')


# Generated at 2022-06-23 13:35:55.882733
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import types
    from ansible_collections.ansible.community.plugins.module_utils.collection_loader import _AnsibleCollectionFinder
    import ansible_collections.ansible.community.plugins.module_utils.facts.system

    # test constructor behavior
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)

# Generated at 2022-06-23 13:36:09.226637
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_finder.fget, property)
    assert isinstance(AnsibleCollectionConfig.collection_finder.fset, property)
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')

    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.default_collection.fget, property)
    assert isinstance(AnsibleCollectionConfig.default_collection.fset, property)
    assert hasattr(AnsibleCollectionConfig, 'default_collection')


# Generated at 2022-06-23 13:36:12.817887
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cc = AnsibleCollectionConfig()
    assert cc._collection_finder is None
    assert cc._default_collection is None
    assert isinstance(cc._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:36:17.000727
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac_config = AnsibleCollectionConfig()
    assert ac_config.collection_finder is None    # pylint: disable=no-member
    assert ac_config.on_collection_load is not None  # pylint: disable=no-member



# Generated at 2022-06-23 13:36:21.383672
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def handler(*args, **kwargs):
        assert args == (1, 2)
        assert kwargs == {'abc': 123}

    event += handler
    event.fire(1, 2, abc=123)

    def raise_exception(exc):
        def handler(*args, **kwargs):
            raise exc

        return handler

    event += raise_exception(RuntimeError())
    event += raise_exception(Exception())



# Generated at 2022-06-23 13:36:27.950739
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    assert len(es._handlers) == 0

    handler = lambda: None
    es -= handler

    assert len(es._handlers) == 0

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    assert len(es._handlers) == 0

    es += handler
    assert len(es._handlers) == 1

    es -= handler
    es -= handler
    es -= handler
    assert len(es._handlers) == 0


# Generated at 2022-06-23 13:36:31.036058
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._on_collection_load
    assert AnsibleCollectionConfig._on_collection_load._handlers is not None

# Generated at 2022-06-23 13:36:38.650607
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    def h1(message):
        pass
    def h2(message):
        pass

    es += h1
    es += h2

    assert(len(es._handlers) == 2)

    es -= h1

    assert(len(es._handlers) == 1)

    es -= h1

    assert(len(es._handlers) == 1)

    es -= h2

    assert(len(es._handlers) == 0)


# Generated at 2022-06-23 13:36:43.963562
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def _event_handler(event_args, event_kwargs):
        pass

    event_source = _EventSource()
    event_source += _event_handler

    event_source -= _event_handler
    assert _event_handler not in event_source._handlers


# Generated at 2022-06-23 13:36:51.905249
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Test removing a handler that was added
    es = _EventSource()
    def handler():
        pass
    es += handler
    es -= handler
    assert handler not in es._handlers

    # Test removing a handler that was not added, which should do nothing
    es = _EventSource()
    es -= handler
    assert handler not in es._handlers

    # Test removing an extra handle
    es = _EventSource()
    es += handler
    es += handler
    es -= handler
    assert handler not in es._handlers



# Generated at 2022-06-23 13:36:56.627322
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(a, b, c):
        global _EventSource___iadd__seen
        _EventSource___iadd__seen = True

    global _EventSource___iadd__seen
    _EventSource___iadd__seen = False

    e = _EventSource()
    assert _EventSource___iadd__seen is False
    e += handler
    assert _EventSource___iadd__seen is False

    e.fire(1, 2, 3)

    assert _EventSource___iadd__seen is True


# Generated at 2022-06-23 13:36:57.172216
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig is not None

# Generated at 2022-06-23 13:36:58.451591
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(data):
        print(data)

    e = _EventSource()
    e += handler
    e -= handler
    e -= handler

# Generated at 2022-06-23 13:37:08.376160
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _TestEventHandler:
        def __init__(self, value):
            self.value = value

        def __call__(self, *args, **kargs):
            self.value['called'] = True

    event_source = _EventSource()

    value = {}
    handler = _TestEventHandler(value)
    event_source += handler

    assert event_source._handlers
    assert handler in event_source._handlers

    event_source -= handler

    assert not event_source._handlers
    assert handler not in event_source._handlers


# Generated at 2022-06-23 13:37:17.588863
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    e.fire()

    handler_calls = []
    e += lambda *args, **kwargs: handler_calls.append(('handler1', args, kwargs))
    e += lambda *args, **kwargs: handler_calls.append(('handler2', args, kwargs))

    e.fire(1, 2, x=3, y=4)
    assert handler_calls == [
        ('handler1', (1, 2), dict(x=3, y=4)),
        ('handler2', (1, 2), dict(x=3, y=4)),
    ]

    handler_calls[:] = []

    def handle_exc(h, ex, *args, **kwargs):
        assert isinstance(ex, ValueError)

# Generated at 2022-06-23 13:37:25.132415
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()

    assert isinstance(es._handlers, set)
    assert len(es._handlers) == 0

    def handler1(arg1, arg2, kwarg1=None, kwarg2=None):
        pass

    def handler2(arg3):
        pass

    es += handler1
    es += handler2

    assert handler1 in es._handlers
    assert handler2 in es._handlers
    assert len(es._handlers) == 2

    es -= handler1

    assert handler1 not in es._handlers
    assert handler2 in es._handlers
    assert len(es._handlers) == 1



# Generated at 2022-06-23 13:37:29.535072
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def handler():
        pass

    es += handler
    assert handler in es._handlers, "Failed to add handler to _EventSource._handlers"



# Generated at 2022-06-23 13:37:33.206058
# Unit test for constructor of class _EventSource
def test__EventSource():
    def foo(arg1, arg2, kwarg1=None):
        pass

    def bar(arg1, arg2, kwarg1=None):
        pass

    s = _EventSource()
    s += foo
    s += bar

    s.fire('a', 'b', kwarg1='c')


# Generated at 2022-06-23 13:37:34.081234
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # test no error raised
    _AnsibleCollectionConfig(None, 'name', None)



# Generated at 2022-06-23 13:37:36.841697
# Unit test for constructor of class _EventSource
def test__EventSource():
    from ansible_test._loader.event_source_test import test__EventSource_constructor

    test__EventSource_constructor(
        _EventSource,
    )

# Generated at 2022-06-23 13:37:37.458340
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    pass

# Generated at 2022-06-23 13:37:45.440850
# Unit test for constructor of class _EventSource

# Generated at 2022-06-23 13:37:49.986753
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    f1 = lambda x: x
    es += f1
    assert f1 in es._handlers
    es -= f1
    assert f1 not in es._handlers


# Generated at 2022-06-23 13:37:58.859937
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Instantiate class _EventSource
    es = _EventSource()

    # Instantiate class _EventHandler
    class _EventHandler(object):
        def __init__(self, test_case, messages):
            self._test_case = test_case
            self._messages = messages

        def __call__(self, *args, **kwargs):
            self._messages.append(args[0])

    # Create list of messages
    messages = []

    # Add two handlers to instance es
    es += _EventHandler(None, messages)
    es += _EventHandler(None, messages)

    # Fire event on instance es
    es.fire('a message')

    # Verify that es contained two handlers of class _EventHandler
    assert len(es._handlers) == 2

    # Verify that both event handlers added the message to the list

# Generated at 2022-06-23 13:37:59.573665
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:38:04.194109
# Unit test for constructor of class _EventSource
def test__EventSource():
    def a(x, y):
        pass

    s = _EventSource()

    s.fire()
    s += a
    s.fire(1, 2)
    s.fire(1, 2)

    s -= a
    s.fire(1, 2)



# Generated at 2022-06-23 13:38:08.731552
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    assert not event._handlers

    def test_func():
        pass

    event += test_func
    assert event._handlers == set([test_func])



# Generated at 2022-06-23 13:38:13.647997
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def func1(arg):
        pass

    def func2(arg):
        pass

    es += func1
    es += func2

    es -= func1

    assert len(es._handlers) == 1
    assert func2 in es._handlers

# Generated at 2022-06-23 13:38:17.081750
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not AnsibleCollectionConfig._collection_finder
    assert not AnsibleCollectionConfig._default_collection
    assert not AnsibleCollectionConfig._on_collection_load._handlers



# Generated at 2022-06-23 13:38:22.557582
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')

# Generated at 2022-06-23 13:38:32.168913
# Unit test for constructor of class _EventSource
def test__EventSource():
    def foo(a, b):
        print('foo(' + str(a) + ', ' + str(b) + ')')

    es = _EventSource()
    es += foo
    assert foo in es._handlers

    es -= foo
    assert foo not in es._handlers

    es += foo
    assert foo in es._handlers

    def bar(a, b):
        print('bar(' + str(a) + ', ' + str(b) + ')')
    es += bar
    assert bar in es._handlers

    es.fire(1, 2)  # check that functions added to set are called

# Generated at 2022-06-23 13:38:35.759630
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    def foo():
        return 1

    source += foo

    for handler in source._handlers:
        assert handler is foo

    source -= foo

    for handler in source._handlers:
        assert False

# Generated at 2022-06-23 13:38:36.503633
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:38:43.080488
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)



# Generated at 2022-06-23 13:38:52.244008
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # This code must be kept functionally identical to code of the same name in test/lib/ansible_test/_util/target/legacy_collection_loader/_event_source.py
    class MyEventSourceImpl(object):
        def __init__(self):
            self.count = 0

        def __call__(self):
            self.count += 1

    # sanity check
    es = _EventSource()
    assert not es._handlers

    # make sure this bails when we call it with a non-callable
    try:
        es += 1
        assert False
    except ValueError:
        assert True

    # add a callable, then verify it worked
    es += MyEventSourceImpl()
    assert len(es._handlers) == 1

    # now test firing the event
    es.fire()

# Generated at 2022-06-23 13:38:54.632787
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestMeta(_AnsibleCollectionConfig):
        pass
    class TestClass(with_metaclass(TestMeta)):
        pass
    t = TestClass()
    assert t._on_collection_load
    assert t._on_collection_load._handlers == set()

# Generated at 2022-06-23 13:38:57.452331
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    ev = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    ev += handler1
    ev += handler2
    ev -= handler2


# Unit tests for class AnsibleCollectionConfig

# Generated at 2022-06-23 13:39:05.158427
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # an empty class
    class TestClass:
        pass

    # the constructor of our metaclass should be executed
    assert TestClass.__mro__[0] == _AnsibleCollectionConfig

    # the three properties which are declared as class modifiers should be defined
    assert TestClass._collection_finder is None
    assert TestClass._default_collection is None
    assert TestClass._on_collection_load is not None


# Generated at 2022-06-23 13:39:13.427385
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest:
        def __init__(self):
            self.prop1 = None

    _es_test = _EventSourceTest()

    def handler1(self):
        self.prop1 = 1

    def handler2(self):
        self.prop1 = 2

    es = _EventSource()
    es += handler1
    es += handler2

    es.fire(_es_test)

    assert _es_test.prop1 == 2

# Generated at 2022-06-23 13:39:19.469951
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler1():
        return 1

    def handler2():
        return 2

    def handler3():
        return 3

    test = _EventSource()

    test += handler1

    assert handler1 in test._handlers

    test -= handler1

    assert handler1 not in test._handlers

    # Ensure that removing a non-existent handler does not cause an exception
    test -= handler2
    test -= handler3


# Generated at 2022-06-23 13:39:21.468403
# Unit test for constructor of class _EventSource
def test__EventSource():
    # call without exception
    _EventSource()


# Generated at 2022-06-23 13:39:24.941628
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # try to create a new instance
    instance = AnsibleCollectionConfig()

    # now, test the initial values
    assert instance._collection_finder is None
    assert instance._default_collection is None
    assert isinstance(instance._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:39:34.792848
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockHandler():
        def __init__(self, throw):
            self.called = False
            self.throw = throw

        def __call__(self, *args, **kwargs):
            self.called = True
            if self.throw:
                raise RuntimeError('test_exception')

    # Create a handler that does not throw an exception
    handler_ok = MockHandler(throw=False)
    # Create a handler that throws an exception
    handler_error = MockHandler(throw=True)

    # Fire a handler. Make sure that handler_ok.called is True.
    event = _EventSource()
    event += handler_ok
    event.fire()
    assert handler_ok.called

    # Fire two handlers. Make sure that both handler_ok.called and handler_error.called is True.
    event = _EventSource()

# Generated at 2022-06-23 13:39:40.716940
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class Test:
        def test_handler(arg):
            pass

    test_event_source = _EventSource()

    test_event_source += Test.test_handler

    assert Test.test_handler in test_event_source._handlers

    test_event_source -= Test.test_handler

    assert Test.test_handler not in test_event_source._handlers

# Unit tests for class AnsibleCollectionConfig

# Generated at 2022-06-23 13:39:48.175836
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handleThrowException(arg, **kwargs):
        raise Exception('This is an exception')

    def handleReThrowException(arg, **kwargs):
        raise Exception('This is an exception to reraise')

    def handleValueError(arg, **kwargs):
        raise ValueError('This is a ValueError that should not be reraised')

    def handle_exception(handler, exc, *args, **kwargs):
        if isinstance(exc, ValueError):
            return False
        else:
            return True

    def handle_excepion_override(handler, exc, *args, **kwargs):
        return True

    source = _EventSource()
    source += handleThrowException
    source += handleValueError
    source += handleReThrowException

    # Test for the default handler

# Generated at 2022-06-23 13:39:51.660418
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac.collection_finder is None
    assert ac.default_collection is None
    assert ac.on_collection_load is not None

# Generated at 2022-06-23 13:39:57.170684
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    expected_collection_finder = object()
    expected_default_collection = object()
    expected_on_collection_load = object()

    class AnsibleCollectionConfigImpl(AnsibleCollectionConfig):
        pass

    AnsibleCollectionConfigImpl.collection_finder = expected_collection_finder
    AnsibleCollectionConfigImpl.default_collection = expected_default_collection
    AnsibleCollectionConfigImpl._on_collection_load = expected_on_collection_load

    assert AnsibleCollectionConfigImpl.collection_finder is expected_collection_finder
    assert AnsibleCollectionConfigImpl.default_collection is expected_default_collection
    assert AnsibleCollectionConfigImpl.on_collection_load is expected_on_collection_load


# Generated at 2022-06-23 13:39:59.456872
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()

    assert not es._handlers



# Generated at 2022-06-23 13:40:11.338077
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    handler = 'fakehandler'

    def on_foobar():
        pass

    # check handler is in the list after iadd
    event += on_foobar
    assert on_foobar in event._handlers
    assert 'fakehandler' not in event._handlers

    # check handler is not in the list after isub
    event -= on_foobar
    assert on_foobar not in event._handlers
    assert 'fakehandler' not in event._handlers

    # check ValueError is raised when handler is not callable
    try:
        event += handler
    except ValueError as e:
        assert str(e) == 'handler must be callable'
    else:
        assert False, 'An exception should have been raised'

# Generated at 2022-06-23 13:40:16.268172
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cls = AnsibleCollectionConfig()
    assert not cls.collection_finder
    assert not cls.default_collection
    assert not cls.collection_paths
    assert not cls.playbook_paths



# Generated at 2022-06-23 13:40:23.151982
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert isinstance(config, AnsibleCollectionConfig)
    assert isinstance(config.collection_finder, _AnsibleCollectionConfig)
    assert isinstance(config.default_collection, _AnsibleCollectionConfig)
    assert isinstance(config.on_collection_load, _AnsibleCollectionConfig)
    assert isinstance(config.playbook_paths, _AnsibleCollectionConfig)



# Generated at 2022-06-23 13:40:34.087287
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # 1 event handler
    evt = _EventSource()
    result = []
    evt += lambda *args, **kwargs: result.append(('a', args, kwargs))
    evt.fire(1, keyword='value')
    assert result == [('a', (1,), {'keyword': 'value'})]

    # 2 event handlers, 1 exception
    evt = _EventSource()
    result = []
    evt += lambda *args, **kwargs: result.append(('a', args, kwargs))

# Generated at 2022-06-23 13:40:39.984261
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    class MyClass(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert isinstance(MyClass._collection_finder, type(None))
    assert isinstance(MyClass._default_collection, type(None))
    assert isinstance(MyClass._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:40:45.448952
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig._default_collection, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)

# Only load the configuration once at import time in the ansible_collections package
_config = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:40:46.171390
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:40:55.231948
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    try:
        class Foo(with_metaclass(_AnsibleCollectionConfig)):
            pass
    except Exception as ex:
        assert False, to_text('Unexpected exception: {}'.format(ex))

    assert isinstance(Foo.collection_finder, property)
    assert isinstance(Foo.collection_paths, property)
    assert isinstance(Foo.default_collection, property)
    assert isinstance(Foo.on_collection_load, property)
    assert isinstance(Foo.playbook_paths, property)


# Generated at 2022-06-23 13:41:05.281673
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None
    assert AnsibleCollectionConfig._on_collection_load.fire is not None

    # test class property setters
    AnsibleCollectionConfig.default_collection = 'foo'
    assert AnsibleCollectionConfig.default_collection == 'foo'
    try:
        AnsibleCollectionConfig.collection_finder = 'foo'
    except ValueError:
        pass
    except Exception as ex:
        assert False, 'expected ValueError but got %s' % ex

# Generated at 2022-06-23 13:41:08.357462
# Unit test for constructor of class _EventSource
def test__EventSource():
    class _EventSourceTestClass:
        _event = _EventSource()

        def test_event_variable_should_be_of_event_source_type(self):
            assert isinstance(self._event, _EventSource)
    _EventSourceTestClass()



# Generated at 2022-06-23 13:41:14.690506
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_event = _EventSource()
    test_args = (1, 2, 3)
    test_kwargs = {
        'foo': 'bar',
    }

    def handler(*args, **kwargs):
        assert args == test_args
        assert kwargs == test_kwargs

    test_event += handler
    test_event.fire(*test_args, **test_kwargs)


# Generated at 2022-06-23 13:41:24.057038
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    collection_config = AnsibleCollectionConfig()

    # the property 'on_collection_load' returns an instance of the _EventSource class
    # assert the type
    assert(isinstance(collection_config.on_collection_load, _EventSource))

    # add a handler
    def handler(value):
        collection_config.collection_paths.append(value)

    collection_config.on_collection_load += handler

    # assert we are able to assign the collection paths property
    def handler(value):
        collection_config.collection_paths = value

    collection_config.on_collection_load += handler

    # add the same handler again and assert that the handler is only added once
    collection_config.on_collection_load += handler
    assert(len(collection_config.on_collection_load._handlers) == 2)

    #

# Generated at 2022-06-23 13:41:27.846691
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()

    source += 1  # must raise ValueError

    try:
        source += 1
    except ValueError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-23 13:41:31.389205
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, type)
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)
    assert isinstance(AnsibleCollectionConfig(), AnsibleCollectionConfig)

# Generated at 2022-06-23 13:41:42.187045
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler1(*args, **kwargs):
        nonlocal handler1_args
        nonlocal handler1_kwargs
        handler1_args = args
        handler1_kwargs = kwargs

    def handler2(*args, **kwargs):
        nonlocal handler2_args
        nonlocal handler2_kwargs
        handler2_args = args
        handler2_kwargs = kwargs

    es = _EventSource()

    handler1_args = None
    handler1_kwargs = None
    handler2_args = None
    handler2_kwargs = None

    es += handler1
    es += handler2

    es.fire('a', 'b', k1='1', k2='2')

    assert handler1_args == ('a', 'b')

# Generated at 2022-06-23 13:41:51.250354
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def x():
        pass

    es += x
    assert len(es._handlers) == 1

    es += x
    assert len(es._handlers) == 1

    def y():
        pass

    es += y
    assert len(es._handlers) == 2
    assert x in es._handlers
    assert y in es._handlers

    with pytest.raises(ValueError, match='handler must be callable'):
        es += 'abc'


# Generated at 2022-06-23 13:41:54.683275
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load
    assert AnsibleCollectionConfig.playbook_paths is None


# Generated at 2022-06-23 13:42:00.795175
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _MyConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert issubclass(_MyConfig, AnsibleCollectionConfig)
    assert not hasattr(_MyConfig, '_on_collection_load')
    assert not hasattr(_MyConfig, '_collection_finder')


# Generated at 2022-06-23 13:42:08.110248
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert event_source._handlers == set()

    def handler():
        pass

    # Define an attribute, handler, in event_source that we can use to determine
    # that method handler was added as an event handler.
    event_source += handler
    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers
    assert not hasattr(event_source, handler)



# Generated at 2022-06-23 13:42:12.520037
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(value):
        if value == 'bar':
            raise ValueError('bar')

    es = _EventSource()
    es += handler
    es.fire('foo')

    try:
        es.fire('bar')
        assert False
    except Exception as ex:
        assert to_text(ex) == 'bar'

# Generated at 2022-06-23 13:42:23.907720
# Unit test for constructor of class _EventSource
def test__EventSource():
    def _fake_handler():
        pass

    event_source = _EventSource()
    assert event_source
    assert event_source._handlers == set()

    event_source += _fake_handler
    assert _fake_handler in event_source._handlers
    assert len(event_source._handlers) == 1

    event_source -= _fake_handler
    assert _fake_handler not in event_source._handlers
    assert len(event_source._handlers) == 0

    try:
        event_source += 1
        assert False, 'expected ValueError'
    except ValueError as ex:
        assert 'handler must be callable' in str(ex)


# Generated at 2022-06-23 13:42:27.652219
# Unit test for constructor of class _EventSource
def test__EventSource():
    EventSource = _EventSource

    def _handler(obj):
        assert obj

    handler = _handler
    obj = object()

    source = EventSource()
    source += handler
    source += handler
    source += handler
    source -= handler
    source -= handler
    source -= handler
    source += handler
    source += handler
    source -= handler
    source -= handler

    with pytest.raises(TypeError):
        source += obj

    with pytest.raises(TypeError):
        source -= obj

    source += handler
    source -= handler
    pytest.raises(KeyError, source.remove, handler)

    source += handler
    source -= handler
    source.fire(obj)



# Generated at 2022-06-23 13:42:28.646169
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()


# Generated at 2022-06-23 13:42:32.134754
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda _: None
    assert len(e._handlers) == 1



# Generated at 2022-06-23 13:42:33.394727
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    _EventSource.__isub__()

# Generated at 2022-06-23 13:42:35.761365
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, _AnsibleCollectionConfig)


# Generated at 2022-06-23 13:42:42.397401
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_test._internal.events import event_data

    # create a callback function
    def on_load_callback(collection):
        event_data.append(collection)

    # create an event source with no callbacks
    source = _EventSource()

    # add a callback to the event source
    source += on_load_callback

    # clear the event data
    event_data.clear()

    # fire the event
    source.fire(collection=1)

    assert event_data == [1]



# Generated at 2022-06-23 13:42:50.330075
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    callbacks_called = []
    def callback(*args, **kwargs):
        callbacks_called.append((args, kwargs))

    s = _EventSource()
    s += callback
    s += callback

    s.fire('foo')

    assert len(callbacks_called) == 2
    assert callbacks_called[0][0] == ('foo',)
    assert callbacks_called[1][0] == ('foo',)



# Generated at 2022-06-23 13:42:50.913687
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()


# Generated at 2022-06-23 13:42:56.024039
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def test_handler():
        pass

    es += test_handler
    es += test_handler

    assert len(es._handlers) == 1

    es += test_handler

    assert len(es._handlers) == 1



# Generated at 2022-06-23 13:42:59.815587
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()

    def f():
        pass

    def g():
        pass

    def h():
        pass

    e += f
    e += g
    e += h

    e -= g

    assert f in e._handlers
    assert g not in e._handlers
    assert h in e._handlers

# Generated at 2022-06-23 13:43:02.099603
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # constructor test
    a = AnsibleCollectionConfig()
    assert a is not None

# Generated at 2022-06-23 13:43:11.903049
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert isinstance(es, _EventSource)
    # Check that an exception is raised if the new handler is not callable
    try:
        es += 'not a callable'
        assert False
    except ValueError:
        pass
    # Check that the value of the set is correct with one handler
    es += lambda x: x*2
    assert len(es._handlers) == 1
    assert es._handlers.pop()(2) == 4
    # Check that the value of the set is correct with two handlers
    es += lambda x: x*4
    es += lambda x: x*8
    assert len(es._handlers) == 2
    assert es._handlers.pop()(2) == 16
    assert es._handlers.pop()(2) == 8
    # Check that the value