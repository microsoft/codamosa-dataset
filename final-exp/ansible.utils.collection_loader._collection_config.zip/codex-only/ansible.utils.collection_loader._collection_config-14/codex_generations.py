

# Generated at 2022-06-23 13:33:13.913673
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    pass

# Generated at 2022-06-23 13:33:17.870688
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig._on_collection_load is not None
    assert AnsibleCollectionConfig._on_collection_load is AnsibleCollectionConfig.on_collection_load
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:33:26.141924
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollectionConfig._on_collection_load
    try:
        AnsibleCollectionConfig.on_collection_load = None
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-23 13:33:29.459945
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = AnsibleCollectionConfig.on_collection_load
    event_source.__isub__(None)



# Generated at 2022-06-23 13:33:33.480589
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler():
        pass

    event_source = _EventSource()
    event_source += handler

    assert len(event_source._handlers) == 1
    assert handler in event_source._handlers

# Generated at 2022-06-23 13:33:37.740223
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler_1():
        pass

    def handler_2():
        pass

    event = _EventSource()

    event -= handler_1
    event += handler_1
    event += handler_2

    event -= handler_1

    assert list(event._handlers) == [handler_2]


# Generated at 2022-06-23 13:33:45.447371
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def assert_calls_are(expected_calls, actual_calls):
        assert len(expected_calls) == len(actual_calls), "expected %s, but got %s" % (expected_calls, actual_calls)
        for i in range(0, len(expected_calls)):
            e = expected_calls[i]
            a = actual_calls[i]
            assert len(e) == len(a), "expected %s, but got %s" % (e, a)
            for j in range(0, len(e)):
                ee = e[j]
                aa = a[j]
                assert ee == aa, "expected %s, but got %s" % (e, a)

    calls = []

# Generated at 2022-06-23 13:33:46.896731
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    obj = AnsibleCollectionConfig()


# Generated at 2022-06-23 13:33:56.603976
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # set up the event source
    handler1 = lambda *a, **kw: None
    handler2 = lambda *a, **kw: None
    handler3 = lambda *a, **kw: None

    es = _EventSource()
    es += handler1
    es += handler2
    es += handler3

    # ensure the handlers can be removed
    es -= handler1
    assert handler1 not in es._handlers

    es -= handler2
    assert handler2 not in es._handlers

    es -= handler3
    assert handler3 not in es._handlers

    # ensure the handlers can be removed more than once
    es -= handler1
    es -= handler2
    es -= handler3

    # ensure that we can remove non-existent handlers
    es -= handler1
    es -= handler2
    es -= handler3



# Generated at 2022-06-23 13:33:58.741294
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():  # pylint: disable=missing-function-docstring
    AnsibleCollectionConfig()  # pylint: disable=unused-variable

# Generated at 2022-06-23 13:34:03.625238
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    errors = []

    def listener(item):
        if item != 'expected':
            errors.append(ValueError('Wrong item: ' + item))

    e = _EventSource()
    e += listener
    e.fire('expected')

    if errors:
        raise ValueError('test__EventSource_fire failed')



# Generated at 2022-06-23 13:34:11.704199
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def handler_a():
        pass

    def handler_b():
        pass

    def handler_c():
        pass

    es += handler_a
    es += handler_b
    es += handler_c

    assert handler_a in es._handlers
    assert handler_b in es._handlers
    assert handler_c in es._handlers

    es -= handler_a

    assert handler_a not in es._handlers
    assert handler_b in es._handlers
    assert handler_c in es._handlers

    es -= handler_b

    assert handler_a not in es._handlers
    assert handler_b not in es._handlers
    assert handler_c in es._handlers

    es -= handler_c

    assert handler_a not in es._handlers
    assert handler_b

# Generated at 2022-06-23 13:34:20.515806
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert es.fire() is None

    def handler():
        print('handler1')

    es += handler
    assert es.fire() is None

    def handler():
        print('handler2')

    es += handler
    assert es.fire() is None

    es -= handler
    assert es.fire() is None

    def handler():
        print('handler3')

    es += handler
    assert es.fire() is None

    es += handler
    assert es.fire() is None

    es -= handler
    assert es.fire() is None



# Generated at 2022-06-23 13:34:23.757027
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    e += lambda x: True
    assert len(e._handlers) == 1
    e -= lambda x: True
    assert len(e._handlers) == 0


# Generated at 2022-06-23 13:34:27.044798
# Unit test for constructor of class _EventSource
def test__EventSource():
    def ok1(a, b):
        raise RuntimeError()

    def ok2(a, b):
        print('OK2')

    def ok3(a, b):
        raise NotImplementedError()

    def on_exception(handler, exc, *args, **kwargs):
        print('EXC')
        return False

    m = _EventSource()
    m += ok1
    m += ok2
    m += ok3
    m._on_exception = on_exception

    m.fire(1, 2)


# Generated at 2022-06-23 13:34:39.024622
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Simple test that verifies that the handler is invoked with the specified arguments
    handler = mock = Mock()
    event = _EventSource()
    event += handler

    args = tuple(('a', 'r', 'g', 'u', 'm', 'e', 'n', 't'))
    kwargs = {'this': 'is', 'a': 'test'}
    event.fire(*args, **kwargs)
    mock.assert_called_once_with(*args, **kwargs)

    # Resets the mock, return value and side_effect
    mock.reset_mock()

    # Fires the event with different arguments
    args = tuple(('a' for _ in range(10)))
    kwargs = {'this': 'is', 'a': 'test'}
    event.fire(*args, **kwargs)


# Generated at 2022-06-23 13:34:40.743147
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    assert True

# Generated at 2022-06-23 13:34:44.528177
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert config._on_collection_load._handlers == set()


# Generated at 2022-06-23 13:34:48.727960
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    mock_handler_data = []
    mock_handler = lambda *args, **kwargs: mock_handler_data.append((args, kwargs))

    event_source = _EventSource()
    event_source += mock_handler
    event_source.fire(1, 2, b=3)

    assert len(mock_handler_data) == 1
    assert mock_handler_data[0] == ((1, 2), {'b': 3})


# Generated at 2022-06-23 13:34:59.221543
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def raise_exc(exc):
        raise exc

    def return_true(exc):
        return True

    def return_false(exc):
        return False

    def return_none(exc):
        return None

    # handler doesn't raise exception, should be fine
    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    event_source.fire()

    # handler raises exception, handler should catch it and return True
    event_source = _EventSource()
    handler = raise_exc
    event_source += handler
    event_source._on_exception = return_true
    ret_val = event_source.fire(ValueError())
    assert ret_val is None

    # handler raises exception, handler should catch it and return False
    event_source = _EventSource()

# Generated at 2022-06-23 13:35:10.870831
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible_collections.notstdlib.moveitallout.tests._util.target.legacy_collection_loader.collection_finder_mock import AnsibleCollectionFinder, CollectionImportMock

    AnsibleCollectionConfig.collection_finder = AnsibleCollectionFinder()

    config = AnsibleCollectionConfig()

    assert config.__class__ == AnsibleCollectionConfig
    assert config.default_collection == None
    assert config.collection_finder

    # set default collection
    config.default_collection = 'geerlingguy.testcollection1'
    assert config.default_collection == 'geerlingguy.testcollection1'

    # set collection_paths
    config.collection_paths = ['/var/lib/ansible/collections/test']

# Generated at 2022-06-23 13:35:16.465930
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Metaclass(_AnsibleCollectionConfig):
        pass

    class AnsibleCollectionConfig(with_metaclass(Metaclass)):
        pass

    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load



# Generated at 2022-06-23 13:35:21.922303
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Verify that __iadd__ raises when the handler is not callable
    source = _EventSource()

    try:
        source += None
    except ValueError as ex:
        assert 'must be callable' in str(ex)

    # Verify that __iadd__ accepts a callable handler
    def handler():
        pass

    source += handler
    assert handler in source._handlers


# Generated at 2022-06-23 13:35:23.835168
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Arrange
    event_source = _EventSource()

    # Act
    event_source -= event_source.fire

    # Assert
    assert len(event_source._handlers) == 0


# Generated at 2022-06-23 13:35:33.911328
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Test case - handler must be callable
    es = _EventSource()
    try:
        es.__iadd__(13)
    except ValueError:
        pass
    else:
        assert False, "__iadd__ must fail when handler is not callable"

    # Test case - handler can be added
    def handler():
        pass
    es.__iadd__(handler)
    assert handler in es._handlers

    # Test case - handler can be removed
    es.__iadd__(handler)
    assert handler in es._handlers
    es.__isub__(handler)
    assert len(es._handlers) == 1

    # Test case - removing a handler that is not present must not raise exception
    es.__isub__(handler)
    assert len(es._handlers) == 1

    #

# Generated at 2022-06-23 13:35:35.932124
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es is not None


# Generated at 2022-06-23 13:35:36.919621
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()


# Generated at 2022-06-23 13:35:37.799224
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:35:42.163226
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert not AnsibleCollectionConfig.collection_paths
    assert not AnsibleCollectionConfig.playbook_paths

    AnsibleCollectionConfig.collection_finder = object()
    AnsibleCollectionConfig.default_collection = 'my_collection'

    try:
        AnsibleCollectionConfig.collection_finder = object()
        assert False, 'second assign of collection_finder did not raise exception'
    except ValueError:
        pass

    try:
        AnsibleCollectionConfig.on_collection_load = None
        assert False, 'direct assign of on_collection_load did not raise exception'
    except ValueError:
        pass

# Generated at 2022-06-23 13:35:50.407410
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    handler = lambda: None
    h2 = lambda: None

    assert handler not in es._handlers
    assert h2 not in es._handlers

    es -= handler
    es -= h2

    assert handler not in es._handlers
    assert h2 not in es._handlers

    es += handler
    es += h2

    assert handler in es._handlers
    assert h2 in es._handlers

    es -= handler
    es -= h2

    assert handler not in es._handlers
    assert h2 not in es._handlers

# Generated at 2022-06-23 13:35:52.752977
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def test_handler(msg):
        print(msg)

    es = _EventSource()
    es += test_handler


# Generated at 2022-06-23 13:35:55.881932
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def handler():
        pass

    assert len(es._handlers) == 0

    es += handler

    assert len(es._handlers) == 1
    assert handler in es._handlers


# Generated at 2022-06-23 13:36:00.368589
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig.default_collection is None

# Generated at 2022-06-23 13:36:08.664363
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler_1(event):
        pass

    def handler_2(event):
        pass

    event_source += handler_1
    event_source += handler_2

    assert (handler_1 in event_source._handlers)
    assert (handler_2 in event_source._handlers)

    event_source -= handler_2

    assert (handler_1 in event_source._handlers)
    assert (handler_2 not in event_source._handlers)


# Generated at 2022-06-23 13:36:12.015325
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    assert event_source._handlers == set()
    event_source += lambda: None
    assert event_source._handlers == {lambda: None}
    event_source -= lambda: None
    assert event_source._handlers == set()



# Generated at 2022-06-23 13:36:18.302388
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    assert not s._handlers

    def handler_1(a, b):
        pass

    def handler_2(a, b):
        pass

    s += handler_1
    s += handler_2

    assert len(s._handlers) == 2
    assert handler_1 in s._handlers
    assert handler_2 in s._handlers



# Generated at 2022-06-23 13:36:20.061771
# Unit test for constructor of class _EventSource
def test__EventSource():
    x = _EventSource()
    assert isinstance(x, _EventSource)


# Generated at 2022-06-23 13:36:27.122441
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert "undefined_variable" not in globals()

    class Event1(object):
        def __init__(self):
            self.fired = False

        def __call__(self):
            self.fired = True
    e1 = Event1()

    class Event2(object):
        def __init__(self):
            self.fired = False

        def __call__(self):
            self.fired = True
    e2 = Event2()

    class Event3(object):
        def __init__(self):
            self.fired = False

        def __call__(self):
            self.fired = True
    e3 = Event3()

    event_source = _EventSource()
    event_source += e1
    event_source += e2
    event_source += e3

    event_source.fire()

# Generated at 2022-06-23 13:36:29.897363
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)


# Generated at 2022-06-23 13:36:36.897505
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class Test:
        def __init__(self):
            self.value = 0

        def f(self, a, b, c=None):
            self.value = a + b + c

    x = _EventSource()
    t = Test()

    x += t.f

    assert len(x._handlers) == 1

    x.fire(1, 2, 3)
    assert t.value == 6

    x.fire(10, 20, c=30)
    assert t.value == 60

    try:
        x += t
        assert False
    except ValueError:
        pass

    try:
        x.fire(1, 2, 3, 4)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-23 13:36:39.206620
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    def test_handler():
        pass
    event += test_handler
    assert test_handler.__self__ is None
    assert test_handler in event._handlers


# Generated at 2022-06-23 13:36:46.651883
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    test_eventsource = _EventSource()

    def f1(*args, **kwargs):
        pass

    def f2(*args, **kwargs):
        pass

    test_eventsource += f1
    test_eventsource += f2

    assert(len(test_eventsource._handlers) == 2)
    test_eventsource -= f1
    assert(len(test_eventsource._handlers) == 1)
    test_eventsource -= f2
    assert(len(test_eventsource._handlers) == 0)



# Generated at 2022-06-23 13:36:51.751896
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    handler = lambda x: x
    assert handler not in event._handlers
    event.__iadd__(handler)
    assert handler in event._handlers
    event.__isub__(handler)
    assert handler not in event._handlers
    return


# Generated at 2022-06-23 13:36:57.431269
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import unittest
    import unittest.mock as mock

    # test: remove handler, call fire
    handler = mock.Mock()
    e = _EventSource()
    e += handler
    assert len(e._handlers) == 1
    e -= handler
    assert len(e._handlers) == 0
    assert handler.call_count == 0

    # test: remove handler, don't call fire
    e = _EventSource()
    assert len(e._handlers) == 0
    e -= handler
    assert len(e._handlers) == 0
    assert handler.call_count == 0



# Generated at 2022-06-23 13:36:58.116377
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:37:00.050321
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.__init__ is _AnsibleCollectionConfig.__init__

# Generated at 2022-06-23 13:37:03.607371
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class C(object):
        pass

    the_type = _AnsibleCollectionConfig(C, 'C', (object,))

# Generated at 2022-06-23 13:37:06.672660
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestClass(AnsibleCollectionConfig):
        pass
    obj = TestClass()
    assert hasattr(obj, "_AnsibleCollectionConfig__init__")


# Generated at 2022-06-23 13:37:14.168464
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler_a = object()

    event_source.__iadd__(handler_a)
    assert len(event_source._handlers) == 1
    assert handler_a in event_source._handlers

    event_source.__isub__(handler_a)
    assert len(event_source._handlers) == 0
    assert handler_a not in event_source._handlers

    event_source.__isub__(handler_a)
    assert len(event_source._handlers) == 0
    assert handler_a not in event_source._handlers



# Generated at 2022-06-23 13:37:18.819107
# Unit test for constructor of class _EventSource
def test__EventSource():
    s = _EventSource()
    assert isinstance(s, _EventSource)
    with pytest.raises(ValueError):
        s += 'not callable'
    def foo():
        pass
    s += foo
    with pytest.raises(ValueError):
        s -= 'not callable'
    assert not s._on_exception(None, Exception())

# Generated at 2022-06-23 13:37:20.082701
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert es == es + 0



# Generated at 2022-06-23 13:37:24.745661
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig()
    except NotImplementedError as e:
        assert 'an AnsibleCollectionFinder has not been installed in this process' in to_text(e)
    except BaseException as e:
        assert False, 'Unexpected exception: %s' % to_text(e)
    else:
        assert False, 'Expected NotImplementedError'

# Generated at 2022-06-23 13:37:31.442202
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    result = {'value': 0}

# Generated at 2022-06-23 13:37:33.409063
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    instance = _EventSource()
    assert instance._handlers == set()

    def test_method():
        pass

    instance += test_method
    assert instance._handlers == set([test_method])

    instance -= test_method
    assert instance._handlers == set()

    instance -= test_method
    assert instance._handlers == set()

# Generated at 2022-06-23 13:37:43.714877
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Parent:
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    class Child1(Parent):
        def __init__(self):
            self._h1_called = False
            self._h2_called = False
            self._h3_called = False
            self.exception = None

        def _h1(self):
            self._h1_called = True

        def _h2(self):
            self._h2_called = True
            raise RuntimeError('foo')

        def _h3(self):
            self._h3_called = True

    # Test: call event source with no handlers
    x = _EventSource()
    x.fire()

    # Test: call event source with no handlers, with and exception handler
    c = Child1()


# Generated at 2022-06-23 13:37:46.432464
# Unit test for constructor of class _EventSource
def test__EventSource():
    def method1(arg):
        return arg

    def method2(arg):
        return arg

    handlers = _EventSource()
    handlers += method1
    handlers += method2
    handlers -= method2


# Generated at 2022-06-23 13:37:57.690313
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class Class:
        # class attribute
        handler = None

        # instance method
        def handler_function(self):
            pass

    c = Class()

    # next is a side-effect free test of __isub__
    event_source = _EventSource()

    event_source += c.handler_function
    assert event_source._handlers == {c.handler_function}

    event_source -= c.handler_function
    assert event_source._handlers == set()

    # next is a side-effect free test of its support for class attribute handlers
    event_source += Class.handler_function
    assert event_source._handlers == {Class.handler_function}

    event_source -= Class.handler_function
    assert event_source._handlers == set()

    # next is a side-effect free test of its support for class

# Generated at 2022-06-23 13:38:01.767636
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:38:06.180978
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    x = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert x._collection_finder is None
    assert x._default_collection is None
    assert isinstance(x._on_collection_load, _EventSource)
    assert len(x._on_collection_load._handlers) == 0


# Generated at 2022-06-23 13:38:07.982427
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    #TODO: Need to write unit test
    pass


# Generated at 2022-06-23 13:38:10.160925
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(_AnsibleCollectionConfig('_AnsibleCollectionConfig', (object,), {}),
                      _AnsibleCollectionConfig)

# Generated at 2022-06-23 13:38:13.030158
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    eventsource = _EventSource()
    eventsource.__iadd__(lambda: None)



# Generated at 2022-06-23 13:38:17.291568
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def callable_func():
        pass

    event_source = _EventSource()
    event_source += callable_func
    event_source -= callable_func
    assert len(event_source._handlers) == 0


# Generated at 2022-06-23 13:38:20.175334
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    obj = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert obj._collection_finder is None
    assert obj._default_collection is None


# Generated at 2022-06-23 13:38:21.996479
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()

# Generated at 2022-06-23 13:38:24.218588
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += es._on_exception
    assert es._handlers


# Generated at 2022-06-23 13:38:34.780086
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # make sure we instantiate a new class for each call
    assert type(AnsibleCollectionConfig) is not AnsibleCollectionConfig

    # no previous config exists
    with pytest.raises(AttributeError):
        config = AnsibleCollectionConfig()
        print('config: %s' % config)
    assert not AnsibleCollectionConfig.collection_finder
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.playbook_paths == []

    # config should not be settable
    with pytest.raises(AttributeError):
        AnsibleCollectionConfig.collection_finder = 'dummy'
    with pytest.raises(AttributeError):
        AnsibleCollectionConfig.collection_paths = 'dummy'

# Generated at 2022-06-23 13:38:46.780236
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Test1:
        def __init__(self):
            self.value = None

        def __call__(self, *args, **kwargs):
            self.value = args[0]

    class _Test2:
        def __init__(self):
            self.value = None
            self.exception = None

        def __call__(self, *args, **kwargs):
            self.value = args[0]
            raise RuntimeError(self.value)

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception = exc

    class _Test3:
        def __init__(self):
            self.value = None
            self.exception = None

        def __call__(self, *args, **kwargs):
            self.value = args

# Generated at 2022-06-23 13:38:51.538801
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=protected-access
    assert not hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert not hasattr(AnsibleCollectionConfig, 'default_collection')
    assert not hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert not hasattr(AnsibleCollectionConfig, 'playbook_paths')
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:38:53.792591
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c.on_collection_load

# Generated at 2022-06-23 13:38:55.559279
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert not event_source._handlers



# Generated at 2022-06-23 13:38:57.190772
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    def handler(ev):
        pass

    e += handler

    assert handler in e._handlers


# Generated at 2022-06-23 13:39:00.003195
# Unit test for constructor of class _EventSource
def test__EventSource():
    targets = _EventSource()
    assert isinstance(targets, _EventSource)



# Generated at 2022-06-23 13:39:07.011638
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    es = _EventSource()

    failed = False

    try:
        es += handler
    except ValueError:
        failed = True

    if failed:
        raise AssertionError('_EventSource.__iadd__ failed to add a callable handler')

    try:
        es += 5
    except ValueError:
        pass
    else:
        raise AssertionError('_EventSource.__iadd__ should have failed to add a non-callable handler')


# Generated at 2022-06-23 13:39:12.909781
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # type: () -> None
    def handler():
        pass

    s = _EventSource()

    assert handler not in s._handlers
    s += handler
    assert handler in s._handlers
    s += handler
    assert handler in s._handlers
    s -= handler
    assert handler not in s._handlers


# Generated at 2022-06-23 13:39:20.528859
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def handler():
        pass

    def handler_removed():
        pass

    event_source += handler
    event_source += handler_removed

    assert handler in event_source._handlers
    assert handler_removed in event_source._handlers

    event_source -= handler

    assert handler not in event_source._handlers
    assert handler_removed in event_source._handlers

    event_source -= handler_removed

    assert handler not in event_source._handlers
    assert handler_removed not in event_source._handlers


# Generated at 2022-06-23 13:39:23.928228
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += 1
    assert False, "Expected ValueError when attempting to set a non-callable object on an EventSource"


# Generated at 2022-06-23 13:39:33.370114
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self._method_calls = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            return True

        def _method1(self, *args, **kwargs):
            self._method_calls.append('method1')

        def _method2(self, *args, **kwargs):
            self._method_calls.append('method2')

        def _method3(self, *args, **kwargs):
            self._method_calls.append('method3')

        def _method4(self, *args, **kwargs):
            self._method_calls.append('method4')

    es = MyEventSource()
    es

# Generated at 2022-06-23 13:39:43.687544
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class spy:
        def __init__(self, expected_args, expected_kwargs, on_exception=None):
            self._expected_args = expected_args
            self._expected_kwargs = expected_kwargs
            self._on_exception = on_exception

        def __eq__(self, other):
            return self.__hash__() == other.__hash__()

        def __hash__(self):
            return id(self)

        def __call__(self, *args, **kwargs):
            assert args == tuple(self._expected_args)
            assert kwargs == self._expected_kwargs
            if self._on_exception:
                self._on_exception()

    e = _EventSource()
    s = spy((1, 2), {'a': 'b'})
    e

# Generated at 2022-06-23 13:39:54.331560
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class testCollectionConfig(AnsibleCollectionConfig):
        pass
    tcc = testCollectionConfig()
    assert type(tcc._collection_finder) == _EventSource
    assert tcc._default_collection == None
    assert type(tcc._on_collection_load) == _EventSource
    assert type(tcc.collection_finder) == property
    assert type(tcc.collection_paths) == property
    assert type(tcc.default_collection) == property
    assert type(tcc.on_collection_load) == property
    assert type(tcc.playbook_paths) == property


# Generated at 2022-06-23 13:39:56.092291
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_event_source = _EventSource()
    assert test_event_source._handlers == set()


# Generated at 2022-06-23 13:40:00.800762
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible.module_utils.collection_loader._event_source import _EventSource

    source = _EventSource()

    source += lambda: None

    len(source._handlers) == 1
    source -= lambda: None
    len(source._handlers) == 0

    try:
        source -= lambda: None
        assert False
    except KeyError:
        pass


# Generated at 2022-06-23 13:40:03.874223
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    es = _EventSource()
    def handler1():
        return True
    def handler2():
        raise ValueError('bogus message')

    es += handler1
    es += handler2

    es.fire()

# Generated at 2022-06-23 13:40:09.724219
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return True
    es = EventSource()
    es += lambda: None
    es.fire()
    es += lambda: None
    es.fire()


# Generated at 2022-06-23 13:40:12.487809
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source._handlers is not None
    assert len(event_source._handlers) == 0


# Generated at 2022-06-23 13:40:17.918630
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # arrange
    eventSource = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    eventSource += handler1
    eventSource += handler2
    eventSource -= handler2

    # assert
    assert handler1 in eventSource._handlers
    assert handler2 not in eventSource._handlers



# Generated at 2022-06-23 13:40:27.001784
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths is []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.playbook_paths is []

    # test that the following properties cannot be directly assigned
    for prop in 'collection_finder', 'on_collection_load':
        try:
            setattr(AnsibleCollectionConfig, prop, None)
        except ValueError:
            pass
        else:
            raise AssertionError('expected ValueError, did not get it for {0!r}'.format(prop))



# Generated at 2022-06-23 13:40:37.002369
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestSource(_EventSource):
        pass

    source = TestSource()
    assert source.on_error is source._on_exception

    source.on_error = lambda h, ex, *args, **kwargs: False

    def run_on_start():
        pass

    def run_on_stop():
        pass

    assert source.on_start == _EventSource.on_start

    source.on_start += run_on_start
    source.on_start(1, 2, 3)

    source.on_start -= run_on_start
    source.on_start(1, 2, 3)

    source.on_stop += run_on_stop
    source.on_stop(1, 2, 3)

    source.on_stop -= run_on_stop

# Generated at 2022-06-23 13:40:42.230477
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    _EventSource()._on_exception = lambda self, handler, ex, *args, **kwargs: False
    event = _EventSource()
    my_test = lambda: True
    event += my_test
    assert len(event._handlers) == 1
    assert my_test in event._handlers


# Generated at 2022-06-23 13:40:45.320528
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible.utils.collection_loader import _AnsibleCollectionConfig
    _AnsibleCollectionConfig()
    assert True


# Generated at 2022-06-23 13:40:54.192655
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler_func1(arg1, arg2):
        pass

    def handler_func2(arg1, arg2):
        pass

    assert event_source._handlers == set()

    event_source += handler_func1
    assert event_source._handlers == {handler_func1}

    event_source += handler_func2
    assert event_source._handlers == {handler_func1, handler_func2}

    # should not raise exception
    event_source += handler_func2



# Generated at 2022-06-23 13:40:56.801150
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(foo, bar):
        pass

    event = _EventSource()

    event += handler
    assert handler in event._handlers

    event += handler
    assert handler in event._handlers



# Generated at 2022-06-23 13:40:59.137493
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source._handlers == set()


# Generated at 2022-06-23 13:41:05.326396
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    source += (lambda x: x)

    source -= (lambda x: x)

    try:
        source -= (lambda x: x)
    except KeyError:
        # The exception KeyError is expected
        pass

    try:
        source -= None
    except ValueError as ex:
        assert str(ex) == 'handler must be callable'


# Generated at 2022-06-23 13:41:07.076836
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_event_source = _EventSource()

    assert test_event_source

# Generated at 2022-06-23 13:41:10.082943
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()
    assert ev._handlers == set()
    assert isinstance(ev._handlers, set)


# Generated at 2022-06-23 13:41:12.862034
# Unit test for constructor of class _EventSource
def test__EventSource():
    def event_handler(p1, p2):
        pass

    e = _EventSource()
    e += event_handler
    assert event_handler in e._handlers

    e -= event_handler
    assert event_handler not in e._handlers

# Generated at 2022-06-23 13:41:15.642129
# Unit test for constructor of class _EventSource
def test__EventSource():
    def foo():
        pass

    def bar():
        pass

    es = _EventSource()
    es += foo
    es += bar
    es -= foo
    es -= foo
    es -= bar



# Generated at 2022-06-23 13:41:21.104649
# Unit test for constructor of class _EventSource
def test__EventSource():
    events = _EventSource()
    assert events
    assert events._handlers == set()
    try:
        events._on_exception(None, ValueError(), "value")
        assert False, "Expected ValueError to have been raised"
    except ValueError as e:
        assert "handler must be callable" in str(e)

    assert events._on_exception(None, None, None)



# Generated at 2022-06-23 13:41:26.522591
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # init
    event_source = _EventSource()
    event_source += lambda: 0
    event_source += lambda: 1

    # exercise
    event_source -= lambda: 1

    # verify
    assert len(event_source._handlers) == 1

    # cleanup

# Generated at 2022-06-23 13:41:36.828240
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class RaiseValueError(Exception):
        pass

    class RaiseAttributeError(Exception):
        pass

    class RaiseException(Exception):
        pass

    event_source = _EventSource()

    def handler(msg):
        return msg

    def raise_value_error(msg):
        raise ValueError(msg)

    def raise_attribute_error(msg):
        raise AttributeError(msg)

    def raise_exception(msg):
        raise Exception(msg)

    
    event_source += handler
    event_source += raise_value_error
    event_source += raise_attribute_error
    event_source += raise_exception

    # test that a value handler works
    assert event_source.fire("handler") == "handler"

    # test that no exception is raised when event_source._on_exception() returns False
   

# Generated at 2022-06-23 13:41:37.977345
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()  # NOQA

# Generated at 2022-06-23 13:41:45.230043
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert not hasattr(_EventSource, '__init__')

    assert hasattr(_EventSource, '__iadd__')
    assert callable(_EventSource.__iadd__)

    assert hasattr(_EventSource, '__isub__')
    assert callable(_EventSource.__isub__)

    assert hasattr(_EventSource, '_on_exception')
    assert callable(_EventSource._on_exception)

    assert hasattr(_EventSource, 'fire')
    assert callable(_EventSource.fire)

    assert hasattr(_EventSource, '_handlers')


# Generated at 2022-06-23 13:41:54.769660
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class AssertionErrorContext:
        def __init__(self):
            self.error = None

    def handler_raises(exc, assertion_error_context):
        def _handler():
            raise exc
        try:
            _handler()
        except Exception as ex:
            assertion_error_context.error = ex
    event_source = _EventSource()
    assertion_error_context = AssertionErrorContext()
    event_source += handler_raises(Exception(), assertion_error_context)
    event_source.fire()
    assert assertion_error_context.error is not None
    assert isinstance(assertion_error_context.error, Exception)



# Generated at 2022-06-23 13:42:08.021074
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_func = lambda x: x
    test_event = _EventSource()

    # test with lambda
    test_event += test_func
    assert test_func in test_event._handlers

    # test with a function
    def test_func_2(x):
        return x

    test_event += test_func_2
    assert test_func_2 in test_event._handlers

    # test with a class function
    class TestClass:
        def test_func(self, x):
            return x

        @staticmethod
        def test_static_func(x):
            return x

        @classmethod
        def test_class_func(cls, x):
            return x

    test_event += TestClass.test_func
    assert TestClass.test_func in test_event._handlers

    # test

# Generated at 2022-06-23 13:42:14.342882
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # This test is for the controller implementation only.
    # The ansible-test implementation does not execute this function.
    source = _EventSource()

    # callable
    source += lambda: None

    # non-callable
    try:
        source += None
        assert False, 'expected ValueError exception'
    except ValueError:
        pass

    # twice
    source += lambda: None
    try:
        source += lambda: None
        assert False, 'expected ValueError exception'
    except ValueError:
        pass


# Generated at 2022-06-23 13:42:25.762749
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    _test_data = dict(test_content_data=dict(test_value=True))

    def _test_handler(test_value=None):
        if not test_value:
            raise ValueError('test_value must be True')

    def _raise_handler(ex, retry):
        raise ex

    # Assign the handler for testing
    test_handler = _test_handler
    test_set = set()
    test_set.add(test_handler)
    test_event_source = _EventSource()
    test_event_source += test_handler
    # the event handler should not raise
    test_event_source.fire(**_test_data['test_content_data'])
    # remove the handler and test it again
    test_event_source -= test_handler
    test_event_source._on_

# Generated at 2022-06-23 13:42:29.249169
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # Default configuration should be set on instantiation
    test_config = AnsibleCollectionConfig()
    assert test_config.collection_finder is None
    assert test_config.default_collection is None
    assert test_config.playbook_paths is not None

# Generated at 2022-06-23 13:42:31.851593
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert len(e._handlers) == 0



# Generated at 2022-06-23 13:42:40.078313
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        pass

    eventsource = MyEventSource()

    called = False

    def on_load_collection(collection, is_new):
        nonlocal called
        called = True
        assert isinstance(is_new, bool)
        assert isinstance(collection, str)

    eventsource += on_load_collection

    eventsource.fire('foo', True)
    assert called

    eventsource -= on_load_collection

    called = False
    eventsource.fire('bar', False)
    assert not called

# Generated at 2022-06-23 13:42:41.771680
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # constructor
    config = AnsibleCollectionConfig()
    assert config._default_collection == None


# Generated at 2022-06-23 13:42:54.620909
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def test_handler1():
        raise RuntimeError('test_handler1 Error')

    def test_handler2():
        raise ValueError('test_handler2 Error')

    def test_handler3():
        raise KeyError('test_handler3 Error')

    def test_handler4():
        raise Exception('test_handler4 Error')

    exec_event = _EventSource()

    try:
        with exec_event.on_collection_load:
            pass
    except ValueError as ve:
        print("ValueError: %s" % ve)

    exec_event.on_collection_load += test_handler1
    exec_event += test_handler2

    try:
        exec_event.fire()
    except ValueError as e:
        print("ValueError: %s" % e)


# Generated at 2022-06-23 13:43:00.004456
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    evt = _EventSource()

    # Will create a python error if not callable
    evt += None

    # Will create a python error if not callable
    evt += 'test'

    # Will create a python error if not callable
    evt += []

    def test():
        pass

    # Works fine
    evt += test

    # Works fine
    evt += test

    assert len(evt._handlers) == 1



# Generated at 2022-06-23 13:43:00.967024
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None

# Generated at 2022-06-23 13:43:07.071734
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def f1(a, b):
        return a + b
    def f2(a, b):
        return a * b

    es += f1
    es += f2

    assert len(es._handlers) == 2
    assert f1 in es._handlers
    assert f2 in es._handlers


# Generated at 2022-06-23 13:43:12.252420
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es

    def my_handler():
        # This function will be called by the event source as an event handler
        return True

    # Register an event handler
    es += my_handler
    assert my_handler in es._handlers
    assert callable(my_handler)

    # Deregister an event handler
    es -= my_handler
    assert my_handler not in es._handlers


# Generated at 2022-06-23 13:43:19.411785
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    x = _EventSource()
    y = [0]

    def inc_y(arg):
        y[0] += arg

    x += inc_y
    x.fire(1)
    assert y[0] == 1

    x -= inc_y
    x.fire(1)
    assert y[0] == 1

    def raise_exception():
        raise Exception('test')

    x += raise_exception

    try:
        x.fire()
    except Exception as ex:
        assert str(ex) == 'test'
    else:
        assert False, 'Exception did not raise'