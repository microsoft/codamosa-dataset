

# Generated at 2022-06-23 13:33:22.014846
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # We define a call handler class to store call history
    class _TestHandler:
        def __init__(self):
            self.call_history = []

        def __call__(self, *args, **kwargs):
            self.call_history.append((args, kwargs))

    # We define a handler that always fails
    def _failing_handler(*args, **kwargs):
        raise IOError('Test failure.')

    # Handler for when a test failure happens.
    # We want to know when the test is properly failing
    # which is why we return True, so the caller re-raises
    def _on_exception(handler, exc, *args, **kwargs):
        if handler != _failing_handler:
            return True

        return False

    # A plain handler

# Generated at 2022-06-23 13:33:30.923182
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    from io import BytesIO
    # Test 1: handler must be callable
    with pytest.raises(ValueError):
        _EventSource.__iadd__(None, None)

    # Test 2: __iadd__ returns self
    assert(_EventSource.__iadd__(None, BytesIO) is None)

    # Test 3: handler must be callable
    with pytest.raises(ValueError):
        _EventSource.__iadd__(None, None)

    # Test 4: __iadd__ returns self
    assert(_EventSource.__iadd__(None, BytesIO) is None)

    # Test 5: handler must be callable
    with pytest.raises(ValueError):
        _EventSource.__iadd__(None, None)

    # Test 6: __

# Generated at 2022-06-23 13:33:35.808659
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.on_collection_load._on_exception(None, None) is True


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 13:33:44.569971
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    e = _EventSource()

    # Add an integer to an event source
    with pytest.raises(ValueError):
        e += 5

    # Add a floating point to an event source
    with pytest.raises(ValueError):
        e += 5.0

    # Add a boolean to an event source
    with pytest.raises(ValueError):
        e += True

    # Add a string to an event source
    with pytest.raises(ValueError):
        e += "five"

    # Add an empty list to an event source
    with pytest.raises(ValueError):
        e += []

    # Add an empty dict to an event source
    with pytest.raises(ValueError):
        e += {}

    # Add an empty tuple to an event source

# Generated at 2022-06-23 13:33:45.877278
# Unit test for constructor of class _EventSource
def test__EventSource():
    with _EventSource() as event:
        pass


# Generated at 2022-06-23 13:33:51.885592
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    foo = 0

    def func1(a, b, c):
        nonlocal foo
        foo = a + b + c

    def func2(a, b, c):
        nonlocal foo
        foo = a * b * c

    event += func1
    event += func2

    event.fire(1, 2, 3)

    assert foo == 18



# Generated at 2022-06-23 13:33:53.340628
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')

# Generated at 2022-06-23 13:33:57.751116
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Arrange
    evt = _EventSource()
    evt += lambda: 1
    evt += lambda: 2

    # Act
    evt.fire()

    # Assert
    assert len(evt._handlers) == 2


# Generated at 2022-06-23 13:34:00.545972
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event_source += handler1
    event_source -= handler2

# Generated at 2022-06-23 13:34:01.982776
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config is not None

# Generated at 2022-06-23 13:34:07.956904
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    # Exception is not raised if handler was not previously added to event
    try:
        event = _EventSource()
        event -= lambda evt: None
    except Exception as error:
        raise AssertionError(to_text(error))

    # Exception is not raised if handler was previously added to event, then removed
    event -= lambda evt: None
    try:
        event -= lambda evt: None
    except Exception as error:
        raise AssertionError(to_text(error))


# END

# Generated at 2022-06-23 13:34:14.689242
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Foo:
        pass

    eventsource = _EventSource()
    foo1 = _Foo()
    foo2 = _Foo()
    foo1.bar = False
    foo2.bar = False
    eventsource += lambda: setattr(foo1, 'bar', True)
    eventsource += lambda: setattr(foo2, 'bar', True)
    eventsource += lambda: setattr(foo1, 'bar', False)
    eventsource += lambda: setattr(foo2, 'bar', False)

    eventsource.fire()

    assert foo1.bar
    assert foo2.bar



# Generated at 2022-06-23 13:34:25.581861
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible.utils.collection_loader.objects import AnsibleCollectionRef

    # The below code is not being spotted as a test by pytest.
    # This is a workaround.
    # See https://www.python.org/dev/peps/pep-0382/
    # and https://docs.pytest.org/en/latest/goodpractices.html#test-discovery
    try:
        import pytest
        is_pytest = True
    except ImportError:
        is_pytest = False

    if is_pytest:
        pytest.main(['-v', __file__])

    # setup
    dummy_ansible_collections_paths = ['dummy_ansible_collections_path']


# Generated at 2022-06-23 13:34:37.489816
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Meta(type):
        pass

    class Base(object):
        pass

    class Test(with_metaclass(Meta, Base)):
        pass

    # when we call the __init__ method of the metaclass, the 'meta' argument is an instance of the metaclass
    Test.__init__(Meta, 'Meta', (object, ))

    # when we call the __init__ method of the metaclass directly, the 'meta' argument is an instance of the metaclass
    Meta.__init__(Meta, 'Meta', (object, ))

    # now, create a class with _AnsibleCollectionConfig as a metaclass
    class Test(with_metaclass(_AnsibleCollectionConfig, Base)):
        pass

    # when we call the __init__ method of the metaclass, the 'meta' argument is

# Generated at 2022-06-23 13:34:42.607077
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    base = _EventSource()
    def foo(): print('foo')
    def bar(): print('bar')
    base += foo
    base += bar
    base -= foo
    base.fire()
    # Ensure that we don't raise an exception.
    base -= foo
    base.fire()
    # Ensure that base.fire is called as expected.
    base -= bar
    try:
        base.fire()
        assert False
    except:
        assert True

# Generated at 2022-06-23 13:34:44.956855
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # This test creates an instance of AnsibleCollectionConfig as
    # defined in ansible_collections/collection_loader/collection_config.py
    # and no other imported class.
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:34:47.694811
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    evt = _EventSource()

    # add a handler
    def handler():
        pass

    evt += handler

    # add the same handler a second time; no error
    evt += handler


# Generated at 2022-06-23 13:34:56.085771
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def func(a, b):
        raise NotImplementedError()

    updated_es = es.__iadd__(func)
    assert es is updated_es

    # Should raise an exception if we try to add something that is not callable
    try:
        updated_es = es.__iadd__(None)
        assert False
    except ValueError:
        assert True

    # Should silently ignore the attempt to add a duplicate
    updated_es = es.__iadd__(func)
    assert len(updated_es._handlers) == 1


# Generated at 2022-06-23 13:35:09.473975
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest
    class _EventSourceTest(object):
        def __init__(self):
            self._event_source = _EventSource()
        @property
        def event_source(self):
            return self._event_source
        def handler(self, value):
            return value
        def invalid_handler(self, value):
            return self
        def exception_handler(self, value):
            raise ValueError(value)
    @pytest.fixture(scope='module')
    def _event_source_test():
        return _EventSourceTest()
    def test__EventSource_fire_with_one_handler(self, _event_source_test):
        event_source = _event_source_test.event_source
        event_source += _event_source_test.handler

# Generated at 2022-06-23 13:35:11.070546
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler():
        pass

    e = _EventSource()
    e += handler
    assert handler in e._handlers

# Generated at 2022-06-23 13:35:14.569635
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    x = AnsibleCollectionConfig()
    assert x.__class__._collection_finder is None
    assert x.__class__._default_collection is None

# Generated at 2022-06-23 13:35:19.651964
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()

    assert ansible_collection_config.collection_finder is None, \
        "collection_finder should have been none"
    assert ansible_collection_config.default_collection is None, \
        "default_collection should have been none"
    assert ansible_collection_config.collection_paths == [], \
        "collection_finder should have been an empty list"

# Generated at 2022-06-23 13:35:23.944858
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def handler1():
        pass

    def handler2():
        pass

    event += handler1
    event += handler2

    assert event._handlers == set([handler1, handler2])


# Generated at 2022-06-23 13:35:27.175495
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=unused-variable
    class ClassWithAnsibleCollectionConfig(object):
        __metaclass__ = _AnsibleCollectionConfig
        pass

    instance = ClassWithAnsibleCollectionConfig()

    assert isinstance(instance, ClassWithAnsibleCollectionConfig)


# Generated at 2022-06-23 13:35:36.271635
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler():
        pass

    def handler1():
        pass

    def handler2():
        pass

    def handler3():
        pass

    es = _EventSource()
    es += handler
    es += handler1
    es += handler2
    es += handler3
    assert handler in es._handlers
    assert handler1 in es._handlers
    assert handler2 in es._handlers
    assert handler3 in es._handlers

    es -= handler
    assert handler not in es._handlers
    assert handler1 in es._handlers
    assert handler2 in es._handlers
    assert handler3 in es._handlers

    es -= handler1
    assert handler not in es._handlers
    assert handler1 not in es._handlers
    assert handler2 in es._handlers
    assert handler3 in es._handlers

    es

# Generated at 2022-06-23 13:35:37.251716
# Unit test for constructor of class _EventSource
def test__EventSource():
    x = _EventSource()



# Generated at 2022-06-23 13:35:38.522542
# Unit test for constructor of class _EventSource
def test__EventSource():
    my_event = _EventSource()

# Generated at 2022-06-23 13:35:41.263816
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    ev_src = _EventSource()
    ev_src += lambda: None
    ev_src -= lambda: None



# Generated at 2022-06-23 13:35:50.019618
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    # test remove of non-existent handler
    assert len(event._handlers) == 0  # sanity check
    ret = event.__isub__(lambda *args, **kwargs: None)
    assert len(event._handlers) == 0
    assert ret is event

    def handler(arg):
        pass

    # add the handler and verify it's in the handlers set
    event.__iadd__(handler)
    assert len(event._handlers) == 1
    assert handler in event._handlers

    # remove the handler and verify it's not in the handlers set
    ret = event.__isub__(handler)
    assert len(event._handlers) == 0
    assert ret is event

# test__EventSource___isub__()


# Generated at 2022-06-23 13:35:55.359338
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert len(AnsibleCollectionConfig.collection_paths) == 0
    assert AnsibleCollectionConfig.collection_paths == []
    assert len(AnsibleCollectionConfig.playbook_paths) == 0
    assert AnsibleCollectionConfig.playbook_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load._handlers == set()

# Generated at 2022-06-23 13:36:06.575094
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler():
        pass

    # test constructor
    e = _EventSource()
    assert not e._handlers

    # test +=
    e += handler
    assert e._handlers == set([handler])

    # test -=
    e -= handler
    assert not e._handlers

    # test += with non-callable handler
    try:
        e += 5
    except ValueError:
        pass
    else:
        assert False, 'expected ValueError'

    # test -= with non-callable handler
    try:
        e -= 5
    except KeyError:
        pass
    else:
        assert False, 'expected KeyError'

# Generated at 2022-06-23 13:36:08.058930
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    with pytest.raises(ValueError) as error:
        event_source.__iadd__('handler')
    assert str(error.value) == 'handler must be callable'


# Generated at 2022-06-23 13:36:09.399496
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()

    assert ev._handlers == set()



# Generated at 2022-06-23 13:36:10.949355
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers is not None

# Generated at 2022-06-23 13:36:17.784817
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    '''
    Unit test for the constructor of class _AnsibleCollectionConfig
    '''
    class TestConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    cfg = TestConfig()
    assert not cfg._collection_finder
    assert not cfg._default_collection
    assert cfg.on_collection_load is cfg._on_collection_load


# Generated at 2022-06-23 13:36:20.761410
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def func(o):
        raise ValueError('func should not be called')
    source = _EventSource()
    source.fire()
    source.__isub__(func)
    source.fire()
    # should not raise
    source.__isub__(func)


# Generated at 2022-06-23 13:36:29.949044
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _TestEventSource(_EventSource):
        def _on_exception(self, d, e, *a, **k):
            self.exception_handler = d
            self.exception = e
            self.args = a
            self.kwargs = k

    def handler(*args, **kwargs):
        handler.called = True
        handler.args = args
        handler.kwargs = kwargs

    # Test a regular handler
    event_source = _TestEventSource()
    event_source += handler
    event_source.fire(1, 2)
    assert handler.called

    # Test a handler that raises
    class TestException(Exception):
        pass

    handler.called = False

    def handler_raises(*args, **kwargs):
        raise TestException('expected to raise')

    event_source += handler

# Generated at 2022-06-23 13:36:31.043082
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:36:38.972662
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    instance = _AnsibleCollectionConfig(object, 'foo', object)

    assert instance._collection_finder is None
    assert instance._default_collection is None
    assert isinstance(instance._on_collection_load, _EventSource)

    assert hasattr(instance, 'collection_finder')
    assert hasattr(instance, 'collection_paths')
    assert hasattr(instance, 'default_collection')
    assert hasattr(instance, 'on_collection_load')
    assert hasattr(instance, 'playbook_paths')


# Generated at 2022-06-23 13:36:44.425224
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler_1():
        pass

    def handler_2():
        pass

    event_source = _EventSource()
    event_source += handler_1
    event_source += handler_2

    assert handler_1 in event_source._handlers
    assert handler_2 in event_source._handlers



# Generated at 2022-06-23 13:36:45.420317
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    v = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:36:57.284225
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # verify that the properties are initialized
    cls = _AnsibleCollectionConfig(None, 'test', None)
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert isinstance(cls._on_collection_load, _EventSource)

    # verify that we cannot overwrite the on_collection_load property
    try:
        cls._on_collection_load = 'foo'
        assert False, 'expected a ValueError exception'
    except ValueError:
        # expected exception
        pass

    # verify that the collection_paths and playbook_paths properties raise NotImplementedError
    try:
        cls.collection_paths
        assert False, 'expected a NotImplementedError exception'
    except NotImplementedError:
        # expected exception
        pass

# Generated at 2022-06-23 13:37:01.821980
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    try:
        a = AnsibleCollectionConfig()
    except TypeError:
        import pytest
        pytest.fail('Failed to instantiate AnsibleCollectionConfig')


# Unit tests for the AnsibleCollectionConfig class

# Generated at 2022-06-23 13:37:12.899722
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # access the module variable '__metaclass__' through the container class's __class__
    assert AnsibleCollectionConfig.__class__.__metaclass__ == _AnsibleCollectionConfig

    # test default class properties
    assert AnsibleCollectionConfig.__class__.collection_finder is None
    assert AnsibleCollectionConfig.__class__.default_collection is None
    assert AnsibleCollectionConfig.__class__.on_collection_load is not None
    assert AnsibleCollectionConfig.__class__.playbook_paths is None

    from ansible.utils.collection_loader._collection_finder_base import AnsibleCollectionFinderBase
    cls = AnsibleCollectionFinderBase()

    # try to set collection_finder without the metaclass

# Generated at 2022-06-23 13:37:17.002559
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c.collection_finder is None
    assert c.default_collection is None
    assert hasattr(c.on_collection_load, 'fire')



# Generated at 2022-06-23 13:37:23.650172
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert hasattr(c, 'on_collection_load')
    assert hasattr(c, 'collection_finder')
    assert hasattr(c, 'collection_paths')
    assert hasattr(c, 'default_collection')
    assert hasattr(c, 'playbook_paths')

    c.default_collection = 'acme.foo'
    assert c.default_collection == 'acme.foo'

    assert isinstance(c.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:37:25.173390
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:37:28.843799
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class AnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    c = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:37:33.471092
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    h = lambda x: None
    es += h
    assert h in es._handlers
    es -= h
    assert h not in es._handlers
    es -= h
    assert h not in es._handlers


# Generated at 2022-06-23 13:37:34.211052
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    acc = _AnsibleCollectionConfig(None, 'acc', (object,))

# Generated at 2022-06-23 13:37:34.852651
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    pass

# Generated at 2022-06-23 13:37:44.870894
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import PY2, PY3

    target = _EventSource()

    import io
    import sys

    class _DevNull(io.StringIO if PY3 else io.BytesIO):
        isatty = lambda self: False

    devnull = _DevNull()
    stderr = sys.stderr
    sys.stderr = devnull

    def f():
        sys.stderr = stderr
    target -= f

    if PY2:
        import cStringIO
        devnull.seek(0)
        if devnull.read():
            sys.stderr.write(cStringIO.StringIO(devnull.getvalue()).getvalue())

# Generated at 2022-06-23 13:37:45.822781
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_class = _EventSource()



# Generated at 2022-06-23 13:37:48.960398
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    instance = AnsibleCollectionConfig()
    assert isinstance(instance.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:37:58.436081
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # load ansible.collection.collection_loader
    import ansible.collection.collection_loader

    # construct instance of class _EventSource
    test_event_source = ansible.collection.collection_loader._EventSource()

    # construct instance of class ansible.cliss.cli.CLI
    test_ansible_cli = ansible.collection.collection_loader.CLI()

    # add method display of class ansible.cliss.cli.CLI to _EventSource
    test_event_source += test_ansible_cli.display

    # test AnsibleCollectionLoader.fire
    test_ansible_collection_loader = ansible.collection.collection_loader.AnsibleCollectionLoader()
    test_ansible_collection_loader.fire(test_event_source, "ignore")



# Generated at 2022-06-23 13:38:05.160858
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)
    assert hasattr(_AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(_AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(_AnsibleCollectionConfig, 'default_collection')
    assert hasattr(_AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(_AnsibleCollectionConfig, 'playbook_paths')

# Generated at 2022-06-23 13:38:07.510340
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    _EventSource.__isub__(None, None)


# Generated at 2022-06-23 13:38:16.080215
# Unit test for constructor of class _EventSource
def test__EventSource():
    from unittest import TestCase
    from unittest import mock

    t = TestCase()
    with mock.patch('%s._on_exception' % __name__) as mock_on_exception:
        mock_on_exception.return_value = False

        # NOTE: __init__() is called by default when the class is instantiated;
        # however, it can be explicitly called to set initial state
        # on any object that has already been instantiated
        event_source = _EventSource.__new__(_EventSource)
        _EventSource.__init__(event_source)

        t.assertEqual(event_source._handlers, set())
        t.assertTrue(callable(event_source.__iadd__))
        t.assertTrue(callable(event_source.__isub__))
       

# Generated at 2022-06-23 13:38:19.823579
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    eventsource = _EventSource()
    eventsource += lambda x: x + 1
    assert len(eventsource._handlers) == 1
    eventsource -= lambda x: x + 1
    assert len(eventsource._handlers) == 0


# Generated at 2022-06-23 13:38:25.486072
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Event:
        def __init__(self, ev_data):
            self.ev_data = ev_data
        def __call__(self, *args, **kwargs):
            print(self.ev_data, args, kwargs)

    es = _EventSource()
    e0 = Event(55)
    e1 = Event(11)
    e2 = Event(22)

    es += e0
    es += e1
    es += e2

    es.fire('cat', 'dog', fish=3)
    es.fire(event_name='event')

    es -= e1
    es.fire('dinner')



# Generated at 2022-06-23 13:38:28.087777
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    x = _EventSource()
    x += 1  # TypeError: handler must be callable
    y = lambda *args, **kwargs: None
    x += y
    assert y in x._handlers


# Generated at 2022-06-23 13:38:31.007708
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None

# Generated at 2022-06-23 13:38:36.844027
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_list = []
    obj = _EventSource()

    def fnc(x):
        test_list.append(x)

    obj += fnc
    obj.fire(1)
    obj.fire(2)
    obj.fire(3)

    assert test_list == [1, 2, 3]
    assert obj._handlers == {fnc}

    obj -= fnc
    assert obj._handlers == set()



# Generated at 2022-06-23 13:38:48.330129
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    class EventSource(object):
        def __init__(self):
            self._handlers = set()

        def __iadd__(self, handler):
            if not callable(handler):
                raise ValueError('handler must be callable')
            self._handlers.add(handler)
            return self

        def __isub__(self, handler):
            try:
                self._handlers.remove(handler)
            except KeyError:
                pass

            return self

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True


# Generated at 2022-06-23 13:38:56.177850
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import ansible.utils.collection_loader

    # This is a test because Python does not guarantee the order of class attributes.
    assert len(ansible.utils.collection_loader.AnsibleCollectionConfig.__dict__.keys()) == len(_AnsibleCollectionConfig.__dict__.keys())
    assert sorted(ansible.utils.collection_loader.AnsibleCollectionConfig.__dict__.keys()) == sorted(_AnsibleCollectionConfig.__dict__.keys())

# Generated at 2022-06-23 13:39:01.289990
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    handler = lambda x: print(x)
    es += handler
    assert handler in es._handlers
    es -= handler
    assert handler not in es._handlers

# Generated at 2022-06-23 13:39:04.518265
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    obj = _AnsibleCollectionConfig()
    assert obj.collection_finder is None
    assert obj.default_collection is None
    assert obj.on_collection_load is not None

# Generated at 2022-06-23 13:39:07.256436
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource()._handlers == set()


# Generated at 2022-06-23 13:39:18.363613
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # initialize the class and validate the event source was added correctly
    assert hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not AnsibleCollectionConfig._collection_finder
    assert hasattr(AnsibleCollectionConfig, '_default_collection')
    assert not AnsibleCollectionConfig._default_collection
    assert hasattr(AnsibleCollectionConfig, '_on_collection_load')
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollectionConfig._on_collection_load
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:39:28.959451
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    def handler_1(event):
        pass

    def handler_2(event):
        pass

    source += handler_1
    source += handler_2

    assert handler_1 in source._handlers
    assert handler_2 in source._handlers

    source -= handler_1

    assert handler_1 not in source._handlers
    assert handler_2 in source._handlers

    source -= handler_2

    assert handler_1 not in source._handlers
    assert handler_2 not in source._handlers

    source -= handler_2

    assert handler_1 not in source._handlers
    assert handler_2 not in source._handlers



# Generated at 2022-06-23 13:39:32.675945
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    es -= 1
    assert len(es._handlers) == 0

    def foo():
        pass

    es += foo
    es -= foo
    assert len(es._handlers) == 0



# Generated at 2022-06-23 13:39:37.279321
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    s = _EventSource()

    class H1:
        def __eq__(self, other):
            return id(self) == id(other)

    h1 = H1()
    s += h1

    s -= h1
    assert len(s._handlers) == 0


# Generated at 2022-06-23 13:39:45.385616
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def noop(*args, **kwargs):
        return

    def raises(*args, **kwargs):
        raise Exception('boom')

    s = _EventSource()

    s += noop
    s += noop

    s += raises
    s += noop

    s.fire(1, 2, 3, a='a', b='b')

    s -= noop
    s -= noop

    s.fire(1, 2, 3, a='a', b='b')

    s -= noop

    s.fire(1, 2, 3, a='a', b='b')

    s -= raises

    s.fire(1, 2, 3, a='a', b='b')

# Generated at 2022-06-23 13:39:55.697980
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Test normal operation where the handler does exist.
    _EventSource___isub___s = _EventSource()
    _EventSource___isub___s += _EventSource___isub___handler
    _EventSource___isub___s -= _EventSource___isub___handler
    _EventSource___isub___s -= _EventSource___isub___handler  # must not throw

    # Test normal operation of not having the handler to remove.
    _EventSource___isub___s = _EventSource()
    _EventSource___isub___s -= _EventSource___isub___handler



# Generated at 2022-06-23 13:40:01.392295
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def not_called(*args, **kwargs):
        raise AssertionError('should not be called')

    es += not_called
    es -= not_called
    assert len(es._handlers) == 0

    es += not_called
    es -= not_called
    assert len(es._handlers) == 0

    es += not_called
    es -= not_called
    assert len(es._handlers) == 0



# Generated at 2022-06-23 13:40:07.555049
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class Foo:
        pass

    foo = Foo()

    event_source = _EventSource()

    assert not event_source._handlers
    event_source += foo
    assert event_source._handlers == set([foo])

    event_source -= foo
    assert not event_source._handlers
    event_source -= foo
    assert not event_source._handlers

# Generated at 2022-06-23 13:40:17.006022
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class MyClass:
        def __init__(self, value):
            self.value = value
        def __call__(self, *args, **kwargs):
            return self.value
        def __eq__(self, other):
            return self.value == other.value

    ev = _EventSource()
    ob1 = MyClass('ob1')
    ob2 = MyClass('ob2')
    ob3 = MyClass('ob3')
    ev += ob1
    ev += ob2
    ev += ob3
    assert len(ev._handlers) == 3

    ev -= ob1
    assert len(ev._handlers) == 2
    assert ob2 in ev._handlers
    assert ob3 in ev._handlers

    ev -= ob2
    assert len(ev._handlers) == 1

# Generated at 2022-06-23 13:40:21.301712
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    event_source += lambda: None

    assert len(event_source._handlers) == 1

    event_source += lambda: None

    assert len(event_source._handlers) == 2


# Generated at 2022-06-23 13:40:26.149926
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestCollectionConfig(AnsibleCollectionConfig):
        pass
    assert TestCollectionConfig.collection_finder is None
    assert TestCollectionConfig.default_collection is None
    assert hasattr(TestCollectionConfig.on_collection_load, 'fire')
    assert TestCollectionConfig.playbook_paths is None


# Generated at 2022-06-23 13:40:32.782312
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')


# Generated at 2022-06-23 13:40:34.856958
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    mock_handler = lambda: None

    event_source = _EventSource()
    event_source += mock_handler
    event_source.fire()

# Generated at 2022-06-23 13:40:37.885653
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestEvent(_EventSource):
        pass
    te = TestEvent()
    te += lambda x: print(x)
    te.fire('This is a test')



# Generated at 2022-06-23 13:40:40.204169
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()

# Generated at 2022-06-23 13:40:41.652450
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')

# Generated at 2022-06-23 13:40:48.451082
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class MyCollectionConfig(AnsibleCollectionConfig):
        pass

    cfg = MyCollectionConfig()

    assert cfg._collection_finder is None
    assert cfg._default_collection is None

    assert cfg._on_collection_load.__class__.__name__ == '_EventSource'
    assert isinstance(cfg.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:40:49.874954
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig()

# Generated at 2022-06-23 13:40:55.613706
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def fail():
        raise Exception('some exception')

    event_source = _EventSource()
    assert len(event_source._handlers) == 0
    event_source += fail
    assert len(event_source._handlers) == 1

    # should not raise any exception
    event_source.fire()

    event_source -= fail
    assert len(event_source._handlers) == 0



# Generated at 2022-06-23 13:40:59.923290
# Unit test for constructor of class _EventSource
def test__EventSource():
    def test_handler(event, data):
        print(event, data)

    event_source = _EventSource()
    event_source += test_handler
    event_source.fire('test event', 'some data')

# Generated at 2022-06-23 13:41:09.133716
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible_test._fake_collections import FakeModuleUtilsCollectionConfig
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # self._on_exception() always returns True
    def test_exception_expect_reraise():
        from ansible_test._data.units.modules.utils.collection_loader.ansible_collection_config import _EventSource

        fake = FakeModuleUtilsCollectionConfig()
        fake.on_collection_load += fake._record_event

        # raise an exception
        fake.on_collection_load.fire(fake._TOKEN)

        assert fake._exception is not None
        assert isinstance(fake._exception, ValueError)

# Generated at 2022-06-23 13:41:13.820836
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    counter = 0

    def handler(data):
        nonlocal counter
        counter += 1
        if counter == 2:
            raise ValueError('I raise at 2')

    source = _EventSource()
    source += handler
    source += handler

    source.fire()

    assert counter == 2

# Generated at 2022-06-23 13:41:18.278833
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.playbook_paths is None
    assert config.on_collection_load is not None

    config.on_collection_load += lambda: print(1)
    assert len(config.on_collection_load._handlers) == 1

# Generated at 2022-06-23 13:41:21.637677
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Test(with_metaclass(_AnsibleCollectionConfig)):
        pass

    test = Test()
    assert test._collection_finder is None
    assert test._default_collection is None
    assert isinstance(test._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:41:33.628143
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Callback:
        def __init__(self, event_source):
            self.count = 0
            event_source += self._callback

        def _callback(self, *args, **kwargs):
            self.count += 1

    class EventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            raise RuntimeError('exception in handler %s' % handler)

    event_source = EventSource()

    callback = Callback(event_source)

    # first event...
    event_source.fire()
    assert callback.count == 1

    # second event...
    event_source.fire()
    assert callback.count == 2

    # remove handler and issue event; count should not change
    event_source -= callback._callback
    event_source.fire()
   

# Generated at 2022-06-23 13:41:36.126116
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')

# Generated at 2022-06-23 13:41:45.804956
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.on_collection_load is not None

    AnsibleCollectionConfig.collection_finder = 'foo'
    assert AnsibleCollectionConfig.collection_finder == 'foo'
    try:
        AnsibleCollectionConfig.collection_finder = 'bar'
        assert False, 'expected exception'
    except ValueError:
        pass

    assert AnsibleCollectionConfig.collection_paths is None

    AnsibleCollectionConfig.default_collection = 'foo'
    assert AnsibleCollectionConfig.default_collection == 'foo'

    assert AnsibleCollectionConfig.playbook_paths is None

    AnsibleCollectionConfig.playbook_paths = ['foo', 'bar']
    assert AnsibleCollectionConfig.playbook_paths == ['foo', 'bar']


# Generated at 2022-06-23 13:41:51.149327
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert AnsibleCollectionConfig.__name__ == 'AnsibleCollectionConfig'
    assert AnsibleCollectionConfig.__dict__ == _AnsibleCollectionConfig.__dict__

# unit test for getters and setters of class AnsibleCollectionConfig

# Generated at 2022-06-23 13:42:01.500689
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestHandler:
        def __call__(self, *args, **kwargs):
            pass

    def _test(event_source, handler):
        event_source.fire(1, 2, 3)
        event_source -= handler

    # handler does nothing
    event_source = _EventSource()
    handler = _TestHandler()
    event_source.fire()
    event_source += handler
    _test(event_source, handler)

    # handler raises exception
    def _exception():
        raise Exception()

    event_source = _EventSource()
    event_source += _exception

    try:
        event_source.fire()
        assert False
    except:
        pass

# Generated at 2022-06-23 13:42:09.085305
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler1(arg1):
        print(arg1)

    def handler2(arg1):
        print(arg1)

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source.fire('foo')
    assert len(event_source._handlers) == 2
    event_source -= handler1
    event_source.fire('bar')
    assert len(event_source._handlers) == 1


# Generated at 2022-06-23 13:42:14.044036
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

# Generated at 2022-06-23 13:42:15.249824
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    pass


# Generated at 2022-06-23 13:42:16.809673
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(_AnsibleCollectionConfig, type)


# Generated at 2022-06-23 13:42:20.264147
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig()
        raise AssertionError('Able to instantiate concrete class AnsibleCollectionConfig')
    except TypeError:
        pass


# replace this class with a metaclass fake in the unit tests

# Generated at 2022-06-23 13:42:24.439264
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import ansible_test.lib.ansible_util._target.legacy_collection_loader

    ansible_test.lib.ansible_util._target.legacy_collection_loader.AnsibleCollectionConfig()



# Generated at 2022-06-23 13:42:27.133952
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert e._handlers == set()


# Generated at 2022-06-23 13:42:34.559277
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _EventSourceTest:
        def __init__(self):
            self._handlers = set()

        def __iadd__(self, handler):
            if not callable(handler):
                raise ValueError('handler must be callable')
            self._handlers.add(handler)
            return self

        def __isub__(self, handler):
            try:
                self._handlers.remove(handler)
            except KeyError:
                pass

            return self

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True


# Generated at 2022-06-23 13:42:44.325957
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_bytes

    es = _EventSource()
    try:
        es += to_bytes
        raise Exception('ValueError was not raised')
    except ValueError:
        pass

    try:
        es += to_text
        raise Exception('ValueError was not raised')
    except ValueError:
        pass

    try:
        es += to_bytes(__import__('ansible.errors'))
        raise Exception('ValueError was not raised')
    except ValueError:
        pass

    def f(a, b):
        assert a == 1 and b == 2
        return 0
    assert f

# Generated at 2022-06-23 13:42:56.023389
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class EventSourceTest(_EventSource):
        def __init__(self):
            self.i_called = False
            # super().__init__() should not be required as this test class does not inherit from any other class
            super(_EventSource, self).__init__()

        def i(self, *args, **kwargs):
            self.i_called = True

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.on_exception_called = True
            return True

    e = EventSourceTest()
    e += e.i
    e -= e.i
    assert e._handlers == set()

    try:
        e -= e.i
    except KeyError:
        pass
    else:
        assert False, 'Expected KeyError'

# Generated at 2022-06-23 13:42:58.705455
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:43:07.153171
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest

    events = _EventSource()

    def _raise(exc):
        def _inner():
            raise exc
        return _inner

    def seh(handler):
        try:
            events += handler
            return True
        except ValueError:
            return False

    # N.B. None is a callable
    assert seh(None)

    # N.B. None is a callable
    assert seh(None)

    no_raise = seh(lambda: None)
    assert no_raise

    with pytest.raises(ValueError):
        assert seh(1)

# Generated at 2022-06-23 13:43:11.133809
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig
    assert AnsibleCollectionConfig.collection_paths
    assert AnsibleCollectionConfig.on_collection_load
    assert AnsibleCollectionConfig.playbook_paths
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')

# Generated at 2022-06-23 13:43:15.245866
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load

# Generated at 2022-06-23 13:43:18.169990
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)