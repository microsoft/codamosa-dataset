

# Generated at 2022-06-23 13:33:17.995258
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # assert the default values
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)


__all__ = ('AnsibleCollectionConfig',)

# Generated at 2022-06-23 13:33:18.807776
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()

# Generated at 2022-06-23 13:33:26.824276
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection == 'ansible_collections.ansible.builtin'
    assert AnsibleCollectionConfig._on_collection_load == _EventSource()

    try:
        AnsibleCollectionConfig._collection_finder = None
        assert False, 'Expected an exception to be raised'
    except:
        pass

    try:
        AnsibleCollectionConfig.collection_finder = None
        assert False, 'Expected an exception to be raised'
    except:
        pass

    try:
        AnsibleCollectionConfig.collection_paths
        assert False, 'Expected an exception to be raised'
    except:
        pass


# Generated at 2022-06-23 13:33:31.636443
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()
    assert a.collection_finder is None
    assert a.collection_paths is None
    assert a.default_collection is None
    assert a.on_collection_load is a._on_collection_load
    assert a.playbook_paths is None

# Generated at 2022-06-23 13:33:42.407332
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _MockHandler:
        def __init__(self, name, raise_exception):
            self._name = name
            self._raise_exception = raise_exception
            self._times_called = 0

        def __call__(self, *args, **kwargs):
            self._times_called += 1

            if self._raise_exception:
                raise Exception('{} handler called'.format(self._name))

    class _MockConfig(AnsibleCollectionConfig):
        def __init__(self):
            self._on_collection_load = _EventSource()

    COUNT = 5
    HANDLER_NAMES = ['h{:d}'.format(i) for i in range(COUNT)]

    config = _MockConfig()


# Generated at 2022-06-23 13:33:52.364522
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def test_handler():
        assert True

    # test_handler must be callable
    es = _EventSource()
    es += test_handler
    assert len(es._handlers) == 1
    assert test_handler in es._handlers
    es += test_handler
    assert len(es._handlers) == 1
    assert es._handlers == {test_handler}

    # test_handler2 is not callable
    test_handler2 = 'not a callable value'
    try:
        es += test_handler2
    except ValueError:
        pass
    else:
        assert False, 'expected ValueError'
    assert len(es._handlers) == 1
    assert es._handlers == {test_handler}


# Generated at 2022-06-23 13:33:56.775225
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # create an instance of _EventSource
    instance = _EventSource()

    def handler():
        pass

    # add handler to instance
    instance += handler

    # assert that instance handlers contains handler
    assert handler in instance._handlers


# Generated at 2022-06-23 13:34:02.868875
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert not hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert not hasattr(AnsibleCollectionConfig, 'default_collection')
    assert not hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert not hasattr(AnsibleCollectionConfig, 'playbook_paths')

# Generated at 2022-06-23 13:34:06.745967
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    n = event_source.__len__()

    def handler(value):
        return value

    event_source += handler
    m = event_source.__len__()

    assert m > n, 'expected handlers to be added to event source'



# Generated at 2022-06-23 13:34:08.061682
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Given
    es = _EventSource()
    handler = object()
    es += handler
    assert len(es._handlers) == 1

    # When
    es -= handler

    # Then
    assert len(es._handlers) == 0



# Generated at 2022-06-23 13:34:16.294440
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    src = _EventSource()

    assert src._handlers == set()

    # failure to add a non-callable
    try:
        src += 123
        assert False, 'should have raised a ValueError'
    except ValueError:
        pass

    # add a callable, add a duplicate
    src += lambda: None
    src += lambda: None

    assert src._handlers == {lambda: None}

    # remove a non-existent handler
    src -= lambda: None
    assert src._handlers == set()

    # operate on a deleted handler
    h = lambda: None
    src += h
    del h
    src -= lambda: None
    assert src._handlers == set()

    # add a bad handler (a bound method), handle it

# Generated at 2022-06-23 13:34:21.399894
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    #
    # Verify correct handling of 'None' value handler
    #
    event_source.__isub__(None)

    #
    # Verify correct handling of non-existent handler
    #
    event_source.__isub__("no_such_handler")

    #
    # Verify correct handling of existing handler
    #
    value = "my_handler"
    event_source.__iadd__(value)
    event_source.__isub__(value)
    assert event_source._handlers == set()

# Generated at 2022-06-23 13:34:33.328037
# Unit test for constructor of class _EventSource
def test__EventSource():
    def test_handler():
        pass

    event_source = _EventSource()

    # Test that handler has not been added yet
    assert event_source._handlers == set()

    # Test that we can add a handler
    event_source += test_handler
    assert test_handler in event_source._handlers

    # Test that we can remove a handler
    event_source -= test_handler
    assert test_handler not in event_source._handlers

    # Test that removing a handler that has not been added fails gracefully
    event_source -= test_handler
    assert test_handler not in event_source._handlers

    # Test that an exception is raised when handler is not callable
    bad_handler = 'not a callable'
    try:
        event_source += bad_handler
    except ValueError:
        pass

# Generated at 2022-06-23 13:34:43.381385
# Unit test for constructor of class _EventSource
def test__EventSource():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.call_count = 0

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.call_count += 1
            return False

    test_event_source = TestEventSource()

    handler1 = lambda a: a + 1
    handler2 = lambda a: a - 1
    handler3 = lambda a: a * 2
    handler4 = lambda a: a / 2

    test_event_source += handler1
    test_event_source += handler2
    test_event_source += handler3
    test_event_source += handler4

    test_event_source.fire(2)
    assert test_event_source.call_count == 0



# Generated at 2022-06-23 13:34:51.879754
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils._text import to_bytes
    from ansible.utils.collection_loader import AnsibleCollectionNotFound
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder
    import pytest

    collection_finder = AnsibleCollectionFinder()
    config = AnsibleCollectionConfig()
    config.collection_finder = collection_finder

    # event handler that throws an exception
    def _event_handler_exception(collection):
        raise AnsibleCollectionNotFound(collection)

    def _event_handler_normal(collection):
        pass

    # event handler that is not callable
    _event_handler_not_callable = collection_finder

    config.on_collection_load += _event_handler_normal
    config.on_collection_load += _event_handler_exception

# Generated at 2022-06-23 13:35:00.783664
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def assert_is_subtracted(collection, expected_length):
        assert len(collection) == expected_length

    anything = object()

    # Check that a handler is not removed if it was not added
    event_source = _EventSource()
    event_source.__isub__(anything)
    assert len(event_source._handlers) == 0

    # Check that a handler is added and then removed
    event_source = _EventSource()
    event_source.__iadd__(assert_is_subtracted)  # add an event handler
    assert len(event_source._handlers) == 1
    event_source.__isub__(assert_is_subtracted)  # remove an event handler
    assert len(event_source._handlers) == 0

# Generated at 2022-06-23 13:35:06.441010
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert not event_source._handlers
    event_source += lambda *args, **kwargs: None
    assert event_source._handlers

    try:
        event_source += None
        assert False
    except ValueError:
        pass


# Generated at 2022-06-23 13:35:08.713802
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    test_handlers = set([(lambda: None), (lambda: None), (lambda: None)])

    es = _EventSource()
    for h in test_handlers:
        es += h

    for h in test_handlers:
        es -= h

    assert not es._handlers



# Generated at 2022-06-23 13:35:14.594800
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    def on_1(a):
        pass
    def on_2(a, b):
        pass
    es += on_1
    es += on_2
    assert (on_1 in es._handlers)
    assert (on_2 in es._handlers)

    es -= on_1
    assert (on_1 not in es._handlers)
    assert (on_2 in es._handlers)

    es -= on_2
    assert (on_1 not in es._handlers)
    assert (on_2 not in es._handlers)

test__EventSource___isub__()

# Generated at 2022-06-23 13:35:19.329392
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(a):
        print('got: %s' % a)

    def handler2(b):
        print('got: %s' % b)

    event_source += handler1
    event_source += handler2

    event_source.fire('foo')

    event_source -= handler1
    event_source -= handler2

    event_source.fire('bar')


# Generated at 2022-06-23 13:35:30.610711
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    called_exception = None

    def test_func(*args, **kwargs):
        assert args == ('a', 'b', 'c')
        assert sorted(kwargs.keys()) == ['d', 'e']
        assert kwargs['d'] == 'd'
        assert kwargs['e'] == 'e'
        raise ValueError('error')

    def test_func2(*args, **kwargs):
        assert args == ('a', 'b', 'c')
        assert sorted(kwargs.keys()) == ['d', 'e']
        assert kwargs['d'] == 'd'
        assert kwargs['e'] == 'e'
        1 / 0

    def on_exception(handler, exc, *args, **kwargs):
        nonlocal called_exception
        called_exception

# Generated at 2022-06-23 13:35:42.386533
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestHandler(object):
        def __init__(self):
            self.call_args = None
            self.call_kwargs = None

        def __call__(self, *args, **kwargs):
            self.call_args = args
            self.call_kwargs = kwargs

    handler = TestHandler()
    event = _EventSource()
    event += handler

    event.fire('foo')

    assert handler.call_args == ('foo',)
    assert handler.call_kwargs == {}

    handler.call_args = None
    handler.call_kwargs = None
    event.fire(bar='baz')
    assert handler.call_args == ()
    assert handler.call_kwargs == dict(bar='baz')



# Generated at 2022-06-23 13:35:46.323570
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Test constructor, positive case
    ev = _EventSource()
    assert ev
    # Test constructor, negative cases
    try:
        ev = _EventSource()
        ev.__init__()
        assert False
    except:
        assert True


# Generated at 2022-06-23 13:35:52.218863
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler():
        raise ValueError('handler executed when it should not have been')

    subject = _EventSource()
    subject += handler

    # when
    subject -= handler

    # then
    subject.fire()

if __name__ == '__main__':
    import sys
    from ansible_test._utils.lib import modules
    from ansible_test._utils.shippable.options import ShippableEnvConfig
    from ansible_test._utils.shippable.environment import ShippableEnvironmentSpec
    from ansible_test._utils.shippable.runner import ShippableTestRunner

    env_config = ShippableEnvConfig()
    env_spec = ShippableEnvironmentSpec(env_config, None)
    runner = ShippableTestRunner(env_spec)

    # The collection loader test suite makes use

# Generated at 2022-06-23 13:35:59.222535
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    try:
        event = _EventSource()

        def event_handler1(*args, **kwargs):
            raise ValueError('Unit test exception 1')

        def event_handler2(*args, **kwargs):
            raise ValueError('Unit test exception 2')

        event += event_handler1
        event += event_handler2

        # The second event handler does not raise an exception, so we are expecting the
        # caller to receive a ValueError exception with the message 'Unit test exception 1'
        event.fire()

    except ValueError as e:
        assert 'Unit test exception 1' in str(e)
        return True

    return False



# Generated at 2022-06-23 13:36:10.975032
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import sys
    import pytest

    # this module is not part of the collection
    from ansible_collections.ansible.testing.util.target import legacy_collection_loader as collection_loader

    def f():
        pass

    def g():
        pass

    class MyEvent(collection_loader._EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            raise

    event = MyEvent()
    event += f

    assert len(event._handlers) == 1

    event -= f
    assert len(event._handlers) == 0

    if sys.version_info >= (3,):
        with pytest.raises(TypeError):
            event -= g

# Generated at 2022-06-23 13:36:17.508900
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()
    assert event._on_exception == _EventSource._on_exception
    assert event.fire == _EventSource.fire
    assert event.__iadd__ == _EventSource.__iadd__
    assert event.__isub__ == _EventSource.__isub__



# Generated at 2022-06-23 13:36:23.306769
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class Foo:
        def __init__(self):
            self.a = True

        def b(self):
            self.a = False

        def c(self):
            self.a = True

    foo = Foo()
    eventSource = _EventSource()
    eventSource += foo.b
    eventSource += foo.c

    eventSource -= foo.b
    eventSource.fire()

    if not foo.a:
        raise AssertionError('eventSource did not remove foo.b from handler list')

# Generated at 2022-06-23 13:36:31.195699
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _TestEventSource(_EventSource):

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True

        def fire(self, *args, **kwargs):
            for h in self._handlers:
                try:
                    h(*args, **kwargs)
                except Exception as ex:
                    if self._on_exception(h, ex, *args, **kwargs):
                        raise

    def test1():
        raise NotImplementedError("No handler to remove")

    def test2():
        pass

    es = _TestEventSource()
    es += test1

    test2()

    es -= test2

    es -= test2

# Generated at 2022-06-23 13:36:35.075066
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert isinstance(cls._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:36:42.092036
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible_collections.community.general.tests.unit.test_loader import _Collection
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef, AnsibleCollectionFinder

    class ansible_collections_test(AnsibleCollectionRef):
        pass

    # the collection_loader must have been loaded, even if it is a null loader
    assert len(AnsibleCollectionConfig.collection_paths) > 0

    # configure the dataloader to use the unit test collection
    # this must be done prior to the AnsibleCollectionFinder since that uses the dataloader to load collections

    loader = DataLoader()
    loader.search_paths = ['ansible_collections/community/general/plugins/modules']


# Generated at 2022-06-23 13:36:44.124504
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _TClass:
        pass

    _AnsibleCollectionConfig('_TClass', (_TClass,), {})

# Generated at 2022-06-23 13:36:48.256833
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    x = _EventSource()

    def test_handler1(x):
        return x

    x += test_handler1

    assert x._handlers == {test_handler1}

    x -= test_handler1

    assert x._handlers == set()


# Generated at 2022-06-23 13:36:49.495246
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    assert _EventSource().fire() is None  # noqa

# Generated at 2022-06-23 13:36:54.020657
# Unit test for constructor of class _EventSource
def test__EventSource():
    handler = lambda: None
    eventSource = _EventSource()
    eventSource += handler
    assert handler in eventSource._handlers
    eventSource -= handler
    assert handler not in eventSource._handlers

# Unit tests for AnsibleCollectionConfig class

# Generated at 2022-06-23 13:36:58.162321
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Setup arguments
    handler = mocker.MagicMock()

    # Setup mocks
    mocker.patch.object(handler, '__call__')

    # Exercise
    event_source = _EventSource()
    event_source += handler

    # Verify
    assert handler in event_source._handlers


# Generated at 2022-06-23 13:37:04.325136
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # Arrange
    class Meta:
        pass
    meta = Meta
    name = 'name'
    bases = 'bases'

    # Act
    ansible_collection_config = _AnsibleCollectionConfig(meta, name, bases)

    # Assert
    assert ansible_collection_config._collection_finder is None

# Generated at 2022-06-23 13:37:10.312968
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    ev = _EventSource()

    def f():
        pass

    def g():
        pass

    def h():
        pass

    def i():
        pass

    def j():
        pass

    ev += f
    ev += g
    ev += h
    ev += i
    ev += j

    ev -= h
    ev -= g
    ev -= i

    assert ev._handlers == set([f, j])

# Generated at 2022-06-23 13:37:12.646345
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()

    assert e._handlers == set()
    assert e.fire() is None
    e += lambda *args, **kwargs: False


# Generated at 2022-06-23 13:37:18.151341
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    handler = lambda *args, **kwargs: None
    es += handler
    assert len(es._handlers) == 1
    es -= handler
    assert len(es._handlers) == 0
    es -= handler
    assert len(es._handlers) == 0


# Generated at 2022-06-23 13:37:26.690817
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class C(object):
        def raise_exception_in_handler(self, e):
            raise e

        def return_true_in_on_exception(self, handler, exc, *args, **kwargs):
            return True

        def return_false_in_on_exception(self, handler, exc, *args, **kwargs):
            return False

    c = C()

    try:
        _EventSource().fire()
        assert False, 'Expected Exception'
    except ValueError:
        pass


# Generated at 2022-06-23 13:37:30.546533
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert '_collection_finder' not in AnsibleCollectionConfig.__dict__
    assert '_default_collection' not in AnsibleCollectionConfig.__dict__
    assert '_on_collection_load' in AnsibleCollectionConfig.__dict__

# Generated at 2022-06-23 13:37:41.668662
# Unit test for constructor of class _EventSource
def test__EventSource():
    class _TestEventSource(object):
        def __init__(self):
            self._handlers = set()

        def __iadd__(self, handler):
            if not callable(handler):
                raise ValueError('handler must be callable')
            self._handlers.add(handler)
            return self

        def __isub__(self, handler):
            try:
                self._handlers.remove(handler)
            except KeyError:
                pass

            return self

        def _on_exception(self, handler, exc, *args, **kwargs):
            # if we return True, we want the caller to re-raise
            return True


# Generated at 2022-06-23 13:37:50.289382
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class _AnsibleCollectionConfigSubclass(AnsibleCollectionConfig):
        pass

    class _AnsibleCollectionConfigSubclassSubclass(_AnsibleCollectionConfigSubclass):
        pass

    # Ensure that each descendant from the metaclass has a new copy of the class variables
    # that are used to implement the class properties defined by this metaclass.
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load is not None
    assert _AnsibleCollectionConfigSubclass._collection_finder is None
    assert _AnsibleCollectionConfigSubclass._default_collection is None
    assert _AnsibleCollectionConfigSubclass._on_collection_load is not None
    assert _AnsibleCollectionConfigSubclassSubclass._collection_finder is None


# Generated at 2022-06-23 13:37:58.964211
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._on_collection_load is not None

    # noinspection PyProtectedMember
    with AnsibleCollectionConfig.collection_finder:
        assert AnsibleCollectionConfig.collection_finder is not None
        assert AnsibleCollectionConfig._collection_finder is not None
        assert AnsibleCollectionConfig._collection_finder is not AnsibleCollectionConfig.collection_finder
        assert AnsibleCollectionConfig.collection_finder._n_collection_paths is not None
        assert AnsibleCollectionConfig.collection_finder._n_playbook_paths is not None


if __name__ == '__main__':
    # noinspection PyUnresolvedReferences
    import test.units.module_utils.collections._util.target.legacy_collection_loader.AnsibleCollectionFinder as acf

    test_AnsibleCollectionConfig()

# Generated at 2022-06-23 13:38:09.232240
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import unittest
    class TestHandlers(unittest.TestCase):
        def test_expected_event_params(self):
            """The 'fire' method fires events with the correct number of parameters."""
            try:
                es = _EventSource()
                es += self.do_fail
                es += self.do_pass

                es.fire('foo', 'bar', 'baz')
            except:
                self.fail('call to event source failed')

        def do_fail(self, *args):
            self.assertEqual(len(args), 3)

        def do_pass(self, *args):
            pass

    suite = unittest.TestLoader().loadTestsFromTestCase(TestHandlers)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 13:38:12.016732
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()
    assert es._on_exception(print, Exception)


# Generated at 2022-06-23 13:38:15.343839
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert callable(e.fire)


_config = AnsibleCollectionConfig()


# Generated at 2022-06-23 13:38:21.174122
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler_1():
        pass
    event_source += handler_1
    assert len(event_source._handlers) == 1

    def handler_2():
        pass
    event_source += handler_2
    assert len(event_source._handlers) == 2


# Generated at 2022-06-23 13:38:26.541016
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler():
        return 42

    e = _EventSource()
    assert len(e._handlers) == 0

    e += handler
    assert len(e._handlers) == 1

    e -= handler
    assert len(e._handlers) == 0


# Generated at 2022-06-23 13:38:29.289490
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig
    assert config._on_collection_load
    assert config._collection_finder is None
    assert config._default_collection is None


# Generated at 2022-06-23 13:38:31.603545
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    event += lambda x: x
    event -= lambda x: x

# Generated at 2022-06-23 13:38:35.322739
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    result = []
    event += lambda x: (result.append("ok1"), None)[1]
    event.fire("x")

    # assertion
    assert result == ["ok1"]


# Generated at 2022-06-23 13:38:40.248233
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert isinstance(c, AnsibleCollectionConfig)
    assert isinstance(c._on_collection_load, _EventSource)
    assert c._on_collection_load is AnsibleCollectionConfig.on_collection_load



# Generated at 2022-06-23 13:38:42.648272
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load'), 'AnsibleCollectionConfig has on_collection_load attribute'

# Generated at 2022-06-23 13:38:44.422289
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()


# Generated at 2022-06-23 13:38:45.049593
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:38:46.548021
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert not event._handlers


# Generated at 2022-06-23 13:38:54.258492
# Unit test for constructor of class _EventSource
def test__EventSource():
    # First test _on_exception
    def f(handler, exc, *args, **kwargs):
        return True

    es = _EventSource()
    es._on_exception = f
    assert es._on_exception == f

    # Second test __iadd__, __isub__ and fire
    def f1(msg):
        print(msg)

    def f2(msg):
        print(msg+msg)

    es = _EventSource()

    es += f1
    assert f1 in es._handlers

    es += f2
    assert f2 in es._handlers

    es -= f1
    assert not f1 in es._handlers

    es -= f1
    assert not f1 in es._handlers

    es = _EventSource()
    es += f1
    assert f1 in es

# Generated at 2022-06-23 13:38:59.171559
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_subject = _EventSource()

    # test adding a callable handler
    test_subject += lambda: None
    if not test_subject._handlers:
        raise AssertionError('callable handler not added')

    # test adding a non-callable handler
    try:
        test_subject += 10
        raise AssertionError('non-callable handler added')
    except ValueError:
        pass

    # return the instance to make happy the pytest gods
    return test_subject


# Generated at 2022-06-23 13:39:05.746801
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert not AnsibleCollectionConfig.collection_finder
    assert not AnsibleCollectionConfig.default_collection
    assert not AnsibleCollectionConfig.collection_paths
    assert not AnsibleCollectionConfig.playbook_paths

# Generated at 2022-06-23 13:39:10.238853
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # The class has no __init__ method,
    # so we just test that we can create an instance
    AnsibleCollectionConfig()

# Unit tests for properties of class AnsibleCollectionConfig

# Generated at 2022-06-23 13:39:15.852057
# Unit test for constructor of class _EventSource
def test__EventSource():
    def h(a):
        pass

    event_source = _EventSource()
    event_source += h  # validation occurs on assignment
    event_source -= h

    event_source += h
    assert event_source._handlers == {h}
    event_source -= h
    assert event_source._handlers == set()


# Generated at 2022-06-23 13:39:18.541497
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(args):
        assert args[0] == 1
        assert args[1] == 2
        assert args[2] == 3

    e = _EventSource()
    e.fire(1, 2, 3)

    e += handler
    e.fire(1, 2, 3)

    e -= handler
    e.fire(1, 2, 3)

# Generated at 2022-06-23 13:39:30.428456
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.raised_exception = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            if isinstance(exc, RuntimeError):
                self.raised_exception = True
            return False

    def handler_a(*args, **kwargs):
        pass

    def handler_b(*args, **kwargs):
        raise RuntimeError('')

    def handler_c(a, *args, **kwargs):
        raise RuntimeError('')
        return a

    t = TestEventSource()
    # Ensure that method fire does not raise when there are no listeners
    t.fire()

    # Add handlers
    t += handler_a

# Generated at 2022-06-23 13:39:31.616294
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()  # noqa F841



# Generated at 2022-06-23 13:39:42.304474
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource:
        def __init__(self):
            self._handlers = set()

        def __iadd__(self, handler):
            self._handlers.add(handler)
            return self

        def __isub__(self, handler):
            self._handlers.remove(handler)
            return self

        def fire(self, *args, **kwargs):
            for handler in self._handlers:
                handler(*args, **kwargs)

    e = MyEventSource()
    x = []
    e += lambda *args, **kwargs: x.append(args[0])
    e += lambda *args, **kwargs: x.append(args[0])
    e += lambda *args, **kwargs: x.append(args[0])

    e.fire('foo')

# Generated at 2022-06-23 13:39:47.082818
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # setup
    es = _EventSource()

    def handler():
        pass

    # execute
    es += handler
    es -= handler

    # verify
    assert len(es._handlers) == 0

# Generated at 2022-06-23 13:39:58.883470
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MockHandler:
        def __init__(self, exception=None):
            self.exception = exception

        def __call__(self, *args, **kwargs):
            if self.exception:
                raise self.exception

    mh1 = MockHandler()
    mh2 = MockHandler()
    event_source = _EventSource()
    event_source += mh1
    event_source += mh2
    event_source.fire(1, 2, 3)
    assert mh1.args == (1, 2, 3)
    assert mh1.kwargs == {}
    assert mh2.args == (1, 2, 3)
    assert mh2.kwargs == {}
    mh1.args = None
    mh1.kwargs = None
    mh2.args = None

# Generated at 2022-06-23 13:40:04.528310
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Initialize the class to be tested
    cls = _EventSource()

    # Define a function that will be used as a handler
    def handler_one(num):
        return num * num

    def handler_two(num):
        return num + 1

    # Register the function with the handler
    cls += handler_one
    cls += handler_two
    # Call the fire method
    cls.fire(num=5)


    # Test that the return values are correct
    assert (handler_one(num=5)) == 25
    assert (handler_two(num=5)) == 6


test__EventSource_fire()

# Generated at 2022-06-23 13:40:12.904502
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert AnsibleCollectionConfig._on_collection_load
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is AnsibleCollectionConfig._on_collection_load
    assert AnsibleCollectionConfig.playbook_paths == []



# Generated at 2022-06-23 13:40:19.204604
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    evt = _EventSource()
    result = []

    def handler1(arg):
        result.append({'handler': 1, 'arg': arg})

    def handler2(arg):
        result.append({'handler': 2, 'arg': arg})

    evt += handler1
    evt += handler2

    evt.fire('a')
    evt.fire('b')
    evt.fire('c')


# Generated at 2022-06-23 13:40:30.657674
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    # Test: passing in something that isn't callable
    try:
        event_source -= 1
    except ValueError:
        # test passed
        pass
    else:
        assert False, '__isub__ with a non-callable value should raise an exception'

    # Test: passing in a callable that hasn't been added
    try:
        event_source -= lambda: None
        # test passed
    except ValueError:
        assert False, '__isub__ with a callable that hasn\'t been registered should not raise an exception'

    # Test: passing in a callable that has been added
    def fn():
        pass

    event_source += fn

# Generated at 2022-06-23 13:40:39.785130
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class TestListener:
        def handler(self, *args, **kwargs):
            pass

    def handler(*args, **kwargs):
        pass

    obj = _EventSource()
    listener = TestListener()
    assert len(obj._handlers) == 0

    # exercise the code path for adding a listener
    obj += listener.handler

    assert len(obj._handlers) == 1

    # exercise the code path for removing a listener
    obj -= listener.handler

    assert len(obj._handlers) == 0

    # exercise the code path for removing a listener that is not present
    obj -= listener.handler

    assert len(obj._handlers) == 0

    # exercise the code path for adding a listener
    obj += handler

    assert len(obj._handlers) == 1

    # clean up
    del handler
    del listener


# Generated at 2022-06-23 13:40:46.928361
# Unit test for constructor of class _EventSource
def test__EventSource():
    # a class that does nothing
    class foo:
        pass

    try:
        evt = _EventSource()
        handler = foo()
        evt += handler  # add our no-op function to the event source
        evt += handler  # should accept being added more than once without raising an exception
        evt += foo()    # add a second no-op function to the event source
        evt -= handler  # remove it again
        evt -= foo()    # should accept being removed without raising an exception if it has never been added
        evt -= foo()    # should accept being removed without raising an exception if it has never been added
        evt.fire(8)     # should accept being called without any handlers
    except ValueError:
        raise ValueError('test__EventSource failed: one or more exceptions raised in _EventSource constructor code')

test

# Generated at 2022-06-23 13:40:49.476707
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    acc = _AnsibleCollectionConfig('meta', 'name', 'bases')


# Generated at 2022-06-23 13:40:58.267386
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    s = _EventSource()
    assert len(s._handlers) == 0

    def f1():
        pass

    def f2():
        pass

    def f3():
        pass

    s += f1
    s += f2
    s += f3

    assert len(s._handlers) == 3

    s -= f2

    assert len(s._handlers) == 2
    assert f1 in s._handlers
    assert f2 not in s._handlers
    assert f3 in s._handlers

    s -= f2

    assert len(s._handlers) == 2
    assert f1 in s._handlers
    assert f2 not in s._handlers
    assert f3 in s._handlers


# Generated at 2022-06-23 13:41:08.328154
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class A(AnsibleCollectionConfig):
        pass

    class B(A):
        pass

    a = A()
    b = B()

    assert a._collection_finder is None
    assert a._default_collection is None
    assert b._collection_finder is None
    assert b._default_collection is None

    assert a.collection_finder is None
    assert a.default_collection is None
    assert b.collection_finder is None
    assert b.default_collection is None

    assert a.playbook_paths == []
    assert b.playbook_paths == []

    assert a.collection_paths == []
    assert b.collection_paths == []

    assert a._on_collection_load is not None
    assert b._on_collection_load is not None

# Generated at 2022-06-23 13:41:10.987730
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def handler():
        pass

    es += handler
    assert handler in es._handlers



# Generated at 2022-06-23 13:41:11.520179
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass

# Generated at 2022-06-23 13:41:15.897212
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def handler1():
        pass

    es += handler1
    es += handler1
    es += handler1
    es -= handler1

    assert handler1 in es._handlers

    es -= handler1
    es -= handler1

    assert handler1 not in es._handlers


del test__EventSource___isub__



# Generated at 2022-06-23 13:41:24.979593
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import os
    import sys
    import tempfile

    # Make a copy of sys.path that does not include the current directory (.)
    # so that we don't find an installed AnsibleCollectionConfig if one is present
    test_sys_path = []
    for path in sys.path:
        if path:
            test_sys_path.append(path)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a subdirectory of the temporary directory to use as the 'library'
    # directory for the collection that this test will create.
    library_dir = tempfile.mkdtemp(dir=tmpdir)

    # Create a subdirectory of the temporary directory to use as the 'module_utils'
    # directory for the collection that this test will create.
    module_utils_dir = tempfile.mkd

# Generated at 2022-06-23 13:41:30.991499
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)
    assert AnsibleCollectionConfig.collection_paths is None
    assert AnsibleCollectionConfig.playbook_paths is None

# Generated at 2022-06-23 13:41:39.436668
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible_collections.ansible.community.plugins.module_utils.collection_loader._collection_finder import AnsibleCollectionFinder
    from ansible_collections.ansible.community.plugins.module_utils.collection_loader._collection_finder import AnsibleCollectionFinderLocator

    finder1 = AnsibleCollectionFinderLocator().get_finder('/usr/local:/etc/ansible')
    finder2 = AnsibleCollectionFinderLocator().get_finder('/usr/local')

    config = AnsibleCollectionConfig()

    assert not config._collection_finder
    assert not config._default_collection

    config.collection_finder = finder1

    assert config._collection_finder == finder1
    assert not config._default_collection

    config.collection_finder = finder2
    assert config._collection_finder == finder

# Generated at 2022-06-23 13:41:41.776471
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)


# Generated at 2022-06-23 13:41:43.380255
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None

# Generated at 2022-06-23 13:41:51.154811
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)
    assert isinstance(_AnsibleCollectionConfig('foo', (object,), {}), type)
    assert isinstance(_AnsibleCollectionConfig('foo', (object,), {})(), object)
    assert isinstance(_AnsibleCollectionConfig('foo', (object,), {})(), AnsibleCollectionConfig)
    assert AnsibleCollectionConfig == _AnsibleCollectionConfig('foo', (object,), {})



# Generated at 2022-06-23 13:41:52.620644
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource()
    assert _EventSource() is not None


# Generated at 2022-06-23 13:41:54.418165
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert isinstance(e, _EventSource)


# Generated at 2022-06-23 13:41:59.893896
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestClass:
        pass

    assert TestClass._collection_finder is None
    assert TestClass._default_collection is None
    assert TestClass._on_collection_load is not None
    assert isinstance(TestClass._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:42:11.312039
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible.collections.ansible_collections.collection1.collection2.plugins.module_utils import (
        ansible_collection_config
    )

    # Initialize
    ansible_collection_config._AnsibleCollectionConfig.__init__(ansible_collection_config.AnsibleCollectionConfig, 'META', 'NAME', 'BASES')

    # Check collection_finder
    assert ansible_collection_config.AnsibleCollectionConfig.collection_finder is None

    # Check default_collection
    assert ansible_collection_config.AnsibleCollectionConfig.default_collection is None

    # Check on_collection_load
    assert '_on_collection_load' in ansible_collection_config.AnsibleCollectionConfig.__dict__



# Generated at 2022-06-23 13:42:15.302430
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Given
    event_source = _EventSource()

    # Then
    try:
        event_source -= object()
    except:
        assert False, 'Should not raise exception when handler is not in handler set'



# Generated at 2022-06-23 13:42:18.580089
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    target = _EventSource()
    handler = lambda *args: None
    target += handler
    assert target._handlers == set([handler]), 'target._handlers is %s' % target._handlers


# Generated at 2022-06-23 13:42:21.921333
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:42:25.312965
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def my_handler():
        pass

    # Add handler
    event += my_handler

    # Remove handler
    event -= my_handler

    # Remove handler again
    event -= my_handler

# Generated at 2022-06-23 13:42:27.328992
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'class_name', (object,))

# Generated at 2022-06-23 13:42:30.608977
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert not e._handlers

    # valid handler
    e += lambda: None
    assert e._handlers

    # invalid handler
    try:
        e += 1
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-23 13:42:32.226376
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert not es._handlers


# Generated at 2022-06-23 13:42:40.078111
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    def test_it(cls):
        assert isinstance(cls.collection_finder, property)
        assert hasattr(cls, 'on_collection_load')
        assert isinstance(cls.on_collection_load, _EventSource)
        assert isinstance(cls.playbook_paths, property)

    test_it(_AnsibleCollectionConfig)
    cls = type('TestClass', (_AnsibleCollectionConfig,), {})
    test_it(cls)


# Generated at 2022-06-23 13:42:41.883595
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    handler = lambda: None

    es += handler
    es -= handler
    assert handler not in es._handlers



# Generated at 2022-06-23 13:42:47.127391
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, type(None))
    assert isinstance(AnsibleCollectionConfig._default_collection, type(None))
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:42:58.008116
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.utils.collection_loader._event_source import _EventSource
    from ansible_collections.ansible.builtin.plugins.module_utils.local_pkg_resources import find_provider

    event_source = _EventSource()

    # add a function
    def f1():
        pass

    event_source += f1
    assert f1 in event_source._handlers

    # add a class method
    class T1:
        def f2(self):
            pass
    event_source += T1.f2
    assert T1.f2 in event_source._handlers

    # add a class
    class T2:
        def f3(self):
            pass
    event_source += T2
    assert T2().f3 in event_source._handlers

    # add a non-callable

# Generated at 2022-06-23 13:43:02.102582
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    def f(*args, **kwargs):
        print(args)
        print(kwargs)
    e += f
    e.fire(1, 2, 3, 4, u = 6, v = 7)

# Generated at 2022-06-23 13:43:06.893162
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible.module_utils.common.collections import AnsibleCollectionConfig

    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

    assert callable(AnsibleCollectionConfig.on_collection_load.fire)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:43:14.668239
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class MockEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kargs):
            raise ValueError('mock')

    event_source = MockEventSource()
    event_source.fire()

    class MockHandler:
        def __call__(self, *args, **kargs):
            pass

    def mock_handler(*args, **kargs):
        pass

    h1 = MockHandler()
    h2 = MockHandler()

    event_source += h1
    event_source += mock_handler

    assert len(event_source._handlers) == 2

    # remove a handler that is not in the set and make sure it does not raise an exception
    event_source -= mock_handler

    assert len(event_source._handlers) == 1

    # remove a handler that is in