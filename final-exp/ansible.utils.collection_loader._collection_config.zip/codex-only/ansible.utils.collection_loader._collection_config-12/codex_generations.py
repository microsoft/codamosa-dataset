

# Generated at 2022-06-23 13:33:16.861019
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj = _EventSource()
    obj += lambda: None


# Generated at 2022-06-23 13:33:25.960536
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # case: function is successful
    def on_exception(handler, exc, *args, **kwargs):
        assert handler == handler1
        assert exc.args == (1, 2, 3)
        assert args == (4, 5, 6)
        assert kwargs == {'x': 7, 'y': 8, 'z': 9}
        return False

    event_source = _EventSource()
    event_source._on_exception = on_exception

    handler1 = lambda *args, **kwargs: 1 / 0
    handler2 = lambda *args, **kwargs: (4, 5, 6)

    event_source += handler1
    event_source += handler2

    assert event_source.fire(x=7, y=8, z=9) == (4, 5, 6)

    # case: function raises

# Generated at 2022-06-23 13:33:33.163686
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def _handler(j):
        raise Exception('Handler called with %d' % j)

    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self._handled_exceptions = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._handled_exceptions.append(exc.args[0])  # save the exception message
            return False  # raise no exception

    es = TestEventSource()
    es += _handler

    with pytest.raises(Exception):
        es.fire(1)

    with pytest.raises(Exception):
        es.fire(2)

    with pytest.raises(Exception):
        es.fire(3)


# Generated at 2022-06-23 13:33:35.892442
# Unit test for constructor of class _EventSource
def test__EventSource():
    try:
        es = _EventSource()
        assert callable(es)
        assert not es._handlers
    except:
        assert False



# Generated at 2022-06-23 13:33:39.366969
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def test_handler(a, b):
        pass

    event_source = _EventSource()
    event_source += test_handler
    event_source -= test_handler

    assert not event_source._handlers


# Generated at 2022-06-23 13:33:40.632849
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()


# Unit tests for class AnsibleCollectionConfig

# Generated at 2022-06-23 13:33:48.820998
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    a = _EventSource()

    def handler1():
        return ['a']

    def handler2(arg):
        return 'a'

    def handler3(arg1, arg2):
        return ''

    def handler4(arg1, arg2=''):
        return ''

    def handler5(arg1, arg2, arg3=''):
        return ''

    for h in [handler1, handler2, handler3, handler4, handler5]:
        a += h



# Generated at 2022-06-23 13:33:50.532804
# Unit test for constructor of class _EventSource
def test__EventSource():
    #__init__()
    obj = _EventSource()
    assert obj._handlers == set()


# Generated at 2022-06-23 13:33:53.346904
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert not es._handlers
    assert es._on_exception
    es += 'hello'
    assert es._handlers == {'hello'}
    es -= 'hello'
    assert not es._handlers

# Generated at 2022-06-23 13:33:58.914697
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    def _test(meta, name, bases):
        cls = AnsibleCollectionConfig
        assert cls._collection_finder is None
        assert cls._default_collection is None

    cls = _AnsibleCollectionConfig
    cls.__init__(None, 'TestClass', None)
    assert type(_AnsibleCollectionConfig) is _AnsibleCollectionConfig

# Generated at 2022-06-23 13:34:00.116475
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')



# Generated at 2022-06-23 13:34:01.645689
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert not e._handlers


# Generated at 2022-06-23 13:34:08.983337
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # ensure adding something not callable is rejected
    handler = lambda: None

    es = _EventSource()
    es += handler
    assert len(es._handlers) == 1

    es += 10
    assert len(es._handlers) == 1
    es += None
    assert len(es._handlers) == 1

    # duplicate additions of the same object have no effect
    es += handler
    assert len(es._handlers) == 1

    # and when we remove it, we're back to zero
    es -= handler
    assert len(es._handlers) == 0


# Generated at 2022-06-23 13:34:13.127677
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source.__iadd__(lambda: print(True))
    assert len(event_source._handlers) == 1
    try:
        event_source.__iadd__(1)
        raise AssertionError('ValueError not raised')
    except ValueError:
        pass


# Generated at 2022-06-23 13:34:17.189520
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:34:18.500558
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None



# Generated at 2022-06-23 13:34:21.756371
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac.default_collection is None
    assert ac.collection_finder is None
    assert ac.collection_paths is None
    assert ac.playbook_paths is None

    ac.playbook_paths = []
    assert hasattr(ac, 'playbook_paths') is True

# Generated at 2022-06-23 13:34:24.166866
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


__all__ = ('AnsibleCollectionConfig',)

# Generated at 2022-06-23 13:34:25.711048
# Unit test for constructor of class _EventSource
def test__EventSource():
    with _EventSource() as es:
        assert not es._handlers



# Generated at 2022-06-23 13:34:35.757769
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import os
    thisdir = os.path.dirname(os.path.realpath(__file__))
    assert AnsibleCollectionConfig.on_collection_load == _EventSource()
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []

    # make sure default playbook_paths is set by default
    assert AnsibleCollectionConfig.playbook_paths == [os.path.join(thisdir, '../../../'), os.path.join(os.path.sep, 'usr', 'share', 'ansible', to_text('playbooks'))]



# Generated at 2022-06-23 13:34:43.593304
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()

    def my_func(x):
        pass

    ev += my_func
    ev += my_func
    assert len(ev._handlers) == 2

    ev -= my_func
    assert len(ev._handlers) == 1

    try:
        ev += 1
    except ValueError:
        pass
    else:
        assert False, '__iadd__ expected to raise ValueError if value is not callable'

    try:
        ev -= 1
    except KeyError:
        pass
    else:
        assert False, '__isub__ expected to raise KeyError if value is not callable'


# Generated at 2022-06-23 13:34:46.693265
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig()._collection_finder is None
    assert AnsibleCollectionConfig()._default_collection is None


# Define our metaclass that we use on AnsibleCollectionMetadata

# Generated at 2022-06-23 13:34:48.520731
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc = AnsibleCollectionConfig()

    assert not acc._collection_finder
    assert not acc._on_collection_load


# Generated at 2022-06-23 13:34:49.078058
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pass

# Generated at 2022-06-23 13:34:57.970689
# Unit test for constructor of class _EventSource
def test__EventSource():
    from ansible_collections.ansible.builtin.tests.unit.compat.mock import MagicMock
    x = _EventSource()
    assert x._handlers == set()

    magic_mock = MagicMock()

    x += magic_mock
    assert x._handlers == {magic_mock}

    x -= magic_mock
    x -= magic_mock
    assert x._handlers == set()

    with pytest.raises(ValueError) as e:
        x += 'not a function'

    assert to_text(e.value) == 'handler must be callable'



# Generated at 2022-06-23 13:35:00.927854
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    event_source = config._on_collection_load
    assert isinstance(event_source, _EventSource)

# Generated at 2022-06-23 13:35:10.538971
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    foo = _EventSource()

    if foo._handlers:
        raise AssertionError('_handlers should be empty but is not')

    def noop_method(self):
        pass
    def another_noop_method(self):
        pass

    foo += noop_method
    foo -= noop_method

    if foo._handlers:
        raise AssertionError('_handlers should be empty but is not')

    foo += noop_method
    foo += another_noop_method
    foo -= noop_method

    if foo._handlers != set([another_noop_method]):
        raise AssertionError('_handlers does not have the expected value')

# Generated at 2022-06-23 13:35:16.577651
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert(not es._handlers)

    def foo(a, b=None):
        pass

    es += foo
    assert(es._handlers)

    try:
        es += 1
    except ValueError:
        pass
    else:
        raise Exception('invalid value for handler should have raised ValueError')



# Generated at 2022-06-23 13:35:22.660015
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')


#
# This module is used by utils/collection_loader.py and ansible_test/_util/target/legacy_collection_loader.py
#

#
# The legacy collection loader design was based on the assumption that the unit of collection loading
# was the plugin type (action, connection, filter, etc.)
#
# The current collection loader design is based on the assumption that the unit of collection loading
# is an AnsibleCollectionFinder
#
# This class implements the legacy collection design for the current collection loader API.
#

# Generated at 2022-06-23 13:35:29.254278
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Handler:
        def __init__(self, value):
            self.value = value
            self.invocations = 0

        def __call__(self, *args, **kwargs):
            self.invocations += 1

    config = AnsibleCollectionConfig()

    handler_1 = Handler(1)
    handler_2 = Handler(2)
    handler_3 = Handler(3)

    config.on_collection_load += handler_1
    config.on_collection_load += handler_2
    config.on_collection_load += handler_3

    config.on_collection_load.fire()

    assert handler_1.invocations == 1
    assert handler_2.invocations == 1
    assert handler_3.invocations == 1

    config.on_collection_load -= handler_2
    config.on_collection_load

# Generated at 2022-06-23 13:35:32.052907
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig()
    except TypeError as e:
        assert str(e) == 'can\'t instantiate abstract class AnsibleCollectionConfig with abstract methods __init__'

# Generated at 2022-06-23 13:35:36.497566
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Arrange
    event = _EventSource()
    event_handler = object()

    # Act
    event += event_handler
    event -= event_handler

    # Assert
    assert len(event._handlers) == 0



# Generated at 2022-06-23 13:35:47.420895
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import sys
    import os

    # When the default AnsibleCollectionConfig is instantiated, it raises an
    # exception because no AnsibleCollectionFinder is installed.
    try:
        AnsibleCollectionConfig()
        assert False, "AnsibleCollectionConfig failed to raise an exception when no AnsibleCollectionFinder was installed."
    except NotImplementedError as e:
        assert str(e) == 'an AnsibleCollectionFinder has not been installed in this process', \
            "AnsibleCollectionConfig failed to raise an exception when no AnsibleCollectionFinder was installed."

    # When the default AnsibleCollectionConfig is instantiated and an AnsibleCollectionFinder
    # has been installed, the properties return values created by the AnsibleCollectionFinder,
    # and the exceptions are no longer thrown.

# Generated at 2022-06-23 13:35:54.180391
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class A:
        def __init__(self):
            self.x = 3
            self.y = 4

        def f(self, a, b, c):
            self.x = a
            self.y = b + c

    class B:
        def __init__(self):
            self.x = 5
            self.y = 6

        def f(self, a, b, c):
            self.x = a + b
            self.y = c

    a = A()
    b = B()

    ev = _EventSource()
    ev += a.f
    ev += b.f

    ev.fire(1, 2, 3)

    assert a.x == 1
    assert a.y == 5
    assert b.x == 3
    assert b.y == 3

    ev -= a.f



# Generated at 2022-06-23 13:36:04.584061
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        pass

    evt = MyEventSource()
    evt.fire('foo')

    # add handlers
    foo = []

    def handler_one(x):
        foo.append('one:' + x)

    def handler_two(x):
        foo.append('two:' + x)

    evt += handler_one
    evt += handler_two

    evt.fire('foo')

    # remove a handler
    evt -= handler_two

    evt.fire('bar')

    assert foo == ['one:foo', 'two:foo', 'one:bar']

# Generated at 2022-06-23 13:36:06.299953
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)

# Generated at 2022-06-23 13:36:09.137640
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def dummy_handler(arg):
        pass

    events = _EventSource()
    events += dummy_handler
    assert dummy_handler in events._handlers


# Generated at 2022-06-23 13:36:14.163777
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    called = False

    def handler(*args, **kwargs):
        nonlocal called
        called = True

    event = _EventSource()
    event += handler

    assert not called
    event.fire()
    assert called



# Generated at 2022-06-23 13:36:16.444089
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=unused-variable
    _AnsibleCollectionConfig(object, 'name', 'bases')

# Generated at 2022-06-23 13:36:17.542837
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-23 13:36:18.475848
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-23 13:36:26.301305
# Unit test for constructor of class _EventSource
def test__EventSource():
    success_cases = [
        (lambda: None),
        (lambda x: None),
        (lambda x, y: None),
        (lambda: 1),
        (lambda x: 1),
        (lambda x, y: 1),
    ]

    def fail(handler):
        try:
            event_source = _EventSource()
            event_source += handler
            assert False, 'Expected ValueError exception'
        except ValueError:
            pass

    def ok(handler):
        event_source = _EventSource()
        event_source += handler

        assert len(event_source._handlers) == 1

        event_source -= handler

        assert len(event_source._handlers) == 0

    for handler in success_cases:
        ok(handler)

    fail('not callable')
    fail(1)
    fail

# Generated at 2022-06-23 13:36:38.177543
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    event_value = []

    def handler1(arg1, arg2, arg3):
        event_value.extend([arg1, arg2, arg3])

    def handler2(arg1, arg2, arg3):
        event_value.extend([arg1, arg2, arg3])

    def handler3(arg1, arg2, arg3):
        event_value.extend([arg1, arg2, arg3])

    event += handler1
    event += handler2
    event += handler3

    event.fire('a', 'b', 'c')

    assert event_value == ['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']



# Generated at 2022-06-23 13:36:48.230351
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def h0():
        nonlocal h0_called
        h0_called = True

    def h1(a, b, c):
        nonlocal h1_called, h1_args, h1_kwargs
        h1_called = True
        h1_args = (a, b, c)
        h1_kwargs = {'x': 1, 'y': 2, 'z': 3}

    e = _EventSource()

    h0_called = False
    e.fire()
    assert h0_called

    h1_called = False
    e += h1
    e.fire(1, 2, 3, x=1, y=2, z=3)
    assert h1_called
    assert h1_args == (1, 2, 3)

# Generated at 2022-06-23 13:36:56.007208
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestHandler(object):
        def __init__(self):
            self.call_count = 0

        def __call__(self):
            self.call_count += 1

    source = _EventSource()

    handler1 = _TestHandler()
    handler2 = _TestHandler()

    source += handler1
    source += handler2

    source.fire()

    assert handler1.call_count == 1
    assert handler2.call_count == 1



# Generated at 2022-06-23 13:36:59.485268
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    assert event_source.fire() is None

    called = []

    def handler(a):
        called.append(a)

    event_source += handler
    event_source.fire('arg1')
    assert called == ['arg1']



# Generated at 2022-06-23 13:37:09.616021
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    handler1 = lambda x: x + 1
    handler2 = lambda x: x + 2

    source += handler1
    source += handler2

    # test that handlers get fired
    assert source.fire(1) == 3

    # test removing a handler
    source -= handler1
    assert source.fire(1) == 3

    # test that exception handler can choose to not re-raise
    source.on_exception = lambda handler, ex, *args, **kwargs: False
    source += lambda: 1/0
    assert source.fire() == None


# Generated at 2022-06-23 13:37:11.745285
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()


# Unit tests for property _EventSource.__iadd__

# Generated at 2022-06-23 13:37:14.379002
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert not es._handlers


# Generated at 2022-06-23 13:37:17.644837
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that no exception is raised
    event_source = _EventSource()
    event_source += lambda: None
    event_source += lambda: 1 / 0
    event_source.fire()


# Generated at 2022-06-23 13:37:22.612448
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.playbook_paths is None


# Generated at 2022-06-23 13:37:27.202987
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)

# Generated at 2022-06-23 13:37:35.803386
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    h1 = lambda: None
    h2 = lambda: None
    h3 = lambda: None

    es += h1  # handler set is now [h1]
    assert list(es._handlers) == [h1]

    # remove h1 handler
    es -= h1
    assert list(es._handlers) == []

    # minus operators remove non-existant handlers without error
    es -= h2
    assert list(es._handlers) == []

    # exception handling is ignored when no exceptions
    es._on_exception = lambda h, e, *a, **kw: None
    es += h1
    es += h2
    es += h3
    assert list(es._handlers) == [h1, h2, h3]


# Generated at 2022-06-23 13:37:44.728348
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class TestAnsibleCollectionConfig(AnsibleCollectionConfig):
        pass

    # Verify behavior with no handlers
    e = TestAnsibleCollectionConfig.on_collection_load
    e.fire(1,2,3)

    # Add two handlers, and verify the fire method calls the correct number of handlers
    def handler1(a, b, c):
        handler1.call_count += 1

    def handler2(a, b, c):
        handler2.call_count += 1

    handler1.call_count = 0
    handler2.call_count = 0
    e += handler1
    e += handler2
    e.fire(0,0,0)
    assert handler1.call_count == 1
    assert handler2.call_count == 1

    # Remove a handler and verify the fire method calls the correct number of handlers

# Generated at 2022-06-23 13:37:49.526484
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, _EventSource)
    assert isinstance(AnsibleCollectionConfig._default_collection, _EventSource)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:37:55.853732
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: True
    assert len(es._handlers) == 1
    es += lambda: True
    assert len(es._handlers) == 2
    es += lambda: True
    assert len(es._handlers) == 3
    def h():
        return False
    es += h
    assert len(es._handlers) == 4



# Generated at 2022-06-23 13:37:59.756047
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.on_collection_load is None
    assert config.playbook_paths is None

# Generated at 2022-06-23 13:38:08.237863
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    h1 = lambda e, x: None
    h2 = lambda e, x: None

    es += h1
    es += h2

    assert h1 in es._handlers
    assert h2 in es._handlers

    es -= h1

    assert h1 not in es._handlers
    assert h2 in es._handlers

    es -= h1
    es -= h2

    assert h1 not in es._handlers
    assert h2 not in es._handlers

    es -= h1
    es -= h2

    assert h1 not in es._handlers
    assert h2 not in es._handlers


# Generated at 2022-06-23 13:38:12.828536
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config.collection_finder is None
    assert config.default_collection is None
    assert config._on_collection_load is not None
    assert len(config.collection_paths) == 0
    assert len(config.playbook_paths) == 0


# Generated at 2022-06-23 13:38:16.615886
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cls = AnsibleCollectionConfig()
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert isinstance(cls._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:38:19.215278
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac.__class__.__name__ == "AnsibleCollectionConfig"


# Generated at 2022-06-23 13:38:22.383806
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test = _EventSource()

    try:
        test += 42
    except ValueError:
        pass
    else:
        raise AssertionError('__iadd__ expected to raise ValueError for non-callable argument')

    def handler():
        pass

    test += handler



# Generated at 2022-06-23 13:38:24.217811
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source is not None

# Generated at 2022-06-23 13:38:26.156321
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()

# Generated at 2022-06-23 13:38:27.275561
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig()

# Generated at 2022-06-23 13:38:37.862754
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.six import StringIO

    class FakeHandler(object):
        def __init__(self, fd):
            self._fd = fd

        def __call__(self, *args, **kwargs):
            self._fd.write(str(dict(args=args, kwargs=kwargs)))
            self._fd.write('\n')

    io = StringIO()
    h1 = FakeHandler(io)
    h2 = FakeHandler(io)
    s = _EventSource()

    s += h1
    s += h2

    s.fire(h1=42, foo=43)
    actual = io.getvalue()

# Generated at 2022-06-23 13:38:44.369394
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    """This is a test for method __isub__ of class _EventSource."""

    _collection_finder = AnsibleCollectionConfig._collection_finder
    _default_collection = AnsibleCollectionConfig._default_collection
    _on_collection_load = AnsibleCollectionConfig._on_collection_load

    AnsibleCollectionConfig._collection_finder = _collection_finder
    AnsibleCollectionConfig._default_collection = _default_collection
    AnsibleCollectionConfig._on_collection_load = _on_collection_load

    event_source = _EventSource()
    handler = lambda: None
    event_source += handler
    event_source -= handler

    AnsibleCollectionConfig._collection_finder = _collection_finder
    AnsibleCollectionConfig._default_collection = _default_collection
    AnsibleCollectionConfig._on_collection_load = _on_collection_load

# Generated at 2022-06-23 13:38:52.418693
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class TestSubscriber:
        def __init__(self):
            self.event_count = 0
            self.last_payload = None

        def on_event(self, payload):
            self.event_count += 1
            self.last_payload = payload

    event_source = _EventSource()
    test_subscriber = TestSubscriber()

    event_source += test_subscriber.on_event

    assert test_subscriber.event_count == 0
    assert test_subscriber.last_payload is None

    event_source.fire('payload')

    assert test_subscriber.event_count == 1
    assert test_subscriber.last_payload == 'payload'


# Generated at 2022-06-23 13:38:57.819307
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def on_event_a(x):
        pass

    def on_event_b(x):
        pass

    def on_event_c(x):
        pass

    def on_event_d(x):
        pass

    def on_event_e(x):
        pass

    es = _EventSource()

    es += on_event_a
    es += on_event_b
    es += on_event_c
    es += on_event_d
    es += on_event_e

    es -= on_event_a

    assert on_event_a not in es._handlers
    assert on_event_b in es._handlers
    assert on_event_c in es._handlers
    assert on_event_d in es._handlers
    assert on_event_e in es._handlers

   

# Generated at 2022-06-23 13:39:05.312302
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        class_ = AnsibleCollectionConfig
        assert class_._collection_finder is None
        assert class_._default_collection is None
        assert isinstance(class_._on_collection_load, _EventSource)
        assert class_._on_collection_load._handlers == set()
    except AssertionError as e:
        raise AssertionError('AnsibleCollectionConfig __init__ is not behaving as expected') from e


# Generated at 2022-06-23 13:39:16.501687
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import pytest

    e = _EventSource()

    @e
    def f(x):
        print(x)

    @e
    def g(x):
        print(x)

    @e
    def h(x):
        print(x)

    e -= h

    e.fire(x=1)
    e.fire(x=2)
    e.fire(x=3)
    e.fire(x=4)
    e.fire(x=5)

    with pytest.raises(ValueError):
        e -= 'not callable'

    with pytest.raises(ValueError):
        e -= None

# Generated at 2022-06-23 13:39:19.232098
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler(s, item):
        assert s == event_source
        assert item == 42

    event_source += handler

    event_source.fire(42)



# Generated at 2022-06-23 13:39:28.540893
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert not event_source._handlers

    def handler_1():
        pass

    assert handler_1 in event_source

    event_source += handler_1
    assert handler_1 in event_source

    def handler_2():
        pass

    assert handler_2 not in event_source

    event_source += handler_2
    assert handler_2 in event_source

    event_source -= handler_1
    assert handler_1 not in event_source

    event_source -= handler_2
    assert handler_2 not in event_source


# Generated at 2022-06-23 13:39:32.746147
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class Sink:
        def __init__(self):
            self.log = []

        def handler(self, value):
            self.log.append(value)

    sink = Sink()
    src = _EventSource()
    src += sink.handler
    src -= sink.handler
    src.fire('ok')
    assert sink.log == []



# Generated at 2022-06-23 13:39:43.236237
# Unit test for constructor of class _EventSource
def test__EventSource():
    def event_handler(x):
        pass

    # Create an event handler for an event.
    event_source = _EventSource()
    assert (len(event_source._handlers) == 0)
    event_source += event_handler
    assert (len(event_source._handlers) == 1)
    assert (event_handler in event_source._handlers)
    assert (callable(event_handler) is True)
    assert (event_source._on_exception is not None)

    test_flag = False
    event_source.fire(test_flag)
    assert (test_flag is False)

    event_source.fire(test_flag)
    assert (test_flag is False)

    # Remove the event handler.
    event_source -= event_handler

# Generated at 2022-06-23 13:39:48.443076
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    m = _AnsibleCollectionConfig('meta', 'name', 'bases')

    assert m._collection_finder is None
    assert m._default_collection is None
    assert isinstance(m._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:39:54.118965
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import weakref
    from types import MethodType

    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.event = object()
            self.handler_count = 0

        def func(self, handler, *args, **kwargs):
            pass

        def method(self, handler, *args, **kwargs):
            pass

        def test1(self):
            def func(handler, *args, **kwargs):
                pass

            self += func
            self -= func
            assert len(self._handlers) == 0

        def test2(self):
            method = MethodType(self.method, self, TestEventSource)
            self += method
            self -= method
            assert len(self._handlers) == 0


# Generated at 2022-06-23 13:40:02.923939
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, _AnsibleCollectionConfig)
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')
    assert str(AnsibleCollectionConfig.__name__) == 'AnsibleCollectionConfig'
    assert str(AnsibleCollectionConfig.collection_finder.__class__.__name__) == 'property'
    assert str(AnsibleCollectionConfig.collection_paths.__class__.__name__) == 'property'
    assert str(AnsibleCollectionConfig.default_collection.__class__.__name__) == 'property'
    assert str(AnsibleCollectionConfig.on_collection_load.__class__.__name__) == 'property'

# Generated at 2022-06-23 13:40:04.968528
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class AnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    instance = AnsibleCollectionConfig()


# Generated at 2022-06-23 13:40:07.227437
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig()

# Generated at 2022-06-23 13:40:12.211775
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler1 = object()
    handler2 = object()

    event_source += handler1
    event_source += handler2

    event_source -= handler1
    event_source -= handler2

    assert event_source._handlers == set()


# Generated at 2022-06-23 13:40:16.529104
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class Source(_EventSource):
        pass

    event_source = Source()
    func = lambda: None
    event_source += func
    event_source -= func
    event_source -= func


# Generated at 2022-06-23 13:40:19.867284
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from lib.ansible_test._util.target.legacy_collection_loader import _AnsibleCollectionConfig
    class Foo(_AnsibleCollectionConfig):
        pass

    assert True

# Generated at 2022-06-23 13:40:26.768551
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler(*args, **kwargs):
        pass

    event_source = _EventSource()
    event_source._handlers = set()
    assert len(event_source._handlers) == 0

    # isub__ with an empty handlers
    event_source.__isub__(handler)
    assert len(event_source._handlers) == 0

    # isub__ with a set containing the passed handler
    event_source._handlers = {handler}
    event_source.__isub__(handler)
    assert len(event_source._handlers) == 0

    # isub__ with a set not containing the passed handler
    event_source._handlers = set()
    event_source.__isub__(handler)
    assert len(event_source._handlers) == 0



# Generated at 2022-06-23 13:40:31.749864
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    def add10(x):
        return x + 10

    assert event._handlers == set()

    event += add10
    assert event._handlers == {add10}

    with pytest.raises(ValueError):
        event += 10

    event -= add10
    assert event._handlers == set()



# Generated at 2022-06-23 13:40:40.672584
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    # Config: a set containing a callable and an integer
    from ansible.module_utils.common.text.converters import to_text
    test_set = set()
    test_callable = to_text
    test_noncallable = None
    test_set.add(test_callable)
    test_set.add(test_noncallable)

    # Test
    test_expectation = True
    try:
        event_source = _EventSource()
        event_source._handlers = test_set

        # Remove the callable
        event_source -= test_callable
        # No exception was raised
        test_result = True
    except Exception as exception:
        # Exception was raised
        test_result = False


# Generated at 2022-06-23 13:40:45.688129
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    event_source = _EventSource()
    foo = lambda a: a
    bar = lambda a: a

    # Test case: remove handler from empty set
    event_source._on_exception = lambda a, b, c: True
    event_source.__isub__(foo)

    # Test case: remove handler from non-empty set
    event_source._on_exception = lambda a, b, c: True
    event_source.__iadd__(bar)
    event_source.__isub__(bar)


# Generated at 2022-06-23 13:40:55.243585
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    obj = _EventSource()
    assert not obj.fire()

    obj_exception = False
    try:
        obj += lambda: 1 / 0
        obj.fire()
    except ZeroDivisionError:
        obj_exception = True
    assert obj_exception

    obj_exception = False
    def _on_exception(handler, exc, *args, **kwargs):
        return True

    try:
        obj._on_exception = _on_exception
        obj.fire()
    except ZeroDivisionError:
        obj_exception = True
    assert obj_exception

# Generated at 2022-06-23 13:41:07.006847
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def foo():
        return 'foo'

    def bar():
        return 'bar'

    class test_class:
        def __init__(self):
            self.x = None

        def set_to_foo(self, a, b=None, *args, **kwargs):
            self.x = foo()

        def set_to_bar(self, a, b=None, *args, **kwargs):
            self.x = bar()

        def set_to_exception(self, a, b=None, *args, **kwargs):
            raise ValueError('always raises an exception')

    # ensure += and -= work
    e = _EventSource()
    e += foo
    e += bar

    assert len(e._handlers) == 2
    assert foo in e._handlers
    assert bar in e._hand

# Generated at 2022-06-23 13:41:11.234828
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)


# Unit tests for class _EventSource

# Generated at 2022-06-23 13:41:13.629212
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None

# Generated at 2022-06-23 13:41:15.091384
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config is not None

# Generated at 2022-06-23 13:41:24.395486
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # on_test is added to the set of handlers for the event source
    # because the method fire is called, on_test is executed
    # it does not raise an exception so it is not caught
    # to_test is not added to the set of handlers so it is not executed
    # the set of handlers includes on_test so it is removed before the test completes
    # if the execution of on_test had raised an exception, it would not have been removed
    # the test ensures that the execution of on_test and the removal of on_test are successful
    # returning True would re-raise an exception
    def on_test(x, y):
        assert x == 'test', 'x = %r instead of %r' % (x, 'test')

# Generated at 2022-06-23 13:41:29.227631
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class config(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert config.collection_finder is None
    assert config.default_collection is None
    assert isinstance(config.on_collection_load, _EventSource)



# Generated at 2022-06-23 13:41:35.573039
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, _AnsibleCollectionConfig)
    assert hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert AnsibleCollectionConfig._collection_finder is None
    assert hasattr(AnsibleCollectionConfig, '_default_collection')
    assert AnsibleCollectionConfig._default_collection is None
    assert hasattr(AnsibleCollectionConfig, '_on_collection_load')
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Unit test isinstance()

# Generated at 2022-06-23 13:41:37.515199
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert (_EventSource() is not None)


# Generated at 2022-06-23 13:41:42.784956
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Meta(type):
        pass

    class Base(object):
        pass

    class Foo(with_metaclass(Meta, Base)):
        pass

    obj = Foo()

    assert obj._collection_finder is None
    assert obj._default_collection is None
    assert isinstance(obj._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:41:54.683747
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    """Test the method fire of class _EventSource.

    Two class called `ExceptionOne` and `ExceptionTwo` are defined.
    The first exception is raised and handled, the other one is raised and re-raised.
    """
    class ExceptionOne(Exception):
        pass

    class ExceptionTwo(Exception):
        pass

    def handler_one(value):
        assert value == 42
        raise ExceptionOne()


    def handler_two(value):
        assert value == 42
        raise ExceptionTwo()


    def handler_three(value):
        assert value == 42
        return value


    def on_exception_one(handler, exc, *args, **kwargs):
        """Handle the exception `ExceptionOne`."""
        assert isinstance(exc, handler.__class__)
        return False



# Generated at 2022-06-23 13:41:56.836691
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert len(es._handlers) == 0


# Generated at 2022-06-23 13:41:58.828274
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-23 13:42:02.411365
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = _AnsibleCollectionConfig('meta_name', 'test_class', None)
    assert c._on_collection_load is not None
    assert c._collection_finder is None
    assert c._default_collection is None

# Generated at 2022-06-23 13:42:13.525765
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    record1 = []
    record2 = []

    def handler1(*args, **kwargs):
        record1.append((args, kwargs))

    def handler2(*args, **kwargs):
        record2.append((args, kwargs))
        raise Exception('handler2 expected exception')

    # test fire with no handlers
    _AnsibleCollectionConfig.on_collection_load.fire(1, a=1)
    assert record1 == []
    assert record2 == []

    # test fire with no args and no kwargs
    _AnsibleCollectionConfig.on_collection_load += handler1
    _AnsibleCollectionConfig.on_collection_load += handler2
    _AnsibleCollectionConfig.on_collection_load.fire()
    assert record1 == [(tuple(), {})]

# Generated at 2022-06-23 13:42:15.633113
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None

# Generated at 2022-06-23 13:42:24.277724
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _TestEventSource(_EventSource):
        pass

    test_event_source = _TestEventSource()
    event_calls = []

    def _handler_1(*args, **kwargs):
        event_calls.append(('handler_1', args, kwargs))

    def _handler_2(*args, **kwargs):
        event_calls.append(('handler_2', args, kwargs))

    test_event_source += _handler_1
    test_event_source += _handler_2

    test_event_source.fire(1, 2, a=3, b=4)


# Generated at 2022-06-23 13:42:28.513579
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    source = _EventSource()

    # Define callbacks
    def cb1():
        pass

    def cb2():
        raise RuntimeError('Something went wrong')

    # Assign callbacks
    source += cb1
    source += cb2

    try:
        source.fire()
    except:
        pass

    assert cb1 in source._handlers
    assert cb2 in source._handlers

# Generated at 2022-06-23 13:42:33.083272
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cls = AnsibleCollectionConfig
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert isinstance(cls._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:42:42.621273
# Unit test for constructor of class _EventSource
def test__EventSource():
    msg = 'handler must be callable'
    event = _EventSource()

    try:
        event += 2
        assert False, 'Adding non-callable handler should fail'
    except ValueError as ex:
        assert msg == str(ex)

    try:
        event += {}
        assert False, 'Adding non-callable handler should fail'
    except ValueError as ex:
        assert msg == str(ex)

    try:
        event += []
        assert False, 'Adding non-callable handler should fail'
    except ValueError as ex:
        assert msg == str(ex)

    event += lambda x: x + 1
    assert 1 == len(event._handlers)



# Generated at 2022-06-23 13:42:46.804364
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():

    # Initialize with inheritance of type
    acc = AnsibleCollectionConfig()

    assert acc.collection_paths is None
    assert acc.playbook_paths is None

# Generated at 2022-06-23 13:42:57.775314
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # Default values
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert callable(AnsibleCollectionConfig._on_collection_load.fire)

    # get/set of collection finder
    class TestCollectionFinder(object):
        # we need something with a _n_* method in it
        def _n_collection_paths(self, *args, **kwargs):
            pass

        def _n_playbook_paths(self, *args, **kwargs):
            pass

    test_collection_finder = TestCollectionFinder()

    AnsibleCollectionConfig.collection_finder = test_collection_finder
    assert AnsibleCollectionConfig._collection_finder == test_collection_finder
    assert AnsibleCollectionConfig.collection_finder == test_collection_finder

    test_

# Generated at 2022-06-23 13:43:08.829151
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    '''
    Test for method __isub__ of class _EventSource

    :id: d532d7b3-f5a5-41d5-a78f-1f2cebabf3f3

    :steps:
        1. Create event handler object.
        2. Add event handler
        3. Remove event handler
        4. Fire event

    :expectedresults:
        1. Event handler object should be created successfully.
        2. Event handler should be added successfully.
        3. Event handler should be removed successfully.
        4. Event should be fired successfully.
    '''

    # Create event handler object
    event_object = _EventSource()

    # Define event handler function
    def handler(x):
        print(x)

    # Add event handler
    event_object += handler

    # Remove event handler


# Generated at 2022-06-23 13:43:11.039682
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    '''
    Ensure that we can create an instance of AnsibleCollectionConfig
    '''
    ACC = AnsibleCollectionConfig()
    assert isinstance(ACC, AnsibleCollectionConfig)

# Generated at 2022-06-23 13:43:16.269029
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc = AnsibleCollectionConfig()
    assert acc.collection_finder is None
    assert acc.default_collection is None
    assert isinstance(acc.on_collection_load, _EventSource)
    assert acc.on_collection_load is acc._on_collection_load
    assert acc.on_collection_load is acc._on_collection_load
    assert acc.collection_paths == []
    assert acc.playbook_paths == []
