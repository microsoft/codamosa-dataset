

# Generated at 2022-06-23 13:33:19.726772
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MyMeta(_AnsibleCollectionConfig):
        pass
    cls = MyMeta('meta', 'name', 'bases')
    # check that the class properties have been initialized
    assert cls.on_collection_load
    assert cls.collection_finder is None
    assert cls.collection_paths is None
    assert cls.default_collection is None
    assert cls.on_collection_load is None
    assert cls.playbook_paths is None


# Generated at 2022-06-23 13:33:27.378537
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class FakeEventSource(_EventSource):
        pass

    t = FakeEventSource()
    t.fire('a', 'b', 'c')

    def handler1(s, m, t):
        assert s == 'a'
        assert m == 'b'
        assert t == 'c'

    def handler2(s, m, t):
        assert s == 'a'
        assert m == 'b'
        assert t == 'c'

    t += handler1
    t += handler2
    t.fire('a', 'b', 'c')

    def handler3(s, m, t):
        assert s == 'a'
        assert m == 'b'
        assert t == 'c'
        raise ZeroDivisionError

    t += handler3

# Generated at 2022-06-23 13:33:28.401713
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    AnsibleCollectionConfig()


# Generated at 2022-06-23 13:33:34.897578
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create a new _EventSource object
    event_source = _EventSource()

    # Define an empty handler
    def empty_handler(event_source, *args, **kwargs):
        pass

    # Add the empty handler to the event_source object
    event_source += empty_handler

    # Fire the event source with no arguments
    event_source.fire()

    # Define a handler that takes 1 argument
    def simple_handler(event_source, arg, *args, **kwargs):
        pass

    # Add the simple handler to the event_source object
    event_source += simple_handler

    # Fire the event source with 1 argument
    event_source.fire('one')

    # Define a handler that takes 1 keyword argument

# Generated at 2022-06-23 13:33:38.828974
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    collection_config = AnsibleCollectionConfig()
    assert collection_config._collection_finder is None
    assert collection_config._default_collection is None
    assert collection_config._on_collection_load is not None
    assert isinstance(collection_config._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:33:43.236057
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    def handler(event_arg):
        pass

    cf = AnsibleCollectionConfig()
    assert cf.collection_finder is None
    assert cf.default_collection is None
    assert cf.collection_paths == []
    assert cf.playbook_paths == []
    assert cf.on_collection_load.fire('test') is None
    assert cf.on_collection_load.__class__.__name__ == '_EventSource'

    cf.on_collection_load += handler
    assert cf.on_collection_load.fire('test') is None

    try:
        cf.on_collection_load = 'foo'
        assert False
    except ValueError:
        assert True

    try:
        cf.on_collection_load += 'foo'
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-23 13:33:46.086651
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda: None

    event_source += handler

    assert hasattr(event_source, '_handlers')
    assert handler in event_source._handlers



# Generated at 2022-06-23 13:33:51.371053
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()
    assert hasattr(a, '_collection_finder')
    assert hasattr(a, '_default_collection')
    assert hasattr(a, '_on_collection_load')
    assert a._collection_finder is None
    assert list(a._on_collection_load._handlers) == []


# Generated at 2022-06-23 13:33:59.357117
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es1 = _EventSource()
    was_called = [False]

    def handler():
        was_called[0] = True

    es1 += handler
    assert len(es1._handlers) == 1

    # add a second handler
    was_called2 = [False]

    def handler2():
        was_called2[0] = True

    es1 += handler2
    assert len(es1._handlers) == 2

    # test the handler
    es1.fire()
    assert was_called[0]
    assert was_called2[0]



# Generated at 2022-06-23 13:34:01.345252
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()

    assert len(event_source._handlers) == 0



# Generated at 2022-06-23 13:34:10.223609
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import mock
    import pytest
    _x = _EventSource()

    def func1(*args, **kwargs):
        pass

    def func2(*args, **kwargs):
        pass

    _x += func1
    _x += func2
    _x.fire('a', 'b', 'c', d='d')
    mock.patch.object(_x, 'fire').start()
    _x.fire('a', 'b', 'c', d='d')

    def another(*args, **kwargs):
        raise Exception('exception')

    _x += another
    with pytest.raises(Exception):
        _x.fire('a', 'b', 'c', d='d')

    _x -= another
    _x.fire('a', 'b', 'c', d='d')

# Generated at 2022-06-23 13:34:11.495837
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    es += lambda: None
    es -= lambda: None

# Generated at 2022-06-23 13:34:15.216295
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_paths == []
    assert config.playbook_paths == []

# Generated at 2022-06-23 13:34:23.210935
# Unit test for constructor of class _EventSource
def test__EventSource():
    from inspect import isfunction

    s = _EventSource()

    def myhandler(event_data):
        print('This is my handler: %s' % event_data)

    assert len(s._handlers) == 0
    s += myhandler
    assert len(s._handlers) == 1
    assert isfunction(s._handlers.pop())
    s -= myhandler
    assert len(s._handlers) == 0

    try:
        s += 'a string is not a callable'
        assert False, 'Expected : ValueError'
    except ValueError:
        pass



# Generated at 2022-06-23 13:34:29.845309
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert es._handlers == set()

    def handler1(a, b):
        pass
    def handler2(a, b):
        pass

    es += handler1
    assert es._handlers == {handler1}
    es += handler1
    assert es._handlers == {handler1}
    es += handler2
    assert es._handlers == {handler1, handler2}

    try:
        es += 'not callable'
        assert False, 'Expected ValueError'
    except ValueError:
        pass



# Generated at 2022-06-23 13:34:31.587743
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += 1


# Generated at 2022-06-23 13:34:41.891159
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def add_one(a, b, c):
        return a + b + c

    def raise_error(a, b, c):
        if c == 3:
            raise ValueError('c == 3')

    def add_one_err(a, b, c):
        if c == 4:
            raise RuntimeError('c == 4')

    def throw_away_ok(a, b, c):
        if c == 5:
            raise RuntimeError('c == 5')

    def throw_away_err(a, b, c):
        if c == 6:
            raise RuntimeError('c == 6')

    # test register and execute of callback function with no error
    on_callback = _EventSource()
    on_callback += add_one
    on_callback.fire(1, 2, 3)
    on_callback -= add

# Generated at 2022-06-23 13:34:46.942200
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    test_event = _EventSource()

    def test_handler():
        test_event._handlers.remove(test_handler)

    # test removing a non-existent handler
    test_event -= test_handler

    # test removing a handler that throws an exception
    test_event += test_handler
    test_event -= test_handler

    # test removing a handler that does not throw an exception
    test_event += test_handler
    test_event.fire()
    test_event -= test_handler

    # no exceptions, so our test succeeded
    assert True


# Generated at 2022-06-23 13:34:48.138746
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # init of class should not raise an exception
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:34:55.358536
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_TestEventSource, self).__init__()
            self._handlers.add(1)
            self._unsubscribed = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            if handler == 1:
                self._unsubscribed = True

    t = _TestEventSource()
    t -= 1

    assert t._unsubscribed
    assert not t._handlers

# Generated at 2022-06-23 13:34:59.688047
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _Test:
        def __init__(self):
            self.called = False

        def __call__(self):
            self.called = True

    source = _EventSource()
    handler1 = _Test()
    handler2 = _Test()

    source += handler1
    source += handler2

    source.fire()

    assert handler1.called
    assert handler2.called

# Generated at 2022-06-23 13:35:03.697570
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    handler = lambda: None

    event += handler

    assert handler in event._handlers

    event -= handler

    assert len(event._handlers) == 0

# Generated at 2022-06-23 13:35:07.446527
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac.__class__._collection_finder is None
    assert ac.__class__._default_collection is None
    assert ac.__class__._on_collection_load



# Generated at 2022-06-23 13:35:08.767797
# Unit test for constructor of class _EventSource
def test__EventSource():
    s = _EventSource()
    assert s._handlers == set()


# Generated at 2022-06-23 13:35:09.619382
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert getattr(_EventSource(), '_handlers', None) is None


# Generated at 2022-06-23 13:35:11.189714
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig


# Initialize the singleton instance of the AnsibleCollectionConfig class
config = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:35:16.271107
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class DummyAnsibleCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):  # noqa pylint: disable=unused-variable
        pass
    # Test py2/py3 constructor differences
    assert getattr(DummyAnsibleCollectionConfig, '__init__') is not object.__init__

# Generated at 2022-06-23 13:35:20.210302
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler1():
        pass

    def handler2():
        pass

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2

    assert event_source._handlers == {handler1, handler2}


# Generated at 2022-06-23 13:35:23.121286
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    event_source += lambda x: x
    assert len(event_source._handlers) == 1



# Generated at 2022-06-23 13:35:25.692687
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:35:35.252261
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler1(a):
        pass

    def handler2(a):
        pass

    class TestEventSource(AnsibleCollectionConfig):
        pass

    e = TestEventSource._on_collection_load
    assert len(e._handlers) == 0

    e += handler1
    e += handler2
    assert len(e._handlers) == 2
    assert handler1 in e._handlers
    assert handler2 in e._handlers

    e -= handler1
    assert len(e._handlers) == 1
    assert handler1 not in e._handlers
    assert handler2 in e._handlers

    e -= handler1
    assert len(e._handlers) == 1
    assert handler1 not in e._handlers
    assert handler2 in e._handlers

    e -= handler2

# Generated at 2022-06-23 13:35:36.596827
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)

# Generated at 2022-06-23 13:35:43.345598
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    called = [0]

    def handler():
        called[0] += 1

    es += handler
    assert len(es._handlers) == 1
    assert called[0] == 0

    es.fire()
    assert called[0] == 1

    es -= handler
    assert len(es._handlers) == 0
    es.fire()
    assert called[0] == 1



# Generated at 2022-06-23 13:35:49.605974
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Setup
    es = _EventSource()
    def handler1():
        pass

    def handler2():
        pass

    es += handler1
    es += handler2

    # Exercise
    es -= handler1
    es -= handler2
    es -= handler2

    # Verify
    assert len(es._handlers) == 1
    assert list(es._handlers)[0] == handler2



# Generated at 2022-06-23 13:35:58.874094
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSourceTest:
        def __init__(self):
            self.event_source = _EventSource()

        def handler1(self, *args, **kwargs):
            return 'handler1'

        def handler2(self, *args, **kwargs):
            return 'handler2'

        def handler3(self, *args, **kwargs):
            raise RuntimeError('handler3')

    e = EventSourceTest()

    e.event_source += e.handler1
    e.event_source += e.handler2

    assert e.event_source.fire() == None

    # add another handler that raises an exception, handler1 is skipped
    e.event_source += e.handler3
    try:
        e.event_source.fire()
    except RuntimeError:
        pass
    else:
        raise Assert

# Generated at 2022-06-23 13:36:02.563633
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert not AnsibleCollectionConfig._on_collection_load._handlers

# Generated at 2022-06-23 13:36:12.550390
# Unit test for constructor of class AnsibleCollectionConfig

# Generated at 2022-06-23 13:36:14.163423
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource() is not None


# Generated at 2022-06-23 13:36:21.040909
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    actual_params = None
    actual_kwargs = None

    def _handler(x, y, z=None):
        global actual_params, actual_kwargs
        actual_params = [x, y]
        actual_kwargs = dict(z=z)

    event = _EventSource()
    event += _handler
    event.fire('a', 'b', z='c')

    assert actual_params == ['a', 'b']
    assert actual_kwargs == dict(z='c')

# Generated at 2022-06-23 13:36:25.416411
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    s = _EventSource()
    def f():
        pass
    s += f
    assert(f in s._handlers)
    s -= f
    assert(f not in s._handlers)
    s -= f
    assert(f not in s._handlers)

# Generated at 2022-06-23 13:36:31.038208
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert TestCollectionConfig._collection_finder is None
    assert TestCollectionConfig._default_collection is None
    assert isinstance(TestCollectionConfig._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:36:38.968610
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    handler = lambda *args, **kwargs: None

    event_source = _EventSource()

    # add a handler
    event_source += handler
    assert handler in event_source._handlers

    # add the same handler again
    event_source += handler
    assert handler in event_source._handlers

    # add an invalid handler, which should result in a ValueError
    exception_raised = False
    try:
        event_source += 'not callable'
    except ValueError:
        exception_raised = True
    assert exception_raised



# Generated at 2022-06-23 13:36:41.685371
# Unit test for constructor of class _EventSource
def test__EventSource():
    instance = _EventSource()
    assert list(instance._handlers) == list()


# Generated at 2022-06-23 13:36:48.990098
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    event = _EventSource()
    assert not event._handlers

    # add a callable object
    class Callable:
        def __call__(self, *args, **kwargs):
            pass
    event += Callable()
    assert len(event._handlers) == 1
    assert isinstance(next(iter(event._handlers)), Callable)

    # add a function
    event += test__EventSource___iadd__
    assert len(event._handlers) == 2
    assert isinstance(next(iter(event._handlers)), type(test__EventSource___iadd__))

    # add a lambda
    event += lambda: None
    assert len(event._handlers) == 3

    # add a non-callable object
    try:
        event += object()
    except ValueError:
        pass

# Generated at 2022-06-23 13:36:59.739917
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler1(arg1, arg2):
        pass

    def handler2(arg3, arg4):
        pass

    def handler3(exc, arg5, arg6):
        raise Exception('handler3')

    def handler4(exc, arg7, arg8):
        return False

    event_source = _EventSource()

    # test add/remove of handlers
    event_source += handler1
    event_source -= handler1
    event_source += handler1
    event_source += handler2
    assert len(event_source._handlers) == 2

    # test event handler calls
    event_source.fire('arg1', 'arg2', arg3='arg3', arg4='arg4')
    assert len(event_source._handlers) == 2

    event_source += handler3

# Generated at 2022-06-23 13:37:03.106905
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    actual = AnsibleCollectionConfig()
    assert ['_AnsibleCollectionConfig__handlers'] == dir(actual._on_collection_load)

# Generated at 2022-06-23 13:37:11.039869
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    source = _EventSource()

    def handler1(non_kwargs, kwargs, kwarg_name=None):
        print("handler1 called")
        print("non_kwargs: %s" % non_kwargs)
        print("kwargs: %s" % kwargs)
        print("kwarg_name: %s" % kwarg_name)
    source += handler1
    source.fire("non_kwargs", kwargs="kwargs", kwarg_name="kwarg_name")


# Generated at 2022-06-23 13:37:16.616606
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert isinstance(cls._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:37:20.728723
# Unit test for constructor of class _EventSource
def test__EventSource():
    o = _EventSource()

    assert callable(o)
    assert o._handlers == set()
    assert o.__iadd__ is not None
    assert o.__isub__ is not None
    assert o._on_exception is not None
    assert o.fire is not None



# Generated at 2022-06-23 13:37:27.111485
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    def handler1(a, b=1):
        pass

    def handler2(a, b=2):
        pass

    def handler3(a, b=3):
        pass

    foo = _TestEventSource()
    foo += handler1
    foo += handler2
    foo += handler3

    assert len(foo._handlers) == 3

    foo -= handler1
    foo -= handler2
    foo -= handler3
    foo -= handler3

    assert len(foo._handlers) == 0

# Generated at 2022-06-23 13:37:34.015310
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    assert es._handlers == set()

    def handler1():
        pass

    def handler2():
        pass

    es += handler1
    assert es._handlers == {handler1}

    es += handler2
    assert es._handlers == {handler1, handler2}

    es -= handler1
    assert es._handlers == {handler2}

    es -= handler1
    assert es._handlers == {handler2}

    es -= handler2
    assert es._handlers == set()

# Generated at 2022-06-23 13:37:44.191788
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class DummyCollectionConfig:
        __metaclass__ = _AnsibleCollectionConfig

    assert isinstance(DummyCollectionConfig.collection_finder, property)
    assert isinstance(DummyCollectionConfig.collection_paths, property)
    assert isinstance(DummyCollectionConfig.default_collection, property)
    assert isinstance(DummyCollectionConfig.on_collection_load, property)
    assert isinstance(DummyCollectionConfig.playbook_paths, property)

    assert DummyCollectionConfig._collection_finder is None
    assert DummyCollectionConfig._default_collection is None

    assert isinstance(DummyCollectionConfig._on_collection_load, _EventSource)
    assert DummyCollectionConfig._on_collection_load._handlers == set()


# Generated at 2022-06-23 13:37:46.194814
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # test_Empty
    e = _EventSource()
    e -= lambda x, y: x + y
    assert e._handlers == set()

# Generated at 2022-06-23 13:37:52.649275
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.playbook_paths is None

# Generated at 2022-06-23 13:37:58.955510
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    # pylint: disable=unused-argument
    def handler1(event_source, event_type, data):
        pass
    # pylint: enable=unused-argument

    event_source += handler1
    assert handler1 in event_source._handlers
    event_source -= handler1
    assert handler1 not in event_source._handlers

    # test that removing a non-existent handler does not fail
    event_source -= handler1
    assert handler1 not in event_source._handlers


# Generated at 2022-06-23 13:38:05.160491
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler(x): return x

    event_source += handler
    assert len(event_source._handlers) == 1
    event_source -= handler
    assert len(event_source._handlers) == 0
    event_source -= handler
    assert len(event_source._handlers) == 0


# Generated at 2022-06-23 13:38:12.277017
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = _AnsibleCollectionConfig(None, 'AnsibleCollectionConfig', None)
    assert ac._collection_finder is None
    assert ac._default_collection is None
    assert ac._on_collection_load.__class__.__name__ == '_EventSource'
    assert ac.collection_finder is None
    assert ac.default_collection is None
    assert ac.on_collection_load.__class__.__name__ == '_EventSource'

# Generated at 2022-06-23 13:38:13.971587
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta_name', 'cls_name', (), {})

# Generated at 2022-06-23 13:38:21.735270
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Given
    event_source = _EventSource()
    event_handler1 = lambda: 'event_handler1'
    event_handler2 = lambda: 'event_handler2'

    # When
    event_source += event_handler1
    event_source += event_handler2
    event_source -= event_handler2

    # Then
    assert event_handler1 in event_source._handlers
    assert event_handler2 not in event_source._handlers



# Generated at 2022-06-23 13:38:27.549432
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    events = _EventSource()

    def foo():
        pass

    def bar():
        pass

    def quux():
        pass

    events += foo
    events += bar
    events += quux

    events -= bar

    assert events._handlers == {foo, quux}


# Generated at 2022-06-23 13:38:35.675504
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.on_collection_load is not None
    assert config.collection_finder is None
    assert config.default_collection is None
    assert config.collection_paths == []
    assert config.playbook_paths == []

    config = AnsibleCollectionConfig()
    assert config.on_collection_load is not None
    assert config.collection_finder is None
    assert config.default_collection is None
    assert config.collection_paths == []
    assert config.playbook_paths == []



# Generated at 2022-06-23 13:38:47.149864
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # try adding a non-method
    instance = _EventSource()
    try:
        instance.__iadd__(1)
        assert False
    except ValueError:
        pass

    # try adding a bound method
    def handler(a, b):
        return a + b
    instance += handler
    assert handler in instance._handlers

    # try adding an unbound method
    class foo(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        def handler(self, value):
            return self.a + self.b + value

    instance = _EventSource()
    instance += foo(1, 2).handler

    # try adding a bound method via +=
    instance += foo(5, 6).handler


# Generated at 2022-06-23 13:38:49.484295
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig._collection_finder, None)
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:38:55.092274
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def subscriber(x):
        print('subscriber {}'.format(x))

    es += subscriber
    assert 1 == len(es._handlers)

    with pytest.raises(ValueError):
        es += 'not callable'



# Generated at 2022-06-23 13:38:56.806395
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert c._collection_finder is None
    assert c._default_collection is None


# Generated at 2022-06-23 13:39:08.161580
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    @AnsibleCollectionConfig.on_collection_load.__iadd__
    def test_handler(path):
        test_handler.path = path

    @AnsibleCollectionConfig.on_collection_load.__iadd__
    def test_exception_handler(path):
        raise ValueError('test exception')

    test_handler.path = None

    path = '/path/to/collection'
    AnsibleCollectionConfig.on_collection_load.fire(path)
    assert test_handler.path == path

    exception_raised = False

    try:
        AnsibleCollectionConfig.on_collection_load -= test_handler
        AnsibleCollectionConfig.on_collection_load.fire(path)
        AnsibleCollectionConfig.on_collection_load += test_handler
    except ValueError:
        exception_raised = True


# Generated at 2022-06-23 13:39:10.884609
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    h1 = None
    h2 = None
    def h1(x):
        pass
    def h2(x):
        pass

    e += h1
    e += h2

    assert h1 in e._handlers
    assert h2 in e._handlers
    assert len(e._handlers) == 2


# Generated at 2022-06-23 13:39:12.260091
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:39:20.668579
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import ansible.utils.collection_loader.collection_finder
    from ansible.utils.collection_loader.collection_finder import AnsibleCollectionFinder
    from ansible.utils.collection_loader.collection_finder import find_collections

    # class instance
    collection_config = AnsibleCollectionConfig()

    # test instance variables after constructor
    assert isinstance(collection_config.collection_finder, AnsibleCollectionFinder)
    assert collection_config.collection_finder.playbook_paths == []
    assert isinstance(collection_config.on_collection_load, _EventSource)
    assert collection_config.default_collection is None

    AnsibleCollectionConfig.default_collection = find_collections()

# Generated at 2022-06-23 13:39:31.497558
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class UnitTest:
        def test_method(self, **kwargs):
            pass

        def raise_exception_handler(self, *args, **kwargs):
            raise Exception('A test exception occurred.')

    unit_test = UnitTest()

    # confirm that the method can accept a callable
    AnsibleCollectionConfig.on_collection_load += unit_test.test_method
    assert callable(unit_test.test_method)

    # confirm that the method raises an exception when adding a non-callable
    try:
        AnsibleCollectionConfig.on_collection_load += unit_test.test_method.__dict__
        raise AssertionError('iAdd did not raise an exception when adding a non-callable.')
    except ValueError:
        pass

    # confirm that the exception handler returns True when an exception occurs and

# Generated at 2022-06-23 13:39:42.139633
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class _DummyEventSource(_EventSource):
        pass

    # _EventSource cannot be instantiated, _DummyEventSource extends it to be testable
    dummy_event_source = _DummyEventSource()

    # event_handler1 is called
    def event_handler1():
        raise ValueError('event_handler1 was called')

    dummy_event_source += event_handler1
    try:
        dummy_event_source.fire()
    except Exception as ex:
        if not isinstance(ex, ValueError) or ex.message != 'event_handler1 was called':
            raise

    # event_handler2 is called
    def event_handler2():
        raise ValueError('event_handler2 was called')

    dummy_event_source += event_handler2

# Generated at 2022-06-23 13:39:46.234763
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # GIVEN: An instance of class _EventSource with a handler already attached.
    event_source = _EventSource()
    handler = lambda: True
    event_source += handler

    # WHEN: the handler is removed from the event_source.
    event_source -= handler

    # THEN: no handlers should be attached to the event_source.
    assert event_source._handlers == set()
    try:
        event_source.fire()
    except:
        fail('Ansible collection loader failed to remove a handler from the event source.')

# Generated at 2022-06-23 13:39:51.733253
# Unit test for constructor of class _EventSource

# Generated at 2022-06-23 13:39:54.036823
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    s = _EventSource()

    def test1():
        pass

    s += test1
    s -= test1

# Generated at 2022-06-23 13:39:57.931475
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest
    x = _EventSource()

    def f():
        pass

    x += f

    with pytest.raises(ValueError) as err:
        x += None
    assert err.value.args == ('handler must be callable',)



# Generated at 2022-06-23 13:40:04.467805
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert len(es._handlers) == 0

    def x():
        return

    es += x
    assert len(es._handlers) == 1
    assert x in es._handlers

    # tests for adding the same handler twice
    # should not result in list having more than one
    # instance of the same handler
    es += x
    assert len(es._handlers) == 1
    assert x in es._handlers

# Generated at 2022-06-23 13:40:15.809852
# Unit test for constructor of class _EventSource
def test__EventSource():
    class Mock:
        pass

    event_source = _EventSource()
    assert isinstance(event_source, _EventSource)

    mock_handler = Mock()
    mock_handler.__call__ = Mock()
    mock_handler.__call__.__call__ = Mock()

    def test_handler_func():
        pass

    event_source += mock_handler
    assert len(event_source._handlers) == 1

    event_source += mock_handler
    assert len(event_source._handlers) == 1

    event_source += test_handler_func
    assert len(event_source._handlers) == 2

    event_source -= mock_handler
    assert len(event_source._handlers) == 1

    event_source -= test_handler_func
    assert len(event_source._handlers) == 0



# Generated at 2022-06-23 13:40:22.050648
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from collections import namedtuple

    eventsource = _EventSource()
    handler = namedtuple('handler', ['__call__'])

    eventsource += handler()

    assert len(eventsource._handlers) == 1
    assert handler() in eventsource._handlers

    eventsource += handler()

    assert len(eventsource._handlers) == 2
    assert handler() in eventsource._handlers



# Generated at 2022-06-23 13:40:26.091246
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # Arrange
    handlers = [lambda: 4, lambda: 5]
    subject = _EventSource()
    subject += handlers[0]

    # Act
    subject -= handlers[1]

    # Assert
    assert len(subject._handlers) == 1

# Generated at 2022-06-23 13:40:31.901280
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class T(object, metaclass=_AnsibleCollectionConfig):
        pass

    assert isinstance(T._on_collection_load, _EventSource)
    assert T.collection_finder is None
    assert T.default_collection is None
    assert T.on_collection_load
    assert T.collection_paths is None
    assert T.playbook_paths is None



# Generated at 2022-06-23 13:40:34.086345
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    handler = lambda: True
    event += handler

    assert handler in event._handlers


# Generated at 2022-06-23 13:40:40.332710
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, type)
    assert not hasattr(AnsibleCollectionConfig, '__init__')
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:40:47.288704
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import datetime
    import json

    def _delta_handler(delta):
        assert isinstance(delta, datetime.timedelta)
        return delta

    def _json_handler(obj):
        if isinstance(obj, datetime.datetime):
            return {'__datetime__': self.isoformat()}

        return self._default_handler(obj)

    es = _EventSource()

    # Noting added, nothing should happen
    es.fire(1, 2, 3)

    es += _delta_handler

    es.fire(datetime.timedelta(days=1, seconds=3))

    es += _json_handler

    # datetime object should be serialized to json-serializable object and passed
    # on to _delta_handler, which will convert back to datetime object.
   

# Generated at 2022-06-23 13:40:56.984008
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def _handler1(self, parameter_1, parameter_2=None):
        pass

    def _handler2(self, parameter_1, parameter_2=None):
        pass

    eventSource = _EventSource()
    assert 0 == len(eventSource._handlers)

    eventSource += _handler1
    assert 1 == len(eventSource._handlers)

    eventSource += _handler1
    assert 1 == len(eventSource._handlers)

    eventSource += _handler2
    assert 2 == len(eventSource._handlers)

    try:
        eventSource += _handler2
    except ValueError:
        pass

    assert 2 == len(eventSource._handlers)



# Generated at 2022-06-23 13:41:01.233160
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    x = _EventSource()
    assert not x._handlers

    def test_handler():
        pass

    x += test_handler

    assert test_handler in x._handlers



# Generated at 2022-06-23 13:41:05.556464
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')
    assert not hasattr(AnsibleCollectionConfig, '_on_collection_load')


# return the class
AnsibleCollectionConfig = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:41:08.753971
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()

    f = lambda x: x
    g = lambda x: x

    event += f
    assert f in event._handlers
    assert g not in event._handlers

    event += f
    assert f in event._handlers
    assert g not in event._handlers



# Generated at 2022-06-23 13:41:10.437157
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    a = _EventSource()
    assert True



# Generated at 2022-06-23 13:41:11.594498
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es._handlers == set()



# Generated at 2022-06-23 13:41:14.069641
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # Compare the __init__ function of class AnsibleCollectionConfig with its
    # superclass type.
    assert AnsibleCollectionConfig.mro()[0].__init__ \
        == _AnsibleCollectionConfig.__init__

# Generated at 2022-06-23 13:41:16.092259
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig = _class_AnsibleCollectionConfig()
    assert AnsibleCollectionConfig._collection_finder == None
    assert AnsibleCollectionConfig._default_collection == None


# Generated at 2022-06-23 13:41:23.527965
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()

    event_count = [0]

    def handler_one(*args, **kwargs):
        event_count[0] += 1

    def handler_two(*args, **kwargs):
        event_count[0] += 1

    def handler_three(*args, **kwargs):
        event_count[0] += 1
        raise Exception('something bad happened')

    event_source += handler_one
    event_source += handler_two
    event_source += handler_three

    event_source.fire()

    assert event_count[0] == 3


# Generated at 2022-06-23 13:41:28.181630
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    pload = [None]
    def handler(*args, **kwargs):
        pload[0] = args

    ev = _EventSource()
    ev += handler
    ev.fire(1, 2, 3)
    assert pload[0] == (1, 2, 3)

# Generated at 2022-06-23 13:41:37.750567
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventHandler:
        def __init__(self):
            self.index = 0
            self.args = None
            self.kwargs = None

        def __call__(self, *args, **kwargs):
            self.index += 1
            self.args = args
            self.kwargs = kwargs

    e = _EventSource()
    h1 = _EventHandler()
    h2 = _EventHandler()

    e.fire(1, 2, 3, kw=4)
    assert h1.index == 0
    assert h2.index == 0

    e += h1
    e += h2

    e.fire(1, 2, 3, kw=4)
    assert h1.index == 1, h1.index
    assert h2.index == 1, h2.index
    assert h

# Generated at 2022-06-23 13:41:38.772919
# Unit test for constructor of class _EventSource
def test__EventSource():
    obj = _EventSource()

    assert not obj._handlers


# Generated at 2022-06-23 13:41:41.567900
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert not c._collection_finder
    assert not c._default_collection
    assert c._on_collection_load._handlers


# Generated at 2022-06-23 13:41:44.175759
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def test_handler(x):
        pass

    assert es._handlers == set()
    es += test_handler
    assert test_handler in es._handlers



# Generated at 2022-06-23 13:41:51.148905
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    handlers = [lambda: None, lambda: None, lambda: None]

    for index, handler in enumerate(handlers):
        es -= handler
        assert es._handlers == set(handlers[:index])

    # Test that KeyError is not raised on removal of a handler that was never added
    es -= lambda: None
    assert es._handlers == set(handlers[:len(handlers)])


# Generated at 2022-06-23 13:41:59.787635
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSource_child(object):
        def __init__(self):
            self.count = 0

        def handler(self):
            self.count += 1

    class _EventSource_child_on_exception(object):
        def __init__(self):
            self.count = 0

        def handler(self):
            self.count += 1
            raise ValueError('foo')

        def on_exception(self, handler, exc, *args, **kwargs):
            self.exc = exc
            return False

    es = _EventSource()
    c1 = _EventSource_child()
    c2 = _EventSource_child()
    c3 = _EventSource_child_on_exception()

    es += c1.handler
    es += c2.handler

    es.fire()
    assert c1

# Generated at 2022-06-23 13:42:11.542421
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0

    def handler1():
        print('handler1')

    def handler2():
        print('handler2')

    def handler3(x, y, z):
        print('handler3')
        assert x == 1
        assert y == 2
        assert z == 3

    event_source += handler1
    assert len(event_source._handlers) == 1

    event_source += handler1
    assert len(event_source._handlers) == 1

    event_source += handler2
    assert len(event_source._handlers) == 2

    event_source += handler3
    assert len(event_source._handlers) == 3

    event_source -= handler1
    assert len(event_source._handlers) == 2

    event

# Generated at 2022-06-23 13:42:15.151845
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:42:16.505260
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()

# Generated at 2022-06-23 13:42:19.961990
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    ev = _EventSource()
    assert _EventSource.__isub__.__doc__ == 'Remove the specified handler from this event source.'
    ev -= lambda: None
    ev += lambda: None
    ev -= lambda: None


# Generated at 2022-06-23 13:42:23.292969
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    handler = lambda *x, **y: None
    event += handler
    assert handler in event._handlers

    event -= handler
    assert not event._handlers


# Generated at 2022-06-23 13:42:25.867270
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class Meta(_AnsibleCollectionConfig):
        def __init__(self):
            pass

    class Test(AnsibleCollectionConfig):
        __metaclass__ = Meta

    assert Test._collection_finder is None
    assert Test._default_collection is None
    assert isinstance(Test._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:42:32.404974
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()

    assert isinstance(c._on_collection_load, _EventSource)
    assert c._collection_finder is None
    assert c._default_collection is None
    assert c.on_collection_load is c._on_collection_load
    assert c.default_collection == c._default_collection
    assert c.collection_finder == c._collection_finder
    assert isinstance(c._on_collection_load, _EventSource)
    assert isinstance(c.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:42:37.243625
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ac = AnsibleCollectionConfig()
    assert ac.__class__._collection_finder is None
    assert ac.__class__._default_collection is None
    assert isinstance(ac.__class__._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:42:41.116052
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def fn1(x):
        return x * 2

    def fn2(x):
        return x * 3

    ev = _EventSource()
    ev += fn1
    ev += fn2

    assert ev.fire(2) == [4, 6]



# Generated at 2022-06-23 13:42:42.993031
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None

# Generated at 2022-06-23 13:42:55.387562
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestException(Exception):
        pass

    class TestClass(object):
        def __init__(self):
            self.call_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1

            if self.call_count == 2:
                raise TestException()

    source = _EventSource()

    o1 = TestClass()
    o2 = TestClass()
    o3 = TestClass()

    # the expected call count is the sum of the call counts prior to handling the exception
    # and then the call count after the exception
    expected_call_count = o1.call_count + o3.call_count + o1.call_count

    source += o1
    source += o2
    source += o3

    source.fire()

    assert o1.call

# Generated at 2022-06-23 13:43:07.354252
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Ensure that _on_exception returns True for an exception, which causes the exception to be re-raised
    event_source = _EventSource()

    threw_exception = False

    exc = Exception('test')

    def handler():
        nonlocal threw_exception
        threw_exception = True
        raise exc

    event_source += handler

    try:
        event_source.fire()
    except Exception as raised:
        assert threw_exception
        assert exc is raised

    # Ensure that _on_exception does not re-raise the exception
    threw_exception = False
    event_source._on_exception = lambda h, e, *args, **kwargs: False

    try:
        event_source.fire()
    except Exception:
        assert False, 'exception not expected'

    assert threw_exception

# Generated at 2022-06-23 13:43:11.282906
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible_test.utils.unittest_classes import TestCase

    class TestClass(with_metaclass(_AnsibleCollectionConfig)):
        pass

    class TestConfig(TestCase):
        def test_init(self):
            c = TestClass()
            self.assertIsNotNone(c)

# Generated at 2022-06-23 13:43:14.328320
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    source -= source.fire

    assert source._handlers == set()


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])