

# Generated at 2022-06-23 13:33:14.331468
# Unit test for constructor of class _EventSource
def test__EventSource():
    # The constructor should initialize an empty set
    event_source = _EventSource()
    assert event_source._handlers == set()


# Generated at 2022-06-23 13:33:16.102046
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source._handlers is not None

# Generated at 2022-06-23 13:33:21.312345
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # arrange
    cls = _EventSource()
    def handler(arg1, arg2):
        pass

    # act
    result = cls.__iadd__(handler)

    # assert
    # make sure we returned the collection
    assert result is cls
    # make sure the handler is in the collection
    assert handler in result._handlers


# Generated at 2022-06-23 13:33:24.563918
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class A:
        def __call__(self):
            pass

    a = A()

    es = _EventSource()
    es += a

    assert(len(es._handlers) == 1)

    es -= a

    assert(len(es._handlers) == 0)

# Generated at 2022-06-23 13:33:30.615166
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    events = _EventSource()

    # Unit test for method fire of class _EventSource
    # with empty events.
    assert events.fire('test_args', 'test_kwargs') is None

    # Unit test for method fire of class _EventSource
    # with events that raises exception
    def function_kills_self():
        raise Exception('test_exc')

    events += function_kills_self

    try:
        events.fire()
        assert False, 'Expected an exception'
    except Exception as ex:
        assert ex.args == ('test_exc',)

# Generated at 2022-06-23 13:33:31.507117
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()


# Generated at 2022-06-23 13:33:37.692869
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = _AnsibleCollectionConfig('meta', 'name', 'bases')
    c._collection_finder = None
    c._default_collection = 'test'
    c._on_collection_load = 'test2'

    c.collection_finder = 'test3'
    c.default_collection = 'test4'
    c.on_collection_load = 'test5'

# Generated at 2022-06-23 13:33:40.591235
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    with pytest.raises(NotImplementedError):
        AnsibleCollectionConfig.collection_paths
    with pytest.raises(NotImplementedError):
        AnsibleCollectionConfig.playbook_paths

# Generated at 2022-06-23 13:33:52.047527
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            # do not want the caller to re-raise
            return False

    event_source = MyEventSource()

    event_called = []

    def handler_that_works(a, b, c):
        assert a == 1
        assert b == 2
        assert c == 3
        event_called.append(1)

    def handler_that_raises_KeyError():
        raise KeyError

    def handler_that_raises_ValueError():
        raise ValueError

    event_source += handler_that_works
    event_source += handler_that_raises_KeyError
    event_source += handler_that_raises_ValueError


# Generated at 2022-06-23 13:33:54.005981
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    obj = _EventSource()
    assert not obj._handlers

    def fake_handler():
        pass

    obj += fake_handler
    assert fake_handler in obj._handlers

# Generated at 2022-06-23 13:33:56.771178
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        AnsibleCollectionConfig()
    except TypeError:
        pass
    else:
        raise AssertionError('AnsibleCollectionConfig should not construct')

# Generated at 2022-06-23 13:33:59.783787
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def callback(*args, **kwargs):
        return (args, kwargs)
    es += callback
    assert len(es._handlers) == 1
    assert callback in es._handlers


# Generated at 2022-06-23 13:34:00.937850
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()


# Generated at 2022-06-23 13:34:03.169272
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    f = lambda: 1
    es += f
    assert f in es._handlers



# Generated at 2022-06-23 13:34:07.957623
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest:
        def __init__(self):
            event = _EventSource()
            event += self._handler

    def _handler(self, *args, **kwargs):
        if 'raise' in kwargs:
            raise RuntimeError('handler exception')

    event = _EventSourceTest()


# Generated at 2022-06-23 13:34:10.302237
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    m = AnsibleCollectionConfig()
    assert m._collection_finder is None
    assert m._default_collection is None


# Generated at 2022-06-23 13:34:14.815638
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler1(a, b):
        pass

    def handler2(a, b):
        pass

    event_source += handler1
    assert handler1 in event_source._handlers
    assert handler2 not in event_source._handlers

    event_source += handler2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers


# Generated at 2022-06-23 13:34:18.075974
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    acct = AnsibleCollectionConfig()
    assert acct.collection_finder is None
    assert acct.default_collection is None
    assert isinstance(acct.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:34:22.368178
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def func_not_in_event_source():
        pass

    event_source += func_not_in_event_source
    event_source -= func_not_in_event_source
    assert len(event_source._handlers) == 0


# Generated at 2022-06-23 13:34:26.339592
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    source = _EventSource()

    def handler1(a, b):
        pass

    def handler2(a, b):
        pass

    source += handler1
    source += handler2

    with pytest.raises(ValueError):
        source += 42



# Generated at 2022-06-23 13:34:27.531104
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()


# Generated at 2022-06-23 13:34:39.412786
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyEventSource(_EventSource):
        def __init__(self):
            super(MyEventSource, self).__init__()
            self.history = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.history.append('_on_exception - %s' % to_text(exc).strip())
            # exception is raised if we return None
            return None

    es = MyEventSource()

    def f0():
        es.history.append('f0')

    def f1(x):
        es.history.append('f1 - %s' % x)

    def f2(x, y, z=None):
        es.history.append('f2 - %s %s %s' % (x, y, z))


# Generated at 2022-06-23 13:34:43.408662
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    def Method1(a,b):
        pass

    es += Method1

    es -= Method1

# Generated at 2022-06-23 13:34:46.501848
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    fired = []
    _test_event = _EventSource()
    _test_event += lambda: fired.append(True)

    _test_event.fire()

    assert fired == [True]

# Generated at 2022-06-23 13:34:47.780607
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)

# Generated at 2022-06-23 13:34:58.386420
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Event:
        pass

    event = Event()

    def handler1(e, *args, **kwargs):
        # should be called
        assert e is event
        assert args == ('arg1', 'arg2')
        assert kwargs == {'karg1': 'varg1', 'karg2': 'varg2'}

    def handler2(e, *args, **kwargs):
        # should be called
        assert e is event
        assert args == ('arg1', 'arg2')
        assert kwargs == {'karg1': 'varg1', 'karg2': 'varg2'}

    def handler3(e, *args, **kwargs):
        # should not be called
        assert e is event
        assert args == ('arg1', 'arg2')

# Generated at 2022-06-23 13:35:06.183270
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    events = _EventSource()

    def handler_1():
        pass

    def handler_2():
        pass

    events += handler_1

    assert handler_1 in events._handlers

    events += handler_1

    assert handler_1 in events._handlers

    events -= handler_1

    assert handler_1 not in events._handlers

    events -= handler_2

    assert handler_2 not in events._handlers



# Generated at 2022-06-23 13:35:14.207559
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def do_nothing(*_args, **_kwargs):
        pass

    def raises_exception(*_args, **_kwargs):
        raise Exception

    def returns_false(*_args, **_kwargs):  # pylint: disable=unused-argument
        return False

    def returns_false_on_even_exceptions(_handler, exception_object, *_args, **_kwargs):  # pylint: disable=unused-argument
        if exception_object.args[0] % 2 == 0:
            return False

        return True

    def returns_true(*_args, **_kwargs):  # pylint: disable=unused-argument
        return True

    def raises_connection_error(*_args, **_kwargs):
        raise ConnectionError


# Generated at 2022-06-23 13:35:15.560809
# Unit test for constructor of class _EventSource
def test__EventSource():
    event = _EventSource()
    assert event._handlers == set()

# Generated at 2022-06-23 13:35:17.317671
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)


# Generated at 2022-06-23 13:35:19.611812
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # _AnsibleCollectionConfig() is called in the header of this file
    type.__init__(_AnsibleCollectionConfig, 'AnsibleCollectionConfig', (object,))

# Generated at 2022-06-23 13:35:23.891890
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def to_upper(s):
        return s.upper()

    event_source = _EventSource()
    event_source += to_upper
    assert event_source.fire("test") == None
    del event_source



# Generated at 2022-06-23 13:35:28.237941
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()

    def foo():
        pass
    event += foo
    assert foo in event._handlers
    event -= foo
    assert foo not in event._handlers

    event -= foo  # still works when not in the set
    assert foo not in event._handlers


# Generated at 2022-06-23 13:35:31.425652
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert cls._collection_finder is None
    assert cls._on_collection_load is not None


# Generated at 2022-06-23 13:35:36.497338
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.playbook_paths == []

# Generated at 2022-06-23 13:35:47.420866
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class EventListener(object):

        def __init__(self):
            self.reset()

        def reset(self):
            self.fired = False
            self.args = ()
            self.kwargs = {}

        def handle_event(self, *args, **kwargs):
            self.fired = True
            self.args = args
            self.kwargs = kwargs

        def __str__(self):
            return '({0}, {1}, {2})'.format(self.fired, self.args, self.kwargs)

    def test_single_listener():
        event = _EventSource()
        listener = EventListener()
        event += listener.handle_event
        event.fire(1, 2, c=3)

        assert listener.args == (1, 2)

# Generated at 2022-06-23 13:35:54.178002
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class ES(_EventSource):
        def __init__(self):
            super(ES, self).__init__()
            self._val = 10

        def _on_exception(self, handler, exc, *args, **kwargs):
            return True

        def handler_1(self):
            self._val += 1

        def handler_2(self):
            self._val += 2

    e = ES()
    e += e.handler_1
    e += e.handler_2
    assert e._handlers == {e.handler_1, e.handler_2}

    e -= e.handler_1
    assert e._handlers == {e.handler_2}

    e -= e.handler_1
    assert e._handlers == {e.handler_2}

    e -= e.handler_2
    assert e

# Generated at 2022-06-23 13:35:56.411354
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    event = _EventSource()
    event += lambda: None
    event += lambda: None
    event -= lambda: None

    # assertions
    assert len(event._handlers) == 1

# Generated at 2022-06-23 13:36:07.774949
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def _handler1():
        pass

    def _handler2():
        pass

    e = _EventSource()
    e += _handler1
    assert _handler1 in e._handlers
    assert _handler2 not in e._handlers

    e += _handler2
    assert _handler1 in e._handlers
    assert _handler2 in e._handlers

    e -= _handler1
    assert _handler1 not in e._handlers
    assert _handler2 in e._handlers

    e -= _handler2
    assert _handler1 not in e._handlers
    assert _handler2 not in e._handlers


# Generated at 2022-06-23 13:36:10.820029
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()

    def handler1(message):
        pass

    def handler2(message):
        pass

    e += handler1
    e += handler2
    assert len(e._handlers) == 2


# Generated at 2022-06-23 13:36:14.684356
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(*args):
        raise RuntimeError()

    _EventSource()
    _EventSource() + handler
    _EventSource() - handler

# Generated at 2022-06-23 13:36:24.291188
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    '''Test method fire of class _EventSource in a standalone process'''

    # Create an object of class _EventSource
    event_source = _EventSource()

    # Define a method that raises an exception
    def test_exception(*args, **kwargs):
        raise Exception

    # Add the method to the event source
    event_source += test_exception

    # Call method fire on the event source with a named argument
    # We expect the method to raise an exception
    try:
        event_source.fire(my_named_argument='my_value')
    except:
        # The method fired on the event source raised an exception
        # as expected
        return

    # We should never reach this point because
    # method test_exception should have raised an exception
    assert False



# Generated at 2022-06-23 13:36:28.607448
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    try:
        event_source = _EventSource()
        event_source += 'func'
    except ValueError:
        pass
    else:
        raise AssertionError('Accept non-callable object')

    event_source += lambda: None
    if len(event_source._handlers) != 1:
        raise AssertionError('Accept callable object')



# Generated at 2022-06-23 13:36:32.356426
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    try:
        # Test constructor (__init__) and code that runs our metaclass (__init__)
        AnsibleCollectionConfig()
        return True
    except Exception:
        return False


# Generated at 2022-06-23 13:36:36.157518
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class __AnsibleCollectionConfigTester(AnsibleCollectionConfig):
        pass

    t = __AnsibleCollectionConfigTester()
    assert isinstance(t._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:36:39.185707
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestAnsibleCollectionConfig(_AnsibleCollectionConfig):
        pass
    assert TestAnsibleCollectionConfig._collection_finder is None
    assert TestAnsibleCollectionConfig._default_collection is None

# Generated at 2022-06-23 13:36:44.245537
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()
    assert AnsibleCollectionConfig is type(c)
    assert AnsibleCollectionConfig._on_collection_load is c.__class__.on_collection_load
    assert isinstance(c.__class__.on_collection_load, _EventSource)



# Generated at 2022-06-23 13:36:53.376196
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def func(arg):
        return arg

    evt = _EventSource()
    assert len(evt._handlers) == 0
    evt += func
    assert len(evt._handlers) == 1
    assert func in evt._handlers
    evt += func
    assert len(evt._handlers) == 1
    evt += func
    assert len(evt._handlers) == 1
    evt -= func
    assert len(evt._handlers) == 0
    evt -= func
    assert len(evt._handlers) == 0


# Generated at 2022-06-23 13:37:01.847884
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible_test.lib.ansible_test._data import data_context

    with data_context(dict(collection_finder=None, default_collection=None, on_collection_load=None)):
        assert AnsibleCollectionConfig.collection_finder is None
        assert AnsibleCollectionConfig.default_collection is None
        assert AnsibleCollectionConfig.on_collection_load is None
        assert AnsibleCollectionConfig.collection_paths == []
        assert AnsibleCollectionConfig.playbook_paths == []

        AnsibleCollectionConfig.collection_finder = 'foo'
        AnsibleCollectionConfig.default_collection = 'foo'
        AnsibleCollectionConfig.on_collection_load = 'foo'
        AnsibleCollectionConfig.collection_paths = 'foo'
        AnsibleCollectionConfig.playbook_paths = 'foo'


# Generated at 2022-06-23 13:37:05.909001
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    events = _EventSource()

    def t1(v):
        assert v == 1
        return 1

    def t2(v):
        assert v == 1
        return 1

    events += t1
    events += t2

    events.fire(1)

    try:
        events += None
        assert False, 'did not throw exception on None'
    except ValueError:
        pass

    try:
        events += 3
        assert False, 'did not throw exception on integer'
    except ValueError:
        pass


# Generated at 2022-06-23 13:37:10.460294
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert hasattr(AnsibleCollectionConfig, '_default_collection')
    assert hasattr(AnsibleCollectionConfig, '_on_collection_load')
    assert AnsibleCollectionConfig.default_collection == None


# Generated at 2022-06-23 13:37:18.854490
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    f1 = lambda: None
    f2 = lambda: None
    es += f1
    es += f2
    assert f1 in es._handlers
    assert f2 in es._handlers
    es -= f2
    assert f1 in es._handlers
    assert f2 not in es._handlers
    es -= f2
    assert f1 in es._handlers
    assert f2 not in es._handlers
    es -= f1
    assert f1 not in es._handlers
    assert f2 not in es._handlers
    es -= f1
    assert f1 not in es._handlers
    assert f2 not in es._handlers

test__EventSource___isub__()

# Generated at 2022-06-23 13:37:22.942607
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    # constructor is called from within the with_metaclass() function
    class _TestClass(with_metaclass(_AnsibleCollectionConfig)):
        pass

    assert isinstance(_TestClass._on_collection_load, _EventSource)
    assert _TestClass._collection_finder is None
    assert _TestClass._default_collection is None



# Generated at 2022-06-23 13:37:24.781624
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert not event_source._handlers

# Unit tests for class _AnsibleCollectionConfig

# Generated at 2022-06-23 13:37:26.908826
# Unit test for constructor of class _EventSource
def test__EventSource():
    s = _EventSource()
    assert callable(s)

# Generated at 2022-06-23 13:37:35.718662
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    c = _AnsibleCollectionConfig('foo', 'bar', 'baz')
    c.collection_finder = 'collection_finder'
    assert c.collection_finder == 'collection_finder'

    c.default_collection = 'test_collection'
    assert c.default_collection == 'test_collection'

    assert c.on_collection_load.__iadd__('test') == c.on_collection_load

    c.on_collection_load += 'add'
    assert 'add' in c.on_collection_load._handlers

    c.on_collection_load -= 'add'
    assert 'add' not in c.on_collection_load._handlers

    assert c.playbook_paths == []

    with pytest.raises(NotImplementedError):
        c.collection_paths


# Generated at 2022-06-23 13:37:37.929114
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_event_source = _EventSource()
    assert test_event_source
    assert test_event_source._handlers



# Generated at 2022-06-23 13:37:39.341607
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    e = _EventSource()
    e.fire()



# Generated at 2022-06-23 13:37:42.572206
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    event_handler = lambda s: s
    event_source += event_handler
    event_source -= event_handler
    assert event_source._handlers == set()


# Generated at 2022-06-23 13:37:46.339588
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    assert not es._handlers
    def event1(arg): pass
    def event2(arg): pass
    es += event1
    assert es._handlers == {event1}
    es += event2
    assert es._handlers == {event1, event2}



# Generated at 2022-06-23 13:37:47.819621
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()
    assert ev._handlers == set()


# Generated at 2022-06-23 13:37:54.429640
# Unit test for constructor of class _EventSource
def test__EventSource():
    # These two variables need to be outside the function to avoid UnboundLocalError
    global handler
    handler = False

    @AnsibleCollectionConfig.on_collection_load.fire
    def test():
        handler = True

    assert handler == False
    test()
    assert handler == True

# Unit tests for AnsibleCollectionConfig.collection_finder and AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-23 13:37:56.766839
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:38:03.376581
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def _handler():
        pass

    event_source = _EventSource()
    event_source += _handler
    assert event_source._handlers == {_handler}, 'event_source._handlers did not contain _handler'

    with pytest.raises(ValueError):
        event_source += 'not callable'


# Generated at 2022-06-23 13:38:07.787288
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.playbook_paths == []
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None

# Generated at 2022-06-23 13:38:14.692949
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    l = [1, 2, 3]

    def f1(a, b):
        l.append(a)
    def f2(a, b):
        l.append(b)

    event_source += f1
    event_source += f2

    event_source.fire(1, 2)

    assert l == [1, 2, 3, 1, 2]

    event_source -= f2

    event_source.fire(3, 4)

    assert l == [1, 2, 3, 1, 2, 1, 3]

# Generated at 2022-06-23 13:38:15.646908
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    AnsibleCollectionConfig()

# Generated at 2022-06-23 13:38:19.912583
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()

    def handler1(*args, **kwargs):
        pass

    event_source += handler1
    assert handler1 in event_source._handlers

    event_source -= handler1
    assert handler1 not in event_source._handlers


# Generated at 2022-06-23 13:38:23.712041
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class Dummy:
        def handler(self, *args, **kwargs):
            pass

    dummy = Dummy()
    event_source = _EventSource()
    event_source += dummy.handler

    event_source -= dummy.handler
    assert list(event_source._handlers) == []
    event_source -= dummy.handler
    assert list(event_source._handlers) == []


# Generated at 2022-06-23 13:38:26.653377
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source is not None


# Generated at 2022-06-23 13:38:37.326350
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # test basic successful execution
    def handler1(a, b):
        assert a == 1
        assert b == 2
        v.append(1)

    def handler2(a, b):
        assert a == 1
        assert b == 2
        v.append(2)

    v = []
    es = _EventSource()
    es += handler1
    es += handler2
    es.fire(1, b=2)
    assert v == [1, 2]
    v = []

    # test exception from one handler doesn't prevent execution of subsequent handlers
    def handler3(a, b):
        v.append(3)
        raise AssertionError('handler3 raised exception')

    def handler4(a, b):
        v.append(4)

    es = _EventSource()
    es += handler3
    es

# Generated at 2022-06-23 13:38:45.253994
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler_1(*args, **kwargs):
        raise NotImplementedError()

    def handler_2(*args, **kwargs):
        raise NotImplementedError()

    def handler_3(*args, **kwargs):
        raise NotImplementedError()

    event = _EventSource()

    event += handler_1
    event += handler_2
    event += handler_3

    event -= handler_2
    event -= handler_3

    event -= handler_2

    assert set() == event._handlers

# Generated at 2022-06-23 13:38:53.476303
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Check the normal case
    event_source = _EventSource()
    assert len(event_source._handlers) == 0
    def handler1(arg1, arg2):
        pass
    event_source += handler1
    assert len(event_source._handlers) == 1
    assert event_source._handlers.pop() == handler1

    # Check that adding a non-callable handler raises a ValueError
    event_source = _EventSource()
    assert len(event_source._handlers) == 0
    non_callable = 'non-callable string'
    try:
        event_source += non_callable
    except ValueError:
        assert True
    else:
        assert False
    assert len(event_source._handlers) == 0

    # Check that adding a non-callable handler does not add it to

# Generated at 2022-06-23 13:38:54.222602
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()

# Generated at 2022-06-23 13:38:55.006451
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    t = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:38:57.052758
# Unit test for constructor of class _EventSource
def test__EventSource():
    # Check that _EventSource.__init__ initializes _handlers, an empty set
    e = _EventSource()
    assert e._handlers == set()


# Generated at 2022-06-23 13:39:04.694310
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def test_canary(msg):
        print(msg)

    def test_error(msg):
        raise Exception('test error')

    event = _EventSource()
    event += test_canary
    event += test_error
    event += test_canary

    try:
        event.fire('hello')
    except Exception as e:
        print(e)
    finally:
        print('Done')

# Generated at 2022-06-23 13:39:09.316935
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    import pytest

    event_source = _EventSource()

    def handler_a(*args, **kwargs):
        pass

    event_source += handler_a



# Generated at 2022-06-23 13:39:12.910963
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Base(object):
        pass

    Base = _AnsibleCollectionConfig('meta', 'name', (Base,))
    # pylint: disable=unused-variable
    base = Base()


# Generated at 2022-06-23 13:39:13.947680
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:39:20.110033
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    source += 1
    source += 2
    source += 3
    assert source._handlers == set([1, 2, 3])
    source -= 2
    assert source._handlers == set([1, 3])
    source -= 4
    assert source._handlers == set([1, 3])
    source -= 1
    assert source._handlers == set([3])
    source -= 3
    assert source._handlers == set()


# Generated at 2022-06-23 13:39:27.421603
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _TestEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            raise RuntimeError('unreachable')

    esrc = _TestEventSource()
    handler1 = lambda: None
    handler2 = lambda: None
    esrc += handler1
    assert len(esrc._handlers) == 1
    esrc -= handler2
    assert len(esrc._handlers) == 1
    esrc -= handler1
    assert len(esrc._handlers) == 0



# Generated at 2022-06-23 13:39:35.776801
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class DummyFinder(object):
        def __init__(self):
            self._n_collection_paths = []
            self._n_playbook_paths = []

    finder = DummyFinder()

    def on_collection_load(collection_path, collection_name):
        pass

    class DummyClass(AnsibleCollectionConfig):
        pass

    # assign values to properties
    DummyClass.collection_finder = finder
    DummyClass.on_collection_load += on_collection_load

    # verify properties
    assert DummyClass.collection_finder is finder
    assert DummyClass.collection_paths == []
    assert DummyClass.default_collection is None
    assert DummyClass.on_collection_load is DummyClass._on_collection_load
    assert DummyClass.playbook

# Generated at 2022-06-23 13:39:45.316098
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    count = {'calls': 0}
    def handler1(count):
        count['calls'] += 1

    def handler2(count):
        count['calls'] += 1

    def handler3(count):
        raise ValueError('oops')

    def handler4(count):
        count['calls'] += 1
        raise ValueError('oops')

    def handler5(count):
        count['calls'] += 1
        return False

    def handler6(count):
        count['calls'] += 1
        raise ValueError('oops')
        return True

    def handler7(count):
        count['calls'] += 1
        return False
        raise ValueError('oops')

    evt = _EventSource()
    evt += handler1
    evt.fire(count)
    assert count['calls'] == 1

# Generated at 2022-06-23 13:39:51.190402
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()
    assert a._collection_finder is None
    assert a._default_collection is None
    assert isinstance(a._on_collection_load, _EventSource)

# Unit tests for properties of class AnsibleCollectionConfig
# We have tested these previously, so just run the code

# Generated at 2022-06-23 13:40:01.319804
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler_one():
        global handler_one_called
        handler_one_called = True

    def handler_two():
        global handler_two_called
        handler_two_called = True

    def handler_three():
        global handler_three_called
        handler_three_called = True
        raise Exception("Exception in handler_three")

    handler_one_called = False
    handler_two_called = False
    handler_three_called = False

    event_source = _EventSource()
    event_source += handler_one
    event_source += handler_two
    event_source += handler_three

    event_source.fire()

    assert (handler_one_called is True)
    assert (handler_two_called is True)
    assert (handler_three_called is False)


# Generated at 2022-06-23 13:40:02.521862
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # TODO: implement
    pass


# Generated at 2022-06-23 13:40:11.431262
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    def foo():
        pass

    def bar():
        pass

    es += foo
    assert foo in es._handlers, "foo not in _handlers"

    es += bar
    assert foo in es._handlers, "foo not in _handlers"
    assert bar in es._handlers, "bar not in _handlers"

    es += bar
    assert foo in es._handlers, "foo not in _handlers"
    assert bar in es._handlers, "bar not in _handlers"



# Generated at 2022-06-23 13:40:16.657187
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda x: x
    assert len(e._handlers) == 1

    try:
        e += "foo"
    except ValueError:
        pass
    else:
        assert False  # should have thrown



# Generated at 2022-06-23 13:40:18.939219
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.on_collection_load._handlers



# Generated at 2022-06-23 13:40:30.392999
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # given
    class Bar:
        def fn(self):
            pass

    callable_target = Bar()
    eventsource = _EventSource()

    def foo1(value):
        pass

    def foo2(value):
        pass

    eventsource += foo1
    eventsource += foo2

    assert 2 == len(eventsource._handlers)
    assert foo1 in eventsource._handlers
    assert foo2 in eventsource._handlers

    # when - then
    eventsource -= callable_target.fn  # callable_target must be instance of Bar
    assert 2 == len(eventsource._handlers)
    assert foo1 in eventsource._handlers
    assert foo2 in eventsource._handlers

    # when - then
    eventsource -= foo1
    assert 1 == len(eventsource._handlers)

# Generated at 2022-06-23 13:40:34.227732
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # We have to have a reference to the class in order to call its __init__ method
    def instantiate(cls):
        return cls()

    result = instantiate(AnsibleCollectionConfig)

    assert result is not None
    assert result.__class__ == AnsibleCollectionConfig
    assert result._collection_finder is None
    assert result._default_collection is None
    assert isinstance(result._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:40:35.552830
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig


# TODO: implement this

# Generated at 2022-06-23 13:40:45.324924
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Test that an exception is re-raised when _on_exception returns True
    def on_exception(handler, ex, *args, **kwargs):
        return True

    event_source = _EventSource()
    event_source._on_exception = on_exception

    def handler(x, y):
        if x == y:
            raise ValueError('x cannot be equal to y')

        return x + y

    event_source += handler

    try:
        event_source.fire(1, 1)
    except Exception:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # Test that an exception is swallowed when _on_exception returns False
    def on_exception(handler, ex, *args, **kwargs):
        return False

    event_source = _EventSource()

# Generated at 2022-06-23 13:40:47.431248
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert not es._handlers



# Generated at 2022-06-23 13:40:57.867845
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler_one(arg):
        pass

    def handler_two(arg):
        pass

    def handler_three(arg):
        pass

    class Test():

        def __init__(self):
            self.event_source = _EventSource()

        def set_up(self):
            self.event_source += handler_one
            self.event_source += handler_two

        def test_one(self):
            self.event_source -= handler_one
            assert len(self.event_source._handlers) == 1

        def test_two(self):
            self.event_source -= handler_three
            assert len(self.event_source._handlers) == 2

        def test_three(self):
            self.event_source -= handler_one
            self.event_source -= handler_two
            assert len

# Generated at 2022-06-23 13:41:00.981894
# Unit test for constructor of class _EventSource
def test__EventSource():
    try:
        _EventSource()
    except Exception as e:
        raise AssertionError('Some unexpected exception raised:', e)



# Generated at 2022-06-23 13:41:06.085362
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    _EventSource___isub__.counter = 0

    def callback():
        _EventSource___isub__.counter += 1

    event = _EventSource()
    event += callback
    event()
    assert _EventSource___isub__.counter is 1
    event -= callback
    event()
    assert _EventSource___isub__.counter is 1



# Generated at 2022-06-23 13:41:09.819605
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    event -= 'notcallable'
    assert not event._handlers, "__isub__ should silently handle un-callable remove handlers"



# Generated at 2022-06-23 13:41:19.352143
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class _NotImplementedError(Exception):
        pass

    class _ValueError(Exception):
        pass

    class _config1(object):
        __metaclass__ = _AnsibleCollectionConfig

        def test_setter(self):
            raise _NotImplementedError()

        @property
        def collection_finder(self):
            return self.test_setter()

        @collection_finder.setter
        def collection_finder(self, value):
            self.test_setter()

        @property
        def playbook_paths(self):
            return self.test_setter()

        @playbook_paths.setter
        def playbook_paths(self, value):
            self.test_setter()

        @property
        def on_collection_load(self):
            return self.test_

# Generated at 2022-06-23 13:41:32.305155
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _TestHandler:
        def __init__(self, success=True):
            self._success = success

        def __call__(self, *args, **kwargs):
            if not self._success:
                raise Exception('error')

    handler1 = _TestHandler()
    handler2 = _TestHandler()
    handler3 = _TestHandler(False)
    evt = _EventSource()
    evt += handler1
    evt += handler2
    evt += handler3

    assert handler2 in evt._handlers
    assert handler1 in evt._handlers
    assert handler3 in evt._handlers

    try:
        evt.fire()
    except Exception as ex:
        assert 'error' in to_text(ex)

    evt -= handler1
    assert handler2 in evt._handlers


# Generated at 2022-06-23 13:41:35.759734
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:41:45.688150
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    # We need to trigger the metaclass initialization logic to populate
    # the event source on a class, so we can't directly test the event source class.
    # Instead, we will create a trivial subclass of AnsibleCollectionConfig
    # and use that as the subject of our test.
    class TestAnsibleCollectionConfig(AnsibleCollectionConfig):
        pass

    # We are going to use a simple function object as our handler.
    test_handler = lambda *a, **kw: None

    # We need to populate the event source on the class.
    # We will use 'on_collection_load' for testing, but any event source will do.
    TestAnsibleCollectionConfig.on_collection_load += test_handler

    # Confirm that the handler is present on the event source.
    assert test_handler in TestAnsibleCollectionConfig.on_

# Generated at 2022-06-23 13:41:49.231505
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ansible_collection_config = AnsibleCollectionConfig()

    assert ansible_collection_config._on_collection_load._handlers == set()

    assert isinstance(ansible_collection_config.on_collection_load, _EventSource)


# Generated at 2022-06-23 13:41:59.009014
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    def handler_one(arg_one, arg_two, **kwargs):
        assert arg_one == 'one'
        assert arg_two == 'two'
        kwargs['one'] = 'one'
        return kwargs

    def handler_two(arg_one, arg_two, **kwargs):
        assert arg_one == 'one'
        assert arg_two == 'two'
        kwargs['two'] = 'two'
        return kwargs

    def handler_three(arg_one, arg_two, **kwargs):
        assert arg_one == 'one'
        assert arg_two == 'two'
        kwargs['three'] = 'three'
        return kwargs

    es = _EventSource()
    es += handler_one
    es += handler_two
    es += handler_three

# Generated at 2022-06-23 13:42:10.415459
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import ansible.utils.collection_loader.finder as _finder
    import ansible_test._util.target.legacy_collection_loader.finder as _test_finder

    # verify that __init__ works as expected
    assert _finder.AnsibleCollectionConfig._collection_finder is None
    assert _finder.AnsibleCollectionConfig._default_collection is None
    assert _test_finder.AnsibleCollectionConfig._collection_finder is None
    assert _test_finder.AnsibleCollectionConfig._default_collection is None

    assert _finder.AnsibleCollectionConfig.on_collection_load._handlers == set()
    assert _test_finder.AnsibleCollectionConfig.on_collection_load._handlers == set()



# Generated at 2022-06-23 13:42:13.361908
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert len(e._handlers) == 0

    def f():
        pass
    e += f
    assert len(e._handlers) == 1
    assert f in e._handlers


# Generated at 2022-06-23 13:42:24.966815
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Create a class which is a subclass of _EventSource
    class ES(_EventSource): pass

    # Create a class which will raise an exception when calling
    class ExceptioningHandler:
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True
            raise ValueError('a value error')

        def verify(self):
            assert self.called

    # Create an instance of ES
    es = ES()

    # Create an instance of ExceptioningHandler
    ee = ExceptioningHandler()

    # set handler to an ExceptioningHandler
    es += ee

    # call fire, but it should raise an exception because of the ExceptioningHandler
    # We catch the exception so we can make an assertion
    caught = False

# Generated at 2022-06-23 13:42:26.160090
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert isinstance(_EventSource(), _EventSource)


# Generated at 2022-06-23 13:42:32.730570
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    _EventSource___isub___test_instance = _EventSource()

    def _EventSource___isub___test_handler1(arg1, arg2):
        pass

    def _EventSource___isub___test_handler2(arg1, arg2):
        pass

    # no exception, handler already removed
    _EventSource___isub___test_instance -= _EventSource___isub___test_handler1

    # no exception, handler does not exist
    _EventSource___isub___test_instance -= _EventSource___isub___test_handler2

# Generated at 2022-06-23 13:42:33.841592
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig is not None



# Generated at 2022-06-23 13:42:35.647335
# Unit test for constructor of class _EventSource
def test__EventSource():
    from ansible.module_utils.six import ensure_str
    _EventSource()

# Generated at 2022-06-23 13:42:44.854756
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    my_config = AnsibleCollectionConfig()

    assert my_config.collection_finder is None
    assert my_config.collection_paths == []
    assert my_config.default_collection is None
    assert my_config.playbook_paths == []
    assert my_config.on_collection_load is not None

    try:
        my_config.collection_paths = 'foo'
        assert False
    except NotImplementedError:
        pass

    try:
        my_config.playbook_paths = 'foo'
        assert False
    except NotImplementedError:
        pass

    try:
        my_config.on_collection_load = 'foo'
        assert False
    except ValueError:
        pass


# Generated at 2022-06-23 13:42:48.539795
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None

# Unit test Exception handler

# Generated at 2022-06-23 13:42:49.611538
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig()

# Generated at 2022-06-23 13:42:50.710302
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cfg = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:42:57.218049
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    src = _EventSource()
    # empty source
    assert not src._handlers

    # add callable
    def dummy():
        pass
    src += dummy
    assert src._handlers == {dummy}

    # add existing callable
    src += dummy
    assert src._handlers == {dummy}

    # try to add something that isn't callable
    with pytest.raises(ValueError):
        src += 'foo'



# Generated at 2022-06-23 13:43:06.806143
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config_cls = AnsibleCollectionConfig()
    # Test AnsibleCollectionConfig metaclass
    assert not config_cls._collection_finder
    assert not config_cls._default_collection
    assert not config_cls._collection_paths
    assert not config_cls._playbook_paths

    # Test AnsibleCollectionConfig metaclass setter
    config_cls._collection_finder = 'test'
    assert config_cls._collection_finder == 'test'

    # Test AnsibleCollectionConfig metaclass getter
    config_cls._collection_finder = 'test'
    assert config_cls.collection_finder == 'test'


# Generated at 2022-06-23 13:43:13.876921
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    event = _EventSource()

    # verify empty
    assert not event._handlers

    # verify handler function allowed
    def handler():
        pass
    event += handler
    assert handler in event._handlers

    # verify handler lambda allowed
    event += lambda: None
    assert handler in event._handlers

    # verify handler method allowed
    class Handler:
        def handler(self):
            pass
    handler = Handler().handler
    event += handler
    assert handler in event._handlers

    # verify handler function from class method allowed
    class Handler:
        def handler(self):
            pass
    handler = Handler().handler
    event += handler
    assert handler in event._handlers

