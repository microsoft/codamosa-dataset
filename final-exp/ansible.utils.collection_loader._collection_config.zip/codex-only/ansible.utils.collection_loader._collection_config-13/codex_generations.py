

# Generated at 2022-06-23 13:33:15.620014
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    @add_metaclass(_AnsibleCollectionConfig)
    class A(object):
        pass
    a = A()
    assert a._collection_finder is None
    assert a._default_collection is None
    assert isinstance(a._on_collection_load, _EventSource)


# Generated at 2022-06-23 13:33:22.456434
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestPlugin:
        def __init__(self):
            self._event_fired_count = 0

        def __call__(self, *args, **kwargs):
            self._event_fired_count += 1

    es = _EventSource()
    tp = _TestPlugin()

    assert tp._event_fired_count == 0
    assert len(es._handlers) == 0

    # test addition of event handler
    es += tp
    assert tp._event_fired_count == 0
    assert len(es._handlers) == 1

    # test fire of event
    es.fire(1, 2, three=4)
    assert tp._event_fired_count == 1
    assert len(es._handlers) == 1

    # test fire of event a second time

# Generated at 2022-06-23 13:33:25.786238
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler(value, **kwargs):
        raise ValueError()

    event = _EventSource()
    event += handler

    assert 1 == len(event._handlers)

    event -= handler

    assert 0 == len(event._handlers)

# Generated at 2022-06-23 13:33:28.805293
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # arrange
    es = _EventSource()
    def handler():
        pass

    # act
    es += handler

    # assert
    actual = es._handlers
    expected = set([handler])
    assert actual == expected


# Generated at 2022-06-23 13:33:34.188465
# Unit test for constructor of class _EventSource
def test__EventSource():
    EventSource = _EventSource()
    try:
        EventSource += "invalid"
    except ValueError:
        print("Expected ValueError exception has been thrown")
    else:
        assert False, "Expected ValueError to be thrown"

    EventSource = _EventSource()
    assert EventSource._handlers == set()

# Generated at 2022-06-23 13:33:35.571559
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, object)



# Generated at 2022-06-23 13:33:44.201422
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # create the _EventSource instance to test
    es = _EventSource()

    # create a test handler that counts how many times it is called
    call_counter = 0
    def handler(test_event, test_msg):
        nonlocal call_counter
        call_counter += 1

    # add our handler to the _EventSource
    es += handler

    # fire our event
    es.fire('test event', 'test message')
    assert call_counter == 1

    # fire our event again with a different message
    es.fire('test event', 'test message 2')
    assert call_counter == 2

    # remove the handler
    es -= handler

    # fire our event again
    es.fire('test event', 'test message 3')
    assert call_counter == 2



# Generated at 2022-06-23 13:33:45.485014
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    type('dummy', (_AnsibleCollectionConfig,), {})

# Generated at 2022-06-23 13:33:46.935608
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()

# Generated at 2022-06-23 13:33:52.006519
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)

# Generated at 2022-06-23 13:34:01.738261
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    x = _AnsibleCollectionConfig('name', (object, ), {})

    assert isinstance(x, type)
    assert x.__name__ == 'name'
    assert x.__bases__ == (object,)
    assert x.__dict__ == {'__module__': 'ansible.module_utils.common.collection_loader._AnsibleCollectionConfig',
                          '__doc__': None}

    # create an independent subclass for testing
    class SubClass(with_metaclass(_AnsibleCollectionConfig)):
        pass

    sub_class_instance = SubClass()
    assert '_collection_finder' in dir(sub_class_instance)
    assert '_default_collection' in dir(sub_class_instance)
    assert '_on_collection_load' in dir(sub_class_instance)

# Generated at 2022-06-23 13:34:03.573809
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda x: print(x)


# Generated at 2022-06-23 13:34:06.659809
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handle_event(arg1, arg2):
        pass

    event_source = _EventSource()
    event_source += handle_event
    event_source -= handle_event
    event_source.fire(5, 6)


# Generated at 2022-06-23 13:34:13.717938
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestClass:
        def __init__(self):
            self.events = 0

        def event_handler(self):
            self.events += 1

    # event handler with no arguments
    event_source = _EventSource()
    test_obj = _TestClass()
    event_source += test_obj.event_handler
    assert test_obj.events == 0
    event_source.fire()
    assert test_obj.events == 1

    # event handler with arguments
    test_obj = _TestClass()
    event_source = _EventSource()
    event_source += test_obj.event_handler
    assert test_obj.events == 0
    event_source.fire('foo')
    assert test_obj.events == 0

    def event_handler(arg):
        test_obj.events += arg

    test_

# Generated at 2022-06-23 13:34:14.688703
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')

# Generated at 2022-06-23 13:34:21.496379
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import pytest

    es = _EventSource()

    def _handler_1(_, exc, *args, **kwargs):
        pass

    es += _handler_1

    assert len(es._handlers) == 1
    es -= _handler_1
    assert len(es._handlers) == 0

    es += _handler_1

    with pytest.raises(ValueError):
        # pylint: disable=unsupported-assignment-operation
        es -= 'xyz'



# Generated at 2022-06-23 13:34:25.753284
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Set up
    event = _EventSource()
    called = []

    def _handler(value):
        called.append(value)

    # Execute
    event += _handler
    event.fire('foo')

    # Verify
    assert called[0] == 'foo'



# Generated at 2022-06-23 13:34:31.032739
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = ansible.collection_loader._AnsibleCollectionConfig(type, 'foo', ())
    assert config.__class__ == ansible.collection_loader._AnsibleCollectionConfig
    assert config._collection_finder is None
    assert config._default_collection is None
    assert config.collection_finder is None
    assert config.collection_paths is None
    assert config.default_collection is None
    assert config.on_collection_load is None
    assert config.playbook_paths is None


# Generated at 2022-06-23 13:34:36.130449
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    aconfig1 = AnsibleCollectionConfig()
    assert aconfig1._collection_finder is None
    assert aconfig1._default_collection is None
    assert isinstance(aconfig1._on_collection_load, _EventSource)
    assert aconfig1.on_collection_load is aconfig1._on_collection_load



# Generated at 2022-06-23 13:34:37.890798
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es is not None


# Generated at 2022-06-23 13:34:40.775594
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class Foo(AnsibleCollectionConfig):
        pass
    assert Foo._collection_finder is None
    assert Foo._default_collection is None
    assert Foo._on_collection_load



# Generated at 2022-06-23 13:34:50.865179
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    import sys
    import unittest

    class TestAnsibleCollectionConfig(unittest.TestCase):
        def setUp(self):
            sys.modules.pop('ansible.collections.config', None)

        def test__AnsibleCollectionConfig(self):
            import ansible.collections.config

            self.assertIsInstance(ansible.collections.config.on_collection_load, _EventSource)
            self.assertEqual(ansible.collections.config.collection_paths, [])
            self.assertIsNone(ansible.collections.config.default_collection)
            self.assertEqual(ansible.collections.config.playbook_paths, [])

    suite = unittest.TestLoader().loadTestsFromTestCase(TestAnsibleCollectionConfig)

# Generated at 2022-06-23 13:35:00.569621
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import types
    import pytest

    # Create an instance of _EventSource
    source = _EventSource()

    # Create a callable instance
    def handler(x):
        return x

    # Ensure we can add a handler
    source += handler
    assert handler in source._handlers

    # Ensure bad handlers are not added
    # Invalid types
    for bad_handler in [None, 'abc', b'abc', 0, 1000, 1.0, {}, []]:
        with pytest.raises(ValueError):
            source += bad_handler

    # Ensure we can delete a handler
    source -= handler
    assert handler not in source._handlers

    # Ensure we can delete a handler that doesn't exist
    source -= handler
    assert handler not in source._handlers

    # Create a new callable instance

# Generated at 2022-06-23 13:35:07.719405
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestMockedAnsibleCollectionConfig(_AnsibleCollectionConfig):
        def __init__(self):
            super(TestMockedAnsibleCollectionConfig, self).__init__('', '', '')

    sut = TestMockedAnsibleCollectionConfig()

    assert sut._collection_finder is None
    assert sut._default_collection is None
    assert isinstance(sut._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:35:10.451372
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    empty = True

    def handler():
        nonlocal empty
        empty = False

    es += handler
    es -= handler
    es.fire()
    assert empty

# Generated at 2022-06-23 13:35:13.262252
# Unit test for constructor of class _EventSource
def test__EventSource():
    def noop():
        pass

    e = _EventSource()
    e += noop



# Generated at 2022-06-23 13:35:16.943146
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    expected_default_collection = 'one.collection'
    AnsibleCollectionConfig.default_collection = 'one.collection'
    assert AnsibleCollectionConfig.default_collection == expected_default_collection
    assert AnsibleCollectionConfig.on_collection_load._handlers == set()


# Generated at 2022-06-23 13:35:23.886872
# Unit test for constructor of class _EventSource
def test__EventSource():
    class MyEventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            print('exception handler called')
            print('  handler = {}'.format(handler))
            print('  exc = {}'.format(exc))
            return False

    try:
        _EventSource()
    except ValueError as ex:
        print('exception when calling EventSource() with no parameters: {}'.format(ex))
    else:
        print('no exception when calling EventSource() with no parameters')

    es = MyEventSource()

    def my_handler(*args, **kwargs):
        print('my_handler called')
        print('  args = {}'.format(args))
        print('  kwargs = {}'.format(kwargs))

    es += my_handler
    es += my

# Generated at 2022-06-23 13:35:25.042301
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert isinstance(_EventSource(), _EventSource)


# Generated at 2022-06-23 13:35:33.637811
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def on_change(*args, **kwargs):
        if 'bar' in kwargs:
            raise ValueError

    def on_error(handler, exc, *args, **kwargs):
        # if we return True, we want the caller to re-raise
        return True

    x = _EventSource()
    x.fire()

    x += on_change
    x.fire('foo', bar='bam')

    x._on_exception = on_error
    try:
        x.fire('foo', bar='bam')
        assert False
    except ValueError:
        pass
    except AssertionError:
        raise
    else:
        assert False

# Generated at 2022-06-23 13:35:37.205067
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    class Config(_AnsibleCollectionConfig):
        pass

    assert Config._collection_finder is None
    assert Config._default_collection is None
    assert isinstance(Config._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:35:43.193138
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    def check_subtract(to_subtract):
        source -= to_subtract
        assert to_subtract not in source._handlers

    def handler():
        pass

    check_subtract(handler)
    source += handler
    check_subtract(handler)
    check_subtract(handler)



# Generated at 2022-06-23 13:35:53.243385
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def handler(*args, **kwargs):
        handler_args.append(args)
        handler_kwargs.append(kwargs)
        return 'handler'

    event_source = _EventSource()
    event_source += handler

    args_value = (5, 'arg2')
    kwargs_value = {'kwarg1': 'arg1', 'kwarg2': 'arg2'}
    handler_args = []
    handler_kwargs = []

    ret = event_source.fire(*args_value, **kwargs_value)

    assert ret is None
    assert handler_args == [args_value]
    assert handler_kwargs == [kwargs_value]


# Generated at 2022-06-23 13:35:56.784479
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler1(event_args):
        # test that event_args are passed
        assert event_args == {'handler1': 1}

    def handler2(event_args):
        # test that event_args are passed
        assert event_args == {'handler2': 2}

    es = _EventSource()

    es += handler1
    es += handler2
    es.fire({'handler1': 1}, {'handler2': 2})

    es -= handler1
    es.fire({'handler2': 2})


# Generated at 2022-06-23 13:36:05.619326
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler_1(args):
        pass

    def handler_2(args):
        raise ValueError('intentional failure')

    event = _EventSource()
    event.on_collection_load += handler_1
    event.on_collection_load += handler_2

    event.on_collection_load -= handler_1
    event.fire('x')

    event.on_collection_load -= handler_2
    event.fire('x')



# Generated at 2022-06-23 13:36:08.625185
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    handler = lambda: None
    event += handler
    event -= handler
    assert len(event._handlers) == 0

# Generated at 2022-06-23 13:36:09.575264
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()

# Generated at 2022-06-23 13:36:14.780786
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert 0 == len(event_source._handlers)
    assert event_source == event_source + event_source
    assert 2 == len(event_source._handlers)


# Generated at 2022-06-23 13:36:24.361617
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    test_source = _EventSource()

    # Nothing should happen if we try to unsubscribe a nonexistent handler
    test_source -= None

    count = [0]

    def handler_1(*_):
        count[0] += 1

    # Unsubscribing the same handler twice does nothing
    test_source += handler_1
    test_source -= handler_1
    test_source -= handler_1

    # Now subscribe again, then unsubscribe and ensure the handler wasn't called
    test_source += handler_1
    test_source -= handler_1
    test_source.fire()
    assert count[0] == 0

    count[0] = 0

    def handler_2(*_):
        count[0] += 1

    # Test when there are multiple handlers, and we unsubscribe one, the others are called
    test_source += handler

# Generated at 2022-06-23 13:36:27.534346
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()
    ev += lambda: 'hi'
    ev += lambda: 'hi'
    ev -= lambda: 'hi'
    ev += lambda: 'hi'
    assert len(ev._handlers) == 1


# Generated at 2022-06-23 13:36:33.134191
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    def handler1():
        pass
    def handler2():
        pass
    event_source += handler1
    event_source += handler2
    assert handler1 in event_source._handlers
    assert handler2 in event_source._handlers



# Generated at 2022-06-23 13:36:35.917361
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_paths == []
    assert config.playbook_paths == []
    assert config.default_collection == None

# Generated at 2022-06-23 13:36:37.595298
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class C:
        __metaclass__ = _AnsibleCollectionConfig
    return C

# Generated at 2022-06-23 13:36:39.151945
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=unused-variable
    acct = AnsibleCollectionConfig()


# Generated at 2022-06-23 13:36:42.945880
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    handler = lambda: None
    es += handler
    es -= handler
    assert handler not in es._handlers



# Generated at 2022-06-23 13:36:49.278993
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    results = []

    def on_collection_load(collection, collection_name, collection_paths):
        results.append((collection, collection_name, collection_paths))

    e = AnsibleCollectionConfig.on_collection_load
    e += on_collection_load
    e.fire('collection', 'collection_name', 'collection_paths')
    assert results == [('collection', 'collection_name', 'collection_paths')]

# Generated at 2022-06-23 13:36:51.905224
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    ev = _EventSource()
    with pytest.raises(ValueError):
        ev += 'not_callable'


# Generated at 2022-06-23 13:36:55.223261
# Unit test for constructor of class _EventSource
def test__EventSource():
    s = _EventSource()

    # test that we can add a handler with the += operator
    def fake_handler():
        return 'hi'

    s += fake_handler

    # test that we can remove a handler with the -= operator
    s -= fake_handler

    # test that we can fire events
    s.fire()



# Generated at 2022-06-23 13:37:06.570024
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible.module_utils.common.text.converters import to_text
    import os

    event = _EventSource()
    called = {'value': False}
    def event_handler(arg):
        assert event == arg
        called['value'] = True

    assert len(event._handlers) == 0
    event += event_handler
    assert len(event._handlers) == 1
    event += event_handler
    assert len(event._handlers) == 1
    event.fire()
    assert called['value'] == True

    called['value'] = False
    event += event
    assert len(event._handlers) == 2
    event.fire()
    assert called['value'] == True

    called['value'] = False
    event += "foobar"
    assert len(event._handlers) == 2


# Generated at 2022-06-23 13:37:09.863009
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    # Arrange
    event_source = _EventSource()

    def handler():
        pass

    # Act
    event_source += handler

    # Assert
    assert handler in event_source._handlers


# Generated at 2022-06-23 13:37:16.906003
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def add(a, b):
        return a + b

    def zero_div(a, b):
        return a / b

    events = _EventSource()
    events += add

    assert events.fire(1, 2) is None
    assert events.fire(1, b=2) is None
    assert events.fire(b=2, a=1) is None

    try:
        events.fire(1)
        assert False
    except TypeError:
        assert True

    events += zero_div
    try:
        events.fire(1, b=0)
        assert False
    except ZeroDivisionError:
        assert True

# Generated at 2022-06-23 13:37:21.259103
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    assert len(event_source._handlers) == 0
    event_source += lambda x: x
    assert len(event_source._handlers) == 1
    try:
        event_source += 123
        raise AssertionError('ValueError exception not raised')
    except ValueError:
        pass


# Generated at 2022-06-23 13:37:27.684278
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()

    def handler():
        pass

    def handler2():
        pass

    # Test: add a handler
    event_source += handler
    assert handler in event_source._handlers

    # Test: add a handler which is already added
    event_source += handler
    assert handler in event_source._handlers

    # Test: add a second handler
    event_source += handler2
    assert handler in event_source._handlers
    assert handler2 in event_source._handlers

    # Test: try adding a badly typed handler
    try:
        event_source += "I am not callable"
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-23 13:37:29.906805
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    acc1 = AnsibleCollectionConfig()
    assert isinstance(acc1._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:37:33.762315
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert _AnsibleCollectionConfig.collection_finder is None
    assert _AnsibleCollectionConfig.default_collection is None
    assert _AnsibleCollectionConfig.on_collection_load is not None



# Generated at 2022-06-23 13:37:34.911578
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    _ = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:37:36.379983
# Unit test for constructor of class _EventSource
def test__EventSource():
    eventsource = _EventSource()
    assert eventsource._handlers == set()

# Generated at 2022-06-23 13:37:41.524250
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import pytest

    def handler1(*args, **kwargs):
        print('handler1', args, kwargs)

    def handler2(*args, **kwargs):
        print('handler2', args, kwargs)
        raise RuntimeError('oops')

    events = _EventSource()
    events += handler1
    events += handler2
    message = 'hello'
    with pytest.raises(RuntimeError):
        events.fire(message)

# Generated at 2022-06-23 13:37:50.194362
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class EventSink:
        def __init__(self):
            self.event_fired = False

        def __call__(self, *args, **kwargs):
            self.event_fired = True

    def non_callable_handler():
        pass

    evt = _EventSource()

    # make sure handler can be removed, even if not previously defined
    evt.fire()

    evt -= non_callable_handler

    # make sure handler can be removed, even if it raises an exception
    def failing_handler():
        raise TypeError()

    evt += failing_handler
    try:
        evt.fire()
    except TypeError:
        pass

    evt -= failing_handler

    # test that a handler can be removed
    handler = EventSink()
    evt += handler
    evt -= handler

# Generated at 2022-06-23 13:37:58.956570
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import unittest

    def a():
        pass

    def b():
        pass

    def c():
        pass

    class Test(unittest.TestCase):
        def setUp(self):
            self.s = _EventSource()
            self.s += a
            self.s += b
            self.s += c

        def test_sub(self):
            self.s -= a
            self.s -= c
            self.assertEqual(len(self.s._handlers), 1)
            self.assertEqual(self.s._handlers, {b})

        def test_sub_non_existent(self):
            self.s -= d
            self.assertEqual(len(self.s._handlers), 3)


# Generated at 2022-06-23 13:38:04.164157
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Foo:
        def __init__(self):
            self.called = False

        def handler(self):
            self.called = True

    foo = Foo()
    source = _EventSource()
    source += foo.handler
    source.fire()
    assert foo.called


# Generated at 2022-06-23 13:38:15.140558
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from ansible.module_utils.common.collections import AnsibleCollectionLoader

    # Use AnsibleCollectionLoader before setting up the config because of side effects related to the default
    # AnsibleCollectionFinder and path configuration.
    loader = AnsibleCollectionLoader()

    config = AnsibleCollectionConfig()
    config.collection_finder = loader._config.collection_finder
    config.default_collection = loader._config.default_collection

    import os
    import sys

    # The test/tw01chars/collections/ansible_collections/tw01chars/test_collection/plugins/modules directory
    # below could be relative or absolute.
    #
    # We want to ensure that the collection_paths property does not use a trailing os.sep because this is
    # removed from the path before searching for the collection.

# Generated at 2022-06-23 13:38:21.344871
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)



# Generated at 2022-06-23 13:38:27.496399
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler1(arg1, arg2):
        pass

    def handler2(arg1, arg2):
        pass

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source -= handler1

    assert event_source._handlers == set([handler2])



# Generated at 2022-06-23 13:38:28.814119
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()



# Generated at 2022-06-23 13:38:38.823398
# Unit test for constructor of class _EventSource
def test__EventSource():
    class Mock:
        def __init__(self):
            self.called = False
            self.args = None
            self.kwargs = None

        def __call__(self, *args, **kwargs):
            self.called = True
            self.args = args
            self.kwargs = kwargs

    e = _EventSource()
    m1 = Mock()
    m2 = Mock()

    e.__iadd__(m1)
    e.__iadd__(m2)

    e.fire('foo', bar='qux')

    assert m1.called is True
    assert m1.args == ('foo', )
    assert m2.kwargs == {'bar': 'qux'}

    assert m2.called is True
    assert m2.args == ('foo', )
    assert m2

# Generated at 2022-06-23 13:38:44.838345
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None

    assert AnsibleCollectionConfig.collection_finder is None

    assert AnsibleCollectionConfig.collection_paths == []

    assert AnsibleCollectionConfig.default_collection is None

    assert AnsibleCollectionConfig.playbook_paths == []

    assert AnsibleCollectionConfig.on_collection_load is not None



# Generated at 2022-06-23 13:38:51.169481
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    '''
    Verify that _EventSource.fire works as expected.
    :return:
    '''
    es = _EventSource()

    class A:
        @es.fire
        def my_func(self, a, b):
            return a + b

    class B:
        def my_func(self, a, b):
            return a + b

    a = A()
    b = B()

    assert a.my_func(1, 2) == 3
    assert b.my_func(1, 2) == 3

    es += b.my_func
    assert a.my_func(1, 2) == 3
    assert b.my_func(1, 2) == 3

    es += a.my_func
    assert a.my_func(1, 2) == 6
    assert b.my_

# Generated at 2022-06-23 13:38:59.903206
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    import unittest
    from unittest.mock import Mock

    class Foo:
        def __isub__(self, other):
            return NotImplemented

    class EventSourceTest(unittest.TestCase):
        def test___isub__(self):
            es = _EventSource()

            h = Mock()
            es += h

            es -= h

            h.assert_not_called()

            # None is not a callable
            self.assertRaises(ValueError, es.__isub__, None)

            # Test for issue #65608, where a missing handler would cause a crash
            es -= h

            # subclassed exception should be OK as well for issue #65608
            foo = Foo()
            es += foo
            es -= foo

    unittest.main()

# Generated at 2022-06-23 13:39:08.012062
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    from ansible_test._internal.test_module import AnsibleTestModule, DummyModSpec
    from ansible.module_utils.basic import AnsibleModule

    module_spec = DummyModSpec.from_name('_unit_test')
    base_path = module_spec.src

    with AnsibleTestModule(module_spec, base_path) as am:
        module = AnsibleModule(argument_spec={})

    es = _EventSource()
    es += module.fail_json

    if not module.fail_json in es._handlers:
        module.fail_json(msg='fail_json not found in handlers')



# Generated at 2022-06-23 13:39:13.275340
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    test_handler = lambda *args, **kwargs: None

    event_source = _EventSource()
    assert not event_source._handlers

    event_source += test_handler

    assert len(event_source._handlers) == 1
    assert callable(test_handler)



# Generated at 2022-06-23 13:39:22.499578
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(arg):
        pass

    es = _EventSource()
    assert es._handlers == set()

    # add a function object
    es += handler
    assert es._handlers == {handler}

    # add it again, no change
    es += handler
    assert es._handlers == {handler}

    # remove the function object
    es -= handler
    assert es._handlers == set()

    # remove it again, no change
    es -= handler
    assert es._handlers == set()

    # add a lambda function object
    es += lambda x: x
    assert len(es._handlers) == 1

    # add a lambda function object again, should be a different function object
    es += lambda x: x
    assert len(es._handlers) == 2

    # add the lambda again, no change

# Generated at 2022-06-23 13:39:26.147157
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    obj = _EventSource()
    handler = lambda *args, **kwargs: None

    obj += handler
    assert len(obj._handlers) == 1

    obj -= handler
    assert len(obj._handlers) == 0


# Generated at 2022-06-23 13:39:28.776863
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert isinstance(es, _EventSource)
    assert 0 == len(es._handlers)


# Generated at 2022-06-23 13:39:31.702068
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler(*args, **kwargs):
        pass

    event_source = _EventSource()

    event_source += handler

    assert handler in event_source._handlers


# Generated at 2022-06-23 13:39:33.923436
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # Instantiate class AnsibleCollectionConfig
    AnsibleCollectionConfig()
    # The constructor of class AnsibleCollectionConfig must not raise an exception
    pass

# Generated at 2022-06-23 13:39:39.024604
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def f1():
        raise Exception()

    def f2():
        raise Exception()
    es = _EventSource()
    es += f1
    es += f2

    try:
        es.fire()
        assert False, 'Expected an exception to be raised'
    except Exception:
        # All good
        pass


# Generated at 2022-06-23 13:39:42.516354
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.default_collection is None
    assert not config.collection_paths
    assert not config.playbook_paths
    assert isinstance(config.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:39:45.747302
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_eventsource = _EventSource()
    assert test_eventsource._handlers == set()


# Generated at 2022-06-23 13:39:55.876387
# Unit test for constructor of class _EventSource
def test__EventSource():
    def test_callable():
        assert callable(test_callable)
    def test_non_callable():
        assert not callable(1)

    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)
    assert not isinstance(AnsibleCollectionConfig.on_collection_load, _AnsibleCollectionConfig)
    assert callable(AnsibleCollectionConfig.on_collection_load.__iadd__)
    assert callable(AnsibleCollectionConfig.on_collection_load.__isub__)
    assert callable(AnsibleCollectionConfig.on_collection_load.fire)



# Generated at 2022-06-23 13:39:57.888739
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._collection_finder is None
    assert AnsibleCollectionConfig._default_collection is None


# Generated at 2022-06-23 13:40:03.397530
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestClass(AnsibleCollectionConfig):
        pass

    assert TestClass.on_collection_load
    assert isinstance(TestClass.on_collection_load, _EventSource)
    assert TestClass.on_collection_load is TestClass._on_collection_load
    assert TestClass.collection_finder is None
    assert TestClass.default_collection is None

# Generated at 2022-06-23 13:40:14.532759
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    class TestObj:
        def __init__(self):
            self.value = 0
            self.start = 0

        def increment(self):
            self.value += 1

        def decrement(self, start):
            self.value -= 1
            self.start = start

    class ObjWithEvent:
        def __init__(self):
            self.obj = TestObj()
            self.on_event = _EventSource()

    obj_with_event = ObjWithEvent()

    def increment(self):
        self.obj.increment()

    def decrement(self):
        self.obj.decrement(start=self.obj.start)

    obj_with_event.on_event += increment

    obj_with_event.on_event += decrement

    obj_with_event.on_event.fire()



# Generated at 2022-06-23 13:40:15.650122
# Unit test for constructor of class _EventSource
def test__EventSource():
    evt = _EventSource()

# Generated at 2022-06-23 13:40:17.288455
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    e -= lambda x: 3  # pylint: disable=unnecessary-lambda

# Generated at 2022-06-23 13:40:29.143512
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # test default constructor
    config = AnsibleCollectionConfig()
    assert config.collection_finder is None
    assert config.default_collection is None
    assert config.collection_paths == []
    assert config.playbook_paths == []
    assert config.on_collection_load._handlers == set()
    assert config.on_collection_load._on_exception is _EventSource._on_exception
    handlers = config.on_collection_load._handlers
    callback = lambda: None
    config.on_collection_load += callback
    assert config.on_collection_load._handlers is handlers
    assert config.on_collection_load._on_exception is _EventSource._on_exception
    config.on_collection_load -= callback
    assert config.on_collection_load._handlers is handlers

# Generated at 2022-06-23 13:40:32.384210
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()

##########
# Then, we create a singleton instance of AnsibleCollectionConfig (which inherits from our metaclass)
# This is the code that would be used in the controller...

# Generated at 2022-06-23 13:40:38.229544
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # Exercise collection_finder property
    a = AnsibleCollectionConfig

    assert not hasattr(a, '_collection_finder')
    assert not hasattr(a, '_default_collection')
    assert not hasattr(a, '_on_collection_load')
    assert not hasattr(a, 'collection_finder')
    assert not hasattr(a, 'default_collection')
    assert not hasattr(a, 'on_collection_load')

    a.collection_finder = 'blah'

    assert hasattr(a, '_collection_finder')
    assert a._collection_finder == 'blah'
    assert a.collection_finder == 'blah'

    a._collection_finder = 'something else'

    assert a._collection_finder == 'something else'
    assert a.collection_finder == 'something else'

    a

# Generated at 2022-06-23 13:40:41.070628
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()

    def noop():
        pass

    source += noop
    source -= noop

# Generated at 2022-06-23 13:40:44.838293
# Unit test for constructor of class _EventSource
def test__EventSource():
    handler = lambda a, b: a + b
    event_source = _EventSource()
    event_source += handler
    event_source -= handler
    event_source.fire(1, 2)


# Generated at 2022-06-23 13:40:52.824207
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    c = AnsibleCollectionConfig()

    assert c.on_collection_load is None
    assert c.playbook_paths is None
    assert c.collection_finder is None

    # This is not done in the real implementation, but is done so in our unittest which is loaded into both the
    # controller and the ansible-test framework.
    # This code path is required to ensure that the metaclass is initialized in both environments.
    o = AnsibleCollectionConfig()

# Generated at 2022-06-23 13:40:59.562003
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _FakeHandler:
        def __init__(self):
            self.invoked = None

        def __call__(self, *args, **kwargs):
            self.invoked = True

    class _FakeEventSource(_EventSource):
        pass

    fake_handler = _FakeHandler()
    fake_event_source = _FakeEventSource()

    fake_event_source += fake_handler
    assert fake_handler in fake_event_source._handlers

    fake_event_source -= fake_handler
    assert fake_handler not in fake_event_source._handlers

    # should no crash
    fake_event_source -= None
    fake_event_source -= fake_handler



# Generated at 2022-06-23 13:41:09.026788
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import os
    import tempfile

    class BadPathError(Exception):
        pass

    def raise_if_not_exists(path):
        if not os.path.exists(path):
            raise BadPathError('path does not exist')
        return path

    def raise_private_exception(path):
        raise BadPathError('private exception')

    def get_temp_path():
        return tempfile.mkdtemp()

    # create a source
    source = _EventSource()

    # add handlers
    source += raise_if_not_exists
    source += raise_private_exception
    source += get_temp_path

    # initial state
    assert list(source._handlers) == [raise_if_not_exists, raise_private_exception, get_temp_path]

    # fire on an

# Generated at 2022-06-23 13:41:16.978774
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventSource(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            self.exception_happened = True
            return False

    event_source = EventSource()

    calls = []

    def handler1():
        calls.append(1)

    def handler2():
        calls.append(2)

    def handler3():
        raise RuntimeError

    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire()
    assert calls == [1, 2]

    assert event_source.exception_happened

# Generated at 2022-06-23 13:41:22.636486
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()
    handler1 = es.__iadd__(lambda *args: None)
    handler2 = es.__iadd__(lambda *args: None)
    es.__isub__(handler1)
    assert len(es._handlers) == 1
    es.__isub__(handler1)
    assert len(es._handlers) == 1
    es.__isub__(handler2)
    assert len(es._handlers) == 0

# Generated at 2022-06-23 13:41:26.585408
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)



# Generated at 2022-06-23 13:41:32.143438
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _Observer:
        def __init__(self):
            self._on_event_fired = None  # event handler

        def __call__(self, *args, **kwargs):
            if self._on_event_fired:
                self._on_event_fired(*args, **kwargs)

        @property
        def on_event_fired(self):
            return self._on_event_fired

        @on_event_fired.setter
        def on_event_fired(self, value):
            if value and not callable(value):
                raise ValueError('on_event_fired must be callable')
            self._on_event_fired = value

    class _EventSourceImpl(_EventSource):
        def __init__(self):
            super(_EventSourceImpl, self).__init__()

            self._state

# Generated at 2022-06-23 13:41:37.094870
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    testee = _EventSource()
    handler1 = lambda x: print('handler1 called')
    handler2 = lambda x: print('handler2 called')

    testee += handler1

    assert handler1 in testee._handlers
    assert handler2 not in testee._handlers


# Generated at 2022-06-23 13:41:44.952218
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def func1(*args, **kwargs):
        assert args == ('arg1', 'arg2')
        assert kwargs == {'kwarg1': 1, 'kwarg2': 2}

    def func2(*args, **kwargs):
        assert args == ('arg1', 'arg2')
        assert kwargs == {'kwarg1': 1, 'kwarg2': 2}
        raise RuntimeError('Exception for testing')

    def func3(*args, **kwargs):
        assert args == ('arg1', 'arg2')
        assert kwargs == {'kwarg1': 1, 'kwarg2': 2}

    event_source = _EventSource()
    event_source += func1
    event_source += func2
    event_source += func3


# Generated at 2022-06-23 13:41:49.084909
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    collection = AnsibleCollectionConfig()
    assert collection.collection_finder is None
    assert collection.default_collection is None
    assert collection.collection_paths is None
    assert collection.playbook_paths is None
    assert collection.on_collection_load is None


# Generated at 2022-06-23 13:41:51.093758
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)



# Generated at 2022-06-23 13:41:56.454915
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestCollectionConfig(_AnsibleCollectionConfig):
        pass

    TestCollection = TestCollectionConfig('TestCollection', (object,), {})
    TestCollection._collection_finder = None
    assert TestCollection.collection_finder is None

    TestCollection._default_collection = None
    assert TestCollection.default_collection is None

    TestCollection._on_collection_load = None
    assert TestCollection.on_collection_load._handlers == set()



# Generated at 2022-06-23 13:41:58.616840
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # pylint: disable=invalid-name
    _AnsibleCollectionConfig.__init__(_AnsibleCollectionConfig, None, 'meta', (object,))



# Generated at 2022-06-23 13:42:07.275611
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    source -= source.fire
    assert source._handlers == set()

    def test_handler1(x):
        return x

    def test_handler2(x):
        return x

    original_handlers = (test_handler1, test_handler2)
    for handler in original_handlers:
        source += handler
    assert set(original_handlers) == source._handlers

    for handler in original_handlers:
        source -= handler

    assert source._handlers == set()



# Generated at 2022-06-23 13:42:16.477096
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventHandler:
        def __init__(self):
            self.called = False
            self.args = None
            self.kwargs = None

        def __call__(self, *args, **kwargs):
            self.called = True
            self.args = args
            self.kwargs = kwargs

    def on_exception_func(self, handler, exc, *args, **kwargs):
        self.exception = exc
        return False

    def test_fire_no_handlers():
        s = _EventSource()
        s.fire(1, 2, a=1, b=2)

    def test_fire_ok():
        handler = EventHandler()
        s = _EventSource()
        s += handler
        s.fire(1, 2, a=1, b=2)

# Generated at 2022-06-23 13:42:24.698389
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    class EventUser:
        def __init__(self):
            self.s = _EventSource()
            self.s += self.event_handler

        def event_handler(self, msg):
            raise ValueError('event_handler called with %s' % msg)

    # verify an exception from an event handler is propagated
    obj = EventUser()
    try:
        obj.s.fire('hello world')
    except ValueError:
        pass
    else:
        assert False, 'expected event handler to raise exception'

    # verify that an event handler is removed after its first exception
    obj = EventUser()
    try:
        obj.s.fire('hello world')
    except ValueError:
        pass

# Generated at 2022-06-23 13:42:31.305625
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():

    class M(type):
        def __init__(self, meta, name, bases):
            super(_AnsibleCollectionConfig, self).__init__(meta, name, bases)

            self._on_collection_load = _EventSource()

    class X(with_metaclass(M)):
        pass

    x = X()
    x.on_collection_load += lambda x: x
    x.on_collection_load.fire(5)

# Generated at 2022-06-23 13:42:34.572868
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    cls = _AnsibleCollectionConfig('Meta', 'AnsibleCollectionConfig', (Exception,))
    assert isinstance(cls._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:42:37.337667
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource();
    def handler():
        pass
    event_source += handler
    event_source -= handler


# Generated at 2022-06-23 13:42:43.791009
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class MyAnsibleCollectionConfig(AnsibleCollectionConfig):
        pass

    class Receiver:
        def __init__(self, name):
            self.name = name

        def __call__(self, *args, **kwargs):
            pass

    receiver1 = Receiver('receiver1')
    receiver2 = Receiver('receiver2')
    receiver3 = Receiver('receiver3')
    MyAnsibleCollectionConfig.on_collection_load += receiver1
    MyAnsibleCollectionConfig.on_collection_load += receiver2
    MyAnsibleCollectionConfig.on_collection_load += receiver3

    MyAnsibleCollectionConfig.on_collection_load.fire('fake_collection')

    # fire after removing a receiver
    MyAnsibleCollectionConfig.on_collection_load -= receiver2

# Generated at 2022-06-23 13:42:47.650095
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:42:52.658724
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event = _EventSource()
    event += lambda: None
    assert len(event._handlers) == 1

    event -= lambda: None
    assert len(event._handlers) == 0

    # make sure -= on a handler not in _handlers doesn't throw
    event -= lambda: None
    assert len(event._handlers) == 0

# Generated at 2022-06-23 13:42:56.713943
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event = _EventSource()
    def foo():
        pass
    def bar():
        pass

    event += foo
    event += bar

    assert len(event._handlers) == 2
    assert foo in event._handlers
    assert bar in event._handlers



# Generated at 2022-06-23 13:43:01.610010
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    try:
        AnsibleCollectionConfig.on_collection_load = None
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-23 13:43:02.894733
# Unit test for constructor of class _EventSource
def test__EventSource():
    handler = _EventSource()

# Generated at 2022-06-23 13:43:05.273276
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    source = _EventSource()
    source -= source._on_exception
    assert len(source._handlers) == 0



# Generated at 2022-06-23 13:43:09.326924
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    a = _EventSource()

    def f(x):
        pass

    assert(a._handlers == set())
    a += f
    assert(a._handlers == set([f]))
    a += f
    assert(a._handlers == set([f]))



# Generated at 2022-06-23 13:43:18.169806
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    a = dict(results=list())
    def f0(*args, **kwargs):
        a['results'].append(0)
    def f1(*args, **kwargs):
        a['results'].append(1)
    def f2(*args, **kwargs):
        a['results'].append(2)
        raise ValueError('test exception')
    def f3(*args, **kwargs):
        a['results'].append(3)

    s = _EventSource()
    s += f0
    s += f1
    s += f2
    try:
        s.fire()
    except ValueError:
        pass
    s += f3
    s.fire()

    assert a['results'] == [0, 1, 2, 3, 0, 1, 3]