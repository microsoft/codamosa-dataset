

# Generated at 2022-06-23 13:33:12.231153
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    def handler():
        pass

    es += handler
    es += handler


# Generated at 2022-06-23 13:33:13.868421
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert callable(event_source)
    assert event_source._handlers == set()


# Generated at 2022-06-23 13:33:24.335403
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # function for testing of class _EventSource, method fire
    def _test_fire():
        _EventSource().fire('test_fire') # fire on EventSource w/o any handler registered
        pass

    def _test_fire1(x):
        raise Exception('test__EventSource_fire(_test_fire1)') # test exception handling

    def _test_fire2(x):
        raise Exception('test__EventSource_fire(_test_fire2)') # test exception handling

    def _test_fire3(x):
        raise Exception('test__EventSource_fire(_test_fire3)') # test exception handling

    _e = _EventSource()
    _e += _test_fire1
    _e += _test_fire2
    _e += _test_fire3
    _e.on_exception = _ExceptionSourceTest

# Generated at 2022-06-23 13:33:31.241696
# Unit test for constructor of class _AnsibleCollectionConfig

# Generated at 2022-06-23 13:33:38.630123
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(arg1, arg2, kwarg1='default'):
        pass

    evt = _EventSource()

    # multiple handlers
    evt += handler
    evt += handler

    # must be callable
    try:
        evt += None
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    evt -= handler
    evt -= handler

    # missing handler is ok
    evt -= handler



# Generated at 2022-06-23 13:33:41.649692
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def handler():
        pass

    es = _EventSource()

    assert handler not in es._handlers

    es += handler

    assert handler in es._handlers

    es -= handler

    assert handler not in es._handlers



# Generated at 2022-06-23 13:33:43.847473
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    e += lambda: None
    assert True



# Generated at 2022-06-23 13:33:48.520827
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    def handler(*args, **kwargs):
        pass

    event = _EventSource()
    event += handler

    assert handler in event._handlers

    with pytest.raises(ValueError, match='handler must be callable'):
        event += 1



# Generated at 2022-06-23 13:33:58.325559
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    from unittest import TestCase
    import copy

    class TestEventSource(_EventSource):
        def __init__(self):
            super(TestEventSource, self).__init__()
            self.on_exception_fired = False

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.on_exception_fired = True
            return True

    class TestHandler(object):
        def __init__(self, should_raise=False):
            self.fired = False
            self.args = None
            self.kwargs = None
            self.should_raise = should_raise

        def __call__(self, *args, **kwargs):
            self.fired = True
            self.args = copy.copy(args)

# Generated at 2022-06-23 13:34:03.574475
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # arrange
    event = _EventSource()
    event_1 = _EventSource()
    event_2 = _EventSource()

    # act
    event += event_1.fire
    event += event_2.fire
    event += event_1.fire
    event.fire(1, 2, 3, 4)

    # assert
    assert True


# Generated at 2022-06-23 13:34:06.618207
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    e = _EventSource()
    def foo(*args, **kwargs):
        print('firing foo')

    e += foo
    e -= foo
    e.fire()

# Generated at 2022-06-23 13:34:13.238382
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    def foo():
        raise ValueError()

    def bar():
        pass

    class Baz:
        def __call__(self):
            raise ValueError()

        def __eq__(self, other):
            raise ValueError()

    fired = [False, False]

    def handler(index):
        def _handler():
            fired[index] = True

        return _handler

    ev = _EventSource()
    ev += foo
    ev += bar
    ev += Baz()
    ev += handler(0)
    ev += handler(1)

    ev.fire()
    assert not any(fired)

    ev.fire()
    assert all(fired)

    fired = [False, False]
    ev.fire()
    assert not any(fired)

# Generated at 2022-06-23 13:34:18.368981
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    m = _AnsibleCollectionConfig('foo', 'bar', 'baz')
    assert m._collection_finder is None
    assert m._default_collection is None
    assert isinstance(m._on_collection_load, _EventSource)

# Unit tests for class _AnsibleCollectionConfig using a dummy class

# Generated at 2022-06-23 13:34:19.472091
# Unit test for constructor of class _EventSource
def test__EventSource():
    e = _EventSource()
    assert e

# Generated at 2022-06-23 13:34:30.066719
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    from ansible.utils.collection_loader.collection_finder import AnsibleCollectionFinder
    finder = AnsibleCollectionFinder()
    AnsibleCollectionConfig.collection_finder = finder
    AnsibleCollectionConfig.default_collection = 'foo.bar'
    AnsibleCollectionConfig.on_collection_load += lambda x,y: None

    finder.set_playbook_paths(['/first/path', '/second/path'])
    assert AnsibleCollectionConfig.playbook_paths == ['/first/path', '/second/path']

    assert AnsibleCollectionConfig.collection_finder == finder
    assert AnsibleCollectionConfig.default_collection == 'foo.bar'
    assert AnsibleCollectionConfig.on_collection_load is not None

# Generated at 2022-06-23 13:34:40.943559
# Unit test for constructor of class _EventSource
def test__EventSource():
    def assert_handler_added(handler):
        handlers = [h for h in source._handlers]
        assert len(handlers) == 1
        assert handlers[0] == handler

    def assert_handler_removed(handler):
        handlers = [h for h in source._handlers]
        assert len(handlers) == 0

    source = _EventSource()

    handler1 = lambda: None
    handler2 = lambda: None

    assert_handler_removed(handler1)

    source += handler1
    assert_handler_added(handler1)

    source += handler2
    assert_handler_added(handler2)

    source -= handler1
    assert_handler_removed(handler1)

    source -= handler1
    assert_handler_removed(handler1)

    source -= handler2
    assert_handler_removed

# Generated at 2022-06-23 13:34:48.238296
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class EventTarget(object):
        def __init__(self):
            self.fired = False

        def my_event_handler(self, the_arg):
            self.the_arg = the_arg
            self.fired = True

    event_source = _EventSource()
    target = EventTarget()
    event_source += target.my_event_handler
    event_source.fire('arg')
    assert target.fired
    assert target.the_arg == 'arg'


# Generated at 2022-06-23 13:34:58.784771
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    import sys

    # test calling a handler that raises an exception
    class _Handler:
        def __call__(self):
            raise RuntimeError('handler error')

    _handlers = [_Handler() for _ in range(4)]

    _event_source = _EventSource()
    for handler in _handlers:
        _event_source += handler

    def _on_exception(exc, handler, *args, **kwargs):
        _exception = handler.__exception__
        if exc is _exception:
            raise _exception

        return False

    _event_source._on_exception = _on_exception

    _raised = False

    try:
        _event_source.fire()
    except RuntimeError:
        _raised = True

    assert _raised is True

    # test calling a handler that returns


# Generated at 2022-06-23 13:35:04.589954
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()

    def handler():
        pass

    assert handler not in event_source._handlers
    event_source += handler
    assert handler in event_source._handlers
    event_source -= handler
    assert handler not in event_source._handlers


# Generated at 2022-06-23 13:35:09.646057
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()

    # test __iadd__ with a callable
    es.__iadd__(callable)

    # test __iadd__ with a non-callable
    try:
        es.__iadd__(1)
    except ValueError:
        pass
    else:
        raise AssertionError('did not raise')


# Generated at 2022-06-23 13:35:14.293221
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    def handler():
        pass
    event_source.__iadd__(handler)
    event_source.__iadd__(handler)
    event_source.__iadd__(handler)
    event_source.__iadd__(handler)
    event_source.__isub__(handler)
    assert handler in event_source._handlers
    event_source.__isub__(handler)
    assert handler not in event_source._handlers


# Generated at 2022-06-23 13:35:22.482872
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    import sys
    import os

    assert issubclass(AnsibleCollectionConfig, AnsibleCollectionConfig)
    assert AnsibleCollectionConfig._on_collection_load is not None

    config_init_path = os.path.abspath(os.path.dirname(sys.modules['ansible'].__file__))
    assert AnsibleCollectionConfig.collection_paths == [config_init_path]

    playbook_paths = [
        '/tmp/1-playbook-path',
        '/tmp/2-playbook-path',
        '/tmp/3-playbook-path',
    ]
    AnsibleCollectionConfig.playbook_paths = playbook_paths
    assert AnsibleCollectionConfig.playbook_paths == playbook_paths


# Generated at 2022-06-23 13:35:24.865982
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.playbook_paths == []



# Generated at 2022-06-23 13:35:25.953809
# Unit test for constructor of class _EventSource
def test__EventSource():
    x = _EventSource()
    assert x


# Generated at 2022-06-23 13:35:29.566541
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = _AnsibleCollectionConfig('meta', 'name', 'bases')

    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config._on_collection_load, _EventSource)



# Generated at 2022-06-23 13:35:32.601234
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    event_source += (lambda: None)

    event_source -= (lambda: None)
    assert len(event_source._handlers) == 0


# Generated at 2022-06-23 13:35:35.841648
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: None
    assert callable(es._handlers.pop())



# Generated at 2022-06-23 13:35:46.018402
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler = lambda x: x

    # test that the handler is added to the EventSource
    event_source += handler
    if handler not in event_source._handlers:
        raise AssertionError('handler should be in _handlers')

    # test that adding the same handler again fails
    try:
        event_source += handler
    except:
        pass
    else:
        raise AssertionError('adding the same handler should fail')

    # test that adding a non-callable handler fails
    handler = object()
    try:
        event_source += handler
    except:
        pass
    else:
        raise AssertionError('adding a non-callable handler should fail')


# Generated at 2022-06-23 13:35:49.050309
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    m = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert type('meta') == type
    assert m._collection_finder == None
    assert m._default_collection == None
    assert type(m._on_collection_load) == _EventSource


# Generated at 2022-06-23 13:35:51.389535
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config.parameter_values == {}
    assert config.parameters == []



# Generated at 2022-06-23 13:35:52.220582
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    raise NotImplementedError()


# Generated at 2022-06-23 13:35:56.181984
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    s = _EventSource()
    s.fire()

    def handler1(event_source, *args, **kwargs):
        return None

    def handler2(event_source, *args, **kwargs):
        return None

    s += handler1
    s += handler2
    s.fire()

    s -= handler1
    s.fire()

    def handler3(event_source, *args, **kwargs):
        raise ValueError()

    s += handler3
    try:
        s.fire()
    except ValueError:
        pass

# Generated at 2022-06-23 13:36:04.584200
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config._default_collection is None
    assert config.collection_finder is None
    assert config.default_collection is None
    assert config.on_collection_load._handlers == set()

    assert config.collection_paths == []
    assert config.playbook_paths == []


# Unit tests for properties of class _AnsibleCollectionConfig

# Generated at 2022-06-23 13:36:05.243597
# Unit test for constructor of class _EventSource
def test__EventSource():
    _EventSource()

# Generated at 2022-06-23 13:36:07.160091
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert isinstance(AnsibleCollectionConfig, _AnsibleCollectionConfig)



# Generated at 2022-06-23 13:36:10.659683
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert callable(AnsibleCollectionConfig._on_collection_load.fire)
    assert callable(AnsibleCollectionConfig.on_collection_load.fire)
    assert AnsibleCollectionConfig._on_collection_load is AnsibleCollectionConfig.on_collection_load

# Generated at 2022-06-23 13:36:20.949816
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    fired = [False]

    def handler():
        fired[0] = True

    event_source = _EventSource()
    event_source.fire()
    assert not fired[0]

    event_source += handler
    event_source.fire()
    assert fired[0]

    # test that we can remove a handler
    fired[0] = False
    event_source -= handler
    event_source.fire()
    assert not fired[0]

    # test that all handlers are invoked even if one handler throws
    event_source += handler
    event_source += lambda: 1 / 0
    event_source += handler

    try:
        event_source.fire()
    except ZeroDivisionError:
        assert fired[0]
        fired[0] = False
    else:
        assert False, 'expected ZeroDivisionError'



# Generated at 2022-06-23 13:36:22.947541
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(AnsibleCollectionConfig, _AnsibleCollectionConfig)


# Generated at 2022-06-23 13:36:30.344759
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class Test:
        def __init__(self):
            self._event = _EventSource()

        @property
        def event(self):
            return self._event

        @event.setter
        def event(self, value):
            if value is not self._event:
                raise ValueError('event is not directly settable (use +=)')

    class Handler:
        def __call__(self, *args, **kwargs):
            pass

    instance = Test()

    handler = Handler()

    instance.event += handler

# CAUTION: If you change this test, you should also change the test of the same name in the ansible-test dir.


# Generated at 2022-06-23 13:36:34.624329
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class Mock:
        raised = False

        def raise_exc(self, *args, **kwargs):
            raise AttributeError('boom')
            return False

    mock = Mock()

    es = _EventSource()
    es += mock.raise_exc
    es += mock.raise_exc
    es += mock.raise_exc

    try:
        es.fire()
    except AttributeError as ex:
        assert str(ex) == 'boom'

# Generated at 2022-06-23 13:36:36.622339
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig._on_collection_load._handlers == set()
    assert AnsibleCollectionConfig.playbook_paths is None


# Generated at 2022-06-23 13:36:40.461785
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    def handler1(m):
        """handler1"""

    def handler2(m):
        """handler2"""

    es = _EventSource()

    # test that we can remove a handler not added
    es -= handler1

    es += handler1

    # test that we can remove a handler added
    es -= handler1

    # test that we can remove a handler added
    es += handler2

    es -= handler2

# Generated at 2022-06-23 13:36:47.329011
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    called = []

    def handler1(event_args, event_kwargs):
        called.append('handler1')

    def handler2(event_args, event_kwargs):
        raise AssertionError('handler2')

    def handler3(event_args, event_kwargs):
        called.append('handler3')

    event_source = _EventSource()
    event_source += handler1
    event_source += handler2
    event_source += handler3

    event_source.fire(None, None)

    assert called == ['handler1', 'handler3']

# Generated at 2022-06-23 13:36:50.007142
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cls = AnsibleCollectionConfig()
    assert cls._collection_finder is None
    assert cls._default_collection is None



# Generated at 2022-06-23 13:36:58.553967
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class MyEventSource(_EventSource):
        pass

    obj = MyEventSource()
    handler = lambda x: x

    # assert that handler is not in obj._handlers
    assert handler not in obj._handlers

    # add handler to obj._handlers
    obj += handler

    # assert that handler is in obj._handlers
    assert handler in obj._handlers

    # remove handler from obj._handlers
    obj -= handler

    # assert that handler is not in obj._handlers
    assert handler not in obj._handlers



# Generated at 2022-06-23 13:37:11.222020
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class TestEventSource(_EventSource):
        def __init__(self, on_exc_result, *args, **kwargs):
            super(TestEventSource, self).__init__(*args, **kwargs)
            self._on_exc_result = on_exc_result

        def _on_exception(self, handler, ex, *args, **kwargs):
            return self._on_exc_result

    def handler():
        raise Exception()

    def handler2(*args, **kwargs):
        raise Exception()

    def handler3(value):
        raise Exception()

    exception = Exception()

    try:
        TestEventSource(on_exc_result=True).fire(handler)
        assert False, 'expected exception'
    except Exception:
        pass


# Generated at 2022-06-23 13:37:17.602909
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()
    count = [0]

    def on_foo(first_arg):
        assert first_arg == 'arg'
        count[0] += 1

    event += on_foo
    event += on_foo
    event.fire('arg')

    assert count[0] == 2



# Generated at 2022-06-23 13:37:21.167276
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    s = _EventSource()
    def f1(): pass
    def f2(): pass
    s += f1
    s += f2
    assert len(s._handlers) == 2
    assert f1 in s._handlers
    assert f2 in s._handlers


# Generated at 2022-06-23 13:37:24.171864
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_obj = _EventSource()

    def test_func(val):
        test_obj.test_val = val

    test_obj += test_func
    test_obj.fire('test')
    assert test_obj.test_val == 'test'

# Generated at 2022-06-23 13:37:34.164530
# Unit test for constructor of class _EventSource
def test__EventSource():
    test_handlers = set()
    def test_handler(*args, **kwargs):
        test_handlers.add((args, kwargs))

    es = _EventSource()
    assert es._handlers == set()

    es += test_handler
    assert es._handlers == {test_handler}

    es -= test_handler
    assert es._handlers == set()

    es += test_handler
    es.fire(1, 2, 3, kwarg='test')
    assert test_handlers == {((1, 2, 3), {'kwarg': 'test'})}

    try:
        es += test_handler
        es += 'not a callable'
    except ValueError:
        pass
    else:
        assert False, 'exception not raised'


# Generated at 2022-06-23 13:37:36.905400
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    with pytest.raises(ValueError, match='must be callable'):
        event_source += 'not callable'


# Generated at 2022-06-23 13:37:45.537578
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert hasattr(AnsibleCollectionConfig, '_default_collection')
    assert hasattr(AnsibleCollectionConfig, '_on_collection_load')
    assert isinstance(AnsibleCollectionConfig._on_collection_load, _EventSource)
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')

# Generated at 2022-06-23 13:37:56.893391
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # instantiate an instance of the metaclass for testing purposes
    x = _AnsibleCollectionConfig('meta', 'name', 'bases')

    # test initialization of collection_finder property
    assert isinstance(x.collection_finder, property)

    # test initialization of default_collection property
    assert isinstance(x.default_collection, property)

    # test initialization of on_collection_load property
    assert hasattr(x, 'on_collection_load')
    assert isinstance(x.on_collection_load, property)

    # test initialization of playbook_paths property
    assert isinstance(x.playbook_paths, property)

    # test _require_finder() function
    assert isinstance(x._require_finder, types.MethodType)

# Generated at 2022-06-23 13:38:02.513583
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    a = _EventSource()
    def b(x):
        pass
    def c(x):
        pass
    a += b
    a += c
    len(a._handlers) == 2
    a -= b
    len(a._handlers) == 1

# Generated at 2022-06-23 13:38:05.296514
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    e = _EventSource()
    assert e._handlers == set()

    def func():
        pass

    e += func
    assert e._handlers == {func}


# Generated at 2022-06-23 13:38:09.056360
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert issubclass(_AnsibleCollectionConfig, type)
    assert isinstance(_AnsibleCollectionConfig, type)
    assert _AnsibleCollectionConfig('meta', 'name', 'bases')

# Generated at 2022-06-23 13:38:21.861337
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    was_called = 0
    def handler1(*args, **kwargs):
        nonlocal was_called
        was_called = 1
        return "handler1"
    def handler2(*args, **kwargs):
        nonlocal was_called
        was_called = 2
        return "handler2"
    def handler3(*args, **kwargs):
        nonlocal was_called
        was_called = 3
        return "handler3"
    event = _EventSource()
    event += handler1
    event += handler2
    event += handler3

    result = event.fire(4, 5, 6)
    assert was_called == 3
    assert result == None
    event -= handler2
    result = event.fire(4, 5, 6)
    assert was_called == 3
    assert result == None



# Generated at 2022-06-23 13:38:33.627183
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    # Variable to track if the expected exception was raised
    exception_raised = False

    # Variable to track if the expected exception was raised for the second handler
    exception_raised_second = False

    # Event source object
    event_source = _EventSource()

    # Handler that raises an exception
    def handler(event_source, *args, **kwargs):
        raise RuntimeError('handler exception')

    # Handler that raises an exception
    def handler_second(event_source, *args, **kwargs):
        raise RuntimeError('handler_second exception')

    # Attach handlers to event source
    event_source += handler
    event_source += handler_second

    # Fire event source. If handler exception is raised, set exception_raised to true
    try:
        event_source.fire()
    except:
        exception_raised = True

    #

# Generated at 2022-06-23 13:38:36.384469
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    new_handlers = [lambda: None]

    event_source += new_handlers[0]

    assert event_source._handlers == set(new_handlers)


# Generated at 2022-06-23 13:38:38.185570
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    collection_config = AnsibleCollectionConfig()
    assert collection_config.collection_finder is None

# Generated at 2022-06-23 13:38:46.825838
# Unit test for constructor of class _EventSource
def test__EventSource():
    def handler(arg):
        return arg

    es = _EventSource()
    assert es._on_exception is not None
    assert es._on_exception(handler, Exception(), 1) == True
    assert es._handlers == set()
    es += handler
    assert es._handlers == set([handler])
    es += handler
    assert es._handlers == set([handler])
    assert len(es._handlers) == 1
    es -= handler
    assert es._handlers == set()
    es -= handler
    assert es._handlers == set()


# Generated at 2022-06-23 13:38:48.197681
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig('meta', 'name', 'bases')

# Generated at 2022-06-23 13:38:54.834562
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    es = _EventSource()

    # call with a non callable value
    try:
        es -= 'not callable'
        assert False
    except ValueError:
        pass

    # call with a callable
    try:
        es -= callable
        assert False
    except KeyError:
        pass

# Generated at 2022-06-23 13:39:00.121861
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class A:
        def __init__(self):
            self.fired = False

        def callback(self):
            self.fired = True

    # add handler
    a = A()
    evt = _EventSource()
    evt += a.callback
    assert len(evt._handlers) == 1

    # remove handler
    evt -= a.callback
    assert len(evt._handlers) == 0

    # remove non-existent handler
    evt -= a.callback
    assert len(evt._handlers) == 0


# Generated at 2022-06-23 13:39:02.968619
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    es = _EventSource()
    es += lambda: 1
    es += lambda: 2

    assert len(es._handlers) == 2
    assert callable(es._handlers.pop())
    assert callable(es._handlers.pop())


# Generated at 2022-06-23 13:39:10.047246
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    class _EventSourceSubclass(_EventSource):
        def _on_exception(self, handler, exc, *args, **kwargs):
            return False

    event_source = _EventSourceSubclass()
    handler = lambda: None

    # Ensure removal of non-existing handler does not fail
    event_source -= handler

    # Ensure handler that is not callable fails when added
    def invalid_handler():
        raise Exception('I am not a callable handler')
    try:
        event_source += invalid_handler
        assert False
    except ValueError:
        event_source -= invalid_handler

    # Ensure handler is called when fired
    event_source += handler
    assert handler in event_source._handlers
    event_source.fire()
    assert handler in event_source._handlers

    # Ensure handler is not called when removed
   

# Generated at 2022-06-23 13:39:16.959983
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    from ansible_test._util.target.legacy_collection_loader.events import EventSource
    from ansible_test._util.target.legacy_collection_loader.events import Event

    events = EventSource()
    assert not events

    event = Event()
    events += event

    assert event in events
    assert events

    event2 = Event()
    assert event2 not in events

    events -= event2
    assert not events

# Generated at 2022-06-23 13:39:19.272949
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    from ansible.utils.collection_loader import _AnsibleCollectionConfig
    _AnsibleCollectionConfig('meta', 'name', 'bases')


# Generated at 2022-06-23 13:39:29.493290
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    # Any class that uses this metaclass has these properties
    assert hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert hasattr(AnsibleCollectionConfig, 'default_collection')
    assert hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert hasattr(AnsibleCollectionConfig, 'playbook_paths')

    # Each of these properties has either a getter or a getter and setter
    for prop in ('collection_finder', 'default_collection', 'on_collection_load'):
        assert callable(getattr(AnsibleCollectionConfig, prop))
        assert not callable(getattr(AnsibleCollectionConfig, prop).__set__)


# Generated at 2022-06-23 13:39:40.814230
# Unit test for method fire of class _EventSource
def test__EventSource_fire():

    # Setup _EventSource object
    event_source = _EventSource()

    # Set a default value for result
    result = None

    # Set a default value for arg
    arg = None

    # Set a default value for kwarg
    kwarg = None

    # Create a function _handler that sets result, arg and kwarg
    def _handler(arg, kwarg=None):
        nonlocal result
        result = arg
        nonlocal arg
        arg = arg
        nonlocal kwarg
        kwarg = kwarg

    # Add the function to the handlers
    event_source += _handler

    # Test the fire method
    event_source.fire('foo', kwarg='bar')

    # Assert result is 'foo'
    assert result == 'foo'

    # Assert arg is 'foo'


# Generated at 2022-06-23 13:39:44.179890
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():

    def handler0():
        pass

    # Negative test
    x = _EventSource()
    try:
        x += 42
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

    # Positive test
    x = _EventSource()
    x += handler0
    assert handler0 in x._handlers


# Generated at 2022-06-23 13:39:50.569575
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    # type: () -> None
    import ansible_collections
    import ansible.utils.collection_loader

    # Python 3.6+
    if hasattr(ansible_collections, '_load_ansible_collections'):
        # noinspection PyProtectedMember
        ansible_collections._load_ansible_collections(
            ansible.utils.collection_loader._AnsibleCollectionLoader._collection_config,
        )

    # Python 2.7
    elif hasattr(ansible_collections, 'load_ansible_collections'):
        # noinspection PyProtectedMember
        ansible_collections.load_ansible_collections(
            ansible.utils.collection_loader._AnsibleCollectionLoader._collection_config,
        )

# Generated at 2022-06-23 13:39:54.879025
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():

    c = AnsibleCollectionConfig()
    assert hasattr(c, 'collection_finder')
    assert hasattr(c, 'default_collection')
    assert hasattr(c, 'on_collection_load')
    assert hasattr(c, 'playbook_paths')



# Generated at 2022-06-23 13:39:59.103269
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert not hasattr(AnsibleCollectionConfig, '_collection_finder')
    assert not hasattr(AnsibleCollectionConfig, '_default_collection')
    assert not hasattr(AnsibleCollectionConfig, '_on_collection_load')
    assert not hasattr(AnsibleCollectionConfig, 'collection_finder')
    assert not hasattr(AnsibleCollectionConfig, 'collection_paths')
    assert not hasattr(AnsibleCollectionConfig, 'default_collection')
    assert not hasattr(AnsibleCollectionConfig, 'on_collection_load')
    assert not hasattr(AnsibleCollectionConfig, 'playbook_paths')

# Generated at 2022-06-23 13:40:01.403801
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    _AnsibleCollectionConfig.__init__(_AnsibleCollectionConfig, None, None, None)

# Generated at 2022-06-23 13:40:04.473222
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    event_source = _EventSource()
    handler1 = lambda: None
    handler2 = lambda: None

    event_source += handler1
    event_source += handler2

    handler_set = set(event_source._handlers)

    assert handler1 in handler_set
    assert handler2 in handler_set
    assert len(handler_set) == 2



# Generated at 2022-06-23 13:40:15.806805
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    calls = []
    event_source = _EventSource()

    def event_handler_1(*args, **kwargs):
        calls.append(('handler_1', args, kwargs))

    def event_handler_2(*args, **kwargs):
        calls.append(('handler_2', args, kwargs))

    def event_handler_3(*args, **kwargs):
        raise Exception("boo")

    event_source += event_handler_1
    event_source += event_handler_2
    event_source += event_handler_3

    try:
        event_source.fire("x", "y", "z")
    except Exception:
        pass


# Generated at 2022-06-23 13:40:27.415720
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MyCollectionConfig(with_metaclass(_AnsibleCollectionConfig)):
        pass

    # should be empty
    assert str(MyCollectionConfig._on_collection_load) == '<ansible.utils.collection_loader._EventSource object at 0x%x>' % id(MyCollectionConfig._on_collection_load)

    # should fail as we cannot set it to a None/empty value
    try:
        MyCollectionConfig.default_collection = None
    except ValueError:
        pass  # expected
    else:
        assert False, "expected ValueError for empty default_collection"

    # should fail as we cannot set it to a None/empty value
    try:
        MyCollectionConfig.on_collection_load = None
    except ValueError:
        pass  # expected

# Generated at 2022-06-23 13:40:31.127752
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class MetaClass(_AnsibleCollectionConfig):
        pass

    class MyClass(with_metaclass(MetaClass)):
        pass

    m = MyClass()

    assert m.on_collection_load



# Generated at 2022-06-23 13:40:40.155631
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    ev = _EventSource()

    # Initially, the set of registered handlers is empty.
    assert not ev._handlers

    # Assert we can register at least one handler successfully.
    # This is not a test of callable.
    def handler():
        pass

    ev += handler
    assert handler in ev._handlers

    # Assert handlers are invoked by fire.
    count = [0]

    def handler():
        count[0] += 1

    ev += handler
    ev.fire()
    assert count[0] == 1

    # Assert handlers not registered with the event source are not invoked.
    def handler2():
        count[0] += 1

    ev.fire()
    assert count[0] == 1
    ev.fire()
    assert count[0] == 2

    # Assert we can unregister a handler successfully

# Generated at 2022-06-23 13:40:42.825308
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    class _TestEventSource:
        def __add__(self, handler):
            pass

    e = _TestEventSource()
    assert e.__add__ == (_EventSource.__iadd__)

# Generated at 2022-06-23 13:40:46.774989
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    class TestClass(_AnsibleCollectionConfig):
        pass

    c = TestClass('meta', 'name', 'bases')
    assert c._on_collection_load._handlers == set()

# Generated at 2022-06-23 13:40:53.522942
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    def test_function():
        pass

    # Assert that the function is in the set of handlers before removing it
    event_source = _EventSource()
    assert test_function in event_source._handlers

    # Assert that the function is removed from the set of handlers after removing it
    event_source -= test_function
    assert test_function not in event_source._handlers


# Generated at 2022-06-23 13:40:55.903843
# Unit test for constructor of class _EventSource
def test__EventSource():
    import pytest

    class _TestEventSource(_EventSource):
        pass

    with pytest.raises(ValueError):
        _TestEventSource().fire(1)



# Generated at 2022-06-23 13:41:07.283174
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    count0 = 0
    def func0(*args, **kwargs):
        count0 += 1

    count1 = 0
    def func1(*args, **kwargs):
        count1 += 1

    count2 = 0
    def func2(*args, **kwargs):
        count2 += 1
        raise Exception

    count3 = 0
    def func3(*args, **kwargs):
        count3 += 1
        raise Exception

    source = _EventSource()
    source += func0
    source += func1
    source += func2
    source += func3

    assert source.count == 4
    assert source.handlers == (func0, func1, func2, func3)
    assert count0 == 0
    assert count1 == 0
    assert count2 == 0
    assert count3 == 0

    source.fire()


# Generated at 2022-06-23 13:41:17.351030
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    event = _EventSource()

    def handler_a(*args, **kwargs):
        raise ValueError('oops')

    def handler_b(*args, **kwargs):
        raise KeyError('oops')

    def handler_c(*args, **kwargs):
        raise TypeError('oops')

    def handler_d(a, b):
        pass

    event += handler_a
    event += handler_b
    event += handler_c
    event += handler_d

    try:
        event.fire(1, 2, 3)
        assert False, 'event.fire did not raise'
    except ValueError:
        assert True
    except BaseException:
        assert False, 'event.fire raised unexpected exception'

    event -= handler_a
    event -= handler_b
    event -= handler_c

    event += handler_d


# Generated at 2022-06-23 13:41:20.005847
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    cls = AnsibleCollectionConfig()
    assert cls._collection_finder is None
    assert cls._default_collection is None
    assert cls._on_collection_load is not None

# Generated at 2022-06-23 13:41:29.999742
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    assert event_source._handlers == set()
    handler1 = object()
    handler2 = object()
    event_source += handler1
    assert handler1 in event_source._handlers
    event_source += handler2
    assert handler2 in event_source._handlers
    event_source -= handler1
    assert handler1 not in event_source._handlers
    event_source -= handler2
    assert handler2 not in event_source._handlers
    event_source -= handler1
    assert handler1 not in event_source._handlers


# Generated at 2022-06-23 13:41:36.898863
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():

    # Test removing handler from event source
    def handler(value):
        pass

    ev = _EventSource()
    ev += handler
    ev -= handler
    assert not ev._handlers

    # Test removing from empty event source
    ev -= handler
    assert not ev._handlers

    # Test removing non-existent handler
    def other_handler(value):
        pass

    ev -= other_handler
    assert not ev._handlers

    # Test removing handler twice
    ev += handler
    ev -= handler
    ev -= handler
    assert not ev._handlers



# Generated at 2022-06-23 13:41:38.570607
# Unit test for constructor of class _EventSource
def test__EventSource():
    event_source = _EventSource()
    assert event_source



# Generated at 2022-06-23 13:41:39.747701
# Unit test for constructor of class _EventSource
def test__EventSource():
    ev = _EventSource()


# Generated at 2022-06-23 13:41:43.041132
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.default_collection is None
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.on_collection_load is not None
    assert AnsibleCollectionConfig.playbook_paths == []

# Generated at 2022-06-23 13:41:48.010804
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()

    assert config._collection_finder is None
    assert config._default_collection is None
    assert isinstance(config._on_collection_load, _EventSource)
    assert len(config._on_collection_load._handlers) == 0


# Generated at 2022-06-23 13:41:56.718738
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    class TestAnsibleCollectionConfig(AnsibleCollectionConfig):
        pass

    assert TestAnsibleCollectionConfig._collection_finder is None
    assert TestAnsibleCollectionConfig._default_collection is None
    assert TestAnsibleCollectionConfig.collection_finder is None
    assert TestAnsibleCollectionConfig.default_collection is None
    assert isinstance(TestAnsibleCollectionConfig.on_collection_load, _EventSource)
    assert TestAnsibleCollectionConfig.on_collection_load == TestAnsibleCollectionConfig._on_collection_load
    assert TestAnsibleCollectionConfig.on_collection_load is not TestAnsibleCollectionConfig._on_collection_load

# Generated at 2022-06-23 13:41:58.698940
# Unit test for constructor of class _EventSource
def test__EventSource():
    es = _EventSource()
    assert es is not None

# Generated at 2022-06-23 13:42:02.711811
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    config = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert not config._collection_finder
    assert not config._default_collection
    assert isinstance(config._on_collection_load, _EventSource)

# Generated at 2022-06-23 13:42:03.531127
# Unit test for constructor of class _EventSource
def test__EventSource():
    assert _EventSource()

# Generated at 2022-06-23 13:42:07.275186
# Unit test for constructor of class _EventSource
def test__EventSource():
    import mock
    import pytest
    e = _EventSource()
    assert callable(e) is False
    assert not e._handlers
    assert isinstance(e, _EventSource) is True


# Generated at 2022-06-23 13:42:10.369701
# Unit test for method __isub__ of class _EventSource
def test__EventSource___isub__():
    event_source = _EventSource()
    handler = lambda: None
    event_source -= handler
    assert list(event_source._handlers) == []


# Generated at 2022-06-23 13:42:20.317909
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    assert AnsibleCollectionConfig.__name__ == 'AnsibleCollectionConfig'
    assert isinstance(AnsibleCollectionConfig.collection_finder, property)
    assert isinstance(AnsibleCollectionConfig.collection_paths, property)
    assert isinstance(AnsibleCollectionConfig.default_collection, property)
    assert isinstance(AnsibleCollectionConfig.on_collection_load, property)
    assert isinstance(AnsibleCollectionConfig.playbook_paths, property)
    assert AnsibleCollectionConfig.collection_paths == []
    assert AnsibleCollectionConfig.default_collection is None
    assert isinstance(AnsibleCollectionConfig.on_collection_load, _EventSource)

# Generated at 2022-06-23 13:42:29.628297
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    test_run_count = 0
    def _test_handler(*args, **kwargs):
        nonlocal test_run_count
        test_run_count += 1
        if kwargs:
            raise RuntimeError("It's bad")
        return args
    test_event = _EventSource()
    test_event += _test_handler
    test_event += _test_handler
    test_event += _test_handler
    test_event += _test_handler
    test_event.fire()
    assert test_run_count == 4

    test_run_count = 0
    def _test_bad_handler(*args, **kwargs):
        nonlocal test_run_count
        test_run_count += 1
        raise RuntimeError("foo")
    test_event += _test_bad_handler

# Generated at 2022-06-23 13:42:32.134937
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    a = AnsibleCollectionConfig()
    assert a._collection_finder is None
    assert a._default_collection is None

# Generated at 2022-06-23 13:42:42.979060
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _EventSourceTest(_EventSource):
        def __init__(self):
            super(_EventSourceTest, self).__init__()
            self.events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self.events.append((handler, exc, args, kwargs, 'exception'))
            return True

    sut = _EventSourceTest()

    def handler_1(*args, **kwargs):
        sut.events.append((handler_1, args, kwargs))

    def handler_2(*args, **kwargs):
        sut.events.append((handler_2, args, kwargs))

    def handler_3(*args, **kwargs):
        sut.events.append((handler_3, args, kwargs))
        raise Value

# Generated at 2022-06-23 13:42:44.853413
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    ans_collection_config = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert isinstance(ans_collection_config, _AnsibleCollectionConfig)



# Generated at 2022-06-23 13:42:48.038286
# Unit test for method __iadd__ of class _EventSource
def test__EventSource___iadd__():
    evt = _EventSource()

    a = []

    evt += a.append
    evt += lambda evt: a.append(2)

    evt.fire()

    assert a == [1, 2]


# to avoid pycodestyle warnings about unused imports
__all__ = [
    AnsibleCollectionConfig,
    _AnsibleCollectionConfig,
    _EventSource,
    test__EventSource___iadd__,
]

# Generated at 2022-06-23 13:42:50.921111
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    config = AnsibleCollectionConfig()
    assert config._collection_finder is None
    assert config.collection_finder is None


__all__ = [
    'AnsibleCollectionConfig',
]

# Generated at 2022-06-23 13:42:57.568438
# Unit test for method fire of class _EventSource
def test__EventSource_fire():
    class _TestEventSource(_EventSource):
        def __init__(self):
            super(_EventSource, self).__init__()
            self._events = []

        def _on_exception(self, handler, exc, *args, **kwargs):
            self._events.append(('exception', exc))
            true_or_false = False if handler == 'handle_no_key' else True
            return true_or_false

    _es = _TestEventSource()

    def handler_with_exception(exc):
        raise exc

    def handler_with_no_parameters():
        pass

    def handler_with_positional_parameters(*args):
        pass

    def handler_with_keyword_parameters(**kwargs):
        pass

    _es += handler_with_exception

# Generated at 2022-06-23 13:43:05.568760
# Unit test for constructor of class _EventSource
def test__EventSource():
    class Foo:
        def __init__(self):
            self.x = 0

        def y(self, *args, **kwargs):
            self.x += 1

    events = _EventSource()
    assert len(events._handlers) == 0
    f = Foo()
    events.fire()
    assert f.x == 0
    events += f.y
    assert len(events._handlers) == 1
    events += f.y
    assert len(events._handlers) == 1
    events.fire()
    assert f.x == 1

# Generated at 2022-06-23 13:43:08.603060
# Unit test for constructor of class _AnsibleCollectionConfig
def test__AnsibleCollectionConfig():
    obj = _AnsibleCollectionConfig('meta', 'name', 'bases')
    assert(not obj._collection_finder)
    assert(not obj._default_collection)
    assert(isinstance(obj._on_collection_load, _EventSource))


# Generated at 2022-06-23 13:43:11.563046
# Unit test for constructor of class AnsibleCollectionConfig
def test_AnsibleCollectionConfig():
    assert AnsibleCollectionConfig
    assert AnsibleCollectionConfig.__name__ == 'AnsibleCollectionConfig'
    assert AnsibleCollectionConfig.__class__ == _AnsibleCollectionConfig
    assert AnsibleCollectionConfig.__metaclass__ == _AnsibleCollectionConfig