

# Generated at 2022-06-20 14:05:10.169354
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('msg', 'python', 'auto_legacy')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'msg'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto_legacy'

# Generated at 2022-06-20 14:05:15.625770
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = "discovery required for host"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert isinstance(error, Exception)
    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-vv'])

# Generated at 2022-06-20 14:05:30.746757
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.action.setup
    # Testcase 1
    def _build_action_tests(**kwargs):
        class MyActionModule(ansible.plugins.action.setup.ActionModule):
            _connection = None

            def __init__(self, **kwargs):
                super(MyActionModule, self).__init__(**kwargs)
                self._supports_pipelining = True
                self._supports_async = True
                self._supports_check_mode = True
                self._connection = MyConnection()

            def _low_level_execute_command(self, cmd, sudoable=False, in_data=None, su=None, **kwargs):
                return self._connection.execute(cmd, in_data=in_data, sudoable=sudoable)


# Generated at 2022-06-20 14:05:31.445220
# Unit test for function discover_interpreter
def test_discover_interpreter():
    return

# Generated at 2022-06-20 14:05:34.687957
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(message=u"test message", interpreter_name=u"python", discovery_mode=u"auto")
    expected_result = u"test message"
    result = error.__repr__()
    assert result == expected_result

# Generated at 2022-06-20 14:05:36.215521
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("error message", "python", "auto")
    assert str(error) == 'error message'

# Generated at 2022-06-20 14:05:41.463035
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class Action(object):
        _discovery_warnings = []

        def __init__(self):
            self.task_vars = dict(
                ansible_python_interpreter=None,
                ansible_python_version=None,
                ansible_python_prefix=None,
                ansible_python_major_version=None,

            )

    class Connection(object):
        def __init__(self, has_pipelining=True):
            self.has_pipelining = has_pipelining

    def _low_level_execute_command(self, path, sudoable=False, in_data=None):
        return dict(stdout=in_data)



# Generated at 2022-06-20 14:05:46.508933
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = 'Failed to find interpreter for test'
    try:
        raise InterpreterDiscoveryRequiredError(msg, 'test', 'silent')
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == msg
        assert e.interpreter_name == 'test'
        assert e.discovery_mode == 'silent'

# Generated at 2022-06-20 14:05:49.824518
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(message="InterpreterDiscoveryRequiredError", interpreter_name="python3",
                                            discovery_mode="auto_legacy")
    assert str(err) == "InterpreterDiscoveryRequiredError"


# Generated at 2022-06-20 14:05:52.709091
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert error.__str__() == "message"

#Unit test for method __repr__ of class InterpreterDiscoveryRequiredError

# Generated at 2022-06-20 14:06:11.878365
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.compat import unittest
    from ansible.executor.discovery import InterpreterDiscoveryRequiredError, discover_interpreter

    class TestDiscovery(unittest.TestCase):

        def test_interpreter_discovery_required_error(self):
            # testing __init__
            e = InterpreterDiscoveryRequiredError(message="testing", interpreter_name="python", discovery_mode="auto")
            self.assertEqual("testing", str(e))
            self.assertEqual("python", e.interpreter_name)
            self.assertEqual("auto", e.discovery_mode)

            # testing repr
            r = repr(e)
            self.assertEqual(r, "testing")

        def test_discover_interpreter(self):
            r = discover_inter

# Generated at 2022-06-20 14:06:14.515950
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(
        'it message',
        'py3',
        'auto'
    )
    assert error.__repr__() == 'it message'



# Generated at 2022-06-20 14:06:27.519079
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test
    task_vars = {
        'ansible_connection': 'ssh',
        'ansible_become_password': '0',
        'ansible_become': '1',
        'ansible_become_method': 'sudo',
        'ansible_become_user': 'root',
        'ansible_version': {
            'full': '2.6.1',
            'major': 2,
            'minor': 6,
            'revision': 1,
            'string': '2.6.1'
        }
    }

    class NoopAction:
        _discovery_warnings = []


# Generated at 2022-06-20 14:06:43.558490
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    action = {'args': 'test'}
    task_vars = {'interpreter_name': 'python'}

    error = InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python', discovery_mode='auto')
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

    error = InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python', discovery_mode='required')
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'required'

    error = InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python', discovery_mode='none')
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'none'


# Generated at 2022-06-20 14:06:44.655437
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: test cases?
    pass

# Generated at 2022-06-20 14:06:51.978735
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_message = 'aaa'
    interpreter_name = 'bbb'
    discovery_mode = 'ccc'
    exception = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert exception.message == error_message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode
    assert str(exception) == error_message
    assert repr(exception) == error_message
    assert exception.__class__ is InterpreterDiscoveryRequiredError


# Generated at 2022-06-20 14:07:00.338193
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError(
        message="Interpreter discovery is required to run the module python, please see the module documentation for "
                "details.",
        interpreter_name="python",
        discovery_mode="auto")
    assert err.interpreter_name == "python"
    assert err.discovery_mode == "auto"

    assert str(err) == err.message
    assert repr(err) == err.message



# Generated at 2022-06-20 14:07:04.276198
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    discovery_mode = 'auto'
    interpreter_name = 'python'
    message = 'test_message'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert error.__str__() == message


# Generated at 2022-06-20 14:07:09.055473
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('hello', 'python', 'auto')
    except Exception as ex:
        assert isinstance(ex, InterpreterDiscoveryRequiredError)
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto'

# Generated at 2022-06-20 14:07:12.105711
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    expected = 'msg: msg'
    error = InterpreterDiscoveryRequiredError('msg', 'interpreter', 'discovery mode')
    assert expected == str(error)

# Generated at 2022-06-20 14:07:31.164433
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'foo'
    discovery_mode = 'bar'
    message = 'baz'
    idre = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert idre.message == message
    assert idre.interpreter_name == interpreter_name
    assert idre.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:07:34.140947
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'test_message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert error.message == msg
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert str(error) == msg

# Generated at 2022-06-20 14:07:39.760067
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # arrange
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'interpreter discovery required'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    #act
    actual_str = str(exception)

    #assert
    assert actual_str == message

# Generated at 2022-06-20 14:07:47.833843
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # assertRaisesRegexp can only be used in Python 2.7+
    # The below code is equivalent to this Python 2.7+ code
    # from assertRaisesRegexp(ValueError, 'Interpreter discovery not supported for foobar'):
    #     discover_interpreter(None, 'foobar', 'auto', {})

    try:
        discover_interpreter(None, 'foobar', 'auto', {})
    except ValueError as ex:
        if 'Interpreter discovery not supported for foobar' not in to_text(ex):
            raise
    else:
        raise AssertionError('Expected ValueError to be raised')


# Generated at 2022-06-20 14:07:56.766091
# Unit test for function discover_interpreter
def test_discover_interpreter():

    import unittest

    class TestActionModule(object):

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd.startswith('python'):
                return {'stdout': '{"stdout": "dummy_platform_dist_results"}', 'stderr': ''}

            return {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND', 'stderr': ''}

        @property
        def _discovery_warnings(self):
            return []

        @property
        def _connection(self):
            return TestConnection()

    class TestConnection(object):
        @property
        def has_pipelining(self):
            return True


# Generated at 2022-06-20 14:08:05.573358
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception_msg = 'Exception message'
    interpreter_name = 'Python3'
    discovery_mode = 'auto'
    try:
        raise InterpreterDiscoveryRequiredError(exception_msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == exception_msg
        assert ex.interpreter_name == interpreter_name
        assert ex.discovery_mode == discovery_mode
    except Exception as e:
        assert False, "InterpreterDiscoveryRequiredError was not an expected exception"

# Generated at 2022-06-20 14:08:22.907893
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.utils.shlex import shlex_split

    # TODO: this test could be a LOT more thorough
    def _mock_execute(*args, **kwargs):
        if kwargs.get('in_data') and kwargs.get('command') == u'/usr/bin/python':
            return {'stdout': json.dumps({'platform_dist_result': ['centos', '7.4.1708', 'Core'],
                                          'osrelease_content': 'NAME="CentOS Linux"\nVERSION="7 (Core)"'})}
        return {'stdout': u'PLATFORM\nlinux\nFOUND\n/usr/bin/python3\n/usr/bin/python\nENDFOUND'}


# Generated at 2022-06-20 14:08:38.284015
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    # Test that the constructor is working properly
    interp_name = 'python'
    discovery_mode = 'auto'
    message = "Python interpreter discovery is required for this host, but discovery mode '{0}' is not supported for '{1}'"\
        .format(discovery_mode, interp_name)
    exception = InterpreterDiscoveryRequiredError(message, interp_name, discovery_mode)

    assert exception.interpreter_name == interp_name, \
        "Expected '{0}'; got '{1}'".format(interp_name, exception.interpreter_name)
    assert exception.discovery_mode == discovery_mode, \
        "Expected '{0}'; got '{1}'".format(discovery_mode, exception.discovery_mode)

# Generated at 2022-06-20 14:08:43.417225
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    message = 'No python interpreters found for host i-xxxxx (tried [u\'/usr/bin/python\', u\'/usr/bin/python3\'])'

    result = InterpreterDiscoveryRequiredError(message, 'python', 'auto_legacy_silent').__str__()
    assert result == message



# Generated at 2022-06-20 14:08:45.522336
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_obj = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy_silent")
    result = str(test_obj)
    assert result == 'message'

# Generated at 2022-06-20 14:09:58.787734
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Action:
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == 'echo PLATFORM; uname; echo FOUND; command -v \'python2.7\'; echo ENDFOUND':
                return {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python2.7\n/usr/bin/python3.5\nENDFOUND'}

            if cmd == '/usr/bin/python2.7':
                return {'stdout': json.dumps({'platform_dist_result': ['fedora', '25', 'Server Edition']})}


# Generated at 2022-06-20 14:10:06.098540
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    actual_result = repr(InterpreterDiscoveryRequiredError('The interpreter /usr/bin/python is not available on this system, but the '
                                                           'system also does not support automatic discovery of the interpreter '
                                                           'location. Specify the interpreter location explicitly or set '
                                                           '"interpreter_discovery_mode" to "auto" to enable automatic discovery',
                                                           'python', 'auto_legacy_silent'))
    expected_result = 'The interpreter /usr/bin/python is not available on this system, but the system also does not ' \
                      'support automatic discovery of the interpreter location. Specify the interpreter location ' \
                      'explicitly or set "interpreter_discovery_mode" to "auto" to enable automatic discovery'

    assert actual_result == expected_result

# Generated at 2022-06-20 14:10:11.879007
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.utils import plugins
    import os

    class NoopActionModule(plugins.ActionBase):
        def run(self, tmp=None, task_vars=None):
            return dict(changed=False, msg='noop')

    class NoopModule(plugins.ActionModule):
        def run(self, tmp=None, task_vars=None):
            return self._execute_module(module_name='noop', module_args=dict(), task_vars=task_vars)

    class NoopAction(plugins.ActionBase):
        def run(self, tmp=None, task_vars=None):
            return self._execute_module(module_name='noop', module_args=dict(), task_vars=task_vars)


# Generated at 2022-06-20 14:10:16.518194
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'silent'
    error_message = 'ERROR!'
    exception = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)

    assert exception.__str__() == error_message

# Generated at 2022-06-20 14:10:21.396750
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = "Test"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode


# Generated at 2022-06-20 14:10:25.381512
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # given
    ider = InterpreterDiscoveryRequiredError(u'foo', u'python', u'mode')

    # when
    result = repr(ider)

    # then
    assert result == u'foo'



# Generated at 2022-06-20 14:10:29.393298
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test = InterpreterDiscoveryRequiredError("test", "test", "test")
    assert test.interpreter_name == "test"
    assert test.discovery_mode == "test"
    assert test.message == "test"

# Generated at 2022-06-20 14:10:37.848267
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'Interpreter discovery required for {} interpreter, but discovery mode {} on host ' \
              'somename is unable to perform discovery. Discovery failed with an error: facts are no available'\
        .format(interpreter_name, discovery_mode)

    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == str(e)

# Generated at 2022-06-20 14:10:39.784004
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('message', 'python2', 'auto')
    assert exc.__repr__() == 'message'

# Generated at 2022-06-20 14:10:46.586329
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError(
        message=u'Message\nwith\nnewline',
        interpreter_name=u'Python',
        discovery_mode=u'auto_legacy_silent'
    )
    exc1 = InterpreterDiscoveryRequiredError(
        message=u'Message\nwith\nnewline',
        interpreter_name=u'Python',
        discovery_mode=u'auto_legacy_silent'
    )
    assert (str(exc) == str(exc1))

# Generated at 2022-06-20 14:11:56.431323
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('msg', 'interpreterName', 'discoveryMode')
    expected = 'msg'
    assert e.__repr__() == expected
# end of def test_InterpreterDiscoveryRequiredError___repr__()


# Generated at 2022-06-20 14:12:01.022624
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError(u'ansible requires python interpreter discovery', u'python', u'auto')
    expected_repr = u"ansible requires python interpreter discovery"
    assert(obj.__repr__() == expected_repr)



# Generated at 2022-06-20 14:12:05.102904
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('system', 'python', 'fatal')
    except InterpreterDiscoveryRequiredError as exc:
        assert exc.interpreter_name == 'python'
        assert exc.discovery_mode == 'fatal'
    else:
        assert False, "Did not raise InterpreterDiscoveryRequiredError exception"

# Generated at 2022-06-20 14:12:08.464424
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert error.__repr__() == "message"

# Generated at 2022-06-20 14:12:16.121203
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(
        message="The default interpreter discovery mode is not allowed in a playbook",
        interpreter_name='python',
        discovery_mode="auto_legacy")
    assert error.message == "The default interpreter discovery mode is not allowed in a playbook"
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == "auto_legacy"
    assert str(error) == "The default interpreter discovery mode is not allowed in a playbook"

# Generated at 2022-06-20 14:12:19.701624
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import doctest

    results = doctest.testmod(verbose=True)

    if results.failed:
        raise Exception('test_discover_interpreter() had {0} failures'.format(results.failed))

# Generated at 2022-06-20 14:12:24.154588
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("should be caught", "python", "auto_legacy")
    except InterpreterDiscoveryRequiredError as e:
        assert e.discovery_mode == "auto_legacy"
        assert str(e) == "should be caught"
        assert "InterpreterDiscoveryRequiredError" in repr(e)

# Generated at 2022-06-20 14:12:28.430206
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = None
    task_vars = None
    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

# Generated at 2022-06-20 14:12:32.395824
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert exception.__repr__() == exception.message

# Generated at 2022-06-20 14:12:36.471907
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    return_value = 42
    instance = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert instance.__repr__() == "message"

# Generated at 2022-06-20 14:14:44.834598
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    """Tests the constructor of class InterpreterDiscoveryRequiredError
    """
    i = InterpreterDiscoveryRequiredError("test error", "test_interpreter", "test_discovery")
    assert i.message == 'test error'
    assert i.interpreter_name == 'test_interpreter'
    assert i.discovery_mode == 'test_discovery'


# Generated at 2022-06-20 14:14:47.292847
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError("message", 'python', 'auto')
    assert exc.__str__() == 'message'

# Generated at 2022-06-20 14:14:49.021914
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert repr(err) == "message"

# Generated at 2022-06-20 14:14:50.662883
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert isinstance(discover_interpreter, object)

# TODO: add doctest for function discover_interpreter

# Generated at 2022-06-20 14:14:52.975855
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """
    Make sure we don't get an exception when calling __repr__
    """
    exception = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    repr(exception)