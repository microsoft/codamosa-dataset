

# Generated at 2022-06-20 14:05:15.118976
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.parsing.vault import VaultLib

    try:
        import platform
        HAS_PLATFORM = True
    except ImportError:
        HAS_PLATFORM = False

    try:
        import json
        HAS_JSON = True
    except ImportError:
        HAS_JSON = False

    class TestInterpreterActionModule(_ActionModule):
        def _execute_module(self):
            pass

    if not HAS_JSON:
        raise AssertionError('platform module not available')

    if not HAS_PLATFORM:
        raise AssertionError('platform module not available')

    pd = platform.dist()
    dist_version = '.'.join(pd[1].split('.')[0:2])

    my_platform

# Generated at 2022-06-20 14:05:23.216439
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("test", 1, 2)
    assert repr(error) == 'test'



# Generated at 2022-06-20 14:05:24.483750
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter({}, 'python', 'auto_legacy', {}) == u'/usr/bin/python'

# Generated at 2022-06-20 14:05:33.817686
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test good path (tmp/foo & /usr/bin/python present)
    assert discover_interpreter(None, 'python', 'auto', {}) == '/usr/bin/python'

    # test good path (tmp/foo & /usr/bin/python not present)
    assert discover_interpreter(None, 'python', 'auto', {'INTERPRETER_PYTHON_FALLBACK': ['tmp/foo']}) == 'tmp/foo'

    # test bad interpreter name
    try:
        discover_interpreter(None, 'python3', 'auto', {})
        assert False
    except ValueError:
        assert True

    # test unsupported platform name

# Generated at 2022-06-20 14:05:37.452022
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('test_message', 'python_foo', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'test_message'
        assert e.interpreter_name == 'python_foo'
        assert e.discovery_mode == 'auto_legacy_silent'


# Generated at 2022-06-20 14:05:47.877418
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = 'action_mock'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {
        'inventory_hostname': 'mock_host',
        'config': {
            'INTERPRETER_PYTHON_DISTRO_MAP': {
                'fedora': {
                    '31': u'/usr/bin/python3'
                }
            },
            'INTERPRETER_PYTHON_FALLBACK': [u'/usr/bin/python3']
        }
    }

    action_result = None

    def execute_command(cmd, sudoable=True, in_data=None):
        assert cmd == u'/usr/bin/python3'
        assert not sudoable  # Not expecting sudo here
        assert in_data  # Will assert later that we

# Generated at 2022-06-20 14:05:52.016186
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Create an object of the class InterpreterDiscoveryRequiredError
    obj = InterpreterDiscoveryRequiredError('Message','python','auto')

    # Convert obj to a string and assert it is equal to the expected __repr__ value
    assert str(obj) == "Message"

# Generated at 2022-06-20 14:05:55.774949
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Interpreter discovery required for python"
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.interpreter_name == "python"
    assert exception.discovery_mode == "auto"


# Unit tests for function discover_interpreter


# Generated at 2022-06-20 14:06:00.255204
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(message=u'message', interpreter_name=u'python', discovery_mode=u'auto')
    assert err.__str__() == u'message'

# Generated at 2022-06-20 14:06:11.664324
# Unit test for function discover_interpreter

# Generated at 2022-06-20 14:06:31.626003
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.plugins import action
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.basic import AnsibleModule, json, env_fallback
    from ansible.module_utils.six.moves import cStringIO

    from ansible.module_utils import common_koji
    from ansible.module_utils.common.process import get_bin_path


# Generated at 2022-06-20 14:06:38.163141
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    host = 'unit-test-host'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Python interpreter discovery required for host {}'.format(host)
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.__repr__() == e.message

# Generated at 2022-06-20 14:06:45.215813
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = u'something happened'
    interpreter_name = u'python'
    discovery_mode = 'auto'

    interpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # Test idempotence
    assert interpreterDiscoveryRequiredError.__str__() == interpreterDiscoveryRequiredError.__str__()

    # Test equality
    assert interpreterDiscoveryRequiredError.__str__() == message

# Generated at 2022-06-20 14:06:48.432378
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError("Some message", "python", "auto_legacy_silent")

    assert str(exception) == "Some message"
    assert repr(exception) == "Some message"

# Generated at 2022-06-20 14:06:50.498170
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: test with action_mocker or similar for the low-level execute command
    pass

# Generated at 2022-06-20 14:07:04.436204
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.linux import LinuxDistribution
    from ansible.plugins.action import ActionBase
    from ansible.errors import AnsibleError
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult

    class FakeDisplay(object):
        def __init__(self):
            self.warnings = []

        def warning(self, msg):
            self.warnings.append(msg)

        def debug(self, msg):
            pass

        def vvv(self, msg):
            pass

    class FakeActionBase(ActionBase):
        def __init__(self):
            self._use_shell = False
            self._low_level_execute_command = lambda a, b: {'stdout': a}
            self._play_context = None
            self._

# Generated at 2022-06-20 14:07:13.724834
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.six import PY2


# Generated at 2022-06-20 14:07:16.774625
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("test", "python", "auto_silent")
    assert str(error) == "test"

# Generated at 2022-06-20 14:07:29.543795
# Unit test for function discover_interpreter
def test_discover_interpreter():

    import unittest
    class PythonDiscoveryTests(unittest.TestCase):

        def test_version_fuzzy_match(self):
            self.assertEqual(_version_fuzzy_match('2.7.11', {'2.7.3': 'python27', '2.7.11': 'python2711', '2.7.12': 'python2712', '3.3.3': 'python33'}), 'python2711')
            self.assertEqual(_version_fuzzy_match('2.6.9', {'2.6.3': 'python26', '2.6.11': 'python2611'}), 'python26')

# Generated at 2022-06-20 14:07:42.363371
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    import os
    import sys
    from pprint import pprint
    from ansible.utils.module_docs import get_docstring
    from ansible.plugins.action import ActionBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    display = Display()

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    test_host = inventory.add_host(host='localhost')

    # set the action on the host


# Generated at 2022-06-20 14:08:03.967326
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert repr(e) == "message"


if __name__ == '__main__':
    import sys
    import subprocess
    import unittest

    class TestInterpreterDiscovery(unittest.TestCase):
        def test_auto_legacy_silent(self):
            # This doesn't really make sense to run in a unit test environment
            # But it's better than nothing for now
            module = """#!/usr/bin/python

import sys
import platform
import json

print(json.dumps({'platform_dist_result': platform.dist(),
                  'osrelease_content': sys.stdin.read()}))
"""

# Generated at 2022-06-20 14:08:08.447765
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'interpreter_name'
        assert e.discovery_mode == 'discovery_mode'

# Generated at 2022-06-20 14:08:13.802094
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert ex.interpreter_name == 'python'
    assert ex.discovery_mode == 'auto'
    assert str(ex) == 'message'



# Generated at 2022-06-20 14:08:22.265518
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_interpreter_name = 'python'
    task_vars = {}
    action = object()
    action.run = False
    action.deprecated = False
    action._low_level_execute_command = 'echo'
    action._connection = object()
    action._connection.has_pipelining = True
    action._discovery_warnings = []
    test_discovery_mode = 'auto'

    try:
        output = discover_interpreter(action, test_interpreter_name, test_discovery_mode, task_vars)
    except InterpreterDiscoveryRequiredError as ex:
        if ex.interpreter_name == test_interpreter_name and ex.discovery_mode == test_discovery_mode:
            pass
        else:
            raise

# Generated at 2022-06-20 14:08:31.594015
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class test_action():

        def __init__(self):
            self._connection = test_connection()
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=None, in_data=None):
            return self._connection.execute(command, sudoable=sudoable, in_data=in_data)

    class test_connection():

        def __init__(self):
            self.has_pipelining = True

        def execute(self, command, sudoable=None, in_data=None):
            return self.execute_normal(command, sudoable=sudoable, in_data=in_data)

        def execute_normal(self, command, sudoable=None, in_data=None):
            platform = "Linux"

# Generated at 2022-06-20 14:08:35.185635
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(message='this is a message', interpreter_name='python', discovery_mode='force_legacy_silent')
    assert str(err) == 'this is a message'

# Generated at 2022-06-20 14:08:44.208624
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    conn = Connection()
    goods_result = {'uname': 'Linux', 'env': {}, 'stdout': "PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/bin/python2\nENDFOUND\n", 'cmd': "/usr/bin/python", 'rc': 0, 'changed': False, 'stderr': '', 'invocation': {'module_name': None}, 'stdout_lines': ['PLATFORM', 'Linux', 'FOUND', '/usr/bin/python', '/bin/python2', 'ENDFOUND'], 'warnings': []}
    tasks

# Generated at 2022-06-20 14:08:55.747892
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None,
                                'python',
                                'auto_legacy_silent',
                                {'interpreter': '/usr/bin/python',
                                 'inventory_hostname': 'myhost'},
                                ) == '/usr/bin/python'
    assert discover_interpreter(None,
                                'python',
                                'auto_legacy_silent',
                                {'inventory_hostname': 'myhost'},
                                ) == '/usr/bin/python'

# Generated at 2022-06-20 14:08:59.666197
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError("message", "python2", "auto")
    assert err.interpreter_name == "python2"
    assert err.discovery_mode == "auto"
    assert str(err) == "message"

# Generated at 2022-06-20 14:09:03.727820
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert exc.message == 'message'
    assert exc.interpreter_name == 'interpreter_name'
    assert exc.discovery_mode == 'discovery_mode'

# Generated at 2022-06-20 14:09:23.673039
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', {}) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', {}) is None
    assert discover_interpreter(None, 'python', 'auto', {}) is None
    assert discover_interpreter(None, 'python', 'force_silent', {}) is None
    assert discover_interpreter(None, 'python', 'force', {}).startswith('InterpreterDiscoveryRequiredError:')

# Generated at 2022-06-20 14:09:26.586737
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Test with interpreter_name
    error = InterpreterDiscoveryRequiredError('inconsistent', 'interpreter_name', 'discovery_mode')
    assert error.__repr__() == 'inconsistent'



# Generated at 2022-06-20 14:09:40.055032
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    action = ActionBase()
    interpreter_name = 'python'
    discovery_mode = 'auto'
    inventory_hostname = '127.0.0.1'
    port = '22'
    task_vars = dict()
    task_vars["inventory_hostname"] = inventory_hostname
    task_vars["ansible_python_interpreter"] = None
    task_vars["ansible_ssh_host"] = inventory_hostname
    task_vars["ansible_connection"] = 'local'
    task_vars["ansible_ssh_port"] = port
    task_vars["ansible_winrm_server_cert_validation"] = 'ignore'

    # Create fake ActionBase object to test discover_interpreter function

# Generated at 2022-06-20 14:09:50.821023
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Python interpreter discovery required'
    InterpreterDiscoveryRequiredError_object = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == InterpreterDiscoveryRequiredError_object.message
    assert interpreter_name == InterpreterDiscoveryRequiredError_object.interpreter_name
    assert discovery_mode == InterpreterDiscoveryRequiredError_object.discovery_mode


# Generated at 2022-06-20 14:09:53.699301
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Test if the method __str__ returns the right error message
    # Arrange
    msg = "Error Message"
    interpreter_name = "python"
    discovery_mode = "auto"
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    # Act
    result = str(interpreter_discovery_required_error)

    # Assert
    assert result == msg

# Generated at 2022-06-20 14:10:02.406513
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'message'
    discovery_required_error = InterpreterDiscoveryRequiredError(
        message=message,
        interpreter_name=interpreter_name,
        discovery_mode=discovery_mode)

    assert str(discovery_required_error) == message

    # test default interpreter_name and discovery_mode values
    del discovery_required_error.interpreter_name
    del discovery_required_error.discovery_mode
    assert str(discovery_required_error) == message

    # test default message value
    del discovery_required_error.message
    assert str(discovery_required_error) == ''



# Generated at 2022-06-20 14:10:05.443933
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    expected_message = "message"
    interpreter_name = "ansible_python_interpreter"
    discovery_mode = "auto_legacy_silent"
    error = InterpreterDiscoveryRequiredError(expected_message, interpreter_name, discovery_mode)
    assert error.__str__() == expected_message


# Generated at 2022-06-20 14:10:09.427761
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('this is a Interpreter Discovery Required Error','python','auto')
    except Exception as ex:
        print(ex)


# Generated at 2022-06-20 14:10:15.379015
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = InterpreterDiscoveryRequiredError(message=None, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert message.interpreter_name == interpreter_name
    assert message.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:10:19.251310
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(
        "some message",
        "python",
        "auto_legacy_silent"
    )
    assert(error.interpreter_name == 'python')
    assert(error.discovery_mode == 'auto_legacy_silent')

# Generated at 2022-06-20 14:10:39.365232
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError("Message", "python", "auto")
    # Check that getters contract holds
    assert e.interpreter_name == "python"
    assert e.discovery_mode == "auto"

# Generated at 2022-06-20 14:10:47.684087
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_message = "Python interpreter discovery required"
    # InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    idr_err = InterpreterDiscoveryRequiredError(error_message, "python", "auto_legacy_silent")
    assert(idr_err.__repr__() == error_message)

# Generated at 2022-06-20 14:10:52.414334
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Arrange
    foo = InterpreterDiscoveryRequiredError('message', 'interp_name', 'discovery_mode')
    expected_result = foo.message

    # Act
    result = repr(foo)

    # Assert
    assert result == expected_result



# Generated at 2022-06-20 14:10:58.102217
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("The python interpreter is not present", "python", "auto")
    assert error.__str__() == "The python interpreter is not present. Try setting interpreter_discovery_mode=auto."
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"

# Generated at 2022-06-20 14:11:03.816291
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('message', 'python', 'release')
    assert to_text(repr(exc)) == 'message'

# Generated at 2022-06-20 14:11:08.956605
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'smart'
    message = 'Python interpreter discovery required on host xyz'

    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert obj.__str__() == message

# Generated at 2022-06-20 14:11:12.381082
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("test", "python", "auto")
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == "python"
        assert ex.discovery_mode == "auto"

# Generated at 2022-06-20 14:11:16.992305
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'message'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    expected = 'message'
    assert exception.__str__() == expected


# Generated at 2022-06-20 14:11:25.938478
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    class Display(object):
        def __init__(self, msg, host):
            self.msg = msg
            self.host = host

        def vvv(self, msg, host):
            assert msg == "Attempting python interpreter discovery"
            assert host == '192.168.0.1'

        def debug(self, msg, host):
            assert msg == "raw interpreter discovery output: PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python3\nENDFOUND"
            assert host == '192.168.0.1'

        def warning(self, msg, host):
            assert msg == 'Unhandled error in Python interpreter discovery for host 192.168.0.1: ValueError("unexpected output from Python interpreter discovery",)'

# Generated at 2022-06-20 14:11:35.134823
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Action:
        def __init__(self):
            self._discovery_warnings = []
            self._low_level_execute_command = None

    action = Action()

    # placeholders to satisfy the calling context; this func doesn't actually use these
    mock_task_vars = {}
    mock_interpreter_name = 'python'
    mock_discovery_mode = 'auto'

    # test double for execution command
    class MockExecute:
        def __init__(self):
            self.cmd = ''
            self.called_count = 0
            self.return_value = {}

        def __call__(self, cmd, sudoable=None, in_data=None):
            self.cmd = cmd
            self.called_count += 1


# Generated at 2022-06-20 14:12:20.024935
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # 1. Setup test data - create a task with a discard action
    action_plugin = ActionModule(task=dict(
        action=dict(
            discard=True
        )
    ))
    # 2. Apply test - initialize a connection to localhost
    action_plugin._setup_connection()

    res = discover_interpreter(action_plugin, 'python', 'auto_legacy', dict(breakme="now"))
    assert res == '/usr/bin/python'

    res = discover_interpreter(action_plugin, 'python', 'smart', dict(breakme="now"))
    assert res == '/usr/bin/python'

    res = discover_interpreter(action_plugin, 'python', 'auto_legacy_silent', dict(breakme="now"))
    assert res == '/usr/bin/python'


# Generated at 2022-06-20 14:12:25.119688
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_exception = InterpreterDiscoveryRequiredError("msg", "interpreter_name", "discovery_mode")
    assert test_exception.message == "msg"
    assert test_exception.interpreter_name == "interpreter_name"
    assert test_exception.discovery_mode == "discovery_mode"
    assert str(test_exception) == "msg"
    assert repr(test_exception) == "msg"

# Generated at 2022-06-20 14:12:29.011259
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        message='Message',
        interpreter_name='python',
        discovery_mode='auto'
    )
    assert error.__str__() == 'Message'

# Generated at 2022-06-20 14:12:33.386552
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        'message',
        'interpreter_name',
        'discovery_mode'
    )
    assert error.__str__() == 'message'



# Generated at 2022-06-20 14:12:44.843514
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # create a mock action class
    class MockAction:
        def __init__(self):
            self._discovery_warnings = []
            self._low_level_execute_command = None
            self._connection = None

            # TODO: self._connection.has_pipelining

        def set_low_level_execute_command(self, f):
            self._low_level_execute_command = f

        def set_connection(self, f):
            self._connection = f

        def set_discovery_warnings(self, warnings):
            self._discovery_warnings = warnings

    # create our mock action object
    action = MockAction()


# Generated at 2022-06-20 14:12:58.481403
# Unit test for constructor of class InterpreterDiscoveryRequiredError

# Generated at 2022-06-20 14:13:05.322081
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Asserts that when an InterpreterDiscoveryRequiredError is created with message, interpreter_name and discovery_mode
    # then its __str__ method will return a string that contains the message, interpreter_name and discovery_mode
    msg = "Test message"
    interpreter_name = "python"
    discovery_mode = "auto_legacy"
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    actual_result = str(interpreter_discovery_required_error)
    assert msg in actual_result and interpreter_name in actual_result and discovery_mode in actual_result

# Generated at 2022-06-20 14:13:18.502790
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TestAction(object):
        def __init__(self, hosts, pipelining_enabled=True, list_stderr=[], list_stdout=[], list_stdout_script=[]):
            self._hosts = hosts
            self._pipelining_enabled = pipelining_enabled
            self._list_stderr = list_stderr
            self._list_stdout = list_stdout
            self._list_stdout_script = list_stdout_script
            self.task_vars = {}
            self._connection = {}
            self.set_become(False)
            self._discovery_warnings = []

        def set_become(self, become):
            self._become = become

        def set_become_user(self, become_user):
            self._become_user

# Generated at 2022-06-20 14:13:22.936839
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Test error", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto"


# Generated at 2022-06-20 14:13:35.637671
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.platform import Platform
    import sys

    def platform():
        return sys.platform

    def interpreter():
        return '/usr/bin/python'

    def get_platform_dist_result():
        return ['redhat', '7', 'Core']

    def get_osrelease_content():
        with open("test/units/module_utils/test_discovery/os-release") as f:
            return f.read()

    def get_executable_path():
        return '/bin/sh'

    def get_bin_path():
        return '/usr/bin'

    def display_debug(msg, host=None):
        print(msg)
