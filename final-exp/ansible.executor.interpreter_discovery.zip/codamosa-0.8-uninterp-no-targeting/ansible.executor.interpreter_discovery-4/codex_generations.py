

# Generated at 2022-06-20 14:05:06.284320
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex_message = 'Failed to find interpreter, discovery required'
    ex_interpreter_name = 'python3'
    ex_discovery_mode = 'auto'
    ex_error = InterpreterDiscoveryRequiredError(ex_message, ex_interpreter_name, ex_discovery_mode)
    assert ex_error.message == ex_message
    assert ex_error.interpreter_name == ex_interpreter_name
    assert ex_error.discovery_mode == ex_discovery_mode

# Generated at 2022-06-20 14:05:13.550523
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.task_result
    fixture_path = 'test/unit/fixtures/legacy_python_discovery_basic.json'
    task_vars = {}
    with open(fixture_path, 'rb') as f:
        task_result_dict = json.loads(to_text(f.read()))
    task_result = ansible.executor.task_result.TaskResult(task_result_dict)
    result = discover_interpreter(task_result, 'python', 'auto', task_vars)
    assert result == '/usr/bin/python'

# Generated at 2022-06-20 14:05:23.334715
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import io
    import os
    import tempfile
    import unittest

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.action.normal import ActionModule
    from ansible.utils.path import unfrackpath

    class _MyTask(object):
        def __init__(self, vars):
            self._task_vars = vars

        def get_vars(self):
            return self._task_vars

        def set_vars(self, value):
            self._task_vars = value

        vars = property(get_vars, set_vars)

    class _MyConnection(object):
        def __init__(self):
            self.has_pipelining

# Generated at 2022-06-20 14:05:33.813228
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'force'
    task_vars = {}
    host = 'localhost'
    from ansible.executor.task_executor import TaskExecutor

    task_executor = TaskExecutor(None, None)
    task_executor.module_for_interpreter = True
    task_executor._action = task_executor
    task_executor._action._discovery_warnings = []
    task_executor._action._connection = task_executor._connection = {}
    task_executor._action._connection.has_pipelining = False
    task_executor._action.module_implementation_preferences = []

# Generated at 2022-06-20 14:05:40.531521
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        message="The actual error message",
        interpreter_name="python",
        discovery_mode="auto"
    )

    assert error.__str__() == error.message

# Generated at 2022-06-20 14:05:53.395667
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task
    from ansible.plugins.connection.local import Connection

    action = Task()

    action._connection = Connection(':memory:')

    # on real target, these should be set from inventory when task is created
    action.args['inventory_hostname'] = 'test_host'
    action.args['connection'] = 'local'
    action.args['playbook_dir'] = '/playbook_dir'

    # test discover interpreter with multiple interpreters on the target
    fake_get_data = {
        "PLATFORM\r\nLinux\r\nFOUND\r\n/usr/bin/python2.7\r\n/usr/bin/python3.6\r\nENDFOUND"
    }

    def fake_get_data(path):
        return fake_get

# Generated at 2022-06-20 14:05:55.346723
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('Test Message', 'python', 'discovery_mode')
    assert 'Test Message' == err.__str__()


# Generated at 2022-06-20 14:06:00.255986
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # When
    exc = InterpreterDiscoveryRequiredError(message="message", interpreter_name='python', discovery_mode='auto_legacy')
    # Then
    assert exc.message == "message"
    assert exc.__repr__() == "message"

# Generated at 2022-06-20 14:06:06.533811
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    x = InterpreterDiscoveryRequiredError("test_message", "test_interpreter", "discovery_mode")
    assert x.message == "test_message"
    assert x.interpreter_name == "test_interpreter"
    assert x.discovery_mode == "discovery_mode"
    # TODO: proper repr impl
    assert str(x) == "test_message"
    assert repr(x) == "test_message"

# Generated at 2022-06-20 14:06:12.180375
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_required_exception = InterpreterDiscoveryRequiredError("Error", "python", "auto_legacy_silent")
    interpreter_discovery_required_exception_str = repr(interpreter_discovery_required_exception)
    assert interpreter_discovery_required_exception_str == "Error"

# Generated at 2022-06-20 14:06:22.929172
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('test message', 'python', 'auto')
    # test message
    assert error.message == 'test message'
    # test interpreter name: python
    assert error.interpreter_name == 'python'
    # test discovery mode
    assert error.discovery_mode == 'auto'


# Generated at 2022-06-20 14:06:28.490494
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    """This test is to check the return value of __str__ method in class InterpreterDiscoveryRequiredError
    """
    message = 'Test'
    interpreter_name = 'Python'
    discovery_mode = 'force'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    # Should pass
    assert(error.__str__() == message)

# Generated at 2022-06-20 14:06:30.901349
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    tester = InterpreterDiscoveryRequiredError("message","python","auto")
    assert to_native("message") == tester.__str__()

# Generated at 2022-06-20 14:06:36.889538
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_string = "Test String"
    test_interpreter_name = "python"
    test_discovery_mode = "auto"
    obj = InterpreterDiscoveryRequiredError(test_string, test_interpreter_name, test_discovery_mode)
    assert test_string == str(obj)

# Generated at 2022-06-20 14:06:42.121957
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("message", "python", "auto")
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.__str__() == "message"
        assert ex.interpreter_name == "python"
        assert ex.discovery_mode == "auto"

# Generated at 2022-06-20 14:06:46.542512
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert exception.message == "message" and exception.interpreter_name == "interpreter_name" and exception.discovery_mode == "discovery_mode"

# Generated at 2022-06-20 14:07:03.041495
# Unit test for function discover_interpreter
def test_discover_interpreter():
    def _set_action(return_values):
        def _mock_execute_command(cmd, sudoable=False, in_data=None):
            import json
            return {'stdout': json.dumps(return_values)}
        action._low_level_execute_command = _mock_execute_command

    action = object()

    # test basic path
    _set_action({'platform_dist_result': ('debian', '9.2', ''), 'osrelease_content': ''})
    assert discover_interpreter(action, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'
    assert not action._discovery_warnings

    # test auto discovery

# Generated at 2022-06-20 14:07:10.903075
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'discovery required for interpreter {interpreter_name}, discovery mode {discovery_mode}'
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message.format(
        interpreter_name=interpreter_name, discovery_mode=discovery_mode), interpreter_name, discovery_mode)
    assert interpreter_discovery_required_error.__repr__() == 'discovery required for interpreter python, discovery mode auto_legacy_silent'



# Generated at 2022-06-20 14:07:17.886906
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError(
        message='Unable to find python interpreter',
        interpreter_name='python',
        discovery_mode='legacy_silent'
    )
    assert exc.message == 'Unable to find python interpreter'
    assert exc.interpreter_name == 'python'
    assert exc.discovery_mode == 'legacy_silent'

# Generated at 2022-06-20 14:07:21.456940
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError('my message', 'python', 'auto')
    repr_obj = repr(exception)
    assert repr_obj == 'my message'

# Generated at 2022-06-20 14:07:33.412488
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError('Test message.', 'python', 'auto_legacy_silent')
    assert str(e) == 'Test message.'



# Generated at 2022-06-20 14:07:39.868357
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    python_interpreter="python2"
    discovery_mode="auto"
    error_msg="Interpreter discovery required for python2"
    test_InterpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError(error_msg, python_interpreter, discovery_mode)

    assert (repr(test_InterpreterDiscoveryRequiredError) == "Interpreter discovery required for python2")

# Generated at 2022-06-20 14:07:48.195975
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python3'
    message = "Interpreter discovery required for {0}".format(interpreter_name)
    discovery_mode = 'auto'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.message == message
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode
    assert str(e) == message
    assert repr(e) == message


# Generated at 2022-06-20 14:07:56.973279
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.discovery import Cache
    from ansible.plugins.action import ActionBase
    from ansible.plugins import action as action_plugins
    from ansible.plugins import module_loader

    class FakeAction(ActionBase):
        def __init__(self, name=None, shared_loader_obj=None,
                     loader=None, templar=None, **kwargs):
            super(FakeAction, self).__init__(
                name=name, shared_loader_obj=shared_loader_obj,
                loader=loader, templar=templar, **kwargs
            )

        def run(self, tmp=None, task_vars=None):
            pass


# Generated at 2022-06-20 14:08:03.119425
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_interp_name = 'python'
    test_discovery_mode = 'auto'

    assert InterpreterDiscoveryRequiredError('message', test_interp_name, test_discovery_mode).interpreter_name == 'python'
    assert InterpreterDiscoveryRequiredError('message', test_interp_name, test_discovery_mode).discovery_mode == 'auto'

# Generated at 2022-06-20 14:08:05.548441
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "test message"

    a = InterpreterDiscoveryRequiredError(message, "python", "auto")
    b = InterpreterDiscoveryRequiredError(message, "python3", "auto")
    c = InterpreterDiscoveryRequiredError(message, "python", "auto_legacy")

    assert str(a) == message
    assert str(b) == message
    assert str(c) == message

# Generated at 2022-06-20 14:08:16.211444
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'message'
        assert e.interpreter_name == 'interpreter_name'
        assert e.discovery_mode == 'discovery_mode'
        assert str(e) == 'message'

# Generated at 2022-06-20 14:08:23.545143
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print('TEST discover_interpreter')
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase
    from ansible.plugins import connection_loader
    from ansible.plugins import module_loader

    class FakeAction(ActionBase):
        TRANSFERS_FILES = False
        _discovery_warnings = []

        def __init__(self):
            self._low_level_execute_command = self._fake_low_level_execute_command

        def _fake_low_level_execute_command(self, cmd, sudoable, in_data=None):
            if cmd.startswith('command -v'):
                return TaskResult('', '', '', None)


# Generated at 2022-06-20 14:08:29.736946
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.message == message

# Generated at 2022-06-20 14:08:42.433784
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    This function is not a normal unit test,
    it's to help develop and test the discover_interpreter function,
    so it is not run normally.
    :return:
    """
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-20 14:08:56.120443
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("error", "python", "auto")
    assert error
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'
    assert error.message == "error"


# Generated at 2022-06-20 14:09:02.109758
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    discovery_mode_expected = 'interpreter discovery mode'
    interpreter_name_expected = 'interpreter name'
    exception_message_expected = 'exception message'
    exception = InterpreterDiscoveryRequiredError(exception_message_expected, interpreter_name_expected, discovery_mode_expected)
    assert exception.__repr__() == exception_message_expected


# Generated at 2022-06-20 14:09:17.268565
# Unit test for function discover_interpreter
def test_discover_interpreter():

    uname_output = 'Linux\nFOUND\n/opt/ansible/bin/python\nENDFOUND'
    dist_output = '{"osrelease_content": "NAME=\"RedHatEntesis\"\nVERSION_ID=\"7.2\""}'
    task_vars = {}

    action = None

    def low_level_execute_command(cmd, sudoable=False, in_data=None):
        if in_data is not None:
            return {'stdout': dist_output}
        else:
            return {'stdout': uname_output}

    action = type('ActionModule', (object,), {'_low_level_execute_command': low_level_execute_command})()

    interpreter_name = 'python'
    discovery_mode = 'always'

    # test for exactly matched version
   

# Generated at 2022-06-20 14:09:27.612387
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test cases
    ###############################
    # python interpreter discovery
    ###############################

    # testcase 1 - discover_interpreter - platform type linux, discovered python interpreters, no compatible
    assert discover_interpreter(action="action", interpreter_name="python",
                                discovery_mode="auto",
                                task_vars={"inventory_hostname": "test_host"}) == "/usr/bin/python"

    # testcase 2 - discover_interpreter - platform type linux, discovered python interpreters, compatible

# Generated at 2022-06-20 14:09:31.094123
# Unit test for function discover_interpreter
def test_discover_interpreter():
    display.verbosity = 4
    assert discover_interpreter(None, 'python', 'auto_legacy', {}) == u'/usr/bin/python'

# Generated at 2022-06-20 14:09:38.172719
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'test message'
    interpreter_name = 'test interpreter name'
    discovery_mode = 'test discovery mode'
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.message == message
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode
    assert str(ex) == ex.message

# Generated at 2022-06-20 14:09:39.128832
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO
    pass

# Generated at 2022-06-20 14:09:43.840533
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Test Init
    idreq_error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')

    if not hasattr(idreq_error, '__str__'):
        raise Exception("InterpreterDiscoveryRequiredError has no __str__ method")

    expected = str('message')

    # Test
    actual = idreq_error.__str__()

    # Verify
    if expected != actual:
        raise Exception("Expected " + expected + " but got " + actual)


# Generated at 2022-06-20 14:09:49.335154
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    import errno

    mod = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # test that discover_interpreter raises an error when an interpreter is not supported
    msg = "Interpreter discovery not supported for php"
    try:
        discover_interpreter(mod, interpreter_name="php", discovery_mode="auto", task_vars=None)
    except NotImplementedError as e:
        assert msg == str(e)

    # test that discover_interpreter raises an error when a platform_type is not supported
    msg = "unsupported platform for extended discovery: windows"

# Generated at 2022-06-20 14:09:50.906402
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    actual = InterpreterDiscoveryRequiredError(message="error!", interpreter_name="python", discovery_mode="auto")
    assert "error!" == actual.__str__(), "__str__() must return value passed to the constructor!"



# Generated at 2022-06-20 14:10:08.332548
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Invalid interpreter", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto"
    print("Successfully tested test_InterpreterDiscoveryRequiredError")

# Generated at 2022-06-20 14:10:14.473854
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("test", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto"
        assert str(e) == "test"
        assert repr(e) == "test"

# Generated at 2022-06-20 14:10:18.958228
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # arrange
    message = 'unhandled exception'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # act
    result = ex.__str__()

    # assert
    assert result == message


# Generated at 2022-06-20 14:10:31.557454
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = "Interpreter '{interpreter_name}' discovery required for '{discovery_mode}'".format(
        interpreter_name=interpreter_name, discovery_mode=discovery_mode)

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as err:
        output_C = str(err)
        output_P = err.__repr__()

    assert (output_C == output_P)



# Generated at 2022-06-20 14:10:37.806930
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    i = InterpreterDiscoveryRequiredError('message', 'interpreter', 'discovery')
    assert i.interpreter_name == 'interpreter'
    assert i.discovery_mode == 'discovery'
    assert str(i) == 'message'

# Generated at 2022-06-20 14:10:44.112820
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('This is message', 'python', 'auto_legacy_silent')
    # The message is taken from the __init__
    assert error.__str__() == 'This is message'
    # Test also with a different message
    error.message = "This is my message"
    assert error.__str__() == 'This is my message'



# Generated at 2022-06-20 14:10:47.174334
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert str(e) == e.message

# Generated at 2022-06-20 14:10:58.890294
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    InterpreterDiscoveryRequiredError("test", "python", "auto")
    InterpreterDiscoveryRequiredError("test2", "python3", "auto")
    with pytest.raises(ValueError):
        InterpreterDiscoveryRequiredError("test3", "ruby", "auto")

    error = InterpreterDiscoveryRequiredError("test", "python", "auto")
    assert error.message == "test"
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"

    error = InterpreterDiscoveryRequiredError("test2", "python3", "auto")
    assert error.message == "test2"
    assert error.interpreter_name == "python3"
    assert error.discovery_mode == "auto"

# Generated at 2022-06-20 14:11:06.716868
# Unit test for function discover_interpreter
def test_discover_interpreter():

    action = None
    # this is a "do enough to make it work" mock
    class MockAction:

        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            return {u'stdout': u'', u'stderr': u''}

        def _get_connection(self):
            return self

        @property
        def has_pipelining(self):
            return True

    class MockConnection:

        @property
        def has_pipelining(self):
            return True

    action = MockAction()
    action._connection = MockConnection()

    assert discover_interpreter(action, 'python', 'auto', {}) == u'/usr/bin/python'

    # F

# Generated at 2022-06-20 14:11:09.450335
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert str("message") == obj.__str__()

# Generated at 2022-06-20 14:11:31.511524
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class FakeAction(object):
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, in_data=None, sudoable=False):
            stdout = ""
            stderr = ""
            if cmd == "command -v 'python3'":
                stdout = "PLATFORM\nLinux\nFOUND\n/usr/bin/python3\nENDFOUND"
            elif cmd == "/usr/bin/python3":
                return self._python_script(cmd, in_data)
            else:
                stdout = "PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND"
            return {"stdout": stdout, "stderr": stderr}


# Generated at 2022-06-20 14:11:35.579934
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(
        message='Failed to discover interpreter', interpreter_name='python', discovery_mode='auto_legacy')
    assert interpreter_discovery_required_error.__str__() == 'Failed to discover interpreter'



# Generated at 2022-06-20 14:11:41.873908
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockLowLevelExecutor:
        def __init__(self):
            self.__has_pipelining = False

        @property
        def has_pipelining(self):
            return self.__has_pipelining

        def _low_level_execute_command(self, command, sudoable, in_data=None):
            mock_res = dict(stdout="PLATFORM\nLinux\nFOUND\n/usr/bin/python2.7\n/usr/bin/python3.6\nENDFOUND",
                            stderr='')
            return mock_res

    mock_task_vars = dict(inventory_hostname='localhost',
                          ansible_python_interpreter='/usr/bin/python2.7')

    mock_action = dict()


# Generated at 2022-06-20 14:11:50.207483
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    """This test case tests the constructor of class InterpreterDiscoveryRequiredError"""
    interpreter_name = "python"
    discovery_mode = 'legacy_silent'
    message_text = "Interpreter {} discovery required with discovery mode {}.".format(interpreter_name, discovery_mode)
    err = InterpreterDiscoveryRequiredError(message_text, interpreter_name, discovery_mode)
    assert interpreter_name == err.interpreter_name
    assert discovery_mode == err.discovery_mode
    assert message_text == to_native(err)


# Generated at 2022-06-20 14:11:57.722834
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = "test message"
    interpreter_name = "python"
    discovery_mode = "auto"
    exception = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert exception.__str__() == error_message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode


# Generated at 2022-06-20 14:12:01.066466
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import random
    import string

    test_dir = 'python_executor_test'
    test_file = 'tmp_python_executor.py'

# Generated at 2022-06-20 14:12:04.207123
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "message"
    interpreter_name = "python"
    discovery_mode = "auto"
    exception = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert exception.__repr__() == msg

# Generated at 2022-06-20 14:12:08.373668
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError('Interpreter discovery required', 'python', 'auto_silent')
    assert exc.message == 'Interpreter discovery required'
    assert exc.interpreter_name == 'python'
    assert exc.discovery_mode == 'auto_silent'

# Generated at 2022-06-20 14:12:16.685017
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = u'Discovery for python for connection local required'
    discovery_mode = u'auto_legacy_silent'
    interpreter_name = u'python'
    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert obj.message == message
    assert obj.discovery_mode == discovery_mode
    assert obj.interpreter_name == interpreter_name
    assert obj.__str__() == message
    assert obj.__repr__() == message

# Generated at 2022-06-20 14:12:26.260852
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-20 14:12:46.207952
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpretediscovery_error = InterpreterDiscoveryRequiredError("Interpreter discovery is required", "python", "auto_legacy_silent")
    assert interpretediscovery_error.message == "Interpreter discovery is required"
    assert interpretediscovery_error.interpreter_name == "python"
    assert interpretediscovery_error.discovery_mode == "auto_legacy_silent"


# Generated at 2022-06-20 14:12:50.096465
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with pytest.raises(InterpreterDiscoveryRequiredError) as excinfo:
        raise InterpreterDiscoveryRequiredError(message='', interpreter_name='', discovery_mode='')


# Generated at 2022-06-20 14:12:55.005926
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError("InterpreterDiscoveryRequiredError", "python", "auto_legacy_silent")
    assert exception.interpreter_name == "python"
    assert exception.discovery_mode == "auto_legacy_silent"

# Generated at 2022-06-20 14:12:58.048391
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError('test', 'python', 'auto_legacy_silent')


# Generated at 2022-06-20 14:13:00.584762
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(u'Testing', u'python', u'auto')
    assert str(error) == u'Testing'

# Generated at 2022-06-20 14:13:11.577000
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Test with a message
    try:
        raise InterpreterDiscoveryRequiredError("test", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == "test"

    # Test with no message
    try:
        raise InterpreterDiscoveryRequiredError("test", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == "test"



# Generated at 2022-06-20 14:13:16.254360
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('This is a test message', 'python', 'auto_legacy_silent')
    expected = 'This is a test message'

    actual = err.__repr__()

    assert actual == expected  # nosec

# Generated at 2022-06-20 14:13:24.770727
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor import task_executor

    # this unit test does not attempt to test:
    # - all possible outcomes
    # - non-Python interpreter discovery
    # - legacy mode behavior
    # - bootstrap python list behavior
    # - distro/version map expansion and fallback behavior

    class TestAction(object):
        def __init__(self):
            self._connection = None
            self._discovery_warnings = []

        def _get_platform(self):
            return 'linux'

        def _set_connection_info(self, connection):
            self._connection = connection

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            return {u'stdout': u''}


# Generated at 2022-06-20 14:13:31.081858
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_message = 'test error message'
    interpreter_name = 'python'
    discovery_mode = 'test discovery mode'

    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)

    assert error.message == error_message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode



# Generated at 2022-06-20 14:13:42.811016
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible import context
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import find_action_plugin
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader

    class LocalTask(object):

        def __init__(self, new_action):
            self._new_action = new_action

        def action(self):
            return self._new_action

    class LocalPlayContext(object):

        def __init__(self, task_vars, def_vars):
            self._task_vars = task_vars
            self._def_vars = def_vars

        @property
        def task_vars(self):
            return self._task_vars


# Generated at 2022-06-20 14:14:24.225740
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    repr = "INTERPRETER_DISCOVERY_FAILED: " \
           "Ansible requires Python interpreter discovery, but interpreter python was not found, and 'auto' discovery " \
           "mode was requested without providing a 'python' interpreter. Please provide a python interpreter in " \
           "your inventory or use 'auto_legacy' discovery mode to use a system python interpreter. See " \
           "https://docs.ansible.com/ansible/latest/reference_appendices/interpreter_discovery.html for more " \
           "information. "
    assert str(InterpreterDiscoveryRequiredError(repr, 'python', 'auto')) == repr

# Generated at 2022-06-20 14:14:30.202775
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    a = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert a.message == 'message'
    assert a.interpreter_name == 'interpreter_name'
    assert a.discovery_mode == 'discovery_mode'
    assert a.__str__() == 'message'
    assert str(a) == 'message'

# Generated at 2022-06-20 14:14:34.091786
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = "message"
    interpreter_name = "python"
    discovery_mode = "auto"

    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert isinstance(ex, InterpreterDiscoveryRequiredError)
    assert str(ex) == ex.message
    assert repr(ex) == ex.message

# Generated at 2022-06-20 14:14:41.440478
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('mock', 'python', 'auto', 'mock_task_vars') == '/usr/bin/python'
    assert discover_interpreter('mock', 'python', 'auto', 'mock_task_vars') != '/usr/bin/python3'

# Generated at 2022-06-20 14:14:47.402520
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    # __str__ with one argument
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message in str(e)
    assert interpreter_name in str(e)
    assert discovery_mode in str(e)


# Generated at 2022-06-20 14:14:49.448571
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError("message", interpreter_name="python", discovery_mode="strict")
    assert str(ex) == "message"