

# Generated at 2022-06-20 14:05:06.751557
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto_legacy_silent'
    test_msg = "Interpreter discovery required for Python but not supported on this platform"
    test_except = InterpreterDiscoveryRequiredError(test_msg, test_interpreter_name, test_discovery_mode)
    assert test_except.message == test_msg
    assert test_except.interpreter_name == test_interpreter_name
    assert test_except.discovery_mode == test_discovery_mode

# Generated at 2022-06-20 14:05:15.599478
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    from ansible.plugins.action.script import ActionModule

    task_vars = {}
    am = ActionModule(None, action=dict(interpreter_discovery_mode='auto', interpreter_discovery_var='my_python'),
                      task_vars=task_vars, inject=None, connection=None, play_context=None, loader=None,
                      templar=None, shared_loader_obj=None)

    py_path = discover_interpreter(am, 'python', 'auto', task_vars)
    assert py_path == "/usr/bin/python"

    py_path = discover_interpreter(am, 'python', 'auto_silent', task_vars)
    assert py_path == "/usr/bin/python"

    # Should have

# Generated at 2022-06-20 14:05:25.820130
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "python interpreter discovery required"

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert message in str(ex)
        assert interpreter_name == ex.interpreter_name
        assert discovery_mode == ex.discovery_mode

# Generated at 2022-06-20 14:05:32.932016
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_message = "test message"
    test_interpreter_name = "test_interpreter_name"
    test_discovery_mode = "test_discovery_mode"

    ex = InterpreterDiscoveryRequiredError(test_message,
                                           test_interpreter_name,
                                           test_discovery_mode)
    assert ex.__repr__() == test_message
    assert ex.interpreter_name == test_interpreter_name
    assert ex.discovery_mode == test_discovery_mode


# Generated at 2022-06-20 14:05:35.938891
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    #interpreter_name = 'python'
    #discovery_mode = 'auto'
    #message = 'test message'
    #test_obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    #r = str(test_obj)
    #assert r == message
    pass

# Generated at 2022-06-20 14:05:48.248518
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: mock action or something so we don't need the real module
    real_discover_interpreter = globals().get('discover_interpreter')

# Generated at 2022-06-20 14:05:50.461463
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    InterpreterDiscoveryRequiredError('test_message', 'test_interpreter_name', 'test_discovery_mode')

# Generated at 2022-06-20 14:05:52.016899
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    InterpreterDiscoveryRequiredError("message","interpreter_name","discovery_mode")


# Generated at 2022-06-20 14:05:53.923732
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    exception_message = 'Python interpreter discovery failed'
    exception = InterpreterDiscoveryRequiredError(exception_message, interpreter_name, discovery_mode)

    assert exception is not None

# Generated at 2022-06-20 14:06:06.615255
# Unit test for function discover_interpreter
def test_discover_interpreter():
    actual_interpreter = None
    class MockAction(object):
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            return {'stdout': actual_interpreter}
    mock_action = MockAction()

    # Test case: No python installed on the host
    expected_interpreter = u''
    try:
        actual_interpreter = discover_interpreter(mock_action, 'python', 'legacy', {})
    except InterpreterDiscoveryRequiredError as ex:
        # We expect the exception
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'legacy'

    # Test case: Host has only one python

# Generated at 2022-06-20 14:06:16.906272
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(object(), 'python', 'auto', {}) == '/usr/bin/python'

# Generated at 2022-06-20 14:06:26.135041
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = u'Python interpreter discovery is required but not enabled'

    # create an instance of class InterpreterDiscoveryRequiredError
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # check the correctness of __str__
    assert ex.__str__() == message

    # check the correctness of interpreter_name and discovery_mode
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:06:31.120946
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'message test'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.discovery_mode == discovery_mode
    assert err.interpreter_name == interpreter_name
    assert err.message == message

# Generated at 2022-06-20 14:06:44.502633
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_message = 'Test message for InterpreterDiscoveryRequiredError'
    python_interpreter = 'python'
    discovery_mode = 'auto'
    interpreter_discovery_error = InterpreterDiscoveryRequiredError(test_message, python_interpreter, discovery_mode)

    # Check if object of the class InterpreterDiscoveryRequiredError is created
    assert interpreter_discovery_error is not None

    # Check if object of the class InterpreterDiscoveryRequiredError is created with correct message
    assert interpreter_discovery_error.message == test_message

    # Check if object of the class InterpreterDiscoveryRequiredError is created with correct interpreter_name
    assert interpreter_discovery_error.interpreter_name == python_interpreter

    # Check if object of the class InterpreterDiscoveryRequiredError is created with correct discovery

# Generated at 2022-06-20 14:06:47.958250
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ex = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert ex.__repr__() == 'message'
    assert ex.__str__() == 'message'

# Generated at 2022-06-20 14:06:50.407625
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert repr(obj) == obj.message

# Generated at 2022-06-20 14:07:04.381372
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    When interpreting_name is not python the above method will raise an exception.
    Which is to be caught and handled
    """
    action = Display()
    task_vars = dict()
    action._low_level_execute_command = _fake_low_level_execute_command
    action._low_level_execute_command_normal = _fake_low_level_execute_command
    action._low_level_execute_command_pipelining = _fake_low_level_execute_command
    versions = {
        u"1": u"/usr/bin/python2.6",
        u"2": u"/usr/bin/python2.7",
        u"3": u"/usr/bin/python3.6",
        u"4": u"/usr/bin/python3.7"
    }


# Generated at 2022-06-20 14:07:07.037496
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(u"test message", u"test interpreter", u"test discovery_mode")
    assert str(error) == u"test message"

# Generated at 2022-06-20 14:07:15.351213
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test bad interpreter name
    try:
        discover_interpreter(None, 'test', 'auto', {})
        assert False
    except ValueError:
        pass

    # Test not implemented error
    try:
        discover_interpreter(None, 'python', 'auto', {})
        assert False
    except NotImplementedError:
        pass

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils import context_objects as co

    # Set display for test_runner
    setattr(co, 'CLIARGS', dict(verbosity=2))

    class FakeActionMod(object):
        _discovery_warnings = []

        def __init__(self, _connection):
            self._connection = _connection


# Generated at 2022-06-20 14:07:28.616236
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test with only one python interpreter in path
    task_vars = dict()
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res == u'/usr/bin/python'

    # test with multiple python interpreters in path
    task_vars = dict()
    task_vars['ansible_python_interpreter'] = '/usr/bin/python3.6'
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

# Generated at 2022-06-20 14:07:51.473774
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class ActionModule:
        def __init__(self):
            self._connection = None
            self._discovery_warnings = []

        def _low_level_execute_command(self, shell_cmd, sudoable, in_data=None):
            assert shell_cmd
            assert self._connection
            if sudoable:
                assert self._connection.become

            if self._connection.has_pipelining:
                assert in_data

        def set_connection(self, connection):
            self._connection = connection

    action_module = ActionModule()
    result = {}

    # Test: _version_fuzzy_match

# Generated at 2022-06-20 14:07:57.542187
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    """
    make sure that InterpreterDiscoveryRequiredError.__str__ returns
    expected result
    """
    error = InterpreterDiscoveryRequiredError(
            'message',
            'interpreter_name',
            'discovery_mode',
        )
    assert error.__str__() == 'message'



# Generated at 2022-06-20 14:08:00.765124
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    inst = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert inst.__str__() == 'message'



# Generated at 2022-06-20 14:08:01.859185
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('error_message', 'interpreter_name', 'discovery_mode')
    assert 'error_message' == str(error)


# Generated at 2022-06-20 14:08:03.620811
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError(
        'test_message',
        'test_interpreter_name',
        'test_discovery_mode'
    )
    assert repr(exc) == 'test_message'


# Generated at 2022-06-20 14:08:08.972040
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    result = InterpreterDiscoveryRequiredError(
        'test_message', 'test_interpreter_name', 'test_discovery_mode')
    assert result.message == 'test_message'
    assert result.interpreter_name == 'test_interpreter_name'
    assert result.discovery_mode == 'test_discovery_mode'


# Generated at 2022-06-20 14:08:10.047883
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-20 14:08:16.211053
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected = "interpreter_name=python, discovery_mode=auto_legacy_silent"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    exc = InterpreterDiscoveryRequiredError("message", interpreter_name, discovery_mode)
    actual = repr(exc)
    assert expected == actual

# Generated at 2022-06-20 14:08:19.982240
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError('message', interpreter_name, discovery_mode)
    assert error.__str__() == 'message'

# Generated at 2022-06-20 14:08:26.256166
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'

    # Message not specified
    message = ''
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.__str__() == message

    # Message specified
    message = 'Random message'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.__str__() == message

# Generated at 2022-06-20 14:08:54.049383
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = ('Missing Python interpreter for python.  Please install python on the target '
               'host before running the play, or update ansible.cfg to specify the correct path.')
    edr = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(edr) == message

# Generated at 2022-06-20 14:08:58.432651
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError(message='Test message', interpreter_name='python', discovery_mode='auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.__repr__() == 'Test message'


# Generated at 2022-06-20 14:09:01.792332
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('the message', interpreter_name='python on host 1.2.3.4', discovery_mode='auto')

    assert repr(exc) == "'the message'"

# Generated at 2022-06-20 14:09:06.243203
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    interpreter_name = 'python'
    action = None
    discovery_mode = 'auto_legacy_silent'

    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    print(res)

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-20 14:09:12.960571
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # test coverage lacks a test for this, but it's currently still in use by the
    # ansible.playbook.Playbook class, so we should continue to support it
    test = InterpreterDiscoveryRequiredError("This is a test", "python", 'auto_silent')
    assert test.__str__() == "This is a test"

# Generated at 2022-06-20 14:09:16.859285
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError("message", "interp_name", "discovery_mode")
    except InterpreterDiscoveryRequiredError as ex:
        assert repr(ex) == "message"

# Generated at 2022-06-20 14:09:22.248213
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "msg"
    interpreter_name = "python"
    discovery_mode = "auto"
    instance = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert instance.__repr__() == msg


# Generated at 2022-06-20 14:09:23.700140
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(message='message', interpreter_name='interpreter_name', discovery_mode='discovery_mode')
    assert err.__repr__() == err.message

# Generated at 2022-06-20 14:09:29.762475
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host = 'testhost'
    action = dict()
    task_vars = dict()
    interpreter_name = 'python'
    discovery_mode = 'auto'

    # Test for NotImplementedError
    action._low_level_execute_command = lambda cmd, sudoable=True, in_data=None: {
        "stdout": "PLATFORM\n" + "FreeBSD\n" + "FOUND\n" + "/usr/bin/python\n" + "ENDFOUND",
        "stderr": "",
        "rc": 0,
        "stdin": ""
    }
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        assert False
    except NotImplementedError:
        assert True

    # Test for version_map ==

# Generated at 2022-06-20 14:09:36.158501
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = u'Message'
    interpreter_name = u'Interpreter'
    discovery_mode = u'Discovery'

    # Create the object
    exc = InterpreterDiscoveryRequiredError(
        message, interpreter_name, discovery_mode
    )

    # Do the tests
    assert not hasattr(exc, '__repr__')

# Generated at 2022-06-20 14:09:58.885919
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    display.columns = 120
    display.verbosity = 4
    err = InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    assert 'test' in str(err)

# Generated at 2022-06-20 14:10:15.329984
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action=object()
    task_vars = dict()

    # Test python interpreter discovery for RedHat and CentOS
    platform_info = {'platform_dist_result':  ['centos', '7', 'Core']}
    action._discovery_warnings = []
    result = discover_interpreter(action, 'python', 'auto', task_vars)
    assert result == u'/usr/bin/python'
    assert action._discovery_warnings == []

    platform_info = {'platform_dist_result':  ['centos', '5', 'Final']}
    action._discovery_warnings = []
    result = discover_interpreter(action, 'python', 'auto', task_vars)
    assert result == u'/usr/bin/python'
    assert not action._discovery_warnings

    platform_

# Generated at 2022-06-20 14:10:15.952546
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-20 14:10:26.327154
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes

    tmpdir = tempfile.mkdtemp()

    # Generates a tempdir of the form:
    #   tmpdir
    #     |
    #     +- python
    #     |   |
    #     |   +- foo
    #     |
    #     +- python2.7
    #     |   |
    #     |   +- foo
    #     |
    #     +- python3.6
    #         |
    #         +- foo

    for py in ['2.4', '2.5', '2.6', '2.7', '3.6']:
        os.mkdir(os.path.join(tmpdir, 'python{0}'.format(py)))
        open

# Generated at 2022-06-20 14:10:32.161823
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error_message = 'Error message'
    exception = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode
    assert str(exception) == error_message

# Generated at 2022-06-20 14:10:44.829241
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    action_plugins = {'action': ActionBase}

    # doit wants to output its own stuff
    import ansible.plugins.action.doit
    ansible.plugins.action.doit.display = display

    # hack to allow always using the doit action
    class ActionModuleDo(ActionBase):
        TRANSFERS_FILES = True

        def run(self, tmp=None, task_vars=None):
            del tmp
            return self._execute_module(task_vars=task_vars, tmp=None, delete_remote_tmp=True)

    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            del tmp

# Generated at 2022-06-20 14:10:48.736161
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_discovery_error = InterpreterDiscoveryRequiredError("err", "python", "auto")
    assert(interpreter_discovery_error.__str__() == "err")



# Generated at 2022-06-20 14:11:01.608664
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import mock
    import platform
    import re

    mock_module_utils_path = 'ansible.module_utils.basic'
    if mock_module_utils_path not in sys.modules:
        sys.modules[mock_module_utils_path] = mock.Mock()
    from ansible.module_utils.basic import AnsibleModule

    class FakeVersionResult(list):
        def __init__(self, val):
            self.append(val)
            self.append('0')
            self.append('1')

    class FakeAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = mock.Mock()


# Generated at 2022-06-20 14:11:04.921645
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    InterpreterDiscoveryRequiredError("This is an Exception", interpreter_name="python", discovery_mode="auto_legacy")


# Generated at 2022-06-20 14:11:09.314393
# Unit test for function discover_interpreter
def test_discover_interpreter():
    discovery_mode = 'auto'
    interpreter_name = 'python'
    task_vars = {}

    assert discover_interpreter(discovery_mode, interpreter_name, task_vars) == u'/usr/bin/python'

# Generated at 2022-06-20 14:11:55.483200
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = "Interpreter discovery required before execution"
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as error:
        assert error.__str__() == message
        assert error.interpreter_name == interpreter_name
        assert error.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:11:59.598056
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    m = "python required discovery"
    i = "python3"
    d = "fallback_silent"
    e = InterpreterDiscoveryRequiredError(m, i, d)
    assert e.__repr__() == m


# Generated at 2022-06-20 14:12:04.359224
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'message'
    interpreter_name = 'interpreter_name'
    discovery_mode = 'discovery_mode'
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    res = str(interpreter_discovery_required_error)
    assert res == 'message'

# Generated at 2022-06-20 14:12:15.952119
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Test with message 'with message', interpreter_name 'python' and discovery_mode 'auto_legacy_silent'
    message = 'with message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    # create instance for testing
    # InterpreterDiscoveryRequiredError()
    # with message 'with message',
    # interpreter_name 'python'
    # discovery_mode 'auto_legacy_silent'
    test_instance = InterpreterDiscoveryRequiredError(
        message=message,
        interpreter_name=interpreter_name,
        discovery_mode=discovery_mode,
    )

    # compare
    assert repr(test_instance) == 'with message'
    # cleanup - nothing to do



# Generated at 2022-06-20 14:12:22.498899
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('Error occurred', 'python', 'auto')

    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

    error = InterpreterDiscoveryRequiredError('Error occurred', 'python', 'auto_legacy_silent')

    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-20 14:12:29.636720
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_message = 'InterpreterDiscoveryRequiredError: There is no interpreter, with name:Python, present in the system.'
    exception = InterpreterDiscoveryRequiredError(error_message, interpreter_name='python', discovery_mode='auto')
    assert str(exception) == error_message

# Generated at 2022-06-20 14:12:41.569573
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_interpreter_name = 'fake_interpreter'
    error_discovery_mode = 'silent'
    error_message = 'fake_message'
    ex = InterpreterDiscoveryRequiredError(error_message, error_interpreter_name, error_discovery_mode)
    ex.message = error_message
    ex.interpreter_name = error_interpreter_name
    ex.discovery_mode = error_discovery_mode
    assert error_message == ex.message
    assert error_interpreter_name == ex.interpreter_name
    assert error_discovery_mode == ex.discovery_mode
    assert error_message == str(ex)
    assert error_message == repr(ex)


# Generated at 2022-06-20 14:12:50.155892
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'failed to discover Python interpreter for interpreter python'

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:12:54.317535
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError('a', 'b', 'discovery_mode')
    assert 'a' == str(e)

# Generated at 2022-06-20 14:12:58.650140
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(u'Test message', u'python', u'auto')
    assert str(error) == u'Test message'
    assert repr(error) == u'Test message'

# Generated at 2022-06-20 14:14:12.346170
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    under_test = InterpreterDiscoveryRequiredError("test message", "test interpreter name", "test discovery mode")
    assert under_test.message == "test message"
    assert under_test.interpreter_name == "test interpreter name"
    assert under_test.discovery_mode == "test discovery mode"

# Generated at 2022-06-20 14:14:23.777322
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery_test_mocks import _ActionModule, _Connection

    host = u'www.example.com'
    task_vars = dict()
    action = _ActionModule(task_vars)
    action._connection = _Connection()

    # Unit test for discover_interpreter
    assert discover_interpreter(action, u'python', u'auto', task_vars) == u'/usr/bin/python2.7'
    assert discover_interpreter(action, u'python', u'auto_legacy', task_vars) == u'/usr/bin/python'

    # Unit test for exceptions raised in discover_interpreter

# Generated at 2022-06-20 14:14:29.632552
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    excpt = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert excpt.message == "message"
    assert excpt.interpreter_name == "interpreter_name"
    assert excpt.discovery_mode == "discovery_mode"


# Generated at 2022-06-20 14:14:34.928534
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Set up initial variables to proper values for unit testing
    task_vars = {}
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    C.config.load_config_file()

    # We do not have control over distro information, so the best we can do
    # is test it is returning a string value
    assert isinstance(discover_interpreter(action, interpreter_name, discovery_mode, task_vars), str) is True


# Generated at 2022-06-20 14:14:45.511171
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert str(error) == 'message'
    error = InterpreterDiscoveryRequiredError('message', 'python2', 'auto_legacy_silent')
    assert str(error) == 'message'
    error = InterpreterDiscoveryRequiredError('message', 'python3', 'auto_legacy_silent')
    assert str(error) == 'message'


# Generated at 2022-06-20 14:14:49.408571
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Unknown error"
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    expected_output = message
    assert repr(err) == expected_output

