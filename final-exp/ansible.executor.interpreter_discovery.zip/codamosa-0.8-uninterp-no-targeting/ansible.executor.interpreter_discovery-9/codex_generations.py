

# Generated at 2022-06-20 14:05:12.995059
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = FakeAction()
    task_vars = FakeTaskVars()
    task_vars._hostvars['unknown'] = FakeHostVars()
    interpreter_name = 'python'
    discovery_mode = 'auto'
    expect_interpreter = '/usr/bin/python'
    assert expect_interpreter == discover_interpreter(action, interpreter_name, discovery_mode, task_vars)



# Generated at 2022-06-20 14:05:16.068789
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError(
        message='Interpreter discovery required',
        interpreter_name='python',
        discovery_mode='auto'
    )
    assert e.__str__() == 'Interpreter discovery required'



# Generated at 2022-06-20 14:05:18.677020
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    assert str(error) == 'test'

# Generated at 2022-06-20 14:05:25.492199
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    with pytest.raises(InterpreterDiscoveryRequiredError) as excinfo:
        raise InterpreterDiscoveryRequiredError('Exception message', 'python', 'auto_legacy_silent')
    assert type(excinfo.value.__repr__) is MethodType
    assert excinfo.value.__repr__() == 'Exception message'


# Generated at 2022-06-20 14:05:31.831551
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_msg = 'interpreter discovery required'
    interpreter_name = 'python'
    discovery_mode = 'manual'
    error = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)

    assert error.__str__() == error
    assert error.__repr__() == error
    assert error.__unicode__() == error
    assert interpreter_name == error.interpreter_name
    assert discovery_mode == error.discovery_mode

# Generated at 2022-06-20 14:05:36.840492
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    from ansible.executor.discovery import InterpreterDiscoveryRequiredError
    msg = 'not found'
    interpreter_name = 'PyPy'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert error.message == msg
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert str(error) == msg

# Test cases for function discover_interpreter

# Generated at 2022-06-20 14:05:41.238616
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert to_text(repr(err)) == 'message'
    assert to_text(str(err)) == 'message'

# Generated at 2022-06-20 14:05:54.612210
# Unit test for function discover_interpreter
def test_discover_interpreter():

    sample_task_vars = dict()

    # Test with not supported interpreter
    try:
        result = discover_interpreter('/bin/bash', 'bash', 'auto', sample_task_vars)
    except NotImplementedError as ex:
        assert (repr(ex) == "Interpreter discovery not supported for bash")

    # Test with supported interpreter
    try:
        result = discover_interpreter('/bin/python', 'python', 'auto', sample_task_vars)
    except NotImplementedError as ex:
        assert (repr(ex) == "unsupported platform for extended discovery: unknown")

    result = discover_interpreter('/bin/python', 'python', 'auto_legacy_silent', sample_task_vars)
    assert(result == u'/usr/bin/python')

# Generated at 2022-06-20 14:05:58.431261
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert str(exc) == 'message'
    assert repr(exc) == 'message'


# Generated at 2022-06-20 14:06:05.023256
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Interpreter discovery required for {0} on host {1} (discovery mode: '{2}')".format(interpreter_name, "test_host", discovery_mode)
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert message == str(error)

# Generated at 2022-06-20 14:06:31.459751
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    class TestActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            interpreter = discover_interpreter(
                action=self,
                interpreter_name='python',
                discovery_mode='auto_legacy_silent',
                task_vars=task_vars
            )


# Generated at 2022-06-20 14:06:37.983909
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'interpreter discovery required'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:06:43.617010
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with pytest.raises(InterpreterDiscoveryRequiredError) as excinfo:
        raise InterpreterDiscoveryRequiredError(Exception, "Test Interpreter Name", "Test Discovery Mode")
    assert excinfo.value.interpreter_name == "Test Interpreter Name"
    assert excinfo.value.discovery_mode == "Test Discovery Mode"

# Generated at 2022-06-20 14:06:50.500107
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import module_loader

    action = module_loader.find_plugin('action', 'shell')
    task_vars = dict(inventory_hostname='foo.example.com', ansible_facts=dict(python=dict()))

    res = discover_interpreter(action, 'python', 'auto', task_vars)

    assert res

    # TODO: more testing, stub low-level interface

# Generated at 2022-06-20 14:07:04.436041
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.plugins.loading import find_plugin

    task = Task()
    task.action = 'command'
    task.args['_raw_params'] = "echo a"

    block = Block()
    block._in_vars = {}
    block._role_names = []
    block._play = None
    block._parent = None
    block._role = None
    block._task_include = None
    block._load_role_tasks = lambda _, __, ___: None
    block._name = ''
    block._loop = None
    block._block = None
    block._loop

# Generated at 2022-06-20 14:07:20.388165
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    class MockAction:
        def __init__(self, _discovery_warnings):
            self._discovery_warnings = _discovery_warnings

    _discovery_warnings = []
    action = MockAction(_discovery_warnings)
    message = u'Failed to find python interpreter /usr/bin/python3'
    interp_name = 'python3'
    discovery_mode = 'auto'
    host = 'test'


# Generated at 2022-06-20 14:07:23.417749
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('test message', 'test interpreter name', 'test discovery mode')

    assert str(error) == 'test message'

# Generated at 2022-06-20 14:07:26.899306
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(message="Test error message", interpreter_name="python3", discovery_mode="auto")
    assert str(error) == "Test error message"

# Generated at 2022-06-20 14:07:42.256461
# Unit test for function discover_interpreter
def test_discover_interpreter():

    interpreter_name = 'python'
    task_vars = {'inventory_hostname': 'localhost', 'ansible_connection': 'local'}

    # Print out all available interpreters, discovered interpreters and the result of the interpreter discovery on
    # localhost. This is a test helper to see the results of the test on the local machine.
    action_debug_msg = 'Available interpreters: {0}'.format(C.config.get_config_value('INTERPRETER_PYTHON_FALLBACK', task_vars))
    action_debug_msg += '\nDiscovery mode: {0}'.format('auto_legacy_silent')

# Generated at 2022-06-20 14:07:46.432112
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    c = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy_silent")
    assert c.__repr__() == "message"

# Generated at 2022-06-20 14:08:04.146634
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Python interpreter discovery required for host localhost but discovery mode auto is silent"
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert repr(err) == message

# Generated at 2022-06-20 14:08:07.807539
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError("Test error",
                                            interpreter_name="test_interpreter",
                                            discovery_mode="test_discovery_mode")
    assert err.__str__() == "Test error"


# Generated at 2022-06-20 14:08:11.420279
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(
        message='This is a test message',
        interpreter_name='python',
        discovery_mode='auto')

    assert error.message == 'This is a test message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

# Generated at 2022-06-20 14:08:16.422389
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError(
        'The message of the exception',
        'Python',
        'auto'
    )

    assert exception.__repr__() == 'The message of the exception'
    assert exception.__repr__() == exception.__str__()

# Generated at 2022-06-20 14:08:21.984203
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError("test message", "test name", "test discovery mode")
    assert e.interpreter_name == "test name"
    assert e.discovery_mode == "test discovery mode"
    assert str(e) == "test message"
    assert repr(e) == "test message"



# Generated at 2022-06-20 14:08:31.479911
# Unit test for function discover_interpreter
def test_discover_interpreter():

    module_info = {'host': 'localhost'}
    task_vars = {
        'ansible_connection': 'local',
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_interpreter_python': 'python',
        'ansible_interpreter_discovery_mode': 'auto'
    }

    action = None

    # Test disallow other interpreter
    try:
        discover_interpreter(action, 'perl', 'auto', task_vars)
        raise AssertionError('Should raise ValueError for interpreter discovery not supported for {0}'
                             .format('perl'))
    except ValueError as ex:
        print(ex)

    # Test Windows is not supported

# Generated at 2022-06-20 14:08:35.139598
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('no interpreter found', 'python', 'auto')
    assert str(err) == 'no interpreter found'



# Generated at 2022-06-20 14:08:40.390226
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Arrange
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = "This is the message"
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # Act & Assert
    assert interpreter_discovery_required_error.__str__() is message

# Generated at 2022-06-20 14:08:45.068711
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name_test = 'python'
    discovery_mode_test = 'auto_legacy'
    discovery_exception_test = InterpreterDiscoveryRequiredError('test message', interpreter_name_test, discovery_mode_test)

    assert discovery_exception_test.message == 'test message'
    assert discovery_exception_test.interpreter_name == 'python'
    assert discovery_exception_test.discovery_mode == 'auto_legacy'


# Generated at 2022-06-20 14:08:47.191017
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    with pytest.raises(Exception) as excinfo:
        raise InterpreterDiscoveryRequiredError('The message', 'the interpreter name', 'the discovery mode')
    assert str(excinfo.value) == 'The message'

# Generated at 2022-06-20 14:09:15.830996
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'message that should appear in str'
    interpreter_name = 'python'
    discovery_mode = 'auto'

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(error) == message

# Generated at 2022-06-20 14:09:17.963305
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    i = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert str(i) == i.message

# Generated at 2022-06-20 14:09:27.900629
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    # Initialize some simple objects for test
    myexec = TaskExecutor()
    myexec._discovery_warnings = []
    play = Play().load({}, variable_manager=VariableManager(), loader=None)
    play_context = PlayContext()
    myexec._play_context = play_context
    myexec._loader = None
    task = Task()
    role = Role()
   

# Generated at 2022-06-20 14:09:38.172870
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'Test interpreter'
    discovery_mode = 'auto_legacy_silent'
    message = 'Exception: Interpreter {} is not present on the target system, and interpreter discovery mode {} ' \
              'requires discovery'.format(interpreter_name, discovery_mode)
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message=message,
                                                                             interpreter_name=interpreter_name,
                                                                             discovery_mode=discovery_mode)
    assert message in str(interpreter_discovery_required_error)

# Generated at 2022-06-20 14:09:39.546862
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('Error message', 'python', 'auto')
    assert repr(e) == 'Error message'


# Generated at 2022-06-20 14:09:54.394507
# Unit test for function discover_interpreter
def test_discover_interpreter():

    display = Display()

    # Interpreter name is 'python'
    interpreter_name = 'python'

    # Discovery mode is 'auto_legacy_silent'
    discovery_mode = 'auto_legacy_silent'

    # task vars is none
    task_vars = None

    test_action = 'discover_interpreter'


# Generated at 2022-06-20 14:09:57.885965
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    x = InterpreterDiscoveryRequiredError('foo')
    assert x
    assert x.message == 'foo'
    assert x.__str__() == 'foo'
    assert x.__repr__() == 'foo'

# Generated at 2022-06-20 14:10:02.406993
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(u'InterpreterDiscoveryRequiredError Message',
                                                u'python',
                                                u'permissive')
    except Exception as ex:
        assert ex.message == u'InterpreterDiscoveryRequiredError Message'
        assert ex.interpreter_name == u'python'
        assert ex.discovery_mode == u'permissive'

# Generated at 2022-06-20 14:10:07.452225
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = ActionModule(connection=None, task_vars=dict(ansible_python_interpreter='/usr/bin/python'), become=False, become_user=None)

    dist = None
    version = None
    for version_map in C.config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP').values():
        dist = version_map.keys()[0]
        version = version_map.values()[0]
        break

    action._low_level_execute_command = lambda command, sudoable, in_data=None: dict(stdout='PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND', stderr='')


# Generated at 2022-06-20 14:10:10.991267
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('')
    assert err.interpreter_name == None
    assert err.discovery_mode == None



# Generated at 2022-06-20 14:11:01.883985
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError("err", "y", "z")
    assert err.message == "err"
    assert err.interpreter_name == "y"
    assert err.discovery_mode == "z"
    assert str(err) == "err"
    assert repr(err) == "err"

# Generated at 2022-06-20 14:11:13.612730
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_loader import ActionModule

    action_module = ActionModule()

    # Discovery fail cases

    # A
    task_vars = {'inventory_hostname': 'test_target_A'}

    # fail case A1.1 (bad mode)
    try:
        discover_interpreter(action_module, 'python', 'unsupported', task_vars)
        assert False, 'Expected ValueError'
    except ValueError as ex:
        assert to_native(ex) == 'Interpreter discovery not supported for python'

    # fail case A1.2 (no default python)

# Generated at 2022-06-20 14:11:22.324812
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto'
    msg = 'Interpreter discovery required for {0}'.format(test_interpreter_name)
    test_error = InterpreterDiscoveryRequiredError(msg, test_interpreter_name, test_discovery_mode)
    assert test_error.message == 'Interpreter discovery required for python'
    assert type(test_error.message) == str
    assert test_error.interpreter_name == 'python'
    assert test_error.discovery_mode == 'auto'
    assert str(test_error) == 'Interpreter discovery required for python'
    assert repr(test_error) == 'Interpreter discovery required for python'

# Generated at 2022-06-20 14:11:24.364547
# Unit test for function discover_interpreter
def test_discover_interpreter():
     # This module is not available on non-linux platform.
     return

# Generated at 2022-06-20 14:11:34.383677
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    action_plugin = action_loader.get('setup', class_only=True)
    action_factory = action_plugin.load()
    action = action_factory(
        'setup',
        {'connection': 'local',
         'hosts': ['localhost'],
         'become': False,
         'become_user': None,
         'become_method': 'sudo'},
        {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'},
    )

# Generated at 2022-06-20 14:11:49.350748
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule

    res = discover_interpreter(ActionModule(), "invalid", "auto", dict())
    assert res == None

    res = discover_interpreter(ActionModule(), "python", "invalid", dict())
    assert res == None

    res = discover_interpreter(ActionModule(), "python", "auto", dict())
    assert res == "/usr/bin/python"

    res = discover_interpreter(ActionModule(), "python", "auto_legacy_silent", dict())
    assert res == "/usr/bin/python"

    res = discover_interpreter(ActionModule(), "python", "auto_legacy", dict())
    assert res == "/usr/bin/python"


# Generated at 2022-06-20 14:12:01.759110
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_factory import ActionModuleFactory
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.sentinel import Sentinel


    action_loader = ActionModuleFactory()

    display = Display()
    play_context = PlayContext()
    play_context.connection = 'local'
    play_context._symbols = {}

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)


# Generated at 2022-06-20 14:12:03.801364
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert e.__repr__() == e.message


# Generated at 2022-06-20 14:12:15.859521
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import tempfile
    import shutil
    import sys
    import os

    class PlayWrapper(Play):
        def __init__(self):
            self.connection = 'local'
            self.hosts = 'localhost'
            self.name = 'Test Play'
            self.become = False
            self.become_user = 'root'
            self.vars = {}
            self.extra_vars = {}
            self.roles = []
            self.force_handlers = False


# Generated at 2022-06-20 14:12:20.729641
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError(
            message='Test message',
            interpreter_name='python',
            discovery_mode='auto_legacy_silent'
        )
    except InterpreterDiscoveryRequiredError as e:
        assert e.__repr__() == e.message

# Generated at 2022-06-20 14:14:05.821465
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError("1", "2", "3")
    expected = "1"

    assert expected == str(err)



# Generated at 2022-06-20 14:14:06.891014
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # The interpreter discovery code is not in a unit-testable form, so we can't do much here yet.
    assert True

# Generated at 2022-06-20 14:14:20.099558
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock
    import copy
    import platform

    # Skip if we don't have any required python modules
    try:
        import ansible.executor.discovery
    except ImportError:
        return

    # Skip if we don't have any required python modules
    if platform.python_version() < '2.7':
        return

    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_versioned_doclink

    display = Display()

    #
    # Test discovery for a supported OS
    #

    # Test data:
    action = ActionBase()

# Generated at 2022-06-20 14:14:33.496581
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.plugins import action
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_docstring
    display = Display()

    def _exec_module(conn, tmp_path, module_name, module_args, inject=None, complex_args=None, **kwargs):
        """
        Executes a temporary module on the remote host
        """
        temp

# Generated at 2022-06-20 14:14:48.325276
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action.script import ActionModule
    from ansible.vars.manager import VariableManager

    class FakePlayContext(object):

        def __init__(self, connection='local'):
            self.connection = connection
            self.become = False
            self.become_method = None
            self.become_user = None
            self.remote_addr = None
            self.remote_user = None
            self.port = None
            self.environment = dict()
            self.shell = None
            self.forks = 5
            self.no_log = False
            self.no_log_path = None

    class FakeTask(object):

        def __init__(self, play_context):
            self._play_context = play_context

# Generated at 2022-06-20 14:14:50.732358
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy_silent")
    assert repr(exception) == "message"



# Generated at 2022-06-20 14:14:52.846774
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Initialize
    # Run the function under test
    # Assert the result
    assert InterpreterDiscoveryRequiredError("message","interpreter_name","discovery_mode").__repr__() == "message"

# Generated at 2022-06-20 14:15:01.224843
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    # Create an instance of class InterpreterDiscoveryRequiredError
    interpreter_discovery_required_error_instance = InterpreterDiscoveryRequiredError(
        message="InterpreterDiscoveryRequiredError message",
        interpreter_name="python",
        discovery_mode="auto_legacy_silent")

    assert repr(interpreter_discovery_required_error_instance) == "InterpreterDiscoveryRequiredError message"