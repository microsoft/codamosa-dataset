

# Generated at 2022-06-20 14:05:15.159562
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_obj = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert repr(test_obj) == "message"

# Generated at 2022-06-20 14:05:24.579632
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError("Error message", "python", "auto")
    assert to_text(e) == u'Error message'
    assert e.interpreter_name == 'python'
    assert e.discovery_mode == 'auto'

# Generated at 2022-06-20 14:05:34.556734
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
    import ansible.plugins.connection

    class TestTaskQueueManager(TaskQueueManager):
        def _wait_on_pending_results(self, iterator, one_pass=False, max_passes=1):
            return super(TaskQueueManager, self)._wait_on_pending_results(iterator, one_pass=True, max_passes=1)


# Generated at 2022-06-20 14:05:36.104484
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    a = InterpreterDiscoveryRequiredError("Error", "PYTHON", "AUTO_SILENT")
    assert "Error" == str(a)

# Generated at 2022-06-20 14:05:38.985964
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(message="Testing InterpreterDiscoveryRequiredError", interpreter_name="python", discovery_mode="auto")
    assert isinstance(error, InterpreterDiscoveryRequiredError)
    assert error.message == "Testing InterpreterDiscoveryRequiredError"
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"

# Generated at 2022-06-20 14:05:45.287998
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    m = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert m.interpreter_name == interpreter_name
    assert m.discovery_mode == discovery_mode
    assert m.message == message
    assert m.__str__() == message
    assert m.__repr__() == message

# Generated at 2022-06-20 14:05:50.063016
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    """Test for __str__ method of class InterpreterDiscoveryRequiredError"""
    # Test with the default values
    e = InterpreterDiscoveryRequiredError("Test message", "python", "auto")
    expected = "Test message"
    actual = e.__str__()
    assert actual == expected, "Expected: {0}, Actual: {1}".format(expected, actual)


# Generated at 2022-06-20 14:05:59.541016
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        error = InterpreterDiscoveryRequiredError(
            "message",
            "/usr/bin/python",
            "auto"
        )
        assert error.interpreter_name == "/usr/bin/python"
        assert error.discovery_mode == "auto"
    except:
        assert False


# Generated at 2022-06-20 14:06:06.083225
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'Python interpreter discovery required'
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.message == message
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode
    assert str(ex) == message
    assert repr(ex) == message

# Generated at 2022-06-20 14:06:16.505621
# Unit test for function discover_interpreter
def test_discover_interpreter():
    args = {}
    args['action'] = None
    args['interpreter_name'] = 'python'
    args['discovery_mode'] = 'auto'
    args['task_vars'] = {
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_python_interpreter_noconflict': '/usr/bin/python'
    }
    assert discover_interpreter(args['action'], args['interpreter_name'], args['discovery_mode'], args['task_vars']) == args['task_vars']['ansible_python_interpreter']


# Generated at 2022-06-20 14:06:29.700642
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        message="message",
        interpreter_name="python",
        discovery_mode="auto_legacy_silent"
    )
    assert str(error) == "message"



# Generated at 2022-06-20 14:06:33.804203
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Init some variables
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'test message'
    iterpreter_discovery_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    # Test method __repr__
    assert iterpreter_discovery_error.__repr__() == message

# Generated at 2022-06-20 14:06:35.504109
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == u'/usr/bin/python'

# Generated at 2022-06-20 14:06:39.650321
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'This is a test message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(e) == message

# Generated at 2022-06-20 14:06:47.565351
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    '''Unit test for method __repr__ of class InterpreterDiscoveryRequiredError'''
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(
        'message', 'interpreter_name', 'discovery_mode')
    assert str(interpreter_discovery_required_error) == 'message'

test_InterpreterDiscoveryRequiredError___repr___output = '''InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)'''

# Generated at 2022-06-20 14:06:52.705540
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Arrange
    interpreter_name = 'python'
    discovery_mode = 'auto'

    # Act
    obj = InterpreterDiscoveryRequiredError(None, interpreter_name, discovery_mode)
    actual_result = obj.__repr__()

    # Assert
    desired_result = 'None'  # we're not testing output here, just the method
    assert desired_result == actual_result

# Generated at 2022-06-20 14:06:57.486252
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = "auto"

    error = InterpreterDiscoveryRequiredError("message", interpreter_name, discovery_mode)
    assert error.__str__() == "message"


# Generated at 2022-06-20 14:07:01.265483
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert error.__str__() == 'message'

# Generated at 2022-06-20 14:07:03.825279
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # find the module
    action = __import__('ansible.modules.system.setup', fromlist=[])
    globals()['action'] = action

    # run the discovery
    python = discover_interpreter(action=action, interpreter_name='python', discovery_mode='auto', task_vars={})
    print('python = %r' % python)



# Generated at 2022-06-20 14:07:07.310043
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('test', 'interpreter_name', 'discovery_mode')
    assert e.interpreter_name == 'interpreter_name'
    assert e.discovery_mode == 'discovery_mode'

# Generated at 2022-06-20 14:07:22.907531
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_object = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert repr(test_object) == "message"

# Generated at 2022-06-20 14:07:32.236083
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class ActionModule:
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            return {'stdout': to_text(cmd)}


    class Connection:
        def has_pipelining(self):
            return True


    class HostVars:
        def get(self, key, default):
            if key == 'inventory_hostname':
                return 'localhost'

            return default

    class Runner:
        def __init__(self, module_args, module_name=None,
                     task_vars=None, play_context=None, loader=None,
                     shared_loader_obj=None, variable_manager=None):
            self.action = ActionModule()

# Generated at 2022-06-20 14:07:37.908999
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Arrange
    message = 'this is a dummy string'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # Act
    result = exception.__repr__()

    # Assert
    assert message == result



# Generated at 2022-06-20 14:07:41.231934
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'not implemented'
    err = InterpreterDiscoveryRequiredError(msg, 'python', 'auto')
    assert err.__str__() == msg
    assert repr(err) == msg

# Generated at 2022-06-20 14:07:44.108350
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert repr(InterpreterDiscoveryRequiredError('test', 'python', 'test mode')) == 'test'


# Generated at 2022-06-20 14:07:50.176329
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = "Python interpreter discovery required for unknown host"
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert err.message == message
    assert err.interpreter_name == interpreter_name
    assert err.discovery_mode == discovery_mode


# Generated at 2022-06-20 14:08:03.009606
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock
    import copy

    def _fake_execute_module(module_name, module_path, module_args, task_vars, tmp, delete_remote_tmp,
                             complex_args=None, **kwargs):
        named_args = dict(host='localhost')
        if complex_args:
            named_args.update(complex_args)

# Generated at 2022-06-20 14:08:07.860994
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    discovery_mode = "auto"
    interpreter_name = "python"
    message = "Interpreter discovery required"
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    expected = message
    result = exception.__str__()
    assert result == expected


# Generated at 2022-06-20 14:08:14.981279
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    from pprint import pprint
    message = "Test message"
    py_list = ['2.7', '3.7']
    assert str(InterpreterDiscoveryRequiredError(message, py_list, 'auto_legacy_silent')) == message
    assert str(InterpreterDiscoveryRequiredError(message, py_list, 'auto_legacy')) == message
    assert str(InterpreterDiscoveryRequiredError(message, py_list, 'auto')) == message
    assert str(InterpreterDiscoveryRequiredError(message, py_list, 'manual')) == message


# Generated at 2022-06-20 14:08:26.651793
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.action import ActionBase

    class MockRunner(object):
        def __init__(self, host, task_vars=dict(), shared_loader_obj=None):
            self.host = MockExecutor(host, task_vars)
            self.shared_loader_obj = shared_loader_obj



# Generated at 2022-06-20 14:08:48.928317
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Exception message: 'Interpreter foo is not present on remote host, discovery required'
    with pytest.raises(InterpreterDiscoveryRequiredError,
                       match='^Interpreter foo is not present on remote host, discovery required$'):
        raise InterpreterDiscoveryRequiredError(
            'Interpreter foo is not present on remote host, discovery required',
            'foo',
            'auto'
        )


# Generated at 2022-06-20 14:08:53.225155
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with pytest.raises(InterpreterDiscoveryRequiredError):
        raise InterpreterDiscoveryRequiredError("Test exception message", "python", "auto_legacy_silent")

# Generated at 2022-06-20 14:08:57.913904
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "discovery required"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(exception) == message

# Generated at 2022-06-20 14:09:00.863469
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('test_message', 'python', 'auto')
    assert error.__str__() == 'test_message'

# Generated at 2022-06-20 14:09:02.109801
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    pass  # nothing to test for now

# Generated at 2022-06-20 14:09:05.202087
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError("msg", "python", "auto")
    assert err.message == "msg"
    assert err.interpreter_name == "python"
    assert err.discovery_mode == "auto"

# Generated at 2022-06-20 14:09:08.939446
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    class TestObj:
        var = 'var'

    test_task_vars = TestObj()
    test_task_vars.inventory_hostname = 'test_host'
    test_ex = InterpreterDiscoveryRequiredError('test_message', 'test_interpreter', 'test_discovery_mode')
    expected_result = 'test_message'

    assert str(test_ex) == expected_result


# Generated at 2022-06-20 14:09:14.532965
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto_legacy"
    message = "test"
    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert obj.__repr__() == message


# Generated at 2022-06-20 14:09:23.545514
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    a = InterpreterDiscoveryRequiredError(message="testing msg", interpreter_name="python", discovery_mode="exact_legacy")
    assert a.interpreter_name == "python"
    a.interpreter_name = "python3"
    assert a.interpreter_name == "python3"
    assert a.discovery_mode == "exact_legacy"
    a.discovery_mode = "auto_legacy_silent"
    assert a.discovery_mode == "auto_legacy_silent"

# Generated at 2022-06-20 14:09:39.885825
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Tests discover_interpreter function with known values.
    """
    from ansible.executor.discovery import discover_interpreter
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    #
    # Test a simple run of the function and verify that it returns the correct
    # value.
    #

    task_vars = {}
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    action = _ActionModule(None, '/path/to/playbook/dir')

    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

# Generated at 2022-06-20 14:10:16.464598
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Error", "python", "auto")
    except InterpreterDiscoveryRequiredError as ex:
        assert ex == "Error"
        assert ex.interpreter_name == "python"
        assert ex.discovery_mode == "auto"

# Generated at 2022-06-20 14:10:20.117692
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('foo', 'python', 'auto_legacy_silent')
    except Exception as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-20 14:10:28.031380
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python_discovery_test'
    discovery_mode = 'auto'
    try:
        raise InterpreterDiscoveryRequiredError(
            'interpreter_name: {0} discovery_mode: {1}'.format(interpreter_name, discovery_mode),
            interpreter_name, discovery_mode
        )
    except Exception as e:
        assert e.message == 'interpreter_name: {0} discovery_mode: {1}'.format(interpreter_name, discovery_mode)
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:10:33.196161
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = "InterpreterDiscoveryRequiredError"
    interpreter_name = "python"
    discovery_mode = "auto"
    InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert InterpreterDiscoveryRequiredError.__repr__() == message


# Generated at 2022-06-20 14:10:35.671699
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', {}) == '/usr/bin/python'

# Generated at 2022-06-20 14:10:39.868635
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto_silent"
    message = u"unable to find an interpreter"
    i = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(i) == message

# Generated at 2022-06-20 14:10:46.932847
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    new_InterpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError("test_msg", "test_interpreter_name", "test_discovery_mode")
    assert new_InterpreterDiscoveryRequiredError.message == "test_msg"
    assert new_InterpreterDiscoveryRequiredError.interpreter_name == "test_interpreter_name"
    assert new_InterpreterDiscoveryRequiredError.discovery_mode == "test_discovery_mode"
    repr(new_InterpreterDiscoveryRequiredError)

# Generated at 2022-06-20 14:10:51.795532
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "test message"
    interpreter_name = "python"
    discovery_mode = "auto"
    b = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(b) == "%s" % (message)


# Generated at 2022-06-20 14:10:58.225194
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert str(err) == 'message'
    assert repr(err) == 'message'
    assert err.message == 'message'
    assert err.interpreter_name == 'interpreter_name'
    assert err.discovery_mode == 'discovery_mode'


# Generated at 2022-06-20 14:11:02.233751
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            message='Interpreter Discovery is Required',
            interpreter_name='python',
            discovery_mode='auto_silent')
    except InterpreterDiscoveryRequiredError:
        pass

# Generated at 2022-06-20 14:12:24.415175
# Unit test for function discover_interpreter
def test_discover_interpreter():

    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    config_file = os.path.join(tmpdir, 'ansible.cfg')
    distro_map_file = os.path.join(tmpdir, 'distro_map.yml')

    with open(distro_map_file, 'w') as f:
        f.write("""
        centos:
          '6': /usr/bin/python2.6
          '7': /usr/bin/python2.7
        """)

    with open(config_file, 'w') as f:
        f.write("""
        [defaults]
        interpreter_python_distro_map = %s
        """ % distro_map_file)

    # Set environment

# Generated at 2022-06-20 14:12:38.092696
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

    play = Play.load(dict(
        name="Ansible Play",
        hosts='host1',
        gather_facts='no',
        tasks=[dict(action=dict(module='command', args=dict(cmd='/bin/true')))]
    ), variable_manager=VariableManager(), loader=None)



# Generated at 2022-06-20 14:12:42.529539
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError("test_message", "test_interpreter_name", "test_discovery_mode")
    assert exc.interpreter_name == "test_interpreter_name"
    assert exc.discovery_mode == "test_discovery_mode"


# Generated at 2022-06-20 14:12:50.469106
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # _version_fuzzy_match
    assert _version_fuzzy_match('5.5', {'5.5': u'/usr/bin/py1', '5.6': u'/usr/bin/py2'}) == u'/usr/bin/py1'
    assert _version_fuzzy_match('5.4', {'5.5': u'/usr/bin/py1', '5.6': u'/usr/bin/py2'}) == u'/usr/bin/py1'
    assert _version_fuzzy_match('5.4', {'5.4': u'/usr/bin/py1', '5.6': u'/usr/bin/py2'}) == u'/usr/bin/py1'

# Generated at 2022-06-20 14:12:54.318202
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto"
    error = InterpreterDiscoveryRequiredError("interpreter discovery required", interpreter_name, discovery_mode)
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:13:00.836342
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = 'Interpreter discovery required'
    exp_result = 'Interpreter discovery required'
    idr_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert idr_error.__repr__() == exp_result


# Generated at 2022-06-20 14:13:08.902969
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = None
    discovery_mode = None

    exception = InterpreterDiscoveryRequiredError('message', interpreter_name, discovery_mode)

    result = str(exception)

    assert result == 'message'



# Generated at 2022-06-20 14:13:20.403661
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Unit test for function discover_interpreter.
    """

    task_vars = dict()
    action = MockAction()
    interpreter_name = 'python'

    # test happy path of discovery using pipelining
    action._connection.has_pipelining = True
    action._low_level_execute_command.return_value = {
        "stdout": "PLATFORM\nLinux\nFOUND\n/usr/bin/python2.7\nENDFOUND"
    }
    result = discover_interpreter(action, interpreter_name, 'auto_legacy_silent', task_vars)

    assert result == "/usr/bin/python2.7"

    # test unhappy path of discovery using pipelining
    action._connection.has_pipelining = True
    action._low_level_

# Generated at 2022-06-20 14:13:35.417436
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class MockAction(object):
        """
        This class is used to create mock objects to patch the interpreter discovery module
        """

        def __init__(self, tasks, hostvars):
            self._discovery_warnings = []
            self.runner_on_ok = tasks
            self.task_vars = dict()
            self.task_vars['inventory_hostname'] = 'test'
            self.task_vars['hostvars'] = hostvars
            self._low_level_execute_command = None
            self._connection = MockConnection()

        def vars(self):
            return self.task_vars

    class MockConnection(object):
        def __init__(self):
            self._has_pipelining = True
            self.has_pipelining = self._has_pipelining


# Generated at 2022-06-20 14:13:46.098419
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Create a new object of class InterpreterDiscoveryRequiredError
    e = InterpreterDiscoveryRequiredError("interpreter discovery required", "python", "auto_legacy")

    # Test if object e is an object of class InterpreterDiscoveryRequiredError
    assert type(e) == InterpreterDiscoveryRequiredError

    # Test the attribute "message" of object e (it should be interpreted discovery required)
    assert e.message == "interpreter discovery required"

    # Test the attribute "interpreter_name" of object e (it should be python)
    assert e.interpreter_name == "python"

    # Test the attribute "discovery_mode" of object e (it should be auto_legacy)
    assert e.discovery_mode == "auto_legacy"
