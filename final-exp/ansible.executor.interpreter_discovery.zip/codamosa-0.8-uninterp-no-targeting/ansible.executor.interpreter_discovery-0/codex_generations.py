

# Generated at 2022-06-20 14:05:07.015071
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(message='I am an InterpreterDiscoveryRequiredError',
                                            interpreter_name='python', discovery_mode='auto')
    assert err.message == 'I am an InterpreterDiscoveryRequiredError'
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'auto'
    assert str(err) == 'I am an InterpreterDiscoveryRequiredError'
    assert repr(err) == 'I am an InterpreterDiscoveryRequiredError'


# Generated at 2022-06-20 14:05:09.851611
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    instance = InterpreterDiscoveryRequiredError(u'test msg', u'pytest_interpreter', u'auto')
    assert instance.__str__() == u'test msg'

# Generated at 2022-06-20 14:05:11.829501
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert str(exc) == 'message'

# Generated at 2022-06-20 14:05:15.929491
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception_thrown = InterpreterDiscoveryRequiredError(
        'message',
        'interpreter_name',
        'discovery_mode')

    assert exception_thrown.__str__() == 'message'
    assert exception_thrown.__repr__() == 'message'

# Generated at 2022-06-20 14:05:19.480787
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError('Test', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as exception:
        assert repr(exception) == 'Test'

# Generated at 2022-06-20 14:05:23.992668
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert str(err) == "message"
    assert repr(err) == "message"

# Generated at 2022-06-20 14:05:28.850338
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    import sys

    idre = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")

    if sys.version_info[0] == 2:
        assert repr(idre) == "message"
    else:
        assert repr(idre) == "message"



# Generated at 2022-06-20 14:05:33.297933
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Given a InterpreterDiscoveryRequiredError
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError('message', interpreter_name='python', discovery_mode='auto')
    # then test
    actual = interpreter_discovery_required_error.__repr__()
    # verify
    assert actual == 'message'

# Generated at 2022-06-20 14:05:38.697873
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: unit test
    assert discover_interpreter is not None

# Generated at 2022-06-20 14:05:44.273099
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = 'Python interpreter discovery required'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.message == message
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:05:58.029696
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError(message="Finding python interpreter was unsuccessful.", interpreter_name="python", discovery_mode="auto")
    assert str(ex) == "Finding python interpreter was unsuccessful."

# Generated at 2022-06-20 14:06:11.197854
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test interpreter_name
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = dict()
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except Exception as ex:
        print(ex.message)

    print("Test interpreter_name success, passed")
    # Test discovery_mode
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict()
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except Exception as ex:
        print(ex.message)

    print("Test discovery_mode success, passed")

    # Test task_vars

# Generated at 2022-06-20 14:06:15.890776
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Test message.'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(e) == message


# Generated at 2022-06-20 14:06:21.332199
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(message="test_message1", interpreter_name="test_interpreter_name1",
                                              discovery_mode="test_discovery_mode1")
    assert error.__str__() == "test_message1"


# Generated at 2022-06-20 14:06:26.135344
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    python_interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required for python:auto'
    error = InterpreterDiscoveryRequiredError(message, python_interpreter_name, discovery_mode)
    assert str(error) == message


# Generated at 2022-06-20 14:06:35.383817
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    class DummyActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            self._discovery_warnings = []
            return discover_interpreter(self, 'python', 'auto_legacy_silent', task_vars)

    class DummyConnection(object):
        class ActionModule(object):
            pass

        @staticmethod
        def has_pipelining():
            return True

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            return {'stdout': to_text(in_data)}


# Generated at 2022-06-20 14:06:40.108302
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    with pytest.raises(InterpreterDiscoveryRequiredError) as e:
        raise InterpreterDiscoveryRequiredError('This is a message', 'python', 'auto/auto_silent')

    assert str(e.value) == 'This is a message'


# Generated at 2022-06-20 14:06:44.655388
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex = InterpreterDiscoveryRequiredError('test_message', 'pytest', 'auto_legacy_silent')
    assert ex.interpreter_name == 'pytest'
    assert ex.discovery_mode == 'auto_legacy_silent'


# Generated at 2022-06-20 14:06:46.702423
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert error == "message"

# Generated at 2022-06-20 14:06:54.231225
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(
        message='interpreter discovery is required for this execution',
        interpreter_name='/usr/bin/python',
        discovery_mode='auto'
    )
    assert error.interpreter_name == '/usr/bin/python'

# Generated at 2022-06-20 14:07:12.295429
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Init the module action
    action = ActionModule(Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Init the task_vars

# Generated at 2022-06-20 14:07:16.408892
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(u'test message', u'python', u'I')
    assert err.__str__() == u'test message'

# Generated at 2022-06-20 14:07:22.734967
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    with pytest.raises(InterpreterDiscoveryRequiredError) as exc_info:
        raise InterpreterDiscoveryRequiredError(message='Interpreter Discovery Required',
                                                interpreter_name='python',
                                                discovery_mode='default')
    assert str(exc_info.value) == 'Interpreter Discovery Required'



# Generated at 2022-06-20 14:07:24.082122
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('error message', 'python', 'auto')
    assert error.message == 'error message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

# Generated at 2022-06-20 14:07:30.975131
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(u"Python interpreter discovery is required, but not enabled (see https://docs.ansible.com/ansible/latest/reference_appendices/interpreter_discovery.html#interpreter-auto-discovery)", 'python', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as ex:
        if ex.interpreter_name == 'python' and ex.discovery_mode == 'auto_legacy_silent':
            pass
        else:
            assert False

# Generated at 2022-06-20 14:07:35.892350
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex1 = InterpreterDiscoveryRequiredError('message1','python','auto')
    assert ex1.__str__() == 'message1'
    assert ex1.__repr__() == 'message1'

    ex2 = InterpreterDiscoveryRequiredError('message2','python','auto_silent')
    assert ex2.__str__() == 'message2'
    assert ex2.__repr__() == 'message2'

    ex3 = InterpreterDiscoveryRequiredError('message3','python','auto_legacy')
    assert ex3.__str__() == 'message3'
    assert ex3.__repr__() == 'message3'

    ex4 = InterpreterDiscoveryRequiredError('message4','python','auto_legacy_silent')
    assert ex4.__str__() == 'message4'

# Generated at 2022-06-20 14:07:39.868403
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    from ansible.executor.discovery import InterpreterDiscoveryRequiredError
    e = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert __str__ == 'message'

# Generated at 2022-06-20 14:07:43.796413
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Test Message'
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(interpreter_discovery_required_error) == message


# Generated at 2022-06-20 14:07:48.295343
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test the default case
    interpreter = discover_interpreter('', 'python', 'auto_legacy_silent', {'inventory_hostname': '127.0.0.1'})
    assert interpreter == '/usr/bin/python'

# Generated at 2022-06-20 14:07:49.426464
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    assert error.__str__() == 'test'



# Generated at 2022-06-20 14:07:59.946897
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError('Test Message', 'python', 'auto')
    assert str(exc) == 'Test Message'

# Generated at 2022-06-20 14:08:03.063696
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('test message', 'test_interpreter', 'test_mode')
    assert err.__str__() == 'test message'


# Generated at 2022-06-20 14:08:09.340883
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(message="Test", interpreter_name="python", discovery_mode="auto_legacy")
    except InterpreterDiscoveryRequiredError as exc:
        assert str(exc) == "Test"
        assert exc.interpreter_name == "python"
        assert exc.discovery_mode == "auto_legacy"
        assert exc.message == "Test"
        assert repr(exc) == "Test"

# Generated at 2022-06-20 14:08:22.672211
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            self._task_vars = task_vars
            del tmp  # tmp no longer has any effect


# Generated at 2022-06-20 14:08:31.852957
# Unit test for function discover_interpreter
def test_discover_interpreter():
    #Test interpreter_name
    test_interpreter_name = 'python'
    assert discover_interpreter('action',test_interpreter_name,'auto_legacy_silent',{'inventory_hostname':'fakehost'}) == '/usr/bin/python'
    test_interpreter_name = 'unsupported'
    try:
        discover_interpreter('action',test_interpreter_name,'auto_legacy_silent',{'inventory_hostname':'fakehost'})
    except ValueError as e:
        assert 1 == 1
    except Exception:
        assert 1 == 0

    #Test discovery_mode
    test_discovery_mode = 'auto_legacy_silent'

# Generated at 2022-06-20 14:08:39.385923
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = 'oops'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    e = InterpreterDiscoveryRequiredError(message=error_message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert "InterpreterDiscoveryRequiredError: {0}, interpreter_name: {1}, discovery_mode: {2}".format(error_message, interpreter_name, discovery_mode) == str(e)


# Generated at 2022-06-20 14:08:46.845800
# Unit test for function discover_interpreter
def test_discover_interpreter():
    global display
    display = Display()
    action = object
    task_vars = {}

    def _low_level_execute_command(interpreter, sudoable=False, in_data=None):
        global display

        platform_script = pkgutil.get_data('ansible.executor.discovery', 'python_target.py')
        if in_data == platform_script:
            # Linux
            res = dict(stdout=json.dumps(dict(platform_dist_result=('', '', ''),
                                              osrelease_content=b'NAME="Ubuntu" VERSION="16.04.3 LTS (Xenial Xerus)"')))

# Generated at 2022-06-20 14:08:51.725454
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError(message='Message', interpreter_name='python', discovery_mode='auto')
    except InterpreterDiscoveryRequiredError as t:
        assert str(t) == 'Message'



# Generated at 2022-06-20 14:09:03.688219
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Not using the action arg
    # pylint: disable=no-value-for-parameter, unused-argument
    # This is a workaround to have proper testing of this internal function
    # without adding a new module_utils file
    def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
        # Only the first invocation of this function is tested here
        if cmd == "command -v '/opt/python27/bin/python2.7'":
            return {'stdout': '/opt/python27/bin/python2.7'}

# Generated at 2022-06-20 14:09:12.664374
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error_msg = 'required interpreter discovery here'
    error = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert error.message == error_msg

# Generated at 2022-06-20 14:09:35.168534
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected_result = "Distribution Foo 1.0 on host localhost should use /usr/bin/python3, but is using /usr/bin/python, since the"
    test_instance = InterpreterDiscoveryRequiredError(expected_result, "python", "auto")
    actual_result = test_instance.__repr__()
    assert actual_result == expected_result

# Generated at 2022-06-20 14:09:38.019279
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('test message', 'test interpreter', 'test discovery mode')
    assert exc.__repr__() == 'test message'



# Generated at 2022-06-20 14:09:42.131304
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = u'This is a test message'
    interpreter_name = u'python'
    discovery_mode = u'auto_legacy_silent'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.message == message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:09:45.293153
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'interpreter discovery required'

    expected = "interpreter discovery not supported for python"
    actual = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(actual) == expected
    assert repr(actual) == expected

# Generated at 2022-06-20 14:09:50.235227
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError(
            'Test message', 'python', 'auto_legacy_silent', 'task_vars')
    except InterpreterDiscoveryRequiredError as inst:
        assert(inst.__str__() == 'Test message')

# Generated at 2022-06-20 14:09:58.467284
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "error message"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert error.message == msg
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert str(error) == msg
    assert repr(error) == msg
    print("test_InterpreterDiscoveryRequiredError: success")


# Generated at 2022-06-20 14:10:05.906686
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from mock import patch

    from ansible.executor.module_common import _low_level_execute_command
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars

    # Set up some mocks for the module import
    task = TaskInclude()
    play_context = PlayContext()
    play_context.prompt = (None, None)
    connection = None

    # Set up the discover_interpreter mocks using the patch decorator
    @patch.object(TaskInclude, '_low_level_execute_command')
    def test1(_low_level_execute_command):
        # Set up the expected return values for the mocked _low_level_execute_command function
        _low_

# Generated at 2022-06-20 14:10:11.548166
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Generate an object with all attributes of a class ModuleUtilsPluginLoader
    class module_utils_plugin_loader_class():
        def __init__(self):
            self.action = None
            self.task_vars = None
    # Configure the traget host
    module_utils_plugin_loader_class.action = dict()
    module_utils_plugin_loader_class.action['host'] = dict()
    module_utils_plugin_loader_class.action['host']['name'] = 'test.example.com'

    # Configure the target host variables
    module_utils_plugin_loader_class.task_vars = dict()
    module_utils_plugin_loader_class.task_vars['ansible_python_interpreter'] = '/usr/bin/python'

    # Test that the interpreter discovery

# Generated at 2022-06-20 14:10:16.666125
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'Interpreter discovery is required due to ambiguous path or missing interpreter'
    interpreter_name = 'python'
    discovery_mode = 'auto'

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert exception.__str__() == exception.message


# Generated at 2022-06-20 14:10:26.753673
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import re
    import platform
    # test with only one python version installed
    if platform.python_version() == '3.3':
        python_path_list = ['/usr/bin/python3.3']
    else:
        python_path_list = ['/usr/bin/python' + platform.python_version()[0:3]]
    osrelease_content = b'ANSIBLE_PLATFORM_DISTRO=centos\nANSIBLE_PLATFORM_VERSION=7.6.1810'
    platform_info = {
        'platform_dist_result': [],
        'osrelease_content': osrelease_content
    }

# Generated at 2022-06-20 14:10:57.175730
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'test message'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.__str__() == message


# Generated at 2022-06-20 14:11:05.738719
# Unit test for function discover_interpreter

# Generated at 2022-06-20 14:11:15.181952
# Unit test for function discover_interpreter

# Generated at 2022-06-20 14:11:22.790253
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "msg"
    interpreter_name = "python"
    discovery_mode = "auto"

    exception = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert exception.__repr__() == msg

# Generated at 2022-06-20 14:11:28.465665
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'
    else:
        assert False, "InterpreterDiscoveryRequiredError was not raised"

# Generated at 2022-06-20 14:11:32.857903
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception_str = "test message"
    exception_type = "test interpreter"
    exception_discovery_mode = "test discovery mode"
    exception = InterpreterDiscoveryRequiredError(
        exception_str, exception_type, exception_discovery_mode)
    assert exception.__repr__() == exception_str


# Generated at 2022-06-20 14:11:37.077674
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message= "Interpreter discovery required"
    exception = InterpreterDiscoveryRequiredError(message,
                                                  interpreter_name,
                                                  discovery_mode)
    assert exception.message == message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode
    # 'str(exception)' call should not fail
    str(exception)
    # 'repr(exception)' call should not fail
    repr(exception)

# Generated at 2022-06-20 14:11:42.984345
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError(
        message="Discovery required", interpreter_name="python", discovery_mode="legacy")
    assert exception.message == "Discovery required"
    assert exception.interpreter_name == "python"
    assert exception.discovery_mode == "legacy"

# Generated at 2022-06-20 14:11:45.964382
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('test', 'foo', 'bar')

    assert str(error) == 'test'
    assert repr(error) == 'test'

# Generated at 2022-06-20 14:11:51.308714
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test the constructor of class
    # error message
    msg = "Python interpreter discovery required, but disabled"
    # create an instance of class
    ex = InterpreterDiscoveryRequiredError(
        message=msg,
        interpreter_name="python",
        discovery_mode="disabled"
    )
    # member of object
    assert ex.message == msg
    assert ex.interpreter_name == "python"
    assert ex.discovery_mode == "disabled"

# Generated at 2022-06-20 14:12:51.492563
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_message='Test Message'
    test_interpreter_name='Test Interpreter Name'
    test_discovery_mode='Test Discovery Mode'
    error = InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)
    assert error.message == test_message
    assert error.interpreter_name == test_interpreter_name
    assert error.discovery_mode == test_discovery_mode


# Generated at 2022-06-20 14:13:03.546243
# Unit test for function discover_interpreter

# Generated at 2022-06-20 14:13:16.784239
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockActionModule:
        def __init__(self):
            self._discovery_warnings = []


# Generated at 2022-06-20 14:13:19.052121
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('Test message', 'python', 'auto')
    assert repr(exc) == 'Test message'

# Generated at 2022-06-20 14:13:27.619112
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        exception = InterpreterDiscoveryRequiredError("message data", "python", "auto")
        repr_string = repr(exception)
    except Exception as ex:
        repr_string = str(ex.args)
    assert repr_string == "('message data', 'python', 'auto')"

# Generated at 2022-06-20 14:13:35.945110
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required'
    interpreter_discovery_required_error_object = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert interpreter_discovery_required_error_object.message == message
    assert interpreter_discovery_required_error_object.interpreter_name == interpreter_name
    assert interpreter_discovery_required_error_object.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:13:43.750610
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    name = "python"
    mode = "auto_legacy"
    message = "interpreter discovery required"

    obj = InterpreterDiscoveryRequiredError(message, name, mode)

    # object created is of class InterpreterDiscoveryRequiredError
    assert isinstance(obj, InterpreterDiscoveryRequiredError) is True

    # object created has correct message
    assert obj.message == message

    # object created has correct interpreter_name
    assert obj.interpreter_name == name

    # object  created has correct discovery_mode
    assert obj.discovery_mode == mode

    return True

# Generated at 2022-06-20 14:13:51.433518
# Unit test for function discover_interpreter
def test_discover_interpreter():

    import os
    os.environ['ANSIBLE_UNIT_TEST'] = '1'

    # hack to get the unit test running outside of the suite
    import ansible.executor.discovery
    ansible.executor.discovery.platform = None
    ansible.executor.discovery.platform_python_map = None

    import ansible.executor.module_common

    class FakeAction(object):
        def __init__(self):
            self._connection = FakeConnection()
            self._low_level_execute_command = self._low_level_execute_command_impl
            self._discovery_warnings = []

        def _low_level_execute_command_impl(self, *args, **kwargs):
            # FUTURE: handle _low_level_execute_command exceptions too
            res = ansible

# Generated at 2022-06-20 14:14:03.271589
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext

    class MockTask(object):
        def __init__(self, host, name, connection):
            self.host = host
            self.name = name
            self.connection = connection


    class MockConnection(object):
        def __init__(self, host, pipelined):
            self.host = host
            self.transport = 'smart'
            self.has_pipelining = pipelined

    class MockPlaybookContext(object):
        def __init__(self, hosts, pipelined):
            self.hosts = hosts
            self.pipelining = pipelined


# Generated at 2022-06-20 14:14:15.770458
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected = "repr"

    # unsupported mode
    e = InterpreterDiscoveryRequiredError(message="msg", interpreter_name="python", discovery_mode="unsupported")
    actual = e.__repr__()
    # This is a very naive method of validating what __repr__ returns, testing for the class name and errors thrown
    assert "InterpreterDiscoveryRequiredError" in actual
    assert "discovery_mode" in actual
    assert "unsupported" in actual

    # auto mode
    e = InterpreterDiscoveryRequiredError(message="msg", interpreter_name="python", discovery_mode="auto")
    actual = to_native(e.__repr__())
    # This is a very naive method of validating what __repr__ returns, testing for the class name and errors thrown