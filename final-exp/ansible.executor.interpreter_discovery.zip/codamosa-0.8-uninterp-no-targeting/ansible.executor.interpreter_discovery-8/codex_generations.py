

# Generated at 2022-06-20 14:05:08.419112
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'This is the message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.__str__() == message

# Generated at 2022-06-20 14:05:16.588617
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Testing when interpreter name is not available and discovery mode is silent
    interpreter_name_1 = None
    discovery_mode_1 = 'silent'
    message_1 = 'Error message'
    interpreter_error_1 = InterpreterDiscoveryRequiredError(message_1, interpreter_name_1, discovery_mode_1)
    assert interpreter_error_1.__str__() == message_1

    # Testing when interpreter name is not available and discovery mode is not silent
    interpreter_name_2 = None
    discovery_mode_2 = 'not_silent'
    message_2 = 'Error message'
    interpreter_error_2 = InterpreterDiscoveryRequiredError(message_2, interpreter_name_2, discovery_mode_2)
    assert interpreter_error_2.__str__() == message_2

    # Testing when interpreter name

# Generated at 2022-06-20 14:05:19.038389
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError("Test message", "python", "auto")

    assert repr(err) == "Test message"

# Generated at 2022-06-20 14:05:27.044206
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.playbook.play_context import PlayContext

    action = DictDataLoader({})
    task_vars = {}
    display.verbosity = 4
    action._play_context = PlayContext(verbosity=4)

    # FUTURE: add some real-world tests here...

# Generated at 2022-06-20 14:05:30.413977
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(message="Something went wrong", interpreter_name="python", discovery_mode="auto_silent")
    assert str(error) == "Something went wrong"

# Generated at 2022-06-20 14:05:35.618431
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter needs to be discovered'
    if InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode):
        print("Constructor of class InterpreterDiscoveryRequiredError works")
    else:
        print("Constructor of class InterpreterDiscoveryRequiredError failed")

if __name__ == "__main__":
    test_InterpreterDiscoveryRequiredError()

# Generated at 2022-06-20 14:05:41.103547
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict()

    # test that discover_interpreter raises error when unsupported interpreter_name is given
    try:
        discover_interpreter(None, 'not_python', discovery_mode, task_vars)
    except ValueError:
        assert True
    else:
        assert False
    # test that discover_interpreter raises NotImplementedError when an unknown platform is given
    task_vars['ansible_system'] = 'not_linux'
    try:
        discover_interpreter(None, interpreter_name, discovery_mode, task_vars)
    except NotImplementedError:
        assert True
    else:
        assert False

    # test that discover_interpreter raises NotImplementedError when an unknown dist

# Generated at 2022-06-20 14:05:50.293130
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # We test that when we construct an InterpreterDiscoveryRequiredError with an empty message,
    # then we get back a the default message.
    # We expect:
    #   an error message
    #   the name of the interpreter
    #   the discovery mode
    error = InterpreterDiscoveryRequiredError(
        message='',
        interpreter_name='python',
        discovery_mode='auto_legacy'
    )
    msg = str(error)
    assert ("Interpreter Discovery is required but not allowed for this task. "
            "Set interpreter_discovery: true for the task or globally to allow it." in msg)
    assert "interpreter: python" in msg
    assert "discovery mode: auto_legacy" in msg



# Generated at 2022-06-20 14:05:57.685089
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError('foo', 'bar', 'baz')
    except InterpreterDiscoveryRequiredError as exc:
        assert repr(exc) == 'foo'


# Generated at 2022-06-20 14:06:07.880407
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins import module_utils
    class ActionModule(_ActionModule):
        def _execute_module(self, tmp=None, task_vars=None, persist_files=True):
            pass

    class TaskExecutor:
        def __init__(self):
            self.name = None
            self.cur_host = None
            self.action = ActionModule()
            self.action_loader = None
            self.task_vars = None

    class Connection:
        def __init__(self):
            self.has_pipelining = True

    class Host:
        def __init__(self):
            self.name = 'localhost'
            self.vars = {}



# Generated at 2022-06-20 14:06:26.423394
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = C.config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP', variables=task_vars)
    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

# Generated at 2022-06-20 14:06:30.992465
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    discovery_mode = 'auto_legacy'
    interpreter_name = 'python'

    exception = InterpreterDiscoveryRequiredError('testing error', interpreter_name, discovery_mode)

    assert exception
    assert interpreter_name == exception.interpreter_name
    assert discovery_mode == exception.discovery_mode

# Generated at 2022-06-20 14:06:36.475935
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    err = InterpreterDiscoveryRequiredError(u"bla", interpreter_name, discovery_mode)
    repr_err = repr(err)
    assert repr_err == u'bla'

# Generated at 2022-06-20 14:06:39.740352
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert error.message == 'message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto_legacy_silent'
    assert str(error) == 'message'
    assert repr(error) == 'message'


# Generated at 2022-06-20 14:06:41.934487
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "Foo"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)


# Generated at 2022-06-20 14:06:52.669495
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test case 1: valid Python 2.6/2.7 interpreter, with Python 2.7 as default
    action, interpreter_name, discovery_mode, task_vars = None, 'python', 'auto', dict(
        INTERPRETER_PYTHON_DISTRO_MAP={
            'redhat': {
                '5.5': '/usr/bin/python2.6',
                '6.10': '/usr/libexec/platform-python',
                '7.8': '/usr/bin/python2.7',
            },
        },
        INTERPRETER_PYTHON_FALLBACK=['/usr/bin/python2.6', '/usr/bin/python2.7'],
    )

# Generated at 2022-06-20 14:07:05.974718
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Linux cases
    # Ubuntu 14.04 LTS (Trusty Tahr)
    plat_info = {
        "osrelease_content": "NAME=\"Ubuntu\"\nVERSION=\"14.04.1 LTS, Trusty Tahr\"\nID=ubuntu\nID_LIKE=debian\nPRETTY_NAME=\"Ubuntu 14.04.1 LTS\"\nVERSION_ID=\"14.04\"\nHOME_URL=\"http://www.ubuntu.com/\"\nSUPPORT_URL=\"http://help.ubuntu.com/\"\nBUG_REPORT_URL=\"http://bugs.launchpad.net/ubuntu/\"",
        "platform_dist_result": ["Ubuntu", "14.04", "trusty"]
    }
    expected_value = "/usr/bin/python"
    actual_value = discover_interpre

# Generated at 2022-06-20 14:07:11.842384
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError("message", "interpreter", "discovery_mode")
    assert repr(err) == "message"


# Generated at 2022-06-20 14:07:15.371045
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert repr(err) == 'message'

# Generated at 2022-06-20 14:07:17.421941
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        "message",
        "ansible-python-interpreter",
        InterpreterDiscoveryRequiredError.DISCOVERY_MODE_NORMAL,
    )

    assert error.__str__() == error.message


# Generated at 2022-06-20 14:07:45.153806
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():  # type: () -> None
    exception = InterpreterDiscoveryRequiredError("Python not found", "python", discovery_mode="auto")
    assert exception.interpreter_name == "python"
    assert exception.discovery_mode == "auto"

# Generated at 2022-06-20 14:07:48.834285
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'message'
    interpreter_name = 'interpreter_name'
    discovery_mode = 'discovery_mode'
    interpreter_discovery_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(interpreter_discovery_error) == message
    assert repr(interpreter_discovery_error) == message


# Generated at 2022-06-20 14:07:52.531176
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError(message='error message', interpreter_name='python', discovery_mode='force')
    assert repr(exception) == 'error message'


# Generated at 2022-06-20 14:08:00.657594
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError(u'Python interpreter discovery is required', u'python', u'auto')
    assert err.message == u'Python interpreter discovery is required'
    assert err.interpreter_name == u'python'
    assert err.discovery_mode == u'auto'
    assert to_text(err) == u'Python interpreter discovery is required'
    assert to_text(repr(err)) == u'Python interpreter discovery is required'



# Generated at 2022-06-20 14:08:06.836619
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Error thrown from test_InterpreterDiscoveryRequiredError", 'python', 'auto')
    except InterpreterDiscoveryRequiredError as error:
        assert error.message == "Error thrown from test_InterpreterDiscoveryRequiredError"
        assert error.interpreter_name == 'python'
        assert error.discovery_mode == 'auto'

# Generated at 2022-06-20 14:08:16.728996
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.test.test_module_utils.test_discovery import (
        create_mock_action, create_mock_task_vars
    )
    from ansible.executor.discovery import (
        InterpreterDiscoveryRequiredError,
        discover_interpreter
    )
    from ansible.plugins.action.script import ActionModule as ScriptActionModule
    import pytest
    import mock

    # Monkeypatch for pytest
    ScriptActionModule._low_level_execute_command = mock.MagicMock(return_value={'stdout': '', 'stderr': ''})

    mock_action = create_mock_action(script_action=ScriptActionModule)
    mock_action._discovery_warnings = []

# Generated at 2022-06-20 14:08:28.471013
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    class TestException(Exception):
        def __init__(self, message, interpreter_name, discovery_mode):
            super(TestException, self).__init__(message)
            self.interpreter_name = interpreter_name
            self.discovery_mode = discovery_mode

        def __str__(self):
            return self.message

        def __repr__(self):
            return self.message

    # Test the constructor of class InterpreterDiscoveryRequiredError
    msg = "Exception message"
    interpreter_name = "python"
    discovery_mode = "auto"
    err = InterpreterDiscoveryRequiredError(message=msg, interpreter_name=interpreter_name, discovery_mode=discovery_mode)

# Generated at 2022-06-20 14:08:41.391292
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.discovery.python import discover_interpreter

    # Setup up play context
    pc = PlayContext()
    fake_task_vars = dict(
        ansible_connection='local',
        ansible_python_interpreter='/usr/bin/python',
        ansible_host='localhost',
        inventory_hostname='localhost',
    )
    pc._set_task_and_variable_override(fake_task_vars, None, None)

    # Setup up task queue manager

# Generated at 2022-06-20 14:08:45.562565
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = u'Unknown interpreter test'
    interpreter_name = u'python'
    discovery_mode = u'auto'

    obj = InterpreterDiscoveryRequiredError(message=message,
                                            interpreter_name=interpreter_name,
                                            discovery_mode=discovery_mode)

    assert repr(obj) == message

# Generated at 2022-06-20 14:08:50.511476
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    for interpreter_name in ['python', 'ruby']:
        for discovery_mode in ['auto', 'auto_legacy', 'auto_legacy_silent', 'auto_silent']:
            error_msg = ('Python interpreter discovery required for interpreter %s and discovery mode %s. '
                         'See https://docs.ansible.com/ansible/latest/reference_appendices/interpreter_discovery.html '
                         'for more information') % (interpreter_name, discovery_mode)
            error = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
            assert error.__str__() == error_msg

# Generated at 2022-06-20 14:09:42.068946
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "error"
    interpreter_name = "python"
    discovery_mode = "auto"

    obj = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert obj.message == msg
    assert obj.interpreter_name == interpreter_name
    assert obj.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:09:42.513966
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-20 14:09:43.961032
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert to_text(e) == "message"


# Generated at 2022-06-20 14:09:45.818043
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError
    except InterpreterDiscoveryRequiredError as e:
        assert isinstance(e, InterpreterDiscoveryRequiredError)


# Generated at 2022-06-20 14:09:49.317330
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError(
        'message',
        interpreter_name='python',
        discovery_mode='auto')
    assert str(e) == 'message'

# Generated at 2022-06-20 14:10:00.608512
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts import Facts
    import ansible.executor.discovery as discovery

    test_host = 'localhost'

    # FUTURE: create a test inventory section for localhost (as a fake 'group')?
    test_vars = {'inventory_hostname': test_host,
                 'inventory_groupname': 'localhost-group',
                 'group_names': ['localhost-group'],
                 'groups': {'localhost-group': [test_host]}}

    # TODO: should we test all discovery modes?
    test_action = InterpreterDiscoveryAction(None, 'auto_silent', facts=Facts(task_vars=test_vars))
    res = discover_interpreter(test_action, 'python', 'auto_silent', test_vars)

# Generated at 2022-06-20 14:10:08.033182
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with InterpreterDiscoveryRequiredError('message', 'interpreter', 'auto_legacy') as e:
        assert e.interpreter_name == 'interpreter' and e.discovery_mode == 'auto_legacy'

# Generated at 2022-06-20 14:10:13.596322
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    class_object = InterpreterDiscoveryRequiredError('test message', 'test interpreter', 'test discovery mode')
    assert class_object.message == 'test message'
    assert class_object.interpreter_name == 'test interpreter'
    assert class_object.discovery_mode == 'test discovery mode'



# Generated at 2022-06-20 14:10:24.540487
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile

    current_directory = os.path.dirname(os.path.realpath(__file__))

    # create a temporary file to store the test data
    fd, temp_test_data_file = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-20 14:10:32.222402
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import json
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.distro import LinuxDistribution
    from ansible.module_utils.compat.version import LooseVersion

    def _get_linux_distro(platform_info):
        dist_result = platform_info.get('platform_dist_result', [])

        if len(dist_result) == 3 and any(dist_result):
            return dist_result[0], dist_result[1]

        osrelease_content = platform_info.get('osrelease_content')

        if not osrelease_content:
            return u'', u''

        osr = LinuxDistribution._parse_os_release_content(osrelease_content)

        return osr.get('id', u''), osr.get

# Generated at 2022-06-20 14:12:06.834473
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = dict()
    discover_interpreter(action, interpreter_name, discovery_mode, task_vars)



# Generated at 2022-06-20 14:12:19.184319
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # just test the version matching code here
    version_map = {
        u'8': u'/usr/bin/python',
        u'9.04': u'/usr/bin/python',
        u'10.04': u'/usr/bin/python2.6',
        u'12.04': u'/usr/bin/python2.7',
        u'14.04': u'/usr/bin/python3.4'
    }

    assert u'/usr/bin/python' == _version_fuzzy_match(u'8', version_map)
    assert u'/usr/bin/python' == _version_fuzzy_match(u'9.04', version_map)

# Generated at 2022-06-20 14:12:27.563137
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import _load_params, _task_fields
    from ansible.executor.action_write_free import ActionModuleWriteFree
    from ansible.executor.play_context import PlayContext

    class _connection_object(object):
        def __init__(self):
            self.has_pipelining = True

    class _task_object(object):
        def __init__(self):
            self.action = 'command'
            self.args = {}
            self.connection = _connection_object()
            self.environment = {}
            self.become = False
            self.become_user = None

# Generated at 2022-06-20 14:12:33.174269
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = "Interpreter 'python' discovery was required but is not available. Discovery mode: 'auto_legacy_silent'"
    name = "python"
    mode = "auto_legacy_silent"
    assert InterpreterDiscoveryRequiredError(error, name, mode) == error

# Generated at 2022-06-20 14:12:44.675204
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: Might be better to use a fixture
    # Mocking ansible.constants.config
    # We try to return some valid data for the unit tests
    # FIXME: do we need more mocking here for C.config?
    class MockConfig:

        def get_config_value(self, s, variables=None):
            if s == 'INTERPRETER_PYTHON_DISTRO_MAP':
                return {"centos": {"4": "python", "5": "python", "6": "python", "7": "python"}}
            elif s == 'INTERPRETER_PYTHON_FALLBACK':
                return ["python"]
    C.config = MockConfig()
    # Mocking task_vars
    task_vars = {'inventory_hostname': 'fake_host'}
    # mock

# Generated at 2022-06-20 14:12:51.033129
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_msg = u'Testing repr for InterpreterDiscoveryRequiredError'
    test_interpreter_name = u'Interpreter_Name'
    test_discovery_mode = 'discovery_mode'

    result = repr(InterpreterDiscoveryRequiredError(test_msg, test_interpreter_name, test_discovery_mode))
    assert result == test_msg

# Generated at 2022-06-20 14:12:58.965145
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    discovery_mode = "auto_legacy"
    interpreter_name = "python"
    message = "Interpreter discovery requested, but python interpreter not found."
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.message == message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode
    assert str(exception) == message

# Generated at 2022-06-20 14:13:04.158231
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    fname = "test_InterpreterDiscoveryRequiredError___repr__"
    msg = "This is an error message"
    interpreter = "python"
    discovery_mode = "legacy"
    error = InterpreterDiscoveryRequiredError(msg, interpreter, discovery_mode)
    assert(msg == error.__repr__())
    display.display(msg="%s: PASSED" % fname)


# Generated at 2022-06-20 14:13:10.050940
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'Failed to discover interpreter for foo'
    foo = 'foo'
    bar = 'bar'
    try:
        raise InterpreterDiscoveryRequiredError(msg, foo, bar)
    except InterpreterDiscoveryRequiredError as e:
        assert repr(e) == msg



# Generated at 2022-06-20 14:13:21.138278
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    import mock
    test_dir = os.path.join(os.path.dirname(__file__), "files")
    sys.path.insert(0, test_dir)

    from ansible.executor.discovery import discover_interpreter
    from ansible.executor.action_plugins.script import ActionModule as ScriptActionModule
