

# Generated at 2022-06-20 14:05:14.134121
# Unit test for function discover_interpreter
def test_discover_interpreter():
    version_map = {
        'debian': {
            '7': ['/usr/bin/python'],
            '8': ['/usr/bin/python']
        },
        'centos': {
            '7': ['/usr/bin/python'],
            '6': ['/usr/bin/python']
        },
    }

    def _test_case(desc, platforms, expected, expected_warning_count=0):
        for platform, version in platforms.items():
            task_vars = {
                'inventory_hostname': 'test_host',
                'INTERPRETER_PYTHON_DISTRO_MAP': version_map,
            }
            interpreter_name = 'python'
            display.color = False

# Generated at 2022-06-20 14:05:18.545711
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    #Arrange
    error = InterpreterDiscoveryRequiredError(message = 'test_message', interpreter_name = 'python', discovery_mode = 'test_mode')

    #Act
    result = error.__repr__()
    #Assert
    assert result == 'test_message'

# Generated at 2022-06-20 14:05:23.217043
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('test message', 'test_interpreter', 'test_discovery_mode')
    assert error.__str__() == error.message

# Generated at 2022-06-20 14:05:28.533429
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('message', 'py', 'auto')
    assert error.interpreter_name == 'py'
    assert error.discovery_mode == 'auto'

    # check str method
    assert str(error) == 'message'
    assert repr(error) == 'message'


# Generated at 2022-06-20 14:05:32.568535
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("message", "python","auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == "message"
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'

# Generated at 2022-06-20 14:05:35.940886
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with InterpreterDiscoveryRequiredError("message",
                                           "interpreter_name",
                                           "discovery_mode") as e:
        assert e.message == "message"
        assert e.interpreter_name == "interpreter_name"
        assert e.discovery_mode == "discovery_mode"

# Generated at 2022-06-20 14:05:41.517885
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    test_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert isinstance(test_error.__str__(), str)

# Generated at 2022-06-20 14:05:45.369585
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    instance = InterpreterDiscoveryRequiredError(
        message='message',
        interpreter_name='python3',
        discovery_mode='auto'
    )
    assert str(instance) == "message"

# Generated at 2022-06-20 14:05:59.694500
# Unit test for function discover_interpreter
def test_discover_interpreter():
    basedefs = dict(
        task_vars=dict(
            inventory_hostname='localhost',
            ansible_python_interpreter='/usr/bin/python',
            ansible_connection='local'
        ),
        interpreter_name='python',
        discovery_mode='auto',
        action=None
    )

    import ansible.plugins.action.normal
    action_module = ansible.plugins.action.normal.ActionModule(**basedefs)

    # Monkeypatch action.
    # TODO: make this proper testing, use proper action object

# Generated at 2022-06-20 14:06:02.894738
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert 'message' == str(exception)

# Generated at 2022-06-20 14:06:14.526401
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'pypy3.6'
    discovery_mode = 'auto_legacy'
    msg = 'interpreter discovery required'
    ex = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    print('msg: %s' % ex.__repr__())
    assert ex.__repr__() == msg


# Generated at 2022-06-20 14:06:16.244992
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("Error message", "python", "auto")
    assert ("Error message") == error.__str__()

# Generated at 2022-06-20 14:06:22.603328
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(message='test', interpreter_name='python', discovery_mode='auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'test'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'

# Generated at 2022-06-20 14:06:33.012530
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.executor.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    import os
    import sys

    class TestInterpreter(ActionBase):
        TRANSFERS_FILES = False

        def _execute_module(self, tmp=None, task_vars=None, **kwargs):
            pass


# Generated at 2022-06-20 14:06:36.475425
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    klass = InterpreterDiscoveryRequiredError("message", "python", "auto")
    repr(klass)


# Generated at 2022-06-20 14:06:43.225338
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    message = 'Interpreter Discovery Unavailable'
    interpreter_name = 'python'
    discovery_mode = 'auto'

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == message
        assert ex.interpreter_name == interpreter_name
        assert ex.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:06:46.596508
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    x = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert "message" in str(x)
    assert "python" in str(x)
    assert "auto" in str(x)

# Generated at 2022-06-20 14:06:55.966232
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = u'Interpreter discovery required'
    interpreter_name = u'python'
    discovery_mode = u'auto'
    exc = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert exc.message == msg
    assert exc.interpreter_name == interpreter_name
    assert exc.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:07:01.376549
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_InterpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError(
        message='test message', interpreter_name='python', discovery_mode='auto')
    assert test_InterpreterDiscoveryRequiredError.__repr__() == 'test message'


# Generated at 2022-06-20 14:07:07.949055
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Discover python 2 interpreter
    test_vars = dict()
    assert discover_interpreter('', 'python', 'auto_legacy_silent', test_vars) == '/usr/bin/python'

    # Discover python 3 interpreter
    test_vars['ansible_python_interpreter'] = '/usr/bin/python3'
    assert discover_interpreter('', 'python', 'auto_legacy_silent', test_vars) == '/usr/bin/python3'

# Generated at 2022-06-20 14:07:26.101275
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    #tests if exception is raised
    error = InterpreterDiscoveryRequiredError("test_message", "test interpreter", "test_discovery_mode")

    assert error.message == "test_message"
    assert error.interpreter_name == "test interpreter"
    assert error.discovery_mode == "test_discovery_mode"

    #tests if repr return the string message
    assert repr(error) == "test_message"

    #tests if str return the string message
    assert str(error) == "test_message"

# Generated at 2022-06-20 14:07:32.566774
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('error message', 'python', 'auto')
    assert str(e) == 'error message'

# Generated at 2022-06-20 14:07:42.255970
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_exception = InterpreterDiscoveryRequiredError(
        message='test', interpreter_name='test', discovery_mode='test')
    # assert error_exception.message == error_exception.__str__()
    # assert error_exception.message == str(error_exception)
    # assert error_exception.message == repr(error_exception)
    assert error_exception.message == 'test'
    assert error_exception.interpreter_name == 'test'
    assert error_exception.discovery_mode == 'test'
    assert error_exception.__repr__() == 'test'


# Generated at 2022-06-20 14:07:48.290023
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_msg = "I am so tired of these discovery errors"
    error = InterpreterDiscoveryRequiredError(error_msg, "python", "auto_silent")
    assert error.message == error_msg
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto_silent"

# Generated at 2022-06-20 14:07:49.561707
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert str(error) == 'message'
# === END ===

# Generated at 2022-06-20 14:07:53.025331
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    instance = InterpreterDiscoveryRequiredError('this is an error', 'python', 'auto')
    assert isinstance(str(instance), str)


# Generated at 2022-06-20 14:07:53.752409
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    pass

# Generated at 2022-06-20 14:07:57.216603
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_err = InterpreterDiscoveryRequiredError('test message', 'python', 'auto_legacy')
    assert test_err.__str__() == 'test message'

# Generated at 2022-06-20 14:08:09.034544
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six import iteritems
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create a test inventory
    inventory = InventoryManager(loader=None, sources=['localhost,'])

    # Create variables
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Create a test playbook
    class TestActionModule(ActionBase):
        """Test action module"""
        def run(self, tmp):
            """Test run method"""
            return dict(failed=False, changed=False)


# Generated at 2022-06-20 14:08:18.914924
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    task_vars = dict()

    # Ubunutu 18.04
    assert discover_interpreter(action, 'python', 'auto_legacy_silent',
                                dict(inventory_hostname='host1',
                                     ansible_facts=dict(os_family='Linux',
                                                        ansible_distribution='Ubuntu',
                                                        ansible_distribution_version='18.04'),
                                     ansible_python_version='2.7.15rc1')) == '/usr/bin/python'


# Generated at 2022-06-20 14:08:47.370073
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required for {} using discovery mode {}'.format(interpreter_name, discovery_mode)
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.interpreter_name == interpreter_name
    assert err.discovery_mode == discovery_mode
    assert str(err) == message

# Generated at 2022-06-20 14:08:49.030096
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    InterpreterDiscoveryRequiredError('message', 'python', 'auto')


# Generated at 2022-06-20 14:09:02.365034
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.loader import discovery_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.discovery import _get_task_result
    from ansible.executor.task_executor import TaskExecutor
    from ansible.module_utils.connection import Connection, ConnectionError
    from ansible.module_utils.remote_management.interpreter_discovery import InterpreterDiscoveryRequiredError
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_str


# Generated at 2022-06-20 14:09:06.532444
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError("test message", "test interpreter name", "test discovery mode")
    assert (e.message == "test message")
    assert (e.interpreter_name == "test interpreter name")
    assert (e.discovery_mode == "test discovery mode")
    assert (str(e) == "test message")


# Generated at 2022-06-20 14:09:07.699490
# Unit test for function discover_interpreter
def test_discover_interpreter():
    #TODO: Add test
    pass

# Generated at 2022-06-20 14:09:14.053689
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError(message='test-message', interpreter_name='test-interpreter-name',
                                          discovery_mode='test-discovery-mode')
    assert e.__repr__() == 'test-message'
    assert str(e) == 'test-message'

# Generated at 2022-06-20 14:09:26.130675
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.vars import VariableManager

    module_args = {
        '_ansible_no_log': False,
        '_ansible_verbosity': 9,
        '_ansible_syslog_facility': 'LOG_USER',
        '_ansible_debug': True,
        '_ansible_check_mode': False,
        '_ansible_diff': False,
        '_ansible_remote_tmp': '/tmp/.ansible/tmp/ansible-tmp-1605857610.36-260554534837541/',
        '_ansible_keep_remote_files': False,
        '_ansible_search_paths': None
    }

    module = MockModule(module_args=module_args)
   

# Generated at 2022-06-20 14:09:31.154933
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError(
        message="test message",
        interpreter_name="python",
        discovery_mode="auto")
    assert exception.__repr__() == "test message"


# Generated at 2022-06-20 14:09:42.130503
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    x = InterpreterDiscoveryRequiredError(message='Error: message: [msg1]', interpreter_name='python', discovery_mode='auto')
    assert repr(x) == 'Error: message: [msg1]'
    x = InterpreterDiscoveryRequiredError(message='Error: message: [msg2]', interpreter_name='python3', discovery_mode='auto_legacy')
    assert repr(x) == 'Error: message: [msg2]'
    x = InterpreterDiscoveryRequiredError(message='Error: message: [msg3]', interpreter_name='python', discovery_mode='auto_silent')
    assert repr(x) == 'Error: message: [msg3]'

# Generated at 2022-06-20 14:09:43.878308
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ex = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert "message" == ex.__repr__()


# Generated at 2022-06-20 14:10:43.910171
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    x = InterpreterDiscoveryRequiredError("sample message", "sample_interpreter_name", "sample_discovery_mode")

    assert x.__str__() == "sample message"

# Generated at 2022-06-20 14:10:48.736740
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_message = 'interpreter discovery required'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert repr(error) == error_message


# Generated at 2022-06-20 14:10:53.593710
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'msg'
    interpreter_name = 'python'
    discovery_mode = 'manual'
    e = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert(repr(e) == msg)


# Generated at 2022-06-20 14:11:01.807905
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "message"
    interpreter_name = "python"
    discovery_mode = "legacy_silent"
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_discovery_required_error.message == "message"
    assert interpreter_discovery_required_error.interpreter_name == "python"
    assert interpreter_discovery_required_error.discovery_mode == "legacy_silent"



# Generated at 2022-06-20 14:11:08.349000
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Python interpreter discovery required but discovery failed.'

    # Create InterpreterDiscoveryRequiredError object
    exp = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    exp_repr = repr(exp)

    assert exp_repr == message

# Generated at 2022-06-20 14:11:12.175050
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Setup test
    testcase = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    # Perform the test
    actual_result = str(testcase)
    # Verify the results
    assert actual_result == 'message'


# Generated at 2022-06-20 14:11:18.893767
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError(
        "test_message",
        "test_interpreter_name",
        "test discovery mode")

    assert isinstance(exception, Exception)

    assert exception.message == "test_message"
    assert exception.interpreter_name == "test_interpreter_name"
    assert exception.discovery_mode == "test discovery mode"

    assert exception.__str__() == "test_message"
    assert exception.__repr__() == "test_message"

# Generated at 2022-06-20 14:11:31.016311
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest

    class TestDiscovery(unittest.TestCase):

        def _send_output(self, command, python_path):
            if command.startswith('echo PLATFORM'):
                return 'PLATFORM\nLinux'
            if command.startswith('uname'):
                return 'Linux'
            if command.startswith('command -v'):
                return python_path

        def _send_output_multiple(self, command, python_path):
            if command.startswith('echo PLATFORM'):
                return 'PLATFORM\nLinux'
            if command.startswith('uname'):
                return 'Linux'
            if command.startswith('command -v'):
                return '\n'.join([interpreter for interpreter in python_path])


# Generated at 2022-06-20 14:11:36.459739
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = "This is an error message"
    interpreter_name = "python"
    discovery_mode = "auto"

    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)

    assert error.message == error_message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

    # Check whether __str__ is returning error_message
    assert str(error) == error_message

# Generated at 2022-06-20 14:11:42.469955
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = 'Some error message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    exception = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert exception.__str__() == error_message

# Generated at 2022-06-20 14:13:33.212763
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("test message", "python", "auto_legacy")
    assert error.__repr__() == "test message"


# Generated at 2022-06-20 14:13:37.694350
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    instance = InterpreterDiscoveryRequiredError(u'hello', u'python', u'auto')
    result = instance.__str__()
    assert type(result) is str
    assert result == u'hello'


# Generated at 2022-06-20 14:13:40.453747
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    failed_msg = 'Unable to run python interpreter discovery using discovery_mode auto_legacy_silent'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    e = InterpreterDiscoveryRequiredError(failed_msg, interpreter_name, discovery_mode)
    assert e.__repr__() == 'Unable to run python interpreter discovery using discovery_mode auto_legacy_silent'
    assert e.__repr__() == e.__str__()

# Generated at 2022-06-20 14:13:43.829656
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "message"
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.__repr__() == ex.__str__()


# Generated at 2022-06-20 14:13:48.346577
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    #Check that InterpreterDiscoveryRequiredError is raised when discovery mode is empty
    discovery_mode = ''
    interpreter_name = 'python'
    message = u'discovery_mode required for interpreter %s' % interpreter_name
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode
    assert ex.message == message

# Generated at 2022-06-20 14:13:56.604214
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'Interpreter discovery required due to interpreter_python config value of auto'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    test_err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert test_err.__str__() == message
    assert test_err.interpreter_name == interpreter_name
    assert test_err.discovery_mode == discovery_mode
    assert test_err.__repr__() == message

# Generated at 2022-06-20 14:14:06.071831
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.module_common import TaskResult
    from ansible.module_utils.remote_management import Chroot, Connection
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):

        def run(self, tmp=None, task_vars=None):
            return TaskResult({}, rc=0)

    class TestInterpreter(object):
        def __init__(self, interpreter_name=None, discovery_mode=None, task_vars=None):
            self.interpreter_name = interpreter_name
            self.discovery_mode = discovery_mode
            self.task_vars = task_vars


# Generated at 2022-06-20 14:14:13.429085
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    x = InterpreterDiscoveryRequiredError(
        message='error1: You need to run interpreter_discovery mode first on this host, for example with the setup module using ansible.cfg .',
        interpreter_name='python',
        discovery_mode='auto_silent')
    assert repr(x) == 'error1: You need to run interpreter_discovery mode first on this host, for example with the setup module using ansible.cfg .'

# Generated at 2022-06-20 14:14:24.301608
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    class MyActionModule(ActionBase):
        def __init__(self):
            super(MyActionModule, self).__init__()

        def _low_level_execute_command(self, command, sudoable=True, in_data=None, executable=None,
                                       persist_files=False,
                                       binary_data=False, path_prefix=None, environ_update=None,
                                       umask=None):
            return {'rc': 0, 'stdout': command}

        def run(self, tmp=None, task_vars=None):
            interpreter = discover_interpreter(self, 'python', 'auto', task_vars)
            return {'failed': False, 'changed': True, 'interpreter': interpreter}

    action_module = MyAction

# Generated at 2022-06-20 14:14:28.410473
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("test message",
                                                "test interpreter",
                                                "test discovery mode")
    except InterpreterDiscoveryRequiredError as ex:
        assert to_text(ex.message) == "test message"
        assert ex.interpreter_name == "test interpreter"
        assert ex.discovery_mode == "test discovery mode"
        assert repr(ex) == "test message"

