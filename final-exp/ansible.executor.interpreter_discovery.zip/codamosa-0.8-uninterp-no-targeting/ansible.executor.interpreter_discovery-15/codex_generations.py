

# Generated at 2022-06-20 14:05:14.305817
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_message = 'Interpreter discovery is required.'
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto'
    interpreter_discovery_error = InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)
    assert interpreter_discovery_error.message == test_message
    assert interpreter_discovery_error.interpreter_name == test_interpreter_name
    assert interpreter_discovery_error.discovery_mode == test_discovery_mode
    assert str(interpreter_discovery_error) == test_message

# Generated at 2022-06-20 14:05:16.462378
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError("Foo", "Bar", "Baz")
    assert err.__str__() == "Foo"

# Generated at 2022-06-20 14:05:17.657767
# Unit test for function discover_interpreter
def test_discover_interpreter():
	#TODO
	return

# Generated at 2022-06-20 14:05:20.988159
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    distro_without_discovery_support = InterpreterDiscoveryRequiredError(message='Message',
                                                                         interpreter_name='python',
                                                                         discovery_mode='auto_legacy')
    assert distro_without_discovery_support.__repr__() == 'Message'


# Generated at 2022-06-20 14:05:28.807160
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('Interpreter Discovery Required', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == 'Interpreter Discovery Required'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'
        assert repr(e) == 'Interpreter Discovery Required'

# Unit tests for the discover_interpreter function

# Generated at 2022-06-20 14:05:32.869611
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'Interpreter discovery required'
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(ex) == message
    assert ex.__repr__() == message

# Generated at 2022-06-20 14:05:40.665166
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import platform
    import random

    def _get_random_python_list():
        # mocks up a set of python interpreters from which we can test finding select one
        # note that these might not all actually be on your system
        python_list = ['/usr/bin/python', '/usr/bin/python2.4', '/usr/bin/python2.7', '/usr/bin/python3.4']

        # randomly pick & return 1 or more of the above
        # TODO: this does not handle case where there are no matches
        return [p for i, p in enumerate(python_list) if random.getrandbits(1) or i == len(python_list) - 1]

    def test_one(host_name, action, interpreter_name, discovery_mode, task_vars, expected_result):
        display.verb

# Generated at 2022-06-20 14:05:45.817434
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Setup test
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'This is a message'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    expected = message
    # Perform test
    actual = str(e)
    # Verify
    assert actual == expected

# Generated at 2022-06-20 14:05:49.737690
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('error message', 'myinterpreter', 'mode')
    assert error.__str__() == 'error message'


# Generated at 2022-06-20 14:05:53.551104
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert repr(exc) == "message"
    assert str(exc) == "message"
    assert exc.interpreter_name == "interpreter_name"
    assert exc.discovery_mode == "discovery_mode"

# Generated at 2022-06-20 14:06:04.753625
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError('msg', 'interpreter name', 'discovery mode')
    assert e.__str__() == 'msg'
    assert str(e) == 'msg'

# Generated at 2022-06-20 14:06:10.026707
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    msg = "Python 2.6 detected, but Ansible requires Python >= 2.7"
    discovery_mode = "auto_legacy_silent"
    exception = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert msg in str(exception)

# Generated at 2022-06-20 14:06:13.564662
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = "Msg %s" % discovery_mode
    idre = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert idre.__repr__() == message

# Generated at 2022-06-20 14:06:18.262835
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Python interpreter discovery required'
    ier = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ier.__str__() == message

# Generated at 2022-06-20 14:06:22.388338
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError(message="message", interpreter_name="python", discovery_mode="auto")
    result = exception.__repr__()
    assert result == 'message'


# Generated at 2022-06-20 14:06:28.344974
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'Message'
    interp = 'Python'
    mode = 'auto_legacy_silent'
    x = InterpreterDiscoveryRequiredError(msg, interp, mode)
    assert(to_native(repr(x)) == msg), "repr(x) = '%s' should be '%s'" % \
            (to_native(repr(x)), msg)

# Generated at 2022-06-20 14:06:31.120812
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    a = InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python', discovery_mode='auto')
    assert a.__repr__() == a.message

# Generated at 2022-06-20 14:06:38.682829
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Tests the case:
    #   message: expected
    #   interpreter_name: python3
    #   discovery_mode: auto
    # Expected result:
    #   expected
    expected = None
    interpreter_name = 'python3'
    discovery_mode = 'auto'
    assert repr(InterpreterDiscoveryRequiredError(expected, interpreter_name, discovery_mode)) == expected


# Generated at 2022-06-20 14:06:45.271210
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    my_error = InterpreterDiscoveryRequiredError(
        message='test message',
        interpreter_name='python',
        discovery_mode='auto_legacy_silent'
    )

    assert my_error.message == 'test message'
    assert my_error.interpreter_name == 'python'
    assert my_error.discovery_mode == 'auto_legacy_silent'



# Generated at 2022-06-20 14:06:52.630039
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("Testing discover_interpreter")
    assert discover_interpreter(None, "python", "auto", None) == "/usr/bin/python"
    assert discover_interpreter(None, "python", "auto_legacy", None) == "/usr/bin/python"
    assert discover_interpreter(None, "python", "auto_silent", None) == "/usr/bin/python"
    assert discover_interpreter(None, "python", "auto_legacy_silent", None) == "/usr/bin/python"

test_discover_interpreter()

# Generated at 2022-06-20 14:07:08.391039
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    ex = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert repr(ex).startswith(ex.message)
    assert 'python' in repr(ex)
    assert 'auto_legacy_silent' in repr(ex)

# Generated at 2022-06-20 14:07:15.942264
# Unit test for function discover_interpreter
def test_discover_interpreter():
    fake_runner = type('FakeRunner', (), {'_low_level_execute_command': lambda *args, **kwargs: {}})
    fake_action = type('FakeAction', (), {'_low_level_execute_command': lambda *args, **kwargs: {}})
    action = fake_action()
    action._connection = fake_runner()
    action._connection.has_pipelining = True

    task_vars = {
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_python_version': {'full': '2.7.6', 'major': 2, 'minor': 7, 'patchlevel': 6}
    }

    # Test discovery mode silent
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    version = Lo

# Generated at 2022-06-20 14:07:28.995035
# Unit test for function discover_interpreter

# Generated at 2022-06-20 14:07:30.770603
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('foo', 'bar', 'baz')
    assert repr(exc) == 'foo'

# Generated at 2022-06-20 14:07:43.181022
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.network.netcli import Command
    import ansible.module_utils.six as six

    test_action = Command()
    test_action._connection = Command()
    test_action._connection.has_pipelining = True

    # test with platform_dist_result first
    test_action._low_level_execute_command = lambda command, sudoable, in_data=six.b(''): {'stdout': six.b(
        'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'), 'stderr': six.b('')}

# Generated at 2022-06-20 14:07:54.641595
# Unit test for function discover_interpreter
def test_discover_interpreter():
    with open('./test/unit/executor/interpreter_discovery_test.py', 'r') as file_f:
        python_target_script = file_f.read()
        assert (python_target_script == pkgutil.get_data('ansible.executor.discovery', 'python_target.py'))

    result = discover_interpreter(action="", interpreter_name='python', discovery_mode='auto_legacy', task_vars={})
    assert(result == "/usr/bin/python")

    result = discover_interpreter(action="", interpreter_name='python', discovery_mode='auto_legacy',
                                  task_vars={'test-interpreter_name': 'python'})
    assert(result == "/usr/bin/python")

    result = discover_interpreter

# Generated at 2022-06-20 14:07:57.414830
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'test_message'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == exception.__str__()

# Generated at 2022-06-20 14:07:59.785118
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    assert not exc.__repr__()

# Generated at 2022-06-20 14:08:10.710419
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # NOTE: This is a unit test to support the interpreter auto-discovery feature, as implemented in
    # TODO: link to unit tests in github?
    action = None
    if action is None:
        raise ValueError('You need to provide an action')
    interpreter_name = 'python'
    # Note: None is a special value for legacy fallback behavior
    discovery_mode = 'auto_legacy'
    task_vars = {}

    # Load the platform python map from the test json fixture
    platform_python_map = json.loads(pkgutil.get_data('ansible.executor.discovery', 'platform_python_fixture.json'))
    task_vars['ansible_config'] = {}
    task_vars['ansible_config']['INTERPRETER_PYTHON_DISTRO_MAP']

# Generated at 2022-06-20 14:08:20.276809
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TaskVars(object):
        def __init__(self, data):
            self._data = data

        def get(self, key, other=None):
            return self._data.get(key, other)

    class Action(object):
        def __init__(self):
            self._discovery_warnings = []

        def get_discovery_warnings(self):
            return self._discovery_warnings

    def _low_level_execute_command(self, raw_command, sudoable=True, in_data=None):
        res = dict(
            rc=0,
            stdout='',
            stderr='',
            stdin='',
        )
        res['stdout'] = self._data.get('_execute_output', 'echo _execute_output not defined')

# Generated at 2022-06-20 14:08:39.436748
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(u'failure message', u'python', u'auto')


# Generated at 2022-06-20 14:08:43.265380
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_InterpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    result = test_InterpreterDiscoveryRequiredError.__repr__()
    assert result == "message"

# Generated at 2022-06-20 14:08:45.992134
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('This should have been caught', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as exc:
        assert exc.__class__.__name__ == 'InterpreterDiscoveryRequiredError'

# Generated at 2022-06-20 14:08:48.326776
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError(
        u'Python interpreter discovery required',
        u'python',
        u'default'
    )
    assert u'Python interpreter discovery required' == exc.__repr__()


# Generated at 2022-06-20 14:08:55.100571
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        interpreter_path = discover_interpreter(action=None, interpreter_name='python', discovery_mode='auto_legacy_silent',
                                                task_vars={})
    except InterpreterDiscoveryRequiredError as e:
        interpreter_path = e.interpreter_name
    assert interpreter_path == 'python'

# Generated at 2022-06-20 14:09:05.845715
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    from ansible.tests.mock.conn_loader import ConnectionLoader

    from ansible.vars.manager import VariableManager

    display = Display()
    display.verbosity = 20

    ################################################################################################
    # Testing when discover_interpreter returns None (no interpreters found)
    ################################################################################################
    action_plugin = action_loader.get('shell', class_only=True)
    variable_manager = VariableManager()
    loader = ConnectionLoader('ansible.plugins.connection', variable_manager)
    connection = loader.get('local')

    c = PlayContext()
    c._set_connection('local')
    action_plugin._connection = connection
    connection._shell.has_p

# Generated at 2022-06-20 14:09:11.985870
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    with pytest.raises(InterpreterDiscoveryRequiredError) as error:
        raise InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert str(error.value) == 'message'
    assert repr(error.value) == 'message'

# Generated at 2022-06-20 14:09:22.414150
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError(
        message='the interpreter discovery method is not specified and cannot '
                'be deduced from the interpreter name. Please set the '
                '\'interpreter_discovery_mode\' parameter to one of the '
                'allowed values for this action.',
        interpreter_name='python',
        discovery_mode=None
    )
    assert str(e) == \
        'the interpreter discovery method is not specified and cannot be deduced from the interpreter name. ' \
        'Please set the \'interpreter_discovery_mode\' parameter to one of the allowed values for this action.'

# Generated at 2022-06-20 14:09:24.447138
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("Error message", "interp", "auto")
    assert error.__str__() == "Error message"

# Generated at 2022-06-20 14:09:27.731960
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(message="Testing Error", interpreter_name="python", discovery_mode="auto")
    assert str(error) == "Testing Error", "Incorrect error message"
    assert error.interpreter_name == "python", "Incorrect interpreter name"
    assert error.discovery_mode == "auto", "Incorrect discovery mode"

# Generated at 2022-06-20 14:09:48.899859
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(message='An error occurred', interpreter_name='python', discovery_mode='fallback')
    assert str(error) == 'An error occurred'



# Generated at 2022-06-20 14:09:59.335802
# Unit test for function discover_interpreter
def test_discover_interpreter():
    ''' test for discover_interpreter function '''

    try:
        from ansible.plugins.action.ping import ActionModule
    except ImportError:
        from ansible.plugins.action import ping

        ActionModule = ping.ActionModule

    task_vars = {}
    action_module = ActionModule(connection=None, task_vars=task_vars, runner_queue=None)

    try:
        discover_interpreter(action_module, 'python', 'auto', task_vars)
    except InterpreterDiscoveryRequiredError:
        pass
    except Exception as ex:
        raise AssertionError(u"Unexpected exception from discover_interpreter function: " + to_text(ex))

# Generated at 2022-06-20 14:10:09.952466
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Ensures that the string representation of this exception is
    # what we expect it to be.
    err = InterpreterDiscoveryRequiredError(
        message='The following error occurred:',
        interpreter_name='python',
        discovery_mode='auto_legacy_silent'
    )
    assert str(err) == 'The following error occurred:', \
        '__str__ not returning expected representation of exception'

# Generated at 2022-06-20 14:10:21.073703
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction():
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            res = dict(stdout=command, stderr=None)
            # Simplest case, only /usr/bin/python found
            if command == "command -v 'python'":
                res['stdout'] = res['stdout'] + '\n/usr/bin/python'
            return res

    test_action = MockAction()
    # Simplest case, only /usr/bin/python found
    res = discover_interpreter(test_action, 'python', 'auto_silent', None)
    assert res == '/usr/bin/python'

    # More complex case
    res = discover_inter

# Generated at 2022-06-20 14:10:25.832956
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_message = "error message"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert str(error) == "error message"


# Generated at 2022-06-20 14:10:35.764019
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_message = "TEST_EXCEPTION"
    test_interpreter_name = "python"
    test_discovery_mode = "auto"
    test_obj = InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)
    assert test_obj.message == test_message, "Error message is unexpected"
    assert test_obj.interpreter_name == test_interpreter_name, "Interpreter name is unexpected"
    assert test_obj.discovery_mode == test_discovery_mode, "Discovery mode is unexpected"

# Generated at 2022-06-20 14:10:46.553285
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    class MockActionModule:
        def __init__(self):
            self._low_level_execute_command_failures = 0
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd.startswith('command -v ') and self._low_level_execute_command_failures > 0:
                self._low_level_execute_command_failures -= 1
                return {'stdout': ''}


# Generated at 2022-06-20 14:10:49.383350
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert 'message' == obj.__repr__()



# Generated at 2022-06-20 14:10:53.778524
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter not found'
    exc = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(exc) == message

# Generated at 2022-06-20 14:11:01.648854
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = None
    message = "MESSAGE_FOR_TEST"
    interpreter_name = "INTERPRETER_NAME_FOR_TEST"
    discovery_mode = "DISCOVERY_MODE_FOR_TEST"

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        exception = e

    assert(str(exception) == message)




# Generated at 2022-06-20 14:11:41.145950
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(
        "message",
        interpreter_name="python",
        discovery_mode="auto"
    )

    assert repr(err) == "message"

# Generated at 2022-06-20 14:11:45.866909
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError(
        message='Python interpreter discovery is required but not enabled',
        interpreter_name='python',
        discovery_mode='auto_silent')
    assert str(exception) == 'Python interpreter discovery is required but not enabled'

# Generated at 2022-06-20 14:11:53.199931
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # No interpreter named python
    from ansible.plugins.action import ActionModule

    # interpreter_name = 'python'
    # discovery_mode = 'auto'
    # task_vars = {
    #   'inventory_hostname': 'localhost'
    # }
    # test_action_module = ActionModule(None, {}, None)
    # test_action_module._discovery_warnings = []
    # test_action_module._connection = {
    #   'has_pipelining': True
    # }
    # assert discover_interpreter(action=test_action_module, interpreter_name=interpreter_name, discovery_mode=discovery_mode, task_vars=task_vars) == '/usr/bin/python', 'expect "/usr/bin/python"'
    pass

# Generated at 2022-06-20 14:12:04.169472
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module = MockModule()

    platform_info = dict(platform_dist_result=[u'ubuntu', u'18.04', u'bionic'])

    module.res = dict(
        stdout=u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python3\nENDFOUND',
    )
    print(discover_interpreter(module, 'python', 'auto', {}))

    module.res = dict(
        stdout=u'PLATFORM\nLinux\nFOUND\n/usr/bin/python3\nENDFOUND',
    )
    print(discover_interpreter(module, 'python', 'auto', {}))


# Generated at 2022-06-20 14:12:07.637924
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(
        u"test message",
        u"test interpreter_name",
        u"test discovery_mode")
    expected = "test message"
    actual = err.__repr__()
    assert expected == actual, \
        "expected '{actual}' to equal '{expected}'".format(actual=actual, expected=expected)

# Generated at 2022-06-20 14:12:11.618845
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    python_interpreter = discover_interpreter(None, interpreter_name='python', discovery_mode='auto_legacy_silent', task_vars=task_vars)

# Generated at 2022-06-20 14:12:14.964758
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ede = InterpreterDiscoveryRequiredError('ada', 'auth', 'silent')
    assert ede is not None
    assert repr(ede) == 'ada'

# Generated at 2022-06-20 14:12:25.151799
# Unit test for function discover_interpreter
def test_discover_interpreter():

    import os
    import tempfile

    def sub_write_file(interpreter_name, discovery_mode):
        (fd, output_file) = tempfile.mkstemp()
        os.write(fd, interpreter_name + '\n')
        os.write(fd, discovery_mode + '\n')
        os.close(fd)

    ########################################################################
    # scenario 1 - no interpreter name
    ########################################################################
    # input
    interpreter = ''
    discovery_mode = ''

    # output
    exp_interpreter = 'python'
    exp_discovery_mode = 'auto'

    # write test output to output file
    host = 'localhost'
    task_vars = dict(inventory_hostname=host)

# Generated at 2022-06-20 14:12:30.121852
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('foo', 'python', 'auto_legacy')

    assert e.message == 'foo'
    assert e.interpreter_name == 'python'
    assert e.discovery_mode == 'auto_legacy'

# Generated at 2022-06-20 14:12:34.088692
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError("Message", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        result = e.__repr__()

    assert result == "Message"

# Generated at 2022-06-20 14:13:11.519234
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'Custom Exception Message'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert (str(exception) == message)
    assert (repr(exception) == message)

# Generated at 2022-06-20 14:13:16.673205
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    def my_repr(args):
        return '%s: %s' % (args[0], args[1])

    e = InterpreterDiscoveryRequiredError('foo', 'bar', 'spam')
    e.__repr__ = my_repr
    assert e.__str__() == 'foo'

# Generated at 2022-06-20 14:13:18.539254
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    a = InterpreterDiscoveryRequiredError("this is a test", "interpreter_name", "discovery_mode")

    assert a.message == 'this is a test'
    assert a.interpreter_name == 'interpreter_name'
    assert a.discovery_mode == 'discovery_mode'

# Generated at 2022-06-20 14:13:26.233742
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('TestInterpreterDiscoveryRequiredError', 'python', 'auto_legacy')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto_legacy'

# Generated at 2022-06-20 14:13:39.395270
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    # We don't really want to execute this code as part of normal unit tests, so
    # we'll tear down the module globals that it depends on to make sure it
    # can't accidentally be run.

# Generated at 2022-06-20 14:13:47.480861
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    """Unit test for method __str__ of class InterpreterDiscoveryRequiredError"""
    exception = InterpreterDiscoveryRequiredError("The message", "python", "auto")
    assert unicode(exception) == "The message"

# Generated at 2022-06-20 14:13:53.835500
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'silent'
    exc = InterpreterDiscoveryRequiredError('message', interpreter_name, discovery_mode)
    str_exc = str(exc)
    assert exc.message==str_exc
    assert exc.interpreter_name==interpreter_name
    assert exc.discovery_mode==discovery_mode

# Generated at 2022-06-20 14:13:59.324306
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python3'
    discovery_mode = 'auto_silent'
    message = 'python3 interpreter discovery requires the auto_silent interpreter discovery mode'

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert repr(exception) == message


# Generated at 2022-06-20 14:14:02.185310
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_required = InterpreterDiscoveryRequiredError(u"msg", u"interpreter", u"discovery")
    assert repr(interpreter_discovery_required) == "msg"

# Generated at 2022-06-20 14:14:09.858556
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "example message"
    interpreter_name = "python"
    discovery_mode = "auto"
    tmp_exception = InterpreterDiscoveryRequiredError(message=msg, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert tmp_exception.message == msg
    assert tmp_exception.interpreter_name == interpreter_name
    assert tmp_exception.discovery_mode == discovery_mode