

# Generated at 2022-06-20 14:05:05.877524
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent_facts_fallback'

    action = MockAction()
    task_vars = dict()
    action._connection.has_pipelining = True
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    expected_res = '/usr/bin/python'
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    print("res: %s" % res)
    assert res == expected_res



# Generated at 2022-06-20 14:05:11.850596
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Define test variables
    action = None
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    task_vars = dict(inventory_hostname='test')
    # Call function
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    # Assert that result is None
    assert result != None
    # Assert that result is a string
    assert isinstance(result, str)
    # Assert that result is /usr/bin/python
    assert result == "/usr/bin/python"

# Generated at 2022-06-20 14:05:15.966522
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Discovery has not been run yet'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == e.__repr__()

# Generated at 2022-06-20 14:05:22.788008
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Ensure __init__() correctly sets the interpreter_name and discovery_mode fields
    msg = "Ansible requires Python interpreter discovery on this platform"
    i_name = "python"
    d_mode = "auto_silent"
    i = InterpreterDiscoveryRequiredError(msg, i_name, d_mode)
    assert i.interpreter_name == i_name
    assert i.discovery_mode == d_mode

    # Ensure __str__() correctly returns the message
    assert str(i) == msg

# Generated at 2022-06-20 14:05:33.492471
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict(
        ansible_distribution='unknown',
        ansible_distribution_version='unknown',
        ansible_distribution_major_version='unknown',
        ansible_distribution_release='unknown',
        ansible_distribution_file_parsed=False,
        ansible_system='unknown',
        ansible_os_family='unknown',
        ansible_pkg_mgr='unknown',
        inventory_hostname='unknown',
    )

    class Action:
        def __init__(self):
            self._discovery_warnings = []
            self._connection = TestConnection()


# Generated at 2022-06-20 14:05:41.404798
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError(u"message", u"python", u"auto")
    assert err.message == u"message"
    assert err.interpreter_name == u"python"
    assert err.discovery_mode == u"auto"

# Generated at 2022-06-20 14:05:50.085909
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    value_for_repr = 'test value'
    item = InterpreterDiscoveryRequiredError(value_for_repr, 'python', 'auto_legacy_silent')

    assert str(item) == value_for_repr
    assert repr(item) == value_for_repr
    assert item.message == value_for_repr
    assert item.interpreter_name == 'python'
    assert item.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-20 14:06:03.472331
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible.module_utils.six as six

    # create class instance and make assertions
    cls = InterpreterDiscoveryRequiredError("message", "interpeter_name", "discovery_mode")
    assert cls.message == "message"
    assert cls.interpreter_name == "interpeter_name"
    assert cls.discovery_mode == "discovery_mode"

    # test __repr__
    assert repr(cls) == "message"


# Generated at 2022-06-20 14:06:07.880209
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    test_error = InterpreterDiscoveryRequiredError('test_InterpreterDiscoveryRequiredError', 'python', 'auto')
    assert test_error.interpreter_name == 'python'
    assert test_error.discovery_mode == 'auto'

# Generated at 2022-06-20 14:06:15.040441
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('python2 interpreter discovery required', 'python2', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'python2 interpreter discovery required'
        assert e.interpreter_name == 'python2'
        assert e.discovery_mode == 'auto_legacy_silent'
        assert str(e) == 'python2 interpreter discovery required'
        assert repr(e) == 'python2 interpreter discovery required'



# Generated at 2022-06-20 14:06:29.427514
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Test function __repr__ of class InterpreterDiscoveryRequiredError
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'test message'
    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert obj.__repr__() == 'test message'



# Generated at 2022-06-20 14:06:32.820528
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "message"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(exception) == message


# Generated at 2022-06-20 14:06:46.024000
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class taskDummy():
        def __init__(self,action):
            self._task = taskDummy(action)
            self._task._discovery_warnings = []

    class actionDummy():
        def __init__(self,action, host):
            self._low_level_execute_command = action
            self._discovery_warnings = list()
            self._task = taskDummy(action)
            self._task._discovery_warnings = []
            self.host = host

    class connectionDummy():
        def __init__(self, has_pipelining=True):
            self.has_pipelining = has_pipelining

    # host OSX
    host = 'MACOSX'
    python_path = '/usr/bin/python'

# Generated at 2022-06-20 14:06:50.227731
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("msg", "python", "auto")

    assert(error.message == "msg")
    assert(error.interpreter_name == "python")
    assert(error.discovery_mode == "auto")


# Generated at 2022-06-20 14:07:04.229192
# Unit test for function discover_interpreter

# Generated at 2022-06-20 14:07:06.533022
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with pytest.raises(InterpreterDiscoveryRequiredError):
        raise InterpreterDiscoveryRequiredError('msg', 'py', 'auto')

# Generated at 2022-06-20 14:07:10.663984
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "This is a test message"
    interpreter_name = "python"
    discovery_mode = "auto"
    exc = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert exc.__str__() == exc.message

# Generated at 2022-06-20 14:07:17.140040
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    err = InterpreterDiscoveryRequiredError(u'message', interpreter_name, discovery_mode)

    assert 'message' in str(err)
    assert interpreter_name in repr(err)
    assert discovery_mode in repr(err)

# Generated at 2022-06-20 14:07:29.765615
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert repr(e) == 'message'
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy')
    assert repr(e) == 'message'
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert repr(e) == 'message'
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent_fail')
    assert repr(e) == 'message'
    e = InterpreterDiscoveryRequiredError('message', 'python', 'manual')
    assert repr(e) == 'message'
    e = InterpreterDiscoveryRequiredError('message', 'python', 'manual_silent')

# Generated at 2022-06-20 14:07:35.506412
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    path = "/foo/bar/baz.py"
    name = "Python"
    discovery_mode = "off"

    error = InterpreterDiscoveryRequiredError("test", name, discovery_mode)
    actual = repr(error)

    expected = "test"
    assert actual == expected
    assert actual is not expected

# Generated at 2022-06-20 14:07:54.494105
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Create a stub class with the necessary attributes.
    class StubConnection:
        has_pipelining = True

    class StubTask:
        def __init__(self):
            self.connection = StubConnection()
            self.action = 'setup'
            self.delegate_to = None
            self.action_loader = None
            self.args = dict(discovered_interpreter_python=dict(path='/usr/bin/python'))
            self.run_once = False


# Generated at 2022-06-20 14:08:07.114750
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import connection_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class ConnectionMock:
        def __init__(self, cmd_output_file, has_pipelining=True):
            self.cmd_output_file = cmd_output_file
            self.has_pipelining = has_pipelining
            self.hostname = "mock"

        def get_host_data(self):
            return {}


# Generated at 2022-06-20 14:08:17.014891
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError

# Generated at 2022-06-20 14:08:23.554501
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = "missing interpreter_python for host localhost and python"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:08:29.239943
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert error.__str__() == 'message'

# Generated at 2022-06-20 14:08:32.507605
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('example message', 'python', 'auto')
    assert repr(error) == 'example message'

# Generated at 2022-06-20 14:08:34.807478
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert str(error) == "message"

# Generated at 2022-06-20 14:08:40.073792
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("unimplemented", "python", "auto")
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == "python"
        assert ex.discovery_mode == "auto"
    else:
        print("Expected Exception not raised")


# Generated at 2022-06-20 14:08:45.047990
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Test message", "python", "auto_legacy_silent")
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_legacy_silent"
        assert str(e) == "Test message"


# Generated at 2022-06-20 14:08:47.070117
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    assert InterpreterDiscoveryRequiredError(
        'interpreter discovery required for python',
        'python',
        'auto_legacy_silent').interpreter_name == 'python'

# Generated at 2022-06-20 14:09:02.159347
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('message', interp_name='python', discovery_mode='auto_legacy_silent')
    assert repr(exc).startswith('message')
    assert repr(exc).endswith(", interpreter_name='python', discovery_mode='auto_legacy_silent')")


# Generated at 2022-06-20 14:09:06.132404
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('test_message', 'test_interpreter', 'test_discovery_mode')
    assert str(err) == 'test_message'
    assert err.interpreter_name == 'test_interpreter'
    assert err.discovery_mode == 'test_discovery_mode'

# Generated at 2022-06-20 14:09:13.829318
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Arrange
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    exception = InterpreterDiscoveryRequiredError(msg="message",
                                                  interpreter_name=interpreter_name,
                                                  discovery_mode=discovery_mode)

    # Act
    result = str(exception)

    # Assert
    assert result == 'message'


# Generated at 2022-06-20 14:09:26.066776
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict

    class ActionModule(object):
        def __init__(self, host, task_vars):
            self._host = host
            self._task_vars = task_vars
            self._discovery_warnings = []

        def get_warning_messages(self):
            return self._discovery_warnings

        @property
        def _connection(self):
            return self

        @property
        def has_pipelining(self):
            return True


# Generated at 2022-06-20 14:09:34.513794
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            'message',
            interpreter_name='python',
            discovery_mode='auto'
        )
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'message'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'



# Generated at 2022-06-20 14:09:37.524877
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Unit test for method __repr__ of class InterpreterDiscoveryRequiredError"""
    # pylint: disable=no-member

    interpreter_name = 'python'
    discovery_mode = 'auto'
    discovery_failure = InterpreterDiscoveryRequiredError(
        'interpreter discovery required', interpreter_name, discovery_mode)

    assert repr(discovery_failure) == discovery_failure.message

# Generated at 2022-06-20 14:09:39.693735
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert error.__str__() == "message"


# Generated at 2022-06-20 14:09:49.261212
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """Test for the function discover_interpreter
    """

    task_vars = {}
    action = object()

    for i in range(1, 5):
        # First call
        discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)

        # Second call, should hit the cache
        discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)

# Generated at 2022-06-20 14:09:50.985708
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    repr(err)
    str(err)
    assert err.message == 'message'
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'auto'

# Generated at 2022-06-20 14:09:53.069297
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception_message = InterpreterDiscoveryRequiredError(
        message='Testing message',
        interpreter_name='python',
        discovery_mode='auto_legacy_silent'
    )

    result = str(exception_message)

    expected = 'Testing message'

    assert expected == result

# Generated at 2022-06-20 14:10:23.744656
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.action_writer import ActionWriter

    ctx = PlayContext()
    ctx.connection = 'local'
    task = TaskInclude()
    task._role = None
    task.action = 'include_role'
    task.loop = ['test']
    task.args = {'role_to_include': 'test', 'name': 'test'}
    task.notify = ['notify_test1']

    task_vars = dict()
    task_vars['inventory_hostname'] = 'testhost'

    result = Task

# Generated at 2022-06-20 14:10:27.340268
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'message'

    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert message == interpreter_discovery_required_error.__repr__()

# Generated at 2022-06-20 14:10:29.266703
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("testing", "Python", "auto")
    assert error.__str__() == "<InterpreterDiscoveryRequiredError: testing>"

# Generated at 2022-06-20 14:10:37.751017
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock
    fake_action = mock.MagicMock()
    fake_action._low_level_execute_command.return_value = {'stdout': u'PLATFORM\nLinux\nFOUND\n/bin/python\nENDFOUND'}
    interpreter = discover_interpreter(action=fake_action, interpreter_name='python', discovery_mode='auto_legacy_silent', task_vars={})
    assert interpreter == '/bin/python'

# Generated at 2022-06-20 14:10:47.406962
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: move to test/utils/module_discovery.py or similar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.connection import ConnectionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class TestConnection(ConnectionBase):
        pass

    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources='')
    host = inventory.get_host(u'localhost')
    host.set_variable(u'ansible_python_interpreter', u'/usr/bin/python')

    task_vars = dict(inventory=inventory)


# Generated at 2022-06-20 14:10:52.226579
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'silent'
    message = 'message'
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    # Test method call
    assert ex.__str__() == message

# Generated at 2022-06-20 14:10:59.168676
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error_message = 'Interpreted discovery required'
    try:
        raise InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as err:
        assert err.message == error_message
        assert err.interpreter_name == interpreter_name
        assert err.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:11:06.848271
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Ensure that py3 and py2 are running
    py3_path = find_python3()
    py2_path = find_python2()

    # Test for python3
    action = ActionModule()
    action._discovery_warnings = []
    interpreter_name = 'python'
    discovery_mode = C.DEFAULT_INTERPRETER_DISCOVERY_MODE
    task_vars = dict()
    test_path = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert action._discovery_warnings == [], \
           "Unexpected warnings during interpreter discovery: {0}".format(action._discovery_warnings)

# Generated at 2022-06-20 14:11:13.467143
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    '''
    Unit test for method __str__ of class InterpreterDiscoveryRequiredError
    '''
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = "Interpreter discovery required for python on this platform"
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.__str__() == message
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:11:19.681233
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    _message = "message"
    _interpreter_name = "python"
    _discovery_mode = "auto_legacy_silent"
    e = InterpreterDiscoveryRequiredError(_message, _interpreter_name, _discovery_mode)

    assert e.message == _message
    assert e.interpreter_name == _interpreter_name
    assert e.discovery_mode == _discovery_mode

    assert str(e) == _message

# Generated at 2022-06-20 14:12:09.394970
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'

    try:
        raise InterpreterDiscoveryRequiredError('Message', interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == 'Message'

# Generated at 2022-06-20 14:12:14.255423
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'Discovery for interpreter python on the target failed'
    e = InterpreterDiscoveryRequiredError(msg, 'python', 'legacy_silent')
    assert e.__repr__() == e.message


# Generated at 2022-06-20 14:12:20.730955
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto_legacy"

    message = "interpreter_name: " + interpreter_name + ", discovery_mode: " + discovery_mode
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert e.message == message
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:12:27.288121
# Unit test for function discover_interpreter
def test_discover_interpreter():

    assert _version_fuzzy_match('1.2.3', {'1.2.2': 'python_one', '1.2.3': 'python_two'}) == 'python_one'
    assert _version_fuzzy_match('1.2.3', {'1.2.3': 'python_two', '1.2.3.1': 'python_three'}) == 'python_two'
    assert _version_fuzzy_match('1.2.3', {'1.2.4': 'python_four', '1.2.4.1': 'python_five'}) == 'python_four'

# Generated at 2022-06-20 14:12:34.734392
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # arrange
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'This test mocked InterpreterDiscoveryRequiredError'
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # act
    res = str(interpreter_discovery_required_error)

    # assert
    assert res == message

# Generated at 2022-06-20 14:12:39.128991
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    z = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert z.message == 'message'
    assert z.interpreter_name == 'python'
    assert z.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-20 14:12:47.934765
# Unit test for function discover_interpreter

# Generated at 2022-06-20 14:12:53.744953
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    obj = InterpreterDiscoveryRequiredError('message','interpreter_name','discovery_mode')

    assert obj.message == 'message'
    assert obj.interpreter_name == 'interpreter_name'
    assert obj.discovery_mode == 'discovery_mode'


# Generated at 2022-06-20 14:12:58.913642
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy")
    assert error.message == "message"
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto_legacy"


# Generated at 2022-06-20 14:13:01.507101
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError(u"message", u"interpreter_name", u"discovery_mode")
    assert repr(exc) == u"message"