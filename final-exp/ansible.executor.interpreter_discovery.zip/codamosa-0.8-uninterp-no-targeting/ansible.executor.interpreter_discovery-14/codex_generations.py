

# Generated at 2022-06-20 14:05:08.805365
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('foo', 'bar', 'baz')
    assert str(e) == 'foo'
    assert e.interpreter_name == 'bar'
    assert e.discovery_mode == 'baz'



# Generated at 2022-06-20 14:05:12.114427
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Create an instance of class InterpreterDiscoveryRequiredError
    obj = InterpreterDiscoveryRequiredError("Test message", "Test/Path", "auto")
    assert (obj.__class__.__name__ == 'InterpreterDiscoveryRequiredError')

# Generated at 2022-06-20 14:05:15.636728
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(
        'message',
        'python',
        'auto_legacy'
    )
    assert err.__str__() == 'message'



# Generated at 2022-06-20 14:05:19.951149
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    '''
    Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
    '''
    test_obj = InterpreterDiscoveryRequiredError('msg', 'interpreter_name', 'discovery_mode')
    assert test_obj.__repr__() == 'msg'

# Generated at 2022-06-20 14:05:23.892239
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError('msg', 'python', 'auto')
    assert exc.interpreter_name == 'python'
    assert exc.discovery_mode == 'auto'

# Generated at 2022-06-20 14:05:30.231275
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('this is a test', 'python', 'auto')
    assert e.message == 'this is a test'
    assert e.interpreter_name == 'python'
    assert e.discovery_mode == 'auto'
    assert e.__str__() == 'this is a test'
    assert e.__repr__() == 'this is a test'

# Generated at 2022-06-20 14:05:33.526264
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    ansible.executor.discovery.test_discover_interpreter

    :param testcase:
    :return:
    """
    return discover_interpreter(None, "python", "auto", None)

# Generated at 2022-06-20 14:05:48.121821
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    import ansible.executor.task_result

    module_name = 'raw'
    # task_vars = dict(inventory_hostname='localhost', ansible_connection='local')
    task_vars = dict(inventory_hostname='localhost')
    interpreter_name = 'python'
    discovery_modes = ['auto_legacy', 'auto', 'auto_silent']
    test_results = {}
    debug_msg = []

    # Common initialization
    pcontext = PlayContext()
    action = ActionBase(pcontext, {}, C.DEFAULT_LOAD_CALLBACK_PLUGINS, C.DEFAULT_LOAD_CALLBACK_PLUGINS,  'localhost')
    action._display.verbosity

# Generated at 2022-06-20 14:05:52.369592
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {}
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res is not None, "test_discover_interpreter error"

# Generated at 2022-06-20 14:05:54.400216
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError("msg", "python", "auto")
    assert str(exc) == "msg"
    assert repr(exc) == "msg"

# Generated at 2022-06-20 14:06:05.023381
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError('test message', 'test interpreter', 'test discovery mode')
    assert e.__str__() == 'test message'

# Generated at 2022-06-20 14:06:10.811390
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(message="message",
                                              interpreter_name="interpreter_name",
                                              discovery_mode="discovery_mode")
    assert error.message == "message"
    assert error.interpreter_name == "interpreter_name"
    assert error.discovery_mode == "discovery_mode"

# Generated at 2022-06-20 14:06:18.028560
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "Failed to find interpreter for python"
    interpreter_name = "python"
    discovery_mode = "explicit_auto"
    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert msg == err.message
    assert interpreter_name == err.interpreter_name
    assert discovery_mode == err.discovery_mode

# Generated at 2022-06-20 14:06:23.854207
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    # Create InterpreterDiscoveryRequiredError object
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError("_message", "_interpreter_name", "_discovery_mode")

    # Test __repr__ of InterpreterDiscoveryRequiredError
    assert interpreter_discovery_required_error.__repr__() == "_message"

# Generated at 2022-06-20 14:06:26.459937
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("error message",
                                              interpreter_name="python",
                                              discovery_mode="auto")

    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'
    assert str(error) == "error message"
    assert repr(error) == "error message"

# Generated at 2022-06-20 14:06:41.946302
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import copy
    import pytest

    test_interpreter_name = 'python'
    # test_discovery_mode = 'always_legacy'
    # test_discovery_mode = 'auto_legacy_silent'
    # test_discovery_mode = 'auto_legacy'
    # test_discovery_mode = 'auto_silent'
    # test_discovery_mode = 'auto'
    test_discovery_mode = 'manual'


# Generated at 2022-06-20 14:06:52.669383
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    TEST_MESSAGE = 'python interpreter discovery is required for this target'
    TEST_INTERPRETER_NAME = 'python'
    TEST_DISCOVERY_MODE = 'auto_legacy_silent'
    ex = InterpreterDiscoveryRequiredError(TEST_MESSAGE,
                                           TEST_INTERPRETER_NAME,
                                           TEST_DISCOVERY_MODE)
    assert ex.message == 'python interpreter discovery is required for this target'
    assert ex.interpreter_name == 'python'
    assert ex.discovery_mode == 'auto_legacy_silent'
    assert ex.__str__() == 'python interpreter discovery is required for this target'
    assert ex.__repr__() == 'python interpreter discovery is required for this target'



# Generated at 2022-06-20 14:07:05.974901
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python3', 'auto', None) == u'/usr/bin/python3'
    assert discover_interpreter(None, 'python3', 'auto_legacy', None) == u'/usr/bin/python3'

# Generated at 2022-06-20 14:07:16.604152
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'test_InterpreterDiscoveryRequiredError'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    myTest = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert myTest.message == message
    assert myTest.interpreter_name == interpreter_name
    assert myTest.discovery_mode == discovery_mode


# Generated at 2022-06-20 14:07:21.572375
# Unit test for function discover_interpreter
def test_discover_interpreter():

    for discovery_mode in ['auto_legacy_silent', 'auto_silent', 'auto_legacy', 'auto']:
        res = discover_interpreter(None, 'python', discovery_mode, {})
        assert res == '/usr/bin/python'

# Generated at 2022-06-20 14:07:37.004843
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'test message'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(exception) == message
    assert repr(exception) == message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:07:42.151057
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "legacy"
    message = "Test message"
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(exception) == message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:07:48.207945
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required for python on host abc'
    exc_instance = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert repr(exc_instance) == 'Interpreter discovery required for python on host abc'


# Generated at 2022-06-20 14:07:56.972684
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module_args = dict(
        action=dict(
            _connection=dict(
                has_pipelining=dict()
            ),
            _low_level_execute_command=dict()
        ),
        interpreter_name=dict(),
        discovery_mode=dict(),
        task_vars=dict()
    )

    from ansible.plugins import connection
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import PY3
    import ansible.inventory


# Generated at 2022-06-20 14:08:00.161475
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "Test_message"
    interpreter_name = "Test_interpreter_name"
    discovery_mode = "Test_discovery_mode"
    err_InterpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err_InterpreterDiscoveryRequiredError.message == message
    assert err_InterpreterDiscoveryRequiredError.interpreter_name == interpreter_name
    assert err_InterpreterDiscoveryRequiredError.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:08:09.354489
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = u"Interpreter discovery required for host, but disabled (interpreter: '{0}', mode: '{1}')"\
        .format(interpreter_name, discovery_mode)

    inter_disco_req_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert inter_disco_req_error.message == message
    assert inter_disco_req_error.interpreter_name == interpreter_name
    assert inter_disco_req_error.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:08:22.672035
# Unit test for function discover_interpreter
def test_discover_interpreter():

    host = 'testhost'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = dict()
    my_display = Display()

    # test exact version match
    '''
    {
        '1.0.0': u'/usr/bin/python',
        '2.0.0': u'/usr/bin/python3'
    }
    '''
    task_vars['ansible_python_interpreter'] = 'unknown'
    task_vars['ansible_python_interpreter_path'] = 'unknown'
    task_vars['ansible_python_interpreter_unfound'] = 'unknown'
    task_vars['ansible_python_interpreter_found'] = 'unknown'

# Generated at 2022-06-20 14:08:37.883415
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Return None if the interpreter name is not supported.
    assert discover_interpreter(None, 'ruby', None, None) is None

    # Return the default interpreter if it is supported.
    def test_default_interpreter(interpreter):
        class MockAction(object):
            def __init__(self, interpreter):
                self.connection = Connection(interpreter)
                self._discovery_warnings = []
                self._low_level_execute_command_result = {'stdout': "PLATFORM\nLinux\nFOUND\n{}\nENDFOUND".format(interpreter)}

            def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
                return self._low_level_execute_command_result


# Generated at 2022-06-20 14:08:40.921725
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    expected_result = 'message'
    result = error.__str__()
    assert result == expected_result

# Generated at 2022-06-20 14:08:48.986047
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This is a unit test, but these constants come from inventory, so we have to fake them
    expected_interpreter = "/usr/bin/python3.5"
    os.environ['FOUND'] = expected_interpreter
    action = FakeActionModule()
    task_vars = dict()
    # try with silenced warnings
    interpreter = discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)
    assert interpreter == expected_interpreter
    # and again with warnings
    del os.environ['FOUND']
    interpreter = discover_interpreter(action, 'python', 'auto_legacy', task_vars)
    assert interpreter == expected_interpreter
    # and again with something we don't expect

# Generated at 2022-06-20 14:08:59.254616
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'this is a message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(exception) == message

# Generated at 2022-06-20 14:09:01.861050
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(message="An error has occurred.", interpreter_name="python", discovery_mode="auto_legacy")
    assert error.__repr__() == error.message

# Generated at 2022-06-20 14:09:06.099660
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError("message", interpreter_name='python2.7', discovery_mode='auto')
    assert repr(err) == "message"



# Generated at 2022-06-20 14:09:12.299400
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto"

    e = InterpreterDiscoveryRequiredError("", interpreter_name, discovery_mode)
    assert interpreter_name == e.interpreter_name
    assert discovery_mode == e.discovery_mode
    # TODO: string test

# Generated at 2022-06-20 14:09:19.666078
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Setup test inputs
    message = "Test message"
    interpreter_name = "python"
    discovery_mode = "auto"

    # expected result
    result = message

    # execute the method under test
    # exception case
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as actual:
        assert actual.__repr__() == result


# Generated at 2022-06-20 14:09:20.933949
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_err = InterpreterDiscoveryRequiredError('testing', 'python', 'auto')
    assert str(test_err) == 'testing'


# Generated at 2022-06-20 14:09:26.028976
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'test'
    interpreter_name = 'python'
    discovery_mode = 'test'
    exp_result = 'test'

    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert e.__str__() == exp_result
    assert e.__repr__() == exp_result

# Generated at 2022-06-20 14:09:30.807922
# Unit test for function discover_interpreter

# Generated at 2022-06-20 14:09:39.833316
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # simulate taskvars
    task_vars = dict()
    task_vars['inventory_hostname'] = 'localhost'
    # test python
    interpreter = discover_interpreter(None, 'python', 'auto_legacy', task_vars)
    assert interpreter == u'/usr/bin/python'
    # test other
    try:
        interpreter = discover_interpreter(None, 'other', 'auto_legacy', task_vars)
        assert False
    except ValueError as ex:
        assert ex.args[0] == 'Interpreter discovery not supported for other'

# Generated at 2022-06-20 14:09:45.307729
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert exception.__str__() == "message"

# Generated at 2022-06-20 14:10:04.229606
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(message='test message',
                                                interpreter_name='python', discovery_mode='auto_silent'
                                                )
    except Exception as e:
        assert e.__str__() == 'test message'

# Generated at 2022-06-20 14:10:17.684832
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict(
        ansible_python_interpreter="/usr/bin/python",
    )
    action = None

    # Test INTERPRETER_PYTHON_DISTRO_MAP is not correctly defined
    try:
        discovery_mode = 'auto_legacy'
        discover_interpreter(action, interpreter_name="python", discovery_mode=discovery_mode, task_vars=task_vars)
        assert False, "An exception should have been raised"
    except ValueError as e:
        pass

    # Test INTERPRETER_PYTHON_FALLBACK is not correctly defined

# Generated at 2022-06-20 14:10:24.225065
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError(u"test message", u"python2", u"auto_legacy")
    s = e.__str__()
    assert s == u"test message"

# Generated at 2022-06-20 14:10:27.950534
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Setup
    exception = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")

    # Test
    assert exception.__str__() == "message"


# Generated at 2022-06-20 14:10:30.776289
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    result = repr(InterpreterDiscoveryRequiredError(u"It is an error", u"python", u"silent"))
    assert result == "It is an error"


# Generated at 2022-06-20 14:10:41.560883
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(u"This is a test error", u"python2.7", u"auto")
    assert error.message == u"This is a test error"
    assert error.interpreter_name == u"python2.7"
    assert error.discovery_mode == u"auto"
    error = InterpreterDiscoveryRequiredError(u"This is a test error", u"python3.6", u"auto")
    assert error.message == u"This is a test error"
    assert error.interpreter_name == u"python3.6"
    assert error.discovery_mode == u"auto"

# Generated at 2022-06-20 14:10:49.121687
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "message"
    interpreter_name = "python"
    test_mode = "auto"
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, test_mode)
    except InterpreterDiscoveryRequiredError as ie:
        assert ie.args[0] == message
        # TODO: assert ie.args[1] == interpreter_name
        assert ie.args[1] == interpreter_name
    finally:
        None

# Generated at 2022-06-20 14:10:53.190488
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "msg"
    idr_e = InterpreterDiscoveryRequiredError(msg, 'python', 'auto')
    assert str(idr_e) == msg
    assert repr(idr_e) == msg

# Generated at 2022-06-20 14:10:57.591614
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = {}

    return discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

# Generated at 2022-06-20 14:11:12.733844
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.module_common import get_action_from_task
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import find_action_plugin
    from ansible.utils.vars import combine_vars

    # Prepare test data
    inventory_data = {
        'all': {
            'hosts': {
                'c0': {
                    'ansible_python_interpreter': "/usr/bin/python",
                    'ansible_become': True
                }
            }
        }
    }
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

# Generated at 2022-06-20 14:11:37.813623
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_message = "Test Message"
    test_interpreter_name = "ansible_test_interpreter"
    test_discovery_mode = "ansible_test_discovery_mode"
    test_exception = InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)
    assert test_exception.message == test_message
    assert test_exception.interpreter_name == test_interpreter_name
    assert test_exception.discovery_mode == test_discovery_mode
    assert str(test_exception) == test_message


# Generated at 2022-06-20 14:11:44.064018
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert e.message == "message", "InterpreterDiscoveryRequiredError"
    assert e.interpreter_name == "python", "InterpreterDiscoveryRequiredError"
    assert e.discovery_mode == "auto", "InterpreterDiscoveryRequiredError"

# Generated at 2022-06-20 14:11:52.422448
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Function: _get_linux_distro
    Unit test for function _get_linux_distro
    """
    assert _get_linux_distro({"platform_dist_result": ["RedHat", "7.2", "Maipo"]}) == ("RedHat", "7.2")
    assert _get_linux_distro({"osrelease_content": "ID=Fedora\nVERSION_ID=25\nPRETTY_NAME=\"Fedora 25 (Twenty Five)\"\nNAME=\"Fedora\"\nVERSION=\"25 (Twenty Five)\"\n"}) == ("Fedora", "25")

# Generated at 2022-06-20 14:11:55.800364
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('foo', 'python', 'silent')
    result = str(error)
    assert result == 'foo'



# Generated at 2022-06-20 14:12:05.814746
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_base import _ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    display = Display()
    task_queue_manager = TaskQueueManager(host_list=[], conn_type='local', display=display)

    class Play:
        def __init__(self):
            self.hosts = 'all'
            self.name = "name"
            self.connection = 'smart'
            self.vars = dict()
            self.vars['ansible_python_interpreter']

# Generated at 2022-06-20 14:12:18.745717
# Unit test for function discover_interpreter

# Generated at 2022-06-20 14:12:24.605575
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "auto_legacy"
    message = "Interpreter discovery is required for action plugin %s, but discovery mode %s has been disabled via " \
              "configuration" % (interpreter_name, discovery_mode)
    test_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert test_error.__str__() == message

# Generated at 2022-06-20 14:12:31.946180
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'

    e = InterpreterDiscoveryRequiredError('message', interpreter_name, discovery_mode)
    assert e.interpreter_name == 'python'
    assert e.discovery_mode == 'auto_legacy'

    assert str(e) == 'message'
    assert repr(e) == 'message'

# Generated at 2022-06-20 14:12:40.841433
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    idr = InterpreterDiscoveryRequiredError(
        message='Unable to discover interpreter',
        interpreter_name='python',
        discovery_mode='auto'
    )
    first_repr = repr(idr)
    assert first_repr == 'Unable to discover interpreter'
    idr2 = InterpreterDiscoveryRequiredError(
        message='Unable to discover interpreter',
        interpreter_name='python',
        discovery_mode='auto'
    )
    assert repr(idr2 == first_repr)
    assert idr is not idr2

# Generated at 2022-06-20 14:12:56.890076
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    module = AnsibleModule(
        argument_spec=dict(
            test_inventory_hostname=dict(type='str'),
            test_discovery_mode=dict(type='str')
        )
    )

    loader = DataLoader()
    # FUTURE: may need to inject inventory_hostname someday
    pc = PlayContext()

    test_inventory_hostname = module.params.get('test_inventory_hostname')
    test_discovery_mode = module.params.get('test_discovery_mode')

    task_vars = {}


# Generated at 2022-06-20 14:13:34.352312
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("This is a test", "python", "auto")
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"

# Generated at 2022-06-20 14:13:45.490789
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This is a test stub for this function
    class FakeAction(object):
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            return {'stdout': "PLATFORM\nlinux\nFOUND\n/usr/bin/python\nENDFOUND"}

    task_vars = {}
    action = FakeAction()

    try:
        discover_interpreter(action, 'jython', 'auto_legacy_silent', task_vars)
        assert False
    except ValueError as ve:
        # check for expected exception; shouldn't happen because we should throw it above
        assert 'Interpreter discovery not supported for jython' in to_text(ve)

    # OK path
    action = Fake

# Generated at 2022-06-20 14:13:49.710562
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'toto'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == repr(error)



# Generated at 2022-06-20 14:13:55.925457
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    mock_message = "message"
    mock_interpreter_name = "python"
    mock_discovery_mode = "auto"

    exception = InterpreterDiscoveryRequiredError(mock_message, mock_interpreter_name, mock_discovery_mode)
    result = exception.__repr__()

    assert result == mock_message


# Generated at 2022-06-20 14:14:01.085548
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # FUTURE: proper implementation
    msg = u'foo'
    iname = u'py'
    dmode = u'auto'

    try:
        raise InterpreterDiscoveryRequiredError(msg, iname, dmode)
    except InterpreterDiscoveryRequiredError as ex:
        assert msg == str(ex)

# Generated at 2022-06-20 14:14:08.289156
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import _version_fuzzy_match
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    class _ActionModule(object):
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            return {'stdout': cmd, 'stderr': ''}

    class _ConnectionModule(object):
        has_pipelining = False

    class _TaskVars():
        def __init__(self):
            pass

        def __getitem__(self, key):
            if key == 'inventory_hostname':
                return 'inventory_hostname'

# Generated at 2022-06-20 14:14:14.297184
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("test message", "python", "auto")
    except InterpreterDiscoveryRequiredError as ex:
        # ctor was successful, check if fields are as expected
        assert ex.interpreter_name == "python"
        assert ex.discovery_mode == "auto"



# Generated at 2022-06-20 14:14:21.801488
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    def test():
        a = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
        b = repr(a)
        return (a, b)

    a, b = test()

    assert a.message == 'message'
    assert a.interpreter_name == 'interpreter_name'
    assert a.discovery_mode == 'discovery_mode'
    assert b == 'message'


# Generated at 2022-06-20 14:14:22.451908
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-20 14:14:29.382473
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "Interpreter path discovery required"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    e = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert isinstance(e, Exception)
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode

