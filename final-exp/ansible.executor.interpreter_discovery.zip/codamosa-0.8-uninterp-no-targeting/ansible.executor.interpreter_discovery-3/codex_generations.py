

# Generated at 2022-06-20 14:05:07.792573
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message="Error Message", interpreter_name="Python", discovery_mode="auto")
    assert repr(interpreter_discovery_required_error) == "Error Message"


# Generated at 2022-06-20 14:05:10.214208
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError("foo", "bar", "baz")
    assert "foo" == str(e)

# Generated at 2022-06-20 14:05:12.154703
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert repr(error) == "message"

# Generated at 2022-06-20 14:05:20.603773
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name='python'
    discovery_mode='auto_legacy_silent'
    message='Discovery mode "auto_legacy_silent" requires the use of platform interpreter discovery, but interpreter ' \
            'discovery failed. Set remote_tmp to a location that can be written to by the user account running the remote ' \
            'python interpreter ({0})'.format(interpreter_name)

    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert to_text(str(err)) == to_text(message)
    assert to_text(repr(err)) == to_text(message)

# Generated at 2022-06-20 14:05:26.403952
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('test', 'python', 'auto_legacy_auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto_legacy_auto'

# Generated at 2022-06-20 14:05:31.521340
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = u'Interpreter discovery error'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert error is not None
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert to_text(error) == message

# Generated at 2022-06-20 14:05:37.353177
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_message = "test_InterpreterDiscoveryRequiredError_test_message"
    test_interpreter_name = "test_interpreter_name"
    test_discovery_mode = "test_discovery_mode"
    test_error = InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)
    assert test_error.__repr__() == test_error.__str__()
    assert test_error.__repr__() == test_message
# end of test_InterpreterDiscoveryRequiredError___repr__


# Generated at 2022-06-20 14:05:39.893985
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy', None) == u'/usr/bin/python'



# Generated at 2022-06-20 14:05:46.787530
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter Discovery Required for ' + interpreter_name + ' with discovery mode ' + discovery_mode
    i = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert i is not None
    assert i.message == message
    assert i.interpreter_name == interpreter_name
    assert i.discovery_mode == discovery_mode


# Generated at 2022-06-20 14:05:50.799066
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    i = 'python'
    d = 'explicit'
    error = InterpreterDiscoveryRequiredError(
        "error", interpreter_name=i, discovery_mode=d
    )
    assert str(error) == "error"

# Generated at 2022-06-20 14:06:01.676578
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    ide = InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    assert ide.__str__() == 'test'


# FUTURE: add other error handling cases to unit tests

# Generated at 2022-06-20 14:06:05.039256
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert error.__repr__() == "message"

# Generated at 2022-06-20 14:06:10.026546
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = "message"
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.__repr__() == e.message == message


# Generated at 2022-06-20 14:06:15.560821
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = None

    platform_python_map = {}
    platform_python_map['centos linux'] = {}
    platform_python_map['centos linux']['6'] = ''
    platform_python_map['centos linux']['7'] = ''

    to_native(discover_interpreter(action, interpreter_name, discovery_mode, task_vars))

# Generated at 2022-06-20 14:06:25.533441
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto'
    test_msg = 'python interpreter discovery required'
    test_result = InterpreterDiscoveryRequiredError(test_msg, test_interpreter_name, test_discovery_mode)
    assert test_result.interpreter_name == test_interpreter_name
    assert test_result.discovery_mode == test_discovery_mode
    assert test_result.message == test_msg
    assert str(test_result) == test_msg
    assert repr(test_result) == test_msg

# Generated at 2022-06-20 14:06:29.472904
# Unit test for function discover_interpreter
def test_discover_interpreter():

    result = discover_interpreter(action=None, interpreter_name='python', discovery_mode=None, task_vars=None)

    assert result == u'/usr/bin/python', "unexpected result from discover_interpreter"

# Generated at 2022-06-20 14:06:37.237328
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_plugins.script import ActionModule as ScriptActionModule
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import io
    import os

    class VoidPlaybookExecutor(PlaybookExecutor):
        def __init__(self):
            self._tqm = None
            self._variables = {}

        def add_tqm(self, tqm):
            self._tqm = tqm

    class VoidActionBase(object):
        def __init__(self, tqm, connection, play_context, loader, templar, shared_loader_obj):
            self._tqm = tqm
            self._shared_loader_obj = shared_loader_obj
            self._loader = loader
            self

# Generated at 2022-06-20 14:06:49.497409
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery  # noqa


# Generated at 2022-06-20 14:06:57.104840
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # test default
    i = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert str(i) == 'message'
    assert repr(i) == 'message'

    # test custom
    i = InterpreterDiscoveryRequiredError('message', 'python3', 'auto_legacy')
    assert str(i) == 'message'
    assert repr(i) == 'message'

# Generated at 2022-06-20 14:07:04.605832
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'this is a message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.message == message
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode
    assert str(ex) == message
    assert repr(ex) == message

# Generated at 2022-06-20 14:07:19.996052
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'test message'
    interpreter_name = 'test interpreter_name'
    discovery_mode = 'test discovery_mode'
    idrError = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == idrError.__str__()

# Generated at 2022-06-20 14:07:31.163621
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # discovered supported distro, everything normal
    task_vars = dict(ansible_python_interpreter="/usr/bin/python3",
                     ansible_distribution="Debian",
                     ansible_distribution_release="9.0")
    discovered_interpreter = discover_interpreter(None, "python", "auto_legacy_silent", task_vars)
    assert discovered_interpreter == "/usr/bin/python3", "Got unexpected interpreter: %s" % discovered_interpreter

    # discovered unsupported distro, using fallback
    task_vars = dict(ansible_python_interpreter="/usr/bin/python3",
                     ansible_distribution="Linux",
                     ansible_distribution_release="9.0")

# Generated at 2022-06-20 14:07:41.381133
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars=dict(inventory_hostname='rhel7')

    # Test out when a valid match for python is found
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    res = discover_interpreter(None, 'python', 'auto', task_vars)
    assert res == '/usr/bin/python'

    # Test out when a valid match for python is not found
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    res = discover_interpreter(None, 'python', 'auto_silent', task_vars)
    assert res == '/usr/bin/python'

# Generated at 2022-06-20 14:07:47.189176
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('error message', 'python', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto_legacy_silent'


# Generated at 2022-06-20 14:07:49.335878
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    InterpreterDiscoveryRequiredError('msg', 'name', 'mode').__str__()


# Generated at 2022-06-20 14:08:02.520078
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class DummyAction:
        def __init__(self):
            self._connection = DummyConnection()
            self._discovery_warnings = []
            self.sudo = False
            self.sudo_user = None
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            if in_data:
                return self._connection._low_level_execute_command(command, sudoable, in_data)
            else:
                return self._connection._low_level_execute_command(command, sudoable)

    class DummyConnection:
        def __init__(self):
            self.has_pipelining = True


# Generated at 2022-06-20 14:08:07.114246
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'Interpreter discovery required'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    test_obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(test_obj) == message


# Generated at 2022-06-20 14:08:11.147236
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("This interpreter is not available", "a", "b")
    assert error.interpreter_name == "a"
    assert error.discovery_mode == "b"
    assert str(error) == "This interpreter is not available"
    assert repr(error) == "This interpreter is not available"

# Generated at 2022-06-20 14:08:17.118500
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'test'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(exception) == 'test'
    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'auto'

# Generated at 2022-06-20 14:08:25.191949
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = u'Boom!'
    interpreter_name = u'python'
    discovery_mode = u'legacy'
    err1 = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert err1.message == msg
    assert err1.interpreter_name == interpreter_name
    assert err1.discovery_mode == discovery_mode

    str_err1 = str(err1)
    assert str_err1 == msg

    repr_err1 = repr(err1)
    assert repr_err1 == msg

# Generated at 2022-06-20 14:08:37.882746
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Arrange
    obj = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')

    # Act
    actual = obj.__repr__()

    # Assert
    assert actual == 'message'



# Generated at 2022-06-20 14:08:40.112976
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', {}) == '/usr/bin/python'

# Generated at 2022-06-20 14:08:44.162197
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'This is the message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.__repr__() == message


# Generated at 2022-06-20 14:08:54.871576
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_message = "test message"
    test_interpreter_name = "test_interpreter_name"
    test_discovery_mode = "test_discovery_mode"
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)
    assert interpreter_discovery_required_error.__repr__() == test_message

# Generated at 2022-06-20 14:08:58.381373
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError('test message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert repr(ex) == 'test message'

# Generated at 2022-06-20 14:09:07.658883
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python3"
    discovery_mode = "auto_legacy_silent"
    message = "Failed to discover a working interpreter. Please ensure this host is " \
              "configured to use a working interpreter path or set interpreter_discovery_mode " \
              "to auto_legacy_silent in ansible.cfg. See the interpreter_discovery_mode " \
              "documentation setting in the Ansible configuration guide."
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert e.message == message
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:09:13.033819
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'msg'
    interpreter_name = 'interpreter'
    discovery_mode = 'discovery'
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert error.__str__() == msg

# Generated at 2022-06-20 14:09:15.172309
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with pytest.raises(InterpreterDiscoveryRequiredError) as excinfo:
        raise InterpreterDiscoveryRequiredError(
            'Could not find interpreter', 'python', 'auto')
    assert 'Could not find interpreter' in to_native(excinfo.value)
    assert 'python' in to_native(excinfo.value)



# Generated at 2022-06-20 14:09:23.631315
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    exception = InterpreterDiscoveryRequiredError(
        message='test exception', interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert exception.message == 'test exception'
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode
    assert str(exception) == 'test exception'
    assert repr(exception) == 'test exception'

# Generated at 2022-06-20 14:09:29.133301
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError("msg", "python", "auto")
    assert repr(exc) == 'msg'

# Generated at 2022-06-20 14:09:42.040818
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError('Nothing found', interpreter_name, discovery_mode)
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert error.__str__() == 'Nothing found'
    assert error.__repr__() == 'Nothing found'

# Generated at 2022-06-20 14:09:47.918873
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = {}
    action['_discovery_warnings'] = []
    action['_low_level_execute_command'] = lambda command, sudoable, in_data: {'rc': 0, 'stdout': '', 'stderr': ''}

    # A) When command_v returns python in /usr/bin/python
    command_v = "command -v python"
    expected_result = ('/usr/bin/python', '/usr/bin/python')
    res = discover_interpreter(action, 'python', 'auto', {'inventory_hostname': 'localhost'})
    assert res == expected_result[0]
    assert action._discovery_warnings[0] == expected_result[1]

    # B) When command_v returns python2 in /usr/bin/python2

# Generated at 2022-06-20 14:09:50.705519
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert (repr(InterpreterDiscoveryRequiredError(u'a', u'b', u'c'))) == 'a'

# Generated at 2022-06-20 14:09:55.258270
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python2'
    discovery_mode = 'auto'
    message = 'interpreter discovery required'
    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert obj.__str__() == message


# Generated at 2022-06-20 14:10:00.071325
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    except Exception as ex:
        assert str(ex) == 'message'
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-20 14:10:16.618544
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        from ansible.plugins.action.normal import ActionModule as _ActionModule
        action_plugins = {u'normal': _ActionModule}
    except ImportError:
        return {}

    action = action_plugins[u'normal'](None, {}, C.DEFAULT_LOOP_TIMEOUT, '', '', '', None, None, None, None, None)

    class FakeConnection(object):
        def __init__(self, has_pipelining):
            self._has_pipelining = has_pipelining

        def has_pipelining(self):
            return self._has_pipelining

        def _has_pipelining(self):
            return self._has_pipelining

    class FakeModule(object):
        def __init__(self, task_vars):
            self._task_

# Generated at 2022-06-20 14:10:31.776918
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TestAction:
        def __init__(self):
            self._discovery_warnings = []

    action = TestAction()

    # Test with older version and no warnings
    task_vars = {"inventory_hostname": "testhost", "CONFIG_FILE": None, "DEFAULT_CONFIG_FILE": None}
    result = discover_interpreter(action, 'python', 'auto', task_vars)
    assert result == '/usr/bin/python', "Interpreter not as expected"
    assert len(action._discovery_warnings) == 0, "Unexpected warnings not empty"

    # Test with newer version and no warnings

# Generated at 2022-06-20 14:10:33.859176
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(exception) == "message"


# Generated at 2022-06-20 14:10:45.401872
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import collections
    import unittest

    MockAction = collections.namedtuple('MockAction', ['_low_level_execute_command', '_connection', '_discovery_warnings'])

    class MockResponse(object):
        pass

    class MockConnection(object):
        def __init__(self, has_pipelining):
            self.has_pipelining = has_pipelining

    class DiscoveryTest(unittest.TestCase):
        def test_interpreter_discovery(self):
            actual = discover_interpreter(MockAction(None, MockConnection(has_pipelining=True), []),
                                          'python', 'auto_legacy_silent', {})
            self.assertEqual(actual, u'/usr/bin/python')


# Generated at 2022-06-20 14:10:50.607406
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    output = ('Unable to locate the {0} interpreter on remote host, '
              'please check your ansible config settings')

    test_error = InterpreterDiscoveryRequiredError(output.format('python'), 'python', 'auto')

    assert(str(test_error) == output.format('python'))

# Generated at 2022-06-20 14:11:14.580900
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    class FakeAction(object):
        def __init__(self, display_warning_method):
            self.display_warning_method = display_warning_method

    display = Display()
    action = FakeAction(display.warning)
    host = 'test-inventory-hostname'
    # test when discovery_mode is auto_legacy
    discovery_mode = 'auto_legacy'
    test_error = InterpreterDiscoveryRequiredError(
        u'Does not support python interpreter discovery when '
        u'discovery_interpreter_timeout is 0.', 'python', discovery_mode
    )

# Generated at 2022-06-20 14:11:22.969809
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor

    action = TaskExecutor(None, {}, {}, None, None, None, None, display)
    action._connection = ConnectionMock()
    discovery_mode = 'auto_legacy'
    try:
        discover_interpreter(action, 'python', discovery_mode, {})
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == discovery_mode
    else:
        raise Exception('Expected InterpreterDiscoveryRequiredError but no exception was raised')



# Generated at 2022-06-20 14:11:27.181717
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('this is a message', 'python', 'auto')
    assert error.__str__() == 'this is a message'
    assert error.__repr__() == 'this is a message'

# Generated at 2022-06-20 14:11:31.377836
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Create a test object
    obj = InterpreterDiscoveryRequiredError('test', 'test', 'test')

    # Call the method
    result = obj.__str__()

    # Assert that the expected result and the real result is equal
    assert (result == 'test')

# Generated at 2022-06-20 14:11:39.433257
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {'ansible_python_interpreter': '/usr/bin/python'}

# Generated at 2022-06-20 14:11:50.712023
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    task_vars['inventory_hostname'] = 'localhost'
    action = dict()
    action['_low_level_execute_command'] = lambda *args, **kwargs: dict()
    assert discover_interpreter(action, 'python', 'auto', task_vars) == '/usr/bin/python'
    assert discover_interpreter(action, 'python', 'auto_legacy', task_vars) == '/usr/bin/python'
    assert discover_interpreter(action, 'python', 'auto_silent', task_vars) == '/usr/bin/python'
    assert discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars) == '/usr/bin/python'

# Generated at 2022-06-20 14:11:58.522687
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "Testmessage"
    interpreter_name = "interpreterName"
    discovery_mode = "discoveryMode"
    ide = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ide.interpreter_name == interpreter_name
    assert ide.discovery_mode == discovery_mode
    assert str(ide) == message
    assert repr(ide) == message

# Generated at 2022-06-20 14:12:01.627173
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert repr(U'foo') == U"u'foo'", 'Expected unicode string representation'
    assert repr(u'foo') == u"u'foo'", 'Expected unicode string representation'

# Generated at 2022-06-20 14:12:05.612341
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = 'hello'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    result = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert result.message == msg
    assert result.interpreter_name == interpreter_name
    assert result.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:12:08.947044
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert obj.__repr__() == 'message'

# Generated at 2022-06-20 14:12:39.943748
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = u'a test message'
    interpreter_name = u'python2'
    discovery_mode = u'auto_legacy_silent'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(err) == u'a test message'

# Generated at 2022-06-20 14:12:45.318140
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert str(error) == "message"

# Generated at 2022-06-20 14:12:56.938625
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule

    display.verbosity = 5
    action = ActionModule(connection=None, task_vars={})
    # TODO: mock better here, look at other uses of _low_level_execute_command, simplify test
    action._low_level_execute_command = lambda command, sudoable, in_data=None: {'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'}
    display.vvvv(msg=u'Expecting /usr/bin/python')
    assert discover_interpreter(action, 'python', 'auto_silent', {}) == u'/usr/bin/python'

# Generated at 2022-06-20 14:13:01.194052
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python', discovery_mode='auto_legacy_silent')
    assert err.__str__() == err.message,\
        "Error message mismatch"

# Generated at 2022-06-20 14:13:04.568173
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    dummy_task = TaskExecutor(dict(task_vars={}))
    interpreter = discover_interpreter(dummy_task, 'python', 'auto', dummy_task.task_vars)
    assert interpreter == '/usr/bin/python'

# Generated at 2022-06-20 14:13:10.552355
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = u'Python interpreter discovery required'
    interpreter_name = u'python'
    discovery_mode = u'auto_legacy_silent'
    exp = msg
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    act = str(error)
    assert act == exp

# Generated at 2022-06-20 14:13:21.424675
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Create an empty task_vars dict
    task_vars = dict()
    # Create a mock class to return a fake distro name
    def get_config_value(name, variables, default, boolean=False, integer=False, floating=False, islist=False):
        return dict(INTERPRETER_PYTHON_DISTRO_MAP=
            {'centos':
                 {'7': '/usr/bin/python'},
             'fedora':
                 {'25': '/usr/bin/python'}},
            INTERPRETER_PYTHON_FALLBACK=
            ['/usr/bin/python3'])

    # Monkey patch C.config.get_config_value to return the mock class
    C.config.get_config_value = get_config_value

    # Create a fake action class


# Generated at 2022-06-20 14:13:26.431556
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto_legacy_silent'
    msg = ('Using python discovery mode auto_legacy_silent but no interpreter info'
           'was provided, discovery required')
    try:
        raise InterpreterDiscoveryRequiredError(msg, test_interpreter_name, test_discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == test_interpreter_name
        assert ex.discovery_mode == test_discovery_mode
        assert str(ex) == msg

# Generated at 2022-06-20 14:13:33.937024
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Since we don't have access to the __init__ method, we need to use an exception instance
    # to test __str__.
    #
    # This is an implementation detail of InterpreterDiscoveryRequiredError, but it should not
    # change as we add more attributes to the class.

    exception = InterpreterDiscoveryRequiredError("Some string", "Python 2.7", "auto")
    assert str(exception) == "Some string"

# Generated at 2022-06-20 14:13:40.033768
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert exception.message == "message"
    assert exception.interpreter_name == "interpreter_name"
    assert exception.discovery_mode == "discovery_mode"
    assert str(exception) == "message"
    assert repr(exception) == "message"

# Generated at 2022-06-20 14:14:40.694696
# Unit test for function discover_interpreter
def test_discover_interpreter():
    def get_task_vars():
        return {}

    def get_action(task_vars):
        return {}

    def get_res(command, action, task_vars):
        return {}

    # Place holder function
    def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
        return {'stdout': self.stdout}

    def _discovery_warnings(self):
        pass

    python_target_py = pkgutil.get_data('ansible.executor.discovery', 'python_target.py')

    # Test case for python script
    interpreter_name = 'python'
    discovery_mode = 'auto'
    action = get_action(get_task_vars())

# Generated at 2022-06-20 14:14:46.953460
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python3'
    discovery_mode = 'auto_legacy'
    message = 'Interpreter Discovery required'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.message == message
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:14:54.675997
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print(_version_fuzzy_match('3.0.3', {'1': {'/usr/bin/python': 0, '/usr/bin/python2.7': 1, '/usr/bin/python3': 2}}))
    print(_version_fuzzy_match('3.7.0', {'1': {'/usr/bin/python': 0, '/usr/bin/python2.7': 1, '/usr/bin/python3': 2}}))
    print(_version_fuzzy_match('3.7.0.3', {'1': {'/usr/bin/python': 0, '/usr/bin/python2.7': 1, '/usr/bin/python3': 2}}))