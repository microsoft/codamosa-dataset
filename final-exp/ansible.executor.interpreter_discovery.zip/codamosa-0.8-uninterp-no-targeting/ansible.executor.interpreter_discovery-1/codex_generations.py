

# Generated at 2022-06-20 14:05:10.443592
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError("A error occurs", "Python", "auto_legacy_silent")
    assert exc.__str__() == "A error occurs"


# Generated at 2022-06-20 14:05:17.465020
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    task_vars = {}

    interpreter_name = 'python'
    discovery_mode = 'explicit'

    # Test when platform type is not linux and it should raise NotImplementedError
    platform_info = {'platform_type': 'aix'}
    task_vars['ansible_platform_info'] = platform_info
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except NotImplementedError as ex:
        assert str(ex) == 'unsupported platform for extended discovery: aix'
    else:
        assert False, "Should have raised NotImplementedError exception"

    # Test when platform type is linux, but distribution name is not found and it should raise NotImplementedError

# Generated at 2022-06-20 14:05:20.418914
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_int_d_r_e = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')

    assert(test_int_d_r_e.__str__() == 'message')

# Generated at 2022-06-20 14:05:25.495005
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    e = InterpreterDiscoveryRequiredError('test message', 'python', 'auto_legacy_silent')
    assert e.message == 'test message'
    assert e.interpreter_name == 'python'
    assert e.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-20 14:05:35.117126
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    interpreter_name = 'python'
    action = _ActionModule(
        task=TaskResult(host='example.com', task=dict(action=dict(module='ping'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    action._discovery_warnings = []



# Generated at 2022-06-20 14:05:44.087730
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class ActionModule(object):
        def __init__(self, connection):
            self._connection = connection
            self._discovery_warnings = []
            self.noop_on_check_mode = True

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            assert sudoable == False
            assert command in command_list

            if command == '/usr/bin/python':
                return {'stdout': json.dumps(platform_info)}
            elif command == 'command -v /usr/bin/python':
                return {'stdout': '/usr/bin/python'}
            elif command == 'command -v python3':
                return {'stdout': 'python3'}

# Generated at 2022-06-20 14:05:49.963906
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = "Error message"
    interpreter = "python"
    discovery_mode = "on_missing"
    mock_task_vars = {}

    e = InterpreterDiscoveryRequiredError(error, interpreter, discovery_mode)

    assert e.message == error
    assert e.interpreter_name == interpreter
    assert e.discovery_mode == discovery_mode

    assert e.__str__() == error
    assert e.__repr__() == error



# Generated at 2022-06-20 14:06:05.792469
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # intercept shell calls and replace with mock values
    def mock_execute_command(cmd, in_data=None, sudoable=True):
        if in_data:
            # trying to invoke the platform.dist() python script
            assert cmd.endswith('/python2.7'), 'unexpected python interpreter for target discovery script'
            return {'stdout': json.dumps({'platform_dist_result': ['fedora', '20', ''],
                                          'osrelease_content': 'ID=fedora\nVERSION_ID=20\n'})}
        else:
            # trying to find a python interpreter
            assert cmd == "echo PLATFORM; uname; echo FOUND; command -v '/usr/bin/python'; command -v '/usr/bin/python2.7'; echo ENDFOUND"

# Generated at 2022-06-20 14:06:09.683339
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError('message', 'interpreter', 'discovery')
    assert exception.__str__() == 'message'


# Generated at 2022-06-20 14:06:17.773757
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    raw_result = dict(
        msg='No python interpreters found for host node1 (tried [u\'/usr/bin/python\', u\'/usr/bin/python3\'])',
        interpreter_name='python',
        discovery_mode='auto_legacy'
    )
    try:
        interpreter_name = raw_result.get('interpreter_name')
        discovery_mode = raw_result.get('discovery_mode')
        msg = raw_result.get('msg')
        raise InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert type(e).__name__ == 'InterpreterDiscoveryRequiredError'
        assert e.interpreter_name == 'python'

# Generated at 2022-06-20 14:06:41.785633
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.compat.tests.mock import Mock, patch

    action = ActionBase()

    # interpreter name must be python
    try:
        discover_interpreter(action, "notpython", "auto", {})
        assert False
    except ValueError:
        assert True

    # test that raise NotImplementedError when the platform is not linux
    with patch.object(action, "_low_level_execute_command", return_value={'stdout': "PLATFORM\r\nnotlinux\r\nFOUND\r\n/usr/bin/python\r\nENDFOUND"}):
        try:
            discover_interpreter(action, "python", "auto", {})
            assert False
        except NotImplementedError:
            assert True

   

# Generated at 2022-06-20 14:06:47.033496
# Unit test for function discover_interpreter
def test_discover_interpreter():
    inventory_item = dict()
    inventory_item['ansible_python_interpreter_discovery_mode'] = 'auto'
    action = dict()
    display.verbosity = 4
    res = discover_interpreter(action, 'python', 'auto', inventory_item)
    assert(res == '/usr/bin/python')

# Generated at 2022-06-20 14:06:48.233887
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert False, "There is no unit test for this function"

# Generated at 2022-06-20 14:06:52.911215
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    errmsg = 'Discovery is required'
    interpreter = 'python'
    discovery_mode = 'forced'

    exception = InterpreterDiscoveryRequiredError(errmsg, interpreter, discovery_mode)

    assert exception.message == 'Discovery is required'
    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'forced'

# Generated at 2022-06-20 14:07:06.166311
# Unit test for function discover_interpreter
def test_discover_interpreter():
    if C.DEFAULT_MODULE_UTILS != 'ansible.module_utils._text':
        # Test no longer valid when config defaults are not used
        return

    task_vars = dict()

    # Test invalid interpreter type
    try:
        discover_interpreter(None, 'perl', 'no', task_vars)
        assert False
    except ValueError:
        pass

    # Test valid interpreter type
    try:
        _ = discover_interpreter(None, 'python', 'no', task_vars)
    except ValueError:
        assert False

    # Test valid interpreter type with 'legacy'
    try:
        _ = discover_interpreter(None, 'python', 'auto_legacy', task_vars)
    except ValueError:
        assert False

    # Test valid interpreter type with '

# Generated at 2022-06-20 14:07:14.691005
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible_collections.misc.not_a_real_collection.plugins.modules.discovery_utils_mock import DiscoveryModule
    # This is a sample module to test the discover_interpreter function
    # In this test module, the interpreter name is 'python' and the discovery_mode is 'auto_legacy_silent'
    sample_module = DiscoveryModule('test_module', 'tests/unit/modules/discovery_utils_test_module.py', 'test_module')
    os_release_file = 'tests/unit/modules/discovery_utils_os-release'

    platform_script = pkgutil.get_data('ansible.executor.discovery', 'python_target.py')

    # Test case 1: not supported interpreter and discovery mode

# Generated at 2022-06-20 14:07:18.066125
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto")
    str_error = str(error)
    assert str_error == "message"



# Generated at 2022-06-20 14:07:27.042061
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """
    Test method __repr__ of class InterpreterDiscoveryRequiredError
    """
    try:
        e = InterpreterDiscoveryRequiredError("test message", "test_interpreter_name", "test_discovery_mode")
        assert e.__repr__() == e.message
    except Exception as ex:
        print("Exception when test_InterpreterDiscoveryRequiredError___repr__")
        print(ex)
        print(traceback.format_exc())
        assert False


# Generated at 2022-06-20 14:07:32.802475
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError(u'msg', u'python', u'auto')
    assert obj.__repr__() == u'msg'

# Generated at 2022-06-20 14:07:45.742670
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.mock import patch

    def _create_action(**kwargs):
        action = type("DEFAULT", (object,), {})()
        action._discovery_warnings = []
        action._connection = _create_connection(**kwargs)
        return action

    def _create_connection(**kwargs):
        connection = type("DEFAULT", (object,), {})()
        connection.has_pipelining = kwargs.get('has_pipelining', True)
        return connection


# Generated at 2022-06-20 14:08:13.305508
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Defines some test variables and fixtures
    # Python interpreter discovery not supported for other interpreter
    # Test case of success

    interpreter = 'python'
    discovery_mode = 'auto'
    task_vars = dict()
    task_vars['inventory_hostname'] = 'localhost'

    interpreter = discover_interpreter(None, interpreter, discovery_mode, task_vars)
    print(interpreter)

    # Test case of failure

# Generated at 2022-06-20 14:08:14.585957
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FIXME: test function
    assert False

# Generated at 2022-06-20 14:08:22.782173
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = "Ansible requires the interpreter to be discovered."
    interpreter_name = "python"
    discovery_mode = "auto"
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    expected = "Failed to discover the interpreter.\n" \
               "Ansible requires the interpreter to be discovered.\n" \
               "interpreter_name: python\n" \
               "discovery_mode: auto"
    assert expected == exception.__repr__()

# Generated at 2022-06-20 14:08:31.926106
# Unit test for function discover_interpreter
def test_discover_interpreter():
    distro, version = _get_linux_distro({'osrelease_content': pkgutil.get_data('ansible.executor.discovery', 'os-release-centos6')})
    assert distro == 'centos'
    assert version == '6'

    # empty string case (should be no exceptions)
    distro, version = _get_linux_distro({})
    assert not (distro or version)

    # real-world data from platform.dist()
    distro, version = _get_linux_distro({'platform_dist_result': ['redhat', '6.7', 'Maipo']})
    assert distro == 'redhat'
    assert version == '6.7'

    # make sure we can handle empty string platform.dist() results
    distro, version = _get_linux_

# Generated at 2022-06-20 14:08:37.882560
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert interpreter_discovery_required_error.__repr__() == interpreter_discovery_required_error.message



# Generated at 2022-06-20 14:08:41.128040
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'foo'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    tested_instance = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(tested_instance) == message

# Generated at 2022-06-20 14:08:44.432060
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError(message='message', interpreter_name='name', discovery_mode='mode')
    except InterpreterDiscoveryRequiredError as exception:
        assert exception.__repr__() == "message"


# Generated at 2022-06-20 14:08:46.187059
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    result = InterpreterDiscoveryRequiredError("test", "python", "test")
    assert result.__repr__() == "test"


# Generated at 2022-06-20 14:08:47.987927
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

# Generated at 2022-06-20 14:08:54.328921
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert exc.message == "message"
    assert exc.interpreter_name == "python"
    assert exc.discovery_mode == "auto"
    assert str(exc) == exc.message
    assert repr(exc) == exc.message

# Generated at 2022-06-20 14:09:34.349960
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'message'
    discovery_mode = 'test discovery_mode'
    interpreter_name = 'python'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert err.__str__() == message
    assert repr(err) == message

# Generated at 2022-06-20 14:09:39.968899
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    ex = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert ex.message == "message"
    assert ex.interpreter_name == "python"
    assert ex.discovery_mode == "auto"

    test_str = str(ex)
    assert test_str == "message"

    test_repr = repr(ex)
    assert test_repr == "message"

# Generated at 2022-06-20 14:09:42.035885
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    assert str(
        InterpreterDiscoveryRequiredError('Test message', 'python', 'auto_legacy_silent')) == 'Test message'

# Generated at 2022-06-20 14:09:52.830873
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = "Python interpreter discovery required for plugin ({0}), but discovery mode is {1}".format(interpreter_name, discovery_mode)
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:10:02.738939
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import collections
    import os
    import unittest

    from ansible.executor.discovery import discover_interpreter

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import PY3

    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.plugin_docs import read_docstub
    from ansible.utils.display import Display

    display = Display()

    FakeConnectionBase = collections.namedtuple('FakeConnectionBase',
                                                ['transport', 'has_pipelining', '_shell', '_executable', '_terminal_stdout_regex',
                                                 '_terminal_stderr_regex'])

    FakeTaskVars

# Generated at 2022-06-20 14:10:04.255884
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")

    assert exception.__repr__() == exception.message


# Generated at 2022-06-20 14:10:06.977858
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError(message='system error', interpreter_name='python', discovery_mode='smart')
    assert str(exception) == 'system error'
    assert exception.__repr__() == 'system error'
    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'smart'

# Generated at 2022-06-20 14:10:13.393472
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError(message='test', interpreter_name='test_interpreter', discovery_mode='test_mode')
    assert e.interpreter_name == 'test_interpreter'
    assert e.discovery_mode == 'test_mode'
    assert e.message == 'test'



# Generated at 2022-06-20 14:10:24.414245
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase

    class TestModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            res = self._execute_module(module_name='shell', module_args=dict(free_form='uname'))
            del(res['invocation'])


# Generated at 2022-06-20 14:10:37.330091
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Action:
        def __init__(self):
            self._discovery_warnings = []
            self._connection = None
        def _low_level_execute_command(self, command, sudoable=True, in_data=None):
            pass
    action = Action()

    class Connection:
        def __init__(self):
            self.has_pipelining = True
    action._connection = Connection()


# Generated at 2022-06-20 14:11:53.524916
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.task_executor
    from ansible.executor.task_result import TaskResult

    class FakeModule:
        def __init__(self, action):
            self.action = action

    class FakeBaseConnection:
        def __init__(self, pipelining):
            self.pipelining = pipelining

        def has_pipelining(self):
            return self.pipelining

    class FakeTaskExecutor(ansible.executor.task_executor.TaskExecutor):
        def __init__(self, interpreter_name, discovery_mode, task_vars):
            self._low_level_execute_command = _low_level_execute_command
            self._connection = FakeBaseConnection(pipelining=False)  # TODO: test on-disk case too?
            self._d

# Generated at 2022-06-20 14:11:59.152594
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # No discovery
    try:
        discover_interpreter(None, 'unknown', 'explicit', None)
    except NotImplementedError as e:
        assert "Interpreter discovery not supported for unknown" == to_text(e)


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-20 14:12:01.717698
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # idrre = InterpreterDiscoveryRequiredError(message = "", interpreter_name = "", discovery_mode = "")
    assert False


# Generated at 2022-06-20 14:12:04.773872
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'msg'
    interpreter_name = 'python'
    discovery_mode = 'auto'

    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert str(error) == msg

# Generated at 2022-06-20 14:12:09.149501
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'test message'
    interpreter_name = 'test_interpreter_name'
    discovery_mode = 'test_discovery_mode'
    exception = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert exception.__repr__() == msg

# Generated at 2022-06-20 14:12:16.684781
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError(
            "message",
            "interpreter_name",
            "discovery_mode",
        )
    except InterpreterDiscoveryRequiredError as  exception:
        assert exception.message == "message"
        assert exception.interpreter_name == "interpreter_name"
        assert exception.discovery_mode == "discovery_mode"
        assert str(exception) == "message"

# Generated at 2022-06-20 14:12:24.075894
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    import sys
    if sys.version_info < (3, 0):
        from mock import patch, Mock
        from ansible.module_utils import basic

        with patch.object(basic, 'get_distribution') as mock_get_distribution:
            mock_get_distribution.return_value = Mock(**{'version': '2.0.0'})
            exception = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
            assert exception.__repr__() == 'message'
            assert str(exception) == 'message'

# Generated at 2022-06-20 14:12:38.049507
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict(
        ansible_user='stack',
    )

    class MockAction(object):
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            self._cmd = cmd
            self._in_data = in_data

            if cmd.startswith('echo PLATFORM'):
                return dict(stdout=u'PLATFORM\nLinux\n\nFOUND\n/usr/bin/python\nENDFOUND')

# Generated at 2022-06-20 14:12:47.324597
# Unit test for function discover_interpreter
def test_discover_interpreter():
    global display
    display = Display()

    import os
    import sys
    import textwrap

    global C
    # Because discover_interpreter is called during an inventory plugin's execution,
    # it is called by an instance of the Inventory class (in this case an instance of MockInventory).
    # The Inventory class in turn uses some constants from the ansible.constants module.
    # To test discover_interpreter, we must therefore mock ansible.constants.
    # To prevent NameError exceptions during execution of this test, we specify
    # that constants should be imported from the constants module in the ansible
    # package in the same directory that this test is located in (i.e. this directory).
    #
    # In other words:
    # This is very, very ugly. The reason for this ugliness is that the constants
    # used by

# Generated at 2022-06-20 14:13:00.798197
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    class TestInterpreterDiscoveryAction(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None, su=None, su_user=None):
            if cmd == "command -v 'python'":
                return dict(stdout=u"/usr/bin/python\n/usr/bin/python3")
            elif cmd == "/usr/bin/python":
                return dict(stdout=u'{"osrelease_content": "NAME=\"Ubuntu\"\nVERSION=\"18.04 LTS (Bionic Beaver)\"\nID=ubuntu\nID_LIKE=debian\nPRETTY_NAME=\"Ubuntu 18.04 LTS\"\nVERSION_ID=\"18.04\""}')