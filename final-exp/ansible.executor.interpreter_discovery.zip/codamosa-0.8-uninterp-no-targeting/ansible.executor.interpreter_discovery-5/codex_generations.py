

# Generated at 2022-06-20 14:05:08.949286
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError("Test", "Python", "auto_legacy_silent")

    assert e.message == "Test"
    assert e.interpreter_name == "Python"
    assert e.discovery_mode == "auto_legacy_silent"


# Generated at 2022-06-20 14:05:16.855547
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    from ansible.module_utils.common.removed import removed_module
    from ansible.executor.module_common import _load_params
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    import tempfile
    import shutil
    import os
    import sys

    test_error_message = 'test message'
    test_interpreter_name = 'test_interpreter'
    test_interpreter_discovery_mode = 'test_discovery_mode'

    # check that the error message is returned

# Generated at 2022-06-20 14:05:25.803352
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.virtual import Virtual, virtuals_fact_class
    from ansible.executor.task_result import TaskResult

    class MockModuleAction:
        def __init__(self):
            self.connection = MockConnection()
            self.module_defaults = dict()
            self.task_vars = dict()
            self.host_name = 'localhost'
            self.task_vars['inventory_hostname'] = 'localhost'
            self.task_vars['ansible_facts'] = dict()
            self.task_vars['ansible_facts']['ansible_system'] = 'Darwin'
            self.task_vars['ansible_facts']['virtualization_role'] = Virtual.ROLE_HOST

# Generated at 2022-06-20 14:05:32.126005
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("test_message1", "test_interp_name", "test_mode")
    except InterpreterDiscoveryRequiredError as e:
        assert isinstance(e, InterpreterDiscoveryRequiredError)
        assert e.message == "test_message1"
        assert e.interpreter_name == "test_interp_name"
        assert e.discovery_mode == "test_mode"


# Generated at 2022-06-20 14:05:38.975730
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

        class MockTaskVars(object):
            def __init__(self, inventory_hostname, interpreter_name, discovery_mode):
                self.inventory_hostname = inventory_hostname
                self.interpreter_name = interpreter_name
                self.discovery_mode = discovery_mode

        # dummy task vars
        task_vars = MockTaskVars('inventory_hostname', 'interpreter_name', 'discovery_mode')

        # dummy exception message
        message = 'message'
        error = InterpreterDiscoveryRequiredError(message, 'python', 'auto')

        assert error.message == message
        assert error.interpreter_name == 'python'
        assert error.discovery_mode == 'auto'
        assert str(error) == message
        assert repr(error) == message

# Generated at 2022-06-20 14:05:46.749695
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_message = "Error message"
    interpreter_name = "python"
    discovery_mode = "auto"

    try:
        raise InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert error_message == ex.message
        assert interpreter_name == ex.interpreter_name
        assert discovery_mode == ex.discovery_mode
        print("Test for constructor of class InterpreterDiscoveryRequiredError passed.")


# Generated at 2022-06-20 14:05:57.536898
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    # Test case with required module interpreter_name
    class TestInterpreterDiscoveryRequiredError:

        def test_interpreter_name(self):
            message = "message"
            interpreter_name = "python"
            discovery_mode = "auto"

            test = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
            val = test.__repr__()

            assert val is not None

    test_case = TestInterpreterDiscoveryRequiredError()
    test_case.test_interpreter_name()

# Generated at 2022-06-20 14:06:01.900928
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "message"
    interpreter_name = 'python'
    discovery_mode = 'auto'

    exception = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode

    assert str(exception) == message
    assert repr(exception) == message

# Generated at 2022-06-20 14:06:15.281921
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from mock import patch
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.script import ActionModule as script
    from ansible.plugins.action.raw import ActionModule as raw

    class TestActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            if self._play_context.connection == 'network_cli':
                module_name = self._task.action.split('.')[-1]
                module_args = self._task.args.copy()
                # since I don't want to depend on the ScriptModule from the action plugin, I manually instantiate it
                # and run it, capturing it's results, which I return here.

# Generated at 2022-06-20 14:06:20.280622
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = "test message"
    interpreter_name = "interp"
    discovery_mode = "test discovery mode"
    error = InterpreterDiscoveryRequiredError(err, interpreter_name, discovery_mode)
    assert error.__repr__() == err

# Generated at 2022-06-20 14:06:31.709185
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    assert InterpreterDiscoveryRequiredError('message', 'python', 'auto').__str__() == 'message'
    assert InterpreterDiscoveryRequiredError('message', 'python', 'auto').message == 'message'

# Generated at 2022-06-20 14:06:39.345910
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            'Test only',
            interpreter_name='python',
            discovery_mode='auto'
        )
    except InterpreterDiscoveryRequiredError as ex:
        assert to_text(ex.interpreter_name) == 'python'
        assert to_text(ex.discovery_mode) == 'auto'

# Generated at 2022-06-20 14:06:51.063344
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    import sys
    import copy
    sys.modules['ansible'].config = type('', (object,),
                                         {'get_config_value': lambda *args: {'interpreter_python_fallback': ['python2.7', 'python2'],
                                                                             'interpreter_python_distro_map': {'redhat': {'7': 'python2'}}}})
    task = type('', (object,), {'_connection': type('', (object,), {'has_pipelining': False})})()

# Generated at 2022-06-20 14:07:04.651169
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.connection import ConnectionBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class MockActionBase(object):
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            return {'stdout': cmd}

    class MockTask(object):
        def __init__(self, action, interpreter_name, discovery_mode=u'auto_silent'):
            self.action = action
            self.interpreter

# Generated at 2022-06-20 14:07:13.838372
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: stub out a fake action?
    class FakeAction(object):
        def _low_level_execute_command(self, a, b, c):
            return {'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'}

    task_vars = dict(any='thing')
    action = FakeAction()
    res = discover_interpreter(action, u'python', u'auto_legacy_silent', task_vars)
    assert res == u'/usr/bin/python'

    action = FakeAction()
    res = discover_interpreter(action, u'python', u'auto_legacy', task_vars)
    assert res == u'/usr/bin/python'

    action = FakeAction()
    res = discover_

# Generated at 2022-06-20 14:07:21.577338
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError("test_message", "python2", "auto")
    # test if the InterpreterDiscoveryRequiredError is constructed and initialized
    assert isinstance(exc, InterpreterDiscoveryRequiredError)
    assert exc.interpreter_name == "python2" and exc.discovery_mode == "auto"
    assert str(exc) == "test_message"
    assert repr(exc) == "test_message"

# Generated at 2022-06-20 14:07:27.484368
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError(message="Test", interpreter_name="python", discovery_mode="auto_legacy")
    assert exc.message == "Test"
    assert exc.interpreter_name == "python"
    assert exc.discovery_mode == "auto_legacy"
    assert str(exc) == "Test"



# Generated at 2022-06-20 14:07:33.804085
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: flesh this out
    class MockAction:
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd.startswith('command -v'):
                stdout = u'{0}\n/usr/bin/python /usr/bin/python2.7 /usr/bin/python3'.format(cmd[11:])
                stderr = u''
            else:
                stdout = u'{0}\n{1}\n/usr/bin/python3'
            return dict(stdout=stdout, stderr=stderr)

    # TODO: uncover more cases
    action_obj = MockAction()

# Generated at 2022-06-20 14:07:46.880371
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction(object):
        def __init__(self):
            self._connection = None
            self.module_args = {}
            self.task_vars = {}

        def _low_level_execute_command(self, command, in_data=None, sudoable=None, chdir=None):
            pass

    class MockConnection(object):
        def __init__(self):
            self.has_pipelining = True

    ma = MockAction()
    ma._connection = MockConnection()
    ma.task_vars = {}

    assert discover_interpreter(ma, 'python', 'auto_legacy_silent', ma.task_vars) == '/usr/bin/python'


# Generated at 2022-06-20 14:07:57.760825
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError(
        message="Python discovery error in discover_interpreter()!",
        interpreter_name="python",
        discovery_mode="auto"
    )

    expected = "Python discovery error in discover_interpreter()!"
    assert str(exception) == expected, "Expected: %s, Actual: %s" % (expected, str(exception))
    assert repr(exception) == expected, "Expected: %s, Actual: %s" % (expected, repr(exception))

# Generated at 2022-06-20 14:08:19.057420
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    try:
        raise InterpreterDiscoveryRequiredError(
            "Python interpreter for module python not found",
            "python",
            "auto_silent"
        )

    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == "Python interpreter for module python not found"
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_silent"

# Generated at 2022-06-20 14:08:24.486193
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(
        "Version of Python '2.7' not detected on host 'myhost.example.com'",
        interpreter_name='python',
        discovery_mode='auto_legacy_silent')
    assert repr(str(err)) == repr(err)



# Generated at 2022-06-20 14:08:34.779783
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = "Interpreter discovery required for python"
    assert InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode).interpreter_name == interpreter_name
    assert InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode).discovery_mode == discovery_mode

# Generated at 2022-06-20 14:08:39.138385
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('','python','auto',{'inventory_hostname':'unknown'}) == '/usr/bin/python'
    assert discover_interpreter('','python3','auto',{'inventory_hostname':'unknown'}) == '/usr/bin/python3'

# Generated at 2022-06-20 14:08:44.095336
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'a'
    discovery_mode = 'b'
    message = "c"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode


# Generated at 2022-06-20 14:08:50.069315
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test = InterpreterDiscoveryRequiredError('This is an error', 'python', 'silent')
    assert test.__str__() == test.message



# Generated at 2022-06-20 14:09:02.870886
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''test discovery_interpreter()'''
    try:
        from ansible.plugins.action.normal import ActionModule
    except:
        return

    # TODO: make this less fragile
    if LooseVersion(C.__version__) > LooseVersion("2.5.0"):
        return

    distribution_type_map = {
        "distro": "debian",
        "suse": "sles",
        "redhat": "rhel",
        "ubuntu": "ubuntu",
        "oracle": "oracle",
        "centos": "centos",
    }

    # TODO: instead of hard-coding "python here, get it dynamically from the interpreter lookup table

# Generated at 2022-06-20 14:09:15.264540
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    # Remove if condition and initialization when
    # https://github.com/microsoft/ptvsd/issues/1245 is resolved.
    if False:
        from unittest import mock
        from ansible.module_utils import interpreter_discovery

        interpreter_discovery.InterpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError

    custom_error = InterpreterDiscoveryRequiredError("Test message", "python", "auto")

    custom_error_repr = custom_error.__repr__()

    assert custom_error_repr == "Test message"

# Generated at 2022-06-20 14:09:16.529597
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert error.__repr__() == "message"



# Generated at 2022-06-20 14:09:22.359018
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError("", "", "")
    assert isinstance(e.interpreter_name, object)
    assert isinstance(e.discovery_mode, object)
    assert isinstance(str(e), str)
    # assert isinstance(repr(e), str)

# Generated at 2022-06-20 14:09:57.269031
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.virtual
    orig_platform_dist = ansible.module_utils.facts.system.distribution.platform_dist
    orig_platform_system = ansible.module_utils.facts.system.platform.platform_system
    orig_get_distribution = ansible.module_utils.facts.system.distribution.get_distribution
    orig_get_distribution_version = ansible.module_utils.facts.system.distribution.get_distribution_version
    orig_get_distribution_release = ansible.module_utils.facts.system.distribution.get_distribution_release
    orig_system_info

# Generated at 2022-06-20 14:10:01.665536
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e1 = InterpreterDiscoveryRequiredError('fake', 'fake2', 'fake3')
    assert e1.message == 'fake'
    assert e1.interpreter_name == 'fake2'
    assert e1.discovery_mode == 'fake3'
    assert str(e1) == 'fake'
    assert repr(e1) == 'fake'

# Generated at 2022-06-20 14:10:03.335627
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    sut = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert 'message' == str(sut)

# Generated at 2022-06-20 14:10:17.102951
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TaskVars():
        def __init__(self, task_vars):
            self.task_vars = task_vars
        def get(self, key, default_value):
            return self.task_vars.get(key, default_value)
    class Action():
        def __init__(self, connection, task_vars):
            self._connection = connection
            self._discovery_warnings = []
            self._task_vars = task_vars
        def _low_level_execute_command(self, cmd, sudoable, in_data=None):
            if cmd == 'command -v \'/usr/local/bin/python\'':
                return {'stdout': to_text(u'/usr/local/bin/python\n', errors='surrogate_or_strict')}


# Generated at 2022-06-20 14:10:25.954362
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'some message'
    interpreter_name = 'interpreter name'
    discovery_mode = 'discovery mode'
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    actual = str(interpreter_discovery_required_error)
    assert msg == actual


# Generated at 2022-06-20 14:10:34.789221
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_str = "test str"
    test_interp = "test interp"
    test_discovery_mode = "test discovery_mode"

    e = InterpreterDiscoveryRequiredError(test_str, test_interp, test_discovery_mode)
    assert e.message == test_str
    assert e.interpreter_name == test_interp
    assert e.discovery_mode == test_discovery_mode
    assert str(e) == test_str
    assert repr(e) == test_str

# Generated at 2022-06-20 14:10:38.286505
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert err.__repr__() == 'message'


# Generated at 2022-06-20 14:10:46.115085
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'test'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(exception) == message

# Generated at 2022-06-20 14:10:54.456440
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        "Ansible detected a Python interpreter mismatch of the Python interpreter "
        "used in the current Ansible runtime environment and the one used by the remote host."
        " Please verify the version of Python used by the remote host is at least 2.6.6.",
        "python",
        "auto_legacy"
    )

    str_error = str(error)

    assert str_error == error.message

# Generated at 2022-06-20 14:10:59.617052
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    id_error = InterpreterDiscoveryRequiredError("message", "python", "auto_silent")
    assert id_error.interpreter_name == u"python"
    assert id_error.discovery_mode == u"auto_silent"
    assert id_error.message == u"message"

# Generated at 2022-06-20 14:11:45.272437
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    assert(repr(InterpreterDiscoveryRequiredError(
        message='Test message',
        interpreter_name='python',
        discovery_mode='legacy'
    )))

# Generated at 2022-06-20 14:11:49.188092
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python2'
    discovery_mode = 'auto_legacy_silent'

    err = InterpreterDiscoveryRequiredError(interpreter_name, discovery_mode, discovery_mode)
    assert err.__repr__() == 'python2'


# Generated at 2022-06-20 14:11:53.212579
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
   error = InterpreterDiscoveryRequiredError("An error message", "interpreter_name", "discovery_mode")
   assert str(error) == "An error message"

# Generated at 2022-06-20 14:11:57.766974
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert e.message == 'message'
    assert e.interpreter_name == 'interpreter_name'
    assert e.discovery_mode == 'discovery_mode'

# Generated at 2022-06-20 14:11:58.720601
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert 'message' == str(obj)

# Generated at 2022-06-20 14:12:01.500514
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError("Error", "python", "auto_legacy_silent")
    assert err.__repr__() == 'Error'


# Generated at 2022-06-20 14:12:05.447733
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError(u"my error", u"python", u"silent")
    assert err.message == u"my error"
    assert err.interpreter_name == u"python"
    assert err.discovery_mode == u"silent"
    assert str(err) == u"my error"

# Generated at 2022-06-20 14:12:10.258015
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'unable to discover interpreter for "python"'

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert error.__str__() == message

# Generated at 2022-06-20 14:12:14.743501
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'Message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    result = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert result.__str__() == msg


# Generated at 2022-06-20 14:12:21.526769
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required'

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert isinstance(error, InterpreterDiscoveryRequiredError)
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert error.__str__() == message

# Generated at 2022-06-20 14:13:39.482674
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    x = InterpreterDiscoveryRequiredError("message1", "interpreter_name1", "discovery_mode1")
    assert str(x) == "message1"
    assert repr(x) == "message1"


# Generated at 2022-06-20 14:13:49.978792
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")

    assert error.message == "message"
    assert error.interpreter_name == "interpreter_name"
    assert error.discovery_mode == "discovery_mode"
    assert error.__str__() == "message"
    assert error.__repr__() == "message"

# Generated at 2022-06-20 14:14:02.136063
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockTaskResult:
        def __init__(self, stdout='', stderr=''):
            self.stdout = stdout
            self.stderr = stderr

    class MockExecutor:
        def __init__(self, name):
            self.name = name
            self.has_pipelining = True

    class MockAction:
        def __init__(self):
            self._connection = MockExecutor('connection')
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            return {'stdout': b'', 'stderr': b''}

    class MockTaskVars:
        def __init__(self):
            self.get = lambda *_, **_: None


# Generated at 2022-06-20 14:14:09.143581
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('error', 'python', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'error'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto_legacy_silent'
    finally:
        del e


# Generated at 2022-06-20 14:14:15.158758
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError("foo", "bar", "baz")
    assert "foo" == err.message
    assert "bar" == err.interpreter_name
    assert "baz" == err.discovery_mode
    assert "foo" == str(err)
    assert "foo" == repr(err)


# Generated at 2022-06-20 14:14:22.291064
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python3'
    discovery_mode = 'auto_legacy'

    new_object = InterpreterDiscoveryRequiredError('Unable to find python interpreter for python3', interpreter_name, discovery_mode)
    assert new_object.message == 'Unable to find python interpreter for python3'
    assert new_object.interpreter_name == 'python3'
    assert new_object.discovery_mode == 'auto_legacy'

# Generated at 2022-06-20 14:14:31.213636
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Create instance of class InterpreterDiscoveryRequiredError
    interpreter_name = "python"
    discovery_mode = "auto"
    interpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError("The error", interpreter_name, discovery_mode)

    # Test method __str__
    assert str(interpreterDiscoveryRequiredError) == interpreterDiscoveryRequiredError.message

    # Test attribute interpreter_name
    assert interpreter_name == interpreterDiscoveryRequiredError.interpreter_name

    # Test attribute discovery_mode
    assert discovery_mode == interpreterDiscoveryRequiredError.discovery_mode

# Generated at 2022-06-20 14:14:32.904989
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    assert InterpreterDiscoveryRequiredError("message", "python", "auto").__str__() == "message"

# Generated at 2022-06-20 14:14:48.021004
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Define some test variables
    vars = {
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_python_interpreter_discovery_mode': 'auto_legacy',
        'ansible_connection': 'ssh',
        'ansible_host': 'example.com',
        'ansible_user': 'example',
        'ansible_ssh_executable': '/usr/bin/ssh',
        'ansible_ssh_extra_args': '-C -o ControlMaster=auto -o ControlPersist=60s',
        'ansible_ssh_common_args': '',
    }

    # Define a connection plugin
    class MockConnection(object):
        def __init__(self):
            pass

        def has_pipelining(self):
            return True



# Generated at 2022-06-20 14:14:52.970037
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('test','test','test')
    assert err.__str__() == 'test'
    assert err.__repr__() == 'test'


# Unit test to check _get_linux_distro with empty dictionary
# INPUT:
#       platform_info : dictionary with keys 'platform_dist_result, osrelease_content' and values as empty list,
#                       empty list respectively
# EXPECTED RESULT:
#       return empty strings