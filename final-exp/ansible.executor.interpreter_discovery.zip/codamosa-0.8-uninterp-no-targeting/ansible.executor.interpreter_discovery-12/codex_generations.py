

# Generated at 2022-06-20 14:05:25.385636
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter = 'python'
    discovery_mode = 'auto'
    exception = InterpreterDiscoveryRequiredError('test exception', interpreter, discovery_mode)
    assert exception.interpreter_name == interpreter
    assert exception.discovery_mode == discovery_mode
    assert exception.message == 'test exception'
    assert str(exception) == 'test exception'



# Generated at 2022-06-20 14:05:29.196976
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    actual = InterpreterDiscoveryRequiredError(u"test_msg", u"test_interpreter_name", u"test_discovery_mode")
    assert repr(actual) == u"test_msg"



# Generated at 2022-06-20 14:05:32.869434
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto_silent"
    message = "For python, discovery mode auto_silent is not valid."

    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert repr(ex) == message

# Generated at 2022-06-20 14:05:34.556991
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError('Sample message', 'python', 'auto')
    assert ex.__str__() == 'Sample message'



# Generated at 2022-06-20 14:05:43.367252
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action_data = {}
    action_data["action_type"] = "command"
    action_data["sudo"] = False
    action_data["sudo_user"] = "root"
    action_data["connection"] = "network_cli"
    action_data["module_name"] = None
    action_data["module_args"] = None
    action_data["_original_basename"] = "command"
    action_data["_uses_shell"] = False
    action_data["_raw_params"] = None
    action_data["_ansible_version"] = "2.4.0.0"

# Generated at 2022-06-20 14:05:48.462241
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required but not enabled'

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:06:01.095427
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible import context
    from ansible.plugins.loader import action_loader

    # TODO: run this test multiple times with different fallback lists to verify that we're not just falling back to the one Python

    # TODO: load a system-specific py_target.py file rather than the generic one

    # TODO: set a different INTERPRETER_PYTHON_DISTRO_MAP to test versions which aren't exact matches

    # TODO: unit test with vars that should trigger auto_legacy (and make sure it warns as it should)

    # TODO: test with a system that doesn't provide any target Pyt

# Generated at 2022-06-20 14:06:06.956903
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = u"interpreter discovery is required for python"
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == message
        assert ex.interpreter_name == interpreter_name
        assert ex.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:06:12.793091
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Unit test for method __repr__ of class InterpreterDiscoveryRequiredError."""
    message = "Python interpreter discovery is required"
    interpreter_name = "python"
    discovery_mode = "auto"

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert repr(exception) == "Python interpreter discovery is required"

# Generated at 2022-06-20 14:06:17.607053
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert exc.args[0] == 'message'
    assert exc.interpreter_name == 'python'
    assert exc.discovery_mode == 'auto'


# Generated at 2022-06-20 14:06:34.682234
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object()
    action._discovery_warnings = []
    task_vars = dict(
        ansible_python_interpreter=u'/usr/bin/python',
        ansible_python_version=u'2.7.5',
    )

    res = discover_interpreter(action, 'python', 'auto', task_vars)

    assert action._discovery_warnings == []
    assert res == u'/usr/bin/python'

    # test a system with no python
    action = object()
    action._discovery_warnings = []

# Generated at 2022-06-20 14:06:46.943558
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.errors import AnsibleError
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    interpreter_name = 'python'
    discovery_mode = 'auto'
    # gather_facts must be off here to guarantee we don't accidentally
    # pick up a real Python interpreter for localhost.
    # gather_facts currently only affects localhost, not remote hosts.
    gather_facts = boolean(discovery_mode != 'explicit')
    task_vars = VariableManager(loader=None, inventory=InventoryManager(loader=None, sources=[]))

# Generated at 2022-06-20 14:06:51.407029
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert repr(
        InterpreterDiscoveryRequiredError(
            "interpreter discovery failed for 'python' on host hostname",
            'python',
            'auto_legacy'
        )
    ) == "interpreter discovery failed for 'python' on host hostname"


# Generated at 2022-06-20 14:06:56.577784
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError(message='test_message',
                                            interpreter_name='test_interpreter_name',
                                            discovery_mode='test_discovery_mode')

    assert exc.__repr__() == 'test_message'


# Generated at 2022-06-20 14:07:09.365551
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_message = u"The interpreter {0} is not available on this system and the required interpreter discovery " \
                    u"mode {1} has not been configured. See {2} for more " \
                    u"information".format(u'python2.7', u'auto_legacy',
                                          get_versioned_doclink('reference_appendices/interpreter_discovery.html'))
    interpreter_name = u'python2.7'
    discovery_mode = u'auto_legacy'
    ex = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)

    # Test that the message has been set
    assert ex.message == error_message

    # Test that the interpreter_name has been set
    assert ex.interpreter_name == interpreter_name

    # Test that the discovery_

# Generated at 2022-06-20 14:07:19.817396
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Raise an exception of class InterpreterDiscoveryRequiredError
    msg = "interpreter discovery required"
    interpreter_name = 'python'
    discovery_mode = ''
    raised_exception = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert raised_exception
    assert raised_exception.message == msg
    assert raised_exception.interpreter_name == interpreter_name
    assert raised_exception.discovery_mode == discovery_mode
    assert str(raised_exception) == msg
    assert repr(raised_exception) == msg


# Generated at 2022-06-20 14:07:31.070759
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    from ansible.plugins.action.normal import ActionModule as ActionNormalModule

    # need to work on a copy because the default impl uses data that changes each run
    # TODO: improve unit test so the default implementation doesn't have to be changed
    def_platform_python_map = C.config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP', variables={})

# Generated at 2022-06-20 14:07:39.026336
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = ('Interpreter discovery required for {0} interpreter, but discovery mode {1} does not support '
               'it.'.format(interpreter_name, discovery_mode))
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.message == message
    assert err.interpreter_name == interpreter_name
    assert err.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:07:46.793659
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = "Python interpreter discovery is required, but discovery mode 'auto_legacy_silent' failed to find it"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode



# Generated at 2022-06-20 14:07:53.084628
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement -- obviously we can't just call the function directly since it's part of an action plugin's
    #       "module" path, but we can mock out the class instantiation, etc
    pass

# Generated at 2022-06-20 14:08:09.974010
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Interpreter discovery required on host 'tests.example.com', " \
              "specify one of: interpreter_python=/usr/bin/python3, interpreter_python=/usr/bin/python2, "\
              "interpreter_python=/usr/bin/python, interpreter_python=/usr/bin/python2-is-python3"
    action = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name,
                                               discovery_mode=discovery_mode)
    assert action.__repr__() == message


# Generated at 2022-06-20 14:08:14.646835
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto'

# Generated at 2022-06-20 14:08:26.405073
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Python 2.6 and Python 2.7 are intentionally not in the list.
    # This tests that we fall back to /usr/bin/python as the default fallback.
    # For example, if an Ubuntu 18.04 system has both Python 2.6 and Python 2.7 installed,
    # we'd want the final target to be the first Python 3, which should be /usr/bin/python3
    stdout = """PLATFORM
Linux
FOUND
/usr/bin/python
/usr/bin/python3
ENDFOUND
"""
    action = object()
    action._discovery_warnings = []
    action._low_level_execute_command = lambda cmd, **kwargs: {'stdout': stdout}
    action._connection = object()
    action._connection.has_pipelining = True

# Generated at 2022-06-20 14:08:36.123279
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import fragment_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor

    class Options(object):
        def __init__(self):
            self.connection = "local"
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None
            self.module_path = None
           

# Generated at 2022-06-20 14:08:39.323609
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('message', 'python', 'auto_silent')
    assert err.__repr__() == 'message'

# Generated at 2022-06-20 14:08:44.546667
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test calling constructor of class InterpreterDiscoveryRequiredError with a valid interpreter name and discovery mode
    try:
        raise InterpreterDiscoveryRequiredError("Test message", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto"


# Generated at 2022-06-20 14:08:50.807824
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    # Test for creating instance of InterpreterDiscoveryRequiredError class
    t1 = InterpreterDiscoveryRequiredError("Test Message", "python", "auto")

    # Test for type of class InterpreterDiscoveryRequiredError
    assert isinstance(t1, InterpreterDiscoveryRequiredError)
    # Test for type of 'message' attribute of class InterpreterDiscoveryRequiredError
    assert isinstance(t1.message, str)
    # Test for value of 'message' attribute of class InterpreterDiscoveryRequiredError
    assert t1.message == "Test Message"
    # Test for type of 'interpreter_name' attribute of class InterpreterDiscoveryRequiredError
    assert isinstance(t1.interpreter_name, str)
    # Test for value of 'interpreter_name' attribute of class InterpreterDiscoveryRequiredError

# Generated at 2022-06-20 14:08:55.483433
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_error = InterpreterDiscoveryRequiredError(
        message="This is a message", interpreter_name="python", discovery_mode="auto")

    assert str(interpreter_discovery_error) == 'This is a message'

# Generated at 2022-06-20 14:08:58.121926
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    assert str(error) == 'test'



# Generated at 2022-06-20 14:09:07.491742
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = Display()
    interpreter_name = 'python'

    task_vars = C.initialize()
    task_vars['ansible_python_interpreter'] = '/usr/bin/python2.7'
    discovery_mode = 'auto_legacy_silent'
    print("Running unit test for python interpreter discovery on {0} with {1}".format(interpreter_name, discovery_mode))
    print("")
    print("Test 1:")
    print("Expected Result: /usr/bin/python2.7\n")
    print("Result: {}\n".format(discover_interpreter(action, interpreter_name, discovery_mode, task_vars)))
    print("Test 2:")
    print("Expected Result: None\n")

# Generated at 2022-06-20 14:09:35.732430
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = u'python'
    discovery_mode = u'auto'
    message = u'Attempt to use {0} interpreter with {1} discovery mode'.format(interpreter_name, discovery_mode)
    e = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert e.__repr__() == 'Attempt to use python interpreter with auto discovery mode'



# Generated at 2022-06-20 14:09:43.564154
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys
    import os
    my_test_path = os.path.join(os.path.dirname(__file__), 'test_data')
    sys.path.insert(0, my_test_path)
    from test_action import ActionBase, HostVars
    from test_connection import Connection
    class TestAction(ActionBase):
        _connection = Connection

    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = HostVars()
    task_vars.update(ActionBase._task_vars)
    action = TestAction()

    interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    assert interpreter == '/usr/bin/python'

# Generated at 2022-06-20 14:09:45.468210
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    class_test = InterpreterDiscoveryRequiredError ( "message", "interpreter_name", "discovery_mode" )
    assert class_test.__repr__() == "message"
    

# Generated at 2022-06-20 14:09:48.355502
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert repr(InterpreterDiscoveryRequiredError('test message', 'python', 'auto')) == 'test message'


# Generated at 2022-06-20 14:09:53.125204
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # define an argument list
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = "Testing error message"

    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert ex.__repr__() == message

# Generated at 2022-06-20 14:09:58.742028
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "This is a message"
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    idre = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert idre.message == message
    assert idre.interpreter_name == interpreter_name
    assert idre.discovery_mode == discovery_mode

# Generated at 2022-06-20 14:10:04.383767
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_message = 'Interpreter Discovery Required'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    error_message_check = error.message == error_message
    interpreter_name_check = error.interpreter_name == interpreter_name
    discovery_mode_check = error.discovery_mode == discovery_mode
    assert(error_message_check and interpreter_name_check and discovery_mode_check)


# Generated at 2022-06-20 14:10:11.721673
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Interpreter Discovery Required", "python", "auto_legacy_silent")
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == "Interpreter Discovery Required"
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_legacy_silent"

# Generated at 2022-06-20 14:10:23.192674
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    for interpreter_name in ['python', 'python3']:
        for discovery_mode in ['auto_legacy', 'auto_legacy_silent', 'auto', 'auto_silent', 'manual', 'manual_silent']:
            error = InterpreterDiscoveryRequiredError('message', interpreter_name, discovery_mode)
            assert repr(error) == str(error)


# TODO: TESTS
#
# 1 - we should test default interpreter discovery fallback
# 2 - we should test parsing platform_dist_result
# 3 - we should test parsing os-release
# 4 - we should test version_fuzzy_match
# 5 - we should test get_linux_distro
# 6 - we should test that _version_fuzzy_match throws when it fails to find a version match
# 7 - we should test that get

# Generated at 2022-06-20 14:10:31.386281
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils._text import to_bytes
    import json

    # pylint: disable=unused-variable
    def _low_level_execute_command(self, command, sudoable=True, in_data=None):
        if command == "command -v 'python'":
            # python 3.2 default
            output = u"/usr/bin/python"
        elif command == "command -v 'python3'":
            # python 3.6 default
            output = u"/usr/bin/python3"
        elif command == "command -v 'python2'":
            # python 2.6 default
            output = u"/usr/bin/python2"

# Generated at 2022-06-20 14:11:13.145145
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = 2
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'

    # No task_vars
    task_vars = {}
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except Exception as ex:
        print(ex)
        assert 'config_file' in to_text(ex)

    # Empty task_vars
    task_vars = {
        'config_file': 'fake_config_file',
        '_ansible_remote_tmp': 'fake_ansible_remote_tmp',
        'ansible_env': {},
        'inventory_hostname': 'fake_inventory_hostname'
    }

# Generated at 2022-06-20 14:11:16.735065
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError(
        message='test', interpreter_name='python', discovery_mode='auto_legacy_silent'
    )
    assert str(obj) == 'test'


# Generated at 2022-06-20 14:11:25.511639
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.template import Templar
    from ansible import context
    from ansible.plugins.loader import action_loader

    task_vars = {}
    display = Display()
    display.verbosity = 4
    context.CLIARGS = {'verbosity': 5}
    task_data = {}
    task_data['task'] = {}
    task_data['task']['args'] = dict(python=u'/usr/bin/python')

    action_instance = action_loader.get('python')

# Generated at 2022-06-20 14:11:34.957919
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        # This is required as execute_module raises ansible.utils.unsafe_proxy.AnsibleUnsafeText when it is called on
        # python 3.
        def to_safe(self, value):
            return to_text(value)

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None, executable=None):
            if cmd.startswith('command -v'):
                # We're only doing this for testing, so no need to make it properly cross-platform
                return {'stdout': u'', 'stderr': u''}

# Generated at 2022-06-20 14:11:41.462263
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, action, connection, play_context, loader, templar, shared_loader_obj, **kwargs):
            self._low_level_execute_command = action._low_level_execute_command
            self._loader = loader
            self._socket_path = kwargs['socket_path']
            self._connection = connection
            self._play_context = play_context
            self._task_vars = dict()
            self._tqm = kwargs.get('tqm')
            self._discovery_warnings = list()
            self._shared_loader_obj = shared_loader_obj
            self._options = kwargs.get('options')

# Generated at 2022-06-20 14:11:48.044402
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err_msg = 'only python interpreter can be discovered'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    err = InterpreterDiscoveryRequiredError(err_msg, interpreter_name, discovery_mode)
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'auto'



# Generated at 2022-06-20 14:11:55.851675
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ok = False
    msg = "Test message"
    interp_name = 'python'
    mode = 'auto'
    try:
        raise InterpreterDiscoveryRequiredError(msg, interp_name, mode)
    except Exception as e:
        ok = True

    assert ok
    assert msg == repr(e)
    assert msg == str(e)
    assert interp_name == e.interpreter_name
    assert mode == e.discovery_mode



# Generated at 2022-06-20 14:12:01.840451
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = Exception(message="test_message")
    class_name = 'InterpreterDiscoveryRequiredError'
    interpreter_name = "python"
    discovery_mode = "auto"
    error = InterpreterDiscoveryRequiredError(exception, interpreter_name, discovery_mode)
    result = str(error)
    assert class_name in result and interpreter_name in result and discovery_mode in result

# Generated at 2022-06-20 14:12:04.282972
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError("message", "python", "legacy_silent")
    assert 'message' == str(err)


# Generated at 2022-06-20 14:12:07.210495
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'test_msg'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    try:
        raise InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert repr(e) == msg

# Generated at 2022-06-20 14:12:38.634844
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    assert str(InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')) == 'message'


# Generated at 2022-06-20 14:12:47.677355
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    import tempfile

    def _write_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

    def _write_python_target_script(path, content):
        _write_file(path, '#!%s\n' % sys.executable + content)


# Generated at 2022-06-20 14:12:51.662591
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError("message", "interpreter", "discovery_mode")
    assert interpreter_discovery_required_error.__repr__() == "message"

# Generated at 2022-06-20 14:12:56.682118
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError(
        message='test_message',
        interpreter_name='test_interpreter_name',
        discovery_mode='test_discovery_mode'
    )
    assert obj.__str__() == 'test_message'


# Generated at 2022-06-20 14:13:00.329052
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError("Error message", "python", "auto_silent")
    result = exception.__repr__()
    assert result == exception.message


# Generated at 2022-06-20 14:13:04.863058
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    inter_name = "python"
    disc_mode = "auto"
    error_msg = "Interpreter Discovery Required"
    error_obj = InterpreterDiscoveryRequiredError(error_msg, inter_name, disc_mode)
    assert error_obj.message == error_msg
    assert error_obj.interpreter_name == inter_name
    assert error_obj.discovery_mode == disc_mode



# Generated at 2022-06-20 14:13:10.341101
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'Failed: The path to the desired interpreter was not specified'
    interpreter_name = 'python'
    discovery_mode = 'auto'

    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert repr(error) == msg

# Generated at 2022-06-20 14:13:17.389124
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    display = Display()

    try:
        raise InterpreterDiscoveryRequiredError('Python Interpreter Discovery is required for python for host localhost', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as exc:
        display.vvv(to_text(exc))
        display.vvv(u"Expected Results:\n"
                    u"Python Interpreter Discovery is required for python for host localhost",
                    host='localhost')

# Generated at 2022-06-20 14:13:21.475342
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('msg','interpreter','mode')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'interpreter'
        assert e.discovery_mode == 'mode'
        assert str(e) == 'msg'
        assert repr(e) == 'msg'

# Generated at 2022-06-20 14:13:23.334476
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("error", "python", "auto_legacy")
    assert repr(error) == "error"



# Generated at 2022-06-20 14:14:26.478255
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.action_buffer import ActionBuffer
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    import os

    # mock task action

# Generated at 2022-06-20 14:14:34.001748
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {}
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    display.verbosity = 4

    try:
        interpreter_path = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        print("\ninterpreter_path: " + interpreter_path)
    except InterpreterDiscoveryRequiredError as e:
        print("\ninterpreter_path: " + str(e))

# run test function for function discover_interpreter
test_discover_interpreter()

# Generated at 2022-06-20 14:14:42.048666
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """test case for __repr__ method"""
    message = 'test message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(error) == message

# Generated at 2022-06-20 14:14:49.532912
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # python3-only modules
    with pytest.raises(TypeError):
        test_exception = InterpreterDiscoveryRequiredError("message", "python3", "auto")
    test_exception = InterpreterDiscoveryRequiredError("message", "python2", "auto")
    assert(test_exception.__str__() == "message")

    # python3-only modules
    test_exception = InterpreterDiscoveryRequiredError("message", "python3", "auto")
    assert(test_exception.__str__() == "message")

# Generated at 2022-06-20 14:14:51.513690
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError('foo bar', 'python', 'auto')
    assert str(ex) == 'foo bar'

# Generated at 2022-06-20 14:14:54.836231
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    try:
        raise InterpreterDiscoveryRequiredError("message", interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode

# Test of _get_linux_distro()