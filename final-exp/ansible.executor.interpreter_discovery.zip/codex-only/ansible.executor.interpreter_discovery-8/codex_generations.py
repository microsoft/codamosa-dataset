

# Generated at 2022-06-22 19:54:05.770550
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    mye = InterpreterDiscoveryRequiredError("This is a test", "python", "auto")
    print(mye)
    print(repr(mye))

# Generated at 2022-06-22 19:54:09.197771
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: more tests
    assert discover_interpreter(None, 'python', 'auto', dict()) == u'/usr/bin/python'

# Generated at 2022-06-22 19:54:11.299032
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert str(ex) == 'message'

# Generated at 2022-06-22 19:54:15.282615
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    actual_output = repr(InterpreterDiscoveryRequiredError(u'', u'', u''))
    expected_output = u''
    found = actual_output.endswith(expected_output)
    assert found, 'Expected {}, but got {}'.format(expected_output, actual_output)

# Generated at 2022-06-22 19:54:19.875150
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = "e"
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_discovery_required_error.__repr__() == message


# Generated at 2022-06-22 19:54:24.071023
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError('foo', 'bar', 'baz')
    assert exc.message == 'foo'
    assert exc.interpreter_name == 'bar'
    assert exc.discovery_mode == 'baz'

# Generated at 2022-06-22 19:54:27.147628
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required'

    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert message == obj.__str__()

# Generated at 2022-06-22 19:54:31.224630
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy")
    assert error.message == "message"
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto_legacy"

# Generated at 2022-06-22 19:54:38.504111
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:54:43.920278
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_msg = "Test Message"
    interpreter_name = "python"
    discovery_mode = "auto"

    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)

    assert interpreter_discovery_required_error.__repr__() == error_msg


# Generated at 2022-06-22 19:54:45.210349
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement
    pass

# Generated at 2022-06-22 19:54:56.674302
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = "Interpreter discovery required"
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert message in str(e)
        assert interpreter_name in str(e)
        assert discovery_mode in str(e)
        message = str(e)

    interpreter_name = 'python3'
    discovery_mode = 'auto'
    msg = "Interpreter discovery required: python3 using auto mode"
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert msg in str(e)
        assert interpreter_name in str

# Generated at 2022-06-22 19:55:06.136421
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    cls_attr_interpreter_name = 'python'
    cls_attr_discovery_mode = 'auto'
    msg = "test exception"

    test_obj = InterpreterDiscoveryRequiredError(message=msg, interpreter_name=cls_attr_interpreter_name, discovery_mode=cls_attr_discovery_mode)
    assert test_obj.message == msg
    assert test_obj.interpreter_name == cls_attr_interpreter_name
    assert test_obj.discovery_mode == cls_attr_discovery_mode
    assert str(test_obj) == msg

# Generated at 2022-06-22 19:55:13.054422
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    display_message = 'This is a display message'
    interpreter_name = 'This is an interpreter name'
    discovery_mode = 'This is a discovery mode'
    e = InterpreterDiscoveryRequiredError(display_message, interpreter_name, discovery_mode)

    # call method __repr__
    result = e.__repr__()

    assert result == display_message


# Generated at 2022-06-22 19:55:16.069693
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'this is a message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    result = error.__str__()
    assert result == message


# Generated at 2022-06-22 19:55:18.113304
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    InterpreterDiscoveryRequiredError("test message", "test_interpreter", "test_mode")


# Generated at 2022-06-22 19:55:23.292201
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    assert InterpreterDiscoveryRequiredError('the message', 'the interpreter', 'the discovery mode').__str__() == 'the message'
    assert InterpreterDiscoveryRequiredError('the message', 'the interpreter', 'the discovery mode').__repr__() == 'the message'

# Generated at 2022-06-22 19:55:35.069051
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message1 = "InterpreterDiscoveryRequiredError: python interpreter discovery is required for this host"
    message2 = "InterpreterDiscoveryRequiredError: ruby interpreter discovery is required for this host"
    interpreter_name1 = "python"
    interpreter_name2 = "ruby"
    discovery_mode1 = "auto"
    discovery_mode2 = "auto_legacy"
    e1 = InterpreterDiscoveryRequiredError(message1, interpreter_name1, discovery_mode1)
    assert e1.message == message1
    assert e1.interpreter_name == interpreter_name1
    assert e1.discovery_mode == discovery_mode1
    e2 = InterpreterDiscoveryRequiredError(message2, interpreter_name2, discovery_mode2)
    assert e2.message == message2
    assert e2.interpre

# Generated at 2022-06-22 19:55:46.523924
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from units.mock.loader import DictDataLoader

    # Mock
    task_vars = HostVars({
        "inventory_hostname": "mock_hostname"
    })

    # Mock
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_

# Generated at 2022-06-22 19:55:59.293641
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible_collections.ansible.misc.tests.unit.compat.mock import patch
    from ansible.executor.module_common import CachingModuleExecutor

    with patch('ansible.module_utils.common.run_command', return_value=dict(stdout='/usr/bin/python', stderr='')):
        with patch('ansible.module_utils.distro.LinuxDistribution._parse_os_release', return_value=dict(id='rhel', version_id='7.5')):
            m = CachingModuleExecutor()
            assert u'/usr/bin/python' == discover_interpreter(m, 'python', 'auto', dict(ansible_distribution='rhel', ansible_distribution_version='7.5'))

# Generated at 2022-06-22 19:56:03.876357
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    # Arrange
    error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')

    # Act
    value = error.__repr__()

    # Assert
    assert value == 'message'



# Generated at 2022-06-22 19:56:10.245307
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = u'python'
    discovery_mode = u'auto_legacy_silent'
    message = 'Python interpreter discovery required for auto_legacy_silent'
    result = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert result.__str__() == 'Python interpreter discovery required for auto_legacy_silent'
    assert result.interpreter_name == u'python'
    assert result.discovery_mode == u'auto_legacy_silent'

# Generated at 2022-06-22 19:56:19.250928
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'

    ex = InterpreterDiscoveryRequiredError(
        'Interpreter discovery required', interpreter_name, discovery_mode)
    expected = 'Interpreter discovery required'
    msg = 'Derived class __str__ method should call superclass __str__ method'
    assert ex.__str__() == expected, msg

    ex = InterpreterDiscoveryRequiredError(
        'Interpreter discovery required', interpreter_name, discovery_mode)
    expected = 'Interpreter discovery required'
    msg = 'Derived class __repr__ method should call superclass __str__ method'
    assert ex.__repr__() == expected, msg



# Generated at 2022-06-22 19:56:22.131198
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError('msg', 'python', 'auto')
    assert str(exc) == 'msg'


# Generated at 2022-06-22 19:56:25.441274
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    assert str(InterpreterDiscoveryRequiredError('test_message', 'python', 'auto_legacy_silent')) == 'test_message'
    assert repr(InterpreterDiscoveryRequiredError('test_message', 'python', 'auto_legacy_silent')) == 'test_message'


# Generated at 2022-06-22 19:56:27.043697
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # TODO: impl; test should match repr() output
    pass


# Generated at 2022-06-22 19:56:39.029178
# Unit test for function discover_interpreter
def test_discover_interpreter():
    simple_discovery_output = """PLATFORM
Linux
FOUND
/usr/bin/python3.6
/usr/bin/python3
/usr/bin/python2
/usr/bin/python
/usr/bin/python2.7
ENDFOUND"""
    result_version_map = {'distro': 'Ubuntu', 'version': '18.04', 'interpreter': '/usr/bin/python3.6'}
    res = _parse_discovery_output(simple_discovery_output)
    assert res == result_version_map


# Generated at 2022-06-22 19:56:43.115782
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    name = 'python'
    mode = 'auto'
    err = InterpreterDiscoveryRequiredError('Interpreter discovery required', name, mode)
    assert err.interpreter_name == name
    assert err.discovery_mode == mode


# Generated at 2022-06-22 19:56:46.967173
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from ansible.module_utils.common.removed import removed_class
    item = InterpreterDiscoveryRequiredError(
        "message",
        interpreter_name="interpreter_name",
        discovery_mode="discovery_mode",
    )
    with pytest.raises(removed_class):
        repr(item)

# Generated at 2022-06-22 19:56:57.210284
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.action.discovery
    platform_python_map = ansible.plugins.action.discovery.get_platform_python_map()
    bootstrap_python_list = ansible.plugins.action.discovery.get_bootstrap_python_list()

    task_vars = {}
    action = None
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    # platform_script = pkgutil.get_data('ansible.executor.discovery', 'python_target.py')
    # _get_linux_distro()
    # _version_fuzzy_match()
    print(discover_interpreter(action, interpreter_name, discovery_mode, task_vars))

# Generated at 2022-06-22 19:57:01.251854
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = u'python'
    discovery_mode = u'auto'

    message = u'interpreter_name {0} discovery_mode {1}'\
        .format(interpreter_name, discovery_mode)

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # The implementation creates the string representation of the error 
    # by returning the message member of the exception.
    assert message == repr(error)

# Generated at 2022-06-22 19:57:03.748004
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError(
        message='Interpreter discovery is required for this task for the interpreter python',
        interpreter_name='python',
        discovery_mode='auto'
    )
    assert err.message == 'Interpreter discovery is required for this task for the interpreter python'

# Generated at 2022-06-22 19:57:08.782513
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_run = 'test_run'
    test_interpreter_name = 'test_interpreter_name'
    test_discovery_mode = 'test_discovery_mode'
    e = InterpreterDiscoveryRequiredError(test_run, test_interpreter_name, test_discovery_mode)
    assert e.__str__()

# Generated at 2022-06-22 19:57:21.012185
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv)

    action = TaskExecutor(play=None, new_stdin='', option_list=[], variable_manager=variable_manager, loader=loader,
                          passwords={})


# Generated at 2022-06-22 19:57:23.125664
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert repr(exception) == 'message'


# Generated at 2022-06-22 19:57:28.217998
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert error.message == 'message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto_legacy_silent'
# end of test_InterpreterDiscoveryRequiredError

# Generated at 2022-06-22 19:57:32.861565
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'test_msg'
    interpreter_name = 'python'
    discovery_mode = 'test_discovery_mode'
    expected = 'test_msg'
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert str(interpreter_discovery_required_error) == expected

# Generated at 2022-06-22 19:57:39.446510
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'msg'
    interpreter_name = 'python3'
    discovery_mode = 'auto_legacy_silent'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.__str__() == 'msg'
    assert err.interpreter_name == 'python3'
    assert err.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-22 19:57:43.057794
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError(message=u'Test', interpreter_name='python',
                                            discovery_mode='auto_legacy_silent')
    assert exc.__repr__() == exc.message


# Generated at 2022-06-22 19:57:46.505456
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    idr = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy')
    assert str(idr) == 'message'
    assert repr(idr) == 'message'


# Generated at 2022-06-22 19:57:52.253950
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = 'failed interpreter discovery'

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except Exception as ex:
        assert ex.interpreter_name == interpreter_name, 'failed interpreter discovery should have interpreter name'
        assert ex.discovery_mode == discovery_mode, 'failed interpreter discovery should have discovery mode'
        assert ex.message == message, 'failed interpreter discovery should have message'

# Generated at 2022-06-22 19:58:00.535370
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
   """
   Test InterpreterDiscoveryRequiredError()
   """
   with pytest.raises(InterpreterDiscoveryRequiredError) as exc_info:
       raise InterpreterDiscoveryRequiredError(message="test message", interpreter_name="python", discovery_mode="auto")
   assert exc_info.type is InterpreterDiscoveryRequiredError
   assert str(exc_info.value) == "test message"
   assert exc_info.value.interpreter_name == "python"
   assert exc_info.value.discovery_mode == "auto"

# Generated at 2022-06-22 19:58:12.985468
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule
    action = ActionModule(None, None, None)

    class FakeConnection(object):
        def __init__(self, has_pipelining=False):
            super(FakeConnection, self).__init__()
            self._has_pipelining = has_pipelining

        @property
        def has_pipelining(self):
            return self._has_pipelining

    # test that we get the interpreter we expect from /etc/os-release, given various supported os id's and versions
    # test that we return None if we can't determine what the interpreter should be and silent_discovery is on
    # test that we raise InterpreterDiscoveryRequiredError if we can't determine what the interpreter should be and
    #   silent_discovery is off
    os_release_inputs

# Generated at 2022-06-22 19:58:17.565439
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError(
        'message',
        interpreter_name='python2',
        discovery_mode='silent')
    assert interpreterDiscoveryRequiredError.__repr__() == "message"


# Generated at 2022-06-22 19:58:22.039635
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    res = obj.__str__()
    assert res == 'message'
    assert res is not obj.message


# Generated at 2022-06-22 19:58:27.410930
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test = InterpreterDiscoveryRequiredError('test message', 'test interpreter', 'test discovery mode')
    assert test.message == 'test message'
    assert test.interpreter_name == 'test interpreter'
    assert test.discovery_mode == 'test discovery mode'
    assert test.__str__() == 'test message'
    assert test.__repr__() == 'test message'

# Generated at 2022-06-22 19:58:35.556539
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_msg = u'This is the error message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    assert error.message == error_msg
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert str(error) == error_msg
    assert repr(error) == error_msg

# Generated at 2022-06-22 19:58:39.154182
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError(message='msg', interpreter_name='foo', discovery_mode='bar')
    assert obj.__str__() == obj.message
    assert obj.__str__() == obj.message == 'msg'

# Generated at 2022-06-22 19:58:42.969039
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_msg = "test message"
    test = InterpreterDiscoveryRequiredError(test_msg, "python", "auto_legacy_silent")
    assert test.__repr__() == test_msg



# Generated at 2022-06-22 19:58:55.150969
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    dummy_task_vars = None
    dummy_action_module = None

    # test that this exception is constructed correctly
    try:
        discover_interpreter(dummy_action_module, 'python', 'auto_legacy_silent', dummy_task_vars)
    except InterpreterDiscoveryRequiredError as ex:
        test_message = "Cannot run a script when interpreter discovery is required. Please use the setup module."
        assert ex.message == test_message
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto_legacy_silent'

    # test other string representation functions

# Generated at 2022-06-22 19:58:57.672467
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert repr(err) == 'message'

# Generated at 2022-06-22 19:58:59.718736
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(u'Error', u'error', "error")
    assert err.__repr__() == 'Error'

# Generated at 2022-06-22 19:59:03.851264
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_discovery_required = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert interpreter_discovery_required.interpreter_name == 'interpreter_name'
    assert interpreter_discovery_required.discovery_mode == 'discovery_mode'

# Generated at 2022-06-22 19:59:06.515719
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = "Interpreter Discovery is Required"
    interpreter_name = "Python"
    discovery_mode = "force_interpreter_discovery"

    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)

    assert error.__str__() == error_message


# Generated at 2022-06-22 19:59:11.837557
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Interpreter discovery is required for host test-host."

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    new_message = str(exception)

    assert new_message == message

# Generated at 2022-06-22 19:59:15.775278
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_inst = InterpreterDiscoveryRequiredError("interpreter_name", "discovery_mode")

    assert error_inst.interpreter_name == "interpreter_name"
    assert error_inst.discovery_mode == "discovery_mode"



# Generated at 2022-06-22 19:59:19.062058
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ex = InterpreterDiscoveryRequiredError("message", "interpreter", "discovery")

    result = repr(ex)
    assert result == "message"


# Generated at 2022-06-22 19:59:24.475864
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test = InterpreterDiscoveryRequiredError("message", "python2", "auto")
    assert test.message == "message"
    assert test.interpreter_name == "python2"
    assert test.discovery_mode == "auto"


# Generated at 2022-06-22 19:59:28.040400
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {}
    try:
        assert discover_interpreter(None, 'python', 'auto', task_vars) is not None
    except Exception as e:
        raise Exception('test_discover_interpreter failed: ' + str(e))

# Generated at 2022-06-22 19:59:31.502567
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    discovery_mode = 'auto'
    interpreter_name = 'python'
    message = 'test message'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.__repr__() == message

# Generated at 2022-06-22 19:59:35.352406
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-22 19:59:41.273866
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        message = 'Test Message'
        interpreter_name = 'python'
        discovery_mode = 'auto'

        exc = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
        assert repr(exc) == 'Test Message'
    except:
        assert False

# Generated at 2022-06-22 19:59:51.887215
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Unit test function discover_interpreter
    """
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestActionModule(object):
        def __init__(self, *args, **kwargs):
            self._task = kwargs.pop('task')
            self._connection = kwargs.pop('connection')
            super(TestActionModule, self).__init__(*args, **kwargs)

        def run(self, *args, **kwargs):
            return self._task.action

        def _execute_module(self):
            return self._task.action

        def _execute_module_with_retries(self):
            return self

# Generated at 2022-06-22 19:59:59.724277
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """unit test for __str__ method of class InterpreterDiscoveryRequiredError"""
    class TestInterpreterDiscoveryRequiredError(InterpreterDiscoveryRequiredError):
        def __init__(self):
            super(TestInterpreterDiscoveryRequiredError, self).__init__(
                u'error message', u'python', u'auto_legacy_silent')

    err = TestInterpreterDiscoveryRequiredError()
    assert repr(err) == u'error message'



# Generated at 2022-06-22 20:00:05.878934
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {}

    # Test with no interpreter name
    try:
        discover_interpreter(None, '', '', task_vars)
        assert False
    except ValueError:
        pass

    # Test with an interpreter name other than 'python'
    try:
        discover_interpreter(None, 'ruby', '', task_vars)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 20:00:12.490405
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Test interpreter discovery error message", "python", "auto")
    except InterpreterDiscoveryRequiredError as err:
        assert err.discovery_mode == "auto"
        assert err.interpreter_name == "python"
        assert err.message == "Test interpreter discovery error message"
        assert str(err) == "Test interpreter discovery error message"
        assert repr(err) == "Test interpreter discovery error message"


# Generated at 2022-06-22 20:00:20.070212
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    error = InterpreterDiscoveryRequiredError(message='py interpreter not found', interpreter_name='python', discovery_mode='auto')

    assert isinstance(error, Exception)
    assert error.message == 'py interpreter not found'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'
    assert str(error) == 'py interpreter not found'
    assert repr(error) == 'py interpreter not found'


# Generated at 2022-06-22 20:00:31.349785
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    host = 'localhost'
    action = Display()

    # Case when the interpreter chosen is the first one available

# Generated at 2022-06-22 20:00:35.482713
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert err.__str__() == 'message'

# Generated at 2022-06-22 20:00:38.881501
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'Interpreter discovery required'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(err) == message

# Generated at 2022-06-22 20:00:41.721816
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "test repr"
    interpreter_name = "python"
    discovery_mode = "auto"
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert msg == repr(error)

# Generated at 2022-06-22 20:00:46.259380
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Create an instance of InterpreterDiscoveryRequiredError
    c = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    # Assert repr of object
    assert repr(c) == 'message'


# Generated at 2022-06-22 20:00:51.780298
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Create an instance of class InterpreterDiscoveryRequiredError
    my_instance = InterpreterDiscoveryRequiredError(message=u"python", interpreter_name=u"python", discovery_mode=u"auto")

    # Test method __repr__ of class InterpreterDiscoveryRequiredError
    assert my_instance.__repr__() == u"python"


# Generated at 2022-06-22 20:00:56.113986
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
  e = InterpreterDiscoveryRequiredError('message', 'interpreter name', 'discovery mode')
  assert e.message == 'message'
  assert e.interpreter_name == 'interpreter name'
  assert e.discovery_mode == 'discovery mode'

# Generated at 2022-06-22 20:01:01.607844
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "test_mode"
    message = "Unit testing method __str__ of class InterpreterDiscoveryRequiredError"
    inter_disc_req_err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(inter_disc_req_err) == message

# Generated at 2022-06-22 20:01:06.193811
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    # Create an instance of InterpreterDiscoveryRequiredError
    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')

    # Verify __str__ of err
    assert err.__str__() == 'message'


# Generated at 2022-06-22 20:01:09.595106
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "Some error message"
    interpreter_name = "python"
    discovery_mode = "auto"
    idre = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(idre) == message

# Generated at 2022-06-22 20:01:17.093389
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    int_name = 'python'
    discover_mode = 'auto_legacy_silent'
    try:
        raise InterpreterDiscoveryRequiredError('no python interpreter found', int_name, discover_mode)
    except Exception as ex:
        assert ex.message == 'no python interpreter found'
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto_legacy_silent'
        assert str(ex) == 'no python interpreter found'


# Generated at 2022-06-22 20:01:23.443203
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('foo', 'bar', 'baz')
    except InterpreterDiscoveryRequiredError as e:
        assert e.__class__.__name__ == 'InterpreterDiscoveryRequiredError'
        assert e.interpreter_name == 'bar'
        assert e.discovery_mode == 'baz'
        assert str(e) == 'foo'

# Generated at 2022-06-22 20:01:29.957174
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor import module_loader, module_common
    from ansible.plugins.loader import module_loader
    import ansible.plugins.action
    import builtins

    # need to load this manually, because the plugin_loader won't
    module_loader.add_directory(ansible.plugins.action._action_loader._get_plugins_dir_paths()[0])
    # fake out builtin loader too
    builtins.__import__ = module_loader.import_module


# Generated at 2022-06-22 20:01:36.279481
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    iterator_name = "python"
    discovery_mode = "auto"
    message = "InterpreterDiscoveryRequiredError: Target host does not include the 'python' interpreter in /usr/bin."
    error = InterpreterDiscoveryRequiredError(message, iterator_name, discovery_mode)
    assert error.message == message
    assert error.interpreter_name == iterator_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:01:45.470624
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Tested with mocked data
    # import ansible/executor/discovery/__init__
    # import ansible.executor.discovery.__init__ as discovery_init
    # discovery_init._version_fuzzy_match = discovery._version_fuzzy_match
    # discovery_init._get_linux_distro = discovery._get_linux_distro
    # discovery.discover_interpreter = discover_interpreter
    from ansible.executor.discovery import discover_interpreter
    from ansible.executor.discovery import _get_linux_distro
    from ansible.executor.discovery import _version_fuzzy_match

    # Test _get_linux_distro function

# Generated at 2022-06-22 20:01:49.122550
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message='message'
    interpreter_name='python'
    discovery_mode='auto'
    interpreter_discovery_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert isinstance(interpreter_discovery_error, Exception)
    assert interpreter_discovery_error.message == message
    assert interpreter_discovery_error.interpreter_name == interpreter_name
    assert interpreter_discovery_error.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:02:01.306724
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: make this more robust by using a fake connection class with a canned platform info response
    # TODO: improve coverage with a fake shell_bootstrap response and a negative findre match
    import platform
    import tempfile

    if platform.system() != 'Darwin':
        print("Skipping tests for discover_interpreter, not on a Mac")
        return True

    # we need to be able to find the python_target.py module we're going to execute
    with tempfile.NamedTemporaryFile() as ftmp:
        ftmp.write(pkgutil.get_data('ansible.executor.discovery', 'python_target.py'))
        ftmp.flush()
        from ansible.module_utils.basic import AnsibleModule
        tmpmodule = AnsibleModule(
                argument_spec=dict(),
        )

# Generated at 2022-06-22 20:02:06.073488
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = "some message"

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert repr(exception) == message


# Generated at 2022-06-22 20:02:18.196313
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.module_common import get_action
    from ansible.plugin.action import ActionModule
    from ansible.plugins.loader import find_plugin

    # task_vars needs values for INTERPRETER_PYTHON_DISTRO_MAP and INTERPRETER_PYTHON_FALLBACK
    # normally provided by loader via _extract_vars_from_task_data()

# Generated at 2022-06-22 20:02:23.323052
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    action = None
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    task_vars = "task_vars"
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.__repr__() is not None

# Generated at 2022-06-22 20:02:27.143448
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_msg = "Discovery of python interpreter is required."
    error_obj = InterpreterDiscoveryRequiredError(message=error_msg, interpreter_name="python", discovery_mode="auto")

    assert str(error_obj) == error_msg


# Generated at 2022-06-22 20:02:31.726195
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    kwargs = {u'message': u'a message from test',
              u'interpreter_name': u'python',
              u'discovery_mode': u'auto'}

    expected_result = "a message from test"

    error_instance = InterpreterDiscoveryRequiredError(**kwargs)
    assert repr(error_instance) == expected_result


# Generated at 2022-06-22 20:02:34.240484
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError('foo', 'bar', 'baz')
    assert ex.__str__() == 'foo'

# Generated at 2022-06-22 20:02:41.506154
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("foo", "python", "unresolved_hosts_silent")
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "unresolved_hosts_silent"
    assert to_native(str(error)) == 'foo'
    assert to_native(repr(error)) == 'foo'


# Generated at 2022-06-22 20:02:49.389079
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # We do not have a good way to test that the warnings are raised.
    # We'll just make sure it runs.
    import ansible.executor.discovery as discovery
    task_vars = dict()
    action = type('Action', (object,), {})
    action._discovery_warnings = []
    action._connection = type('Connection', (object,), {'has_pipelining': True})
    python = discovery.discover_interpreter(action, 'python', 'auto_legacy', task_vars)
    assert python



# Generated at 2022-06-22 20:02:56.420452
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = "Interpreter discovery required, but unsuccessful or not compatible with discovery mode '{0}'".format(discovery_mode)
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert(error.interpreter_name == interpreter_name)
    assert(error.discovery_mode == discovery_mode)
    assert(error.message == message)

# Generated at 2022-06-22 20:03:00.371448
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "python interpreter discovery"
    interpreter_name = "python"
    discovery_mode = "auto"
    e = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert e.__repr__() == msg

# Generated at 2022-06-22 20:03:10.079925
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import json
    import unittest
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.compat.version import LooseVersion
    from ansible.executor.discovery import discover_interpreter

    # get platform_python_map into a form we can use
    platform_python_map = C.config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP')
    pp_map = dict((pp.lower().strip(), {v: k for k, v in p.items()}) for pp, p in platform_python_map.items())

    def get_fuzzy(distro, distro_version):
        return _version_fuzzy_match(distro_version, pp_map.get(distro))


# Generated at 2022-06-22 20:03:22.698780
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class MockAction(ActionBase):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj
            self._connection = connection
            self._display = Display()
            self._discovery_warnings = []


# Generated at 2022-06-22 20:03:33.237252
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(u'foo', u'python', u'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == u'python'
        assert e.discovery_mode == u'auto'

    try:
        raise InterpreterDiscoveryRequiredError(u'foo', u'python', u'auto_legacy')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == u'python'
        assert e.discovery_mode == u'auto_legacy'


# Generated at 2022-06-22 20:03:38.085650
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'foo'
    discovery_mode = 'bar'
    message = 'foo_bar'
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_discovery_required_error.__str__() == message

# Generated at 2022-06-22 20:03:40.743721
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    exc = InterpreterDiscoveryRequiredError("testmessage", interpreter_name="python", discovery_mode="auto_silent")

    assert "testmessage" == str(exc)

# Generated at 2022-06-22 20:03:53.418535
# Unit test for function discover_interpreter
def test_discover_interpreter():

    host = u'1.2.3.4'

    action = object()

    action._low_level_execute_command = lambda command, sudoable, in_data=None:\
        {'stdout': u'mullet\nPLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND',
        'stdout_lines': [u'mullet', u'PLATFORM', u'Linux', u'FOUND', u'/usr/bin/python', u'ENDFOUND'],
        'warnings': [u'No python interpreters found for host 1.2.3.4 (tried /usr/bin/python2, /usr/bin/python3)'],
        }

    action._discovery_warnings = []

    action._connection = object()
    action._connection.has_pipel

# Generated at 2022-06-22 20:03:57.407706
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert e.message == "message"
    assert e.interpreter_name == "interpreter_name"
    assert e.discovery_mode == "discovery_mode"

# Generated at 2022-06-22 20:04:04.226468
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "test message"
    interpreter_name = "test interpreter name"
    discovery_mode = "test discovery mode"
    interpreter_discovery_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_discovery_error.message == message
    assert interpreter_discovery_error.interpreter_name == interpreter_name
    assert interpreter_discovery_error.discovery_mode == discovery_mode