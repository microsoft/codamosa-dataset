

# Generated at 2022-06-22 19:54:09.248434
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    raised_error = InterpreterDiscoveryRequiredError("message","python","auto")
    assert(raised_error.interpreter_name == 'python' and raised_error.discovery_mode == 'auto')
    assert(raised_error.message == 'message')
    assert(raised_error.__repr__() == 'message' and raised_error.__str__() == 'message')

# Generated at 2022-06-22 19:54:14.676948
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto_silent"
    message = "Python interpreter discovery required in order to run {0} module.".format(interpreter_name)
    test_InterpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert(test_InterpreterDiscoveryRequiredError.__repr__() == message)


# Generated at 2022-06-22 19:54:24.824163
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Success test
    InterpreterDiscoveryRequiredError('InterpreterDiscoveryRequiredError', 'python', 'auto')
    # Failure test1
    try:
        InterpreterDiscoveryRequiredError(None, 'python', 'auto')
    except Exception:
        pass
    # Failure test2
    try:
        InterpreterDiscoveryRequiredError('InterpreterDiscoveryRequiredError', None, 'auto')
    except Exception:
        pass
    # Failure test3
    try:
        InterpreterDiscoveryRequiredError('InterpreterDiscoveryRequiredError', 'python', 'auto_legacy')
    except Exception:
        pass

# Generated at 2022-06-22 19:54:27.753026
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected = "msg"
    actual = InterpreterDiscoveryRequiredError(message=expected, interpreter_name="python", discovery_mode="auto_legacy_silent").__repr__()
    assert expected == actual


# Generated at 2022-06-22 19:54:30.845970
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError('This is a message', 'python', 'auto')
    assert exception.__repr__() == 'This is a message'

# Generated at 2022-06-22 19:54:35.577490
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'

    test_obj = InterpreterDiscoveryRequiredError("test", interpreter_name, discovery_mode)
    assert test_obj.interpreter_name == interpreter_name
    assert test_obj.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:54:40.096871
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required for python on host {0}.'.format(discovery_mode)
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:54:45.016818
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Python version auto-detection is required for python on this platform.'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.__str__() == message

# Generated at 2022-06-22 19:54:46.205727
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement
    pass

# Generated at 2022-06-22 19:54:57.421732
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''
    Unit test function, to verify the operation of discover_interpreter.  The test compares the operation to the
    expected result of the function, based on current data.
    :return: None
    '''
    from ansible.executor.discovery.data.python_target_discovery import plat_python_map
    from ansible.executor.discovery.data.python_target_discovery import plat_python_fallbacks
    from ansible.executor.discovery.data.python_target_discovery import expected_test_output
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.common.text.converters import to_text
    import platform

    # test data reference - the dictionary keys are versions of Linux, the values are the expected path

# Generated at 2022-06-22 19:55:05.880785
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    # Simple tests
    err = InterpreterDiscoveryRequiredError("msg", "python", "auto")
    assert str(err) == "msg"
    assert repr(err) == "msg"

    # Test for __str__ and __repr__ with long messages
    long_msg = 'a' * 1000 + '1'
    err = InterpreterDiscoveryRequiredError(long_msg, "python", "auto")
    assert str(err) == long_msg
    assert repr(err) == long_msg

    # Test when __str__ is not implemented
    class ErrorWithCustomRepr():
        def __repr__(self):
            return "5"
    err = InterpreterDiscoveryRequiredError(ErrorWithCustomRepr(), "python", "auto")
    assert str(err) == "5"
    assert repr(err)

# Generated at 2022-06-22 19:55:17.781290
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import load_plugin

    class FakeActionModule(ActionBase):
        def _discovery_warnings(self):
            return []

        def _discovery_warnings_append(self, warning):
            self._discovery_warnings.append(warning)

        def _low_level_execute_command(self, command, sudoable=None, in_data=None, executable=None):
            print(command)
            return {'stdout': 'echo PLATFORM; uname; echo FOUND; command -v=/usr/bin/python; echo ENDFOUND',
                    'rc': 0,
                    'stdout_lines': ['PLATFORM', 'Linux', 'FOUND', '/usr/bin/python', 'ENDFOUND']}


# Generated at 2022-06-22 19:55:19.970817
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "1", "2")
    assert str(error) == "message"

# Generated at 2022-06-22 19:55:25.283122
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    try:
        raise InterpreterDiscoveryRequiredError('message' , 'interpreter', 'discovery_mode')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'message'
        assert e.interpreter_name == 'interpreter'
        assert e.discovery_mode == 'discovery_mode'
        assert str(e) == 'message'
        assert repr(e) == 'message'

# Generated at 2022-06-22 19:55:27.754093
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError("message","interpreter_name","discovery_mode")
    assert str(exception) == "message"

# Generated at 2022-06-22 19:55:32.863021
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.connection_info import ConnectionInformation
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a basic action so we can call the method
    class BasicAction:
        pass

    action = BasicAction()

    test_hosts = ['test_host']
    test_playbook = 'playbook.yml'

    loader = DataLoader()

    # create necessary play context
    play_context = PlayContext()
    play_context._custom_vars = {}
    play_context.become

# Generated at 2022-06-22 19:55:37.572912
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = 'failed'
    exception_obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(exception_obj) == message

# Generated at 2022-06-22 19:55:39.915440
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert repr(err) == 'message'



# Generated at 2022-06-22 19:55:42.177148
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    if not isinstance(InterpreterDiscoveryRequiredError('error message', 'python', 'auto'), Exception):
        raise AssertionError()

# Generated at 2022-06-22 19:55:43.819524
# Unit test for function discover_interpreter
def test_discover_interpreter():
    res = discover_interpreter('action', 'python', 'auto', None)
    print(res)



# Generated at 2022-06-22 19:55:46.630611
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    assert InterpreterDiscoveryRequiredError(u'unit test', u'python', u'auto').__str__() == u'unit test'



# Generated at 2022-06-22 19:55:49.797020
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert repr(InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')) == 'message'



# Generated at 2022-06-22 19:55:52.610012
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(
        "Error message", "interpreter_name", "discovery_mode")
    assert repr(error) == "Error message"

# Generated at 2022-06-22 19:56:03.681302
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class Action:
        def __init__(self):
            self._discovery_warnings = []
            self._connection = Connection()

        def _low_level_execute_command(self, command, sudoable, in_data=''):
            if command not in ['bootstrap.sh', 'platform.py', 'platform3.py']:
                raise ValueError(command)
            if command == 'bootstrap.sh':
                return {'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python3\nENDFOUND'}
            if command == 'platform.py':
                return {'stdout': json.dumps({'platform_dist_result': ['Fedora', '27', 'Twenty']})}

# Generated at 2022-06-22 19:56:12.790035
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.connection.network_cli import Connection
    from ansible.playbook.task import Task

    class ActionModule(object):
        def __init__(self):
            self._discovery_warnings = list()

    class PlayContext(object):
        def __init__(self):
            self.become = False
            self.become_user = 'become_user'
            self.become_method = 'become_method'
            self.become_pass = 'become_pass'

    class TaskVars(object):
        def __init__(self):
            self.hostvars = None

    class TestConnection(object):
        def __init__(self):
            self.has_pipelining = True


# Generated at 2022-06-22 19:56:24.717682
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'explicit'
    message = 'Error parsing template: template error while templating string: unexpected ' \
              'char u\'v\' at 0. String: {% if ansible_ansible_version != \'2.5\' %}'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(error) == 'Error parsing template: template error while templating string: ' \
                         'unexpected char u\'v\' at 0. String: ' \
                         '{% if ansible_ansible_version != \'2.5\' %}'

# Generated at 2022-06-22 19:56:30.427875
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    display = Display()
    display.verbosity = 2  # TODO: fake verbose

    try:
        raise InterpreterDiscoveryRequiredError("Message", "python", "auto_legacy_silent")
    except InterpreterDiscoveryRequiredError as e:
        assert e.__str__() == "Message"


# Generated at 2022-06-22 19:56:34.353231
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError("msg", "interpreter_name", "discovery_mode")
    except InterpreterDiscoveryRequiredError as ex:
        assert str(ex) == "msg"


# Generated at 2022-06-22 19:56:37.448921
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(message="test message", interpreter_name="python3", discovery_mode="auto_legacy_silent")
    assert 'test message' == repr(error)

# Generated at 2022-06-22 19:56:43.514214
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "message"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    res = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert res is not None
    assert res.message == "message"
    assert res.discovery_mode =="auto_legacy_silent"
    assert res.interpreter_name == "python"



# Generated at 2022-06-22 19:56:52.023341
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Create an instance of class InterpreterDiscoveryRequiredError
    interpreter_error = InterpreterDiscoveryRequiredError(u'NotImplementedError: interpreter discovery not supported',
                                                          'test_interpreter', 'test_discovery')
    # The error should have attributes interpreter_name and discovery_mode
    assert interpreter_error.interpreter_name == 'test_interpreter'
    assert interpreter_error.discovery_mode == 'test_discovery'

# Generated at 2022-06-22 19:56:54.551035
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    temp = InterpreterDiscoveryRequiredError('Message', 'interpreter_name', 'discovery_mode')
    assert str(temp), 'Message'
    assert repr(temp), 'Message'

# Generated at 2022-06-22 19:57:01.228718
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Test discover_interpreter with a task_vars that contains an entry for interpreter_python_version_map
    def test_interpreter_discovery_python_1():
        task_vars = {"inventory_hostname": "localhost", "ansible_distribution": "Centos",
                     "ansible_distribution_version": "7",
                     "interpreter_python_version_map": {"centos": {"7": "/usr/bin/python", "6": "/usr/bin/python"},
                                                        "fedora": {"28": "/usr/bin/python", "27": "/usr/bin/python"},
                                                        "debian": {"9": "/usr/bin/python", "8": "/usr/bin/python"},
                                                        "ubuntu": {"16.04": "/usr/bin/python", }}}
        interpreter

# Generated at 2022-06-22 19:57:12.569364
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError

# Generated at 2022-06-22 19:57:16.920648
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    msg = 'discovery error'
    interp = 'python'
    discovery = 'auto'

    ex = InterpreterDiscoveryRequiredError(msg, interp, discovery)
    assert str(ex) == msg

# Generated at 2022-06-22 19:57:23.888079
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("interpreter discovery error", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == "interpreter discovery error"
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto"
    else:
        raise Exception("not raise InterpreterDiscoveryRequiredError")


# Generated at 2022-06-22 19:57:28.217518
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex = InterpreterDiscoveryRequiredError('msg', 'python', 'auto')
    assert ex.message == 'msg'
    assert ex.interpreter_name == 'python'
    assert ex.discovery_mode == 'auto'
    assert repr(ex).startswith('msg')

# Generated at 2022-06-22 19:57:31.188788
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'interpreter', 'discovery_mode')
    assert error.__str__() == 'message'

# Generated at 2022-06-22 19:57:36.522649
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert(e.message == 'message')
        assert(e.interpreter_name == 'python')
        assert(e.discovery_mode == 'auto')

# Generated at 2022-06-22 19:57:42.948439
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    t_args = {
        'message': 'message',
        'interpreter_name': 'python',
        'discovery_mode': 'auto'
    }
    error = InterpreterDiscoveryRequiredError(**t_args)
    assert error.message == 'message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

# Generated at 2022-06-22 19:57:49.117139
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    action = ActionBase()
    task_vars = dict()

    assert discover_interpreter(action, 'python', 'auto_legacy', task_vars) == u'/usr/bin/python'

    # TODO: add a test for the os-release-only case (from a CentOS 7 VM)

    task_vars['ansible_python_interpreter'] = '/usr/bin/python2'

# Generated at 2022-06-22 19:57:53.101502
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert err.message == "message"
    assert err.interpreter_name == "interpreter_name"
    assert err.discovery_mode == "discovery_mode"
    assert str(err) == "message"

# Generated at 2022-06-22 19:58:05.040589
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # _version_fuzzy_match
    assert _version_fuzzy_match('3.4', {'3.4': 'foo', '3.2': 'bar', '3.6': 'baz'}) == 'foo'
    assert _version_fuzzy_match('3.0', {'3.4': 'foo', '3.2': 'bar', '3.6': 'baz'}) == 'bar'
    assert _version_fuzzy_match('3.8', {'3.4': 'foo', '3.2': 'bar', '3.6': 'baz'}) == 'baz'

# Generated at 2022-06-22 19:58:10.188749
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    my_error = InterpreterDiscoveryRequiredError(
        message='test_message',
        interpreter_name='test_interpreter',
        discovery_mode='test_discovery_mode',
    )
    assert str(my_error) == my_error.message

# Generated at 2022-06-22 19:58:16.675817
# Unit test for function discover_interpreter
def test_discover_interpreter():
    #   test case 1
    actual = discover_interpreter(action='test_action', interpreter_name='python',
                                  discovery_mode='mode_silent',
                                  task_vars={'inventory_hostname': 'my_hostname',
                                             'config.get_config_value': 'config.get_config_value'})
    expected = u'/usr/bin/python'
    msg = "result: %s != %s" % (actual, expected)
    assert actual == expected, msg

    #   test case 2

# Generated at 2022-06-22 19:58:19.857394
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert exception.__str__() == 'message'

# Generated at 2022-06-22 19:58:31.570341
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:58:33.415814
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError("err", "interpreter_name", "discovery_mode")
    assert repr(err) == err.message

# Generated at 2022-06-22 19:58:38.560935
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'test message'
    interpreter_name = 'test interpreter name'
    discovery_mode = 'test discovery mode'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(error) == message


# Generated at 2022-06-22 19:58:49.843420
# Unit test for function discover_interpreter
def test_discover_interpreter():
    def run_discover_interpreter(*args, **kwargs):
        try:
            return discover_interpreter(*args, **kwargs)
        except InterpreterDiscoveryRequiredError as e:
            return (e.interpreter_name, e.discovery_mode)

    class MockAction(object):
        def __init__(self, host_name, interpreter_name, discovery_mode, task_vars):
            self.host_name = host_name
            self.interpreter_name = interpreter_name
            self.discovery_mode = discovery_mode
            self.task_vars = task_vars
            self._low_level_execute_command = test_discover_interpreter_exec
            self._discovery_warnings = []

        def get_connection(self):
            return self

       

# Generated at 2022-06-22 19:59:00.355328
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class ActionModuleDiscoveryMock(object):
        def __init__(self):
            self._discovery_warnings = []
            self._low_level_execute_command = lambda *args, **kwargs: {'stdout': '', 'stderr': ''}

    class ConnectionMock(object):
        def __init__(self):
            self.has_pipelining = True

    class TaskMock(object):
        def __init__(self):
            self._connection = ConnectionMock()

    obj = TaskQueue

# Generated at 2022-06-22 19:59:03.347253
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            "Test Message",
            'python',
            'auto'
        )
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'Test Message'
        assert e.discovery_mode == 'auto'
        assert e.interpreter_name == 'python'



# Generated at 2022-06-22 19:59:08.292458
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError(
        'message',
        'interpreter_name',
        'discovery_mode',
    )

    result = str(exc)

    assert result == 'message'

# Generated at 2022-06-22 19:59:14.550129
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    expected_msg = "msg"
    expected_interpreter_name = "python"
    expected_discovery_mode = "auto"
    error = InterpreterDiscoveryRequiredError(expected_msg, expected_interpreter_name, expected_discovery_mode)
    assert error.message == expected_msg
    assert error.interpreter_name == expected_interpreter_name
    assert error.discovery_mode == expected_discovery_mode

# Generated at 2022-06-22 19:59:23.229983
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    error_msg = 'error msg'
    try:
        del C.DEFAULT_INTERPRETER_DISCOVERY_MODE
        raise InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode
        assert str(e) == error_msg

# Generated at 2022-06-22 19:59:27.104699
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError("error test", "python", "auto")
    assert repr(interpreter_discovery_required_error) == "error test"


# Generated at 2022-06-22 19:59:39.141272
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        from ansible.plugins.action import ActionBase
        from ansible.plugins.test.test_action_module import ActionModule
        from ansible.plugins.test.test_action_modules import ActionModuleBase
    except ImportError:
        from ansible_collections.ansible.community.plugins.action import ActionBase
        from ansible_collections.ansible.community.plugins.test.test_action_module import ActionModule
        from ansible_collections.ansible.community.plugins.test.test_action_modules import ActionModuleBase

    class TestActionModule(ActionModule, ActionModuleBase):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)


# Generated at 2022-06-22 19:59:44.801563
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError(
        message='message',
        interpreter_name='python',
        discovery_mode='auto',
    )
    assert str(e) == 'message'
    assert repr(e) == 'message'
    assert isinstance(e, InterpreterDiscoveryRequiredError)


# Generated at 2022-06-22 19:59:47.876284
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError("message", "python", "auto_legacy_silent")
    except InterpreterDiscoveryRequiredError as e:
        assert repr(e) == "message"

# Generated at 2022-06-22 19:59:59.724376
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager, HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    host_name = 'localhost'
    play_context = PlayContext()
    loader = DataLoader()
    inventory = InventoryManager([], loader=loader)
    inventory.add_host(host_name)

    vars_manager = VariableManager()
    vars_manager.set_inventory(inventory)
    vars_manager.set_host_variable

# Generated at 2022-06-22 20:00:00.981904
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto_silent")
    assert error.__str__() == "message"

# Generated at 2022-06-22 20:00:03.904659
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    import pytest
    message = 'test message'
    interpreter_name = 'test interpreter name'
    discovery_mode = 'test discovery mode'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.__repr__() == e.message

# Generated at 2022-06-22 20:00:15.660821
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.plugins.action import ActionBase

    action = ActionBase()

    class Connection(object):
        def __init__(self):
            self.has_pipelining = True

    class TaskVars(dict):
        def __init__(self):
            super(TaskVars, self).__init__()
            self['inventory_hostname'] = 'localhost'
            self['config'] = {'INTERPRETER_PYTHON_DISTRO_MAP': {'alpine': {'3.7': '/usr/bin/python3.7'}},
                              'INTERPRETER_PYTHON_FALLBACK': ['/usr/bin/python3', '/usr/bin/python']}

    class ActionModule(object):
        def __init__(self, interpreter_name, discovery_mode):
            self

# Generated at 2022-06-22 20:00:20.121050
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('Failed', 'python', 'failed')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'failed'

# Generated at 2022-06-22 20:00:21.500826
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'automatic')
    assert to_text(error) == 'message'

# Generated at 2022-06-22 20:00:27.620955
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    host = "some host"
    interpreter = "some interpreter"
    discovery_mode = "some discovery_mode"
    message = "some error message"

    error = InterpreterDiscoveryRequiredError(message, interpreter, discovery_mode)
    error._host = host
    assert error.__repr__() == 'some error message on host some host'


# Generated at 2022-06-22 20:00:34.402822
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('my error', 'my_interpreter', 'my_discovery_mode')
    except InterpreterDiscoveryRequiredError as ex:
        assert to_text(ex) == 'my error'
        assert ex.interpreter_name == 'my_interpreter'
        assert ex.discovery_mode == 'my_discovery_mode'

# Generated at 2022-06-22 20:00:43.280933
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    os_release_contents = """NAME="SLES"
VERSION="15"
VERSION_ID="15"
PRETTY_NAME="SUSE Linux Enterprise Server 15"
ID="sles"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:suse:sles:15"
"""

    platform_dist_result = ('SLES', '15', 'SLES_15')
    # Display is a singleton, so don't pollute test framework's use of it.
    display._display.verbosity = 4
    action_plugin = AnsibleModule(argument_spec={}, supports_check_mode=True)
    discovery_mode = 'auto_legacy'

# Generated at 2022-06-22 20:00:45.546275
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError('This is a test', 'python', 'auto_legacy_silent')
    assert "This is a test" in to_native(e)

# Generated at 2022-06-22 20:00:50.251170
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_msg = 'error message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    try:
        raise InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == error_msg
        assert ex.interpreter_name == interpreter_name
        assert ex.discovery_mode == discovery_mode



# Generated at 2022-06-22 20:01:01.865967
# Unit test for function discover_interpreter

# Generated at 2022-06-22 20:01:05.090075
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert e.__str__() == 'message'

# Generated at 2022-06-22 20:01:11.174411
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'this is my message'
    interp_name = 'python2'
    discovery_mode = 'auto_legacy'

    idr_error = InterpreterDiscoveryRequiredError(msg, interp_name, discovery_mode)

    assert str(idr_error) == msg


# Generated at 2022-06-22 20:01:15.830694
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Test1
    err = InterpreterDiscoveryRequiredError("message", 'python', 'auto')
    print(str(err))

    # Test2
    err = InterpreterDiscoveryRequiredError("message", 'python', 'manual')
    print(str(err))



# Generated at 2022-06-22 20:01:26.353179
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    import ansible.executor.task_queue_manager
    from ansible.plugins.loader import task_loader
    from ansible.plugins.dynamic_inventory import InventoryModule
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    # Setup class for use with test_discovery_python_target_py
    class TaskQueueManager:
        def __init__(self, inventory, variable_manager, loader, options, passwords, stdout_callback=None, run_tree=False,
                     stdout_callback_nodes=None):
            self._play_context = PlayContext()

# Generated at 2022-06-22 20:01:32.403380
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'foo'
    interpreter_name = 'python2'
    discovery_mode = 'auto'
    e = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    expected = msg
    returned = e.__repr__()
    assert expected == returned

# Generated at 2022-06-22 20:01:38.125267
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required'
    er = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert er.message == message
    assert er.interpreter_name == interpreter_name
    assert er.discovery_mode == discovery_mode
    assert str(er) == message



# Generated at 2022-06-22 20:01:41.346440
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(message=u'Bad Python Interpreter', interpreter_name=u'python', discovery_mode=u'new_mode')
    assert str(error) == u'Bad Python Interpreter'

# Generated at 2022-06-22 20:01:48.653326
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        import ansible.executor.action_plugins.discovery
        from ansible.executor.action_plugins.discovery import discover_interpreter
        from ansible.plugins.action.normal import ActionModule
        from ansible.inventory.host import Host
        from ansible.inventory.group import Group
        from ansible.playbook.task import Task
        from ansible.vars.manager import VariableManager
    except ImportError:
        print('Failed to load ansible modules')
        return 3

    # generate fake action for test
    fake_loader = DictDataLoader({})
    fake_inventory = Inventory(loader=fake_loader, variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

# Generated at 2022-06-22 20:01:52.967581
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert obj.message == "message"
    assert obj.interpreter_name == "interpreter_name"
    assert obj.discovery_mode == "discovery_mode"
    assert str(obj) == "message"

# Generated at 2022-06-22 20:01:56.052163
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("message", "python", "foo_silent")
    expected = "message"
    actual = repr(error)
    assert expected == actual

# Generated at 2022-06-22 20:02:06.936684
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError()
    except InterpreterDiscoveryRequiredError as e:
        assert e.message is None
        assert e.interpreter_name is None
        assert e.discovery_mode is None
    try:
        raise InterpreterDiscoveryRequiredError(message="test message", interpreter_name="test name",
                                                discovery_mode="test mode")
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == "test message"
        assert e.interpreter_name == "test name"
        assert e.discovery_mode == "test mode"



# Generated at 2022-06-22 20:02:13.038603
# Unit test for function discover_interpreter
def test_discover_interpreter():
    ''' Unit test for function discover_interpreter '''
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.basic import AnsibleModule

    class FakeAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = Connection('ssh', 'localhost', 22, 'testuser', 'testpass', 'test-shell')._connector
            self._connection.has_pipelining = True

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            return {'stdout': 'PLATFORM\r\nLinux\r\nFOUND\r\n/usr/bin/python3\r\nENDFOUND'}

    action = FakeAction()
    task_vars = {}

# Generated at 2022-06-22 20:02:15.237112
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add test fixture
    # TODO: add some sort of unit test framework to allow mocking
    return

# Generated at 2022-06-22 20:02:18.036683
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert repr(err) == 'message'

# Generated at 2022-06-22 20:02:20.931816
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python', discovery_mode='auto')
    assert to_text(repr(err)) == to_text('test message')

# Generated at 2022-06-22 20:02:31.678667
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: make proper tests
    assert discover_interpreter(None, 'python', 'auto', None)
    #assert discover_interpreter(None, 'python3', 'auto', None)
    assert discover_interpreter(None, 'python', 'auto_legacy', None)
    assert discover_interpreter(None, 'python', 'always', None)
    assert discover_interpreter(None, 'python', 'never', None)
    assert discover_interpreter(None, 'python', 'auto_silent', None)
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', None)
    assert discover_interpreter(None, 'python', 'always_silent', None)
    assert discover_interpreter(None, 'python', 'never_silent', None)

# Generated at 2022-06-22 20:02:38.638831
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Test different modes
    test_cases = ['auto_legacy', 'auto', 'auto_silent', 'auto_legacy_silent']
    for mode in test_cases:
        my_exception = InterpreterDiscoveryRequiredError('Message', 'python', mode)
        repr_exception = repr(my_exception)

        assert(repr_exception == 'Message')


# Generated at 2022-06-22 20:02:50.136881
# Unit test for function discover_interpreter
def test_discover_interpreter():
    display.verbosity = 4
    display.deprecated_warning = False

    # test that fallback works
    task_vars = dict()
    task_vars['inventory_hostname'] = 'localhost'
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    action = dict()
    action['_discovery_warnings'] = []
    action['_connection'] = dict()
    action['_connection']['has_pipelining'] = True

# Generated at 2022-06-22 20:03:01.858808
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Setup
    discovery_mode = 'auto_legacy'
    interpreter_name = 'python'
    # The task_vars used to get the config values
    task_vars = dict(
        ansible_ssh_user='test_user',
        ansible_python_interpreter='/usr/bin/python',
        ansible_connection='local',
        ansible_host='localhost',
        ansible_inventory='localhost')

    # Test none discovery_mode

# Generated at 2022-06-22 20:03:06.758358
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = "test message"

    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert obj.message == message
    assert obj.interpreter_name == interpreter_name
    assert obj.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:03:09.780718
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert test.interpreter_name == 'python'
    assert test.discovery_mode == 'auto'
    assert test.message == 'message'

# Generated at 2022-06-22 20:03:14.794190
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(
        message='Interpreter discovery for python is required for this host.',
        interpreter_name='python',
        discovery_mode='require'
    )

    assert repr(error) == 'Interpreter discovery for python is required for this host.'

# Generated at 2022-06-22 20:03:25.655523
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class action_mock:
        def __init__(self, connection_has_pipelining=True):
            self.has_pipelining = connection_has_pipelining

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == '/usr/bin/python':
                # uname
                return {'stdout': u'PLATFORM\r\nLinux\r\nFOUND\r\n/usr/bin/python\r\nENDFOUND'}
            elif cmd == '/usr/bin/python3':
                # platform.dist()
                return {'stdout': u'PLATFORM\r\nLinux\r\nFOUND\r\n/usr/bin/python3\r\nENDFOUND'}

# Generated at 2022-06-22 20:03:31.257103
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interperter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'Python interpreter discovery required'
    interpreter_exception = InterpreterDiscoveryRequiredError(message, interperter_name, discovery_mode)

    assert interpreter_exception.__str__() == message


# Generated at 2022-06-22 20:03:38.729164
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "this is a test error string, {0}, {1}"
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = {}

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert message == str(e)
        assert interpreter_name == e.interpreter_name
        assert discovery_mode == e.discovery_mode

# Generated at 2022-06-22 20:03:48.698591
# Unit test for function discover_interpreter

# Generated at 2022-06-22 20:03:54.891193
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    task_vars = {}
    discovery_mode = 'auto_legacy_silent'
    interpreter_name = 'python'
    message = 'test message'
    instance = InterpreterDiscoveryRequiredError(
        message=message,
        discovery_mode=discovery_mode,
        interpreter_name=interpreter_name
    )
    expected = message
    assert repr(instance) == expected



# Generated at 2022-06-22 20:03:56.370143
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    idr = InterpreterDiscoveryRequiredError(message="Test Message", interpreter_name="test_interpreter", discovery_mode="test_discovery")
    assert idr.__str__() == "Test Message"

# Generated at 2022-06-22 20:03:58.071862
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', None) is not None

# Generated at 2022-06-22 20:04:09.770011
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest

    # FUTURE: test the remote cases too

    assert discover_interpreter(None, 'python', 'auto', {'inventory_hostname': 'localhost'}) == u'/usr/bin/python'

    assert discover_interpreter(None, 'python2', 'auto', {'inventory_hostname': 'localhost'}) == u'/usr/bin/python'

    # simple version mapping