

# Generated at 2022-06-22 19:54:05.795238
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('msg', 'name', 'mode')
    assert e.interpreter_name == 'name'
    assert e.discovery_mode == 'mode'

# Unit tests for discover_interpreter

# Generated at 2022-06-22 19:54:09.588946
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    result = InterpreterDiscoveryRequiredError(
        'message',
        'python',
        'auto'
    )
    assert result.__str__() == result.message

# Generated at 2022-06-22 19:54:16.475709
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "message"
    interpreter_name = "python"

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == message
        return
    assert False



# Generated at 2022-06-22 19:54:21.924510
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'hello'
    interpreter_name = 'python'
    discovery_mode = 'silent'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.__repr__() == e.message

# Generated at 2022-06-22 19:54:25.727098
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    myerror = InterpreterDiscoveryRequiredError("my message", "my interpreter", "my discovery mode")
    assert myerror.message == "my message"
    assert myerror.interpreter_name == "my interpreter"
    assert myerror.discovery_mode == "my discovery mode"

# Generated at 2022-06-22 19:54:36.967047
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery.bootstrap import BootstrapAction
    from ansible.executor.task_result import TaskResult

    b = BootstrapAction(u'python', u'discovery_only', TaskResult(host=u'foo.bar'), None, None)

    with open('tests/unit/data/interpreter_discovery.json') as f:
        data = f.read()

    raw_stdout = u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND' + data

    action = BootstrapAction(u'python', u'discovery_only', TaskResult(host=u'foo.bar'), None, None)


# Generated at 2022-06-22 19:54:39.176370
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError("hello, world!", "python", "auto_legacy_silent")
    assert repr(err) == "hello, world!"

# Generated at 2022-06-22 19:54:47.227161
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex = InterpreterDiscoveryRequiredError(message='TestException', interpreter_name='python', discovery_mode='auto')
    assert ex.__class__.__name__ == 'InterpreterDiscoveryRequiredError'
    assert ex.message == 'TestException'
    assert ex.interpreter_name == 'python'
    assert ex.discovery_mode == 'auto'
    assert ex._explanation == ex.message
    assert ex.__str__() == ex.message
    assert repr(ex) == ex.message

# Generated at 2022-06-22 19:54:52.397199
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg1 = 'something went wrong'
    msg2 = 'it was your fault'
    msg3 = 'unit test error'

    exception = InterpreterDiscoveryRequiredError(msg1, msg2, msg3)

    assert msg1 == exception.__repr__(), '__repr__ returned incorrect value'

# Generated at 2022-06-22 19:55:03.734933
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest

    class TestInterpreterDiscovery(unittest.TestCase):
        interpreter_name = 'python'
        discovery_mode = 'auto_legacy_silent'

# Generated at 2022-06-22 19:55:09.890242
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    host = 'host'
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = """python interpreter discovery required for host 'host' ('auto_silent' mode)."""
    test_error = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)

    assert test_error.__str__() == message

# Generated at 2022-06-22 19:55:13.458617
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Arrange
    exc = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    # Act
    res = str(exc)
    # Assert
    assert res == 'message'


# Generated at 2022-06-22 19:55:17.590737
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error_msg = 'Interpreter discovery required'

    error = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode


# Generated at 2022-06-22 19:55:27.991156
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # discover_interpreter(action, interpreter_name, discovery_mode, task_vars):
    from ansible.executor.discovery.abs_data_accessor import AbsDataAccessor

    action = AbsDataAccessor()
    task_vars = {}
    interpreter_name = 'python'
    discovery_mode = 'auto'
    try:
        result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except InterpreterDiscoveryRequiredError as e:
        print('Exception: %s' % e)
        print('interpreter_name: %s' % e.interpreter_name)
        print('discovery_mode: %s' % e.discovery_mode)
    else:
        print('result: %s' % result)

# Generated at 2022-06-22 19:55:31.362307
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError(message='hello', interpreter_name='python', discovery_mode='auto')
    assert exc.__repr__() == exc.message


# Generated at 2022-06-22 19:55:34.427289
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError('FAIL','python','auto_silent')
    except InterpreterDiscoveryRequiredError as e:
        assert to_text(e) == 'FAIL'

# Generated at 2022-06-22 19:55:38.112554
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    display.verbosity = 3
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(error) == message
    display.verbosity = 4

# Generated at 2022-06-22 19:55:42.086967
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "Testing InterpreterDiscoveryRequiredError"
    interpreter_name = "python3"
    discovery_mode = "auto"
    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(obj) == message


# Generated at 2022-06-22 19:55:44.446452
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "Interpreter discovery required"
    exception = InterpreterDiscoveryRequiredError(msg, "python", "auto")
    assert repr(exception).endswith(msg)

# Generated at 2022-06-22 19:55:49.909788
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    a = InterpreterDiscoveryRequiredError(message='Foo', interpreter_name='Baz', discovery_mode='Bar')
    assert a.message == 'Foo'
    assert a.interpreter_name == 'Baz'
    assert a.discovery_mode == 'Bar'

# Generated at 2022-06-22 19:55:52.293161
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    assert InterpreterDiscoveryRequiredError("testmsg", "testinterpreter", "testdiscoverymode").__str__() == "testmsg"

# Generated at 2022-06-22 19:56:03.422679
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import ansible.executor.action_result
    import ansible.executor.module_common
    import ansible.plugins.loader
    import os

    class ActionPlugin(object):
        _supports_check_mode = False
        _supports_async = False
        _supports_diff = False
        _async_timeout = 120
        _check_mode_timeout = 15

        def __init__(self):
            self._connection = _MockConnection()
            self._task_vars = {}
            self._discovery_warnings = []
            self._async_notify = []

        @property
        def connection(self):
            return self._connection

        @property
        def task_vars(self):
            return self._task_vars


# Generated at 2022-06-22 19:56:12.673718
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: better unit test for this thing
    class fake_action(object):
        def __init__(self):
            self._connection = None
            self._play_context = None
            self.become = None
            self.become_user = None
            self.become_method = None
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable, in_data=None):
            s = None
            if cmd.endswith("/usr/bin/python"):
                s = u"PLATFORM\nLinux\nFOUND\n"

# Generated at 2022-06-22 19:56:21.205838
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            'Executing a task requires discovery of a suitable interpreter',
            'python',
            'auto_legacy_silent',
        )
    except Exception as ex:
        assert type(ex) == InterpreterDiscoveryRequiredError
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto_legacy_silent'
        assert str(ex) == 'Executing a task requires discovery of a suitable interpreter'
        assert repr(ex) == 'Executing a task requires discovery of a suitable interpreter'

# Generated at 2022-06-22 19:56:25.177323
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError(message='', interpreter_name='python', discovery_mode='automatic')

    assert err.message == ''
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'automatic'

# Generated at 2022-06-22 19:56:27.093124
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("", "", "")
    assert repr(error) == ""

# Generated at 2022-06-22 19:56:32.874959
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    new_e = InterpreterDiscoveryRequiredError("test", "python", "auto")
    # assert str(new_e) == "test"
    # assert repr(new_e) == "test"

if __name__ == "__main__":
    test_InterpreterDiscoveryRequiredError()

# Generated at 2022-06-22 19:56:35.756545
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError('Exc message', 'py', 'new')
    assert obj.__repr__() == 'Exc message'


# Generated at 2022-06-22 19:56:45.005402
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Test an exception message with newline
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "this is a \n test"
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.__str__() == message
    # Test an exception message without newline
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "this is not a test"
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.__str__() == message


# Generated at 2022-06-22 19:56:47.398995
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        'test message',
        'test interpreter name',
        'test discovery mode'
    )
    assert error.__str__() == 'test message'

# Generated at 2022-06-22 19:56:50.722904
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # arrange
    _msg = 'this is a test message'
    _interpreter_name = 'python'
    _discovery_mode = 'auto'
    _obj = InterpreterDiscoveryRequiredError(_msg, _interpreter_name, _discovery_mode)

    # act
    response = repr(_obj)

    # assert
    assert response == _msg

# Generated at 2022-06-22 19:56:51.358723
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-22 19:56:58.346739
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    This function tests the discovery of an interpreter.
    :return:
    """
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping
    import ansible.module_utils.discovery as d
    import os

    class Test_ActionModule(object):
        def __init__(self, connection, become_method, become_user, module_name, module_args, task_uuid,
                     tmp=None, delete_remote_tmp=True, connection_info=None, task_vars=None, wrap_async=None,
                     no_log=False, stdin=None, become=None, become_user=None, check=None, diff=None, sudoable=True,
                     environment=None):
            self

# Generated at 2022-06-22 19:57:10.916203
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule

    test_host = 'testhost'

    # Test for host with python in path
    task_vars = dict()
    task_vars['inventory_hostname'] = test_host
    action = ActionModule(None, None, task_vars=task_vars)

    class MockConnection(object):
        def __init__(self):
            self.has_pipelining = True
            self.become = False

        def _low_level_execute_command(self, command, in_data, sudoable):
            if not isinstance(command, str) or in_data or sudoable:
                raise AssertionError('unexpected call')

# Generated at 2022-06-22 19:57:15.911609
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = 'test message'
    interpreter_name = 'test_interpreter'
    discovery_mode = 'test_discovery'
    i = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert i.message == msg
    assert i.interpreter_name == interpreter_name
    assert i.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:57:22.913129
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'test'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.message == 'test'
    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'auto'
    assert exception.__repr__() == 'test'


# Generated at 2022-06-22 19:57:26.949024
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected_output = "test message"

    idr_err = InterpreterDiscoveryRequiredError(expected_output, "interpreter_name", "discovery_mode")
    actual_output = idr_err.__repr__()

    assert expected_output == actual_output

# Generated at 2022-06-22 19:57:30.270802
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert error.__str__() == 'message'
    assert error.__repr__() == 'message'

# Generated at 2022-06-22 19:57:38.311190
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.__init__ import Facts

    try:
        from ansible_collections.ansible.community.tests.unit.test_utils.mock.modules import plugintools
    except ImportError:
        print("test_utils_plugin.py must be imported from ansible_collections.ansible.community.tests.unit.test_utils")
        sys.exit(1)
    # Unit test script not in the same directory as module_utils, so it's possible that
    # __file__ is pointing to the wrong place.
    if __file__.endswith('.py'):
        utils_path = os.path.join(os.path.dirname(__file__), 'utils.py')

# Generated at 2022-06-22 19:57:49.610477
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery
    import ansible.executor.task_result
    import ansible.playbook.play
    import ansible.playbook.task
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Utility for creating a mock task to pass to discover_interpreter
    def _get_mock_task(name, action_plugin=None):
        play = ansible.playbook.play.Play.load({'name': 'test_play', 'hosts': []})
        return ansible.playbook.task.Task.load({'name': name, 'action': action_plugin}, play=play, variable_manager=None)


# Generated at 2022-06-22 19:57:51.304969
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Interpreter was not found on target", "python", "auto")
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == "python"
        assert ex.discovery_mode == "auto"

    # TODO: add repr tests

# Generated at 2022-06-22 19:57:58.717402
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common._collections_compat import MutableMapping
    import copy
    import types

    # Test data class for mocking up module parameters and task vars

    class MockVars(MutableMapping):
        def __init__(self, iterable=None, **kwargs):
            self.store = dict()
            self.update(iterable, **kwargs)

        def __getitem__(self, key):
            return self.store[key]

        def __setitem__(self, key, value):
            self.store[key] = value

        def __delitem__(self, key):
            del self.store[key]

        def __iter__(self):
            return iter(self.store)

        def __len__(self):
            return len(self.store)

   

# Generated at 2022-06-22 19:58:05.338870
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    errormsg = "Test message"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    test_object = InterpreterDiscoveryRequiredError(errormsg, interpreter_name, discovery_mode)
    assert test_object.message == errormsg
    assert test_object.interpreter_name == interpreter_name
    assert test_object.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:58:14.006744
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from pytest import raises
    from ansible.module_utils.connection import Connection

    # First we test using a value of arguments that it should work
    interpreter_name = "python"
    discovery_mode = "auto"
    conn = Connection(host="localhost")
    task_vars = {"inventory_hostname": "localhost", "connection": conn}
    message = "Unable to automatically determine interpreter. Doing discovery. "

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.__repr__() == message + "interpreter_name: python discovery_mode: auto"

    # Second we test using a null value of arguments that it should raise an exception
    interpreter_name = None
    discovery_mode = None
    message = None
    task_vars = None

    error = Interpre

# Generated at 2022-06-22 19:58:24.324130
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = "error in discovery mode {} for interpreter named {}".format(discovery_mode, interpreter_name)
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # assert the attributes of error
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

    # assert the __str__ method
    assert str(error) == message
    assert repr(error) == message

# Generated at 2022-06-22 19:58:27.394328
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert e.__repr__() == 'message'

# Test for the method _version_fuzzy_match

# Generated at 2022-06-22 19:58:29.120806
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='legacy')
    assert ex.__str__() == 'message'

# Generated at 2022-06-22 19:58:31.236572
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError('test', 'python', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == 'test'

# Generated at 2022-06-22 19:58:36.543560
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError("An exception", "python", "auto")
    assert "An exception" == err.message
    assert "python" == err.interpreter_name
    assert "auto" == err.discovery_mode
    assert "An exception" == str(err)

# Generated at 2022-06-22 19:58:41.769908
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Ansible requires the Python interpreter {} which is not available'.format(interpreter_name)
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_discovery_required_error.__str__() == message

# Generated at 2022-06-22 19:58:47.220414
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Test with a simple error message
    message = "This is an error"
    interpreter_name = "python"
    discovery_mode = "auto"
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(err) == message


# Generated at 2022-06-22 19:58:50.602248
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError("Test message", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.__str__() == "Test message"

# Generated at 2022-06-22 19:58:52.439561
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    assert InterpreterDiscoveryRequiredError("Exception", "test_interpreter", "test_discovery_mode")

# Generated at 2022-06-22 19:58:55.703322
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    exception = InterpreterDiscoveryRequiredError(
        "message",
        "interpreter_name",
        "discovery_mode")

    assert exception.__repr__() is not None


# Generated at 2022-06-22 19:58:59.534542
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError('message', 'python', 'default')
    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'default'
    assert str(exception) == 'message'
    assert repr(exception) == 'message'

# Generated at 2022-06-22 19:59:05.076583
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Unable to detect Python version for host <hostname>."
    try:
        error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
        raise error
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode
        assert str(e) == message

# Generated at 2022-06-22 19:59:11.607925
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        "The interpreter must be discovered because interpreter_discovery_mode is: auto_legacy_silent", "python", "auto_legacy_silent")
    assert error.__str__() == "The interpreter must be discovered because interpreter_discovery_mode is: auto_legacy_silent"

# Generated at 2022-06-22 19:59:17.838506
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Given
    interpreter_name = 'python'
    discovery_mode = "auto"
    message = 'Interpreter discovery required but not supported for {0} in discovery mode {1}'.format(interpreter_name, discovery_mode)
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # When
    result = ex.__str__()

    # Then
    assert result == message



# Generated at 2022-06-22 19:59:22.997572
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "smart"

    error = InterpreterDiscoveryRequiredError('message', interpreter_name, discovery_mode)

    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:59:32.775665
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """Test discover interpreter with dummy data"""

    class MockAction(object):
        def __init__(self):
            self._low_level_execute_command = None
            self._connection = MockConnection(has_pipelining=True)
            self._discovery_warnings = list()


    class MockConnection(object):
        def __init__(self, has_pipelining=True):
            self.has_pipelining = has_pipelining

    class MockTaskVars(object):
        def get(self, var, default='unknown'):
            return default

        def __init__(self):
            self.inventory_hostname = 'localhost'
            self.ansible_python_interpreter = '/usr/bin/python'
            self.raw_ssh_args = ''


# Generated at 2022-06-22 19:59:45.817796
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('', 'python', 'smart', {}) == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'smart_silent', {}) == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'explicit', {}) == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'auto', {}) == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'auto_silent', {}) == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'auto_legacy', {}) == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'

   

# Generated at 2022-06-22 19:59:50.445233
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    with pytest.raises(Exception) as error:
        raise InterpreterDiscoveryRequiredError('error_msg1', 'python', 'auto')
    assert repr(error.value) == 'error_msg1'



# Generated at 2022-06-22 19:59:56.337165
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ex_1 = InterpreterDiscoveryRequiredError('Test error message', 'python', 'auto_legacy_silent')
    assert repr(ex_1) == 'Test error message'

    ex_2 = InterpreterDiscoveryRequiredError('Another test error message', 'python', 'auto_legacy_silent')
    assert repr(ex_2) == 'Another test error message'


# Generated at 2022-06-22 20:00:00.593897
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "message"
    interpreter_name = "interpreter_name"
    discovery_mode = "discovery_mode"
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert(str(e) == message)


# Generated at 2022-06-22 20:00:04.555146
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "this is a test"
    interpreter = "python"
    discovery_mode = "auto_legacy"
    exception = InterpreterDiscoveryRequiredError(msg, interpreter, discovery_mode)
    assert exception.__repr__() == msg



# Generated at 2022-06-22 20:00:12.280770
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = ActionModule(task_vars={'inventory_hostname': 'localhost',
                                     'ansible_discovery_interpreter': json.dumps(
                                         {'python': {'discovery_mode': 'auto_legacy_silent',
                                                     'interpreter_name': 'python'}})})
    result = discover_interpreter(action, 'python', 'auto_legacy_silent', {'inventory_hostname': 'localhost'})
    assert result == "/usr/bin/python"

# Generated at 2022-06-22 20:00:24.412908
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.discovery.python_target import _version_fuzzy_match
    assert _version_fuzzy_match('1.1', {'1.0': '/usr/bin/python', '1.1': '/usr/bin/python1.1', '1.2': '/usr/bin/python'}) == '/usr/bin/python1.1'
    assert _version_fuzzy_match('1.0.1', {'1.0': '/usr/bin/python', '1.1': '/usr/bin/python1.1', '1.2': '/usr/bin/python'}) == '/usr/bin/python'

# Generated at 2022-06-22 20:00:28.615386
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(
        message=u'message',
        interpreter_name=u'interpreter_name',
        discovery_mode=u'discovery_mode'
    )
    return err.__repr__() == err.message

# Generated at 2022-06-22 20:00:33.535174
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Setup
    interpreter_name = 'python'
    discovery_mode = 'silent'
    message = 'Test message'

    # Test
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # Verify
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode
    assert e.message == message
    assert e.__repr__() == message

# Generated at 2022-06-22 20:00:34.612204
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: tests for discovery and discovery failure modes
    pass

# Generated at 2022-06-22 20:00:39.607980
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required for {0} on target (discovery mode: {1})'.format(interpreter_name, discovery_mode)

    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.__repr__() == message

# Generated at 2022-06-22 20:00:46.695794
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = u'message1'
    interpreter_name = u'python'
    discovery_mode = u'auto'
    interpreter_definition = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_definition.message == message
    assert interpreter_definition.interpreter_name == interpreter_name
    assert interpreter_definition.discovery_mode == discovery_mode
    assert isinstance(interpreter_definition, InterpreterDiscoveryRequiredError)
    # TODO: add proper repr impl

# Generated at 2022-06-22 20:00:58.205655
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    import pytest

    context.CLIARGS._ansible_connection = 'docker'
    context.CLIARGS.connection = 'docker'

    task_vars = dict()
    host = 'host.example.com'


# Generated at 2022-06-22 20:01:11.565315
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # we are testing for Fedora, so set the platform type to linux
    platform_type = 'linux'

    # this is the actual output of uname -r, so we set that value to the output of the uname command
    res = dict(stdout='0.0-0.0.el8')
    assert res['stdout'] == '0.0-0.0.el8'

    # we are testing the discover_interpreter function with no argument, so that means it cannot be a non-linux platform
    # and so will print out an error saying the platform is not supported
    try:
        discover_interpreter(res, platform_type)
    except NotImplementedError as e:
        assert str(e) == 'unsupported platform for interpreter discovery'

    # this is what you get when you run platform.dist(), so I will

# Generated at 2022-06-22 20:01:21.539507
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TestModule(object):
        def __init__(self, module_name, module_args, task_vars):
            self.module_name = module_name
            self.module_args = module_args
            self.task_vars = task_vars
            self._discovery_warnings = []

        def get_option(self, opt):
            return None

        def _low_level_execute_command(self, cmd, **kwargs):
            class TestResult(object):
                def __init__(self, payload, exception=None, version=None):
                    self.stdout = payload
                    self.exception = exception
                    self.version = version

            if isinstance(cmd, tuple):
                cmd = cmd[0]


# Generated at 2022-06-22 20:01:24.850178
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    result = str(InterpreterDiscoveryRequiredError('Test error message', 'python', 'auto'))
    assert result == 'Test error message'



# Generated at 2022-06-22 20:01:28.894871
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Python interpreter discovery is required but not enabled"
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == str(err)

# Generated at 2022-06-22 20:01:33.763947
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'message'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto_legacy'

# Generated at 2022-06-22 20:01:43.444394
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    discovery_error_msg = 'no interpreters found'
    expected_string_output = "no interpreters found"
    actual_string_output = InterpreterDiscoveryRequiredError(discovery_error_msg, interpreter_name, discovery_mode)
    assert expected_string_output in repr(actual_string_output), "%s not found in %s" % (expected_string_output, repr(actual_string_output))
    # Regression
    assert interpreter_name not in repr(actual_string_output), "%s found in %s" % (interpreter_name, repr(actual_string_output))

# Generated at 2022-06-22 20:01:48.990237
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # python_executable = "/usr/bin/python3.6"
    # discovery_mode = "auto"
    # message = "Python interpreter not found. use interpreter_discovery=True to use python interpreter auto discovery"
    # exception = InterpreterDiscoveryRequiredError(message, python_executable, discovery_mode)
    #
    # assert exception.__str__() == message
    pass

# Generated at 2022-06-22 20:02:01.212525
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('test message', 'test interpreter_name', 'test discovery_mode')
    except InterpreterDiscoveryRequiredError as e:
        # call the __str__ and __repr__ methods of InterpreterDiscoveryRequiredError class
        print(str(e))
        print(repr(e))
        # check for type and value of error message
        assert isinstance(e.message, str), "message is not of type string"
        assert e.message == 'test message', "message has invalid value"
        # check for type and value of interpreter name
        assert isinstance(e.interpreter_name, str), "interpreter_name is not of type string"
        assert e.interpreter_name == 'test interpreter_name', "interpreter_name has invalid value"
        #

# Generated at 2022-06-22 20:02:13.405206
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_loader import ActionLoader
    from ansible.plugins.loader import fragment_loader

    action_loader = ActionLoader()

    mock_host = MockHost()

    action = action_loader.get('ping', mock_host, fragment_loader)

    print('Testing interpreter discovery')
    action.become = False
    action._low_level_execute_command = mock_low_level_execute_command
    action._connection.has_pipelining = True

# Generated at 2022-06-22 20:02:18.140143
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    raised_exception = InterpreterDiscoveryRequiredError('message', interpreter_name, discovery_mode)
    repr_value = raised_exception.__repr__()
    assert repr_value == 'message'

# Generated at 2022-06-22 20:02:28.384858
# Unit test for function discover_interpreter
def test_discover_interpreter():

    def test_action(task_vars, become=False, in_data=None):
        task_vars = task_vars or dict()
        action = MockAction()
        action.task_vars = task_vars
        conn = MockConnection()
        conn.has_pipelining = True
        action._connection = conn
        action._low_level_execute_command(found_interpreters[0], sudoable=False, in_data=platform_script)

    platform_script = pkgutil.get_data('ansible.executor.discovery', 'python_target.py')

    # Define the platform_python_map

# Generated at 2022-06-22 20:02:30.666364
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError("Dummy exception", "python", "auto")
    assert repr(exc) == "Dummy exception"

# Generated at 2022-06-22 20:02:35.116238
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'test message'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert (str(error) == message)

# Generated at 2022-06-22 20:02:36.675572
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError(message="Test", interpreter_name="python", discovery_mode="explicit")
    assert ex.__str__() == "Test"

# Generated at 2022-06-22 20:02:44.264402
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = u'Interpreter discovery required'
    interpreter_name = u'python'
    discovery_mode = u'auto_legacy_silent'
    with pytest.raises(InterpreterDiscoveryRequiredError) as context:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert context.value.message == message
    assert context.value.interpreter_name == interpreter_name
    assert context.value.discovery_mode == discovery_mode


# Generated at 2022-06-22 20:02:47.890385
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    my_error = InterpreterDiscoveryRequiredError(
        message="my message",
        interpreter_name="python",
        discovery_mode="auto_legacy_silent")

    assert str(my_error) == "my message"


# Generated at 2022-06-22 20:02:55.538607
# Unit test for function discover_interpreter
def test_discover_interpreter():
    fake_action = type('FakeAction', (object,), {})
    fake_action._connection = 'fake_connection'
    fake_action._discovery_warnings = []
    fake_action._options = C.config.get_config_value('DEFAULTS', variables={})

    # uname/python discovery test
    bootstrap_platform = 'Linux'
    bootstrap_python = '/usr/bin/python2.7'
    bootstrap_python_version = '2.7'

# Generated at 2022-06-22 20:03:02.173787
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_str = InterpreterDiscoveryRequiredError(
                'Error: Interpreter discovery required.',
                'python',
                'auto_legacy_silent'
    )

    assert test_str.message == 'Error: Interpreter discovery required.'
    assert test_str.interpreter_name == 'python'
    assert test_str.discovery_mode == 'auto_legacy_silent'


# Generated at 2022-06-22 20:03:03.700055
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    pass



# Generated at 2022-06-22 20:03:14.354958
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.discovery import ActionModule
    import ansible.plugins.action.discovery
    import ansible.executor.task_queue_manager
    import tempfile

    import sys
    platf = sys.platform

    def _clear_action_plugin_discovery_vars():
        # reset action plugin variables
        ActionModule._discovery_warnings = []
        ActionModule._discovery_results = {}

    def _get_action_plugin_discovery_vars(action):
        return action._discovery_warnings, action._discovery_results

    def _run_ansible_discovery(platform_type, search_interpreters, default_python_interp='/usr/bin/python'):
        import ansible.playbook.play_context
        import ansible.playbook.play
       

# Generated at 2022-06-22 20:03:19.420073
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'Missing distribution information'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'

    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert to_text(err) == to_text(msg)

# Generated at 2022-06-22 20:03:29.980063
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = u'python'
    discovery_mode = u'auto'
    task_vars = {}

    # case 1:
    # when interpreter_name is not python, should raise ValueError
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except ValueError:
        pass

    # case 2:
    # when platform_type is linux, and platform_interpreter is not found in found_interpreters, should append warning
    try:
        discover_interpreter(action, u'python', u'auto', task_vars)
    except Exception:
        pass
    assert len(action._discovery_warnings) == 1

    # case 3:
    # when the discovery_mode is auto_legacy, and platform_interpre

# Generated at 2022-06-22 20:03:34.228615
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('Test message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as err:
        assert(err.interpreter_name == 'python')
        assert(err.discovery_mode == 'auto')
        assert(err.message == 'Test message')

# Generated at 2022-06-22 20:03:38.729335
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(message='The interpreter discovery is required',
                                              interpreter_name='python',
                                              discovery_mode='auto_legacy_silent')
    assert error.__str__() == 'The interpreter discovery is required'


# Generated at 2022-06-22 20:03:42.571598
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name="python"
    discovery_mode="auto_legacy_silent"
    message="Error in python interpreter discovery"

    ex = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert message in ex.__repr__()
    assert discovery_mode in ex.__repr__()
    assert interpreter_name in ex.__repr__()


# Generated at 2022-06-22 20:03:48.815173
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """
    This test checks the return value of method __repr__
    of class InterpreterDiscoveryRequiredError
    """
    test_obj = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    str_val = str(test_obj)
    assert str(test_obj) == str_val


# Generated at 2022-06-22 20:03:54.613058
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = 'test message'
    interpreter_name = 'test interpreter_name'
    discovery_mode = 'test discovery_mode'
    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert err.message == msg
    assert err.interpreter_name == interpreter_name
    assert err.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:03:58.177359
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert error.__str__() == 'message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

# Generated at 2022-06-22 20:04:09.832204
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {}

    # Test with Python 2.6
    stdout_fake, stderr_fake = ['PLATFORM', 'Linux', 'FOUND', '/usr/bin/python', 'ENDFOUND'], None
    action.connection._low_level_execute_command = lambda _, in_data=None: dict(stdout=stdout_fake, stderr=stderr_fake)

    platform_info = dict(platform_dist_result=['centos', '6.6', 'Final'], osrelease_content=None)

    action.connection._low_level_execute_command = lambda _, in_data=None: dict(stdout=json.dumps(platform_info), stderr=None)

