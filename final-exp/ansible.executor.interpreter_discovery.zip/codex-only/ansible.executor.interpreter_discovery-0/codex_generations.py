

# Generated at 2022-06-22 19:54:04.891769
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = "Some message"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.__repr__() == error.__str__()

# Generated at 2022-06-22 19:54:12.068930
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'Interpreter Discovery Required'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    interpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreterDiscoveryRequiredError.__repr__() == message
    assert interpreterDiscoveryRequiredError.__str__() == message
    assert str(interpreterDiscoveryRequiredError) == message

# Generated at 2022-06-22 19:54:20.167440
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    class ExceptionResult():
        def __init__(self, message, interpreter_name, discovery_mode):
            self.message = message
            self.interpreter_name = interpreter_name
            self.discovery_mode = discovery_mode

    message = "message"
    interpreter_name = "python"
    discovery_mode = "auto"

    exception_result = ExceptionResult(message, interpreter_name, discovery_mode)

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.__repr__() == exception_result.__repr__()


# Generated at 2022-06-22 19:54:32.460502
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys
    import os
    import mock
    import unittest
    from ansible.module_utils.distro import DistributionInfo

    old_cwd = os.getcwd()
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    class PyTestTests(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-22 19:54:35.438318
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # TYPEERROR
    expected = ValueError
    with pytest.raises(expected):
        InterpreterDiscoveryRequiredError.__repr__()


# Generated at 2022-06-22 19:54:43.592547
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test discover_interpreter with a mocked action object
    class MockAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = MockConnection(self)

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            return self._connection.execute(cmd, sudoable, in_data)

    # Test discover_interpreter with a mocked connection object
    class MockConnection(object):
        def __init__(self, action):
            self._action = action
            self.has_pipelining = True

        def execute(self, cmd, sudoable=False, in_data=None):
            if cmd == "command -v 'python3'":
                return {'stdout': "/usr/bin/python3"}


# Generated at 2022-06-22 19:54:46.263566
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test case 1
    try:
        raise InterpreterDiscoveryRequiredError("Message1", "Python", "auto")
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == "Python"
        assert ex.discovery_mode == "auto"
    except Exception as e:
        assert False

# Generated at 2022-06-22 19:54:51.971797
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    err_msg = 'This is an automated test'
    err = InterpreterDiscoveryRequiredError(err_msg, interpreter_name, discovery_mode)

    # Test __str__()
    assert str(err) == 'This is an automated test'


# Generated at 2022-06-22 19:54:58.688589
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    EXPECTED_STR_VALUE = 'test message'
    EXPECTED_INTERPRETER_NAME = 'python'
    EXPECTED_DISCOVERY_MODE = 'auto'
    EXCEPTION = InterpreterDiscoveryRequiredError(EXPECTED_STR_VALUE, EXPECTED_INTERPRETER_NAME, EXPECTED_DISCOVERY_MODE)
    ACTUAL_STR_VALUE = EXCEPTION.__repr__()
    assert(ACTUAL_STR_VALUE == EXPECTED_STR_VALUE)


# Generated at 2022-06-22 19:55:03.001548
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'Use python3 to run this modue with Ansible 2.4 or higher'
    interpreter_name = "python3"
    discovery_mode = "auto"
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message in e.message
    assert interpreter_name in e.message
    assert discovery_mode in e.message


# Generated at 2022-06-22 19:55:11.132532
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Create object of class InterpreterDiscoveryRequiredError
    error = InterpreterDiscoveryRequiredError("message", 'python', "auto")
    # Check if variables are as expected
    assert error.message == "message"
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"
    # Check if __str__ works as expected
    assert str(error) == "message"
    # Check if __repr__ works as expected
    assert repr(error) == "message"



# Generated at 2022-06-22 19:55:13.458982
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy_silent")
    assert isinstance(err, InterpreterDiscoveryRequiredError)

# Generated at 2022-06-22 19:55:22.073280
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # For now, only test non-pipelining case.
    # FUTURE: implement on-disk case (via script action or ?)
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.manager import VariableManager
    import ansible

    # Load plugins
    callback_plugin_path = ansible.config.get_config_value('DEFAULT_CALLBACK_WHITELIST')
    ansible.plugins.load_callback_plugins(callback_plugin_path)

    class TestCallbackModule(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(TestCallbackModule, self).__init__

# Generated at 2022-06-22 19:55:30.661289
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object()
    action.module_name = 'shell'
    action.host = 'host'
    action._discovery_warnings = []
    action._connection = object()
    action._connection.has_pipelining = True
    text_type = 'text'

    task_vars = {
        'inventory_hostname': 'host',
        'ansible_connection': 'network_cli',
        'ansible_network_os': 'ios',
        'ansible_user': 'user',
        'ansible_ssh_pass': 'pass',
        'ansible_become_method': 'enable',
        'ansible_become_pass': 'pass',
        'ansible_become': True,
        'ansible_python_interpreter': '/usr/bin/python'
    }

    #

# Generated at 2022-06-22 19:55:37.531626
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = 'Python interpreter not found'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'auto_silent'
    assert err.message == 'Python interpreter not found'
    assert err.__str__() == 'Python interpreter not found'
    assert err.__repr__() == 'Python interpreter not found'

# Generated at 2022-06-22 19:55:49.053595
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    '''
    Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
    '''

    obj = InterpreterDiscoveryRequiredError("haha", "python", "auto_legacy")
    assert obj.__repr__() == "haha"
    obj = InterpreterDiscoveryRequiredError("Failed to load interpreter for task", "python", "auto_legacy")
    assert obj.__repr__() == "Failed to load interpreter for task"
    obj = InterpreterDiscoveryRequiredError("Failed to load interpreter for task", "python", "auto_legacy_silent")
    assert obj.__repr__() == "Failed to load interpreter for task"

# Generated at 2022-06-22 19:55:54.037467
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_discovery_action = object()
    # Need to set _connection to prevent errors when running unit tests
    setattr(test_discovery_action, '_connection', object())
    setattr(test_discovery_action, '_discovery_warnings', [])

    setattr(test_discovery_action, '_low_level_execute_command', lambda: {'stdout': u"PLATFORM\nLinux\nFOUND\n/usr/bin/python3\nENDFOUND"})
    setattr(test_discovery_action, '_get_linux_distro', lambda: (u'Debian GNU/Linux', u'buster/sid'))
    setattr(test_discovery_action, '_version_fuzzy_match', lambda x: x)

    test_discovery_task_vars

# Generated at 2022-06-22 19:55:58.612547
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err_obj = InterpreterDiscoveryRequiredError('message', 'python2', 'auto')
    exp_repr = 'message'
    # compare
    assert err_obj.__repr__() == exp_repr



# Generated at 2022-06-22 19:56:02.442269
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    actual = InterpreterDiscoveryRequiredError("test message", "test interpreter", "test discovery_mode")

    assert actual.message == 'test message'
    assert actual.interpreter_name == 'test interpreter'
    assert actual.discovery_mode == 'test discovery_mode'

# Generated at 2022-06-22 19:56:12.583385
# Unit test for function discover_interpreter
def test_discover_interpreter():
    def get_mock_module_class(is_pipelined, stdout=u'', stderr=u'', rc=0, discovery_mode='auto'):
        class MockModule(object):
            _debug = False
            _display = Display()

            def __init__(self, task_vars):
                self._task_vars = task_vars

            def _debug_args(self, *args, **kwargs):
                if self._debug:
                    display.debug(u"MockModule._debug_args: {0}".format(args))

            def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
                self._debug_args(cmd, sudoable, in_data)

# Generated at 2022-06-22 19:56:24.478528
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:56:36.294175
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    test_action = ActionBase()
    test_task_vars = dict()

    test_interpreter_name = 'python'

    # test unix-style distros
    os = 'linux'
    platform_dist_result = ['centos', '6', 'Final']
    osrelease_content = None

# Generated at 2022-06-22 19:56:40.229469
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError(
            message='message',
            interpreter_name='python',
            discovery_mode='auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.__str__() == 'message'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'



# Generated at 2022-06-22 19:56:47.040946
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter ({0}) discovery required for {1}'.format(interpreter_name, discovery_mode)
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_discovery_required_error.interpreter_name == interpreter_name
    assert interpreter_discovery_required_error.discovery_mode == discovery_mode
    assert interpreter_discovery_required_error == message


# Generated at 2022-06-22 19:56:51.536014
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {'ansible_python_interpreter':'/usr/bin/python'}
    interpreter = discover_interpreter(object(), 'python', 'auto', task_vars)
    assert interpreter == u'/usr/bin/python'

# Generated at 2022-06-22 19:56:58.471982
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test basic platform discovery
    assert discover_interpreter(None, 'python', 'auto', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', None) == u'/usr/bin/python'

    # Test error handling
    try:
        discover_interpreter(None, 'python', 'blah', None)
        assert False
    except ValueError:
        pass


# Generated at 2022-06-22 19:57:10.999054
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Run a series of tests to ensure interpreter discovery works as expected. The following tests are performed:
    - test_discover_interpreter_basic
    - test_discover_interpreter_no_python
    - test_discover_interpreter_no_discovery
    All of these are run against 2 different python binaries. The tests should be expanded upon as new discovery
    methods are added.
    """
    # Values for use in tests are kept here for easier modification

# Generated at 2022-06-22 19:57:14.702341
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc=InterpreterDiscoveryRequiredError(
        message="'Message'",
        interpreter_name='interpreter_name',
        discovery_mode='discovery_mode'
    )
    assert repr(exc) == "'Message'"

# Generated at 2022-06-22 19:57:26.978178
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext

    def _load_play_context(data):
        context = PlayContext()
        context.__dict__ = data
        return context

    def _load_task_vars(data):
        return data

    class _SudoableConnection(object):

        def __init__(self, has_pipelining):
            self.has_pipelining = has_pipelining

    class _Executable(object):

        def __init__(self, play_context, connection, task_vars):
            self._play_context = play_context
            self._connection = connection
            self._task_vars = task_vars
            self._discovery_warnings = []


# Generated at 2022-06-22 19:57:39.554306
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({
        "host": {
            "hostname": "host",
            "_ansible_verbosity": 3,
            "somevar": 42
        }
    })

    variable_manager = VariableManager()
    variable_manager.set_inventory(loader)

    vars = variable_manager.get_vars(play=None, host=loader.get_host("host"))
    play_context = PlayContext(**vars)


# Generated at 2022-06-22 19:57:42.105153
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("message", "python3", "auto")
    repr(error)


# Generated at 2022-06-22 19:57:46.643764
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    e = InterpreterDiscoveryRequiredError('test InterpreterDiscoveryRequiredError', interpreter_name, discovery_mode)
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:57:55.446214
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import _get_shebang
    from ansible.module_utils.common._collections_compat import Mapping

    # Test cases:
    #   - discovery mode, set to "auto_legacy"
    #   - discovery mode, set to "yes"
    #   - discovery mode, set to "no"
    #   - task vars, setting the interpreter
    #   - module_path is not Python
    #   - module_path is Python
    #   - module_path is Python3, even if interpreter is Python 2
    #   - module

# Generated at 2022-06-22 19:57:58.591314
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("discovery required", "python", "auto:legacy+warn")
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto:legacy+warn"

# Generated at 2022-06-22 19:58:02.679246
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    expected_value = "this is a test"
    ex = InterpreterDiscoveryRequiredError("this is a test", "python", "auto_silent")
    actual_value = str(ex)
    assert expected_value == actual_value

# Generated at 2022-06-22 19:58:06.150835
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError(message='TestMessage', interpreter_name='TestInterpreterName',
                                            discovery_mode='TestDiscoveryMode')
    assert repr(obj) == 'TestMessage'

# Generated at 2022-06-22 19:58:09.721895
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Discovery required for interpreter python", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto"

# Generated at 2022-06-22 19:58:14.548246
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    msg = u"Interpreter discovery for 'python' is required for this host (discovery mode auto)"
    try:
        raise InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert isinstance(e, InterpreterDiscoveryRequiredError)
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'

# Generated at 2022-06-22 19:58:20.018533
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("test exception", "python", "auto")
    except Exception as e:
        assert "test exception" in str(e)
        assert "python" == e.interpreter_name
        assert "auto" == e.discovery_mode

# Generated at 2022-06-22 19:58:24.648973
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'Test'
    interpreter_name = 'python3'
    discovery_mode = 'auto_legacy'
    ex = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert ex.__str__() == msg

# Generated at 2022-06-22 19:58:32.905156
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        from mock import MagicMock, patch

    # self, host_list, module_name, module_args, inject=None, complex_args=None
    # inject = ['-v', 'vv', 'vvv', 'vvvv', 'vvvvv', 'vvvvvv']
    class FakeOptions(object):
        def __init__(self, forks=None, ask_vault_pass=None, verbosity=None, stdout_callback=None, run_hosts=None):
            self.forks = forks
            self.verbosity = verbosity
            self.stdout_callback = stdout_callback
            self.run_hosts = ['127.0.0.1']

# Generated at 2022-06-22 19:58:43.170825
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock
    import doctest
    # TODO: add test for discovery mode
    # TODO: add test for warning output
    # TODO: add test for multiple interpreters
    # TODO: add test for "nearest version back" logic
    # TODO: add test for "on-disk script" logic
    # TODO: add test for "no interpreter found" logic
    # TODO: add test for "discover failed" logic


# Generated at 2022-06-22 19:58:47.162902
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError("test msg", "test_interpreter_name", "test_discovery_mode")
    assert exc.__repr__() == "test msg"

# Generated at 2022-06-22 19:58:58.129640
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock
    import __main__ as main
    import ansible
    mock_task = mock.Mock()
    mock_task.run_once = False
    mock_task._role = None
    mock_task._play = mock.Mock()
    mock_task._play.deprecate = mock.Mock()
    mock_task._play.deprecate.validate = mock.Mock()
    mock_task._play.deprecate.validate.return_value = 'deprecate: nothing'
    mock_task._play.name = 'test_play'
    mock_task._ds = mock.Mock()
    mock_task._ds.get.return_value = 'test_value'
    mock_task._ds.get.side_effect = lambda x: x
    mock_task._ds.get_first

# Generated at 2022-06-22 19:59:01.139477
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    idre = InterpreterDiscoveryRequiredError('Test Message','python','auto')
    assert idre.interpreter_name == 'python'
    assert idre.discovery_mode == 'auto'
    assert idre.message == 'Test Message'


# Generated at 2022-06-22 19:59:05.739745
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "test message"
    interpreter_name = "test_interpreter"
    discovery_mode = "test_discovery_mode"
    exception = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert exception.__repr__() == msg

# Generated at 2022-06-22 19:59:08.169561
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter() == ""

# Generated at 2022-06-22 19:59:11.561482
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert repr(InterpreterDiscoveryRequiredError('Python interpreter discovery required for {0}', 'python',
                                                  discovery_mode='auto')) == 'Python interpreter discovery required for {0}'


# Generated at 2022-06-22 19:59:15.865659
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    discovery_mode = "test_discovery_mode"
    interpreter_name = "test_interpreter_name"
    message = "test_message"
    te = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == te.__str__()



# Generated at 2022-06-22 19:59:23.405969
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "This is a test"
    idr_error = InterpreterDiscoveryRequiredError("This is a test", 'python', 'auto_legacy_silent')
    assert idr_error.interpreter_name == 'python'
    assert idr_error.discovery_mode == 'auto_legacy_silent'
    assert idr_error.message == msg


# Generated at 2022-06-22 19:59:34.648178
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext()
    templar = Templar(loader=None, variables=dict(), fail_on_undefined=True)
    action = ActionModule(templar, action_loader=None, connection_loader=None, play_context=context, loader=None,
                          shared_loader_obj=None, task_vars=dict(), remove_tmp_path=None)

    # Test invalid mode
    try:
        discover_interpreter(action, 'python', 'unsupportedMode', dict())
    except InterpreterDiscoveryRequiredError as e:
        assert repr(e) is not None
    except Exception as e:
        assert isinstance(e, Exception)

# Generated at 2022-06-22 19:59:40.995695
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError(
        message='Test error message',
        interpreter_name='python',
        discovery_mode='auto'
    )
    assert e.message == 'Test error message'
    assert e.interpreter_name == 'python'
    assert e.discovery_mode == 'auto'

# Generated at 2022-06-22 19:59:43.944738
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    discovery_req_error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert str(discovery_req_error) == "message"

# Generated at 2022-06-22 19:59:48.856285
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'test message'
    interpreter_name = 'test interpreter name'
    discovery_mode = 'test discovery mode'
    try:
        raise InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as err:
        assert err.__repr__() == 'test message'


# Generated at 2022-06-22 19:59:55.763060
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy')
    except InterpreterDiscoveryRequiredError as e:
        exc_message = str(e)
        assert exc_message == 'message'

        interpreter_name = e.interpreter_name
        assert interpreter_name == 'python'

        discovery_mode = e.discovery_mode
        assert discovery_mode == 'auto_legacy'

# Generated at 2022-06-22 20:00:00.055302
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_message = 'test error message'
    interpreter_name = 'python'
    discovery_mode = 'auto'

    try:
        raise InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.__repr__() == error_message

# Generated at 2022-06-22 20:00:08.133281
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("Don't use /usr/bin/python in your playbooks. See https://docs.ansible.com/ansible/2.9/reference_appendices/interpreter_discovery.html for more information.", 'python', 'auto')
    assert str(error) == "Don't use /usr/bin/python in your playbooks. See https://docs.ansible.com/ansible/2.9/reference_appendices/interpreter_discovery.html for more information."


# Generated at 2022-06-22 20:00:13.015991
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys
    sys.modules['ansible.module_utils.distro'] = sys.modules['ansible.module_utils.compat.tests.test_discovery.test_distro']
    interpreter = discover_interpreter('action', 'python', 'auto_legacy', 'task_vars')
    assert interpreter == u'/usr/bin/python'
    interpreter = discover_interpreter('action', 'python', 'auto_legacy_silent', 'task_vars')
    assert interpreter == u'/usr/bin/python'
    interpreter = discover_interpreter('action', 'python', 'auto', 'task_vars')
    assert interpreter == u'/usr/bin/python'
    interpreter = discover_interpreter('action', 'python', 'auto_silent', 'task_vars')
    assert interpreter == u

# Generated at 2022-06-22 20:00:16.547447
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    import pytest
    msg = "test"
    exception = PytestInterpreterDiscoveryRequiredError(msg, "inter_name", "discovery_mode")
    assert repr(exception) == msg


# Generated at 2022-06-22 20:00:20.720753
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
        message = 'Fake Exception'
        interpreter_name = 'python'
        discovery_mode = 'auto_legacy'
        exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
        assert exception.__str__() == message

# Generated at 2022-06-22 20:00:31.800738
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys
    import pytest
    from ansible.executor.discovery import discover_interpreter, _version_fuzzy_match
    from ansible.executor.discovery import _get_linux_distro
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder

    if sys.version_info[0] < 3:
        pytest.skip('Python 2 is EOL')

    task_vars = dict()
    action = dict()
    action._discovery_warnings = []

    # Specification of test data
    #
    # Dict represents INTERPRETER_PYTHON_DISTRO_MAP
    # Key represents Dist

# Generated at 2022-06-22 20:00:42.268864
# Unit test for function discover_interpreter
def test_discover_interpreter():
    bootstrap_python_list = ["/usr/bin/python3"]
    shell_bootstrap = "echo PLATFORM; uname; echo FOUND; {0}; echo ENDFOUND".format('; '.join(["command -v '%s'" % py for py in bootstrap_python_list]))
    platform_interpreter = to_text(_version_fuzzy_match("1.0", {"1.0": "/usr/bin/python",
                                                                "2.0": "/usr/bin/python2",
                                                                "3.0": "/usr/bin/python3"}), errors='surrogate_or_strict')
    class HostInfo:
        platform_type = "linux"
        platform_dist_result = ["ubuntu", "18.04", "bionic"]

# Generated at 2022-06-22 20:00:48.298320
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError("MESSAGE", "python", "auto")
    except InterpreterDiscoveryRequiredError as err:
        assert err.__repr__() == "MESSAGE"
        assert err.__str__() == "MESSAGE"
        assert err.discovery_mode == "auto"
        assert err.interpreter_name == "python"


# Generated at 2022-06-22 20:00:52.022803
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError(message='test', interpreter_name='python', discovery_mode='auto_legacy')
    assert e.__repr__() == 'test'
    assert str(e) == 'test'


# Generated at 2022-06-22 20:01:04.201055
# Unit test for function discover_interpreter
def test_discover_interpreter():
    dargs = dict(
        action=None,
        interpreter_name='python',
        discovery_mode='auto_legacy',
        task_vars=dict(
            inventory_hostname='test',
            ansible_distribution=None,
            ansible_distribution_version=None
        )
    )

    # simple test case - exact match of distribution and version
    assert discover_interpreter(**dict(dargs, task_vars=dict(dargs['task_vars'], ansible_distribution='redhat', ansible_distribution_version='7.4'))) == '/usr/bin/python'

    # test case - version in table is newer than what we're running

# Generated at 2022-06-22 20:01:17.011556
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    from ansible.utils import plugin_docs

    test_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    test_data = os.path.join(test_dir, 'test/units/module_utils/executor/discovery/data')

    # Test various configurations

# Generated at 2022-06-22 20:01:20.666836
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python', discovery_mode='auto_legacy')
    assert err.__repr__() == 'test message'

# Generated at 2022-06-22 20:01:32.946648
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys
    import unittest

    class TestConnection(object):
        class Transport(object):
            def __init__(self, pipelined=False, new_stdin=None):
                self.pipelined = pipelined
                self.new_stdin = new_stdin

        class ActionModule(object):
            def __init__(self, warnings=None):
                self._discovery_warnings = warnings or []

        def __init__(self, pipelined=False, new_stdin=None):
            self.transport = self.Transport(pipelined, new_stdin)

        def _dispatch_module(self, name, args):
            return {'hostname': 'testhost'}

        def has_pipelining(self):
            return self.transport.pipelined

   

# Generated at 2022-06-22 20:01:35.200063
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python3', discovery_mode='auto')
    assert error.message == 'message'
    assert error.interpreter_name == 'python3'
    assert error.discovery_mode == 'auto'

# Generated at 2022-06-22 20:01:39.066573
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'test'
    interpreter_name = 'test'
    discovery_mode = 'test'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.message == message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:01:47.359046
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule

    class ActionModule(_ActionModule):
        def _discovery_warnings(self):
            return []

    display = Display()
    # Just a simple check, with a very basic local testing, to verify the cases
    # on a linux system
    class Test:
        def __init__(self, host, discovery_mode, interpreters, output):
            self.host = host
            self.discovery_mode = discovery_mode
            self.interpreters = interpreters
            self.output = output


# Generated at 2022-06-22 20:01:59.469602
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    from ansible.plugins.action.normal import ActionModule as ActionBase

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.args = []

    test_module = TestModule()

    class TestAction(ActionBase):
        BYPASS_HOST_LOOP = True
        NO_TARGET_SYSTEM_DEPRECATION_WARNING = True

        def __init__(self):
            self._task = None
            self._play_context = None
            self._loaded_fragment = None
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            return {'stdout': 'stdout',
                    'stderr': 'stderr',
                    'rc': 1}

# Generated at 2022-06-22 20:02:02.524735
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')

    assert str(exception).startswith("message")


# Generated at 2022-06-22 20:02:05.011948
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    repr(obj)

# Generated at 2022-06-22 20:02:17.130470
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    import unittest
    import tempfile
    from ansible.executor import action_write_locks as awl
    from ansible.executor.interpreter_discovery import discover_interpreter
    from ansible.utils import unsafe_proxy

    class MockActionModule:
        def __init__(self, adhoc_action=None, connection=None, noop=None, task_vars=None,
                     runner_path=None, remote_user='root', sudo=True, sudo_user='root',
                     become=True, become_user='root', diff=None):
            self._runner_path = runner_path
            self._shared_loader_obj = None
            self._action = adhoc_action
            self._connection = connection

# Generated at 2022-06-22 20:02:22.124438
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = "Interpreter discovery required."
    interpreter_name = "python"
    discovery_mode = "implicit"
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert repr(message) == repr(e)



# Generated at 2022-06-22 20:02:27.548555
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError(message=u'Exception message', interpreter_name=u'Interpreter', discovery_mode=u'auto_legacy_silent')
    assert exception.__repr__() == u'<InterpreterDiscoveryRequiredError(message=Exception message, interpreter_name=Interpreter, discovery_mode=auto_legacy_silent)>'


# Generated at 2022-06-22 20:02:31.210803
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    ex = InterpreterDiscoveryRequiredError('Interpreter discovery required', interpreter_name, discovery_mode)
    assert to_text(ex) == to_text(ex.message)


# Generated at 2022-06-22 20:02:39.122582
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    attrs = {'message': 'Foo', 'interpreter_name': 'python', 'discovery_mode': 'auto_legacy_silent'}
    error = InterpreterDiscoveryRequiredError(**attrs)
    print('InterpreterDiscoveryRequiredError message: ' + error.message)
    assert vars(error) == attrs
    assert repr(error) == 'Foo'
    assert str(error) == 'Foo'


# Generated at 2022-06-22 20:02:42.289178
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError(message='some message', interpreter_name='python', discovery_mode='auto')

    assert repr(e) == e.message



# Generated at 2022-06-22 20:02:47.478919
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'TestMessage'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert(error.message == message)
    assert(error.interpreter_name == interpreter_name)
    assert(error.discovery_mode == discovery_mode)

# Generated at 2022-06-22 20:02:52.451191
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('test error message', 'python', 'auto_legacy_silent')
    assert str(error) == 'test error message'
    assert repr(error) == 'test error message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-22 20:03:00.640125
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    import io
    from io import StringIO
    import sys

    captured_output = StringIO()
    sys.stdout = captured_output

    try:
        raise InterpreterDiscoveryRequiredError('Python interpreter discovery is required but not enabled', 'python', 'silent')
    except InterpreterDiscoveryRequiredError:
        output = 'Python interpreter discovery is required but not enabled'
    finally:
        sys.stdout = sys.__stdout__

    assert captured_output.getvalue() == output + "\n"

# Generated at 2022-06-22 20:03:03.864133
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'automatic'
    message = 'Interpreter Discovery Required'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == str(error)

# Generated at 2022-06-22 20:03:06.683785
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # undefined: __repr__ method not defined
    # pass
    InterpreterDiscoveryRequiredError(message='', interpreter_name='', discovery_mode='').__repr__()



# Generated at 2022-06-22 20:03:08.629313
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert repr(error) == "message"



# Generated at 2022-06-22 20:03:12.103184
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Test method __repr__ of class InterpreterDiscoveryRequiredError."""
    msg = "Error message"
    interpreter_name = "python"
    discovery_mode = "auto"
    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert repr(err) == msg


# Generated at 2022-06-22 20:03:19.217850
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    # Create an instance of InterpreterDiscoveryRequiredError
    msg = "The interpreter 'python' was not found on the remote host"
    interpreter_name = "python"
    discovery_mode = "auto"
    e = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    # Check correct output
    assert e.__repr__() == msg


# Generated at 2022-06-22 20:03:22.697774
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = "Test InterpreterDiscoveryRequiredError __str__"
    error = InterpreterDiscoveryRequiredError(error_message, "python3", "auto")
    assert str(error) == error_message

# Generated at 2022-06-22 20:03:30.674353
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = "Discovery Mode: auto_legacy_silent, Interpreter Name: python"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    expected = "Discovery Mode: auto_legacy_silent, Interpreter Name: python"
    actual = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert actual.__repr__() == expected

# Generated at 2022-06-22 20:03:38.035409
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "Some_name"
    discovery_mode = "discovery_mode"
    message = "Some_message"


    # Check with valid values
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == message
        assert ex.interpreter_name == interpreter_name
        assert ex.discovery_mode == discovery_mode
        assert str(ex) == message

# Generated at 2022-06-22 20:03:42.320627
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    discovery_mode = 'auto_silent'
    interpreter_name = 'python'
    message = 'failed automatically in silent mode'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(error) == message
    assert repr(error) == message

# Generated at 2022-06-22 20:03:51.690190
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # prepare test data
    task_vars = dict(
        inventory_hostname=u"",
        ansible_python_interpreter=C.DEFAULT_INTERPRETER_PYTHON,
        ansible_discovery_interpreter_python=C.DEFAULT_INTERPRETER_DISCOVERY_MODE,
    )

    # run the test
    res = discover_interpreter(None, "python", C.DEFAULT_INTERPRETER_DISCOVERY_MODE, task_vars=task_vars)

    # test Python 3 is the interpreter
    assert 'python3' in res

# Generated at 2022-06-22 20:03:59.765760
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Sorry, no python interpreter found in known paths.'
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as interpreter_discovery_required_error:
        assert interpreter_discovery_required_error.interpreter_name == interpreter_name
        assert interpreter_discovery_required_error.discovery_mode == discovery_mode
        assert interpreter_discovery_required_error.message == message
