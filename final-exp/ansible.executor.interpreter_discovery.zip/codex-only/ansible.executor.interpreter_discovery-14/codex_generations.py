

# Generated at 2022-06-22 19:54:04.599271
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', None) == u'/usr/bin/python'
    # TODO: add more tests

# Generated at 2022-06-22 19:54:12.734979
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Expected error message"
    with pytest.raises(Exception) as e:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.value.interpreter_name == interpreter_name
    assert e.value.discovery_mode == discovery_mode
    assert e.value.message == message
    assert str(e.value) == message
    assert repr(e.value) == message

# Generated at 2022-06-22 19:54:21.840793
# Unit test for function discover_interpreter
def test_discover_interpreter():
    distro_map = {
        'rhel': {
            '6': '/usr/bin/python2.7',
            '7': '/usr/bin/python3',
            '8': '/usr/bin/python3'
        },
        'centos': {
            '6': '/usr/bin/python2.6',
        },
        'debian': {
            '8': '/usr/bin/python2.7',
            '9': '/usr/bin/python3',
        },
        'ubuntu': {
            '16.04': '/usr/bin/python3',
            '18.04': '/usr/bin/python3',
        },
    }


# Generated at 2022-06-22 19:54:24.608014
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    repr_result = repr(InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode"))
    assert repr_result == "message"



# Generated at 2022-06-22 19:54:31.225835
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Test for expection thrown
    with pytest.raises(InterpreterDiscoveryRequiredError) as e:
        raise InterpreterDiscoveryRequiredError('discovery_required', 'python', 'auto')
    assert str(e.value) == 'discovery_required'
    assert repr(e.value) != ''
    assert e.value.interpreter_name == 'python'
    assert e.value.discovery_mode == 'auto'


# Generated at 2022-06-22 19:54:33.792122
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Arrange
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'test message'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    # Act
    got = e.__repr__()
    # Assert
    assert got == message


# Generated at 2022-06-22 19:54:37.393229
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test to ensure proper instantiation of the class
    try:
        raise InterpreterDiscoveryRequiredError('This is an error message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        print(e.interpreter_name + " " + e.discovery_mode)

# Generated at 2022-06-22 19:54:39.724951
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('message text', 'python', 'auto')
    assert error.__repr__() == 'message text'


# Generated at 2022-06-22 19:54:42.722331
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert error.__str__() == "message"


# Generated at 2022-06-22 19:54:50.845006
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test with a dictionary containing ansible config
    res = discover_interpreter(None, 'python', 'auto_silent', {'ansible_config': {'interpreter_python_distro_map': {'redhat': {'7.4': '/usr/bin/python2.7'}}}})
    # Test with a dictionary containing interpreter config
    assert res == '/usr/bin/python2.7'

# Test for function _get_linux_distro

# Generated at 2022-06-22 19:54:55.285474
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError('Message','python','auto_legacy')
    assert str(interpreter_discovery_required_error) == 'Message'
    assert repr(interpreter_discovery_required_error) == 'Message'


# Generated at 2022-06-22 19:55:01.584270
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message="""discovery required but not supported: interpreted: python, discovery_mode: auto_legacy_silent"""
    e=InterpreterDiscoveryRequiredError(message,"python","auto_legacy_silent")
    assert e.message==message
    assert e.interpreter_name=="python"
    assert e.discovery_mode == "auto_legacy_silent"
    assert e.__str__()==message
    assert e.__repr__()==message

# Generated at 2022-06-22 19:55:12.913110
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # initialize required objects
    loader = DataLoader()
    inventory = InventoryManager(loader, sources=['tests/inventory_invalid.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    task_vars = dict()
    play_context = PlayContext()
    play_context.network_os = 'linux'

    task = dict(
        action=dict(
            module='test',
        ),
    )

    result

# Generated at 2022-06-22 19:55:15.436048
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('test_message', 'test_interpreter_name', 'test_discovery_mode')
    assert err.__repr__() == 'test_message'

# Generated at 2022-06-22 19:55:27.752414
# Unit test for function discover_interpreter
def test_discover_interpreter():
    platform_python_map = {
        'centos': {
            '6': '/usr/bin/python',
            '7': '/usr/bin/python2',
        },
        'redhat': {
            '6': '/usr/bin/python',
            '7': '/usr/bin/python2',
        },
    }

    action = MockAction()

    # Test invalid platform type
    try:
        discover_interpreter(action, 'python', 'auto', {u'inventory_hostname': 'a', 'INTERPRETER_PYTHON_DISTRO_MAP': platform_python_map})
        assert False
    except NotImplementedError as e:
        assert str(e) == 'unsupported platform for extended discovery: unknown'

    # Test not implemented platform type

# Generated at 2022-06-22 19:55:38.183564
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()

    # This should work (but is not supported) on macOS and Windows
    platform_python_map = dict()
    platform_python_map['centos'] = dict()
    platform_python_map['centos']['6'] = '/usr/bin/python2.6'
    platform_python_map['centos']['7'] = '/usr/bin/python3.6'
    platform_python_map['opensuse'] = dict()
    platform_python_map['opensuse']['15'] = '/usr/bin/python3.6'
    platform_interpreter = discover_interpreter(None, 'python', 'auto', task_vars,
                                                platform_python_map, ['debian_python_interpreter'])

# Generated at 2022-06-22 19:55:46.054033
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'DummyError'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    test_exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert test_exception.message == message
    assert test_exception.interpreter_name == interpreter_name
    assert test_exception.discovery_mode == discovery_mode
    assert test_exception.__repr__() == 'DummyError'
    assert test_exception.__str__() == 'DummyError'


# Generated at 2022-06-22 19:55:53.760279
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError('test message', 'test_interpreter_name', 'test_discovery_mode')
    except InterpreterDiscoveryRequiredError as ex:
        assert to_text(ex) == 'test message'
        assert ex.__repr__() == 'test message'
        assert ex.interpreter_name == 'test_interpreter_name'
        assert ex.discovery_mode == 'test_discovery_mode'

# Generated at 2022-06-22 19:55:59.074556
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name,
                                              discovery_mode=discovery_mode)
    assert error.__repr__() == message

# Generated at 2022-06-22 19:56:05.493874
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Given
    class MockException(Exception):
        pass
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = str(MockException())
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    # When
    result = repr(e)
    # Then
    assert result == message, repr(e)

# Generated at 2022-06-22 19:56:13.099943
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            "Missing interpreter_name in interpreter_python module, interpreter_python action or playbook",
            "python", "auto_legacy_silent")
    except InterpreterDiscoveryRequiredError as exception:
        assert exception.message == "Missing interpreter_name in interpreter_python module, interpreter_python action or playbook"
        assert exception.interpreter_name == "python"
        assert exception.discovery_mode == "auto_legacy_silent"
    else:
        assert False

# Generated at 2022-06-22 19:56:13.696320
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    pass

# Generated at 2022-06-22 19:56:16.281267
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_object = InterpreterDiscoveryRequiredError("Error message", "interpreter name", "mode")
    message = error_object.__repr__()
    assert message == "Error message"

# Generated at 2022-06-22 19:56:21.460075
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_msg = "No interpreter found"
    sut = InterpreterDiscoveryRequiredError(
        error_msg,
        "python",
        "always_auto"
    )
    result = str(sut)
    assert result == error_msg

# Generated at 2022-06-22 19:56:24.221866
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(action=None, interpreter_name='python', discovery_mode='auto_silent', task_vars={}) == u'/usr/bin/python'

# Generated at 2022-06-22 19:56:30.064609
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    with pytest.raises(ValueError) as excinfo:
        raise InterpreterDiscoveryRequiredError("discovery mode must be in_development, auto, auto_legacy, or auto_legacy_silent", "python", "mode")
    assert excinfo.type == InterpreterDiscoveryRequiredError
    assert excinfo.value.interpreter_name == "python"
    assert excinfo.value.discovery_mode == "mode"

# Generated at 2022-06-22 19:56:32.207721
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # repr of InterpreterDiscoveryRequiredError() is not implemented
    # TODO: proper repr impl
    pass

# Generated at 2022-06-22 19:56:36.058001
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    obj = InterpreterDiscoveryRequiredError("test message", "py3", "legacy_silent")
    obj.__str__()

    assert isinstance(obj, InterpreterDiscoveryRequiredError)

# Generated at 2022-06-22 19:56:37.878885
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    example = InterpreterDiscoveryRequiredError("example", "python", "auto")
    assert str(example) == "example"
    assert repr(example) == "example"


# Generated at 2022-06-22 19:56:42.837621
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Arrange
    message = "message"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent_no_warn"

    # Act
    expected = "message"
    actual = repr(InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode))

    # Assert
    assert expected == actual

# Generated at 2022-06-22 19:56:52.750391
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object()
    task_vars = dict()

    # Test alias python3 match - note that in this case the target should already be using python3, but we want to make
    # sure that the alias is handled properly
    python3 = discover_interpreter(action, 'python3', 'auto', task_vars)
    assert python3 == '/usr/bin/python3', 'python3 alises failed'

    # Test python discovery
    python = discover_interpreter(action, 'python', 'auto', task_vars)
    assert python == '/usr/bin/python', 'python discovery failed'

# Generated at 2022-06-22 19:56:59.581073
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MyAction:
        _connection = None
        _low_level_execute_command = None

    my_action = MyAction()
    my_action._low_level_execute_command = lambda x, y, z: {'stdout': """PLATFORM
Linux
FOUND
/usr/bin/py2
/usr/bin/py3
ENDFOUND"""}
    print(discover_interpreter(my_action, 'python', 'auto', {}))

    my_action._low_level_execute_command = lambda x, y, z: {'stdout': """PLATFORM
linux
FOUND
/usr/bin/python
ENDFOUND"""}
    print(discover_interpreter(my_action, 'python', 'auto', {}))


# Generated at 2022-06-22 19:57:03.716138
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    expected = 'abc'
    test_obj = InterpreterDiscoveryRequiredError('abc', 'python', 'auto')
    assert str(test_obj) == expected


# Generated at 2022-06-22 19:57:09.503197
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto"
    error_message = "Discovery required for interpreter 'python' with mode 'auto'"
    idre = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert str(idre) == error_message
    assert repr(idre) == error_message

# Unit tests for discover_interpreter

# Generated at 2022-06-22 19:57:13.064433
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    instance = InterpreterDiscoveryRequiredError(
        message="Interpreter discovery required for python on remote host",
        interpreter_name="python",
        discovery_mode="auto_silent")
    assert str(instance) == "Interpreter discovery required for python on remote host"

# Generated at 2022-06-22 19:57:15.350241
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert str(ex) == 'message'

# Generated at 2022-06-22 19:57:21.282154
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError(
        'message',
        'python',
        'auto_legacy_silent')

    # In python3, __str__ returns a unicode object
    assert(isinstance(exc.__str__(), str))
    assert(exc.__str__() == 'message')

# Generated at 2022-06-22 19:57:23.410889
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert error.__str__() == 'message'

# Generated at 2022-06-22 19:57:35.992799
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    class ActionModule(ActionBase):
        pass

    action = ActionModule(None, {})
    task_vars = dict()


# Generated at 2022-06-22 19:57:42.519692
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import _get_action
    task_vars = {'ansible_play_hosts': ['foo']}
    action = _get_action('/foo/bar', task_vars)
    actual = discover_interpreter(action, 'python', 'auto', task_vars)
    assert actual == '/usr/bin/python'

# Generated at 2022-06-22 19:57:52.000651
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest

    class Action:
        def __init__(self):
            self._discovery_warnings = []
            self._connection = ActionConnection()

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            return ActionConnection()._low_level_execute_command(command, sudoable, in_data)

    # ActionConnection only implements the _low_level_execute_command method.
    class ActionConnection:
        def __init__(self):
            self.has_pipelining = True

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            assert command

# Generated at 2022-06-22 19:57:56.150215
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert repr(InterpreterDiscoveryRequiredError(
        message="m", interpreter_name="in", discovery_mode="dm")) \
        == "m"

# Generated at 2022-06-22 19:58:01.925260
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class FakeConnection(object):
        def __init__(self):
            self.has_pipelining = True

    class FakeAction(object):
        def __init__(self):
            self._connection = FakeConnection()
            self.module_name = 'shell'
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            res = {}

            if in_data:
                # simulate distro script upload
                if 'platform.dist' in to_text(in_data):
                    # simulate distro script return
                    res['stdout'] = "{\"platform_dist_result\": [\"redhat\", \"8.0\", \"\"]}"
                    return res

            # return 3 known interpreters

# Generated at 2022-06-22 19:58:11.910006
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:58:17.250113
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    class_name = 'InterpreterDiscoveryRequiredError'
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    error = InterpreterDiscoveryRequiredError(message,
                                              interpreter_name,
                                              discovery_mode)
    assert error.__str__() == message

# Generated at 2022-06-22 19:58:20.181131
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError("message", "python", "auto_silent")
    assert str(exc).startswith("message")


# Generated at 2022-06-22 19:58:28.508089
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = "python interpreter auto discovery required for host host.example.com"
    except_object = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert interpreter_name == except_object.interpreter_name
    assert discovery_mode == except_object.discovery_mode
    assert message == except_object.message
    assert message == str(except_object)    # same as str(except_object)
    assert message == repr(except_object)    # same as str(except_object)

# Generated at 2022-06-22 19:58:32.838172
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', {})
    assert discover_interpreter(None, 'python', 'auto_silent', {})
    assert discover_interpreter(None, 'python', 'auto_legacy', {})
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {})

# Generated at 2022-06-22 19:58:40.806062
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'interpreter not found'
    skip_interpreter_discovery = True
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    error.skip_interpreter_discovery = skip_interpreter_discovery
    expected_result = 'interpreter not found. discovery mode: auto_legacy_silent'
    assert (error.__str__() == expected_result)

# Generated at 2022-06-22 19:58:51.498679
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader

    test_action = ActionBase()
    test_action._discovery_warnings = []

    test_task_vars = dict(
        ansible_connection='ssh',
        ansible_python_interpreter='/usr/bin/python',
        ansible_user='root',
    )

    # test bad discovery mode
    try:
        discover_interpreter(test_action, interpreter_name='python', discovery_mode='bogus', task_vars=test_task_vars)
        raise Exception("Should have failed")
    except ValueError:
        pass

    # test different connection methods (-k, -K)

# Generated at 2022-06-22 19:58:56.358900
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    expected_output = "test"
    actual_output = repr(error)
    assert actual_output == expected_output, \
        "Expected output: {0}, Actual output: {1}".format(expected_output, actual_output)


# Generated at 2022-06-22 19:58:59.443088
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_obj = InterpreterDiscoveryRequiredError("test_message", "test_interpreter_name", "test_discovery_mode")
    assert test_obj.__repr__() == "test_message"

# Generated at 2022-06-22 19:59:03.928389
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(message="This interpreter is not installed",
                                                interpreter_name='not_installed',
                                                discovery_mode='auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == 'not_installed'
        assert ex.discovery_mode == 'auto'

# Generated at 2022-06-22 19:59:10.380102
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('foo', 'python', 'auto_legacy_silent')
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto_legacy_silent'
    assert str(error) == 'foo'
    assert repr(error) == 'foo'

# Generated at 2022-06-22 19:59:13.972777
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("msg", "python", "auto_legacy_silent")
    exp_repr = "msg"
    assert error.__repr__() == exp_repr
# end of __repr__ test

# Generated at 2022-06-22 19:59:25.153106
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    try:
        print("TEST START")
        print("TEST expected output:\n"
              "unhandled error")
        raise InterpreterDiscoveryRequiredError("unhandled error", "test_interpreter", "test_discovery_mode")
    except InterpreterDiscoveryRequiredError as e:
        print("TEST actual output:\n"
              "exception raised: {0}".format(e))
        assert e.interpreter_name == "test_interpreter"
        assert e.discovery_mode == "test_discovery_mode"
        assert "unhandled error" in str(e)
        assert "unhandled error" in repr(e)
        print("TEST END")

# Generated at 2022-06-22 19:59:28.518004
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    iex = InterpreterDiscoveryRequiredError('error message', 'python', 'auto')
    assert iex.message == 'error message'
    assert iex.interpreter_name == 'python'
    assert iex.discovery_mode == 'auto'

# Generated at 2022-06-22 19:59:30.833400
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    result = str(InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode"))
    assert result == 'message'

# Generated at 2022-06-22 19:59:34.832461
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(u'error message', u'python', u'auto_legacy_silent')
    assert "[Errno 256] error message" in str(error)
    assert "interpreter_name: python" in str(error)
    assert "discovery_mode: auto_legacy_silent" in str(error)



# Generated at 2022-06-22 19:59:47.612577
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class mock_action():

        def __init__(self):
            self._discovery_warnings = []
            self._connection = TestConnection()

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            res = TestCommand(command, in_data=in_data)
            return res

    action = mock_action()

    class TestConnection():
        def __init__(self):
            self.has_pipelining = True

    class TestCommand():
        def __init__(self, command, in_data):
            self.command = command
            self.in_data = in_data


# Generated at 2022-06-22 19:59:53.660029
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    IDRE = InterpreterDiscoveryRequiredError('foo', 'bar', 'baz')
    assert hasattr(IDRE, 'interpreter_name')
    assert IDRE.interpreter_name == 'bar'
    assert hasattr(IDRE, 'discovery_mode')
    assert IDRE.discovery_mode == 'baz'
    assert repr(IDRE) == IDRE.message

# Generated at 2022-06-22 19:59:58.670536
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "Interpreter Discovery Required!"
    interpreter_name = "python"
    discovery_mode = "auto"
    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert isinstance(err, InterpreterDiscoveryRequiredError) is True


# Generated at 2022-06-22 20:00:03.269717
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(
        message = 'error message',
        interpreter_name = 'python',
        discovery_mode = 'auto_legacy_silent'
    )

    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-22 20:00:07.664531
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(message='message', interpreter_name='interpreter_name', discovery_mode='discovery_mode')
    assert_equal(str(err), 'message')


# Generated at 2022-06-22 20:00:11.130586
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('dummy message',
                                            interpreter_name='preter',
                                            discovery_mode='disco_mode')
    assert repr(err) == 'dummy message'

# Generated at 2022-06-22 20:00:13.287705
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
  assert str(InterpreterDiscoveryRequiredError('msg', 'py', 'auto')) == 'msg'


# Generated at 2022-06-22 20:00:18.538289
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = 'Interpreter discovery required'
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    err = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert str(err) == error_message

# Generated at 2022-06-22 20:00:30.153102
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('auto_legacy') == '/usr/bin/python'
    assert discover_interpreter('auto_legacy') == '/usr/bin/python'
    assert discover_interpreter('auto_legacy') == '/usr/bin/python'
    assert discover_interpreter('auto_legacy') == '/usr/bin/python'
    assert discover_interpreter('auto_legacy') == '/usr/bin/python'
    assert discover_interpreter('auto_legacy') == '/usr/bin/python'
    assert discover_interpreter('auto_legacy') == '/usr/bin/python'
    assert discover_interpreter('auto_legacy') == '/usr/bin/python'
    assert discover_interpreter('auto_legacy') == '/usr/bin/python'
   

# Generated at 2022-06-22 20:00:41.530900
# Unit test for function discover_interpreter
def test_discover_interpreter():

    try:
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
    except ImportError as e:
        raise SkipTest(e)

    # initialize required objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test Python interpreter discovery
    # TODO: test warnings, fallback/failure paths

    # test RHEL-7.6
    inventory.add_host(host=Host("host_name_1"))
    variable_manager.set_host_variable("host_name_1", "platform_dist_result", ['redhat', '7.6', 'Maipo'])


# Generated at 2022-06-22 20:00:45.897946
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "error message"
    interpreter_name = "python"
    discovery_mode = "auto"
    instance = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert instance.__str__() == message

# Generated at 2022-06-22 20:00:57.113565
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    import ansible.executor.task_result as task_result
    import ansible.executor.task_executor as task_executor
    import ansible.executor.action_executor as action_executor
    import ansible.executor.module_common as module_common
    import ansible.plugins.loader as plugins
    import ansible.plugins.action as action
    action.add_directory(modules_action_path)
    plugins.add_directory(module_path)
    hostvars = dict()
    play_context = PlayContext()
    play_context._become_method = 'sudo'
    play_context._become_user = 'root'
    host = 'localhost'

# Generated at 2022-06-22 20:01:08.804642
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = u'python'
    discovery_mode = u'auto'
    error_message = u"Interpreter Discovery is required for this version of Ansible. For more information, please see " \
                    u"https://docs.ansible.com/ansible/devel/reference_appendices/interpreter_discovery.html"
    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)

    assert error.message == error_message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert str(error) == error_message
    assert repr(error) == error_message



# Generated at 2022-06-22 20:01:13.652729
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Unit test for method __repr__ of class InterpreterDiscoveryRequiredError"""
    exception = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert str("message") == exception.__repr__()
    assert str("message") == exception.__str__()

# Generated at 2022-06-22 20:01:16.077628
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    assert err == 'test'

# Generated at 2022-06-22 20:01:21.139307
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Given
    exception = InterpreterDiscoveryRequiredError(message='Some message', interpreter_name='python', discovery_mode='auto_legacy')
    # When
    actual = exception.__repr__()
    # Then
    assert actual == 'Some message'

# Generated at 2022-06-22 20:01:29.633764
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test with interpreter name not python
    exception = InterpreterDiscoveryRequiredError('message', 'test_interpreter', 'strict')
    assert exception.interpreter_name == 'test_interpreter'
    assert exception.discovery_mode == 'strict'
    # Test with interpreter name python
    exception = InterpreterDiscoveryRequiredError('message', 'python', 'strict')
    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'strict'

# Generated at 2022-06-22 20:01:37.609567
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    """Test that __str__ of InterpreterDiscoveryRequiredError does not throw an exception"""
    msg = 'EVERYTHING IS ON FIRE!'
    interp = 'python'
    discovery_mode = 'auto'
    try:
        raise InterpreterDiscoveryRequiredError(msg, interp, discovery_mode)
    except InterpreterDiscoveryRequiredError as exception:
        assert exception.__str__() == msg
        assert exception.interpreter_name == interp
        assert exception.discovery_mode == discovery_mode

# Unit tests for method _get_linux_distro

# Generated at 2022-06-22 20:01:42.599780
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    a = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert a.__str__() == 'message'
    assert a.__repr__() == 'message'

# Generated at 2022-06-22 20:01:44.642323
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    c = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    result = repr(c)
    assert result == "message"

# Generated at 2022-06-22 20:01:49.962843
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Valid python paths
    python_paths = ['python', 'python3']
    for path in python_paths:
        assert discover_interpreter(path)

    # Invalid python path
    python_path = 'python2'
    try:
        discover_interpreter(python_path)
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-22 20:01:53.388604
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = u"Interpreter Discovery Required"
    test_err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert test_err.interpreter_name == interpreter_name
    assert test_err.discovery_mode == discovery_mode
    assert str(test_err) == message
    assert repr(test_err) == message

# Generated at 2022-06-22 20:02:01.412393
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name='python_for_repr_test'
    discovery_mode='auto_silent_for_repr_test'
    msg = u"Interpreter discovery not required with {0} interpreter and {1} discovery mode".format(interpreter_name,
                                                                                                   discovery_mode)
    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert err.__repr__() == msg

# Generated at 2022-06-22 20:02:07.262776
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('An Exception', 'python', 'auto_legacy_silent')
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'auto_legacy_silent'
    assert not err.__repr__()
    assert str(err) == 'An Exception'

# Generated at 2022-06-22 20:02:10.240232
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "some_discovery_mode"
    message = "some_message"
    test_exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert test_exception.__str__() == message


# Generated at 2022-06-22 20:02:22.352461
# Unit test for function discover_interpreter
def test_discover_interpreter():
    fake_task_vars = dict()

    display.display = lambda msg, color=None, stderr=False, screen_only=False, log_only=False: msg
    display.verbosity = 4

    fake_action = dict()
    fake_action['_discovery_warnings'] = []
    fake_action['_low_level_execute_command'] = lambda cmd, sudoable=False, in_data=None: dict(stdout=cmd, stderr=None)

    # discover_interpreter
    # Case 1 : interpreter_name is 'python'
    # Case 2 : interpreter_name is 'python2'
    # Case 3 : interpreter_name is 'python3'


    # Case 1 : interpreter_name is 'python'

# Generated at 2022-06-22 20:02:26.192227
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("test", "python", "auto_legacy")
    assert(error.message == "test")
    assert(error.interpreter_name == "python")
    assert(error.discovery_mode == "auto_legacy")

# Generated at 2022-06-22 20:02:34.237918
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.test import TestModule

    # Setup
    pm = TestModule()
    pm.init(PlayContext())

    # Test: valid python3 interpreter discovery
    pm._connection.has_pipelining = True
    pm.set_options(connection='local')
    res = discover_interpreter(pm, 'python', 'auto', {})
    assert pm._discovery_warnings == [], 'Warning: {0}'.format(pm._discovery_warnings)
    assert res is not None, 'No interpreter found for python'
    assert res.endswith('python'), 'Wrong interpreter found for python'

    # Test: error on invalid interpreter name

# Generated at 2022-06-22 20:02:38.967382
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    '''
    Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
    '''
    res = InterpreterDiscoveryRequiredError(None, None, None)
    assert res.__repr__() == None

# Generated at 2022-06-22 20:02:43.393624
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = u'python'
    discovery_mode = u'strict'
    err = InterpreterDiscoveryRequiredError(u'Test', interpreter_name, discovery_mode)
    assert err.__repr__() == u'Test'



# Generated at 2022-06-22 20:02:53.779226
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockRunner(object):

        def __init__(self, interpreter_name, discovery_mode, task_vars):
            self.tasks = []

            class MockTask(object):
                def __init__(self, runner, interpreter_name, discovery_mode, task_vars):
                    self.runner = runner
                    self.interpreter_name = interpreter_name
                    self.discovery_mode = discovery_mode
                    self.task_vars = task_vars
                    self._discovery_warnings = []

                def __call__(self, connection):
                    return self.runner.discover_interpreter(self, connection)

            self.tasks.append(MockTask(self, interpreter_name, discovery_mode, task_vars))


# Generated at 2022-06-22 20:03:00.907679
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert interpreter_discovery_required_error.message == "message"
    assert interpreter_discovery_required_error.interpreter_name == "interpreter_name"
    assert interpreter_discovery_required_error.discovery_mode == "discovery_mode"

# Generated at 2022-06-22 20:03:08.556029
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    import unittest.mock
    with unittest.mock.patch('ansible.module_utils.interpreter_discovery.InterpreterDiscoveryRequiredError.message', new_callable=unittest.mock.PropertyMock) as mock_message:
        mock_message.return_value = "MOCK_MESSAGE"
        assert InterpreterDiscoveryRequiredError("MOCK_MESSAGE", "MOCK_INTERPRETER_NAME", "MOCK_DISCOVERY_MODE").__str__() == "MOCK_MESSAGE"

# Generated at 2022-06-22 20:03:16.028981
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError(
            message="shell interpreter discovery required",
            interpreter_name="shell",
            discovery_mode="auto"
        )
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == "shell"
        assert ex.discovery_mode == "auto"
        assert str(ex).startswith(ex.message)
        assert ex.message == "shell interpreter discovery required"


# Generated at 2022-06-22 20:03:26.529918
# Unit test for function discover_interpreter
def test_discover_interpreter():
    def test_discovery_fallback(msg, interpreter_name, discovery_mode, task_vars, exceptions=(NotImplementedError,)) -> None:
        with display.override_verbosity(2):
            try:
                discover_interpreter(None, interpreter_name, discovery_mode, task_vars)
                raise Exception('Should have failed, but did not')
            except Exception as ex:
                if not isinstance(ex, exceptions):
                    raise ex
                assert isinstance(ex, InterpreterDiscoveryRequiredError), msg

    def test_discovery(msg, interpreter_name, discovery_mode, task_vars, expected_interpreter):
        assert expected_interpreter == discover_interpreter(None, interpreter_name, discovery_mode, task_vars), msg


# Generated at 2022-06-22 20:03:33.622517
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_error = InterpreterDiscoveryRequiredError("test error", "test_interpreter", "test_discovery_mode")

    error_text = str(test_error)
    assert error_text == 'test error', "Incorrect error text"

    assert test_error.interpreter_name == "test_interpreter", "Incorrect interpreter_name"
    assert test_error.discovery_mode == "test_discovery_mode", "Incorrect discovery_mode"

# Generated at 2022-06-22 20:03:36.970507
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError(message='My message', interpreter_name='python', discovery_mode='auto')
    assert exc.__str__() == 'My message'

# Generated at 2022-06-22 20:03:41.952531
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host_vars = dict(ansible_discovery_interpreter='python', ansible_python_interpreter_discovery_mode='auto_legacy_silent')
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', host_vars) == u"/usr/bin/python"


# Generated at 2022-06-22 20:03:49.558688
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'message'
    ider = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ider.message == "message"
    assert ider.interpreter_name == 'python'
    assert ider.discovery_mode == 'auto_legacy_silent'
    assert ider.__repr__() == 'message'

# Generated at 2022-06-22 20:04:01.710839
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import shutil
    import tempfile

    thisdir = os.path.dirname(os.path.realpath(__file__))
    testdir = tempfile.mkdtemp(prefix=u"test_executor_discover_interpreter")


# Generated at 2022-06-22 20:04:12.832455
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # discover_interpreter will be called by the future interpreter plugin implementation
    # FUTURE: test that

    # Testing the function itself here is difficult, because it's basically a wrapper around some large
    # data structures, and mocking out a lot of the test would be more trouble than it's worth.

    # To some extent, just running the unit tests twice, once with and once without the compatibility plugin
    # in the build, will test that.

    # As a sanity check, though, let's make sure the map we're using is sane, by looking for some known
    # distro names and making sure the map looks about right.

    import pytest

    # using the current interpreter, find the interpreter discovery plugin
    interpreter_plugin = None