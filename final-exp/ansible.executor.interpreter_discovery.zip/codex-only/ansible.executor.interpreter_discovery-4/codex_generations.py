

# Generated at 2022-06-22 19:54:04.893676
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError("Test Message", "python2", "auto")
    assert str(err) == "Test Message"
    assert err.interpreter_name == "python2"
    assert err.discovery_mode == "auto"



# Generated at 2022-06-22 19:54:10.619601
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    req_err = InterpreterDiscoveryRequiredError('message', 'interpreter', 'discovery')
    assert str(req_err) == 'message'
    assert req_err.interpreter_name == 'interpreter'
    assert req_err.discovery_mode == 'discovery'

# Generated at 2022-06-22 19:54:16.791018
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'some message'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(err) == message
    assert str(err) == message

# Generated at 2022-06-22 19:54:21.642788
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Unit test for method `__repr__` of class `InterpreterDiscoveryRequiredError`."""
    message = 'The interpreter "python" was not found in any of the candidate locations'
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    task_vars = {}
    actual = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode).__repr__()
    expected = message
    assert actual == expected

# Generated at 2022-06-22 19:54:32.720645
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test_display_mock = DisplayMock()
    # display_mock = test_display_mock.display
    # ---
    # Implements 1. Python 2.6 - 2.7
    # Implements 2. Python 3.6
    # Python 2.6 is not installed.
    # Python 3.8 is not installed.

    # If Python 3.6 only is installed
    interpreters = ['python3.6']

    mocked_res = {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python3.6\nENDFOUND\n', 'stderr': ''}

# Generated at 2022-06-22 19:54:34.155863
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ex = InterpreterDiscoveryRequiredError(Exception(), 'python', 'prefer_legacy')
    repr(ex)
    repr(ex)

# Generated at 2022-06-22 19:54:36.966541
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('This is my message', 'python', 'auto_legacy')
    assert repr(e) == 'This is my message'


# Generated at 2022-06-22 19:54:44.561726
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_plugins.script import ActionModule as script_action
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(
        loader=None,
        sources=None,
    )

    # Set up task vars
    task_vars = dict()
    task_vars['ansible_os_family'] = 'Debian'
    task_vars['ansible_lsb'] = 'redhat'
    task_vars['ansible_distribution'] = 'Debian'
    task_vars['ansible_distribution_version'] = '9'
   

# Generated at 2022-06-22 19:54:54.148461
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from ansible.test.unit.test_utils import create_func_namespace
    globals_dict = create_func_namespace(test_InterpreterDiscoveryRequiredError___repr__)
    # test
    exc = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    exc_repr = repr(exc)
    # validation
    assert exc.message == "message"
    assert exc.interpreter_name == "interpreter_name"
    assert exc.discovery_mode == "discovery_mode"
    assert exc_repr == exc.message


# Generated at 2022-06-22 19:54:56.055582
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'test message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(error) == message


# Generated at 2022-06-22 19:54:58.352732
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert str(ex) == "message"

# Generated at 2022-06-22 19:55:00.433678
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    idre = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert repr(idre) == "'message'"



# Generated at 2022-06-22 19:55:10.023260
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    # construct InterpreterDiscoveryRequiredError
    exception_obj = InterpreterDiscoveryRequiredError(
        message='Python interpreter discovery is required on host, but was not possible.',
        interpreter_name='python',
        discovery_mode='auto_silent'
    )
    assert(exception_obj.message == 'Python interpreter discovery is required on host, but was not possible.')
    assert(exception_obj.interpreter_name == 'python')
    assert(exception_obj.discovery_mode == 'auto_silent')
    assert(exception_obj.__str__() == 'Python interpreter discovery is required on host, but was not possible.')

# Generated at 2022-06-22 19:55:14.908711
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('test message', 'python', 'auto')

    assert error.message == 'test message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'
    assert error.__str__() == 'test message'
    assert error.__repr__() == 'test message'


# Generated at 2022-06-22 19:55:19.923547
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected_result = 'missing_interpreter_for_modules'
    obj = InterpreterDiscoveryRequiredError('missing_interpreter_for_modules', None, None)

    actual_result = obj.__repr__()

    assert actual_result == expected_result


# Generated at 2022-06-22 19:55:24.233016
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError(message='Hello world!', interpreter_name='python3', discovery_mode='auto_legacy_silent')
    assert exc.__str__() == 'Hello world!'


# Generated at 2022-06-22 19:55:27.744080
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError(u'test', u'python', u'auto_legacy_silent')
    assert e.__repr__() == u'test'

# Generated at 2022-06-22 19:55:31.517866
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError(
        'interpreter_name', 'interpreter_name', 'discovery_mode')
    assert e.__str__() == 'interpreter_name'

# Generated at 2022-06-22 19:55:37.855907
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Interpreter {} discovery is required for hosts using {} (for example, host.example.org)".format(
        interpreter_name, discovery_mode
    )
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(error) == message

# Generated at 2022-06-22 19:55:43.642531
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("test message", "test interpreter", "test discovery mode")
    assert error.message == "test message"
    assert error.interpreter_name == "test interpreter"
    assert error.discovery_mode == "test discovery mode"
    assert 'test message' in repr(error)
    assert 'test interpreter' in repr(error)
    assert 'test discovery mode' in repr(error)


# Generated at 2022-06-22 19:55:51.992845
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "test message"
    interpreter_name = 'test_interpreter_name'
    discovery_mode = 'test_discovery_mode'
    x = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert x.interpreter_name == 'test_interpreter_name'
    assert x.discovery_mode == 'test_discovery_mode'
    assert x.message == 'test message'
    assert x.__str__() == 'test message'


# Generated at 2022-06-22 19:56:00.244088
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    import textwrap
    message_sample = "Module xxx requires interpreter discovery for Python."
    expected = textwrap.dedent("""\
        {0}
        interpreter_name: python
        discovery_mode: auto
    """).format(to_text(message_sample))
    interp_discovery_required_error = InterpreterDiscoveryRequiredError(message_sample, 'python', 'auto')
    actual = textwrap.dedent(to_text(interp_discovery_required_error)).strip()
    assert expected == actual

# Generated at 2022-06-22 19:56:01.795964
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert str(error) == "message"


# Generated at 2022-06-22 19:56:07.625011
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_var = "test_value"
    try:
        raise InterpreterDiscoveryRequiredError("test_message", test_var, test_var)
    except InterpreterDiscoveryRequiredError as err:
        assert str(err) == "test_message"
        assert err.interpreter_name == test_var
        assert err.discovery_mode == test_var

# Generated at 2022-06-22 19:56:12.061419
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = 'Interpreter discovery failed'
    error = InterpreterDiscoveryRequiredError(msg,'python','auto')
    assert(error.message == msg)
    assert(error.interpreter_name == 'python')
    assert(error.discovery_mode == 'auto')


# Generated at 2022-06-22 19:56:16.616963
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message='Interpreter Discovery Required'
    interpreter_name='python'
    discovery_mode='auto'
    obj=InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert obj.message == message
    assert obj.interpreter_name == interpreter_name
    assert obj.discovery_mode == discovery_mode


# Generated at 2022-06-22 19:56:21.100053
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('msg', 'py', 'auto_legacy')
    assert err.__repr__() == 'msg'
    assert str(err) == 'msg'



# Generated at 2022-06-22 19:56:32.518078
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: this needs to be fixed to work in all environments, not just when running from the source tree
    from ansible.executor.task_result import TaskResult
    from ansible.executor.action_iterator import ActionIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.playbook import Playbook

    loader = DataLoader()

# Generated at 2022-06-22 19:56:35.289860
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert 'message' in repr(obj)



# Generated at 2022-06-22 19:56:38.725508
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'interpreter discovery required'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.__str__() == message

# Generated at 2022-06-22 19:56:43.908860
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(u"test_message", u"test_interpreter_name", u"test_discovery_mode")
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == u"test_interpreter_name"
        assert ex.discovery_mode == u"test_discovery_mode"

# Generated at 2022-06-22 19:56:48.056944
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('my message', 'my interp', 'my mode')
    assert(err.interpreter_name == 'my interp')

# Generated at 2022-06-22 19:56:59.128236
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.six import PY3

    test_vars = dict(
        ansible_python_interpreter=env_fallback('ANSIBLE_PYTHON_INTERPRETER', None),
        ansible_interpreter_discovery=env_fallback('ANSIBLE_INTERPRETER_DISCOVERY', 'auto')
    )

    # No interpreter discovery
    python_path = discover_interpreter(
        action=None,
        interpreter_name='python',
        discovery_mode='none',
        task_vars=test_vars,
    )

    assert python_path is None, 'Interpreter discovery should have failed'

    # Auto discovery

# Generated at 2022-06-22 19:57:06.180571
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    import pytest

    task_vars = {
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_python_interpreter_discovery_mode': 'auto_legacy_silent',
    }

    host = 'localhost'
    display.debug = host
    display.v = host
    display.vv = host
    display.vvv = host

    # pass a test object that implements feature of action_plugin
    class FakeAction():
        def __init__(self):
            self._discovery_warnings = []
            self._connection = type('', (), {})()
            self._connection.has_pipelining = True # we'll execute a python script, so must have pipelining support


# Generated at 2022-06-22 19:57:08.780381
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {'ansible_python_interpreter': '/usr/bin/python'}
    _test_discovery_success_impl(task_vars)



# Generated at 2022-06-22 19:57:14.531334
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as ex:
        pass
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto'

# Generated at 2022-06-22 19:57:24.259469
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction(object):
        def __init__(self):
            self._connection = MockConnection()
            self._discovery_warnings = []

    class MockTaskVars(object):
        def __init__(self):
            self.inventory_hostname = 'testhost'

    action = MockAction()
    task_vars = MockTaskVars()

    result = discover_interpreter(action, 'python', 'auto_legacy', task_vars)

    # verify we get a result
    assert result is not None



# Generated at 2022-06-22 19:57:28.217569
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = 'Discovery is required for this interpreter.'
    si = 'python'
    dm = 'auto_legacy_silent'
    result = InterpreterDiscoveryRequiredError
    assert result(msg, si, dm)


# Generated at 2022-06-22 19:57:31.581641
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected = "InterpreterDiscoveryRequiredError('message', 'python', 'auto')"
    assert InterpreterDiscoveryRequiredError("message", "python", "auto").__repr__() == expected

# Generated at 2022-06-22 19:57:44.194419
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    from ansible.errors import AnsibleError
    from ansible.utils.hashing import checksum_s

    class TestCase(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def _mock_action(self):
            from ansible.plugins import action as action_loader
            return action_loader.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

        def test_discover_interpreter_non_linux(self):
            action = self._mock_action()

# Generated at 2022-06-22 19:57:48.428176
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = "Some errors"
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(e) == message
    assert repr(e) == message

# Generated at 2022-06-22 19:57:51.816621
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError(
        'some message',
        'python',
        'obnoxious_debug_mode'
    )

    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'obnoxious_debug_mode'

# Generated at 2022-06-22 19:57:56.498074
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('hello', 'python', 'auto')
    err_repr = repr(err)
    assert err_repr == 'hello'



# Generated at 2022-06-22 19:58:00.807233
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test discovery for Python 2
    action = AnsibleAction()
    task_vars = dict()
    interpreter = discover_interpreter(action, 'python', 'auto_silent', task_vars)
    assert interpreter == '/usr/bin/python'

    # Test discovery for Python 3
    # action = AnsibleAction()
    # task_vars = dict()
    # interpreter = discover_interpreter(action, 'python3', 'auto_silent', task_vars)
    # assert interpreter == '/usr/bin/python3'
    pass



# Generated at 2022-06-22 19:58:04.907004
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    expected = "foo"
    err = InterpreterDiscoveryRequiredError("foo", "python", "auto")
    actual = str(err)
    assert expected == actual, "InterpreterDiscoveryRequiredError.__str__() did not return the expected string"


# Generated at 2022-06-22 19:58:08.587639
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError("test message", "test_interp", "test_discovermode")
    assert err.__repr__() == "test message"


# Generated at 2022-06-22 19:58:12.890672
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_msg = 'Interpreter discovery is required'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    error = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert error.message == error_msg

# Generated at 2022-06-22 19:58:25.844668
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class TestAction:

        def __init__(self):
            self._connection = TestConnection()
            self._discovery_warnings = []

        def _low_level_execute_command(self, arg, sudoable, in_data=None):
            if arg == '/usr/bin/python':
                return {'stdout': u'{"platform_dist_result": [], "osrelease_content": "ID=ubuntu\\nVERSION_ID=16.04"}'}
            elif arg == 'command -v \'python\'':
                return {'stdout': u'python not found'}
            else:
                raise Exception('unexpected {0}'.format(arg))

        def _execute_module(self, *args, **kwargs):
            raise Exception('not implemented')


# Generated at 2022-06-22 19:58:33.445986
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module_name = 'script'
    task_vars = dict()

    # Test case 1: Default version for given platform
    task_vars['ansible_python_interpreter'] = 'auto'
    action = dict(linux_distribution=dict(name='amazon', version='2'))
    result = discover_interpreter(action, 'python', 'auto', task_vars)
    assert result == u'/usr/bin/python2.7'

    # Test case 2: Default version for given platform for known version
    task_vars['ansible_python_interpreter'] = 'auto'
    action = dict(linux_distribution=dict(name='amazon', version='20180214'))
    result = discover_interpreter(action, 'python', 'auto', task_vars)

# Generated at 2022-06-22 19:58:39.154911
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('test_message', 'test_interpreter', 'test_discovery_mode')
    assert err.message == 'test_message'
    assert err.interpreter_name == 'test_interpreter'
    assert err.discovery_mode == 'test_discovery_mode'
    assert str(err) == 'test_message'

# Generated at 2022-06-22 19:58:42.320603
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('Some message', 'python', 'auto')
    repr = e.__repr__()
    # TODO: check repr
    assert True

# Generated at 2022-06-22 19:58:47.104276
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError('foo', 'python', 'auto')
    assert e.__str__() == 'foo'
    assert e.interpreter_name == 'python'
    assert e.discovery_mode == 'auto'

# Generated at 2022-06-22 19:58:52.746023
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        InterpreterDiscoveryRequiredError(
            message='This is a test message.',
            interpreter_name='This is a test interpreter_name.',
            discovery_mode='This is a test discovery_mode.'
        )
    except ValueError as exception:
        assert str(exception) == 'Interpreter discovery not supported for This is a test interpreter_name.'
        assert repr(exception) == 'This is a test message.'

# Generated at 2022-06-22 19:59:03.236750
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test data
    action_mock = Mock()
    action_mock._low_level_execute_command = Mock(return_value={'stdout': u'PLATFORM\n\ndarwin\n\nFOUND\n/usr/bin/python3\n/usr/bin/python\n\nENDFOUND'})
    action_mock._connection.has_pipelining = True
    action_mock._low_level_execute_command = Mock(return_value={'stdout': u'{"platform_dist_result": ["macOS", "10.13.4", "x86_64"]}'})
    task_vars = {'ansible_python_interpreter': u'/usr/bin/python'}

    # Test

# Generated at 2022-06-22 19:59:06.361723
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert exception.__repr__() == 'message'

# Generated at 2022-06-22 19:59:13.479374
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    inter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    msg = 'Interpreter discovery required'

    exp_msg = 'Interpreter discovery required'

    e = InterpreterDiscoveryRequiredError(msg, inter_name, discovery_mode)

    # Run the code to be tested
    res = e.__str__()

    # Check the results
    assert res == exp_msg



# Generated at 2022-06-22 19:59:22.680193
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_message = 'test message'
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto'

    # Create test object
    test_obj = InterpreterDiscoveryRequiredError(
        message=test_message,
        interpreter_name=test_interpreter_name,
        discovery_mode=test_discovery_mode)

    assert test_obj.message == test_message
    assert test_obj.interpreter_name == test_interpreter_name
    assert test_obj.discovery_mode == test_discovery_mode

# Generated at 2022-06-22 19:59:25.095391
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:59:28.874817
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = u"Test message"

    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(err) == message

# Generated at 2022-06-22 19:59:31.549659
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy_silent")
    assert "message" == obj.__repr__()

# Generated at 2022-06-22 19:59:35.351116
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError('discovering', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == 'discovering'


# Generated at 2022-06-22 19:59:45.500988
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Create an instance of InterpreterDiscoveryRequiredError with message, interpreter_name and discovery_mode
    exception = InterpreterDiscoveryRequiredError(message="test_message", interpreter_name="test_interpreter_name",
                                                  discovery_mode="test_discovery_mode")
    assert exception.message == "test_message"
    assert exception.interpreter_name == "test_interpreter_name"
    assert exception.discovery_mode == "test_discovery_mode"
    # Test __str__ of InterpreterDiscoveryRequiredError
    assert exception.__str__() == "test_message"

# Generated at 2022-06-22 19:59:51.127484
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    from ansible.module_utils.discovery import InterpreterDiscoveryRequiredError
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')

    assert 'message' == interpreter_discovery_required_error.__str__()

# Generated at 2022-06-22 19:59:57.146427
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    value = "The interpreter {} could not be found in the list of discovered Python interpreters"
    interpreter_name = 'python'
    discovery_mode = 'auto'
    exception = InterpreterDiscoveryRequiredError(value, interpreter_name, discovery_mode)
    actual_result = exception.__str__()
    expected_result = value.format(interpreter_name)
    assert actual_result == expected_result

# Generated at 2022-06-22 20:00:00.261395
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('discovery failed', 'python', 'auto_legacy_silent')
    assert repr(exc) == 'discovery failed'



# Generated at 2022-06-22 20:00:02.981853
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('test message for InterpreterDiscoveryRequiredError',
                                                interpreter_name='python', discovery_mode='auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert isinstance(ex, Exception)
        assert hasattr(ex, 'interpreter_name')
        assert hasattr(ex, 'discovery_mode')
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto'


# Generated at 2022-06-22 20:00:06.330890
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError('message', 'name', 'mode')
    assert e.message == e.__str__()



# Generated at 2022-06-22 20:00:08.565351
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("discovery_mode is required for this interpreter", "python", "auto")
    if not str(error) == "discovery_mode is required for this interpreter":
        raise AssertionError()


# Generated at 2022-06-22 20:00:15.134521
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        message=u'Python interpreter discovery required, but discovery mode is set to auto_legacy_silent',
        interpreter_name=u'python',
        discovery_mode=u'auto_legacy_silent')

    assert str(error) == u'Python interpreter discovery required, but discovery mode is set to auto_legacy_silent'

# Generated at 2022-06-22 20:00:19.761703
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert str(exception) == "message"
    assert exception.interpreter_name == "python"
    assert exception.discovery_mode == "auto"



# Generated at 2022-06-22 20:00:23.564071
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("test", "python", "auto")
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"
    assert str(error) == "test"

# Generated at 2022-06-22 20:00:33.748517
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor

    class DummyActionModule(object):
        _discovery_warnings = []

        def __init__(self, interpreter_name):
            self.interpreter_name = interpreter_name
            self.connection = None

        def _low_level_execute_command(self, cmd, sudoable, in_data=None):
            return {'stdout': '', 'stderr': ''}

    class DummyConnection(object):
        def __init__(self, has_pipelining=False):
            self.has_pipelining = has_pipelining

    action = DummyActionModule('python')
    display.verbosity

# Generated at 2022-06-22 20:00:35.431337
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError('message', 'py1', 'discovery_mode')

    assert exc.__str__() == 'message'

# Generated at 2022-06-22 20:00:43.092657
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    errObj = InterpreterDiscoveryRequiredError(
        'Ansible requires the Python interpreter from the managed target system in order to '
        'execute modules. If you would like to see a list of available interpreter '
        'installations and their corresponding paths in the managed system, run the '
        'ansible-interpreter-discovery script.', 'python', 'auto')
    assert u'Ansible requires the Python interpreter from the managed target system in order to execute' \
           u' modules. If you would like to see a list of available interpreter installations and their ' \
           u'corresponding paths in the managed system, run the ansible-interpreter-discovery script.' == \
           str(errObj)


# Generated at 2022-06-22 20:00:46.304696
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interp_name = 'python'
    discovery_mode = 'auto'
    test_exception = InterpreterDiscoveryRequiredError('message', interp_name, discovery_mode)
    assert repr(test_exception) == 'message'


# Generated at 2022-06-22 20:00:51.825776
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError(message='unknown', interpreter_name='python', discovery_mode='auto')
    assert e.interpreter_name == 'python'
    assert e.discovery_mode == 'auto'
    assert e.message == 'unknown'
    assert str(e) == 'unknown'
    assert repr(e) == 'unknown'


# Generated at 2022-06-22 20:01:03.990681
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import platform
    import os
    import shutil
    from tempfile import mkdtemp
    from ansible.plugins.loader import module_loader

    class FakeTaskAction(object):
        def __init__(self, connection, tmpdir_path):
            self._connection = connection
            self._tmpdir_path = tmpdir_path
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            res = {
                'stdout': '',
                'stdout_lines': [],
                'stderr_lines': []
            }

            if sudoable and self._connection.become and self._connection.become_method == 'sudo':
                command = 'sudo -k {0}'.format(command)

            # NOTE:

# Generated at 2022-06-22 20:01:10.031266
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # test_case1: message = 'message', interpreter_name = 'python', discovery_mode = 'auto'
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert repr(e) == 'message'


# Generated at 2022-06-22 20:01:20.422801
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This test is a bit stupid/insufficient as it is very Ansible/Travis specific.
    # The underlying platform.dist() and /etc/os-release data is really what should be tested here,
    # but those things are pretty stable and will be easy to spot if they ever change.
    modules_path = "/home/travis/build/ansible/ansible/lib/ansible/modules"

    class _Connection(object):
        def __init__(self):
            self.has_pipelining = False

        def exec_command(self, cmd, in_data=None, sudoable=False):
            return {'stdout': cmd, 'stderr': ""}

    class _Action(object):
        def __init__(self):
            self._connection = _Connection()
            self._discovery_warnings = []



# Generated at 2022-06-22 20:01:26.568674
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # test the message and the interpreter_name property
    error = InterpreterDiscoveryRequiredError('message', 'python', 'default')
    assert (error.message == 'message')
    assert (error.interpreter_name == 'python')
    assert (error.discovery_mode == 'default')

    # test the repr
    assert (repr(error) == 'message: python: default')

# Generated at 2022-06-22 20:01:31.431709
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('error message',
                                                'python',
                                                'auto')
    except Exception as ex:
        assert ex.message == 'error message'
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto'

# Generated at 2022-06-22 20:01:41.742091
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """
    InterpreterDiscoveryRequiredError.__repr__() output test.
    """
    assert InterpreterDiscoveryRequiredError(
        "InterpreterDiscoveryRequiredError",
        "python",
        "logical_always_silent").__repr__() == "InterpreterDiscoveryRequiredError"
    assert InterpreterDiscoveryRequiredError(
        "InterpreterDiscoveryRequiredError",
        "python",
        "logical_always").__repr__() == "InterpreterDiscoveryRequiredError"
    assert InterpreterDiscoveryRequiredError(
        "InterpreterDiscoveryRequiredError",
        "python",
        "auto_legacy_silent").__repr__() == "InterpreterDiscoveryRequiredError"

# Generated at 2022-06-22 20:01:52.429130
# Unit test for function discover_interpreter
def test_discover_interpreter():
    collection_loader = 'ansible.plugins.loader.collection_loader.CollectionLoader'
    if collection_loader not in C.config.plugin_filters:
        C.config.plugin_filters.append(collection_loader)
    action = C.config.get_action_instance('setup', C.config.SHARED_CONNECTION)
    task_vars = {}
    interpreter_name = 'python'
    discovery_mode = 'auto'
    display.verbosity = 3
    display.debugger = True
    display.display(u'', screen_only=True)
    # C.config.DEFAULT_MODULE_LANG='python'
    interpreter_path = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

# Generated at 2022-06-22 20:01:55.920070
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    msg = 'Interpreter discovery required for python'
    try:
        raise InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode
        assert e.message == msg

# Generated at 2022-06-22 20:01:59.843453
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('test_message', 'abc', 'abc')
    assert e.__repr__() == e.message

# Generated at 2022-06-22 20:02:05.176045
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Arrange
    expected_result = 'Discovery required'
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError('Discovery required', 'unknown', 'unknown')

    # Act
    actual_result = interpreter_discovery_required_error.__str__()

    # Assert
    assert actual_result == expected_result

# Generated at 2022-06-22 20:02:09.258166
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert exception.message == "message"
    assert exception.interpreter_name == "interpreter_name"
    assert exception.discovery_mode == "discovery_mode"

# Generated at 2022-06-22 20:02:13.944024
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    t = "msg"
    i = "interpreter_name"
    d = "discovery_mode"
    e = InterpreterDiscoveryRequiredError(t, i, d)
    assert e.__str__() == t

# Generated at 2022-06-22 20:02:24.862985
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import RESULT_HAS_CHANGED
    from ansible.executor.module_common import RESULT_FAILED
    from ansible.executor.module_common import RESULT_UNHANDLED_ERROR
    from ansible.executor.module_common import RESULT_IGNORED
    from ansible.executor.module_common import RESULT_SKIPPED
    from ansible.executor.module_common import RESULT_OK
    from ansible.executor.module_common import RESULT_CANCELED
    from ansible.executor.module_common import RESULT_UNKNOWN

    host = 'testhost'
    task_vars = dict(inventory_hostname=host)

    # hostvars

# Generated at 2022-06-22 20:02:28.796324
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Tests that the class InterpreterDiscoveryRequiredError is constructed
    # correctly.
    try:
        raise InterpreterDiscoveryRequiredError("test", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == "test"
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto"

# Generated at 2022-06-22 20:02:29.291669
# Unit test for function discover_interpreter

# Generated at 2022-06-22 20:02:42.232003
# Unit test for function discover_interpreter

# Generated at 2022-06-22 20:02:45.937640
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("foo", "python", "auto_legacy")

    assert error.discovery_mode == "auto_legacy"
    assert error.interpreter_name == "python"
    assert error.message == "foo"

# Generated at 2022-06-22 20:02:49.153428
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Just return the message from __init__
    e = InterpreterDiscoveryRequiredError("This is a test message", "python", "auto")
    assert e.__str__() == "This is a test message"

# Generated at 2022-06-22 20:02:52.984396
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected = 'Error message'
    interpreter_name = 'python2'
    discovery_mode = 'auto'
    test_class = InterpreterDiscoveryRequiredError(expected, interpreter_name, discovery_mode)
    assert repr(test_class) == expected

# Generated at 2022-06-22 20:02:57.213466
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError('missing_interpreter', 'python', 'auto')
    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'auto'

# Generated at 2022-06-22 20:02:58.133085
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-22 20:03:01.260921
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError(to_text("interpreter_name"), to_text("discovery_mode"))
    assert str(exc) == to_text("interpreter_name")



# Generated at 2022-06-22 20:03:08.475704
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    with mock.patch("ansible.module_utils.basic.AnsibleModule.fail_json") as mock_AnsibleModule_fail_json:

        ansible.module_utils.basic.AnsibleModule.fail_json.return_value = "mock_message"
        my_obj = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
        my_obj.message = "mock_message"
        result = my_obj.__str__()

        assert result == my_obj.message


# Generated at 2022-06-22 20:03:13.552673
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    exception = InterpreterDiscoveryRequiredError(
        "Python interpreter discovery required for remote host", interpreter_name, discovery_mode)
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:03:15.130620
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    InterpreterDiscoveryRequiredError("msg", "py2", "discovery_mode")

# Generated at 2022-06-22 20:03:20.589295
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("test_message", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == "test_message"
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto"

# Generated at 2022-06-22 20:03:22.742631
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert e.__str__() == 'message'

# Generated at 2022-06-22 20:03:32.175865
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Testcase 1
    message = "Testing InterpreterDiscoveryRequiredError"
    interpreter_name = "python"
    discovery_mode = "auto"

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == message
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode
        assert type(e) == InterpreterDiscoveryRequiredError
        assert repr(e)
        assert str(e)


# Generated at 2022-06-22 20:03:37.099611
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Test function with mock data, which can be used in ansible modules.
    :return:
    """
    try:
        from ansible.plugins.action import ActionBase
    except ImportError:
        raise ImportError("ansible.plugins.action is needed for running discover_interpreter self test")

    action = ActionBase()
    action._discovery_warnings = []
    task_vars = {
        "inventory_hostname": "test_host",
        "ansible_python_interpreter": "python"
    }
    task_vars["ansible_python_interpreter"] = discover_interpreter(action, "python", "auto_silent", task_vars)
    print(task_vars)

# Generated at 2022-06-22 20:03:43.211403
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    msg = 'Python interpreter discovery required'
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert error.__str__() == msg
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:03:49.400380
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    custom_message = 'Use interpreter discovery to identify the correct Python interpreter for this host'
    e = InterpreterDiscoveryRequiredError(message=custom_message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)

    assert str(e) == '%s' % custom_message

# Generated at 2022-06-22 20:03:53.981471
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = "Test exception message"
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.__repr__() == message

# Generated at 2022-06-22 20:03:58.300673
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    name = 'python'
    mode = 'auto_legacy_silent'
    err_msg = 'test_msg'
    err = InterpreterDiscoveryRequiredError(err_msg, name, mode)

    assert err.interpreter_name == name
    assert err.discovery_mode == mode

# Generated at 2022-06-22 20:04:03.934943
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    e = InterpreterDiscoveryRequiredError('Message', interpreter_name, discovery_mode)
    assert e.message == 'Message'
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode