

# Generated at 2022-06-22 19:54:13.892915
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: MORE TESTS!!!!
    task_vars = {}

    # Test the default case of a legacy OS that should use /usr/bin/python
    task_vars['ansible_python_interpreter'] = ''
    task_vars['ansible_interpreter_python_discovery_mode'] = 'auto_legacy'
    found_interpreter = discover_interpreter(None, 'python', 'auto_legacy', task_vars)
    assert found_interpreter == u'/usr/bin/python'

    # Test the default case of a legacy OS that should use /usr/bin/python, but it's not there
    task_vars['ansible_python_interpreter'] = ''

# Generated at 2022-06-22 19:54:20.095549
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    error_message = 'InterpreterDiscoveryRequiredError'

    e = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert repr(e) == error_message
    assert str(e) == error_message
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode


# Generated at 2022-06-22 19:54:26.387709
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    exception = InterpreterDiscoveryRequiredError("message", interpreter_name, discovery_mode)
    assert exception.message == "message"
    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'auto_legacy'



# Generated at 2022-06-22 19:54:30.374810
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module_mock = MockModule()
    assert discover_interpreter(module_mock, 'python', 'auto', {}) == '/usr/bin/python'
    assert len(module_mock.discovery_warnings) == 1



# Generated at 2022-06-22 19:54:33.196506
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError("test message", "test interpreter_name", "test discovery_mode")
    assert "test message" == str(ex)

# Generated at 2022-06-22 19:54:37.930924
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(
        "message",
        "interpreter_name",
        "discovery_mode"
    )

    assert err.message == "message"
    assert err.interpreter_name == "interpreter_name"
    assert err.discovery_mode == "discovery_mode"

    assert str(err) == "message"

# Generated at 2022-06-22 19:54:41.140827
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("message", "python", "auto")
    except InterpreterDiscoveryRequiredError as err:
        assert(err.interpreter_name == "python")
        assert(err.discovery_mode == "auto")

# Generated at 2022-06-22 19:54:46.427719
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    a = InterpreterDiscoveryRequiredError('hello world', 'python', 'auto')
    assert a.message == 'hello world'
    assert a.interpreter_name == 'python'
    assert a.discovery_mode == 'auto'
    assert str(a) == 'hello world'


# Generated at 2022-06-22 19:54:57.600342
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # mock up task_vars

# Generated at 2022-06-22 19:55:06.028473
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    action_name = 'shell'

    connection = 'local'
    pc = PlayContext()
    pc.verbosity = 0

    # Load the action plugin
    action_plugin = action_loader.get(action_name.lower(), pc=pc, connection=connection)

    interpreter_name = 'python'

    # should be a successfull discovery
    discovery_mode = 'auto_legacy_silent'
    task_vars = dict(inventory_hostname='localhost')
    assert discover_interpreter(action_plugin, interpreter_name, discovery_mode, task_vars) == '/usr/bin/python'

    # should be a successfull discovery
    discovery_mode = 'auto_legacy'
    task_

# Generated at 2022-06-22 19:55:08.792921
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert error.__str__() == 'message'

# Generated at 2022-06-22 19:55:10.324024
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    str(InterpreterDiscoveryRequiredError("test_message", 'python', 'auto'))

# Generated at 2022-06-22 19:55:16.035842
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "test for interpreter discovery required error"
    interpreter_name = "python"
    discovery_mode = "auto_silent"
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert to_text(err.message) == to_text(message)
    assert to_text(err.interpreter_name) == to_text(interpreter_name)
    assert to_text(err.discovery_mode) == to_text(discovery_mode)

# Generated at 2022-06-22 19:55:25.882045
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    import pytest
    from ansible.module_utils.facts import InterpreterDiscoveryRequiredError
    message = 'test_message'
    interpreter_name = 'python'
    discovery_mode = 'force_auto'
    edr = InterpreterDiscoveryRequiredError(message=message,
                                            interpreter_name='python',
                                            discovery_mode='force_auto')
    assert edr.__str__() == message
    assert edr.__str__() == edr.message
    assert edr.interpreter_name == 'python'
    assert edr.discovery_mode == 'force_auto'

# Generated at 2022-06-22 19:55:29.533865
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto")
    expected = "message"
    assert error.__repr__() == expected


# Generated at 2022-06-22 19:55:34.102868
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    o = InterpreterDiscoveryRequiredError('test_message', 'python', 'auto_legacy_silent')
    assert o.message == 'test_message'
    assert o.interpreter_name == 'python'
    assert o.discovery_mode == 'auto_legacy_silent'


# Generated at 2022-06-22 19:55:38.184144
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            message="No interpreter was found for {0}".format('python'),
            interpreter_name='python'
        )
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == 'python'
        assert ex.message == "No interpreter was found for python"

# Generated at 2022-06-22 19:55:41.514959
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(
        "test_error_message",
        "test_interpreter_name",
        "test_discovery_mode")
    assert "test_error_message" == repr(error)


# Generated at 2022-06-22 19:55:43.972475
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError("a message", "py", "auto")
    assert str(e) == "a message"

# Generated at 2022-06-22 19:55:47.303577
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ex = InterpreterDiscoveryRequiredError('some_message', 'some_interpreter_name', 'some_discovery_mode')
    assert repr(ex) == 'some_message'

# Generated at 2022-06-22 19:55:52.133715
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('test message', 'python', 'auto')
    assert error.message == 'test message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'


# Generated at 2022-06-22 19:55:59.335605
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.message == message
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode
    assert e.__str__() == message
    assert e.__repr__() == message

# Generated at 2022-06-22 19:56:07.322975
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction(object):
        def __init__(self):
            self._discovery_warnings = []
    action_obj = MockAction()
    task_vars = dict(inventory_hostname='testhost')
    interpreter_path = discover_interpreter(action=action_obj, interpreter_name='python', discovery_mode='auto_legacy_silent', task_vars=task_vars)
    assert interpreter_path == '/usr/bin/python'
    assert len(action_obj._discovery_warnings) > 0

# Generated at 2022-06-22 19:56:14.177128
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interp_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    try:
        raise InterpreterDiscoveryRequiredError(
            'Test InterpreterDiscoveryRequiredError', interp_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.__str__() == 'Test InterpreterDiscoveryRequiredError'
        assert ex.interpreter_name == interp_name
        assert ex.discovery_mode == discovery_mode


# Generated at 2022-06-22 19:56:18.282812
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_interpreter_name = 'python3'
    test_discovery_mode = 'auto'
    test_message = 'missing interpreter'
    test_ex = InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)

    assert str(test_ex) == test_message

test_InterpreterDiscoveryRequiredError___str__()

# Generated at 2022-06-22 19:56:23.078025
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(message=u'Test message', interpreter_name=u'python', discovery_mode=u'auto_legacy')
    assert to_text(err) == u'Test message'



# Generated at 2022-06-22 19:56:30.076257
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict()

    interpreter_path = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert interpreter_path == u'/usr/bin/python'

    discovery_mode = 'auto_legacy'

    interpreter_path = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert interpreter_path == u'/usr/bin/python'

# Generated at 2022-06-22 19:56:37.405250
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto'
    test_err = InterpreterDiscoveryRequiredError("message", test_interpreter_name, test_discovery_mode)
    assert test_err.interpreter_name == test_interpreter_name
    assert test_err.discovery_mode == test_discovery_mode
    assert test_err.__str__() == "message"
    assert test_err.__repr__() == "message"

# Generated at 2022-06-22 19:56:43.115540
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test constructor
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = u'Python interpreter discovery required for host dummy, but interpreter discovery not enabled'
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert ex.interpreter_name == 'python'
    assert ex.discovery_mode == 'auto_legacy'



# Generated at 2022-06-22 19:56:46.297754
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError("foo", "python", "auto")
    assert str(err) == "foo"


# Generated at 2022-06-22 19:56:52.471457
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("error message", "python", "auto_legacy_silent")
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == "error message"
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_legacy_silent"

# Generated at 2022-06-22 19:56:56.101699
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = u'Interpreter discovery required'
    interpreter_name = u'python'
    discovery_mode = u'auto_legacy_silent'

    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert str(err) == msg

# Generated at 2022-06-22 19:56:57.298556
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy")
    assert error.__str__() == "message"

# Generated at 2022-06-22 19:57:03.854639
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager

    class ModuleStub(object):

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def fail_json(self, *args, **kwargs):
            self.fail_json_args = args
            self.fail_json_kwargs = kwargs
            raise Exception('the task failed')

        def exit_json(self, *args, **kwargs):
            self.exit_json_args = args
            self.exit_json_kwargs = kwargs
            raise Exception('done')

        def run(self, tmp=None, task_vars=None):
            display.debug('running test task')

# Generated at 2022-06-22 19:57:08.148916
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError(
        message=u'Unit test message',
        interpreter_name=u'Unit test name',
        discovery_mode=u'auto_legacy_silent')
    assert exception.__str__() == u'Unit test message'



# Generated at 2022-06-22 19:57:12.141305
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert 'message' == InterpreterDiscoveryRequiredError.__repr__(e)


# Generated at 2022-06-22 19:57:13.963830
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('fail', 'python', 'auto')
    assert exc.__repr__() == exc.__str__()

# Generated at 2022-06-22 19:57:17.453483
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert repr(e) == 'message'

# Generated at 2022-06-22 19:57:23.583610
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Arrange
    msg = "test message"
    interpreter_name = "test_interpreter"
    discovery_mode = "test_discovery_mode"

    # Act
    output = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    # Assert
    assert output.__repr__() == msg


# Generated at 2022-06-22 19:57:29.081285
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(u'Test', u'python', u'auto_legacy')
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == u'python'
        assert ex.discovery_mode == u'auto_legacy'


# Generated at 2022-06-22 19:57:36.888934
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test with the following required arguments
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = "Python interpreter discovery requried"

    # Create an instance of Class
    error_instance = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error_instance._message == message
    assert error_instance.interpreter_name == interpreter_name
    assert error_instance.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:57:43.736598
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Setup test data
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = "Failed to find interpreter for python!"

    # Exercise and Verify
    interpreter_discovery_err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_discovery_err.__repr__() == interpreter_discovery_err.message

# Generated at 2022-06-22 19:57:47.666128
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = "test discovery error message"
    try:
        raise InterpreterDiscoveryRequiredError(error_message, 'python', 'sad_face')
    except InterpreterDiscoveryRequiredError as e:
        assert error_message == str(e)


# Generated at 2022-06-22 19:57:49.616525
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("test message", "test interpreter", "test discovery mode")
    assert repr(error) == "test message"

# Generated at 2022-06-22 19:57:57.311040
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_iterator import ActionIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager

    class PlayContext(object):
        def __init__(self):
            self.become = None
            self.become_user = None
            self.module_vars = None
            self.remote_addr = None

    class Play(object):
        def __init__(self):
            self.context = PlayContext()

    class Task(object):
        def __init__(self):
            self.action = None
            self.args = None
            self.async_val = None
            self.delegate_to = None
            self.environment = None
            self.loop = None

# Generated at 2022-06-22 19:58:09.800198
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test case 1: no arguments to constructor
    try:
        e = InterpreterDiscoveryRequiredError()
        raise AssertionError('should have thrown an exception')
    except TypeError:
        pass
    # Test case 2: single positional argument to constructor
    message = 'a'
    try:
        e = InterpreterDiscoveryRequiredError(message)
        raise AssertionError('should have thrown an exception')
    except TypeError:
        pass
    # Test case 3: 2 positional arguments to constructor
    try:
        e = InterpreterDiscoveryRequiredError(message, 'python')
        raise AssertionError('should have thrown an exception')
    except TypeError:
        pass
    # Test case 4: 3 positional arguments to constructor

# Generated at 2022-06-22 19:58:14.369604
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Test `__repr__` method of class InterpreterDiscoveryRequiredError."""
    message = "Error message"
    interpreter_name = "python3"
    discovery_mode = "auto_silent"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    expected = "Error message"
    assert repr(error) == expected, "Invalid repr: {0}".format(repr(error))


# Generated at 2022-06-22 19:58:27.367703
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction(object):
        def __init__(self):
            self._connection = MockConnection()
            self._low_level_execute_command = self._low_level_execute_command_impl
            self._discovery_warnings = []

        def _low_level_execute_command_impl(self, *args, **kwargs):
            return dict(stdout='PLATFORM\nLinux\nFOUND\n/usr/bin/python3\n/usr/bin/python2\nENDFOUND')

    action = MockAction()
    res = discover_interpreter(action, 'python', 'auto_legacy_silent', dict())

    assert res == '/usr/bin/python2'
    # make sure no warnings were generated
    assert not action._discovery_warnings



# Generated at 2022-06-22 19:58:39.578111
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_data = [
        {
            'input': dict(interpreter_name='python', discovery_mode='auto_silent',
                          task_vars={'inventory_hostname': 'localhost'}),
            'output': '/usr/bin/python',
        },
        {
            'input': dict(interpreter_name='python', discovery_mode='auto_legacy',
                          task_vars={'inventory_hostname': 'localhost'}),
            'output': '/usr/bin/python',
        },
    ]

    test_results = []

# Generated at 2022-06-22 19:58:50.439092
# Unit test for function discover_interpreter
def test_discover_interpreter():

    task_vars = dict()

    # test auto_legacy
    task_vars['ansible_python_interpreter'] = '/user/bin/python_legacy'
    action = dict()
    action['_low_level_execute_command'] = lambda *args, **kwargs: dict(stdout='PLATFORM\nLinux\nFOUND\n/user/bin/python_legacy\n', stderr='')
    action['_discovery_warnings'] = []
    action['_connection'] = dict(has_pipelining=True)
    interpreter = discover_interpreter(action, 'python', 'auto_legacy', task_vars)
    assert interpreter == '/user/bin/python_legacy'

# Generated at 2022-06-22 19:58:55.796437
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = 'Hello'
    exception_obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert (message == str(exception_obj))

# Generated at 2022-06-22 19:59:02.287243
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            "message",
            "python",
            "auto_legacy_silent"
        )
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == "message"
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_legacy_silent"
    else:
        assert False, 'Expected InterpreterDiscoveryRequiredError to be raised.'

# Generated at 2022-06-22 19:59:09.549517
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected = InterpreterDiscoveryRequiredError.__module__ + '.' + InterpreterDiscoveryRequiredError.__qualname__
    expected += '(message=\'Error message\', interpreter_name=\'python\', discovery_mode=\'auto\')'

    discovery_error = InterpreterDiscoveryRequiredError(message='Error message', interpreter_name='python', discovery_mode='auto')

    assert repr(discovery_error) == expected

# Generated at 2022-06-22 19:59:12.021327
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError("msg", "python", "auto")
    assert str(e) == "msg"


# Generated at 2022-06-22 19:59:22.678999
# Unit test for function discover_interpreter
def test_discover_interpreter():
    def pytest_funcarg__action(request):
        class Action(object):
            # FIXME: should be moved to test case class
            def __init__(self):
                self._discovery_warnings = []

            def _get_connection(self):
                return None

            def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
                if cmd == "/bin/uname":
                    return dict(stdout="Linux", stderr='')
                elif cmd == "command -v 'python'":
                    return dict(stdout='/usr/bin/python', stderr='')
                elif cmd == "/usr/bin/python" and "platform_dist_result=['Ubuntu', '14.04', 'trusty']" in in_data:
                    return dict

# Generated at 2022-06-22 19:59:26.062277
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ed_error = InterpreterDiscoveryRequiredError("fake error", "test_interp", "test_mode")
    assert ed_error.__str__() == ed_error.message


# Generated at 2022-06-22 19:59:30.376741
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
        error_message = 'Bad error message'
        interpeter_name = 'python'
        discovery_mode = 'auto_legacy'

        exception = InterpreterDiscoveryRequiredError(error_message, interpeter_name, discovery_mode)
        assert str(exception) == error_message



# Generated at 2022-06-22 19:59:42.989491
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    # call discover_interpreter with all supported discovery modes, for a known distro/version
    # with known presence/absence of system interpreter
    task_vars = {
        'inventory_hostname': u'foo',
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_python_discovery_mode': 'auto',
        'ansible_python_interpreter_discovery_mode': 'auto',
        'ansible_python_interpreter_name': 'python',
    }

    class MockActionBase(ActionBase):
        def __init__(self, config, task, host, connection, play_context, loader, templar, shared_loader_obj):
            self._config = config
            self._task = task
           

# Generated at 2022-06-22 19:59:45.947467
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError('test', 'test', 'test')
    result = repr(obj)
    assert obj.message == result


# Generated at 2022-06-22 19:59:50.192346
# Unit test for function discover_interpreter
def test_discover_interpreter():
    ansible_module_args = {}
    from ansible.plugins.action.command import ActionModule as command_action
    action = command_action(None, ansible_module_args, None)
    task_vars = {}
    assert discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars) == '/usr/bin/python'

# Generated at 2022-06-22 19:59:54.431032
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "message"
    interpreter_name = "python"
    discovery_mode = "auto"
    interp_discovery_required_err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert interp_discovery_required_err.__str__() == msg

# Generated at 2022-06-22 20:00:02.862466
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager

    module_utils_path = C.config.get_config_value('DEFAULT_MODULE_UTILS_PATH')
    result = TaskResult('test', 'action')
    context = PlayContext()
    context.become = False
    context.become_user = 'root'
    variables = VariableManager()
    variables.extra_vars = {}
    action = ActionBase(context, 'test', result, variables, module_utils_path, False, False, None)

    # mock module_utils.compat.interpreters

# Generated at 2022-06-22 20:00:13.810511
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    for discovery_mode in ('smart', 'smart_silent', 'auto', 'auto_silent', 'auto_legacy', 'auto_legacy_silent'):
        message = "Python interpreter discovery required"
        try:
            raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
        except InterpreterDiscoveryRequiredError as exception:
            expected_value = message
            actual_value = repr(exception)
            assert actual_value == expected_value, \
                "Expected the value of repr(exception) to be '%s' but it was '%s'" % (expected_value, actual_value)



# Generated at 2022-06-22 20:00:16.958447
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('msg', 'python', 'auto')
    assert str(e) == 'msg'
    assert repr(e) == 'msg'

# Generated at 2022-06-22 20:00:22.070892
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex = InterpreterDiscoveryRequiredError('message', 'interpreter', 'discovery mode')
    assert ex.interpreter_name == 'interpreter'
    assert ex.discovery_mode == 'discovery mode'
    assert str(ex) == 'message'
    assert repr(ex) == 'message'

# Generated at 2022-06-22 20:00:32.725121
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    #Test that InterpreterDiscoveryRequiredError is a subclass of Exception
    assert issubclass(InterpreterDiscoveryRequiredError, Exception), 'InterpreterDiscoveryRequiredError is not a subclass of Exception'

    #Test that InterpreterDiscoveryRequiredError can take a message and interpreter_name.

# Generated at 2022-06-22 20:00:33.767293
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True

# Generated at 2022-06-22 20:00:37.433449
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_discovery_required_error_instance = InterpreterDiscoveryRequiredError(u"message", u"interpreter_name", u"discovery_mode")

    assert interpreter_discovery_required_error_instance.__str__() == u"message"

# Generated at 2022-06-22 20:00:38.061584
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-22 20:00:46.185081
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # fail on non-python
    try:
        discover_interpreter(None, 'foo', 'auto', None)
    except ValueError as ex:
        assert 'Interpreter discovery not supported for foo' in to_text(ex)
    else:
        raise AssertionError('failure expected')

    # fail on unsupported platform
    host = 'example.com'
    task_vars = {'inventory_hostname': host}

    class _Action(object):
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            out = u'PLATFORM\nfoo\nFOUND\n/errors/\nENDFOUND'
            return {'stdout': out}

    action = _Action()


# Generated at 2022-06-22 20:00:50.897189
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'interpreter', 'discovery_mode')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'interpreter'
        assert e.discovery_mode == 'discovery_mode'

# Generated at 2022-06-22 20:00:55.101940
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with pytest.raises(InterpreterDiscoveryRequiredError):
        msg = "Interpreter Discovery Required Error"
        interpreter_name = "python"
        discovery_mode = "auto"
        raise InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

# Generated at 2022-06-22 20:01:04.829527
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    class_name = 'InterpreterDiscoveryRequiredError'
    class_repr = '<class \'ansible.executor.interpreter_discovery.InterpreterDiscoveryRequiredError\'>'
    inst_repr = '<ansible.executor.interpreter_discovery.InterpreterDiscoveryRequiredError object at 0x7f59ec7b1208>'
    err = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert(repr(err.__class__) == class_repr)
    assert(repr(err) == inst_repr)


# Generated at 2022-06-22 20:01:07.622210
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    repr(e) == 'message'

# Generated at 2022-06-22 20:01:15.654739
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict()
    expected_res = '/usr/bin/python'
    action = dict()
    action['_discovery_warnings'] = []

    try:
        true_res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        assert true_res == expected_res
    except Exception as e:
        # If assert fails, then test is failed
        raise e

# Generated at 2022-06-22 20:01:26.217657
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    class _Action(object):
        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            import os
            import subprocess

            cmd = command.split()
            if in_data:
                proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdout, stderr = proc.communicate(input=in_data)

# Generated at 2022-06-22 20:01:30.867837
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='auto')
    assert repr(obj) == 'message'



# Generated at 2022-06-22 20:01:34.705117
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError("test message", "test interpreter_name", "test discovery_mode")

    assert exception.__repr__() == exception.message
    assert exception.__repr__() == "test message"


# Generated at 2022-06-22 20:01:44.115630
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.remote_management import RemoteManagement
    from ansible.module_utils.shell import Shell
    from ansible.module_utils.action import Action
    import ansible.module_utils.facts as facts

    host = 'test.example.com'
    task_vars = dict()
    action = Action()

    distro_map = dict()
    distro_map[u'ansible_python_interpreter'] = u'/usr/bin/python'

    def _get_python_interpreter(task_vars):
        return u'/usr/bin/python2.7'


# Generated at 2022-06-22 20:01:49.863369
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'Interpreter Discovery is Required'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    test = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    # __repr__ is replaced by __str__, but __repr__ should still be a valid repr
    assert repr(test) == message


# Generated at 2022-06-22 20:01:53.843619
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert err.interpreter_name == "python"
    assert err.discovery_mode == "auto"
    assert err.__str__() == "message"
    assert err.__repr__() == "message"

# Generated at 2022-06-22 20:02:07.188973
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert _version_fuzzy_match(u'10', {'9': u'/usr/bin/python3.5', u'10': u'/usr/bin/python3.6'}) == u"/usr/bin/python3.6"
    assert _version_fuzzy_match(u'10.11', {'10.11': u'/usr/bin/python3.6', u'10.10': u'/usr/bin/python3.5'}) == u"/usr/bin/python3.6"

# Generated at 2022-06-22 20:02:12.379970
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_interpreter_name = 'test_interpreter_name'
    test_discovery_mode = 'test_discovery_mode'
    test_message = 'test_message'
    test_id = InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)
    assert test_id.interpreter_name == test_interpreter_name
    assert test_id.discovery_mode == test_discovery_mode
    assert test_id.message == test_message
    assert str(test_id) == test_message
    assert repr(test_id) == test_message



# Generated at 2022-06-22 20:02:15.380270
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError('test me', 'test', 'test')
    assert exc.message == 'test me'
    assert exc.interpreter_name == 'test'
    assert exc.discovery_mode == 'test'
    assert exc.args == ('test me',)
    assert str(exc) == 'test me'

# Generated at 2022-06-22 20:02:26.242538
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.facts import Facts
    import platform
    import sys

    # Test interpreter discovery on legacy (pre-pypy3) versions of Python 2 and 3.
    # Note that this will likely not work on any version of Python >= 2.7.15 or
    # >= 3.7, since they switched to C locale by default, which will break
    # module string processing.
    if sys.version_info[:2] == (2, 7) and sys.version_info[2] >= 14:
        # test py2 < 2.7.15
        test_py2 = '/usr/bin/python'
        test_py2_path = '/usr/bin/python'

# Generated at 2022-06-22 20:02:29.465008
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError("test-message", "test-interpreter_name", "test-discovery_mode")
    assert obj.__str__() == "test-message"


# Generated at 2022-06-22 20:02:36.550131
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'test_message'
    interpreter_name = 'test_interpreter_name'
    discovery_mode = 'test_discovery_mode'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == str(e)
    assert interpreter_name == e.interpreter_name
    assert discovery_mode == e.discovery_mode



# Generated at 2022-06-22 20:02:37.728479
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError('', '', '')
    assert 'InterpreterDiscoveryRequiredError' in str(exception)


# Generated at 2022-06-22 20:02:45.370545
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'message' 
    interpreter_name = 'python'
    discovery_mode = 'auto'

    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(
                                            message,
                                            interpreter_name,
                                            discovery_mode)
    # Currently, this method is equal to __str__
    interpreter_discovery_required_error_repr = interpreter_discovery_required_error.__repr__()
    assert interpreter_discovery_required_error_repr == message

# Generated at 2022-06-22 20:02:51.470051
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        u"Python interpreter discovery failed for host hostname (found interpreters were [u'/usr/bin/python2.7'])",
        u'python',
        u'auto'
    )

    assert to_native(error) == u"Python interpreter discovery failed for host hostname (found interpreters were [u'/usr/bin/python2.7'])"

# Generated at 2022-06-22 20:03:01.574947
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(None, None, None, None)
    host = 'localhost'
    action = ActionModule(tqm, host, None)
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict(inventory_hostname='localhost')
    discover_interpreter(action, interpreter_name, discovery_mode, task_vars)



# Generated at 2022-06-22 20:03:04.575173
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interp_name = 'python'
    discovery_mode = 'auto'
    exc = InterpreterDiscoveryRequiredError('N/A', interp_name, discovery_mode)
    assert exc.interpreter_name == interp_name
    assert exc.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:03:09.031616
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            "Test Message", "python", "auto_legacy_silent"
        )
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == "Test Message"
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_legacy_silent"

# Generated at 2022-06-22 20:03:12.133100
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('Interpreter discovery failed', 'python', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-22 20:03:23.540122
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    # Create a dummy function, we just need its name in the Exception
    def foo():
        pass
    interpreter_name = 'python'
    discovery_mode = 'auto'

    # Do not implement the discovery, should raise the exception
    # InterpreterDiscoveryRequiredError
    try:
        discover_interpreter(foo, interpreter_name, discovery_mode, None)
    except InterpreterDiscoveryRequiredError as e:
        test_e = e

    # The string should contain the function name, the interpreter name and
    # the discovery mode
    assert interpreter_name in test_e.__str__()
    assert foo.__name__ in test_e.__str__()
    assert discovery_mode in test_e.__str__()

# Generated at 2022-06-22 20:03:34.003908
# Unit test for function discover_interpreter
def test_discover_interpreter():

    distro = 'Ubuntu'
    version = '18.04'
    task_vars = {'inventory_hostname': 'localhost',
                 'config_file': '/etc/ansible/ansible.cfg',
                 'config_file_setup': {'yaml': {'interpreter': '/usr/bin/python3'}},
                 'inventory_directory': '/private/etc/ansible/hosts',
                 'inventory_file': '/private/etc/ansible/hosts',
                 'env': {'ANSIBLE_CONFIG': '/private/etc/ansible/ansible.cfg'},
                 'ansible_python_interpreter': 'python3',
                 'ansible_interpreter_python': 'python3',
                 'ansible_playbook_python': 'python3'
                 }

    interpreter_

# Generated at 2022-06-22 20:03:39.749590
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Create object
    class_id = InterpreterDiscoveryRequiredError("test message", "test interpreter", "test discovery")

    # Run test
    assert isinstance(class_id, InterpreterDiscoveryRequiredError) is True
    assert class_id.interpreter_name == "test interpreter"
    assert class_id.discovery_mode == "test discovery"

# Generated at 2022-06-22 20:03:43.911874
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError(
        "message",
        "myinterpreter",
        "mydiscoverymode"
    )

    assert str(exception) == "message"

# Generated at 2022-06-22 20:03:48.323450
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(u'', u'', u'')
    err_repr = u"InterpreterDiscoveryRequiredError('', '', '')"
    assert err.__repr__() == err_repr


# Generated at 2022-06-22 20:03:53.004128
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError('this is a message', 'python3', 'auto')
    assert str(exc) == 'this is a message'
    assert exc.interpreter_name == 'python3'
    assert exc.discovery_mode == 'auto'



# Generated at 2022-06-22 20:03:59.447243
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action', 'python', 'auto', {}) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto', {}) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python2', 'auto', {}) == u'/usr/bin/python2'
    assert discover_interpreter(None, 'python3', 'auto', {}) == u'/usr/bin/python3'

# Generated at 2022-06-22 20:04:08.721455
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # check if two InterpreterDiscoveryRequiredError objects with same and different attributes are equal
    a = InterpreterDiscoveryRequiredError(u"test error", u"python", u"auto_legacy")
    b = InterpreterDiscoveryRequiredError(u"test error", u"python", u"auto")
    c = InterpreterDiscoveryRequiredError(u"test error", u"python", u"auto_legacy")

    assert str(a) != str(b)
    assert str(a) != str(c)

    assert str(a) == u"test error"