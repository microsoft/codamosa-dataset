

# Generated at 2022-06-22 19:54:09.468473
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Test with an exception that doesn't include the interpreter_name and discovery_mode attributes.
    # This should cause the method to raise an exception.
    try:
        # A plain Exception
        message = "The interpreter is not supported on this host."
        e = Exception(message)
        output = str(InterpreterDiscoveryRequiredError.__str__(e, 'python', 'auto'))
    except Exception as ex:
        output = str(ex)

    assert output == message

    # Test with an exception that does include the interpreter_name and discovery_mode attributes.
    # This should return output that includes those attributes.

# Generated at 2022-06-22 19:54:10.489144
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert None, "Tests not yet implemented"

# Generated at 2022-06-22 19:54:18.102962
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = "Interpreter discovery required"
    e = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert interpreter_name == e.interpreter_name
    assert discovery_mode == e.discovery_mode
    assert message == e.message

# Generated at 2022-06-22 19:54:23.310446
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = u'foo'
    discovery_mode = u'bar'
    message = u'baz'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.__repr__() == message



# Generated at 2022-06-22 19:54:31.220362
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    class DummyAction:
        pass
    dummy_action = DummyAction()
    dummy_action.environment = {'ANSIBLE_DISCOVER_INTERPRETER': 'force'}
    msg = 'msg'
    interpreter_name = 'python'
    discovery_mode = 'force'
    task_vars = {'inventory_hostname': 'localhost'}
    # No Error
    try:
        raise InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.__repr__() == msg

    # Error

# Generated at 2022-06-22 19:54:37.395271
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Unit test for method __repr__ of class InterpreterDiscoveryRequiredError"""
    message = "message"
    interpreter_name = "interpreter_name"
    discovery_mode = "discovery_mode"
    test_exception = InterpreterDiscoveryRequiredError(
        message, interpreter_name, discovery_mode)
    assert to_text(test_exception) == to_text(test_exception.__repr__())

# Generated at 2022-06-22 19:54:48.981786
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Setup Test
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    msg = u"Host inventory_hostname should use python at location /usr/bin/python, but is using /usr/local/bin/python " \
          u"instead. See https://docs.ansible.com/ansible/latest/reference_appendices/interpreter_discovery.html " \
          u"for more information"
    expected = msg

    # Exercise
    target = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    actual = target.__str__()

    # Verify
    assert actual == expected, "str({0}) expected:\n{1}\nactual:\n{2}".format(msg, expected, actual)



# Generated at 2022-06-22 19:54:53.429449
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "test"
    interpreter_name = "python"
    discovery_mode = "auto"
    m = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert m.message == msg
    assert str(m) == msg

# Generated at 2022-06-22 19:54:58.246415
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    """
    Test method __str__ of InterpreterDiscoveryRequiredError
    """
    message = 'message'
    interpreter_name = 'python3'
    discovery_mode = 'auto'
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_discovery_required_error.__str__() == message

# Generated at 2022-06-22 19:55:00.633164
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('test_method', 'test_interpreter', 'test_mode')
    assert err.__str__() == err.message

# Generated at 2022-06-22 19:55:07.550253
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    stdout = "stdout"
    stderr = "stderr"
    rc = 0
    msg = "msg"
    name = "name"
    mode = 'auto'

    res = InterpreterDiscoveryRequiredError(msg, name, mode)
    assert res.message is msg
    assert res.interpreter_name is name
    assert res.discovery_mode is mode
    assert res.__str__() == msg


# Generated at 2022-06-22 19:55:12.635949
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='auto')
    assert err.message == 'message'
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'auto'
    assert str(err) == 'message'



# Generated at 2022-06-22 19:55:22.928129
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    expected_message = "Python interpreter discovery required"
    expected_interpreter_name = "python"
    expected_discovery_mode = "auto_legacy_silent"

    ex = InterpreterDiscoveryRequiredError(expected_message, expected_interpreter_name, expected_discovery_mode)

    assert "Python interpreter discovery required" == str(ex)
    assert "Python interpreter discovery required" == repr(ex)
    assert expected_message == ex.message
    assert expected_interpreter_name == ex.interpreter_name
    assert expected_discovery_mode == ex.discovery_mode

# Generated at 2022-06-22 19:55:26.530166
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    idre = InterpreterDiscoveryRequiredError(u"test", u"test", u"test")
    result = str(idre)
    assert result == u"test"



# Generated at 2022-06-22 19:55:37.638610
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    def test_InterpreterDiscoveryRequiredError__init__():
        loader = DataLoader()
        variable_manager = VariableManager()
        inventory = Inventory(loader, variable_manager, host_list="")
        test_host = inventory.get_host('test_host')
        test_host.vars = {'ansible_python_interpreter': '/usr/bin/python'}
        variable_manager.set_host_variable(test_host, 'ansible_python_interpreter', '/usr/bin/python')

# Generated at 2022-06-22 19:55:49.217610
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class ActionModuleTest(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = object()

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd.startswith("python"):
                if cmd.endswith("/python2.7"):
                    return {'stdout': '{"platform_dist_result": []}'}
                elif cmd.endswith("/python3.6"):
                    return {'stdout': '{"platform_dist_result": [],'
                            '"osrelease_content": "ID=rhel,VERSION_ID=7.5"}'}

# Generated at 2022-06-22 19:55:51.680551
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert error.__str__() == "message"


# Generated at 2022-06-22 19:55:53.520162
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError(message='interpreter discovery required',
                                                interpreter_name='python',
                                                discovery_mode='auto_legacy')
    except InterpreterDiscoveryRequiredError as exception:
        assert repr(exception) == 'interpreter discovery required'

# Generated at 2022-06-22 19:55:59.958832
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    """Unit test for constructor of class InterpreterDiscoveryRequiredError"""
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'message'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:56:03.109637
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    my_object = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    expected_value = 'message'
    value = my_object.__str__()
    assert value == expected_value

# Generated at 2022-06-22 19:56:06.726660
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    edre = InterpreterDiscoveryRequiredError(message="foo", interpreter_name="python", discovery_mode="auto")
    with pytest.raises(NotImplementedError):
        assert repr(edre)

# Generated at 2022-06-22 19:56:11.788009
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = "Could not determine the python interpreter"

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert interpreter_name == error.interpreter_name
    assert discovery_mode == error.discovery_mode


# Generated at 2022-06-22 19:56:16.969137
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError("Interpreter test_python is not available on this system and "
                                           "discovery mode test_auto_legacy_silent requires it.",
                                           "test_python",
                                           "test_auto_legacy_silent")
    assert str(ex) == "Interpreter test_python is not available on this system and discovery mode test_auto_legacy_silent requires it."


# Generated at 2022-06-22 19:56:23.800883
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(
        '{{ interpreter }} interpreter is required to run python3 code',
        'foo',
        'foobar'
    )

    assert str(err) == '{{ interpreter }} interpreter is required to run python3 code'
    assert err.interpreter_name == 'foo'
    assert err.discovery_mode == 'foobar'



# Generated at 2022-06-22 19:56:26.532318
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError('%s', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as exc:
        assert str(exc) == '%s'

# Generated at 2022-06-22 19:56:31.084735
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError("msg", "python", "legacy")
    assert e.__repr__() == "msg"
    assert e.interpreter_name == "python"
    assert e.discovery_mode == "legacy"

# Generated at 2022-06-22 19:56:34.637770
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_exception = InterpreterDiscoveryRequiredError("Some message", 'python', 'auto')
    assert to_str("Some message") == test_exception.__str__()


# Generated at 2022-06-22 19:56:37.848767
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = "legacy"
    exception = InterpreterDiscoveryRequiredError("Some error string", interpreter_name, discovery_mode)
    assert "Some error string" == exception.__repr__()



# Generated at 2022-06-22 19:56:40.153541
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert 'test_message' == InterpreterDiscoveryRequiredError('test_message', 'test_interpreter_name', 'test_discovery_mode').__repr__()

# Generated at 2022-06-22 19:56:42.657823
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError('m', 'i', 'd')
    assert obj.__repr__() == 'm'


# Generated at 2022-06-22 19:56:46.905093
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "Error message"
    interpreter_name = "python"
    discovery_mode = "normal"
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(exception) == message

# Generated at 2022-06-22 19:56:49.787409
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # the __str__ method returns self.message
    assert str(error) == message

# Generated at 2022-06-22 19:56:51.413564
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError('message', 'name', 'mode')
    assert 'message' == str(exception)

# Generated at 2022-06-22 19:56:52.693859
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert repr(error) == 'message'

# Generated at 2022-06-22 19:56:56.321396
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected_result = "test message"
    discovery_mode = "test discovery_mode"

    result = InterpreterDiscoveryRequiredError(expected_result, "test interpreter_name", discovery_mode).__repr__()

    assert expected_result == result


# Generated at 2022-06-22 19:56:59.127582
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    a = InterpreterDiscoveryRequiredError('','','a')
    assert a.interpreter_name == ''
    assert a.discovery_mode == 'a'

# Generated at 2022-06-22 19:57:04.037636
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with pytest.raises(Exception) as excinfo:
        raise InterpreterDiscoveryRequiredError(to_text("No interpreter found"), to_text("python"), to_text("auto"))
    assert "No interpreter found" in str(excinfo.value)

# Generated at 2022-06-22 19:57:14.161114
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock
    import StringIO
    # FUTURE: update to use mock_open when moving to Python 2.7 or later
    class open_mock(object):
        def __init__(self, data):
            self.data = data
            self.fileobj = StringIO.StringIO(data)

        def __call__(self, name, mode='r'):
            self.fileobj.seek(0)
            return self.fileobj

    # can't use patch when the decorated method is an inner class; it won't get bound and will try to unwrap the instance
    # instead. TODO: update to use functools.wraps
    m = mock.Mock(name='action_plugin')
    m.display = display
    m._low_level_execute_command = mock.Mock()
    m._low_level

# Generated at 2022-06-22 19:57:19.497478
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('Error', 'interpreter_name', 'discovery_mode')
    assert error.__repr__() == error.__str__() == 'Error'

# Generated at 2022-06-22 19:57:28.752534
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system
    from ansible.module_utils import common_koji
    from io import StringIO

    class TestModule(object):
        def __init__(self, task_vars, action_vars):
            self._discovery_warnings = []
            self.task_vars = task_vars
            self.action_vars = action_vars

        def get_task_vars(self):
            return self.task_vars

        def get_action_vars(self):
            return self.action_vars

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            self.cmd = cmd
            self.sudoable = sudoable

# Generated at 2022-06-22 19:57:33.970239
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    expected_msg = "test InterpreterDiscoveryRequiredError"
    exception_obj = InterpreterDiscoveryRequiredError(expected_msg, 'python', 'auto')
    assert exception_obj.__str__() == expected_msg


# Test for method _version_fuzzy_match of module interpreter_discovery

# Generated at 2022-06-22 19:57:37.153846
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_obj = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert test_obj.__str__() == 'message'

# Generated at 2022-06-22 19:57:42.427623
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # if not is_silent:
    msg = "platform python 3.2.0 not found on host server.example.com"
    ex = InterpreterDiscoveryRequiredError(msg, "python", "auto")
    assert(msg == ex.__repr__())



# Generated at 2022-06-22 19:57:47.577138
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = u'Python interpreter auto-discovery required'
    interpreter_name = u'python'
    discovery_mode = u'auto'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.__str__() == message
    assert error.__repr__() == message


# Generated at 2022-06-22 19:57:52.267044
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    json_input = {'msg': 'Python interpreter discovery failed for host test_host1: interpreter discovery required',
                  'interpreter_name': 'python',
                  'discovery_mode': 'auto'}
    error = InterpreterDiscoveryRequiredError.__str__(json_input)
    assert error == json_input['msg']


# Generated at 2022-06-22 19:58:04.998658
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    interpreter_name = 'python'

    # we test both the legacy (pre-2.7) and current modes
    # legacy mode uses the discover_interpreter function and sets the interpreter in the module_vars dict
    # current mode sets the interpreter as a connection option and does not set the dict var

# Generated at 2022-06-22 19:58:14.920488
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class action(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = connection()

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            return self._connection.execute_command(command, in_data)

    class connection(object):
        def __init__(self):
            self.has_pipelining = True

        def execute_command(self, command, in_data=None):
            if command.startswith('command -v'):
                return dict(rc=0, stdout=u'/usr/bin/python')


# Generated at 2022-06-22 19:58:23.599427
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from ansible.executor.discovery import InterpreterDiscoveryRequiredError

    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    msg = 'Interpreter discovery required for {} but discovery mode is {}.'.format(interpreter_name, discovery_mode)

    assert repr(InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)) == msg


# Generated at 2022-06-22 19:58:27.771036
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python2'
    discovery_mode = 'auto'
    error_info = 'some info'
    ex = InterpreterDiscoveryRequiredError(error_info, interpreter_name, discovery_mode)
    expected_value = "some info"
    assert repr(ex) == expected_value


# Generated at 2022-06-22 19:58:30.472770
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("test", "python", "auto_legacy")
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_legacy"

# Generated at 2022-06-22 19:58:42.249200
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery_tools import _version_fuzzy_match


# Generated at 2022-06-22 19:58:54.311168
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Tests the ability of the function discover_interpreter to
    discover a system's python interpreter. This test only
    contains the first use case that checks to see if the
    system's python interpreter is found using the shell
    commands, and if the python interpreter is found,
    discover_interpreter should return the interpreter path.
    """
    expected_result = '/usr/bin/python'

    # Mock the _low_level_execute_command function in
    # ansible.executor.action_plugins.shell
    class MockAction:
        def __init__(self):
            self.shell_bootstrap = ''
            self._discovery_warnings = []
            self._connection = MockConnection()

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            self.shell

# Generated at 2022-06-22 19:58:55.018804
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-22 19:58:58.982393
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'I can haz messages'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == err.__str__()



# Generated at 2022-06-22 19:59:03.851013
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    inter_discov_not_supported = InterpreterDiscoveryRequiredError(
        'Interpreter discovery not supported for {0}',
        'pyhton',
        'auto_legacy')

    inter_discov_not_supported.interpreter_name == 'python'
    inter_discov_not_supported.discovery_mode == 'auto_legacy'

# Generated at 2022-06-22 19:59:08.084039
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module_args = dict(
        interpreter_name='python',
        discovery_mode='auto',
        task_action='setup'
    )

    # test exact match
    platform_info = dict(
        platform_dist_result=['arch linux arm', '4.10.1-1', 'armv7h']
    )
    found_interpreter_path = discover_interpreter(None, module_args['interpreter_name'], module_args['discovery_mode'],
                                                  dict(inventory_hostname='localhost', platform_info=platform_info))
    assert found_interpreter_path == '/usr/bin/python'

    # test version mismatch

# Generated at 2022-06-22 19:59:11.883422
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError(
        message='mocked error message',
        interpreter_name='mocked name',
        discovery_mode='mocked mode',
    )

    # Test execution
    assert str(exc) == 'mocked error message'

# Generated at 2022-06-22 19:59:17.411143
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ''' InterpreterDiscoveryRequiredError: test method __repr__ '''

    # Create a new InterpreterDiscoveryRequiredError object
    obj = InterpreterDiscoveryRequiredError(message='Unit test', interpreter_name='test', discovery_mode='test')

    assert obj.__repr__() == 'Unit test'
    assert obj.__str__() == 'Unit test'


# Generated at 2022-06-22 19:59:23.249254
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err_msg = 'Test message'
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    err = InterpreterDiscoveryRequiredError(err_msg, interpreter_name, discovery_mode)
    assert type(err) is InterpreterDiscoveryRequiredError
    assert err.interpreter_name == interpreter_name
    assert err.discovery_mode == discovery_mode
    assert err.message == err_msg
    assert str(err) == err_msg
    assert repr(err) == err_msg

# Generated at 2022-06-22 19:59:26.460672
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy")
    assert repr(error) == "message"



# Generated at 2022-06-22 19:59:29.614728
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    instance = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert instance.interpreter_name == "interpreter_name"



# Generated at 2022-06-22 19:59:34.186321
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert exc.__str__() == "message"
    assert str(exc) == "message"
    assert str(exc) == exc.message
    assert exc.__repr__() == "message"
    assert repr(exc) == "message"

# Generated at 2022-06-22 19:59:38.401328
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert err.__str__() == 'message'


# Generated at 2022-06-22 19:59:42.250061
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception_object = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='auto')
    assert 'message' == exception_object.__repr__()



# Generated at 2022-06-22 19:59:52.473411
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor

    class ActionModule(object):
        def __init__(self, task_executor):
            self._task_executor = task_executor

    class Connection(object):
        def __init__(self, support_pipelining):
            self._support_pipelining = support_pipelining

        @property
        def has_pipelining(self):
            return self._support_pipelining

    class PlayContext(object):
        def __init__(self):
            self.become = False
            self.become_user = None
            self.become_method = None
            self.become_pass = None
            self.become_exe = None


# Generated at 2022-06-22 19:59:57.008071
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "interpreter"
    discovery_mode = "discovery_mode"
    message = "message"
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.__str__() == message


# Generated at 2022-06-22 20:00:00.506014
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError("test", "python", "legacy")
    assert e.interpreter_name == "python"
    assert e.discovery_mode == "legacy"

# Generated at 2022-06-22 20:00:04.092613
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Create mock objects
    interpreter_name = "python"
    discovery_mode = "auto_silent"
    test = InterpreterDiscoveryRequiredError("test message", interpreter_name, discovery_mode)

    assert str(test) == test.message

# Generated at 2022-06-22 20:00:15.698062
# Unit test for function discover_interpreter

# Generated at 2022-06-22 20:00:22.538765
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('foo', 'python', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as exc:
        assert exc.message == 'foo'
        assert exc.interpreter_name == 'python'
        assert exc.discovery_mode == 'auto_legacy_silent'
        assert str(exc) == 'foo'
        assert repr(exc) == 'foo'

# Generated at 2022-06-22 20:00:24.180212
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    a = InterpreterDiscoveryRequiredError("", interpreter_name, discovery_mode)
    assert a.__repr__() == ""

# Generated at 2022-06-22 20:00:28.774998
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Interpreter discovery required"

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(error) == message



# Generated at 2022-06-22 20:00:30.503404
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("anything", "python", "auto")
    assert str(error) == "anything"

# Generated at 2022-06-22 20:00:37.433897
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Creating object of class InterpreterDiscoveryRequiredError
    interpreter_error = InterpreterDiscoveryRequiredError('foo', 'python', 'bar')

    # Testing attributes of object of class InterpreterDiscoveryRequiredError
    assert interpreter_error.interpreter_name == 'python'
    assert interpreter_error.discovery_mode == 'bar'
    assert interpreter_error.message == 'foo'

# Generated at 2022-06-22 20:00:42.578392
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        message='[test_message]',
        interpreter_name='python',
        discovery_mode='auto')

    result = error.__str__()

    # Check if result is of type string
    assert isinstance(result, str)
    # Check if result is equals to message
    assert result == '[test_message]'

# Generated at 2022-06-22 20:00:45.576308
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError("message", "interpreter", "discovery")
    assert repr(exc) == "message"


# Generated at 2022-06-22 20:00:47.195624
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("", "", "")
    assert error.__repr__() == error.message

# Generated at 2022-06-22 20:00:50.896316
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert str(err) == "message"
    assert repr(err) == "message"



# Generated at 2022-06-22 20:01:02.548601
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import platform
    import sys
    import six
    import unittest
    from mock import patch, MagicMock

    class TestAction(object):
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            res = {'stdout': u''}
            if in_data:
                in_data = to_text(in_data, errors='surrogate_or_strict')
                res['stdout'] = discover_interpreter_script(in_data)
            elif 'uname' in cmd:
                res['stdout'] = '{0}\n'.format(platform.system().lower())

            return res

        _discovery_warnings = []


# Generated at 2022-06-22 20:01:06.279500
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(
        message='message',
        interpreter_name='python',
        discovery_mode='force')

    assert err.__repr__() ==  err.message


# Generated at 2022-06-22 20:01:08.525319
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(message="Test Message", interpreter_name="python", discovery_mode="auto")
    assert repr(err) == "Test Message"


# Generated at 2022-06-22 20:01:15.489386
# Unit test for function discover_interpreter
def test_discover_interpreter():
    hosts = {'inventory_hostname': 'test_host'}
    action = type('TestAction', (object,), {'_low_level_execute_command': _test_interpreter_action_command,
                                            '_discovery_warnings': []})
    interpreter = discover_interpreter(action, 'python', 'auto_legacy_silent', hosts)
    assert(interpreter == 'python')


# Generated at 2022-06-22 20:01:20.515094
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    str_result = exception.__str__()
    assert str_result == message

# Generated at 2022-06-22 20:01:21.343069
# Unit test for function discover_interpreter
def test_discover_interpreter():
    raise Exception('Not implemented')

# Generated at 2022-06-22 20:01:27.629945
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    exp_res = message

    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert to_native(err.__str__()) == to_native(exp_res)


# Generated at 2022-06-22 20:01:36.658249
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'Interpreter discovery is required'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as err:
        assert message == err.message
        assert interpreter_name == err.interpreter_name
        assert discovery_mode == err.discovery_mode
        assert str(err) == message
        assert repr(err) == message
    # this should never be reached
    assert False

# Generated at 2022-06-22 20:01:38.633399
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert InterpreterDiscoveryRequiredError("m", "py", "auto_legacy") == InterpreterDiscoveryRequiredError("m", "py", "auto_legacy").__repr__()

# Generated at 2022-06-22 20:01:42.520772
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    f = lambda: raise_()
    with pytest.raises(InterpreterDiscoveryRequiredError) as e:
        f()

    err = str(e.value)
    assert "InterpreterDiscoveryRequiredError" in err
    assert "python" in err
    assert "auto" in err



# Generated at 2022-06-22 20:01:45.362762
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "custom message"
    interp_name = "python"
    discovery_mode = "auto"
    exception = InterpreterDiscoveryRequiredError(msg, interp_name, discovery_mode)
    assert msg == exception.__repr__()

# Generated at 2022-06-22 20:01:51.250830
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with pytest.raises(InterpreterDiscoveryRequiredError) as excinfo:
        raise InterpreterDiscoveryRequiredError("", "", "")
    assert 'InterpreterDiscoveryRequiredError' in str(excinfo.value)
    assert isinstance(excinfo.value, InterpreterDiscoveryRequiredError)
    assert excinfo.value.interpreter_name == ""
    assert excinfo.value.discovery_mode == ""


# Generated at 2022-06-22 20:01:53.721418
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    with pytest.raises(InterpreterDiscoveryRequiredError) as e:
        raise InterpreterDiscoveryRequiredError(
            u"Python interpreter discovery required",
            u"python",
            u"auto_legacy_silent"
        )
    expected = u"Python interpreter discovery required"
    actual = to_text(e.value)
    assert expected == actual

# Generated at 2022-06-22 20:02:07.188858
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        import ansible.plugins.action.setup
    except ImportError:
        from ansible.plugins.action import setup

    # copy the "setup" action invocation
    action = setup.ActionModule(
        task=dict(
            action=dict(setup=dict()),
            args=dict()),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # use the config value we'd normally get from AnsibleModule
    action._discovery_warnings = []

    # need to pre-populate the task_vars with the magic python interpreter vars so they can be used in the config values
    # we use to look up the interpreter map, etc.

# Generated at 2022-06-22 20:02:09.415504
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('error message', 'python', 'auto')
    expected = 'error message'
    output = error.__str__()
    assert output == expected

# Generated at 2022-06-22 20:02:12.821497
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'abc'

    interpreterDiscoveryRequiredError = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    result = interpreterDiscoveryRequiredError.__repr__()

    assert interpreterDiscoveryRequiredError.message == result

# Generated at 2022-06-22 20:02:15.392150
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('Message', 'python', 'auto')
    assert error.__str__() == 'Message'

# Generated at 2022-06-22 20:02:19.756120
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    try:
        raise InterpreterDiscoveryRequiredError('Python interpreter discovery required',
                                                'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        #print(repr(e))
        assert repr(e) == 'Python interpreter discovery required'

# Generated at 2022-06-22 20:02:22.840643
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'msg'
    name = 'name'
    mode = 'mode'

    e = InterpreterDiscoveryRequiredError(msg, name, mode)

    assert str(e) == msg

# Generated at 2022-06-22 20:02:32.338177
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import ResultCallback
    from ansible.module_utils.connection import ConnectionBase
    from ansible.vars.hostvars import HostVars

    test_vars = HostVars()

    test_vars['inventory_hostname'] = 'test_hostname'
    test_vars['ansible_python_interpreter'] = 'python'

    test_vars['ansible_python_interpreter_version'] = '2.7.12'
    test_vars['ansible_python_interpreter_version_bare'] = '2.7'

# Generated at 2022-06-22 20:02:44.947623
# Unit test for function discover_interpreter
def test_discover_interpreter():
    script_path = os.path.dirname(os.path.dirname(os.path.dirname(inspect.getfile(inspect.currentframe()))))
    distro_map = os.path.join(script_path, 'examples', 'interpreter_python_distro_map.yml')
    interpreter_python_distro_map = yaml.load(open(distro_map), Loader=yaml.SafeLoader)

    task_vars = {'ansible_connection': 'local',
                 'ansible_become_user': 'become_user',
                 'ansible_become_password': 'become_password',
                 'become_env': {},
                 'ansible_python_interpreter': interpreter_python_distro_map}

    display = Display()

# Generated at 2022-06-22 20:02:48.956846
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'Python interpreter discovery required for host hostname'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(exception) == message

# Generated at 2022-06-22 20:02:53.106348
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'one'
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    e = InterpreterDiscoveryRequiredError(message=msg, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert repr(e) == msg



# Generated at 2022-06-22 20:02:59.803667
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('TestMessage', 'python', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as err:
        assert str(err) == 'TestMessage'
        assert err.interpreter_name == 'python'
        assert err.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-22 20:03:09.563843
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Unsupported interpreter
    try:
        discover_interpreter(None, 'perl', 'auto', None)
        assert False, "Incorrect interpreter type should raise error"
    except ValueError as e:
        assert str(e) == "Interpreter discovery not supported for perl"
    # Legacy auto mode
    if 'auto_legacy_silent' in dir(interpreter):
        try:
            discover_interpreter(None, 'python', 'auto_legacy_silent', None)
            assert False, "Incorrect interpreter type should raise error"
        except ValueError as e:
            assert str(e) == "auto_legacy* discovery modes are not supported for interpreter discovery"
    # Not implemented mode

# Generated at 2022-06-22 20:03:14.113482
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "Message"
    interpreter_name = "Python"
    discovery_mode = "auto_legacy"

    exception = None
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        exception = e

    assert exception is not None
    assert exception.message == message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode
    assert str(exception) == message

# Generated at 2022-06-22 20:03:22.007754
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # pylint: disable=protected-access
    error = InterpreterDiscoveryRequiredError(
        interpreter_name='python3.6',
        message='Python interpreter discovery required, but not enabled or supported',
        discovery_mode='auto_legacy_silent')

    assert error
    assert error.message == 'Python interpreter discovery required, but not enabled or supported'
    assert error.interpreter_name == 'python3.6'
    assert error.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-22 20:03:25.703390
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError(
            message='test message',
            interpreter_name='python',
            discovery_mode='auto_legacy_silent'
            )
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == 'test message'

# Generated at 2022-06-22 20:03:30.671484
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("unit test", "python", "auto")
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"
    assert str(error) == "unit test"
    assert repr(error) == "unit test"

# Generated at 2022-06-22 20:03:33.823961
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(message='message1', interpreter_name='python', discovery_mode='auto')
    assert to_native(error) == "message1"


# Generated at 2022-06-22 20:03:37.873602
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "message"
    interpreter_name = "python"
    discovery_mode = "auto_silent"
    x = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert x.__repr__() == msg

# Generated at 2022-06-22 20:03:44.255121
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = u'Python interpreter discovery required'
    interpreter_name = u'python'
    discovery_mode = u'auto'

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == message
        assert ex.interpreter_name == interpreter_name
        assert ex.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:03:48.244340
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    class_ = InterpreterDiscoveryRequiredError
    class_instance = class_("message", "interpreter_name", "discovery_mode")
    assert str(class_instance) == "message"

# Generated at 2022-06-22 20:03:54.891457
# Unit test for function discover_interpreter
def test_discover_interpreter():
    platform_info = json.loads(pkgutil.get_data('ansible.executor.discovery', 'test_data/python_target.json'))
    distro, version = _get_linux_distro(platform_info)

    if distro != 'centos' or version != '7.7.1908':
        raise AssertionError('distro: {0} version: {1}'.format(distro, version))

# Generated at 2022-06-22 20:03:58.917674
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Create an instance of InterpreterDiscoveryRequiredError
    err = InterpreterDiscoveryRequiredError('error message', 'python', 'auto')
    # Test if the __str__ method returns the proper string
    assert err.__str__() == err.message


# Generated at 2022-06-22 20:03:59.620914
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass