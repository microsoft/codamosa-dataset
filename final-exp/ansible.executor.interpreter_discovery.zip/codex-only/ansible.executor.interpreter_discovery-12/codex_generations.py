

# Generated at 2022-06-22 19:54:09.496915
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.action.discovery
    import ansible.plugins.action
    import ansible.plugins
    import ansible.runner
    import ansible.constants
    import ansible.utils


# Generated at 2022-06-22 19:54:13.040743
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "Discovery required"
    interpreter_name = "python"
    discovery_mode = "auto_legacy"
    exc = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert exc.__repr__() == msg

# Generated at 2022-06-22 19:54:17.484311
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('Test Exception', 'ansible', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'ansible'
        assert e.discovery_mode == 'auto'

# Generated at 2022-06-22 19:54:28.962681
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase
    from ansible.vars import VariableManager

    class ActionModule(ActionBase):
        TRANSFERS_FILES = True

        def run(self, tmp=None, task_vars=None):
            return TaskResult(dict(changed=False, ansible_interpreter_python=discover_interpreter('', 'python', 'auto', task_vars)))

    varmgr = VariableManager()
    varmgr.data_for_hosts('example.com')
    varmgr.set_vars({'ansible_connection': 'local'})

    action = ActionModule(variable_manager=varmgr, task=dict())
    action._connection = action.connect()
    action._low_level_execute

# Generated at 2022-06-22 19:54:33.614632
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_message = 'error'
    interpreter_name = 'python'
    discovery_mode = 'conditional_fallback'
    exception = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert repr(exception) == error_message

# Generated at 2022-06-22 19:54:43.328425
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test for case where expected interpreter is not found among those discovered by
    # shell uname, this is where the default interpreter is returned.
    host = 'host-1'
    task_vars = dict(inventory_hostname=host)
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    action_mock = type('Action', (object,), dict(
        _discovery_warnings=[],
        _low_level_execute_command=lambda self,cmd,sudoable=False: dict(stdout='PLATFORM\nLinux',stderr='')))
    action = action_mock()
    interpreter_path = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert interpreter_path == u'/usr/bin/python'

   

# Generated at 2022-06-22 19:54:48.139312
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    discovery_mode = 'auto_legacy_silent'
    obj = InterpreterDiscoveryRequiredError(message="message", interpreter_name='python', discovery_mode=discovery_mode)
    expected = 'message'
    assert expected == obj.__repr__()


# Generated at 2022-06-22 19:54:54.666017
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Test when message is not blank
    try:
        raise InterpreterDiscoveryRequiredError("some message", "some interpreter name", "some discovery mode")
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == "some message"
        assert e.interpreter_name == "some interpreter name"
        assert e.discovery_mode == "some discovery mode"


# Generated at 2022-06-22 19:54:59.428472
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    with pytest.raises(InterpreterDiscoveryRequiredError) as excinfo:
        raise InterpreterDiscoveryRequiredError(
            "message",
            interpreter_name="interpreter_name",
            discovery_mode="discovery_mode"
        )
    assert "message" == str(excinfo.value)

# Generated at 2022-06-22 19:55:06.240657
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Check the case when interpreter name is not python
    exception = InterpreterDiscoveryRequiredError("message", "perl", "auto")
    assert exception.__str__() == "message"

    # Check the case when interpreter name is python
    exception = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert exception.__str__() == "message"

# Generated at 2022-06-22 19:55:12.593912
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(message="Can not find: /usr/bin/python", interpreter_name="python",
                                              discovery_mode="auto")
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"
    assert str(error) == "Can not find: /usr/bin/python"
    assert repr(error) == "Can not find: /usr/bin/python"

# Generated at 2022-06-22 19:55:17.181890
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_args = u"Something wrong happened"
    test_interpreter_name = u"python"
    test_discovery_mode = u"auto_legacy"
    test_case = InterpreterDiscoveryRequiredError(test_args, test_interpreter_name, test_discovery_mode)
    assert test_case.__repr__() == test_args

# Generated at 2022-06-22 19:55:21.375127
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Test for InterpreterDiscoveryRequiredError."""
    message = '"message" for InterpreterDiscoveryRequiredError'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    result = exception.__repr__()
    assert result == message

# Generated at 2022-06-22 19:55:25.283026
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = "foo"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.__repr__() == message

# Generated at 2022-06-22 19:55:35.207822
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Init exception object
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'Discovery mode {0} is enabled, but could not determine appropriate interpreter for {1} on host'\
                .format(interpreter_name, discovery_mode)
    exception_obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # Call method __repr__
    exception_obj_repr = exception_obj.__repr__()

    # Verify that __repr__ return expected value
    assert message == exception_obj_repr


# Generated at 2022-06-22 19:55:41.497847
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "message"
    interpreter_name = "MyInterpreter"
    discovery_mode = "MyDiscoveryMode"

    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.message == message
    assert err.interpreter_name == interpreter_name
    assert err.discovery_mode == discovery_mode
    assert str(err) == message


# Generated at 2022-06-22 19:55:43.863833
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert error.__str__() == 'message'

# Generated at 2022-06-22 19:55:49.629918
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Unable to find usable interpreter for python'
    interpreter_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_error.__str__() == message


# Generated at 2022-06-22 19:55:57.103567
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Failed to discover interpreters for python on host foo.bar.com. Provide the " \
              "'interpreter_python' option in the inventory or on the command " \
              "line to select the interpreter to use for this task."

    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert repr(err)

# Generated at 2022-06-22 19:56:08.710428
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """

    Check that the __repr__ function of InterpreterDiscoveryRequiredError
    returns a correct format of string.

    Parameter:
    (str) message
        A string that indicates a message of the error.

    (str) interpreter_name
        A string that indicates a name of an interpreter.

    (str) discovery_mode
        A string that indicates a discovery_mode of an interpreter.

    """
    # Create a InterpreterDiscoveryRequiredError object.
    e = InterpreterDiscoveryRequiredError(
        message="Script not found in configured interpreter paths: /usr/bin/python",
        interpreter_name="python",
        discovery_mode="auto"
    )

    # Test whether the __repr__ function of InterpreterDiscoveryRequiredError object
    # returns a correct format string.
    # InterpreterDiscoveryRequired

# Generated at 2022-06-22 19:56:14.708256
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'Testing object'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert str(error) == message
    assert repr(error) == message


# Generated at 2022-06-22 19:56:20.416856
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'interpreter discovery is required'
    error = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert repr(error) == message

# Generated at 2022-06-22 19:56:31.905587
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    action = basic.AnsibleModule(argument_spec=dict())
    task_vars = dict()
    result = action.discover_interpreter('python', 'auto', 'auto', task_vars)
    assert result == '/usr/bin/python'
    result = action.discover_interpreter('python', 'auto', 'auto_silent', task_vars)
    assert result == '/usr/bin/python'
    result = action.discover_interpreter('python', 'auto', 'auto_legacy', task_vars)
    assert result == '/usr/bin/python'
    result = action.discover_interpreter('python', 'auto', 'auto_legacy_silent', task_vars)

# Generated at 2022-06-22 19:56:36.152578
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("msg", "python", "auto_legacy_silent")
    assert error.message == "msg"
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto_legacy_silent"

# Generated at 2022-06-22 19:56:38.448826
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "Unit test message"
    interpreter = "python"
    mode = "auto"
    ex = InterpreterDiscoveryRequiredError(msg, interpreter, mode)
    assert ex.__str__() == msg


# Generated at 2022-06-22 19:56:42.610206
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError("TEST_MESSAGE", "TEST_INTERPRETER_NAME", "TEST_DISCOVERY_MODE")
    except InterpreterDiscoveryRequiredError as e:
        assert repr(e) == e.message

# Generated at 2022-06-22 19:56:53.944983
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test without message
    try:
        raise InterpreterDiscoveryRequiredError(None, 'python', 'none')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message is not None
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'none'
        assert str(e) == e.message

    # Test with message
    try:
        raise InterpreterDiscoveryRequiredError('test message', 'python', 'none')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'test message'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'none'
        assert str(e) == 'test message'

# Generated at 2022-06-22 19:56:55.238009
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:56:57.470173
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(
        message='message',
        interpreter_name='python',
        discovery_mode='auto_legacy_silent'
    )
    assert str(error) == 'message'

# Generated at 2022-06-22 19:57:02.485475
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'
    assert error.__str__() == 'message'

# Generated at 2022-06-22 19:57:07.917445
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = 'Foo'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    expected_error_message = 'Foo'
    assert error.__str__() == expected_error_message


# Generated at 2022-06-22 19:57:19.869265
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.virtual.linux_distro import LinuxDistro
    from ansible.module_utils.facts.virtual.package_manager import PackageManager
    from ansible.plugins.action import ActionModule
    from ansible.plugins.loader import action_loader

    class TestActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            self._discovery_warnings = []
            super(TestActionModule, self).__init__(args, kwargs)

        def v2_runner_on_failed(self, *args, **kwargs):
            if 'result' in kwargs:
                raise InterpreterDiscoveryRequiredError(kwargs['result'].get('msg'), 'python', 'auto')


# Generated at 2022-06-22 19:57:28.750821
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    action = ActionModule(task_vars=task_vars)
    task_vars['inventory_hostname'] = 'testhost'
    task_vars['ansible_distribution'] = 'Ubuntu'
    task_vars['ansible_distribution_version'] = '16.04'
    task_vars['ansible_python_version'] = '2.7.12'
    assert discover_interpreter(action, 'python', 'auto', task_vars) == u'/usr/bin/python'
    task_vars['ansible_python_version'] = '3.8.1'
    assert discover_interpreter(action, 'python', 'auto', task_vars) == u'/usr/bin/python3'

# Generated at 2022-06-22 19:57:32.482022
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")

    # test for proper error object construction
    assert type(error) is InterpreterDiscoveryRequiredError
    assert error.interpreter_name == "interpreter_name"
    assert error.discovery_mode == "discovery_mode"

# Generated at 2022-06-22 19:57:44.750218
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.module_defs import basic
    try:
        import mock
    except ImportError:
        # if you are running py3, you must 'pip install mock' before you can run the tests
        raise ImportError('unable to import mock library')

    setattr(basic, '_discovery_warnings', [])
    task_vars = {'inventory_hostname': 'testhost'}

    with mock.patch('ansible.module_utils.common._load_params', return_value={'_ansible_verbosity': 2}):
        import ansible.module_utils.basic

# Generated at 2022-06-22 19:57:49.903506
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    object = InterpreterDiscoveryRequiredError(
        "cannot determine python interpreter for discovery mode auto", interpreter_name, discovery_mode)

    assert object.message == "cannot determine python interpreter for discovery mode auto"
    assert object.interpreter_name == interpreter_name
    assert object.discovery_mode == discovery_mode


# Generated at 2022-06-22 19:57:53.494850
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    message = 'Test Message'
    discovery_mode = 'auto_legacy_silent'

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == exception.__repr__()
    assert message == exception.__str__()

# Generated at 2022-06-22 19:57:57.162149
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'test_message'
    idr = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert idr.__repr__() == idr.message
    assert idr.__repr__() == message


# Generated at 2022-06-22 19:58:00.386201
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    obj = InterpreterDiscoveryRequiredError("foo", "bar", "baz")
    str(obj)

# Generated at 2022-06-22 19:58:04.211677
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(message='message', interpreter_name='interpreter_name', discovery_mode='discovery_mode')
    assert error.__str__() == 'message'

# Generated at 2022-06-22 19:58:07.647460
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError(
        'message',
        'interpreter_name',
        'discovery_mode',
    )
    assert obj.__str__() == 'message'

# Generated at 2022-06-22 19:58:11.483961
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError("message", "INTERPRETER", "discovery_mode")
    assert exc.interpreter_name == "INTERPRETER"
    assert exc.discovery_mode == "discovery_mode"
    assert str(exc) == "message"
    assert repr(exc) == "message"



# Generated at 2022-06-22 19:58:18.609902
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test all attributes
    exception_1 = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert exception_1.message == 'message'
    assert exception_1.interpreter_name == 'python'
    assert exception_1.discovery_mode == 'auto_legacy_silent'

    # Test __str__
    assert str(exception_1) == 'message'
    assert repr(exception_1) == 'message'

# Generated at 2022-06-22 19:58:26.590969
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    # Test with no exception message
    interpreter_name = 'python'
    discovery_mode = 'auto'

    exc = InterpreterDiscoveryRequiredError(None, interpreter_name, discovery_mode)
    assert exc.__repr__() == ''

    # Test with exception message
    exc_message = 'Exception message'
    exc = InterpreterDiscoveryRequiredError(exc_message, interpreter_name, discovery_mode)
    assert exc.__repr__() == exc_message


# Generated at 2022-06-22 19:58:30.508139
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    test_msg = 'test_msg'
    test_interpreter_name = 'test_interpreter_name'
    test_discovery_mode = 'test_discovery_mode'

    test_exception_object = InterpreterDiscoveryRequiredError(test_msg, test_interpreter_name, test_discovery_mode)

    assert repr(test_exception_object) == test_msg

# Generated at 2022-06-22 19:58:38.565911
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = 'Failed to get interpreter'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    # Fail
    try:
        raise InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == msg
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:58:41.037778
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert repr(error) == 'message'

# Generated at 2022-06-22 19:58:43.378200
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    x = InterpreterDiscoveryRequiredError(message='foobar', interpreter_name='foo', discovery_mode='bar')
    assert x.__str__() == "foobar"

# Generated at 2022-06-22 19:58:55.287987
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict

    task_vars = ImmutableDict(dict(
        inventory_hostname='testhost',
        ansible_python_interpreter='test_interpreter',
        ansible_python_interpreter_discovery_mode='test_discovery_mode',
    ))
    action = DummyModule()

    try:
        discover_interpreter(action, 'python', 'test_discovery_mode', task_vars)
    except InterpreterDiscoveryRequiredError:
        # we don't have a real connection, so discovery will fail in this case
        pass

    action._connection = DummyConnection()
    # we need a real connection (try a bad interpreter to increase test coverage)

# Generated at 2022-06-22 19:59:00.000913
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'Interpreter Discovery Failed for python on host abcd'

    ret = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ret.__repr__() == message



# Generated at 2022-06-22 19:59:03.813850
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'test message'
    interpreter_name = 'test_python'
    discovery_mode = 'test_auto_legacy'
    exception = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert msg in exception.__str__()

# Generated at 2022-06-22 19:59:09.233781
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='auto')
    assert err.message == 'message'
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'auto'



# Generated at 2022-06-22 19:59:12.604298
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError('test message', 'test_interpreter_name', 'test_discovery_mode')
    assert obj.__repr__() == 'test message'


# Generated at 2022-06-22 19:59:25.058726
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager

    display._verbosity = 4
    display.verbose = 4

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader)


# Generated at 2022-06-22 19:59:32.008933
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    try:
        raise InterpreterDiscoveryRequiredError(u'Failed to find interpreter', 'python', 'auto')
    except Exception as e:
        # Verify the value of exception e and e.message is equal to expected value
        assert e.message == u'Failed to find interpreter'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'
        # Verify the error message is equal to expected value
        assert str(e) == 'Failed to find interpreter'


# Generated at 2022-06-22 19:59:40.835633
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = 'Test message'

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode
        assert str(e) == message
        assert repr(e) == message
    else:
        assert False

# Generated at 2022-06-22 19:59:47.955938
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    from pytest import raises
    from ansible import errors
    exception = InterpreterDiscoveryRequiredError("My message", "python", "auto_legacy")

    assert(exception.message == "My message")
    assert(exception.interpreter_name == "python")
    assert(exception.discovery_mode == "auto_legacy")

    with raises(errors.AnsibleError):
        raise InterpreterDiscoveryRequiredError("My message", "python", "auto_legacy")

# Generated at 2022-06-22 19:59:54.373661
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = "auto_legacy"
    message = 'foo'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.interpreter_name == interpreter_name
    assert err.discovery_mode == discovery_mode
    assert err.message == message

    assert str(err) == message
    assert repr(err) == message


# Generated at 2022-06-22 19:59:58.617480
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = u'test message'
    interpreter_name = u'python'
    discovery_mode = u'default'
    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert obj.__str__() == message

# Generated at 2022-06-22 20:00:10.604691
# Unit test for function discover_interpreter
def test_discover_interpreter():
    discover_interpreter.__globals__['display'] = Display()
    discover_interpreter.__globals__['C'] = C
    discover_interpreter.__globals__['pkgutil'] = pkgutil
    task_vars = dict()

    interp_list = [u'/usr/bin/pytho', u'/usr/bin/python', u'/usr/bin/python2', u'/usr/bin/python2.4', u'/usr/bin/python2.7']

# Generated at 2022-06-22 20:00:23.187284
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # import this here as it imports discover_interpreter itself
    from ansible.module_utils.common.parameters import verify_interpreter

    # default Python interpreter for these tests (no discovery)
    assert verify_interpreter('python', '/usr/bin/python') == '/usr/bin/python'

    # test discovery failure
    test_task_vars = {
        'inventory_hostname': 'testhost',
        # required for the discovery to fail
        'ansible_connection': 'network_cli'
    }
    try:
        discover_interpreter(None, 'python', 'auto_silent', test_task_vars)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto_silent'

# Generated at 2022-06-22 20:00:28.776999
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    exception = InterpreterDiscoveryRequiredError('test message', 'test_interpreter', 'test_mode')

    assert to_text(exception) == 'test message'
    assert to_text(exception.interpreter_name) == 'test_interpreter'
    assert to_text(exception.discovery_mode) == 'test_mode'

# Generated at 2022-06-22 20:00:40.515596
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class MockAction(object):
        def __init__(self):
            self._low_level_execute_command = None
            self._connection = MockConnection()
            self._discovery_warnings = []

    class MockConnection(object):
        def __init__(self):
            self.has_pipelining = True

    class TestCase(object):
        def __init__(self, name, action, interpreter_name, discovery_mode, task_vars, expected_result):
            self.name = name
            self.action = action
            self.interpreter_name = interpreter_name
            self.discovery_mode = discovery_mode
            self.task_vars = task_vars
            self.expected_result = expected_result

    action = MockAction()

# Generated at 2022-06-22 20:00:50.032693
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''
    This function is used to collect the tests for the discover_interpreter function.
    The tests will be run if one executes the module directly.
    '''

    # Necessary imports, so that we can run the tests
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    # First we set up the ActionModule instance with dummy data
    action = ActionModule({}, {'_ansible_version': ansible_version, '_ansible_no_log': False, '_ansible_verbosity': 2,
                               'ANSIBLE_MODULE_ARGS': {'interpreter': 'python', 'discovery_mode': 'auto_legacy_silent'}},
                          'test-playbook')

    #

# Generated at 2022-06-22 20:00:57.161380
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_message = 'Python interpreter discovery required'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'

    interpreter_discovery_error = InterpreterDiscoveryRequiredError(error_message,
                                                                    interpreter_name,
                                                                    discovery_mode)

    assert interpreter_discovery_error.__str__() == error_message
    assert interpreter_discovery_error.interpreter_name == interpreter_name
    assert interpreter_discovery_error.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:01:03.169780
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex = InterpreterDiscoveryRequiredError("message", 'some interpreter', 'some discovery mode')
    assert ex.message == 'message'
    assert ex.interpreter_name == 'some interpreter'
    assert ex.discovery_mode == 'some discovery mode'
    assert str(ex) == 'message'
    assert repr(ex) == 'message'

# Generated at 2022-06-22 20:01:07.551798
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    idre = InterpreterDiscoveryRequiredError(message='test', interpreter_name='python', discovery_mode='auto_legacy_silent')

    assert repr(idre) == 'test'


# Generated at 2022-06-22 20:01:18.551626
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.action.normal
    class ActionModule(ansible.plugins.action.normal.ActionModule):
        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            if cmd.startswith('python'):
                self.results['stdout'] = '''PLATFORM
Linux
FOUND
/usr/bin/python
/usr/share/python
ENDFOUND'''
                self.results['rc'] = 0

# Generated at 2022-06-22 20:01:22.580525
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'manual_silent'
    exception = InterpreterDiscoveryRequiredError("a message", interpreter_name, discovery_mode)
    assert repr(exception) == 'a message'



# Generated at 2022-06-22 20:01:25.887689
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = "Interpreter Discovery Required"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.__repr__() == message

# Generated at 2022-06-22 20:01:37.203604
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Prerequisites
    # Center os
    # FUTURE: Is there a good way to do this without requiring an existing inventory?
    C.CONFIG_FILE = u"/etc/ansible/ansible.cfg"
    C.config = config = None
    try:
        from ansible.config.manager import ConfigManager
        from ansible.parsing import vault
        config = ConfigManager()
        config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP')
    except IOError as e:
        print(u"FATAL: error reading config file %s: %s" % (C.CONFIG_FILE, e))

# Generated at 2022-06-22 20:01:40.166437
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError(
        message='message', interpreter_name='interpreter_name', discovery_mode='discovery_mode')
    assert repr(exc) == 'message'

# Generated at 2022-06-22 20:01:43.525490
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError(
        message='message', interpreter_name='python', discovery_mode='auto')
    assert exception.message == 'message'
    assert exception.interpreter_name == 'python'
    assert exception.discovery_mode == 'auto'

# Generated at 2022-06-22 20:01:47.099364
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('This is an exception message', 'python', 'auto')
    assert str(e) == 'This is an exception message'
    assert repr(e) == 'This is an exception message'

# Generated at 2022-06-22 20:01:59.155719
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.module_common import _load_params
    from ansible.plugins.action import ActionBase
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    host = Host(name='localhost')
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file('tests/unit/inventory'))
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(
                module='command',
                args='/bin/true'
            ))
        ]
    )

# Generated at 2022-06-22 20:02:07.669031
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'Interpreter discovery is required for ansible'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    try:
        raise exception
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == message
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode
        assert e.__str__() == message
        assert e.__repr__() == message

# Generated at 2022-06-22 20:02:10.694307
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    class DummyInterpreterDiscoveryRequiredError(InterpreterDiscoveryRequiredError):
        def __init__(self):
            pass
    d = DummyInterpreterDiscoveryRequiredError()
    d.message = "A test message"

    result = d.__repr__()
    assert "A test message" == result, "Result should be \"A test message\""


# Generated at 2022-06-22 20:02:13.111682
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError("msg", "interpreter", "discovery")
    except InterpreterDiscoveryRequiredError as ex:
        assert to_native(ex) == to_native(ex.message)

# Generated at 2022-06-22 20:02:16.645286
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError(
        message='foo',
        discovery_mode='auto',
        interpreter_name='foo_interpreter')
    assert repr(e) == e.message

# Generated at 2022-06-22 20:02:22.925360
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error_msg = 'Interpreter discovery required'

    discovery_error = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    assert discovery_error.interpreter_name == 'python'
    assert discovery_error.discovery_mode == 'auto'
    assert str(discovery_error) == error_msg

# Generated at 2022-06-22 20:02:27.496525
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('Message', 'interpreter_name', 'discovery_mode')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'Message'
        assert e.interpreter_name == 'interpreter_name'
        assert e.discovery_mode == 'discovery_mode'

# Generated at 2022-06-22 20:02:29.866315
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert InterpreterDiscoveryRequiredError(message='foo', interpreter_name='bar', discovery_mode='baz').__repr__() == 'foo'

# Generated at 2022-06-22 20:02:31.050751
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    assert InterpreterDiscoveryRequiredError('message', 'py27', 'auto_silent')

# Generated at 2022-06-22 20:02:33.747143
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('msg', 'python', 'auto')
    assert repr(e) == 'msg'


# Generated at 2022-06-22 20:02:40.465378
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError(
            message='foo',
            interpreter_name='python',
            discovery_mode='foo')
    except Exception as exc:
        assert str(exc) != ''

if __name__ == '__main__':
    import pytest
    pytest.main([__file__, "-v", "-s"])

# Generated at 2022-06-22 20:02:43.685300
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('testmessage', 'testinterp', 'testmode')
    assert error.__repr__() == error.message
    assert error.__str__() == error.message

# Generated at 2022-06-22 20:02:46.558722
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "error_msg"
    obj = InterpreterDiscoveryRequiredError(msg, "python", "auto_legacy")
    assert str(obj) == msg

# Generated at 2022-06-22 20:02:58.137025
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import tempfile
    import shutil

    my_discovery_warnings = []

    class MockAction(object):
        _connection = None

        @staticmethod
        def _discovery_warnings():
            return my_discovery_warnings

        def _low_level_execute_command(self, cmd, **kwargs):
            display.vvvv(u"Mocked low_level_execute_command: cmd: {0} args: {1}".format(cmd, kwargs))
            return {'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'}


# Generated at 2022-06-22 20:03:04.334391
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'a message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    e = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert e.__str__() == msg
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:03:08.018441
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'example_message'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(error) == message
    assert str(error) == message

# Generated at 2022-06-22 20:03:10.538508
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError("message1", "interpreter_name1", "discovery_mode1")
    repr_string = repr(exc)
    assert repr_string == "message1"

# Generated at 2022-06-22 20:03:17.070754
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    test_msg = 'test message'

    try:
        raise InterpreterDiscoveryRequiredError(test_msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert test_msg == str(e)

# Generated at 2022-06-22 20:03:20.287042
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert(ex.__str__() == "message")
    assert(repr(ex) == "message")


# Generated at 2022-06-22 20:03:23.887748
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'require interpreter discovery'
    inter_name = 'python'
    discovery_mode = 'auto'
    e = InterpreterDiscoveryRequiredError(message, inter_name, discovery_mode)
    assert e.__str__() == 'require interpreter discovery'

# Generated at 2022-06-22 20:03:28.172104
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('test message', 'python', 'auto')
    repr = error.__repr__()
    assert repr == 'test message'



# Generated at 2022-06-22 20:03:31.256652
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(
        "message",
        interpreter_name="python",
        discovery_mode="auto"
    )
    assert error.__repr__() == "message"

# Generated at 2022-06-22 20:03:42.367605
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict(
        ansible_python_interpreter='python',
        ansible_python_interpreter_discovery_mode='auto'
    )


# Generated at 2022-06-22 20:03:45.167837
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError(message="message", interpreter_name="python", discovery_mode="auto")
    assert "message" == str(exc)


# Generated at 2022-06-22 20:03:48.323465
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError("msg", "interpreter_name", "discovery_mode")
    assert str(err) == "msg"

# Generated at 2022-06-22 20:03:50.210384
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(message="test_message", interpreter_name='test_interpreter', discovery_mode='test_discovery')
    assert to_text(error) == "test_message"

# Generated at 2022-06-22 20:03:56.620650
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_message = "Test message"
    error_interpreter_name = "Test interpreter name"
    error_discovery_mode = "Test discovery mode"
    error1 = InterpreterDiscoveryRequiredError(error_message, error_interpreter_name, error_discovery_mode)
    err = 'failed due to InterpreterDiscoveryRequiredError: Test message'
    assert err == str(error1)


# Generated at 2022-06-22 20:04:01.710055
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy_silent")
    assert err.message == "message"
    assert err.interpreter_name == "python"
    assert err.discovery_mode == "auto_legacy_silent"