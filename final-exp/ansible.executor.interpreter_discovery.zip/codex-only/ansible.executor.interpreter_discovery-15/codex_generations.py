

# Generated at 2022-06-22 19:54:05.282339
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Interpreter discovery required", "python", "auto_legacy_silent")
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == "python"
        assert ex.discovery_mode == "auto_legacy_silent"

# Generated at 2022-06-22 19:54:12.515031
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    test_message = 'message'
    exception = InterpreterDiscoveryRequiredError(test_message, interpreter_name, discovery_mode)
    assert exception.message == test_message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode
    assert repr(exception) == test_message
    assert str(exception) == test_message

# Generated at 2022-06-22 19:54:17.751765
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert str(e) == "message"
    assert repr(e) == "message"
    assert e.interpreter_name == 'python'
    assert e.discovery_mode == 'auto_legacy_silent'


# Generated at 2022-06-22 19:54:26.414649
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    # Test InterpreterDiscoveryRequiredError with default message
    exception = InterpreterDiscoveryRequiredError('test', 'python', 'auto')

    assert str(exception) == 'test', 'Failed to assert that str(exception) == message'

    # Test InterpreterDiscoveryRequiredError with custom message
    exception = InterpreterDiscoveryRequiredError('test', 'python', 'auto', message='test message')

    assert str(exception) == 'test message', 'Failed to assert that str(exception) == message'


# Generated at 2022-06-22 19:54:31.709435
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert str(ex) == 'message'
    assert repr(ex) == 'message'
    assert ex.interpreter_name == 'python'
    assert ex.discovery_mode == 'auto_legacy_silent'


# Generated at 2022-06-22 19:54:36.966868
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "expected_interpreter", "expected_discovery_mode")
    assert error.__str__() == "message"
    assert error.interpreter_name == "expected_interpreter"
    assert error.discovery_mode == "expected_discovery_mode"


# Generated at 2022-06-22 19:54:39.660238
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    instance = InterpreterDiscoveryRequiredError("message", "python", "silent")
    assert str(instance) == "message"
    assert repr(instance) == "message"



# Generated at 2022-06-22 19:54:42.202447
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('msg', 'interpreter_name', 'discovery_mode')
    print(err)



# Generated at 2022-06-22 19:54:49.716721
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(u'Python interpreter discovery required', interpreter_name='python', discovery_mode='auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'
        assert str(e) == 'Python interpreter discovery required'
        assert repr(e) == 'Python interpreter discovery required'


# Generated at 2022-06-22 19:54:55.545614
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(message="Testing python interpreter discovery", interpreter_name="python", discovery_mode="auto_legacy")
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == "Testing python interpreter discovery"
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_legacy"
        return True

# Generated at 2022-06-22 19:55:01.756462
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError(
            u'message', u'interpreter_name', u'discovery_mode')
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == u"message"
        assert ex.interpreter_name == u'interpreter_name'
        assert ex.discovery_mode == u'discovery_mode'
        assert str(ex) == u"message"
        assert repr(ex) == u"message"

# Generated at 2022-06-22 19:55:06.675273
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            message='Hello', interpreter_name='python', discovery_mode='auto')
    except Exception as e:
        assert e.message == 'Hello'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'

# Generated at 2022-06-22 19:55:09.533319
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    req_error = InterpreterDiscoveryRequiredError('foo', 'bar', 'baz')
    assert to_text(req_error) == u'foo'


# Generated at 2022-06-22 19:55:14.835683
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # noinspection PyTypeChecker
    exc = InterpreterDiscoveryRequiredError(
        'Interpreter discovery required for python',
        'python',
        'auto_legacy_silent',
    )

    assert exc.__str__() == exc.message
    # TODO: proper repr impl
    assert exc.__repr__() == exc.message

# Generated at 2022-06-22 19:55:27.197131
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test uname not Linux
    task_vars = {'ansible_facts': {'platform': 'MacOS'}}
    action, interpreter_name, discovery_mode, task_vars = None, 'python', 'auto', task_vars
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        raise Exception('')
    except NotImplementedError:
        pass

    # Test non-Linux uname and missing bootstrap
    task_vars = {'ansible_facts': {'platform': 'MacOS'}}
    action, interpreter_name, discovery_mode, task_vars = None, 'python', 'auto', task_vars

# Generated at 2022-06-22 19:55:37.965650
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import sys
    import os.path
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_stdout():
        sys.stdout, old_stdout = StringIO(), sys.stdout
        try:
            yield sys.stdout
        finally:
            sys.stdout = old_stdout

    class TestModuleUtilsDiscovery(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.current_dir = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-22 19:55:40.656462
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert str(error) == "message"
    assert repr(error) == "message"

# Generated at 2022-06-22 19:55:44.309164
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
  interpreter_name = 'python'
  discovery_mode = 'auto_legacy_silent'
  message = 'unhandled error'
  e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
  assert e.__repr__() == message

# Generated at 2022-06-22 19:55:56.016574
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_action = TestAction()
    task_vars = {}
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto_legacy_silent'

    # This test assumes that there are some python interpreters in /usr/bin/
    # which is present in all Linux distributions and BSDs.
    #
    # The test should not fail for other python interpreters as long as there
    # are some of them in /usr/bin/
    distro, version = _get_linux_distro({'platform_dist_result': [], 'osrelease_content': ''})
    assert distro == u'', 'unable to get Linux distribution/version info'

# Generated at 2022-06-22 19:55:59.887779
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # perform test
    exception = InterpreterDiscoveryRequiredError("This is a test message", "python", "auto")
    # check interpreter name
    assert exception.interpreter_name == "python"
    # check discovery mode
    assert exception.discovery_mode == "auto"

# Generated at 2022-06-22 19:56:03.722250
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'magic string'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    try:
        exception.__str__()
    except Exception:
        assert False



# Generated at 2022-06-22 19:56:08.434868
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('foo', 'bar', 'baz')
    assert 'foo' == e.message
    assert 'bar' == e.interpreter_name
    assert 'baz' == e.discovery_mode
    assert 'foo' == e.__repr__()
    assert 'foo' == e.__str__()

# Generated at 2022-06-22 19:56:11.652840
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("error message", "python", "auto")
    assert str(error) == "error message"
    error = InterpreterDiscoveryRequiredError("error message", "python", "auto")
    assert str(error) == "error message"

# Generated at 2022-06-22 19:56:15.636804
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('foo', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'

# For use in a unit test

# Generated at 2022-06-22 19:56:21.205485
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'Interpreter discovery required'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert error.__str__() == msg


# Generated at 2022-06-22 19:56:30.066167
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'legacy'
    expected_error_msg = ("Interpreter discovery is required, but not supported for interpreter '{0}' and discovery mode '{1}'".format
                          (interpreter_name, discovery_mode))
    try:
        raise InterpreterDiscoveryRequiredError(expected_error_msg, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == expected_error_msg
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode



# Generated at 2022-06-22 19:56:40.304284
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import _version_fuzzy_match

    assert _version_fuzzy_match('1.1.1', {'1.1.0': u'/usr/bin/python2.7'}) == u'/usr/bin/python2.7'
    assert _version_fuzzy_match('1.1.1', {'1.0.0': u'/usr/bin/python2.7'}) == u'/usr/bin/python2.7'
    assert _version_fuzzy_match('1.1.1', {'1.2.0': u'/usr/bin/python2.7'}) is None


# Generated at 2022-06-22 19:56:43.579071
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required for python'
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except Exception as e:
        assert str(e) == message
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:56:53.309388
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    for message in [None, '', 'message']:
        for interpreter_name in [None, '', 'python', 'python3']:
            for discovery_mode in [None, '', 'auto', 'auto_legacy', 'auto_legacy_silent']:
                error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

                assert error.message == message
                assert error.interpreter_name == interpreter_name
                assert error.discovery_mode == discovery_mode

                assert str(error) == message


# Generated at 2022-06-22 19:56:55.475622
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError('msg', 'py', 'auto')
    assert str(obj) == 'msg'


# Generated at 2022-06-22 19:56:58.471107
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    err = InterpreterDiscoveryRequiredError("test", "python", "modern")

    expected = "test"
    actual = err.__str__()
    assert actual == expected, '__str__ method of InterpreterDiscoveryRequiredError returned %s instead of %s' \
        % (actual, expected)


# Generated at 2022-06-22 19:57:05.501615
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "The test message"
    interpreter_name = "python3"
    discovery_mode = "auto_legacy_non_silent"
    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert(err.__repr__() == "The test message")
    assert(err.__repr__() == err.__str__())

# Generated at 2022-06-22 19:57:07.792568
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = 'Please enable interpreter discovery, or explicitly specify an interpreter'
    obj = InterpreterDiscoveryRequiredError(error_message, 'python', 'auto')
    assert obj.__str__() == error_message

# Generated at 2022-06-22 19:57:13.538626
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    discovery_mode = 'auto_legacy_silent'
    interpreter_name = 'python'
    message = 'Failed to discover the python interpreter.'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.__repr__() == e.message



# Generated at 2022-06-22 19:57:19.919963
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as error:
        assert 'message' == str(error)
        assert 'python' == error.interpreter_name
        assert 'auto' == error.discovery_mode



# Generated at 2022-06-22 19:57:20.767027
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    e = InterpreterDiscoveryRequiredError('message', 'python', 'auto')

    assert repr(e) == 'message'

# Generated at 2022-06-22 19:57:24.888531
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_msg = "Error Message"
    interpreter_name = 'python'
    discovery_mode = 'auto'
    idr = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    assert repr(idr) == idr.message

# Generated at 2022-06-22 19:57:36.732347
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_message = 'test message'
    test_interpreter_name = 'test_interpreter_name'
    test_discovery_mode = 'test_discovery_mode'
    test_valid_exception = InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)
    assert test_valid_exception.message == test_message
    assert test_valid_exception.interpreter_name == test_interpreter_name
    assert test_valid_exception.discovery_mode == test_discovery_mode
    assert str(test_valid_exception) == test_message
    assert repr(test_valid_exception) == test_message

# Generated at 2022-06-22 19:57:44.491493
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Test with no args
    testObj = InterpreterDiscoveryRequiredError('test_message', 'test_interpreter_name', 'test_discovery_mode')
    assert testObj.__repr__() == "test_message"

    # Test with a message
    testObj = InterpreterDiscoveryRequiredError('test_message', 'test_interpreter_name', 'test_discovery_mode')
    assert testObj.__repr__() == "test_message"


# Generated at 2022-06-22 19:57:53.300352
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.utils.hashing import md5s, checksum_s

    def update_host_var(host_vars, host, key, value):
        if host_vars:
            host_vars[md5s(host)] = host_vars.get(md5s(host), {})
            host_vars[md5s(host)][key] = value

    from ansible.plugins.action import ActionBase
    from ansible.module_utils._text import to_bytes, to_text
    import tempfile
    import os

    class MyAction(ActionBase):

        def _run(self, tmp=None, task_vars=None):
            return to_text(self._low_level_execute_command(tmp, sudoable=False)[0], errors='surrogate_or_strict')



# Generated at 2022-06-22 19:58:04.463085
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader

    display.verbosity = 4

    class MockActionModule(object):
        def __init__(self, name, interpreter=None):
            self._name = name
            self._interpreter = interpreter


# Generated at 2022-06-22 19:58:09.047142
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python')
    except Exception as e:
        assert e.message == 'test message'
        assert e.interpreter_name == 'python'
        assert e.interpreter_name == 'python'


# Generated at 2022-06-22 19:58:16.035262
# Unit test for function discover_interpreter
def test_discover_interpreter():
    display = Display()
    display.verbosity = 2
    host = 'localhost'
    task_vars = dict()

    # verify that no error occurs when discovery via os-release is required
    res = discover_interpreter(None, 'python', 'auto', task_vars)
    assert res == u'/usr/bin/python'

    # verify that plain auto works
    task_vars[u'ansible_python_interpreter'] = u'/usr/bin/python'
    res = discover_interpreter(None, 'python', 'auto', task_vars)
    assert res == u'/usr/bin/python'

    # verify that auto_legacy fails for /usr/bin/python
    task_vars[u'ansible_python_interpreter'] = u'/usr/bin/python'

# Generated at 2022-06-22 19:58:24.757353
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python2', 'auto_legacy', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python2', 'auto', {}) == '/usr/bin/python'

    assert discover_interpreter(None, 'python3', 'auto_legacy', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python3', 'auto', {}) == '/usr/bin/python'

# Generated at 2022-06-22 19:58:36.721433
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Ansible version compat
    try:
        from ansible.compat.tests import unittest
    except ImportError:
        import unittest
    from ansible.compat.tests.mock import MagicMock
    from ansible.compat.tests.mock import patch

    class TestDiscoveryMode(unittest.TestCase):

        def setUp(self):
            self._action = MagicMock()

        def test_standard(self):
            task_vars = dict(
                ansible_connection='local',
                ansible_python_interpreter='python',
            )
            self._action._low_level_execute_command = MagicMock(return_value={'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'})
           

# Generated at 2022-06-22 19:58:44.919036
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins import action
    from ansible.plugins.action import ActionModule

# Generated at 2022-06-22 19:58:50.449461
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # arrange
    msg = 'Invalid interpreter mode'
    interpreter_name = 'python'
    discovery_mode = 'discover_silent'
    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    # act
    res = err.__repr__()

    # assert
    assert res == msg


# Generated at 2022-06-22 19:58:52.282897
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "A error was produced"
    interpreter_name = "python"
    discovery_mode = "unavailable"
    exc = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert exc.__repr__() == msg


# Generated at 2022-06-22 19:58:55.842311
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('error message', 'python', 'auto')
    assert 'error message' == str(error)

# Generated at 2022-06-22 19:59:04.251609
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "Something went horribly wrong!"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    obj = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert obj.__dict__ == {"message": "Something went horribly wrong!", "interpreter_name": "python", "discovery_mode": "auto_legacy_silent"}
    assert obj.message == "Something went horribly wrong!"
    assert obj.interpreter_name == "python"
    assert obj.discovery_mode == "auto_legacy_silent"
    assert str(obj) == "Something went horribly wrong!"
    assert repr(obj) == "Something went horribly wrong!"

# Generated at 2022-06-22 19:59:04.872847
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-22 19:59:10.138818
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    instance = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='auto_legacy_silent')
    assert str(instance) == 'message'
    assert repr(instance) == 'message'

# Generated at 2022-06-22 19:59:16.324137
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert 'message' == str(e)
    assert 'interpreter_name' == e.interpreter_name
    assert 'discovery_mode' == e.discovery_mode

# Generated at 2022-06-22 19:59:21.825078
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Discovery failed for python interpreter"
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.__repr__() == message

# Generated at 2022-06-22 19:59:32.052906
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_results = []

    # test basic exception handling for unknown interpreters
    try:
        discover_interpreter('python', 'echo', 'legacy')
        test_results.append('fail')
    except ValueError:
        test_results.append('ok')

    # test expected output from platform.dist() and os-release parsing
    try:
        if discover_interpreter('python', 'python', 'legacy', {})[0] != '/usr/bin/python':
            test_results.append('fail')
        else:
            test_results.append('ok')
    except InterpreterDiscoveryRequiredError:
        test_results.append('ok')
        display.vvv(msg=u"Test platform is not a supported distro")

    if test_results == ['ok', 'ok']:
        display.vvv

# Generated at 2022-06-22 19:59:38.296530
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from ansible.module_utils._text import to_bytes
    interpreter_name = "python"
    discovery_mode = "none"
    message = u"to_bytes error"
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert to_bytes(message) in to_bytes(err)

# Generated at 2022-06-22 19:59:43.516266
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Unit test for method ``__repr__`` of class
    ``ansible.executor.discovery.InterpreterDiscoveryRequiredError``
    """

    # given
    message = 'Error'
    interpreter_name = 'python'
    discovery_mode = 'auto'

    # when
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # then
    assert error.message == message


# Generated at 2022-06-22 19:59:46.035377
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('error', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as ex:
        pass

# Generated at 2022-06-22 19:59:53.717025
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = u'python'
    discovery_mode = u'auto_legacy_silent'
    message = u'Interpreter discovery required for {0} interpreter discovery on host somehost'.format(interpreter_name)
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == u'auto_legacy_silent'
    assert err.message == message

# Generated at 2022-06-22 19:59:57.721042
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto'

# Generated at 2022-06-22 20:00:01.342557
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    discovery_mode = 'auto_legacy_silent'
    __repr__ = InterpreterDiscoveryRequiredError('', 'python', discovery_mode)
    repr = repr(__repr__)
    assert repr == ''


# Generated at 2022-06-22 20:00:07.996651
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    discovery_mode = "auto_legacy_silent"
    err = InterpreterDiscoveryRequiredError("test message", "test_interpreter", discovery_mode)
    assert err.message == "test message"
    assert err.interpreter_name == "test_interpreter"
    assert err.discovery_mode == discovery_mode
    assert str(err) == err.message


# Generated at 2022-06-22 20:00:17.386988
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    # TODO: better mock test that actually goes through the discovery scripts?
    c = PlayContext()
    c._connection = MockConnection()
    c.connection = 'mock'

# Generated at 2022-06-22 20:00:19.694089
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    error.__str__()

# Generated at 2022-06-22 20:00:28.882375
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('test_InterpreterDiscoveryRequiredError exception message',
                                                'python', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == 'test_InterpreterDiscoveryRequiredError exception message'
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto_legacy_silent'
        assert str(ex) == 'test_InterpreterDiscoveryRequiredError exception message'
        assert repr(ex) == 'test_InterpreterDiscoveryRequiredError exception message'

# Generated at 2022-06-22 20:00:31.558309
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'

# Generated at 2022-06-22 20:00:42.268709
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert _version_fuzzy_match('1.1', {'1': 'a', '1.1': 'b', '2': 'c', '2.1': 'd'}) == 'b'
    assert _version_fuzzy_match('1.2', {'1': 'a', '1.1': 'b', '2': 'c', '2.1': 'd'}) == 'c'
    assert _version_fuzzy_match('1.3', {'1': 'a', '1.1': 'b', '2': 'c', '2.1': 'd'}) == 'c'
    assert _version_fuzzy_match('2', {'1': 'a', '1.1': 'b', '2': 'c', '2.1': 'd'}) == 'c'
   

# Generated at 2022-06-22 20:00:51.091285
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor import task_executor
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    # Build the required objects for testing

    # Host
    host = Host(name='testhost')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python')

    # Group
    group = Group(name='testgroup')
    group.add_host(host)

    # Inventory
    inventory = Inventory()
    inventory.add_group(group)

    # PlayContext
    play_context = PlayContext()

    # Play

# Generated at 2022-06-22 20:00:57.011139
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    msg = 'Interpreter discovery required for {0} interpreter, but host is not in localhost or hostvars (discovery mode: {1})'.format(interpreter_name, discovery_mode)
    ex = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert str(ex) == msg


# Generated at 2022-06-22 20:01:00.284649
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('message', 'interpreter', 'discovery_mode')
    assert str(e) == 'message'



# Generated at 2022-06-22 20:01:04.276133
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class actionwrapper(object):
        def __init__(self):
            self._connection = self
            self._discovery_warnings = []
            self._is_pipelined = False

        def has_pipelining(self):
            return self._is_pipelined

        def _low_level_execute_command(self, command, sudoable=True, in_data=None):
            self.test_command = command
            return self.test_res

        def warn(self, msg):
            self._discovery_warnings.append(msg)

    class connectionwrapper(object):
        def __init__(self, is_pipelined=True):
            self._is_pipelined = is_pipelined
            self.test_result = {'stderr': u''}


# Generated at 2022-06-22 20:01:17.053329
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # mock up a module result and task vars
    module_return = dict(stdout=b'PLATFORM\nLinux', rc=0)
    module_return['stdout'] += b'\nFOUND\n/usr/bin/python\n/usr/bin/python2\n/usr/bin/python3\nENDFOUND'
    module_return['stdout'] += b'\n'
    module_return['stdout_lines'] = module_return['stdout'].splitlines()

    # mimics distro.py result when platform_dist is not implemented by Python
    distro_py_version = LooseVersion(platform.dist()[1])
    if distro_py_version >= LooseVersion('2.7') and distro_py_version < LooseVersion('3.0'):
        test_

# Generated at 2022-06-22 20:01:24.407504
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery is required for "{0}" using "{1}" discovery mode'.format(interpreter_name,
                                                                                              discovery_mode)
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.message == message
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode
    assert str(ex) == ex.message

# Generated at 2022-06-22 20:01:27.192712
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    i = InterpreterDiscoveryRequiredError('message', 'python', 'discover')

    assert i.__str__() == 'message'

# Generated at 2022-06-22 20:01:30.106908
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    i = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert i.__str__() == "message"

# Generated at 2022-06-22 20:01:33.920752
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex = InterpreterDiscoveryRequiredError("message", "interpreter", "discovery_mode")
    assert ex.interpreter_name == "interpreter"
    assert ex.discovery_mode == "discovery_mode"

# Generated at 2022-06-22 20:01:43.605905
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-22 20:01:46.462268
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
  exc = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode');
  assert repr(exc) == 'message'

# Generated at 2022-06-22 20:01:58.390505
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    # Valid case
    try:
        raise InterpreterDiscoveryRequiredError("message", interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ide:
        assert ide.interpreter_name == interpreter_name
        assert ide.discovery_mode == discovery_mode
        assert ide.message == "message"
        assert ide.__str__() == ide.message
        assert ide.__repr__() == ide.message

    # Invalid cases

# Generated at 2022-06-22 20:02:02.560470
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter Discovery Required'
    idre = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert message == idre.message
    assert interpreter_name == idre.interpreter_name
    assert discovery_mode == idre.discovery_mode
    assert message == idre.__str__()
    assert message == idre.__repr__()



# Generated at 2022-06-22 20:02:08.539399
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(
        'test message', 'test interpreter', 'test discovery'
    )

    assert error.message == 'test message'
    assert error.interpreter_name == 'test interpreter'
    assert error.discovery_mode == 'test discovery'

    assert error.__str__() == 'test message'

    assert error.__repr__() == 'test message'

# Generated at 2022-06-22 20:02:10.540534
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert 'message' == str(error)

# Generated at 2022-06-22 20:02:17.997681
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.vars.manager import VariableManager
    from ansible.utils import context_objects as co
    from ansible.plugins.action import ActionBase
    from ansible.utils.sentinel import Sentinel
    from ansible.inventory.manager import InventoryManager

    test_variables = {u'inventory_hostname': u'test_host',
                      u'inventory_hostname_short': u'test_host'}

    # this is obviously ridiculous, but it's the most convenient way to get a basic un-runnable connection object
    # that can be populated with the result we need
    test_connection = Sentinel()
    test_connection.has_pipelining = True
    test_connection.become = False
    test_connection.become_method = u'sudo'

# Generated at 2022-06-22 20:02:22.667232
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc_msg = "Test Exception Message"
    exc = InterpreterDiscoveryRequiredError(exc_msg, "python", "auto")

    assert exc.interpreter_name == 'python'
    assert exc.discovery_mode == 'auto'
    assert exc.__str__() == exc_msg
    assert exc.__repr__() == exc_msg

# Generated at 2022-06-22 20:02:26.537738
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'


# Generated at 2022-06-22 20:02:28.341991
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert "message" == str(exc)

# Generated at 2022-06-22 20:02:30.297325
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    raise InterpreterDiscoveryRequiredError("Test Message", "PYTHON", "AUTO")

# Generated at 2022-06-22 20:02:33.798449
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    c = InterpreterDiscoveryRequiredError('My Message', 'python', 'auto')
    assert str(c) == "My Message"
    assert repr(c) == "My Message"

# Generated at 2022-06-22 20:02:36.437634
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert str(exc) == exc.message

# Generated at 2022-06-22 20:02:42.549195
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(message='Test', interpreter_name='python', discovery_mode='auto')
    except InterpreterDiscoveryRequiredError as e:
        assert to_native(e) == 'Test'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'


# Generated at 2022-06-22 20:02:46.973018
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert error.message == "message"
    assert error.interpreter_name == "interpreter_name"
    assert error.discovery_mode == "discovery_mode"


# Generated at 2022-06-22 20:02:58.533611
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    from ansible.plugins.action import ActionBase
    from ansible.parsing.vault import VaultLib

    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            del tmp  # tmp no longer has any effect
            vault_pass = task_vars.get('ansible_vault_password', None)
            if not vault_pass:
                vault_pass = basic._load_vault_password(filename=C.DEFAULT_VAULT_PASSWORD_FILE,
                                                        vault_id=None, loader=None)

            vault = VaultLib(vault_pass)


# Generated at 2022-06-22 20:03:02.775780
# Unit test for function discover_interpreter
def test_discover_interpreter():
    response = discover_interpreter('action', 'python', 'auto', {'inventory_hostname': 'test.example.org'})
    assert response
    assert response.startswith('/usr/bin/python')



# Generated at 2022-06-22 20:03:07.608369
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Missing interpreter discovery'
    error = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    repr_msg = repr(error)
    assert repr_msg == 'Missing interpreter discovery'

# Generated at 2022-06-22 20:03:12.289275
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "Hello, world"
    for interpreter in ("python", "python3"):
        for discovery_mode in ("auto_legacy_silent", "auto_legacy", "auto_silent", "auto"):
            error = InterpreterDiscoveryRequiredError(message=msg, interpreter_name=interpreter, discovery_mode=discovery_mode)
            assert msg == error.__str__()
            assert msg == error.__repr__()


# Generated at 2022-06-22 20:03:15.473873
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("test_discover_interpreter called")


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-22 20:03:18.394886
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert repr(InterpreterDiscoveryRequiredError("message", "python", "auto")) == "message"

# Generated at 2022-06-22 20:03:26.530527
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    """
    Sanity test which will execute all methods in class InterpreterDiscoveryRequiredError.
    """

    # Create an instance of the class InterpreterDiscoveryRequiredError
    test_obj = InterpreterDiscoveryRequiredError("Testing error message", "python", "auto_legacy")

    # Test the __init__ method to make sure it correctly sets the message
    assert test_obj.message == "Testing error message"

    # Test the __str__ method to make sure it correctly returns the message
    assert str(test_obj) == "Testing error message"

    # Test the __repr__ method to make sure it correctly returns the message
    assert repr(test_obj) == "Testing error message"

# Generated at 2022-06-22 20:03:30.381734
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "never"
    message = "Interpreter discovery is not enabled"

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(error) == message

# Generated at 2022-06-22 20:03:41.275186
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host_vars = {'inventory_hostname': 'localhost',
                 'ansible_python_interpreter': '/usr/bin/python'}

    target = {
        '_ansible_no_log': False,
        '_ansible_verbosity': 3,
        '_ansible_version': {'full': '2.7.4', 'version': '2.7.4', 'major': 2, 'minor': 7, 'revision': 4, 'string': '2.7.4'},
        '_ansible_syslog_facility': 'LOG_USER'}

    # Place the interpreter discovery script in the same directory as the test
    # script. It is not possible to place this script in any other location.
    # This works as long as there is always a __file__ attribute for any
    # python script

# Generated at 2022-06-22 20:03:43.638323
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    assert 'Python' == str(InterpreterDiscoveryRequiredError('Python', 'Python', 'a'))

# Generated at 2022-06-22 20:03:49.400294
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Setup test
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Something is wrong'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # Exercise
    result = repr(exception)

    # Verify
    assert result == message


# Generated at 2022-06-22 20:03:52.480606
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("An error message", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto"
    e = InterpreterDiscoveryRequiredError("An error message", "python", "auto")
    assert e.__str__() == "An error message"
    assert e.__repr__() == "An error message"

# Generated at 2022-06-22 20:03:56.249632
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(message="test", interpreter_name="python", discovery_mode="auto")
    assert error.message == "test"
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"

# Generated at 2022-06-22 20:04:01.284633
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object
    action.transport = 'local'
    action._connection = object
    action._connection.has_pipelining = True
    action._low_level_execute_command = lambda cmd, sudoable, in_data: {'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python2.7\n/usr/bin/python\nENDFOUND'}
    task_vars = dict()
    result = discover_interpreter(action, interpreter_name='python', discovery_mode='some_mode', task_vars=task_vars)
    print(result)
    assert result == u'/usr/bin/python'