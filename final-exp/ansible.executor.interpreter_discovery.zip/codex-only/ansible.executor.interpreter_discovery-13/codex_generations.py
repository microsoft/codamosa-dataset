

# Generated at 2022-06-22 19:54:08.293084
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Setup
    discovery_mode = 'auto'
    interpreter_name = 'python'
    task_vars = 'variables'
    # No InterpreterDiscoveryRequiredError
    try:
        res = discover_interpreter(None, interpreter_name, discovery_mode, task_vars)
    except InterpreterDiscoveryRequiredError as e:
        assert False, 'Unexpected InterpreterDiscoveryRequiredError: {0}'.format(to_native(e))
    # Test with None as return
    if res is None:
        assert True
    else:
        assert False, 'Unexpected output: {0}'.format(to_native(res))

# Generated at 2022-06-22 19:54:10.875598
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Return the string
    assert InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode').__str__() == 'message'

# Generated at 2022-06-22 19:54:17.392593
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    def throw_it():
        raise InterpreterDiscoveryRequiredError("hello", "python", "auto")

    try:
        throw_it()
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == "python"
        assert ex.discovery_mode == "auto"
        assert str(ex) == "hello"

# Generated at 2022-06-22 19:54:28.965152
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    import yaml
    from ansible.plugins.action import ActionBase
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultLib

    INTERPRETER_PYTHON_DISTRO_MAP = """\
---
amazon:
  2: /usr/bin/python2.7
  3: /usr/local/bin/python3
centos:
  5: /usr/bin/python2.4
  6: /usr/bin/python2.6
redhat:
  6: /usr/bin/python2.6
  7: /usr/bin/python2.7
  8: /usr/local/bin/python3
"""

    INTERPRETER_PYTHON_F

# Generated at 2022-06-22 19:54:33.201699
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_ex = InterpreterDiscoveryRequiredError('Testing InterpreterDiscoveryRequiredError', 'python', 'auto')
    assert test_ex.interpreter_name == 'python'
    assert test_ex.discovery_mode == 'auto'

# Generated at 2022-06-22 19:54:38.565527
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_msg = "Error Message"
    interpreter_name = "Python"
    discovery_mode = "only"
    exception = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    assert exception.message == "{0} - interpreter {1} discovery mode: {2} ".format(error_msg, interpreter_name, discovery_mode)
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode



# Generated at 2022-06-22 19:54:44.571429
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "This is a message"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert interpreter_name == e.interpreter_name
    assert discovery_mode == e.discovery_mode
    assert message == str(e)

# Generated at 2022-06-22 19:54:49.906481
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:54:56.536319
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    interpreter_name = 'test_interpreter_name'
    discovery_mode = 'test_discovery_mode'

    message = 'test_message'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert getattr(exception, 'interpreter_name') is not None
    assert getattr(exception, 'discovery_mode') is not None
    assert getattr(exception, 'message') is not None

# Generated at 2022-06-22 19:55:08.492447
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    interpreter_name = "python"
    discovery_mode = "auto"

    # Test that exception is triggered when no message is given
    try:
        raise InterpreterDiscoveryRequiredError(message=None,
                                                interpreter_name=interpreter_name,
                                                discovery_mode=discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert (e.interpreter_name == interpreter_name)
        assert (e.discovery_mode == discovery_mode)
        assert (str(e) == "None")

    message = "Some message"

    # Test that exception is triggered when a message is given

# Generated at 2022-06-22 19:55:20.644561
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test for discover_interpreter - parse platform info and return exact match
    # if possible, and nearest previous version otherwise
    # If no match is found, return the oldest version in the map
    # The platform_python_map is platform-specific, this is a simple version

    # Test exact match
    task_vars = {'config': {}}
    action = object
    task_vars['config']['test'] = {'INTERPRETER_PYTHON_DISTRO_MAP':
                                       {'redhat': {'6.0': '/usr/bin/python3'},
                                        'centos': {'6.0': '/usr/bin/python3'}},
                                   'INTERPRETER_PYTHON_FALLBACK': ['/usr/bin/python3']}

    action._discovery_warn

# Generated at 2022-06-22 19:55:26.767147
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_msg = "error_msg"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    obj = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    assert obj.interpreter_name == interpreter_name
    assert obj.discovery_mode == discovery_mode


# Generated at 2022-06-22 19:55:31.725750
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('test_message', 'python', 'auto')

    assert err.message == 'test_message'
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'auto'


# Generated at 2022-06-22 19:55:41.295174
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import Distribution as distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution as linux_distribution

    from ansible.module_utils.basic import AnsibleModule

    # Failed to fetch platform info
    class FakeModuleMissingPlatformInfo(AnsibleModule):
        def _exec_command(self, *args, **kwargs):
            return {'stdout': '',
                    'stderr': '',
                    'rc': 0,
                    'start': '',
                    'end': '',
                    'delta': '',
                    'cmd': ''}


# Generated at 2022-06-22 19:55:47.066486
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exceptionMessage = "Exception message"
    exceptionInterpreterName = "python"
    exceptionDiscoveryMode = "auto"
    exception = InterpreterDiscoveryRequiredError(exceptionMessage, exceptionInterpreterName, exceptionDiscoveryMode)
    strException = str(exception)
    assert exceptionMessage in strException
    assert exceptionInterpreterName in strException
    assert exceptionDiscoveryMode in strException

# Generated at 2022-06-22 19:55:53.813065
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_message = "Test message"
    test_interpreter_name = "python3"
    test_discovery_mode = "auto"
    interpreter_discovery_required_error = \
        InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)
    assert interpreter_discovery_required_error.__str__() == test_message

# Generated at 2022-06-22 19:55:58.749288
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    obj = InterpreterDiscoveryRequiredError('test_message', 'test_interpreter_name', 'test_discovery_mode')
    assert obj.__repr__() == 'test_message'


# Unit tests for method __str__ of class InterpreterDiscoveryRequiredError

# Generated at 2022-06-22 19:56:09.702543
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:56:11.833589
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    assert (InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode").__str__()) == ("message")

# Generated at 2022-06-22 19:56:16.904220
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'Test InterpreterDiscoveryRequiredError Exception'
    interpreter_name = 'Python'
    discovery_mode = 'auto'

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert message == exception.message
    assert interpreter_name == exception.interpreter_name
    assert discovery_mode == exception.discovery_mode

# Generated at 2022-06-22 19:56:23.417427
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("msg", "python", "auto_legacy_auto_silent")
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto_legacy_auto_silent"
    assert "msg" in str(error)
    assert "msg" in repr(error)

# Generated at 2022-06-22 19:56:26.204404
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        "error_message",
        "python",
        "auto_silent"
    )

    assert error.__str__() == "error_message"



# Generated at 2022-06-22 19:56:38.066251
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:56:47.578685
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:56:51.003797
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('test_message', 'python3', 'auto')
    assert err.__repr__() == 'test_message'



# Generated at 2022-06-22 19:57:02.428275
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:57:13.145611
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class FakeAction(object):
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(low, cmd, sudoable=True, in_data=None):
            if low == 'command -v python':
                # no-op bootstrap, returns 'python' and
                # /usr/bin/python as the first python interpreter
                return dict(stdout=u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND')
            elif low == '/usr/bin/python':
                # the platform script
                return dict(stdout=json.dumps({'osrelease_content': 'id=rhel\nversion_id=7.6'}))

# Generated at 2022-06-22 19:57:22.330201
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error1 = InterpreterDiscoveryRequiredError('Error', 'python', 'auto')
    assert error1.message == 'Error'
    assert error1.interpreter_name == 'python'
    assert error1.discovery_mode == 'auto'
    error2 = InterpreterDiscoveryRequiredError('Error2', 'python2', 'auto')
    assert error2.message == 'Error2'
    assert error2.interpreter_name == 'python2'
    assert error2.discovery_mode == 'auto'

# Generated at 2022-06-22 19:57:25.074341
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg='Test message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    assert InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

# Generated at 2022-06-22 19:57:37.797071
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    task_vars['inventory_hostname'] = 'localhost'
    action = dict()
    action['_connection'] = dict(has_pipelining=True)
    action['_discovery_warnings'] = list()
    action['_low_level_execute_command'] = dict()
    # test for linux platform
    action['_low_level_execute_command']['stdout'] = 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'
    action['_low_level_execute_command']['pid'] = 3
    action['_low_level_execute_command']['stdin'] = ''
    action['_low_level_execute_command']['stderr'] = ''
    # Fake platform_dist_result


# Generated at 2022-06-22 19:57:49.295868
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    from ansible.module_utils.common.removed import removed_module

    bin_dir = os.path.join(tempfile.mkdtemp(), 'bin')
    python_bin = os.path.join(bin_dir, 'python')
    os.makedirs(bin_dir)

    # Create a fake python interpreter
    with open(python_bin, 'w') as out:
        out.write("""#!/bin/sh
echo "sys.version_info(major=2, minor=7, micro=1, releaselevel='final', serial=0)";
echo "sys.platform='linux2'";
""")
    os.chmod(python_bin, 0o755)

    # Simple test with an explicit interpreter, with discovery
    action = removed_module

# Generated at 2022-06-22 19:57:51.608652
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    value = 'Value'
    message = 'Test'
    result = InterpreterDiscoveryRequiredError(message, value, value).__str__()
    assert result == message


# Generated at 2022-06-22 19:58:00.438049
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'Interpreter discovery is required but is not supported for the requested interpreter and ' \
              'discovery mode [[\'auto_silent\', \'auto_legacy_silent\']]'
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'

    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.message == message
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:58:12.919439
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:58:23.709489
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    str_py_path = '/usr/bin/python'
    interpolation_text = 'Please set ansible_python_interpreter or use ansible.builtin.raw'
    discovery_mode = 'auto'
    err = InterpreterDiscoveryRequiredError(interpolation_text, str_py_path, discovery_mode)

    assert err.message == interpolation_text
    assert err.interpreter_name == str_py_path
    assert err.discovery_mode == discovery_mode

    assert err.__str__() == interpolation_text
    assert err.__repr__() == interpolation_text



# Generated at 2022-06-22 19:58:34.183172
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    test_cases = [
        (
            "EXAMPLE STRING 1",
            "EXAMPLE STRING 1"
        ),
        (
            "EXAMPLE STRING 2",
            "EXAMPLE STRING 2"
        ),
        (
            "EXAMPLE STRING 3",
            "EXAMPLE STRING 3"
        ),
    ]

    for message, expected_result in test_cases:
        try:
            raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
        except InterpreterDiscoveryRequiredError as ex:
            assert ex.__str__() == expected_result

# Generated at 2022-06-22 19:58:42.264980
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = "Interpreter discovery required for {0} but {1} discovery is not supported.".format(interpreter_name, discovery_mode)

    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.__str__() == message


# Generated at 2022-06-22 19:58:45.913323
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("error", "python", "auto")

    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

# Generated at 2022-06-22 19:58:49.864735
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert error.message == 'message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

# Generated at 2022-06-22 19:59:00.399364
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # test case 1
    def_error = InterpreterDiscoveryRequiredError('some error message', 'python', 'auto')
    actual_return = def_error.__str__()
    expected_return = 'some error message'
    assert actual_return == expected_return

    # test case 2
    def_error = InterpreterDiscoveryRequiredError('some error message \n with newline', 'python', 'auto')
    actual_return = def_error.__str__()
    expected_return = 'some error message \n with newline'
    assert actual_return == expected_return

    # test case 3
    def_error = InterpreterDiscoveryRequiredError('some error message', 'python3', 'auto')
    actual_return = def_error.__str__()
    expected_return = 'some error message'
    assert actual

# Generated at 2022-06-22 19:59:01.756629
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(u'TestError: interpreter discovery mode unreachable', u'python', u'local')
    assert repr(error) == u'TestError: interpreter discovery mode unreachable'



# Generated at 2022-06-22 19:59:05.447900
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex = InterpreterDiscoveryRequiredError('test', 'python', 'auto')
    assert ex.interpreter_name == 'python'
    assert ex.discovery_mode == 'auto'



# Generated at 2022-06-22 19:59:11.561166
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert err.message == 'message'
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'auto'
    assert str(err) == 'message'


# Generated at 2022-06-22 19:59:16.131241
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(u'This is an error message', u'python', 'auto')
    assert repr(err) == u'This is an error message'


# Generated at 2022-06-22 19:59:21.023918
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    i = InterpreterDiscoveryRequiredError("Error test message", "py", "auto")

    assert i.message == "Error test message"
    assert i.interpreter_name == "py"
    assert i.discovery_mode == "auto"

# Generated at 2022-06-22 19:59:27.455508
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError(message="Test message",
                                            interpreter_name="python3",
                                            discovery_mode='auto_legacy_silent')
    assert to_text(exc.message) == "Test message"
    assert to_text(exc.interpreter_name) == "python3"
    assert to_text(exc.discovery_mode) == "auto_legacy_silent"

# Generated at 2022-06-22 19:59:34.081694
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError(u'The interpreter is not found and requires "auto" discovery mode',
                                            'python', 'not_auto')
    assert str(exc) == 'The interpreter is not found and requires "auto" discovery mode'
    assert repr(exc) == 'The interpreter is not found and requires "auto" discovery mode'
    assert exc.interpreter_name == 'python'
    assert exc.discovery_mode == 'not_auto'
    assert isinstance(exc, Exception)

# Generated at 2022-06-22 19:59:38.243455
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='legacy')
    assert repr(error) == 'message'

# Generated at 2022-06-22 19:59:49.221195
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor import module_common
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-22 19:59:52.216282
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    my_exception = InterpreterDiscoveryRequiredError("My error message", "python", "auto")
    assert my_exception.message == "My error message"

# Generated at 2022-06-22 19:59:55.589622
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = "message"
    interpreter_name = "python"
    discovery_mode = "auto"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error

# Generated at 2022-06-22 19:59:58.053688
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert exc.__repr__() == exc.message


# Generated at 2022-06-22 20:00:10.135960
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    # FUTURE: more comprehensive test cases

    # test case: happy path
    # (a real action object would be desirable, but an awful lot of work to replicate)
    c_data = dict(
        stdout=u'PLATFORM\nLinux\nFOUND\n/fakepath/python\nENDFOUND',
        stderr=u''
    )

# Generated at 2022-06-22 20:00:13.909607
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    idr = InterpreterDiscoveryRequiredError('Test message', 'python', 'a')
    assert idr.__repr__() == idr.message


# Generated at 2022-06-22 20:00:16.647843
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy')
    assert repr(error) == 'message'


# Generated at 2022-06-22 20:00:28.882828
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_versioned_doclink
    display = Display()
    ex = InterpreterDiscoveryRequiredError(
        message='The default Python interpreter on this host is {0} but {1} is required in order to execute this module.'
                .format(display.bold('/usr/bin/python'), display.bold('/usr/bin/python3')),
        interpreter_name='python3',
        discovery_mode='auto')
    output = str(ex)
    assert output == 'The default Python interpreter on this host is {0} but {1} is required in order to execute this module.'.format(
        display.bold('/usr/bin/python'), display.bold('/usr/bin/python3'))

# Generated at 2022-06-22 20:00:33.702167
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('test', 'python2', 'auto_legacy_silent')
    expected_result = 'test'
    assert(str(error) == expected_result)


# Generated at 2022-06-22 20:00:42.876933
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    task_vars = {}
    play_source = dict(
        name="test play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='pwd'))
        ]
    )

# Generated at 2022-06-22 20:00:46.259458
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'Interpreter discovery required for this target'
    exc = InterpreterDiscoveryRequiredError(msg, 'python', 'auto')
    assert msg == str(exc)

# Generated at 2022-06-22 20:00:57.592295
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import contextlib
    from ansible.executor.action_buffer import ActionBuffer
    from ansible.plugins import action
    import ansible.executor.task_executor

    if not hasattr(ansible.executor.task_executor.TaskExecutor, '_low_level_execute_command'):
        raise RuntimeError('Cannot test interpreter discovery without core patch (see unit test docs)')

    # Need to monkeypatch the action base class to stub out the low-level command executor
    # and to prevent the live plugin loading of module_utils, which would fail due to the
    # lack of connection/module_loader
    @contextlib.contextmanager
    def _dummy_loader():
        yield dict()

    old_loader = action.ActionBase._loader_context
    old_execute = ansible.executor.task_executor

# Generated at 2022-06-22 20:01:00.805464
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # TODO: proper test impl
    err = InterpreterDiscoveryRequiredError('message', 'python', 'automatic')
    assert str(err) == err.message

# Generated at 2022-06-22 20:01:13.938883
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import shutil
    import tempfile
    import unittest

    class TestModule(object):
        def __init__(self, module_name, module_args, *extra_args):
            self.module_name = module_name
            self.module_args = module_args
            self._low_level_execute_command = extra_args[0]

    class MockAction(object):
        def __init__(self, *extra_args):
            self._connection = extra_args[0]
            self._discovery_warnings = []

    class MockConnection(object):
        def __init__(self, has_pipelining):
            self.has_pipelining = has_pipelining


# Generated at 2022-06-22 20:01:20.457637
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "test_msg"
    name = "test_interpreter"
    mode = "test_mode"
    test_error = InterpreterDiscoveryRequiredError(msg, name, mode)
    assert test_error.message == msg
    assert test_error.interpreter_name == name
    assert test_error.discovery_mode == mode

# Generated at 2022-06-22 20:01:25.717971
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name='python'
    discovery_mode='auto'
    message='Interpreter discovery required but not supported on this platform.'
    exc = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(exc) == "Interpreter discovery required but not supported on this platform."

# Generated at 2022-06-22 20:01:27.599007
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_object = InterpreterDiscoveryRequiredError('message','interpreter_name','discovery_mode')
    assert isinstance(test_object.__str__(), str)

# Generated at 2022-06-22 20:01:35.388114
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    #Check object creation
    with pytest.raises(InterpreterDiscoveryRequiredError) as excinfo:
        raise InterpreterDiscoveryRequiredError('Test message for InterpreterDiscoveryRequiredError', 'python', 'auto')

    #Check exception message
    assert excinfo.type == InterpreterDiscoveryRequiredError
    assert excinfo.value.message == 'Test message for InterpreterDiscoveryRequiredError'
    assert excinfo.value.interpreter_name == 'python'
    assert excinfo.value.discovery_mode == 'auto'

# Generated at 2022-06-22 20:01:36.788705
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError('msg', 'python', 'silent')
    except InterpreterDiscoveryRequiredError as e:
        assert repr(e) == 'msg'



# Generated at 2022-06-22 20:01:39.353536
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = "Interpreter discovery required."
    error_obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    result = str(error_obj)
    assert result == message

# Generated at 2022-06-22 20:01:43.046341
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """test_InterpreterDiscoveryRequiredError___repr___0"""
    # Repr Implementation is not found for method __repr__ of class InterpreterDiscoveryRequiredError



# Generated at 2022-06-22 20:01:46.316456
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("Message", "python", "auto")
    assert 'Message, interpreter: python, discovery mode: auto' == str(error)

# Generated at 2022-06-22 20:01:58.214891
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.executor.task_result import TaskResult
    from ansible.executor.action_result import HostActionResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.action import ActionBase

    class StubbedAction(ActionBase):

        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self.task = task
            self.connection = connection
            self.play_context = play_context
            self.loader = loader
            self.templar = templar
            self.shared_loader_obj = shared_loader_obj
            self.results = []
            self.result_q = []
           

# Generated at 2022-06-22 20:02:03.494537
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # given
    message = "message"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    interpreter_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # when
    result = str(interpreter_error)

    # then
    assert result == message

# Generated at 2022-06-22 20:02:10.291399
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = mock_action()
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = {'ansible_python_interpreter': '/usr/bin/python'}

    interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert interpreter == '/usr/bin/python'
    assert action._discovery_warnings == []



# Generated at 2022-06-22 20:02:17.727731
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Test_Action:
        def __init__(self):
            self._connection = None
            self._success = True
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            self._executed_commands += 1
            self._connection = Test_Connection()

            if self._success:
                return Test_Connection.execute_command(command, in_data)
            else:
                return None

    class Test_Connection:
        @classmethod
        def execute_command(self, command, in_data):
            # print('execute_command({0})'.format(command))
            fake_res = {}

# Generated at 2022-06-22 20:02:21.619279
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert exception.message == 'message'
    assert exception.interpreter_name == 'interpreter_name'
    assert exception.discovery_mode == 'discovery_mode'

# Generated at 2022-06-22 20:02:25.794798
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    error = InterpreterDiscoveryRequiredError('message', 'python3', 'auto')
    assert error.interpreter_name == 'python3'
    assert error.discovery_mode == 'auto'
    assert str(error) == 'message'
    assert repr(error) == 'message'



# Generated at 2022-06-22 20:02:26.451795
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-22 20:02:31.552286
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert(e.interpreter_name == interpreter_name)
    assert(e.discovery_mode == discovery_mode)

# unit tests for discover_interpreter()

# Generated at 2022-06-22 20:02:37.568081
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "msg"
    interpreter_name = 'python'
    discovery_mode = 'auto'
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert error.message == msg
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:02:43.028496
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert isinstance(exc, Exception) and str(exc) == "message"
    assert exc.interpreter_name == "interpreter_name" and exc.discovery_mode == "discovery_mode"


# Generated at 2022-06-22 20:02:47.846139
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Test error msg", "/usr/bin/python", "legacy")
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == "Test error msg"
        assert ex.interpreter_name == "/usr/bin/python"
        assert ex.discovery_mode == "legacy"

# Generated at 2022-06-22 20:02:53.348363
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    args = {'message':'test', 'interpreter_name':'python', 'discovery_mode':'auto'}
    error = InterpreterDiscoveryRequiredError(**args)
    assert (error.message == args['message'] and
            error.interpreter_name == args['interpreter_name'] and
            error.discovery_mode == args['discovery_mode'])


# Generated at 2022-06-22 20:03:01.569323
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    def check_representation(message, interpreter_name, discovery_mode, expected):
        error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
        result = repr(error)

        assert result == expected, "Error repr representation is incorrect: %s != %s" % (result, expected)

    check_representation('Abort, Retry, Fail?', 'python', 'auto_legacy',
                         "Abort, Retry, Fail? (python, discovery = auto_legacy)")

# Generated at 2022-06-22 20:03:06.640947
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    assert InterpreterDiscoveryRequiredError("test", "python", "auto_legacy")
    assert not InterpreterDiscoveryRequiredError("test", "python", "auto_legacy").interpreter_name is None
    assert not InterpreterDiscoveryRequiredError("test", "python", "auto_legacy").discovery_mode is None


# Generated at 2022-06-22 20:03:09.879133
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert error.interpreter_name == 'interpreter_name'
    assert error.discovery_mode == 'discovery_mode'



# Generated at 2022-06-22 20:03:13.552478
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('message', 'py', 'auto')
    assert repr(error) is not None
    assert repr(error) == 'message'


# Generated at 2022-06-22 20:03:17.397768
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('test message', 'interpreter', 'discovery')
    assert err.__repr__() == u'test message'


# Generated at 2022-06-22 20:03:27.014137
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Unit test: discover python interpreters
    action = object()
    action._low_level_execute_command = lambda command, sudoable, in_data='': (
            {'stderr': '', 'stdout': 'PLATFORM\nLinux\nFOUND\n/bin/python\n/usr/bin/python\nENDFOUND\n',
             'rc': 0, 'stdout_lines': []})
    action._discovery_warnings = []

    python_interpreter = discover_interpreter(action=action, interpreter_name='python', discovery_mode='auto_legacy_silent',
                                              task_vars={})
    assert python_interpreter == u'/usr/bin/python'
    assert action._discovery_warnings == []

    action = object()
    action._low

# Generated at 2022-06-22 20:03:30.757068
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python', discovery_mode='auto_legacy_silent')
    exp_result = 'test message'
    assert exc.__repr__() == exp_result

# Generated at 2022-06-22 20:03:38.994813
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    host = 'test_host'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    error_message = 'error message'
    try:
        raise InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == error_message
        assert ex.interpreter_name == interpreter_name
        assert ex.discovery_mode == discovery_mode
    else:
        assert False, "Should have raised InterpreterDiscoveryRequiredError"

# Generated at 2022-06-22 20:03:42.015261
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Initiate a InterpreterDiscoveryRequiredError
    result = InterpreterDiscoveryRequiredError(
        message="test_message", interpreter_name="test_interpreter_name", discovery_mode="test_discovery_mode"
    )

    # Check the result of __repr__
    assert result.__repr__() == "test_message"

# Generated at 2022-06-22 20:03:49.186734
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required'
    display.verbosity = 4

    try:
        raise InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    except Exception as e:
        assert message in str(e) and interpreter_name in str(e) and discovery_mode in str(e)

# Generated at 2022-06-22 20:03:53.772455
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    msg = "test msg"
    interpreter_name = "test_interpreter_name"
    discovery_mode = "whatever"
    exc = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert msg == exc.__str__()


# Generated at 2022-06-22 20:04:02.705904
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    examples = [
        {
            'message': 'Interpreter discovery failed',
            'interpreter_name': 'python',
            'expected': 'Interpreter discovery failed'
        },
        {
            'message': 'Interpreter discovery required',
            'interpreter_name': 'python',
            'expected': 'Interpreter discovery required'
        },
    ]

    for example in examples:
        try:
            raise InterpreterDiscoveryRequiredError(example['message'], 'python', 'auto')
        except InterpreterDiscoveryRequiredError as error:
            assert str(error) == example['expected']