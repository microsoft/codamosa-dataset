

# Generated at 2022-06-22 19:54:06.234500
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message',"python","auto")
    assert error.__str__() == error.message

# Unit tests for method __repr__ of class InterpreterDiscoveryRequiredError
# TODO: proper repr impl

# Generated at 2022-06-22 19:54:09.541994
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    assert isinstance(InterpreterDiscoveryRequiredError("Test error", "python", "auto_legacy_silent"), InterpreterDiscoveryRequiredError)

# Generated at 2022-06-22 19:54:13.405226
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('Some message', 'python', 'auto')
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'
    assert error.__str__() == 'Some message'
    assert error.__repr__() == 'Some message'

# Generated at 2022-06-22 19:54:18.875516
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # TODO: mock taskvars arg
    task_vars = {}
    # TODO: mock action arg
    action = ""
    discovery_mode = "auto"
    interpreter_name = "python"
    err = InterpreterDiscoveryRequiredError("test_message", interpreter_name, discovery_mode)

# Unit Test for discover_interpreter method

# Generated at 2022-06-22 19:54:22.458319
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    d = InterpreterDiscoveryRequiredError(
        'message',
        interpreter_name='Python',
        discovery_mode='auto')

    assert d.__repr__() == 'message'



# Generated at 2022-06-22 19:54:25.923085
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    errmsg = 'foo'
    interp = 'python'
    mode = 'foo'

    e = InterpreterDiscoveryRequiredError(errmsg, interp, mode)
    assert e.__str__() == errmsg


# Generated at 2022-06-22 19:54:29.745880
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "message"
    interpreter_name = "python3"
    discovery_mode = "auto"

    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert message == str(ex)

# Generated at 2022-06-22 19:54:33.503868
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError("test message", "test interpreter name", "test discovery mode")
    actual_result = exception.__repr__()
    assert actual_result == "test message"

# Generated at 2022-06-22 19:54:42.317934
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:54:50.297113
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError("hello world", "python", "auto")
    assert 'hello world' in err.__str__()
    assert 'InterpreterDiscoveryRequiredError' in err.__str__()
    err = InterpreterDiscoveryRequiredError("hello world 2", "python 2", "auto 2")
    assert 'hello world 2' in err.__str__()
    assert 'InterpreterDiscoveryRequiredError' in err.__str__()



# Generated at 2022-06-22 19:55:01.793203
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test with a date version that deliberately falls after the latest known version
    task_vars = {
        "inventory_hostname": "testhost"
    }
    task_vars["ansible_config"] = {
        "INTERPRETER_PYTHON_DISTRO_MAP": {
            "ubuntu": {
                "16.04": "/usr/bin/python3",
                "16.10": "/usr/bin/python3",
                "17.04": "/usr/bin/python3",
                "17.10": "/usr/bin/python3"
            }
        },
        "INTERPRETER_PYTHON_FALLBACK": [
            "/usr/bin/python3",
            "/usr/bin/python2"
        ]
    }

    # Test with an "older" version that previously would

# Generated at 2022-06-22 19:55:08.792525
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_message = 'test_error_message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    try:
        raise InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == error_message
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:55:12.732916
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    instance = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert instance.__str__() == "message"
    assert instance.__str__() == instance.message

# Generated at 2022-06-22 19:55:21.610297
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.plugins import module_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.hostvars import HostVars

    # Create a task for test purpose, as discovery requires a task object
    task = Task()
    task.action = 'shell'
    task.args = {'_raw_params': 'echo PLATFORM; uname; echo FOUND; /usr/bin/env python -V; echo ENDFOUND'}
    task._ds = {}
    task.register = {}
    task.args['_uses_shell'] = True
    task.args['_raw_params'] = task.args['_raw_params'].lstrip()
    task.no_log = False

# Generated at 2022-06-22 19:55:24.785187
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert exc.__repr__() == "message"

# Unit tests for method discover_interpreter

# Generated at 2022-06-22 19:55:34.781581
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Case 1: Message is passed
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as exception:
        assert exception.message == 'message'

    # Case 2: Message is not passed
    try:
        raise InterpreterDiscoveryRequiredError('python', 'auto')
    except InterpreterDiscoveryRequiredError as exception:
        assert exception.message is None

    # Case 3: Message and name are not passed
    try:
        raise InterpreterDiscoveryRequiredError('auto')
    except InterpreterDiscoveryRequiredError as exception:
        assert(exception.message is None)

# Generated at 2022-06-22 19:55:40.832066
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = 'Hello'
    exc = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exc.__str__() == message, '__str__ returns unexpected message'
    assert exc.__repr__() == message, '__repr__ returns unexpected message'

# Generated at 2022-06-22 19:55:45.378760
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('msg', 'python', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-22 19:55:58.427824
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule

    from ansible.executor.discovery import discover_interpreter

    module = AnsibleModule(argument_spec={
        'interpreter_name': dict(required=True, type='str'),
        'discovery_mode': dict(required=True, type='str'),
        'task_vars': dict(required=True, type='dict'),
        'host': dict(required=True, type='str'),
    },
        supports_check_mode=False
    )


# Generated at 2022-06-22 19:56:02.771281
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError('Interpreter is not found. "This is a demo message"', 'python3', 'auto')
    except Exception as ex:
        assert str(ex) == 'Interpreter is not found. "This is a demo message"'



# Generated at 2022-06-22 19:56:10.202170
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''Test discover_interpreter'''
    # interpreter used for 'discover' mode
    # assert discover_interpreter('python', 'discover', {}) == u'/usr/bin/python'

    # interpreter used for 'auto_silent' mode
    # assert discover_interpreter('python', 'auto_silent', {}) == u'/usr/bin/python'

    # interpreter used for 'auto_legacy' mode
    # assert discover_interpreter('python', 'auto_legacy', {}) == u'/usr/bin/python'

# Generated at 2022-06-22 19:56:14.703022
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(
        'This is a test of method __str__ of InterpreterDiscoveryRequiredError class',
        'Python',
        'auto'
    )

    assert error.__str__() == 'This is a test of method __str__ of InterpreterDiscoveryRequiredError class'

# Generated at 2022-06-22 19:56:26.689715
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class ActionModule(object):

        def __init__(self):
            self._connection = self
            self._low_level_execute_command = self
            self._tmp_path = ''
            self._discovery_warnings = []

        def __call__(self, *args, **kwargs):
            return self

        def has_pipelining(self):
            return True


# Generated at 2022-06-22 19:56:33.688859
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'foo'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.message == message
    assert err.interpreter_name == interpreter_name
    assert err.discovery_mode == discovery_mode
    assert str(err) == message
    assert repr(err) == message

# Generated at 2022-06-22 19:56:37.786596
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('MOCK MSG', 'python', 'silent')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'silent'
        assert repr(e) == str(e) == 'MOCK MSG'

# Generated at 2022-06-22 19:56:42.746694
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    class_name = "test_error"
    discovery_mode = "discovery_mode"

    error = InterpreterDiscoveryRequiredError(class_name, "python", discovery_mode)

    assert error.message == "python"
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "discovery_mode"

# Generated at 2022-06-22 19:56:50.419017
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """Tests the discover_interpreter function module"""

    class ActionModule:
        class Connection:
            def __init__(self, has_pipelining=False):
                self.has_pipelining = has_pipelining

        def __init__(self, _connection):
            self._connection = _connection
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=None, in_data=None):
            return {'stdout': '', 'stderr': ''}

    action = ActionModule(ActionModule.Connection(has_pipelining=True))

    task_vars = dict()

    task_vars['ansible_python_interpreter'] = '/bin/python3'


# Generated at 2022-06-22 19:56:54.550703
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    repetition_message = "This is the repetition message"
    interpreter_name = "python"
    discovery_mode = "auto"
    exception = InterpreterDiscoveryRequiredError(repetition_message, interpreter_name, discovery_mode)
    assert repr(exception) == repetition_message

# Generated at 2022-06-22 19:56:56.112873
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    result = InterpreterDiscoveryRequiredError("python interpreter cannot be used on this target",
                                               "python", "auto")

    print("interpreter_name = ", result.interpreter_name)
    print("discovery_mode = ", result.discovery_mode)

# Generated at 2022-06-22 19:57:00.376213
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError("Overriding __repr__ is not supported",
                                                "InterpreterDiscoveryRequiredError", "")
    except InterpreterDiscoveryRequiredError as e:
        assert e.__repr__() == e.message



# Generated at 2022-06-22 19:57:07.792444
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = "Interpreter discovery required"
    interpreter_name = "python"
    discovery_mode = "auto"
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.__repr__() == "Interpreter discovery required"
    assert str(error) == "Interpreter discovery required"



# Generated at 2022-06-22 19:57:12.321710
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(
        message='Error message',
        interpreter_name='python',
        discovery_mode='auto')
    assert 'python interpreter discovery required' in error.__repr__()
    assert 'auto' in error.__repr__()
    assert 'Error message' in error.__repr__()



# Generated at 2022-06-22 19:57:15.874212
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'Unable to find python interpreter'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(exception) == message

# Generated at 2022-06-22 19:57:20.669052
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'default', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', None) == u'/usr/bin/python'

    assert discover_interpreter(None, 'python', 'auto_legacy_silent', None) == u'/usr/bin/python'

# Generated at 2022-06-22 19:57:24.797746
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError("message", "python", "fallback")

    assert exception.message == "message"
    assert exception.interpreter_name == "python"
    assert exception.discovery_mode == "fallback"


# Generated at 2022-06-22 19:57:29.961798
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    message = "First test"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    idre = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert idre.__str__() == idre.message


# Generated at 2022-06-22 19:57:37.388497
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = ('Platform python on host localhost was not found, '
               'but auto-discovery could not be done without creating a '
               'subprocess on the remote host. Please explicitly set ansible_python_interpreter.')
    exc = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(exc) == message

# Generated at 2022-06-22 19:57:48.882289
# Unit test for function discover_interpreter
def test_discover_interpreter():
    fake_action = None
    fake_task_vars = {}
    fake_action._discovery_warnings = []

    def fake_low_level_execute_command(shell_bootstrap, sudoable=False, in_data=None):
        res = {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python2\nENDFOUND'}
        return res

    fake_action._low_level_execute_command = fake_low_level_execute_command

    def _get_config_value(key, variables):
        if key == 'INTERPRETER_PYTHON_FALLBACK':
            return ['/usr/bin/python', '/usr/bin/python2']

# Generated at 2022-06-22 19:57:54.130975
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("message", "python", "auto_silent")
    except Exception as e:
        assert isinstance(e, InterpreterDiscoveryRequiredError)
        # Checks that all arguments passed to the constructor are stored in the instance of the class
        assert e.message == "message"
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_silent"


# Generated at 2022-06-22 19:58:05.392685
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest

    class DummyModule(object):
        def __init__(self, task_vars):
            self._task_vars = task_vars

        def get_option(self, key):
            return self._task_vars.get(key)

    class DummyConnection(object):
        def __init__(self, pipelining=True):
            self._pipelining = pipelining

        def has_pipelining(self):
            return self._pipelining

    class DummyActionModule(object):
        def __init__(self, connection, task_vars):
            self.connection = connection
            self._module = DummyModule(task_vars)
            self._discovery_warnings = []


# Generated at 2022-06-22 19:58:11.970772
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    import ansible.executor.discovery
    ansible.executor.discovery.C = type('config', (object,), {'get_config_value': lambda self, key, variables: None})()
    e = ansible.executor.discovery.InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python', discovery_mode='silent')

    assert(str(e) == 'test message')

# Generated at 2022-06-22 19:58:24.486971
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test interpreter_name python

    task_vars = {}
    host = 'test'
    is_silent = False

    # test discovery_mode auto
    discovery_mode = 'auto'
    try:
        discover_interpreter(None, "python", discovery_mode, task_vars)
    except InterpreterDiscoveryRequiredError as e:
        # this is a newly added feature, do not fail the test for now
        pass

    # test discovery_mode auto_legacy
    discovery_mode = 'auto_legacy'
    try:
        discover_interpreter(None, "python", discovery_mode, task_vars)
    except InterpreterDiscoveryRequiredError as e:
        # this is a newly added feature, do not fail the test for now
        pass

    # test discovery_mode auto_legacy

# Generated at 2022-06-22 19:58:28.127927
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "msg"
    interpreter_name = "interpreter_name"
    discovery_mode = "discovery_mode"
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert str(error) == msg


# Generated at 2022-06-22 19:58:31.809382
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto_silent'
    test_message = 'Interpreter Discovery Required'

    e = InterpreterDiscoveryRequiredError(test_message, test_interpreter_name, test_discovery_mode)

    assert e.__str__() == test_message


# Generated at 2022-06-22 19:58:42.829476
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # import modules for testing
    from ansible.module_utils.basic import AnsibleModule, ModuleDeprecationWarning
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.system
    import warnings

    warnings.simplefilter('ignore', ModuleDeprecationWarning)

    # set the interpreter_python_version fact to match the value returned by the next call to discover_interpreter
    interpreter_python_version = '2.6'
    linux_distro = 'rhel'
    osrelease_content = 'ID=rhel\nVERSION_ID=8.1\n'
    facts = ansible.module_utils.facts.system.SystemInsights(module=None)
    module_run_command = 'ansible.module_utils.facts.system.SystemInsights.run(module=None)'

# Generated at 2022-06-22 19:58:51.647680
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    try:
        raise InterpreterDiscoveryRequiredError('test message', 'test_interpreter', 'test_discovery_mode')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == 'test message'
        assert e.interpreter_name == 'test_interpreter'
        assert e.discovery_mode == 'test_discovery_mode'
        assert e.__str__() == 'test message'
        assert e.__repr__() == 'test message'
        assert e.args == ('test message',)

# Generated at 2022-06-22 19:58:54.401015
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert 'message' == str(exc)
    assert 'message' == repr(exc)


# Generated at 2022-06-22 19:58:58.925578
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError(
        message="Python interpreter discovery is required for this host, but is disabled.",
        interpreter_name='python',
        discovery_mode='auto_legacy_silent'
    )
    # Verify the __str__ return value
    assert obj.__str__() == "Python interpreter discovery is required for this host, but is disabled."


# Generated at 2022-06-22 19:59:06.978482
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.urls import open_url

    # Mock
    class TestAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.fail_json = kwargs['fail_json']
            self.fail_json_for_missing_interpreter = kwargs['fail_json_for_missing_interpreter']
            self.check_mode = kwargs['check_mode']

            self.taskvars = dict()
            self.connection = object()
            self.connection.has_pipelining = True



# Generated at 2022-06-22 19:59:11.793079
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'message'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.__repr__() == message


# Generated at 2022-06-22 19:59:15.366486
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    with pytest.raises(NotImplementedError):
        raise InterpreterDiscoveryRequiredError(message="Test error message",
                                                interpreter_name="Python3",
                                                discovery_mode="auto_legacy_silent")

# Generated at 2022-06-22 19:59:27.606718
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule as script

    test_cases = [
        # test cases for discover_interpreter
        # run_command_environ_update, command, expected_result
        (dict(action_plugins={'script': script}), 'whoami', 'python', 'discovery_success'),
    ]

    for run_command_environ_update, command, interpreter_name, discovery_mode in test_cases:
        display.debug('Testing command: {0}'.format(command))
        run_command_environ_update['become_user'] = 'root'

# Generated at 2022-06-22 19:59:39.405111
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins import module_loader
    from ansible.plugins.loader import module_loader
    from ansible.executor.module_common import ACTION_SHELL
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.connection import Connection

    class MockModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            try:
                res = discover_interpreter(self, 'python', 'auto', task_vars)
                self.results = dict(ansible_facts=dict(python_discovery_result=res))
            except Exception as e:
                self.results = dict(ansible_facts=dict(python_discovery_error=e))
            return self.results

   

# Generated at 2022-06-22 19:59:42.834669
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy_silent")
    assert str(exception) == "message"



# Generated at 2022-06-22 19:59:44.442861
# Unit test for function discover_interpreter
def test_discover_interpreter():
    #TODO: unit test
    return True


# Generated at 2022-06-22 19:59:54.424135
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test all version matching scenarios
    class TestVersionMap(object):
        def __init__(self):
            self.vmap = {'1.7.0': '1', '1.8.0': '2', '2.2.0': '3', '2.2.1': '4'}

        def get(self, key, default=None):
            return self.vmap.get(key, default)

    pythons = ['python', 'python3']

    for python in pythons:
        for discovery_mode in ['auto', 'auto_legacy', 'auto_silent', 'auto_legacy_silent']:
            for version in ['1.7.0', '1.8.5', '2.2.0', '2.2.5']:
                version_map = TestVersionMap()

# Generated at 2022-06-22 20:00:02.863145
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import ansible.module_utils.discovery as module_utils
    import ansible.module_utils.discovery.platforms as platforms
    import ansible.module_utils.common.collections as collections

    class ActionTest(object):
        def __init__(self, name):
            self._name = name
            self._discovery_warnings = collections.OrderedDict()
            self.connection = FakeConnection()

        def _low_level_execute_command(self, command, sudoable=True, in_data=None):
            res = FakeResult(self._name)


# Generated at 2022-06-22 20:00:12.573098
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError('test message', "test_interpreter", "test_discovery_mode")
    assert exception.message == 'test message'
    assert exception.interpreter_name == 'test_interpreter'
    assert exception.discovery_mode == 'test_discovery_mode'
    assert isinstance(exception, Exception)


DISCOVERY_MODE_CHOICES = [
    'auto',
    'auto_legacy',
    'auto_silent',
    'auto_legacy_silent',
    'manual',
    'manual_silent',
    'off',
]



# Generated at 2022-06-22 20:00:24.776885
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    import unittest

    class MockAction(object):
        def __init__(self, action_name=None, module_loader=None, _discovery_warnings=None):
            self._discovery_warnings = _discovery_warnings or []


# Generated at 2022-06-22 20:00:30.373473
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("test", "jax", "rk")
    assert error.message == "test"
    assert error.interpreter_name == "jax"
    assert error.discovery_mode == "rk"
    assert str(error) == "test"
    assert repr(error) == "test"



# Generated at 2022-06-22 20:00:35.074698
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError(message='test message', interpreter_name='my_interpreter', discovery_mode='some_mode')
    assert exc.__str__() == str(exc)

# Generated at 2022-06-22 20:00:46.481127
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()

    action = dict()
    action['_discovery_warnings'] = list()
    action['_connection'] = dict()
    action['_connection']['has_pipelining'] = True
    action['_low_level_execute_command'] = dict()
    action['_low_level_execute_command']['stdout'] = 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'

    def _ll_exc_command(command, sudoable=False, in_data=None):
        res = dict()
        if sudoable:
            res['stdout'] = '/usr/bin/python'

# Generated at 2022-06-22 20:00:52.023448
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    identifier = "InterpreterDiscoveryRequiredError"
    interpreter_name = 'python'
    discovery_mode = 'auto'

    error = InterpreterDiscoveryRequiredError(identifier, interpreter_name, discovery_mode)

    assert error.message == identifier
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode


# Generated at 2022-06-22 20:00:56.381042
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "normal"
    exception = InterpreterDiscoveryRequiredError("MESSAGE", interpreter_name, discovery_mode)

    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:01:01.444598
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = "test_action"
    interpreter_name = "python"
    discovery_mode = "auto_legacy"
    task_vars = "test_task"

    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res is not None

# Generated at 2022-06-22 20:01:02.672449
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: implement
    return


# Generated at 2022-06-22 20:01:08.475439
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.cli.adhoc import AdHocCLI

    class TestActionModule(object):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar

# Generated at 2022-06-22 20:01:11.415174
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        discover_interpreter(None, 'python', 'auto', {})
    except InterpreterDiscoveryRequiredError:
        pass



# Generated at 2022-06-22 20:01:14.343441
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError(u"message", u"python", u"discovery_mode")
    assert u"message" == str(exception)


# Generated at 2022-06-22 20:01:17.985986
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(
        message='Python interpreter discovery is required for this target host',
        interpreter_name='python',
        discovery_mode='auto'
    )
    assert repr(error) == 'Python interpreter discovery is required for this target host'

# Generated at 2022-06-22 20:01:27.446375
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    import re

    mock_action = MockAction()
    mock_task_vars = dict(
        ansible_python_interpreter='/usr/bin/python3.6',
        ansible_python_major = 3,

        inventory_hostname='test_host',
        # no need to mock all the inventory variables, just one per group:
        ansible_distribution='RedHat',
        ansible_distribution_version='7.5',
        ansible_distribution_major_version='7',
        ansible_distribution_release='Red Hat Enterprise Linux Server release 7.5 (Maipo)',
        ansible_system='Linux',
        ansible_pkg_mgr='yum',
        ansible_os_family='RedHat',
    )

# Generated at 2022-06-22 20:01:36.422716
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # try differnt interpreter_name
    for interpreter_name in ['python', 'python2', 'python3', 'python-6.1.0']:
        # try different discovery_mode
        for discovery_mode in ['explicit', 'auto', 'auto_legacy', 'auto_silent', 'auto_legacy_silent']:
            try:
                raise InterpreterDiscoveryRequiredError('message', interpreter_name, discovery_mode)
            except InterpreterDiscoveryRequiredError as ex:
                if ex.interpreter_name != interpreter_name:
                    assert False
                if ex.discovery_mode != discovery_mode:
                    assert False

# Generated at 2022-06-22 20:01:40.875639
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Test to make sure string representation
    # of InterpreterDiscoveryRequiredError is correct
    msg = "Expected test condition"
    interpreter_name = "python"
    discovery_mode = "auto"
    test_exception = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert str(test_exception) == msg

# Generated at 2022-06-22 20:01:43.826284
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_msg = u'Interpreter discovery required for python on host "localhost"'
    ider = InterpreterDiscoveryRequiredError(error_msg, 'python', 'auto_legacy_silent')
    assert repr(ider) == error_msg

# Generated at 2022-06-22 20:01:48.602252
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = 'some error message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert error.__str__() == error_message

# Generated at 2022-06-22 20:01:52.925621
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "interpreter_name_not_found"
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == str(exception)
    assert message == repr(exception)


# Generated at 2022-06-22 20:01:58.389592
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Error Message'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(exception) == message


# Generated at 2022-06-22 20:02:01.135451
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert repr(interpreter_discovery_required_error) == 'message'


# Generated at 2022-06-22 20:02:03.439791
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')

# Generated at 2022-06-22 20:02:09.391498
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_message = "Interpreter discovery required for python"
    interpreter_name = "python"
    discovery_mode = "auto,silent"
    exception = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert exception.message == error_message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode


# Generated at 2022-06-22 20:02:18.650031
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("Interpreter Discovery Required", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        # test the constructor of class InterpreterDiscoveryRequiredError
        assert isinstance(e, InterpreterDiscoveryRequiredError)
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'
    # test __str__ method
    assert str(e) == "Interpreter Discovery Required"
    assert repr(e) == "Interpreter Discovery Required"

# Generated at 2022-06-22 20:02:21.563895
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    result = InterpreterDiscoveryRequiredError("message", "interp", "discovery").__str__()
    assert result == "message"


# Generated at 2022-06-22 20:02:26.387559
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('Message', 'Python', 'auto')
    assert e.message == 'Message'
    assert e.interpreter_name == 'Python'
    assert e.discovery_mode == 'auto'
    assert str(e) == 'Message'
    assert repr(e) == 'Message'

# Generated at 2022-06-22 20:02:29.957575
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    str_output = "test message, python, test_discovery_mode"
    err = InterpreterDiscoveryRequiredError(str_output, "python", "test_discovery_mode")
    assert str(err) == str_output


# Generated at 2022-06-22 20:02:36.384261
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('something bad happened', 'python', 'typed')
    except InterpreterDiscoveryRequiredError as e:
        assert isinstance(e, InterpreterDiscoveryRequiredError)
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'typed'

# Generated at 2022-06-22 20:02:47.846649
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.task_queue_manager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils import plugin_docs

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, variable_manager=variable_manager, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play_source = dict(name="Ansible Play",
                       hosts='localhost',
                       gather_facts='no',
                       tasks=[])
    play = Play().load(play_source, variable_manager=variable_manager, loader=None)

    tqm = ansible.executor.task_queue_manager.TaskQueue

# Generated at 2022-06-22 20:02:52.368807
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception_message = 'Exception message'
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    exception = InterpreterDiscoveryRequiredError(exception_message, interpreter_name, discovery_mode)

    assert exception.__repr__() == exception_message


# Generated at 2022-06-22 20:02:55.068682
# Unit test for function discover_interpreter
def test_discover_interpreter():
    result = discover_interpreter(None, 'python', 'auto', dict())
    assert result == '/usr/bin/python'


# Generated at 2022-06-22 20:03:01.472942
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "pyhton"
    discovery_mode = "auto"
    error = InterpreterDiscoveryRequiredError(None, interpreter_name, discovery_mode)
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode
    assert str(error) == repr(error)

# Generated at 2022-06-22 20:03:08.626365
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('This is a custom error',
                                                'python',
                                                'auto_legacy_silent')
    except Exception as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto_legacy_silent'
        assert e.message == 'This is a custom error'
        assert str(e) == 'This is a custom error'
        assert repr(e) == 'This is a custom error'


# Generated at 2022-06-22 20:03:15.146739
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: stub out action; add pytest mark.skipif, to run with pipelining and without?
    action = None
    task_vars = dict()
    interpreter_name = 'python'

    for discovery_mode in ['auto_legacy', 'auto']:
        result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        assert result

# Generated at 2022-06-22 20:03:18.852739
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError('message', 'python',
                                            'auto_silent')

    assert repr(exc) == 'message'


# Generated at 2022-06-22 20:03:24.422439
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    import pytest
    message = 'message'
    interpreter_name = 'python'
    discovery_mode ='auto_legacy'

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.message == message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode

    assert str(exception) == message
    assert repr(exception) == message



# Generated at 2022-06-22 20:03:34.280630
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.connection.network_cli import Connection
    from ansible.utils.vars import combine_vars

    class MockModule:
        def __init__(self):
            self._shared_loader_obj = None
            self._task = MockTask()
            self._connection = Connection()


# Generated at 2022-06-22 20:03:40.046094
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('The interpreter was not found.', 'python', 'auto_legacy')
    except InterpreterDiscoveryRequiredError as exc:
        assert to_text(exc) == 'The interpreter was not found.'
        assert exc.interpreter_name == 'python'
        assert exc.discovery_mode == 'auto_legacy'

# Generated at 2022-06-22 20:03:44.292629
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError("message", 'python', 'auto')
    assert e.message == "message"
    assert e.interpreter_name == 'python'
    assert e.discovery_mode == 'auto'

    assert e.__repr__() == e.message

# Generated at 2022-06-22 20:03:46.564827
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'message'
    InterpreterDiscoveryRequiredError(message, 'python', 'auto_legacy_silent')

# Generated at 2022-06-22 20:03:53.369404
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'legacy'
    message = 'The interpreter discovery required by the interpreter_name: {0} and discovery_mode: {1}.'.format(interpreter_name, discovery_mode)

    expected = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert isinstance(expected, InterpreterDiscoveryRequiredError)

# Generated at 2022-06-22 20:03:55.172183
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy', {}) == u'/usr/bin/python'

# Generated at 2022-06-22 20:04:02.981237
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = 'message'
    interp_name = 'python'
    disc_mode = 'auto_legacy_silent'
    err = InterpreterDiscoveryRequiredError(msg, interp_name, disc_mode)
    assert err.message == msg, 'error message is not expected'
    assert err.interpreter_name == interp_name, 'error interpreter name is not expected'
    assert err.discovery_mode == disc_mode, 'error discovery_mode is not expected'


# Generated at 2022-06-22 20:04:08.611444
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    discovery_mode = 'smart'
    interpreter_name = 'python'
    err = InterpreterDiscoveryRequiredError('Missing Python interpreter', interpreter_name, discovery_mode)
    assert isinstance(err, Exception)
    assert err.interpreter_name == interpreter_name
    assert err.discovery_mode == discovery_mode

