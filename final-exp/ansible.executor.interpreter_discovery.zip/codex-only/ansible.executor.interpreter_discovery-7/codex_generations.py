

# Generated at 2022-06-22 19:54:05.616207
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: make this a unit test
    p = dict(e=dict(f=dict(b=1,c=2), d=4), a=dict(b=1,c=2))
    assert discover_interpreter('', 'py', 'c', p) == u'/usr/bin/python'

# Generated at 2022-06-22 19:54:11.299856
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError(u"error_message", u"interpreter_name", u"discovery_mode")
    assert err.message == u"error_message"
    assert err.interpreter_name == u"interpreter_name"
    assert err.discovery_mode == u"discovery_mode"

# Generated at 2022-06-22 19:54:16.045265
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_object = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    repr_result = repr(error_object)
    assert repr_result == 'message'


# Generated at 2022-06-22 19:54:22.687167
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
  """
  Test that the method __str__(self) of class InterpreterDiscoveryRequiredError
  returns a human readable string
  """
  # Arrange
  # Note: a simple string will be compared to the string returned by
  # InterpreterDiscoveryRequiredError.__str__
  message = "This is a test message"
  interpreter_name = "This is a test interpreter_name"
  discovery_mode = "This is a test discovery_mode"
  expected_output = "This is a test message"

  # Act
  actual_output = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

  # Assert
  assert str(actual_output).__eq__(expected_output)

# Generated at 2022-06-22 19:54:28.322107
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(
        "Ansible requires Python interpreter discovery to be performed on this host.",
        "python",
        "auto_legacy_silent"
    )
    expected_repr = "Ansible requires Python interpreter discovery to be performed on this host."
    assert interpreter_discovery_required_error.__repr__() == expected_repr


# Generated at 2022-06-22 19:54:31.922835
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError("test", "python", "auto_legacy")
    err_str = str(err)
    assert err_str == "test"



# Generated at 2022-06-22 19:54:41.575827
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.system.distribution

    test_action = basic.ActionBase()
    test_action._low_level_execute_command = low_level_execute_command_mock
    test_action._discovery_warnings = []

    _system_distribution = ansible.module_utils.facts.system.distribution
    _system_distribution.linux_distribution = _linux_distribution_stub
    _system_distribution.LinuxDistribution = _linux_distribution_stub

    test_task_vars = {'inventory_hostname': 'test_hostname', 'ansible_connection': 'local'}


# Generated at 2022-06-22 19:54:53.867435
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        from ansible.plugins.action import ActionBase
    except ImportError:
        print('skipped test_discover_interpreter: unable to import from ansible.plugins.action')
        return

    class ActionModule(ActionBase):
        TRANSFERS_FILES = False

        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            self._low_level_execute_command(command="true", sudoable=False)
            return super(ActionModule, self).run(tmp, task_vars)

    class Connection(object):

        @staticmethod
        def has_pipelining():
            return True

        def __init__(self, host, port, user, password):
            self._host = host
            self._

# Generated at 2022-06-22 19:54:57.743672
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    res = InterpreterDiscoveryRequiredError(u"message", u"python", u"auto")
    assert res.__repr__() == u"message"



# Generated at 2022-06-22 19:55:06.112039
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from ansible.module_utils.distro import LinuxDistribution
    from ansible.module_utils.compat.version import LooseVersion
    id = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    expected = 'message'
    actual = id.__repr__()
    assert actual == expected
    assert actual is not expected
    assert type(id.interpreter_name) == str
    assert type(id.discovery_mode) == str
    assert LinuxDistribution._parse_os_release_content('NAME="Red Hat Enterprise Linux Server"') == {'name': 'Red Hat Enterprise Linux Server'}

# Generated at 2022-06-22 19:55:08.838888
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    foo = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert foo.__str__() == "message"

# Generated at 2022-06-22 19:55:11.515086
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("message", "name", "mode")
    assert error.__repr__() == "message"

# Generated at 2022-06-22 19:55:16.711141
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_obj = InterpreterDiscoveryRequiredError(
        message='some message',
        interpreter_name='python',
        discovery_mode='auto_silent'
    )
    assert error_obj.__repr__() == 'Unable to detect which python interpreter to use. Discovery mode: auto_silent'

# Generated at 2022-06-22 19:55:26.601350
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    try:
        raise InterpreterDiscoveryRequiredError("message", "python", "auto")
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto"
    else:
        assert False

    try:
        raise InterpreterDiscoveryRequiredError("message", "python", "auto_legacy")
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_legacy"
    else:
        assert False


# Generated at 2022-06-22 19:55:37.674821
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'silent'
    task_vars = None

    try:
        # run the function
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == 'Python interpreter discovery required for this version of Ansible. ' \
                         'See https://docs.ansible.com/ansible/latest/reference_appendices/interpreter_discovery.html ' \
                         'for more information'
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:55:41.678561
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError("Message", "InterpreterName", "DiscoveryMode")

    assert exception.message == "Message"
    assert exception.interpreter_name == "InterpreterName"
    assert exception.discovery_mode == "DiscoveryMode"

# Generated at 2022-06-22 19:55:47.128395
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'some message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    expected_result = msg
    actual_result = error.__repr__()
    assert actual_result == expected_result



# Generated at 2022-06-22 19:55:59.711421
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    expected_interpreter_name = 'python'
    expected_discovery_mode = 'auto'
    # TODO: should be returning a test message, not to_native(exception)
    expected_message = to_native(InterpreterDiscoveryRequiredError(expected_message,
                                                                   expected_interpreter_name,
                                                                   expected_discovery_mode))
    actual_exception = InterpreterDiscoveryRequiredError(expected_message,
                                                         expected_interpreter_name,
                                                         expected_discovery_mode)
    actual_message = actual_exception.message
    actual_interpreter_name = actual_exception.interpreter_name
    actual_discovery_mode = actual_exception.discovery_mode

# Generated at 2022-06-22 19:56:01.580531
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("Interpreter required", "python", "auto")
    assert error.__str__() == "Interpreter required"

# Generated at 2022-06-22 19:56:11.168585
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = "Interpreter discovery required, but interpreter parameter set to '%s', and" \
              " interpreter_discovery_mode is '%s'. " % (interpreter_name, discovery_mode)
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == interpreter_name
        assert e.discovery_mode == discovery_mode
        message_from_str = str(e)
        assert message_from_str == message

# Generated at 2022-06-22 19:56:13.978082
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError(
            message='error', interpreter_name='python', discovery_mode='default')
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == 'error'

# Generated at 2022-06-22 19:56:25.830444
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import ansible.executor.discovery
    class TestDiscovery(unittest.TestCase):
        def test_discover_interpreter(self):
            # Simple test for discovering python3 when its
            # discovered in the bin/ directory normally.
            discovery_mode = 'auto'
            interpreter_name = 'python'

            task_vars = {}
            action = ansible.executor.action_templates.ActionModule(task_vars)

            python2_path = "/usr/bin/python"
            python3_path = "/usr/bin/python3"

# Generated at 2022-06-22 19:56:32.657253
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Call method __repr__ of class InterpreterDiscoveryRequiredError with a specific object
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'Test message'
    test = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    res = test.__repr__()
    assert res == message

# Generated at 2022-06-22 19:56:39.883483
# Unit test for function discover_interpreter
def test_discover_interpreter():
    with open("script_tests/interpreter_discovery/fixtures/discover_interpreter_data.json") as json_file:
        json_data = json.load(json_file, encoding='utf-8')
        for data in json_data:
            version = data.get("version")
            version_map = data.get("version_map")
            expected_result = data.get("expected_result")
            result = _version_fuzzy_match(version, version_map)
            assert result == expected_result

# Generated at 2022-06-22 19:56:44.515558
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'interpreter discovery required'
    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    # Check if message is the same as the one passed in
    assert obj.__str__() == message

# Generated at 2022-06-22 19:56:48.384763
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError(u'foobar', u'python', u'auto_legacy_silent')
    assert e.__repr__() == e.message
    assert u'foobar' in repr(e)
    assert e.interpreter_name in repr(e)
    assert e.discovery_mode in repr(e)


# Generated at 2022-06-22 19:56:56.146340
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    discovery_mode = 'test_discovery_mode'
    interpreter_name = 'test_interpreter_name'
    message = 'test_message'
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == interpreter_discovery_required_error.message
    assert interpreter_name == interpreter_discovery_required_error.interpreter_name
    assert discovery_mode == interpreter_discovery_required_error.discovery_mode



# Generated at 2022-06-22 19:56:58.218591
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'Some message'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(error) == message
    assert repr(error) == message

# Generated at 2022-06-22 19:57:03.191394
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError(message='Error Message', interpreter_name='python',
                                                discovery_mode='auto')
    except InterpreterDiscoveryRequiredError as exception:
        assert exception.__str__() == 'Error Message'

# Generated at 2022-06-22 19:57:08.102023
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto_legacy_silent")
    assert error.__repr__() == "message"
    assert error.__str__() == "message"


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-22 19:57:12.142607
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert err.__repr__() == "message"


# Generated at 2022-06-22 19:57:19.826005
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class Action:
        def __init__(self):
            self._low_level_execute_command_results = []

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            res = self._low_level_execute_command_results.pop(0)
            if res.get('failed', False):
                raise Exception('shell test failure')
            return res

        _discovery_warnings = []


# Generated at 2022-06-22 19:57:27.405291
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e1 = InterpreterDiscoveryRequiredError(u'foo', u'python', u'auto')
    assert e1.message == u'foo'
    assert e1.interpreter_name == u'python'
    assert e1.discovery_mode == u'auto'

    e2 = InterpreterDiscoveryRequiredError(u'foobar', u'jython', u'auto_silent')
    assert e2.message == u'foobar'
    assert e2.interpreter_name == u'jython'
    assert e2.discovery_mode == u'auto_silent'


# Generated at 2022-06-22 19:57:40.577516
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python3', 'auto', None) == u'/usr/bin/python3'
    assert discover_interpreter(None, 'python', 'auto_legacy', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python3', 'auto_legacy', None) == u'/usr/bin/python3'
    assert discover_interpreter(None, 'python', 'auto_silent', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python3', 'auto_silent', None) == u'/usr/bin/python3'

# Generated at 2022-06-22 19:57:50.631588
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Test with non python interpreter
    try:
        discover_interpreter(None, 'perl', 'auto', None)
    except NotImplementedError:
        pass
    else:
        assert False

    # Test with an invalid auto discovery mode
    try:
        discover_interpreter(None, 'python', 'auto_invalid', None)
    except ValueError:
        pass
    else:
        assert False

    # Test with a valid auto discovery mode

# Generated at 2022-06-22 19:57:55.848878
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # unit test for method __repr__ of class InterpreterDiscoveryRequiredError
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    idrre = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    # expected __repr__ value
    expected_repr = 'message'

    repr_result = repr(idrre)

    assert repr_result == expected_repr


# Generated at 2022-06-22 19:58:06.178176
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six import PY3

    if not PY3:
        from ansible.module_utils.six.moves import builtins
        builtins.__dict__['__salt__'] = {'cmd.run': lambda x: b''}
    else:
        import __builtin__
        __builtin__.__dict__['__salt__'] = {'cmd.run': lambda x: b''}

    try:
        assert discover_interpreter(None, 'python', 'auto', {}) is not None
    finally:
        if not PY3:
            del builtins.__dict__['__salt__']
        else:
            del __builtin__.__dict__['__salt__']

# Generated at 2022-06-22 19:58:09.761585
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(u'My Error Message', u'python', u'auto')
    except InterpreterDiscoveryRequiredError as err:
        assert(err.interpreter_name == 'python')
        assert(err.discovery_mode == 'auto')

# Generated at 2022-06-22 19:58:12.239914
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(u"Test Message", u"python-interpreter", u"auto_legacy")
    assert str(err) == u'Test Message', "Should be same message"

# Generated at 2022-06-22 19:58:16.630686
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err_msg = "error message"

    # set up
    exception = InterpreterDiscoveryRequiredError(err_msg, "python2", "auto_legacy_silent")

    # exercise
    result = str(exception)

    # verify
    assert result == err_msg

# Generated at 2022-06-22 19:58:22.912400
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError(
        "Error on module called", "python", "auto")
    assert e.interpreter_name == "python"
    assert e.discovery_mode == "auto"
    assert str(e) == "Error on module called"
    assert repr(e) == "Error on module called"



# Generated at 2022-06-22 19:58:26.125605
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    expected_value = u'InterpreterDiscoveryRequiredError: foo'
    assert InterpreterDiscoveryRequiredError(u'foo', None, None).__repr__() == expected_value



# Generated at 2022-06-22 19:58:27.425024
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # TODO: add tests
    raise NotImplementedError

# Generated at 2022-06-22 19:58:29.463678
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError('test message', 'test interpreter name', 'test discovery mode')
    assert str(e) == e.message
    assert repr(e) == e.message



# Generated at 2022-06-22 19:58:35.660547
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = u'Unable to detect Python interpreter for network_cli due to discovery mode auto_legacy'
    error = InterpreterDiscoveryRequiredError(msg, u'network_cli', u'auto_legacy')
    assert error.__repr__() == error.message

# Generated at 2022-06-22 19:58:44.359434
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    import unittest
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    class TestDiscoveryInterpreter(unittest.TestCase):
        def setUp(self):
            self.loader = DataLoader()
            self.inventory = InventoryManager(self.loader, sources=['localhost,'])
            self.variable_manager = VariableManager(self.loader, self.inventory)
            self.variable_manager.extra_vars = {
                'ansible_python_interpreter': '/usr/bin/python',  # default connection
            }
           

# Generated at 2022-06-22 19:58:52.870880
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
   try:
      raise InterpreterDiscoveryRequiredError('test', 'test', 'test')
   except Exception as e:
      assert isinstance(e, Exception)
      assert e.interpreter_name == 'test'
      assert e.discovery_mode == 'test'
      assert str(e) == 'test'
      assert repr(e) == 'test'

# Unit Test for Method discover_interpreter
import pytest
from ansible.module_utils.common.collections import ImmutableDict

# Generated at 2022-06-22 19:58:56.494525
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = 'Test message'
    inter_name = 'Test interpreter name'
    mode = 'Test discovery mode'
    test_error = InterpreterDiscoveryRequiredError(msg, inter_name, mode)
    assert msg == str(test_error)

# Generated at 2022-06-22 19:59:07.073420
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock

    action = mock.MagicMock()
    task_vars = dict()
    action._low_level_execute_command.return_value = {
        'stdout': u'''
        PLATFORM
        Linux
        FOUND
        /usr/bin/python
        ENDFOUND
        ''',
        'stdout_lines': [
            u'PLATFORM', u'Linux', u'FOUND', u'/usr/bin/python', u'ENDFOUND'
        ],
        'stderr': u'',
        'stderr_lines': [],
        'rc': 0,
        'invocation': {}
    }
    action._connection = mock.MagicMock()
    action._connection.has_pipelining = True


# Generated at 2022-06-22 19:59:12.791763
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'
    else:
        raise AssertionError()


# Generated at 2022-06-22 19:59:14.680599
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: test this (or move to a provisioning test at least)
    pass

# Generated at 2022-06-22 19:59:18.276732
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    x = InterpreterDiscoveryRequiredError("Python interpreter discovery test", "python", "auto")
    assert x.interpreter_name == "python"
    assert x.discovery_mode == "auto"

# Generated at 2022-06-22 19:59:25.339253
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = 'interpreter discovery required, but not supported'
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.message == message
    assert err.interpreter_name == interpreter_name
    assert err.discovery_mode == discovery_mode

# Generated at 2022-06-22 19:59:36.493835
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionModule

    class FakeTask:
        def __init__(self):
            self._connection = None
            self.args = {}
            self.action = 'command'
            self.module_args = ''

        def set_connection_info(self):
            pass

        def to_json(self):
            return {}

    class FakePlay:
        def __init__(self):
            self.hostvars = {'inventory_hostname': 'test_host'}
            self.become = False

    class FakePlayContext:
        def __init__(self):
            self.remote_addr = 'test_connection'
            self.become = False
            self.become_user = 'test_user'
            self.become_method = 'sudo'
            self.no_log

# Generated at 2022-06-22 19:59:39.300055
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('Some message', 'python', 'auto')
    assert repr(e) == 'Some message'

# Generated at 2022-06-22 19:59:40.396739
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-22 19:59:51.836524
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # import here to avoid dependency circularity issues
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.action_factory import ActionFactory
    from ansible.plugins.action import ActionBase

    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return task_vars

    class PlayContext():
        def __init__(self):
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.remote_addr = None

    class Connection():
        def __init__(self, transport='paramiko', remote_addr=None):
            self.transport = transport
            self.remote_addr = remote_addr

# Generated at 2022-06-22 19:59:56.767117
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from ansible.executor.discovery import InterpreterDiscoveryRequiredError
    error_obj = InterpreterDiscoveryRequiredError(message='',
                                                  interpreter_name=None,
                                                  discovery_mode=None)
    assert error_obj.__repr__() == error_obj.message

# Generated at 2022-06-22 20:00:03.571856
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    t_interpreter_name = 'python'
    t_discovery_mode = 'auto'

    try:
        raise(InterpreterDiscoveryRequiredError(interpreter_name=t_interpreter_name,
                                                discovery_mode=t_discovery_mode
                                               ))
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == t_interpreter_name
        assert e.discovery_mode == t_discovery_mode


# Generated at 2022-06-22 20:00:07.145524
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert repr(InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')) == 'message'


# Generated at 2022-06-22 20:00:13.588381
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    #Testing for constructor
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    msg = 'Interpretor discovery required for Python'
    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    assert str(err) == msg

# Test for discover_interpreter
# TODO : Mock _low_level_execute_command to return stderr, stdout

# Generated at 2022-06-22 20:00:17.215997
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(message='test message', interpreter_name='python', discovery_mode='auto')
    assert error.__repr__() == 'test message'


# Generated at 2022-06-22 20:00:20.018797
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert err.__str__() == "message"

# Generated at 2022-06-22 20:00:24.829928
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'Interpreter discovery required for python on host foo in mode auto'
    interpreter_name = 'python'
    discovery_mode = 'auto'

    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert message == exception.__str__()



# Generated at 2022-06-22 20:00:31.059557
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule as script_plugin

    task_vars = {}
    connection = type('obj', (object,), {'has_pipelining': False})()
    action = script_plugin(connection, 'path/to/library', 'module_args', task_vars=task_vars)
    # TODO: write more thorough test cases; for now, just make sure we can execute it without raising an exception
    discover_interpreter(action, 'python', 'auto', task_vars)

# Generated at 2022-06-22 20:00:36.978779
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # when
    error = InterpreterDiscoveryRequiredError(message="Test message", interpreter_name="python", discovery_mode="auto")

    # then
    str_output = str(error)
    assert "Test message" in str_output
    assert "python" in str_output
    assert "auto" in str_output

# Generated at 2022-06-22 20:00:47.486793
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible import context
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import os
    # since the API is constructed for CLI it expects certain options to always be set, named tuple 'fakes' the args parsing options object
    C.HOST_KEY_CHECKING = False
    C.DEFAULT_REMOTE_USER = 'root'
    context._init_global_context(C)

    # initialize needed objects
    loader = DataLoader()
    host

# Generated at 2022-06-22 20:00:52.024402
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():

    # Create an instance of InterpreterDiscoveryRequiredError with a message
    e = InterpreterDiscoveryRequiredError("message", "python", "auto")
    # assigned to variable a
    a = str(e)
    assert a == "message"


# Generated at 2022-06-22 20:00:59.493189
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Test the constructor by creating an InterpreterDiscoveryRequiredError object with specific message,
    # interpreter_name and discovery_mode.
    message = 'Missing interpreter, discovery required'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    # Check if the constructed object is an instance of the class InterpreterDiscoveryRequiredError.
    assert isinstance(e, InterpreterDiscoveryRequiredError)

# Generated at 2022-06-22 20:01:05.243535
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(
        message='Test InterpreterDiscoveryRequiredError',
        interpreter_name='python',
        discovery_mode='auto')

    assert error.message == 'Test InterpreterDiscoveryRequiredError'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

# Generated at 2022-06-22 20:01:17.758476
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os

    # test that distro-specific python works

# Generated at 2022-06-22 20:01:23.487123
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Discovery required for interpreter %s' % interpreter_name
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.message == message
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:01:25.559386
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError(
        "Exception message",
        "foobar",
        "baz",
    )
    assert str(err) == "Exception message"

# Generated at 2022-06-22 20:01:30.531706
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    ex = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy')
    assert ex.message == 'message'
    assert ex.interpreter_name == 'python'
    assert ex.discovery_mode == 'auto_legacy'

    assert repr(ex) == 'message'

# Generated at 2022-06-22 20:01:32.853211
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    print(InterpreterDiscoveryRequiredError('Msg:', 'python', 'auto'))



# Generated at 2022-06-22 20:01:34.256326
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy', {}) == u'/usr/bin/python'

# Generated at 2022-06-22 20:01:38.581152
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError

# Generated at 2022-06-22 20:01:42.478188
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError(message="test message", interpreter_name="python", discovery_mode="auto")
    assert exc.message == "test message"
    assert exc.interpreter_name == "python"
    assert exc.discovery_mode == "auto"


# Generated at 2022-06-22 20:01:46.316403
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(message='test error', interpreter_name='python', discovery_mode='auto_legacy_silent')
    assert err.__repr__() == 'test error'

# Generated at 2022-06-22 20:01:48.201922
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    exception = InterpreterDiscoveryRequiredError("message", interpreter_name, discovery_mode)

    assert to_native(repr(exception)) == "message"

# Generated at 2022-06-22 20:01:51.961944
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    my_idre = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    if my_idre.__str__() != "message":
        raise Exception("test_InterpreterDiscoveryRequiredError___str__ failed")

# Generated at 2022-06-22 20:01:59.274638
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: first use a real action with a localhost connection instead
    action = type('TestAction', (object,), {'_low_level_execute_command': type('Noop', (object,),
                                                                            {'__call__': lambda self, *args, **kwargs:
                                                                                {'stdout': u''},
                                                                             'has_pipelining': False})()})()


# Generated at 2022-06-22 20:02:04.639610
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_msg = "Error occurs"
    name = "name"
    disc_mode = "disc_mode"
    result = InterpreterDiscoveryRequiredError(error_msg, name, disc_mode)
    assert (repr(result) == error_msg)
    assert (str(result) == error_msg)


# Generated at 2022-06-22 20:02:11.849121
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = "Interpreter discovery required for \'%s\' on host %s, mode \'%s\'" % (interpreter_name, "127.0.0.1", discovery_mode)
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.message == message
    assert exception.interpreter_name == interpreter_name
    assert exception.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:02:19.278765
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Create InterpreterDiscoveryRequiredError instance with error message
    idr_error = InterpreterDiscoveryRequiredError(u'Required python', 'python', 'oldest')

    # Call method __repr__ of class InterpreterDiscoveryRequiredError
    repr_string = repr(idr_error)

    # AssertionError is raised if 'Required python' is not in repr_string
    assert 'Required python' in repr_string


# Generated at 2022-06-22 20:02:24.463908
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError(message="Example message", interpreter_name="python", discovery_mode="legacy")
    assert error.__str__() == "Example message"



# Generated at 2022-06-22 20:02:34.050948
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.plugins.action import ActionBase

    fake_action = type('ActionModule', (ActionBase,), {'ARG_SPEC': {'_ansible_interpreter_discovery_mode': {'type': 'str', 'choices': ['auto_legacy', 'auto', 'auto_legacy_silent', 'auto_silent', 'legacy', 'legacy_silent', 'silent', 'always']}}})

# Generated at 2022-06-22 20:02:35.042669
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-22 20:02:35.488539
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-22 20:02:47.123288
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        # Note: this import depends on the ansible root directory added to PYTHONPATH
        from ansible.executor.discovery import InterpreterDiscoveryRequiredError
    except ImportError:
        skip_if_not_root = True
    else:
        skip_if_not_root = False

    import os
    import doctest
    import platform
    import sys

    module_dir = os.path.dirname(os.path.abspath(__file__))
    root_dir = os.path.dirname(os.path.dirname(module_dir))

    if skip_if_not_root and os.getuid() != 0:
        # this test only makes sense if run as root, since we can't mock the python discovery (and we should not)
        return None


# Generated at 2022-06-22 20:02:54.989739
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This function is a bit of a black box; the only way to test it is to run it.
    task_vars = dict()

    from ansible.plugins.action import ActionBase
    action = ActionBase()

    # TODO: implement a standalone test fixture to pull in all of the interpreter discovery script data
    # TODO: also need to implement a mock os-release on the target
    # TODO: this doesn't even parse the results at the moment; we need tests, but that's probably a separate PR

    # one real case (with auto_legacy) to exercise that branch
    discover_interpreter(action, 'python', 'auto_legacy', task_vars)

    # one silent case assumed to have succeeded (without warnings)

# Generated at 2022-06-22 20:03:06.509202
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule
    import ansible.executor.discovery


# Generated at 2022-06-22 20:03:12.430001
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    import ansible.executor.module_common as module_common

    class TestAction(ActionBase):
        _module_cls = module_common.ModuleClsFactory()

    action = TestAction()

    my_vars = dict(
        ansible_python_interpreter='',
        inventory_hostname='test_host',
    )

    interpreter, warning = discover_interpreter(action, 'python', 'auto_legacy_silent', my_vars)

    assert interpreter == '/usr/bin/python'
    assert not warning

# Generated at 2022-06-22 20:03:15.476851
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ede = InterpreterDiscoveryRequiredError("error", "python", "auto")
    assert repr(ede) == "error"



# Generated at 2022-06-22 20:03:20.543890
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = DummyAction()
    task_vars = dict()
    result = discover_interpreter(action, 'python', 'auto', task_vars)
    print("Python: " + result)
    assert result == '/usr/bin/python'


# Generated at 2022-06-22 20:03:31.964028
# Unit test for function discover_interpreter
def test_discover_interpreter():
    example_bootstrap_python_list = ['python', '/usr/libexec/platform-python']

# Generated at 2022-06-22 20:03:34.822675
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert 'message' == error.__repr__()

# Generated at 2022-06-22 20:03:45.740944
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # If a host runs a python version which is not in the version_map,
    # it should use the first "known good" version
    action = {}
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = {}
    action._discovery_warnings = []
    action._low_level_execute_command = lambda x, sudoable=True, in_data=None: {
        'stdout': """PLATFORM
Linux
FOUND
/usr/bin/python3.8
ENDFOUND""",
        'stderr': ''
    }
    action.become = lambda **kwargs: None
    action.set_become = lambda **kwargs: None

# Generated at 2022-06-22 20:03:50.239142
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test case for python interpreter discovery
    try:
        discover_interpreter('python', 'auto')
    except Exception as ex:
        display.warning(msg=u'Unhandled error in Python interpreter discovery: {0}'.format(to_text(ex)))
        display.debug(msg=u'Interpreter discovery traceback:\n{0}'.format(to_text(format_exc())))
        return False
    return True

# Generated at 2022-06-22 20:03:55.872458
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exception = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert exception.message == 'message'
    assert exception.interpreter_name == 'interpreter_name'
    assert exception.discovery_mode == 'discovery_mode'
    assert str(exception) == 'message'
    assert repr(exception) == 'message'

# Generated at 2022-06-22 20:04:02.168829
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'some interpreter'
    discovery_mode = 'manual'
    e = InterpreterDiscoveryRequiredError(u'Interpreter %s requires discovery mode %s' % (interpreter_name, discovery_mode), interpreter_name,
                                          discovery_mode)
    assert 'Interpreter DiscoveryRequired' in repr(e)
