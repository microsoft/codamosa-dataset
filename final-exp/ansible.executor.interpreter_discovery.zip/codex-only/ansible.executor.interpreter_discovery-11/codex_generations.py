

# Generated at 2022-06-22 19:54:03.298669
# Unit test for function discover_interpreter
def test_discover_interpreter():
    raise NotImplementedError

# Generated at 2022-06-22 19:54:05.015565
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert str(InterpreterDiscoveryRequiredError('message', 'python', 'auto')) == 'message'

# Generated at 2022-06-22 19:54:12.823691
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            message="Testing: interpreter discovery is required for python",
            interpreter_name="python",
            discovery_mode="auto"
        )
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == "Testing: interpreter discovery is required for python"
        assert ex.interpreter_name == "python"
        assert ex.discovery_mode == "auto"
        assert str(ex) == "Testing: interpreter discovery is required for python"

# Generated at 2022-06-22 19:54:16.690920
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError(
        'This is the message',
        'python',
        'auto_legacy_silent')

    assert to_text(exception) == 'This is the message'


# Generated at 2022-06-22 19:54:19.239362
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('error message', 'python2', 'auto')
    assert e.__repr__() == e.__str__()


# Generated at 2022-06-22 19:54:25.116944
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six import StringIO
    import sys

    sys.stdout = StringIO()
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = dict()
    discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert True

# Generated at 2022-06-22 19:54:31.442524
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Create an instance of class InterpreterDiscoveryRequiredError
    x = InterpreterDiscoveryRequiredError(message='msg', interpreter_name='python', discovery_mode='auto')
    # Check if the instance x is of the class InterpreterDiscoveryRequiredError
    assert isinstance(x, InterpreterDiscoveryRequiredError)
    # Test __str__ method
    assert x.__str__() == 'msg'



# Generated at 2022-06-22 19:54:41.252945
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test unsupported interpreter
    try:
        discover_interpreter('action', 'php', 'auto', {'inventory_hostname': 'unknown'})
    except NotImplementedError:
        pass
    else:
        raise AssertionError(u'InterpreterDiscoveryRequiredError not raised')

    # Test none of the supported interpreters present
    try:
        discover_interpreter('action', 'python', 'auto', {'inventory_hostname': 'unknown'})
    except InterpreterDiscoveryRequiredError:
        pass
    else:
        raise AssertionError(u'InterpreterDiscoveryRequiredError not raised')

    # Test output on error

# Generated at 2022-06-22 19:54:41.872860
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-22 19:54:48.546149
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("m1", "python", "auto")
    except InterpreterDiscoveryRequiredError as ex:
        assert to_text('m1') == to_text(ex.message)
        assert to_text('python') == to_text(ex.interpreter_name)
        assert to_text('auto') == to_text(ex.discovery_mode)

# Generated at 2022-06-22 19:54:54.575186
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('discovery failed', 'python', 'auto_legacy_silent')
    except InterpreterDiscoveryRequiredError as e:
        assert str(e) == 'discovery failed'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto_legacy_silent'


# Generated at 2022-06-22 19:54:57.535756
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy_silent')
    assert repr(exception) == 'message'

# Generated at 2022-06-22 19:55:00.395047
# Unit test for function discover_interpreter
def test_discover_interpreter():
    result = discover_interpreter(None, 'python', 'auto_legacy_silent', {'ansible_python_interpreter': ''})
    assert result == '/usr/bin/python'
    pass

# Generated at 2022-06-22 19:55:04.763595
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('test message', 'python', 'auto')
    assert error.message == 'test message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'

# Generated at 2022-06-22 19:55:16.603874
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.script import ActionModule as ScriptAction
    from ansible.plugins.action.copy import ActionModule as CopyAction

    # test platform_python_map
    platform_python_map = C.config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP')
    platform_python_map['freebsd'] = {'11.2': u'/usr/local/bin/python'}
    platform_python_map['osx'] = {'10.13': u'/usr/bin/python'}

    # test script action for copy module

# Generated at 2022-06-22 19:55:21.733192
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # https://github.com/ansible/ansible/blob/devel/test/units/module_utils/test_interpreter_discovery.py#L1

    message = 'test message'
    interpreter_name = 'test-interpreter-name'
    discovery_mode = 'test-discovery-mode'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert to_text(exception) == message



# Generated at 2022-06-22 19:55:28.045767
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    idr = InterpreterDiscoveryRequiredError('ERROR MESSAGE', 'PYTHON', 'auto_legacy')
    assert idr.message == 'ERROR MESSAGE'
    assert idr.interpreter_name == 'PYTHON'
    assert idr.discovery_mode == 'auto_legacy'
    result = idr.__repr__()
    assert result == idr.message



# Generated at 2022-06-22 19:55:38.372639
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Discover interpreter for Linux
    action = type(Display)("Display", (object,), dict(debug=lambda message: display.debug(message=message)))
    task_vars = dict(inventory_hostname="testLinux", test_distro="RedHat", test_version="7.5")

    # Test for RedHat
    # Test for version 7.5 using auto_silent mode
    result = discover_interpreter(action, "python", "auto_silent", task_vars)
    assert result == u"/usr/bin/python2.7"

    # Test for version 7.5 using auto_legacy_silent mode
    result = discover_interpreter(action, "python", "auto_legacy_silent", task_vars)
    assert result == u"/usr/bin/python2.7"



# Generated at 2022-06-22 19:55:43.063863
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():

    # Setup
    exp_result = 'message_value'
    candidate = InterpreterDiscoveryRequiredError('message_value', 'interpreter_name_value', 'discovery_mode_value')

    # Exercise
    result = candidate.__repr__()

    # Verify
    assert result == exp_result


# Generated at 2022-06-22 19:55:50.852982
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():

    with pytest.raises(InterpreterDiscoveryRequiredError) as excinfo:
        raise InterpreterDiscoveryRequiredError('test', 1, 2)
    assert 'test' in str(excinfo.value)

    try:
        raise InterpreterDiscoveryRequiredError('test', 'first', 'second')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'first'
        assert e.discovery_mode == 'second'

# Generated at 2022-06-22 19:55:57.843335
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    exc = InterpreterDiscoveryRequiredError("Testing", "test_interpreter", "test_discovery_mode")

    #FUTURE: proper repr impl
    # assert 'Testing' in exc.__repr__()
    assert 'Testing' in exc.__str__()
    assert exc.interpreter_name == 'test_interpreter'
    assert exc.discovery_mode == 'test_discovery_mode'

# Generated at 2022-06-22 19:56:08.842478
# Unit test for function discover_interpreter
def test_discover_interpreter():

    action={'_discovery_warnings': []}
    task_vars = {}
    action._low_level_execute_command = lambda x, sudoable=False, in_data=None: {'stdout': x}
    action._connection = None
    action._connection.has_pipelining = True

    assert discover_interpreter(action, 'python', 'auto_silent', task_vars) == u'/usr/bin/python'

# Generated at 2022-06-22 19:56:12.111331
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter Discovery Required'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(error) == message

# Generated at 2022-06-22 19:56:15.720703
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(message='Test', interpreter_name='python', discovery_mode='auto')
    assert error.message == 'Test'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'


# Generated at 2022-06-22 19:56:20.009679
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='auto')
    expected = 'message'

    assert err.__repr__() == expected

# Generated at 2022-06-22 19:56:25.314253
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = to_text(u'This is the error message')
    interpreter_name = to_text(u'python')
    discovery_mode = to_text(u'auto')
    result = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    res = str(result)
    assert res == msg

# Generated at 2022-06-22 19:56:30.031985
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert interpreter_discovery_required_error.__str__() == "message"



# Generated at 2022-06-22 19:56:33.531917
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    err = InterpreterDiscoveryRequiredError('Test InterpreterDiscoveryRequiredError', 'python', 'auto')
    assert err.interpreter_name == 'python'
    assert err.discovery_mode == 'auto'

# Generated at 2022-06-22 19:56:37.827901
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(u'Test', u'python', u'auto_legacy_silent')
    assert error.message == u'Test'
    assert error.interpreter_name == u'python'
    assert error.discovery_mode == u'auto_legacy_silent'


# Generated at 2022-06-22 19:56:42.421397
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    try:
        raise InterpreterDiscoveryRequiredError('message', interpreter_name='python', discovery_mode='missing')
    except InterpreterDiscoveryRequiredError as e:
        res = e.__repr__()
        assertIsNotNone(res)
        assertEquals('message', res)


# Generated at 2022-06-22 19:56:43.380685
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # TODO: add tests for full discovery path
    pass

# Generated at 2022-06-22 19:56:48.167120
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "poodle"
    interp = "python"
    mode = "auto"
    exc = InterpreterDiscoveryRequiredError(msg, interp, mode)
    assert str(exc) == msg


# Generated at 2022-06-22 19:56:59.217056
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Python interpreter discovery is a two-step process. The first step is to do an uname and look
    # for any random Python to get the information we need. This is the first thing that is tested.
    action = FakeConnection()
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict()

    # A successful Linux test (which has a platform_dist_result)
    action.v_result = {u'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND', u'rc': 0}
    result1 = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert result1 == '/usr/bin/python'

    # A successful Mac test (which doesn't have a platform_dist_

# Generated at 2022-06-22 19:57:05.718462
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError("Testing the constructor of InterpreterDiscoveryRequiredError", "python", "auto")
    assert error.message == "Testing the constructor of InterpreterDiscoveryRequiredError"
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"



# Generated at 2022-06-22 19:57:10.419377
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Unit-test for method __repr__ of class InterpreterDiscoveryRequiredError"""
    InterpreterDiscoveryRequiredError_instance = InterpreterDiscoveryRequiredError(
        message="some message", interpreter_name="python", discovery_mode="auto")

    assert repr(InterpreterDiscoveryRequiredError_instance) == "some message"

# Generated at 2022-06-22 19:57:22.913524
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook import play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    def create_mock_action():
        mock_action = object()
        mock_action._debug = u''
        mock_action._discovery_warnings = []
        mock_action._low_level_execute_command = lambda py, sudo, piped: {'stdout': py, 'stderr': u''}
        _connection = object()
        _connection.has_pipelining = True
        mock_action._connection = _connection
        return mock_action

    def create_mock_play(action):
        mock_play = play.Play()
        mock_play.connection = 'local'
        mock_play.hosts = 'all'
        mock_play.bec

# Generated at 2022-06-22 19:57:30.564883
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    task_vars['ansible_python_interpreter'] = None
    task_vars['ansible_python_interpreter_discovery_mode'] = 'auto'

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins import module_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

# Generated at 2022-06-22 19:57:34.555551
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    maxDiff = None
    message = 'test_msg'
    interpreter_name = 'python3'
    discovery_mode = 'auto_legacy_silent'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert message == error.message
    assert interpreter_name == error.interpreter_name
    assert discovery_mode == error.discovery_mode


# Generated at 2022-06-22 19:57:46.008521
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    class Fake:
        class FakeAction:
            def __init__(self, playbook_name, playbook_path, connection):
                self.playbook_name = playbook_name
                self.playbook_path = playbook_path
                self.connection = connection
                self.name = 'fakeaction'

            def get_paths(self, variables=None):
                pass

            def _low_level_execute_command(self, cmd, options=None, in_data=None, sudoable=False, chdir=None):
                return dict(stdout=cmd)


# Generated at 2022-06-22 19:57:49.616278
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    InterpreterDiscoveryRequiredError("First error message", "python", "smart").__str__() == "First error message"
    InterpreterDiscoveryRequiredError("First error message", "python", "smart").__repr__() == "First error message"



# Generated at 2022-06-22 19:57:51.566351
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    assert repr(InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')) is 'message'

# Generated at 2022-06-22 19:57:54.350099
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    obj = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    actual = obj.__str__()
    expected = 'message'
    assert(actual == expected)



# Generated at 2022-06-22 19:57:56.473190
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_instance = InterpreterDiscoveryRequiredError('test_message', 'python', 'auto')
    result = str(test_instance)
    assert result == 'test_message'


# Generated at 2022-06-22 19:57:58.930540
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError('MESSAGE', 'python', 'auto')
    assert repr(err) == 'MESSAGE'



# Generated at 2022-06-22 19:58:04.996880
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error_message = "Error message"
    interpreter_name = "python"
    discovery_mode = "auto"
    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert error.__str__() == error_message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode


# Generated at 2022-06-22 19:58:06.500560
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: write
    display.vvv("FIXME: no unit tests")

# Generated at 2022-06-22 19:58:11.680347
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'This is a message'
    interpreter_name = 'The interpreter name'
    discovery_mode = 'The discovery mode'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert to_text(exception) == message
    assert to_text(exception.interpreter_name) == interpreter_name
    assert to_text(exception.discovery_mode) == discovery_mode

# Generated at 2022-06-22 19:58:15.103130
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert error.message == 'message'
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'
    assert str(error) == 'message'


# Generated at 2022-06-22 19:58:17.571043
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement!
    pass

# Generated at 2022-06-22 19:58:28.256201
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from ansible.module_utils.six import string_types
    exc = InterpreterDiscoveryRequiredError("The interpreter for 'python' is missing for this host. "
                                            "Ansible is using the discovered Python interpreter "
                                            "at /usr/bin/python, but future installation of another "
                                            "Python interpreter could change the meaning of that "
                                            "path. See https://docs.ansible.com/ansible/latest/reference_appendices/interpreter_discovery.html "
                                            "for more information",
                                            interpreter_name='python', discovery_mode='auto')
    assert isinstance(exc.__repr__(), string_types)
    assert exc.__repr__() == exc.__str__()

# Generated at 2022-06-22 19:58:30.473787
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('This is just a test', 'python', 'auto_legacy_silent')
    assert repr(error) == 'This is just a test'



# Generated at 2022-06-22 19:58:35.555824
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "Test Message"
    interp = "python"
    discovery = "auto_legacy_silent"
    err = InterpreterDiscoveryRequiredError(msg, interp, discovery)
    assert err.__repr__() == msg

# Generated at 2022-06-22 19:58:37.862644
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    InterpreterDiscoveryRequiredError(u'test message', u'python', u'legacy').__repr__()

# Generated at 2022-06-22 19:58:42.479461
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = u'This is the error message'
    interpreter_name = u'python'
    discovery_mode = u'pipeline_silent'

    test_obj = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name,
                                                 discovery_mode=discovery_mode)

    assert str(test_obj) == message

    del test_obj

# Generated at 2022-06-22 19:58:46.237485
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    test_object = InterpreterDiscoveryRequiredError("message","interpreter_name","discovery_mode")
    res = test_object.__str__()
    assert res == "message"

# Generated at 2022-06-22 19:58:50.154721
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # Arrange
    exception = InterpreterDiscoveryRequiredError("message", "python", "auto_silent")

    # Act
    res = exception.__repr__()

    # Assert
    assert res == exception.message


# Generated at 2022-06-22 19:58:54.664649
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == 'message'
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto'

# Generated at 2022-06-22 19:59:01.653261
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    tester = InterpreterDiscoveryRequiredError(
        u"Interpreter discovery required - explicitly set python interpreter not found and interpreter auto_legacy_silent discovery mode not configured",
        u"python", u"auto_legacy_silent")

    res = repr(tester)

    assert res == u"Interpreter discovery required - explicitly set python interpreter not found and interpreter auto_legacy_silent discovery mode not configured", "InterpreterDiscoveryRequiredError instance wasn't properly represented. Result was: " + res

# Generated at 2022-06-22 19:59:07.449755
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'message'
    exception_obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception_obj.__repr__() == exception_obj.message


# Generated at 2022-06-22 19:59:17.309991
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # For now there is no way to mock a remote system and check for the fallback.
    assert discover_interpreter(None, 'python', 'legacy', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'legacy_silent', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', None) == u'/usr/bin/python'

    try:
        discover_interpreter(None, 'python', 'smart', None)
        assert False, "Did not raise InterpreterDiscoveryRequiredError"
    except InterpreterDiscoveryRequiredError:
        pass

# Generated at 2022-06-22 19:59:25.755720
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_InterpreterDiscoveryRequiredError_obj = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert test_InterpreterDiscoveryRequiredError_obj.message == 'message'
    assert test_InterpreterDiscoveryRequiredError_obj.interpreter_name == 'interpreter_name'
    assert test_InterpreterDiscoveryRequiredError_obj.discovery_mode == 'discovery_mode'



# Generated at 2022-06-22 19:59:37.471470
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # The purpose of this test is to make sure that the interpreter discovery works
    # even when code changes and will not be changed again in future.
    # The test uses the combined fallback and default configuration, which is
    # the most common and covers the basic functionality. If this configuration
    # is changed, then the test must also be changed.
    # The test will always pass with the default configuration, even if the
    # functionality is broken.
    from ansible.executor import task_executor

    # Initialize the config with the minimum required properties
    C.config = object()
    C.config.DEFAULT_MODULE_INTERPRETER = 'python'
    C.config.DEFAULT_INTERNAL_POLL_INTERVAL = 0.1
    C.config.DEFAULT_KEEP_REMOTE_FILES = True

# Generated at 2022-06-22 19:59:42.199315
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(
        "message",
        "interpreter_name",
        "discovery_mode"
    )
    assert interpreter_discovery_required_error.__str__() == "message"

# Generated at 2022-06-22 19:59:52.180460
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "auto"

    # Test with message
    test_obj = InterpreterDiscoveryRequiredError("test", interpreter_name, discovery_mode)
    assert test_obj.message == "test"
    assert test_obj.interpreter_name == interpreter_name
    assert test_obj.discovery_mode == discovery_mode
    assert str(test_obj) == "test"

    # Test without message
    test_obj = InterpreterDiscoveryRequiredError(None, interpreter_name, discovery_mode)
    assert test_obj.message is None
    assert test_obj.interpreter_name == interpreter_name
    assert test_obj.discovery_mode == discovery_mode
    assert str(test_obj) is None

# Generated at 2022-06-22 19:59:57.145885
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = "Interpreter discovery required for python on host testhost"
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert err.__str__() == message


# Generated at 2022-06-22 20:00:02.543676
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with pytest.raises(InterpreterDiscoveryRequiredError) as discovery_error:
        raise InterpreterDiscoveryRequiredError('Wrong interpreter', 'python', 'auto_legacy_silent')
    assert discovery_error.value.interpreter_name == 'python'
    assert discovery_error.value.discovery_mode == 'auto_legacy_silent'

# Generated at 2022-06-22 20:00:14.455388
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    dist_collector = DistributionFactCollector()
    dist_fact = dist_collector.get_facts(dict())
    task_vars = {
        'ansible_distribution': 'Ubuntu',
        'ansible_distribution_major_version': '16',
        'ansible_distribution_version': '16.04',
        'ansible_facts': dist_fact,
        'ansible_python_interpreter': '/usr/bin/python',
    }
    # Run discover_interpreter for interpreter_name=python, discovery_mode=auto_legacy_silent
    interp = discover_interpreter(None, 'python', 'auto_legacy_silent', task_vars)

# Generated at 2022-06-22 20:00:17.990351
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert e.__str__() == e.message

# Generated at 2022-06-22 20:00:29.706894
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import unfrackpath
    from ansible.utils.path import unfrackpath as path_unfrackpath

    action = ActionBase()

    ACTION_TEST_ENV = action._shared_loader_obj.module_loader.get_basedir()
    if not ACTION_TEST_ENV:
        ACTION_TEST_ENV = action._shared_loader_obj.module_loader.get_basedir()
    action._shared_loader_obj.module_loader.set_env(ACTION_TEST_ENV)
    action._loader.set_basedir(ACTION_TEST_ENV)

# Generated at 2022-06-22 20:00:41.333558
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TestAction:
        _low_level_execute_command = None
        _connection = None
        _discovery_warnings = []

        def run(self, low_level_execute_command, _connection):
            self._low_level_execute_command = low_level_execute_command
            self._connection = _connection

    test_action = TestAction()

    # Test case 1:
    # Darwin - should return /usr/bin/python
    class TestConnection1:
        has_pipelining = False

        def run(self, low_level_execute_command, has_pipelining):
            self.has_pipelining = has_pipelining

    test_connection = TestConnection1()

# Generated at 2022-06-22 20:00:46.080038
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'The value of the message attribute.'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert repr(error) == message



# Generated at 2022-06-22 20:00:51.967838
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto'
    test_message = "Unable to discover Python interpreter for host 'test_host'"

    error = InterpreterDiscoveryRequiredError(test_message,
                                              test_interpreter_name,
                                              test_discovery_mode)

    assert error.__repr__() == error.message

# Generated at 2022-06-22 20:00:56.754919
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'message'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    obj = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert obj.__repr__() == message
    del obj


# Generated at 2022-06-22 20:01:06.141417
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error_message = u'Interpreter discovery required but not supported for py3'
    interpreter_name = 'py3'
    discovery_mode = u'auto_legacy_silent'

    error = InterpreterDiscoveryRequiredError(error_message, interpreter_name, discovery_mode)
    assert (isinstance(error, InterpreterDiscoveryRequiredError))

    assert (error.interpreter_name == interpreter_name)
    assert (error.discovery_mode == discovery_mode)

    assert (str(error) == error_message)
    assert (repr(error) == error_message)


# Generated at 2022-06-22 20:01:10.855138
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError(
        'hello',
        interpreter_name='python',
        discovery_mode='auto',
    )

    assert exception.__str__() == 'hello'

# Generated at 2022-06-22 20:01:13.017582
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exc = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert repr(exc) == 'message'

# Generated at 2022-06-22 20:01:24.642789
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.connection import ConnectionBase
    class TestActionBase(ActionBase):
        pass

    class TestConnectionBase(ConnectionBase):
        pass

    class Runner:
        def __init__(self, connection, module_name, play_context=None, loader=None,
                     shared_loader_obj=None, path_info=None, var_manager=None):
            self.connection = connection
            self.module_name = module_name
            self.play_context = play_context
            self.loader = loader
            self.shared_loader_obj = shared_loader_obj
            self.path_info = path_info
            self.var_manager = var_manager


# Generated at 2022-06-22 20:01:26.736576
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    error = InterpreterDiscoveryRequiredError("message", "python", "auto")
    assert "message" == str(error)

# Generated at 2022-06-22 20:01:32.499710
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    res = to_text(err)
    assert 'message' == res

    err = InterpreterDiscoveryRequiredError('message', 'interpreter_name', u'ñ')
    res = to_text(err)
    assert 'message' == res

# Generated at 2022-06-22 20:01:36.565021
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "The required interpreter for this task is not available on the target"
    idre = InterpreterDiscoveryRequiredError(message=msg, interpreter_name='python', discovery_mode='auto_legacy')
    assert idre.__str__() == msg


# Generated at 2022-06-22 20:01:41.390250
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    # test for exception InterpreterDiscoveryRequiredError
    error_msg = u'Python interpreter discovery required'
    interpreter_name = u'python'
    discovery_mode = u'auto_silent'
    curr_exception = InterpreterDiscoveryRequiredError(error_msg, interpreter_name, discovery_mode)
    assert repr(curr_exception) == error_msg

# Generated at 2022-06-22 20:01:48.713767
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # Test __str__ with discovery mode 'auto_legacy_silent'.
    INTERPRETER_NAME = 'python'
    DISCOVERY_MODE = 'auto_legacy_silent'
    MESSAGE = 'foo'
    e = InterpreterDiscoveryRequiredError(MESSAGE, INTERPRETER_NAME, DISCOVERY_MODE)
    actual_result = str(e)
    assert actual_result == MESSAGE

    # Test __str__ with discovery mode 'auto_legacy'.
    DISCOVERY_MODE = 'auto_legacy'
    e = InterpreterDiscoveryRequiredError(MESSAGE, INTERPRETER_NAME, DISCOVERY_MODE)
    actual_result = str(e)
    assert actual_result == MESSAGE

    # Test __str__ with discovery

# Generated at 2022-06-22 20:01:53.089373
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    message = "Interpreter discovery is required to run this task"
    idre = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert idre.__str__() == idre.message

# Generated at 2022-06-22 20:02:06.509163
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''Test function discover_interpreter'''
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext

    class MockAction(object):
        def __init__(self):
            self._connection = None
            self._discovery_warnings = []
            self._play_context = PlayContext()

        def _low_level_execute_command(self, cmd, sudoable, in_data=None):
            res = TaskResult(host=None, task=None, return_data={'cmd': cmd})

# Generated at 2022-06-22 20:02:09.581830
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'


# Generated at 2022-06-22 20:02:17.385773
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # support Python 3
    try:
        from unittest import mock
    except ImportError:
        import mock

    def unit_test_bootstrap(bootstrap_python_list):
        def side_effect(*args, **kwargs):
            command_list = ["command -v '%s'" % py for py in bootstrap_python_list]
            shell_bootstrap = "echo PLATFORM; uname; echo FOUND; {0}; echo ENDFOUND".format('; '.join(command_list))
            if shell_bootstrap in args[0]:
                return dict(stdout='')
            return dict(stdout='', stderr='The command failed!')
        return side_effect


# Generated at 2022-06-22 20:02:18.865251
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e = InterpreterDiscoveryRequiredError(to_text('test message'), 'python', 'auto')
    assert str(e) == 'test message'

# Generated at 2022-06-22 20:02:23.433948
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exc = InterpreterDiscoveryRequiredError('some message', 'some interpreter', 'some discovery mode')
    assert to_text(exc) == 'some message'



# Generated at 2022-06-22 20:02:26.829714
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required for host xyz'
    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(e) == message

# Generated at 2022-06-22 20:02:29.656519
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    target = InterpreterDiscoveryRequiredError('my message', 'my interpreter name', 'my discovery mode')
    expected = 'my message'
    assert repr(target) == expected

# Generated at 2022-06-22 20:02:31.992237
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_discovery_required_exception = InterpreterDiscoveryRequiredError("message", "python", "force")
    assert interpreter_discovery_required_exception.__repr__() == "message"



# Generated at 2022-06-22 20:02:36.601571
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    search_result = 'Interpreter Discovery is required for the interpreter: python'
    error = InterpreterDiscoveryRequiredError(message=search_result, interpreter_name='python', discovery_mode='auto')
    assert search_result in error.__str__()

# Generated at 2022-06-22 20:02:43.441661
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    '''Unit test for method __str__ of class InterpreterDiscoveryRequiredError'''
    message = "Python interpreter discovery required"
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    idre = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert isinstance(idre.__str__(), str)
    assert isinstance(idre.__repr__(), str)

# Generated at 2022-06-22 20:02:48.922289
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    discovery_mode = 'auto_legacy'
    interpreter_name = 'python'
    host = 'localhost'
    message = '{0} interpreter discovery required for host {1}'.format(interpreter_name, host)
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert repr(error) == message

# Generated at 2022-06-22 20:03:00.485697
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Instantiate a module class to be used for testing
    module_args = dict(
        a=1,
        b=2
    )
    action = dict(
        module='test_utils.module',
        args=module_args
    )
    task = dict(
        action=action,
        register=None
    )
    play = dict(
        tasks=[task]
    )
    connection = dict(
        environ={},
        # FUTURE: replace with a stub implementation of a connection class
        has_pipelining=False
    )
    mock_loader = dict()


# Generated at 2022-06-22 20:03:06.747343
# Unit test for function discover_interpreter
def test_discover_interpreter():

    discovery_mode = 'auto'
    platform_python_map = {
        'redhat': {'6.0': '/usr/bin/python2.6', '7.0': '/usr/bin/python2.7', '8.0': '/usr/libexec/platform-python'},
        'debian': {'9.0': '/usr/bin/python3', '8.0': '/usr/bin/python3', '7.0': '/usr/bin/python2.7'}
    }
    bootstrap_python_list = ['/usr/bin/python', '/usr/bin/python3']


# Generated at 2022-06-22 20:03:10.863160
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = 'message'
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.message == message
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:03:15.732132
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    x = InterpreterDiscoveryRequiredError('testing', 'python', 'auto_silent')
    assert x.message == 'testing'
    assert x.interpreter_name == 'python'
    assert x.discovery_mode == 'auto_silent'


# Generated at 2022-06-22 20:03:21.078791
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    e = InterpreterDiscoveryRequiredError('message', 'interpreter', 'discovery')
    assert e.interpreter_name == 'interpreter'
    assert e.discovery_mode == 'discovery'
    assert str(e) == 'message'
    assert repr(e) == 'message'

# Generated at 2022-06-22 20:03:26.320418
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError(
            "message", "interpreter_name", "discovery_mode"
        )
    except InterpreterDiscoveryRequiredError as error:
        test = (
            error.message == "message" and
            error.interpreter_name == "interpreter_name" and
            error.discovery_mode == "discovery_mode"
        )
    assert test == True

# Generated at 2022-06-22 20:03:34.760571
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction(object):
        def __init__(self, module_name, no_log_results=None, installer_data=None, action_remote_tmp=None,
                     action_results=None, action_runner_on_failed=None, interpreter_name=None,
                     _eject_device=None, _play_context=None):
            self.module_name = module_name
            self.no_log_results = no_log_results
            self.installer_data = installer_data
            self.action_remote_tmp = action_remote_tmp
            self.action_results = action_results
            self.action_runner_on_failed = action_runner_on_failed
            self._discovery_warnings = []
            self.interpreter_name = interpreter_name

# Generated at 2022-06-22 20:03:45.666138
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This test is based on a real-world example from a docker image
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    # -- Unit test for discover_interpreter starts --
    # test a real-world container that returns a valid os-release
    # and where no python is installed
    ansible_facts = {'system': {'distribution': {}, 'distribution_version': '', 'distribution_major_version': ''}}
    # 3.2 returns None, 3.3 throws

# Generated at 2022-06-22 20:03:49.062176
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("test", "python", "auto")
    except InterpreterDiscoveryRequiredError as error:
        assert error.interpreter_name == "python"
        assert error.discovery_mode == "auto"


# Generated at 2022-06-22 20:03:53.268184
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python3"
    discovery_mode = "auto"

    err = InterpreterDiscoveryRequiredError("Error Message", interpreter_name, discovery_mode)
    assert err.__repr__() == "Error Message"



# Generated at 2022-06-22 20:04:04.546896
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict