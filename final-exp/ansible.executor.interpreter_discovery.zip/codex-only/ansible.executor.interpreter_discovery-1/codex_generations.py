

# Generated at 2022-06-22 19:54:04.188707
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError("Invalid or unsupported interpreter for module", "python", "auto")
    assert repr(error) == error.message

# Generated at 2022-06-22 19:54:11.257716
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'test'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode


# Generated at 2022-06-22 19:54:16.837929
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError('test message', 'python', 'auto_legacy_silent')
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto_legacy_silent'
    assert str(error) == 'test message'



# Generated at 2022-06-22 19:54:20.853224
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    assert ex.__str__() == "message"


# Generated at 2022-06-22 19:54:27.216610
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'This is an error message'
    interpreter_name = 'python'
    discovery_mode = 'force'
    ex = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert ex.message == message
    assert ex.interpreter_name == interpreter_name
    assert ex.discovery_mode == discovery_mode
    assert str(ex) == message
    assert repr(ex) == message


# Generated at 2022-06-22 19:54:31.335033
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    message = 'this is a test'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)


# Generated at 2022-06-22 19:54:39.936241
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = "python3"
    discovery_mode = "auto"
    message = "No python interpreters found for host 127.0.0.1 (tried /usr/bin/python3,/usr/bin/python,/usr/bin/python2,/usr/bin/python3.6,/usr/bin/python3.5,/usr/bin/python3.4,/usr/bin/python2.7,/usr/bin/python3.7,/usr/bin/python3.8)"

    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(error) == message



# Generated at 2022-06-22 19:54:47.229060
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    print('test_InterpreterDiscoveryRequiredError__str__')
    error = InterpreterDiscoveryRequiredError("This is a test", "python", "auto_silent")
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto_silent'
    assert error.__str__() == 'This is a test'
    assert error.__repr__() == 'This is a test'



# Generated at 2022-06-22 19:54:51.670191
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    data = {
        'InterpreterDiscoveryRequiredError': 'InterpreterDiscoveryRequiredError',
        'interpreter_name': 'interpreter_name',
        'discovery_mode': 'discovery_mode',
    }
    test = InterpreterDiscoveryRequiredError(**data)
    assert test.__str__() == data.get('InterpreterDiscoveryRequiredError')
    assert test.__repr__() == data.get('InterpreterDiscoveryRequiredError')
    assert test.interpreter_name == data.get('interpreter_name')
    assert test.discovery_mode == data.get('discovery_mode')

# Generated at 2022-06-22 19:55:02.957013
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {}
    action = {}
    action._low_level_execute_command = lambda cmd, sudoable, in_data=None: {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'}
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    task_vars['inventory_hostname'] = 'host1'
    action._discovery_warnings = []

    # auto_legacy_silent
    discovered_interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert discovered_interpreter == '/usr/bin/python'

    # auto_legacy
    discovery_mode = 'auto_legacy'
    task_vars

# Generated at 2022-06-22 19:55:08.689507
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto"
    message = 'Interpreter discovery required for {0} (discovery_mode={1})'.format(interpreter_name, discovery_mode)
    # check if the representation contains the expected message
    assert repr(InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)) == message

# Generated at 2022-06-22 19:55:20.838113
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.module_common

    ansible.executor.module_common.register_ansible_module_finder()
    import ansible.plugins.loader

    module_finder = ansible.plugins.loader.find_plugin

    module_name = 'setup'

    setup_module = module_finder.find_plugin(module_name, mod_type='.ps1', ignore_deprecated=True)

    assert not setup_module

    interpreter_name = 'powershell'

    assert interpreter_name in C.config.get_config_value('INTERPRETER_DISCOVERY_MAP')

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    variable_manager = VariableManager()

    host_list = ['localhost']

    inventory = Inventory

# Generated at 2022-06-22 19:55:26.878304
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    value_1 = 'Error has occurred'
    value_2 = 'python'
    value_3 = 'auto_silent'
    err = InterpreterDiscoveryRequiredError(value_1, value_2, value_3)
    assert err.message == value_1
    assert err.interpreter_name == value_2
    assert err.discovery_mode == value_3

# Generated at 2022-06-22 19:55:33.868543
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    # Constructor of class InterpreterDiscoveryRequiredError
    with pytest.raises(Exception) as excinfo:
        raise InterpreterDiscoveryRequiredError("test message", "test_interpreter_name", "test_discovery_mode")
    assert excinfo.value.interpreter_name == 'test_interpreter_name'
    assert excinfo.value.discovery_mode == 'test_discovery_mode'

# Generated at 2022-06-22 19:55:40.771983
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    test_str = list()
    test_str.append("This is an example of an error message")
    #test_str.append("This is an example of an error message")
    test_str.append("interpreter_name: 'python'")
    test_str.append("discovery_mode: 'auto'")

    e = InterpreterDiscoveryRequiredError(" ".join(test_str), "python", "auto")

    assert e.interpreter_name == "python"
    assert e.discovery_mode == "auto"
    assert to_text(e) == " ".join(test_str)

# Generated at 2022-06-22 19:55:53.210025
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.executor.task_result import TaskResult
    import ansible.executor.module_common as module_common
    from ansible.playbook.play_context import PlayContext

    m_av = AnsibleModule(
        argument_spec=dict(),
    )
    task_result = TaskResult('test.test_discover_interpreter', 'test.test_discover_interpreter')
    task_result._host = 'test.test_discover_interpreter'
    task_result.connection = 'test.test_discover_interpreter'

# Generated at 2022-06-22 19:55:56.512032
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('foo', 'bar', 'baz')
    assert str(err) == 'foo'

# Generated at 2022-06-22 19:55:59.207548
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    instance = InterpreterDiscoveryRequiredError(message='message', interpreter_name='py', discovery_mode='legacy')
    assert instance.__repr__() == 'message'

# Generated at 2022-06-22 19:56:05.213705
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError("message", "interpreter_name", "discovery_mode")
    except InterpreterDiscoveryRequiredError as e:
        assert(e.message == "message")
        assert(e.interpreter_name == "interpreter_name")
        assert(e.discovery_mode == "discovery_mode")

# Generated at 2022-06-22 19:56:15.596494
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    use_msg = u'Python interpreter discovery is required for this module. Pass `force_python: True` to ignore this warning.'
    disc_ex_norm = InterpreterDiscoveryRequiredError(use_msg, interpreter_name='python', discovery_mode='auto')
    assert disc_ex_norm.message == use_msg
    assert str(disc_ex_norm) == use_msg

    use_msg = u'Python interpreter discovery is required for this module.'
    disc_ex_extra = InterpreterDiscoveryRequiredError(use_msg, interpreter_name='python3', discovery_mode='auto')
    assert disc_ex_extra.message == use_msg
    assert str(disc_ex_extra) == u'Python interpreter discovery is required for this module for interpreter python3.'


# Generated at 2022-06-22 19:56:19.430540
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interp_name = 'python'
    discovery_mode = 'auto'
    message = 'There is no system Python on this host, and interpreter discovery mode is not set to "auto_silent".'
    err = InterpreterDiscoveryRequiredError(message, interp_name, discovery_mode)
    assert repr(err) == message

# Generated at 2022-06-22 19:56:24.435429
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('22', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.message == '22'
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'
        str(e)

# Generated at 2022-06-22 19:56:29.529644
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interp_err = InterpreterDiscoveryRequiredError("error msg", "python", "auto_legacy")
    assert interp_err.interpreter_name == "python"
    assert interp_err.discovery_mode == "auto_legacy"
    assert interp_err.message == "error msg"

# Generated at 2022-06-22 19:56:32.540329
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError(
        'message',
        interpreter_name='python',
        discovery_mode='auto'
    )
    assert repr(error) == 'message'

# Generated at 2022-06-22 19:56:36.092873
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    err = InterpreterDiscoveryRequiredError(
        message = "message",
        interpreter_name = "python3",
        discovery_mode = "auto_legacy",
    )
    assert str(err) == "message"

# Generated at 2022-06-22 19:56:43.303294
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:56:52.126523
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = "python"
    discovery_mode = "auto"
    error_msg = 'skipping task'
    exception = InterpreterDiscoveryRequiredError(message=error_msg, interpreter_name=interpreter_name,
                                                  discovery_mode=discovery_mode)
    expected_msg = "skipping task. See https://docs.ansible.com/ansible/latest/reference_appendices/interpreter_discovery.html for more information"
    assert exception.__repr__() == expected_msg

# Generated at 2022-06-22 19:56:59.006025
# Unit test for function discover_interpreter

# Generated at 2022-06-22 19:57:07.039802
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter discovery required for {0} with discovery_mode {1}'.format(interpreter_name, discovery_mode)
    interpreter_discovery_required_error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert interpreter_discovery_required_error.__repr__() == message

# Generated at 2022-06-22 19:57:17.488834
# Unit test for function discover_interpreter
def test_discover_interpreter():
    distro_data = (
        u"PRETTY_NAME=\u201eRed Hat Enterprise Linux Server 6.8 (Santiago)\u201d\nNAME=\u201eRed Hat Enterprise Linux\u201d"
        u"\nVERSION=\u201e6.8 (Santiago)\u201d\nID=\u201eredhat\u201d\nVERSION_ID=\u201e6.8\u201d\nPRETTY_NAME="
        u"\u201eRed Hat Enterprise Linux Server 6.8 (Santiago)\u201d"
    )

    # Mock class to test discover_interpreter
    class BaseActionModule(object):
        def __init__(self):
            self._discovery_warnings = []
            self._low_level_execute_command_result = {}

# Generated at 2022-06-22 19:57:19.614366
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    msg = "Discovery required for python"
    interpreter_name = "python"
    discovery_mode = "auto"
    err = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert str(err) == msg

# Generated at 2022-06-22 19:57:24.044262
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'discovery failed'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert str(exception) == message


# Generated at 2022-06-22 19:57:29.495982
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('Error: please provide an interpreter name', '', '')
    assert e.interpreter_name == ''
    assert e.discovery_mode == ''
    assert str(e) == 'Error: please provide an interpreter name'

# Unit tests for function _get_linux_distro

# Generated at 2022-06-22 19:57:42.753401
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict(
        ansible_connection='connection',
        ansible_python_interpreter='interpreter',
        ansible_host='host'
    )

    class action(object):
        _display = display
        _connection = object()
        _low_level_execute_command = object()

    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'

    expected_result = 'expected_result'

    def mocked_version_fuzzy_match(version, version_map):
        return expected_result

    def mocked_get_linux_distro(platform_info):
        return 'distro', 'version'

    _version_fuzzy_match = discover_interpreter._version_fuzzy_match
    _get_linux_distro = discover_

# Generated at 2022-06-22 19:57:44.228884
# Unit test for function discover_interpreter
def test_discover_interpreter():
    discover_interpreter()

# Generated at 2022-06-22 19:57:50.399221
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    message = 'ERROR: python interpreter discovery not implemented for "auto" mode yet.'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    try:
        raise InterpreterDiscoveryRequiredError(message, 'python', 'auto')
    except InterpreterDiscoveryRequiredError as err:
        assert err.message == message
        assert err.interpreter_name == interpreter_name
        assert err.discovery_mode == discovery_mode



# Generated at 2022-06-22 19:57:58.148703
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import copy
    import test.utils.module_runner
    import ansible.module_utils.basic
    import ansible.module_utils.connection

    # setup our modules
    for module_name in ('command', 'script', 'raw'):
        test.utils.module_runner.add_module(ansible.module_utils.basic.AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
            mutually_exclusive=[],
            required_together=[],
            bypass_checks=False))

    # setup test environment
    socket_path = test.utils.module_runner.get_default_socket_path()
    conn = ansible.module_utils.connection.Connection(socket_path)

# Generated at 2022-06-22 19:57:59.745323
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    ex = InterpreterDiscoveryRequiredError('message', 'python', 'auto')
    assert str(ex) == 'message'

# Generated at 2022-06-22 19:58:03.595468
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError("message", "interpreter", "discovery_mode")
    assert u"message" == exception.__str__()



# Generated at 2022-06-22 19:58:07.055851
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    foo = InterpreterDiscoveryRequiredError("An error message", "python", "auto_legacy")
    print("Interpreter name: {0}".format(foo.interpreter_name))


# Generated at 2022-06-22 19:58:14.807385
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    e1 = InterpreterDiscoveryRequiredError(u'Failed, as expected', u'python', u'auto')
    e2 = InterpreterDiscoveryRequiredError(u'Failed, as expected', u'python', u'auto_legacy')
    e3 = InterpreterDiscoveryRequiredError(u'Failed, as expected', u'python', u'auto_legacy_silent')
    e4 = InterpreterDiscoveryRequiredError(u'Failed, as expected', u'python', u'auto_silent')

    assert(str(e1) == 'Failed, as expected')
    assert(str(e2) == 'Failed, as expected')
    assert(str(e3) == 'Failed, as expected')
    assert(str(e4) == 'Failed, as expected')

# Unit

# Generated at 2022-06-22 19:58:21.930654
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    with pytest.raises(Exception) as exc:
        raise InterpreterDiscoveryRequiredError('message', 'python', 'auto_legacy')

    assert str(exc.value) == 'message'
    assert exc.value.interpreter_name == 'python'
    assert exc.value.discovery_mode == 'auto_legacy'

# Generated at 2022-06-22 19:58:29.329795
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name='python'
    discovery_mode='auto_legacy_silent'
    message='Interpreter discovery required for python on connection localhost'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert exception.interpreter_name == interpreter_name, 'Interpreter name is not equal to python'
    assert exception.discovery_mode == discovery_mode, 'Interpreter discovery mode is not equal to auto_legacy_silent'
    assert exception.message == message, 'Interpreter discovery message is not equal to '+message

# Generated at 2022-06-22 19:58:35.099406
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'some message'
    c = InterpreterDiscoveryRequiredError(message, 'python', 'auto_silent')
    assert c.__str__() == message
    assert str(c) == message


# Generated at 2022-06-22 19:58:39.110771
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    object = InterpreterDiscoveryRequiredError("this is an error message", "python", "auto")
    assert object.interpreter_name == 'python'
    assert object.discovery_mode == 'auto'
    assert str(object) == "this is an error message"

# Generated at 2022-06-22 19:58:44.063030
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'This is an error message.'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert error.message == message
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode



# Generated at 2022-06-22 19:58:47.378619
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    exception = InterpreterDiscoveryRequiredError('test_message', 'python', 'auto')
    expected_result = 'test_message'

    assert exception.__str__() == expected_result

# Generated at 2022-06-22 19:58:50.305567
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    repr_object = InterpreterDiscoveryRequiredError('message', 'python', 'auto').__repr__()
    assert repr_object == 'message'


# Generated at 2022-06-22 19:59:00.281960
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {}
    # Need to import action plugins here, or we get Could not find action plugin Error
    from ansible.plugins.action import ActionBase
    action = ActionBase(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Test normal case
    task_vars['inventory_hostname'] = 'test'
    task_vars['ansible_connection'] = 'local'
    task_vars['ansible_interpreter_python'] = '/usr/bin/python'
    assert discover_interpreter(action, 'python', 'auto', task_vars) == '/usr/bin/python'
    assert not action._discovery_warnings
    # Test use_default mode

# Generated at 2022-06-22 19:59:03.807382
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    err = InterpreterDiscoveryRequiredError('failure', 'python', 'auto_legacy_silent')
    assert 'failure' == str(err)

# Generated at 2022-06-22 19:59:15.954238
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase

    # action in order to have a _load_name_to_path function and _shared_loader_obj attribute
    class ActionMock(ActionBase):
        def run(self, tmp=None, task_vars=None):
            pass

    # context in order to have a _connection variable
    class ConnectionMock():
        def has_pipelining(self):
            pass

    # context in order to have a _task variable
    class TaskMock():
        name = 'shell'

    # context in order to have a _loader variable
    class LoaderMock():
        pass

    context = PlayContext()

# Generated at 2022-06-22 19:59:28.169514
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    from ansible.module_utils import basic
    from ansible.compat.tests import unittest

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action.copy import ActionModule as CopyActionModule

    class TestInterpreterDiscovery:

        def __init__(self, runner):
            self.runner = runner
            self.connection = runner.connection

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            if in_data:
                return {'stdout': self._low_level_in_data_exec(cmd)}


# Generated at 2022-06-22 19:59:30.833827
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    with InterpreterDiscoveryRequiredError(message="test message", interpreter_name="python", discovery_mode="auto") \
            as exc:
        assert str(exc) == "test message"

# Generated at 2022-06-22 19:59:32.187979
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    assert InterpreterDiscoveryRequiredError.__str__(None) is not None

# Generated at 2022-06-22 19:59:35.125296
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ex = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='auto')
    assert ex.__repr__() == 'message'

# Generated at 2022-06-22 19:59:39.352914
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    message = 'Test message'
    error = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert(error.message == message)
    assert(error.interpreter_name == interpreter_name)
    assert(error.discovery_mode == discovery_mode)
    assert(error.__str__() == message)


# Generated at 2022-06-22 19:59:43.199756
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('test_message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert to_native(ex) == 'test_message'

# Generated at 2022-06-22 19:59:48.329761
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    msg = "Test Message"
    interpreter_name = "python"
    discovery_mode = "auto"

    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert error.message == msg
    assert error.interpreter_name == interpreter_name
    assert error.discovery_mode == discovery_mode


# Generated at 2022-06-22 19:59:54.320033
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = "<test message>"
    interpreter_name = "<test interpreter>"
    discovery_mode = "<test discovery_mode>"

    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.message == message
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode

    assert e.__str__() == message

# Generated at 2022-06-22 19:59:59.632950
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    from ansible.module_utils.six import StringIO

    exc = InterpreterDiscoveryRequiredError('message', 'python', 'auto')

    with StringIO() as stream:
        exc.__repr__(stream=stream)
        assert stream.getvalue() == 'message'



# Generated at 2022-06-22 20:00:10.955597
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    # By default a message is required to create an InterpreterDiscoveryRequiredError
    # object.
    msg = u"This is a temporary test error message"

    # Create an InterpreterDiscoveryRequiredError object with a message
    # and an interpreter name
    interpreter_name = u'python'
    discovery_mode = u'auto'
    interpreter_discovery_error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)

    # Call the __str__ method of the InterpreterDiscoveryRequiredError object
    val = str(interpreter_discovery_error)

    # Verify that the value returned is identical to the message
    # that was passed in to create the InterpreterDiscoveryRequiredError object
    assert val == msg


# Generated at 2022-06-22 20:00:13.996413
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    testing_error = InterpreterDiscoveryRequiredError('message', 'python', 'auto_silent')
    assert testing_error.__repr__() == 'message'

# Generated at 2022-06-22 20:00:16.060684
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    item = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert item.__repr__() == 'message'


# Generated at 2022-06-22 20:00:24.723454
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'Discovery of %s interpreter required for host %s, mode %s' % (interpreter_name, 'localhost', discovery_mode)
    try:
        raise InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    except InterpreterDiscoveryRequiredError as err:
        assert message == str(err)
        assert interpreter_name == err.interpreter_name
        assert discovery_mode == err.discovery_mode
        return True
    assert False

# Generated at 2022-06-22 20:00:34.448361
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor

    # Use a copy of the default config as the test-config
    test_config = C.config.defaults.copy()
    test_config['DEFAULT']['remote_tmp'] = '/tmp'
    test_config['DEFAULT']['local_tmp'] = '/tmp'
    test_config['DEFAULT']['gather_subset'] = ['all']

    # import the config
    C.config = C.Config(config_defs=test_config, filename=None)

    # Create a fake task to store the task-vars
    task = {}
    task_vars = {}
    task_vars['ansible_distribution'] = 'alpine'
    task_v

# Generated at 2022-06-22 20:00:39.143570
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('foo', 'Python', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'Python'
        assert e.discovery_mode == 'auto'
        assert str(e) == 'foo'
        assert repr(e) == 'foo'

# Generated at 2022-06-22 20:00:42.702626
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "message"
    interpreter_name = "python"
    discovery_mode = "auto"
    error = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert error.__repr__() == msg


# Generated at 2022-06-22 20:00:46.080121
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    parser = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert str(parser) == 'message'

# Generated at 2022-06-22 20:00:53.567228
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    expected_message = "Interperter discovery is required when launching python"
    expected_interpreter_name = "python"
    expected_discovery_mode = "auto"

    idr_error = InterpreterDiscoveryRequiredError(
        expected_message, expected_interpreter_name, expected_discovery_mode
    )

    assert idr_error.message == expected_message
    assert idr_error.interpreter_name == expected_interpreter_name
    assert idr_error.discovery_mode == expected_discovery_mode

# Generated at 2022-06-22 20:00:57.536458
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    exception = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='legacy')
    assert str(exception) == 'message'
    assert repr(exception) == 'message'

# Generated at 2022-06-22 20:01:10.958241
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction(object):

        def _low_level_execute_command(self, cmd, sudoable=None, in_data=None):
            """Pretend to run a command and return result as a dict with stdout/stderr keys."""


# Generated at 2022-06-22 20:01:15.653905
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    try:
        raise InterpreterDiscoveryRequiredError('TestError', 'interpreter_name', 'auto')
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'interpreter_name'
        assert e.discovery_mode == 'auto'

# Generated at 2022-06-22 20:01:21.810571
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    message = "interpreter_name = {0}, discovery_mode={1}".format(interpreter_name, discovery_mode)
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)

    assert err.__str__() == message


# Generated at 2022-06-22 20:01:26.164737
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    try:
        raise InterpreterDiscoveryRequiredError('Test error message', 'python', 'auto')
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.__str__() == 'Test error message\n'

# Generated at 2022-06-22 20:01:37.566805
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Mock class action because of dependencies
    class action(object):
        def __init__(self):
            self.host = u"host"
            self._low_level_execute_command = None
            self._connection = MagicMock()
            self._connection.has_pipelining.side_effect = True
            self._discovery_warnings = []

    class Target(object):
        def __init__(self):
            self.res = None
            self.res_out = None
            self.res_out_list = []

        def set_res(self, res):
            self.res = res

        def set_res_out(self, res_out):
            self.res_out = res_out


# Generated at 2022-06-22 20:01:42.916714
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    f = InterpreterDiscoveryRequiredError(message=None, interpreter_name=None, discovery_mode=None)
    assert (repr(f) == "<class 'ansible.module_utils.facts.interpreter_discovery.InterpreterDiscoveryRequiredError'>")
    assert (str(f) == "<class 'ansible.module_utils.facts.interpreter_discovery.InterpreterDiscoveryRequiredError'>")



# Generated at 2022-06-22 20:01:51.205808
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    message = 'Interpreter {0} will be auto-discovered in this release. ' \
              'Please see the interpreter_discovery option in the ' \
              'ansible.cfg file. For more information, see ' \
              'https://docs.ansible.com/ansible/latest/interpreter_discovery.html'.format(interpreter_name)
    err = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert message == str(err)
    assert isinstance(err, Exception)

# Generated at 2022-06-22 20:01:59.367499
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    message = 'Expected an interpreter discovery to be required'
    actual_error = InterpreterDiscoveryRequiredError(message=message, interpreter_name=interpreter_name, discovery_mode=discovery_mode)
    assert actual_error.message == message
    assert actual_error.interpreter_name == interpreter_name
    assert actual_error.discovery_mode == discovery_mode

# Generated at 2022-06-22 20:02:01.162927
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(
        "Error message.", "python", "auto")
    assert error.interpreter_name == "python"
    assert error.discovery_mode == "auto"

# Generated at 2022-06-22 20:02:08.361453
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = "Interpreter discovery required for host xyz"
    interpreter_name = "python"
    discovery_mode = "auto_legacy_silent"
    with pytest.raises(InterpreterDiscoveryRequiredError) as execinfo:
        raise InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    exception_repr = repr(execinfo.value)
    assert repr(msg) in exception_repr


# Generated at 2022-06-22 20:02:13.192265
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'test'
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    exception = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert str(exception) == message


# Generated at 2022-06-22 20:02:17.933614
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    msg = 'error message'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    test_object = InterpreterDiscoveryRequiredError(msg, interpreter_name, discovery_mode)
    assert test_object.__repr__() == msg


# Generated at 2022-06-22 20:02:24.511373
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    """Unit test for method ``__repr__`` of class
    :class:`ansible.module_utils.common.InterpreterDiscoveryRequiredError`.
    """
    error = InterpreterDiscoveryRequiredError(
        u'message',
        u'interpreter_name',
        u'discovery_mode',
    )
    expected_value = u'message'
    actual_value = repr(error)
    assert actual_value == expected_value, 'Actual value does not match expected value'

# Generated at 2022-06-22 20:02:27.630536
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    message = 'Test error message'
    interpreter_name = 'python'
    discovery_mode = 'auto'

    e = InterpreterDiscoveryRequiredError(message, interpreter_name, discovery_mode)
    assert e.__str__() == message



# Generated at 2022-06-22 20:02:30.294312
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    i = InterpreterDiscoveryRequiredError(
        'foo', interpreter_name='python', discovery_mode='auto_legacy_silent')
    assert str(i) == 'foo'

# Generated at 2022-06-22 20:02:38.194500
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error_msg = 'Some exception error message'
    error_interpreter_name = 'python3'
    error_discovery_mode = 'auto'
    interpreter_error = InterpreterDiscoveryRequiredError(error_msg, error_interpreter_name, error_discovery_mode)

    expected_result = error_msg
    actual_result = interpreter_error.__repr__()

    assert expected_result == actual_result



# Generated at 2022-06-22 20:02:41.850249
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    excp = InterpreterDiscoveryRequiredError("Test message", "python", "auto_legacy_silent")
    assert str(excp) == "Test message0\n"



# Generated at 2022-06-22 20:02:45.494373
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    IDRE = InterpreterDiscoveryRequiredError("this is a test", "python", "auto")
    assert IDRE.interpreter_name == 'python'
    assert IDRE.discovery_mode == 'auto'


# Generated at 2022-06-22 20:02:54.294989
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    with pytest.raises(InterpreterDiscoveryRequiredError) as exc_info:
        raise InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert isinstance(exc_info.value.message, str)
    assert isinstance(exc_info.value.interpreter_name, str)
    assert isinstance(exc_info.value.discovery_mode, str)
    assert exc_info.value.message == 'message'
    assert exc_info.value.interpreter_name == 'interpreter_name'
    assert exc_info.value.discovery_mode == 'discovery_mode'
    assert exc_info.value.__str__() == 'message'
    assert exc_info.value.__repr__() == 'message'

# Generated at 2022-06-22 20:02:58.601101
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    actual_result = str(InterpreterDiscoveryRequiredError('message-for-str', 'python', 'auto'))
    expected_result = 'message-for-str'

    assert expected_result == actual_result

# Generated at 2022-06-22 20:03:01.614518
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    error = InterpreterDiscoveryRequiredError('Python interpreter discovery required', 'python', 'auto')
    assert str(error) == 'Python interpreter discovery required'
    assert repr(error) == 'Python interpreter discovery required'

# Generated at 2022-06-22 20:03:07.362995
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    e = InterpreterDiscoveryRequiredError('This is the message', 'python', 'auto')
    assert(e is not None)
    assert(e.message == 'This is the message')
    assert(e.interpreter_name == 'python')
    assert(e.discovery_mode == 'auto')

    s = str(e)
    assert(s == 'This is the message')


# Generated at 2022-06-22 20:03:09.260104
# Unit test for method __repr__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___repr__():
    ex = InterpreterDiscoveryRequiredError('test message', 'python', 'auto')
    assert repr(ex) == 'test message'

# Generated at 2022-06-22 20:03:17.343666
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    e = InterpreterDiscoveryRequiredError('message', interpreter_name, discovery_mode)
    assert e.interpreter_name == interpreter_name
    assert e.discovery_mode == discovery_mode
    assert e.message == 'message'
    assert e.__str__() == 'message'
    assert e.__repr__() == 'message'

# Generated at 2022-06-22 20:03:25.068241
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    import ansible.module_utils.facts.virtual.guest

    # some values that may be used in a test scenario

# Generated at 2022-06-22 20:03:34.437372
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import doctest

# Generated at 2022-06-22 20:03:37.209804
# Unit test for method __str__ of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError___str__():
    x = InterpreterDiscoveryRequiredError('message', 'interpreter_name', 'discovery_mode')
    assert x.__str__() == 'message'

# Generated at 2022-06-22 20:03:39.407922
# Unit test for constructor of class InterpreterDiscoveryRequiredError
def test_InterpreterDiscoveryRequiredError():
    error = InterpreterDiscoveryRequiredError(message='message', interpreter_name='python', discovery_mode='auto')
    assert error.interpreter_name == 'python'
    assert error.discovery_mode == 'auto'


# Generated at 2022-06-22 20:03:52.966901
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop as mock_unfrackpath

    from ansible.plugins.action.normal import ActionModule as ActionNormal
    import ansible.executor.action_plugins.command as command

    class ActionModule(ActionNormal):
        def _execute_module(self, tmp=None, task_vars=None, persist_files=False):
            super(ActionModule, self)._execute_module(tmp, task_vars, persist_files)

            # we are testing the discovery function via this action, so we have to override this to make it no-op
            self._remove_tmp_path(self._connection._shell.tmpdir)

            self._remove_insignificant_keys(self._result)
            return self._result

# Generated at 2022-06-22 20:04:04.309948
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    from ansible.module_utils.common.validation import check_type_str
    import ansible.module_utils.connection
    import ansible.module_utils.network.common.module_loader
    import ansible.module_utils.network.common.utils

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception(kwargs['msg'])

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
