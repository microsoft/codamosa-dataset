

# Generated at 2022-06-10 23:12:51.595701
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.action.normal import ActionModule as ActionNormal
    from ansible.executor.task_queue_manager import TaskQueueManager

    class DummyConnection:

        def __init__(self, has_pipelining=True):
            self.has_pipelining = has_pipelining


# Generated at 2022-06-10 23:13:03.040225
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TestAction(object):
        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            script = pkgutil.get_data('ansible.executor.discovery', 'platform_script_output.json')
            return {
                'stdout': script
            }

    action = TestAction()

    task_vars = {}
    res = discover_interpreter(action, 'python', 'auto', task_vars)
    assert res == u'python3'

    res = discover_interpreter(action, 'python', 'auto_legacy', task_vars)
    assert res == u'/usr/bin/python'

    res = discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)

# Generated at 2022-06-10 23:13:04.209791
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FIXME: implement unit tests for interpreter discovery
    pass

# Generated at 2022-06-10 23:13:13.845602
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import shutil
    import tempfile

    actual_wanted = (
        (u'ubuntu', (u'16.04', u'/usr/bin/python'), (u'/usr/bin/python', u'/usr/bin/python2.7')),
        (u'CentOS', (u'7.6.1810', u'/usr/bin/python2.7'), (u'/usr/bin/python2.7', u'/usr/bin/python')),
        (u'CentOS', (u'8.0', u'/usr/bin/python'), (u'/usr/bin/python3', u'/usr/bin/python')),
    )

    from ansible.utils import context_objects as co
    from ansible.plugins.action.normal import ActionModule as _ActionModule

# Generated at 2022-06-10 23:13:26.950509
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import pytest

    display.verbosity = 4  # enable debugging output

    class TestInterpreterDiscoveryAction(ActionBase):
        def _low_level_execute_command(self, *args, **kwargs):
            # simulate the output of 'command -v /usr/bin/python'
            return {'stdout': u'/usr/bin/python\n/usr/local/bin/python'}


# Generated at 2022-06-10 23:13:39.890927
# Unit test for function discover_interpreter
def test_discover_interpreter():
    fake_action = MockAction()
    task_vars = {}
    interpreter_name = 'python'
    discovery_mode = 'auto'

    # test discovery when discovery_mode is standard (i.e. auto)
    # and when the platform is Linux
    res = discover_interpreter(fake_action, interpreter_name, discovery_mode, task_vars)
    assert(res == u'/usr/bin/python')

    # test discovery when discovery_mode is legacy (i.e. auto_legacy)
    # and when the platform is Linux
    discovery_mode = 'auto_legacy'
    res = discover_interpreter(fake_action, interpreter_name, discovery_mode, task_vars)
    assert(res == u'/usr/bin/python')

    # test discovery when discovery_mode is silent (i.

# Generated at 2022-06-10 23:13:52.850950
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Testing function discover_interpreter
    # Case 1: interpreter_name != 'python'
    # Expected result: raise ValueError('Interpreter discovery not supported for interpreter_name')
    # First parameter is action, second parameter is interpreter_name, third parameter is discovery_mode,
    # and fourth parameter is task_vars
    action = None
    interpreter_name = 'java'
    discovery_mode = 'auto_legacy_silent'
    task_vars = None
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except Exception as err:
        assert err.args[0] == 'Interpreter discovery not supported for java'

    # Case 2: platform_type != 'linux'
    # Expected result: raise NotImplementedError('unsupported platform for

# Generated at 2022-06-10 23:14:04.935375
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class FakeAction(object):
        def __init__(self):
            self._discovery_warnings = []

    action = FakeAction()

    task_vars = dict()

    python_map = dict()
    python_map['redhat'] = dict()
    python_map['redhat']['6.5'] = '/usr/libexec/platform-python'
    python_map['redhat']['7.6'] = '/usr/lib/python2.7'
    python_map['ubuntu'] = dict()
    python_map['ubuntu']['16.04'] = '/usr/bin/python3'
    python_map['ubuntu']['18.04'] = '/usr/bin/python3'

# Generated at 2022-06-10 23:14:06.422122
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # works if it doesn't error out
    discover_interpreter(None, 'python', 'auto', {})

# Generated at 2022-06-10 23:14:18.860932
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    ansible.executor.discovery.test_discover_interpreter
    :return:
    """
    from ansible.executor.task_executor import TaskExecutor

    class TestAction:
        def __init__(self):
            self.display = display
            self._discovery_warnings = []
            self._connection = {}
            self._connection['has_pipelining'] = True
            self._low_level_execute_command = lambda *args: {'stdout': '', 'stderr': '', 'rc': 0, 'changed': False}

        def _get_task_vars(self):
            return {'inventory_hostname': 'testhost'}

    # _interpreter_discovery() - test python
    action = TestAction()

# Generated at 2022-06-10 23:14:39.125648
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Setup
    def fake_low_level_execute_command(cmd, sudoable=False, in_data=None):
        res = {'stdout': u'', 'stderr': u''}
        if cmd == 'echo PLATFORM; uname; echo FOUND; command -v "python"; echo ENDFOUND':
            res['stdout'] = u'PLATFORM\nLinux\nFOUND\n/bin/python2\nENDFOUND'

# Generated at 2022-06-10 23:14:48.048275
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils import connection as mod_con
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.playbook.task import Task

    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = dict(ansible_python_interpreter=u'/usr/bin/python')
    action = Task()
    action.action = 'shell'
    action.delegate_to = 'localhost'
    action._low_level_execute_command = mod_con.Connection._execute
    action.args = dict()


# Generated at 2022-06-10 23:14:49.620755
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action', 'python', 'auto_legacy_silent', {}) == u'/usr/bin/python'



# Generated at 2022-06-10 23:14:51.268286
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """ Test for function discover_interpreter"""
    pass

# Generated at 2022-06-10 23:15:02.221333
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    pmgr = VariableManager()

    # Set up a mocked action plugin
    class MockActionPlugin():
        def __init__(self, *args, **kwargs):
            pass

        def _low_level_execute_command(self, command, **kwargs):
            return {'stdout': command}

        _discovery_warnings = []

    # Set up a mocked connection plugin
    class MockConnection():
        def __init__(self, *args, **kwargs):
            pass

        has_pipelining = True
        transport = 'mock'

    # Set up a mocked inventory
   

# Generated at 2022-06-10 23:15:12.405426
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.plugins.loader import action_loader, connection_loader, module_loader
    from ansible.vars.manager import VariableManager

    hosts = [u'localhost']
    task = AnsibleMapping(dict(name=u'test', action=u'ping'))
    variable_manager = VariableManager()
    variable_manager.set_host_variable(hosts[0], 'inventory_hostname', hosts[0])

# Generated at 2022-06-10 23:15:19.434953
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_connection': 'local',
        'ansible_inventory_hostname': 'localhost',
    }
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    action = ActionBase()
    task = TaskExecutor(local_action=action.__class__.__name__)
    action.set_loader(action_loader)
    action.set_task(task)
    action.set_play_context(dict(become='True'))
    action.set_task_vars(task_vars)


# Generated at 2022-06-10 23:15:21.700133
# Unit test for function discover_interpreter
def test_discover_interpreter():
    display.verbosity = 4
    display.debug('test_discover_interpreter')
    action = ActionModule('/tmp')
    print('test_discover_interpreter')
    print(discover_interpreter(action, 'python', 'auto', 'ansible_distribution'))

# Generated at 2022-06-10 23:15:31.769396
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.connection_factory import ConnectionFactory
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    # for test harness convenience
    class TestAction(object):
        def __init__(self):
            self._connection = None
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            module_list = [u'uname', u'platform']
            if not self._connection:
                pc = ConnectionFactory(task=None, play_context=PlaybookExecutor.load_play_context(variable_manager=None, loader=None))
                self._connection = pc.create

# Generated at 2022-06-10 23:15:45.152964
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    task_vars = dict()

    class ActionDummy(object):
        def __init__(self):
            self._low_level_execute_command = lambda x, sudoable, in_data=None: dict(stdout=u'/bin/bash')
            self._connection = ConnectionDummy()

    class TaskDummy(object):
        def __init__(self):
            self._task = AnsibleMapping()
            self.action = 'shell'
            self.args = dict()
            self.block = None
            self.any_errors_fatal = False
            self.always_run = False
            self.delegate_to = None

# Generated at 2022-06-10 23:16:05.493051
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("in test_discover_interpreter")

# Generated at 2022-06-10 23:16:16.845015
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:16:28.483039
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.loader as plugins
    import ansible.plugins.action as action

    # get a test ActionBase class.
    TestAction = plugins.get_action_class('system', class_only=True)

    class TestConnection(object):
        def __init__(self, has_pipelining):
            self.transport = 'local'
            self.has_pipelining = has_pipelining

    class TestTask(object):
        def __init__(self, connection, task_vars):
            self.action = TestAction()
            self.action._play_context = TestPlayContext()
            self.action._task = self
            self.status = 'ok'
            self.connection = connection
            self.task_vars = task_vars


# Generated at 2022-06-10 23:16:38.292132
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    import shutil
    import sys
    import importlib
    import platform

    # if we would be using the platform interpreter by default, we skip these tests, since discover_interpreter
    # will just return the default.
    if platform.python_version() == sys.version[:3]:
        sys.exit()

    # create a temp copy of the module_utils dir
    module_utils_copy_path = tempfile.mkdtemp(prefix='ansible_module_utils_')

    # add our new path to sys.path, so we're importing from the new location
    sys.path.insert(0, module_utils_copy_path)

    # get the real interpreter_python_distro_map and copy it to the temp location
    real_interpreter_python_distro_map = importlib

# Generated at 2022-06-10 23:16:40.511735
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This function is tested in unit/module_utils/test_interpreter_discovery.py
    pass

# Generated at 2022-06-10 23:16:52.334919
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:17:03.394530
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager, \
        TaskQueueManagerError
    from ansible.executor.play_context import PlayContext
    from ansible.plugins.action import ActionBase

    def _get_task_result(task, interpreter_name='python', discovery_mode='auto', task_name=None):
        display.verbosity = 2
        task_vars = {'inventory_hostname': 'localhost'}
        action = ActionBase(task, task_name, 'test', task_vars)
        rc = 0
        result = None
        exception = None
        start = 0
        end = 0


# Generated at 2022-06-10 23:17:15.389070
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action', 'python', 'auto_legacy_silent',
                                {'inventory_hostname': 'test-host',
                                 'config': {'get_config_value': _fake_get_config_value}}) == '/usr/bin/python'
    assert discover_interpreter('action', 'python', 'auto_legacy_silent',
                                {'inventory_hostname': 'test-host',
                                 'config': {'get_config_value': _fake_get_config_value},
                                 'ansible_python_interpreter': '/usr/bin/python'}) == '/usr/bin/python'

# Generated at 2022-06-10 23:17:21.892239
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # import the module into the global space so it can be accessed by the test
    import ansible.executor.discovery

# Generated at 2022-06-10 23:17:32.261388
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:17:53.340222
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.raw import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    a = ActionModule(task_vars=dict(ansible_python_interpreter=u'/usr/bin/python'))
    try:
        assert discover_interpreter(a, 'python', 'auto_legacy_silent', dict()) == u'/usr/bin/python'
    except InterpreterDiscoveryRequiredError as ex:
        pass

# Generated at 2022-06-10 23:18:07.882385
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class mock_module():
        def __init__(self):
            self._debug = True
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            if args[0].endswith('uname'):
                return {'stdout': 'Linux\n', 'stderr': '', 'rc': 0}
            if args[0].endswith('python'):
                return {'stdout': 'Body output', 'stderr': '', 'rc': 0}

# Generated at 2022-06-10 23:18:18.199755
# Unit test for function discover_interpreter
def test_discover_interpreter():

    action = u''  # we're not doing any actions, so this is a mock for (never-accessed) call attributes

    interpreter_name = u'python'
    discovery_mode = u'auto_legacy'
    platform_type = u'linux'

    # also, mock for some things that can't easily be replicated in a unit test
    action._connection = {}
    action._connection.has_pipelining = True

    # the results for the fallback, for mocking the bootstrap output
    action._discovery_warnings = []
    # TODO: this really, really needs to test the warning output, but I don't know how to do that yet
    # TODO: also needs to test the legacy fallback case, without warnings (and with a warning)

    # get the python platform info

    # first, get some output from the platform module (

# Generated at 2022-06-10 23:18:30.585146
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Subroutine that tests discover_interpreter with a given Python version
    def test_interpreter_version(expected, version_map_dict, version_to_test):

        # Execute
        task_vars = dict()
        task_vars['INTERPRETER_PYTHON_DISTRO_MAP'] = version_map_dict
        task_vars['INTERPRETER_PYTHON_FALLBACK'] = [u'/usr/bin/python']
        interpreter_version = discover_interpreter(None, 'python', 'auto', task_vars)

        # Assert
        assert interpreter_version == expected

    # Test for all the python versions

# Generated at 2022-06-10 23:18:40.689088
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play

    fake_task_vars = {"ansible_connection": "local",
                      "inventory_hostname": "127.0.0.1"}
    fake_action = TaskResult(host=fake_task_vars['inventory_hostname'], task=Play()._create_dummy_task())
    fake_action._task.action = "shell"
    fake_action._low_level_execute_command = lambda cmd, sudoable, in_data: {"stdout": cmd}

    # Auto discovery without host fallback
    result = discover_interpreter(fake_action, "python", "auto_legacy_host", fake_task_vars)

# Generated at 2022-06-10 23:18:43.072900
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', None) == '/usr/bin/python'

# Generated at 2022-06-10 23:18:56.535382
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class FakeAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = FakeConnection()

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            self.cmd = cmd
            return dict(stdout='', stderr='')

    class FakeConnection(object):
        has_pipelining = True


# Generated at 2022-06-10 23:19:09.118855
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_loader import ActionModuleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = ActionModuleLoader(None, '/tmp', '', '', False)
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-10 23:19:19.335843
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TestAction(object):
        _connection = object()
        _low_level_execute_command = None
        _discovery_warnings = []
        def __init__(self):
            self.has_pipelining = True

    action = TestAction()

    def _ll_execute(command, sudoable, in_data=None):
        assert action.has_pipelining
        assert command == '/usr/bin/python'
        if in_data:
            platform_python_map = C.config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP', variables={})
            platform_script = pkgutil.get_data('ansible.executor.discovery', 'python_target.py')
            assert in_data == platform_script

# Generated at 2022-06-10 23:19:29.801703
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # None of these tests should ever actually go to a remote host, so we'll use a noop connection wrapper that
    # just returns canned output
    class MockConnectionNoop():
        def _exec_command(self, cmd):
            return dict(stdout='',
                        stderr='',
                        rc=0)

        def has_pipelining(self):
            return True

    class MockModuleFail():
        def _low_level_execute_command(self, *args, **kwargs):
            raise ValueError('fail')

        def _execute_module(self, *args, **kwargs):
            raise ValueError('fail')

        @property
        def action_args(self):
            return dict(discovery_mode='auto')

        @property
        def _connection(self):
            return MockConnectionNoop()


# Generated at 2022-06-10 23:20:11.340482
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys

    if sys.version_info[0] < 3:
        import mock


# Generated at 2022-06-10 23:20:21.558985
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.discovery import InterpreterNotFoundError
    from ansible.module_utils.six import PY3
    from contextlib import contextmanager

    @contextmanager
    def mock_action(task_vars, interpreters, python_script, connection_pipelining=True):
        def _mock_low_level_execute_command(interpreter, sudoable=False, in_data=None):
            try:
                return {'stdout': interpreters[interpreter]}
            except KeyError:
                raise InterpreterNotFoundError(interpreter)

        # Python 3.5+ has a return_value in the context

# Generated at 2022-06-10 23:20:33.827221
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test non-python interpreter discovery
    assert discover_interpreter('', 'not supported', '', {}) is None

    # Test pre-calculated interpreter discovery
    assert discover_interpreter('', 'python', 'precalculated', {'ansible_python_interpreter': '/usr/bin/python'}) == '/usr/bin/python'

    # Test bootstrap interpreter discovery path
    class ActionModuleMock():
        _connection = MockConnection()
        _discovery_warnings = []

        def __init__(self):
            self._low_level_execute_command = MockLL()

    action = ActionModuleMock()

# Generated at 2022-06-10 23:20:42.228678
# Unit test for function discover_interpreter
def test_discover_interpreter():
    display = Display()
    host = 'localhost'
    task_vars = dict()

    def run_test(action, interpreter_name, discovery_mode, expected_result, expected_warnings=None, expected_exception=None):
        display.debug(u'Testing discovery with interpreter {0}, discovery mode {1}, action {2}...'
                      .format(interpreter_name, discovery_mode, to_text(action)))

        if not isinstance(expected_warnings, list) and expected_warnings is not None:
            raise ValueError('{0} is not a list'.format(expected_warnings))

        action._discovery_warnings = []

# Generated at 2022-06-10 23:20:54.892724
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test the discover_interpreter function in case of:
    # 1. success
    # 2. missing python
    # 3. missing platform.dist() call
    # 4. missing python interpreters
    # 5. missing Linux dist
    # 6. success with pipelining
    # 7. error with pipelining

    # Steps:
    # 1. Use a mock module to replace _low_level_execute_command() and get_tmp_path()
    # 2. Start a mock connection for action
    # 3. Start a mock task_vars for action
    # 4. Call discover_interpreter on that
    # 5. Analyze the results
    from ansible.module_utils import connection
    from ansible.playbook.play_iterator import TaskIterator
    from ansible.playbook.task import Task

# Generated at 2022-06-10 23:21:06.269055
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # case 1: default interpreter discovery mode
    task_vars = {}
    action = ''
    interpreter_name = 'python'
    discovery_mode = 'auto'
    expected_result = "/usr/bin/python"
    actual_result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert actual_result == expected_result

    # case 2: auto_legacy interpreter discovery mode
    task_vars = {}
    action = ''
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    expected_result = "/usr/bin/python"
    actual_result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert actual_result == expected_result

    # case 3: auto_legacy_sil

# Generated at 2022-06-10 23:21:19.077526
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.plugins import connection_loader

    from ansible.plugins.loader import action_loader, module_loader

    from ansible.plugins.connection.local import Connection as LocalConnection

    conn_obj = LocalConnection()
    task_queue_manager = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
    )


# Generated at 2022-06-10 23:21:32.375112
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object()
    action._low_level_execute_command = lambda command, sudoable=False, in_data=None: {'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python2.7\nENDFOUND'}
    action._connection = object()
    action._connection.has_pipelining = True
    action._discovery_warnings = []

    interpreter_name = u'python'
    discovery_mode = u'auto'
    task_vars = dict()

    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res == u'/usr/bin/python2.7'
    assert not len(action._discovery_warnings)

    # test an interpreter not found
    action._low_level_execute

# Generated at 2022-06-10 23:21:40.239838
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Unit test for function discover_interpreter
    # Test for an older distribution
    task_vars = dict()
    task_vars['ansible_python_interpreter_discovery_mode'] = 'conservative'
    task_vars['ansible_python_interpreter_discovery_filename'] = '/a/b/interpreter'
    task_vars['ansible_python_interpreter_discovery_target'] = 'python3'

    class ActionModule:
        def __init__(self):
            self._connection = object()
            self._discovery_warnings = []


# Generated at 2022-06-10 23:21:50.062740
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext

    class TestAction(ActionBase):
        def __init__(self):
            super(TestAction, self).__init__()
            self._connection = None
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            return dict(stdout=u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND')

        def _save_task_result(self, res, task_vars, task_result):
            pass

    task_vars = dict()
    pc = PlayContext()

    action = TestAction()

    # Test discovery with 'auto' mode