

# Generated at 2022-06-10 23:12:48.387813
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery
    from ansible.module_utils._text import to_bytes
    # Mock action
    class test_discover_action(object):
        result = None
        done = False
        discovery_warnings = []


# Generated at 2022-06-10 23:12:59.470613
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import find_plugin, get_all_plugin_loaders
    from ansible.template import generate_ansible_template_vars
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.manager import VariableManager

    # FUTURE: add a way for the user to pass in vars for testing?

    loader = AnsibleCollectionLoader()
    find_plugin()
    plugin_loaders = get_all_plugin_loaders()

    # FUTURE: should we use test_lookup.ReturnData(), test_lookup.MockLookupBase, or something else?

# Generated at 2022-06-10 23:13:10.457936
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:13:24.394301
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest.mock as mock
    import distutils.version
    import io
    import sys

    class MockAction(object):
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            return {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python3\nENDFOUND'}

        # TODO: implement this
        @property
        def _connection(self):
            class MockConnection(object):

                has_pipelining = True

            return MockConnection()


# Generated at 2022-06-10 23:13:26.427869
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """Function to test discover_interpreter"""
    # TODO: Add unit test for discovery
    pass

# Generated at 2022-06-10 23:13:35.249444
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task

    class TestAction:
        def __init__(self, host):
            self.task_vars = {'inventory_hostname': host}
            self._discovery_warnings = []

        @staticmethod
        def _low_level_execute_command(cmd, sudoable=True, in_data=None):
            if cmd == "command -v '/usr/bin/python'":
                return {'stdout': u'FOUND\n/usr/bin/python\nENDFOUND'}

# Generated at 2022-06-10 23:13:42.824743
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import action
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    # define the mock task and action value
    task = dict(action=dict(name='setup', module_name='setup'), register='system_info')

    task_vars = dict(inventory_hostname='test')

    # TODO: if interpreter_discovery_mode is ever not 'auto', we probably need to add
    # an 'auto_silent' mode for this to test properly?
    interpreter_discovery_mode = 'auto'

    result = discover_interpreter(action, 'python', interpreter_discovery_mode, task_vars)

    # TODO: we need a better way to verify

# Generated at 2022-06-10 23:13:53.307003
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # setup
    test_host = 'host'
    test_interpreter = 'python'
    test_action = object()

    # TODO: mock action object?
    test_action.discovery_warnings = []
    test_action._discovery_warnings = []
    test_action._low_level_execute_command = object()

    # test distributions

# Generated at 2022-06-10 23:14:05.367919
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionModule
    from ansible.executor.discovery import discover_interpreter
    from ansible.executor.task_result import TaskResult

    class TestActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            ActionModule.__init__(self, *args, **kwargs)
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            if kwargs.get('in_data'):
                return {'stdout': u'{"platform_dist_result": ["Ubuntu", "15.10", "wily"]}'}

# Generated at 2022-06-10 23:14:14.012554
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play = Play()
    play_context = PlayContext(play=play)

    task = Task()
    task.set_play_context(play_context)
    task_vars = dict()
    
    assert(discover_interpreter(task, 'python', 'auto', task_vars) == '/usr/bin/python')

# Generated at 2022-06-10 23:14:35.277241
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.utils.display import Display
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.connection.network_cli import Connection as _Connection

    display = Display()
    display.verbosity = 4
    display.columns = 80

    class DummyTaskVars(object):
        def __init__(self):
            self.inventory_hostname = 'unittest'
            self.vars = {}

    class DummyActionModule(_ActionModule):
        def __init__(self, task_vars):
            self._discovery_warnings = []
            self._low_level_execute_command = None
            super(DummyActionModule, self).__init__(task_vars)

    class DummyPlayContext(object):
        become = False
        become_method

# Generated at 2022-06-10 23:14:45.532644
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Unit test using dictionary values instead of file
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        _discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None, executable=None, stdin=None):
            return {'stdout': "PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND", 'stderr': None, 'rc': 0, 'stdin': None}

        def _discovery_warn(self, msg):
            self._discovery_warnings.append(msg)

    action = TestAction()

    # NOTE: this will have to be updated as the map is

# Generated at 2022-06-10 23:14:52.420109
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = mock_action()
    task_vars = {
        'inventory_hostname': 'test_host'
    }

    interp = discover_interpreter(action, 'python', 'auto', task_vars)

    assert interp == u'/usr/bin/python'
    assert len(action.discovery_warnings) == 1
    assert action.discovery_warnings[0] == u'No python interpreters found for host test_host (tried /usr/bin/python)'



# Generated at 2022-06-10 23:15:03.336772
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactModule
    # a fake platform...
    class FakeLinuxPlatform(object):
        PLATFORM_NAME = 'linux'

        def dist(self):
            return ('CentOS', '6.5', 'Final')

    # and a fake module
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.platform as platform
    import ansible.module_utils as module_utils

    class FakeModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable != 'python':
                raise Exception("Unexpected executible %s" % executable)
            return '/usr/bin/python'


# Generated at 2022-06-10 23:15:13.056788
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Stub out the check for pipelining
    class ActionModule(object):
        def __init__(self):
            self.connection = Connection()
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            return dict(stdout=cmd)

    a = ActionModule()

    # Stub out the config values via task_vars
    task_vars = dict()
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    task_vars['ansible_python_interpreter_discovery_mode'] = 'auto_legacy_silent'
    task_vars['ansible_python_interpreter_discovery_warnings'] = 'True'
    task_vars

# Generated at 2022-06-10 23:15:27.061003
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.module_utils.interpreter_discovery.tests.dummy_module as dummy_module

    platform_python_map = {
        'redhat': {
            '5': '/usr/bin/python',
            '6': '/usr/bin/python',
            '7': '/usr/bin/python2'
        }
    }

    bootstrap_python_list = ['python', 'python2', 'python3']


# Generated at 2022-06-10 23:15:35.957529
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', {}) != '/usr/bin/python'
    assert discover_interpreter(None, 'other', 'auto_silent', {}) == '/usr/bin/python'

# Generated at 2022-06-10 23:15:47.099883
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter as di
    from ansible.playbook.play import Play

    def fake_execute(*args, **kwargs):
        return {'stdout': '', 'stderr': '', 'rc': 0}

    class FakeAction(object):
        def __init__(self):
            self._connection = None
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            return fake_execute(*args, **kwargs)

    class FakeConnection(object):
        def __init__(self):
            self.has_pipelining = True


# Generated at 2022-06-10 23:15:55.196921
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test case 1
    action = ActionModule()
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = {'inventory_hostname': 'localhost'}
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert result == '/usr/bin/python'

    # test case 2
    action = ActionModule()
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = {'inventory_hostname': 'localhost', 'ansible_python_interpreter': '/usr/local/bin/python'}
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert result == '/usr/local/bin/python'



# Generated at 2022-06-10 23:16:07.859079
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # on a system with at least the default python, this should return the default
    result = discover_interpreter(None, "python", "auto", dict())
    assert result == u'/usr/bin/python'

    # on a system with only python3, this should return python3
    result = discover_interpreter(None, "python", "auto", dict(ansible_python_interpreter="/usr/bin/python3"))
    assert result == u'/usr/bin/python3'

    # on a system with only python3, this should return python3, even if legacy mode is requested
    result = discover_interpreter(None, "python", "auto_legacy", dict(ansible_python_interpreter="/usr/bin/python3"))
    assert result == u'/usr/bin/python3'

    # on a system with

# Generated at 2022-06-10 23:16:33.271848
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Test action is used to
    class TestAction(object):
        def __init__(self, result, exception=None):
            self.result = result
            self.exception = exception

        def _low_level_execute_command(self, *args, **kwargs):
            if self.exception:
                raise self.exception
            return self.result

    # Test task_vars var is used to
    task_vars = {}

    if C.DEFAULT_INTERPRETER_DISCOVERY_MODE == 'auto':
        task_vars['ansible_python_interpreter'] = '/usr/bin/python'

# Generated at 2022-06-10 23:16:44.661712
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Unit test for function version_fuzzy_match
    def test_version_fuzzy_match():
        version = ['13.0', '13.1', '13.2', '13.3', '13.99']
        value = ['13.0','13.1','13.2','13.3','13.99']
        version_map = {'13.0':'v1', '13.1':'v2', '13.2':'v3', '13.3':'v4', '13.99':'v5'}

        for i in range(len(version)):
            assert _version_fuzzy_match(version[i], version_map) == value[i]

    test_version_fuzzy_match()

# Generated at 2022-06-10 23:16:56.645924
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # pytest is not installed on travis, so we have to use unittest
    # TODO: move to test_discovery.py?

    # FUTURE: unit test for all possible scenarios, vs. only the happy path here
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionModule

    class TestInterpreterDiscoveryActionModule(ActionModule):
        def _low_level_execute_command(self, cmd, **kwargs):
            return {'stdout': cmd}

        def _execute_module(self, tmp=None, task_vars=None, **kwargs):
            return {'shell_bootstrap': 'echo PLATFORM; uname; echo FOUND; command -v python; echo ENDFOUND'}


# Generated at 2022-06-10 23:17:06.504769
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    import os
    import sys

    # Unit testing python interpreted discovery is tricky, as it depends on the system you are running the tests on.
    # We use a mocked LinuxDistribution class that returns information based on the test environment.
    class LinuxDistributionMock(LinuxDistribution):

        def __init__(self):
            self._distro_info = None
            self._distro = {'debian': 'Debian',
                            'ubuntu': 'Ubuntu',
                            'suse': 'Suse',
                            'others': 'Linux'}

            plat = sys.platform
            if plat == 'linux2':
                distname, version, id = platform.linux

# Generated at 2022-06-10 23:17:18.662533
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import shutil
    import tempfile

    # Test data
    # FIXME: This should be data driven and cover more cases, with mocks
    test_host = '192.168.1.1'
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto'

    # Correct data
    test_linux_distro = 'CentOS'
    test_linux_version = '7.4.1708'
    test_python_interpreter = '/usr/bin/python'


# Generated at 2022-06-10 23:17:29.704386
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader

    action = ActionBase()

    assert 'ShellModule' in action._shared_loader_obj.module_loader
    assert 'ScriptModule' in action._shared_loader_obj.module_loader

    assert 'shell' in action._shared_loader_obj.module_loader.module_name_map
    assert 'script' in action._shared_loader_obj.module_loader.module_name_map
    assert 'command' in action._shared_loader_obj.module_loader.module_name_map

    assert 'shell' in action.shared_loader_obj.module_loader.module_name_map
    assert 'script' in action.shared_loader_obj.module_loader.module_name_map
    assert 'command' in action.shared

# Generated at 2022-06-10 23:17:40.606703
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.parsing import vault

    host = 'localhost'

# Generated at 2022-06-10 23:17:52.432722
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_bytes

    # FUTURE: this is broken, needs rewrite
    return

    action = AnsibleModule({})
    action._discovery_warnings = []

    test_vars = {
        'ansible_python_interpreter': '/usr/bin/python',
        'inventory_hostname': 'test-host',
        'playbook_dir': 'playbook_dir',
    }

    # test single default interpreter discovered
    setup_vars = test_vars.copy()
    setup_vars['ansible_python_interpreter'] = 'python'
    action._host_vars = setup_vars
    action._task_vars = test_vars

    inter

# Generated at 2022-06-10 23:18:06.932612
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_warn', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', None) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_warn', None) == u'/usr/bin/python'

    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {
        'inventory_hostname': 'foo',
        'ansible_python_interpreter': '/north/pole/python'
    }) == '/north/pole/python'
    assert discover_interpre

# Generated at 2022-06-10 23:18:17.504592
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_discovery_mode = 'auto_legacy'
    test_action = object()
    test_interpreter_name = 'python'

    test_task_vars = dict()
    test_task_vars['inventory_hostname'] = 'testhost'
    test_task_vars['ansible_connection'] = 'network_cli'

    # test discover_interpreter() with unsupported interpreter_name
    expected_interpreter_name = 'python'
    actual_interpreter_name = None
    try:
        actual_interpreter_name = discover_interpreter(test_action, 'python3', test_discovery_mode, test_task_vars)
    except ValueError:
        actual_interpreter_name = 'python3'


# Generated at 2022-06-10 23:18:46.191256
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_python_version'    : '2.7.12',
        'ansible_distribution'      : 'CentOS',
        'ansible_distribution_version': '7.0',
        'ansible_distribution_release': 'Core',
        'ansible_distribution_major_version': '7',
        'ansible_distribution_file_parsed': True,
        'ansible_python_version_full': '2.7.12',
        'ansible_python_version_major_minor': '2.7',
        'ansible_python_version_major': '2'
        }

    # Happy path
    # TODO: What can we assert here?
   

# Generated at 2022-06-10 23:18:57.728381
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_mock_uname = u"PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND"
    test_mock_platform = u"PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND"
    class MockAction():
        class MockLowlevelExecCmd():
            def __init__(self, text, sudoable, in_data):
                self._text = text
                self._sudoable = sudoable
                self._data = in_data

            def __call__(self):
                if self._sudoable is False and self._data is None:
                    return {'stdout': test_mock_uname}

# Generated at 2022-06-10 23:19:10.229844
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins import module_loader
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext

    m_cls = module_loader.get('shell', class_only=True)
    t_vars = dict()

    j_res = {
        "msg": "",
        "stdout": "",
        "stderr": "",
        "rc": 0
    }

    t_res = TaskResult(host='localhost', task=dict(), task_fields=dict(), result=j_res)

    test_shell = m_cls.load_module()
    test_shell.run = lambda *args, **kwargs: t_res
    test_shell.check_mode = False

    test

# Generated at 2022-06-10 23:19:20.581156
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test script to simulate action._low_level_execute_command function
    class MockAction():
        def _low_level_execute_command(self, python_path, sudoable=False, in_data=None):
            if (python_path == '/usr/bin/python') and in_data:
                return {'stdout': test_distro_information}

            return {}

        def __init__(self):
            self._discovery_warnings = []

    # Test script to simulate task_vars
    class MockTaskVars():
        def __init__(self):
            self.inventory_hostname = 'test'

    # Test script to simulate Config module

# Generated at 2022-06-10 23:19:31.122124
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = dict()
    assert ('/usr/bin/python' == discover_interpreter(action, interpreter_name, discovery_mode, task_vars))
    assert (1 == len(action._discovery_warnings))
    action._discovery_warnings.clear()

    discovery_mode = 'auto_legacy_silent'
    assert ('/usr/bin/python' == discover_interpreter(action, interpreter_name, discovery_mode, task_vars))
    assert (0 == len(action._discovery_warnings))
    action._discovery_warnings.clear()

    discovery_mode = 'auto_silent'

# Generated at 2022-06-10 23:19:42.664593
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionModule

    def _get_linux_distro_for_test(platform_info):
        return platform_info.get('osrelease_content').get('ID', u''), platform_info.get('osrelease_content').get('VERSION_ID', u'')

    test_python_fallback = ['/usr/bin/python', '/usr/local/bin/python', '/opt/bin/python']

# Generated at 2022-06-10 23:19:55.533945
# Unit test for function discover_interpreter
def test_discover_interpreter():
    display.verbosity = 4
    class MockAction:
        warning_regex = re.compile(r'^\[WARNING\].*$')

        def __init__(self):
            self._discovery_warnings = []

        def _discovery_warn(self, message):
            self._discovery_warnings.append(message)

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == '/usr/bin/python':
                return {'stdout': '{ "platform_dist_result": [ "Debian", "9.2", "stretch" ], '
                                  '"osrelease_content": "ID=debian\\n" }'}

# Generated at 2022-06-10 23:20:01.100839
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.normal import ActionModule

    interpreter_name = 'python'
    discovery_mode = 'explicit'  # disables discovery as a whole

    assert discover_interpreter(ActionModule(PlayContext()), interpreter_name, discovery_mode, {}) is None

# Generated at 2022-06-10 23:20:10.709951
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys
    import pytest

    class TestActionModule(object):
        def __init__(self, *args, **kwargs):
            self.host = u'localhost'
            self.name = u'test'
            self._connection = None
            self._low_level_execute_command = self._low_level_execute_command_mock

            self._discovery_warnings = []

        def _low_level_execute_command_mock(self, command, sudoable, in_data=None):
            # simulate the command interpreter discovery bootstrap
            if u'command' in command and u'-v' in command:
                return dict(stdout=u'/usr/bin/python3\n/usr/bin/python', stderr='')

# Generated at 2022-06-10 23:20:21.198086
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    import ansible.constants as C
    import ansible.plugins.loader

    # Setup the TaskQueueManager
    TQM = None

# Generated at 2022-06-10 23:20:59.974563
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print(discover_interpreter(None,'python','auto',{}))

# Generated at 2022-06-10 23:21:14.095786
# Unit test for function discover_interpreter
def test_discover_interpreter():
    with open('./test/integration/targets/platform_python_map.json') as f:
        raw_map = json.load(f)

    # make platform_python_map work without config context
    platform_python_map = dict()
    for k, v in raw_map.items():
        platform_python_map[k.replace('_', ' ')] = v

    class TestModule: pass
    class TestAction:
        def __init__(self):
            self.connection = TestModule()
            self.connection.has_pipelining = True
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, **kwargs):
            if cmd == 'command -v /usr/bin/python':
                return dict(stdout='/usr/bin/python')

# Generated at 2022-06-10 23:21:24.902427
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor import task_executor
    from ansible.executor.discovery import InterpreterDiscoveryRequiredError
    from ansible.playbook.play_context import PlayContext

    action = task_executor.ActionModule(task=None,
                                        connection=None,
                                        play_context=PlayContext(),
                                        loader=None,
                                        templar=None,
                                        shared_loader_obj=None)
    action._discovery_warnings = []

    task_vars = dict()

    assert discover_interpreter(action, 'python', 'auto_legacy', task_vars) == u'/usr/bin/python'


# Generated at 2022-06-10 23:21:36.989036
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Simplistic unit test for discover_interpreter
    """

    # Stub classes for the test
    class action(object):
        pass

    class connection(object):
        def __init__(self, pipelining):
            self.has_pipelining = pipelining

    class task_vars(object):
        pass

    # Use data from the configuration itself to ensure the test is reasonably realistic.
    action = action()
    action._connection = connection(C.config.get_config_value('DEFAULT_PIPELINING'))
    action._discovery_warnings = []
    task_vars = task_vars()

    # FUTURE: add tests for different discovery modes?

    if not C.DEFAULT_INTERNAL_POLL_INTERVAL:
        C.DEFAULT_INTERNAL_

# Generated at 2022-06-10 23:21:50.810391
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test an unsupported interpreter
    try:
        discover_interpreter(None, 'perl', None, None)
        assert False, 'Expected an error with unsupported interpreter'
    except ValueError:
        pass

    # Test unknown platform
    try:
        discover_interpreter(None, 'python', None, {'platform_type': 'unknown'}).value
        assert False, 'Expected an error with unknown platform'
    except NotImplementedError:
        pass

    # Test missing distro or version in platform info
    try:
        discover_interpreter(None, 'python', None, {'platform_type': 'linux', 'platform_dist_result': []}).value
        assert False, 'Expected an error with missing distro or version'
    except NotImplementedError:
        pass

    # Test missing

# Generated at 2022-06-10 23:21:59.268081
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.module_common import InterpreterInfo

    res = InterpreterInfo('python', 'auto')
    assert res.default_interpreter == '/usr/bin/python'
    res.run_discovery(task_vars={'ansible_python_interpreter': '/usr/bin/python3'})

    assert res.python_interpreter == '/usr/bin/python3'

    res.run_discovery(discovery_mode='auto_legacy_with_warnings', task_vars={'ansible_python_interpreter': '/usr/bin/python3'})
    assert res.python_interpreter == '/usr/bin/python3'


# Generated at 2022-06-10 23:22:08.986154
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_action = _TestAction()
    test_action._low_level_execute_command = lambda x, **y: {'stderr': '', 'stdout': 'PLATFORM\nlinux\nFOUND\n/usr/bin/python\n/usr/bin/python3\nENDFOUND'}
    test_action._connection = _TestConnection()
    test_action._discovery_warnings = []
    test_interpreter = discover_interpreter(test_action, 'python', 'auto', {'inventory_hostname': 'testhost'})
    assert test_interpreter == '/usr/bin/python'

# Generated at 2022-06-10 23:22:13.865316
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts import ansible_local, ansible_module_facts
    from ansible.module_utils.facts import is_executable
    from ansible.module_utils import fact_cache
    from ansible.module_utils.facts import get_module_path


# Generated at 2022-06-10 23:22:18.614966
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # test_discover_interpreter starts here
    interpreter_name = 'python'
    discovery_mode = 'auto'
    action = ''
    task_vars = {}

    print(discover_interpreter(action, interpreter_name, discovery_mode, task_vars))

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-10 23:22:27.057159
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import doctest
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.distro import LinuxDistribution
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display
    import sys
    import io

    display = Display()

    # Save real stdout, then replace with io.StringIO() file-like object,
    # so we can test the print() calls in the function.
    stdout_saved, sys.stdout = sys.stdout, io.StringIO()