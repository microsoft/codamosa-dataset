

# Generated at 2022-06-10 23:12:54.190669
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.executor.module_common import ActionBase
    from ansible.module_utils.connection import Connection

    class Action(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None, executable=None):
            if cmd == "/usr/bin/python":
                return {"stdout": to_bytes(json.dumps({"platform_dist_result": ["ubuntu", "16.04", "xenial"]}))}
            elif cmd == "command -v 'python'":
                return {"stdout": "PLATFORM\nlinux\nFOUND\n/usr/bin/python\nENDFOUND"}

# Generated at 2022-06-10 23:13:05.580166
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as ActionModule_normal
    from ansible.vars.manager import VariableManager

    class ActionModule(ActionModule_normal):
        def _execute_module(self, tmp=None, task_vars=None):
            pass

    class Host:
        def __init__(self, name):
            self.name = name
            self.vars = dict()

    class Connection:
        def __init__(self, pipelining_support=None):
            self._pipelining_support = pipelining_support

        def has_pipelining(self):
            return self._pipelining_support

    class PlayContext:
        def __init__(self, connection=None):
            self.connection = connection


# Generated at 2022-06-10 23:13:09.877400
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """ Unit test for ansible.executor.discovery.discover_interpreter """

    # Test error when trying to discover an unknown interpreter
    action = get_dummy_plugin()
    with pytest.raises(ValueError):
        discover_interpreter(action, 'unknown', 'auto', {})



# Generated at 2022-06-10 23:13:23.803051
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.module_utils.common.removed import removed

    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    import ansible.plugins.action.setup as setup
    import ansible.module_utils.basic as basic
    import ansible.module_utils.pycompat24 as pycompat24
    import ansible.module_utils.python_version_discovery as pvd

    mock_action = mock.MagicMock(spec=setup.ActionModule)

    mock_action._discovery_warnings = []
    mock_action._low_level_execute_command = mock.MagicMock()


# Generated at 2022-06-10 23:13:33.377204
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        pass

    class TestTask(Task):
        action_cls = TestAction

    class TestModule:
        class TestTask:
            class TestAction:
                class TestModule(ActionBase):
                    pass

        task_cls = TestTask

    display.verbosity = 4
    display.warning = lambda msg: msg
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {
        'inventory_hostname': 'localhost',
        'ansible_python_interpreter': '',
        'ansible_connection': 'local',
        'ansible_playbook_python': 'python'
    }

    test_module = TestModule()
   

# Generated at 2022-06-10 23:13:45.518397
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Python interpreter discovery not supported for 'perl'
    assert discover_interpreter(None, 'perl', None, None) is None

    # test _get_linux_distro
    assert _get_linux_distro({}) == ('', '')

    # test _get_linux_distro
    assert _get_linux_distro({'platform_dist_result': [u'Debian', u'9', u'']}) == ('Debian', '9')

    # test _get_linux_distro

# Generated at 2022-06-10 23:13:56.781850
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    task_vars['inventory_hostname'] = 'testhost'
    action = MockAction()
    # Test distro that matches exactly
    raw_stdout = u"PLATFORM\nLinux\nFOUND\n/usr/bin/python2.7\n/usr/bin/python3.6\nENDFOUND"
    action.results_dict['stdout'] = raw_stdout
    test_res = discover_interpreter(action, 'python', 'auto', task_vars)
    assert test_res == "/usr/bin/python2.7"
    # Test with a distro that does not match exactly

# Generated at 2022-06-10 23:14:09.404930
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:14:11.413589
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: how do we test the discover_interpreter function?
    pass

# Generated at 2022-06-10 23:14:11.983103
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # TODO: add unit tests.
    pass

# Generated at 2022-06-10 23:14:31.360098
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_plugins.discovery import discover_interpreter
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict

    task_vars = ImmutableDict({
        'inventory_hostname': 'localhost',
        'ansible_connection': 'local'
    })

    interpreter_name = 'python'
    discovery_mode = 'auto'


# Generated at 2022-06-10 23:14:42.617208
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins import module_loader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    module = module_loader.get('debug', class_only=True)
    task_vars = {'test_var': 'test_val'}
    display.verbosity = 3
    display.debug = True
    # Test a failing discovery
    action = module.ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    try:
        interpreter = discover_interpreter(action, 'python2', 'explicit_auto', task_vars)
        assert False, "The discovery should have failed"
    except InterpreterDiscoveryRequiredError:
        pass

    # Test a working discovery with the required information


# Generated at 2022-06-10 23:14:50.394228
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Python 2 and 3: try to import mock (python-mock in PyPI, python3-mock in EPEL)
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    def _mock_connection_class_init(self, *args, **kwargs):
        pass

    def _mock_has_pipelining(self):
        return True

    def _mock_run_cmd(self, cmd, sudoable=False, in_data=None):
        if cmd[0].endswith('uname'):
            return {'stdout': "{0}\n".format('LINUX'), 'rc': 0}


# Generated at 2022-06-10 23:15:01.455104
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''Test discover_interpreter'''
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.connection import Connection

    class TestAction:
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=None, in_data=None, executable='/bin/sh'):
            '''Simulate _low_level_execute_command()'''

# Generated at 2022-06-10 23:15:11.865419
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader
    from ansible.plugins.action import ActionBase

    class MockActionModule(ActionBase):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(MockActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self._low_level_execute_command = MockTaskExecutor(self._display).execute_command
            self._discovery_warnings = []

    class MockTaskExecutor(object):
        def __init__(self, display):
            self.display = display


# Generated at 2022-06-10 23:15:15.268981
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    interpreter_name = 'python'
    discovery_mode = 'auto'
    action = None

    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == '/usr/bin/python'

# Generated at 2022-06-10 23:15:28.107612
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python3', 'auto', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python3', 'auto_legacy', {}) == '/usr/bin/python'

# Generated at 2022-06-10 23:15:41.692308
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:15:50.633659
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:15:54.980508
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Create some test data for the function
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = None

    # Call the function
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    # Check the result
    assert res is None

# Generated at 2022-06-10 23:16:16.317937
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from more_itertools import last
    from ansible.module_utils.distro import LinuxDistribution

    major_platform_data = {
        'Mint': {
            '18': {
                '2.0': '3.0',
                'newer': '3.0',
                'older': '2.7',
                'older_os': '15.0'
            },
            '15': {
                '2.7': '2.7',
                'newer': '2.7'
            },
            'older_os': {
                'older': '2.7'
            }
        },
        'older_os_major': {
            'older': '2.7'
        }
    }

    # tests are ordered in this list by increasing significance of failure
    #

# Generated at 2022-06-10 23:16:29.082271
# Unit test for function discover_interpreter
def test_discover_interpreter():
    def _test_case(action, interpreter_name, discovery_mode, task_vars,
                   expected_result, expected_warnings=None, expected_error=None):
        expected_warnings = expected_warnings or []

# Generated at 2022-06-10 23:16:38.578967
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.plugins import module_loader
    from ansible.module_utils.facts import ModuleArgsParser

    # Setup mock interpreter_pythons

# Generated at 2022-06-10 23:16:49.974294
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.module_utils.interpreter_discovery as interpreter_discovery

    # test case 1 - unknown os_family
    try:
        action = None
        task_vars = {'ansible_facts': {'os_family': 'Windows'}}
        interpreter_discovery.discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)
    except Exception as ex:
        assert ex.message == 'unsupported platform for extended discovery: unknown'

    # test case 2 - unsupported os_distribution

# Generated at 2022-06-10 23:17:01.823082
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    task_vars['interpreter_python_distro_map'] = {
        'redhat': { '7': '/usr/bin/python2.7' },
        'rhel': { '7': '/usr/bin/python2.7' },
        'centos': { '7': '/usr/bin/python2.7' },
        'scientific': { '7': '/usr/bin/python2.7' },
        'fedora': { '28': '/usr/local/python2.7', '24': '/usr/bin/python2.7' },
        'oracle': { '7': '/usr/bin/python2.7' },
        'amazon': { '1': '/usr/bin/python2.7' },
    }


# Generated at 2022-06-10 23:17:14.062766
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.plugins.action import ActionBase
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.connection import ConnectionBase

    class ActionModule(ActionBase):

        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task

# Generated at 2022-06-10 23:17:25.620779
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.action.discovery
    action = ansible.plugins.action.discovery.ActionModule(None)

    task_vars = {
        'inventory_hostname': 'localhost',
        'ansible_connection': 'local',
    }

    class DummyConnection:
        def __init__(self, has_pipelining):
            self._has_pipelining = has_pipelining

        def has_pipelining(self):
            return self._has_pipelining

        def close(self):
            pass

    # unix
    action._connection = DummyConnection(True)
    data = discover_interpreter(action, 'python', 'auto_legacy', task_vars)
    assert data == '/usr/bin/python'

# Generated at 2022-06-10 23:17:30.851164
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert _version_fuzzy_match('1.2.3.4', {'3': '3', '3.1': '3.1'}) == '3'
    assert _version_fuzzy_match('9.9.9.9', {'3': '3', '3.1': '3.1'}) == '3.1'
    assert _version_fuzzy_match('9.9.9.9', {'3': '3', '3.1': '3.1', '3.2': '3.2'}) == '3.2'

    # all patches

# Generated at 2022-06-10 23:17:42.441721
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = FakeAction()
    task_vars = dict()
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'

# Generated at 2022-06-10 23:17:53.164298
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.executor.play_context import PlayContext

    class FakeConnection(object):
        @staticmethod
        def has_pipelining():
            return True

    class FakeRunner(object):
        def __init__(self):
            self.host_name = 'localhost'
            self.connection = FakeConnection()
            self.action = action_loader.get('script', class_only=True)
            self.task_vars = dict()

        def _execute_module(self):
            discover_interpreter(self.action, 'python', 'auto', self.task_vars)


# Generated at 2022-06-10 23:18:09.521917
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    task_vars['inventory_hostname'] = 'test_host'
    action = dict()
    action['_discovery_warnings'] = []
    action['_low_level_execute_command'] = dict()
    action['_low_level_execute_command']['stdout'] ='PLATFORM\r\nLinux\r\nFOUND\r\n/usr/bin/python\r\n/usr/bin/python3.5\r\nENDFOUND'


# Generated at 2022-06-10 23:18:19.567090
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:18:32.544263
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from ansible.executor.action_loader import ActionModuleLoader
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.network.common.config import NetworkConfig

    module = ActionModuleLoader().get('raw', class_only=True)

    class DummyConnection(object):
        def __init__(self, has_pipelining=False):
            self.has_pipelining = has_pipelining

        def exec_command(self, cmd, sudoable=False):
            raw_stdout = ''
            if cmd == "echo PLATFORM; uname; echo FOUND; command -v '/usr/bin/python'; echo ENDFOUND":
                raw_stdout = "PLATFORM\r\nLinux\r\n" \
                             "FOUND\r\n"

# Generated at 2022-06-10 23:18:40.327802
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_host_vars = {}

    # test a few different discovery modes and comment out the one you want to run
    # discovery_mode = 'auto_legacy'
    discovery_mode = 'auto'
    # discovery_mode = 'auto_silent'


# Generated at 2022-06-10 23:18:42.679377
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', '', dict()) == u'/usr/bin/python'

# Generated at 2022-06-10 23:18:56.322679
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert _version_fuzzy_match("6.5", {"6.4": "/usr/bin/python/6.4", "6.5": "/usr/bin/python/6.5"}) == "/usr/bin/python/6.5"
    assert _version_fuzzy_match("6.1", {"6.4": "/usr/bin/python/6.4", "6.5": "/usr/bin/python/6.5"}) == "/usr/bin/python/6.4"
    assert _version_fuzzy_match("6.6", {"6.4": "/usr/bin/python/6.4", "6.5": "/usr/bin/python/6.5"}) == "/usr/bin/python/6.5"

# Generated at 2022-06-10 23:18:57.218896
# Unit test for function discover_interpreter
def test_discover_interpreter():
    raise NotImplementedError('Tests not implemented yet')

# Generated at 2022-06-10 23:18:58.974191
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement
    display.warning(u"TODO: implement test_discover_interpreter")

# Generated at 2022-06-10 23:19:11.137707
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None

# Generated at 2022-06-10 23:19:21.603949
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: FUTURE: add test cases for the actual, extended discovery
    # TODO: FUTURE: add test cases for the legacy discovery behavior
    # TODO: FUTURE: add test cases for the silent discovery behavior
    # TODO: FUTURE: add test cases for the on-disk discovery behavior
    # TODO: FUTURE: consider adding/using a mock library?

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-10 23:19:46.989075
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action.normal import DummyConnection

    class ActionModule(_ActionModule):
        def _get_shebang(self, filename, is_playbook):
            return '/usr/bin/python'

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None, executable=None):
            if cmd == '/usr/bin/python':
                return {'stdout': 'asdf', 'stderr': ''}
            elif executable == '/usr/bin/python':
                return {'stdout': json.dumps({'osrelease_content': '[    ID="rhel",    VERSION_ID="7.2"]'}), 'stderr': ''}


# Generated at 2022-06-10 23:19:55.061098
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Set up test parameters
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict()
    answer = '/usr/bin/python'
    # Call function
    try:
        result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except InterpreterDiscoveryRequiredError as e:
        result = e
    # Check result
    assert result == answer

# Generated at 2022-06-10 23:20:08.296212
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    import unittest

    from ansible.utils.path import unfrackpath
    from ansible_collections.ansible.misc.tests.unit.compat.mock import patch, mock_open, MagicMock
    from ansible.module_utils.common.collections import ImmutableDict
    #from ansible.module_utils.common import get_distribution



    class TestDiscoveryInterpreter(unittest.TestCase):
        def setUp(self):
            # Setup a mock configuration, to get the config file
            p = patch('ansible.module_utils.discovery.C.config.get_config_file')
            p.start()
            self.addCleanup(p.stop)

            # Mock ansible_hosts_file

# Generated at 2022-06-10 23:20:19.703134
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:20:32.816984
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule

    action = ActionModule(connection=None, play_context=None)

    # Test auto_legacy_silent
    fake_env = dict(TEST_DISCOVER_INTERPRETER_MAP='{"xenial": {"16.04": "/usr/bin/python", "18.04": "/usr/bin/python3"}}',
                     TEST_DISCOVER_INTERPRETER_BOOTSTRAP=u'["/usr/bin/python", "/usr/bin/python3"]',
                     TEST_DISCOVER_INTERPRETER_TASK_VARS=u'{}')

    def fake_get_option(key):
        return fake_env.get(key)

    action._get_action_option = fake_get_option

    res = discover_interpre

# Generated at 2022-06-10 23:20:41.469463
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play

    from ansible.plugins.action import ActionBase
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    class DummyModule(object):
        def __init__(self, task_vars=dict()):
            self._task_vars = task_vars

    class DummyAction(ActionBase):
        def __init__(self):
            self._discovery_warnings = []


# Generated at 2022-06-10 23:20:54.238330
# Unit test for function discover_interpreter
def test_discover_interpreter():
    mock_task_vars1 = {'inventory_hostname': 'test_host', 'platform': 'someunknownplatform'}
    mock_task_vars2 = {'inventory_hostname': 'test_host', 'platform': 'linux'}
    mock_task_vars3 = {'inventory_hostname': 'test_host', 'platform': 'linux', 'osrelease_content': ''}

    mock_module_args = {'_ansible_verbosity': 0, '_ansible_no_log': False, '_ansible_debug': False}

    # INITIAL: initial state before discovery
    # DISCOVERY_MODE: discovery mode to use
    # PLATFORM: platform type we'll emulate from the discovery command
    # FOUND: list of interpreters found by discovery command
    # STDOUT: expected stdout for

# Generated at 2022-06-10 23:21:05.517861
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.module_utils._text import to_bytes

    class TestAction(ActionBase):
        def _low_level_execute_command(self, command, in_data=None, sudoable=True):
            self._low_level_execute_command.script = command
            self._low_level_execute_command.sudoable = sudoable
            if in_data:
                self._low_level_execute_command.in_data = in_data
            return self.module


# Generated at 2022-06-10 23:21:18.618263
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Unit test for function discover_interpreter
    def test_discover_interpreter_with_discovery_mode(discovery_mode):
        action = None
        interpreter_name = 'python'
        return discover_interpreter(action, interpreter_name, discovery_mode, None)

    # Test discover_interpreter with parameter discovery_mode = auto
    test_discover_interpreter_with_discovery_mode('auto')

    # Test discover_interpreter with parameter discovery_mode = auto_legacy
    test_discover_interpreter_with_discovery_mode('auto_legacy')

    # Test discover_interpreter with parameter discovery_mode = auto_silent
    test_discover_interpreter_with_discovery_mode('auto_silent')

    # Test discover_interpreter

# Generated at 2022-06-10 23:21:31.841220
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Note: We need to mock out the AnsibleModule and the function _discovery_warnings
    # so that we are not relying on the existence of the module or the function
    from ansible.playbook.role.include import IncludeRole
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):

        class MockConnection(object):
            def __init__(self, has_pipelining=True, *args, **kwargs):
                self.has_pipelining = has_pipelining

            def has_pipelining(self):
                return self.has_pipelining


# Generated at 2022-06-10 23:22:19.272116
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:22:27.561043
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import tempfile

    task_vars = {'inventory_hostname': 'localhost', 'ansible_connection': 'local' }
    action = DummyAction()

# Generated at 2022-06-10 23:22:36.311442
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import interpreter_discovery

    module = AnsibleModule(
        argument_spec=dict(
            discovery_mode=dict(type='str', default='auto_silent')
        ),
        supports_check_mode=True
    )

    result = dict(
        changed=False,
        interpreter=interpreter_discovery.discover_interpreter(
            module, 'python', module.params.get('discovery_mode'), dict()
        )
    )

    module.exit_json(**result)

