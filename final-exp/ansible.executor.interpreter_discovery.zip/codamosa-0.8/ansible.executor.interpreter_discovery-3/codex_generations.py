

# Generated at 2022-06-10 23:12:49.142584
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils._text import to_bytes

    action = Mock()
    action._low_level_execute_command = lambda x, **kw: {'stdout': x}
    action._connection = Mock()
    action._connection.has_pipelining = True
    action._discovery_warnings = []

    # return the same thing for each platform.dist test. this is as close to a unit test as we can hope to get without
    # a real implementation of that function.
    action._low_level_execute_command.side_effect = lambda x, **kw: {'stdout': to_bytes(x, encoding=None)}


# Generated at 2022-06-10 23:12:59.929903
# Unit test for function discover_interpreter
def test_discover_interpreter():
    C.DEFAULT_INTERPRETER_DISCOVERY_MODE = 'auto_legacy_silent'
    C.config.initialize_plugin_configuration_definitions()
    C.config.get_config_value('ANSIBLE_INTERPRETER_DISCOVERY_MODE')

    action = None
    task_vars = {}
    class Action(object):
        _discovery_warnings = []
        _connection = None

        class Connection(object):
            def __init__(self, has_pipelining):
                self.has_pipelining = has_pipelining

        def __init__(self, has_pipelining=False):
            self._connection = Action.Connection(has_pipelining)


# Generated at 2022-06-10 23:13:01.388534
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass


# Generated at 2022-06-10 23:13:11.900378
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    task_vars = dict()

    # Test normal case
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    host = 'example.com'
    task_vars['inventory_hostname'] = host
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    if res != '/usr/bin/python':
        print("Failed: discover_interpreter returned incorrect value: %s, expected %s" % (res, '/usr/bin/python'))
        return 1

    # Test invalid interpreter name
    interpreter_name = 'foo'
    discovery_mode = 'auto_legacy'
    host = 'example.com'
    task_vars['inventory_hostname'] = host

# Generated at 2022-06-10 23:13:24.137512
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockTaskActionModule(object):
        def __init__(self):
            self._connection = MockConnection()
            self._discovery_warnings = []


# Generated at 2022-06-10 23:13:33.566268
# Unit test for function discover_interpreter
def test_discover_interpreter():
    if platform.python_implementation() != 'PyPy':
        raise unittest.SkipTest("Skipping, only works for PyPy")

    from ansible.tests.unit.compat import mock
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import _global_action_args

    # Create mock return values for a number of tasks/calls
    task_vars = {'inventory_hostname': 'mock_host'}

    # Create mock action with a shared task arguments and populates it with initial parameter values
    action = mock.Mock(run_what='module', _global_action_args=_global_action_args)
    action.no_log = False
    action.task_vars = task_vars
    action._discovery_warnings = []

# Generated at 2022-06-10 23:13:45.664814
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: mock away the actual module calls
    # TODO: test _version_fuzzy_match
    import sys
    import collections
    import platform
    import tempfile

    # TODO: add tests of OSX, FreeBSD, etc.

# Generated at 2022-06-10 23:13:56.916338
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # These are not complete or perfect tests, but are a start
    # TODO: more tests, better mocking, etc.
    print("Testing discover_interpreter")
    import sys
    from ansible.module_utils import basic
    fake_display = basic.AnsibleModuleHelper(
        argument_spec={},
        supports_check_mode=False,
        bypass_checks=True,
    )
    fake_display.basic(display)

    interpreter_name = "python"

    real_discovery_warning_set = set()

    class FakeActionModule(object):
        _connection = None
        _low_level_execute_command_value = None
        _discovery_warnings = real_discovery_warning_set


# Generated at 2022-06-10 23:14:06.743562
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    task_vars = {}
    action = ActionBase()
    action._display = display

    try:
        discover_interpreter(action, interpreter_name='python', discovery_mode='auto_silent', task_vars=task_vars)
    except InterpreterDiscoveryRequiredError as e:
        # expected to raise an exception, since the default task_vars are empty
        assert e is not None

    # TODO: test_discover_interpreter: add tests for different discovery modes/fallback behavior
    # TODO: test_discover_interpreter: add tests for remote results

# Generated at 2022-06-10 23:14:19.072664
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts import Facts
    from ansible_collections.ansible.netcommons.plugins.module_utils.network.netcommons.facts.facts import Facts as NetworkFacts

    action = NetworkFacts(module=Facts(module=object()))
    interpreter_name = "python"
    discovery_mode = "auto_silent"
    task_vars = dict()
    # task_vars = {'ansible_interpreter_python': '/usr/bin/python'}
    actual = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    expected = "/usr/bin/python"
    assert actual == expected, \
        "actual {0} is not match expected {1}" \
        .format(actual, expected)



# Generated at 2022-06-10 23:14:41.441190
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:14:49.651908
# Unit test for function discover_interpreter
def test_discover_interpreter():
    platform_info = dict()

# Generated at 2022-06-10 23:14:52.290093
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, u'python', u'auto', {}) == '/usr/bin/python3'

# Generated at 2022-06-10 23:15:03.005492
# Unit test for function discover_interpreter
def test_discover_interpreter():
    all_discovery_modes = C.config.get_config_value('INTERPRETER_DISCOVERY', variables={})
    modes = [discovery_mode for discovery_mode, value in all_discovery_modes.items() if value]

    # mock that we want to discover a python interpreter
    interpreter_name = 'python'

    # mock the task_vars to use
    task_vars = dict()

    # mock a connection object (with no pipelining capability).
    # required to instantiate an action
    connection = dict()
    connection['has_pipelining'] = False

    # mock an action object
    action = dict()
    action['_connection'] = connection
    action['_discovery_warnings'] = []

    # mock a connection method to handle low_level_execute_command

# Generated at 2022-06-10 23:15:12.882750
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible import constants as C

    C.config.set_config_value('INTERPRETER_PYTHON_DISTRO_MAP', {'redhat': {'7.4': '/usr/bin/python2.7'}}, None)
    C.config.set_config_value('INTERPRETER_PYTHON_FALLBACK', ['python3', 'python'], None)

    # redhat 7.4 has python2.7 as the expected interpreter
    fake_pipeline_res = {'stdout': b"PLATFORM\nLinux\nFOUND\n/usr/bin/python\n"
                                   b"/usr/bin/python2.7\n/usr/bin/python3\nENDFOUND"}

# Generated at 2022-06-10 23:15:26.859277
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule

    display.verbosity = 4
    display.debug = True

    # Mock imports needed for discovery
    import __builtin__

# Generated at 2022-06-10 23:15:33.885686
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    # create test action
    action = AnsibleModule(argument_spec={})

    # Test exception for NotImplementedError
    # test for NotImplementedError
    action._low_level_execute_command = lambda cmd, sudoable=False, in_data=None: \
        {"stdout": "PLATFORM\nNo_Platform_Type\nFOUND\n/bin/python\n"
                   "/bin/python3\n/usr/lib/python3.6/python3.6\n"
                   "/usr/bin/python\n/usr/bin/python3\nENDFOUND"}


# Generated at 2022-06-10 23:15:46.322653
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add tests for auto_silent and auto_legacy_silent modes; need to mock out the config value loading,
    #  task_vars and action._discovery_warnings
    action = mock_action()
    task_vars = {'inventory_hostname': u'localhost'}

    # test an exception is raised if we try to determine an interpreter other than 'python'
    ex = get_custom_exception(ValueError, 'Interpreter discovery not supported for python3')
    assert exception_is_expected(ex, discover_interpreter, 'local', 'python3', 'auto', task_vars)

    # test NotImplementedError is correctly handled for unsupported platform
    ex = get_custom_exception(NotImplementedError, 'unsupported platform for extended discovery: windows')
    assert exception_is

# Generated at 2022-06-10 23:15:55.617743
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible
    import ansible.plugins
    ansible.modules.packages.platform = None
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.result import ResultProcessor
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    class MockDisplay(Display):
        def __init__(self):
            super(MockDisplay, self).__init__()
            self.logs = []

        def vvv(self, msg, *args, **kwargs):
            self.logs.append('vvv: {0}'.format(msg))

        def debug(self, msg, *args, **kwargs):
            self.logs.append('debug: {0}'.format(msg))


# Generated at 2022-06-10 23:16:08.433979
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import get_all_plugin_loaders, get_loader
    from ansible.plugins.action import ActionBase

    # Create a dummy host and group for testing
    test_host = Host(name='testhost')
    test_group = Group(name='testgroup')
    test_group.add_host(test_host)
    # Create a dummy inventory and add group to it
    test

# Generated at 2022-06-10 23:16:31.383680
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.mock.mock_action_plugin import MockActionBase

    # Create a minimal action object
    class mock_action(MockActionBase):
        class ActionModule(object):
            pass
        action_class = ActionModule()

        _low_level_execute_command = lambda self, *args, **kwargs: {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'}

    action = mock_action()
    # Create a minimal task_vars object
    task_vars = dict()

    assert(discover_interpreter(action, 'python', 'auto', task_vars) == '/usr/bin/python')
    action._discovery_warnings = []


test_discover_interpreter()

# Generated at 2022-06-10 23:16:39.820666
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible
    import os

    # mock modules
    ansible_path = os.path.dirname(os.path.dirname(ansible.__file__))

    class ActionBase:
        class Command(object):
            def __init__(self, module_name=None, module_args=None, transformed_args=None, add_ansible_lib_vars=None,
                         remove_tmp=True, as_json=False, shebang=None, target_name=None, wrap_async=None, become=False,
                         become_method=None, become_user=None, extra_args=None, stdin=None, stdin_add_newline=True,
                         strip_empty_ends=True):
                pass


# Generated at 2022-06-10 23:16:50.968313
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test to see if the default fall-back is returned for a unix platform that is not Red Hat.
    result = discover_interpreter('action', 'python', 'auto', {'inventory_hostname': 'unknown_host',
                                                               'ansible_facts': {'distribution': 'AIX'}})
    assert to_text(result) == u'/usr/bin/python'

    # Test to see if the fall-back specified in ansible.cfg is returned for a unix platform that is not Red Hat.

# Generated at 2022-06-10 23:17:02.742977
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import tempfile
    import shutil
    import subprocess
    import os

    # Create temp directory and test file containing 3 os-release files
    tempdir = tempfile.mkdtemp()
    test_file = os.path.join(tempdir, 'test_file')
    os_release = [
        'NAME="SUSE Linux Enterprise Server"\n'
        'VERSION="12"\n'
        'VERSION_ID="12"\n'
        'PRETTY_NAME="SUSE Linux Enterprise Server 12"'
    ]
    with open(test_file, 'w') as f:
        for i, release in enumerate(os_release):
            f.write('#%s\n' % i)
            f.write(release)
            f.write('\n')


# Generated at 2022-06-10 23:17:14.398154
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.connection import Connection
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    import pytest

    # Create a mock object to store needed internals
    class ActionBase:
        def __init__(self):
            self.connection = Connection()

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            return in_data

    class Playbook:
        def __init__(self):
            pass


# Generated at 2022-06-10 23:17:26.196208
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    class UnsafeDict(dict):
        def get(self, key, default=None):
            if key == 'inventory_hostname':
                return 'testhost.example.com'

            return super(UnsafeDict, self).get(key, default)

    class TestInterpreterDiscovery(unittest.TestCase):
        def setUp(self):
            # needed to load config
            C._init_global_vars()

            self.task_vars = UnsafeDict()

            # C.DEFAULT_MODULE_UTILS is set in C._init_global_vars, and we have no way to override it
            # mock the filesystem instead of patching (and breaking) the setting
            import mock

# Generated at 2022-06-10 23:17:34.988203
# Unit test for function discover_interpreter
def test_discover_interpreter():  # noqa
    from ansible.executor.task_executor import TaskExecutor
    from ansible.module_utils.connection import Connection
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins import module_loader
    from ansible.executor.discovery import InterpreterDiscoveryRequiredError
    from ansible.module_utils.connection import ConnectionError

    conn_args = {'remote_addr': '127.0.0.1', 'module_name': 'shell'}

    # test case 1: discover_interpreter - action._connection.module_implementation_preferences is empty,
    #              sudoable=False, python interpreter is missing from the platform
    conn_args['module_name'] = 'command'

# Generated at 2022-06-10 23:17:36.709955
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Unit test for function discover_interpreter
    """
    pass

# Generated at 2022-06-10 23:17:50.449529
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action_name = 'win_ping'
    host = "testhost"
    error_message = "An error message"
    fake_stdout = 'fake stdout'
    with pytest.raises(ValueError) as excinfo:
        discover_interpreter(action_name, 'python3', 'auto_legacy_silent', host, fake_stdout)
    assert error_message == str(excinfo.value)
    with pytest.raises(NotImplementedError) as excinfo:
        discover_interpreter(action_name, 'python', 'auto_legacy_silent', host, 'fake stdout')
    assert error_message == str(excinfo.value)

# Generated at 2022-06-10 23:17:51.270892
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:18:20.580302
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test with no interpreter name
    action = None
    interpreter_name = u''
    discovery_mode = u'auto_legacy_silent'
    task_vars = {}
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        assert False
    except ValueError as e:
        assert str(e) == 'Interpreter discovery not supported for python'
    except:
        assert False

    # test with unsupported interpreter name
    action = None
    interpreter_name = u'perl'
    discovery_mode = u'auto_legacy_silent'
    task_vars = {}

# Generated at 2022-06-10 23:18:33.744727
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_loader import ActionModuleLoader
    import sys
    import json

    platform_python_map = {
        "centos": {
            # "7.1.1503": None,
            "7.2.1511": u"/usr/bin/python2.7",
            "7.3.1611": u"/usr/bin/python2.7"
        },
        "redhat": {
            "7.3": u"/usr/bin/python2.7",
            "7.4": u"/usr/bin/python2.7"
        }
    }

    # FUTURE: once we have other options, this should be a task_vars value for
    #         the test hosts

# Generated at 2022-06-10 23:18:45.978297
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.interpreter import InterpreterFacts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import Time

    host = 'localhost'
    action = BaseFactCollector(setup_collector=False, connection=None, task_vars=dict(inventory_hostname=host))
    action._discovery_warnings = []
    action._low_level_execute_command = mock_low_level_execute_command
    action._connection = FakeConnection()
    action._legacy_mode = True
    # First test that discovery fails with a non-python interpreter

# Generated at 2022-06-10 23:18:49.849097
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    task_vars = {}
    #TODO(ettlmartin): write test
    discover_interpreter(action, 'python', 'auto', task_vars)

# Generated at 2022-06-10 23:18:58.698014
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module_path = "/var/ansible/test/test.py"
    display.verbosity = 4
    display.debug_level = 4
    display.output = "all"
    class_action = _FakeActionModule()
    task_vars = dict()
    task_vars["ansible_python_interpreter"] = "python2"
    task_vars["ansible_interpreter_discovery_mode"] = "auto_legacy_silent"
    discover_interpreter(class_action, 'python', 'auto_legacy_silent', task_vars)
    assert display.verbosity == 4
    assert display.debug_level == 4
    assert display.output == "all"



# Generated at 2022-06-10 23:19:10.974533
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.plugins.action import ActionBase


# Generated at 2022-06-10 23:19:21.432712
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.utils.scheduler import JobScheduler
    from ansible.playbook.task import Task
    from ansible.playbook.context import TaskContext
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import module_loader
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess
    from ansible.executor.process.clear import ResultClearingProcess
    import os
    import select
    import sys
    import ansible.release
    import time

    # For interpreter discovery to work, C.config.get_config_value

# Generated at 2022-06-10 23:19:22.396600
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO:
    assert False

# Generated at 2022-06-10 23:19:34.105461
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.plugins.action.python_interpreter import ActionModule

    # Test 1: Test the basic case
    test_action_module = ActionModule()
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto'

# Generated at 2022-06-10 23:19:44.047530
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = ActionModule(connection=None, runner_queue=None)
    task_vars = {}

    # /usr/bin/python should be returned when interpreter discovery is not supported for the given interpreter
    assert discover_interpreter(action, 'ruby', 'auto', task_vars) == u'/usr/bin/python'

    # /usr/bin/python should be returned when uname fails to return a platform name
    # TODO: is this issue fixed or not? if so, how can we simulate it?
    #assert discover_interpreter(action, 'python', 'auto', task_vars) == u'/usr/bin/python'

    # /usr/bin/python should be returned when a discovery case is not implemented

# Generated at 2022-06-10 23:20:33.538802
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Override the constants
    C.DEFAULT_INTERPRETER_DISCOVERY_MODE = "auto_legacy_silent"
    C.DEFAULT_INTERPRETER_PYTHON_FALLBACK = ["/usr/bin/python3", "/usr/bin/python2", "/usr/bin/python"]

# Generated at 2022-06-10 23:20:42.014966
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TestAction(object):
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            if command == 'command -v /usr/bin/python3':
                return {'stdout': '', 'stderr': ''}
            elif command == 'command -v /usr/bin/python2':
                return {'stdout': '/usr/bin/python2', 'stderr': ''}
            elif command == '/usr/bin/python2':
                if in_data:
                    return {'stdout': '{"platform_dist_result": ["debian", "9", ""], '
                                      '"osrelease_content": ""}', 'stderr': ''}

# Generated at 2022-06-10 23:20:54.681426
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """This only tests the discover_interpreter function, as that's the only user-visible functionality"""
    import shutil
    try:
        from ansible.module_utils.distro import Distribution
        from ansible.module_utils.facts import default_collectors

        from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
        from ansible.module_utils import basic

    except Exception:
        # FIXME: actually require the above stuff in a proper unit test/suite
        try:
            shutil.rmtree('./ansible_collections')
        except Exception:
            pass
        return True

    # intercept platform.dist output
    def mock_dist(full_distribution_name=0):
        return ['redhat', '5']

    # intercept /etc/os-

# Generated at 2022-06-10 23:20:56.915814
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Unit test for function discover_interpreter
    """
    # TODO: implement
    import pytest
    pytest.skip()

# Generated at 2022-06-10 23:21:04.654315
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from unittest import TestCase
    from .action_plugins.shell_common import ActionModule as ShellActionModule

    class TestDiscoveryActionModule(ShellActionModule):
        _discovery_warnings = []

        def _display_warnings(self):
            super(TestDiscoveryActionModule, self)._display_warnings()

            for warning in self._discovery_warnings:
                self._display.warning(msg=warning)

        def _prepare_exec_env(self):
            return ({}, {})

 

# Generated at 2022-06-10 23:21:18.010418
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash

    class TestAction(ActionBase):

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            return {'stdout': to_text(cmd), 'stderr': ''}

    action = TestAction('DummyModule', '/tmp/...', merge_hash({'connection': 'DummyConnection'}, {}, True))

    task_vars = {}
    assert(discover_interpreter(action, 'python', 'auto', task_vars) == '/usr/bin/python')
    assert(discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars) == '/usr/bin/python')

# Generated at 2022-06-10 23:21:19.400513
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass


# Generated at 2022-06-10 23:21:32.747489
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.script import ActionModule

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    class MockConnection(object):

        def __init__(self, supports_pipelining=True):
            self.supports_pipelining = supports_pipelining

        def __getattr__(self, name):
            return None

    class MockActionModule(ActionModule):

        def __init__(self, task_vars, tmpdir, supports_pipelining=True):
            self._low_level_execute_command = self._low_level_execute_command_pipelined_python \
                if supports_pipelining \
                else self._low_level_execute_command_on_disk_

# Generated at 2022-06-10 23:21:40.391373
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # add some mocks
    class ActionModuleMock(object):
        # TODO: this is a lame hack
        _low_level_execute_command = lambda self, py, sudoable, in_data=None: {'rc': 0, 'stdout': u'{}'}
        _connection = ActionModuleMock
        _connection.has_pipelining = True
        display = Display()
        _discovery_warnings = []

    action = ActionModuleMock()

    # arbitrary distro info from CI, from real-world data
    # FUTURE: just grab data from _get_linux_distro()

# Generated at 2022-06-10 23:21:41.058262
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass