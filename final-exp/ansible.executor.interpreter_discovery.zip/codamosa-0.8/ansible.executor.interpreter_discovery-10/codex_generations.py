

# Generated at 2022-06-10 23:12:48.474217
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins import action

    class TestAction(action.ActionBase):
        def __init__(self, *args, **kwargs):
            super(TestAction, self).__init__(*args, **kwargs)
            self._discovery_warnings = []
            self._connection = 'mock'

        def _low_level_execute_command(self, command, sudoable=True, in_data=None):
            if command.startswith('command -v'):
                return {'stdout': '/usr/bin/python'}

# Generated at 2022-06-10 23:12:59.514937
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # TODO: mock target interactions for unit testing?

    print("Test Python interpreter discovery")

    task_vars = {
        'ansible_distribution': 'Debian',
        'ansible_distribution_version': '8.0'
    }
    action = None
    interpreter_name = 'python'

    print("Test: interpreter discovery using custom interpreter (/usr/bin/python, which exists)")
    try:
        res = discover_interpreter(action, interpreter_name, 'auto_legacy_silent', task_vars)
        assert res == "/usr/bin/python"
    except NotImplementedError:
        print("Interpreter discovery not implemented for this target")

    print("Test: interpreter discovery using custom interpreter (/usr/bin/python, which does not exist)")

# Generated at 2022-06-10 23:13:10.458208
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys
    import pytest
    from ansible.utils.display import Display
    from ansible.utils.unit import get_data_loader
    from ansible.module_utils.compat.version import LooseVersion

    if LooseVersion(pytest.__version__) < LooseVersion('1.0'):
        # pytest < 1.0 checks if the test runner has an attribute called config
        # before calling pytest_configure on the plugin. So we add it here instead.
        setattr(sys, 'config', None)

    from ansible.module_utils.discovery import InterpreterDiscoveryRequiredError, discover_interpreter


# Generated at 2022-06-10 23:13:24.395128
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {"ansible_python_interpreter": "/usr/bin/python3"}
    # Test case 1
    task_vars['ANSIBLE_DISCOVERY_MODE'] = "auto_legacy_silent"
    action_test = ActionModule()
    expected_result = u"/usr/bin/python"
    discovered_interpreter = discover_interpreter(action_test, "python", "auto_legacy_silent", task_vars)
    assert discovered_interpreter == expected_result, "Not expected result"
    # Test case 2
    action_test = ActionModule()
    task_vars['ANSIBLE_DISCOVERY_MODE'] = "auto_silent"
    expected_result = u"/usr/bin/python"
    discovered_interpreter = discover_inter

# Generated at 2022-06-10 23:13:35.710499
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Function is being tested
    :return: dict of specific test cases.
    """
    error_msg = u'unexpected output from Python interpreter discovery'

# Generated at 2022-06-10 23:13:43.193914
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: test case for no python interpreters?
    # FUTURE: test case for a simply-missing interpreter?
    # FUTURE: test case for null output from platform script (to verify clean exception handling)?
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager

    class ActionTest:
        _discovery_warnings = []


# Generated at 2022-06-10 23:13:54.997760
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:14:07.018832
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # set up fake action object
    action = type('FakeAction', (), {})()
    action.check_mode = False
    action.no_log = False
    action.become = False
    action.become_user = None
    action.become_method = None
    action.set_become = True
    action.set_become_user = False
    action.set_become_method = False
    action.become_pass = None

    action._connection = type('FakeConnection', (), {})()
    action._connection.has_pipelining = True


# Generated at 2022-06-10 23:14:19.238733
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test bootstrap
    test1 = 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python3\nENDFOUND'
    test2 = 'PLATFORM\nLinux\nFOUND\nENDFOUND'
    test3 = ''
    test4 = 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'
    test5 = 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python2\n/usr/bin/python3\nENDFOUND'

# Generated at 2022-06-10 23:14:31.929701
# Unit test for function discover_interpreter
def test_discover_interpreter():
    #import _mock_discover_interpreter as mock_discover_interpreter
    #mock_discover_interpreter.setup()
    #import ansible.executor.discovery
    #ansible.executor.discovery = mock_discover_interpreter

    # Test discover_interpreter with python with default discovery mode and task_vars
    action = object()
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {}

    found_interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert found_interpreter == u'/usr/bin/python'

    # Test discover_interpreter with python with SILENT discovery mode and task_vars
    action = object()
    interpreter_name

# Generated at 2022-06-10 23:14:50.582013
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class ActionModule(object):
        def __init__(self):
            self._discovery_warnings = []
            self._low_level_execute_command = lambda interp, sudoable, in_data: {'stdout':u'PLATFORM\nLinux\nFOUND\n/usr/bin/python2\nENDFOUND',
                                                                                  'stderr':''}
        @property
        def connection(self):
            return self

        def has_pipelining(self):
            # we can use the old action plugin protocol just to test the mapping code
            return True

    # Case 1: Successful pipelining, with warnings
    action_module = ActionModule()

# Generated at 2022-06-10 23:14:52.590507
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', None) == '/usr/bin/python'

# Generated at 2022-06-10 23:15:03.382735
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class ActionModule:
        _discovery_warnings = []
        module_name = None
        module_args = None
        _connection = None

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            return dict(rc=0, stdout="FOUND", stderr="")

        def _execute_module(self, module_name, module_args, task_vars=None, wrap_async=None, wrap_async_timeout=None):
            pass

    action = ActionModule()

    # TODO: mock results from _low_level_execute_command
    # TODO: test discovery warnings

    # should be the same

# Generated at 2022-06-10 23:15:13.085671
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_interpreter_name = 'python'

    class ActionModule:
        _discovery_warnings = []

        def __init__(self):
            class Connection:
                def __init__(self):
                    self.has_pipelining = True

            self._connection = Connection

        @staticmethod
        def _low_level_execute_command(cmd, sudoable=False, in_data=None):
            if cmd == "/usr/bin/python":
                raise InterpreterDiscoveryRequiredError('interpreter discovery required', test_interpreter_name, 'auto')

            if cmd == "interpreter_not_found":
                return dict(stdout="")


# Generated at 2022-06-10 23:15:27.067960
# Unit test for function discover_interpreter
def test_discover_interpreter():
    os_type = {
        'distribution': 'Fedora',
        'distribution_version': '27',
        'distribution_release': 'Rawhide',
        'os_family': 'RedHat',
        'python': '/usr/bin/python'
    }
    task_vars = {
        'ansible_python_interpreter': None,
        'ansible_python_interpreter_discovery_mode': 'auto_legacy_silent',
        'ansible_distribution': 'Fedora',
        'ansible_distribution_version': '27',
        'ansible_distribution_release': 'Rawhide',
        'ansible_os_family': 'RedHat',
        'inventory_hostname': 'localhost'
    }

# Generated at 2022-06-10 23:15:40.738128
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # initialize needed objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=''))
        ]
    )

    # create play

# Generated at 2022-06-10 23:15:50.161092
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This test will only run if you have ansible-test installed in the same
    # virtualenv as ansible itself.
    from ansible_test.runner import get_default_options, create_targets

    # FIXME: update for any interpreter(s) added to interpreter discovery
    interpreter_name = 'python'

    # this is the test runner entry point, used by the test-module tests
    def run(action_plugin, action, interpreter_name, discovery_mode, tasks):
        # create a host to be used by the Runner
        action.host = create_targets(action.runner, '127.0.0.1')
        # empty vars
        action.host.vars = {}
        action.host.set_variable('ansible_python_interpreter', None)

# Generated at 2022-06-10 23:15:50.842243
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Properly test
    pass

# Generated at 2022-06-10 23:15:57.731676
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # initialize vars
    task = None
    action = None
    interpreter = "python"
    discovery_mode = "auto_legacy_silent"
    task_vars = {"ansible_python_interpreter": "/usr/bin/python"}

    # successful test case
    try:
        discover_interpreter(action, "python", discovery_mode, task_vars)
    except Exception as ex:
        # this test case should not throw an exception
        assert False

    # Test case with no interpreter param
    try:
        discover_interpreter(action, None, discovery_mode, task_vars)
    except Exception as ex:
        # this test case should throw an exception
        assert True

    # Test case with no task_vars param

# Generated at 2022-06-10 23:16:10.474399
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import StringIO
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.utils.pycompat24 import get_exception
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible_collections.sensu.sensu_go.plugins.action.basic import DiscoveryAction

    # TODO: https://github.com/ansible/ansible/issues/60114
    # error handling cases
    #   not implemented types
    #       return None or Python2: /usr/bin/python
    #       return None or Python3: /usr/bin/python3
    #   error cases
    #       return None or Python2: /usr/bin/python
    #       return None or Python3: /usr/bin/python3


# Generated at 2022-06-10 23:16:33.766825
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    import os
    import pwd
    import tempfile

    action = ActionBase()

    def mock_execute_command(cmd, sudoable=None, in_data=None):
        # we assume this is the first call!
        assert cmd == 'echo PLATFORM; uname; echo FOUND; command -v \'/usr/bin/python\'; echo ENDFOUND'
        assert sudoable is False
        assert in_data is None

        return {
            'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND',
            'stderr': '',
            'rc': 0,
            'changed': False,
            'delta': 0,
        }

    action._low_level_execute_command = mock_execute

# Generated at 2022-06-10 23:16:45.893733
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import collections
    import json

    import ansible.executor.discovery as disc

    TestAction = collections.namedtuple('TestAction', ['_discovery_warnings', '_connection', '_low_level_execute_command'])

    # Mock low-level command execution
    def execute_command(cmd, **kwargs):
        if cmd == 'echo PLATFORM; uname; echo FOUND; echo /usr/bin/python; echo ENDFOUND':
            return {'stdout': 'PLATFORM\r\nLinux\r\nFOUND\r\n/usr/bin/python\r\nENDFOUND'}

# Generated at 2022-06-10 23:16:58.093509
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    import ansible.plugins.action.copy
    import ansible.plugins.action.script
    import ansible.plugins.action.shell
    test_dir = tempfile.mkdtemp(prefix='ansible_test_discovery')
    os.mkdir(test_dir + "/lib64/")
    os.mkdir(test_dir + "/python3.6/site-packages/")
    os.mkdir(test_dir + "/python2.7/site-packages/")
    open(test_dir + "/lib64/libc.so.6", 'a').close()
    open(test_dir + "/python3.6/site-packages/python3.6.egg-link", 'a').close()

# Generated at 2022-06-10 23:17:07.416842
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext

    class MockAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = MockConnection()

        def _low_level_execute_command(self, cmd, **kwargs):
            return {'stdout': cmd}

    class MockConnection(object):
        def __init__(self):
            self.has_pipelining = True

    class MockTaskResult(TaskResult):
        def __init__(self, result_dict):
            self.result = result_dict

    class MockTask(object):
        def __init__(self):
            self.task_vars = {"inventory_hostname": "test"}

    mock_task = MockTask

# Generated at 2022-06-10 23:17:18.886286
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', dict()) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', dict()) == '/usr/bin/python'
    try:
        discover_interpreter(None, 'python', 'auto_silent', dict())
        assert False
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == 'python'
        assert ex.discovery_mode == 'auto_silent'
    try:
        discover_interpreter(None, 'python', 'auto_legacy_silent', dict())
        assert False
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.interpreter_name == 'python'

# Generated at 2022-06-10 23:17:29.970987
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    import ansible.executor.discovery

    class TestActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            for warning in self._discovery_warnings:
                display.warning(warning)

    task_vars = dict()
    action = TestActionBase(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    def run_test(host, discovery_mode, expect_result, expect_warnings=[]):
        task_vars['inventory_hostname'] = host


# Generated at 2022-06-10 23:17:31.592719
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', None) == u'/usr/bin/python'

# Generated at 2022-06-10 23:17:36.959032
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic

    display.verbosity = 4
    display._display.verbosity = 4
    assert discover_interpreter(
        basic.AnsibleModule(argument_spec={}),
        'python',
        'auto_legacy_silent',
        dict()
    )

# Generated at 2022-06-10 23:17:50.600362
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.discovery import find_interpreter_version_by_path
    from ansible.parsing.splitter import parse_kv

    # Test configuration constants
    class Config:
        C.ANSIBLE_LOCALHOST = "localhost"
        C.ANSIBLE_CONFIG_FILE = "ansible.cfg"
        C.ANSIBLE_INVENTORY_FILE = "hosts"


# Generated at 2022-06-10 23:18:05.006951
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.actions import ActionBase
    from ansible.plugins.action import ActionModule
    import ansible.module_utils.actions

    class FakeAction(ActionBase):
        def _discovery_warnings(self):
            return None

        def _low_level_execute_command(self, interpreter_path, sudoable=False, in_data=None):
            display.v("called _low_level_execute_command with interpreter_path={0}".format(interpreter_path))

    class FakeActionModule(ActionModule):
        def get_bin_path(self, argv, required=False, opt_dirs=None):
            return ansible.module_utils.actions.get_bin_path(argv[0])


# Generated at 2022-06-10 23:18:36.116164
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:18:37.812925
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, None, None, None) is None

# Generated at 2022-06-10 23:18:44.926494
# Unit test for function discover_interpreter
def test_discover_interpreter():

    task_vars = {}
    action = None
    interpreter_name = 'python'
    discovery_mode = 'normal'

    try:
        discovery_interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        print("Ansible Interpreter Discovery Success, python interpreter : %s" % discovery_interpreter)
    except Exception as ex:
        print("Ansible Interpreter Discovery Failed : %s" % ex)

# Generated at 2022-06-10 23:18:55.929084
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # sanity test
    assert discover_interpreter({}, 'python', 'auto_legacy_silent', {}) == u'/usr/bin/python'

    # "real" test
    action = {
        '_low_level_execute_command': lambda x, sudoable=False, in_data=None: {'stdout': 'command -v /usr/bin/python3\n/usr/bin/python3', 'rc': 0},
        '_discovery_warnings': [],
    }

    assert discover_interpreter(action, 'python', 'smart_silent', {}) == u'/usr/bin/python3'

# Generated at 2022-06-10 23:19:08.496800
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        import ansible.playbook.play_context
    except:
        print('ansible.playbook.play_context unavailable')
        return

    display_runtime = ansible.utils.display.Display()
    display_runtime.verbosity = (4)
    action = ansible.playbook.play_context.PlayContext()

    task_vars = {}

    # test 1: PBM (distro/version)

# Generated at 2022-06-10 23:19:18.993769
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_action import TaskAction
    from ansible.plugins.action.script import ActionModule as ScriptActionModule
    from ansible.module_utils.six import string_types
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    hostvars = [HostVars(name='testhost', port=22, host_specific_vars=dict(
        ansible_python_interpreter='/usr/bin/python'))]
    inventory = InventoryManager(host_list=[], vault_password=None, loader=None)
    inventory.hosts = hostvars
    var_mgr = VariableManager(loader=None, inventory=inventory)


# Generated at 2022-06-10 23:19:29.468580
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # need to mock the action because it's the one that gets a connection
    # the action and connection will be mocked further in the individual tests
    # we can't just do this across the board, because the plugin loaders
    # all rely on getting the real action/connection
    def mock_action(self, task_vars, tmp=None, task_name=None):
        self._connection = MagicMock()
        self._connection.has_pipelining = True
        self._low_level_execute_command = self._connection._low_level_execute_command = MagicMock()
        self._discovery_warnings = []

    # find the function
    import ansible.executor.discovery as dmod
    discoverer = dmod.discover_interpreter

    # the test data is setup in such a way that the first interpreter in

# Generated at 2022-06-10 23:19:41.316208
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Note: this unit test should run with the interpreter discovery settings unchanged, and the paths
    # are currently based on Debian-like systems.

    # minimal dummy object to pass to discover_interpreter
    class Action:
        @property
        def _connection(self):
            return self

        def has_pipelining(self):
            return True

        def _low_level_execute_command(self, interpreter, sudoable=False, in_data=None):
            return {'stdout': json.dumps({'platform_dist_result': []})}

        _discovery_warnings = []

    # test with each distro/version, using other distro/versions to populate the found_interpreters
    def assert_version(version, discovered_interp, expected_interp):
        action = Action()
        res = discover_interpre

# Generated at 2022-06-10 23:19:47.904411
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test platform discovery by distro:
    display.verbosity = 2
    action = DummyActionModule()
    task_vars = {
        'ansible_python_interpreter': 'python',
        'ansible_python_interpreter_discovery_mode': 'auto_legacy',
        'inventory_hostname': 'test_inventory_hostname',
    }

    test_distro_info = {
        'platform_dist_result': ['centos', '7.4.1708', 'Final'], # this is what platform.dist() returns
        'osrelease_content': 'NAME="CentOS Linux"\nVERSION="7 (Core)"', # this is /etc/os-release
    }


# Generated at 2022-06-10 23:19:54.410671
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, "python", "auto_legacy_silent", {}) == '/usr/bin/python'
    assert discover_interpreter(None, "python", "auto_legacy", {}) == '/usr/bin/python'
    assert discover_interpreter(None, "python", "auto", {}) == '/usr/bin/python'

# Generated at 2022-06-10 23:20:22.668495
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_factory import ActionModuleFactory
    from ansible.executor.connection_factory import ConnectorFactory
    from ansible.plugins.loader import find_plugin, get_all_plugin_loaders

    from ansible.plugins.stdout_callback import CallbackModule
    from ansible.plugins import connection
    connection.get = lambda *args, **kwargs: None

    try:
        import __main__ as main
    except ImportError:
        import sys
        main = sys.modules['__main__']


# Generated at 2022-06-10 23:20:34.153205
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import mock

    import ansible.module_utils.discovery as discovery

    # TODO: mocking this is atrocious; find a way to load the real config and set the discovery config values in there
    def mock_config_get(path, variables=None, convert_to=None, default=None, boolean=False, islist=False, safe=True):
        if path == 'INTERPRETER_PYTHON_DISTRO_MAP':
            return {
                'redhat': {
                    '7': '/usr/libexec/platform-python'
                },
                'centos': {
                    '7': '/usr/libexec/platform-python',
                    '7.0': '/usr/bin/python2'
                }
            }

# Generated at 2022-06-10 23:20:42.459442
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    class TestAction(ActionBase):
        _discovery_warnings = []


# Generated at 2022-06-10 23:20:55.229569
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test that basic platform discovery works
    from ansible.module_utils.connection import Connection
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor

    action = TaskExecutor()
    action._display = Display()
    action._task = dict(action=dict())
    action._connection = Connection(module_name='test')
    action._connection.has_pipelining = True
    action._low_level_execute_command = lambda cmd, sudoable=False, in_data=None: TaskResult(dict(stdout=cmd))
    action._discovery_warnings = []
    task_vars = dict()

    assert discover_interpreter(action, 'python', 'auto', task_vars) == u'/usr/bin/python'
    assert action

# Generated at 2022-06-10 23:20:57.401115
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_silent', None) == u'/usr/bin/python'


# Generated at 2022-06-10 23:21:08.710565
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:21:10.037958
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass


# Generated at 2022-06-10 23:21:18.298559
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.connection import Connection
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader, connection_loader
    from ansible.parsing.dataloader import DataLoader

    action_plugin_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'plugins/action')
    action_loader.add_directory(action_plugin_path)

    action_cls = action_loader.get('shell')


# Generated at 2022-06-10 23:21:31.633288
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.raw import ActionModule as RawActionModule
    from ansible.plugins.action import ActionBase

    class ActionModule(ActionBase):

        TRANSFERS_FILES = False

        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(ActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self._low_level_execute_command = RawActionModule(task, connection, play_context, loader, templar, shared_loader_obj).run

    # We need to tell the discovery logic that we're using pipelining
    class Connection(object):
        has_pipelining = True

    # The class-based structure is a little annoying to deal with here, but this

# Generated at 2022-06-10 23:21:39.972382
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from ansible.plugins.action.interpreter_discovery import discover_interpreter

    # Test code
    test_action = lambda *args, **kwargs: None
    test_task_vars = {'ansible_python_interpreter': '/usr/bin/python',
                      'ansible_python_interpreter_discovery_mode':
                          'auto'}

    # Test cases

# Generated at 2022-06-10 23:22:24.819742
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system import distribution
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system import platform
    platform.collector = PlatformFactCollector
    distribution.collector = DistributionFactCollector
    res = discover_interpreter('action', 'python', 'auto', {})
    assert res is not None
    assert res

# Generated at 2022-06-10 23:22:29.547700
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins import module_loader
    from ansible.plugins.loader import find_plugin

    mod = module_loader._load_powershell_provider(find_plugin('powershell'), 'powershell')
    action = mod.ActionModule({}, {}, 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test')

    res = discover_interpreter(action, 'python', 'auto_legacy_silent', {})
    assert res == '/usr/bin/python'