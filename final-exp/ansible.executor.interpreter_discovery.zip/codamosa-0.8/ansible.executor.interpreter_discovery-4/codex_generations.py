

# Generated at 2022-06-10 23:12:55.107112
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:13:06.462126
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host = 'localhost'
    hostvars = dict()
    action = dict()
    interpreter_name = "python"
    exec_path = "/usr/bin"
    discovery_mode = "auto"

# Generated at 2022-06-10 23:13:21.129423
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:13:31.775601
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.platform import Platform


# Generated at 2022-06-10 23:13:44.444689
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.discovery import InterpreterDiscoveryRequiredError
    from ansible.module_utils.facts.system.distribution import Distribution as DistributionFacts
    from ansible.parsing.plugin_docs import read_docstring

    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase

    ACTION_NAME = 'discovery'

    class FakePlayContext(PlayContext):
        def __init__(self, *args, **kwargs):
            super(FakePlayContext, self).__init__(*args, **kwargs)
            self.become = False


# Generated at 2022-06-10 23:13:45.401234
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:13:56.699534
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.basic import AnsibleModule

    class ActionModule(object):
        def __init__(self, task_vars):
            self._task_vars = task_vars
            self._low_level_execute_command_results = {}
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            if sudoable:
                raise Exception('sudoable not supported')

            if command not in self._low_level_execute_command_results:
                raise Exception('unexpected low level command')

            return self._low_level_execute_command_results[command]

        def _display_warning(self, msg):
            self._discovery_warn

# Generated at 2022-06-10 23:14:09.303629
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Mock(object):
        def __init__(self, *args, **kwargs):
            pass

    class MockAction(object):
        def __init__(self, no_pipelining, warnings):
            self._connection = Mock(has_pipelining=no_pipelining)
            self._discovery_warnings = warnings

    class MockResult(object):
        def __init__(self, stdout, stderr=''):
            self['stdout'] = stdout
            self['stderr'] = stderr

    # Test for pipelining
    warnings = []
    action = MockAction(False, warnings)
    result = MockResult(json.dumps({"platform_dist_result": ["redhat", "7.3.1611", "Core"]}))

# Generated at 2022-06-10 23:14:20.450145
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={
            'host': {'required': True, 'type': 'str'},
            'interpreter': {'required': True, 'type': 'str'},
            'discovery_mode': {'required': True, 'type': 'str'},
            'task_vars': {'required': True, 'type': 'dict'}
        },
    )

    # case1: valid hostname and valid disc_mode with no interpreter warning
    host = 'testhost'
    disc_mode = 'auto_legacy_silent'
    interpreter_name = 'python'

# Generated at 2022-06-10 23:14:32.497140
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Runs a single test against the command interpreter discovery implememtation.
    The test is run with a single, fake execution action that responds with a string to the
    python bootstrap commands.

    The test is successful if discover_interpreter returns a tuple of ('linux', 'fedora', '23')
    """

    class Action(object):
        def __init__(self, stdout, stderr=''):
            self._stdout = stdout
            self._stderr = stderr
            self._discovery_warnings = []


# Generated at 2022-06-10 23:14:49.495821
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # pylint: disable=unused-variable
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    # pylint: disable=line-too-long,attribute-defined-outside-init
    class StubTaskQueueManager(TaskQueueManager):
        def __init__(self, *args, **kwargs):
            self._shared_loader_obj = None
            self._loader = None
            self._inventory = None
            self._variable_manager = None
            self._all_vars = dict()
            self._fact_cache = dict()

    class FakeDisplay(object):
        def __init__(self):
            pass

        def vvv(self, msg, host=None):
            print(msg)


# Generated at 2022-06-10 23:15:01.280655
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict()


# Generated at 2022-06-10 23:15:11.679156
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import collections
    import unittest
    class test_action(object):

        def  __init__(self, test_host, test_python_list, test_distro_map, test_res):
            self._connection = collections.namedtuple('connection', 'has_pipelining')(True)
            self._discovery_warnings = []
            self._host = test_host
            self._python_list = test_python_list
            self._distro_map = test_distro_map
            self._res = test_res

        def _low_level_execute_command(self, test_interp, sudoable=False, in_data=None):
            self._called_interp = test_interp
            return self._res


# Generated at 2022-06-10 23:15:19.145305
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {'ansible_python_interpreter': u'/usr/bin/python'}

    # Test Linux distro platform
    platform_linux_distro_map = {'ubuntu': {'12.04': u'/usr/bin/python',
                                            '14.04': u'/usr/bin/python2.7',
                                            '16.04': u'/usr/bin/python3.5'},
                                 'centos': {'7': u'/usr/bin/python',
                                            '8': u'/usr/bin/python2.7'},
                                 'oracle': {'7': u'/usr/bin/python'}}

# Generated at 2022-06-10 23:15:30.863884
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    class action_test(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return dict()

    # Test 1
    test1_action = action_test(None, dict(ANSIBLE_MODULE_ARGS=dict(ANSIBLE_MODULE_ARGS=dict(interpreter_name='python', discovery_mode='auto'))))
    test1_interpreter = discover_interpreter(test1_action, 'python', 'auto', None)
    assert test1_interpreter == '/usr/bin/python'

    # Test 2
    test2_action = action_test(None, dict())

# Generated at 2022-06-10 23:15:43.034229
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.vars import VariableManager
    from ansible.utils.vars import load_extra_vars, load_options_vars, merge_vars
    from ansible.utils.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import os

    host_data = """
    [testhosts]
    localhost ansible_connection=local
    """


# Generated at 2022-06-10 23:15:51.513047
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # basic test - discover_interpreter returns a valid path
    host = 'localhost'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict()

    def _low_level_execute_command(cmd, *args, **kwargs):
        # First, we use a simple shell-agnostic bootstrap to get the system type from uname, and find any random Python that can get us the info we need.
        if cmd == u"command -v 'python'":
            # For supported target OS types, we'll dispatch a Python script that calls plaform.dist() (for older platforms, where available)
            # and brings back /etc/os-release (if present).
            stdout = 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'


# Generated at 2022-06-10 23:15:57.951388
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.urls import open_url

    def test_versions(version):
        # Build a temporary map
        test_map = {
            u'oracle': u'/usr/bin/python2.6',
            u'redhatenterpriseserver': u'/usr/bin/python2.6',
            u'sl': u'/usr/bin/python',
        }

        return _version_fuzzy_match(version, test_map)

    assert test_versions('7.6') == '/usr/bin/python2.6'
    assert test_versions('6.7') == '/usr/bin/python2.6'

# Generated at 2022-06-10 23:16:05.667910
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Check if it works as expected
    result = discover_interpreter("action", 'python', 'auto', None)
    assert isinstance(result, str)

    # Check if it raises exception when it is invoked with incorrect arguments
    try:
        discover_interpreter("action", 'perl', 'auto', None)
    except NotImplementedError as ex:
        assert isinstance(ex, NotImplementedError)
    except Exception as ex:
        raise ex



# Generated at 2022-06-10 23:16:09.002836
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_action = []
    discover_interpreter("test_interpreter", "python", "auto_legacy_silent", test_action)
    assert test_action == []

# Generated at 2022-06-10 23:16:32.479606
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # For now, just a smoke test.
    # TODO: add more tests to ensure that the returned interpreter
    # is in fact the one we expect.
    discover_interpreter(action=None,
                         interpreter_name='python',
                         discovery_mode='auto_legacy_silent',
                         task_vars={ 'inventory_hostname': '' })

# Generated at 2022-06-10 23:16:40.108687
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class FakeModule():
        def __init__(self):
            self._connection = FakeModule.FakeConnection()
            self.params = {'interpreter': 'python', 'discovery_mode': 'explicit'}

        class FakeConnection:
            def __init__(self):
                self.has_pipelining = True

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            return {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python3\nENDFOUND\n', 'stderr': ''}

    class FakeTaskVars():
        @staticmethod
        def get(name, default=None):
            if name == 'inventory_hostname':
                return 'test_host'
            else:
                return default

# Generated at 2022-06-10 23:16:51.438050
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    import unittest
    # The below test is based on using ansible/venv for testing
    # ansible/venv should be created using virtualenv and
    # have python 2 and python 3 interpreter.
    #
    # 1. Download https://github.com/ansible/ansible/raw/devel/contrib/inventory/vagrant.py
    # 2. Download https://github.com/ansible/ansible/raw/devel/contrib/inventory/vagrant.ini
    # 3. Download https://github.com/ansible/ansible/raw/devel/contrib/inventory/vagrant_example.ini
    # 4. Download https://github.com/ansible/ansible/raw/devel/contrib/inventory/vagrant_expanded.ini
    # 5. Download https

# Generated at 2022-06-10 23:17:02.980378
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.plugins
    from ansible.plugins.loader import action_loader

    test_interp_map = {
        'ubuntu': {
            '14.04': u'/usr/bin/python2.7',
            '16.04': u'/usr/bin/python3.5',
            '17.04': u'/usr/bin/python3.6'
        }
    }

    # os-release content from Ubuntu 17.04

# Generated at 2022-06-10 23:17:14.751392
# Unit test for function discover_interpreter
def test_discover_interpreter():
    platform_python_map = {
        u'centos': {
            u'6': u'/usr/libexec/platform-python',
            u'7': u'/usr/lib/python2.7/site-packages',
        }
    }

    bootstrap_python_list = [u'/usr/bin/python', u'/usr/libexec/platform-python', u'/usr/lib/python3_7/site-packages']


# Generated at 2022-06-10 23:17:26.553717
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {"INTERPRETER_PYTHON_DISTRO_MAP": {
        "centos": {
            "5": "/usr/bin/python",
            "6": "/usr/bin/python",
            "7": "/usr/bin/python"}},
        "INTERPRETER_PYTHON_FALLBACK": [
            "/usr/bin/python"]}
    discovery_mode = 'auto'
    action = "null"
    interpreter_name = "python"

    module = {"platform_dist_result": ["centos", "7", " "], "osrelease_content": "ID=centos\nVERSION_ID=7"}

    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == "/usr/bin/python"

# Generated at 2022-06-10 23:17:35.180900
# Unit test for function discover_interpreter
def test_discover_interpreter():
    display_data = []
    # SUT
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.shell import ShellModule
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from unit.mock.loader import DictDataLoader
    from unit.mock.path import MockPath
    from unit.mock.dataloader import MockDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from collections import namedtuple


# Generated at 2022-06-10 23:17:49.216963
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # call discover_interpreter with various task_vars
    # should return ('/usr/bin/python')
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = dict(
        ansible_connection='network_cli',
        inventory_hostname='localhost',
        network_os='nxos',
        nxos_command_timeout='50',
    )
    interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert interpreter == '/usr/bin/python'
    task_vars['ansible_connection'] = 'local'
    interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert interpreter == '/usr/bin/python'

# Generated at 2022-06-10 23:18:03.387955
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test case 1, the host is redhat with python 2.7
    action = MockAction()
    task_vars = MockTaskVars()
    version_map = {'redhat': {'6.5': '/opt/rh/python27/root/usr/bin/python',
                              '6.0': '/opt/rh/python27/root/usr/bin/python'},
                   'i386': '/opt/python27/bin/python'}

    task_vars.vars['ansible_facts'] = {'distribution': 'redhat',
                                       'distribution_version': '6.5'}

    # original code, no change.
    action.check_mode = False
    task_vars.vars['ansible_python_interpreter'] = None
    C.config.get_config_

# Generated at 2022-06-10 23:18:14.921565
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    import ansible.executor
    import ansible.plugins.discovery.interpreter

    task_vars = dict(
        ansible_ssh_host='mockhost',
        ansible_ssh_user='mockuser',
    )

    action = ActionBase(ansible.executor.task_executor._task, dict(), False)

    # mock execution of the discovery script so we can test cases without actually having the Pythons installed

# Generated at 2022-06-10 23:18:46.032925
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import connection_loader, module_loader, plugin_loader
    from ansible.module_utils.connection import ConnectionBase
    from ansible.executor.discovery import plugin_cache
    import ansible.plugins.action.discovery

    # reset the cache of plugin-generated values
    plugin_cache.clear()

    # fake a module loader
    mod_class = type('MyModule', (basic.AnsibleModule,), {})
    setattr(mod_class, '_ansible_module_class', mod_class)
    module_loader.add_directory(C.DEFAULT_MODULE_PATH)
    setattr(mod_class, 'module_loader', module_loader)

    # fake a connection plugin

# Generated at 2022-06-10 23:18:57.293794
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import TaskRunner

    class ActionModuleRun(object):
        def __init__(self):
            self._low_level_execute_command = lambda **kwargs: kwargs
            self._connection = object()
            self.connection._has_pipelining = False
            self._discovery_warnings = []

        def run(task_runner, **kwargs):
            task = task_runner._task
            if task.action != 'command':
                raise ValueError('unexpected task action')
            interpreter = task.args.get('_ansible_interpreter')
            discovery_mode = task.args.get('_ansible_interpreter_discovery_mode')

# Generated at 2022-06-10 23:19:02.790732
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy', {'inventory_hostname': 'unknown'}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto', {'inventory_hostname': 'unknown'}) == '/usr/bin/python'

# Generated at 2022-06-10 23:19:12.515797
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    class TestAction(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None, executable=None):
            if cmd == '/usr/bin/python':
                out_data = pkgutil.get_data('ansible.executor.discovery', 'test_platform_info.json')

                return dict(stdout=out_data, stdout_lines=out_data.splitlines(), stderr=None, rc=0)

            out_data = u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n'

            return dict(stdout=out_data, stdout_lines=out_data.splitlines(), stderr=None, rc=0)

    a = TestAction()

# Generated at 2022-06-10 23:19:17.620248
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.module_common
    action = ansible.executor.module_common.ActionModule(connection=None, runner=None)
    task_vars = {}
    try:
        assert discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)
    except Exception as e:
        print (to_text(e))

# Generated at 2022-06-10 23:19:28.427572
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.task import Task

    import ansible.executor.discovery
    import ansible.plugins.action
    import ansible.inventory.host
    import ansible.vars.manager

    from ansible.playbook.play_context import PlayContext

    class FakeModule(object):
        def __init__(self):
            self._shared_loader_obj = {}

        @property
        def FAILED_IF(self):
            return []


# Generated at 2022-06-10 23:19:39.921461
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.module_common import ActionBase

    action = ActionBase()

    # this is the default target interpreter list
    bootstrap_python_list = C.config.get_config_value('INTERPRETER_PYTHON_FALLBACK')

    # Basic test: does it return something?
    interpreter = discover_interpreter(action, 'python', 'auto', {})
    assert interpreter

    interpreter = discover_interpreter(action, 'python', 'auto_legacy', {})
    assert interpreter

    interpreter = discover_interpreter(action, 'python', 'auto_silent', {})
    assert interpreter

    interpreter = discover_interpreter(action, 'python', 'auto_legacy_silent', {})
    assert interpreter

    # 'auto' mode should fail without an inventory hostname

# Generated at 2022-06-10 23:19:47.278540
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module_name = 'setup'
    task_vars = dict()

    class MockAction(object):
        def __init__(self):
            self.tested = False
            self.task_vars = task_vars
            self._low_level_execute_command = self.low_level_execute_command
            self._discovery_warnings = []

        # stub for _low_level_execute_command
        def low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if self.tested:
                return
            self.tested = True

            # ensure we've properly substituted the command for the python it should run
            assert cmd == '/usr/bin/python3'

            assert in_data

            import platform

# Generated at 2022-06-10 23:19:48.798652
# Unit test for function discover_interpreter
def test_discover_interpreter():
    #TODO: stub out an action object
    pass

# Generated at 2022-06-10 23:19:59.701310
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import action_loader
    connection = connection_loader.get('local', class_only=True)()
    connection.has_pipelining = False
    action = action_loader.get('command', class_only=True)()
    task_queue_manager = TaskQueueManager(inventory=None, variable_manager=None, loader=None,
                                          options=None, passwords=None, stdout_callback=None)
    action._shared_loader_obj = task_queue_manager.loader
    action._task = task_queue_manager.get_task_obj()

    display.verbosity = 4

# Generated at 2022-06-10 23:20:43.823376
# Unit test for function discover_interpreter
def test_discover_interpreter():
    dummy_connection = type('Connection', (object,), {'has_pipelining': True})
    dummy_action = type('ActionBase', (object,), {'_connection': dummy_connection(), '_low_level_execute_command': low_level_execute_command})
    dummy_task_vars = {
        'inventory_hostname': 'fake_host',
        'config': type('Config', (object,), {
            'get_config_value': _get_config_value
        })()
    }

    # test no valid python interpreters found
    found_interpreters = [u'C:\Windows\py.exe']
    result = discover_interpreter(dummy_action, 'python', 'auto_silent', dummy_task_vars)
    assert result == u'/usr/bin/python'

   

# Generated at 2022-06-10 23:20:53.766724
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # the function only supports python for now
    interpreter_name = "python"
    discovery_mode = "auto_legacy_on_fail"
    task_vars = dict()

    # test for error
    try:
        discover_interpreter("", interpreter_name, discovery_mode, task_vars)
    except  InterpreterDiscoveryRequiredError as e:
        assert e.message == "Python interpreter discovery not supported for {0}".format("")
        assert e.interpreter_name == "python"
        assert e.discovery_mode == "auto_legacy_on_fail"

# Generated at 2022-06-10 23:21:05.004707
# Unit test for function discover_interpreter
def test_discover_interpreter():
    bootstrap_python_list = ['python3', '/usr/bin/python', 'python']
    python_platform_dist_map = {
        'sles': {
            '14': '/usr/bin/python2.7',
            '15': '/usr/bin/python2.7'
        },
        'sles_sap': {
            '15': '/usr/bin/python3',
            '15-sp1': '/usr/bin/python3',
            '15-sp2': '/usr/bin/python3',
            '15-sp3': '/usr/bin/python3',
            '11-sp4': '/usr/bin/python2.7',
            '12-sp2': '/usr/bin/python2.7'
        }
    }

    # Missing python interpreter
    fake_module_args

# Generated at 2022-06-10 23:21:14.708214
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import os
    import shutil
    import tempfile
    class TestDiscovery(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.base_dir = tempfile.mkdtemp(prefix='ansible_test_discover_interpreter')
            cls.playbook_dir = tempfile.mkdtemp(dir=cls.base_dir)
            cls.module_dir = tempfile.mkdtemp(dir=cls.base_dir)


# Generated at 2022-06-10 23:21:15.896967
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # assert discover_interpreter('python', 'auto', {}, None) == '/usr/bin/python'
    pass

# Generated at 2022-06-10 23:21:24.452936
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {}

    class FakeAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._aliases = {}

        def _low_level_execute_command(self, cmd, *args, **kwargs):
            if cmd == 'command -v "/usr/bin/python"':
                return {'stdout': to_text("/usr/bin/python\n")}
            if cmd == '/usr/bin/python':
                return {'stdout': to_text('{"platform_dist_result": ["fedora", "23", "Twenty Three"]}')}
            raise ValueError(cmd)

    action = FakeAction()

    interpreter = discover_interpreter(action, 'python', 'auto', task_vars)


# Generated at 2022-06-10 23:21:36.701017
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/unittests/test_data/hosts_interpreters_discovery'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    pbex = PlaybookExecutor(playbooks=['tests/unittests/test_data/playbooks/test_interpreters.yaml'],
                            inventory=inventory, variable_manager=variable_manager,
                            loader=loader)

    result = pbex.run()


# Generated at 2022-06-10 23:21:50.464971
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    import shutil
    from ansible.executor.task_executor import TaskExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    display = Display()
    temp_dir = tempfile.mkd

# Generated at 2022-06-10 23:21:58.153539
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext

    class ActionStub:
        _discovery_warnings = []
        _low_level_execute_command = None
        _connection = ConnectionStub()

        def __init__(self):
            self._discovery_warnings = []

        def warn(self, msg):
            self._discovery_warnings.append(msg)

        def _discovery_warn(self, msg):
            self._discovery_warnings.append(msg)

    class ConnectionStub:

        def __init__(self, pipelining_supported=True):
            self.has_pipelining = pipelining_supported


# Generated at 2022-06-10 23:22:04.534554
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction:
        def __init__(self):
            self._discovery_warnings = list()
            self._connection = MockConnection()

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            if command == 'echo PLATFORM; uname; echo FOUND; command -v \'/usr/bin/python\'; echo ENDFOUND':
                stdout = 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'
            elif command == 'command -v \'/usr/bin/python\'':
                stdout = 'PLATFORM\nLinux\nFOUND\n/usr/local/bin/python\nENDFOUND'
            else:
                stdout = ''