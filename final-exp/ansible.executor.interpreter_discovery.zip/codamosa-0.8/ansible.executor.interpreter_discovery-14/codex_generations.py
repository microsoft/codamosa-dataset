

# Generated at 2022-06-10 23:12:46.535501
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # No test available currently
    pass
    # No test available currently

# Generated at 2022-06-10 23:12:56.249253
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module_stdout = b'''PLATFORM
Linux
FOUND
/usr/bin/python
ENDFOUND
'''
    module_ipy_stdout = b'''PLATFORM
Linux
FOUND
/usr/bin/python
/usr/bin/python2.7
ENDFOUND
'''
    module_ipy3_stdout = b'''PLATFORM
Linux
FOUND
/usr/bin/python3
ENDFOUND
'''
    module_ipy_py3_stdout = b'''PLATFORM
Linux
FOUND
/usr/bin/python3
/usr/bin/python2.7
ENDFOUND
'''

# Generated at 2022-06-10 23:13:07.753071
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Case: no interpreter name
    action = None
    interpreter_name = None
    discovery_mode = None
    task_vars = None
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        raise AssertionError("Interpreter name should not be null")
    except ValueError:
        pass

    # Case: unknown interpreter name
    action = None
    interpreter_name = 'unknown'
    discovery_mode = None
    task_vars = None
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        raise AssertionError("Interpreter name should not be unknown")
    except ValueError:
        pass

    # Case: null action
    action = None
    interpreter_name = 'python'


# Generated at 2022-06-10 23:13:16.756127
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import ActionBase
    class Action(ActionBase):
        # dummy class to make this work
        def __init__(self):
            self._connection = None
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable):
            return TaskResult(cmd)

    # Test always fail
    interpreter_name = 'python'
    discovery_mode = 'always_legacy_silent'
    action = Action()
    class TaskVars(dict):
        def __init__(self):
            super(TaskVars, self).__init__()
            self.keydata = {}

# Generated at 2022-06-10 23:13:29.091329
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    from ansible.module_utils import distro

    class TestInterpreterDiscovery(unittest.TestCase):

        platform_python_map = {
            'fedora': {'20': u'/usr/bin/python', '21': u'/usr/bin/python3'},
            'redhat': {'6': u'/usr/bin/python', '7': u'/usr/bin/python3'},
        }

        bootstrap_python_list = [u'/usr/bin/python', u'/usr/bin/python3']

        host = 'testhost'

        action = distro.LinuxDistribution()


# Generated at 2022-06-10 23:13:42.134366
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery
    import ansible.module_utils.distro

    ansible.executor.discovery.display = Display()

    # Linux Distribution discovery testing
    assert _get_linux_distro({'platform_dist_result': ['alpine', '3.10.2', 'alpine']}) == ('alpine', '3.10.2')
    assert _get_linux_distro({'osrelease_content': u"NAME=openSUSE\nVERSION_ID=15.1\nID=opensuse\nID_LIKE="}) == ('opensuse', '15.1')

# Generated at 2022-06-10 23:13:53.415432
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import tempfile
    import ansible.executor.module_common
    import ansible.executor.module_executor
    import ansible.utils.module_docs
    import ansible.utils.module_docs_fragments

    task_vars = dict()
    task_vars['inventory_hostname'] = 'localhost'
    task_vars['_ansible_verbosity'] = 4
    action = ansible.executor.module_common.ActionModule(
        socket_path=tempfile.mkdtemp(),
        task_vars=task_vars,
    )
    display.verbosity = 4

    assert discover_interpreter(action, 'python', 'default', task_vars) in ['/usr/bin/python', '/usr/bin/python3']

# Generated at 2022-06-10 23:13:58.006976
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    task_vars = {}
    discovered_interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert discovered_interpreter == '/usr/bin/python'

# Generated at 2022-06-10 23:14:11.286251
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.action_factory import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext

    class FakeModule(object):
        def __init__(self, result):
            self._results = result

        def _execute_module(self):
            return self._results

    class FakeTaskResult(TaskResult):
        def __init__(self, result, is_changed=False, is_failed=False, is_skipped=False, is_unreachable=False):
            self._result = result
            self._is_changed = is_changed
            self._is_failed = is_failed
            self._is_skipped = is_skipped
            self

# Generated at 2022-06-10 23:14:21.325675
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_dir = os.path.dirname(__file__)
    data_dir = os.path.join(test_dir, 'data', 'interpreter_discovery')
    for test_file in sorted(os.listdir(data_dir)):
        if not test_file.endswith('.yml'):
            continue
        test_data = data_from_path(os.path.join(data_dir, test_file))
        for test_case in test_data:
            if isinstance(test_case['interpreter'], dict):
                test_case['interpreter'] = VersionedInterpreterSpec(**test_case['interpreter'])

# Generated at 2022-06-10 23:14:42.066260
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Need to be more thorough in testing.
    # For example, checking for specific values in the returned variables.
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', None)
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {'inventory_hostname': 'localhost'})
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {'inventory_hostname': 'localhost',
                                                                         'config_file': 'hosts'})

# Generated at 2022-06-10 23:14:48.814066
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # import ansible
    # # TODO: write test case
    # ansible_path = os.path.dirname(ansible.__file__)
    # # print(ansible_path)
    # sys.path.insert(0, ansible_path + '/executor/discovery')
    # from interpreter_discovery import discover_interpreter
    #
    # action = None
    # interpreter_name = 'python'
    # discovery_mode = 'smart'
    # task_vars = None
    #
    # discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    pass

# Generated at 2022-06-10 23:14:59.878932
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.plugins.action import ActionModule

    class Module(ActionModule):
        pass

    task_vars = {
        'ansible_python_interpreter': u'/usr/bin/python',
        'ansible_connection': 'local',
        'ansible_inventory': 'localhost',
        'inventory_hostname': 'localhost',
    }

    action = Module(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    res = discover_interpreter(action, 'python', 'auto_legacy', task_vars)

    print(res)
    res = discover_interpreter(action, 'python', 'auto_silent', task_vars)

# Generated at 2022-06-10 23:15:11.077641
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule

    # setup the class
    setattr(ActionModule, '_connection', type('connection', (object,), {'has_pipelining': True}))

    # mock some task_vars

# Generated at 2022-06-10 23:15:22.432458
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    # dummy task_vars which should be enough for testing discovery
    task_vars = dict(
        ansible_python_interpreter='/usr/bin/python'
    )

    # create mock display object
    display.verbosity = 2

    # create variable manager and add task_vars
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(host_list=C.DEFAULT_HOST_LIST))
    variable_manager.extra_vars = task_vars

    # create the persistent object for the play
    pc = PlayContext()
    # FIXME: terrible hack
    pc

# Generated at 2022-06-10 23:15:32.157262
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # for now, just make sure no errors are raised when running the test harness
    import pytest
    from ansible.module_utils.common.removed import removed_module

    if not C.config.get_config_value('DEVELOP_MODE'):
        pytest.skip('Skipping tests which only run in develop mode')

    if removed_module.PY3:
        pytest.skip('Skipping tests which only run on Python 2')

    def execute_module_mock(self, module_name, module_args=None, tmp=None, delete_remote_tmp=True, *args, **kwargs):
        res = dict(failed=False, changed=False)


# Generated at 2022-06-10 23:15:45.389184
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.action import Action
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action.normal import ActionModule as ActionModule
    class TestInterpreterDiscovery(Action):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(TestInterpreterDiscovery, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

            self._discovery_warnings = []


# Generated at 2022-06-10 23:15:54.865582
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    def _setup_discovery_mock(context, cmd_items, u_path, new_version_map, **kwargs):
        context.action._low_level_execute_command = lambda x, sudoable, in_data=None: {'stdout': cmd_items}
        context.action._connection.has_pipelining = True

        def _get_tmp_path(z):
            return u_path + z

        context.action._connection._shell.get_tmp_path = _get_tmp_path
        context.action._connection.host = 'host.example.org'

        # yes, we're putting this in a global instead, so we can do an in-place replacement
        # this is an ugly unit

# Generated at 2022-06-10 23:16:07.117047
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == 'echo PLATFORM; uname; echo FOUND; command -v python; echo ENDFOUND':
                return {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python2\n/usr/bin/python3\nENDFOUND'}
            if cmd == '/usr/bin/python':
                return {'stdout': '{"osrelease_content": "[centos]\nname=CentOS\nversion=7.7.1908\n"}'}

# Generated at 2022-06-10 23:16:17.744537
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Successful case(using discover_interpreter)
    task_vars = dict()

    # Extract the 'INTERPRETER_PYTHON_DISTRO_MAP' from the config file.
    # This is the default case.
    task_vars['ansible_config'] = C.Config(constants=C)
    INTERPRETER_PYTHON_DISTRO_MAP = C.config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP', variables=task_vars)
    INTERPRETER_PYTHON_FALLBACK = C.config.get_config_value('INTERPRETER_PYTHON_FALLBACK', variables=task_vars)
    # Check the default entries
    # 1. There are multiple possible interpreters for one version.

# Generated at 2022-06-10 23:16:55.997282
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    fake_action = DictDataLoader({
        '_low_level_execute_command': lambda *args, **kwargs: {},
        '_discovery_warnings': [],
        '_connection': {'has_pipelining': True}
    }).get_basedir()

    def do_test(testcase, hostvars=None, configvars=None):
        action = fake_action.copy()
        task_vars = {'inventory_hostname': testcase['inventory_hostname']}
        if hostvars:
            task_vars.update(hostvars)

# Generated at 2022-06-10 23:17:05.969710
# Unit test for function discover_interpreter
def test_discover_interpreter():
    connection_mock = {'has_pipelining':True}
    action_mock = {'_connection':connection_mock}

    def low_level_execute(interpreter, sudoable, in_data):
        return {"stdout":"""PLATFORM
Linux
FOUND
/usr/bin/python
ENDFOUND
""",
                "stdout_lines":[],
                "stderr":"",
                "stderr_lines":[],
                "stdin":"python_script",
                "stdin_add_newline":True,
                "changed":False,
                "warnings":[]}

    action_mock['_low_level_execute_command'] = low_level_execute


# Generated at 2022-06-10 23:17:18.371000
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {"inventory_hostname": "test_host"}
    test_interpreter_name = 'python'
    test_discovery_mode = "auto"

    # Test to return interpreter in case of python not in bootstrap list
    bootstrap_python_list = ['python3', '/usr/bin/python3']
    C.config.set_config_value("INTERPRETER_PYTHON_FALLBACK", bootstrap_python_list, variables=task_vars)
    # Set plaform_dist_result for platform.dist() call
    platform_info = {"platform_dist_result": ["debian", "8", "jessie"]}
    # Set python interpreter path for debian-8
    version_map = {"8": "/usr/bin/python3"}

# Generated at 2022-06-10 23:17:29.437873
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """Unit test for interpreter discovery"""
    import unittest

    class TestModule(object):
        class _ModuleResult(object):
            """Mock class for module result."""
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)

            def get(self, key, default=None):
                return self.__dict__.get(key, default)

        class _LowLevel(object):
            """Mock class for low-level connection data."""
            def __init__(self, pipelining=True):
                self.pipelining = pipelining

            def has_pipelining(self):
                return self.pipelining

        class _ExecuteModule(object):
            def __init__(self, result, script, **kwargs):
                self.result = result


# Generated at 2022-06-10 23:17:36.431781
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.version import __version__ as ansible_version
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult

    # setup a test class to call
    class ActionPlugin(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return TaskResult(
                host=self._play_context.remote_addr,
                return_data=dict(
                    ansible_version=ansible_version,
                )
            )

    # create a test task
    task = dict(
        action=dict(
            module='setup'
        )
    )

    # create a test task_vars
    task_vars = dict()

    # have this look like we're on an archive distro

# Generated at 2022-06-10 23:17:50.287600
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.compat.six import string_types

    class MockAction(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            raise AssertionError('MockAction._low_level_execute_command should not be invoked')

        def run(self, tmp=None, task_vars=None):
            raise NotImplementedError('MockAction.run should not be invoked')

    def _run_discover_interpreter(action, interpreter_name, discovery_mode, task_vars):
        if not isinstance(task_vars, dict):
            raise TypeError('task_vars must be a dict')

        if not isinstance(discovery_mode, string_types):
            raise Type

# Generated at 2022-06-10 23:18:04.725171
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Check interpreter_name 'python'
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {}
    out = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert out == u'/usr/bin/python'

    # Check interpreter_name 'not_python'
    action = None
    interpreter_name = 'not_python'
    discovery_mode = 'auto'
    task_vars = {}
    try:
        out = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        assert False, "InterpreterDiscoveryRequiredError not raised"
    except ValueError as e:
        assert str(e) == 'Interpreter discovery not supported for not_python'

# Generated at 2022-06-10 23:18:11.670980
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class testaction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = None

    taction = testaction()
    taction._connection = Connection()
    # taction._connection.has_pipelining = True
    tinterp = discover_interpreter(taction, 'python', 'auto', {'inventory_hostname': 'test'})
    assert tinterp == '/usr/bin/python'

# Generated at 2022-06-10 23:18:19.257144
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''
    This is a unit test for the function discover_interpreter().
    '''
    # Find Python and version
    test_task_vars = dict(
        ansible_distribution='Ubuntu',
        ansible_distribution_version='14.04',
        ansible_distribution_release='trusty',
        ansible_os_family='Debian',
        ansible_kernel='Linux'
    )

    assert discover_interpreter(None, 'python', 'auto_legacy', test_task_vars) == u'/usr/bin/python'

# Generated at 2022-06-10 23:18:28.972047
# Unit test for function discover_interpreter
def test_discover_interpreter():
    platform_python_map, bootstrap_python_list = _get_discovery_config()
    test_interpreter = discover_interpreter(None, 'python', 'auto_legacy_silent', {'inventory_hostname': 'foo',
                                                                                   'config': lambda section,
                                                                                   key,
                                                                                   variables: _discovery_config(section,
                                                                                                                 key,
                                                                                                                 variables)})
    assert test_interpreter == '/usr/bin/python'



# Generated at 2022-06-10 23:19:30.816832
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    import ansible.plugins.discovery.interpreter_discovery

    class ActionModule(_ActionModule):
        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None, executable=None):
            if executable is None:
                executable = self._connection._shell.executable
            return {'stdout': cmd, 'stdout_lines': [cmd], 'stderr': u'', 'stderr_lines': [], 'rc': 0, 'cmd': cmd,
                    'start': u'', 'end': u'', 'delta': u'', 'msg': u'', 'invocation': {'module_args': cmd},
                    'changed': False, 'failed': False}


# Generated at 2022-06-10 23:19:42.419003
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.parsing.dataloader import DataLoader

    import os
    import copy
    import pytest

    class DiscoverInterpreterAction(ActionBase):
        def run(self, tmp=None, task_vars=None):

            """
            Discover python interpreter based on task_vars, and
            modify it in-place.

            task_vars is a template_vars argument
            """

            distribution, version = _get_linux_distro(self._get_platform_info(task_vars))


# Generated at 2022-06-10 23:19:55.490559
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule

    # TODO: a better way to test this function, the following
    # is a hack and the test will likely break if the function
    # is updated.

    # Some test examples
    #
    # platform_type, remote_interpreters, local_interpreters, result
    #
    # linux, ['/usr/bin/python'], ['/usr/bin/python'],
    #   "/usr/bin/python"
    #
    # linux, ['/usr/bin/python'], ['/usr/bin/python', '/usr/bin/python3'],
    #   "/usr/bin/python"
    #
    # linux, ['/usr/bin/python', '/usr/bin/python2'],
    #   ['/usr/bin/python', '/

# Generated at 2022-06-10 23:20:08.967765
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    class FakeAction(ActionBase):
        def __init__(self):
            self._connection = type('Connection', (object,), {'transport': 'local', 'has_pipelining': True})
            self._play_context = type('PlayContext', (object,), {'become': False, 'become_user': None})
            self._low_level_execute_command = lambda *args, **kwargs: {'stdout': pkgutil.get_data('ansible.executor.discovery', 'test_interpreter_discovery_result.txt')}
            self._discovery_warnings = []
    discovery_mode = 'auto_legacy_silent'
    task_vars = {}
    action = FakeAction()
    interp = discover_interpre

# Generated at 2022-06-10 23:20:19.790823
# Unit test for function discover_interpreter
def test_discover_interpreter():
    with open('test/unittests/data/test_discover_python_interpreter.json', 'r') as dpi_data:
        dpi_test_data = json.load(dpi_data)
    test_dpi_vars = {'ansible_python_interpreter': '/usr/lib/python2.7/site-packages'}
    for test in dpi_test_data:
        test_action = ActionModule({}, task_vars=test_dpi_vars)
        test_action.set_task_vars(test_action._task.args)
        expected = test['expected_python']
        assert discover_interpreter(test_action, 'python', test['discovery_type'], test_action._task.args) == expected

# Generated at 2022-06-10 23:20:29.516177
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec=dict(interpreter=dict(type='str', default='python'), action=dict(type='str', default='test'), discovery_mode=dict(type='str', default='auto')))
    display.verbosity = 4
    display.debug('Hello, world!')
    print(discover_interpreter(mod, mod.params['interpreter'], mod.params['discovery_mode'], dict(inventory_hostname='localhost')))

# Generated at 2022-06-10 23:20:39.201437
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    class TestAction(ActionBase):
        def run(self, tmp=None, task_vars=dict(), **kwargs):
            discovery_mode = task_vars.get('ansible_python_interpreter_discovery', 'silent')
            results = discover_interpreter(self, 'python', discovery_mode, task_vars)
            return results
    class TestConnection(object):
        def __init__(self):
            self.has_pipelining = False
        def connect(self, *args, **kwargs):
            return True
        def exec_command(self, *args, **kwargs):
            return 1, 'success\n', ''


# Generated at 2022-06-10 23:20:51.292726
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_io import ActionIO
    action = ActionIO(None, None, None, None, None, None, None)
    action._connection = ActionIO(None, None, None, None, None, None, None)
    action._connection.has_pipelining = False
    task_vars = {
        "inventory_hostname": "test_host",
        "hostvars": {
            "test_host": {
                "ansible_connection": "local"
            }
        }
    }

    from ansible.executor.discovery import _version_fuzzy_match
    assert _version_fuzzy_match("4.4", {"4": 1, "4.4.4": 2}) == 1

# Generated at 2022-06-10 23:21:02.646399
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-10 23:21:04.302299
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement unit test
    assert False