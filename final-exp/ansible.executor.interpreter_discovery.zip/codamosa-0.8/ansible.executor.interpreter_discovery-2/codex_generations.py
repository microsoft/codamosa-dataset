

# Generated at 2022-06-10 23:12:49.852808
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # set up a fake action
    class FakeAction(object):
        class FakeConnection(object):
            def __init__(self):
                self.has_pipelining = True

        def __init__(self):
            self._discovery_warnings = []
            self._connection = self.FakeConnection()

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            import platform
            import os

            def file_contents(path):
                try:
                    with open(path, 'rb') as f:
                        return f.read()
                except (OSError, IOError):
                    return None

            if command.startswith('python '):
                script = command.split(' ', 1)[1]
                info = json.loads(script)

# Generated at 2022-06-10 23:13:00.987639
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        import ansible.module_utils.basic
    except ImportError:
        raise ImportError("Could not import ansible.module_utils.basic")

    import os
    import sys
    old_sys_path = sys.path

    test_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    test_data_path = os.path.join(test_path, 'units', 'module_utils')

    sys.path.insert(0, test_data_path)

    from test_data.module_utils import TestExecutorActionModule


# Generated at 2022-06-10 23:13:10.025389
# Unit test for function discover_interpreter
def test_discover_interpreter():

    assert discover_interpreter(None, 'python', 'auto_legacy', {'inventory_hostname': 'hostname'}) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {'inventory_hostname': 'hostname'}) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto', {'inventory_hostname': 'hostname'}) == u'/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', {'inventory_hostname': 'hostname'}) == u'/usr/bin/python'

# Generated at 2022-06-10 23:13:11.317347
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: mock the test
    pass

# Generated at 2022-06-10 23:13:25.103254
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from ansible.plugins.action.normal import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from unit.mock.loader import DictDataLoader
    from unit.mock.inventory import MockInventory
    from unit.mock.vault import MockVaultSecret

    _inventory = InventoryManager(loader=DictDataLoader({}), sources=[])
    _loader = DictDataLoader({})

# Generated at 2022-06-10 23:13:29.478616
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # pylint: disable=too-many-function-args
    raise NotImplementedError('test for discover_interpreter not implemented')


# Generated at 2022-06-10 23:13:40.009629
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # paths that don't exist should return warnings
    assert discover_interpreter(None, 'python', 'auto_legacy_silent',
                                {'inventory_hostname': 'test_hostname',
                                 'config': {
                                     'config_value': {'INTERPRETER_PYTHON_DISTRO_MAP': {'darwin': {}},
                                                      'INTERPRETER_PYTHON_FALLBACK': ['/usr/bin/python3']}}}) == \
           '/usr/bin/python'
    # paths that do exist should not

# Generated at 2022-06-10 23:13:52.852407
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:14:04.933116
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.loader import action_loader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    import sys
    import pickle
    import tempfile
    import subprocess
    import time
    import os
    import shutil


# Generated at 2022-06-10 23:14:11.385753
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.executor import module_common

    action = module_common.ActionModule()

    # Py3
    # mapping = Mapping(dict(name='python3', discovery_mode='auto_legacy_silent', interpreter='/usr/bin/python3.5'))
    mapping = Mapping(dict(name='python', discovery_mode='auto_legacy_silent', interpreter='/usr/bin/python3.5'))
    result = discover_interpreter(action, **mapping)
    assert result == '/usr/bin/python3.5'

    # Py2
    mapping = Mapping(dict(name='python', discovery_mode='auto_legacy_silent', interpreter='/usr/bin/python2.7'))

# Generated at 2022-06-10 23:14:32.330258
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.removed import removed_module
    removed_module("ansible.executor.discovery")
    import ansible.executor.discovery as discovery
    import ansible.module_utils.basic as basic

    class Mock(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def get(self, name, default=None):
            if name in self.__dict__:
                return self.__dict__[name]
            else:
                return default


# Generated at 2022-06-10 23:14:34.755327
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    :return: description of the test
    """
    print("Testing discover_interpreter")

    assert discover_interpreter is not None

# Generated at 2022-06-10 23:14:45.250260
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-10 23:14:55.832879
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = None

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            return {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python3\nENDFOUND'}

    action = MockAction()
    task_vars = {}

    res = discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)
    assert res == u'/usr/bin/python'

    task_vars = {'ansible_python_interpreter': '/usr/local/bin/python'}

# Generated at 2022-06-10 23:14:57.876643
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter("action", "python", "auto_legacy_silent", "task_vars") == '/usr/bin/python'

# Generated at 2022-06-10 23:15:09.625281
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class ActionModule:
        def __init__(self):
            self._low_level_execute_command = None
            self._discovery_warnings = []

    def _low_level_execute_command(self, *args, **kwargs):
        command = args[0]

        if command == "command -v '%s'":
            # return first python in the list
            return dict(dict(stdout="/usr/bin/python3\n"))
        else:
            # return platform_info
            return dict(dict(stdout=json.dumps(dict(dict(platform_dist_result=["redhat", "7.6", "Final"])))))

    action = ActionModule()
    action._low_level_execute_command = _low_level_execute_command

    # get action_args for this test
    action

# Generated at 2022-06-10 23:15:18.137265
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Action(object):
        def __init__(self, sudoable=True, pipelining=False, python='python'):
            self._low_level_execute_command_results = []
            self._connection = type('Connection', (object,), {'has_pipelining': pipelining, 'become': sudoable})()
            self._discovery_warnings = []

            if python == 'not-found':
                python = "command -v 'not-found'"
            self._low_level_execute_command_results.append(
                dict(stdout=u'PLATFORM\nLinux\nFOUND\n{0}\nENDFOUND'.format(python)))


# Generated at 2022-06-10 23:15:27.423274
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # stub task_vars with the place where we store the interpreter table
    task_vars = dict()

    # Unit test for valid interpreter discovery
    task_vars['inventory_hostname'] = u'foo.bar.baz'
    interpreter_name = u'python'
    discovery_mode = 'legacy'
    action = object()
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res == u'/usr/bin/python'

# Generated at 2022-06-10 23:15:40.379829
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module_mock = MockModule([
        'uname',
        '/usr/bin/python',
        '/usr/bin/python2.7',
        '/usr/bin/python3.5',
        '/usr/bin/python3.5',
        '/usr/local/bin/python'
    ])

    task_vars = dict()
    task_vars['ansible_connection'] = 'local'
    task_vars['ansible_python_interpreter'] = '/usr/local/bin/python'
    task_vars['ansible_python_interpreter_discovery_mode'] = 'auto_legacy_silent'
    task_vars['ansible_python_interpreter_discover_warnings'] = []
    task_vars['inventory_hostname'] = 'localhost'

    display

# Generated at 2022-06-10 23:15:46.558286
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.facts import namespace_facts
    try:
       discover_interpreter('action', 'python', 'auto_legacy', namespace_facts(None))
    except InterpreterDiscoveryRequiredError:
       return True
    except:
       raise Exception('test_discover_interpreter failed.')

# Generated at 2022-06-10 23:16:14.840435
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule

    PyModule = type('PyModule', (ActionModule,), dict(ActionModule.__dict__))
    PyModule.action_loader = None
    PyModule.action_plugins = {}
    PyModule.action_plugins['python'] = PyModule()
    PyModule.action_plugins['python'].action_plugins = {}
    PyModule.action_plugins['python'].connection_plugins = {}
    PyModule.action_plugins['python'].bypass_host_loop = False
    PyModule.action_plugins['python'].no_log = False
    PyModule.action_plugins['python']._loaded_once = False


# Generated at 2022-06-10 23:16:28.097596
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        import ansible_collections.ansible.posix.tests.unit.executor.discovery.platform_python_map  # noqa
        import ansible_collections.ansible.posix.tests.unit.executor.discovery.bootstrap_python_list  # noqa
        from ansible_collections.ansible.posix.tests.unit.executor.discovery import python_target  # noqa
    except ImportError:
        # those libraries might be missing if we're not running from the main Ansible repo
        return True

    # TODO: platform.dist() is not supported on all platforms (e.g. OSX), so this test case needs to not invoke it

# Generated at 2022-06-10 23:16:38.067292
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.connection import Connection

    class TestActionBase(ActionBase):
        ''' Specialization of ActionBase to allow mocking the _low_level_execute_command method'''

# Generated at 2022-06-10 23:16:49.570877
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test interpreter_name
    try:
        discover_interpreter(None, '', '')
    except ValueError as v:
        assert 'Interpreter discovery not supported for ' in to_text(v)
    # test host
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {'inventory_hostname': 'localhost'}
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except Exception as e:
        assert str(e) == 'missing action for interpreter discovery'
    # test res
    # test platform_type
    # test platform_python_map
    # test bootstrap_python_list
    # test platform_script
    # test found_interpreters
    # test is_

# Generated at 2022-06-10 23:16:58.413716
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''
        Unit tests for function discover_interpreter
    '''
    # Step 01: make sure the function returns '/usr/bin/python' when the discovery_mode is 'auto_legacy'
    import ansible.modules.extras.system.setup  # pylint: disable=unused-variable
    task_vars = dict(some_var='some_value')
    res = discover_interpreter(ansible.modules.extras.system.setup, 'python', 'auto_legacy', task_vars)

    assert res == '/usr/bin/python'

# Generated at 2022-06-10 23:17:00.472379
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('','','','','','','','','','','','','','','','')

# Generated at 2022-06-10 23:17:08.742714
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.network import ModuleStub
    from ansible.module_utils.remote_management.common.remoting import Connection
    from ansible.executor.module_common import TaskExecutor
    from ansible.module_utils.parsing.convert_bool import boolean

    module = ModuleStub({'module_name': 'ping', 'module_args': {}})
    task_vars = {}
    module_vars = {}

    task_executor = TaskExecutor()
    task_executor._shared_loader_obj = task_executor._loader
    task_executor._connection = Connection(module_name='ping', module_args='', play_context=None, new_stdin=None)


# Generated at 2022-06-10 23:17:16.306177
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'explicit'
    task_vars = {}

    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == u'/usr/bin/python'

    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {}
    assert(discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == u'/usr/bin/python')


# Generated at 2022-06-10 23:17:27.843563
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys
    import unittest
    from ansible.module_utils.common.process import get_bin_path

    # init display object
    display.verbosity = 3

    # init the system
    action = sys.modules["ansible.executor.action_plugins.normal"]
    action._discovery_warnings = []
    action._shared_loader_obj = None
    interpreter_name = 'python'
    discovery_mode = 'always'
    task_vars = dict()

    def _low_level_execute_command(exe):
        from ansible.executor.task_executor import TaskExecutor

        conn = TaskExecutor()
        conn.has_pipelining = True
        conn._display = display
        conn._shell = exe
        conn.bin_path = dict()
        conn.bin_path

# Generated at 2022-06-10 23:17:29.832005
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Tests will be required to use a patched version of the config object
    raise Exception("Tests not implemented")

# Generated at 2022-06-10 23:17:56.576077
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils import basic
    from ansible.playbook.task_include import TaskInclude

    class MyAction():
        def __init__(self):
            self._low_level_execute_command = basic.run_command
            self.connection = MyConnection()

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=u''):
            return {}

        def _discovery_warnings(self):
            return []

    class MyTaskInclude(TaskInclude):
        def __init__(self):
            self._task = self
            self.action = MyAction()

    def test_discover_interpreter_success():
        test_task_include = MyTaskInclude()
        res

# Generated at 2022-06-10 23:18:10.137515
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Unit test for function discover_interpreter.
    Check if the function properly works.
    """
    # Test with platform_python_map that only has a hash and
    # a default value.
    action = None
    platform_python_map = {
        'redhat': {
            '6': '/usr/bin/python2.6',
            '7-default': '/usr/bin/python2.7',
        }
    }
    bootstrap_python_list = ['/usr/bin/python', '/usr/bin/python2.6', '/usr/bin/python2.7']

    # Test if function properly works when the python2.7 is used by default.

# Generated at 2022-06-10 23:18:19.178425
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.action
    action = ansible.plugins.action.ActionModule(connection=None,
                                                 play_context=None,
                                                 new_stdin=None,
                                                 loader=None,
                                                 templar=None,
                                                 shared_loader_obj=None)
    discovery_mode = 'auto_legacy'
    interpreter_name = 'python'
    task_vars = dict()
    task_vars['ansible_python_interpreter'] =  u'/usr/bin/python'

    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == u'/usr/bin/python'



# Generated at 2022-06-10 23:18:32.490163
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object()
    action._low_level_execute_command = lambda a, **kw: {'stdout': u"\r\n".join(a.split())}
    action._discovery_warnings = []
    action._connection = object()
    action._connection.has_pipelining = True
    task_vars = dict()

    action._low_level_execute_command.return_value = {
        'stdout': u'',
        'stderr': u'',
    }

    action._low_level_execute_command.side_effect = lambda a, **kw: {
        'stdout': u"PLATFORM\r\nLINUX\r\nFOUND\r\n/foo/bar/python-1\r\nENDFOUND",
    }


# Generated at 2022-06-10 23:18:40.272017
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:18:42.135277
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add test
    pass


# Generated at 2022-06-10 23:18:51.873563
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.action.discovery
    from ansible.release import __version__

    # NOTE: during refactor, we reduced the amount of test code in this file and
    # moved the remaining tests to a separate test module under unit/plugins/modules,
    # since this does not exercise the framework.
    from ansible.plugins.action.discovery.tests import test_discovery
    from ansible.plugins.action.discovery.tests import fakes

    test_discovery.run(ansible.plugins.action.discovery, fakes.FakeActionModule)

# Generated at 2022-06-10 23:19:03.865988
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # empty action - something _low_level_execute_command will work with
    action = type("", (), {})()

    # empty task_vars - something the config module will work with
    task_vars = {}

    # test missing discovery_mode value
    try:
        discover_interpreter(action, "python", "", task_vars)
        assert False
    except ValueError as ex:
        assert ex.message == "discovery_mode must be one of ['auto_legacy', 'auto_legacy_silent', 'auto', 'auto_silent', 'strict', 'strict_silent']"

    # test invalid discovery_mode value

# Generated at 2022-06-10 23:19:12.966446
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible_test.utils.test_runner as test_runner
    import ansible_test.shell_integration.test_discovery as test_discovery

    # The test actions use direct calls to the LegacyExecutor for speed.
    # But since that code is what we want to test, that is OK.
    # Note that stdout and stderr are replaced with our own versions
    # that can parse the results and allow us to verify we got the
    # expected results.
    display.quiet = True
    try:
        res = test_discovery.test_discover_interpreter()
        if res != 'successful':
            raise AssertionError('The test_discover_interpreter test failed.')
    finally:
        display.quiet = False

    display.quiet = True

# Generated at 2022-06-10 23:19:23.541000
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This function is called in test/unit/test_module_common.py, which is
    # not executed through tox.
    # If you modify this function, please test it manually by
    # running tox and executing test/unit/test_module_common.py.

    # To test this function, create a new file under:
    # test/units/test_module_common/test_discovery_interpreter

    # To add a new test, copy the following section, adjust to your need, and save the file.
    # Note: The file name will be displayed in module_common test log, so it is recommended
    # that you comment out the file after the test is completed.
    """
    This is a test for function discover_interpreter
    """
    import traceback
    from ansible.plugins.action.normal import ActionModule

# Generated at 2022-06-10 23:20:01.678209
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import tempfile
    import os
    from ansible.plugins.action import ActionBase

    class DummyActionModule(ActionBase):
        def __init__(self, *args, **kwargs):
            super(DummyActionModule, self).__init__(*args, **kwargs)
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            if 'echo PLATFORM; uname;' in args[0]:
                return {'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/local/bin/python\n/usr/bin/python\nENDFOUND'}


# Generated at 2022-06-10 23:20:11.222633
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    # FUTURE: better way to mock action?
    class DummyAction(object):
        def __init__(self):
            self._connection = Connection()
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            res = {}
            stdout = kwargs.get('in_data')
            if stdout is None:
                stdout = to_text('PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND')
            res['stdout'] = stdout
            return res

    display.verbosity = 3
    action = DummyAction()


# Generated at 2022-06-10 23:20:21.477595
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter

    mock_action = MockAction()
    mock_task_vars = dict()

    assert discover_interpreter(mock_action, 'python', 'auto_legacy', mock_task_vars) == '/usr/bin/python'

    mock_task_vars['inventory_hostname'] = 'localhost'
    assert discover_interpreter(mock_action, 'python', 'auto_legacy', mock_task_vars) == '/usr/bin/python'

    mock_task_vars['ansible_facts'] = {'notplatform_dist': ['', '', '']}
    display.verbosity = 1

# Generated at 2022-06-10 23:20:33.786255
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.executor.discovery import InterpreterDiscoveryRequiredError
    from ansible.errors import AnsibleError
    from ansible import constants as C
    from ansible.plugins.action import ActionBase
    from ansible.vars import VariableManager

    # test case 1
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {'inventory_hostname': 'test',
                 'ansible_python_interpreter': '/usr/bin/python3.6'}
    action = ActionBase()
    action._task = action.task_class(task_vars)

# Generated at 2022-06-10 23:20:42.200371
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Importing within function for better unit testing
    from ansible.executor.task_result import TaskResult

    class MockModule(object):
        def __init__(self, interpreter_name, discovery_mode, task_vars):
            self._discovery_warnings = []
            self._interpreter_name = interpreter_name
            self._discovery_mode = discovery_mode
            self._task_vars = task_vars

# Generated at 2022-06-10 23:20:54.892343
# Unit test for function discover_interpreter
def test_discover_interpreter():
    os.environ['ANSIBLE_SKIP_INTERPRETER_DISCOVERY'] = "yes"
    os.environ['ANSIBLE_PYTHON_INTERPRETER'] = "some_interpreter"
    fake_action = MagicMock()
    fake_action._low_level_execute_command = _low_level_execute_command
    fake_action._connection = _connection

    module_utils.distro._distribution = _distribution_fedora_28_python3

    result = discover_interpreter(fake_action, 'python', 'auto', {})
    assert result == 'some_interpreter'

    module_utils.distro._distribution = _distribution_fedora_28

    result = discover_interpreter(fake_action, 'python', 'auto', {})


# Generated at 2022-06-10 23:21:03.313331
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.vars.hostvars import HostVars

    class TestAction(ActionBase):
        def run(self, tmp=None, task_vars=dict()):
            return dict(token='dummy')

    results = TestAction(PlayContext()).run(task_vars=HostVars())

    interp_name = results['token']

    assert interp_name != None, "test_discover_interpreter() failed"

# Generated at 2022-06-10 23:21:11.373188
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Action:
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            return dict(rc=0, stdout='PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND\n', stderr='')
        def _discovery_warnings(self, msg):
            pass

    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {}

    res = discover_interpreter(Action(), interpreter_name, discovery_mode, task_vars)

    assert res == '/usr/bin/python'


# Generated at 2022-06-10 23:21:19.031968
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.action_write_locks import ActionWriteLock
    from ansible.plugins import module_loader
    from ansible.plugins.loader import find_plugin
    from ansible.vars import VariableManager

    action_write_lock = ActionWriteLock(None, None, None)

    # Create the task queue manager
    variable_manager = VariableManager()
    task_queue_manager = TaskQueueManager(
        variable_manager=variable_manager,
        loader=module_loader,
        passwords=dict(),
        stdout_callback=None,
        run_tree=False,
        action_write_lock=action_write_lock,
    )

    # Create the module_name for

# Generated at 2022-06-10 23:21:32.373579
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Most of the coverage for this function is in integration tests (see test/units/modules/utils/fetch/test_interpreter_discovery.yml),
    # but we'll add some unit test coverage here just to be safe.
    #
    # We're somewhat limited by the fact that the code is basically a big if/then/else, so we'll just cover
    # the explicit Python interpreter case, since that's the only one we care about on older Ansible versions.
    # Any changes to the function will probably cause unit test failures anyway.
    try:
        # FUTURE: expose this decorator to modules with proper config interface?
        from ansible.module_utils.common.removed import removed
        removed('discover_interpreter test')
    except ImportError:
        pass  # older version of Ansible
