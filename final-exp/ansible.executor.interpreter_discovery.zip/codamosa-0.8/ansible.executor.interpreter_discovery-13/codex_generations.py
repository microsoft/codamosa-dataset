

# Generated at 2022-06-10 23:12:40.744679
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:12:49.509740
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role, RoleRequirement
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    import os
    from collections import namedtuple

    # Create a named tuple that contains the needed inventory arguments
    # Needed for create

# Generated at 2022-06-10 23:13:00.357213
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:13:11.210343
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys
    import operator
    import tempfile
    import ansible.module_utils.basic
    ansible.module_utils.basic._ANSIBLE_ARGS = ['-T', '10', '-vvvvvvvvvv', '-C']
    from ansible.plugins.loader import module_loader
    from ansible.module_utils import basic
    from ansible.playbook.role.definition import RoleDefinition

    class FakeConnection(object):
        def __init__(self):
            self._has_pipelining = False

        def has_pipelining(self, filter=None):
            if filter is False:
                return False
            return self._has_pipelining and True or False

        def set_has_pipelining(self, val=True):
            self._has_pipelining = val


# Generated at 2022-06-10 23:13:13.324159
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # raise NotImplementedError('Write unit tests')
    pass

# Generated at 2022-06-10 23:13:26.500866
# Unit test for function discover_interpreter
def test_discover_interpreter():

    def _do_checks(res, warnings, interp):
        if res is None:
            assert False, 'discover_interpreter failed'

        if warnings:
            for w in warnings:
                assert w.startswith('Platform')

        assert res == interp

    def _create_action(**kwargs):
        """
        Creates a mock _ActionModule object and fills in the required attributes.  The object is stateful,
        but nothing should be side-effected.
        """
        class FakeModuleUtils(object):
            def __getattr__(self, item):
                # A few actions need to get the system temporary directory, which is implemented
                # in the module utils.  We can safely provide a fake tempdir and just return
                # a hardcoded path here.
                if item == 'tempfile':
                    return

# Generated at 2022-06-10 23:13:34.717122
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    #module = AnsibleModule(argument_spec=dict(inventory_hostname='test', interpreter_name='py3', discovery_mode='auto', version_map=dict(), version='3.4'))
    module = AnsibleModule(argument_spec=dict(inventory_hostname='test', interpreter_name='py3', discovery_mode='auto_legacy', version_map=dict(), version='3.4'))
    assert discover_interpreter(module, 'py3', 'auto', dict()) == '/usr/bin/python'

# Generated at 2022-06-10 23:13:46.569841
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest

    class _DiscoveryTask(object):
        def __init__(self):
            self._discovery_warnings = []

    class _DiscoveryModule(object):
        def __init__(self, interpreter_name='python', discovery_mode='auto'):
            self.args = {'interpreter': interpreter_name, 'discovery_mode': discovery_mode}
            self._connection = _DiscoveryModuleConnection()
            self.task = _DiscoveryTask()

    class _DiscoveryModuleAction(object):
        def __init__(self):
            self._connection = _DiscoveryModuleConnection()
            self._discovery_warnings = []

    class _DiscoveryModuleConnection(object):
        def __init__(self):
            self.has_pipelining = True


# Generated at 2022-06-10 23:13:57.354781
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import Mock

    shell_bootstrap = '''echo PLATFORM; uname; echo FOUND; /usr/bin/python; echo ENDFOUND'''

    mock_action = Mock()
    mock_action._low_level_execute_command.return_value = {'stderr': '', 'rc': 0, 'stdout': shell_bootstrap}

    mock_task_vars = {
        'ansible_connection': '',
        'inventory_hostname': 'localhost'
    }
    mock_action._connection = Mock()
    mock_action._connection.has_pipelining = True

    # TODO: we need a way to inject the standard pkgutil resources, as we don't have a context to pull in the module
   

# Generated at 2022-06-10 23:14:10.165389
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # prepare test data
    data = dict()
    data['inventory_hostname'] = 'test_host'
    data['gather_subset'] = ['!all']
    data['interpreter_python_fallback'] = ['python3', '/opt/python3.6']

# Generated at 2022-06-10 23:14:20.944748
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert None == discover_interpreter(action=None, interpreter_name='pep8', discovery_mode='auto', task_vars={})



# Generated at 2022-06-10 23:14:33.184216
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    task_vars = {}

# Generated at 2022-06-10 23:14:43.998187
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This implements unit tests for the function to find interpreter for a host for the new
    #  interpreter discovery code
    import os
    import unittest

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.connection import Connection
    from ansible.plugins.action.script import ActionModule as ScriptActionModule

    from units.mock.procenv import swap_stdin_and_argv

    class TestModule(unittest.TestCase):
        """This implements unit tests for the function to find interpreter for a target host
        """


# Generated at 2022-06-10 23:14:51.021136
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = dict(inventory_hostname='test_host', ansible_python_interpreter='/test/bin/test_python')

    # No InterpreterDiscoveryRequiredError should be raised.
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res == '/test/bin/test_python'

# Generated at 2022-06-10 23:15:02.000222
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = dict()
    action['_discovery_warnings'] = list()
    action['_low_level_execute_command'] = dict()
    action['_low_level_execute_command']['stdout'] = "PLATFORM\r\ndarwin\r\nFOUND\r\n/usr/bin/python2.7\r\nENDFOUND"

    interpreter_name='python'
    discovery_mode='auto'
    task_vars=[{'inventory_hostname': 'test'}]
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res == '/usr/bin/python2.7'


# Generated at 2022-06-10 23:15:12.245112
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test a standard case (with mocked data file handling)
    test_task_vars = dict(ANSIBLE_DISCOVERY_MODE='auto_legacy_silent')
    test_action = MockAction()
    # FUTURE: test different interpreter names (via a new MockAction)
    assert discover_interpreter(test_action, 'python', 'auto_legacy_silent', test_task_vars) == u'/usr/bin/python'

    # test NotImplementedError (mocked)
    test_task_vars = dict(ANSIBLE_DISCOVERY_MODE='auto_legacy')
    test_action = MockAction(methods={'_low_level_execute_command': {'raise': NotImplementedError('mock error')}})

# Generated at 2022-06-10 23:15:19.362265
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule as ScriptActionModule
    from ansible.executor import module_loader
    import ansible.executor.discovery
    import os

    class TestActionModule(ScriptActionModule):
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if in_data:
                if cmd != '/usr/bin/python':
                    raise AssertionError('unexpected interpreter for pipelined command: {0}'.format(cmd))

                res = ansible.executor.discovery.LinuxDistribution().get_platform_info()
                return dict(stdout=json.dumps(res).encode('utf-8'), stderr=b'')


# Generated at 2022-06-10 23:15:20.836067
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:15:30.561269
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FIXME: unit tests should be in test/units/modules/ , not here
    module_args = dict(
        interpreter_name='python',
        discovery_mode='auto_legacy_silent',
    )
    task_vars = dict(
        ansible_python_interpreter='/usr/bin/python',
        ansible_python_major_version=2,
    )
    res = discover_interpreter(action=None, interpreter_name=module_args['interpreter_name'],
                               discovery_mode=module_args['discovery_mode'], task_vars=task_vars)
    assert res == task_vars['ansible_python_interpreter']

# Generated at 2022-06-10 23:15:34.033915
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    test the discover_interpreter function
    """
    print(discover_interpreter(None, 'python', 'auto_silent', {}))

# Generated at 2022-06-10 23:15:50.903093
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible_collections.ansible.executor.tests.unit.test_module_discovery as test

    import tests.unit.executor.test_discovery as test_discovery

    interp_names = ['python', 'python2', 'python3']
    discovery_modes = ['auto', 'auto_legacy']


# Generated at 2022-06-10 23:15:58.368621
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import ansible.module_utils.common.process
    import ansible.module_utils.common.text
    import ansible.module_utils.connection.connection

    import ansible.executor.discovery
    ansible_module = AnsibleModule(argument_spec={})
    ansible_module.exit_json = lambda x: test_discover_interpreter_callback(x)

    mock_display = type('MockDisplay', (object,), {'debug': lambda x: None, 'v': lambda x: None, 'vv': lambda x: None, 'vvv': lambda x: None, 'warning': lambda x: None})
    ansible.module_utils.common.text.Display = mock_display
   

# Generated at 2022-06-10 23:16:00.503634
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', "auto_silent", {}) == u'/usr/bin/python'

# Generated at 2022-06-10 23:16:12.645041
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins import action
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    _action = action.ActionModule(play_context=PlayContext())

    # TODO: verify exceptions/warnings and discovery results
    # TODO: beef up with multiple distros/versions

    # non-discovery mode
    assert discover_interpreter(_action, u'python', u'auto', dict(inventory_hostname='fakehost')) == u'/usr/bin/python'
    assert discover_interpreter(_action, u'python', u'auto_legacy', dict(inventory_hostname='fakehost')) == u'/usr/bin/python'

# Generated at 2022-06-10 23:16:21.001835
# Unit test for function discover_interpreter
def test_discover_interpreter():
    mock_action_type = type('MockAction', (object,), {
        '_discovery_warnings': ['discovery_warnings_mock'],
        '_low_level_execute_command': lambda self, shell_bootstrap, sudoable, in_data: {"stdout": "PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND\n"},
        '_connection': type('MockConn', (object,), {'has_pipelining': True})
    })

    mock_action = mock_action_type()


# Generated at 2022-06-10 23:16:26.765219
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action_plugin = ActionModule(connection=MagicMock(), runner_queue=MagicMock())
    assert discover_interpreter(action_plugin, 'python', 'silent', {}) == '/usr/bin/python'

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-10 23:16:37.458004
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class ActionModule:
        def _discovery_warnings(self):
            return []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=''):
            return {'stdout': "PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND", 'stderr': ''}

    action = ActionModule()
    # We are using the execute_command() to return static values we need for testing the discover_interpreter()
    #
    # FUTURE: unit test cases for the extended discovery

    ###########################################################################
    # test exact match
    ###########################################################################
    # test exact match with lowercase distro name
    # when distro name is lowercase it should work fine

# Generated at 2022-06-10 23:16:49.207246
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.raw import ActionModule as RawActionModule
    from ansible.executor.discovery import discover_interpreter

    # Test 1, with success
    task_vars = dict()

    action = RawActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    action._low_level_execute_command = lambda cmd, sudoable=False, in_data=None: dict(stdout='PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND')
    with action:
        result = discover_interpreter(action=action, interpreter_name='python', discovery_mode='force', task_vars=task_vars)

    assert result == '/usr/bin/python'

# Generated at 2022-06-10 23:17:01.110120
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object()

    # test values for parameters
    action._low_level_execute_command = lambda *args: {'stdout': u'LINUX\ncmd1\n\n\ncmd2\n', 'rc': 0, 'stderr': u''}
    action._discovery_warnings = []
    action._connection = object()
    action._connection.has_pipelining = True
    action._task = object()
    action._task.args = dict()
    task_vars = dict()

    # Ensure that our helper function throws a ValueError when given a non-python interpreter

# Generated at 2022-06-10 23:17:02.468667
# Unit test for function discover_interpreter
def test_discover_interpreter():
    discover_interpreter(None, 'python', 'auto', {})

# Generated at 2022-06-10 23:17:30.658084
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'
    try:
        discover_interpreter(None, 'python2', 'auto', {})
        assert False, "should have failed"
    except ValueError:
        pass

# Generated at 2022-06-10 23:17:42.199793
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    import ansible.module_utils.basic
    import ansible.module_utils.distro

    # setup test environment, we are using basic here as a mock object
    action = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())

    # Linux Distribution
    plat_info_ubuntu = dict()
    plat_info_debian = dict()
    plat_info_amzn = dict()
    plat_info_suse = dict()
    plat_info_redhat = dict()
    plat_info_unknown = dict()

    # Ubuntu
    plat_info_ubuntu['platform_dist_result'] = ['Ubuntu', '16.04', 'xenial']

# Generated at 2022-06-10 23:17:49.149657
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext

    pc = PlayContext()

    interpreter_name = "python"
    discovery_mode = "auto_silent"
    task_vars = {}

    interpreter = discover_interpreter(pc, interpreter_name, discovery_mode, task_vars)

    assert interpreter == '/usr/bin/python'

# Generated at 2022-06-10 23:18:03.324939
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.executor.discovery
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence

    original_import = __import__
    # Mock display
    class MockDisplay(object):
        def __init__(self):
            self.debug = mock.MagicMock()
            self.vvv = mock.MagicMock()
            self.warning = mock.MagicMock()

    display = MockDisplay()
    # Mock Class ActionModule
    module_args = {}

# Generated at 2022-06-10 23:18:05.034502
# Unit test for function discover_interpreter
def test_discover_interpreter():
    result = discover_interpreter(None, 'python', 'auto', dict())
    assert result == u'/usr/bin/python'

# Generated at 2022-06-10 23:18:15.992366
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Create a test action
    class TestAction:
        def __init__(self):
            self.test_task_vars = dict()
            self._low_level_execute_command = None

    test_action = TestAction()

    # Set up test inventory variables
    test_action.test_task_vars['INTERPRETER_PYTHON_DISTRO_MAP'] = {
        "amazon": {
            "1.0": "/usr/bin/python"
        },
        "redhat": {
            "1": "/usr/bin/python",
            "2": "/usr/bin/python2"
        },
        "suse": {
            "1": "/usr/bin/python",
            "2": "/usr/bin/python2"
        }
    }

    test_action.test_task

# Generated at 2022-06-10 23:18:23.582102
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(AnsibleModule):
        def __init__(self):
            super(FakeModule, self).__init__
            self._discovery_warnings = []

        def warning(self, msg):
            self._discovery_warnings.append(msg)

    # Set to autodetect python interpreter with silent mode

# Generated at 2022-06-10 23:18:35.929072
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.module_common import ModuleCommon
    import ansible.executor.action_write as action_write
    import ansible.plugins.loader as plugin_loader
    import ansible.executor.module_common as module_common

    plugin_loader.add_directory('./lib/ansible/plugins')
    plugin_loader.add_directory('./lib/ansible/modules')

    action = action_write.ActionModule(connection=None,
                                       templar=None,
                                       shared_loader_obj=None,
                                       ansible_modlib=None,
                                       connection_loader=None,
                                       play_context=None)

    action._templar.available_variables = {'inventory_hostname': 'test_host'}

    interpreter_name = 'python'
    discovery

# Generated at 2022-06-10 23:18:47.477006
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.compat import ipaddress

    display.verbosity = 4
    action = C.ANSIBLE_MODULE_UTILS + '/powershell.ps1'

    # init inventory vars, we need to mock all the facts

# Generated at 2022-06-10 23:18:57.600874
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    assert discover_interpreter(None, 'python', 'auto_legacy', {'ansible_distribution': 'debian'}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', {'ansible_distribution': 'ubuntu', 'ansible_distribution_version': '14.04'}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', {'ansible_distribution': 'ubuntu', 'ansible_distribution_version': '18.04'}) == '/usr/bin/python3'

# Generated at 2022-06-10 23:19:41.620382
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.module_utils.facts.system.discovery.python_target
    def _run_func(osrelease_content):
        osrelease_content = osrelease_content.encode('utf8')
        platform_info = {
            'osrelease_content': osrelease_content,
        }
        distro, version = ansible.module_utils.facts.system.discovery.python_target._get_linux_distro(platform_info)
        return distro, version

    assert _run_func('') == (u'', u'')
    assert _run_func('NAME="CentOS Linux"') == (u'', u'')
    assert _run_func('NAME="CentOS Linux"\nVERSION_ID="7"') == (u'centos', u'7')

# Generated at 2022-06-10 23:19:55.163779
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FIXME: I couldn't figure out how to mock out the actual interpreter discovery, since it
    # requires non-trivial command execution, so this test is pretty limited...
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_text, to_bytes
    fakeshell = b'PLATFORM\nDarwin\nFOUND\n/usr/bin/python\nENDFOUND'
    task_vars = dict(ansible_python_interpreter='/usr/bin/python3',
                     ansible_connection='local',
                     ansible_connection_local_tmp='/tmp',
                     ansible_hostname='localhost',
                     ansible_user_id='root')


# Generated at 2022-06-10 23:20:08.483460
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader

    my_host = "somehost"
    action_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)
    action_plugin = action_loader.get('command')
    my_task = dict(action=dict(module='command', args=dict(cmd='/usr/bin/python --version')))
    my_task_

# Generated at 2022-06-10 23:20:19.835309
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """Tests to ensure the interpreter discovery matches python interpreters as expected"""
    import ansible.executor.discovery
    import ansible.utils.ansible_runner

    test_task = ansible.utils.ansible_runner.AnsibleRunner(
        os.path.join(os.path.dirname(__file__), '..')
    ).get_ansible_runner_init_callback()()

    test_task_vars = {}
    if os.path.exists('/etc/os-release'):
        with open('/etc/os-release') as f:
            test_task_vars['os_release'] = f.read()
    else:
        test_task_vars['os_release'] = ''

# Generated at 2022-06-10 23:20:29.127540
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # include default python interpreters for test_host_manager
    # these are what ansible-test will use
    py_interpreters = ['/usr/bin/python', '/usr/bin/python2', '/usr/bin/python3']

    test_interpreter = discover_interpreter(None, 'python', 'auto', {'ansible_python_interpreter': py_interpreters})
    assert test_interpreter in py_interpreters, "Failed to find python interpreter"

# Generated at 2022-06-10 23:20:38.883606
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from six import StringIO
    from ansible.errors import AnsibleModuleError, AnsibleActionFail, AnsibleParseError
    from ansible.plugins.action.script import ActionModule as script_action
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class Connection:
        def __init__(self, has_pipelining, **kwargs):
            self.has_pipelining = has_pipelining
            self.host = None
            self.kwargs = kwargs


# Generated at 2022-06-10 23:20:50.426860
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:20:55.607628
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult

    # Data for test
    test_task_vars = {'foo': 'bar'}
    action = TaskResult(host='127.0.0.1', task='shell', module_name='shell',
                        module_args='', task_action='command', interpreter_name='python', task_vars=test_task_vars)

    # Test python interpreter discovery
    assert discover_interpreter(action, 'python', 'auto', test_task_vars) == '/usr/bin/python'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-10 23:21:06.733153
# Unit test for function discover_interpreter
def test_discover_interpreter():
    display.verbosity = 2

    test_task_vars =  {'inventory_hostname': 'test_hostname'}

    test_action = C.settings.Action()
    test_action._connection = C.settings.Action()
    test_action._connection.has_pipelining = True


# Generated at 2022-06-10 23:21:19.326725
# Unit test for function discover_interpreter