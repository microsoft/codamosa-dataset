

# Generated at 2022-06-10 23:12:50.039526
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.discovery import ActionModule

    class FakeModule:
        def __init__(self, name):
            self.name = name
            self.discovery_warnings = []

    class FakeRunner:
        def __init__(self, hostname):
            self.hostname = hostname
            self.connection = FakeRunnerConnection()
            self.name = 'runner'

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            if command.startswith('command -v '):
                return {'stdout': self._resolve_fallback_interpreter(command)}
            if command.startswith('/usr/bin/python'):
                return {'stdout': self._resolve_linux_distro(in_data)}
           

# Generated at 2022-06-10 23:13:01.327050
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import string
    import random
    import os
    import sys

    # needed because pkgutil is not found in VCR cassettes
    if sys.version_info[0] == 2:
        import __builtin__ as builtin
    else:
        import builtins as builtin

    # don't assume the file is already loaded
    with os.popen('cat modules/platform.py') as f:
        platform_code = f.read().strip()
    # assume for now that the platform code is relatively current and does not need to be modified for the test
    # FUTURE: add more cases (older platforms, distros with multiple Python versions)

    def _setuptools_safe_pkgutil_get_data(package, resource):
        if resource == 'platform.py':
            return platform_code

# Generated at 2022-06-10 23:13:11.858331
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import json
    import pytest
    from ansible.executor.task_result import TaskResult
    from ansible.executor.discovery import discover_interpreter

    distribution_platforms = {
        'ubuntu': ['12.04', '14.04', '16.04', '18.04', '20.04'],
        'debian': ['7', '8', '9'],
        'centos': ['7', '8'],
        'fedora': ['28', '29', '30', '31', '32'],
        'redhat': ['6', '7', '8'],
        'oracle': ['6', '7', '8'],
    }

    def _get_platform_type(distro, version):
        if distro in ['ubuntu', 'debian']:
            return 'debian'


# Generated at 2022-06-10 23:13:21.784352
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Unit test for function discover_interpreter.
    """
    task_vars = {
        'ansible_distribution': 'RedHat',
        'ansible_distribution_version': '7.3',
        'ansible_python_interpreter': '/usr/bin/python',
    }
    action = None
    interpreter_name = 'python'
    discovered_interpreter = discover_interpreter(action, interpreter_name, 'auto_legacy_silent', task_vars)
    assert discovered_interpreter == '/usr/bin/python'

# Generated at 2022-06-10 23:13:32.188812
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.discovery import InterpreterDiscoveryRequiredError

    mock_class = type("MockAction", (object,), {
        "__init__": lambda self: None,
        "_low_level_execute_command": lambda self, command, sudoable=None, in_data=None: {
            "stdout": "PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python3.6\nENDFOUND"
        },
        "_discovery_warnings": list()
    })
    mock_action = mock_class()

    # mock task_vars
    task_vars = dict()
    mock_python_distro_map = dict()
    mock_python_distro_map['centos'] = dict()
    mock_python_dist

# Generated at 2022-06-10 23:13:34.619613
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', {}) == u'/usr/bin/python'

# Generated at 2022-06-10 23:13:46.521614
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult

    # test for python discovery
    action = TaskResult('null', 'null', 'null')

    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = {}

    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except Exception as ex:
        assert ex.__class__.__name__ == 'InterpreterDiscoveryRequiredError'
        assert interpreter_name == ex.interpreter_name
        assert discovery_mode == ex.discovery_mode

    # test for python3 discovery
    action = TaskResult('null', 'null', 'null')

    interpreter_name = 'python3'
    discovery_mode = 'auto_legacy_silent'

# Generated at 2022-06-10 23:13:57.327911
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Executor(object):
        def __init__(self):
            self.has_pipelining = True
            self._connection = Executor()

        def _low_level_execute_command(self, _command, sudoable=False, in_data=None, stdin=None):
            # python-specific test case
            if _command == '/bin/sh':
                return {'rc': 0, 'stdout': """PLATFORM
Linux
FOUND
/usr/bin/python
ENDFOUND
""", 'stderr': ''}

# Generated at 2022-06-10 23:13:58.490593
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO
    pass

# Generated at 2022-06-10 23:14:11.734211
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {'ansible_python_interpreter': '/usr/bin/python'}) == '/usr/bin/python'

    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'

    assert discover_interpreter(None, 'python', 'off_silent', {}) == '/usr/bin/python'

    assert discover_interpreter(None, 'python', 'force_silent', {'ansible_python_interpreter': '/usr/bin/python'}) == 'python'


# Generated at 2022-06-10 23:14:33.447736
# Unit test for function discover_interpreter
def test_discover_interpreter():
    if not C.HAS_PYTHON_VALIDATE:
        pytest.skip('python-validate not installed')

    from ansible.module_utils.compat.version import LooseVersion
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    # We need to create and initilalize class variables.
    context = PlayContext()
    action = ActionBase(task=dict(action=dict()), connection=dict(conn_type='ssh', host='localhost'), play_context=context)

    action._connection.has_pipelining = True

    # Required by _version_fuzzy_match
    assert LooseVersion('1.1') < LooseVersion('1.15')


# Generated at 2022-06-10 23:14:44.254174
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor

    class FakeAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self.task_vars = {'ansible_sudo': False}
            self._connection = FakeConnection()

        def _low_level_execute_command(self, command, sudoable=True, in_data=None):
            warnings = []
            if command.startswith('echo PLATFORM; uname'):
                if command.endswith('python3'):
                    return {'stdout': 'PLATFORM\nLinux\n'
                                      'FOUND\n/usr/bin/python2.7 /usr/bin/python3.5\nENDFOUND'}

# Generated at 2022-06-10 23:14:55.304602
# Unit test for function discover_interpreter
def test_discover_interpreter():
    with open('tests/unit/executor/discovery/python_target_centos_6.json') as centos_6_json:
        centos_6_platform_info = json.load(centos_6_json)

    with open('tests/unit/executor/discovery/python_target_centos_7.json') as centos_7_json:
        centos_7_platform_info = json.load(centos_7_json)

    with open('tests/unit/executor/discovery/python_target_debian_8.json') as debian_8_json:
        debian_8_platform_info = json.load(debian_8_json)

    with open('tests/unit/executor/discovery/python_target_debian_9.json') as debian_9_json:
        debian_

# Generated at 2022-06-10 23:15:07.085055
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import _load_params

    action = 'setup'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict(inventory_hostname='foo.foobar', ansible_python_interpreter='/tmp/foo/bar')
    # TODO: expose _discovery_warnings as a property on TaskResult
    result = TaskResult(name='foo', host='foo.foobar')
    display._verbosity = 10
    display.color = 'light'

    pb_context = PlayContext()
    pb_context.connection = 'local'
    pb_context.become = False
    pb_context

# Generated at 2022-06-10 23:15:16.606988
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class action_mock():
        def __init__(self):
            self._discovery_warnings = []
            self._connection = connection_mock()

        def _low_level_execute_command(self, __, sudoable, in_data=None):
            return {'stdout': discovered_output_mock(__)}

    class connection_mock():
        def __init__(self):
            self.has_pipelining = True

    class discovered_output_mock():
        def __init__(self, python_interpreter):
            self.python_interpreter = python_interpreter
            self.platform_type = 'linux'
            self.distro = 'centos'
            self.version = '7.0'

# Generated at 2022-06-10 23:15:29.258189
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        TRANSFERS_FILES = False
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(ActionBase, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

        def _execute_module(self, tmp=None, task_vars=None):
            #calls the real method
            return discover_interpreter(self, 'python', 'auto_legacy_silent', task_vars)


# Generated at 2022-06-10 23:15:42.701736
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    play_context = Play().set_loader(None)
    play_context._set_connection('local')
    action = TaskExecutor(play_context, Handler(), Task(), Block(), None, task_vars={}, templar=None)
    action._set_connection_info(connection_info={'host': 'localhost'})
    action._set_loader(None)
    action._set_play_context(play_context)
    action._discovery_warnings = []

    # invalid interpreter

# Generated at 2022-06-10 23:15:49.595986
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = {'_host': {'ipv4': '192.168.10.1'},
              '_discovery_warnings': [],
              '_low_level_execute_command': lambda x, sudoable=None, in_data=None: x,
              '_connection': {'has_pipelining': True}}
    task_vars = {'ansible_python_interpreter': '/usr/bin/python'}
    interpreter = discover_interpreter(action, 'python', 'auto_legacy', task_vars)
    assert interpreter == '/usr/bin/python'

# Generated at 2022-06-10 23:15:56.684646
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.parsing.plugin_docs import read_docstring

    #TODO: this test should mock the action object, but for now use the real thing and just ignore the warnings
    from ansible.plugins.action import ActionModule
    action = ActionModule(connection=None)

    # try a missing version
    platform_interpreter = discover_interpreter(action, 'python', 'explicit', {'ansible_facts': {'ansible_distribution': u'Wallaby',
                                                                                                 'ansible_distribution_version': u'2.0'}})
    assert platform_interpreter == u'/usr/bin/python'

    action._discovery_warnings = []

    platform_interpreter = discover_interpre

# Generated at 2022-06-10 23:15:58.637573
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement
    pass

# Generated at 2022-06-10 23:16:29.947531
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class ActionModule:
        _discovery_warnings = None
        _low_level_execute_command = None
        _connection = None

        def set_discovery_warnings(self, warnings):
            self._discovery_warnings = warnings

        def get_discovery_warnings(self):
            return self._discovery_warnings

        def set_low_level_execute_command(self, execute_command):
            self._low_level_execute_command = execute_command

        def get_low_level_execute_command(self):
            return self._low_level_execute_command

        def set_connection(self, connection):
            self._connection = connection

    class Connection:
        def __init__(self, has_pipelining):
            self._has_pipelining = has_pipelining


# Generated at 2022-06-10 23:16:39.122987
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule
    action = ActionModule(None, None, {})
    # Test in case of no interpreter found on system
    assert not discover_interpreter(action, 'python', 'auto_legacy_silent', {})
    # Test in case of both python 2 and python 3 installed
    assert discover_interpreter(action, 'python', 'auto_legacy_silent', {
        'INTERPRETER_PYTHON_DISTRO_MAP': {
            'centos': {
                '6.8': '/usr/bin/python'
            }
        },
        'inventory_hostname': 'test_host'
    }) == '/usr/bin/python'
    # Test in case of python 2 is installed

# Generated at 2022-06-10 23:16:44.170817
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.utils.version import NumericVersion

    gather_subset = [u's!all', u'*']

    # minimal task_vars to satisfy the config lookup

# Generated at 2022-06-10 23:16:45.159929
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: write a test or two
    pass

# Generated at 2022-06-10 23:16:46.115197
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass


# Generated at 2022-06-10 23:16:58.231121
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.cli import CLI
    from ansible.executor import module_common
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible_collections.kube_modules.sensu.plugins.module_utils import sensu_common

    from ansible_collections.kube_modules.sensu.plugins.module_utils.k8s.raw import KubernetesRawModule

    loader = DataLoader()
    a = CLI()
    a.options = SensuCL

# Generated at 2022-06-10 23:16:58.887109
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:17:07.928903
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.mock import patch, Mock
    from ansible.module_utils.basic import AnsibleModule

    C.DEFAULT_INTERPRETER_DISCOVERY = 'auto_legacy_silent'


    def _mock_low_level_execute_command(cmd, sudoable=None, in_data=None, executable='/bin/sh'):
        if cmd.startswith('command -v'):
            return dict(stdout='/usr/bin/python\n/usr/bin/python2.7')
        elif cmd == '/usr/bin/python':
            return dict(stdout='{"platform_dist_result": ["redhat", "8.1", "Beta"]}')

# Generated at 2022-06-10 23:17:15.024877
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    action = os
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {
        "inventory_hostname": "fake_host",
        "auto_python_interpreter": None
    }
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    print('test_discover_interpreter: {}'.format(res))


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-10 23:17:26.775706
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    host_list = [
        'localhost'
    ]

    inventory = InventoryManager(loader=loader, sources=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-10 23:18:12.180341
# Unit test for function discover_interpreter
def test_discover_interpreter():
    args = dict(action=None, interpreter_name='python', discovery_mode='auto')

    def _mock_low_level_execute_command(cmd, **kwargs):
        # this is the shell bootstrap
        if cmd.startswith('echo PLATFORM'):
            return dict(stdout=u'PLATFORM\nlinux\nFOUND\n/usr/bin/python\nENDFOUND')

        # this is the platform Python interpreter command
        bootstrap_python = cmd

        display.debug(u"found interpreters: {0}".format(args.get('interpreter_name')), args.get('host'))

        platform_python_map = C.config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP', variables=args.get('task_vars'))

# Generated at 2022-06-10 23:18:21.429833
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.common.removed import removed_module

    class TestActionBase(ActionBase):
        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            if command == "command -v 'python'":
                return dict(stdout=u'/usr/bin/python')
            elif command == "/usr/bin/python":
                output_fname = 'python_target_output.txt'
                return dict(stdout=removed_module.read_data_from_file(output_fname, module_name='discovery'))
            else:
                raise ValueError("unexpected command: {0}".format(command))

    task_vars = dict(inventory_hostname='localhost')
    test

# Generated at 2022-06-10 23:18:34.465960
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test 1
    interpreter_name = "python"
    discovery_mode = "auto"
    task_vars = {"ansible_problem": "world", "inventory_hostname": "test_host", "inventory_dir": "test_dir"}
    action = object()
    try:
        result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except NotImplementedError:
        assert True
    else:
        assert False, "Test is supposed to raise the NotImplementedError exception."

    # Test 2
    action.become = True
    action.become_user = "test_user"
    try:
        result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except NotImplementedError:
        assert True

# Generated at 2022-06-10 23:18:46.613269
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule

    # testing data
    test_hosts = [{u'inventory_hostname': u'host_value_missing'},
                  {u'inventory_hostname': u'host_with_python2'},
                  {u'inventory_hostname': u'host_with_python3'},
                  {u'inventory_hostname': u'host_with_python2_and_python3'}]

    # host with missing python interpreters
    test_hosts.append({u'inventory_hostname': u'host_with_no_python'})
    test_hosts.append({u'inventory_hostname': u'host_with_default_python_only'})

# Generated at 2022-06-10 23:18:57.797687
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # unit test is loaded, but function is not yet
    try:
        discover_interpreter
    except NameError:
        from ansible.executor.discovery import discover_interpreter

    # test corner cases
    try:
        discover_interpreter(None, 'foo', 'auto_legacy_silent', None)
        assert False, 'discover_interpreter() should have failed for an unsupported interpreter'
    except ValueError:
        pass

    try:
        discover_interpreter(None, 'python', 'foo', None)
        assert False, 'discover_interpreter() should have failed for an unsupported discovery mode'
    except ValueError:
        pass


# Generated at 2022-06-10 23:19:10.001896
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = MockAction()
    task_vars = action._get_task_vars()
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    discovery_mode_supported = True
    if discovery_mode != 'auto' and discovery_mode != 'auto_legacy':
        discovery_mode_supported = False
        raise InterpreterDiscoveryRequiredError(
            "Invalid discovery mode '{0}' specified. Currently supported modes are 'auto' and 'auto_legacy'.".format(discovery_mode),
            interpreter_name,
            discovery_mode)
    print(discover_interpreter(action, interpreter_name, discovery_mode, task_vars))
    print(discovery_mode_supported)


# Generated at 2022-06-10 23:19:20.283303
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    This function is not meant to be ran directly.
    It will be used by the python interpreter discovery unit test
    """
    import os
    import sys

    # Save the real environment
    real_vars = os.environ.copy()

    # Unload ansible
    if "ansible" in sys.modules:
        del sys.modules["ansible"]

    # Mock the inventory_hostname
    os.environ['inventory_hostname'] = "ubuntu_18.04"

    # Mock the constants
    sys.modules['ansible.constants'] = None
    import ansible.constants as C

    # Mocking the configuration
    C.config = None
    sys.modules['ansible.config'] = None
    import ansible.config as config
    from ansible.module_utils.six import StringIO

   

# Generated at 2022-06-10 23:19:30.766231
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.plugins.action import ActionBase
    from ansible.utils.color import stringc
    class TestActionModule(ActionBase):
        def run(self, tmp=None, task_vars=dict()):
            # need to override ActionBase to handle tqm
            class TestTaskQueueManager(object):
                def __init__(self):
                    self.console_buffer = []
                    self.output = None
                    self.blocked_hosts = dict()
                def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False, redirect_stdout=False):
                    self.console_buffer.append(stringc(msg, color))

# Generated at 2022-06-10 23:19:42.377633
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    import platform
    import sys
    import unittest

    # individual test cases are tuples of:
    #    * discovery mode (legacy / auto_legacy / auto)
    #    * list of available interpreters
    #    * expected result (interpreter path)
    #    * expected warning string (or None if no warning expected)

# Generated at 2022-06-10 23:19:55.444490
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class ActionModule(object):
        def __init__(self):
            self._discovery_warnings = []
        def __getitem__(self, item):
            return self.__dict__.get(item)
        def __setitem__(self, key, value):
            self.__dict__[key] = value
        class _LowLevelExecuteCommand(object):
            def __init__(self, stdout, stderr):
                self.stdout = stdout
                self.stderr = stderr
        class _Connection(_LowLevelExecuteCommand):
            def __init__(self, stdout, stderr):
                super(ActionModule._Connection, self).__init__(stdout, stderr)
                self.has_pipelining = True

# Generated at 2022-06-10 23:21:34.494958
# Unit test for function discover_interpreter
def test_discover_interpreter():
    for line in discover_interpreter(discover_interpreter, 'python', 'auto_legacy_default_silent', {}):
        print(line[:-1])

# Generated at 2022-06-10 23:21:43.938690
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:21:55.281559
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.setup import ActionModule as Setup
    from ansible.plugins.sorter.linear import sort
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    class MockConnection:
        def __init__(self):
            self.has_pipelining = True
            self.transport = 'local'

        def exec_command(self):
            return True

    class MockOptions:
        def __init__(self):
            self.connection = 'local'
            self.module_path = '.'
            self.listhosts = None
            self.listtasks = None

# Generated at 2022-06-10 23:22:02.847071
# Unit test for function discover_interpreter
def test_discover_interpreter():
    with open('test/units/module_utils/discovery_fixtures/interpreter_discovery_files/python_target.py', 'rb') as f:
        platform_script = to_text(f.read(), errors='surrogate_or_strict')

    with open('test/units/module_utils/discovery_fixtures/interpreter_discovery_files/python_target_stdout.json', 'rb') as f:
        platform_stdout = to_text(f.read(), errors='surrogate_or_strict')

    platform_info = json.loads(platform_stdout)

    distro, version = _get_linux_distro(platform_info)

    assert distro == 'RedHatEnterpriseServer'
    assert version == '7.3'

    # simulate a pipelined connection

# Generated at 2022-06-10 23:22:06.037621
# Unit test for function discover_interpreter
def test_discover_interpreter():
    ''' Unit test for function discover_interpreter '''
    raise SkipTest("discover_interpreter not testable without _task_vars")

# Generated at 2022-06-10 23:22:16.968987
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # NOTE: this test assumes these interpreter paths will exist for all distributions that we've tested
    # with that we expect to use interpreter discovery.
    #
    # If we're adding support for a major new distro, please add a manual test as well, or a test
    # harness that's able to run on that distro.

    assert discover_interpreter('fake_action', interpreter_name='python',
                                discovery_mode='auto_legacy_silent', task_vars={}) == '/usr/bin/python'
    assert discover_interpreter('fake_action', interpreter_name='python',
                                discovery_mode='auto_legacy', task_vars={}) == '/usr/bin/python'

# Generated at 2022-06-10 23:22:25.710433
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionModule
    class FakeAnsibleModule(AnsibleModule):
        def __init__(self):
            pass

    class FakeActionModule(ActionModule):
        def __init__(self):
            self.connection = FakeAnsibleModule()
            self._low_level_execute_command = self.connection._low_level_execute_command

    class FakeConnection(object):
        def __init__(self):
            self.has_pipelining = True

    # FUTURE: need to parameterize discovery mode in test
    discovery_mode = 'auto'

    # test run_once
    host = 'test_host'

# Generated at 2022-06-10 23:22:28.572560
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action', 'python', 'auto_legacy_silent',
                                {'inventory_hostname': 'unknown', 'config': {}}) == u'/usr/bin/python'