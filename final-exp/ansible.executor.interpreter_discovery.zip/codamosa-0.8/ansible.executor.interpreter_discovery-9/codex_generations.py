

# Generated at 2022-06-10 23:12:48.416954
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery
    reload(ansible.executor.discovery)

    # Empty interpreter map
    task_vars = {'ansible_python_interpreter': ''}
    try:
        ansible.executor.discovery.discover_interpreter(None, 'python', 'auto', task_vars)
        assert False, 'Should not be able to discover interpreter with no interpreter map'
    except Exception as e:
        assert to_native(e) == "No value was found for 'ansible_python_interpreter' in " \
                               "INI config, environment or interpreter_python_distro_map"

    # No interpreter maps for distribution

# Generated at 2022-06-10 23:12:59.432081
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.normal import ActionModule

    class FakeModule(object):
        def __init__(self, interpreter_name, task_vars):
            self.default_interpreter_name = interpreter_name
            self.default_interpreter_discovery_mode = 'auto_legacy'
            self.task_vars = task_vars
            self.interpreter = None
            self.discovery_warnings = []

        def get_interpreter(self):
            self.interpreter = discover_interpreter(self, self.default_interpreter_name,
                                                    self.default_interpreter_discovery_mode, self.task_vars)

# Generated at 2022-06-10 23:13:10.359670
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ..plugins.action.script import ActionModule as script


# Generated at 2022-06-10 23:13:24.329465
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.module_common import task_vars_ansible_tower
    from ansible.playbook.play_context import PlayContext

    task_vars = task_vars_ansible_tower  # use some default ansible vars
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    play_context = PlayContext()
    play_context.connection = 'local'
    action = dict(action='setup')
    res = discover_interpreter(action, 'python', 'auto_legacy', task_vars)
    assert res == '/usr/bin/python'  # fallback to system default


# Generated at 2022-06-10 23:13:27.141296
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action', 'python',
                                'auto', {'inventory_hostname': 'unknown'}) == u'/usr/bin/python'

# Generated at 2022-06-10 23:13:40.080734
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class FakeActionModule:
        # Pretend to be a low level execute module for _low_level_execute_command
        def __init__(self, display):
            self._display = display

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            if cmd == 'uname -a':
                return ('Linux', None)
            elif cmd == "command -v 'python'":
                return ('/usr/bin/python', None)

# Generated at 2022-06-10 23:13:52.852246
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.action_iterator import ActionIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.playbook_executor import handler_loader
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-10 23:14:04.932953
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import tempfile
    import os
    import shutil

    class Action(object):
        def __init__(self):
            self._connection = None
            self._shell = None
            self._low_level_execute_command = None
            self._discovery_warnings = []

        def set_connection(self, connection):
            self._connection = connection

        def set_shell(self, shell):
            self._shell = shell

        def set_low_level_execute_command(self, low_level_execute_command):
            self._low_level_execute_command = low_level_execute_command

        def get_discovery_warnings(self):
            return self._discovery_warnings

    class Connection(object):
        def __init__(self, has_pipelining=False):
            self.has_p

# Generated at 2022-06-10 23:14:06.669604
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(object, 'python', 'auto', {}) == '/usr/bin/python'  # should raise notimplemented

# Generated at 2022-06-10 23:14:19.030371
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test the case where the platform is an unsupported one
    action = ""
    interpreter_name = "python"
    discovery_mode = "silent"
    task_vars = dict()

    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except NotImplementedError as nie:
        assert nie.args[0] == 'unsupported platform for extended discovery: unknown'

    # Test the case where the platform is none
    platform_dist_result = []
    osrelease_content = b''

    task_vars = dict()
    action = ""
    interpreter_name = "python"
    discovery_mode = "silent"
    platform_info = dict(platform_dist_result=platform_dist_result, osrelease_content=osrelease_content)

   

# Generated at 2022-06-10 23:14:39.127788
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class MockHost:
        name = 'testhost'
        vars = {}
        port = 22
        has_pipelining = True

        def get_vars(self):
            return self.vars

        def get_name(self):
            return self.name

        def __getstate__(self):
            return self.__dict__

        def __setstate__(self, d):
            self.__dict__.update(d)

    class MockModule:
        pass

    class MockTask:
        pass


# Generated at 2022-06-10 23:14:39.882689
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:14:41.264237
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement unit test for function discover_interpreter
    pass

# Generated at 2022-06-10 23:14:43.298223
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'

# Generated at 2022-06-10 23:14:50.758845
# Unit test for function discover_interpreter
def test_discover_interpreter():
    bootstrap_python_list = [u'/usr/bin/python', u'/usr/bin/python2.7']
    platform_python_map = {'ubuntu': {'16.04': u'/usr/bin/python3.5', '18.04': u'/usr/bin/python3.6'},
                           'suse': {'15': u'/usr/bin/python3.6', '12': u'/usr/bin/python2.7'}}
    task_vars = {'inventory_hostname': 'foo',
                 'config': {'INTERPRETER_PYTHON_DISTRO_MAP': platform_python_map,
                            'INTERPRETER_PYTHON_FALLBACK': bootstrap_python_list}}


# Generated at 2022-06-10 23:15:01.772623
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    res = {
        'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python2.4\n/usr/bin/python2.7\n/usr/bin/python3.5\nENDFOUND',
        'stderr': u'',
        'rc': 0,
        'start': u'2017-03-07 20:35:01.785549',
        'end': u'2017-03-07 20:35:01.814904',
        'delta': u'0:00:00.029355',
        'cmd': None,
    }

# Generated at 2022-06-10 23:15:12.081446
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    python_target_py = pkgutil.get_data('ansible.executor.discovery', 'python_target.py')
    python_target_py_os_release = pkgutil.get_data('ansible.executor.discovery', 'python_target_os_release.py')
    platform_python_map = C.config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP')
    bootstrap_python_list = C.config.get_config_value('INTERPRETER_PYTHON_FALLBACK')
    res = dict()

    # discover python on a centos 7.0 host

# Generated at 2022-06-10 23:15:19.366039
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TestAction(object):
        def __init__(self):
            self._connection = None
            self._discovery_warnings = []
            self._low_level_execute_command = None

    action = TestAction()

    # Test successful discovery
    def _low_level_execute_command(cmd=None, sudoable=True, in_data=None):
        stdout = 'PLATFORM\r\nLinux\r\nFOUND\r\n/usr/bin/python\r\nENDFOUND'
        return {'stdout': stdout}
    action._low_level_execute_command = _low_level_execute_command
    action._connection = object()
    discovered_interpreter = discover_interpreter(action, 'python', 'auto', {})

# Generated at 2022-06-10 23:15:24.866326
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:15:33.182973
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery
    # Get version_map and bootstrap_python_list from ansible.executor.discovery for testing
    version_map = ansible.executor.discovery.VERSION_MAP
    bootstrap_python_list = ansible.executor.discovery.BOOTSTRAP_PYTHON_FALLBACK
    action = FakeAction()  # Fake Action class for testing
    task_vars = dict()
    task_vars['ansible_python_interpreter'] = ansible.executor.discovery.DEFAULT_PYTHON_INTERPRETER
    # Test case for LinuxDistribution._parse_os_release_content

# Generated at 2022-06-10 23:15:43.633495
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: create unit test
    pass

# Generated at 2022-06-10 23:15:53.849261
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection

    # Needed for interpreter discovery to work
    assert 'ANSIBLE_STRICT_TASK_EXECUTION' in C.config.defaults
    C.config.defaults['ANSIBLE_STRICT_TASK_EXECUTION'] = False

    test_task_vars = {
        'inventory_hostname': '',
    }

    class MockConnection(Connection):
        def __init__(self, *args, **kwargs):
            super(MockConnection, self).__init__(*args, **kwargs)


# Generated at 2022-06-10 23:16:05.492838
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    action = ActionBase._shared_loader_obj

    # Fake a task vars
    task_vars = dict()
    # Just make sure there is no weird caching
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'

    # Discover where python is
    task_vars['ansible_python_interpreter'] = discover_interpreter(action, 'python', 'auto', task_vars)
    # In a sane system this should be /usr/bin/python
    assert task_vars['ansible_python_interpreter'] == '/usr/bin/python'

    # Make sure we still have the same interpreter

# Generated at 2022-06-10 23:16:16.801606
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.action_factory import ActionFactory
    from ansible.plugins.action.normal import ActionModule

    class TestActionModule(ActionModule):

        def _low_level_execute_command(self, cmd, in_data, sudoable):
            return dict(cmd=cmd, in_data=in_data, sudoable=sudoable)

        def _execute_module(self, *args, **kwargs):
            return dict(args=args, kwargs=kwargs)

    def _get_variables_from_task(task_vars):
        return dict()

    class TestActionFactory(ActionFactory):
        def get(self, name, *args, **kwargs):
            return TestActionModule(*args, **kwargs)

    task_

# Generated at 2022-06-10 23:16:29.563693
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class MockDisplay():
        def __call__(self, *args, **kwargs):
            return None

        def info(self, *args, **kwargs):
            return None

        def debug(self, *args, **kwargs):
            return None

        def warning(self, *args, **kwargs):
            return None

        def vvv(self, *args, **kwargs):
            return None

    display = MockDisplay()

    # test uname -m
    class MockAction():

        def __init__(self, host):
            self._connection = MockConnection(host)
            self.task_vars = {}
            self._discovery_warnings = []


# Generated at 2022-06-10 23:16:33.033922
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter = discover_interpreter(None, 'python', 'auto_legacy_silent', {'inventory_hostname': 'localhost'})
    assert interpreter == '/usr/bin/python'

# Generated at 2022-06-10 23:16:45.160449
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import shutil
    import tempfile
    import os
    import sys

    # This test is limited to the default set of interpreters in config, since we are
    # loading this module from a zip file and can't import it to directly obtain the
    # config values.
    bootstrap_python_list = [
        "/usr/bin/python",
        "/usr/bin/python3",
    ]

    platform_python_map = {
        'debian': {
            '8': '/usr/bin/python',
            '9': '/usr/bin/python3',
        },
        'redhat': {
            '7': '/usr/bin/python',
            '8': '/usr/bin/python3',
        },
    }
    # mock out the action context

# Generated at 2022-06-10 23:16:46.846571
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FIXME: mock the _low_level_execute_command call
    pass

# Generated at 2022-06-10 23:16:58.722531
# Unit test for function discover_interpreter
def test_discover_interpreter():

    try:
        config_dict = {
            'INTERPRETER_PYTHON_DISTRO_MAP': {
                'ubuntu': {
                    '14.04': '/usr/bin/python2.7',
                    '18.04': '/usr/bin/python3.6'
                },
                'debian': {
                    '7': '/usr/bin/python2.7',
                    '9': '/usr/bin/python3.5'
                }
            },
            'INTERPRETER_PYTHON_FALLBACK': [
                '/usr/bin/python',
                '/usr/bin/python2.7',
                '/usr/bin/python3.6'
            ]
        }
    except KeyError:
        print("Error reading config file")
        return
    action = None

# Generated at 2022-06-10 23:17:07.805830
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import get_interpreter_discovery_info
    from ansible.plugins.action.script import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager

    def _good_popen_mock(self, *args, **kwargs):
        fake = dict(stdout='')

# Generated at 2022-06-10 23:17:33.693524
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import re
    from ansible.module_utils.basic import AnsibleModule
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.six.moves import StringIO

    def _get_fake_module(task_vars={}):
        fake_module = AnsibleModule(
            argument_spec=dict(
                interpreter=dict(required=True, type='str'),
                discovery_mode=dict(required=True, type='str'),
                test_platform=dict(required=True, type='str'),
            ),
            supports_check_mode=True
        )

        task_vars_stream = StringIO()
        to_text = lambda s: s if isinstance(s, unicode) else s.decode('utf-8')

# Generated at 2022-06-10 23:17:35.808811
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """ no-op function used to trigger loading of discover_interpreter
        for unit testing.
    """
    pass

# Generated at 2022-06-10 23:17:49.832420
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class EasyModule:
        def __init__(self):
            self.module_name = ""
            self._warnings = []
            self.data = {}
            self.params = {}
            self.fail_json = False
            self.fail_json_msg = None
            self.no_log = False
            self._ansible_verbosity = 0
            self._ansible_debug = True
            self.deprecate = False

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == 'python -c "import json; import platform; print(json.dumps(dict(osrelease_content=open(\'/etc/os-release\').read(), platform_dist_result=platform.dist())))"':
                res = dict()

# Generated at 2022-06-10 23:17:54.521028
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = {}

    print(discover_interpreter(action, interpreter_name, discovery_mode, task_vars))


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-10 23:18:08.818986
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test discovery on an unsupported platform type
    host = 'test-host'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = {'ansible_discovery_interpreter_warnings': []}

    # Note: the 'action' parameter is a mock object
    action = type('obj', (object,), {'_connection': type('obj', (object,), {'has_pipelining': True})(),
                                     '_low_level_execute_command': (lambda *a, **kw: {'stdout': u'PLATFORM\nUnsupported\nFOUND\nENDFOUND'}),
                                     '_discovery_warnings': task_vars['ansible_discovery_interpreter_warnings']})()


# Generated at 2022-06-10 23:18:18.945121
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import json
    from ansible.plugins.action.raw import ActionModule as RawAction
    from ansible.plugins.loader import action_loader, fragment_loader
    from ansible.compat.tests import unittest

    # TODO: mock these out properly
    def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
        if 'uname' in cmd:
            # supports -a and -s
            return dict(rc=0, stdout=u'Linux')
        if 'command -v' in cmd:
            return dict(rc=0, stdout=u'/usr/bin/python')
        if 'python_target.py' in cmd:
            # TODO: add some platform.dist()-compatible return cases
            python_dir = os.path.dirname

# Generated at 2022-06-10 23:18:21.104881
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Code of test_discover_interpreter is moved to test/units/module_utils/test_interpreter.py
    pass

# Generated at 2022-06-10 23:18:34.417312
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    import unittest
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.executor.discovery

    # get the path of this file.
    current_path = __file__

    # find the path of the test directory
    test_directory = os.path.join(os.path.dirname(current_path), 'fixtures', 'python_interpreter_discovery')

    def _get_method_name(i):
        return sys._getframe(i).f_code.co_name


# Generated at 2022-06-10 23:18:46.613695
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.module_utils.facts import module_facts_vars
    from ansible.playbook import PlayContext
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):

        SKIP_LOCKDOWN = True

        def __init__(self, *args, **kwargs):
            self._display = Display()
            self._discovery_warnings = []

            super(TestAction, self).__init__(*args, **kwargs)

        def _execute_module(self, result, tmp=None, task_vars=None, wrap_async=False, **kwargs):
            return result


# Generated at 2022-06-10 23:18:57.941056
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    class TestModuleAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return {}

    test_action = TestModuleAction(self._task, self._connection, self._play_context, self._loader, self._templar, self._shared_loader_obj)

    # test with a bad interpreter name
    with pytest.raises(ValueError):
        discover_interpreter(test_action, interpreter_name='bogus', discovery_mode='auto', task_vars={})

    # test with a bad discovery mode
    with pytest.raises(InterpreterDiscoveryRequiredError):
        discover_interpreter(test_action, interpreter_name='python', discovery_mode='bogus', task_vars={})

# Generated at 2022-06-10 23:19:39.431028
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    task_vars = {}
    distro_version_map = {
        u'centos': {u'7': u'/usr/bin/python'},
        u'rhel': {u'7': u'/usr/libexec/platform-python'},
        u'sles': {u'12': u'/usr/lib/python2.7/site-packages'}
    }
    task_vars['ansible_distribution'] = 'CentOS'
    task_vars['ansible_distribution_version'] = '7'

    interpreter_name = 'python'
    discovery_mode = 'auto'
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert result == '/usr/bin/python'

# Generated at 2022-06-10 23:19:47.015736
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.discovery import ActionModule as discovery_action
    from ansible.plugins.action.setup import ActionModule as setup_action

    discovery_action.get_versioned_doclink = lambda x: 'http://ansible.com/test'
    setup_action.get_versioned_doclink = lambda x: 'http://ansible.com/test'


# Generated at 2022-06-10 23:19:58.837019
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # We are going to do a "real" discovery run, but intercept the actual shell call and feed it a canned reply
    # This is not ideal, but it's going to be a lot easier than mocking the entire connection stack
    import ansible.executor.task_executor
    import ansible.plugins.action


# Generated at 2022-06-10 23:20:12.951590
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.distro import _test_file_data

    _test_file_data.update({
        '/etc/os-release': 'NAME="Fedora"\nID=fedora\nVERSION_ID=27\nVARIANT="Server Edition"\nVARIANT_ID=server\n'
    })

    # test against full centos 7 mapping
    with open('packaging/action/centos-version-map.json') as f:
        centos_version_map = json.load(f)


# Generated at 2022-06-10 23:20:23.130946
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common._collections_compat import Mapping

    assert isinstance(discover_interpreter(None, 'python', 'auto', {}), str)
    assert isinstance(discover_interpreter(None, 'python', 'auto', {'inventory_hostname': 'localhost'}), str)
    assert isinstance(discover_interpreter(None, 'python', 'auto', {'inventory_hostname': 'localhost', 'FOUND': u'/usr/bin/python'}), str)
    assert isinstance(discover_interpreter(None, 'python', 'auto', {'inventory_hostname': 'localhost', 'PLATFORM': u'LINUX', 'FOUND': u'/usr/bin/python'}), str)

    # "linux" is a valid platform type, but we don't

# Generated at 2022-06-10 23:20:34.476684
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.executor.task_result import TaskResult
    from ansible.mock import MagicMock
    from ansible.plugins.action import ActionBase

    # create mocks for ActionBase.execute_module, etc.
    def do_mod():
        if do_mod.called:
            raise Exception('ActionBase.execute_module called multiple times')
        else:
            do_mod.called = True
        return dict(
            failed=False,
            stdout=json.dumps(result_data),
            stderr="",
        )
    do_mod.called = False

    def do_cmd():
        if do_cmd.called:
            raise Exception('ActionBase.run_command called multiple times')

# Generated at 2022-06-10 23:20:42.679717
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Results(object):
        class Ok(object):
            stderr = ''
            rc = 0
            stdout = ''

        class Bad(object):
            stderr = ''
            rc = 1
            stdout = ''

        def __init__(self):
            self.next = self.Ok()

        def __call__(self, *args, **kwargs):
            res = self.next
            self.next = self.Bad()
            return res

    global display, foundre

    def pl_dist(parameter_list):
        if parameter_list[0].get('platform') == 'linux':
            parameter_list[0]['platform_dist_result'] = parameter_list[0].get('_linux_distro_result')
        else:
            raise NotImplementedError


# Generated at 2022-06-10 23:20:55.352061
# Unit test for function discover_interpreter
def test_discover_interpreter():

    import tempfile
    import os
    import shutil
    import sys
    from ansible.module_utils.six import PY3

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems

    from ansible.errors import AnsibleAction, AnsibleActionFail, AnsibleRunnerAssertionFailure
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-10 23:21:06.566860
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter

    # Invalid interpreter
    try:
        discover_interpreter(None, "perl", "auto", None)
    except ValueError as e:
        assert to_native(e) == "Interpreter discovery not supported for perl"

    # Old Debian
    platform_info = {
        'platform_dist_result': ['debian', '8.0', None],
        'osrelease_content': ''
    }
    result = discover_interpreter(None, "python", "auto", {'_python_interpreter_discovery_result': platform_info})
    assert result == "/usr/bin/python"

    # New Debian

# Generated at 2022-06-10 23:21:19.246413
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule
    from ansible.plugins.connection.network_cli import Connection as NetworkCliConnection
    from ansible.executor.task_queue_manager import TaskQueueManager

    display = Display()
    display.verbosity = 4

    # this should discover only one python, which should be our fallback
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'

    # this should discover python3, which should be our fallback
    assert discover_interpreter(None, 'python3', 'auto_legacy_silent', {}) == '/usr/bin/python3'

    # create the module
    name_of_temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-10 23:22:02.487203
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Test with various interpreter discovery modes, assuming a GNU/Linux target with /bin/python2.7,
    /usr/bin/python3.5, and /usr/bin/python3.6 available, and Python 2.7.14 installed.
    """

# Generated at 2022-06-10 23:22:14.280083
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import tempfile
    import shutil
    import os

    def create_mock_file_content(filename, content):
        tf = tempfile.NamedTemporaryFile(delete=False)
        tf.write(content.encode('utf-8'))
        tf.close()

        old_path = os.path.join(mocked_env['mock_dir'], filename)
        shutil.move(tf.name, old_path)
        return old_path

    # We're going to mimic C.config.get_config_value here, by setting values in a module namespace that we pass
    # in as the config_context arg to discovery calls.
    class mocked_config_module(object):
        pass


# Generated at 2022-06-10 23:22:23.602928
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Mock helpers
    class FakeAction:
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, args, sudoable=False, in_data=None):
            return {'stdout': args, 'stderr': u''}

    class FakeSetting:
        def get_config_value(self, key, variables=None):
            if key == 'INTERPRETER_PYTHON_DISTRO_MAP':
                return {'alpine': {'3.6': '/usr/bin/python3.6', '3.7': '/usr/bin/python3.7'}}

# Generated at 2022-06-10 23:22:24.514181
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: proper unit tests
    pass