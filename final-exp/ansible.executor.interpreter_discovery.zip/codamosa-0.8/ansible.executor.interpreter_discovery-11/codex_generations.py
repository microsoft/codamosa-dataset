

# Generated at 2022-06-10 23:12:51.638696
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    import shutil

    d = tempfile.mkdtemp()

# Generated at 2022-06-10 23:12:54.657483
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """Unit test for discover_interpreter"""
    from ansible.plugins.action import ActionBase
    action = ActionBase()
    # interpreter = discover_interpreter(action, 'python', 'auto_legacy', )

# Generated at 2022-06-10 23:13:05.960538
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    This test is used to verify the following behaviors of the
    discover_interpreter function in the interpreter_discovery module:

    1. Verify that if the interpreter name is not python, an exception is
       raised.
    2. Verify that if the interpreter name is python and the host's platform is
       neither linux nor windows (or it cannot be determined), an exception is
       raised.
    3. Verify that if the interpreter name is python and the host's platform is
       linux, that the function returns the appropriate platform interpreter
       corresponding to the host's Linux distribution.
    4. Verify that if the interpreter name is python and the host's platform is
       linux, that the function returns /usr/bin/python if no platform
       interpreter is found for the host's distribution.
    """
    # Mock action object

# Generated at 2022-06-10 23:13:15.499689
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_host = 'host-01'
    task_vars = dict()

    # test: no valid python
    python_data_1_in = "PLATFORM\ndarwin\nFOUND\n/bin/python\nENDFOUND\n"
    shell_bootstrap_1_out = "command -v 'python'"
    python_data_2_in = '{"platform_dist_result": ["Darwin", "15.5.0", "Darwin Kernel Version 15.5.0: Tue Apr 19 18:36:36 PDT 2016; root:xnu-3248.50.21~8/RELEASE_X86_64"]}\n'
    shell_bootstrap_2_out = "/usr/bin/python"

# Generated at 2022-06-10 23:13:22.247280
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {
        'ansible_distribution_version': '8.0',
        'ansible_distribution': 'OracleLinux',
    }

    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert result == '/usr/bin/python2'



# Generated at 2022-06-10 23:13:32.434001
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest

    # Case: successful python discovery
    def test_discover_interpreter_good(self):
        ansible_discovery = {'hostvars': {}}
        action = self.create_action_mock(ansible_discovery)
        interpreter_name = 'python'
        discovery_mode = 'auto'
        task_vars = {}

        self.assertEqual(u'/usr/bin/python', discover_interpreter(action, interpreter_name, discovery_mode, task_vars))

    # Case: no python interpreters found
    def test_discover_interpreter_none(self):
        ansible_discovery = {'hostvars': {}}
        action = self.create_action_mock(ansible_discovery)
        interpreter_name = 'python'
       

# Generated at 2022-06-10 23:13:44.894273
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader

    vm = VariableManager()
    loader = DataLoader()
    task = Task()
    task.action = 'test_discover_interpreter'

    # Configure value for config INTERPRETER_PYTHON_DISTRO_MAP

# Generated at 2022-06-10 23:13:56.353592
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pprint
    import pytest

    test_action = object()
    # TODO: move this to a fixture so we don't build the whole object on each test (the plugin was the first
    # one I picked, but this should come from outside the impl once we unify more of the interpreter discovery
    # code)
    test_action._connection = pytest.importorskip('ansible.plugins.connection.ssh').Connection(play_context=None)
    # TODO: same for this
    test_action._discovery_warnings = []

    task_vars = dict()
    task_vars['ansible_python_interpreter'] = None


# Generated at 2022-06-10 23:14:08.917724
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print('Testing')

# Generated at 2022-06-10 23:14:20.201877
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    class VarsModule:
        def vars(self, args):
            return dict(interpreter_python_fallback=['/usr/bin/python2.6', '/usr/bin/python2.7'])

    class TestModuleArgs:
        def __init__(self, args):
            self.module_args = args


# Generated at 2022-06-10 23:14:39.781595
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.task_result

    tres = ansible.executor.task_result.TaskResult(host='host1')
    tres._host.set_variable('ansible_python_interpreter', '/usr/bin/python')

    # test the 2-letter suffix mode (subset of supported Linux distributions)
    tres.set_task_var('ansible_os_family', 'RedHat')
    tres.set_task_var('ansible_distribution', 'Fedora')
    tres.set_task_var('ansible_distribution_version', '27')

    assert to_native(discover_interpreter(tres, 'python', 'auto', tres.get_task_vars())) == '/usr/bin/python2.7'

    tres.set_task_var

# Generated at 2022-06-10 23:14:48.448457
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.basic import AnsibleModuleTestCase

    class TestModule(AnsibleModuleTestCase):
        def test_discover(self):
            module = AnsibleModule(
                argument_spec={},
            )

            # create a fake connection object
            connection = Connection()

            module._connection = connection

            # create fake task_vars
            module.task_vars = {}

            ansible_python_interpreter = discover_interpreter(module, 'python', 'auto', module.task_vars)
            self.assertIsNotNone(ansible_python_interpreter)

    test_case = TestModule()
    test_case.run()

# Generated at 2022-06-10 23:14:59.473306
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from six import PY3
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    action = AnsibleUnsafeText("FUTURE")
    interpreter_name = 'python2'
    discovery_mode = 'auto'
    task_vars = {
        'inventory_hostname': 'localhost',
        'connection': 'local',
        'ansible_env': {
            'LANG': 'en_US.UTF-8'
        },
        'ansible_python_interpreter': "/usr/bin/python",
        'ansible_python_version': {
            'major': 3,
            'minor': 8,
            'micro': 0,
            'releaselevel': 'final',
            'serial': 0
        }
    }

# Generated at 2022-06-10 23:15:10.713335
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Simulate the ansible_python_interpreter value being set in the task_vars dict
    # (This would normally be done by the host_vars lookup and the host fact cache)
    task_vars = dict(ansible_python_interpreter='/usr/bin/python')

    # Test auto_legacy mode discovery
    auto_legacy_result = discover_interpreter(None, 'python', 'auto_legacy', task_vars)
    assert auto_legacy_result == '/usr/bin/python'

    # Test auto mode discovery
    auto_result = discover_interpreter(None, 'python', 'auto', task_vars)
    assert auto_result == '/usr/bin/python'

    # Test auto_silent mode discovery

# Generated at 2022-06-10 23:15:12.301861
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # get_python_interpreter and test_platform_python_map_exact_match
    print("test_discover_interpreter running ...")


# Generated at 2022-06-10 23:15:19.388434
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    class FakeActionModule(ActionBase):
        def __init__(self):
            super(FakeActionModule, self).__init__()

    python_interpreters = ['/usr/bin/python', '/usr/bin/python3', '/usr/bin/python2', '/usr/local/bin/python2']

    # test simple path returns
    for python_interpreter in python_interpreters:
        test_results = discover_interpreter(FakeActionModule(), 'python', 'auto', {'python_interpreter': python_interpreter})
        assert test_results == python_interpreter

    # test error returns

# Generated at 2022-06-10 23:15:24.889813
# Unit test for function discover_interpreter
def test_discover_interpreter():
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../'))
    from ansible.module_utils.connection import Connection
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.six import b
    from ansible.module_utils.six.moves import StringIO

    from ansible.playbook.task import Task

    from ansible.executor.discovery import InterpreterDiscoveryRequiredError, discover_interpreter
    from ansible.executor.clean import strip_ansi

    class FakeAction(object):
        _discovery_warnings = []

        def __init__(self, _connection, _host, module_vars=None, warn=False):
            self._connection = _connection
            self._host = _host

# Generated at 2022-06-10 23:15:34.393053
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unit.utils.unittest as unittest
    import mock

    class MockAction(object):
        def __init__(self):
            self._connection = mock.MagicMock()
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            return {}


# Generated at 2022-06-10 23:15:46.368801
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar

    # init required objects
    play_context = PlayContext()
    templar = Templar(loader=None, variables={})
    templar.set_available_variables(play_context.serialize())
    action = ActionBase(play_context, templar, loader=None)

    # test python discovery without pipelining
    action._connection = MockConnection(has_pipelining=False)
    play_context.become = mock_become
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.connection = 'test'

    # test unknown

# Generated at 2022-06-10 23:15:55.650375
# Unit test for function discover_interpreter
def test_discover_interpreter():
    def _get_version_map(data):
        '''
        Helper method to return version map from test data.

        We can't simply reference find_looseversion in the main method because
        if we do that then we'll need to run the whole method instead of this
        specific test method, which we don't want to do.
        '''
        return data['linux_data']['version_map']

    def test_version_fuzzy_match(version, version_map):
        '''
        Helper method to test version_fuzzy_match.

        We can't simply reference find_looseversion in the main method because
        if we do that then we'll need to run the whole method instead of this
        specific test method, which we don't want to do.
        '''

# Generated at 2022-06-10 23:16:20.948228
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class FakeActionModule(object):
        def __init__(self):
            self._low_level_execute_command_success_map = {}
            self._low_level_execute_command_response_map = {}
            self.display = Display()
            self._discovery_warnings = []
            self._connection = FakeConnection()

        def _low_level_execute_command(self, command, sudoable=True, in_data=None):
            if command in self._low_level_execute_command_success_map:
                success = self._low_level_execute_command_success_map.get(command)
            else:
                success = True

            if command in self._low_level_execute_command_response_map:
                res = self._low_level_execute_command_response_map.get(command)
           

# Generated at 2022-06-10 23:16:34.242409
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:16:46.568771
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule as script

    scripted_action = script(
        task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None
    )

    test_task_vars = {
        "inventory_hostname": "localhost",
    }

    # Test parameters
    a = "python"
    b = "auto"
    c = "auto_silent"
    d = "auto_legacy"
    e = "auto_legacy_silent"

    # Test cases

# Generated at 2022-06-10 23:16:58.413415
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: should be handled more cleanly
    try:
        C.config.load_config_file()
    except TypeError:
        pass

    action = None

    # TODO: no good way to override the "auto_legacy" case yet, so the rest of the test is skipped if it can't be set
    try:
        C.config.load_config_file(overrides={'interpreter_python_discovery_mode': 'auto_silent'})
    except TypeError:
        return

    try:
        r = discover_interpreter(action, 'python', 'auto', {})
    except InterpreterDiscoveryRequiredError as e:
        assert e.interpreter_name == 'python'
        assert e.discovery_mode == 'auto'

# Generated at 2022-06-10 23:17:07.615870
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    hosts = [Host(name='127.0.0.1', port=22)]
    inventory = InventoryManager(loader=loader, sources='')

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {}

# Generated at 2022-06-10 23:17:11.676753
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # import the plugin
    from ansible.plugins.action.interpreter_discovery import ActionModule as interpreter_discovery

    # create an instance
    i = interpreter_discovery(
        task=None,
        connection=None,
        _play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = dict()

    discover_interpreter(i, interpreter_name, discovery_mode, task_vars)



# Generated at 2022-06-10 23:17:23.224119
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.distro import Distro

    platform_python_map = {
        'redhat': {
            '7.4': '/usr/bin/python2.7',
            '7.6': '/usr/bin/python2.7',
            '8': '/usr/bin/python3'
        },
        'centos': {
            '7.4.1708': '/usr/bin/python2.7',
            '7.6.1810': '/usr/bin/python2.7',
            '8.0': '/usr/bin/python3'
        }
    }
    bootstrap_python_list = ['/usr/bin/python', '/usr/bin/python2.7', '/usr/bin/python3']

# Generated at 2022-06-10 23:17:33.281253
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_interp_name = 'python'
    test_discovery_mode = 'auto_legacy'

# Generated at 2022-06-10 23:17:44.777426
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object()
    action.task = object()
    action.task.args = {}
    action.task.args.get = lambda x: None
    action._connection = object()
    action._connection.has_pipelining = True
    action._low_level_execute_command = lambda x, y: {'stdout': x}
    action._discovery_warnings = []
    task_vars = {
        'ansible_python_interpreter': '/usr/bin/python2.6',
        'ansible_python_interpreter2': '/usr/bin/python2.7',
        'ansible_python_interpreter3': '/usr/bin/python3.0',
        'ansible_python_interpreter4': '/usr/bin/python3.2',
    }
    # test mismatch

# Generated at 2022-06-10 23:17:55.864768
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader

    # All the required objects to execute a Task

# Generated at 2022-06-10 23:18:38.293611
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars

    class TestAction(ActionBase):
        TRANSFERS_FILES = False

        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(TestAction, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self._connection = connection
            self._loader = loader
            self._task = task
            self._play_context = play_context
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj
            self._discovery_warnings = []


# Generated at 2022-06-10 23:18:49.644394
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys, os
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'plugins', 'action')))
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'plugins', 'action', 'lib')))
    import action as _action

    class ActionModule(_action.ActionModule):
        pass

    module_loader = ''
    tmpdir = '/tmp/ansible-test'

    # Execute interpreter discovery test case
    if not os.path.exists(tmpdir):
        os.makedirs(tmpdir)
    action = ActionModule(module_loader, {}, tmpdir, '', '', '', task_vars={})
   

# Generated at 2022-06-10 23:18:59.246522
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Unit test for both bootstrap and extended discovery
    action = object()
    action._connection = object()
    action._connection.has_pipelining = True
    action._low_level_execute_command = object()

# Generated at 2022-06-10 23:19:11.137260
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.task_result
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.action_factory import ActionFactory
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    display.verbosity = 5
    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-10 23:19:19.378746
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.normal import ActionModule
    from ansible.executor.task_result import TaskResult

    action = ActionModule(task_results=TaskResult(), task_executor='dummy', task_vars=ImmutableDict(), task_args=ImmutableDict(), loader=None, templar=None, shared_loader_obj=None)
    assert discover_interpreter(action, 'python', 'smart', ImmutableDict({'inventory_hostname': 'local'})) == '/usr/bin/python'

# Generated at 2022-06-10 23:19:29.847256
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task

    task_vars = dict()

    # Set up fake group_vars for test
    group_vars = task_vars.setdefault('group_vars', dict())
    group_vars['all'] = dict()

    # Set up fake config data
    config = group_vars['all'].setdefault(C.CONFIG_KEY, dict())

    # Set up fake interpreter discovery data

# Generated at 2022-06-10 23:19:41.662401
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    # load the inventory
    inv = InventoryManager(C.DEFAULT_HOST_LIST)
    # load the play
    file = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'support', 'test_play.json')
    with open(file, 'rb') as f:
        test_play = json.load(f)
    # load the connection
    connection = MockConnection()
    # build the task queue manager

# Generated at 2022-06-10 23:19:55.307166
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.normal import ActionModule as Action
    from ansible.executor.task_result import TaskResult


# Generated at 2022-06-10 23:20:08.696835
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # NOTE: interpreter discovery is an extension to core (it's not part of the PlayContext object), so we have to
    # fake up enough data for it to work
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'inventory_hostname': 'testhost'}
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['/dev/null']))

    play_

# Generated at 2022-06-10 23:20:19.962517
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    from ansible.module_utils.connection import ConnectionBase

    action = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        mutually_exclusive=[],
        required_together=[]
    )

    connection = ConnectionBase(play_context=action._play_context, new_stdin=None)
    action._connection = connection

    # test no bootstrap python found (should be silent)
    action._low_level_execute_command = lambda cmd, sudoable, in_data=None: {'stdout': ''}
    assert discover_interpreter(action, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'


# Generated at 2022-06-10 23:21:37.663509
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', {}) == '/usr/bin/python'

# Generated at 2022-06-10 23:21:51.581975
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Test interpreter_name != Python
    action = MockAction()
    task_vars = dict()
    interpreter_name = 'ruby'
    discovery_mode = 'auto'
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        assert False
    except ValueError:
        assert True

    # Test empty stdout
    action = MockAction()
    task_vars = dict()
    action._low_level_execute_command = MockCommand()
    interpreter_name = 'python'
    discovery_mode = 'auto'
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        assert False
    except ValueError:
        assert True

    # Test uname != linux
    action = MockAction()
    action._

# Generated at 2022-06-10 23:21:58.022455
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    action = ActionBase()
    action._connection = MockConnection()
    action._task = MockTask()
    action._task.action = 'setup'
    action.task_vars = dict(ansible_python_interpreter='/usr/bin/python')

    interpreter = discover_interpreter(action, 'python', 'auto_legacy', action.task_vars)
    assert interpreter == '/usr/bin/python'



# Generated at 2022-06-10 23:22:04.469589
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    task_vars = {}
    assert u'/usr/bin/python' == discover_interpreter(action, 'python', 'auto', task_vars)
    assert u'/usr/bin/python' == discover_interpreter(action, 'python', 'auto_legacy', task_vars)
    assert u'/usr/bin/python' == discover_interpreter(action, 'python', 'auto_silent', task_vars)
    assert u'/usr/bin/python' == discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)
    assert u'/usr/bin/python' == discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)

    assert u'/usr/bin/python' == discover_

# Generated at 2022-06-10 23:22:14.327055
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule as Script

    task_vars = dict()
    script = Script(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    script.set_options(dict())

    # Test centos 8 should use python3
    assert discover_interpreter(script, 'python', 'auto_legacy_silent', task_vars) == '/usr/bin/python3'

    # Test centos 7 should use python2
    assert discover_interpreter(script, 'python', 'auto_legacy_silent', task_vars) == '/usr/bin/python2'

# Generated at 2022-06-10 23:22:20.034032
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook import Playbook

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.loader import find_plugin, action_loader

    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    test_host = Host(name="discovery_test", port=22)
    test_host.set_variable("ansible_connection", "local")
    inventory.add_host(test_host)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)


# Generated at 2022-06-10 23:22:28.105414
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # mocked os_release content
    os_release = """
NAME="Ubuntu"
VERSION="18.04.1 LTS (Bionic Beaver)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 18.04.1 LTS"
VERSION_ID="18.04"
HOME_URL="https://www.ubuntu.com/"
SUPPORT_URL="https://help.ubuntu.com/"
BUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"
PRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"
VERSION_CODENAME=bionic
UBUNTU_CODENAME=bionic
"""

    # mocked platform.dist output