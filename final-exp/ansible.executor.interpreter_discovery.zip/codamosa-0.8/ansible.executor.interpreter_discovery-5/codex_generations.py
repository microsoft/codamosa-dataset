

# Generated at 2022-06-10 23:12:54.032786
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:13:05.422847
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.action.interpreter_discovery
    action_plugin = ansible.plugins.action.interpreter_discovery.ActionModule()
    action_plugin.set_modules_environment({'ANSIBLE_USER': 'test_user'})
    action_plugin.set_task_vars({'inventory_hostname': 'localhost'})

    from ansible.plugins.connection import local
    action_plugin._connection = local.Connection(action_plugin._play_context)

    action_plugin._connection.has_pipelining = True
    action_plugin._connection.set_host_overrides(action_plugin._task.args)

    action_plugin.set_loader()

    # test the function itself, not the ansible plugin
    assert ansible.plugins.action.interpreter_discovery.discover_inter

# Generated at 2022-06-10 23:13:15.062842
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockActionModule(object):
        def __init__(self, *args, **kwargs):
            self._discovery_warnings = []

    class MockConnection(object):
        def __init__(self, has_pipelining=True):
            self.has_pipelining = has_pipelining
            self._shell = MockShell()

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            output = self._shell.run(cmd, in_data=in_data)

            return {
                'stdout': output,
                'stderr': '',
                'rc': 0
            }

        def close(self):
            pass

    class MockShell(object):
        def __init__(self, safe_dict={}):
            self.safe

# Generated at 2022-06-10 23:13:27.814779
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.compat import collections_native_str
    import tempfile
    import shutil
    import os
    import sys


# Generated at 2022-06-10 23:13:31.415627
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = MockAnsibleAction()
    task_vars = {}
    discover_interpreter(action, "python", "auto_legacy_silent", task_vars)



# Generated at 2022-06-10 23:13:44.138927
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FIXME: This test is muck code, need refactoring.
    # Requirement:
    # python -V in localhost should return the correct version
    # python -c "import platform; print(platform.dist())" should return the correct version info
    # python -c "import platform; print(platform.dist())" should return the correct version info (redhat/ol)
    # python -c "import platform; print(platform.dist())" should return the correct version info (suse)
    # python -c "with open('/etc/os-release', 'r') as f: print(f.read())" should return the correct version info

    # init play context for test, only for test
    from ansible.playbook import PlayContext
    from ansible.plugins.loader import action_loader
    context = PlayContext()

# Generated at 2022-06-10 23:13:55.899336
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    import traceback
    import unittest
    import yaml

    class TestEnv(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_interpreter_discovery(self):
            def _load_task_vars(var_file):
                with open(var_file) as v:
                    task_vars = yaml.load(v.read())
                return task_vars

            # Set the CWD to the test/mock directory so the tests will work from within
            # a source checkout or an installed package.
            mock_dir = os.path.join(os.path.dirname(__file__), 'mock')
            os.chdir(mock_dir)

            # load test

# Generated at 2022-06-10 23:14:08.421160
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class MockAction(object):
        def __init__(self):
            self._connection = None
            self._low_level_execute_command = None
            self._cleanup_remote_tmp = None
            self._discovery_warnings = []

    class MockConnection(object):
        def __init__(self):
            self.has_pipelining = True

    class MockHost:
        def __init__(self):
            self.vars = {}

    class MockTask:
        def __init__(self):
            self.host = MockHost()

    action = MockAction()
    action._connection = MockConnection()

    task_vars = {'inventory_hostname': 'localhost'}

    assert discover_interpreter(action, 'python', 'auto', task_vars) == '/usr/bin/python'

# Generated at 2022-06-10 23:14:19.850373
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert _get_linux_distro({'platform_dist_result': []}) == ('', '')
    assert _get_linux_distro({'platform_dist_result': ['a', 'b', 'c']}) == ('a', 'b')

    assert _get_linux_distro({}) == ('', '')
    assert _get_linux_distro({'osrelease_content': 'NAME="CentOS Linux" ID="centos" ID_LIKE="rhel fedora" VERSION_ID="7"'}) == ('centos', '7')
    assert _get_linux_distro({'osrelease_content': 'NAME="CentOS Linux" ID="centos" ID_LIKE="rhel fedora" VERSION_ID="7" VERSION="7 (Core)"'}) == ('centos', '7')
    assert _get

# Generated at 2022-06-10 23:14:32.169153
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # pylint: disable=too-many-locals, too-many-branches, too-many-statements
    from ansible.plugins.action.set_fact import ActionModule as SetFact
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import find_plugin


# Generated at 2022-06-10 23:14:49.922839
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    import ansible.executor.discovery
    with open(ansible.executor.discovery.__file__.replace('pyc', 'py')) as f:
        exec(compile(f.read(), ansible.executor.discovery.__file__, 'exec'), globals())
    module_name = 'raw'  # noqa
    #pylint: disable=undefined-variable
    import ansible.plugins.action
    action_plugin_class = ansible.plugins.action.ActionModule
    action = action_plugin_class(task=None, connection=None, play_context=None, loader=loader, templar=None,
                                 shared_loader_obj=None)


# Generated at 2022-06-10 23:14:53.730425
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test "auto_legacy" discovery mode
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'

    # test "auto" discovery mode
    assert discover_interpreter(None, 'python', 'auto_silent', {}) == '/usr/bin/python'

    # test "strict" discovery mode
    try:
        discover_interpreter(None, 'python', 'strict_silent', {})
        assert False
    except InterpreterDiscoveryRequiredError as ex:
        assert ex.message == 'strict discovery mode requires that Python interpreter discovery be successful'



# Generated at 2022-06-10 23:15:04.553497
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.utils.hashs import md5s

    class TestAction(ActionBase):
        def __init__(self, connection, tmp=None, task_vars=None):
            self._low_level_execute_command = MockExecute()
            self._templar = None
            self._connection = connection
            self._loader = None
            self._tmp = tmp
            self.task_vars = task_vars
            self._shared_loader_obj = None
            self._task = None
            self.load_name = None

        def _get_connection(self):
            return None


# Generated at 2022-06-10 23:15:13.757694
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    class FakePlugin(object):
        interpreter_name = 'python'

        def __init__(self, name, action=None, **kwargs):
            self.name = name
            self.action = action

    class FakeAction(object):
        def __init__(self):
            self.connection = FakeConnection()
            self._play_context = FakePlayContext()
            self._task = FakeTask(action=self)
            self._discovery_warnings = []


# Generated at 2022-06-10 23:15:27.569975
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    action = dict()
    action['_discovery_warnings'] = list()
    action['_low_level_execute_command'] = lambda cmd, sudoable=True, in_data=None: dict()

    try:
        actual = discover_interpreter(action, 'not-python', 'auto', task_vars)
        assert False, to_text(u"Expected exception but got actual: {}".format(actual))
    except ValueError:
        pass

    try:
        actual = discover_interpreter(action, 'python', 'auto', task_vars)
        assert False, to_text(u"Expected exception but got actual: {}".format(actual))
    except NotImplementedError:
        pass


# Generated at 2022-06-10 23:15:41.177643
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.task_result
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.result import ResultProcessor
    from ansible.executor.module_common import _find_needle
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.action.normal import ActionModule as ActionBase

    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            del tmp  # tmp no longer has any effect

            result = super(ActionModule, self).run(task_vars=task_vars)
            self._task.action = 'discover_interpreter'
            self._task.args

# Generated at 2022-06-10 23:15:50.373219
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_pass = True
    for test_case in [
        {'interpreter': 'python', 'discovery_mode': 'auto', 'host': 'localhost'},
        {'interpreter': 'python', 'discovery_mode': 'auto', 'host': 'ubuntu'},
        {'interpreter': 'python', 'discovery_mode': 'auto', 'host': 'rhel'},
        {'interpreter': 'python', 'discovery_mode': 'auto', 'host': 'rhel7'},
    ]:
        try:
            discover_interpreter(None, test_case['interpreter'], test_case['discovery_mode'], test_case['host'])
        except Exception as e:
            test_pass = False
            display.error(msg=to_text(e))
           

# Generated at 2022-06-10 23:15:58.029455
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from unit.mock.loader import DictDataLoader
    from ansible.vars.manager import VarManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsV2
    from ansible.plugins.loader import module_loader, action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy_core import StrategyModuleMixin
    from ansible.executor.process.worker import WorkerProcess
    import ansible.plugins.loader as module_loader
    import ansible

# Generated at 2022-06-10 23:16:02.006381
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.parsing.ajson import AnsibleJSONEncoder
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    import sys
    import os
    import unittest


# Generated at 2022-06-10 23:16:10.842445
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_interpreter_name = 'python'
    test_discovery_mode = 'auto_legacy_silent'
    test_task_vars = {"inventory_hostname": "foo"}
    from ansible.plugins.action.script import ActionModule
    action = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print(discover_interpreter(action, test_interpreter_name, test_discovery_mode, test_task_vars))

# Generated at 2022-06-10 23:16:32.065146
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:16:43.850238
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import _get_linux_distro
    from ansible.module_utils.distro import get_distribution
    import distro

    dist, version, id = get_distribution()

    assert dist == distro.id()
    assert version == distro.version()
    assert id == distro.codename()

    platform_info = {'osrelease_content': 'PRETTY_NAME="Debian GNU/Linux 10 (buster)"\nNAME="Debian GNU/Linux"\nVERSION_ID="10"\nVERSION="10 (buster)"\nID=debian\nHOME_URL="https://www.debian.org/"\nSUPPORT_URL="https://www.debian.org/support"\nBUG_REPORT_URL="https://bugs.debian.org/"'}
    distro,

# Generated at 2022-06-10 23:16:55.621535
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = {
        '_send_timeout': 30,
        '_low_level_execute_command': (lambda *args, **kwargs: {'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python2\nENDFOUND'})
    }
    assert discover_interpreter(action, 'python', 'auto_legacy', {}) == u'/usr/bin/python2'
    assert action['_discovery_warnings'][0] == 'No python interpreters found for host unknown (tried [u\'/usr/bin/python2\', u\'/usr/bin/python3\'])'


# Generated at 2022-06-10 23:17:05.862100
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.strategy.linear import StrategyModule

    display.verbosity = 3
    action_module = ActionModule(
        task=dict(name='action name', action='action name', args=dict()),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    strategy_module = StrategyModule(
        loader=None,
        shared_loader_obj=None,
        strategy='linear',
        variables=dict())
    strategy_module._tqm = None

    task_vars = dict()
    task_vars['inventory_hostname'] = 'test-host'

    # TODO: check the actual output

# Generated at 2022-06-10 23:17:13.631326
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    from ansible.plugins.action.ping import ActionModule
    task_vars = dict()

    action = ActionModule(None, None, basic.AnsibleModule(None, None))
    action._connection = basic.Connection("")
    action._display = Display()

    interpreter = discover_interpreter(action, 'python', 'auto', task_vars)
    assert interpreter == '/usr/bin/python'
    print("discover_interpreter test passed")

# Generated at 2022-06-10 23:17:25.621267
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule

    import collections


# Generated at 2022-06-10 23:17:34.674164
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import ActionModule
    import os
    import sys

    class TActionModule(ActionModule):
        def _execute_module(self, tmp=None, task_vars=None):
            print('in _execute_module')
            print('in _execute_module')
            print('in _execute_module')
            return []

    class TTaskVars:
        def get(self, item, default=None):
            print('in get')
            # print('in get')
            return default

    task_vars = TTaskVars()
    action = TActionModule(connection=None)

    script_path = os.path.dirname(os.path.abspath(__file__))
    script_file = 'get_platform_info.py'
    script_file_path = os

# Generated at 2022-06-10 23:17:48.675014
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'

    test_hosts = ['host_a', 'host_b', 'host_c', 'host_d']

    # Set up fallback interpreters
    discovery_modes = ['auto', 'auto_legacy', 'auto_silent', 'auto_legacy_silent']
    bootstrap_pythons = ['python', 'python3', 'python2']
    fallback_python = bootstrap_pythons[0]
    test_interpreter_fallbacks = []
    for discovery_mode in discovery_modes:
        for bootstrap_python in bootstrap_pythons:
            test_interpreter_fallbacks.append((discovery_mode, bootstrap_python))

    # Set up test hosts
    # Hosts a and b are modern hosts
    # Host c is a legacy

# Generated at 2022-06-10 23:17:49.451477
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:18:03.796792
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.action_factory import ActionModuleFactory
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    class MyActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            super(MyActionModule, self).run(tmp, task_vars)
            if self._task.args.get('fail', False):
                return TaskResult(self._task.args.get('result', True),
                                  msg="oops, action a {0}".format(self._task.args.get('result', '')))

# Generated at 2022-06-10 23:18:37.563638
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock
    import os

    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.distribution.archlinux as archlinux
    import ansible.module_utils.facts.system.distribution.amazon as amazon
    import ansible.module_utils.facts.system.distribution.altlinux as altlinux
    import ansible.module_utils.facts.system.distribution.alt as alt
    import ansible.module_utils.facts.system.distribution.debian as debian
    import ansible.module_utils.facts.system.distribution.freebsd as freebsd
    import ansible.module_utils.facts.system.distribution.mandriva as mandriva

# Generated at 2022-06-10 23:18:41.477518
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import doctest
    suite = doctest.DocTestSuite(discover_interpreter)
    return suite

__all__ = ['discover_interpreter', 'InterpreterDiscoveryRequiredError']

# Generated at 2022-06-10 23:18:46.019040
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Try a happy path
    action = _FauxActionModule()
    res = discover_interpreter(action, 'python', 'auto_legacy', {})
    assert res == '/usr/bin/python'



# Generated at 2022-06-10 23:18:57.665864
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    from ansible.executor.task_result import TaskResult

    sys_result = TaskResult('192.168.1.1', '1', '', '')
    sys_result.stdout = 'PLATFORM\nLinux\nFOUND\n/usr/bin/python2.7\n/usr/bin/python3.4\nENDFOUND'
    sys_result.rc = 0

    class MockedAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = MockCommandConnection()

    class MockCommandConnection(object):
        def has_pipelining(self):
            return True

        def _build_module_command(self, module_name, module_args=None, task_vars=None):
            return 'python'

# Generated at 2022-06-10 23:19:08.531118
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import platform
    # test all of the not implemented error cases
    assert discover_interpreter(None, 'python3', 'auto', None) == '/usr/bin/python3'
    assert discover_interpreter(None, 'python', 'auto', None) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', None) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', None) == '/usr/bin/python'
    # TODO: add tests with an action object (which will require mocking)

# Generated at 2022-06-10 23:19:18.992961
# Unit test for function discover_interpreter
def test_discover_interpreter():
    dist_map = {
        'redhat' : {
            '6.9' : 'python=/usr/bin/python2.7.5',
            '7.0' : 'python=/usr/bin/python2.7.5',
            },
        'fedora' : { '27' : 'python=/usr/bin/python3.6' },
        'ubuntu' : {
            '17.04' : 'python=/usr/bin/python3.6',
            '17.10' : 'python=/usr/bin/python3.6',
            '18.04' : 'python=/usr/bin/python3.6',
            },
        }
    bootstrap_python_list = ['python', '/usr/local/bin/python']

# Generated at 2022-06-10 23:19:19.934115
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass



# Generated at 2022-06-10 23:19:30.521859
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.connection import Connection
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        def __init__(self):
            super(TestAction, self).__init__()
            self._host_data = dict()

        def get_connection(self, play_context, new_stdin, *_, **__):
            connection = Connection(play_context.remote_addr)
            connection.has_pipelining = True
            connection.set_options(direct={'persistent_command_timeout': 60})
            return connection

        def run(self, tmp=None, task_vars=None):
            interpreter_name = 'python'
            discovery_mode = 'auto_legacy_silent'

# Generated at 2022-06-10 23:19:42.167030
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Mock a module action
    class MockAction(object):
        interpreter_discovery_warnings = []
        _connection = {'has_pipelining': True}

        @classmethod
        def _low_level_execute_command(cls, path, sudoable=False, in_data=None):
            platform_result = ''.join(['PLATFORM\n', 'linux\n', 'FOUND\n',
                                       path, '\nENDFOUND'])
            return {'stdout': platform_result}

    action = MockAction()

    # Mock a task_vars dict
    task_vars = {'variables': {'ansible_python_interpreter': '/usr/bin/python'}}

    # Test discover_interpreter with valid inputs

# Generated at 2022-06-10 23:19:55.402945
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        import ansible.plugins.action
    except ImportError:
        raise ImportError("Couldn't find ansible plugins in module path")

    # test: auto_legacy_silent

# Generated at 2022-06-10 23:20:58.251824
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # an ugly hack to get a fake ActionBase and ActionModule for these tests to use
    # TODO: refactor this w/ FakeModule, etc.
    class FauxActionModule():
        def __init__(self, task_vars):
            self._task_vars = task_vars
            self._connection = None
            self.fail_json = False
            self._discovery_warnings = []

        def add_cleanup_file(self, path):
            pass

        def _low_level_execute_command(self, command, sudoable=True, in_data=None, executable='/bin/sh'):
            if command == u'command -v \'python\'':
                return {'stdout': u'/usr/bin/python'}

# Generated at 2022-06-10 23:21:09.317577
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''
    Test for test_discover_interpreter

    :return:
    '''

    # Create an ActionBase object
    action = ActionBase()
    action._connection = Connection('host')
    action._connection.has_pipelining = True

    # Task vars
    task_vars = dict()

    # no traceback
    action._low_level_execute_command = lambda cmd, sudoable, in_data: dict(stdout='PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python2\n/usr/bin/python3\nENDFOUND')
    action._get_platform_version_data = lambda: dict()

# Generated at 2022-06-10 23:21:11.217363
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add things here
    pass


# Generated at 2022-06-10 23:21:21.917204
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection, ConnectionError
    from ansible.module_utils.network.common import load_provider
    from ansible.plugins.loader import action_loader

    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict(
        ansible_connection='network_cli',
        ansible_network_os='ios',
        ansible_python_interpreter='/usr/bin/python',
        inventory_hostname='localhost',
    )

    action = action_loader.get('setup', task=dict(), connection=Connection('network_cli'), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-10 23:21:32.269695
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.play_iterator import TaskIterator
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import fact_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.module_utils.facts.virtual.kvm import KVMMixin as kvm
    from ansible.module_utils.facts.virtual.lxc import LXCinfo as lxc
   

# Generated at 2022-06-10 23:21:33.493445
# Unit test for function discover_interpreter
def test_discover_interpreter():
    raise NotImplementedError()

# Generated at 2022-06-10 23:21:34.144684
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:21:48.404316
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile

    class ActionModule:
        def __init__(self):
            self._connection = None
            # list of all interpreter discovery warnings encountered, for assert purposes
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            if os.path.exists(cmd):
                # cmd is a single file
                with open(cmd) as f:
                    return dict(rc=0, stdout=f.read(), stderr=u'')

# Generated at 2022-06-10 23:21:57.231000
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    class FAKE_MODULE_UTILS_BASIC(object):
        def __init__(self, action_module, task_vars, host):
            self._task_vars = task_vars
            self._host = host
            self._action_module = action_module

        @property
        def task_vars(self):
            return self._task_vars

        @property
        def host(self):
            return self._host

    # mock the module instantiation
    def FAKE_ANSIBLE_MODULE_INIT(self, *args, **kwargs):
        return None


# Generated at 2022-06-10 23:22:04.063928
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play_context import PlayContext

    fake_task = {
        'identifier': 'fake_task',
        'implementation': 'fake_implementation',
        'module': 'fake_module',
    }
    fake_action = TaskExecutor(PlayContext())

    # Test non-python interpreter
    fake_action._discovery_warnings = []
    assert discover_interpreter(fake_action, 'perl', 'auto_legacy', {}) == '/usr/bin/python'
    assert len(fake_action._discovery_warnings) == 1

    # Test auto_legacy discovery mode
    fake_action._discovery_warnings = []