

# Generated at 2022-06-10 23:12:49.409320
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # imports are here to prevent circular import trap
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.connection.local import Connection as _Connection

    test_host_vars = {}

    # test host is assumed to have the following available for Python interpreter discovery:
    #   /usr/bin/python  (identical to /usr/bin/python2)
    #   /usr/bin/python3.6
    #   /home/testuser/mypy
    #   /opt/python-2.7/bin/python2.7
    #   /opt/python-2.7/bin/python
    #       (if this is present and points to same exe as /opt/python-2.7/bin/python2.7, it will be ignored)

    # test_host_v

# Generated at 2022-06-10 23:13:00.226183
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_loader import ActionModuleLoader
    from ansible.plugins.action import ActionBase
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader, connection_loader

    class TestAction(ActionBase):

        def __init__(self, *args, **kwargs):
            self._low_level_execute_command = lambda *args, **kwargs: {'stdout': "", 'stderr': ""}

            super(TestAction, self).__init__(*args, **kwargs)

            self._discovery_warnings = []


# Generated at 2022-06-10 23:13:08.404849
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.local import LocalAnsibleModule

    task_vars = {}
    filename = './ansible_module_dummy.py'
    module = LocalAnsibleModule(filename, task_vars=task_vars, is_command=False)

    test_interpreter = discover_interpreter(module, "python", "auto", task_vars)
    assert test_interpreter == "/usr/bin/python", "did not return '/usr/bin/python'"

# Generated at 2022-06-10 23:13:17.207028
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:13:29.353161
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Connection(object):
        has_pipelining = True

    class TaskVars(object):
        def __init__(self):
            self.inventory_hostname = 'foobar'

    class ActionModule(object):
        def __init__(self, connection, task_vars):
            self._connection = Connection()
            self._discovery_warnings = ['foobar']

        def _low_level_execute_command(self, interpreter_name, sudoable, in_data=None):
            return {
                'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python2.7\n/usr/bin/python3.6\nENDFOUND',
                'stderr': ''
            }

    action = ActionModule(None, TaskVars())

# Generated at 2022-06-10 23:13:39.978194
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import copy
    import os

    from ansible.executor.discovery.test import get_test_data_paths, MockAction

    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    task_vars = {}

    test_data_paths = get_test_data_paths(__file__)
    test_data_path = test_data_paths['test_data_path']
    test_data_paths = get_test_data_paths(__file__)
    test_data_path = test_data_paths['test_data_path']


# Generated at 2022-06-10 23:13:52.865753
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult

# Generated at 2022-06-10 23:14:04.933090
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:14:11.386572
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import SUPPORTED_INTERPRETERS
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager

    # Setup Module (does not touch disk)
    class TestModule(object):
        def __init__(self):
            self.argument_spec = dict()

        def fail_json(self, **kwargs):
            raise Exception(kwargs.get('msg'))

    # Make subclass of ActionBase to make available to _low_level_execute_command helper
    class TestActionBase(ActionBase):
        TRANSFERS_FILES = False
        __test__ = True


# Generated at 2022-06-10 23:14:18.315763
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''ansible.executor.discovery_test'''
    from ansible.module_utils.common.text.converters import to_bytes

    # FIXME: this test is pretty terrible, but it's better than nothing for now
    here = os.path.dirname(os.path.abspath(__file__))
    test_data = dict(
        osrelease_content=to_bytes(to_text(json.dumps(dict(
            id='centos',
            version_id='7.5.3',
        )))),
        platform_dist_result=[u'CentOS', u'7.5.3', u'Final'],
    )

# Generated at 2022-06-10 23:14:40.026303
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # This is a very minimal test, and will not work on a non-Linux system.
    # I initially put it in the test/units/executor directory, but some
    # dependencies are needed, so I put it in the module directory.

    # Set up a display object to capture the warning.
    class DisplayTest():
        def __init__(self):
            self.loglines = []

        def warning(self, msg):
            self.loglines.append(msg)

    display = DisplayTest()
    task_vars = {}

    # FUTURE: detect appropriate bootstrap list for current OS
    task_vars['ansible_python_interpreter_fallback']

# Generated at 2022-06-10 23:14:48.620609
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction(object):
        def __init__(self):
            self.__discovery_warnings = []

        @property
        def _discovery_warnings(self):
            return self.__discovery_warnings


# Generated at 2022-06-10 23:14:59.627673
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    host = 'localhost'
    discovery_mode = 'auto'
    task_vars = {'inventory_hostname': host}
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'

    if discovery_mode != 'auto':
        raise ValueError('Interpreter discovery not supported for {0}'.format(interpreter_name))

    host = task_vars.get('inventory_hostname', 'unknown')


# Generated at 2022-06-10 23:15:10.835252
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts import Facts
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.action import ActionBase
    import ansible.executor.discovery

    class TestModule(object):
        def __init__(self, module_args, *args, **kwargs):
            self.args = module_args

# Generated at 2022-06-10 23:15:17.829784
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # To test the function, we will create a fake ansible.utils.action module and return a fake ansible.utils.action.ModuleAction
    # object
    import ansible.utils.action
    import ansible.utils.action
    test_action = ansible.utils.action.ModuleAction()
    test_action.has_pipelining = True
    # Now, let's create a fake dict and pass it to the function
    result = discover_interpreter(test_action, 'python', 'auto_legacy_silent', {})
    assert result == '/usr/bin/python'

# Generated at 2022-06-10 23:15:30.211569
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.action.discovery as discovery

    # Tests for the mode auto, when legacy non-distro interpreter is available
    # the interpreter is returned
    assert '/usr/bin/python' == \
        discovery.discover_interpreter(None, 'python', 'auto',
                                       {'ansible_python_interpreter': '/usr/bin/python'})

    # Tests for the mode auto_legacy, when legacy non-distro interpreter is
    # available the interpreter is returned
    assert '/usr/bin/python' == \
        discovery.discover_interpreter(None, 'python', 'auto_legacy',
                                       {'ansible_python_interpreter': '/usr/bin/python'})

    # Tests for the mode auto_silent, when legacy non-distro interpreter is
    # available

# Generated at 2022-06-10 23:15:42.768921
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # NOTE: this is a very light-touch coverage-friendly test, since _version_fuzzy_match is already well-tested!
    action = dict()
    action['_discovery_warnings'] = []
    action['_low_level_execute_command'] = lambda x, sudoable=True, in_data=None: dict(stdout=x, stderr='')

    test_cases = dict()


# Generated at 2022-06-10 23:15:51.300291
# Unit test for function discover_interpreter
def test_discover_interpreter():

    import mock

    import ansible.module_utils.basic

    class TestModule(object):
        def __init__(self, task_vars=None):
            self._debug = False
            self._display = None
            self._options = None
            self.action = None
            self.check_mode = False
            self.connection = None
            self.no_log = False
            self.play_context = None
            self.task = None
            self.task_vars = task_vars
            self.tmpdir = None

    class TestTask(ansible.module_utils.basic.AnsibleModule):
        def __init__(self, module_runner=None, task_vars=None):
            self._debug = None
            self._display = None
            self._module_runner = module_runner
            self._

# Generated at 2022-06-10 23:15:57.887242
# Unit test for function discover_interpreter
def test_discover_interpreter():

    discovery_mode = 'auto_legacy_silent'
    interpreter_name = 'python'


# Generated at 2022-06-10 23:16:10.474875
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.mock import mocker

    fake_result = dict(platform_dist_result=[u'centos', u'7.3.1611', u'Core'], osrelease_content=u'ID=centos\nVERSION_ID="7.3.1611"')
    fake_result_json = json.dumps(fake_result)
    fake_result_raw = "PLATFORM\r\nLinux\r\nFOUND\r\n/usr/bin/python\r\nENDFOUND"

    action_mock = mocker.MagicMock()
    action_mock.has_pipelining = True
    action_mock._discovery_warnings = []

    # First we'll test the case where the bootstrap returns an empty list for found_interpreters
    action_mock._low

# Generated at 2022-06-10 23:16:33.940938
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock
    import pytest
    from ansible.module_utils.six.moves import StringIO

    from ansible.executor.discovery import _get_linux_distro, _version_fuzzy_match, discover_interpreter

    from ansible.plugins.action.script import ActionModule as Script

    platform_linux = mock.MagicMock()
    platform_linux.return_value.dist.return_value = ('Debian', '9.5', 'stretch')
    platform_linux.return_value.system.return_value = 'Linux'

    platform_darwin = mock.MagicMock()
    platform_darwin.return_value.mac_ver.return_value = ('10.14.1', ('', '', ''), 'x86_64')

# Generated at 2022-06-10 23:16:39.022493
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: test_module path doesn't exist, but the exception isn't what we want anyway
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {'inventory_hostname': 'localhost'}) == u'/usr/bin/python'

# Generated at 2022-06-10 23:16:40.627859
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This is a stub to make pytest happy, so it doesn't throw a warning
    pass

# Generated at 2022-06-10 23:16:43.651858
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import platform
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-10 23:16:45.479506
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: test with a "bootstrap python" that isn't in the final interpreter list
    pass

# Generated at 2022-06-10 23:16:47.552157
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', {}) == u'/usr/bin/python'

# Generated at 2022-06-10 23:16:59.665123
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import TaskVarsVars


# Generated at 2022-06-10 23:17:08.267267
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible import errors
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import ActionBase
    from ansible.module_utils.six import PY3

    class action(ActionBase):
        def __init__(self, connection, play_context, new_stdin, loader, templar, shared_loader_obj):
            self._attributes = {'name': 'test'}
            self._low_level_execute_command = lambda x, sudoable, y, z: y
            self._connection = connection
            self._play_context = play_context
            self.loader = loader
            self.templar = templar
            self.shared_loader_obj = shared_loader_obj
            self._discovery_warnings = []

    class connection:
        has

# Generated at 2022-06-10 23:17:12.175566
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = ActionModule()
    action._discovery_warnings = []
    python_result = discover_interpreter(action, 'python', 'auto', {})
    assert len(python_result) > 0
    assert len(action._discovery_warnings) == 0



# Generated at 2022-06-10 23:17:23.757342
# Unit test for function discover_interpreter
def test_discover_interpreter():
    def _create_task_vars(interpreter_map=None):
        task_vars = {}
        task_vars['inventory_hostname'] = 'test_host'

        config_override = {}
        config_override['INTERPRETER_PYTHON_DISTRO_MAP'] = interpreter_map or {'ubuntu': {'16.04': '/usr/bin/python2.7'}}
        config_override['INTERPRETER_PYTHON_FALLBACK'] = ['python3', '/usr/bin/python']

        task_vars['ansible_config_overrides'] = config_override

        return task_vars

    class TestAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._low_level_execute_command

# Generated at 2022-06-10 23:17:48.198931
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import InterpreterDiscoveryRequiredError
    from ansible.module_utils import basic
    from ansible.playbook.task import Task

    class DummyAction():
        def __init__(self):
            self._discovery_warnings = []

    action = DummyAction()

    module_args = dict(
        interpreter='python',
        discovery_mode='legacy_silent',
    )

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        **module_args
    )

    task = Task()

    # Mock task_vars

# Generated at 2022-06-10 23:18:01.979090
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    import platform
    import sys

    res = {}
    class FakeTask:
        def __init__(self):
            self.action = FakeAction()
        def set_runner_facts(self, runner_facts):
            pass
        def get_vars(self):
            return {'inventory_hostname': 'localhost', 'group_names': ['all']}

    class FakeAction:
        def __init__(self):
            self.connection = FakeConnection()

        def _get_action_defaults(self):
            return {}

# Generated at 2022-06-10 23:18:09.448913
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.script import ActionModule as ScriptModule
    simple_action = ScriptModule(
        task=dict(action=dict(args=dict(interpreter='python')),
                  action_plugins=['script']),
        connection=None,
        templar=None,
        shared_loader_obj=None,
        loader=None,
    )

    # mock ad-hoc task_vars dict

# Generated at 2022-06-10 23:18:17.839399
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Action():
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            return {'stdout': cmd, 'stderr': 'unit_test'}

    task_vars = {}
    action = Action()

    C.config.runtime._set_constants_from_environment()
    C.config.runtime.load_from_file()

    res = discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)
    assert res == '/usr/bin/python'

# Generated at 2022-06-10 23:18:22.814212
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module_args = dict(discovery_mode='auto', interpreter_name='python')
    task_vars = dict(ansible_python_version='2.6')
    try:
        discover_interpreter(None, **module_args)
    except InterpreterDiscoveryRequiredError as e:
        assert isinstance(e, InterpreterDiscoveryRequiredError)
        assert e.discovery_mode == module_args['discovery_mode']
        assert e.interpreter_name == module_args['interpreter_name']

# Generated at 2022-06-10 23:18:35.335274
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ast
    import sys
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import module_loader, action_loader

    loader = DataLoader()

    # read inventory
    inventory = InventoryManager(loader, sources=sys.argv[1])

    # parse inventory file
    inventory.parse_inventory(None)

    # create the dictionary to pass to the play context
    variables = inventory.get_vars(inventory.hosts)

    # create the play context
    play_

# Generated at 2022-06-10 23:18:46.865605
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test with a known system
    import json
    # The task_vars is the only input that can change and the function is tested with
    # a few system tests.

# Generated at 2022-06-10 23:18:58.061069
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    c = display.Display().display.__class__
    builtins.display = c()

    class FakeDisplay(object):
        def __init__(self):
            self.vvv_messages = []
            self.debug_messages = []
            self.warning_messages = []

        def vvv(self, msg, host=None):
            self.vvv_messages.append(msg)

        def debug(self, msg, host=None):
            self.debug_messages.append(msg)

        def warning(self, msg):
            self.warning_messages.append(msg)

    class FakeAction(object):
        def __init__(self):
            self._discovery_warnings = []



# Generated at 2022-06-10 23:19:10.522183
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:19:15.372653
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = {}

    # Test NotImplementedError
    # Test python_target.py not found
    assert '/usr/bin/python' == discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

# Generated at 2022-06-10 23:19:43.415742
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common._collections_compat import Mapping

    assert('python' == discover_interpreter('hello', 'python', 'auto_legacy_silent', Mapping({})))
    assert('python2' == discover_interpreter('hello', 'python', 'auto_legacy_silent', Mapping({'inventory_hostname': 'debian'})))
    assert('python2' == discover_interpreter('hello', 'python', 'auto_legacy_silent', Mapping({'inventory_hostname': 'rhel'})))
    assert('python3' == discover_interpreter('hello', 'python', 'auto_legacy_silent', Mapping({'inventory_hostname': 'fedora'})))

# Generated at 2022-06-10 23:19:45.965478
# Unit test for function discover_interpreter
def test_discover_interpreter():
    res = discover_interpreter(None, 'python', 'auto_legacy', None)
    assert res == u'/usr/bin/python'

# Generated at 2022-06-10 23:19:58.399620
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class _ActionModule(object):
        def __init__(self):
            self._discovery_warnings = []

        @staticmethod
        def _low_level_execute_command(cmd, sudoable=False, in_data=None):
            if cmd == "command -v 'python3'":
                return {'stdout': u"PLATFORM\nLinux\nFOUND\n/usr/bin/python3\nENDFOUND"}
            elif cmd == "/usr/bin/python3":
                # TODO: fold this into a fixture file
                return {'stdout': u'{"platform_dist_result": ["SUSE", "42", "x86_64"], '
                                  u'"osrelease_content": "NAME=SUSE Leap\\nVERSION_ID=42"}'}

# Generated at 2022-06-10 23:20:06.998465
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:20:17.237103
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        TRANSFERS_FILES = True

        def __init__(self, *args, **kwargs):
            super(TestAction, self).__init__(*args, **kwargs)

            self._discovery_warnings = []

        def _get_connection(self):
            return DummyConnection()

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None, executable='/bin/sh',
                                       use_unsafe_shell=False):
            return {'stdout': cmd}

        def warning(self, msg):
            self._discovery_warnings.append(msg)


# Generated at 2022-06-10 23:20:27.498479
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest
    import copy
    from base64 import b64decode
    task_vars = {'inventory_hostname': 'localhost', 'ansible_connection': 'local'}

    # using interpreter_discovery_message_template as test command

# Generated at 2022-06-10 23:20:37.817995
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:20:46.956886
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    from ansible.parsing.vault import VaultLib

    class FakeAction(object):
        def __init__(self, *args, **kwargs):
            self._play_context = kwargs.get('play_context')
            self._task = kwargs.get('task')
            self._loader = kwargs.get('loader')
            self._connection = kwargs.get('connection')
            self._tmp = None
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, *args, **kwargs):
            """Return the result of the remote execution"""
            return {'stdout': cmd, 'stderr': ''}

    task_vars = dict()

# Generated at 2022-06-10 23:20:59.022172
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict(
        ansible_python_interpreter=None,
        ansible_python_interpreter_python2=None,
        ansible_python_interpreter_python3=None,
        ansible_python_version='',
    )

    # First test - valid case with only exact match

# Generated at 2022-06-10 23:21:00.267684
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit test
    pass

# Generated at 2022-06-10 23:21:38.088650
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts import get_module_facts

    assert discover_interpreter(
        None,
        'python',
        'auto',
        get_module_facts('setup')['ansible_facts']
    )
    assert discover_interpreter(
        None,
        'python',
        'auto_legacy',
        get_module_facts('setup')['ansible_facts']
    )
    assert discover_interpreter(
        None,
        'python',
        'auto_silent',
        get_module_facts('setup')['ansible_facts']
    )



# Generated at 2022-06-10 23:21:51.991339
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class FakeAction(object):
        task_vars = dict()
        _connection = None
        _discovery_warnings = list()

    class FakeConnection(object):
        has_pipelining = True

    class MockInterpreterMap(dict):
        def get_config_value(self, key, variables=None):
            return self[key]

    action = FakeAction()
    action._connection = FakeConnection()

    my_map = MockInterpreterMap()

# Generated at 2022-06-10 23:22:00.524233
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from .plugins.action import ActionBase

    action_module = ActionBase(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._connection = MockConnection()
    action_module._low_level_execute_command = MockLowLevelExecute()
    task_vars = dict()

    # The actual python interpreters are not present in the system os.environ.
    # So, the results sent back by the low_level_execution_command function are
    # formatted according to the fallback interpreter path, instead of the native
    # python interpreter path.
    os.environ["PATH"] = "/bin:/usr/bin:/usr/local/bin"

    # By default, the fallback interpreter paths are assumed

# Generated at 2022-06-10 23:22:11.918690
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.setup import ActionModule as SetupAction
    from ansible.plugins.action import ActionBase
    from ansible.executor import module_common
    from ansible.utils.vars import combine_vars

    class PseudoHostVars(object):
        hostvars = {'host1': {'ansible_python_interpreter': 'python', 'ansible_python_interpreter_discovery_mode': 'auto_legacy_silent'}}
    class PseudoTaskVars(dict):
        def __init__(self, host):
            combine_vars(self, PseudoHostVars().hostvars[host], None)

    class PseudoTask(object):
        def __init__(self, host):
            self.host = host
            self.vars = PseudoTaskV

# Generated at 2022-06-10 23:22:21.701811
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.connection import Connection

    # need "test" connection plugin loaded to do this, but not all test runners do that
    connection_class_list = Connection._load_plugins()
    assert 'test' in connection_class_list, \
        'The "test" connection plugin has not been registered and cannot be used for this test'

    # mock platform, for now hardcoded for this test
    class MockConnectionPlugin:
        def get_option(self, opt):
            return getattr(self, opt)

        def __init__(self, *args, **kwargs):
            self.become = self.become_user = None
            self.become_method = 'sudo'


# Generated at 2022-06-10 23:22:29.048916
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule

    # Test instantiation
    action = ActionModule(None, '', '')

    # Test call
    result = discover_interpreter(action, 'python', 'auto_legacy_silent', None)

    assert result == u'/usr/bin/python'
    assert action._discovery_warnings == []

    # Test instantiation
    action = ActionModule(None, '', '')

    # Test call
    result = discover_interpreter(action, 'python', 'auto_legacy', None)

    assert result == u'/usr/bin/python'
    assert len(action._discovery_warnings) > 0

    # Test instantiation
    action = ActionModule(None, '', '')

    # Test call