

# Generated at 2022-06-10 23:12:48.327460
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None  # not important for this test
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = dict()

    if C.__version_info__ >= (2, 8, 0):
        # This used to be the default, but starting with 2.8.0, its the empty string
        task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    else:
        # This used to be the default, but starting with 2.8.0, its the empty string
        task_vars['ansible_python_interpreter'] = '/usr/bin/python'

    display.verbosity = 2

    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)


# Generated at 2022-06-10 23:12:59.297548
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    assert discover_interpreter(action, 'python', 'auto', {}) == '/usr/bin/python'
    assert discover_interpreter(action, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'
    assert discover_interpreter(action, 'python', 'auto_legacy', {}) == '/usr/bin/python'
    assert discover_interpreter(action, 'python', 'auto_silent', {}) == '/usr/bin/python'
    assert discover_interpreter(action, 'python', 'auto_silent', {'INTERPRETER_PYTHON_DISTRO_MAP': {'foo': {'1.0': '/bin/python', '1.1': '/usr/bin/python'}}}) == '/bin/python'

# Generated at 2022-06-10 23:13:10.222435
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import tempfile
    import os

    base_path = tempfile.mkdtemp()
    python_path = os.path.join(base_path, "python")
    os.makedirs(python_path)
    python_path = python_path + "/"
    python_file = tempfile.NamedTemporaryFile(mode='w', dir=base_path, suffix=".py")
    python_file_path = python_file.name
    with python_file as fh:
        fh.write('#!/usr/bin/env python\nprint("#!/usr/bin/python")\n')
        fh.flush()
        os.fsync(fh.fileno())

    os.chmod(python_file_path, 0o755)

    def shell_boot_script():
        import platform
       

# Generated at 2022-06-10 23:13:24.208032
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert _version_fuzzy_match('3.4', {'3.4': 'a', '3.5': 'b'}) == 'a'
    assert _version_fuzzy_match('3.5', {'3.4': 'a', '3.5': 'b'}) == 'b'
    assert _version_fuzzy_match('3.5', {'3.4': 'a', '3.5': 'b', '3.6': 'c'}) == 'b'
    assert _version_fuzzy_match('3.4', {'3.4': 'a', '3.5': 'b', '3.6': 'c'}) == 'a'

# Generated at 2022-06-10 23:13:35.511054
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery.python_discovery_mock as mock_platform

# Generated at 2022-06-10 23:13:43.005633
# Unit test for function discover_interpreter

# Generated at 2022-06-10 23:13:54.791172
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.module_common import InterpreterDiscoveryAction, ModuleAction
    from ansible.plugins.action import ActionBase, TransferActionBase

    class MockModuleAction(ModuleAction):
        def __init__(self, task_vars):
            super(MockModuleAction, self).__init__()
            self.connection = None
            self.task_vars = task_vars
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, in_data=None, sudoable=True, executable=None, persist_files=False):
            if cmd == 'command -v \'/usr/bin/python\'':
                return dict(stdout='/usr/bin/python')
            if cmd == 'command -v \'/bin/python\'':
                return dict

# Generated at 2022-06-10 23:14:06.743788
# Unit test for function discover_interpreter
def test_discover_interpreter():
    display.verbosity = 1
    class TestAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._low_level_execute_command_pipeline = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if in_data:
                self._low_level_execute_command_pipeline.append(cmd)
                return {'stdout': json.dumps({'platform_dist_result': ['centos', '6.9', 'Final']}), 'stderr': ''}
            return {'stdout': '', 'stderr': ''}

# Generated at 2022-06-10 23:14:08.492553
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: write tests
    pass

# Generated at 2022-06-10 23:14:17.828356
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert _version_fuzzy_match('15', {'12': 'python3.4', '21': 'python3.6', '30': 'python3.7'}) == 'python3.6'
    assert _version_fuzzy_match('14', {'12': 'python3.4', '21': 'python3.6', '30': 'python3.7'}) == 'python3.4'
    assert _version_fuzzy_match('30', {'12': 'python3.4', '21': 'python3.6', '30': 'python3.7'}) == 'python3.7'

# Generated at 2022-06-10 23:14:39.226129
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule

    task_vars = dict(
        inventory_hostname='test_host',
    )

    # Test with no possible results
    action_module = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    try:
        discover_interpreter(action_module, 'python', 'auto_legacy_silent', task_vars)
    except RuntimeError as ex:
        assert 'Unable to discover python interpreters' in to_text(ex)
    else:
        assert False

    # Test with C.config.get_config_value using a common fallback
    task_vars['ansible_connection'] = 'local'

# Generated at 2022-06-10 23:14:42.892447
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('dummy', 'python', 'smart', 'dummy') == '/usr/bin/python'
    assert discover_interpreter('dummy', 'python' , 'smart_silent', 'dummy') == '/usr/bin/python'


# Generated at 2022-06-10 23:14:43.486860
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:14:50.848244
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_write_locks import ActionWriteLock
    from ansible.plugins import module_loader

    task_vars = dict()
    action = module_loader.find_plugin('system', 'ping')
    result = discover_interpreter(action, 'python', 'explicit', task_vars)
    assert result == '/usr/bin/python'

    result = discover_interpreter(action, 'python', 'auto', task_vars)
    assert result == '/usr/bin/python'

    result = discover_interpreter(action, 'python', 'auto_legacy', task_vars)
    assert result == '/usr/bin/python'

    result = discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)

# Generated at 2022-06-10 23:14:53.267542
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy', dict()) == u'/usr/bin/python'



# Generated at 2022-06-10 23:15:04.039693
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    from ansible.module_utils.compat.version import LooseVersion

    # Insert the current directory as the first location where we search for
    # interpreter discovery python files. This is to ensure that we will find
    # the file version_map.json if it exists in the current directory.
    #
    # The reason for inserting the directory in the first position instead of the
    # last position is because this is how the behavior is when the
    # feature is not implemented. So we want to ensure that we check it first
    # so that if there is an override of the constant it will be found.
    #
    # FUTURE: consider making this a little more robust by searching the
    # current directory first and then the configured directory.
    C.config.config_dirs.insert(0, os.path.abspath('.'))

   

# Generated at 2022-06-10 23:15:13.465435
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.packaging_yum import ActionModule as yum_action
    from ansible.plugins.action.packaging_apt import ActionModule as apt_action
    from ansible.plugins.action.packaging_pacman import ActionModule as pacman_action
    from ansible.plugins.action.packaging_portage import ActionModule as portage_action
    from ansible.plugins.action.packaging_pkgng import ActionModule as pkgng_action
    from ansible.plugins.action.packaging_slackpkg import ActionModule as slackpkg_action
    from ansible.plugins.action.packaging_zypper import ActionModule as zypper_action
    from ansible.plugins.action.packaging_dnf import ActionModule as dnf_action

# Generated at 2022-06-10 23:15:27.359109
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.connection import Connection
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import connection_loader
    from ansible.utils import context_objects as co

    # Setup the mock module to be executed
    fake_module_name = 'fake_module'
    fake_module_args = {}
    fake_module_kv = None

    fake_module_payload = (fake_module_name, fake_module_args, fake_module_kv)

    # Create connection plugin to use

# Generated at 2022-06-10 23:15:41.114402
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # we need to monkeypatch this for now, since the bootstrapping and discovery scripts are only in the DIST.
    C.config.set_config_value('ANSIBLE_LIBRARY', './lib/ansible/modules')
    C.config.set_config_value('ANSIBLE_MODULE_UTILS', './lib/ansible/module_utils')

    # initialize module_utils/facts.py, so we can test this in isolation
    import ansible.module_utils.facts
    ansible.module_utils.facts.__file__ = './lib/ansible/module_utils/facts.py'
    import ansible.module_utils.facts.system.distribution

# Generated at 2022-06-10 23:15:50.353862
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.remote_management.interpreter_discovery import discover_interpreter

    class FakeAction(object):
        def __init__(self):
            self._connection = Connection()
            self._discovery_warnings = []

    action = FakeAction()
    action._connection = Connection()
    action._connection.has_pipelining = True
    action._connection.executable = '/bin/sh'

    # Test with no python interpreters installed
    res = discover_interpreter(action, 'python', 'auto', {})
    assert res == '/usr/bin/python'
    assert len(action._discovery_warnings) > 0

    # Test with /usr/bin/python and /usr/

# Generated at 2022-06-10 23:16:17.819622
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Action:
        def __init__(self, host):
            self._low_level_execute_command = lambda _, __: {'stdout': host}
            self._discovery_warnings = []

    action = Action('\n'.join(['PLATFORM', 'Linux', 'FOUND', '/usr/bin/python', '/usr/bin/python3', 'ENDFOUND']))

# Generated at 2022-06-10 23:16:30.089588
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    module_vars = dict()
    task_vars = dict()
    module_vars['ansible_facts'] = task_vars['ansible_facts'] = dict()
    module_vars['ansible_facts']['ansible_python_interpreter'] = "/usr/bin/python"
    result = TaskResult(dict(module_vars=module_vars, task_vars=task_vars, loader=loader))

# Generated at 2022-06-10 23:16:39.183068
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.loader import module_loader
    from ansible.executor.task_result import TaskResult

    class MyDisplay(object):
        def __init__(self):
            pass

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            print(to_text(msg, errors='surrogate_or_strict'))

    display = MyDisplay()

    class MyActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._shared_loader_obj = shared_loader_obj
            self._loader = loader
            self._templar = templ

# Generated at 2022-06-10 23:16:43.351988
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.connection import Connection
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.common.collections import ImmutableDict

    mock_task_vars = ImmutableDict()
    ActionBase = type('ActionBase', (object,), dict(_connection=Connection(),
                                                    _low_level_execute_command=lambda _, __, ___, ____: dict(stdout=interp_path)))
    mock_action = ActionBase()

    # Test successful discovery
    interp_path = '/usr/bin/python'
    mock_action._discovery_warnings = []

# Generated at 2022-06-10 23:16:55.178215
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # unit test for function discover_interpreter
    import ansible.executor.discovery
    import ansible.executor.discovery_old
    debug = open("unit_test/debug.log", "a")

    def get_action():
        class Action(object):
            def __init__(self):
                self._discovery_warnings = []
                self._connection = get_connection()

        class Connection(object):
            def __init__(self):
                self.has_pipelining = True


# Generated at 2022-06-10 23:17:05.527836
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import Platform

# Generated at 2022-06-10 23:17:18.169071
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockActionModule(object):
        def __init__(self, interpreter_discovered):
            self._low_level_execute_command_results = []
            self._discovery_warnings = []

            # setup the bootstrap
            self._low_level_execute_command_results.append({
                "stdout": "PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/local/python\nENDFOUND"
            })

            # fake the fetched platform info

# Generated at 2022-06-10 23:17:29.338941
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.connection.local import Connection
    from ansible.plugins.strategy.linear import StrategyModule

    loader = DataLoader()

    display = Display()

    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info={"ansible_version": "2.5.5"})


# Generated at 2022-06-10 23:17:36.394473
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # pylint: disable=unused-variable,import-error
    import ansible.module_utils.distro
    import ansible.module_utils.interpreter_discovery
    # pylint: enable=unused-variable,import-error

    class MockAction:
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, command, sudoable=False, in_data=None):
            output = 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/python2\nENDFOUND'
            out = Test_Interpreter_Discovery.CONNECTION_RESULT_MAP.get(command)
            stdout = out if out else output
            return {'stdout': stdout}

# Generated at 2022-06-10 23:17:50.247339
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Note: we're not testing against a real target, so we'll pretend that we found the old-style /usr/bin/python,
    # but we'll also add our packaged python to the list, so we can see that we pick the right one

    action_mock = lambda: None
    action_mock.task_vars = {}
    action_mock._connection = lambda: None
    action_mock._connection.has_pipelining = True
    action_mock._low_level_execute_command = lambda i, sudoable, in_data: {'stdout': u''}
    action_mock._discovery_warnings = []
    assert discover_interpreter(action_mock, u'python', u'auto', action_mock.task_vars) == u'/usr/bin/python'
    assert discover

# Generated at 2022-06-10 23:18:35.083111
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.pycompat24 import get_exception
    import pytest


# Generated at 2022-06-10 23:18:46.816716
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.task_result as t_r
    import ansible.executor.task_executor as t_e
    import ansible.executor.action_executor as ac_e
    import ansible.plugins.action as a_p

    class FakeAction(a_p.ActionBase):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(FakeAction, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self._discovery_warnings = []

        def _execute_module(self, tmp=None, task_vars=None, wrap_async=None):
            module_name = self._task.action

# Generated at 2022-06-10 23:18:58.016628
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import become_loader, cache_loader, connection_loader, test_loader
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.shell import ShellModule
    from ansible.plugins.terminal import TerminalBase
    from ansible.utils.plugins import AnsiblePlugin
    # create a dummy map because we're going to override it later
    """
    PLATFORM
    Linux
    FOUND
    /usr/bin/python
    ENDFOUND
    """

# Generated at 2022-06-10 23:19:10.485146
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # basic module data
    action = {}
    action['module_name'] = 'setup'
    action['module_args'] = {}
    action['_original_file'] = '/path/to/playbook/module-name.yaml'
    action['_uses_shell'] = False

    import ansible.executor.task_result
    result = ansible.executor.task_result.TaskResult()

    import ansible.plugins.action.normal
    action = ansible.plugins.action.normal.ActionModule(task=None, connection=None, play_context=None, loader=None,
                                                        templar=None, shared_loader_obj=None)

    # load ansible.constants
    import ansible.constants
    C = ansible.constants

    # ansible.constants.config

# Generated at 2022-06-10 23:19:20.885743
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: remove once all the warning messages are added in display portion
    import ansible.plugins.action.script

    test_task_vars = dict(
        ansible_python_interpreter='user_define',
        ansible_ssh_user='root',
        ansible_hostname='hostname',
    )
    action_args = dict(
        interpreter='python',
        discovery_mode='default',
    )
    action = ansible.plugins.action.script.ActionModule(None, action_args, play_context=None, loader=None)
    action._discovery_warnings = []
    result = discover_interpreter(action, 'python', 'default', test_task_vars)
    assert result == '/usr/bin/python'


# Generated at 2022-06-10 23:19:31.460731
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # we need a module and a host for our action
    action = ActionModule('/foo/bar', Host(name='testhost', port=22), '/foo/bar')
    action._discovery_warnings = []
    task_vars = dict()

    # set up a stub connection plugin object
    class StubConnection(object):
        def __init__(self):
            self.has_pipelining = True

    action._connection = StubConnection()

    # test with "known" distro, which should return the known path
    task_vars['platform.system'] = 'Linux'
    task_vars['platform.dist'] = ['CentOS', '7', 'Core']
   

# Generated at 2022-06-10 23:19:42.948098
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule

    mock_task_vars = dict()
    action = ActionModule(None, None, task_vars=mock_task_vars, loader=None, templar=None, shared_loader_obj=None)

    def fake_low_level_execute_command(*args, **kwargs):  # pylint: disable=unused-argument
        return {'stdout': ''}

    action._low_level_execute_command = fake_low_level_execute_command

    default_python = discover_interpreter(action, 'python', 'auto', mock_task_vars)
    assert default_python == u'/usr/bin/python'


# Generated at 2022-06-10 23:19:43.686919
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:19:56.284893
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    **This is test function for discover_interpreter

    """
    import mock

    import ansible.module_utils.connection as connection
    import ansible.module_utils.distro as distro
    import ansible.module_utils.network.common.config as config
    from ansible.module_utils.network.common.utils import to_list

    from ansible.module_utils.distro import LinuxDistribution
    from ansible.module_utils.network.common.utils import to_list

    import ansible.executor.discovery

    class Dummy(object):
        def __init__(self, has_pipelining, stdout, name):
            self.has_pipelining = has_pipelining
            self.stdout = stdout
            self.name = name


# Generated at 2022-06-10 23:20:10.350596
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import unittest2 as unittest
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.loader import find_plugin_filepaths, load_plugins
    from ansible.utils.display import Display
    from ansible.utils.path import basedir
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleError
    from ansible.executor.task_executor import TaskExecutor

    display = Display()
    loader = DataLoader()


# Generated at 2022-06-10 23:21:31.700510
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # If a non-python interpreter is passed in, exception should be raised with error message
    from ansible.executor.discovery import discover_interpreter as discover_interpreter
    from collections import namedtuple
    action = namedtuple('action', ['results', '_low_level_execute_command', '_discovery_warnings', '_connection'])
    action._connection = namedtuple('action', ['has_pipelining'])
    action._connection.has_pipelining = True
    task_vars = {}

# Generated at 2022-06-10 23:21:39.998853
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system import system

    class Result(object):
        def __init__(self, stdout=None, stderr=None):
            self.stdout = stdout
            self.stderr = stderr

    class InterpDiscoveryTestModule(system.System):
        def __init__(self, *args, **kwargs):
            super(InterpDiscoveryTestModule, self).__init__(*args, **kwargs)
            self._connection = object()
            self._discovery_warnings = []


# Generated at 2022-06-10 23:21:53.156537
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Python
    interpreter_name = 'python'
    # hostvars: empty
    hostvars = {}
    # action: empty
    class action:
        _low_level_execute_command_stdout = """command -v 'python'
/usr/bin/python
command -v 'python3.6'
/usr/bin/python3.6
command -v 'python2.7'
/usr/bin/python2.7"""
        _discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            res = {'stdout': self._low_level_execute_command_stdout}
            return res

    # discovery_mode: auto
    discovery_mode = 'auto'

    # distro: None
    expected_inter

# Generated at 2022-06-10 23:22:01.544768
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.removed import removed

    def test_strict(interpreter_name, mode):
        if removed:
            return
        if mode == 'auto':
            if interpreter_name == 'python':
                return '/usr/bin/python'
            else:
                return None
        raise InterpreterDiscoveryRequiredError("foo", interpreter_name, mode)

    def test_auto_legacy(interpreter_name, mode):
        if removed:
            return
        if interpreter_name != 'python':
            raise ValueError('Interpreter discovery not supported for {0}'.format(interpreter_name))
        if mode == 'auto':
            return '/usr/bin/python'
        raise InterpreterDiscoveryRequiredError("foo", interpreter_name, mode)

    # FIXME: not

# Generated at 2022-06-10 23:22:13.133157
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action', 'python', 'auto', 'task_vars') == '/usr/bin/python'
    assert discover_interpreter('action', 'python', 'auto_legacy', 'task_vars') == '/usr/bin/python'
    assert discover_interpreter('action', 'python', 'auto_legacy_silent', 'task_vars') == '/usr/bin/python'
    assert discover_interpreter('action', 'python', 'auto_silent', 'task_vars') == '/usr/bin/python'
    try:
        assert discover_interpreter('action', 'not_python', 'auto', 'task_vars') == 'program'
    except ValueError as ex:
        assert str(ex) == "Interpreter discovery not supported for not_python"

# Generated at 2022-06-10 23:22:22.773886
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.module_common as mc

    # This is just an integration test, we need to mock some things, but not the whole world.
    class MockActionModule(object):
        def __init__(self):
            self._discovery_warnings = list()

        def debug(self, msg):
            print('DEBUG: ' + msg)

        def warning(self, msg):
            print('WARN:  ' + msg)

    class MockActionExecutor(mc.action_executor):
        def __init__(self):
            self._low_level_execute_command = MockLowLevelExecCommand()
            self._connection = MockConnection()
            self._templar = MockTemplar()

    class MockConnection(object):
        def __init__(self):
            self.has_pipelining = True

   

# Generated at 2022-06-10 23:22:30.257287
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ..action_plugins.discovery import ActionModule
    task_vars = dict()
    action = ActionModule(None, task_vars=task_vars, onlyif='', unless='', async_val=None, poll=0,
                          action_plugins_setting={}, connection_plugins_setting={}, stdin='',
                          stdout='', executor_config=None, connection=None)

    task_vars['discover_interpreter_python'] = False
    try:
        result = discover_interpreter(action, 'python', 'auto_legacy_silent', task_vars)
    except InterpreterDiscoveryRequiredError:
        result = True
    assert result, 'discover_interpreter fails'
