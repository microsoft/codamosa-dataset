

# Generated at 2022-06-10 23:12:56.925808
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # the test_discover_interpreter function is intended to
    # be run outside the normal Ansible testing framework, since
    # it depends on having a working, running Python interpreter on
    # the system Ansible is installed on
    # TODO: get it running under an Ansible test harness without
    # having to actually execute stuff on the system Ansible is installed on

    from ansible.module_utils.basic import AnsibleModule, get_distribution

    # _get_linux_distro
    # this set of tests assumes the Python running this test is a recent-enough RHEL/CentOS
    interp_mod = AnsibleModule(argument_spec={})
    run_distro, run_version = _get_linux_distro(interp_mod._platform_detect(None)())

    # if this Python is on RHEL7 or RH

# Generated at 2022-06-10 23:12:58.054970
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-10 23:13:09.227607
# Unit test for function discover_interpreter
def test_discover_interpreter():

    try:
        # Import is done here to avoid a circular import of the interpreter function and the test function
        from ansible.executor.action_plugins.action import ActionModule
    except ImportError:
        raise SkipTest('Unable to import ansible.executor.action_plugins.action.ActionModule. Skipping test.')

    # Python version will vary based on the version installed on the system running the test.  Initialize the list
    # with the executable name and then append the version to the end.
    platform_python_map = {'python': ['python', '/usr/bin/python', '/usr/bin/python2', '/usr/bin/python2.7']}
    bootstrap_python_list = [u'/usr/bin/python3.6']

    # Test python3.6
    discovery_mode = 'explicit'
    action

# Generated at 2022-06-10 23:13:23.206473
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {
        'config': {
            'INTERPRETER_PYTHON_DISTRO_MAP': {
                'debian': {
                    '7': '/usr/bin/python2.7',
                    '8': '/usr/bin/python2.7'
                },
                'ubuntu': {
                    '14.04': '/usr/bin/python3.4',
                    '16.04': '/usr/bin/python3.5'
                }
            },
            'INTERPRETER_PYTHON_FALLBACK': '/usr/bin/python2.7'
        }
    }

    # AttributeError because there is no _low_level_execute_command method
    # AttributeError: 'NoneType' object has no attribute '_low_level_execute_command'

# Generated at 2022-06-10 23:13:33.027729
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    task = Task()
    task._connection = None
    task.action = 'command'
    task.args = {'_raw_params': 'echo "hi"'}
    task.become = False
    task.become_user = None
    task.delegate_to = 'localhost'
    task.delegate_facts = False
    task.environment = None
    task.module_name = 'command'
    task.module_args = None
    task.no_log = False
    task.register = None
    task.remote_user = 'root'
    task.set_fact = None
    task.run_once = False
   

# Generated at 2022-06-10 23:13:45.271155
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery
    # Setup os-release info and python version information

# Generated at 2022-06-10 23:13:56.614438
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import mock
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    display = Display()

    # sorta hacky way to get a valid TaskQueueManager
    results = mock.Mock(spec=TaskResult)
    results.is_failed = False
    loader = mock.Mock(spec=DataLoader)
    variable_manager = mock.Mock(spec=VariableManager)

# Generated at 2022-06-10 23:13:58.532111
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test interpreter string
    interpreter = discover_interpreter()
    assert isinstance(interpreter, str)

# Generated at 2022-06-10 23:14:10.548757
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto', None) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy', None) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', None) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent', None) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_silent_legacy', None) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'default', None) == '/usr/bin/python'

# Generated at 2022-06-10 23:14:21.028027
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Setup a task_vars dict
    task_vars = {
        'inventory_hostname': 'hostname',
        '_ansible_parsed_strings': {}
    }

    # Setup a "mock" action
    class MockAction:
        def __init__(self):
            self._discovery_warnings = []
            self._connection = MockConnection()

        def _low_level_execute_command(self, cmd, sudoable, in_data=None):
            return {'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'}

    action = MockAction()

    conn = MockAction()._connection

    # Test with a valid interpreter name

# Generated at 2022-06-10 23:14:50.126499
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module_action = MockModuleAction()
    module_action._discovery_warnings = []
    task_vars = dict()

    # specify the config for MockModuleAction
    config_path = os.path.join(os.path.dirname(__file__), './../../testing/units/config_data.yml')
    module_action.config_data = load_config_data(config_path)
    module_action.connection = MockConnection()

    # test data for the unit test

# Generated at 2022-06-10 23:15:01.367464
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_builder import ActionModule
    from ansible.plugins.loader import action_loader

    action = ActionModule(action_loader.get('raw'), {}, task_vars={}, loader=None)

    ret = discover_interpreter(action, 'python', 'silent_legacy', {})
    assert ret == '/usr/bin/python'
    assert not action._discovery_warnings

    ret = discover_interpreter(action, 'python', 'silent_fail', {})
    assert not ret
    assert not action._discovery_warnings
    ret = discover_interpreter(action, 'python', 'silent_legacy', {})
    assert ret == '/usr/bin/python'
    assert not action._discovery_warnings


# Generated at 2022-06-10 23:15:11.753971
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.urls import open_url

    class DummyActionModule:
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, *args, **kwargs):
            resp = open_url('http://localhost:' + str(port))
            return dict(stdout=resp.read())

    class FakeConnection:
        def __init__(self):
            self.has_pipelining = True

    action = DummyActionModule()
    action._connection = FakeConnection()

    # make sure the platform_python_map is loading
    assert isinstance(C.config.get_config_value('INTERPRETER_PYTHON_DISTRO_MAP'), dict)

# Generated at 2022-06-10 23:15:15.500823
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = FakeActionModule()
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = {}
    interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    assert interpreter.endswith('python')


# Generated at 2022-06-10 23:15:26.693193
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.task_queue_manager
    import ansible.plugins.action

    action = ansible.plugins.action.ActionModule(None, {}, C.DEFAULT_SUDO_USER, C.DEFAULT_SUDO_PASS, False, False)

    task_vars = ansible.executor.task_queue_manager.TaskQueueManager._create_global_vars(
        {}, {}, {}, {}, C.DEFAULT_SUDO_USER, C.DEFAULT_SUDO_PASS, False, False)

    assert discover_interpreter(action, 'python', 'auto_legacy', task_vars) == '/usr/bin/python'

# Generated at 2022-06-10 23:15:28.794832
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Unit test for function discover_interpreter
    :return: None
    """
    print("Not implemented")



# Generated at 2022-06-10 23:15:41.679134
# Unit test for function discover_interpreter
def test_discover_interpreter():

    from ansible.plugins.action.copy import ActionModule as ActionCopyModule
    from ansible.plugins.action.synchronize import ActionModule as ActionSyncModule

    action = ActionCopyModule(task=dict(action='copy'), connection='local', play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert discover_interpreter(action, 'python', 'auto', dict()) == '/usr/bin/python'

    action = ActionCopyModule(task=dict(action='copy'), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert discover_interpreter(action, 'python', 'auto', dict()) is None


# Generated at 2022-06-10 23:15:51.313336
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test for function _version_fuzzy_match
    a = _version_fuzzy_match(version='2.6.9',
                             version_map={'3.6': '/usr/bin/python3.6',
                                          '3.5': '/usr/bin/python3.5',
                                          '2.7': '/usr/bin/python2.7'})
    assert a == '/usr/bin/python2.7'

    # Test for logic of function discover_interpreter with python interpreter
    b = discover_interpreter(action='', interpreter_name='python', discovery_mode='auto', task_vars='')
    assert b == '/usr/bin/python'

# Generated at 2022-06-10 23:15:57.894556
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.plugins.action
    import ansible.plugins.action.copy
    import ansible.plugins.action.synchronize
    import ansible.plugins.action.template
    import ansible.plugins.connection
    import ansible.plugins.connection.network_cli
    import ansible.plugins.connection.ssh
    import ansible.plugins.lookup
    import ansible.plugins.lookup.template
    import ansible.plugins.shell
    import ansible.plugins.shell.bash
    import ansible.plugins.shell.sh
    import ansible.plugins.shell.tcsh
    import ansible.plugins.test

    host = 'test_host'
    task_vars = dict()

    # Test discovery (and version_map)
    test_osreleases = ['debian9', 'rhelpers']

# Generated at 2022-06-10 23:16:10.481349
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter, InterpreterDiscoveryRequiredError
    from ansible.module_utils.common.collections import ImmutableDict
    import pytest

    # an empty task vars dict is ok
    # this is a fallback-only discovery
    py2 = discover_interpreter(None, 'python', 'auto_legacy_silent', ImmutableDict())
    assert py2 == u'/usr/bin/python'

    with pytest.raises(ValueError):
        discover_interpreter(None, 'non-python', 'auto_legacy_silent', ImmutableDict())

    task_vars1 = ImmutableDict({
        'ansible_python_interpreter': '/usr/bin/python'
    })

    # an empty task vars dict

# Generated at 2022-06-10 23:16:46.567936
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.connection import Connection

    # Bootstrap-only case
    class MockAction(object):
        _connection = Connection(None)
        _low_level_execute_command = staticmethod(lambda c, s, **kwargs: {'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'})

    task_vars = {}
    actual = discover_interpreter(MockAction(), 'python', 'auto', task_vars)
    assert actual == u'/usr/bin/python'

    # Full discovery case
    class MockAction(object):
        _connection = Connection(None)

# Generated at 2022-06-10 23:16:58.419960
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class MockHostVars(dict):
        def __init__(self):
            super(MockHostVars, self).__init__()
            self['ansible_python_interpreter'] = u'/usr/bin/python'

    class MockAction(object):
        def __init__(self):
            self._connection = MockConnection()
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            return MockLowLevelExecute(sudoable, in_data)

    class MockConnection(object):
        def __init__(self):
            self.has_pipelining = True


# Generated at 2022-06-10 23:17:07.649436
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = dict()
    action['_discovery_warnings'] = []
    action['_low_level_execute_command'] = _test_execute_command
    action['_connection'] = dict()

    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict()
    task_vars['inventory_hostname'] = 'test'
    task_vars['ansible_python_interpreter'] = '/bin/python2.7'
    task_vars['ansible_connection'] = 'local'

    # Test failing to find a python interpreter

# Generated at 2022-06-10 23:17:10.251538
# Unit test for function discover_interpreter
def test_discover_interpreter():

    test_1 = discover_interpreter(None, "python@2", "auto", dict())
    assert test_1 == "/usr/bin/python"


# Generated at 2022-06-10 23:17:21.988673
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test for minimum required python version
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common._collections_compat import Mapping
    import sys
    pyver = sys.version_info

    if not (pyver[0], pyver[1]) >= (2, 7):
        raise Exception('ERROR: interpreter_discovery requires at least Python 2.7')

    action = MockModuleAction(False)
    task_vars = {
        'ansible_python_interpreter': None,
        'ansible_connection': 'local'
    }

    # test for argument error

# Generated at 2022-06-10 23:17:32.300745
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Action(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = Connection()

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == 'command -v python':
                return dict(stdout='/usr/bin/python')
            elif cmd == 'command -v python3':
                return dict(stdout='/usr/bin/python3')

# Generated at 2022-06-10 23:17:44.024340
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult

    def _low_level_execute_command(interpreter, sudoable=False, in_data=None):
        # type: (Text, bool, Optional[Text]) -> TaskResult
        if in_data is None:
            raise AssertionError('Interpreter discovery bootstrap script not found')
        if sudoable:
            raise AssertionError('Interpreter discovery bootstrap script should not have been sudoable')

        # the idea here is we should feed this a path to a script on the target, and it should return the
        # version/etc. info we need to map the target to a Python interpreter, or raise an exception if
        # that script isn't present/executable or not running it is a fatal error.

        platform = 'linux'
        distro = 'centos'


# Generated at 2022-06-10 23:17:53.756144
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Interpreter discovery only supported for Python, at present
    interpreter_name = 'python'

    # We don't have a host connection object here, so we need to mock one.
    class HostConnection:

        def __init__(self, has_pipelining):
            self._has_pipelining = has_pipelining

        def has_pipelining(self):
            return self._has_pipelining

    # We don't have a host Action object or Task here, so we need to mock them.
    class HostAction:

        def __init__(self):
            self._discovery_warnings = []

        def _discovery_warning(self):
            return self._discovery_warnings

    # We don't have a host TaskVars object here, so we need to mock it.

# Generated at 2022-06-10 23:18:04.867089
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.action_plugin import ActionModule
    from ansible.plugins.action import ActionBase
    # test discovery with a fake connection
    test_host = 'fake_host'
    test_data = 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'

    # dummy with discovery on
    discovery_mode = 'auto_legacy_silent'
    ac = ConnectionForTest(has_pipelining=True, test_data=test_data.encode('utf-8'))
    action = ActionModule({}, task_vars={}, connection=ac)
    res = discover_interpreter(action, 'python', discovery_mode, {})
    assert res == '/usr/bin/python'

    # test with discovery off
    discovery_mode = 'off'


# Generated at 2022-06-10 23:18:15.902400
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class Action(object):
        def __init__(self):
            self.connection = Connection()
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            if "uname" in args[0]:
                return {'rc': 0, 'stdout': 'Darwin', 'stderr': ''}
            elif "command -v" in args[0]:
                return {'rc': 0, 'stdout': '/usr/bin/python\n/usr/bin/python2.7\n/usr/bin/python2.7.2\n/usr/bin/python2.7.12\n/usr/bin/python2.7.15\n/usr/bin/python3\n', 'stderr': ''}

# Generated at 2022-06-10 23:19:06.710325
# Unit test for function discover_interpreter
def test_discover_interpreter():
    res = discover_interpreter(None, 'python', 'auto', None)
    print(res)

# Generated at 2022-06-10 23:19:13.738538
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import json
    import os
    import pkgutil

    # Create a dummy AnsibleAction object and then update it with what we need
    class AnsibleAction(object):
        def __init__(self):
            self.become_user = None
            self.become_method = None
            self.become = False
            self.become_pass = None
            self.become_exe = None
            self.become_flags = None

    aa = AnsibleAction()

    # TODO: figure out a good way to mock out _run_shell() but still have the low-level command execute
    # a sample of how to use _run_shell() is in the test for shell.py
    # aa._run_shell = mock.Mock(return_value=dict(code=0, rc=0, stdout='fo

# Generated at 2022-06-10 23:19:24.042936
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.copy import ActionModule as CopyModule

    dm_strategies = [u'auto_legacy', u'explicit_auto_legacy']
    for dm in dm_strategies:
        tr = TaskResult(host=u'localhost')
        ctx = PlayContext()
        ctx.connection = 'local'
        ctx.become = None
        ctx.become_method = None
        ctx.become_user = 'test_become_user'
        ctx.remote_addr = '127.0.0.1'
        ctx.remote_user = 'test_remote_user'
        ctx._prefix = None
       

# Generated at 2022-06-10 23:19:35.665112
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockTask:
        def __init__(self):
            self.connection = None

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            return {'stdout': cmd}

        def set_connection(self, conn):
            self.connection = conn

        def get_connection(self):
            return self.connection

    class MockConnection:
        def __init__(self, has_pipelining=False):
            self.has_pipelining = has_pipelining

    task = MockTask()
    task.connection = MockConnection()

# Generated at 2022-06-10 23:19:45.029905
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager

    context = PlayContext()
    action_base = ActionBase()
    variable_manager = VariableManager()

    def _get_connection_connection(self, *args, **kwargs):
        raise NotImplementedError

    action_base._get_connection = _get_connection_connection
    action_base._low_level_execute_command = _get_connection_connection
    action_base.connection = None

    action_base.task_vars = dict()
    action_base.task_vars['ansible_python_interpreter'] = 'python'
    action_base.context = context

    # Test 1
    # test os_linux
    # call pl

# Generated at 2022-06-10 23:19:54.313104
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule

    # Test for all possible discovery modes for 'python'
    for mode in ['auto', 'auto_legacy', 'auto_silent', 'auto_legacy_silent']:
        action = ActionModule(play_context=None, play_context=dict(interpreter_discovery_mode=mode), task_vars={})
        assert discover_interpreter(action, 'python', mode, dict(inventory_hostname='test_hostname', ansible_host="unknown")) is not None

# Generated at 2022-06-10 23:20:02.226317
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import action_loader

    my_collection = AnsibleCollectionLoader(None).load_collections(['ansible_test_test'])
    assert isinstance(my_collection, dict), my_collection
    assert 'test' in my_collection, my_collection
    assert isinstance(my_collection['test'], dict), my_collection['test']
    assert 'my_module' in my_collection['test'], my_collection['test']
    assert isinstance(my_collection['test']['my_module'], dict), my_collection['test']['my_module']
    my_action = action_loader.get('test.my_module', my_collection['test'])


# Generated at 2022-06-10 23:20:04.204309
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'

# Generated at 2022-06-10 23:20:17.006827
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Variables needed to run discover_interpreter
    playbook_path = './test_playbook.yml'
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-10 23:20:20.062897
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor

    assert discover_interpreter(TaskExecutor(None, dict()), 'python', 'auto_legacy', dict()) == u'/usr/bin/python'

# Generated at 2022-06-10 23:21:32.679989
# Unit test for function discover_interpreter
def test_discover_interpreter():
    display = Display()
    display.verbosity = 4

    # Force host to be a testing host.
    task_vars = {"inventory_hostname": "testing_host"}

    # Force config to have the path to a specific interpreter
    interpreter_path = "python3"
    C.config.set_config_value("INTERPRETER_PYTHON_DISTRO_MAP", {"python3": {"testing_version": interpreter_path}}, variables=task_vars)

    # Force config to have the path to a specific interpreter
    interpreter_bootstrap = "python3"
    C.config.set_config_value("INTERPRETER_PYTHON_FALLBACK", bootstrap_python_list=[interpreter_bootstrap], variables=task_vars)

    # Create an action object to be used in the test
    action

# Generated at 2022-06-10 23:21:45.502552
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Ensure no exceptions with some basic input

    from ansible.module_utils.common.collections import ImmutableDict
    try:
        discover_interpreter(None, None, None, ImmutableDict(foo=1))
    except Exception as e:
        assert False

    # Test ValueError
    try:
        discover_interpreter(None, 'foo', None, ImmutableDict(foo=1))
    except ValueError:
        pass
    except Exception as e:
        assert False

    # Test NotImplementedError
    try:
        discover_interpreter(None, None, 'foo', ImmutableDict(foo=1))
    except NotImplementedError:
        pass
    except Exception as e:
        assert False

    # Test expected

# Generated at 2022-06-10 23:21:55.971062
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic
    from ansible.parsing.plugin_docs import read_docstring

    # Load test module
    data = pkgutil.get_data('ansible.executor.discovery', 'python_target.py')
    _, _, doc, _, _, _ = read_docstring(data)
    module_args = basic._load_params(doc)

    # We can't use the main action class here; we're just testing to see if the module produces the right output
    # TODO: get access to action_main and run it directly?
    class MockAction:
        def __init__(self):
            self._discovery_warnings = []


# Generated at 2022-06-10 23:22:03.240214
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockActionModule:

        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            res = dict(stdout=cmd, stderr=u'stderr')
            if 'command' in cmd:
                if cmd == "command -v 'python3'":
                    res = dict(stdout=u'/usr/bin/python3\n/usr/bin/python\n', stderr=u'stderr')
                if cmd == "command -v 'python2'":
                    res = dict(stdout=u'/usr/bin/python2\n/usr/bin/python\n', stderr=u'stderr')

# Generated at 2022-06-10 23:22:14.961133
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    import os

    # Set the hostname
    host_name = 'localhost'

    # Create tasks & result objects
    task_result = TaskResult(host_name, 'discover_interpreter')
    task_queue_manager = TaskQueueManager()

    # Create the inventory
    loader = DataLoader()
    options = task_queue_manager.options

# Generated at 2022-06-10 23:22:20.533919
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule, EnvironmentError

    task_vars = ImmutableDict(inventory_hostname='test_host')

    class MockAction(object):
        def __init__(self):
            self.connection = MockConnection()
            self.task_vars = task_vars
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, **kwargs):
            return self.connection.execute(cmd)

    class MockConnection(object):
        def __init__(self):
            self.has_pipelining = True


# Generated at 2022-06-10 23:22:28.441790
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest

    class _TestAction(object):
        _low_level_execute_command = None
        _connection = None

        def __init__(self):
            self._discovery_warnings = []

        def _ll_execute_command(self, *args, **kwargs):
            return self._low_level_execute_command(*args, **kwargs)

    def _test_bootstrap(bootstrap, expected_output, expected_platform_type, expected_found, expected_warnings=None):
        action = _TestAction()
        task_vars = {}

        class _TestConnection(object):
            def __init__(self):
                self.has_pipelining = True

        class _TestExecutor(object):
            def __init__(self):
                self._connection = _TestConnection()
