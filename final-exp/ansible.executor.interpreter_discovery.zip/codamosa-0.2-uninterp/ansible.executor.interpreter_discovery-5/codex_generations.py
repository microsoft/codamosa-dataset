

# Generated at 2022-06-16 20:54:57.366734
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.os_release
    import ansible.module_utils.facts.system.pkg_mgr

    # mock out the low-level execute command
    def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
        if cmd.startswith('command -v'):
            return dict(stdout=u'/usr/bin/python\n/usr/bin/python3\n')

# Generated at 2022-06-16 20:55:09.018178
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.connection import ConnectionBase

# Generated at 2022-06-16 20:55:16.944812
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import DebianDistribution
    from ansible.module_utils.facts.system.distribution import AlpineLinuxDistribution
    from ansible.module_utils.facts.system.distribution import OracleLinuxDistribution
    from ansible.module_utils.facts.system.distribution import FedoraDistribution
    from ansible.module_utils.facts.system.distribution import GentooDistribution

# Generated at 2022-06-16 20:55:25.829252
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            if cmd == 'command -v /usr/bin/python':
                return {'stdout': '/usr/bin/python'}
            elif cmd == 'command -v /usr/bin/python3':
                return {'stdout': '/usr/bin/python3'}
            elif cmd == '/usr/bin/python':
                return {'stdout': '{"platform_dist_result": ["centos", "7.4.1708", "Core"]}'}

# Generated at 2022-06-16 20:55:39.213040
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test for the case where the interpreter is not python
    try:
        discover_interpreter(None, 'perl', 'auto', None)
    except ValueError as e:
        assert e.message == 'Interpreter discovery not supported for perl'

    # Test for the case where the platform is not linux
    try:
        discover_interpreter(None, 'python', 'auto', {'inventory_hostname': 'unknown',
                                                      'config': {'get_config_value': lambda x, y: {'darwin': '/usr/bin/python'}[x]}})
    except NotImplementedError as e:
        assert e.message == 'unsupported platform for extended discovery: unknown'

    # Test for the case where the platform is linux but the distro is not supported

# Generated at 2022-06-16 20:55:51.258709
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.plugins.connection.local import Connection as LocalConnection

    class TestAction(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            if cmd == "command -v 'python'":
                return ImmutableDict(dict(stdout=to_bytes("/usr/bin/python\n/usr/bin/python3\n")))

# Generated at 2022-06-16 20:55:52.218393
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests for this function
    pass

# Generated at 2022-06-16 20:56:01.118794
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.module_utils.common.collections import ImmutableDict

# Generated at 2022-06-16 20:56:05.922949
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import StringIO
    import sys

    # Mock the _low_level_execute_command function
    def mock_execute_command(cmd, sudoable=False, in_data=None):
        if cmd == "command -v 'python'":
            return {'stdout': u'/usr/bin/python\n/usr/bin/python3\n', 'stderr': u'', 'rc': 0, 'start': 0, 'end': 0, 'delta': 0}

# Generated at 2022-06-16 20:56:16.897595
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.role.requirement import RoleRequirement

# Generated at 2022-06-16 20:56:31.892048
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-16 20:56:42.792532
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader

    class TestTaskExecutor(TaskExecutor):
        def __init__(self, host, task, task_vars=dict(), wrap_async=False):
            self._host = host
            self._task = task
            self._task_vars = task_vars
            self._wrap_async = wrap_async
            self._discovery_warnings = []


# Generated at 2022-06-16 20:57:23.758604
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.action_result import ActionResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-16 20:57:29.732969
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery
    import ansible.executor.task_result
    import ansible.executor.action_result
    import ansible.executor.module_common
    import ansible.executor.module_loader
    import ansible.executor.play_iterator
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.role.definition
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.connection
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.callback
    import ansible.plugins.cache
    import ansible.plugins.lookup

# Generated at 2022-06-16 20:57:41.786540
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class FakeOptions(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 10
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = False
            self.diff = False
            self.listhosts = None
            self

# Generated at 2022-06-16 20:57:52.967307
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-16 20:58:05.778166
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None, executable=None):
            if cmd == "command -v 'python'":
                return {'stdout': u'/usr/bin/python'}
            elif cmd == "command -v 'python3'":
                return {'stdout': u'/usr/bin/python3'}
            elif cmd == "/usr/bin/python":
                return {'stdout': json.dumps({'platform_dist_result': ['', '', ''], 'osrelease_content': 'ID=debian\nVERSION_ID=8.0'})}

# Generated at 2022-06-16 20:58:14.630492
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_facts
    from ansible.utils.vars import combine_vars_hash
    from ansible.utils.vars import combine_vars_facts
    from ansible.utils.vars import combine_vars_facts_hash
   

# Generated at 2022-06-16 20:58:27.558886
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.vars.manager import VariableManager

    class ActionModule(_ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(ActionModule, self).run(tmp, task_vars)

    class TestTaskQueueManager(TaskQueueManager):
        def _final_qc(self):
            return True


# Generated at 2022-06-16 20:58:39.449583
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader

    class TestAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return TaskResult(host=self._play_context.remote_addr, task=self._task, result=dict(changed=False))

    action_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)
    action_loader.add_directory(C.DEFAULT_ACTION_INCLUDE_PATH)

# Generated at 2022-06-16 20:59:05.176430
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-16 20:59:14.196220
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
   

# Generated at 2022-06-16 20:59:25.444160
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.task_include import TaskInclude
   

# Generated at 2022-06-16 20:59:28.253140
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests
    pass

# Generated at 2022-06-16 20:59:40.342634
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-16 20:59:52.205147
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test for function _version_fuzzy_match
    version_map = {'1.0': '/usr/bin/python1.0', '2.0': '/usr/bin/python2.0', '3.0': '/usr/bin/python3.0'}
    assert _version_fuzzy_match('1.0', version_map) == '/usr/bin/python1.0'
    assert _version_fuzzy_match('2.0', version_map) == '/usr/bin/python2.0'
    assert _version_fuzzy_match('3.0', version_map) == '/usr/bin/python3.0'
    assert _version_fuzzy_match('0.9', version_map) == '/usr/bin/python1.0'
    assert _version_fuzzy

# Generated at 2022-06-16 21:00:00.186549
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-16 21:00:09.669840
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.normal import ActionModule as _ActionModule

    class ActionModule(_ActionModule):
        def _execute_module(self, tmp=None, task_vars=None):
            return dict(failed=False, changed=False, msg=u'OK')

    class Connection(object):
        def __init__(self, has_pipelining=True):
            self.has_pipelining = has_pipelining

    class Task(object):
        def __init__(self, action, task_vars):
            self.action = action
            self.task_vars = task_vars

    class PlayContext(object):
        def __init__(self, connection):
            self.connection = connection


# Generated at 2022-06-16 21:00:21.771241
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import V

# Generated at 2022-06-16 21:00:32.990522
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.plugins.loader import action_loader
    from ansible.plugins.connection.local import Connection as LocalConnection
    from ansible.plugins.connection.ssh import Connection as SSHConnection
    from ansible.plugins.connection.winrm import Connection

# Generated at 2022-06-16 21:01:15.705728
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.manager import Variable

# Generated at 2022-06-16 21:01:23.177045
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.module_utils.connection import ConnectionBase

    class ActionModule(_ActionModule):
        def _execute_module(self, tmp=None, task_vars=None, persist_files=True):
            return dict(changed=False, ansible_facts=dict())

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None, executable=None):
            if cmd == "command -v 'python'":
                return dict(stdout="/usr/bin/python\n/usr/bin/python3", stderr="")

# Generated at 2022-06-16 21:01:24.794346
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: write unit tests
    pass

# Generated at 2022-06-16 21:01:37.238840
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action import ActionBase

    class ActionModule(_ActionModule, ActionBase):
        def _execute_module(self, tmp=None, task_vars=None, persist_files=True):
            return dict(changed=False, msg=u'', ansible_facts=dict())

    action = ActionModule(task=dict(action=dict()), connection=None, play_context=None, loader=None, templar=None,
                          shared_loader_obj=None)
    action._discovery_warnings = []

    # test for a known platform

# Generated at 2022-06-16 21:01:50.946543
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY2

    task_vars = ImmutableDict({
        'inventory_hostname': 'localhost',
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_connection': 'local',
        'ansible_python_interpreter_discovery_mode': 'auto_legacy_silent',
        'ansible_python_interpreter_discovery_warnings': [],
        'ansible_python_interpreter_discovery_result': None,
        'ansible_python_interpreter_discovery_failed': False,
        'ansible_python_interpreter_discovery_unhandled_failure': False,
    })


# Generated at 2022-06-16 21:01:58.805479
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class TestAction(object):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader


# Generated at 2022-06-16 21:02:10.692260
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_plugin import BecomePlugin
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.role.include import RoleInclude


# Generated at 2022-06-16 21:02:11.629323
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests
    pass

# Generated at 2022-06-16 21:02:23.481815
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class TestAction(ActionBase):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(TestAction, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self._discovery_warnings = []


# Generated at 2022-06-16 21:02:36.370393
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars

# Generated at 2022-06-16 21:03:56.768467
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-16 21:04:08.816651
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import DebianDistribution
    from ansible.module_utils.facts.system.distribution import AlpineDistribution
    from ansible.module_utils.facts.system.distribution import AmazonDistribution
    from ansible.module_utils.facts.system.distribution import OracleLinuxDistribution
    from ansible.module_utils.facts.system.distribution import Fedora

# Generated at 2022-06-16 21:04:19.472682
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.connection import Connection
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        def __init__(self, connection, *args, **kwargs):
            self._connection = connection
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == "command -v 'python'":
                return {'stdout': to_bytes("/usr/bin/python")}

# Generated at 2022-06-16 21:04:31.626271
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator

    class TestAction(ActionBase):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(TestAction, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None, executable=None):
            if cmd == 'command -v /usr/bin/python':
                return {'stdout': '/usr/bin/python'}