

# Generated at 2022-06-16 20:54:55.922712
# Unit test for function discover_interpreter

# Generated at 2022-06-16 20:55:03.604861
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

# Generated at 2022-06-16 20:55:11.973437
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == 'command -v python':
                return {'stdout': '/usr/bin/python'}
            elif cmd == '/usr/bin/python':
                return {'stdout': to_bytes(json.dumps({'platform_dist_result': ['debian', '9.4', 'stretch']}))}
            elif cmd == 'command -v python3':
                return {'stdout': '/usr/bin/python3'}
            el

# Generated at 2022-06-16 20:55:22.085512
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-16 20:55:30.513576
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-16 20:55:43.696029
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess

# Generated at 2022-06-16 20:55:53.754443
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskIn

# Generated at 2022-06-16 20:56:02.123534
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six import PY3

    class FakeAction(object):
        def __init__(self):
            self._connection = Connection()
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == "command -v 'python'":
                return {'stdout': '/usr/bin/python'}
            elif cmd == "command -v 'python3'":
                return {'stdout': '/usr/bin/python3'}

# Generated at 2022-06-16 20:56:08.946902
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes

    # test_discover_interpreter_basic
    # test_discover_interpreter_basic_no_python
    # test_discover_interpreter_basic_no_python_silent
    # test_discover_interpreter_basic_no_python_legacy
    # test_discover_interpreter_basic_no_python_legacy_silent
    # test_discover_interpreter_basic_no_python_legacy_silent_no_warn
    # test_discover_interpreter_basic_no_python_legacy_silent_no_warn_no_python
    # test

# Generated at 2022-06-16 20:56:18.461186
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == 'command -v /usr/bin/python':
                return ImmutableDict(dict(stdout='/usr/bin/python'))
            elif cmd == 'command -v /usr/bin/python3':
                return ImmutableDict(dict(stdout='/usr/bin/python3'))

# Generated at 2022-06-16 20:56:37.873123
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become

# Generated at 2022-06-16 20:56:54.740872
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import lookup

# Generated at 2022-06-16 20:57:04.564813
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    module = AnsibleModule(
        argument_spec=dict(
            interpreter_name=dict(type='str', required=True),
            discovery_mode=dict(type='str', required=True),
            task_vars=dict(type='dict', required=True),
        ),
        supports_check_mode=True,
    )

    # mock the connection
    connection = Connection(module._socket_path)
    connection.has_pipelining = True
    module._connection = connection

    # mock the action

# Generated at 2022-06-16 20:57:11.319091
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-16 20:57:22.275609
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action.normal import ActionModule as _ActionModule


# Generated at 2022-06-16 20:57:33.568632
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.connection.local import Connection
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class MockAction(object):
        def __init__(self, action_name):
            self._name = action_name
            self._connection = Connection()

# Generated at 2022-06-16 20:57:39.798999
# Unit test for function discover_interpreter

# Generated at 2022-06-16 20:57:51.727731
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader

    class TestAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return TaskResult(dict(changed=False, failed=False, rc=0, stdout='', stderr=''))

    action = TestAction(action_loader, 'test', {}, {})
    task_vars = dict()
    result = discover_interpreter(action, 'python', 'auto', task_vars)
    assert result == '/usr/bin/python'

    result = discover_interpreter(action, 'python', 'auto_legacy', task_vars)
    assert result == '/usr/bin/python'

    result

# Generated at 2022-06-16 20:58:04.250309
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryLegacy
    from ansible.module_utils.facts.system.distribution import LinuxDistributionLegacy
    from ansible.module_utils.facts.system.distribution import LinuxDistributionLegacyFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionLegacyFactoryLegacy
    from ansible.module_utils.facts.system.distribution import LinuxDistributionLegacyLegacy
    from ansible.module_utils.facts.system.distribution import LinuxDistributionLeg

# Generated at 2022-06-16 20:58:13.895200
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-16 20:58:44.590265
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native


# Generated at 2022-06-16 20:58:57.533590
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    class MockAction(object):
        def __init__(self, action_name, task_vars):
            self._discovery_warnings = []
            self._connection = MockConnection()
            self._task = MockTask(action_name, task_vars)
            self._loader = DataLoader()
            self._templar = None


# Generated at 2022-06-16 20:59:06.592313
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryRedHat
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactorySuse
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryDebian
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryAlpine
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryArch
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryGentoo

# Generated at 2022-06-16 20:59:15.902348
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-16 20:59:26.335976
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs


# Generated at 2022-06-16 20:59:39.731775
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task.include import Include

# Generated at 2022-06-16 20:59:51.637753
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    class TestAction(object):
        def __init__(self, action_name):
            self.action_name = action_name
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == 'command -v /usr/bin/python':
                return {'stdout': '/usr/bin/python'}

# Generated at 2022-06-16 20:59:59.743638
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
   

# Generated at 2022-06-16 21:00:08.856570
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser


# Generated at 2022-06-16 21:00:21.345934
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    class TestAction(object):
        def __init__(self):
            self._discovery_warnings = []
            self._connection = None
            self._low_level_execute_command = None

    class TestConnection(object):
        def __init__(self):
            self.has_pipelining = True

    class TestTaskResult(TaskResult):
        def __init__(self):
            self._result

# Generated at 2022-06-16 21:01:12.432806
# Unit test for function discover_interpreter

# Generated at 2022-06-16 21:01:21.593801
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter

# Generated at 2022-06-16 21:01:35.612476
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class MockAction(object):
        def __init__(self, action_name, action_args, action_loader, task_vars):
            self._name = action_name
            self._args = action_args
            self._loader = action_loader

# Generated at 2022-06-16 21:01:41.867975
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.module_utils.connection import Connection
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-16 21:01:53.642145
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_facts
    from ansible.utils.vars import combine_vars_hash
    from ansible.utils.vars import combine_vars_facts

# Generated at 2022-06-16 21:02:06.656062
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-16 21:02:11.416175
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-16 21:02:23.319483
# Unit test for function discover_interpreter

# Generated at 2022-06-16 21:02:29.696776
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFallback
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryRedHat
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactorySuse
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryDebian
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryAlpine
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryArch


# Generated at 2022-06-16 21:02:39.471149
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    action = action_loader.get('shell', task=dict(action='shell'))
    action._shared_loader_obj = action_loader
    action._connection = None
    action._task = None
    action._low_level_execute_command = lambda *args, **kwargs: TaskResult(host=None, return_data=dict(stdout='', stderr=''))
    action._discovery_warnings = []


# Generated at 2022-06-16 21:04:11.771447
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-16 21:04:17.762955
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager as _TaskQueueManager

    class ActionModule(_ActionModule):
        def _execute_module(self, tmp=None, task_vars=None, **kwargs):
            return dict(changed=False, ansible_facts=dict(platform_type='Linux',
                                                          platform_dist_result=['Ubuntu', '14.04', 'trusty'],
                                                          osrelease_content=''))


# Generated at 2022-06-16 21:04:28.017305
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action.normal import ActionModule as _ActionModule

    class ActionModule(_ActionModule):
        def _execute_module(self):
            return dict(changed=False, msg='', ansible_facts=dict())

    class Connection(Connection):
        def __init__(self, *args, **kwargs):
            self._has_pipelining = True

# Generated at 2022-06-16 21:04:36.574042
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.config import NetworkConfig, dumps
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser