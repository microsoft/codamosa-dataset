

# Generated at 2022-06-16 20:54:54.460845
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-16 20:55:02.827810
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-16 20:55:07.679119
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=False, in_data=None):
            if cmd == 'command -v python':
                return {'stdout': u'/usr/bin/python'}
            elif cmd == 'command -v python2':
                return {'stdout': u'/usr/bin/python2'}
            elif cmd == 'command -v python3':
                return {'stdout': u'/usr/bin/python3'}
            elif cmd == '/usr/bin/python':
                return {'stdout': u'{"platform_dist_result": ["redhat", "7.3", "Maipo"]}'}

# Generated at 2022-06-16 20:55:18.121183
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-16 20:55:28.133384
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.module_utils.connection import Connection

# Generated at 2022-06-16 20:55:40.400652
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    def _execute_module(module_name=None, module_args=None, task_vars=None):
        if not module_name:
            module_name = 'ping'
        if not module_args:
            module_args = {}
        if not task_vars:
            task_vars = dict(inventory_hostname='testhost')

        module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
        )

        module.params = module_args

        connection = Connection(module._socket_path)
        connection.set_module_name(module_name)
        connection.set_task_uuid('test_task_uuid')
        connection.set

# Generated at 2022-06-16 20:55:52.146862
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.plugins.connection import ConnectionBase

    class TestAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(TestAction, self).run(tmp, task_vars)

    class TestConnection(ConnectionBase):
        def __init__(self, play_context, new_stdin, *args, **kwargs):
            super(TestConnection, self).__init__(play_context, new_stdin, *args, **kwargs)
            self._has_

# Generated at 2022-06-16 20:56:01.085814
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class TestTaskQueueManager(TaskQueueManager):
        def __init__(self, *args, **kwargs):
            super(TestTaskQueueManager, self).__init__(*args, **kwargs)
            self._unreachable_hosts = []

# Generated at 2022-06-16 20:56:08.240952
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryRedHat
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryDebian
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactorySuse
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryAlpine
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryArch

# Generated at 2022-06-16 20:56:16.261515
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager

    class TestAction(ActionBase):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(TestAction, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self._discovery_warnings = []


# Generated at 2022-06-16 20:56:35.387636
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryRedHat
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryDebian
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactorySuse
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryAlpine
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryArch
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryGentoo

# Generated at 2022-06-16 20:56:35.901456
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: test with a mock action
    pass

# Generated at 2022-06-16 20:57:16.500997
# Unit test for function discover_interpreter

# Generated at 2022-06-16 20:57:24.931558
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
   

# Generated at 2022-06-16 20:57:35.473787
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-16 20:57:48.961476
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude

# Generated at 2022-06-16 20:57:56.658058
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector


# Generated at 2022-06-16 20:58:04.351334
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add tests for all the error cases
    # TODO: add tests for the warning cases
    # TODO: add tests for the legacy cases
    # TODO: add tests for the silent cases
    # TODO: add tests for the pipelining cases
    # TODO: add tests for the non-pipelining cases
    # TODO: add tests for the on-disk cases
    # TODO: add tests for the non-Linux cases
    # TODO: add tests for the non-Python cases
    pass

# Generated at 2022-06-16 20:58:13.997911
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-16 20:58:26.281450
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import ModuleCommon
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.normal import ActionModule as NormalActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-16 20:58:54.095065
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-16 20:59:03.188519
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.inventory.yaml import InventoryYAMLParser

# Generated at 2022-06-16 20:59:12.861277
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser

# Generated at 2022-06-16 20:59:24.866058
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_

# Generated at 2022-06-16 20:59:39.071770
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
   

# Generated at 2022-06-16 20:59:51.335571
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-16 21:00:03.070336
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return TaskResult(host=self._play_context.remote_addr,
                              return_data=dict(failed=False,
                                               changed=False,
                                               msg="test"))


# Generated at 2022-06-16 21:00:12.790137
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.plugins.connection.local import Connection as LocalConnection
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
   

# Generated at 2022-06-16 21:00:22.935420
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action import ActionBase

    class ActionModule(_ActionModule, ActionBase):
        def _execute_module(self, tmp=None, task_vars=None, persist_files=True):
            return dict(
                changed=False,
                ansible_facts=dict(
                    ansible_python_interpreter=self._task.args.get('interpreter')
                )
            )

    class Connection(object):
        def __init__(self, has_pipelining=True):
            self

# Generated at 2022-06-16 21:00:33.764296
# Unit test for function discover_interpreter

# Generated at 2022-06-16 21:01:15.788375
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-16 21:01:26.761315
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    module = AnsibleModule(
        argument_spec=dict(
            discovery_mode=dict(type='str', default='auto_legacy_silent'),
            interpreter_name=dict(type='str', default='python'),
        ),
    )

    # TODO: mock out the connection and action objects
    connection = Connection(module._socket_path)
    action = connection._create_action()

    task_vars = dict()
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    task_vars['ansible_python_interpreter_discovery_mode'] = 'auto_legacy_silent'

    # TODO: mock out the connection and action objects

# Generated at 2022-06-16 21:01:37.931064
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
   

# Generated at 2022-06-16 21:01:51.605066
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action.script import ActionModule as ScriptActionModule
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.plugins.action.template import ActionModule as TemplateActionModule

    class MockActionModule(object):
        def __init__(self, action_name):
            self._connection = MockConnection()
            self._task = MockTask(action_name)
            self._play_context = MockPlayContext()
            self._loader = MockLoader()
            self._templar = MockTemplar()
            self._shared_loader_obj = MockLoader()
            self._task_vars = dict(inventory_hostname='localhost', ansible_python_interpreter='/usr/bin/python')
            self._discovery

# Generated at 2022-06-16 21:01:59.214158
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-16 21:02:11.025425
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-16 21:02:22.982367
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFallback
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryRedhat
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactorySuse
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryDebian
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryAlpine

# Generated at 2022-06-16 21:02:29.228142
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils.connection import Connection
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.display import Display

# Generated at 2022-06-16 21:02:39.341595
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-16 21:02:48.694744
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-16 21:04:14.701181
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_plugin import BecomePlugin
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_all_plugins
    from ansible.plugins.loader import get_all_plugin

# Generated at 2022-06-16 21:04:26.796579
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader

    class TestAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(TestAction, self).run(tmp, task_vars)

    action_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)
    action = action_loader.get('test', class_only=True)
    action = action()
    action.connection = None
    action._task = ImmutableDict({'args': {'interpreter': 'python'}})

# Generated at 2022-06-16 21:04:35.956392
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager