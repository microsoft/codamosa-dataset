

# Generated at 2022-06-16 20:54:57.086731
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action.normal import ActionBase as _ActionBase
    from ansible.plugins.action import ActionModule as _ActionModule
    from ansible.plugins.action import ActionBase as _ActionBase

    class ActionModule(_ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(ActionModule, self).run(tmp, task_vars)

    class ActionBase(_ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(ActionBase, self).run(tmp, task_vars)

    class Connection(object):
        def __init__(self, has_pipelining=True):
            self._has_pipelining = has_pipelining



# Generated at 2022-06-16 20:54:58.131674
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests
    pass

# Generated at 2022-06-16 20:55:09.101208
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    class FakeConnection(object):
        def __init__(self, has_pipelining):
            self.has_pipelining = has_pipelining

    class FakeAction(object):
        def __init__(self, connection, task_vars):
            self._connection = connection
            self._task_vars = task_vars
            self._discovery_warnings = []


# Generated at 2022-06-16 20:55:17.008036
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.process.worker import WorkerProcess

# Generated at 2022-06-16 20:55:25.247597
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import configparser

# Generated at 2022-06-16 20:55:30.680727
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel


# Generated at 2022-06-16 20:55:31.960151
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests
    pass

# Generated at 2022-06-16 20:55:45.081418
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.module_utils.connection import ConnectionBase
   

# Generated at 2022-06-16 20:55:46.167155
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests
    pass

# Generated at 2022-06-16 20:55:55.316554
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.host import Host

# Generated at 2022-06-16 20:56:15.385582
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.path import PathFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

# Generated at 2022-06-16 20:56:19.746936
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-16 20:56:31.576374
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    import os
    import tempfile
    import shutil
    import sys


# Generated at 2022-06-16 20:57:09.495017
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_vars_hash

# Generated at 2022-06-16 20:57:18.247016
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.args = args

    class FakeConnection(Connection):
        def __init__(self, *args, **kwargs):
            self.transport = 'local'
            self.become = False
            self.become_method = 'sudo'
            self.become_user = ''
            self.no_log = False
            self.args = args
            self.kwargs = kwargs
            self.has_pipelining = True

# Generated at 2022-06-16 20:57:19.312772
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests for this function
    pass

# Generated at 2022-06-16 20:57:31.438328
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    # Create a task result object
    task_result = TaskResult(host=None, task=None, return_data=dict(invocation=dict(module_args=dict())))

    # Create a play context
    play_context = PlayContext()

    # Create a task queue manager
    task_queue_manager = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None)

    # Create an action plugin

# Generated at 2022-06-16 20:57:43.778553
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.module_utils.facts.system.distribution import Distribution

# Generated at 2022-06-16 20:57:54.225492
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-16 20:58:06.926667
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 20:58:35.875073
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.connection import Connection
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            if cmd == "command -v 'python'":
                return ImmutableDict(dict(stdout=to_bytes("/usr/bin/python\n")))
            elif cmd == "command -v 'python3'":
                return ImmutableDict(dict(stdout=to_bytes("/usr/bin/python3\n")))
            elif cmd == "/usr/bin/python":
                return

# Generated at 2022-06-16 20:58:47.395502
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryImpl
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImpl
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplRedHat
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplSuse
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplDebian
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplAlpine

# Generated at 2022-06-16 20:58:59.118876
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.role.include import RoleIn

# Generated at 2022-06-16 20:59:11.653126
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    action = action_loader.get('setup', play_context, variable_manager, loader)
    task = Task()

# Generated at 2022-06-16 20:59:23.854677
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import sys
    import tempfile
    import shutil
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.script import ActionModule as ScriptActionModule
    from ansible.plugins.action.raw import ActionModule as RawActionModule
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.plugins.action.template import ActionModule as TemplateActionModule
    from ansible.plugins.action.slurp import ActionModule as SlurpActionModule
    from ansible.plugins.action.unarchive import ActionModule as UnarchiveActionModule

# Generated at 2022-06-16 20:59:30.651861
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.strategy import StrategyBase
   

# Generated at 2022-06-16 20:59:41.739462
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class TestAction(ActionBase):
        def __init__(self, *args, **kwargs):
            self._discovery_warnings = []
            super(TestAction, self).__init__(*args, **kwargs)


# Generated at 2022-06-16 20:59:42.865019
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:59:53.787696
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    class TestAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return TaskResult(host=self._task.host, return_data=dict(changed=False, msg=u'ok'))

    class TestTask(Task):
        def __init__(self, name, action, interpreter, discovery_mode, task_vars):
            self._name = name
            self._action = action
            self._interpreter = interpreter
            self._

# Generated at 2022-06-16 21:00:05.383385
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-16 21:00:42.664753
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests
    pass

# Generated at 2022-06-16 21:00:43.510999
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests for this function
    pass

# Generated at 2022-06-16 21:00:51.355565
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action.normal import ActionModule as ActionModule
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-16 21:00:59.432528
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.module_utils.connection import Connection

# Generated at 2022-06-16 21:01:05.717513
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

# Generated at 2022-06-16 21:01:14.786236
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.connection import Connection
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader

    class TestAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(TestAction, self).run(tmp, task_vars)

    class TestConnection(Connection):
        def __init__(self, *args, **kwargs):
            super(TestConnection, self).__init__(*args, **kwargs)
            self.has_pipelining = True


# Generated at 2022-06-16 21:01:26.277338
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import action_loader
    from ansible.plugins.connection import ConnectionBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-16 21:01:37.684434
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    from ansible.module_utils.facts.system import distro
    from ansible.module_utils.facts.system import distro_release
    from ansible.module_utils.facts.system import platform
    from ansible.module_utils.facts.system import system

    # Test for discover_interpreter
    # Test for discover_interpreter with discovery_mode = auto
    # Test for discover_interpreter with discovery_mode = auto_legacy
    # Test for discover_interpreter with discovery_mode = auto_silent
    # Test for discover_interpreter with discovery_mode = auto_legacy_silent
    # Test for discover_interpreter with discovery_mode = auto_silent_fail
    # Test for discover_interpreter with discovery

# Generated at 2022-06-16 21:01:51.469054
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_hash


# Generated at 2022-06-16 21:01:59.133814
# Unit test for function discover_interpreter

# Generated at 2022-06-16 21:03:23.531917
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase

# Generated at 2022-06-16 21:03:31.348462
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-16 21:03:33.274115
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests for this
    pass

# Generated at 2022-06-16 21:03:44.596951
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.common._collections_compat import MutableMapping

# Generated at 2022-06-16 21:03:57.046010
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_keys
   

# Generated at 2022-06-16 21:04:09.077414
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-16 21:04:19.524839
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.action_result import ActionResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-16 21:04:31.629401
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager