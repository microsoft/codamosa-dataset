

# Generated at 2022-06-16 20:54:53.676586
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-16 20:55:02.548074
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import Variable

# Generated at 2022-06-16 20:55:11.422079
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution

# Generated at 2022-06-16 20:55:21.666027
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.action import ActionBase

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)

            self._discovery_warnings = []


# Generated at 2022-06-16 20:55:34.307984
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return TaskResult(host=self._play_context.remote_addr,
                              return_data=dict(
                                  stdout=u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND',
                                  stderr=u'',
                                  rc=0,
                                  stdout_lines=[u'PLATFORM', u'Linux', u'FOUND', u'/usr/bin/python', u'ENDFOUND'],
                                  stderr_lines=[],
                              ))

# Generated at 2022-06-16 20:55:47.032280
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-16 20:55:55.815929
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryImpl
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImpl
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplDebian
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplRedHat
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplSuse
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplUnknown

# Generated at 2022-06-16 20:56:00.979095
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-16 20:56:08.149364
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-16 20:56:16.193536
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_facts
    from ansible.utils.vars import combine_vars_hash
    from ansible.utils.vars import combine_vars_facts

# Generated at 2022-06-16 20:56:32.463206
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine

# Generated at 2022-06-16 20:56:54.498725
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test_discover_interpreter_basic
    action = MockAction()
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {'inventory_hostname': 'localhost',
                 'config': {'INTERPRETER_PYTHON_DISTRO_MAP': {'centos': {'7': '/usr/bin/python2'},
                                                             'ubuntu': {'16.04': '/usr/bin/python2'}},
                            'INTERPRETER_PYTHON_FALLBACK': ['/usr/bin/python2', '/usr/bin/python']}}
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res == '/usr/bin/python2'

    # test_discover_inter

# Generated at 2022-06-16 20:57:04.326389
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-16 20:57:22.845903
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-16 20:57:29.064239
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-16 20:57:41.101903
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-16 20:57:51.305487
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.action_result import ActionResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-16 20:58:03.744145
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.action_result import HostActionResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-16 20:58:05.114499
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: write unit tests
    pass

# Generated at 2022-06-16 20:58:14.304875
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.module_utils.connection import Connection

# Generated at 2022-06-16 20:58:45.698853
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_hash_merge
    from ansible.utils.vars import combine_vars_merge
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-16 20:58:58.624926
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.normal import ActionModule as _ActionModule

    class ActionModule(_ActionModule):
        def _execute_module(self, tmp=None, task_vars=None):
            return dict(
                changed=False,
                interpreter=discover_interpreter(self, 'python', 'auto', task_vars),
                warnings=self._discovery_warnings
            )

    class Connection:
        def __init__(self, has_pipelining):
            self._has_pipelining = has_pipelining

        def has_pipelining(self):
            return self._has_pipelining

    class PlayContext:
        def __init__(self, connection):
            self._connection = connection


# Generated at 2022-06-16 20:59:11.152612
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_

# Generated at 2022-06-16 20:59:23.148014
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser

# Generated at 2022-06-16 20:59:30.353475
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-16 20:59:41.549518
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class TestAction(object):
        def __init__(self, task_vars):
            self._task_vars = task_vars
            self._discovery_warnings = []


# Generated at 2022-06-16 20:59:42.670848
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:59:53.791891
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-16 21:00:05.382820
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader

    class TestActionModule(object):
        def __init__(self, action_name, action_args):
            self._action_name = action_name
            self._action_args = action_args
            self._discovery_warnings = []


# Generated at 2022-06-16 21:00:17.223784
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-16 21:01:10.932661
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor


# Generated at 2022-06-16 21:01:20.581834
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.utils.vars import combine_v

# Generated at 2022-06-16 21:01:28.631382
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryLinux
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryLinuxGeneric
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryLinuxRedHat
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryLinuxSuse
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryLinuxUbuntu
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory

# Generated at 2022-06-16 21:01:38.729089
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.executor.discovery
    import ansible.executor.task_executor
    import ansible.module_utils.basic
    import ansible.plugins.action
    import ansible.plugins.loader
    import ansible.plugins.strategy
    import ansible.utils.plugin_docs

    class MockActionModule(ansible.plugins.action.ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(MockActionModule, self).run(tmp, task_vars)

    class MockConnection(object):
        def __init__(self, has_pipelining):
            self._has_pipelining = has_pipelining

        def has_pipelining(self):
            return self._has_pipelining


# Generated at 2022-06-16 21:01:51.871783
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

# Generated at 2022-06-16 21:01:53.286807
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit tests
    pass

# Generated at 2022-06-16 21:02:06.495097
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-16 21:02:15.163027
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser

# Generated at 2022-06-16 21:02:23.753967
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-16 21:02:36.663294
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_list import HandlerTaskList
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-16 21:04:23.920610
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.module_utils.connection import Connection
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.plugins.action import ActionBase

# Generated at 2022-06-16 21:04:32.827666
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.plugins.connection.network_cli import Connection as NetworkCli
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars

    class ActionModule(_ActionModule, ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(ActionModule, self).run(tmp, task_vars)
