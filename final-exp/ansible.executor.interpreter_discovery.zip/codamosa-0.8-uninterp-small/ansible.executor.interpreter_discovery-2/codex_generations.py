

# Generated at 2022-06-24 18:46:46.654416
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:46:50.616472
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test cases are using module boilerplate (in __main__) due to
    # limited access to action, connection and display in unit tests
    # FUTURE: write proper tests
    pass


# Generated at 2022-06-24 18:46:52.628311
# Unit test for function discover_interpreter
def test_discover_interpreter():
    result = discover_interpreter(interpreter_name, discovery_mode, task_vars)
    assert result is None



# Generated at 2022-06-24 18:47:01.427225
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils import basic

    action_0 = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        bypass_checks=False,
    )

    action_1 = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        bypass_checks=False,
    )
    str_0 = 'python'
    str_1 = 'auto'
    str_2 = 'python'
    str_3 = 'auto'
    str_4 = 'auto'
    str_5 = 'python'
    str_6 = 'auto'
    str_7 = 'auto_legacy_silent'
    str_8 = 'auto_silent'
    str_9 = 'auto_legacy'
    str_10

# Generated at 2022-06-24 18:47:02.117238
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True

# Generated at 2022-06-24 18:47:03.459250
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass



# Generated at 2022-06-24 18:47:04.217657
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True


# Generated at 2022-06-24 18:47:11.159714
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import subprocess

    action_0 = subprocess.Popen([], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto'
    task_vars_0 = {'inventory_hostname': 'localhost', 'connection': 'local'}

    # Call function with args
    try:
        result = discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)
    except InterpreterDiscoveryRequiredError:
        pass
    else:
        raise Exception("Unexpected exception")


# Generated at 2022-06-24 18:47:15.671031
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Testcase 0
    from ansible.plugins.action import ActionModule
    action = ActionModule(connection=None,
                          module_name=None,
                          task_vars=None,
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)
    result = discover_interpreter(action, 'python', 'auto', {})


# Generated at 2022-06-24 18:47:20.489653
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # At the moment, I'm not convinced we need to test the discovery code. It should be kept as simple as possible
    # and rely on other components' tests (e.g. script module) for its basic functionality.
    pass



# Generated at 2022-06-24 18:47:32.615420
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Failing test: interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(bytes_0, dict_0, float_0)
    # verify the result for discover_interpreter
    assert True
    # this is to silence pytest and pylint on this function
    assert True

# Generated at 2022-06-24 18:47:40.744971
# Unit test for function discover_interpreter
def test_discover_interpreter():
    lv0 = LooseVersion("2.3.3")
    lv1 = LooseVersion("2.3.3-1")
    lv2 = LooseVersion("2.6.11")
    lv3 = LooseVersion("2.6.12")
    lv4 = LooseVersion("2.6.13")
    lv5 = LooseVersion("2.6.14")
    lv6 = LooseVersion("2.6.15")
    lv7 = LooseVersion("2.6.18")
    lv8 = LooseVersion("2.6.19")
    lv9 = LooseVersion("2.6.20")
    lv10 = LooseVersion("2.6.21")
    lv11 = LooseVersion("2.6.22")

# Generated at 2022-06-24 18:47:41.751359
# Unit test for function discover_interpreter
def test_discover_interpreter():

    test_case_0()

# Generated at 2022-06-24 18:47:54.541402
# Unit test for function discover_interpreter
def test_discover_interpreter():
    bytes_0 = b'\xc5\x86\xdb\xbcxH\x94]\xa6\xd2\xca\x82\xbf`K@\xc8\xc4\xb8'
    dict_0 = {b'\xc5\x86\xdb\xbcxH\x94]\xa6\xd2\xca\x82\xbf`K@\xc8\xc4\xb8': b'\xc5\x86\xdb\xbcxH\x94]\xa6\xd2\xca\x82\xbf`K@\xc8\xc4\xb8'}
    float_0 = 60.0
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(bytes_0, dict_0, float_0)

# Generated at 2022-06-24 18:48:02.495677
# Unit test for function discover_interpreter
def test_discover_interpreter():
    #
    # Expected result:
    #

    from ansible.module_utils.six.moves import cStringIO as StringIO


# Generated at 2022-06-24 18:48:03.226063
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: write this :(
    pass



# Generated at 2022-06-24 18:48:04.324480
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert callable(discover_interpreter)



# Generated at 2022-06-24 18:48:10.076261
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # this test is trivial at best, but it's better than nothing

    action_mock = _ActionMock()
    action_mock._connection._shell = _ShellMock()

    platform_mock = _PlatformMock()

    # The following values will be used as default arguments
    # for the function.
    # test 1
    display.verbosity = display.Verbosity.NORMAL

    try:
        discover_interpreter(action_mock, 'python', 'auto', platform_mock)
    except NotImplementedError:
        pass

    display.verbosity = display.Verbosity.VERBOSE
    # test 2
    display.verbosity = display.Verbosity.VERY_VERBOSE


# Generated at 2022-06-24 18:48:15.529780
# Unit test for function discover_interpreter
def test_discover_interpreter():
    bytes_0 = b'\xc5\x86\xdb\xbcxH\x94]\xa6\xd2\xca\x82\xbf`K@\xc8\xc4\xb8'
    dict_0 = {bytes_0: bytes_0}
    float_0 = 60.0
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(bytes_0, dict_0, float_0)
    action_0 = 15 == 15
    assert isinstance(discover_interpreter(action_0, 'adsl_router'), int)


# Generated at 2022-06-24 18:48:22.065557
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockAction():
        def __init__(self):
            self._discovery_warnings = []
            self._connection = MockConnection()
        def _low_level_execute_command(self, arg_0, arg_1, arg_2=None, arg_3=None, arg_4=None, arg_5=None):
            return {u'stdout': ''}
    assert discover_interpreter(MockAction(), 'python', 'auto', dict()) == u'/usr/bin/python'


# Generated at 2022-06-24 18:48:44.150381
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Construct args
    action = None
    interpreter_name = b'python'
    discovery_mode = b'auto'
    task_vars = None

    # Invoke method
    discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

# Generated at 2022-06-24 18:48:55.026248
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host = 'localhost'
    res_0 = None
    platform_type_0 = 'linux'
    found_interpreters_0 = ['/usr/bin/python']
    is_auto_legacy_0 = False
    is_silent_0 = True
    action_0 = None
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto_silent'
    task_vars_0 = {}
    try:
        assert (discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0) == '/usr/bin/python')
    except TypeError:
        assert (discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0) == '')
#     try

# Generated at 2022-06-24 18:49:01.472937
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        # Test cases
        host = 'test-host'
        action = action_0 = 'action-0'
        interpreter_name = 'test-interpreter-name'
        discovery_mode = 'test-discovery-mode'
        task_vars = task_vars_0 = 'task-vars'
        # discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        raise Exception(u'test failure')
    except Exception:
        # Unit test throws an exception, so this code should not be reached
        assert False


# Generated at 2022-06-24 18:49:02.721626
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: Implement unit test for discover_interpreter
    assert False


# Generated at 2022-06-24 18:49:08.243214
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {}
    res = discover_interpreter(None, None, None, task_vars)
    interpreter_discovery_required_error_0 = res
    test_case_0()
    assert interpreter_discovery_required_error_0 == u'/usr/bin/python'


# Generated at 2022-06-24 18:49:14.314828
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None # TODO: implement a test case
    interpreter_name = None
    discovery_mode = None
    task_vars = None

    # Test with a basic implementation of the action impl
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert isinstance(result, str)



# Generated at 2022-06-24 18:49:20.698588
# Unit test for function discover_interpreter
def test_discover_interpreter():
    source = {'inventory_hostname': 'localhost', 'ansible_python_interpreter': '/usr/bin/python'}
    action = None

    res = discover_interpreter(action, "python", "auto_legacy_silent", source)
    assert res is not None

    res = discover_interpreter(action, "python", "auto_legacy", source)
    assert res is not None

    res = discover_interpreter(action, "python", "auto", source)
    assert res is not None

    res = discover_interpreter(action, "python", "auto_silent", source)
    assert res is not None

# Generated at 2022-06-24 18:49:21.504918
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert isinstance(discover_interpreter(), str)

# Generated at 2022-06-24 18:49:32.879868
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import types
    # Suppose some module variables
    test_values = types.ModuleType('ansible.module_utils.discovery.test_values')
    test_values.action = types.ModuleType('ansible.module_utils.discovery.test_values.action')
    test_values.action._final_fallback_interpreter = '/usr/bin/python'
    test_values.action._discovery_warnings = types.ModuleType('ansible.module_utils.discovery.test_values.action._discovery_warnings')
    test_values.action._low_level_execute_command = types.ModuleType('ansible.module_utils.discovery.test_values.action._low_level_execute_command')
    test_values.action._low_level_execute_command.res = {'rc': 1}


# Generated at 2022-06-24 18:49:43.945366
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert LooseVersion('1.2.3') < LooseVersion('2')
    assert LooseVersion('1.2.3') < LooseVersion('1.3')
    assert LooseVersion('1.2.3') < LooseVersion('1.2.4')
    assert LooseVersion('1.2.3') < LooseVersion('1.2.3.1')
    assert LooseVersion('1.2.3') < LooseVersion('1.2.3.1.1.1')

    # exact match
    assert _version_fuzzy_match('1.2.3', {'1.2.3': 'f'}) == 'f'

    # exact match, but first

# Generated at 2022-06-24 18:50:06.155072
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # No error should be raised for this test case
    res = discover_interpreter("discover_interpreter")
    assert res is not None, "unexpected result from discover_interpreter"


# Generated at 2022-06-24 18:50:12.995055
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Python Mock.EXPECT().any_order().any_count().any_args()
    # Python Mock.assert_called_once()
    # Python Mock.return_value = (0, 'ok')

    action = Mock()
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = Mock()
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)


from unittest.mock import Mock

# Generated at 2022-06-24 18:50:16.329012
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action_0 = None
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto'
    task_vars_0 = {}

    # Call function
    res = discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)

    # No assertion check


# Generated at 2022-06-24 18:50:26.382513
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        raise Exception('This is the error message.')
    except Exception:
        err = sys.exc_info()[1]
        traceback = sys.exc_info()[2]

        try:
            raise Exception('This is the error message.')
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()

    bytes_0 = b'\xc5\x86\xdb\xbcxH\x94]\xa6\xd2\xca\x82\xbf`K@\xc8\xc4\xb8'
    dict_0 = {bytes_0: bytes_0}
    float_0 = 60.0
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(bytes_0, dict_0, float_0)

# Generated at 2022-06-24 18:50:34.758336
# Unit test for function discover_interpreter
def test_discover_interpreter():
    bytes_0 = b'\xc5\x86\xdb\xbcxH\x94]\xa6\xd2\xca\x82\xbf`K@\xc8\xc4\xb8'
    dict_0 = {bytes_0: bytes_0}
    float_0 = 60.0
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(bytes_0, dict_0, float_0)
    # Uncomment the following line to see the output of the unit test
    #print(discover_interpreter(bytes_0, dict_0, float_0))


# Generated at 2022-06-24 18:50:36.389234
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement tests if this is ever used again
    pass

# Generated at 2022-06-24 18:50:41.945112
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Initialize test values
    action_0 = _Action()
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto'
    task_vars_0 = dict()

    # Call function under test
    actual_result_0 = discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)

    # Return results
    return actual_result_0


# Generated at 2022-06-24 18:50:49.841802
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.playbook.play_context
    ansible.playbook.play_context.CLIARGS = None
    action = None
    interpreter_name = u'python'
    discovery_mode = u'auto_legacy_silent'
    task_vars = {u'inventory_hostname': u'localhost'}
    discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    # assert mock_discover.call_count == 1
    # assert mock_discover.call_args == mock.call(action, interpreter_name, discovery_mode, task_vars)


# Generated at 2022-06-24 18:50:59.784820
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # FIXME(ansible-debugging): Modify these to match your testcase
    return_value = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    try:
        assert (return_value.decode('utf-8') == '/usr/bin/python')
    except AssertionError:
        raise AssertionError(return_value.decode('utf-8'))



# Generated at 2022-06-24 18:51:06.552791
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test 1: test_discover_interpreter_exception_types
    # Test 1.1: Test exception type
    action = 'test action'
    interpreter_name = 'test interpreter'
    discovery_mode = 'test discovery mode'
    task_vars = 'test task vars'

    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except ValueError as err:
        # Test 1.2: Test exception value
        assert u'Interpreter discovery not supported for test interpreter' == str(err)

    # Test 2: test_discover_interpreter_not_implemented_platform_type
    # Test 2.1: Test exception type
    action = 'test action'
    interpreter_name = 'python'

# Generated at 2022-06-24 18:51:26.821970
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# Generated at 2022-06-24 18:51:31.241407
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = {}
    var_1 = discover_interpreter(var_0, str_0, str_0, var_0)
    assert var_1 == '/usr/bin/python'


# FUTURE: conditional import based on platform/distro
try:
    from ansible.module_utils.distro import Distro
except ImportError:
    Distro = None

# Generated at 2022-06-24 18:51:34.972186
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = {}
    var_1 = discover_interpreter(var_0, str_0, str_0, var_0)
    print(var_1)


# Generated at 2022-06-24 18:51:38.657507
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter.__doc__ is not None
    assert 'interpreter_name=' in discover_interpreter.__doc__

    # Call function discover_interpreter
    # assert not isinstance(discover_interpreter(discovery_mode, host, task_vars), basestring)
    test_case_0()

# Generated at 2022-06-24 18:51:41.954910
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Note that this test file is not under Ansible and is not a unit test for the module.
    print(discover_interpreter('foo', 'python', 'auto', {}))

if __name__ == '__main__':
    # test_discover_interpreter()
    test_case_0()

# Generated at 2022-06-24 18:51:42.483934
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True == False

# Generated at 2022-06-24 18:51:48.654477
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:51:58.103485
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Set up mock
    class MockAction:
        pass

    action = MockAction()
    action._connection = Mock()
    action._connection.has_pipelining = True
    action._low_level_execute_command = Mock()
    action._low_level_execute_command.return_value = {
        'stdout': u'PLATFORM\nLinux\nFOUND\n/usr/bin/python\n/usr/bin/foo\nENDFOUND',
        'stderr': u''
    }
    action._discovery_warnings = []

    # Call tested function
    result = discover_interpreter(action)

    # Assertions
    assert result == '/usr/bin/python'



# Generated at 2022-06-24 18:51:59.100780
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# Generated at 2022-06-24 18:52:05.988509
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import os
    import tempfile
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.action_factory import ActionModuleFactory
    from ansible.plugins.loader import module_loader, connection_loader
    from ansible.plugins.discovery import ModuleDiscovery
    from ansible.executor.task_queue_manager import TaskQueueManager

    # set up some dummy configuration, inventory, and context objects
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), "../../action"))
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), "../../plugins/modules"))

# Generated at 2022-06-24 18:52:53.716580
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = {}
    var_1 = discover_interpreter(var_0, str_0, str_0, var_0)



# Generated at 2022-06-24 18:52:56.537453
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # testcase 0
    res_0 = discover_interpreter(None, 'python', 'python', None)
    print(res_0)
    print('\n')

    test_case_0()
    test_case_1()



# Generated at 2022-06-24 18:52:59.314529
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception as ex:
        display.error('Failed to run test case: {0}'.format(ex))

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:52:59.979958
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter()


# Generated at 2022-06-24 18:53:03.461289
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = InterpreterDiscoveryRequiredError(str_1, str_2, str_3)
    var_1 = discover_interpreter(str_1, str_2, str_3, str_1)
    var_2 = discover_interpreter(str_1, str_3, str_1, str_1)
    var_3 = discover_interpreter(str_1, str_4, str_5, str_1)

# Generated at 2022-06-24 18:53:12.842800
# Unit test for function discover_interpreter
def test_discover_interpreter():
    cases = [
        {
            'input':
                {'action': 'action', 'interpreter_name': 'python', 'discovery_mode': 'auto_legacy',
                 'task_vars': {'inventory_hostname': 'unknown'}},
            'out': 'python'
        },
        {
            'input':
                {'action': 'action', 'interpreter_name': 'python', 'discovery_mode': 'auto_legacy_silent',
                 'task_vars': {'inventory_hostname': 'unknown'}},
            'out': 'python'
        }
    ]
    for case in cases:
        out = discover_interpreter(**case['input'])

# Generated at 2022-06-24 18:53:19.026331
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # make sure it doesn't accept a bad interpreter name
    try:
        discover_interpreter(str, 'bad')
        assert False
    except NotImplementedError:
        assert True

    # make sure it doesn't accept a bad discovery mode
    try:
        discover_interpreter(str, 'python', 'bad')
        assert False
    except NotImplementedError:
        assert True

    # make sure it returns None for a silent failure
    var_0 = {}
    var_1 = discover_interpreter(var_0, 'python', 'fail')
    assert var_1 == None

    # make sure it throws something for a non-silent failure

# Generated at 2022-06-24 18:53:30.405729
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # 0
    str_0 = 'python'
    var_0 = {}
    var_1 = discover_interpreter(var_0, str_0, str_0, var_0)
    print(var_1)
    print(var_1)

    # 1
    str_0 = 'python'
    str_1 = 'python2'
    var_0 = {}
    var_1 = discover_interpreter(var_0, str_0, str_1, var_0)
    print(var_1)
    print(var_1)

    # 2
    str_0 = 'python'
    str_1 = 'auto_legacy'
    var_0 = {}
    var_1 = discover_interpreter(var_0, str_0, str_1, var_0)
   

# Generated at 2022-06-24 18:53:39.025190
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python3'
    str_1 = 'auto_legacy'
    str_2 = 'auto_legacy_silent'
    str_3 = 'auto'
    str_4 = 'auto_silent'
    str_5 = 'fixed'
    str_6 = 'fixed_silent'
    var_0 = {}
    var_1 = discover_interpreter(var_0, str_0, str_1, var_0)
    var_2 = discover_interpreter(var_0, str_0, str_2, var_0)
    var_3 = discover_interpreter(var_0, str_0, str_3, var_0)
    var_4 = discover_interpreter(var_0, str_0, str_4, var_0)
   

# Generated at 2022-06-24 18:53:39.855680
# Unit test for function discover_interpreter
def test_discover_interpreter():

    test_case_0()

# Generated at 2022-06-24 18:55:15.648932
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("\nTesting discover_interpreter")

    test_case_0()

# Generated at 2022-06-24 18:55:25.202926
# Unit test for function discover_interpreter
def test_discover_interpreter():
    with pytest.raises(ValueError):
        str_0 = 'python'
        var_0 = {}
        str_1 = 'python3'
        discover_interpreter(var_0, str_0, str_1, var_0)
    with pytest.raises(NotImplementedError):
        str_0 = 'python'
        var_0 = {}
        str_1 = 'auto'
        var_1 = ('PLATFORM', '\n', ' uname \n', 'FOUND', '\n', ' /bin/python ', '\n', 'ENDFOUND')
        test_case_0()
    with pytest.raises(ValueError):
        str_0 = 'python'
        var_0 = {}
        str_1 = 'auto'

# Generated at 2022-06-24 18:55:30.693277
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = {}

    try:
        var_1 = discover_interpreter(var_0, str_0, str_0, var_0)
    except NotImplementedError as ex:
        pass
    except Exception as ex:
        display.warning(msg=u'Unhandled error in Python interpreter discovery for host : {}'.format(to_text(ex)))
        display.debug(msg=u'Interpreter discovery traceback:\n{}'.format(to_text(format_exc())))



# Generated at 2022-06-24 18:55:31.301678
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert isinstance(test_case_0(), str)

# Generated at 2022-06-24 18:55:31.976166
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()


# Generated at 2022-06-24 18:55:33.463786
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = {}
    var_1 = discover_interpreter(var_0, str_0, str_0, var_0)
    assert u'/usr/bin/python'

# Generated at 2022-06-24 18:55:35.126370
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        assert(test_case_0())
    except:
        print('fail test_discover_interpreter')
    else:
        print('pass test_discover_interpreter')


# Generated at 2022-06-24 18:55:35.740552
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()



# Generated at 2022-06-24 18:55:48.083215
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test with a valid argument
    try:
        assert discover_interpreter(to_text('/usr/bin/python'), 'python', 'auto') == '/usr/bin/python'
    except:
        print('error')
    # Test with a valid argument
    try:
        assert discover_interpreter(to_text('/usr/bin/python'), 'python', 'auto_legacy') == '/usr/bin/python'
    except:
        print('error')
    # Test with a valid argument
    try:
        assert discover_interpreter(to_text('/usr/bin/python'), 'python', 'auto_legacy_silent') == '/usr/bin/python'
    except:
        print('error')
    # Test with a valid argument

# Generated at 2022-06-24 18:56:00.248946
# Unit test for function discover_interpreter
def test_discover_interpreter():
    p1 = (None, 'python', 'auto', None)
    p2 = (None, 'python3', 'auto', None)
    p3 = ('test', 'python', 'auto', None)
    p4 = ('test', 'python3', 'auto', None)
    p5 = ('test', 'python', 'auto_legacy', None)
    p6 = ('test', 'python', 'auto_legacy_silent', None)
    p7 = ('test', 'python', 'auto_silent', None)

    assert test_case_0() == 'test'
    assert discover_interpreter(*p1) == 'test'
    assert discover_interpreter(*p2) == 'test'
    assert discover_interpreter(*p3) == 'test'