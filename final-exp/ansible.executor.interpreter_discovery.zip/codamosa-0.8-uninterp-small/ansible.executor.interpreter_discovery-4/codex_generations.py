

# Generated at 2022-06-24 18:46:59.912894
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = argv = interpreter_name = None
    task_vars = dict()
    discovery_mode = 'auto_legacy_silent'

    test_interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert isinstance(test_interpreter, str)

    # Run again with different timeout
    discovery_mode = 'auto_silent'
    test_interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert isinstance(test_interpreter, str)

    # Run with a bad discovery mode
    discovery_mode = 'auto_silent_bad'

# Generated at 2022-06-24 18:47:10.652240
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action_0 = None # FUTURE: implement test
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto'
    task_vars_0 = {'inventory_hostname': 'localhost'}
    from ansible.module_utils.facts.system.distribution import Distribution
    import distro
    distro_0 = Distribution()
    distro_0.name = distro.name()
    distro_0.major_version = distro.major_version()
    distro_0.minor_version = distro.minor_version()
    distro_0.distro_version = distro.version()
    task_vars_0['ansible_facts'] = {'distribution': distro_0}
    with pytest.raises(ValueError) as error:
        discover

# Generated at 2022-06-24 18:47:13.268264
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == 'PLATFORM\nlinux\nFOUND\n/usr/bin/python\nENDFOUND'


# Generated at 2022-06-24 18:47:17.581950
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = ''
    interpreter_name = ''
    discovery_mode = ''
    task_vars = {u'inventory_hostname': u'localhost', u'module_name': u'shell'}
    # No exception is expected
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    # Verify the result
    assert(result == u'/usr/bin/python')


# Generated at 2022-06-24 18:47:22.480526
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test with an actual Dict and options:
    action = Dict()
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = Dict()
    task_vars['inventory_hostname'] = 'some_host'
    task_vars['config']['INTERPRETER_PYTHON_DISTRO_MAP'] = {u'ansible_python_interpreter': u'/usr/bin/python2'}
    expected_result = '/usr/bin/python2'
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert expected_result == result



# Generated at 2022-06-24 18:47:26.757318
# Unit test for function discover_interpreter
def test_discover_interpreter():
    hostname = 'mock_inventory_hostname'
    interpreter_name = 'python'
    host_vars = {}
    task_vars = {'inventory_hostname': hostname,
                 'hostvars': {hostname: host_vars}}
    action = None
    discovery_mode = 'auto'
    expected_result = '/usr/bin/python'

    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == expected_result

# Unit tests for function _get_linux_distro

# Generated at 2022-06-24 18:47:32.836304
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(tuple_0, tuple_0, bytes_0, [tuple_0, ]).__repr__() == "InterpreterDiscoveryRequiredError('\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00', '\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00', 's\\x15h\\xb3Y')"

# Generated at 2022-06-24 18:47:38.449597
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = { 'inventory_hostname': 'localhost', 'ansible_connection': 'local' }
    res_0 = discover_interpreter(None, interpreter_name, discovery_mode, task_vars)


# Generated at 2022-06-24 18:47:43.054004
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: Write unit tests for function discover_interpreter
    assert False

# Generated at 2022-06-24 18:47:55.492999
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    test_action = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    action = test_action
    test_task_vars = ImmutableDict({
        'ansible_facts': {},
        'ansible_check_mode': False,
        'vars': {},
        'inventory_hostname': u'localhost',
    })
    task_vars = test_task_vars
    test_action._CHECK_MODE_ENABLED = True
    test_action._connection = None
    test_interpreter_name = u'python'
    interpreter_

# Generated at 2022-06-24 18:48:12.499681
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Initialize
    action = dict()
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = dict()

    # Assert
    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) is None

# Generated at 2022-06-24 18:48:23.435457
# Unit test for function discover_interpreter
def test_discover_interpreter():
    dict_0 = {}
    str_0 = 'python'
    str_1 = 'auto'
    str_2 = 'discovery'
    str_3 = 'executor'
    str_4 = 'host'
    str_5 = 'vars'
    dict_0['inventory_hostname'] = str_0
    dict_1 = {}
    dict_1[str_1] = dict_0
    dict_2 = {}
    dict_2[str_2] = dict_1
    dict_3 = {}
    dict_3[str_3] = dict_2
    dict_4 = {}
    dict_4[str_4] = dict_3
    dict_5 = {}
    dict_5[str_5] = dict_4
    dict_6 = {}

# Generated at 2022-06-24 18:48:26.897568
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object()
    interpreter_name = object()
    discovery_mode = object()
    task_vars = object()
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res is None


# Generated at 2022-06-24 18:48:33.456889
# Unit test for function discover_interpreter
def test_discover_interpreter():
    shell_bootstrap = u'echo PLATFORM; uname; echo FOUND; /usr/bin/python; echo ENDFOUND'
    platform_interpreter = u'/usr/bin/python'

# Generated at 2022-06-24 18:48:44.562187
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: this doesn't really test anything yet, but it's a start
    # ensure non-python interpreters fail
    try:
        discover_interpreter(None, 'perl', 'auto', {})
        raise AssertionError('unsupported interpreter did not throw exception')
    except ValueError as ex:
        pass

    try:
        discover_interpreter(None, 'python', 'foobar', {})
        raise AssertionError('unknown discovery mode did not throw exception')
    except ValueError as ex:
        pass


if __name__ == '__main__':
    # unit tests
    import sys
    if 'test_case_0' in sys.argv:
        test_case_0()
    if 'test_discover_interpreter' in sys.argv:
        test_discover

# Generated at 2022-06-24 18:48:55.251718
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = MagicMock()
    action.module_name = 'win_ping'
    action.become = False
    action.no_log = True
    action.connection = MagicMock()

# Generated at 2022-06-24 18:48:57.161964
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True


# Generated at 2022-06-24 18:49:04.664707
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_discovery_required_error_0 = Test_discover_interpreter_case_0()
    tuple_0 = ()
    bytes_0 = b'\xaa\xa4\xa4\x4a\x10\x0c'

# Generated at 2022-06-24 18:49:08.774874
# Unit test for function discover_interpreter
def test_discover_interpreter():
    data = {'hostvars': {u'host1': {u'inventory_hostname': u'host1'}, u'host2': {u'inventory_hostname': u'host2'}}}
    res = discover_interpreter(data, 'python', 'auto', data)
    assert res != '', "Failed to discover_interpreter"



# Generated at 2022-06-24 18:49:13.749824
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test signature and function call
    interpreter_name = 'foobar'
    discovery_mode = 'foobar'
    task_vars = {}
    assert discover_interpreter(interpreter_name, discovery_mode, task_vars)
    # TODO: automated testing of module discovery

# Generated at 2022-06-24 18:49:28.675852
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import shutil
    test_dir = 'interpreter_discovery_test'

    # Setup inventory dir
    inv_dir = shutil.rmtree(test_dir, True)
    inv_dir = os.mkdir(test_dir)

    # Setup inventory file
    inventory_file = 'inventory.ini'
    inventory_file_path = os.path.join(test_dir, inventory_file)
    inventory_file_obj = open(inventory_file_path, 'w')
    inventory_file_obj.write('localhost ansible_connection=local')
    inventory_file_obj.close()

    # Setup module_utils dir
    module_utils_dir = os.mkdir(os.path.join(test_dir, 'module_utils'))
    # Setup module_utils/python_target.py
    module

# Generated at 2022-06-24 18:49:30.145345
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:49:33.730232
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
        assert False

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:49:44.680214
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'res'
    str_1 = 'output'
    str_2 = 'python'
    str_3 = 'python3'
    str_4 = 'python3.4'
    str_5 = 'python3.5'
    str_6 = 'python3.6'
    str_7 = 'python3.7'
    str_8 = 'python3.8'
    str_9 = 'python3.9'
    str_10 = 'python2'
    str_11 = 'found'
    str_12 = 'ENDFOUND'
    str_13 = 'PLATFORM'
    str_14 = 'FOUND'
    str_15 = 'PLATFORM\r\nuname\r\nFOUND\r\nENDFOUND'
    str_16 = 'Linux'


# Generated at 2022-06-24 18:49:47.004171
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'

    # Test case with all local input parameters
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)

test_discover_interpreter()
test_case_0()

# Generated at 2022-06-24 18:49:53.327112
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Sanity check - these should be true
    assert True

    test_cases = [
        # TODO: add specific test cases
    ]

    for test_case in test_cases:
        try:
            test_case()
        except AssertionError as e:
            print(test_case.__doc__)
            print(test_case.__name__)
            print(e)
            assert False

# Generated at 2022-06-24 18:49:55.851453
# Unit test for function discover_interpreter
def test_discover_interpreter():
    res = discover_interpreter(1,2,3,4)
    assert res is not None, "Expected discovery result to be a not be None"



# Generated at 2022-06-24 18:49:59.388611
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_1 = 'python'
    var_2 = 'auto'
    var_3 = 'abc'
    try:
        var_0 = discover_interpreter(var_1, var_2, var_3, var_1)
    except Exception as e:
        var_0 = e

    assert isinstance(var_0, ValueError)


# Generated at 2022-06-24 18:50:03.290623
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        var_0 = 'python'
        var_1 = 'python'
        var_2 = 'auto'
        var_3 = 'tbd'
        var_4 = discover_interpreter(var_0, var_1, var_2, var_3)
    except InterpreterDiscoveryRequiredError as ex:
        pass
    except Exception as ex:
        print('Got exception:', ex)

# Generated at 2022-06-24 18:50:10.932955
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = str()
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    var_1 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 is not None
    assert var_1 is var_0



# Generated at 2022-06-24 18:50:37.575371
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)

    # We failed to find a python interpreter on the system.
    if to_native(var_0) == to_native('/usr/bin/python'):
        raise ValueError("Unable to find a selected interpreter")

    # We selected an interpreter on the system.
    if to_native(var_0) != to_native('/usr/bin/python'):
        raise ValueError("We found an interpreter on the system")



# Generated at 2022-06-24 18:50:40.403526
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        # We'll do some testing here
        assert test_case_0() == None

    except:
        pass


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:50:49.291097
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test with valid inputs
    # Put valid input here
    str_0 = 'python'
    str_1 = 'auto'
    str_2 = 'python'
    str_3 = 'python'
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    assert var_0 == "python"
    # Test with more valid inputs
    # Put valid input here
    str_0 = 'python'
    str_1 = 'auto'
    str_2 = 'python'
    str_3 = 'python'
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    assert var_0 == "python"
    # Test with valid inputs
    # Put valid input here
    str_0 = 'python'

# Generated at 2022-06-24 18:50:51.643763
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_1 = discover_interpreter('store', 'python', 'auto', 'task_vars')
    assert var_1 == '/usr/bin/python'


# Generated at 2022-06-24 18:51:03.505304
# Unit test for function discover_interpreter
def test_discover_interpreter():
    platform.dist = MagicMock(return_value=('redhat', '6.10', ''))
    os.path.isfile = MagicMock(return_value=True)
    python_version = 'python3'
    task_vars = dict()
    task_vars[python_version] = '/usr/bin/python3'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    if C.config.get('CACHE_PLUGIN_RESULT', False) and C.config.get('CACHE_PLUGIN', False):
        res = discover_interpreter(interpreter_name, discovery_mode, task_vars)
    else:
        result = discover_interpreter(interpreter_name, discovery_mode, task_vars)

# Generated at 2022-06-24 18:51:06.237053
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("Running test_discover_interpreter", end="\r")
    # Test when expected
    test_case_0()
# End unit-test: test_discover_interpreter

# Generated at 2022-06-24 18:51:07.114935
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True

# Generated at 2022-06-24 18:51:11.007859
# Unit test for function discover_interpreter
def test_discover_interpreter():
    case_0_test_str_0 = 'python'
    case_0_test_str_1 = 'python'
    case_0_test_str_2 = 'python'
    case_0_test_str_3 = 'python'
    var_0 = discover_interpreter(case_0_test_str_0, case_0_test_str_1, case_0_test_str_2, case_0_test_str_3)



# Generated at 2022-06-24 18:51:13.829008
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 in (True, False)
    # Test if a python interpreter is found



# Generated at 2022-06-24 18:51:21.135251
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'auto'
    str_2 = 'auto_silent'
    str_3 = 'auto_legacy'
    str_4 = 'auto_legacy_silent'

    str_5 = 'python'
    str_6 = 'auto'
    str_7 = 'auto_silent'
    str_8 = 'auto_legacy'
    str_9 = 'auto_legacy_silent'

    str_10 = 'python'
    str_11 = 'auto'
    str_12 = 'auto_silent'
    str_13 = 'auto_legacy'
    str_14 = 'auto_legacy_silent'

    str_15 = 'python'
    str_16 = 'auto'

# Generated at 2022-06-24 18:52:02.542568
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import sys

    orig_stdout = sys.stdout
    orig_stderr = sys.stderr

    class NullStream(object):
        def write(self, content):
            pass

        def flush(self):
            pass

    sys.stdout = NullStream()

    sys.stderr = NullStream()

    try:
        assert discover_interpreter('action', 'python', 'auto', 'task_vars') == 'python'
    except NotImplementedError:
        pass

    sys.stdout = orig_stdout

    sys.stderr = orig_stderr

# Generated at 2022-06-24 18:52:09.489683
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()


if __name__ == "__main__":
    import sys
    import doctest

    failed, tried = doctest.testmod()
    sys.exit(failed)
    test_discover_interpreter()

# Generated at 2022-06-24 18:52:10.623500
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# Generated at 2022-06-24 18:52:18.055092
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("Testing function discover_interpreter")
    msg = "Fake Message"
    try:
        print("\tCalling discover_interpreter() with no parameters")
        discover_interpreter("", "", "", "")
    except Exception:
        if isinstance(ex, NotImplementedError):
            print("Exception caught as expected.")
            assert True
        else:
            print("Exception not found as expected.")
            assert False
    else:
        print("Exception not found as expected.")
        assert False


# Generated at 2022-06-24 18:52:27.097191
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'python'
    str_2 = 'python'
    str_3 = 'python'
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    assert 'usr' in var_0 or 'bin' in var_0 or 'python' in var_0 or 'usr' in var_0 or 'bin' in var_0 or 'bin' in var_0 or 'bin' in var_0



# Generated at 2022-06-24 18:52:35.979770
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Setup
    str_0 = 'python'
    str_1 = 'auto'
    str_2 = 'auto'
    str_3 = 'auto'
    str_4 = 'auto'
    str_5 = 'auto'
    str_6 = 'auto'
    str_7 = 'auto'

    # Exercise
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    var_1 = discover_interpreter(str_0, str_4, str_5, str_3)
    var_2 = discover_interpreter(str_0, str_6, str_7, str_3)

    # Verify
    assert var_0 == '/usr/bin/python'
    assert var_1 == '/usr/bin/python'
    assert var

# Generated at 2022-06-24 18:52:37.988369
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert next((True for _ in [
        test_case_0(),
    ] if not _), False), "One or more test cases failed"

# Generated at 2022-06-24 18:52:41.308382
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print('Testing function discover_interpreter')
    # TODO: Add test code here
    test_case_0()


if __name__ == '__main__':
    print('Testing ansible/executor/discovery.py')
    test_discover_interpreter()

# Generated at 2022-06-24 18:52:43.665215
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert to_native(discover_interpreter(str, str, str, str)) == 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND'

# Generated at 2022-06-24 18:52:54.502376
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = {'var_0': 'foo'}

# Generated at 2022-06-24 18:54:27.084529
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:54:34.983780
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Use this to set up the test environment
    str_0 = 'python'
    str_1 = 'silent'
    str_2 = 'auto'
    str_3 = ''
    str_4 = 'strict'

    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    print(var_0)
    var_1 = discover_interpreter(str_0, str_0, str_4, str_3)
    print(var_1)


# Hack
if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:54:38.232282
# Unit test for function discover_interpreter
def test_discover_interpreter():
    arg_0 = u'python'
    arg_1 = u'python'
    arg_2 = u'python'
    arg_3 = u'python'

    ret_0 = discover_interpreter(arg_0, arg_1, arg_2, arg_3)
    # Do not use assert for this test



# Generated at 2022-06-24 18:54:41.994991
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = u'action'
    interpreter_name = u'interpreter name'
    discovery_mode = u'discovery mode'
    task_vars = u'task vars'
    try:
        try:
            # Test case 0
            test_case_0()
        except NotImplementedError:
            pass
    except Exception as err:
        assert False, str(err)


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:54:44.817003
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # 1. Test case with arguments: str and str

    # TEST CASE: Test with file inputs
    # Setup
    test_case_0()

# Generated at 2022-06-24 18:54:46.036377
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 18:54:55.551396
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Calls discover_interpreter with correct parameters
    discover_interpreter('action', 'python', 'auto', 'task_vars')

    # Calls discover_interpreter with incorrect parameters
    # This will raise a ValueError exception
    try:
        discover_interpreter('action', 'python', 'auto', 'task_vars')
    except ValueError:
        pass  # expected

    # Calls discover_interpreter with incorrect parameters
    # This will raise a NotImplementedError exception
    try:
        discover_interpreter('action', 'python', 'auto', 'task_vars')
    except NotImplementedError:
        pass  # expected

    # Calls discover_interpreter with incorrect parameters
    # This will raise a ValueError exception

# Generated at 2022-06-24 18:55:00.917407
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        # FUTURE: this should be a real test, with an action and target node
        test_case_0()
    except ValueError as ex:
        print('ValueError: ' + to_native(ex.args))

# Generated at 2022-06-24 18:55:03.369024
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("Test discover_interpreter()")

    # Make sure this compiles
    test_case_0()

# Generated at 2022-06-24 18:55:04.826464
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True

