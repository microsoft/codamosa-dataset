

# Generated at 2022-06-24 18:46:39.545584
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print('Testing discover_interpreter...')
    assert discover_interpreter(0, 0, 0, 0) == 'python'
    print('done!')



# Generated at 2022-06-24 18:46:46.260933
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils._text import to_bytes
    # Python27 not supported for PySyck
    action_0 = to_bytes('')
    interpreter_name_0 = 'jy8qN'
    discovery_mode_0 = 'not_implemented'
    task_vars_0 = {}
    # exception raised test
    try:
        discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)
    except Exception:
        pass
    else:
        assert False, 'Expected exception not thrown.'
    # State the expected exception type
    exception_expected = NotImplementedError
    # State the expected exception message
    exception_msg = "unsupported discovery mode: {0}".format(to_native(discovery_mode_0))


# Generated at 2022-06-24 18:46:56.502617
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {"default_ipv4": "172.18.223.2","group_names": ["vars"], "inventory_file": "/etc/ansible/hosts", "inventory_hostname_short": "virtualbox", "inventory_hostname": "virtualbox", "inventory_dir": "/etc/ansible", "invocation": {"module_name": "command", "module_args": "", "module_complex_args": {}, "module_args_line": "", "module_name": "command", "module_complex_args": {}, "module_args_line": ""}, "module_name": "command", "module_complex_args": {}, "module_args_line": "", "groups": {"vars": ["virtualbox"]}, "group_names": ["vars"]}
    # TODO: Add tests for all of

# Generated at 2022-06-24 18:47:08.127463
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:47:15.031251
# Unit test for function discover_interpreter
def test_discover_interpreter():
    int_0 = -1414876707
    int_1 = -749404235
    int_2 = 47963012
    int_3 = -1425849706
    int_4 = -1790465284
    int_5 = -1126920682
    str_0 = 'xJt'
    str_1 = 'j8c'
    str_2 = '+j'
    str_3 = 'nx g'
    int_6 = -1385804319
    action_0 = ActionModule({str_0: {str_1: {str_2: {str_3: int_0}}}}, {}, int_1, boolean_0=True)
    str_4 = 'm'
    int_7 = -1236168474
    str_5 = '!X)'

    # Call discover

# Generated at 2022-06-24 18:47:21.219111
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'
    task_vars = {'inventory_hostname': 'unknown'}
    # Call function
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    # TODO: I don't really know what to assert here?
    try:
        assert result == u'/usr/bin/python'
    except AssertionError as e:
        print(e)
        print("AssertionError caught in test_discover_interpreter")

# Generated at 2022-06-24 18:47:31.561342
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = ['z', 'b', 'x', 'a', 'c']
    interpreter_name = 'q'
    discovery_mode = 'awy'
    task_vars = {'B':'C', 'A':'B', 'C':'D'}

    print("INPUT: " +
          "action={0}, " +
          "interpreter_name={1}, " +
          "discovery_mode={2}, " +
          "task_vars={3}".format(action,
                                 interpreter_name,
                                 discovery_mode,
                                 task_vars))
    expected_result = None

    try:
        result = discover_interpreter(interpreter_name, discovery_mode, action, task_vars)
    except Exception as exc:
        result = exc


# Generated at 2022-06-24 18:47:36.700391
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host = 'localhost'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = dict()
    testobj = action_test(host, interpreter_name, discovery_mode, task_vars)
    result = discover_interpreter(testobj, interpreter_name, discovery_mode, task_vars)
    assert result == '/usr/bin/python'


# Generated at 2022-06-24 18:47:45.600673
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:47:56.878675
# Unit test for function discover_interpreter
def test_discover_interpreter():
    int_0 = -575
    str_0 = 'kQr'
    set_0 = {str_0, str_0}
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(set_0, set_0, set_0)

    with pytest.raises(NotImplementedError):
        discover_interpreter(set_0, set_0, set_0, set_0)

    with pytest.raises(NotImplementedError):
        discover_interpreter(set_0, set_0, set_0, set_0)

    with pytest.raises(NotImplementedError):
        discover_interpreter(set_0, set_0, set_0, set_0)


# Generated at 2022-06-24 18:48:14.628212
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_1 = 'python'
    str_2 = 'auto_legacy_silent'
    str_3 = 'auto_silent'
    var_1 = discover_interpreter(str_1, str_2, str_3, str_1)
    print('var_1 is', var_1)
    assert var_1 is not None
if __name__ == '__main__':
    test_discover_interpreter()
    test_case_0()

# Generated at 2022-06-24 18:48:24.953662
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:48:27.513845
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:48:28.613984
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print(test_case_0())
    return



# Generated at 2022-06-24 18:48:30.171521
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter == 'python'


# Module level function tests

# Generated at 2022-06-24 18:48:33.869167
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert callable(discover_interpreter)
    try:
        discover_interpreter(str, str, str, str)
    except TypeError:
        pass
    else:
        assert False, "unexpected exception" # should throw


# Generated at 2022-06-24 18:48:36.319745
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action', 'python', 'auto_legacy_silent', 'task_vars') == 'python'

# Generated at 2022-06-24 18:48:46.508581
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # uknown/known/legacy
    assert discover_interpreter(None, 'python', 'unknown', {}) is None
    assert discover_interpreter(None, 'python', 'known', {}) is None
    assert discover_interpreter(None, 'python', 'legacy', {}) == '/usr/bin/python'

    # invalid explicit values
    assert discover_interpreter(None, 'python', 'foo', {}) is None
    assert discover_interpreter(None, 'python', 'foo_silent', {}) is None

    # invalid mode for distro/version map
    assert discover_interpreter(None, 'python', 'bar', {}) is None
    assert discover_interpreter(None, 'python', 'bar_silent', {}) is None

    # valid modes, no map
    assert discover_

# Generated at 2022-06-24 18:48:53.234272
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Call function discover_interpreter
    try:
        discover_interpreter(str_0, str_0, str_0, str_0)
    except Exception as caught_exc:
        # Verify the error
        assert False

# Testing that test_case_0() raises an exception and the error is actually "method not implemented"

# Generated at 2022-06-24 18:48:59.363054
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_1 = 'unknown'
    var_2 = 'unknown'
    var_3 = 'unknown'
    var_4 = 'unknown'
    obj_0 = discover_interpreter(var_1, var_2, var_3, var_4)
    assert obj_0 == var_4



# Generated at 2022-06-24 18:49:14.658426
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(0, 0, 0, 0) == 0


# Generated at 2022-06-24 18:49:15.637761
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Perform test
    test_case_0()

# Generated at 2022-06-24 18:49:18.026878
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'unknown'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)



# Generated at 2022-06-24 18:49:18.810050
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# Generated at 2022-06-24 18:49:26.101655
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test1_0 = 'ansible_connection=network_cli transport=cli network_os=nxos'
    test1_1 = 'python'
    test1_2 = 'auto'
    try:
        test_case_0()
    except Exception:
        pass
    assert var_0 == '/usr/bin/python'
    assert var_0 == '/usr/bin/python'
    assert var_0 == '/usr/bin/python'
    assert var_0 == '/usr/bin/python'
    assert var_0 == '/usr/bin/python'
    assert var_0 == '/usr/bin/python'
    assert var_0 == '/usr/bin/python'
    assert var_0 == '/usr/bin/python'
    assert var_0 == '/usr/bin/python'

# Generated at 2022-06-24 18:49:29.207343
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'unknown'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == '/usr/bin/python'


# Generated at 2022-06-24 18:49:30.433206
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement
    assert False  # noqa



# Generated at 2022-06-24 18:49:32.025029
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert test_case_0() == None

# Generated at 2022-06-24 18:49:33.959270
# Unit test for function discover_interpreter
def test_discover_interpreter():
    res = discover_interpreter(str, str, str, str)
    assert res is not None


# Generated at 2022-06-24 18:49:38.571187
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except AssertionError as e:
        print("FAIL: {}".format(str(e)))
    else:
        print("PASS")

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:50:04.725023
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert(isinstance(test_case_0()), str)  # If you know the expected result, put it here

# Generated at 2022-06-24 18:50:08.681391
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-24 18:50:19.370959
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action', 'python', 'auto_legacy', 'task_vars') == 'return value'
    assert discover_interpreter('action', 'python', 'auto_legacy_silent', 'task_vars') == 'return value'
    assert discover_interpreter('action', 'python', 'auto', 'task_vars') == 'return value'
    assert discover_interpreter('action', 'python', 'auto_silent', 'task_vars') == 'return value'
    assert discover_interpreter('action', 'python', 'warn', 'task_vars') == 'return value'
    assert discover_interpreter('action', 'python', 'fail', 'task_vars') == 'return value'

# Generated at 2022-06-24 18:50:22.252671
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter("action", "interpreter_name", "discovery_mode", "task_vars") == "interpreter_name"



# Generated at 2022-06-24 18:50:23.527833
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('unknown', 'unknown', 'unknown', 'unknown') != None

# Generated at 2022-06-24 18:50:30.970636
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('', 'python', 'auto_legacy_silent', '') == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'auto_silent', '') == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'auto', '') == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'forced', '') == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'auto_legacy_warn', '') == '/usr/bin/python'
    assert discover_interpreter('', 'python', 'auto_warn', '') == '/usr/bin/python'



# Generated at 2022-06-24 18:50:39.484454
# Unit test for function discover_interpreter
def test_discover_interpreter():
    case_0()
    case_1()
    case_2()
    case_3()
    case_4()
    case_5()
    case_6()
    case_7()
    case_8()
    case_9()
    case_10()
    case_11()
    case_12()
    case_13()
    case_14()
    case_15()
    case_16()
    case_17()
    case_18()
    case_19()
    case_20()
    case_21()
    case_22()


# Test cases for InterpreterDiscoveryRequiredError

# Generated at 2022-06-24 18:50:44.879910
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter = 'python'
    discovery_mode = 'auto'
    task_vars = {'inventory_hostname': 'localhost'}
    action = 'bootstrap_python_interpreter'
    target = discover_interpreter(action, interpreter, discovery_mode, task_vars)
    assert target == u'/usr/bin/python', (
        "expected target: '/usr/bin/python'; got %s instead" % str(target))

# Generated at 2022-06-24 18:50:51.773439
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {"some": ["thing"]}

# Generated at 2022-06-24 18:50:57.440520
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Testing detection of operating system type
    # Non-Linux operating system
    str_1 = 'darwin'
    str_2 = 'python'
    str_3 = 'auto_legacy'
    str_4 = 'no_cf_key'
    # Linux operating system
    str_5 = 'linux'
    str_6 = 'python'
    str_7 = 'auto_legacy'
    str_8 = 'no_cf_key'
    assert 'darwin' == discover_interpreter(str_1, str_2, str_3, str_4)
    assert 'linux' == discover_interpreter(str_5, str_6, str_7, str_8)


# Generated at 2022-06-24 18:51:53.528697
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: test multiple discovery modes
    discovery_mode = 'auto_legacy'
    interpreter_name = 'python'
    action = 'dummy'

    task_vars = {
        "ansible_connection": "network_cli",
        "ansible_network_os": "vyos",
        "ansible_network_os_version": "1.3.0-rc1",
        "ansible_user": "username",
        "gather_subset": [
            "all"
        ],
        "inventory_hostname": "vyos-1.3.0-rc1-01"
    }
    assert discover_interpreter(action, 'python', 'auto_legacy', task_vars) == '/usr/bin/python'

# Generated at 2022-06-24 18:51:58.230136
# Unit test for function discover_interpreter
def test_discover_interpreter():
    expected_results = 'unknown'
    test_case_0()
    #
    # if ((pytest.config.option.test_verbose == True)):
    #     print ("Expected result: " + expected_results)
    #     print ("Actual result:   " + var_0)

    assert expected_results == var_0

# Utility function for testing

# Generated at 2022-06-24 18:51:59.744498
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """Test for discover_interpreter"""
    # Test 1: Simple test
    test_case_0()

# Generated at 2022-06-24 18:52:02.406495
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test_case_0
    str_0 = 'unknown'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)

    return var_0


# Generated at 2022-06-24 18:52:10.991955
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'unknown'
    str_1 = 'unknown'
    str_2 = 'unknown'
    str_3 = 'unknown'
    str_4 = 'unknown'
    str_5 = 'unknown'
    str_6 = 'unknown'

    discovered_interpreter = discover_interpreter(str_0, str_1, str_2, str_3)
    assert discovered_interpreter == str_4

    discovered_interpreter = discover_interpreter(str_5, str_6, str_2, str_3)
    assert discovered_interpreter == str_4

# Generated at 2022-06-24 18:52:15.215890
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print(discover_interpreter.__class__)
    print(discover_interpreter.__name__)
    print(discover_interpreter.__doc__)


# Generated at 2022-06-24 18:52:17.728121
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test with simple platform type
    try:
        test_case_0()
    except Exception:
        assert False, "Failed test_case_0"


if __name__ == "__main__":
    test_discover_interpreter()

# Generated at 2022-06-24 18:52:20.886775
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True



# Generated at 2022-06-24 18:52:23.144971
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Replace 'pass' with your implementation of the function.
    test_case_0()



# Generated at 2022-06-24 18:52:24.615854
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: adjust test case 0 as needed
    test_case_0()

# Generated at 2022-06-24 18:54:28.798556
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Unit test code should go here.
    test_case_0()

# Generated at 2022-06-24 18:54:31.101042
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Strings
    test_case_0()


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:54:31.672569
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert False

# Generated at 2022-06-24 18:54:39.171502
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:54:46.378021
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        # when discovery_mode is auto_legacy_silent
        test_case_0()
    except:
        str_0 = 'unknown'
        var_0 = discover_interpreter(str_0, str_0, str_0, str_0)

# Generated at 2022-06-24 18:54:52.391446
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'automatic'
    str_1 = 'python'
    str_2 = 'auto_legacy_off'
    str_3 = 'os'

    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    assert var_0 == '/usr/bin/python', "discover_interpreter() returned wrong output"

# Generated at 2022-06-24 18:54:53.636762
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert 'python' == discover_interpreter("ansible", "python", "auto", "task_vars")

# Generated at 2022-06-24 18:54:57.209995
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Input arguments
    dummy_action = None
    dummy_interpreter_name = "python"
    dummy_discovery_mode = "auto_legacy_silent"
    dummy_task_vars = dict()

    ret_0 = discover_interpreter(dummy_action, dummy_interpreter_name,
                                          dummy_discovery_mode, dummy_task_vars)
    assert ret_0 == "/usr/bin/python"

# Generated at 2022-06-24 18:55:09.017168
# Unit test for function discover_interpreter
def test_discover_interpreter():

    cmd_opts = {
        'host': 'host_0',
        'tgt': 'tgt_0',
        'func': 'func_0',
        'functype': 'type_0',
        'no_log': True
    }

    actionplugin = ActionBase(cmd_opts)

    actionplugin._low_level_execute_command = MagicMock(return_value=True)


    try:
        actionplugin_0 = discover_interpreter(actionplugin, 'python', 'auto_legacy_silent', {})
    except ValueError as e:
        print('Test case 0 failed: '
              'unexpected exception raised: {}'.format(e))
    else:
        print('Test case 0: '
              'python interpreter discovery works')



# Generated at 2022-06-24 18:55:13.140665
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test case 0
    try:
        test_case_0()
        print('passed case 0')
    except NotImplementedError:
        print('caught exception')
        pass
    else:
        print('failed case 0')

# Utility function for test_discover_interpreter