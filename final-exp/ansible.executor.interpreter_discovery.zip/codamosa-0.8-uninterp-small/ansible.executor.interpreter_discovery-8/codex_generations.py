

# Generated at 2022-06-24 18:46:43.890325
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = "Rd-U]()~}_T'}W"
    interpreter_name = b'\xf4\xf9\xef\x98{6\xce\x17\x1a\xc1j\xc0\xe8'
    discovery_mode = "Rd-U]()~}_T'}W"
    task_vars = 78.0
    var_0 = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert var_0 == "/usr/bin/python"
    assert type(var_0) == type('')


# Generated at 2022-06-24 18:46:54.672674
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Output from mock command
    output_0 = "PLATFORM\nUnknown\nFOUND\n/usr/bin/python\nENDFOUND"
    # Output from mock command
    output_1 = "PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND"
    # Output from mock command
    output_2 = "PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND"
    # Output from mock command
    output_3 = "PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND"
    # Output from mock command
    output_4 = "PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND"
    # Output from mock command
    output

# Generated at 2022-06-24 18:47:02.044281
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Setup
    try:
        str_0 = "Rd-U]()~}_T'}W"
        bytes_0 = b'\xf4\xf9\xef\x98{6\xce\x17\x1a\xc1j\xc0\xe8'
        float_0 = 78.0

        # Testing
        var_0 = discover_interpreter(str_0, bytes_0, str_0, float_0)

        # Verify
        assert isinstance(var_0, (str, bytes))
    except Exception as ex:
        display.error(ex)
        raise AssertionError('Discover interpreter failed when testing python')

# Generated at 2022-06-24 18:47:06.926439
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = "Rd-U]()~}_T'}W"
    str_1 = "}m9y_^"
    float_0 = 78.0
    result = discover_interpreter(str_0, str_0, str_1, float_0)
    assert result == 'Rd-U]()~}_T\'}W'



# Generated at 2022-06-24 18:47:13.351434
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Case 0:
    try:
        str_0 = "Rd-U]()~}_T'}W"
        bytes_0 = b'\xf4\xf9\xef\x98{6\xce\x17\x1a\xc1j\xc0\xe8'
        float_0 = 78.0
        var_0 = discover_interpreter(str_0, bytes_0, str_0, float_0)
    except Exception as ex:
        var_0 = None

    assert var_0 == None


# Generated at 2022-06-24 18:47:17.644371
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# Generated at 2022-06-24 18:47:18.694582
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # invoke function for testing
    test_case_0()

# Generated at 2022-06-24 18:47:22.344778
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = "Rd-U]()~}_T'}W"
    bytes_0 = b'\xf4\xf9\xef\x98{6\xce\x17\x1a\xc1j\xc0\xe8'
    float_0 = 78.0
    var_0 = discover_interpreter(str_0, bytes_0, str_0, float_0)
    assert str_0
    assert bytes_0
    assert float_0
    assert var_0


# Generated at 2022-06-24 18:47:26.094547
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: enhance test coverage
    str_0 = "Rd-U]()~}_T'}W"
    bytes_0 = b'\xf4\xf9\xef\x98{6\xce\x17\x1a\xc1j\xc0\xe8'
    float_0 = 78.0
    assert discover_interpreter(str_0, bytes_0, str_0, float_0) == None

# Generated at 2022-06-24 18:47:31.707395
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # str_0 = "Rd-U]()~}_T'}W"
    # bytes_0 = b'\xf4\xf9\xef\x98{6\xce\x17\x1a\xc1j\xc0\xe8'
    # float_0 = 78.0
    # var_0 = discover_interpreter(str_0, bytes_0, str_0, float_0)
    pass

# Generated at 2022-06-24 18:47:48.613454
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:47:58.833667
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test with a host that returns "No python interpreters found" and :ref:`AUTO_DISCOVERY_MODE=legacy_silent`
    #
    # SETUP
    module_name = None
    module_args = None
    task_vars = {
        "inventory_hostname": "host_0",
        "config": {
            "AUTO_DISCOVERY_MODE": "legacy_silent",
            "INTERPRETER_PYTHON_DISTRO_MAP": {},
            "INTERPRETER_PYTHON_FALLBACK": ["/usr/bin/test_python", "/usr/bin/python3.8"],
            "interpreter_python_discovery_warnings": [],
        }
    }
    # END SETUP
    # TEST
    result = discover

# Generated at 2022-06-24 18:47:59.945901
# Unit test for function discover_interpreter
def test_discover_interpreter():
    res = discover_interpreter()
    assert_equals(res, expected)
    


# Generated at 2022-06-24 18:48:05.256164
# Unit test for function discover_interpreter
def test_discover_interpreter():

    assert discover_interpreter(action = '', interpreter_name = 'python', discovery_mode = 'auto_legacy_silent', task_vars = '') == ''
    assert discover_interpreter(action = '', interpreter_name = 'python', discovery_mode = 'auto_legacy_silent', task_vars = '',) == ''
    assert discover_interpreter(action = '', interpreter_name = 'python', discovery_mode = 'auto_silent', task_vars = '') == ''
    assert discover_interpreter(action = '', interpreter_name = 'python', discovery_mode = 'auto_silent', task_vars = '',) == ''
    assert discover_interpreter(action = '', interpreter_name = 'python', discovery_mode = 'off', task_vars = '') == ''

# Generated at 2022-06-24 18:48:12.499729
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # test_case_0
    discovered_interpreter = discover_interpreter('/bin/python', 'python', 'auto_legacy', {'inventory_hostname': 'unknown'})
    assert discovered_interpreter == u'/usr/bin/python'

# Generated at 2022-06-24 18:48:21.188029
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host = ''
    action = object()
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = {"inventory_vars": {}, "ansible_play_hosts_all": [host], "play_hosts": [host], "play_hosts_count": 1, "play_hosts_remaining": [host], "play_hosts_remaining_count": 1, "inventory_hostname": host, "inventory_hostname_short": host}
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert isinstance(res, str)

# Generated at 2022-06-24 18:48:23.624233
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # assert discover_interpreter() == expected_result
    test_discover_interpreter.answer = None


# Generated at 2022-06-24 18:48:31.513961
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = ':)'
    str_1 = ':('
    str_2 = 'discover'
    str_3 = 'allow'

    str_4 = ':)'
    str_5 = ':('
    str_6 = 'discover'
    str_7 = 'allow'

    str_8 = ':)'
    str_9 = ':('
    str_10 = 'discover'
    str_11 = 'allow'

    str_12 = ':)'
    str_13 = ':('
    str_14 = 'discover'
    str_15 = 'allow'
    str_16 = 'allow'
    str_17 = 'allow'
    str_18 = 'allow'
    str_19 = 'allow'
    str_20 = 'allow'

# Generated at 2022-06-24 18:48:42.918224
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_str_str_str_str_0 = ':+/'
    str_str_str_str_str_1 = ':+/'
    str_str_str_str_str_2 = ':+/'
    str_str_str_str_str_3 = ':+/'
    str_str_str_str_str_4 = ':+/'
    str_str_str_str_str_5 = ':+/'
    str_str_str_str_str_6 = ':+/'
    str_str_str_str_str_7 = ':+/'
    str_str_str_str_str_8 = ':+/'
    str_str_str_str_str_9 = ':+/'
    str_str_str_str_

# Generated at 2022-06-24 18:48:49.744271
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Input parameters
    action_0 = None
    interpreter_name_0 = None
    discovery_mode_0 = None
    task_vars_0 = None

    # Outputs from the function
    discovered_interpreter_0 = None

    # Call the function
    discovered_interpreter_0 = discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)
    assert discovered_interpreter_0 is None

    # Call the function with arguments macro-substituted
    discovered_interpreter_1 = discover_interpreter(action_0, interpreter_name_0, 'auto_legacy', task_vars_0)
    assert discovered_interpreter_1 is None


# Generated at 2022-06-24 18:49:00.359004
# Unit test for function discover_interpreter
def test_discover_interpreter():
    discover_interpreter(None, None, None, None)


# Generated at 2022-06-24 18:49:08.149542
# Unit test for function discover_interpreter
def test_discover_interpreter():
    dict_0 = {'inventory_hostname': 'localhost', 'interpreter_python_distro_map': {'fedora': {'28': '/usr/bin/python3'}, 'redhat': {'6': '/usr/bin/python2', '7': '/usr/bin/python3'}, 'debian': {'7': '/usr/bin/python2', '8': '/usr/bin/python3', '9': '/usr/bin/python3', '10': '/usr/bin/python3'}}, 'interpreter_python_fallback': ['/usr/bin/python']}
    str_0 = 'python'
    str_1 = 'auto'
    expected = '/usr/bin/python'
    actual = discover_interpreter(test_case_0, str_0, str_1, dict_0)

# Generated at 2022-06-24 18:49:17.929625
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Arguments used in test case
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = {}

    # Return value used in test case
    return_value = u'/usr/bin/python'

    # Return value used in test case
    expected_value = return_value
    try:
        return_value = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except Exception as e:
        display.info('Exception raised in test case: ' + type(e).__name__)
        raise
    else:
        assert return_value == expected_value


# Generated at 2022-06-24 18:49:24.890683
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = ':'
    bool_0 = None
    dict_0 = {str_0: bool_0}
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(str_0, bool_0, dict_0)
    str_1 = ':'
    bool_1 = None
    dict_1 = {str_0: bool_0}
    interpreter_discovery_required_error_1 = InterpreterDiscoveryRequiredError(str_1, bool_1, dict_1)
    str_2 = ':'
    bool_2 = None
    dict_2 = {str_0: bool_0}
    interpreter_discovery_required_error_2 = InterpreterDiscoveryRequiredError(str_2, bool_2, dict_2)
    str_3 = ':'
    bool

# Generated at 2022-06-24 18:49:29.334264
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # sample inputs and expected outputs.
    action_0 = str
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto'
    task_vars_0 = {u'inventory_hostname': u'localhost'}

    # pass in test values to the function.
    results_0 = discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)

    # unit tests
    assert isinstance(results_0, str)

    display.vvv(results_0)

# Generated at 2022-06-24 18:49:40.686116
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = '>'
    str_1 = '/'
    tuple_0 = (str_1, str_0)
    tuple_1 = (str_1, str_1)
    dict_0 = {tuple_0: tuple_1}
    str_2 = 'a'
    str_3 = 'c'
    str_4 = '@'
    str_5 = 'b'
    str_6 = '-'
    tuple_2 = (str_2, str_3, str_4)
    tuple_3 = (str_5, str_6)
    tuple_4 = (tuple_2, tuple_3)
    str_7 = 'd'
    str_8 = 'e'
    str_9 = 'h'

# Generated at 2022-06-24 18:49:44.504602
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {}

    # Test 1
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res is None

# Generated at 2022-06-24 18:49:45.429464
# Unit test for function discover_interpreter
def test_discover_interpreter():
  assert True # TODO: implement your test here


# Generated at 2022-06-24 18:49:49.872019
# Unit test for function discover_interpreter
def test_discover_interpreter():
    #monkeypatch.setattr('ansible.executor.discovery.plugin_loader.all_plugin_dirs', lambda: ['/home/travis/build/ansible/ansible/lib/ansible/plugins/action/'])
    assert discover_interpreter(u'/usr/bin/python', u'python', u'auto', u'unknown') == u'/usr/bin/python'


# Generated at 2022-06-24 18:49:53.948645
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars0 = {u'inventory_hostname': u'localhost.localdomain'}
    action0 = None
    interpreter_name0 = u'python'
    discovery_mode0 = u'auto_silent'
    res0 = discover_interpreter(action0, interpreter_name0, discovery_mode0, task_vars0)
    assert res0 == u'/usr/bin/python'


# Generated at 2022-06-24 18:50:11.156787
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        str_0 = 'python'
        str_1 = 'python'
        str_2 = 'python'
        str_3 = 'python'
        var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    except Exception as exception_0:
        assert False
    else:
        assert True


# Tests for InterpreterDiscoveryRequiredError

# Generated at 2022-06-24 18:50:14.900043
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == '/usr/bin/python'


# Generated at 2022-06-24 18:50:19.252785
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception as e:
        import traceback, sys
        print(traceback.format_exc())
        print(sys.exc_info())


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:50:22.164942
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    assert discover_interpreter(str_0, str_0, str_0, str_0) == "/usr/bin/python"


# Generated at 2022-06-24 18:50:29.778727
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    mock_0 = Mock(name='action')
    def side_effect_function():
        return str_0
    mock_0.interpreter = MagicMock(name='_low_level_execute_command', side_effect=side_effect_function)
    mock_0.discovery = MagicMock(name='_low_level_execute_command', side_effect=side_effect_function)
    mock_0.warnings = MagicMock(name='_low_level_execute_command', side_effect=side_effect_function)

    var_0 = discover_interpreter(mock_0, str_0, str_0, str_0)
    assert var_0 == str_0

# Generated at 2022-06-24 18:50:33.712175
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == '/usr/bin/python'


# Generated at 2022-06-24 18:50:36.508590
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # These inputs are artificial and may not represent actual use cases.
    test_case_0()


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:50:38.035271
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True
    #test_case_0()

# Generated at 2022-06-24 18:50:40.855630
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except:
        display.error('Test case 0 failed:')
        raise
    else:
        display.vvv('All test cases passed.')



# Generated at 2022-06-24 18:50:43.675951
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test execution
    test_case_0()

if __name__ == '__main__':
    # Equivalent of unittest.main()
    test_discover_interpreter()

# Generated at 2022-06-24 18:51:05.862323
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert 'FOUND' or ''


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:51:06.579156
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True

# Generated at 2022-06-24 18:51:09.400591
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert False, "No test implemented"

if __name__ == '__main__':
    test_discover_interpreter()
    # example of how to use the interpreter discovery results
    # print(discover_interpreter('auto', 'python', 'auto', {}))

# Generated at 2022-06-24 18:51:17.841964
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'auto_legacy_silent'
    str_2 = ''
    str_3 = 'Raspbian'
    str_4 = '9'
    str_5 = 'auto_legacy_silent'
    str_6 = 'python'
    str_7 = 'unsupported platform'
    str_8 = '/usr/bin/python'
    str_9 = 'auto'
    str_10 = 'unknown'
    str_11 = 'fallback'
    str_12 = 'auto_silent'
    str_13 = 'python'
    str_14 = 'python'
    str_15 = 'fallback'
    str_16 = 'auto'
    str_17 = 'auto_silent'
    str_18 = 'auto_silent'

# Generated at 2022-06-24 18:51:20.783674
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(str_0, str_0, str_0, str_0) == var_0

# Generated at 2022-06-24 18:51:28.050798
# Unit test for function discover_interpreter
def test_discover_interpreter():
    platform_python_map = {
        'ubuntu': {
            '14.04': '/usr/bin/python3',
            '16.04': '/usr/bin/python3',
            '17.10': '/usr/bin/python3',
            '18.04': '/usr/bin/python3',
        },
        'fedora': {
            '28': '/usr/bin/python3',
            '29': '/usr/bin/python3',
        },
        'redhat': {
            '7': '/usr/bin/python2',
        },
        'debian': {
            'wheezy': '/usr/bin/python3',
            'jessie': '/usr/bin/python3',
        },
    }

# Generated at 2022-06-24 18:51:34.275491
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'python'
    str_2 = 'python'
    str_3 = 'python'

    # Test case 0
    res = discover_interpreter(str_0, str_1, str_2, str_3)
    # Call function 'discover_interpreter' with arguments (str, str, str, str)
    str_4 = 'python'
    assert res == str_4



# Generated at 2022-06-24 18:51:37.708131
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        assert discover_interpreter('action', 'interpreter_name', 'discovery_mode', 'task_vars') == None
    except NotImplementedError as ex:
        if str(ex) != "'unsupported platform for extended discovery: python'":
            raise AssertionError(ex)

# Generated at 2022-06-24 18:51:40.452926
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    print("Result: " + str(var_0))
    pass



# Generated at 2022-06-24 18:51:43.088855
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("Unit test for function: discover_interpreter")
    print("Test case 0: ")
    test_case_0()
    print("Test success")


if __name__ == '__main__':

    test_discover_interpreter()

# Generated at 2022-06-24 18:52:29.662640
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception:
        pass


# Generated at 2022-06-24 18:52:37.987536
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # !! Warning: This function and the one(s) it calls may be
    # !! destructively modifying your list of inventory hosts.
    # !! Consider using --limit to restrict the hosts to a test
    # !! system.
    hosts = inventory.get_hosts()
    for h in hosts:
        h.vars['tox_interpreter_discovery_mode'] = u'auto'
        h.vars['tox_test_case_var_0'] = u'python'
    test_case_0(hosts[0], hosts[0].vars['tox_test_case_var_0'], hosts[0].vars['tox_interpreter_discovery_mode'], hosts[0].vars)

# Generated at 2022-06-24 18:52:39.791689
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        assert_equals(test_case_0(), None)
    except (AssertionError, TypeError) as e:
        print(e)
        throw(e)

test_discover_interpreter()

# Generated at 2022-06-24 18:52:49.697885
# Unit test for function discover_interpreter
def test_discover_interpreter():
    ofp = open("test/results/output_discovery.txt", "w")
    ofp.write("")
    ofp.close()

    from ansible.module_utils.basic import AnsibleModule
    module_args = dict(
        executable=dict(type='str', required=False, default='python'),
        discovery_mode=dict(type='str', required=False, default='auto')
    )

    result = dict(
        changed=False,
        interpreter='python',
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )


# Generated at 2022-06-24 18:52:56.858623
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_1 = ['~/.ansible/tmp/ansible-tmp-1558216447.15-207926980986425/ansible_python_select_payload']
    var_2 = 'host'

# Generated at 2022-06-24 18:53:06.449681
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:53:14.834208
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import pytest
    from ansible.utils.plugin_docs import get_versioned_doclink
    from ansible.module_utils.distro import LinuxDistribution
    from ansible.module_utils.compat.version import LooseVersion
    import re
    import json

    assert discover_interpreter is not None

    # First, try a simple run with the python3 interpreter
    python3_bootstrap = [u'/usr/bin/python3']
    python3_bootstrap_command_list = ["command -v '%s'" % py for py in python3_bootstrap]
    shell_bootstrap = "echo PLATFORM; uname; echo FOUND; {0}; echo ENDFOUND".format('; '.join(python3_bootstrap_command_list))
    # Get the platform info to use
    platform_python_map

# Generated at 2022-06-24 18:53:19.657989
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # not a proper unit test, just a sanity check for now...
    test_case_0()

# Generated at 2022-06-24 18:53:24.624620
# Unit test for function discover_interpreter
def test_discover_interpreter():
    for str_0 in [('py3'), ('python'), ('py2'), ('py0')]:
        try:
            test_case_0()
        except Exception as err:
            print(err)


test_discover_interpreter()

# Generated at 2022-06-24 18:53:26.898499
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == '/usr/bin/python'

# Generated at 2022-06-24 18:55:10.126639
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except:
        assert False

# PYTEST_VALIDATE_IGNORE_EXCEPTIONS = True


# Generated at 2022-06-24 18:55:12.594374
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# main function entry
if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:55:21.126432
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test with valid string arguments
    str_1 = 'linux'
    str_2 = '2.7.10'
    str_3 = 'ansible_connection=local'
    var_1 = discover_interpreter(str_1, str_2, str_3, str_1)
    assert var_1 == u'/usr/bin/python'

    # Test with valid int arguments
    int_1 = 1
    int_2 = 1
    int_3 = 2
    str_4 = 'linux'
    str_5 = '2.7.10'
    str_6 = 'ansible_connection=local'
    var_2 = discover_interpreter(int_1, int_2, int_3, str_4)
    assert var_2 == u'/usr/bin/python'

    # Test with

# Generated at 2022-06-24 18:55:22.740677
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert test_case_0() is None

# Generated at 2022-06-24 18:55:30.521291
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Input parameters
    action = 'some_action'

    interpreter_name = 'python'

    discovery_mode = 'auto_legacy_silent'

    task_vars = {'inventory_hostname': 'some_host'}

    try:
        result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:55:31.212662
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert False  # No test defined

# Generated at 2022-06-24 18:55:31.893413
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# Generated at 2022-06-24 18:55:35.035603
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host = 'test_host'
    action = 'dummy_action'
    interpreter_name = 'python'
    discovery_mode = 'default'
    task_vars = {'inventory_hostname': host}
    
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    # FIXME: assert something
    # assert (res != None)

# Unit test to test the default value of discovery_mode

# Generated at 2022-06-24 18:55:40.959958
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:55:45.772737
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()


if __name__ == '__main__':
    C.config.load_config_file()
    test_discover_interpreter()