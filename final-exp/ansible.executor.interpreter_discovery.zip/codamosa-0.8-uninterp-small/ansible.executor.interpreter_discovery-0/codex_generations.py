

# Generated at 2022-06-24 18:46:41.808682
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test case 1
    str_1 = 'EX\xee\xa9\xfc*\r\xc7'
    str_2 = '0  '
    bool_1 = False
    interpreter_discovery_required_error_1 = InterpreterDiscoveryRequiredError(str_1, str_2, bool_1)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()



# Generated at 2022-06-24 18:46:45.511994
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: check if type signature matches run-time signature
    action = unittest.mock()
    interpreter_name = 'test_name'
    discovery_mode = 'test_mode'
    task_vars = unittest.mock()
    var_0 = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert var_0 is None, 'return value not None'

# Generated at 2022-06-24 18:46:48.658588
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    res = discover_interpreter(None, 'python', 'auto_legacy_silent', task_vars)
    assert(res == '/usr/bin/python')

# Generated at 2022-06-24 18:46:58.361393
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """
    Unit test for function discover_interpreter
    """
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = None
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert isinstance(result, unicode)

    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = None
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert isinstance(result, unicode)

    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = None

# Generated at 2022-06-24 18:47:02.924155
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action_0 = u'_low_level_execute_command.py'
    interpreter_name_0 = 'test string'
    discovery_mode_0 = u'static_only'
    task_vars_0 = {}
    res = discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)
    assert (res == .787)

# Generated at 2022-06-24 18:47:04.405155
# Unit test for function discover_interpreter
def test_discover_interpreter():
    """Test cases for AnsibleModule._load_params()"""

    # TODO: how do we test this?

# Generated at 2022-06-24 18:47:08.232625
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = ""
    discovery_mode = ""
    task_vars = None
    An = to_text(discover_interpreter(action, interpreter_name, discovery_mode, task_vars))
    assert An == to_text(u'/usr/bin/python')

# Testing for edge cases

# Generated at 2022-06-24 18:47:12.729918
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Stub code to test with
    stub_action = StubActionClass()

    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = None
    assert discover_interpreter(stub_action, interpreter_name, discovery_mode, task_vars) == '/usr/bin/python'


# Generated at 2022-06-24 18:47:19.248653
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = ''
    interpreter_name = ''
    discovery_mode = ''
    task_vars = {}
    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == '/usr/bin/python'

# Unit test _get_linux_distro

# Generated at 2022-06-24 18:47:29.894115
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'snippet 1'
    str_1 = 'b\'SCQd\xde\xebP\xf8W\x1e'
    str_2 = 'unknown'
    str_3 = 'snippet 2'
    str_4 = 'b\x1c\xb4\xd0\x1d\xab\x9c\x0e'
    str_5 = 'unknown'
    str_6 = 'snippet 3'
    str_7 = 'b\x1b\xb0\xd2\x1c\xa2\x9b\x0b'
    str_8 = 'unknown'
    str_9 = 'snippet 4'

# Generated at 2022-06-24 18:47:44.478288
# Unit test for function discover_interpreter
def test_discover_interpreter():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()
    dict_21 = dict()
    dict_22 = dict()
    dict_23 = dict()
    dict_24 = dict()

# Generated at 2022-06-24 18:47:48.566089
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert '<unknown>' == discover_interpreter(action = '<unknown>', interpreter_name = '<unknown>', discovery_mode = '<unknown>', task_vars = '<unknown>')


# Generated at 2022-06-24 18:47:58.793155
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # if we run this from the toplevel, we're already importing the plugins, so try/except prevent tracebacks
    try:
        from ansible.plugins.action.normal import ActionModule as action
    except:
        # but if you're running this from a subdir and you haven't run "make", you need to load the plugins
        import ansible.plugins.action.normal
        action = ansible.plugins.action.normal.ActionModule

    task_vars = {
        'ansible_connection': 'network_cli',
        'ansible_user': 'test',
        'ansible_password': 'test',
        'ansible_port': 'test',
        'ansible_host': 'test',
        'inventory_hostname': 'test',
        'connection': 'local'
    }

    # note that the last 2 return

# Generated at 2022-06-24 18:48:01.413770
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = {'inventory_hostname': 'unknown'}
    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == u'/usr/bin/python'


# Generated at 2022-06-24 18:48:07.185667
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:48:19.750337
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # fail case
    try:
        discover_interpreter('action', 'interpreter_name', 'discovery_mode', 'task_vars')
    except TypeError as e:
        if str(e).startswith(str_0):
            print('Test passed.')
        else:
            print('Test failed: '+str(e))
    except Exception as e:
        print('Test failed: '+str(e))
    else:
        print('Test failed: no exception')

    # success case
    try:
        discover_interpreter('action', 'python', 'auto_legacy_silent', 'task_vars')
    except Exception as e:
        print('Test failed: '+str(e))
    else:
        print('Test passed.')

# Test entry point

# Generated at 2022-06-24 18:48:25.610503
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("TEST: discover_interpreter")

    # Test case:
    #    Run discover_interpreter with dummy values and check the return value.
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {}
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert result is not None
    print("SUCCESS: discover_interpreter return None")



# Generated at 2022-06-24 18:48:26.362577
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter == discover_interpreter()


# Generated at 2022-06-24 18:48:30.909324
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # prepare the test input
    action = 'Test'
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = 'Test'

    # Run the test
    results = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    # Verify the results
    assert results is not None
    assert results == u'/usr/bin/python' or results == '/usr/bin/python'


# Generated at 2022-06-24 18:48:32.998674
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(discover_interpreter, 'python', 'auto', 'task_vars') == None


# Generated at 2022-06-24 18:48:47.871718
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {'ansible_fqdn': 'fake', 'group_names': [], 'inventory_hostname': 'fake',
                 'play_hosts': ['fake'], 'play_hosts_all': ['fake']}
    result = discover_interpreter('', 'python', 'auto', task_vars)
    assert result == u'/usr/bin/python'

if __name__ == '__main__':
    # test_case_0()
    test_discover_interpreter()

# Generated at 2022-06-24 18:48:58.061155
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # interpret the string str0 = 'Test cases for AnsibleModule._load_params()' into the print format
    print('%s\n' % test_case_0.__doc__)

    # Test case 1: Create a test case class
    class TestCase():
        def __init__(self, **kwargs):
            self.action = kwargs.get('action', '')
            self.interpreter_name = kwargs.get('interpreter_name', '')
            self.discovery_mode = kwargs.get('discovery_mode', '')
            self.task_vars = kwargs.get('task_vars', '')
            self.ansible_module = kwargs.get('action', '')

# Generated at 2022-06-24 18:48:59.609737
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'Test cases for AnsibleModule._load_params()'


# Generated at 2022-06-24 18:49:00.933710
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert 'python' == discover_interpreter(str(0), 'python', 'auto_legacy', dict())

# Generated at 2022-06-24 18:49:04.881158
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Set up mock objects
    action = MockAction()
    action.module_name = 'ansible.module_utils.compat.discovery'
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {}
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert result == 'usr/bin/python'

# start of mocked objects

# Generated at 2022-06-24 18:49:13.519490
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Mock function: action._low_level_execute_command
    mock_action = ActionModule()
    mock_action._low_level_execute_command = MagicMock(return_value={})

    mock_task_vars = {}

    try:
        actual_output = discover_interpreter(mock_action, 'python', 'auto', mock_task_vars)
        print('\nActual output', actual_output)
        assert 'No python interpreters found for host unknown (tried /bin/python,/usr/bin/python)' in mock_action._discovery_warnings
        assert '/usr/bin/python' in actual_output
    except ValueError as exp:
        print('\nValueError exception was thrown')
        print(exp)
        assert 'unexpected output from Python interpreter discovery' in str(exp)


# Generated at 2022-06-24 18:49:16.276167
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FIXME: this test needs a mock action object, which doesn't exist yet...
    # output = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    pass


# Generated at 2022-06-24 18:49:20.829375
# Unit test for function discover_interpreter
def test_discover_interpreter():
    botsh.setup_module_args(dict(
        interpreter_name=dict(type='str', required=True),
        discovery_mode=dict(type='str', required=True),
    ))
    display.info(msg='Test cases for AnsibleModule._load_params()')
    test_case_0()

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:49:23.463989
# Unit test for function discover_interpreter
def test_discover_interpreter():
    arg0, arg1, arg2, arg3 = test_case_0()
    assert discover_interpreter(arg0, arg1, arg2, arg3) == 'Test cases for AnsibleModule._load_params()'
    # Fill in the rest of the test cases



# Generated at 2022-06-24 18:49:27.169942
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Unit test for function discover_interpreter
    # create an action
    # check to make sure the right interpreter is returned
    str_0 = 'discover_interpreter'
    str_1 = 'python'
    str_2 = 'auto'
    dict_0 = {}
    dict_1 = {}
    x = discover_interpreter(str_0, str_1, str_2, dict_0, dict_1)
    assert x


# Generated at 2022-06-24 18:49:37.650206
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True


# Generated at 2022-06-24 18:49:42.848376
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host = {
        'inventory_hostname': 'localhost',
        'ansible_python_interpreter': '/usr/bin/python3'
    }
    action = 'ping'
    interpreter = 'python'
    discovery_mode = 'auto'
    var = discover_interpreter(action, interpreter, discovery_mode, host)
    assert var == '/usr/bin/python3'

# Generated at 2022-06-24 18:49:44.898272
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
        assert False



# Generated at 2022-06-24 18:49:46.184658
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'python', None) == 'python'

# Generated at 2022-06-24 18:49:47.310703
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'python', None) is not None


# Generated at 2022-06-24 18:49:57.196716
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: add a test on hardcoded data (non-connection-dependency)

    # TODO: get some way to test Linux distributions other than Debian/Ubuntu (and the one I use)

    # test the Ubuntu fallback path
    action = object()
    action._connection = object()
    action._connection.has_pipelining = True
    action._low_level_execute_command = MockLowLevelExecuteCommand('ubuntu_uname', 'ubuntu_platform_data')
    action._discovery_warnings = []

    interpreter = discover_interpreter(action, 'python', 'auto', {'inventory_hostname': 'localhost'})

    assert interpreter == '/usr/bin/python3'

    # test the Debian fallback path
    action = object()
    action._connection = object()
    action._connection.has_p

# Generated at 2022-06-24 18:50:04.019920
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert u'/usr/bin/python' == discover_interpreter(
        None,
        'python',
        'python',
        None
    )

# Generated at 2022-06-24 18:50:09.993618
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        assert True == True # to show example of test in output
        test_case_0()
    except AssertionError as e:
        raise AssertionError(e)

    return

# Generated at 2022-06-24 18:50:13.896531
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # try:
    #     import ansible_test_data
    #     ans_test_data = ansible_test_data.TestData()
    # except ImportError:
    #     ans_test_data = None
    # For some reason we can't get ansible_test_data to import, so for now, just don't unit test this code.
    pass

# Generated at 2022-06-24 18:50:16.357392
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

if __name__ == '__main__':
    # Run simple test for module
    test_discover_interpreter()
    exit(0)

# Generated at 2022-06-24 18:50:38.375836
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        assert(discover_interpreter(None, 'python', None, None))
    except NotImplementedError:
        try:
            # Python 2
            raise Exception
        except Exception:
            e = sys.exc_info()[1]
            raise Exception(e.message)
    assert(discover_interpreter(None, 'python', None, None))

# Generated at 2022-06-24 18:50:47.618662
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = None
    str_0 = 'python'
    # Create mock var_1 for discover_interpreter(var_0, str_0, str_0, var_0)
    class Mock_var_1:
        pass
    var_1 = Mock_var_1()
    var_1.id = 'platform_dist_result'
    var_1.value = (u'centos', u'5.6', u'')
    var_1.mock_add_spec(platform_info)

    # Create mock var_2 for discover_interpreter(var_0, str_0, str_0, var_0)
    class Mock_var_2:
        pass
    var_2 = Mock_var_2()
    var_2.id = 'osrelease_content'
    var_2

# Generated at 2022-06-24 18:50:49.707977
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True is not False

# Unit test to check function _get_linux_distro

# Generated at 2022-06-24 18:50:56.315739
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert "dev_mode" in locals(), "dev_mode should be defined."
    assert "_testcase_index" in locals(), "_testcase_index should be defined."
    globals()["dev_mode"] = True
    globals()["_testcase_index"] = 0
    yield test_case_0

if __name__ == '__main__':
    # unit tests run in-line, and testcases are also run in-line (and don't get imported as modules)
    # In dev mode, run the tests in-line, but if a test fails, re-run it with more verbose output
    if dev_mode:
        test_case_index = 0

# Generated at 2022-06-24 18:51:01.499595
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = None
    str_0 = 'python'
    var_1 = discover_interpreter(var_0, str_0, str_0, var_0)
    str_1 = ''
    str_2 = ''
    test_case_0(var_0, str_0, str_1, str_2, var_1)


# Generated at 2022-06-24 18:51:09.195497
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: compose test data here
    test_data = (
        # First argument, a variable.
        (
            # TODO: compose test data here
            None,  # TODO: first test variable
        ),
        # Second argument, a variable.
        (
            # TODO: compose test data here
            None,  # TODO: second test variable
        ),
        # Third argument, a variable.
        (
            # TODO: compose test data here
            None,  # TODO: third test variable
        ),
        # Fourth argument, a variable.
        (
            # TODO: compose test data here
            None,  # TODO: fourth test variable
        ),
    )

    for test in test_data:
        # TODO: insert test code here
        raise Exception("test not implemented")

# Unit

# Generated at 2022-06-24 18:51:12.444362
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {}
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'

    val = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert val


# Generated at 2022-06-24 18:51:15.389185
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # First test case
    str_0 = 'python'
    var_0 = None
    var_1 = discover_interpreter(var_0, str_0, str_0, var_0)
    assert var_1 == 'python'

# Generated at 2022-06-24 18:51:23.752496
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = 'action'
    str_0 = 'python'
    str_1 = 'auto_legacy_silent'
    str_2 = 'task_vars'
    var_1 = discover_interpreter(var_0, str_0, str_1, str_2)
    var_2 = '/usr/bin/python'
    assert var_1 == var_2



# Generated at 2022-06-24 18:51:24.356551
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True

# Generated at 2022-06-24 18:52:09.120219
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Testing Python interpreter discovery
    # test case 0
    try:
        test_case_0()
    except ValueError as e:
        assert str(e) == 'unexpected output from Python interpreter discovery'
    except Exception as e:
        assert False


# Generated at 2022-06-24 18:52:16.582511
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var__0 = None
    var__1 = None
    str_0 = 'python'
    str_1 = 'auto'
    res_0 = discover_interpreter(var__0, str_0, str_1, var__1)
    res_1 = discover_interpreter(var__0, str_0, str_1, var__1)
    assert res_0 == res_1, 'Expected return values identical'
    print('Success: test_discover_interpreter')



# Generated at 2022-06-24 18:52:18.953254
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = None
    str_0 = 'python'
    var_1 = discover_interpreter(var_0, str_0, str_0, var_0)
    assert var_1 is None


# Generated at 2022-06-24 18:52:24.230545
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = None
    str_0 = 'python'
    str_1 = 'python'
    res = discover_interpreter(var_0, str_0, str_1, var_0)
    assert "python" in res

# Generated at 2022-06-24 18:52:30.228268
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_cases = [
        {
            'action': None,
            'interpreter_name': 'python',
            'discovery_mode': 'auto',
            'task_vars': None
        }
    ]

    for test_case in test_cases:
        try:
            result = discover_interpreter(**test_case)
        except:
            print('FAILED!\nFailed to discover interpreter in testcase: {testcase}'.format(testcase=test_case))
            raise



# Generated at 2022-06-24 18:52:32.440418
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert to_native(discover_interpreter(var_0, str_0, str_0, var_0)) == 'python'

# Generated at 2022-06-24 18:52:36.757004
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Get params
    var_1 = 'python'
    var_2 = 'smart'
    var_3 = None
    # Test function
    str_1 = discover_interpreter(var_1, var_2, var_3)
    print("discover_interpreter: " + str_1)
    #assert str_1 == # TODO: write test

# Generated at 2022-06-24 18:52:39.752308
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print('Test case 0')
    print('Test case 0 - Python')
    test_case_0()

if __name__ == '__main__':
    print('Executing test cases')
    test_discover_interpreter()

# Generated at 2022-06-24 18:52:42.614398
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = None
    var_1 = discover_interpreter("None", "python", "python", "None")
    print(var_1)
    assert var_1



# Generated at 2022-06-24 18:52:44.117099
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'python', None) is not None, 'Unexpected value returned'

# Generated at 2022-06-24 18:54:38.422366
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test raise exception when interpreter_name != 'python'
    try:
        str_0 = 'ruby'
        str_1 = 'auto_legacy'
        var_0 = None
        discover_interpreter(var_0, str_0, str_1, var_0)
    except ValueError as ex:
        msg = u'Interpreter discovery not supported for {0}'.format(str_0)
        assert ex is not None and msg == to_text(ex)

    # Test error when InterpreterDiscoveryRequiredError raised

# Generated at 2022-06-24 18:54:43.203476
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = None
    str_0 = ''
    str_1 = ''
    test_case_0()
    assert discover_interpreter(var_0, str_0, str_1, var_0) == '/usr/bin/python'
    assert discover_interpreter(var_0, str_1, str_0, var_0) == '/usr/bin/python'
    assert discover_interpreter(var_0, str_1, str_1, var_0) == '/usr/bin/python'
    assert discover_interpreter(var_0, str_0, str_0, var_0) == '/usr/bin/python'
    assert discover_interpreter(var_0, str_0, str_1, var_0) == '/usr/bin/python'
    assert discover_inter

# Generated at 2022-06-24 18:54:44.817270
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(None, 'python', 'python', None)



# Generated at 2022-06-24 18:54:47.756105
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_14 = None
    var_15 = 'python'
    var_16 = _get_linux_distro(var_14)
    var_17 = discover_interpreter(var_14, var_15, var_15, var_14)
    if var_17 != None:
        assert True
    else:
        assert False


# Generated at 2022-06-24 18:54:50.670913
# Unit test for function discover_interpreter
def test_discover_interpreter():
    platform_type = 'linux'
    found_interpreters = [u'/usr/bin/python']  # fallback value



# Generated at 2022-06-24 18:54:53.851366
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception as ex:
        assert False, 'Expected no exceptions, got: ' + str(ex)



# Generated at 2022-06-24 18:54:55.139940
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO:  expected result?
    pass


# Generated at 2022-06-24 18:55:01.645719
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test with a arguments
    var_0 = None
    str_0 = 'python'
    var_1 = discover_interpreter(var_0, str_0, str_0, var_0)
    #assert var_1 == ''
    print(var_1)

# test_discover_interpreter()
test_case_0()

# Generated at 2022-06-24 18:55:06.611425
# Unit test for function discover_interpreter
def test_discover_interpreter():
    with pytest.raises(ValueError):
        var_0 = None
        str_0 = 'python'
        str_1 = 'python'
        discover_interpreter(var_0, str_0, str_1, var_0)



# Generated at 2022-06-24 18:55:16.065224
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        var_1 = None
        str_0 = 'python'
        str_1 = 'auto'
        discover_interpreter(var_1, str_0, str_1, var_1)
        display.warning('*** UNIT TEST SUCCESS: discover_interpreter ***')
    except ValueError as ex:
        display.warning('*** UNIT TEST FAILED: discover_interpreter ***' + str(ex))
    except NotImplementedError as ex:
        display.warning('*** UNIT TEST FAILED: discover_interpreter ***' + str(ex))
    except Exception as ex:
        display.warning('*** UNIT TEST FAILED: discover_interpreter ***' + str(ex))

