

# Generated at 2022-06-24 18:46:39.465739
# Unit test for function discover_interpreter
def test_discover_interpreter():
    connection_0 = MagicMock()
    action_0 =  ActionModule(connection_0, 'dragon', False, 'dragon')
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'dragon'
    task_vars_0 = {}
    result_0 = discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)
    assert result_0 == '/usr/bin/python'


# Generated at 2022-06-24 18:46:47.815669
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test case_0
    float_0 = -292.22005
    bool_0 = False
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(float_0, bool_0, float_0)
    # TODO: Write implementaton


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:46:57.034707
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'always'
    task_vars = {
        'inventory_hostname': 'localhost',
    }
    action_0 = None


    # Calling discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    try:
        assert interpreter_name == 'python' and discovery_mode == 'always' and task_vars == {'inventory_hostname': 'localhost'}
        assert action_0 is None
        # Test does not throw an exception
        pass
    except Exception as ex:
        assert False, 'discover_interpreter(action, interpreter_name, discovery_mode, task_vars) threw an exception'


# Generated at 2022-06-24 18:46:58.199359
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:47:05.928853
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Create mock object for args
    class args_0(object):
        action = 'get_inventory'

    action_0 = args_0()
    # Create mock object for task_vars
    class task_vars_0(object):
        inventory_hostname = 'hostname_0'

    task_vars_0 = task_vars_0()
    # Create mock object for task_vars['inventory_hostname']
    class inventory_hostname_0(object):
        pass

    inventory_hostname_0 = inventory_hostname_0()
    task_vars_0.inventory_hostname = inventory_hostname_0
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto'
    # Call function discover_interpreter with args (action_0, interpreter_name_0

# Generated at 2022-06-24 18:47:10.695112
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = ()
    interpreter_name = 'test_interpreter'
    discovery_mode = 'test_discovery_mode'
    task_vars = {}
    try:
        result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except Exception as ex:
        result = ex
    assert isinstance(result, InterpreterDiscoveryRequiredError)



# Generated at 2022-06-24 18:47:17.264298
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()

    try:
        ansible_facts = {"interpreter_python_distro_map": "platform_python_interpreter_map",
                         "interpreter_python_fallback": "python_interpreter_list"}
        task_vars = {"ansible_facts": ansible_facts, "ansible_check_mode": True}
        result = discover_interpreter(task_vars['ansible_facts'], task_vars['ansible_check_mode'], task_vars)
        print(result)
    except Exception as ex:
        print(ex)


# Generated at 2022-06-24 18:47:18.460529
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# Generated at 2022-06-24 18:47:29.079372
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.six import PY3
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    string_0 = 'string'
    string_1 = 'string'
    unicode_0 = u'unicode'
    unicode_1 = u'unicode'
    float_0 = -292.22005
    bool_0 = False
    float_1 = -292.22005
    bool_1 = False
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(float_0, bool_0, float_0)
    unicode_2 = u'unicode'
    unicode_3 = u'unicode'

# Generated at 2022-06-24 18:47:30.130396
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_0()
    test_1()


# Generated at 2022-06-24 18:47:57.136927
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {"inventory_hostname": "localhost"}
    action = object()
    action._low_level_execute_command = object()
    action._low_level_execute_command.return_value = {'stderr': None, 'stdout': "\n"}
    action._connection = object()
    action._connection.has_pipelining = False

    action._discovery_warnings = []

    test_cases = [
        {'interpreter_name': 'python', 'discovery_mode': 'auto', 'task_vars': task_vars,
         'return_val': to_text(u'/usr/bin/python')}
    ]

    for test_case in test_cases:
        discover_interpreter(action, **test_case)
        # we don't actually check particular return values here

# Generated at 2022-06-24 18:48:04.553263
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import BytesIO


# Generated at 2022-06-24 18:48:19.422100
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test function call with parameters, then return to their original values
    float_0 = -292.22005
    bool_0 = False
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto_legacy'
    task_vars_0 = {'var_0': 'a', 'var_1': 'b', 'var_2': 'c'}
    result_0 = '/usr/bin/python'
    assert result_0 == discover_interpreter(float_0, interpreter_name_0, discovery_mode_0, task_vars_0)
    interpreter_name_1 = 'a'
    discovery_mode_1 = 'auto'
    task_vars_1 = {'var_0': 'a', 'var_1': 'c', 'var_2': 'd'}


# Generated at 2022-06-24 18:48:20.846279
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This function is a stub, test is required
    assert True



# Generated at 2022-06-24 18:48:24.449411
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # input arguments
    action = ''
    interpreter_name = ''
    discovery_mode = ''
    task_vars = {}

    # perform the run
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    # assert result
    assert result is None


# Generated at 2022-06-24 18:48:31.961118
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # For test_case_0
    float_0 = -292.22005
    bool_0 = False
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(float_0, bool_0, float_0)
    try:
        discover_interpreter(interpreter_discovery_required_error_0, float_0, bool_0, float_0)
    except Exception as exception_0:
        assert type(exception_0) == ValueError
    # For test_case_1
    bool_3 = True
    str_1 = 'endwith_silent'
    float_1 = -0.4023
    try:
        discover_interpreter(bool_3, str_1, float_1, bool_3)
    except Exception as exception_1:
        assert type

# Generated at 2022-06-24 18:48:33.542841
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: need to write unit tests for this function
    pass



# Generated at 2022-06-24 18:48:44.595842
# Unit test for function discover_interpreter
def test_discover_interpreter():
    float_0 = -293.1
    int_0 = -246
    bool_0 = False
    list_0 = [float_0, float_0]
    str_0 = 'N ZY'
    dict_0 = {'Nq3B' : list_0, 'Q2bU' : int_0, 'U6Fd' : str_0, 'g' : bool_0, 'h' : str_0, 'i' : int_0, 'j' : bool_0}
    dict_1 = {'Nq3B' : dict_0, 'Q2bU' : dict_0, 'U6Fd' : dict_0, 'g' : dict_0, 'h' : dict_0, 'i' : dict_0, 'j' : dict_0}
    dict_2

# Generated at 2022-06-24 18:48:47.649909
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: update test cases with branch coverage
    # FUTURE: add more test cases for coverage
    try:
        test_case_0()
    except ValueError as e:
        pass

# Generated at 2022-06-24 18:48:50.927501
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print(to_text(discover_interpreter()))


if __name__ == '__main__':
    # Unit test for function discover_interpreter
    test_discover_interpreter()

# Generated at 2022-06-24 18:49:14.970704
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # See full catalog of available assertions: http://tinyurl.com/python-assert
    # Note: these only validate the module functionality, and not the YAML/JSON files
    from ansible.module_utils.compat.test import TestCase

    class TestHost(object):
        def __init__(self, name, vars):
            self._name = name
            self._vars = vars

        @property
        def name(self):
            return self._name

        @property
        def vars(self):
            return self._vars

    class TestPlayContext(object):
        def __init__(self, **kwargs):
            self._dict = kwargs

        def __getattr__(self, item):
            return self._dict[item]


# Generated at 2022-06-24 18:49:23.194244
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class MockDisplay:
        def __init__(self):
            self.message = None
            self.level = None
            self.all_messages = []

        def debug(self, message, host=None):
            self.all_messages.append(dict(level='debug', message=message, host=host))

        def vvv(self, message, host=None):
            self.all_messages.append(dict(level='vvv', message=message, host=host))

        def warning(self, message, host=None):
            self.all_messages.append(dict(level='warning', message=message, host=host))

    class MockAction:
        def __init__(self):
            self._connection = MockConnection()


# Generated at 2022-06-24 18:49:32.903251
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert re.match('<ansible_facts>.*</ansible_facts>', discover_interpreter(action,interpreter_name='python',discovery_mode='auto_legacy_silent',task_vars=''))

#
# Example for how to use the class to provide some user feedback on error or to
# fix specific errors.
#
# This code is not used for anything in Ansible itself, but if you want
# to use the class, you can use these examples similar to how the
# "InterpreterDiscoveryRequiredError" exception is handled in the module_utils
# code itself.
#
# To use this you need to override the runner/action.py '_execute_module'
# method (for example in your connection/plugin) and add this (or similar)
# code there.
#
# def _execute_module

# Generated at 2022-06-24 18:49:38.309257
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test to verify that the function at least returns a string type
    assert (isinstance(discover_interpreter(discover_interpreter, discover_interpreter, discover_interpreter, discover_interpreter), str)
        ), "The return value of discover_interpreter is not the correct type"


# Generated at 2022-06-24 18:49:47.982721
# Unit test for function discover_interpreter
def test_discover_interpreter():
    content = "test string"
    action_0 = InterpreterDiscoveryRequiredError(content, content, content)

    interpreter_name_0 = "test string"
    discovery_mode_0 = "test string"
    task_vars_0 = "test string"

    # Call function with args
    try:
        discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)
    except InterpreterDiscoveryRequiredError as error:
        print(error)
        return False

    # Call function with args
    try:
        discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)
    except InterpreterDiscoveryRequiredError as error:
        print(error)
        return False

    output = discover

# Generated at 2022-06-24 18:49:49.981514
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE
    return


if __name__ == "__main__":
    test_case_0()
    test_discover_interpreter()

# Generated at 2022-06-24 18:49:53.267021
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: implement tests
    args = {"action": "action", "interpreter_name": "interpreter_name", "discovery_mode": "discovery_mode", "task_vars": "task_vars"}
    rval = discover_interpreter(**args)
    assert rval != None

# Generated at 2022-06-24 18:49:56.428471
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host_0 = 'host_0'
    task_vars_0 = {'inventory_hostname': host_0}
    result = discover_interpreter('action', 'python', 'auto_legacy', task_vars_0)
    assert result == '/usr/bin/python'


# Generated at 2022-06-24 18:50:03.663378
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test different combinations and verify results

    # test full match
    assert _version_fuzzy_match('2.6.9', {'2.6.9': 'python-2.6.9', '2.6.8': 'python-2.6.8', '2.6.10': 'python-2.6.10'}) == 'python-2.6.9'

    # test slot match
    assert _version_fuzzy_match('2.6.9', {'2.6.9': 'python-2.6.9', '2.6.10': 'python-2.6.10'}) == 'python-2.6.10'

    # test older match

# Generated at 2022-06-24 18:50:14.080307
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This call to `discover_interpreter` will raise an exception because
    # the test does not specify a task_vars parameter.
    try:
        display.vvv(msg='Attempting python interpreter discovery')
        args = "python"
        kwargs = {
            "interpreter_name": "python",
            "discovery_mode": "auto",
            "task_vars": {},
        }
        discover_interpreter(**kwargs)
    except InterpreterDiscoveryRequiredError as e:
        # This assert is just used to check that the exception was raised
        # and isn't used for the test's actual assertion.
        assert(isinstance(e, InterpreterDiscoveryRequiredError))
        assert(e.interpreter_name == "python")

# Generated at 2022-06-24 18:50:41.124387
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Mock action
    class Mock_action:
        def __init__(self):
            self.container = {}

        def get(self, key, value=None):
            if key in self.container:
                return self.container[key]
            return value

        def __setitem__(self, key, value):
            self.container[key] = value

        def _low_level_execute_command(self, python_0, sudoable_0=False, in_data_0=None):
            return {"stdout": "xyz", "stderr": "abc"}

        def has_pipelining(self):
            return True

    # Mock task_vars
    class Mock_task_vars:
        def __init__(self):
            self.container = {}


# Generated at 2022-06-24 18:50:42.848385
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:50:50.645629
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert _version_fuzzy_match(LooseVersion('1.2.3'), {'1.0.0': 1, '1.2.0': 2, '2.0.0': 3}) == 2
    assert _version_fuzzy_match(LooseVersion('1.3.3'), {'1.0.0': 1, '1.2.0': 2, '2.0.0': 3}) == 3
    assert _version_fuzzy_match(LooseVersion('1.3.3'), {'1.0.0': 1, '1.2.0': 2}) == 1
    assert _version_fuzzy_match(LooseVersion('1.3.3'), {}) == None



# Generated at 2022-06-24 18:50:55.017208
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # 1. Test: Empty interpreter_name 

    interpreter_name = ''

    # Test case 1
    assert discover_interpreter(interpreter_name) == 'python'

    # 2. Test: Non-empty interpreter_name

    interpreter_name = 'python'

    # Test case 2
    assert discover_interpreter(interpreter_name) == 'python'

# Generated at 2022-06-24 18:51:01.687076
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Setup args and inputs
    action = MagicMock()
    interpreter_name = "python"
    discovery_mode = "auto"
    task_vars = {
        'inventory_hostname': 'localhost',
        'ansible_python_interpreter': '',
        'ansible_python_version': '',
        'ansible_python_version_compare': False
    }

    _detected_interpreter = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    if _detected_interpreter != '/usr/bin/python':
        print("Expected: /usr/bin/python")
        print("Got: {0}".format(_detected_interpreter))
        assert False



# Generated at 2022-06-24 18:51:06.383045
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 18:51:13.178930
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # First setup the test skeleton
    test_args = {}
    test_kwargs = {}
    test_args['action'] = "action"  #
    test_kwargs['interpreter_name'] = "python"  #
    test_kwargs['discovery_mode'] = "auto"  #
    test_args['task_vars'] = "task_vars"  #

    # TODO: Determine a way to insert the test args and kwargs

    # TODO: Remove this 'if' block, and replace it with the test logic
    if False:
        display.warning(u'discover_interpreter() not implemented')
        # Insert test logic here
        raise ValueError(u'Test logic for function discover_interpreter not implemented')

    # TODO: Remove this 'if' block and replace it with the test

# Generated at 2022-06-24 18:51:18.530774
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test the expected functionality
    display.vvv(msg='Test::expected functionality')
    exc = Exception
    # FIXME: Pass in a valid task_vars
    task_vars = {}
    interpreter_name = ''
    discovery_mode = ''
    discover_interpreter(exc, interpreter_name, discovery_mode, task_vars)

    # Test the negative cases
    display.vvv(msg='Test::negative cases')
    # FIXME: Add a valid negative test


# Generated at 2022-06-24 18:51:22.857966
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = dict(ansible_python_interpreter='/usr/bin/python')

    assert callable(discover_interpreter)

# Generated at 2022-06-24 18:51:26.692610
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = None
    discovery_mode = None
    task_vars = None
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    assert result is None


# Generated at 2022-06-24 18:52:03.149536
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import InterpreterDiscoveryRequiredError
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule, get_exception

    test_case_0()



# Generated at 2022-06-24 18:52:06.700567
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# vim: expandtab tabstop=4 shiftwidth=4 autoindent

# Generated at 2022-06-24 18:52:10.491153
# Unit test for function discover_interpreter
def test_discover_interpreter():
    discover_interpreter('test', 'test', 'test', 'test')


# Generates a dict of ANSIBLE_TEST_PRIVATE_INTERPRETER_DISCOVERY_MODE values
# that leave the value in question set to the desired mode, and all others set
# to 'auto'.

# Generated at 2022-06-24 18:52:15.690999
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        action = var_0
        interpreter_name = var_0
        discovery_mode = var_0
        task_vars = var_0
        test_case_0()
    except Exception as var_1:
        assert False
        raise
    else:
        assert True


# Generated at 2022-06-24 18:52:18.189405
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # See https://docs.python.org/2/library/unittest.html
    pytest.xfail("Failing until discover_interpreter is updated to not use Ansible 2.0 APIs")
    test_case_0()

# Generated at 2022-06-24 18:52:30.031565
# Unit test for function discover_interpreter
def test_discover_interpreter():
    arg0 = InterpreterDiscoveryRequiredError('Interpreter discovery required, but discovery mode is not set', 'python', 'auto')
    arg1 = InterpreterDiscoveryRequiredError('Interpreter discovery required, but discovery mode is not set', 'python', 'auto')
    arg2 = InterpreterDiscoveryRequiredError('Interpreter discovery required, but discovery mode is not set', 'python', 'auto')
    arg3 = InterpreterDiscoveryRequiredError('Interpreter discovery required, but discovery mode is not set', 'python', 'auto')
    with pytest.raises(ValueError) as __ve: # todo replace ValueError with exception type
        discover_interpreter(arg0, arg1, arg2, arg3)

# Generated at 2022-06-24 18:52:31.896383
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = test_case_0()
    res = [var_0]
    return res


# Generated at 2022-06-24 18:52:34.957838
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    str_1 = '/usr/bin/python'
    assert var_0 == str_1

# Generated at 2022-06-24 18:52:40.665588
# Unit test for function discover_interpreter
def test_discover_interpreter():
    args_0 = {}
    args_0['action'] = None
    args_0['interpreter_name'] = None
    args_0['discovery_mode'] = None
    args_0['task_vars'] = None

    with pytest.raises(InterpreterDiscoveryRequiredError) as excinfo:
        discover_interpreter(**args_0)
    assert excinfo.value.message == 'Either interpreter discovery is required or a specific executable must be provided'



# Generated at 2022-06-24 18:52:43.346948
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test case 0
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == '/usr/bin/python'


# Generated at 2022-06-24 18:54:52.618905
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter('', str_0, '', '')
    assert (var_0 == '/usr/bin/python')
    str_0 = 'python'
    var_0 = discover_interpreter('', str_0, '', '')
    assert (var_0 == '/usr/bin/python')

# Generated at 2022-06-24 18:54:54.577471
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == to_text('/usr/bin/python')



# Generated at 2022-06-24 18:55:01.368820
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Get a JSON or YAML representation of the output
    try:
        txt = json.dumps(test_case_0)
    except AttributeError:
        txt = test_case_0

    # Do the actual test
    assert txt == test_case_0.__doc__

# Generated at 2022-06-24 18:55:06.019208
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO:
    #   - add test for other platforms
    #   - add test for invalid patterns
    #   - add test for pipelining=False
    #   - add test for no python found in stdout
    test_case_0()

# Generated at 2022-06-24 18:55:10.110793
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = 'python'
    var_1 = 'python'
    var_2 = 'python'
    var_3 = 'python'

    actual_0 = discover_interpreter(var_0, var_1, var_2, var_3)

# Generated at 2022-06-24 18:55:12.910347
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test 1: we expect an error because kwargs are not valid
    with pytest.raises(ValueError) as e_info:
        test_case_0()



# Generated at 2022-06-24 18:55:17.270887
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FIXME: this whole thing needs to be rewritten, it's just too slow to do real unit tests
    # with it
    # expect = 'expect_val'
    # actual = discover_interpreter('param_0', 'param_1', 'param_2', 'param_3')
    test_case_0()



# Generated at 2022-06-24 18:55:20.253280
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("\n")
    print("test_discover_interpreter start")
    print("\n")
    test_case_0()
    print("\n")
    print("test_discover_interpreter end")
    print("\n")



# Generated at 2022-06-24 18:55:23.907457
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_cases = [
        # These test cases have not been implemented
    ]
    for test_case in test_cases:
        try:
            test_case()
        except NotImplementedError:
            pass

# Generated at 2022-06-24 18:55:28.865452
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)