

# Generated at 2022-06-24 18:46:46.787273
# Unit test for function discover_interpreter
def test_discover_interpreter():
    for pyver in ('python', 'python3'):
        for mode in ('auto', 'auto_legacy', 'auto_silent', 'auto_legacy_silent'):
            print("Testing mode: {0}".format(mode))
            ret = discover_interpreter(action=None,
                                       interpreter_name=pyver,
                                       discovery_mode=mode,
                                       task_vars=C.config.get_config_value('DEFAULT_TASK_VARS', variables=dict()))
            print("Got: {0}".format(ret))



# Generated at 2022-06-24 18:46:54.838103
# Unit test for function discover_interpreter
def test_discover_interpreter():
    bytes_0 = b'\xe06\xa2o\x1d]\x01\x93'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(bytes_0, bytes_0, dict_0)
    assert discover_interpreter(interpreter_discovery_required_error_0, bytes_0, dict_0, interpreter_discovery_required_error_0) == b'/usr/bin/python'

# Generated at 2022-06-24 18:47:03.254090
# Unit test for function discover_interpreter
def test_discover_interpreter():
    osrelease_content = b''
    platform_info = {'osrelease_content': osrelease_content}

# Generated at 2022-06-24 18:47:10.797524
# Unit test for function discover_interpreter
def test_discover_interpreter():
    bytes_0 = b'\xe06\xa2o\x1d]\x01\x93'

    # initial args
    list_0 = ['cat', 'python', 'python', 'python', 'python', 'python']
    str_0 = 'python'
    tuple_0 = ([11, 'n', 'False', ''], {'python': 'python', 'python': 'python', 'python': 'python', 'python': 'python', 'python': 'python'})
    # end initial args

    # call function using initial args
    discover_interpreter(list_0, str_0, tuple_0)


if __name__ == '__main__':
    test_case_0()
    test_discover_interpreter()

# Generated at 2022-06-24 18:47:16.753979
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_interpreter_name = "python"
    test_discovery_mode = "auto_silent"
    task_vars = {}

    try:
        # No value for task_vars['inventory_hostname']
        result = discover_interpreter(action, test_interpreter_name, test_discovery_mode, task_vars)
        assert False, "expected ValueError to be thrown"
    except ValueError as e:
        pass

    task_vars['inventory_hostname'] = "ubuntu-528"


# Generated at 2022-06-24 18:47:20.727138
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict(inventory_hostname=None)
    action = None
    interpreter_name = None
    discovery_mode = None
    try:
        ansible_module_result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except Exception as e:
        ansible_module_result = str(e)

    print(ansible_module_result)

# Generated at 2022-06-24 18:47:28.820790
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: add unit test(s) to verify the following:
    #   * output of the function
    #   * output of calling discover_interpreter against mocked input(s)
    #   * output of calling discover_interpreter against the live remote host (assuming it's been configured to allow it)
    #   * ensure discover_interpreter raises appropriate exceptions for invalid input
    #   * call discover_interpreter multiple times with the same input and ensure it behaves as expected
    #   * ensure discover_interpreter does NOT modify the input (i.e. ensure it's a pure function)
    pass

# Generated at 2022-06-24 18:47:37.989211
# Unit test for function discover_interpreter
def test_discover_interpreter():
    platform_python_map_0 = {u'fedora': {u'27': u'/usr/bin/python3', u'25': u'/usr/bin/python2.7'},
                             u'ubuntu': {u'17.10': u'/usr/bin/python3', u'16.04': u'/usr/bin/python2.7'}}
    bootstrap_python_list_0 = [u'/usr/sbin/python3', u'/usr/sbin/python2.7']
    action_0 = u'discovery'
    interpreter_name_0 = u'python'
    discovery_mode_0 = u'auto'

# Generated at 2022-06-24 18:47:40.433396
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {"inventory_hostname": "unknown"}

    # After executing the code,
    # discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert True == True



# Generated at 2022-06-24 18:47:53.940387
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Arguments for function 'discover_interpreter'
    action = object()
    interpreter_name = str()
    discovery_mode = str()
    task_vars = dict()

    # Call function 'discover_interpreter'
    try:
        result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except Exception as e:
        # Catch exception here, so it doesn't escape the function and cause a backtrace
        result = 'Execution error:', e

    # Check for 'NotImplementedError' or 'UnboundLocalError' in result
    assert(isinstance(result, (str, bytes)) and
           ('NotImplementedError' in result or 'UnboundLocalError' in result))



# Generated at 2022-06-24 18:48:07.545755
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: as more interpreters are added, expand this test to handle them
    for interp in ['python', 'python3']:
        for mode in ['auto', 'auto_legacy', 'auto_silent', 'auto_legacy_silent']:
            d = discover_interpreter(None, interp, mode, {'ansible_python_interpreter': '/usr/bin/python'})
            if not d:
                raise Exception('Discovery mode {0} failed to return an interpreter'.format(mode))



# Generated at 2022-06-24 18:48:12.054905
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(b'', b'', {}, {}) is None
    assert discover_interpreter(b'', b'', {}, {}) is None



# Generated at 2022-06-24 18:48:16.438199
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = test_case_0()
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {'inventory_hostname': 'unknown'}
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

# Generated at 2022-06-24 18:48:20.143727
# Unit test for function discover_interpreter
def test_discover_interpreter():
    res = discover_interpreter()


if __name__ == '__main__':
    import pytest

    # Unit test for function str
    test_case_0()

    # Unit test for function discover_interpreter
    test_discover_interpreter()

# Generated at 2022-06-24 18:48:27.308292
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = {'_discovery_warnings': [], '_low_level_execute_command': lambda command, sudoable, **kwargs: {'stdout': 'PLATFORM\nLinux\nFOUND\n/usr/bin/python\nENDFOUND\n'}}
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {'inventory_hostname': 'localhost'}
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res == '/usr/bin/python'

# Generated at 2022-06-24 18:48:38.240273
# Unit test for function discover_interpreter
def test_discover_interpreter():
    osrelease_content = b'NAME="Fedora"\nVERSION="20 (Heisenbug)"\nID=fedora\nVERSION_ID=20\nPRETTY_NAME="Fedora 20 (Heisenbug)"\nANSI_COLOR="0;34"'
    osrelease_content_eof = b'NAME="Fedora"\nVERSION="20 (Heisenbug)"\nID=fedora\nVERSION_ID=20\nPRETTY_NAME="Fedora 20 (Heisenbug)"\nANSI_COLOR="0;34"'
    platform_dist_result = [b'fedora', b'20', b'Heisenbug']
    platform_info = {b'platform_dist_result': platform_dist_result, b'osrelease_content': osrelease_content}

# Generated at 2022-06-24 18:48:47.319299
# Unit test for function discover_interpreter
def test_discover_interpreter():
    r'''
    This function tests the discover_interpreter function in the module discover_interpreter. The function gets the
    interpreter and the discovery mode. The function returns the interpreter.
    '''
    dict = {}
    action = {}
    interpreter = 'python'
    discovery_mode = 'ansible_default'
    task_vars = {}
    interpreter = discover_interpreter(action, interpreter, discovery_mode, task_vars)
    assert interpreter == u'/usr/bin/python'

    discovery_mode = 'auto'
    interpreter = discover_interpreter(action, interpreter, discovery_mode, task_vars)
    assert interpreter == u'/usr/bin/python'

    discovery_mode = 'auto_legacy'

# Generated at 2022-06-24 18:48:49.078735
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO needs unit test
    pass



# Generated at 2022-06-24 18:48:54.120428
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object()
    interpreter_name = to_text(b'python', errors='surrogate_or_strict')
    discovery_mode = 'silent_fail'
    task_vars = dict()
    test_result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

if __name__ == '__main__':
    test_case_0()

    # Unit test for function discover_interpreter
    test_discover_interpreter()

# Generated at 2022-06-24 18:48:59.339197
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Find a platform that they have in common
    assert discover_interpreter(None, 'python', 'auto_legacy', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'
    assert discover_interpreter(None, 'python', 'auto_legacy_silent', {}) == '/usr/bin/python'

# Generated at 2022-06-24 18:49:14.107148
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Find the first Linux distribution and version from platform_info
    _get_linux_distro_test_0()
    # Find the first Linux distribution and version from platform_info
    _get_linux_distro_test_1()
    # Find the first Linux distribution and version from platform_info
    _get_linux_distro_test_2()
    # Find the first Linux distribution and version from platform_info
    _get_linux_distro_test_3()

# Unit test helper function for _get_linux_distro

# Generated at 2022-06-24 18:49:21.921324
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # mock actions
    class dummy_Action:
        def _low_level_execute_command(self, command, sudoable, in_data=None):
            return {'stdout': b'PLATFORM\r\nLinux\r\nFOUND\r\n/usr/bin/python\r\nENDFOUND'}

    class mock_Action:
        _discovery_warnings = []
        _connection = {'has_pipelining': True}

        def __init__(self, *args, **kwargs):
            pass

    # mock task vars

# Generated at 2022-06-24 18:49:22.666503
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: make a unit test
    pass

# Generated at 2022-06-24 18:49:26.480366
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action_0 = {}
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto'
    task_vars_0 = {}

    # Call function
    result = discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)

    ###########################################################################
    ## Validation with expected result

    # check result
    assert result == '/usr/bin/python'


# Generated at 2022-06-24 18:49:36.427512
# Unit test for function discover_interpreter
def test_discover_interpreter():

    task_vars = {
        'ansible_distribution': 'test_ansible_distribution',
        'ansible_distribution_version': 'test_ansible_distribution_version',
        'ansible_python_interpreter': 'test_ansible_python_interpreter'
    }

    platform = 'linux'

    version_map = {
        'test_ansible_distribution_version': 'test_ansible_python_interpreter'
    }

    interpreter_python_map = {
        'test_ansible_distribution': version_map
    }

    bootstrap_python_list = ['test_bootstrap_python_list']


# Generated at 2022-06-24 18:49:47.004349
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # example source
    task_vars_0 = {"inventory_hostname": "localhost"}
    res = discover_interpreter(None, "python", "auto", task_vars_0)
    assert res is not None
    res = discover_interpreter(None, "python", "auto_legacy", task_vars_0)
    assert res is not None
    res = discover_interpreter(None, "python", "auto_legacy_silent", task_vars_0)
    assert res is not None
    res = discover_interpreter(None, "python", "auto_silent", task_vars_0)
    assert res is not None
    res = discover_interpreter(None, "python", "no", task_vars_0)
    assert res is not None
    res = discover

# Generated at 2022-06-24 18:49:51.098590
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {'inventory_hostname': 'localhost', 'ansible_connection': 'local'}

    try:
        print(discover_interpreter(None, interpreter_name, discovery_mode, task_vars))
    except InterpreterDiscoveryRequiredError as e:
        print(e)


# Generated at 2022-06-24 18:49:52.374984
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass
    # the interpreter discovery code is tested via integration tests and so will not be unit tested here


# Generated at 2022-06-24 18:49:58.459816
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.action_builder import TaskError

    # Unsupported interpreter
    try:
        discover_interpreter(None, 'perl', None, None)
    except ValueError as ex:
        assert to_text(ex) == 'Interpreter discovery not supported for perl'

    # Auto discovery with all good data
    class FakeAction(object):
        def __init__(self):
            self._low_level_execute_command = None
            self._connection = FakeConnection()
            self._discovery_warnings = []


# Generated at 2022-06-24 18:50:05.161789
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # set up mock 'module_utils.compat.version.LooseVersion' class
    class LooseVersion(object):
        def __init__(self, vstring):
            self.vstring = vstring
        def __lt__(self, other):
            return self.vstring < other.vstring
        def __gt__(self, other):
            return self.vstring > other.vstring
        def __eq__(self, other):
            return self.vstring == other.vstring
        def __le__(self, other):
            return self.vstring <= other.vstring
        def __ge__(self, other):
            return self.vstring >= other.vstring

    vstring = '1.7.0'

    # set up mock 'ansible.module_utils.compat.version.LooseVersion

# Generated at 2022-06-24 18:50:17.191438
# Unit test for function discover_interpreter
def test_discover_interpreter():
    #TODO: Fix this test

    # action, interpreter_name, discovery_mode, task_vars = None

    # AssertionError: unexpected output from Python interpreter discovery
    # discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    assert True

# Generated at 2022-06-24 18:50:22.816949
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Arrange
    action = ''
    interpreter_name = ''
    discovery_mode = ''
    task_vars = ''

    # Act
    try:
        discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    except ValueError as err:
        assert err.message == ("Interpreter discovery not supported for python")


# Generated at 2022-06-24 18:50:30.633468
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.discovery import discover_interpreter
    import ansible.module_utils.basic
    discover_interpreter(ansible.module_utils.basic.AnsibleModule('/dev/null', 'python'), 'python', 'auto', '/dev/null')
    discover_interpreter(ansible.module_utils.basic.AnsibleModule('/dev/null', 'python'), 'python', 'auto_legacy', '/dev/null')
    discover_interpreter(ansible.module_utils.basic.AnsibleModule('/dev/null', 'python'), 'python', 'auto_legacy_silent', '/dev/null')

# Generated at 2022-06-24 18:50:35.753600
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Python interpreter discovery not supported for foo
    try:
        discover_interpreter(None, "foo", "discovery_mode", {'inventory_hostname': 'unknown'})
    except ValueError:
        pass

    # Unsupported platform for extended discovery: linux
    try:
        discover_interpreter(None, "python", "auto_legacy_silent", {'inventory_hostname': 'unknown', 'INTERPRETER_PYTHON_DISTRO_MAP': {}, 'INTERPRETER_PYTHON_FALLBACK': ['/usr/bin/python']})
    except NotImplementedError:
        pass

    # Pipelining support required for extended interpreter discovery

# Generated at 2022-06-24 18:50:45.605745
# Unit test for function discover_interpreter
def test_discover_interpreter():
    func_args = []
    func_kwargs = dict()
    func_expected_result = None

    # parse arguments and create an interpreter_discovery_required_error_0
    # FIXME: make test more robust to changes in argument types
    interpreter_discovery_required_error_0 = test_case_0()

    # re-create function call and set testable function call arguments
    # FIXME: consider more complex cases
    func_args.insert(0, interpreter_discovery_required_error_0)

    # call the function with the defined arguments
    # and save it's result for later comparison
    func_result = discover_interpreter(*func_args, **func_kwargs)

    # compare the result against the expected result
    assert func_result == func_expected_result


# Generated at 2022-06-24 18:50:46.526072
# Unit test for function discover_interpreter
def test_discover_interpreter():
    if test_case_0():
        pass

# Generated at 2022-06-24 18:50:48.285161
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# Generated at 2022-06-24 18:50:57.372789
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import ansible.module_utils.basic
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.executor.task_result
    import ansible.executor.task_executor

    def _ansible_module_get_interpreter(self):
        return None
    def _ansible_module_run(self, *args, **kwargs):
        return dict()
    def _ansible_module_init(self, *args, **kwargs):
        self.params = dict()
    def _ansible_module_load_params(self):
        return dict()
    def _ansible_module_set_parsed(self):
        self.parsed = True
    def _ansible_module_set_instantiated(self):
        self.instantiated

# Generated at 2022-06-24 18:50:58.933407
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()
    test_discover_interpreter()

# Generated at 2022-06-24 18:50:59.597951
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-24 18:51:22.336847
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# Generated at 2022-06-24 18:51:31.886294
# Unit test for function discover_interpreter
def test_discover_interpreter():
    from ansible.executor.task_result import TaskResult

    class MockTaskResult(TaskResult):
        def __init__(self, host, cmd, return_code, stdout, stderr):
            super(MockTaskResult, self).__init__(host, cmd, return_code, stdout, stderr)

        @property
        def _result(self):
            return {'stdout': self._stdout, 'stderr': self._stderr}


    class MockAction(object):
        def __init__(self, host, connection, interpreter_name, discovery_mode, task_vars):
            self._connection = connection
            self._discovery_warnings = []


# Generated at 2022-06-24 18:51:33.858269
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO:
    assert False


# Generated at 2022-06-24 18:51:44.166906
# Unit test for function discover_interpreter
def test_discover_interpreter():
    par_0 = ''
    par_1 = ''
    par_2 = ''
    par_3 = ''

    #Parameters
    dict_0 = str
    dict_1 = str
    dict_2 = str
    dict_3 = str
    dict_4 = str
    dict_5 = str
    dict_6 = str
    dict_7 = str
    dict_8 = str
    dict_9 = str
    dict_10 = str
    dict_11 = str
    dict_12 = str
    dict_13 = str



# Generated at 2022-06-24 18:51:56.214997
# Unit test for function discover_interpreter
def test_discover_interpreter():
    json_0 = b'\xc9\x8f\x17\xb4\xc6\x15\x8c\xd3\xcb\xe7\x9e\xab\x80\x97\xb0\x81\xa8\x94\x81O\x03\x82\x8c\x12\xde\x18\xd5\x84\x18\xfe\x11\x8c\xd9\xdf\xc7\xa0\x8f\xe2\x08\x03'

# Generated at 2022-06-24 18:52:04.208745
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {'inventory_hostname': 'demo_host'}

    try:
        display.debug(msg='Unable to load platform_type', host='demo_host')
    except NotImplementedError as ex:
        display.debug(msg='Python interpreter discovery fallback', host='demo_host')

    # TODO: patch with mocks to get better testing coverage?
    discovery_mode = discovery_mode.strip('_silent').strip('_legacy')


# Generated at 2022-06-24 18:52:12.759327
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Case-0: NotImplementedError(used wrapper)
    # covered
    #   ansible.module_utils.interpreter_discovery.discover_interpreter
    #   ansible.module_utils.interpreter_discovery.InterpreterDiscoveryRequiredError
    #   ansible.module_utils.interpreter_discovery._get_linux_distro
    # not covered
    #   ansible.module_utils.interpreter_discovery._version_fuzzy_match

    class ActionModule:
        def __init__(self, action_name):
            self.action_name = action_name


# Generated at 2022-06-24 18:52:13.558959
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True

test_case_0()
test_discover_interpreter()

# Generated at 2022-06-24 18:52:20.437745
# Unit test for function discover_interpreter
def test_discover_interpreter():
    C.config.set_config_value('INTERPRETER_PYTHON_DISTRO_MAP', {'linux': {'3.9.9': '/usr/bin/python3'}})
    C.config.set_config_value('INTERPRETER_PYTHON_FALLBACK', ['/usr/bin/python'])


# Generated at 2022-06-24 18:52:30.267190
# Unit test for function discover_interpreter
def test_discover_interpreter():
    bytes_0 = b"\x1c\x9d\x11\x8c\xd0\x15\xda\x95L\x1c\xd7\x1e\x0e\xf8=\x00\x91\x00\x1e\x8f\x81\xc6<"
    bytes_1 = b'`\x06\x1f\x92\x8d\xf6\xc9\x17\xe7\xbd\xb0\x04\xbc\x81\xbc\x8d\x17\x01\xc7\x86\x14\x1e\xb2"\xce\x8d\x87\x10\x9e'

# Generated at 2022-06-24 18:53:30.852012
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # source: ansible/lib/ansible/module_utils/compat/version.py
    def loose_version(vstring):
        parts = []
        for part in vstring.split('.'):
            if re.match(r'^\d+$', part):
                part = int(part)
            elif not re.match(r'^\d+[A-Za-z]$', part):
                part = part.lower()
            parts.append(part)
        parts = tuple(parts)

        class LooseVersion(parts.__class__):
            def __init__(self, vstring):
                self.vstring = vstring
                parts.__class__.__init__(self, parts)


# Generated at 2022-06-24 18:53:39.406557
# Unit test for function discover_interpreter
def test_discover_interpreter():
    for depth_1 in range(5):
        if depth_1 == 0:
            command_0 = '\x18'
            list_0 = ['\x18', '\x18', '\x18']
            str_0 = '\x18'
            str_1 = '\x18'
        elif depth_1 == 1:
            command_0 = '\x18'
            list_0 = ['\x18', '\x18', '\x18']
            str_0 = '\x18'
            str_1 = '\x18'
        elif depth_1 == 2:
            command_0 = '\x18'
            list_0 = ['\x18', '\x18', '\x18']
            str_0 = '\x18'

# Generated at 2022-06-24 18:53:47.931833
# Unit test for function discover_interpreter
def test_discover_interpreter():
    data = {}
    assert discover_interpreter(data, 'python', 'auto_legacy', data) is not None

    data = {}
    assert discover_interpreter(data, 'python', 'auto_legacy_silent', data) is not None

    data = {}
    assert discover_interpreter(data, 'python', 'auto_silent', data) is not None

    data = {}
    assert discover_interpreter(data, 'python', 'auto', data) is not None

    data = {}
    try:
        discover_interpreter(data, 'python', 'force_auto_silent', data)
    except InterpreterDiscoveryRequiredError as got:
        assert got.message is not None
        assert got.interpreter_name is not None
        assert got.discovery_mode is not None



# Generated at 2022-06-24 18:53:57.099903
# Unit test for function discover_interpreter
def test_discover_interpreter():

    task_vars = dict()
    task_vars['ansible_connection'] = dict()
    task_vars['ansible_connection']['network_os'] = 'Network OS'
    task_vars['ansible_python_interpreter'] = 'Python Interpreter'

    action = dict(INTERPRETER_PYTHON_DISTRO_MAP=dict(),
                  INTERPRETER_PYTHON_FALLBACK=dict())

    interpreter_name = 'Python Interpreter'
    discovery_mode = 'auto'

    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert result == '/usr/bin/python'

# Generated at 2022-06-24 18:53:59.592015
# Unit test for function discover_interpreter
def test_discover_interpreter():
    discover_interpreter(None, 'python', 'auto', None)



# Generated at 2022-06-24 18:54:06.570178
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class DummyAction(object):
        def __init__(self):
            self._low_level_execute_command = lambda x, y, z: {}
            self._connection = {}
            self._discovery_warnings = []

    bytes_0 = b'\xe06\xa2o\x1d]\x01\x93'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(bytes_0, bytes_0, dict_0)

    try:
        discover_interpreter(DummyAction(), bytes_0, dict_0, dict_0)
    except InterpreterDiscoveryRequiredError as ex:
        assert type

# Generated at 2022-06-24 18:54:16.991665
# Unit test for function discover_interpreter
def test_discover_interpreter():
    list_0 = [u'\u4f60\u597d\u4f60\u597d', u"FOUND\r\n/usr/bin/python\n/bin/python\nENDFOUND"]
    Test_Host = {u'inventory_hostname': u'localhost'}
    Test_Action = {u'_connection': {u'has_pipelining': False}, u'_discovery_warnings': [u'No python interpreters found for host localhost (tried /usr/bin/python, /usr/bin/python3, /usr/local/bin/python, /usr/local/bin/python3)']}

# Generated at 2022-06-24 18:54:20.674883
# Unit test for function discover_interpreter
def test_discover_interpreter():
    discover_interpreter(action=bytes_0, interpreter_name=dict_0, discovery_mode=dict_0, task_vars=dict_0)


# Generated at 2022-06-24 18:54:27.507174
# Unit test for function discover_interpreter
def test_discover_interpreter():
    result = discover_interpreter(bytes_0, bytes_0, dict_0, interpreter_discovery_required_error_0)
    assert result == bytes_0


# Generated at 2022-06-24 18:54:30.063844
# Unit test for function discover_interpreter
def test_discover_interpreter():
    discover_interpreter(action=None, interpreter_name=None, discovery_mode=None, task_vars=None)


# Generated at 2022-06-24 18:56:23.677806
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # fail for invalid interpreter name
    try:
        discover_interpreter(None, None, None, None)
        assert(False)
    except ValueError as e:
        assert(e.args[0] == 'Interpreter discovery not supported for None')

    # fail for unknown platform
    try:
        discover_interpreter(None, 'python', 'auto', {'inventory_hostname': 'test', 'platform': 'test'})
        assert(False)
    except NotImplementedError as e:
        assert(e.args[0] == 'unsupported platform for extended discovery: test')

    # warning for missing platform non-linux case
    discover_interpreter(None, 'python', 'auto_silent', {'inventory_hostname': 'test', 'platform': 'test'})

    # warning for missing platform python