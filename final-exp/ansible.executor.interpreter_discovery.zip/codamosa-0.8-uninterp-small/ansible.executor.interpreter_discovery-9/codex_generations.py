

# Generated at 2022-06-24 18:46:44.461779
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test case 0
    int_0 = 952
    float_0 = 960.0
    dict_0 = None
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(int_0, float_0, dict_0)

    str_0 = '13+00'
    str_1 = 'l'
    str_2 = '+'
    str_3 = 'Ym9keQ=='
    tuple_0 = ()
    # tuple_1 = (str_3,)
    str_4 = '13+0'
    # tuple_2 = (str_0, str_1)
    str_5 = '13+0'
    str_6 = 'z'
    str_7 = '\x08'
    str_8 = '6'

# Generated at 2022-06-24 18:46:55.173914
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # check that the function throws an exception when given bad args
    try:
        discover_interpreter(None, 1, 2, 3)
    except Exception:
        pass
    else:
        raise AssertionError('Expected exception')
    # check that the function throws an exception when given bad args
    try:
        discover_interpreter(None, 1, None, None)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected exception')
    # check that the function throws an exception when given bad args
    try:
        discover_interpreter(None, None, None, None)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected exception')
    # check that the function throws an exception when given bad args

# Generated at 2022-06-24 18:46:58.953964
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = object()
    interpreter_name = u'python'
    discovery_mode = u'auto_legacy_silent'
    task_vars = dict()
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

test_case_0()
test_discover_interpreter()

# Generated at 2022-06-24 18:47:06.588128
# Unit test for function discover_interpreter
def test_discover_interpreter():
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {'inventory_hostname': 'localhost'}
    # Test with default argument values
    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) is None
    # Test with default argument values
    # TODO: uncomment the next line once the first test passes
    # assert find_python_interpreter(action, interpreter_name, discovery_mode, task_vars)i == '()'
    # Test with default argument values
    # TODO: uncomment the next line once the first test passes
    # assert find_python_interpreter(action, interpreter_name, discovery_mode, task_vars) == ''
    # Test with default argument values
    # TODO: uncomment

# Generated at 2022-06-24 18:47:15.236925
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # See test_cases/modules/remote_management/script/test_script.py for additional test cases
    # Bootstrap python discovery
    regex_0 = 'PLATFORM[\r\\n]+(.*)FOUND(.*)ENDFOUND'
    regex_1 = 'PLATFORM[\r\\n]+(.*)FOUND(.*)ENDFOUND'
    regex_2 = 'PLATFORM[\r\\n]+(.*)FOUND(.*)ENDFOUND'
    regex_3 = 'PLATFORM[\r\\n]+(.*)FOUND(.*)ENDFOUND'
    regex_4 = 'PLATFORM[\r\\n]+(.*)FOUND(.*)ENDFOUND'
    regex_5 = 'PLATFORM[\r\\n]+(.*)FOUND(.*)ENDFOUND'

# Generated at 2022-06-24 18:47:27.352834
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test for action of class ActionBase

    # Test if it returns the correct value
    from ansible.plugins.action.normal import ActionModule as action_module_class

    connection_0 = Connection('ssh')
    temporary_path_0 = None
    shell_0 = None
    become_method_0 = None
    become_user_0 = None
    check_mode_0 = None
    diff_mode_0 = None
    task_uuid_0 = None
    action_0 = action_module_class(connection_0, temporary_path_0, shell_0, become_method_0, become_user_0, check_mode_0,
                                   diff_mode_0, task_uuid_0)
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto_silent'
    task

# Generated at 2022-06-24 18:47:30.832974
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Example of usage
    print(discover_interpreter(1, 1, 1, 1))


if __name__ == '__main__':
    # test_discover_interpreter()
    test_case_0()

# Generated at 2022-06-24 18:47:38.942326
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: testcase for a platform type we don't (yet) support, NotImplementedError should be raised
    # TODO: testcase for unexpected output from discovery function, ValueError should be raised
    # TODO: testcase for a known distribution that has no python version map for it, NotImplementedError should be raised
    # TODO: testcase for a host that returns /etc/os-release but no platform/dist, NotImplementedError should be raised
    # TODO: testcase for a host that has a known distro/version but no interpreter on it, the fallback should be used
    # TODO: testcase for a host that has a known distro/version with multiple interpreters, the right one should be used
    pass



# Generated at 2022-06-24 18:47:47.511253
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:47:51.734934
# Unit test for function discover_interpreter
def test_discover_interpreter():
    unittest.TestCase.assertRaises(self=None, exc=InterpreterDiscoveryRequiredError, fun=discover_interpreter, action=None, interpreter_name=None, discovery_mode=None, task_vars=None)


# Generated at 2022-06-24 18:48:01.759454
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()



# Generated at 2022-06-24 18:48:02.378313
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert callable(discover_interpreter)

# Generated at 2022-06-24 18:48:04.552686
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {}

    # test_case_0()
    test_case_0()



# Generated at 2022-06-24 18:48:13.269929
# Unit test for function discover_interpreter
def test_discover_interpreter():
    bootstrap_python_list = C.config.get_config_value('INTERPRETER_PYTHON_FALLBACK')

    assert find_executable(bootstrap_python_list, '/usr/bin/python') is not None
    # assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == expected

# Generated at 2022-06-24 18:48:16.530992
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'tho'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)



# Generated at 2022-06-24 18:48:17.519857
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True  # No tests



# Generated at 2022-06-24 18:48:27.159835
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'foo,bar,baz'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    var_1 = discover_interpreter(str_0, str_0, str_0, str_0)
    var_2 = discover_interpreter(str_0, str_0, str_0, str_0)
    var_3 = discover_interpreter(str_0, str_0, str_0, str_0)
    try:
        str_1 = 'tho'
        var_4 = discover_interpreter(str_1, str_1, str_1, str_1)
    except RuntimeError:
        pass
    else:
        raise AssertionError("RuntimeError not raised")


# Generated at 2022-06-24 18:48:33.633385
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'tho'
    str_1 = 'tho'
    str_2 = 'tho'
    str_3 = 'tho'
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)

# Generated at 2022-06-24 18:48:35.561327
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert 'function' == type(discover_interpreter).__name__
# High-level test with pytest



# Generated at 2022-06-24 18:48:39.081762
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'tho'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)


# Generated at 2022-06-24 18:49:06.572507
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('tho', 'tho', 'tho', 'tho') is None

# Generated at 2022-06-24 18:49:10.604597
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'tho'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)

    assert var_0 == "tho", "Return value of function 'discover_interpreter' is incorrect."


# Generated at 2022-06-24 18:49:15.279222
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_1 = 'tho'
    var_2 = 'tho'
    var_3 = 'tho'
    var_4 = 'tho'
    result = discover_interpreter(var_1, var_2, var_3, var_4)
    assert type(result) == unicode

# Cut and paste this into a Python interpreter to test manually.
# test_case_0()

# Generated at 2022-06-24 18:49:16.593742
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert test_case_0() == None, "Test case 0"


# Generated at 2022-06-24 18:49:20.530778
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        from mock import patch
    except ImportError:
        from unittest.mock import patch

    with patch('ansible.module_utils.interpreter_discovery.InterpreterDiscoveryRequiredError', new=Exception):
        with patch('ansible.module_utils.interpreter_discovery.NotImplementedError', new=Exception):
            # call function with arguments
            test_case_0()

# Generated at 2022-06-24 18:49:26.966028
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Initialize test environment
    str_0 = 'tho'
    str_1 = 'tho'
    str_2 = 'tho'
    str_3 = 'tho'
    version_0 = 'tho'
    version_1 = 'tho'
    version_2 = 'tho'
    version_3 = 'tho'
    version_4 = 'tho'
    version_5 = 'tho'
    version_6 = 'tho'
    version_7 = 'tho'

    # Call the function
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)

    # Verify the results
    assert var_0 == str_0

    # Initialize test environment
    str_0 = 'tho'

# Generated at 2022-06-24 18:49:30.599781
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = 'tho'
    var_1 = 'tho'
    var_2 = 'tho'
    var_3 = 'tho'
    var_4 = discover_interpreter(var_0, var_1, var_2, var_3)
    assert isinstance(var_4, str)



# Generated at 2022-06-24 18:49:42.347898
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Define mock input and output values
    str_0 = 'tho'
    str_1 = 'this'
    str_2 = 'might'
    str_3 = 'work for anyone'
    str_4 = 'world.'
    str_5 = 'hello'
    str_6 = 'world'
    str_7 = 'hello'
    str_8 = 'tho'
    str_9 = 'hello'
    str_10 = 'world.'
    str_11 = 'world'
    str_12 = 'hello'
    str_13 = 'world.'
    str_14 = 'hello'
    str_15 = 'tho'
    str_16 = 'hello'
    str_17 = 'world.'
    str_18 = 'world'
    str_19 = 'hello'
    str_20

# Generated at 2022-06-24 18:49:42.945083
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True

# Generated at 2022-06-24 18:49:45.678835
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:50:46.091276
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        assert discover_interpreter('test', 'python', 'test', 'test')
    except:
        print("Can't run unit test for this module")
    else:
        print("Unit test passed")

if __name__ == '__main__':
    test_case_0()
    test_discover_interpreter()

# Generated at 2022-06-24 18:50:51.255046
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'tho'
    str_1 = 'tho'
    str_2 = 'tho'
    str_3 = 'tho'
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    assert 'tho' == var_0


# Generated at 2022-06-24 18:50:55.225563
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str0 = 'tho'
    str1 = 'use'
    str2 = 'tho'
    str3 = 'use'
    str4 = 'tho'
    var0 = discover_interpreter(str0, str1, str2, str3)
    assert var0 == 'tho'
    pass



# Generated at 2022-06-24 18:51:00.257331
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        str_0 = 'tho'
        var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
        # AssertionError - # TODO: right exception type?
        raise AssertionError
    except Exception:
        pass
    var_1 = discover_interpreter(str_0, str_0, var_0, str_0)
    # AssertionError - # TODO: right exception type?
    raise AssertionError



# Generated at 2022-06-24 18:51:02.013890
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'tho'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == None

# Generated at 2022-06-24 18:51:06.931024
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: replace these with actual test cases
    # print test_case_0()
    pass

# Generated at 2022-06-24 18:51:13.311810
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host = "test_host"

    # Test 1: match exact version
    # mock output of bootstrap
    platform_type = u'linux'
    found_interpreters = ['python', 'python2.6']
    module_name = u'python'
    res = {'stdout': u'PLATFORM\nlinux\nFOUND\npython\npython2.6\nENDFOUND'}

# Generated at 2022-06-24 18:51:18.892713
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print('Test #0')
    print('Expected Results:\n\tReturn Value: None\n\tType: <class \'NoneType\'>')
    print('Actual Results:')
    var_0 = discover_interpreter('tho', 'tho', 'tho', 'tho')
    print('\tReturn Value: ', var_0)
    print('\tType: ', type(var_0))
    if var_0 == None:
        print('Passed')
    else:
        print('Failed')

# Generated at 2022-06-24 18:51:20.876673
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True == True



# Generated at 2022-06-24 18:51:28.204775
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = 'tho'
    var_1 = 'tho'
    var_2 = 'tho'
    var_3 = 'tho'
    try:
        var_0 = discover_interpreter(var_0, var_1, var_2, var_3)
    finally:
        if 'var_0' in locals():
            var_0 = None
        assert (var_0 is None), "test_discover_interpreter: discovery failed"


# Generated at 2022-06-24 18:53:10.071890
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'tho'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == '/usr/bin/python'


# Generated at 2022-06-24 18:53:10.998807
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # This test case is not implemented
    pass


# Generated at 2022-06-24 18:53:16.101584
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = u'linux'
    var_1 = u'python'
    var_2 = 'auto'
    var_3 = {'inventory_hostname': 'localhost', 'net_hostname': 'localhost'}
    var_4 = discover_interpreter(var_0, var_1, var_2, var_3)
    assert var_4 == '/usr/bin/python'


# Generated at 2022-06-24 18:53:18.900988
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

# Generated at 2022-06-24 18:53:22.217497
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_1 = 'tho'
    var_1 = discover_interpreter(str_1, str_1, str_1, str_1)
    assert var_1 == '/usr/bin/python'


# Generated at 2022-06-24 18:53:31.708486
# Unit test for function discover_interpreter
def test_discover_interpreter():
    module = 'interpreters'
    filename = u'interpreters.py'
    line = 59
    function = u'discover_interpreter'

    str_arg = u'test string'

    # Call function
    result = discover_interpreter(str_arg, str_arg, str_arg, str_arg)

    # Basic tests
    assert isinstance(result, basestring)

    # Blank test-case for function discover_interpreter

    # Check function and module names
    assert inspect.currentframe().f_code.co_name == function
    assert os.path.split(inspect.getfile(inspect.currentframe()))[1] == filename
    assert inspect.getmodule(discover_interpreter).__name__ == module

    # Check for line number
    assert inspect.currentframe().f_

# Generated at 2022-06-24 18:53:39.892861
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = 'FOUND'
    var_1 = 'Linux'
    var_2 = 'FOUND'
    var_3 = '/usr/bin/python'
    var_4 = 'ENDFOUND'
    var_5 = 'PLATFORM'
    var_6 = '\n'
    var_7 = var_5 + var_1 + var_6 + var_2 + var_3 + var_4
    #print(var_7)
    try:
        var_8 = discover_interpreter(var_7, var_0, var_0, var_0)
        test_case_0()
    except InterpreterDiscoveryRequiredError as exception:
        var_9 = exception.interpreter_name
        var_10 = exception.discovery_mode
        #print(var_9)


# Generated at 2022-06-24 18:53:41.212280
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(str_0, str_0, str_0, str_0) == var_0

# Generated at 2022-06-24 18:53:43.072970
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        # Testing a case which should match the first element in array version_map
        test_case_0()
    except Exception as exception:
        print(exception)
        raise exception

# Generated at 2022-06-24 18:53:49.478094
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'tho'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == u'/usr/bin/python'
    str_1 = 'clj'
    with pytest.raises(ValueError) as pytest_wrapped_e:
        discover_interpreter(str_0, str_1, str_0, str_0)
    assert 'Interpreter discovery not supported for clj' in to_native(pytest_wrapped_e.value)

