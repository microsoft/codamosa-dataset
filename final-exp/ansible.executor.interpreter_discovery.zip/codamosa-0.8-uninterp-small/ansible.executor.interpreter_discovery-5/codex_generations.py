

# Generated at 2022-06-24 18:46:40.946038
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {'inventory_hostname': 'localhost'}
    res = discover_interpreter('action', 'python', 'auto_silent', task_vars)
    assert res == '/usr/bin/python'

# Generated at 2022-06-24 18:46:47.189962
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test case 1
    tuple_0 = ()
    int_0 = 232
    set_0 = set()
    dict_0 = dict()
    action_0 = dict()
    action_0['action'] = 'setup'
    action_0['args'] = set_0
    action_0['delegate_to'] = 'default'
    action_0['delegate_facts'] = False
    action_0['register'] = dict_0
    action_0['_removed_entry'] = dict_0
    action_0['_ansible_verbosity'] = 0
    action_0['_ansible_version'] = '2.7.8'
    action_0['_ansible_selected_optionals'] = dict_0
    action_0['_ansible_syslog_facility'] = 'LOG_USER'

# Generated at 2022-06-24 18:46:57.197411
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()

    # FUTURE: need to mock the command action
    action = dict()

    action._low_level_execute_command = dict()

    action._low_level_execute_command.__call__ = lambda: dict()

    # No override of provided arguments
    res = discover_interpreter(action,
                               interpreter_name='python',
                               discovery_mode='auto',
                               task_vars=task_vars)
    assert res == u'/usr/bin/python'

    # Override of provided arguments
    res = discover_interpreter(action=action,
                               interpreter_name='python3',
                               discovery_mode='auto',
                               task_vars=task_vars)
    assert res == u'/usr/bin/python3'


# Generated at 2022-06-24 18:47:05.026954
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Setup test variables
    task_vars = dict()
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    display.verbosity = 4

    # Test a case which should raise an error
    try:
        discover_interpreter(None, 12, 'auto_legacy', task_vars)
        assert False, "An exception should have been raised"
    except ValueError as err:
        assert(True)

    # Test a case which should return the default python path
    result = discover_interpreter(None, 'python', 'auto_legacy', task_vars)
    assert(result == '/usr/bin/python')

    # Test a case where the discover process will raise an error

# Generated at 2022-06-24 18:47:12.976212
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # mock task_vars
    task_vars = dict()

    # mock action
    action = dict()
    action['_low_level_execute_command'] = dict()
    action['_low_level_execute_command']['stdout'] = "PLATFORM; Linux; FOUND; /usr/bin/python; ENDFOUND"
    action._discovery_warnings = list()

    # mock display
    display = dict()
    display['vvv'] = dict()
    display['vvv']['msg'] = "Attempting Python interpreter discovery"
    display['debug'] = dict()
    display['debug']['msg'] = "found interpreters: ['/usr/bin/python']"
    display['warning'] = dict()

# Generated at 2022-06-24 18:47:22.257072
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError('abcd', 5, '&h')
    d = {'a': 'b', 'c': 'd'}
    e = {'h': 'i', 'j': 'k'}
    tuple_0 = (d,)
    tuple_1 = (e,)
    tuple_2 = ()
    def test_has_pipelining(self):
        return True
    action_0 = type('ActionModule', (object,), dict(task_vars=d, _low_level_execute_command=None, _discovery_warnings=e, has_pipelining=test_has_pipelining))

# Generated at 2022-06-24 18:47:22.620771
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-24 18:47:27.359156
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'foo'
    discovery_mode = 'bar'
    task_vars = {
        'foo': 'bar'
    }
    expected_result = u'baz'

    fake_action = type('ActionModule', (object,), {
        '_discovery_warnings': [],
        '_low_level_execute_command': lambda self, cmd, **kwargs: {
            'stdout': expected_result
        }
    })()

    result = discover_interpreter(fake_action, interpreter_name, discovery_mode, task_vars)

    assert result == expected_result


# Generated at 2022-06-24 18:47:28.253760
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True


# Generated at 2022-06-24 18:47:29.453961
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert False


# Generated at 2022-06-24 18:47:48.365025
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Return the interpreter path given an action and interpreter name
    action = 'action'
    interpreter_name = 'interpreter_name'
    discovery_mode = 'discovery_mode'
    task_vars = dict()
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert res is not None
    return res



# Generated at 2022-06-24 18:47:56.616824
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: test with 'getpass.getuser()'
    # TODO: test with 'return return'

    try:
        # TODO: test with 'to_text'
        tuple_0 = ()
        str_0 = 'python'
        str_1 = 'some_discovery_mode'
        dict_0 = {}
        discover_interpreter(tuple_0, str_0, str_1, dict_0)

    except NotImplementedError as ex:
        display.vvv(msg=u'Python interpreter discovery fallback ({0})'.format(to_text(ex)))



# Generated at 2022-06-24 18:47:59.192824
# Unit test for function discover_interpreter
def test_discover_interpreter():
    discover_interpreter_function_0 = discover_interpreter(tuple_0, int_0, set_0, dict_0)
    return discover_interpreter_function_0


# Generated at 2022-06-24 18:48:01.918704
# Unit test for function discover_interpreter
def test_discover_interpreter():
    '''
    Test function with defined arguments
    '''
    action = None
    interpreter_name = 'python'
    discovery_mode = 'auto'
    task_vars = {"inventory_hostname": "localhost"}

    ret = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    assert ret == '/usr/bin/python'


# Generated at 2022-06-24 18:48:03.677062
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FIXME: Fix this, maybe add an interpreter_discovery_required_error arg, one of these is failing
    # assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == 'expected result'
    pass

# Generated at 2022-06-24 18:48:09.752892
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host = 'test_host'
    action = 'test_action'
    interpreter_name = 'test_interpreter_name'
    discovery_mode = 'test_discovery_mode'
    task_vars = 'test_task_vars'

    # Mock the AnsibleModule object
    mock_ansible_module = AnsibleModule({})

    # Mock the ansible module
    if sys.version_info[:3] == (2, 6, 9):
        from ansible.modules.packaging.os import yum
        from ansible.modules.packaging.os import yum_repository
        from ansible.modules.cloud.amazon import ec2
    else:
        from ansible.modules.packaging.os.yum import yum
        from ansible.modules.packaging.os.yum import y

# Generated at 2022-06-24 18:48:16.661641
# Unit test for function discover_interpreter
def test_discover_interpreter():
    list_0 = ['1.0.0', '5.5.5', '', '4.4.4']
    class_0 = type('', (), {})()
    class_0._discovery_warnings = list_0
    class_0._connection = class_0_0 = type('', (), {})()
    class_0_0.has_pipelining = tuple_0 = ()
    class_0_0.has_pipelining = dict_0 = {}
    class_0_0.has_pipelining = str_0 = ''

    discover_interpreter(class_0, str_0, dict_0, tuple_0)


if __name__ == "__main__":
    if test_case_0():
        print('Test Successful')
    else:
        print('Test Failure')


# Generated at 2022-06-24 18:48:20.357072
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = {}
    action = None
    interpreter_name = None
    discovery_mode = None
    rv = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert rv == u'/usr/bin/python'


# Generated at 2022-06-24 18:48:23.178922
# Unit test for function discover_interpreter
def test_discover_interpreter():
    with pytest.raises(Exception):
        assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars)


# Generated at 2022-06-24 18:48:31.214984
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # unit test for
    #     interpreter_discovery_required_error_0
    #     action_0
    #     interpreter_name_0
    #     discovery_mode_0
    #     task_vars_0
    #
    tuple_0 = ()
    int_0 = 232
    set_0 = set()
    interpreter_discovery_required_error_0 = InterpreterDiscoveryRequiredError(tuple_0, int_0, set_0)
    test_case_0()
    action_0 = ()
    interpreter_name_0 = 'python'
    discovery_mode_0 = 'auto'
    task_vars_0 = {}
    result = discover_interpreter(action_0, interpreter_name_0, discovery_mode_0, task_vars_0)

# Generated at 2022-06-24 18:48:45.641122
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('lkjasd', 'python', 'auto_legacy_silent', {'inventory_hostname': 'blah'}) == '/usr/bin/python'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:48:52.803352
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Assert 'platform_type' (0 elements)
    str_0 = 'python3'
    var_0 = dict()
    var_1 = discover_interpreter(str_0, str_0, str_0, var_0)


stuff_0 = None


# Generated at 2022-06-24 18:48:54.086380
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print(test_case_0())

test_discover_interpreter()

# Generated at 2022-06-24 18:48:59.455236
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Unexpected return type for discover_interpreter
    # raise TypeError('Unexpected return type')

    # Unexpected return value for discover_interpreter
    # raise ValueError('Unexpected return value')

    # No exception was raised
    return


# Generated at 2022-06-24 18:49:02.400353
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = dict()
    str_1 = 'ansible'
    str_2 = 'auto'
    var_1 = discover_interpreter(str_1, str_1, str_2, var_0)
    assert var_1 is not None

# Test cases for function discover_interpreter

# Generated at 2022-06-24 18:49:04.730927
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = dict()
    str_0 = 'python3'
    var_1 = discover_interpreter(str_0, str_0, str_0, var_0)
    assert('/usr/bin/python' == var_1)

# Generated at 2022-06-24 18:49:08.174440
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        # Unit test for function discover_interpreter
        # TODO: implement unit tests for discover_interpreter
        assert True
    except AssertionError as ae:
        display.error('Unit test for function discover_interpreter failed: %s' % ae)
        raise


# Generated at 2022-06-24 18:49:16.447337
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test case 0
    # Test case 1
    # Test case 2
    # Test case 3
    # Test case 4
    # Test case 5
    # Test case 6
    # Test case 7
    # Test case 8
    # Test case 9
    # Test case 10
    # Test case 11
    # Test case 12
    # Test case 13
    # Test case 14
    # Test case 15
    # Test case 16
    # Test case 17
    # Test case 18
    # Test case 19
    # Test case 20
    # Test case 21
    pass

# Generated at 2022-06-24 18:49:19.754152
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = dict()
    str_0 = 'python'
    str_1 = 'auto_silent'
    var_1 = discover_interpreter(str_0, str_0, str_1, var_0)
    assert 'py' in var_1

# Generated at 2022-06-24 18:49:26.425465
# Unit test for function discover_interpreter
def test_discover_interpreter():

    class MockAction(object):
        def __init__(self):
            self.connection = MockConnection()
            self._discovery_warnings = []

        def _low_level_execute_command(self, *args, **kwargs):
            if kwargs.get('in_data'):
                return {'stdout': platform.python_target_resp}
            else:
                return {'stdout': platform.python_bootstrap_resp}

    class MockConnection(object):
        def __init__(self):
            self.has_pipelining = True

    action = MockAction()

    # init
    host = 'linux-ubuntu-14.04'
    inventory_hostname = host  # set by the inventory plugin later
    platform_version = '14.04'

# Generated at 2022-06-24 18:49:42.244982
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # TODO: Move this to a proper unit test.
    # This will throw exceptions and exit.
    test_case_0()
    return


if __name__ == '__main__':
    # FIXME: Boilerplate code.  This whole file should be converted to a proper unit test.
    import argparse
    parser = argparse.ArgumentParser(description="Test function with standard args and optional flags")
    parser.add_argument('-v', '--verbosity', type=int, default=1, help='verbosity level')
    args = parser.parse_args()
    for key, value in vars(args).items():
        setattr(C, key.upper(), value)
    test_discover_interpreter()

# Generated at 2022-06-24 18:49:46.101066
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'python'
    str_2 = 'python'
    str_3 = 'python'
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    assert var_0 == u'/usr/bin/python'

# Generated at 2022-06-24 18:49:46.747555
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-24 18:49:48.505660
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter("action", "interpreter_name", "discovery_mode", "task_vars") == "usr/bin/python"

# Generated at 2022-06-24 18:49:58.633473
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var__at_host = 'var__at_host'
    var___exclude_hosts = 'var___exclude_hosts'
    var___play_hosts_all = 'var___play_hosts_all'
    var___play_hosts_countries = 'var___play_hosts_countries'
    var___play_hosts_designed_hosts = 'var___play_hosts_designed_hosts'
    var___play_hosts_groups = 'var___play_hosts_groups'
    var___play_hosts = 'var___play_hosts'
    var___play_hosts_patterns = 'var___play_hosts_patterns'
    var___play_hosts_single = 'var___play_hosts_single'

# Generated at 2022-06-24 18:50:05.287216
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'auto'
    dict_0 = dict()
    var_0 = discover_interpreter('python', 'auto', dict_0)
    assert var_0 == '/usr/bin/python'
    dict_2 = dict()
    dict_2['inventory_hostname'] = 'localhost'
    dict_2['inventory_hostname_short'] = 'localhost'
    dict_2['groups'] = dict()
    dict_2['hostvars'] = dict()
    dict_2['hostvars']['localhost'] = dict()
    dict_2['hostvars']['localhost']['ansible_hostname'] = 'localhost'

# Generated at 2022-06-24 18:50:06.889506
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print('>' * 10, 'test for discover_interpreter')
    test_case_0()

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:50:16.452242
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action', 'python', 'auto_silent', 'task_vars') == '/usr/bin/python'
    assert discover_interpreter('action', 'python', 'auto', 'task_vars') == '/usr/bin/python'
    assert discover_interpreter('action', 'python', 'auto_legacy', 'task_vars') == '/usr/bin/python'
    assert discover_interpreter('action', 'python', 'auto', 'task_vars') == '/usr/bin/python'
    assert discover_interpreter('action', 'python', 'auto', 'task_vars') == '/usr/bin/python'
    assert discover_interpreter('action', 'python', 'auto_legacy', 'task_vars') == '/usr/bin/python'
    assert discover_

# Generated at 2022-06-24 18:50:22.956839
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = '<function _executor.get at 0x7f627991d0e0>'
    str_1 = 'test_interpreter'
    str_2 = 'auto'
    str_3 = {'inventory_hostname': 'localhost'}
    result = discover_interpreter(str_0, str_1, str_2, str_3)
    assert result is None



# Generated at 2022-06-24 18:50:24.534294
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert set('ab') == set('abc')
    assert set('abc') != set('abc')



# Generated at 2022-06-24 18:50:50.957741
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Input args for the function
    str_0 = 'python'
    str_1 = 'python'
    str_2 = 'python'
    str_3 = 'python'

    # Return value from the function
    var_0 = u'/usr/bin/python'

    # Call the function
    var_1 = discover_interpreter(str_0, str_1, str_2, str_3)

    # Get the value from the function
    assert var_0 == var_1


# Generated at 2022-06-24 18:50:54.384223
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert var_0 == 'python'

# Set up to test

# Generated at 2022-06-24 18:51:00.020462
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_1 = 'python'
    var_2 = 'python'
    var_3 = 'python'
    var_4 = 'python'
    var_5 = discover_interpreter(var_1, var_2, var_3, var_4)
    assert var_5 == '/usr/bin/python'


# Generated at 2022-06-24 18:51:01.330147
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception as e:
        raise

# Generated at 2022-06-24 18:51:02.904765
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    return var_0

# Generated at 2022-06-24 18:51:12.610276
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = 'CONFIG_ANSIBLE_INTERPRETER_PYTHON_DISTRO_MAP'
    var_1 = 'CONFIG_ANSIBLE_INTERPRETER_PYTHON_FALLBACK'
    var_2 = 'executor_discovery'
    var_3 = 'python_target.py'
    var_4 = 'ansible.executor.discovery'
    var_5 = 'python'
    var_6 = 'python'
    var_7 = 'python'
    var_8 = 'unknown'
    var_9 = ['usr/bin/python']
    var_10 = 'platform_python_map'
    var_11 = 'bootstrap_python_list'
    var_12 = 'host'
    var_13 = 'command -v '

# Generated at 2022-06-24 18:51:20.342660
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Test with a simple connection
    connection = Connection({})
    connection.has_pipelining = True
    connection._shell.has_unbuffered_output = True
    connection.set_options(direct={'persistent': False})
    connection.connect()
    host = 'test_discover_interpreter'
    task_vars = {'inventory_hostname': host}

    class ActionModule(object):
        def __init__(self):
            self._discovery_warnings = []

        def _low_level_execute_command(self, cmd, sudoable=True, in_data=None):
            if cmd == 'command -v python':
                return dict(stdout='/bin/python')

# Generated at 2022-06-24 18:51:30.018430
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    try:
        var_0 = discover_interpreter(var_0, var_1, var_2, var_3)
    except NotImplementedError:
        print('NotImplementedError')
    except Exception as ex:
        print(ex.__class__.__name__)
        print(ex.message)


if __name__ == '__main__':
    test_case_0()
else:
    print('Tests could not be run')

# Generated at 2022-06-24 18:51:37.189453
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    print(var_0)

    str_0 = 'python2'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    print(var_0)

    str_0 = 'python3'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    print(var_0)



# Generated at 2022-06-24 18:51:43.250346
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Setup test data
    str_0 = 'python'
    str_1 = 'python'
    str_2 = 'python'
    str_3 = 'python'

    # Perform the action
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)

    # Check if the results are as expected
    if var_0 is not None:
        raise Exception("Expected None, got {0} for argument 'var_0'".format(var_0))


test_case_0()

# Generated at 2022-06-24 18:52:26.982445
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)



# Generated at 2022-06-24 18:52:35.186059
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'auto_legacy'
    str_1 = 'python'
    str_2 = 'python'
    str_3 = 'python'
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    assert var_0 == '/usr/bin/python'

    str_1 = 'python'
    str_2 = 'auto_legacy'
    str_3 = 'auto_legacy'
    str_4 = 'auto_legacy'
    var_0 = discover_interpreter(str_1, str_2, str_3, str_4)
    assert var_0 == '/usr/bin/python'

# Test for function discover_interpreter

# Generated at 2022-06-24 18:52:43.701579
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:52:44.173161
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True

# Generated at 2022-06-24 18:52:50.794020
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy'
    task_vars = 'test'

    res = discover_interpreter(interpreter_name, discovery_mode, task_vars)
    assert res == 'python'

# Generated at 2022-06-24 18:52:53.373763
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        assert test_case_0() == None
    except:
        print('Test Failed')


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:52:54.305814
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert callable(discover_interpreter)

# Generated at 2022-06-24 18:52:56.959336
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == '/usr/bin/python'

# Generated at 2022-06-24 18:53:00.375107
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = 'python'
    var_1 = 'python'
    var_2 = 'python'
    var_3 = 'python'
    var_4 = discover_interpreter(var_0, var_1, var_2, var_3)

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:53:06.126905
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert 'InterpreterDiscoveryRequiredError' in repr(InterpreterDiscoveryRequiredError('message',
                                                                                         'interpreter_name',
                                                                                         'discovery_mode'))
    assert 'Exception' in repr(InterpreterDiscoveryRequiredError('message',
                                                                 'interpreter_name',
                                                                 'discovery_mode'))

    try:
        discover_interpreter('action', 'python', 'auto_legacy_silent', 'task_vars')
    except InterpreterDiscoveryRequiredError:
        pass

    try:
        discover_interpreter('action', 'not_python', 'auto_legacy_silent', 'task_vars')
    except ValueError:
        pass
    else:
        assert False, 'Failed to raise exception'



# Generated at 2022-06-24 18:54:42.750018
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == '/usr/bin/python'


# Generated at 2022-06-24 18:54:45.181530
# Unit test for function discover_interpreter
def test_discover_interpreter():
    ret_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == ret_0

# Generated at 2022-06-24 18:54:49.290448
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print(test_case_0())


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:54:56.226389
# Unit test for function discover_interpreter
def test_discover_interpreter():
    text_0 = '6.9'
    text_1 = '7.0'
    text_2 = '7.1'
    text_3 = '7.2'
    text_4 = '7.3'
    text_5 = '7.4'
    text_6 = '7.5'
    text_7 = '7.6'
    text_8 = '7.7'
    text_9 = '7.8'
    text_10 = '7.9'
    text_11 = '8.0'
    text_12 = '8.1'
    text_13 = '8.2'
    text_14 = '8.3'
    text_15 = '8.4'
    text_16 = '8.5'
    text_17 = '8.6'
   

# Generated at 2022-06-24 18:55:00.150121
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print(' ')
    print(discover_interpreter(None, 'python', 'auto', {}))


# Generated at 2022-06-24 18:55:03.097667
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print(test_case_0())

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:55:05.492828
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True
    # assert_equal(str_0, var_0)


# Generated at 2022-06-24 18:55:08.704301
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = "test_string"
    str_1 = "test_string"
    str_2 = "test_string"
    str_3 = "test_string"
    assert discover_interpreter(str_0, str_1, str_2, str_3) == "test_string"

# Generated at 2022-06-24 18:55:09.762411
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert callable(discover_interpreter)

# Generated at 2022-06-24 18:55:11.880431
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()


if __name__ == '__main__':
    test_discover_interpreter()