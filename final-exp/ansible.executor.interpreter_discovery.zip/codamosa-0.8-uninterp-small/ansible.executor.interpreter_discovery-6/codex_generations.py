

# Generated at 2022-06-24 18:46:42.820427
# Unit test for function discover_interpreter
def test_discover_interpreter():
    host = 'localhost'
    task_vars = dict(ansible_connection='local', ansible_local=dict(interpreter_python_version=2), ansible_architecture='x86_64')
    action, interpreter_name, discovery_mode, task_vars = '', 'python', 'auto_legacy_silent', task_vars
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert type(res) is str
    assert res == '/usr/bin/python'


# Generated at 2022-06-24 18:46:46.340902
# Unit test for function discover_interpreter
def test_discover_interpreter():
    with pytest.raises(AttributeError):
        task_vars_0 = dict(
            ansible_distribution=None,
            ansible_distribution_release=None,
            ansible_distribution_version=None,
            ansible_os_family=None,
        )
        discover_interpreter(ansible_module_1, str_0, str_0, task_vars_0)


# Generated at 2022-06-24 18:46:55.921071
# Unit test for function discover_interpreter
def test_discover_interpreter():
    task_vars = dict()
    interpreter_name = 'python'
    discovery_mode = 'auto_silent'

    # Test normal execution
    # Normally it's not possible to mock an object that has already been imported,
    # but this is a special case because we call this function before the class
    # is imported into memory.
    action = object()
    action._low_level_execute_command = lambda x: {'stdout': str(x)}
    action._connection = object()
    action._connection.has_pipelining = True
    action._discovery_warnings = list()
    res = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
    assert isinstance(res, str)

# Generated at 2022-06-24 18:46:58.078230
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # FUTURE: implement unit test for discover_interpreter
    assert discover_interpreter(1,2,3,4) == 5


# Generated at 2022-06-24 18:47:05.613250
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Initialize and set up objects, Mocks and Stubs
    # object - object under test
    # mock_object - object to be mocked
    # stub_object - object to be stubbed

    # Fixtures
    int_0 = 65536
    str_0 = 'TEST CASE'
    str_1 = 'TEST'
    str_2 = 'case'
    str_3 = 'x'
    bool_0 = True
    bool_1 = False
    float_0 = None
    list_0 = [str_1, str_2, str_3]
    list_1 = [bool_0, float_0, float_0]
    dict_0 = {str_0: str_1, str_1: str_1, str_2: str_2}

# Generated at 2022-06-24 18:47:10.272586
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Host variable is a string
    a = "blue"
    # Path variable is a string
    b = "blue"
    # Task variable is a dictionary
    c = {
        "inventory_hostname": "blue",
        "inventory_hostname_short": "blue"
    }
    # Ensure discover_interpreter does not return None
    assert discover_interpreter(a, b, c) is not None

# Generated at 2022-06-24 18:47:14.828050
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        action = mock_action()
        interpreter_name = 'python'
        discovery_mode = 'auto_legacy'
        task_vars = mock_task_vars()
        result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)
        assert result == u'/usr/bin/python'
    except NotImplementedError:
        pass


# Generated at 2022-06-24 18:47:27.353335
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TestAnsibleModule(object):
        def __init__(self, action, connection, sudoable):
            self._ansible_module_created_by = self

    class TestAnsibleConnection(object):
        def __init__(self, has_pipelining):
            self.has_pipelining = has_pipelining

    class TestAnsibleAction(object):
        _ansible_module_created_by = TestAnsibleModule
        def __init__(self, _low_level_execute_command, discovery_warnings):
            self._low_level_execute_command = _low_level_execute_command
            self._discovery_warnings = discovery_warnings


# Generated at 2022-06-24 18:47:30.069734
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action', 'python', 'auto_legacy_silent', 'task_vars') == u'/usr/bin/python'



# Generated at 2022-06-24 18:47:32.876942
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter('action_0', 'interpreter_name_0', 'discovery_mode_0', 'task_vars_0') == 'interpreter_0'


# Generated at 2022-06-24 18:47:55.448920
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'auto_legacy'
    dictionary_0 = {'ansible_connection': 'ssh', 'ansible_user': 'vagrant', 'ansible_python_interpreter': '/usr/bin/python', 'ansible_host': '127.0.0.1', 'ansible_port': '2222', 'ansible_ssh_private_key_file': '~/.vagrant.d/insecure_private_key', 'ansible_ssh_common_args': '-o StrictHostKeyChecking=no', 'ansible_ssh_pass': 'vagrant'}
    str_2 = '/usr/bin/python'
    assert discover_interpreter(str_0, str_1, dictionary_0) == str_2

# Generated at 2022-06-24 18:47:56.025402
# Unit test for function discover_interpreter
def test_discover_interpreter():
    pass

# Generated at 2022-06-24 18:47:57.647452
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:48:00.414455
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'auto_legacy'
    list_0 = []
    assert discover_interpreter(str_0, str_1, list_0) == 'python3'


# Generated at 2022-06-24 18:48:03.411230
# Unit test for function discover_interpreter
def test_discover_interpreter():
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    action = 0
    task_vars = 0
    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == 0
    assert discover_interpreter(action, interpreter_name, discovery_mode, task_vars) == 0


test_case_0()

# Generated at 2022-06-24 18:48:06.137094
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'auto_legacy'
    print('Testing function discover_interpreter')
    assert discover_interpreter(str_0, str_1, 'auto_legacy_silent', str_0) is None


# Generated at 2022-06-24 18:48:08.575234
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert discover_interpreter(test_case_0, True) == 'python'

# Generated at 2022-06-24 18:48:20.935230
# Unit test for function discover_interpreter
def test_discover_interpreter():
    class TaskVars:
        inventory_hostname = 'unknown'
        pass

    class Action:
        def _low_level_execute_command(self, shell_bootstrap, sudoable=False, in_data=None):
            pass

        def _connection_has_pipelining(self):
            return False

        def __init__(self):
            self._discovery_warnings = None
            self._connection = Connection()

        pass

    # TODO: from the code above, it looks like this function is not going to work on windows
    # should not be tested
    class Connection:
        def __init__(self):
            self.has_pipelining = False

        pass

    action = Action()
    task_vars = TaskVars()

# Generated at 2022-06-24 18:48:29.911891
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("Testing discover_interpreter()")
    try:
        assert test_case_0() == None
    except AssertionError as ae:
        print('AssertionError: {0}'.format(ae))
    except TypeError as te:
        print('TypeError: {}'.format(te))
    except AttributeError as ae:
        print('AttributeError: {}'.format(ae))
    except ImportError as ie:
        print('ImportError: {}'.format(ie))
    except SyntaxError as se:
        print('SyntaxError: {}'.format(se))
    except NameError as ne:
        print('NameError: {}'.format(ne))
    except RuntimeError as re:
        print('RuntimeError: {}'.format(re))

# Generated at 2022-06-24 18:48:31.882083
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'auto_legacy'
    test_case_0()

# Generated at 2022-06-24 18:48:43.990143
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == '/usr/bin/python'

# Generated at 2022-06-24 18:48:44.496588
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert True

# Generated at 2022-06-24 18:48:53.518276
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        str_0 = 'python'
        str_1 = 'python'
        str_2 = 'python'
        str_3 = 'python'
        var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
        if (var_0 != 'python'):
            print ("var_0 {}".format(var_0))
            assert False
    except AssertionError as e:
        print (e)
        assert False

if __name__ == '__main__':
    test_case_0()
    test_discover_interpreter()
    print('all test passed')

# Generated at 2022-06-24 18:48:55.013292
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print(test_case_0())

# Generated at 2022-06-24 18:49:01.439690
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        expected_0 = u'/usr/bin/python'
        test_case_0()
        test_value_0 = discover_interpreter(u'abcd', u'python', u'auto_legacy_silent', {u'inventory_hostname': u'abcd'})
        assert test_value_0 == expected_0
    except (AssertionError, ValueError, InterpreterDiscoveryRequiredError, TypeError):
        display.error('Test error in `test_discover_interpreter`\n{err}'.format(err=format_exc()))
        return False
    return True

# Generated at 2022-06-24 18:49:13.205863
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Check all possible function calls
    str_0 = 'python'
    str_1 = 'python'
    str_2 = 'auto'
    str_3 = 'auto'
    str_4 = 'auto_legacy'
    str_5 = 'auto_legacy'
    str_6 = 'auto_legacy_silent'
    str_7 = 'auto_legacy_silent'
    str_8 = 'wrong_string'
    str_9 = 'wrong_string'
    str_10 = 'wrong_string'
    str_11 = 'wrong_string'
    str_12 = 'wrong_string'
    str_13 = 'wrong_string'
    str_14 = 'wrong_string'
    str_15 = 'wrong_string'
    str_16 = 'wrong_string'
    str

# Generated at 2022-06-24 18:49:18.157697
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Set up mock
    action = MagicMock(spec=ActionBase)
    interpreter_name = 'python'
    discovery_mode = 'auto_legacy_silent'
    task_vars = 'task_vars'

    # Invoke method
    result = discover_interpreter(action, interpreter_name, discovery_mode, task_vars)

    # Check for correct result
    assert result is None

# Generated at 2022-06-24 18:49:19.018444
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()


# Generated at 2022-06-24 18:49:21.579506
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert var_0 == u'/usr/bin/python'


# Generated at 2022-06-24 18:49:22.828051
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception as ex:
        raise AssertionError(str(ex))

# Generated at 2022-06-24 18:49:42.619140
# Unit test for function discover_interpreter
def test_discover_interpreter():
    test_case_0()


# Generated at 2022-06-24 18:49:45.377786
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    assert isinstance(var_0, str)



# Generated at 2022-06-24 18:49:52.577971
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # make sure the error handling works
    try:
        discover_interpreter(None, 'not-python', 'auto', {})
        assert False, 'did not raise expected exception'
    except ValueError:
        pass

    try:
        discover_interpreter(None, 'python', 'mode-that-doesnt-exist', {})
        assert False, 'did not raise expected exception'
    except NotImplementedError:
        pass

    try:
        discover_interpreter(None, 'python', 'auto_legacy', {'inventory_hostname': 'no-pipelining',
                                                             'ansible_connection': 'smart'})
        assert False, 'did not raise expected exception'
    except NotImplementedError:
        pass

# Generated at 2022-06-24 18:49:59.972743
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    str_1 = 'python_legacy_silent'
    str_2 = 'python_legacy_warn'
    str_3 = 'python_new_silent'
    str_4 = 'python_new_warn'
    str_5 = 'python_auto_legacy_silent'
    str_6 = 'python_auto_legacy_warn'
    str_7 = 'python_auto_new_silent'
    str_8 = 'python_auto_new_warn'
    str_9 = 'python'
    var_1 = discover_interpreter(str_0, str_9, str_0, str_0)
    var_1 = discover_interpreter(str_0, str_9, str_1, str_0)

# Generated at 2022-06-24 18:50:02.301328
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except:
        import traceback
        print(traceback.format_exc())

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:50:07.950504
# Unit test for function discover_interpreter
def test_discover_interpreter():
    if test_case_0() == u'/usr/bin/python':
        print(u'Unit tests for function discover_interpreter passed.\n')
    else:
        print(u'Unit tests for function discover_interpreter failed.\n')
    pass

# Generated at 2022-06-24 18:50:11.836543
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Dummy test
    assert True

test_case_0()

# Generated at 2022-06-24 18:50:14.355885
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert(to_text(discover_interpreter(test_case_0())) == "python")

# Standalone test

# Generated at 2022-06-24 18:50:20.779284
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = 'python'
    var_1 = 'auto'
    var_2 = 'any'
    var_3 = ''
    var_4 = discover_interpreter(var_0, var_1, var_2, var_3)
    assert var_4 == 'auto'
    # assert type(var_4) == collections.OrderedDict
    # assert var_4[''] == 'auto'



# Generated at 2022-06-24 18:50:25.467934
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print ('Testing function "discover_interpreter"')

    # In case of successful scenario:
    # Variable name = var_0
    var_0= discover_interpreter('str_0', 'str_0', 'str_0', 'str_0')
    print (var_0)

if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:51:06.272177
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # function to test Python Interpreter discovery
    test_case_0()


if __name__ == "__main__":
    # Now we call the test_case_0
    test_discover_interpreter()

# Generated at 2022-06-24 18:51:08.324787
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("test_discover_interpreter")
    test_case_0()

# Call main function
test_discover_interpreter()

# Generated at 2022-06-24 18:51:16.877570
# Unit test for function discover_interpreter
def test_discover_interpreter():
    distro = 'ubuntu'
    version = LooseVersion('18.04')
    version_map = {'16.04': '/usr/bin/python3', '18.04': '/usr/bin/python3'}

    assert _version_fuzzy_match('18.04', version_map) == '/usr/bin/python3'
    assert _version_fuzzy_match('18.03', version_map) == '/usr/bin/python3'
    assert _version_fuzzy_match('19.04', version_map) == '/usr/bin/python3'
    assert _version_fuzzy_match('16.03', version_map) == '/usr/bin/python3'
    assert _version_fuzzy_match('17.03', version_map) == '/usr/bin/python3'



# Generated at 2022-06-24 18:51:26.661823
# Unit test for function discover_interpreter
def test_discover_interpreter():
    var_0 = {'a': 3, 'b': 5 }
    str_0 = 'python'
    str_1 = 'x'
    str_2 = 'y'
    str_3 = 'z'
    str_4 = 'l'
    str_5 = 'm'
    str_6 = 'n'
    str_7 = 'o'
    str_8 = 'p'
    str_9 = 'q'
    str_10 = 'r'
    str_11 = 's'
    str_12 = 't'
    str_13 = 'u'
    str_14 = 'v'
    str_15 = 'w'
    str_16 = 'xx'
    str_17 = 'yy'
    str_18 = 'zz'
    str_19 = '{ '
    str

# Generated at 2022-06-24 18:51:31.128809
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Loop 0 - successful test case
    str_0 = 'python'
    str_1 = 'python'
    str_2 = 'python'
    str_3 = 'python'
    var_0 = discover_interpreter(str_0, str_1, str_2, str_3)
    print(var_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:51:40.531904
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'ubuntu-16.10'
    str_1 = 'ubuntu'
    str_2 = '16.10'
    dict_0 = {str_1: {str_2: str_0}}
    list_0 = [str_0]
    str_3 = 'soft'
    str_4 = 'auto'
    str_5 = 'auto_silent'
    str_6 = 'auto_legacy'
    str_7 = 'auto_legacy_silent'
    dict_1 = {str_3: dict_0, str_4: dict_0, str_5: dict_0, str_6: dict_0, str_7: dict_0}
    str_8 = 'conf.cfg'

# Generated at 2022-06-24 18:51:43.162149
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print("Testing 'discover_interpreter' ...")
    test_case_0()

# Program entry point
if __name__ == '__main__':
    print("Running tests ...")
    test_discover_interpreter()

# Generated at 2022-06-24 18:51:44.603525
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert callable(discover_interpreter)


# Generated at 2022-06-24 18:51:50.028559
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # various test cases
    test_case_0()
    # additional test case(s)
    additional_test_case(str_0, str_0, str_0, str_0)

# unit test for additional test case(s)

# Generated at 2022-06-24 18:51:52.436937
# Unit test for function discover_interpreter

# Generated at 2022-06-24 18:53:36.764213
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert test_case_0() is not None

# Generated at 2022-06-24 18:53:37.355151
# Unit test for function discover_interpreter
def test_discover_interpreter():
    assert False



# Generated at 2022-06-24 18:53:41.375629
# Unit test for function discover_interpreter
def test_discover_interpreter():
    str_0 = 'python'
    var_0 = discover_interpreter(str_0, str_0, str_0, str_0)
    var_1 = discover_interpreter(str_0, str_0, str_0, str_0)
    var_2 = discover_interpreter(str_0, str_0, str_0, str_0)



# Generated at 2022-06-24 18:53:51.214947
# Unit test for function discover_interpreter
def test_discover_interpreter():
    print('In test_discover_interpreter', str())
    str_0 = 'python'
    str_1 = 'python'
    str_2 = 'python'
    str_3 = 'python'
    result = discover_interpreter(str_0, str_1, str_2, str_3)

    assert True
    # assert result == expected_result, str_0
    # assert discover_interpreter(str_1, str_2, str_3) == expected_result, str_1
    # assert discover_interpreter(str_2, str_3) == expected_result, str_2
    # assert discover_interpreter(str_3) == expected_result, str_3


if __name__ == '__main__':
    test_discover_interpreter()

# Generated at 2022-06-24 18:53:59.290887
# Unit test for function discover_interpreter
def test_discover_interpreter():
    import platform

    # we want to test the following scenarios:
    # 1) action.connection has both a command and a remote_addr
    # 2) action.connection has only a command set
    # 3) action.connection has only a remote_addr set
    # 4) action.connection has neither, so we need to use connection plugin
    #    to create a command
    # 5) interpreter not found in the bootstrap list
    # 6) interpreter not in the correct place

    # TODO: this will require us to mock several other things in order to
    # get a proper action mocked up.

    # TODO: test for hostvars['ansible_python_interpreter']
    pass



# Generated at 2022-06-24 18:54:01.036695
# Unit test for function discover_interpreter
def test_discover_interpreter():
    try:
        test_case_0()
    except Exception:
        print("Test case failed")
        raise

# Generated at 2022-06-24 18:54:07.224750
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # run_module(module_args='', module_name='discover_interpreter')
    try:
        var_0 = discover_interpreter(str_0, str_0)
    except NameError as err:
        assert str(err) == "global name 'discover_interpreter' is not defined", "An exception of type {0} occured. Arguments:\n{1!r}".format(type(err).__name__, err.args)
    except TypeError as err:
        assert str(err) == "discover_interpreter() takes at least 2 arguments (1 given)", "An exception of type {0} occured. Arguments:\n{1!r}".format(type(err).__name__, err.args)


test_case_0()
test_discover_interpreter()

# Generated at 2022-06-24 18:54:17.232190
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # Set up test variables
    str_0 = 'python'
    str_1 = 'auto_legacy'
    str_2 = 'auto_silent'
    str_3 = 'auto'
    str_4 = 'mixed'
    str_5 = 'forced'
    str_6 = 'Id'
    str_7 = 'VersionId'
    str_8 = 'Id'
    str_9 = 'VersionId'
    str_10 = 'Id'
    str_11 = 'VersionId'
    map_0 = {str_0: {str_1: str_2}, str_3: {str_4: str_5}, str_6: {str_7: str_8}, str_9: {str_10: str_11}}

    # Call function with args
    res = discover_interpreter

# Generated at 2022-06-24 18:54:26.462440
# Unit test for function discover_interpreter
def test_discover_interpreter():

    # Test with invalid values for the parameters 'action' (obj), 'interpreter_name' (str), 'discovery_mode' (str),
    # 'task-vars' (obj)
    with pytest.raises(ValueError) as excinfo:
        discover_interpreter(obj, str, str, obj)
    assert excinfo.value.args[0] == 'Interpreter discovery not supported for python'

    # Test with invalid values for the parameters 'action' (obj), 'interpreter_name' (str), 'discovery_mode' (str),
    # 'task-vars' (dict)
    with pytest.raises(ValueError) as excinfo:
        discover_interpreter(obj, str, str, dict)

# Generated at 2022-06-24 18:54:30.145678
# Unit test for function discover_interpreter
def test_discover_interpreter():
    # str(str_0, str_0='python', str_1='python', str_2='python') -> str
    pass

# vim: expandtab tabstop=4 shiftwidth=4