

# Generated at 2022-06-17 19:45:18.931709
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-17 19:45:21.701602
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-17 19:45:28.718885
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m', 'baz']) == 9

# Generated at 2022-06-17 19:45:36.769580
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m', 'baz']) == 9

# Generated at 2022-06-17 19:45:47.424361
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', '\x1b[0m', 'bar']) == 6

# Generated at 2022-06-17 19:45:58.279831
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m', 'baz']) == 9

# Generated at 2022-06-17 19:46:08.272352
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m', 'baz']) == 9

# Generated at 2022-06-17 19:46:10.780026
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-17 19:46:14.575059
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-17 19:46:24.517204
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', '\x1b[0m', 'bar']) == 6