

# Generated at 2022-06-17 19:40:39.747140
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-17 19:40:47.938447
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi((text,)) == 6
    assert len_without_ansi(text + '\x1b[38;5;209m') == 6
    assert len_without_ansi(text + '\x1b[38;5;209m' + text) == 12
    assert len_without_ansi(text + '\x1b[38;5;209m' + text + text) == 18
    assert len_without_ansi(text + '\x1b[38;5;209m' + text + text + text) == 24
    assert len_without_ans

# Generated at 2022-06-17 19:40:56.715591
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.split()) == 6
    assert len_without_ansi([text, text]) == 12
    assert len_without_ansi(['foo', text, 'bar']) == 9
    assert len_without_ansi(['foo', text, 'bar', text]) == 15
    assert len_without_ansi(['foo', text, 'bar', text, text]) == 21
    assert len_without_ansi(['foo', text, 'bar', text, text, text]) == 27
    assert len_without_ansi(['foo', text, 'bar', text, text, text, text]) == 33
    assert len_without_

# Generated at 2022-06-17 19:41:07.134819
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'bar']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209mbar\x1b[0m']) == 6

# Generated at 2022-06-17 19:41:09.705268
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-17 19:41:20.097299
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.split()) == 6
    assert len_without_ansi(text.split()[0]) == 6
    assert len_without_ansi(text.split()[0].split('\x1b[38;5;209m')) == 6
    assert len_without_ansi(text.split()[0].split('\x1b[38;5;209m')[0]) == 0
    assert len_without_ansi(text.split()[0].split('\x1b[38;5;209m')[1]) == 6

# Generated at 2022-06-17 19:41:29.484878
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi([text, text]) == 12
    assert len_without_ansi([text, text, text]) == 18
    assert len_without_ansi([text, text, text, text]) == 24
    assert len_without_ansi([text, text, text, text, text]) == 30
    assert len_without_ansi([text, text, text, text, text, text]) == 36
    assert len_without_ansi([text, text, text, text, text, text, text]) == 42

# Generated at 2022-06-17 19:41:38.261575
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209m\x1b[0mbar'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-17 19:41:48.242019
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'bar']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'bar', '\x1b[38;5;209mfoo\x1b[0m']) == 9

# Generated at 2022-06-17 19:41:51.002887
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-17 19:45:56.997241
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.split()) == 6
    assert len_without_ansi(text.split()[0]) == 6
    assert len_without_ansi(text.split()[1]) == 0
    assert len_without_ansi(text.split()[2]) == 0
    assert len_without_ansi(text.split()[3]) == 0
    assert len_without_ansi(text.split()[4]) == 0
    assert len_without_ansi(text.split()[5]) == 0
    assert len_without_ansi(text.split()[6]) == 0

# Generated at 2022-06-17 19:46:07.782819
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m', '\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 12

# Generated at 2022-06-17 19:46:13.717732
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m', 'baz']) == 9

# Generated at 2022-06-17 19:46:23.960467
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-17 19:46:31.229797
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6

# Generated at 2022-06-17 19:46:33.274185
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-17 19:46:36.176618
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-17 19:46:44.809839
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar', '\x1b[0m', 'baz']) == 9
    assert len_without

# Generated at 2022-06-17 19:46:48.660678
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12



# Generated at 2022-06-17 19:46:59.921834
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6