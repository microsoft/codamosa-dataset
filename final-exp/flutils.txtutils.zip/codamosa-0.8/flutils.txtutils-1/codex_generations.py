

# Generated at 2022-06-11 22:47:30.623684
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    # Test text containing ANSI codes
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    # 'foobar' is length six without ANSI codes
    assert len_without_ansi(text) == 6
    # Test a list of strings containing ANSI codes
    text = ['\x1b[38;5;209mfoo', '\x1b[0m', 'bar']
    # 'foobar' is length six without ANSI codes
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:47:33.773244
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:47:42.625680
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = 'a\x1b[38;5;209mfoobar\x1b[0mb'
    assert len_without_ansi(text) == 8
    text = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ['a\x1b[38;5;209mfoobar\x1b[0mb']
    assert len_without_ansi(text) == 8
    text = ['a\x1b[38;5;209mfoo', 'bar\x1b[0mbcd']
    assert len_without_ans

# Generated at 2022-06-11 22:47:53.254213
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test with string
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # Test with list
    text = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(text) == 6
    # Test with tuple
    text = ('\x1b[38;5;209m', 'foobar', '\x1b[0m')
    assert len_without_ansi(text) == 6
    # Test with nested tuple

# Generated at 2022-06-11 22:47:57.952188
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('\x1b[38;5;224mfoobar\x1b[0m') == 6

# Generated at 2022-06-11 22:48:00.575979
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:04.773876
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar\x1b[31m') == 6
    assert len_without_ansi(['foobar', '\x1b[31m']) == 6
# /Unit test for function len_without_ansi



# Generated at 2022-06-11 22:48:12.046985
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from nose.tools import assert_equal
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[1m\x1b[38;5;209mfoobar\x1b[0m',
    ]
    assert_equal(len_without_ansi(text[0]), 6)
    assert_equal(len_without_ansi(text), 6 * 2)



# Generated at 2022-06-11 22:48:19.496695
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .testing import TestCase

    from flutils.txtutils import len_without_ansi


# Generated at 2022-06-11 22:48:24.165569
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Run test for :func:`flutils.txtutils.len_without_ansi`.

    *New in version 0.7.1*
    """
    import doctest
    doctest.testmod(report=True)  # pragma: no cover



# Generated at 2022-06-11 22:48:40.031263
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
#



# Generated at 2022-06-11 22:48:45.160011
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text: str = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    #
    assert len_without_ansi(['f', '\x1b[38;5;209moobar\x1b[0m', 'g']) == 6
#
# end function test_len_without_ansi



# Generated at 2022-06-11 22:48:48.394516
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6
    out = len_without_ansi([text])
    assert out == 6

# Generated at 2022-06-11 22:48:52.759467
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi."""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# ANSI Text Wrapper

# Generated at 2022-06-11 22:48:57.107159
# Unit test for function len_without_ansi
def test_len_without_ansi():
    return len_without_ansi('\x1b[0mfoobar\x1b[31m')
test_len_without_ansi.__test__ = True  # type: ignore[attr-defined, misc] # noqa: F821
test_len_without_ansi.__unit__ = True  # type: ignore[attr-defined, misc] # noqa: F821



# Generated at 2022-06-11 22:49:02.135882
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text2 = ['a', '\x1b[38;5;209mfoo\x1b[0m', 'bar', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text2) == 6
# del test_len_without_ansi



# Generated at 2022-06-11 22:49:12.493086
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['foo', '\x1b[38;5;209m', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(['foo', 'bar', '\x1b[38;5;209m', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(['foobar\x1b[38;5;209m', 'bar', '\x1b[0m']) == 6

# Generated at 2022-06-11 22:49:15.224684
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test ``len_without_ansi``."""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 16
    assert len_without_ansi(text) == 6
# End of function test_len_without_ansi



# Generated at 2022-06-11 22:49:26.117954
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[30mbla\x1b[0m\x1b[34mhbla'
    assert len_without_ansi(text) == 6
    text = 'blah\x1b[30mbla\x1b[0m\x1b[34mhbla'
    assert len_without_ansi(text) == 10
    text = 'blah\x1b[30mbla\x1b[0m\x1b[34mhbla\x1b[0m'
    assert len_without_ansi(text) == 10

# Generated at 2022-06-11 22:49:28.345981
# Unit test for function len_without_ansi
def test_len_without_ansi():
    s = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(s) == 6



# Generated at 2022-06-11 22:49:54.454620
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi
    """
    assert len_without_ansi(1) == 1
    assert len_without_ansi('foo bar') == 7
    assert len_without_ansi(['foo', 'bar']) == 7
    assert len_without_ansi(('foo', 'bar')) == 7
    assert len_without_ansi('foo\x1b[38;5;209mbar\x1b[0m') == 6
    assert len_without_ansi('foo\x1b[38;5;209m bar\x1b[0m') == 7
    assert len_without_ansi(['foo\x1b[38;5;209mbar\x1b[0m']) == 6

# Generated at 2022-06-11 22:49:58.904477
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi((text,)) == 6



# Generated at 2022-06-11 22:50:01.869663
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:05.770157
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:50:15.848551
# Unit test for function len_without_ansi
def test_len_without_ansi():
    r"""Test the len_without_ansi() function."""
    from flutils.txtutils import len_without_ansi as l
    assert l('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert l('\x1b[38;5;209mfoobar') == 6
    assert l('\x1b[38;5;209m') == 0
    assert l('foo\x1b[38;5;209m') == 3
    assert l('\x1b[s\x1b[38;5;209mfoobar\x1b[u') == 6

    assert l(['\x1b[38;5;209mfoo', '\x1b[0mbar']) == 6

# Generated at 2022-06-11 22:50:25.246416
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', '\x1b[0m', 'b', 'ar']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', '\x1b[0m', 'b', 'ar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:50:37.129378
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mfoobar',
        '\x1b[38;5;209mfoobar',
        '\x1b[0mfoobar',
        '\x1b[0mfoobar\x1b[0m',
        'foobar\x1b[0m',
    ]
    for _text in text:
        assert len_without_ansi(_text) == 6
    assert len_without_ansi([]) == 0
    assert len_without_ansi('') == 0

try:
    from typing import TYPE_CHECKING
except ImportError:
    TYPE_CHECKING = False


# Generated at 2022-06-11 22:50:45.996573
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest  # type: ignore[import]
    from flutils.txtutils import len_without_ansi

    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6

    assert len_without_ansi('hello') == 5
    assert len_without_ansi([]) == 0

    # Test the fallback
    assert len_without_ansi(['foo\x1b[38;5;209m', 'bar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:50:49.256699
# Unit test for function len_without_ansi
def test_len_without_ansi():
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(_text) == 6



# Generated at 2022-06-11 22:50:51.441869
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    return True



# Generated at 2022-06-11 22:51:13.623979
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6
    test_list = list(text)
    out = len_without_ansi(test_list)
    assert out == 6



# Generated at 2022-06-11 22:51:16.219479
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:18.834994
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:22.817049
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 16
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:28.367849
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from len_without_ansi import len_without_ansi
    # Single string
    text = '\x1b[38;5;209mfoo\x1b[0m'
    assert len_without_ansi(text) == 3
    # List of strings
    text = ['\x1b[1mfoo', '\x1b[38;5;209mbar', '\x1b[0m']
    assert len_without_ansi(text) == 6
    # Empty string
    text = ''
    assert len_without_ansi(text) == 0
    # List with empty string
    text = ['', '\x1b[38;5;209mfoo', '', '\x1b[0m']
    assert len_without_ansi(text) == 3
    # Single string with reset

# Generated at 2022-06-11 22:51:33.582916
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[0m', 'bar']) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoo', '\x1b[0m', 'bar')) == 6



# Generated at 2022-06-11 22:51:35.575915
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:40.333483
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:42.613282
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.testingutils import unit_test_helper
    return unit_test_helper(len_without_ansi)



# Generated at 2022-06-11 22:51:45.855469
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    split_text = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(split_text) == 6
    return True



# Generated at 2022-06-11 22:52:14.617125
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('1234') == 4
    assert len_without_ansi('1234\x1b[48m') == 4
    assert len_without_ansi('1234\x1b[48;5;15m') == 4
    assert len_without_ansi('1234\x1b[48;5;15m5') == 5
    assert len_without_ansi('12345') == 5
    assert len_without_ansi('1234\x1b[48;5;15m56') == 6



# Generated at 2022-06-11 22:52:24.722778
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test the len_without_ansi function.
    """
    from flutils.txtutils import len_without_ansi

    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6

    # Test the edge cases
    assert len_without_ansi('\x1b[38;5;209m') == 0
    assert len_without_ansi('\x1b[38;5;209') == 0
    assert len_without_ansi('\x1b[38;5;209') == 0
    assert len_without_ansi('\x1b[38;5;209') == 0
    assert len_without_ansi('\x1b[38;5;209') == 0



# Generated at 2022-06-11 22:52:26.551295
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:34.405813
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ins = [
        'foobar',
        '\x1b[38;5;209mfoobar\x1b[0m',
        ('foo', 'bar', '\x1b[38;5;209mfoobar\x1b[0m'),
        ('\x1b[38;5;209mfoobar\x1b[0m', 'baz', 'quux'),
        (('\x1b[38;5;209mfoobar\x1b[0m',), ('baz', 'quux')),
    ]
    outs = (
        6, 6, 9, 8, 10
    )
    for in_, out in zip(ins, outs):
        assert len_without_ansi(in_) == out



# Generated at 2022-06-11 22:52:40.712808
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = [
        '[0;38;5;209mfoobar',
        'hello',
        ' \\x1b[38;5;214mworld'
    ]
    assert len_without_ansi(text) == 9
    text.append('\x1b[0m')
    assert len_without_ansi(text) == 9
# /Unit test



# Generated at 2022-06-11 22:52:43.651933
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:54.254252
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar', '\x1b[0m']
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 12

# Generated at 2022-06-11 22:53:00.597046
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from os.path import dirname, join
    from flutils.loadutils import get_data_abspath  # type: ignore[import]
    from flutils.txtutils import len_without_ansi
    text = get_data_abspath(join(dirname(__file__), 'testdata', 'ansi_text.txt'))
    with open(text, 'r') as f:
        text = f.read()
    assert len_without_ansi(text) == 8



# Generated at 2022-06-11 22:53:12.378398
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # pylint: disable=invalid-name
    import textwrap
    from flutils.txtutils import AnsiTextWrapper, len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    ansi_wrapper = AnsiTextWrapper(width=10)
    wrapped = ansi_wrapper.wrap(text)
    assert len_without_ansi(wrapped) == 10

    text = 'baz'
    wrapped = ansi_wrapper.wrap(text)
    assert len_without_ansi(wrapped) == 10

    ansi_wrapper = AnsiTextWrapper(width=6)
    wrapped = ansi_wrapper.wrap(text)

# Generated at 2022-06-11 22:53:22.402333
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from os import getenv
    from click.testing import CliRunner
    from flutils.cli import flutils

    runner = CliRunner()

    result = runner.invoke(flutils, ['len_without_ansi', '--no-color', '3'])
    if getenv('NO_COLOR') is not None:
        assert result.exit_code == 0
        assert result.output.split() == ['3']
    else:
        result = runner.invoke(flutils, ['len_without_ansi', '3'])
        assert result.exit_code == 0
        assert result.output.split() == ['3']

    result = runner.invoke(flutils, ['len_without_ansi', '3', '3', '3'])
    assert result.exit_code == 0

# Generated at 2022-06-11 22:55:54.684600
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert 6 == len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert 8 == len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[0mbar'])
    assert 6 == len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert 12 == len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[0mbar', '\x1b[38;5;209mfoo', '\x1b[0mbar'])



# Generated at 2022-06-11 22:56:03.455721
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m',
                             '\x1b[38;5;209mfoobar\x1b[0m')) == 12
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m',
                             '\x1b[38;5;209mfoobar\x1b[0m']) == 12



# Generated at 2022-06-11 22:56:13.223857
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['abc', 'def', '123']
    assert len_without_ansi(text) == 9
    # If the python version is >= 3.8
    if hexversion >= 0x03080000:
        assert len_without_ansi.cache_info().hits == 0
        assert len_without_ansi.cache_info().misses == 2
        assert len_without_ansi.cache_info().maxsize == 128
    # If the python version is < 3.8
    else:
        assert len_without_ansi.__wrapped__.cache_info().hits == 0
        assert len_without_ansi.__wrapped__.cache

# Generated at 2022-06-11 22:56:19.769984
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Basic test using a string
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # Basic test using a list/tuple
    text = ('\x1b[38;5;209mfoo', 'bar', '\x1b[0m')
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:56:26.035285
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoo\x1b[0m']
    assert len_without_ansi(text) == 12
    return True


# Generated at 2022-06-11 22:56:30.846972
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo\x1b[38;5;209m') == 3
    assert len_without_ansi(['foo', '\x1b[38;5;209m']) == 3
    assert len_without_ansi(['\x1b[38;5;209m', 'foo']) == 3
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', '\x1b[0m']) == 3
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m') == 3

