

# Generated at 2022-06-11 22:47:35.908444
# Unit test for function len_without_ansi
def test_len_without_ansi():
    s = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(s) == 6
# EOF test_len_without_ansi



# Generated at 2022-06-11 22:47:38.344862
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:47:44.024832
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from inspect import cleandoc
    from .commonutils import assert_equal

    text = cleandoc("""
        \x1b[38;5;209mfoobar\x1b[0m
    """)
    assert_equal(len_without_ansi(text), 6)



# Generated at 2022-06-11 22:47:47.187441
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# TODO: write unit tests

# Generated at 2022-06-11 22:47:50.548007
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    t = len_without_ansi(text)
    assert(t == 6)

# Generated at 2022-06-11 22:47:52.277483
# Unit test for function len_without_ansi
def test_len_without_ansi():
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(_text) == 6
    assert len_without_ansi([_text]) == 6



# Generated at 2022-06-11 22:47:58.161311
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.split()) == 6


# Generated at 2022-06-11 22:48:09.739277
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.miscutils import func_name
    from flutils.txtutils import len_without_ansi
    from . import data

    print(f'Running unittests for function "{func_name(len_without_ansi)}"')
    # Test with a single string
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6
    # Test with a list of strings
    seq = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    out = len_without_ansi(seq)
    assert out == 12
    # Test using data from the data module
   

# Generated at 2022-06-11 22:48:16.908203
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import sys
    import pytest
    assert len_without_ansi('\x1b[38;5;209mfoobar') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar']) == 6
    if sys.version_info[:2] >= (3, 7):
        with pytest.raises(TypeError, match='\'str\' object is not iterable'):
            len_without_ansi('foobar')
    else:
        assert len_without_ansi('foobar') == 6
# ---



# Generated at 2022-06-11 22:48:22.436488
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text, text]) == 12

# TextWrapper class with extended options and ANSI color
# awareness

# Generated at 2022-06-11 22:49:44.244579
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .texttest import _tst
    _tst.is_(len_without_ansi(''), 0)
    _tst.is_(len_without_ansi(None), 0)
    _tst.is_(len_without_ansi(1), 1)
    _tst.is_(len_without_ansi('foobar'), 6)
    _tst.is_(len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m'), 6)
    _tst.is_(len_without_ansi('\\x1b[38;5;209mfoo\\x1b[0mbar'), 9)
    _tst.is_(len_without_ansi(['foo', 'bar']), 6)

# Generated at 2022-06-11 22:49:53.618162
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function :func:`len_without_ansi`
    """
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209m'
    assert len_without_ansi(text) == 0
    text = 'foobar'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len

# Generated at 2022-06-11 22:50:04.965363
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    answer = 6
    assert len_without_ansi(text) == answer
    text = ['\x1b[38;5;209mfoobar\x1b[0m']
    answer = 6
    assert len_without_ansi(text) == answer
    text = ['\x1b[0m\x1b[38;5;209mfoob', 'ar\x1b[0m']
    answer = 6
    assert len_without_ansi(text) == answer
    text = '\x1b[38;5;209mfoo'
    answer = 3
    assert len_without_ansi(text) == answer



# Generated at 2022-06-11 22:50:15.389795
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pytest import raises

    with raises(TypeError, match=r'expected Sequence, got int'):
        len_without_ansi(42)

    assert len_without_ansi('foobar') == 6

    seq = '\u001b[38;5;209mfoobar\u001b[0m' \
          'other text\u001b[1;31mstuff\u001b[0m'
    assert len_without_ansi(seq) == 17

    seq = '\u001b[38;5;209mfoobar\u001b[0m' \
          '\u001b[1;31mstuff\u001b[0m'
    assert len_without_ansi(seq) == 15


# Generated at 2022-06-11 22:50:18.913107
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar:\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:24.722041
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = ('\x1b[1;3;31;46m\x1b[Kfoobar\x1b[m\x1b[K'
            ' \x1b[1;3;34;46;107m\x1b[Kfoobar\x1b[m\x1b[K')
    assert len_without_ansi(text) == 12



# Generated at 2022-06-11 22:50:35.054037
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function :func:`len_without_ansi`"""
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m',)) == 6

if __name__ == '__main__':
    test_len_without_ansi()



# Generated at 2022-06-11 22:50:46.085147
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert 0 == len_without_ansi('')
    assert 1 == len_without_ansi('\\x1b[38;5;209mt\\x1b[0m')
    assert 2 == len_without_ansi('\\x1b[38;5;209mte\\x1b[0m')
    assert 2 == len_without_ansi('\\x1b[38;5;209mt\\x1b[0m\\x1b[38;5;209me\\x1b[0m')
    assert 3 == len_without_ansi('\\x1b[38;5;209mt\\x1b[0m\\x1b[38;5;209me\\x1b[0m\\x1b[38;5;209mst\\x1b[0m')
    assert 0 == len

# Generated at 2022-06-11 22:50:50.060336
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-11 22:50:53.721831
# Unit test for function len_without_ansi
def test_len_without_ansi():  # pragma: no cover
    from flutils.txtutils import len_without_ansi

    len_without_ansi('')
    len_without_ansi(' ' * 100)
    len_without_ansi('\n' * 100)



# Generated at 2022-06-11 22:51:45.150157
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    assert len_without_ansi(['foobar', '\\x1b[38;5;209mfoobar\\x1b[0m']) == 12


# Generated at 2022-06-11 22:51:47.667161
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:51.451853
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-11 22:51:59.954938
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:06.362964
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m') == 3
    assert len_without_ansi('foo\x1b[0m') == 3
    assert len_without_ansi('\x1b[38;5;209mfoo') == 3
    assert len_without_ansi('foo\x1b[0mbar') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0mbar', 'baz']) == 9



# Generated at 2022-06-11 22:52:09.894797
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
# end function test_len_without_ansi


# Generated at 2022-06-11 22:52:13.102946
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # type: () -> None
    from .testing import check_len_without_ansi
    check_len_without_ansi(len_without_ansi)



# Generated at 2022-06-11 22:52:24.167042
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('foo bar') == 7
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    assert len_without_ansi(['foo']) == 3
    assert len_without_ansi(('foo bar', 'baz')) == 10
    assert len_without_ansi(['\\x1b[38;5;209mfoo\\x1b[0m', 'bar']) == 3
    assert len_without_ansi(('\\x1b[38;5;209mfoo\\x1b[0m', 'bar')) == 3

# Generated at 2022-06-11 22:52:33.721264
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test a single string
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[41m\x1b[38;5;209mfoobar\x1b[0m\x1b[0m') == 6
    assert len_without_ansi('\x1b[41m\x1b[38;5;209mfoobar') == 6
    assert len_without_ansi('\x1b[1m\x1b[38;5;209mfoobar\x1b[0m') == 7
    # Test a list of strings

# Generated at 2022-06-11 22:52:40.188713
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[1mfoobar\x1b[0m') == 6
    assert len_without_ansi(('\x1b[1mfoobar\x1b[0m', '\x1b[38;5;9mbaz\x1b[0m')) == 9



# Generated at 2022-06-11 22:53:14.969328
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Function to test
    from flutils.txtutils import len_without_ansi
    # Setup
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    # Test
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:19.427327
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[1m\x1b[38;5;209mfoo', '\x1b[0m', 'bar']
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:23.851658
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:31.022020
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from nose.tools import eq_
    text = ('\x1b[38;5;209mfoo\x1b[0m', '\x1b[1m\x1b[38;5;209mbar\x1b[0m')
    txt = ''.join(text)
    assert eq_(len_without_ansi(text), 6)
    assert eq_(len_without_ansi(txt), 6)
    # ---
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert eq_(len_without_ansi(text), 6)



# Generated at 2022-06-11 22:53:37.829110
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.custom_exceptions import FlutilsValueError
    import contextlib
    from flutils.txtutils import len_without_ansi
    from io import StringIO
    import sys
    import unittest

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-11 22:53:46.128375
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[31m', 'bar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[31mbar', '\x1b[38;5;209m', 'foo\x1b[0m']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:53:50.685199
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6



# Generated at 2022-06-11 22:53:59.542793
# Unit test for function len_without_ansi

# Generated at 2022-06-11 22:54:05.490224
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('foo\nbar') == 6
    assert len_without_ansi('foo\rbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\nbar\x1b[0m') == 6

# Generated at 2022-06-11 22:54:13.220064
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar', '\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar', '\x1b[0m', '\x1b[38;5;209mbaz', '\x1b[0m']
    assert len_without_ansi(text) == 9

