

# Generated at 2022-06-11 22:49:20.324737
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'bar']) == 6



# Generated at 2022-06-11 22:49:28.345530
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(2) == 0
    assert len_without_ansi(['x']) == 1
    ansi_str = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi([ansi_str, ansi_str]) == 12
    assert len_without_ansi(list(ansi_str)) == 6



# Generated at 2022-06-11 22:49:33.944343
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12



# Generated at 2022-06-11 22:49:39.092500
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('hello world') == 11
    assert len_without_ansi(['hello', 'world']) == 11
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:49:43.145354
# Unit test for function len_without_ansi
def test_len_without_ansi():  # pragma: no cover
    import pytest
    from flutils.txtutils import len_without_ansi
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:49:49.872304
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m',
                             '\x1b[38;5;209mbaz\x1b[0m')) == 8

# Generated at 2022-06-11 22:49:52.763695
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

#: .. versionadded:: 0.9.0

# Generated at 2022-06-11 22:49:56.612739
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = '\x1b[1m\x1b[41m\x1b[38;5;196mfoo\x1b[0m\x1b[1mbar\x1b[0m\x1b[0m'
    assert len_without_ansi(seq) == 7



# Generated at 2022-06-11 22:50:10.085669
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # pylint: disable=missing-function-docstring
    text = '\x1b[33;41;1mfoobar\x1b[0m'
    assert len(text) == 14
    assert len_without_ansi(text) == 6

    # Non-ascii string with accents
    text = '\x1b[38;2;255;85;85mfööbär\x1b[0m'
    assert len(text) == 19
    assert len_without_ansi(text) == 12

    # Unicode string with accents
    text = '\x1b[38;2;255;85;85mfööbär\x1b[0m'
    assert len(text) == 19
    assert len_without_ansi(text) == 12

    # List

# Generated at 2022-06-11 22:50:13.544061
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

