

# Generated at 2022-06-11 22:48:50.540875
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\033[1mfoobar\033[22m') == 6
    assert len_without_ansi(['\033[1mfoo', 'bar\033[22m']) == 6
    assert len_without_ansi(('\033[1mfoo', 'bar\033[22m')) == 6



# Generated at 2022-06-11 22:48:57.690088
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 17
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12
test_len_without_ansi()



# Generated at 2022-06-11 22:49:00.121943
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:49:09.586938
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Perform testing on flutils.txtutils.len_without_ansi()."""
    from flutils.txtutils import len_without_ansi

    _text = '\x1b[38;5;209mfoobar\x1b[0m'  # type: str
    expected = 6
    actual = len_without_ansi(_text)
    assert actual == expected

    _text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mbazboo\x1b[0m'
    ]  # type: List[str]
    expected = 12
    actual = len_without_ansi(_text)
    assert actual == expected
# /Unit test for function len_without_ansi



# Generated at 2022-06-11 22:49:16.720666
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest
    assert len_without_ansi('') == 0
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foo']) == 3
    assert len_without_ansi(('foo',)) == 3
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(('foo', 'bar')) == 6
    assert len_without_ansi(['foo', '\x1b[31mbar\x1b[0m']) == 6
    assert len_without_ansi(('foo', '\x1b[31mbar\x1b[0m')) == 6

# Generated at 2022-06-11 22:49:21.184851
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:49:27.386219
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = 'bal\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 9
    assert len_without_ansi(['bal', '\x1b[38;5;209mfoo\x1b[0m', 'bar']) == 9



# Generated at 2022-06-11 22:49:33.746660
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m \x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['foo', ' ', 'bar']) == 6



# Generated at 2022-06-11 22:49:43.030900
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'bar']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209mbar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'ba', 'r', '\x1b[38;5;209m']) == 6



# Generated at 2022-06-11 22:49:53.332436
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import ANSI_RESET, ANSI_RED, ANSI_UNDERLINE
    # Test 1
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    expected = 6
    actual = len_without_ansi(seq)
    assert actual == expected, 'Function failed: {} != {}'.format(actual, expected)
    # Test 2
    seq = ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209mbar\x1b[0m']
    expected = 6
    actual = len_without_ansi(seq)
    assert actual == expected, 'Function failed: {} != {}'.format(actual, expected)
    # Test 3

# Generated at 2022-06-11 22:51:25.390092
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m',
                             '\x1b[38;5;209mbar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m',
                             'foo',
                             '\x1b[0m',
                             '\x1b[38;5;209m',
                             'bar',
                             '\x1b[0m']) == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:51:27.456693
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:29.955088
# Unit test for function len_without_ansi
def test_len_without_ansi():
    _test_string = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(_test_string) == 6


# Generated at 2022-06-11 22:51:32.560873
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:41.031697
# Unit test for function len_without_ansi
def test_len_without_ansi(): # noqa: D202
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.splitlines(keepends=True)) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m\n\n'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.splitlines(keepends=True)) == 7

# Generated at 2022-06-11 22:51:44.270684
# Unit test for function len_without_ansi
def test_len_without_ansi():  # pragma: no cover
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:51:53.842851
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi


# Generated at 2022-06-11 22:52:00.058046
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6

# Generated at 2022-06-11 22:52:02.428890
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:04.430105
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:53:15.856896
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from sys import version_info
    from random import choice, randrange
    from string import hexdigits

    _text = ''.join([choice(hexdigits) for i in range(20)])
    text = '\x1b[38;5;' + _text + 'mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    if version_info.major >= 3 and version_info.minor >= 8:
        _text = ''.join([str(randrange(0, 9)) for _ in range(20)])
        text = '\x1b[38;5;' + _text + 'mfoobar\x1b[0m'

# Generated at 2022-06-11 22:53:20.133928
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 14
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar\x1b[0m']) == 6


# Generated at 2022-06-11 22:53:25.288327
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:53:27.867292
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:31.442440
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi([text, text]) == 12



# Generated at 2022-06-11 22:53:35.854770
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(['foo', '\x1b[38;5;209mbar\x1b[0m']) == 6



# Generated at 2022-06-11 22:53:39.740246
# Unit test for function len_without_ansi
def test_len_without_ansi():
    result = 6
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == result



# Generated at 2022-06-11 22:53:48.006543
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Assert function :func:`len_without_ansi <flutils.txtutils.len_without_ansi>`
    works correctly.

    *New in version 0.6.0*
    """
    from flutils.testing import assert_function
    import flutils.txtutils as txtutils
    assert_function(txtutils.len_without_ansi)
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
# /Unit test for function len_without_ansi



# Generated at 2022-06-11 22:53:53.353866
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(seq) == 6
    seq = ['\x1b[38;5;209mfoo', '\x1b[1mbar\x1b[0m']
    assert len_without_ansi(seq) == 6


# Generated at 2022-06-11 22:54:01.936492
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi."""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert(len_without_ansi(text) == 6)
    iterable = ['\x1b[38;5;209mfoobar\x1b[0m', '1234567890']
    assert(len_without_ansi(iterable) == 16)
    iterable = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert(len_without_ansi(iterable) == 6)
    # make sure it doesn't raise an exception
    iterable = ['\x1b[38;5;209m', 'foobar', '\x1b[0m', None]
