

# Generated at 2022-06-11 22:47:27.142416
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Test the `flutils.txtutils.len_without_ansi` function
    """
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    ansi_len = len(text)
    text_len = len_without_ansi(text)
    assert text_len == 6
    assert text_len < ansi_len


# TODO(jrruethe): Add support to accept an instance of ansicolor.Colr
#  as a wrapper.

# Generated at 2022-06-11 22:47:29.760262
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar \x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:47:39.708678
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('\x1b[1mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[1mfoobar\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[1mfoobar\x1b[0m',)) == 6
    assert len_without_ansi('foo\nbar\nbaz') == 11
    assert len_without_ansi(['foo', 'bar', 'baz']) == 11
    assert len_without_ansi(('foo', 'bar', 'baz')) == 11



# Generated at 2022-06-11 22:47:42.735607
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:47:45.533979
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:47:52.381362
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoobar', '\x1b[0m')) == 6



# Generated at 2022-06-11 22:47:55.993058
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-11 22:48:08.174288
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from py.test import raises


    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 20
    assert len_without_ansi(text) == 6

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 20
    assert len_without_ansi(text) == 6

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 20
    assert len_without_ansi(text) == 6

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 20
    assert len_without_ansi

# Generated at 2022-06-11 22:48:12.525928
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6, 'Wrong character count!'
#
# End test_len_without_ansi()



# Generated at 2022-06-11 22:48:13.756477
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:32.631929
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Unit test for function ``len_without_ansi``.
    """
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foobar', '\x1b[38;5;209m', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:48:41.027405
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = [
        '\x1b[38;5;209m',
        'foobar',
        '\x1b[0m',
    ]
    out = len_without_ansi(text)
    assert out == 6
    text = [
        '\x1b[38;5;209m',
        '1',
        '\x1b[38;5;208m',
        '2',
        '\x1b[38;5;207m',
        '3',
        '\x1b[38;5;206m',
        '4',
        '\x1b[38;5;205m',
        '5',
        '\x1b[0m',
    ]
    out = len_without_ansi(text)
    assert out == 5
    text

# Generated at 2022-06-11 22:48:44.126449
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:53.401501
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    from os import linesep as ls
    assert(len_without_ansi('foobar') == 6)
    assert(len_without_ansi(['foo', 'bar']) == 6)
    assert(len_without_ansi('foo' + ls + 'bar') == 6)
    assert(len_without_ansi(['foo' + ls + 'bar']) == 6)
    assert(len_without_ansi('foo' + ls + 'bar' + ls) == 6)
    assert(len_without_ansi(['foobar', 'foobar']) == 12)
    assert(len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6)

# Generated at 2022-06-11 22:48:59.462694
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from textwrap import dedent
    from pytest import raises
    from flutils.txtutils import len_without_ansi

    # Test valid string input
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    # Test invalid string input
    with raises(TypeError):
        assert len_without_ansi(None)
    with raises(TypeError):
        assert len_without_ansi(None, 1)
    with raises(TypeError):
        assert len_without_ansi(None, 1, None)

    # Test valid list/tuple input
    text = ('\x1b[38;5;209mfoobar\x1b[0m', 'baz')

# Generated at 2022-06-11 22:49:08.262393
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils import TestCase
    from random import randint
    from random import choice as rc
    from sys import hexversion
    from textwrap import wrap
    from itertools import chain
    from string import ascii_letters


# Generated at 2022-06-11 22:49:13.802653
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = 6
    assert out == len_without_ansi(text)
    text = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    out = 6
    assert out == len_without_ansi(text)



# Generated at 2022-06-11 22:49:21.506075
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3
    assert len_without_ansi(['foo']) == 3
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foo\x1b[38;5;209mfoobar\x1b[0m') == 9
    assert len_without_ansi(['foo', '\x1b[38;5;209mfoobar\x1b[0m']) == 9


# Generated at 2022-06-11 22:49:23.848319
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# AnsiTextWrapper

# Generated at 2022-06-11 22:49:30.331901
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('\u001b[38;5;209mfoobar\u001b[0m') == 6
    assert len_without_ansi(
        ['\u001b[38;5;209mfoo\u001b[0m', "\u001b[38;5;209mbar\u001b[0m"]
        ) == 6



# Generated at 2022-06-11 22:49:51.287228
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-11 22:49:54.274408
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209m\x1b[38;5;196mbold\x1b[0m\x1b[0m'
    assert len_without_ansi(text) == 5

# Generated at 2022-06-11 22:49:59.538137
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa: D103
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:50:03.133850
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:10.989101
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = (
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;124mfoobar\x1b[0m',
    )
    assert len_without_ansi(text) == 12
# /Unit test for function len_without_ansi



# Generated at 2022-06-11 22:50:15.354667
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoo\x1b[K\x1b[0m'
    expected = 3
    assert len_without_ansi(text) == expected

    text = '\x1b[K\x1b[0m'
    expected = 0
    assert len_without_ansi(text) == expected



# Generated at 2022-06-11 22:50:18.225516
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:50:24.083132
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6
    out = len_without_ansi(['foo', '\x1b[38;5;209mbar\x1b[0m'])
    assert out == 3



# Generated at 2022-06-11 22:50:31.415917
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi."""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', '', 'baz']) == 6



# Generated at 2022-06-11 22:50:38.362537
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test the len_without_ansi function."""
    from .txtutils import len_without_ansi

    str_text = '\x1b[38;5;209mfoobar\x1b[0m'
    str_out = len_without_ansi(str_text)

    assert str_out == 6

    list_text = ['\x1b[38;5;209mfoobar', '\x1b[0m']
    list_out = len_without_ansi(list_text)

    assert list_out == 6

# Generated at 2022-06-11 22:50:57.049424
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', 'baz']) == 9



# Generated at 2022-06-11 22:51:00.399406
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:05.733171
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for len_without_ansi."""
    assert len_without_ansi('hello world') == 11
    assert len_without_ansi('\x1b[38;5;209mhelloworld\x1b[0m') == 11
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:51:10.749419
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6



# Generated at 2022-06-11 22:51:16.312061
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foobar']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6

# ==== ==== ==== ==== ==== ==== ==== ==== ==== ==== ==== ==== ==== ==== ==== ====


# Generated at 2022-06-11 22:51:20.858168
# Unit test for function len_without_ansi
def test_len_without_ansi():
    utxt = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(utxt) == 6
    utxt = '\x1b[38;5;209mfoo\x1b[0mbar\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(utxt) == 9
    utxt = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(utxt) == 3
    utxt = 'foo'
    assert len_without_ansi(utxt) == 3



# Generated at 2022-06-11 22:51:24.714759
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:51:26.239947
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:51:32.191389
# Unit test for function len_without_ansi
def test_len_without_ansi():
    '''
    Test:
        >>> from flutils.txtutils import len_without_ansi
    '''
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m',
            '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:42.898999
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 9



# Generated at 2022-06-11 22:52:02.869961
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6


# Generated at 2022-06-11 22:52:05.039236
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.splitlines()) == 6

# Generated at 2022-06-11 22:52:09.080346
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = """\x1b[38;5;209mfoobar
        \x1b[38;5;250mfizzbuzz\x1b[0m"""
    expected = 11
    assert len_without_ansi(text) == expected



# Generated at 2022-06-11 22:52:16.558151
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # text = 'x\x1b[38;5;209mfoobar\x1b[0m'
    text = ['x', '\x1b[38;5;209m', 'foobar', '\x1b[0m', 'x']
    assert len_without_ansi(text) == 8
    assert len_without_ansi(text[1:]) == 6
    assert len_without_ansi('') == 0
    assert len_without_ansi(text[0]) == 1



# Generated at 2022-06-11 22:52:24.038478
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[1m\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foo\x1b[1m\x1b[38;5;209mbar\x1b[0m') == 6
    assert len_without_ansi(('foo', '\x1b[1m\x1b[38;5;209mbar\x1b[0m')) == 6



# Generated at 2022-06-11 22:52:33.734646
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa: D103
    from textwrap import dedent
    from sys import modules
    from pathlib import Path
    from unittest.mock import patch
    from flutils.txtutils import (
        len_without_ansi,
        AnsiTextWrapper,
    )
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert isinstance(AnsiTextWrapper(width=80), TextWrapper)
    assert len_without_ansi('foobar') == 6
    # Test for issue #32
    wrapper = AnsiTextWrapper(width=80)
   

# Generated at 2022-06-11 22:52:45.542908
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == len('foobar')
    text = '\x1b[38;5;209m\x1b[0mfoo\x1b[0mbar\x1b[0m'
    assert len_without_ansi(text) == len('foobar')
    text = '\x1b[38;5;209m\x1b[0m\x1b[38;5;209m\x1b[0mfoo\x1b[38;5;209mfo'

# Generated at 2022-06-11 22:52:49.942506
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:53.960438
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:02.471313
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

# Generated at 2022-06-11 22:53:14.925806
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:18.844390
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-11 22:53:25.047019
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ('\x1b[38;5;209mfoobar', '\x1b[0m')
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:29.192819
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foo', '\x1b[38;5;209m', 'bar', '\x1b[0m']) == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:53:33.435635
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[33mbar\x1b[0m']
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:39.355996
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from . import txtutils
    txt = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert txtutils.len_without_ansi(txt) == 6
    seq = ['\\x1b[38;5;209m', 'foobar', '\\x1b[0m']
    assert txtutils.len_without_ansi(seq) == 6

# Generated at 2022-06-11 22:53:47.567164
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = ['\x1b[1mbold\x1b[0m', '\x1b[2mitalics\x1b[0m']
    assert len_without_ansi(text) == 10

    text = "\x1b[1mbold &\x1b[0m \x1b[2m 'italics' \x1b[0m"
    assert len_without_ansi(text) == 12



# Generated at 2022-06-11 22:53:52.994101
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test the function :func:`len_without_ansi <flutils.txtutils.len_without_ansi>`."""
    from .txtutils import len_without_ansi
    ansi_text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(ansi_text) == 6



# Generated at 2022-06-11 22:54:01.554760
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from nose.tools import assert_equal
    from flutils.txtutils import len_without_ansi
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert_equal(len_without_ansi(text), 6)
    _text = '\\x1b[38;5;209mfoobar\\x1b[0m\\x1b[38;5;209m\\x1b[0m'
    assert_equal(len_without_ansi(_text), 6)
    _text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert_equal(len_without_ansi(_text), 6)

# Generated at 2022-06-11 22:54:03.098183
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:54:48.015719
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi(['foo', 'bar', 'baz']) == 9
    assert len_without_ansi([]) == 0
    assert len_without_ansi(['', '', '', '']) == 0
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;34mfoo\x1b[0mbar\x1b[38;5;16mbaz') == 9



# Generated at 2022-06-11 22:54:49.535413
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:54:51.184362
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert(len_without_ansi(text) == 6)
test_len_without_ansi()



# Generated at 2022-06-11 22:55:02.363156
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text_list = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(text_list) == 6

    text_list = ['\x1b[38;5;209m', 'foobar\x1b[0m']
    assert len_without_ansi(text_list) == 6

    text_list = ['\x1b[38;5;209m', 'foobar', '\x1b[0m ']
    assert len_without_ansi(text_list) == 6

   

# Generated at 2022-06-11 22:55:06.852655
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('\x1b[1;32mfoo\x1b[m') == 3
    assert len_without_ansi(['foo', '\x1b[0m']) == 3



# Generated at 2022-06-11 22:55:15.010046
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = [text, text]
    assert len_without_ansi(text) == 12
    assert len_without_ansi([text, text]) == 24
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foobar', 'foobar']) == 12
    assert len_without_ansi([['foobar', 'foobar']]) == 24
    text = '{!r}'.format(text)
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text, text]) == 12
    assert len_without

# Generated at 2022-06-11 22:55:22.481923
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # type: () -> None
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mfoobar\x1b[0m') == 12
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']) == 12

# Generated at 2022-06-11 22:55:26.376993
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:35.515089
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi."""
    from flutils.txtutils import len_without_ansi
    # Used to test if comments are counted.
    text1 = '''
# This is a comment.
foo = bar'''
    assert len_without_ansi(text1) == 12
    # Used to test if ANSI codes are counted.
    # Should be 0 because of all the ANSI codes.
    text2 = '\x1b[38;5;209mblue\x1b[0m'
    assert len_without_ansi(text2) == 0
    # Used to see if ANSI-colored strings are counted.
    text3 = '\x1b[38;5;209mblue\x1b[0m'

# Generated at 2022-06-11 22:55:41.510925
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12
