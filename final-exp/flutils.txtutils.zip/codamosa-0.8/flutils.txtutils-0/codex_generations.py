

# Generated at 2022-06-11 22:47:55.160806
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:06.945227
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi([]) == 0
    assert len_without_ansi(['foo']) == 3
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(['foo', 'bar', 'baz']) == 9
    assert len_without_ansi(['']) == 0
    assert len_without_ansi(['', '', '']) == 0
    assert len_without_ansi(['', '', 'foo']) == 3
    assert len_without_ansi(['foo', '', 'bar']) == 6
    assert len_without_ansi(['foo', '', 'bar', '']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-11 22:48:15.149247
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Unit test for flutils.txtutils.len_without_ansi
    """
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-11 22:48:17.627879
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:25.447703
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6
    text = [text, text]
    out = len_without_ansi(text)
    assert out == 12
    text = [text, text]
    out = len_without_ansi(text)
    assert out == 24



# Generated at 2022-06-11 22:48:31.152401
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function `len_without_ansi`."""
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['foo', '\\x1b[38;5;209mbar', '\\x1b[0mbaz']
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:48:40.331360
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from hypothesis import given, strategies as st

    @given(st.text())
    def test_len_without_ansi_text(text):
        out = len_without_ansi(text)
        assert isinstance(out, int)
    test_len_without_ansi_text()  # type: ignore[call-arg]

    @given(st.lists(st.text(), min_size=1))
    def test_len_without_ansi_list(lst):
        out = len_without_ansi(lst)
        assert isinstance(out, int)
    test_len_without_ansi_list()  # type: ignore[call-arg]


# Generated at 2022-06-11 22:48:47.852654
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', '', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi('\x1b[38;5;209m\x1b[0mfoobar') == 6
    assert len_without_ansi(['\x1b[38;5;209m', '', '\x1b[0mfoobar']) == 6
    assert len_without_ans

# Generated at 2022-06-11 22:48:52.152056
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m\x1b[2m\x1b[38;5;230mfoo\x1b[0m'
    assert len_without_ansi(text) == 9



# Generated at 2022-06-11 22:48:56.102653
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    expected = 6
    actual = len_without_ansi(text)
    assert actual == expected, 'Actual: {0!r}'.format(actual)



# Generated at 2022-06-11 22:50:47.689621
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pytest import raises
    from flutils.txtutils import len_without_ansi
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    with raises(TypeError):
        len_without_ansi(123)



# Generated at 2022-06-11 22:50:50.596750
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    return len_without_ansi(text)
assert test_len_without_ansi() == 6



# Generated at 2022-06-11 22:50:58.607920
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foobar']) == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m\x1b[49m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo') == 3
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m') == 3

# Generated at 2022-06-11 22:51:03.050316
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(('\x1b[38;5;209mfoo', 'bar\x1b[0m')) == 6



# Generated at 2022-06-11 22:51:05.993406
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:15.910838
# Unit test for function len_without_ansi
def test_len_without_ansi(): # noqa
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    text = 'f\\x1b[38;5;209moobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\\x1b[38;5;209mfoo', 'bar\\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ['f\\x1b[38;5;209mo', 'ob\\x1b[0mar']
    assert len_without_ansi(text) == 6
    text = 'f\\x1b[38;5;209moobar\\x1b[0m'
    assert len_without_

# Generated at 2022-06-11 22:51:21.201826
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from hypothesis import given
    from hypothesis.strategies import from_regex, lists

    from .strategies import ansi_codes

    text = from_regex('[a-zA-Z0-9 ]+', fullmatch=True)
    text_list = lists(text).map(''.join)

    def ansi_str(
            code_str: str,
            text: str,
    ):
        """
        :param code_str: The ANSI sequence code.
        :type: :obj:`str`
        :param text: The text preceded by the ANSI sequence.
        :type: :obj:`str`
        :return: text preceded by the ANSI sequence.
        :rtype: :obj:`str`
        """

# Generated at 2022-06-11 22:51:27.492990
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = 'f\x1b[38;5;209moobar\x1b[0mbaz'
    assert len_without_ansi(text) == 9

    text = ['f\x1b[38;5;209moobar\x1b[0m', 'baz']
    assert len_without_ansi(text) == 9
test_len_without_ansi()


# noinspection PyAbstractClass

# Generated at 2022-06-11 22:51:33.162873
# Unit test for function len_without_ansi
def test_len_without_ansi():
    t = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(t) == 6
    assert len_without_ansi(['foo\x1b[38;5;209m', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(('foo\x1b[38;5;209m', 'bar', '\x1b[0m')) == 6



# Generated at 2022-06-11 22:51:43.122133
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils import _testhelper
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[38;5;228mb\x1b[38;5;169ma\x1b[38;5;173mr\x1b[0m') == 6
    _testhelper.test(len_without_ansi)
test_len_without_ansi.__test__ = False  # type: ignore[assignment]


# Generated at 2022-06-11 22:52:54.637257
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0mbar',
                             '\x1b[38;5;209mfoo\x1b[0mbar']) == 12



# Generated at 2022-06-11 22:53:01.973384
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('foo\x1b[0m') == 3
    assert len_without_ansi('\x1b[0m') == 0
    assert len_without_ansi('\x1b[0mfoo\x1b[0m') == 3
    seq = ['foo\x1b[0m', 'bar\x1b[0m']
    assert len_without_ansi(seq) == 6
# end function test_len_without_ansi



# Generated at 2022-06-11 22:53:09.129745
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for the :func:`len_without_ansi` method."""
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;224m']) == 6


# Generated at 2022-06-11 22:53:15.557731
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12


# Generated at 2022-06-11 22:53:18.185102
# Unit test for function len_without_ansi
def test_len_without_ansi():
    txt = '\x1b[31mfoobar\x1b[0m'
    assert len_without_ansi(txt) == 6


# Generated at 2022-06-11 22:53:25.446551
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    lines = ['\x1b[38;5;209mfoo', 'bar\x1b[0m']
    assert len_without_ansi(lines) == 6



# Generated at 2022-06-11 22:53:33.966125
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from textwrap import dedent
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('foobar') == 6
    text = dedent('''\
        >>> import flutils
        >>> print flutils.__name__
        flutils
        ''')
    assert len_without_ansi(text) == 31
    text = dedent('''\
        >>> print flutils.__version__
        '0.1'
        ''')
    assert len_without_ansi(text) == 26
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    # When a list of strings is supplied, they are concatenated first

# Generated at 2022-06-11 22:53:39.474594
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(('\x1b[38;5;209mfoo', '\x1b[38;5;210mbar')) == 6



# Generated at 2022-06-11 22:53:43.627587
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.split()) == 6



# Generated at 2022-06-11 22:53:47.139388
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:16.881119
# Unit test for function len_without_ansi

# Generated at 2022-06-11 22:55:20.677151
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import doctest
    from . import txtutils
    doctest.testmod(txtutils)


# Based on https://github.com/pypa/pip/blob/master/pip/_internal/utils/misc.py
# MIT License

# Generated at 2022-06-11 22:55:29.928582
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Test function len_without_ansi
    """
    from unittest import TestCase
    from .flutils_types import SimpleNamespace

    from .txtutils import len_without_ansi

    class Test_len_without_ansi(TestCase):
        """
        Test case for function len_without_ansi
        """
        def test_len_without_ansi(self):
            """
            Test len_without_ansi
            """
            # self.assertEqual(len_without_ansi(['abc', 'defghijk']), 10)
            # self.assertEqual(len_without_ansi(['abc', '\\x1b[38;5;209mdefghijk']),
            #                  10)

# Generated at 2022-06-11 22:55:31.799322
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:42.414552
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m\x1b[1mBOLD\x1b[0m'
    assert len_without_ansi(text) == 10
    text = '\x1b[38;5;209mfoobar\x1b[0m\x1b[1mBOLD\x1b[0m\x1b[1mBOLD\x1b[0m'
    assert len_without_ansi(text) == 12

# Generated at 2022-06-11 22:55:45.992266
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert 6 == len_without_ansi(text)



# Generated at 2022-06-11 22:55:51.136680
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m']) == 6


# Generated at 2022-06-11 22:55:54.117847
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
# test_len_without_ansi



# Generated at 2022-06-11 22:55:58.862641
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test flutils.txtutils.len_without_ansi()."""
    from flutils.txtutils import len_without_ansi

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:56:01.214177
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

