

# Generated at 2022-06-11 22:48:29.655808
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar') == 6
    assert len_without_ansi('\x1b[38;5;209m') == 0
    assert len_without_ansi('\x1b[0m') == 0
    assert len_without_ansi(
        ['\x1b[38;5;209mfoobar', '\x1b[0m']
    ) == 6

# Generated at 2022-06-11 22:48:31.649163
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:48:40.674218
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '''\
\x1b[38;5;209mfoobar\x1b[0m
\x1b[38;5;209mfoobar\x1b[0m
\x1b[38;5;209mfoobar\x1b[0m'''
    assert len_without_ansi(text) == 18

# Generated at 2022-06-11 22:48:43.614608
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert(len_without_ansi(text) == 6)



# Generated at 2022-06-11 22:48:48.841551
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from hypothesis import given
    from hypothesis.strategies import (
        sampled_from,
        text,
    )
    from flutils.txtutils import len_without_ansi
    from .conftest import ANSI_CODES
    ansi_codes = sampled_from(ANSI_CODES)

    # Test as string
    @given(text(min_size=1), ansi_codes)
    def test_len_without_ansi_string(text: str, ansi_code: str):
        new_text = ''.join([text, ansi_code, 'foobar', '\x1b[0m'])
        assert len_without_ansi(new_text) == len(text) + 6

    # Test as list of strings

# Generated at 2022-06-11 22:48:53.743587
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Unit test for function :func:`flutils.txtutils.len_without_ansi`
    """
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
# type: ignore[misc]



# Generated at 2022-06-11 22:48:58.990910
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text = '\x1b[31mfoo\x1b[0m'
    assert 6 == len_without_ansi(ansi_text)
    text = '\x1b[31mfoo\x1b[0m'
    ansi_text = '\x1b[31mfoo\x1b[0m'
    text2 = '\x1b[32mbar\x1b[0m'
    seq = [text, ansi_text, text2]
    assert 12 == len_without_ansi(seq)
    assert 6 == len_without_ansi(text)



# Generated at 2022-06-11 22:49:01.650166
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:49:07.152865
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('abcdef') == 6
    assert len_without_ansi(('aaa', 'bbb')) == 6
    assert len_without_ansi(['aaa', 'bbb', 'c']) == 6
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
test_len_without_ansi()  # pragma: no cover



# Generated at 2022-06-11 22:49:09.907171
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:49:58.577259
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text: str = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
# -- end-of Unit test for function len_without_ansi


# Generated at 2022-06-11 22:50:04.584134
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ('\x1b[38;5;209mfoobar', '\x1b[0m')
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:50:13.901427
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('ABC DEF') == 7
    assert len_without_ansi(['ABC', 'DEF']) == 7
    assert len_without_ansi('ABC\x1b[38;5;209mDEF') == 7
    assert len_without_ansi('ABC\x1b[38;5;209mDEF\x1b[0m') == 7
    assert len_without_ansi('\x1b[38;5;209mABC\x1b[0m') == 3
    assert len_without_ansi('\x1b[38;5;209mABC\x1b[0mDEF') == 6



# Generated at 2022-06-11 22:50:21.774926
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m') == 6
    assert len_without_ansi([text, text]) == 12



# Generated at 2022-06-11 22:50:29.779148
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Show that function works with a regular string
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # Show that it works with a list
    text = ['\x1b[38;5;209mfoobar\x1b[0m', 'hello', 'world']
    assert len_without_ansi(text) == 15



# Generated at 2022-06-11 22:50:32.106612
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:37.621421
# Unit test for function len_without_ansi
def test_len_without_ansi():
    cases = [
        ('\x1b[38;5;209mfoobar\x1b[0m', 6),
        ('\x1b[38;5;209mfoo\x1b[0mbar', 6),
    ]
    for text, expected in cases:
        assert len_without_ansi(text) == expected
test_len_without_ansi()  # Leave this line in the source code



# Generated at 2022-06-11 22:50:40.337126
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    output = len_without_ansi(text)
    assert output == 6



# Generated at 2022-06-11 22:50:44.533074
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:48.573987
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6


# Generated at 2022-06-11 22:51:43.935252
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 12
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12

# Generated at 2022-06-11 22:51:51.948635
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi"""
    from flutils.txtutils import len_without_ansi
    from random import randint
    from string import ascii_lowercase
    for _ in range(100):
        out = []
        for _ in range(randint(0, 10)):
            out.append(''.join(ascii_lowercase[randint(0, 25)] for _ in range(50)))
        text = ''.join(out)
        _ = len_without_ansi(text)
        _ = len_without_ansi([text])
    return True

# Generated at 2022-06-11 22:51:54.985521
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function ``len_without_ansi``."""
    from ..constants.misc import TEST_STRING as TEXT

    assert len_without_ansi(TEXT) == 6
    assert len_without_ansi([TEXT]) == 6



# Generated at 2022-06-11 22:52:04.263060
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa: D103
    from pytest_check import check as chk
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    with chk.only():
        chk.equal(len_without_ansi(text), 6)
        chk.equal(len_without_ansi([text]), 6)
        chk.equal(len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']), 6)
        chk.equal(len_without_ansi(['foobar']), 6)



# Generated at 2022-06-11 22:52:10.852322
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test for function len_without_ansi."""
    # Test flutils.txtutils.len_without_ansi
    from flutils.txtutils import len_without_ansi
    from .prints import cprint

    cprint('foobar', 'red', attrs=('bold',))
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    ans = len_without_ansi(text)
    print(ans)
    assert ans == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:52:16.170967
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foo', '\x1b[38;5;209m', 'bar', '\x1b[0m', 'asdf']) == 8



# Generated at 2022-06-11 22:52:25.791697
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest
    main_test = '\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mfoo\x1b[0m'
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    text += '\x1b[38;5;209m\x1b[38;5;209mfoobar\x1b[0m\x1b[0m'
    res = len_without_ansi(text)
    assert res == len(main_test)
    assert res != len(text)
    res = len_without_ansi([text])
    assert res == len(main_test)
    assert res != len(text)

# Generated at 2022-06-11 22:52:29.417280
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:32.524619
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:44.592150
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[0mfoobar\x1b[0m'
    assert len_without_ansi(text) == len(text) == 7
    seq = [text, '\x1b[0mbaz\x1b[0m']
    assert len_without_ansi(seq) == len(seq) == 10
    seq = ['\x1b[38;5;160mquux\x1b[0m', '\x1b[38;5;160mexfoobar\x1b[0m']
    assert len_without_ansi(seq) == len(seq) == 14
    text = '\x1b[38;5;160mfoobar\x1b[0m'
    assert len_without_ansi(text) == len(text) == 12



# Generated at 2022-06-11 22:53:23.162417
# Unit test for function len_without_ansi
def test_len_without_ansi():
    items = ['\x1b[38;5;209mfoobar\x1b[0m', ('\x1b[1mfoo\x1b[0m', '\x1b[2mbar\x1b[0m')]
    for item in items:
        expected = 6
        actual = len_without_ansi(item)
        assert expected == actual



# Generated at 2022-06-11 22:53:26.559399
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    ans = len_without_ansi(text)
    assert ans == 6
# end function test_len_without_ansi



# Generated at 2022-06-11 22:53:32.422458
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m',
                    '\x1b[38;5;208mfoobar\x1b[0m')) == 12


# Generated at 2022-06-11 22:53:34.582099
# Unit test for function len_without_ansi
def test_len_without_ansi():
    "{}"
    from flutils.txtutils import len_without_ansi

    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:53:37.246394
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:46.913249
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    sequences: List[Sequence] = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        ['\x1b[38;5;209m', 'foobar', '\x1b[0m'],
        ['foo', '\x1b[2mbar']
    ]
    expected = [6, 6, 4]
    for num, seq in enumerate(sequences):
        result = len_without_ansi(seq)
        assert result == expected[num]
# Test function len_without_ansi
test_len_without_ansi()



# Generated at 2022-06-11 22:53:56.549506
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

# Generated at 2022-06-11 22:54:01.961672
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from textwrap import dedent
    from .txtutils import len_without_ansi

    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6

    text = dedent("""\
        foobar
        * foo
          * foo
            * foo
              * foo
        * bar
          * bar
            * bar
              * bar
        """)
    assert len_without_ansi(text.splitlines()) == 132



# Generated at 2022-06-11 22:54:05.379741
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = (
        '\x1b[38;5;209mfoobar\x1b[0m',
        ['\x1b[38;5;209mfoo', 'bar\x1b[0m'],
        'foo',
        ['foo', 'bar']
    )
    for seq in text:
        answer = len_without_ansi(seq)
        if answer != 6:
            raise AssertionError(answer)
test_len_without_ansi()



# Generated at 2022-06-11 22:54:10.417006
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi
    """
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:10.191334
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mfoo',
        'bar\x1b[0m',
    ]
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:13.483708
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # Make sure this works with lists/tuples:
    assert len_without_ansi(['test', text]) == 10



# Generated at 2022-06-11 22:55:20.647251
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = [
        '', '\x1b[0m', 'f', '\x1b[38;5;209m', 'oo', '\x1b[0m', 'b',
        '\x1b[38;5;209m', 'ar'
    ]
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:28.319066
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12



# Generated at 2022-06-11 22:55:31.513691
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:36.439613
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    assert len_without_ansi(['\\x1b[31mfoo', 'bar\\x1b[0m']) == 6



# Generated at 2022-06-11 22:55:43.691387
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('123') == 3
    assert len_without_ansi('1234') == 4
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('12\x1b[38;5;209m34\x1b[0m') == 4
    assert len_without_ansi('12\x1b[38;5;209m34\x1b[0m\x1b[38;5;209m56\x1b[0m78') == 8

# Generated at 2022-06-11 22:55:52.000192
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    text2 = '\x1b[38;5;209mfoobar\x1b[38;5;209mfoobar\x1b[0m\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text2) == 12
    assert len_without_ansi('\nfoobar') == 7
    assert len_without_ansi(['\nfoo', 'bar']) == 7



# Generated at 2022-06-11 22:55:54.490919
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:57.423721
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    return True

