

# Generated at 2022-06-11 22:50:08.282274
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit tests for flutils.txtutils.len_without_ansi"""
    import pytest  # noqa
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    text2 = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    ans = len_without_ansi(text)
    ans2 = len_without_ansi(text2)
    assert (ans == 6) and (ans2 == 6), 'Function failed.'



# Generated at 2022-06-11 22:50:14.268811
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test1 = '\x1b[38;5;209mfoobar\x1b[0m'
    test2_list = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(test1) == 6
    assert len_without_ansi(test2_list) == 6
# Unit test method
test_len_without_ansi()


_wrapper: Optional[TextWrapper] = None



# Generated at 2022-06-11 22:50:19.434854
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(ansi) == 6
    assert len_without_ansi([ansi]) == 6
    assert len_without_ansi([ansi, '  ']) == 6



# Generated at 2022-06-11 22:50:29.755199
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    text2 = '\x1b[38;5;209mfoobar\x1b[0m'.split()
    text3 = '\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mfoobar\x1b[0m'.split()
    text4 = '\x1b[38;5;209mf\x1b[0moobar\x1b[0m'.split()
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text2) == 6
    assert len_without_ansi(text3) == 12
    assert len_without_ansi(text4) == 6



# Generated at 2022-06-11 22:50:38.916685
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test for flutils.txtutils.len_without_ansi
    """
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    out = 6
    assert len_without_ansi(text) == out

    text = '\\x1b[38;5;209mfoo\\x1b[0m \\x1b[1mbar\\x1b[0m'
    out = 8
    assert len_without_ansi(text) == out

    text = '\\x1b[1mfoobar\\x1b[0m'
    out = 6
    assert len_without_ansi(text) == out


# Generated at 2022-06-11 22:50:42.057372
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:50:45.724693
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:55.908008
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function ``len_without_ansi``."""
    from copy import copy
    from flutils.txtutils import len_without_ansi
    from .testhelpers import get_testdata_filepath, string_to_ansi


# Generated at 2022-06-11 22:51:00.435300
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6



# Generated at 2022-06-11 22:51:05.612755
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[0mbar']) == 6



# Generated at 2022-06-11 22:52:18.210910
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6



# Generated at 2022-06-11 22:52:24.164641
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text2 = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text2) == 12



# Generated at 2022-06-11 22:52:33.762680
# Unit test for function len_without_ansi

# Generated at 2022-06-11 22:52:40.653386
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['', '\x1b[38;5;209mfoobar', '', 'baz\x1b[0m']
    assert len_without_ansi(text) == 11



# Generated at 2022-06-11 22:52:43.687159
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:48.617060
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:56.446408
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi()."""
    # Simple string
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    # List of strings
    text = ['\\x1b[38;5;209mfoobar\\x1b[0m', '\\x1b[1;32mblah\\x1b[0m', 'suuuuuu']
    assert len_without_ansi(text) == 14



# Generated at 2022-06-11 22:53:04.477161
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi"""
    import os
    import pytest
    from rtimbroo_utils.testing.flutils import HasLogger

    # In python 3.7 and later, sys.hexversion is a named attribute
    # In earlier versions, it is a numeric constant
    if hasattr(hexversion, 'bit_length'):
        python_version = f'{hexversion >> 24}.{(hexversion >> 16) & 0xff}.{hexversion & 0xffff}'
    else:
        python_version = f'{hexversion >> 24}.{(hexversion >> 16) & 0xff}.{hexversion & 0xffff}'
    if python_version < (3, 7, 0):
        pytest.skip('Tests for len_without_ansi only relevant for Python >= 3.7')


# Generated at 2022-06-11 22:53:16.261912
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pytest import raises
    from flutils.tests.txtutils import text
    assert len_without_ansi('') == 0
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi([]) == 0
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('foo  ') == 5
    assert len_without_ansi(text) == 0
    assert len_without_ansi(text + 'foobar') == 6
    assert len_without_ansi([text, 'foo']) == 3
    assert len_without_ansi([text, 'foobar']) == 6
    assert len_without_ansi(1) == 0
    assert len_without_ansi(12) == 2

# Generated at 2022-06-11 22:53:26.202095
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from random import choice
    from string import ascii_letters

    def get_len(seq):
        return len_without_ansi(seq)

    for _ in range(100): # nosec
        text = ''.join(choice(ascii_letters) for _ in range(500))
        text = '\x1b[38;5;209m' + text + '\x1b[0m'
        seq = [choice(ascii_letters) for _ in range(500)]
        assert get_len(text) == len(text) - 6
        assert get_len(seq) == len(seq)
    for _ in range(100): # nosec
        text = ''.join(choice(ascii_letters) for _ in range(500))

# Generated at 2022-06-11 22:55:54.559783
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(f'{text} - {text}') == 12
    assert len_without_ansi([text]) == 6
# Unit test ends



# Generated at 2022-06-11 22:56:00.107855
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo\x1b[38;5;209mbar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foo\x1b[38;5;209m\x1b[0mbar') == 6



# Generated at 2022-06-11 22:56:03.415281
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:56:13.282600
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function :func:`~flutils.txtutils.len_without_ansi`."""
    from typing import Any
    from flutils.txtutils import len_without_ansi

    # Basic test
    text = '\x1b[38;5;209mfoobar\x1b[0m'  # str
    assert len_without_ansi(text) == 6, 'Failed to determine length of color text'

    # Test list of strings
    text = ['\x1b[38;5;209mfoobar', '\x1b[38;5;214mbaz\x1b[0m']  # List[str]
    assert len_without_ansi(text) == 9, 'Failed to determine length of color text'

    # Test tuple of strings

# Generated at 2022-06-11 22:56:16.264540
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:56:19.428142
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:56:28.707519
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # no-ansi
    text = 'foobar'
    assert len_without_ansi(text) == 6
    # bold
    text = '\x1b[1mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # fg red
    text = '\x1b[31mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # fg red and bold
    text = '\x1b[31;1mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # fg red, bg green
    text = '\x1b[31;42mfoobar\x1b[0m'
    assert len_without_ansi