

# Generated at 2022-06-11 22:50:39.623608
# Unit test for function len_without_ansi

# Generated at 2022-06-11 22:50:47.981879
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from ..flutils._compat import StringIO
    from flutils.txtutils import len_without_ansi
    from contextlib import redirect_stdout
    with redirect_stdout(StringIO()):
        text = '\x1b[38;5;209mfoobar\x1b[0m'
        len_without_ansi(text)
    assert len_without_ansi(text) == 6
# End function test_len_without_ansi



# Generated at 2022-06-11 22:50:51.060415
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi()"""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:54.448925
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.split()) == 6



# Generated at 2022-06-11 22:50:56.395133
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:06.591470
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi."""
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\\x1b[38;5;209mfoo\\x1b[0mbar'
    assert len_without_ansi(text) == 6
    text = [
        '\\x1b[38;5;209mfoo\\x1b[0m',
        '\\x1b[38;5;209mbar\\x1b[0m',
    ]
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:51:16.410603
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6
    text = '\x1b[38;5;209mfoobar\x1b[0mhello'
    out = len_without_ansi(text)
    assert out == 11
    text = '\x1b[38;5;209mfoobar\x1b[0mworld\x1b[0mhello'
    out = len_without_ansi(text)
    assert out == 11
    text = '\x1b[38;5;209mfoobar\x1b[0m\x1b[1mworld\x1b[0mhello'
    out = len_without_ansi(text)

# Generated at 2022-06-11 22:51:19.682034
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test 1
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    expected = 6
    actual = len_without_ansi(text)
    assert expected == actual
    return True



# Generated at 2022-06-11 22:51:26.372085
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[1mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;72mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[3mfoobar\x1b[0m') == 6
    assert len_without_ansi(('foo', '\x1b[0m', 'bar')) == 6



# Generated at 2022-06-11 22:51:28.490799
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:43.695981
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-11 22:52:48.514793
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:51.230828
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:54.501308
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:01.142956
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[38;5;209mbar\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoo', '\x1b[38;5;209mbar\x1b[0m')) == 6



# Generated at 2022-06-11 22:53:06.786102
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == 6



# Generated at 2022-06-11 22:53:09.224623
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:19.409420
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from unittest import TestCase
    from sys import version_info
    from os import path

    from flutils.txtutils import len_without_ansi

    class Test(TestCase):
        def test_len_without_ansi(self):
            if version_info.major < 3:
                self.assertEqual(len_without_ansi(b'foobar'), 0)
            text = '\x1b[38;5;209mfoobar\x1b[0m'
            self.assertEqual(len_without_ansi(text), 6)
            text = '\x1b[38;5;209mfoo\x1b[0mbar'
            self.assertEqual(len_without_ansi(text), 6)

# Generated at 2022-06-11 22:53:24.847691
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:53:30.904571
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test string
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(_text) == 6
    # Test tuple
    _tup = ('\x1b[38;5;209mfoobar\x1b[0m', 'baz', '\x1b[38;5;209m')
    assert len_without_ansi(_tup) == 9
# Test function
test_len_without_ansi()



# Generated at 2022-06-11 22:55:03.726278
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 14
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['foo', 'bar']) == 6

# Generated at 2022-06-11 22:55:07.548305
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:10.346422
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:16.900199
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    #
    Seq = List[str]
    text = ['\\x1b[38;5;209mfoobar\\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ['foobar']
    assert len_without_ansi(text) == 6
    text = ['\\x1b[38;5;209mfoo', 'bar\\x1b[0m']
    assert len_without_ansi(text) == 6
    assert len_without_ansi(cast(Seq, text)) == 6

# Generated at 2022-06-11 22:55:20.024897
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:21.629493
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:26.377669
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Tests :func:`flutils.txtutils.len_without_ansi`
    """
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:28.284916
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:31.453355
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:37.022880
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert 6 == len_without_ansi(text)
    text = 'This is text'
    assert 13 == len_without_ansi(text)

