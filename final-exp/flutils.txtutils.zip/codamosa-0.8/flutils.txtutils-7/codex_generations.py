

# Generated at 2022-06-11 22:48:46.807141
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[31mfoobar') == 3
    assert len_without_ansi('foo\x1b[3m\x1b[31mbar') == 6
    assert len_without_ansi('foo\x1b[3mbar\x1b[31m') == 7
    assert len_without_ansi('foo\x1b[3m\x1b[31mbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foo', '\x1b[3m\x1b[31mbar', 'baz']) == 9



# Generated at 2022-06-11 22:48:52.761156
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    texts = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(texts) == 6



# Generated at 2022-06-11 22:48:56.616263
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:49:04.367966
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    .. code-block:: python

        import pytest

        @pytest.mark.parametrize('seq,length', [
            (['foobar', '\x1b[1mfoobar', '\x1b[38;5;209mfoobar', 'foobar\x1b[0m'], 6),
            ('foobar\x1b[1mfoobar\x1b[38;5;209mfoobarfoobar\x1b[0m', 6),
        ])
        def test_len_without_ansi(seq, length):
            from flutils.txtutils import len_without_ansi
            assert len_without_ansi(seq) == length
    """
    pass  # pragma: nocover



# Generated at 2022-06-11 22:49:14.124362
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from sys import version_info
    from textwrap import dedent
    from typing import Tuple
    if version_info.major == 3 and version_info.minor >= 8:
        from contextlib import nullcontext  # pylint: disable=E0611
        expected: Tuple[int, ...] = (31, 6, 15, 15, 6)
        with nullcontext() as context_manager:
            assert len_without_ansi(context_manager) == 0
            assert len_without_ansi([]) == 0
    else:  # pragma: no cover
        expected = (32, 6, 16, 32, 7)

# Generated at 2022-06-11 22:49:23.776093
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest
    assert len_without_ansi('') == 0
    assert len_without_ansi(None) == 0
    assert len_without_ansi('abc') == 3
    assert len_without_ansi('abc def') == 7
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[38;5;59mbar\x1b[0m']) == 6
    with pytest.raises(TypeError):
        len_without_ansi(['abc', 123])
# /Unit test for function len_without_ansi



# Generated at 2022-06-11 22:49:26.840427
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:49:31.651610
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(['foo', 'bar', 'qux']) == 9
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foo', '\x1b[38;5;209m', 'bar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:49:33.984256
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-11 22:49:37.639047
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:42.899027
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(('foo', '\x1b[38;5;209mbar\x1b[0m', 'baz')) == 7



# Generated at 2022-06-11 22:51:48.367322
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(('foo', 'bar')) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foo\x1b[38;5;209mfoobar\x1b[0mbar') == 11
    assert len_without_ansi('foo\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mbar\x1b[0m') == 11
# Type hint for function len_without_ansi
len_without_ansi.__annotations__: dict = {}  # type: ignore[assignment] # noqa



# Generated at 2022-06-11 22:51:52.187332
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:54.477612
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:05.077461
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Test the len_without_ansi function
    """
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(['foo', '\x1b[38;5;209m', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', '\x1b[0m', 'bar']) == 6


# Generated at 2022-06-11 22:52:11.313073
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa: D103,W0613
    import doctest
    results = doctest.testmod(verbose=False)
    __tracebackhide__ = results[0] == 1
    if results[0]:
        raise results[0](results[1])
    elif results[1]:
        for test, error in results[1]:
            __tracebackhide__ = True
            if error.exception:
                raise error.exception(error)



# Generated at 2022-06-11 22:52:14.022365
# Unit test for function len_without_ansi
def test_len_without_ansi():
    return len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:52:18.507305
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['abc', text]) == 9
test_len_without_ansi()



# Generated at 2022-06-11 22:52:25.232223
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar', '\x1b[0m']) == 6
    with pytest.raises(ValueError):
        len_without_ansi(None)
    with pytest.raises(ValueError):
        len_without_ansi('\x1b[38;5;209mfoobar\x1b[')



# Generated at 2022-06-11 22:52:29.263183
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function ``len_without_ansi``."""

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:54:48.434922
# Unit test for function len_without_ansi
def test_len_without_ansi():
    len_without_ansi('Hello World!')
    len_without_ansi(['\x1b[1mHello World!\x1b[0m'])



# Generated at 2022-06-11 22:54:49.988925
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('abc') == 3
    assert len_without_ansi('x\x1b[33mabc\x1b[0mx') == 5



# Generated at 2022-06-11 22:54:57.869203
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi"""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ('\x1b[38;5;209m', 'foobar', '\x1b[0m')
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:06.227159
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Run unit tests for the flutils.txtutils module."""
    from hypothesis import given, settings
    from hypothesis.strategies import (
        characters,
        lists,
        sampled_from,
        text,
    )
    from string import ascii_lowercase
    from unittest import TestCase
    from unittest.mock import patch

    class TestLenWithoutAnsi(TestCase):
        """Unit test the flutils.txtutils.len_without_ansi function."""

        def setUp(self) -> None:
            """Set up the tests."""

# Generated at 2022-06-11 22:55:12.429959
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoo', '\x1b[0mbar']
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:55:19.654943
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # text without ansi
    assert len_without_ansi('foobar') == 6

    # text with ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    # list of strings with ansi
    seq = ['\x1b[38;5;209mfoo\x1b[0m', 'bars']
    assert len_without_ansi(seq) == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:55:21.374148
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:55:27.630370
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = ('\x1b[38;5;209mfoobar\x1b[0m'
            '\x1b[38;5;151mfoo\x1b[0mbar'
            '\x1b[38;5;200mfoobar\x1b[0m')
    assert len_without_ansi(text) == 9
    assert len_without_ansi('foobar') == 6



# Generated at 2022-06-11 22:55:30.533149
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:55:38.224163
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pprint import pformat
    from .datastructures import FrozenOrderedDict

    __tracebackhide__ = True

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    expected = 6
    out = len_without_ansi(text)
    assert out == expected
    #
    text = ['\x1b[38;5;209mfoo\x1b[0m', 'bar']
    expected = 6
    out = len_without_ansi(text)
    assert out == expected

