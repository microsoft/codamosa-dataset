

# Generated at 2022-06-11 22:47:55.274633
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    out == 6



# Generated at 2022-06-11 22:48:04.245559
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mf', 'oo', 'bar', '\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mf', ['o', 'o'], 'bar', '\x1b[0m']
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:15.148959
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;196mfoobar\x1b[0m',
        '\x1b[38;5;28mfoobar\x1b[0m']
    assert len_without_ansi(text) == 7
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 18
# end test_len_without_ansi


# noinspection PyMissingOrEmptyDocstring

# Generated at 2022-06-11 22:48:23.270284
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi"""
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m \t \x1b[38;5;209mbaz\x1b[0m') == 9

# Generated at 2022-06-11 22:48:29.745726
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert(len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')) == 6
    # Test a list of 3 strings
    seq = [
        '\x1b[38;5;9mfoobar',
        'foo\x1b[0m',
        '\x1b[38;5;29mbar'
    ]
    assert(len_without_ansi(seq)) == 6



# Generated at 2022-06-11 22:48:32.979915
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[1mfoobar\x1b[0m'
    if len_without_ansi(text) != 6:
        raise AssertionError(
            f'{text!r} should have 6 characters.'
        )

# Generated at 2022-06-11 22:48:38.042018
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text, text]) == 12
    assert len_without_ansi(text + text) == 12


########################
# Text Wrapping #
########################


# Generated at 2022-06-11 22:48:46.718282
# Unit test for function len_without_ansi

# Generated at 2022-06-11 22:48:56.412144
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # pylint: disable=bad-whitespace
    from flutils.txtutils import len_without_ansi
    from flutils.txtutils import AnsiTextWrapper
    import pytest

    atw = AnsiTextWrapper(width=10, max_lines=1, break_long_words=True)
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    with pytest.raises(ValueError, match=r"Cannot break line"):
        atw(text)
    assert len_without_ansi(text) == 6
    assert len_without_ansi(atw(text)) == 10
    text = ['\x1b[38;5;209mfoobar\x1b[0m', 'baz']

# Generated at 2022-06-11 22:48:57.865774
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

