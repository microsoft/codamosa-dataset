

# Generated at 2022-06-11 22:47:49.323955
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'  # Seven chars, but only 6 visible
    assert len_without_ansi(text) == 6
    text = 'foo\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = 'Python \x1b[38;5;208m3.8\x1b[0m'
    assert len_without_ansi(text) == 12
    text = 'foo\x1b[38;5;209mbar'  # ANSI code not terminated
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:47:51.797592
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:47:54.726916
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:01.427616
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(seq) == 6
    seq = ('\x1b[38;5;209mf', 'oobar\x1b[0m')
    assert len_without_ansi(seq) == 6
# end Unit test for function len_without_ansi



# Generated at 2022-06-11 22:48:05.677810
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:48:16.491992
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from collections.abc import Sequence
    from flutils.txtutils import len_without_ansi
    from pprint import pformat
    from typing import (
        Optional,
        Sequence,
        Union,
    )
    # ValueError if not str or Sequence[str]
    for bad_input in (1, 2.0, None):
        assert_raises(ValueError, len_without_ansi, bad_input)
    # Non-empty string
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    len_text = len_without_ansi(text)
    assert len_text == 6, pformat(len_text)
    # Empty string
    text = ''
    len_text = len_without_ansi(text)

# Generated at 2022-06-11 22:48:22.070421
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    return



# Generated at 2022-06-11 22:48:32.395087
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from unittest import TestCase
    t_txt = '\x1b[38;5;52m{}\x1b[0m'
    t = TestCase()
    t.assertEqual(len_without_ansi(t_txt.format('foobar')), 6)
    t.assertEqual(len_without_ansi(t_txt.format('foo') + 'bar'), 6)
    t.assertEqual(len_without_ansi(t_txt.format('foo') + '\x1b[0mbar'), 6)
    t.assertEqual(len_without_ansi([t_txt.format('foo')]), 3)
    t.assertEqual(len_without_ansi([t_txt.format('foo'), 'bar']), 6)

# Generated at 2022-06-11 22:48:36.372643
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Tests :func:`len_without_ansi <flutils.txtutils.len_without_ansi>`."""
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6


# Generated at 2022-06-11 22:48:39.783340
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:49:35.929681
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(seq) == 6
    seq = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(seq) == 6
    seq = 'foobar'
    assert len_without_ansi(seq) == 6
    seq = ['foo', 'bar']
    assert len_without_ansi(seq) == 6



# Generated at 2022-06-11 22:49:44.268117
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .testing import (
        print_test_single_result,
        print_test_start,
    )
    from . import testing
    from .txtutils import len_without_ansi
    from .testing import _method_log
    this_function_name = 'len_without_ansi'
    print_test_start(f'{this_function_name}()')
    _method_log.clear()
    # Test len_without_ansi() with no args
    _method_log.append(f'{this_function_name}()')
    expected_result = 6
    actual_result = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')

# Generated at 2022-06-11 22:49:47.731302
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-11 22:49:51.125487
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# <https://stackoverflow.com/q/57708826/355230>

# Generated at 2022-06-11 22:50:01.265798
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function :func:`flutils.txtutils.len_without_ansi`"""
    import pytest


# Generated at 2022-06-11 22:50:08.347210
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m']) == 0
    assert len_without_ansi(['\x1b[38;5;209m', 'baz']) == 3



# Generated at 2022-06-11 22:50:12.448783
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:50:15.014623
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    answer = 6
    assert len_without_ansi(text) == answer



# Generated at 2022-06-11 22:50:18.225652
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:26.264765
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # length of string
    assert len_without_ansi('foobar') == 6
    # length of list of strings
    assert len_without_ansi(['foobar', 'buzz']) == 11
    # length of string with ansi codes
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    # length of list of strings with ansi codes
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', 'buzz']) == 11



# Generated at 2022-06-11 22:51:24.922924
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.testing import assert_raises
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    eq_(len_without_ansi(text), 6)
    text = ['\x1b[38;5;209mf', 'oobar\x1b[0m']
    eq_(len_without_ansi(text), 6)
    eq_(len_without_ansi(['foo', '', '', 'bar']), 6)
    with assert_raises(TypeError):
        assert len_without_ansi(None)
    with assert_raises(TypeError):
        assert len_without_ansi(1337)



# Generated at 2022-06-11 22:51:26.177980
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .testdata import ANSI_TEXT
    assert len_without_ansi(ANSI_TEXT) == 100



# Generated at 2022-06-11 22:51:28.554071
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 16
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:35.016605
# Unit test for function len_without_ansi
def test_len_without_ansi():
    tests = (
        (0, ''),
        (6, '\x1b[38;5;209mfoobar\x1b[0m'),
        (6, '\x1b[38;5;209mfoobar\x1b[0m'),
        (6, ['\x1b[38;5;209mfoobar\x1b[0m']),
        (6, ('\x1b[38;5;209mfoobar\x1b[0m',)),
    )
    for ans, text in tests:
        assert len_without_ansi(text) == ans



# Generated at 2022-06-11 22:51:42.444010
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[1mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[1mfoo\x1b[0m', 'bar']) == 6
    assert len_without_ansi(['\x1b[1mfoo', 'bar\x1b[0m']) == 6


# Generated at 2022-06-11 22:51:48.142261
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import sys
    # noinspection PyUnresolvedReferences
    from flutils.txtutils_tests import (  # type: ignore[no-name-in-module]
        _AnsiTextWrapper,
        _AnsiTextWrapperTestCase,
    )

    class _TestCase(_AnsiTextWrapperTestCase):
        text_wrapper_cls = _AnsiTextWrapper

        def test_input_types(self):
            """Ensure that the given input types are supported."""
            # Define the input types
            input_types: List[Optional[type(None)]] = [
                None,
                list(),
                tuple(),
                '',
                list(['']),
                tuple(['']),
            ]
            if sys.version_info >= (3, 8, 0):
                input_types += (None,)

# Generated at 2022-06-11 22:51:53.521583
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['a', text, 'b']) == 8
    assert len_without_ansi(['a', text]) == 7
test_len_without_ansi()

# Generated at 2022-06-11 22:51:59.953385
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:52:06.887564
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest
    from flutils.txtutils import len_without_ansi
    class TestLenWithoutAnsi:
        def test_01(self):
            text = '\x1b[38;5;209mfoobar\x1b[0m'
            assert len_without_ansi(text) == 6
        def test_02(self):
            text = '\x1b[38;5;209mfoobar\x1b[0m'
            assert len_without_ansi([text]) == 6
        def test_03(self):
            text = '\x1b[38;5;209mfoobar\x1b[0m'
            assert len_without_ansi([text, 'baz']) == 9
    tester = TestLenWithoutAnsi()
    tester.test_01

# Generated at 2022-06-11 22:52:09.725368
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:26.023529
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert isinstance(out, int)
    assert out == 6

# Generated at 2022-06-11 22:53:28.070366
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:35.489977
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    ans = 6
    assert len_without_ansi(text) == ans
test_len_without_ansi()

# class AnsiTextWrapper(TextWrapper):
#     """A :obj:`TextWrapper <textwrap.TextWrapper>` subclass which wraps
#     text without counting ANSI codes.

#     .. versionadded:: 0.6

#     .. note::

#         This class is not intended to be used directly, but may be
#         used to add ANSI support to the :obj:`TextWrapper
#         <textwrap.TextWrapper>` class or other
#         :obj:`TextWrapper <textwrap.TextWrapper>` subclasses.

#         The following methods

# Generated at 2022-06-11 22:53:47.030784
# Unit test for function len_without_ansi

# Generated at 2022-06-11 22:53:54.644592
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = [
        '\x1b[38;5;123m\x1b[48;5;9m\x1b[38;5;0m',
        'foobar',
        '\x1b[38;5;123m\x1b[48;5;9m',
        '\x1b[0m',
    ]
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:57.227944
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:54:01.558569
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m foobar \x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']) == 9



# Generated at 2022-06-11 22:54:02.701151
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:54:07.202552
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi."""
    tt = len_without_ansi
    seq = '\x1b[31mfoobar\x1b[39m'
    assert tt(seq) == 6
    seq = '\x1b[31mfoo\x1b[39m'
    assert tt(seq) == 3
    seq = '\x1b[31mfoo\x1b[39mbar'
    assert tt(seq) == 6
    seq = '\x1b[31mfoo\x1b[39m\x1b[31mbar\x1b[39m'
    assert tt(seq) == 6
    seq = '\x1b[31mfoo\x1b[39mbar\x1b[31m'

# Generated at 2022-06-11 22:54:14.006135
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[38;5;208mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[38;5;208mbar\x1b[0m']) == 6
test_len_without_ansi()
del test_len_without_ansi



# Generated at 2022-06-11 22:55:42.648392
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from six import u
    msg = u('\x1b[38;5;209mfoobar\x1b[0m')
    assert len_without_ansi(msg) == 6
    msg = u('\x1b[38;5;209mfoo\x1b[0mbar\x1b[38;5;209mfoo\x1b[0mbar')
    assert len_without_ansi(msg) == 12
    msg = u('\x1b[38;5;209mfoo')
    assert len_without_ansi(msg) == 3
    msg = u('\x1b[38;5;209m')
    assert len_without_ansi(msg) == 0
    msg = u('\x1b[38;5;209mfoobar\x1b[0m')

# Generated at 2022-06-11 22:55:54.004106
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from textwrap import fill
    from flutils.txtutils import strip_ansi_codes

# Generated at 2022-06-11 22:56:04.515365
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    text = '\x1b[38;5;209mfoo\x1b[0mbar\x1b[38;5;209m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(('foo', 'bar')) == 6
    assert len_without_ansi(['foo']) == 3
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(['foo', 'bar', 'baz', 'buzz']) == 10
    # Unit test for function len_without_ansi with a split kwarg


# Generated at 2022-06-11 22:56:14.040162
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # pylint: disable=missing-function-docstring
    text = b'\\x1b[31m\\x1b[42m\\x1b[31mfoo\\x1b[0m\\x1b[0m'
    assert len_without_ansi(text) == 3
    text = '\\x1b[31m\\x1b[42m\\x1b[31mfoo\\x1b[0m\\x1b[0m'
    assert len_without_ansi(text) == 3
    text = ['bar', '\\x1b[31m\\x1b[42m\\x1b[31mbaz\\x1b[0m\\x1b[0m']
    assert len_without_ansi(text) == 7

# Generated at 2022-06-11 22:56:19.180833
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa: D102,D103,D105
    from flutils.txtutils import len_without_ansi
    text = ('\x1b[38;5;209mfoobar'
            '\x1b[0m')
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:56:24.272755
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('foo') == 3
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi([]) == 0
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:56:27.606858
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(_text) == 6

