

# Generated at 2022-06-11 22:47:24.266679
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:47:26.966335
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:47:38.386528
# Unit test for function len_without_ansi
def test_len_without_ansi():
  """Test for the len_without_ansi function"""
  import random

  text = '\x1b[38;5;{}mfoobar\x1b[0m'.format(random.randint(0, 255))
  assert len_without_ansi(text) == 6
  # https://stackoverflow.com/a/27421745
  assert len_without_ansi(['\x1b[38;5;{}m'.format(random.randint(0, 255)), 'foobar'] + ['\x1b[0m'] * 2) == 6
  assert len_without_ansi('foo\x1b[38;5;{}mbar'.format(random.randint(0, 255))) == 7

# Generated at 2022-06-11 22:47:50.462681
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.split()) == 6
    text = (
        '\x1b[38;5;199m\x1b[48;5;15m%s\x1b[0m' % text
        + '\x1b[38;5;209m%s\x1b[0m' % text
    )
    assert len_without_ansi(text) == 12
    assert len_without_ansi(text.split()) == 12
test_len_without_ansi()  # pragma: no cover



# Generated at 2022-06-11 22:48:01.470302
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from io import StringIO
    from flutils.txtutils import len_without_ansi
    from flutils.tester import assert_function

    tests = [
        {
            'in': {
                'seq': '\x1b[38;5;209mfoobar\x1b[0m',
            },
            'out': 6,
        },
        {
            'in': {},
            'out': 0,
        },
    ]

    assert_function(
        function=len_without_ansi,
        tests=tests,
        stdout=StringIO()
    )
    assert len_without_ansi() == 0  # type: ignore
    assert len_without_ansi([]) == 0  # type: ignore


# Generated at 2022-06-11 22:48:13.405308
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi."""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m,\x1b[38;5;209mfoobar\x1b[0m,' \
           '\x1b[38;5;209mfoobar\x1b[0m,\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 24

# Generated at 2022-06-11 22:48:18.495321
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    seq = [
        '\x1b[38;5;209mfoo',
        'bar\x1b[0m',
        '\x1b[38;5;209mhell',
        'o, world\x1b[0m!!!']
    assert len_without_ansi(seq) == 18
# /Unit test for function len_without_ansi



# Generated at 2022-06-11 22:48:22.072487
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:25.165849
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:31.935265
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'bar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:49:41.450518
# Unit test for function len_without_ansi
def test_len_without_ansi():
    tests = (
        (
            '\x1b[38;5;209mfoobar\x1b[0m',
            6
        ),
        (
            [
                '\x1b[38;5;209mfoobar\x1b[0m',
                '\x1b[38;5;209mbaz',
                '\x1b[0mblah',
            ],
            11
        ),
    )
    for test, length in tests:
        assert len_without_ansi(test) == length



# Generated at 2022-06-11 22:49:43.600373
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:49:45.679026
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
# --- End: def



# Generated at 2022-06-11 22:49:51.985320
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Mix of strings
    assert len_without_ansi(['foo', 'bar', 'baz']) == 9
    # Strings
    assert len_without_ansi('foobarbaz') == 9
    # List of strings
    assert len_without_ansi(['foo', '\x1b[38;5;10mbar', '\x1b[0mbaz']) == 5

# TODO: Move to flutils.decorators

# Generated at 2022-06-11 22:50:03.433236
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('hell\x1b[38;5;209mo\x1b[0m there') == 8
    assert len_without_ansi(('hell\x1b[38;5;209mo\x1b[0m there',
                             'hell\x1b[38;5;209mo\x1b[0m there')) == 16
    assert len_without_ansi(('hell\x1b[38;5;209mo\x1b[0m',
                             'there')) == 8
    assert len_without_ansi(('hell\x1b[38;5;209mo\x1b[0m',
                             '\x1b[38;5;209mthere\x1b[0m')) == 8



# Generated at 2022-06-11 22:50:07.103297
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:11.359509
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:50:18.586449
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function `flutils.txtutils.len_without_ansi`."""
    from flutils.txtutils import len_without_ansi
    import pytest

    with pytest.raises(TypeError):
        len_without_ansi(None)
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foo']) == 3
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['foo', 'bar']) == 6

# Generated at 2022-06-11 22:50:23.097300
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-11 22:50:30.365951
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoo\x1b[0m', 'bar']
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:48.485508
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from textwrap import dedent
    from flutils.randomutils import gen_random_str
    from flutils.txtutils import len_without_ansi

    # Setup
    chars = gen_random_str(100).split()
    text: str = ' '.join(chars)

    # Execute
    res1 = len_without_ansi(chars)
    res2 = len_without_ansi(text)
    res3 = len_without_ansi(dedent(text).split('\n'))

    # Verify
    assert res1 == len(''.join(chars))
    assert res1 == res2
    assert res2 == res3

# Generated at 2022-06-11 22:50:52.273865
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


_ANSITextWrapper: Optional[type] = None  # type: ignore[assignment]



# Generated at 2022-06-11 22:50:58.863742
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa: D103
    text = '\x1b[38;5;209mTEST\x1b[39m'
    assert len(text) == 12
    assert len_without_ansi(text) == 4
    assert len_without_ansi('a') == 1
    assert len_without_ansi(['a']) == 1
    assert len_without_ansi(('a')) == 1
    assert len_without_ansi(('a b')) == 1
    assert len_without_ansi(['a b']) == 1
    assert len_without_ansi(('a', 'b')) == 1
    assert len_without_ansi(('a', 1)) == 1


# noinspection PyAbstractClass

# Generated at 2022-06-11 22:51:07.141297
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from collections.abc import Sequence
    from flutils.unittest import UnitTester

    ut = UnitTester(__file__, get_seq()).run

    class SequenceData(Sequence):
        __slots__ = ['data']

        def __init__(self, data: str) -> None:
            self.data = data

        def __getitem__(self, index: int) -> str:
            return self.data[index]

        def __len__(self) -> int:
            return 1

    ut(len_without_ansi, '\x1b[38;5;209mfoobar\x1b[0m', 6)
    ut(len_without_ansi, SequenceData('\x1b[38;5;209mfoobar\x1b[0m'), 6)

# Generated at 2022-06-11 22:51:13.586503
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mbaz\x1b[0m']
    assert len_without_ansi(text) == 10



# Generated at 2022-06-11 22:51:16.220999
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:20.218806
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m ') == 7
    assert len_without_ansi('foo\x1b[38;5;209m foo\x1b[0mbar') == 8
    assert len_without_ansi(['foo', '\x1b[38;5;209m', 'foo',
                             '\x1b[0m', 'bar']) == 8



# Generated at 2022-06-11 22:51:26.732730
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa: D103
    from flutils.txtutils import len_without_ansi

    assert len_without_ansi('\x1b[1ffoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[1ffoo', 'bar\x1b[0m']) == 6
    assert len_without_ansi(()) == 0
    assert len_without_ansi([]) == 0


# Custom TextWrapper class to handle ANSI code length

# Generated at 2022-06-11 22:51:35.121093
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text1 = 'foo\x1b[30mbar\x1b[0m'
    text2 = ['foo\x1b[30m', 'bar\x1b[0m']
    assert len_without_ansi(text1) == 3
    assert len_without_ansi(text2) == 3
    assert len_without_ansi(text1 + text1) == 6
    assert len_without_ansi(text1 + text2) == 6
    assert len_without_ansi(text2 + text1) == 6
    assert len_without_ansi(text2 + text2) == 6

# Generated at 2022-06-11 22:51:43.622443
# Unit test for function len_without_ansi
def test_len_without_ansi():
    tests = [
        (
            'foo',
            3
        ),
        (
            ['foo', 'bar', 'baz'],
            3
        ),
        (
            '\\x1b[38;5;209mfoo',
            3
        ),
        (
            ['\\x1b[38;5;209mfoo', 'bar'],
            3
        ),
    ]
    for seq, expected in tests:
        assert len_without_ansi(seq) == expected



# Generated at 2022-06-11 22:52:07.036329
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test for string
    ansi_text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(ansi_text) == 6
    # Test for list/tuple
    ansi_text = ('\x1b[38;5;209m', 'foobar', '\x1b[0m')
    assert len_without_ansi(ansi_text) == 6
    ansi_text = ('\x1b[38;5;209mfoobar\x1b[0m',)
    assert len_without_ansi(ansi_text) == 6



# Generated at 2022-06-11 22:52:18.638982
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from io import StringIO
    from flutils.txtutils import len_without_ansi
    from flutils.miscutils import ShortRepr
    from flutils._compatibility import Literal


# Generated at 2022-06-11 22:52:23.640349
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar', '\x1b[0m']
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:28.287287
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-11 22:52:31.090847
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-11 22:52:39.461433
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    seq = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(seq) == 6
    seq = ['\x1b[38;5;209mfoo', 'bar', '\x1b[0m']
    assert len_without_ansi(seq) == 6
# end unit test



# Generated at 2022-06-11 22:52:47.617187
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from typing import Callable, List, Optional, TypeVar
    T = TypeVar('T', bound=str)
    supports_multiple: Optional[bool] = None
    text: str = '\x1b[38;5;209mfoobar\x1b[0m'
    try:
        len_without_ansi(text * 2)
        supports_multiple = True
    except TypeError:
        supports_multiple = False
    def _test_mul(input_: T,
                  output: int,
                  supports_multiple: Optional[bool] = supports_multiple) -> None:
        print('\x1b[38;5;110m%s\x1b[0m' % (input_ * 3))
        print(len_without_ansi(input_ * 3))

# Generated at 2022-06-11 22:52:52.221647
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test for 'len_without_ansi' function."""
    from flutils.txtutils import len_without_ansi

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:57.744387
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m\x1b[31m!'
    assert len_without_ansi(text) == 7


# Generated at 2022-06-11 22:53:00.866130
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function `len_without_ansi`."""
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:53:11.259031
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('abc') == 3
    assert len_without_ansi('éé') == 2
    assert len_without_ansi('\\x1b[0;36mabc\\x1b[0m') == 3



# Generated at 2022-06-11 22:53:20.442794
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('foobar\x1b[38;5;209mbaz\x1b[0m') == 10
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('', ) == 0
    assert len_without_ansi('\x1b[38;5;209m', ) == 0
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m', ) == 3
    assert len_without_ansi('foobar\x1b[38;5;209m', ) == 6

# Generated at 2022-06-11 22:53:25.272044
# Unit test for function len_without_ansi
def test_len_without_ansi():
    _text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(_text) == 6
# /Unit test for function len_without_ansi


# Generated at 2022-06-11 22:53:27.276442
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(['Test 1', 'Test 2']) == 8
    assert len_without_ansi('Test') == 4


# Generated at 2022-06-11 22:53:30.865560
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:53:37.007488
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(['foo\x1b[38;5;209m', 'bar']) == 6
    assert len_without_ansi([]) == 0
    assert len_without_ansi(('', '')) == 0
    assert len_without_ansi((' ', ' ')) == 2
    assert len_without_ansi(('foo', 'bar')) == 6
    assert len_without_ansi(('foo\n', 'bar')) == 6
    assert len_without_ansi(('foo', '', '')) == 3
    assert len_without

# Generated at 2022-06-11 22:53:47.937035
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi([]) == 0
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m') == 3
    assert len_without_ansi('\x1b[38;5;209mfoobar') == 6
    assert len_without_ansi('foobar\x1b[0m') == 6

# Generated at 2022-06-11 22:53:53.897743
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:53:59.417476
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    lines = (
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[1m\x1b[38;5;145mbaz\x1b[0m',
    )
    assert len_without_ansi(lines) == 9



# Generated at 2022-06-11 22:54:00.705358
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("foobar") == 6



# Generated at 2022-06-11 22:54:12.639769
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
# End unit test for function len_without_ansi



# Generated at 2022-06-11 22:54:20.696394
# Unit test for function len_without_ansi
def test_len_without_ansi():
    out = len_without_ansi('\x1b[1;34mbold blue\x1b[0m')
    assert out == 11
    out = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert out == 6
    out = len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m'])
    assert out == 6
# /Unit test for function len_without_ansi



# Generated at 2022-06-11 22:54:21.998849
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:54:33.551372
# Unit test for function len_without_ansi

# Generated at 2022-06-11 22:54:41.102512
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 18
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:54:48.497639
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['a', '\x1b[38;5;209mfoobar\x1b[0m', 'b']) == 8
    assert len_without_ansi(('a', '\x1b[38;5;209mfoobar\x1b[0m', 'b')) == 8
    assert len_without_ansi(('a', '\x1b[38;5;209mfoobar\x1b[0m', 'b')) == 8



# Generated at 2022-06-11 22:54:53.273943
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # The function accepts a single string
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    rv = len_without_ansi(text)
    assert rv == 6
    # It also accepts a list of strings
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mfoobar\x1b[0m',
    ]
    rv = len_without_ansi(text)
    assert rv == 12
    # It also counts non-ansi text in the list

# Generated at 2022-06-11 22:54:57.214137
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = 'hello'
    assert len_without_ansi(text) == 5
    text = '\x1b[38;5;211mfoobar\x1b[m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:05.900717
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi."""
    from flutils.txtutils import len_without_ansi
    text = 'foo\x1bbaz\x1b[0m'
    out = len_without_ansi(text)
    if out != 4:
        raise AssertionError('len_without_ansi() did not return 4.')
    out = len_without_ansi([text, text])
    if out != 8:
        raise AssertionError('len_without_ansi() did not return 8.')
    lst = [text] * 3
    out = len_without_ansi(lst)
    if out != 12:
        raise AssertionError('len_without_ansi() did not return 12.')

# Generated at 2022-06-11 22:55:12.652242
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for :func:`~flutils.txtutils.len_without_ansi`."""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;38;25mfoobar\x1b[0m'
    assert len_without_ansi(text) == 12

# Generated at 2022-06-11 22:55:29.133758
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = '\x1b[38;5;209mfoobar\x1b[0m\n'
    assert len_without_ansi(seq) == 6
    seq = ['\x1b[38;5;209mfoobar', '\x1b[0m\n']
    assert len_without_ansi(seq) == 6
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(seq) == 6
test_len_without_ansi()


# Generated at 2022-06-11 22:55:31.437197
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:55:42.083413
# Unit test for function len_without_ansi

# Generated at 2022-06-11 22:55:53.597496
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function :func:`len_without_ansi` """
    from string import ascii_letters
    from random import choice
    from . import txtlen

    for _ in range(1000):
        text = ''.join(choice(ascii_letters) for _ in range(20))
        assert txtlen(text) == len_without_ansi(text)
        idx = 10
        assert txtlen(text[:idx]) == len_without_ansi(text[:idx])
        assert txtlen(text[idx:]) == len_without_ansi(text[idx:])

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert txtlen(text) == 6

# Generated at 2022-06-11 22:55:56.782126
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:56:04.607245
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;9mfoobar\x1b[0m'
    ]
    for val in text:
        assert len_without_ansi(val) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = 'foobar'
    assert len_without_ansi(text) == 6
# end function test_len_without_ansi



# Generated at 2022-06-11 22:56:07.781504
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:56:11.925145
# Unit test for function len_without_ansi
def test_len_without_ansi():  # pragma: no cover
    text = ('\x1b[38;5;209mfoobar\x1b[0m', 'foobar')
    for s in text:
        result = len_without_ansi(s)
        assert result == 6



# Generated at 2022-06-11 22:56:15.052398
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:56:18.186108
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi(text)
    6

