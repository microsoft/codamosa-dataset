

# Generated at 2022-06-11 22:48:06.099429
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m',
                             '\x1b[38;5;209mbar\x1b[0m']) == 6



# Generated at 2022-06-11 22:48:11.067313
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function ``len_without_ansi``."""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:48:14.143738
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[1mfoo']) == 9



# Generated at 2022-06-11 22:48:25.852338
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from io import StringIO
    from pytest import raises
    from sys import stdout
    from flutils.txtutils import len_without_ansi

    def _check_fails_with(text: str, num: int):
        with raises(AssertionError):
            assert len_without_ansi(text) == num

    _check_fails_with('foo', 0)
    _check_fails_with('foo', 1)
    _check_fails_with('foo', 2)
    _check_fails_with('foo', 3)
    _check_fails_with('foo', 4)
    _check_fails_with('foo', 5)
    _check_fails_with('foo', 6)
    assert len_without_ansi('foo') == 3
    _check_fails_with

# Generated at 2022-06-11 22:48:30.458944
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:34.715911
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6

# Generated at 2022-06-11 22:48:42.907821
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from copy import copy
    def assertEq(seq, expect):
        got = len_without_ansi(seq)
        assert got == expect, f"\nGot: {got}\nXpect: {expect}"
    assertEq('', 0)
    assertEq('foo', 3)
    assertEq('bar', 3)
    assertEq('\x1b[38;5;209mfoobar\x1b[0m', 6)
    assertEq('foo\x1b[38;5;209mbar\x1b[0m', 6)
    assertEq('\x1b[38;5;209mfoobar', 6)
    assertEq('foobar\x1b[0m', 6)

# Generated at 2022-06-11 22:48:45.590071
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    out = 6
    assert len_without_ansi(seq) == out



# Generated at 2022-06-11 22:48:47.412179
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    return



# Generated at 2022-06-11 22:48:50.670577
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-11 22:50:57.050749
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == 6


# Generated at 2022-06-11 22:51:06.765077
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    text += '\x1b[38;5;220m is a baz\x1b[0m'
    assert len_without_ansi(text) == 11
    text = ['\x1b[38;5;209mf', 'ooba', 'r\x1b[0m']
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:51:12.233304
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_list = ['\x1b[38;5;209mfoo\x1b[0m', ['\x1b[38;5;209mfoo', '\x1b[0mbar']]
    for i in test_list:
        assert len_without_ansi(i) == 6



# Generated at 2022-06-11 22:51:14.882996
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Unit test for ``len_without_ansi``.
    """
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:17.176774
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:20.245241
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi"""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:26.553520
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        'baz',
        '\x1b[38;5;209mqux\x1b[0m',
    ]
    assert len_without_ansi(text) == 9


# Generated at 2022-06-11 22:51:28.684448
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:51:38.852731
# Unit test for function len_without_ansi
def test_len_without_ansi():
    def _test_case(seq, length):
        assert len_without_ansi(seq) == length

# Generated at 2022-06-11 22:51:41.782504
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:28.603084
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:35.201555
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import unittest

    class LenWithoutAnsiTestCase(unittest.TestCase):

        def setUp(self):
            self.text_1 = 'foobar'
            self.text_2 = '\x1b[38;5;209mfoobar\x1b[0m'
            self.text_3 = ['\x1b[48;5;209m', 'foobar', '\x1b[0m']

        def test_str(self):
            self.assertEqual(len_without_ansi(self.text_1), 6)

        def test_str_2(self):
            self.assertEqual(len_without_ansi(self.text_2), 6)


# Generated at 2022-06-11 22:52:37.745065
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:52:45.297218
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Basic
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    # Basic list
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    # Mixed list
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', 'hello', 'world']) == 8



# Generated at 2022-06-11 22:52:52.942059
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(list(text)) == 6
    assert len_without_ansi(('f', 'o', 'o')) == 3
    assert len_without_ansi('foo') == 3
    assert len_without_ansi(['foo']) == 3
test_len_without_ansi()



# Generated at 2022-06-11 22:53:01.872047
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Simple strings
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('foo\\nbar') == 6
    assert len_without_ansi('foo\x1bbaz') == 6
    assert len_without_ansi('foo\\bbaz') == 6
    assert len_without_ansi('foo\x1b[38;5;209mbaz\x1b[0m') == 6
    assert len_without_ansi('foo\x1b[38;5;209m\x1b[1mbaz\x1b[0m\x1b[22m') == 6
    # Lists / tuples
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(('foo', 'bar')) == 6
   

# Generated at 2022-06-11 22:53:13.657822
# Unit test for function len_without_ansi
def test_len_without_ansi():
    tests = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209mbar\x1b[0m'],
        ['\x1b[38;5;209mfoo', 'bar\x1b[0m'],
        [f'\x1b[38;5;209m{c}\x1b[0m' for c in 'foobar'],
        [f'\x1b[38;5;209m{c}' for c in 'foobar'],
    ]
    for test in tests:
        assert len_without_ansi(test) == 6
    # end for
# end test_len_without

# Generated at 2022-06-11 22:53:14.829428
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 23
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:17.465518
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:53:19.897804
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = ('\x1b[38;5;209mfoobar\x1b[0m',)
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:54:12.150835
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-11 22:54:17.825460
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text, text]) == 12



# Generated at 2022-06-11 22:54:21.445304
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:54:24.800443
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


_wrapper: Optional[TextWrapper] = None


# Generated at 2022-06-11 22:54:31.480380
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 6


# noinspection PyPep8Naming

# Generated at 2022-06-11 22:54:34.961117
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
test_len_without_ansi()
del test_len_without_ansi


# noinspection PyTypeChecker,PyUnresolvedReferences

# Generated at 2022-06-11 22:54:39.053906
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi((text,)) == 6
    assert len_without_ansi([text, text]) == 12
    assert len_without_ansi((text, text, text)) == 18



# Generated at 2022-06-11 22:54:42.594707
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi(['', '']) == 0
    assert len_without_ansi('abc') == 3
    assert len_without_ansi(['abc', 'def']) == 6



# Generated at 2022-06-11 22:54:44.415940
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:54:49.809249
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[31mred',
        '\x1b[39;49mblack',
    ]
    assert len_without_ansi(text) == 10



# Generated at 2022-06-11 22:55:39.212104
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:41.690476
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:47.126283
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = 'foobar'
    length = len_without_ansi(text)
    assert length == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    length = len_without_ansi(text)
    assert length == 6


# Generated at 2022-06-11 22:55:53.726788
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = 'foobar'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ['foobar']
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:57.897907
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi."""
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:56:04.256712
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pytest import raises
    from flutils.txtutils import len_without_ansi

    with raises(TypeError):
        len_without_ansi(5)  # type: ignore[arg-type]
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:56:07.479550
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:56:11.398895
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # type: () -> None
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-11 22:56:14.408998
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-11 22:56:25.962761
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit tests for function len_without_ansi"""
    from string import ascii_letters
    from unittest.mock import MagicMock
    from .contextmanagers import preserve_stdout

    for length in range(1, 100):
        for text in (ascii_letters[:length], ascii_letters[-length:]):
            assert len(text) == length
            assert len_without_ansi(text) == length
        for text in (ascii_letters[:length], ascii_letters[-length:]):
            text = f'\x1b[38;5;209m{text}\x1b[0m'
            assert len(text) == length + 2   # The two ansi codes
            assert len_without_ansi(text) == length
            assert len_without_ans