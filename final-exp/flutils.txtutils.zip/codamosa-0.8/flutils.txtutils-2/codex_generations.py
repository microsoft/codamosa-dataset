

# Generated at 2022-06-11 22:48:19.040599
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi(' ') == 1
    assert len_without_ansi('123') == 3
    assert len_without_ansi([' ']) == 1
    assert len_without_ansi(['123']) == 3
    assert len_without_ansi([' ']) == 1
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    assert len_without_ansi([]) == 0
    assert len_without_ansi(['  ']) == 0
    assert len_without_ansi(['\\x1b[38;5;209mfoobar\\x1b[0m']) == 6

# Generated at 2022-06-11 22:48:26.233632
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Function should pass
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    # Function should pass
    text = (
        '\\x1b[38;5;209mfoo',
        'bar\\x1b[0m'
    )
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:48:28.909430
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:48:31.283974
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from nose.tools import eq_
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6

# Generated at 2022-06-11 22:48:40.472234
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Type check for checking that it ignores ANSI codes
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # Type check for checking that it can take a list of strings
    text = ['\x1b[38;5;209mfoo', 'bar\x1b[0m']
    assert len_without_ansi(text) == 6
    # Type check for checking that it counts all the characters in a string
    text = '\x1b[38;5;209mf\x1b[0moobar'
    assert len_without_ansi(text) == 6
    # Type check for checking that it counts all the characters in a list

# Generated at 2022-06-11 22:48:43.747880
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .txtutils import len_without_ansi

    for text, exp in _EXAMPLES:
        out = len_without_ansi(text)
        assert out == exp, out



# Generated at 2022-06-11 22:48:48.275842
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(['abc',
                             '\x1b[38;5;209mfoobar',
                             'baz',
                             '\x1b[0m',
                             'qux']) == 12
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0mqux') == 9



# Generated at 2022-06-11 22:48:53.236347
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest  # type: ignore[import]

    pytest.raises(TypeError, len_without_ansi, None)
    assert len_without_ansi('\x1b[38;5;209mHello\x1b[0m') == 5


# TODO: Implement class "AnsiTextWrapper"

# Generated at 2022-06-11 22:48:56.810462
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text, text]) == 12
    assert len_without_ansi([text, text, text]) == 18



# Generated at 2022-06-11 22:49:02.040683
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi(['\x1b[38;5;209m', text, '\x1b[0m']) == 6



# Generated at 2022-06-11 22:49:43.935013
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209m\x1b[1mfoo\x1b[0m\x1b[22mbar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:49:48.797805
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:49:51.043193
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:49:53.356361
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:04.962612
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test :py:func:`len_without_ansi`.
    """
    assert len_without_ansi('') == 0
    assert len_without_ansi('a') == 1
    assert len_without_ansi('ab') == 2
    assert len_without_ansi('abc') == 3
    assert len_without_ansi('a b c') == 5
    assert len_without_ansi(['a', 'b', 'c']) == 3
    assert len_without_ansi(('a', 'b', 'c')) == 3
    assert len_without_ansi(('a', 'b', '', 'c')) == 3
    assert len_without_ansi('\x1b[38;5;209ma\x1b[0mb\x1b[38;5;209m')

# Generated at 2022-06-11 22:50:09.756648
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar') == len('foobar')
    assert len_without_ansi(['\x1b[38;5;209mfoobar']) == len('foobar')



# Generated at 2022-06-11 22:50:15.568578
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from test import TestCase
    from flutils.txtutils import len_without_ansi

    class Test_len_without_ansi(TestCase):
        def test(self):
            text = '\\x1b[38;5;209mfoobar\\x1b[0m'
            self.assertEqual(len_without_ansi(text), 6)

    test = Test_len_without_ansi()
    test.test()
# /Unit test for function len_without_ansi



# Generated at 2022-06-11 22:50:19.389733
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text_with_codes = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text_with_codes) == 6



# Generated at 2022-06-11 22:50:23.095246
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:50:29.264237
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


##############################################################################
# CLASSES
##############################################################################


# Generated at 2022-06-11 22:51:04.194972
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# #############################################################################
# The following is derivative of the Python stdlib txtutils module (see
# https://docs.python.org/3/library/textwrap.html) with minor modifications to
# account for ANSI codes.
# #############################################################################


# Generated at 2022-06-11 22:51:10.243150
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['a', '\x1b[38;5;209m', 'b', '\x1b[0m', 'c']) == 3



# Generated at 2022-06-11 22:51:13.363026
# Unit test for function len_without_ansi
def test_len_without_ansi():     # pragma: no cover
    from flutils.txtutils import len_without_ansi
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:17.435250
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209mbar\x1b[0m']
    assert len_without_ansi(text) == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:51:20.172438
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    length = len_without_ansi(text)
    assert length == 6



# Generated at 2022-06-11 22:51:24.133420
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:26.623330
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for the module-level len_without_ansi function."""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:51:30.352585
# Unit test for function len_without_ansi
def test_len_without_ansi():
    r"""Test for function len_without_ansi."""
    import doctest
    from flutils.txtutils import len_without_ansi
    assert not doctest.testmod(
        len_without_ansi,
        optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE
    ).failed



# Generated at 2022-06-11 22:51:33.132839
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    res = len_without_ansi(text)
    assert res == 6



# Generated at 2022-06-11 22:51:35.712489
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(list(text)) == 6



# Generated at 2022-06-11 22:52:16.285203
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m'
    assert len_without_ansi(text) == 3


#: An alias for :obj:`AnsiTextWrapper`
Wrapper = AnsiTextWrapper  # type: ignore[assignment,misc]



# Generated at 2022-06-11 22:52:22.125660
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa: D103
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-11 22:52:32.046298
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi([text]) == 6
    text = '\x1b[38;5;209m{}\x1b[0m'.format('foo' * 3)
    assert len_without_ansi([text]) == 9



# Generated at 2022-06-11 22:52:36.207804
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text, text]) == 12



# Generated at 2022-06-11 22:52:39.673047
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:42.683709
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:52:48.788598
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi = '\x1b[38;5;208m'
    text = 'foobar'
    template = '{}'
    assert len_without_ansi(ansi + text) == len(text)
    assert len_without_ansi([ansi + text]) == len(text)
    assert len_without_ansi([template.format(ansi + text)]) == len(text)
    assert len_without_ansi((ansi + text,)) == len(text)
    assert len_without_ansi((template.format(ansi + text),)) == len(text)
    assert len_without_ansi((template.format(ansi + text), ansi + text)) == (
        2 * len(text)
    )



# Generated at 2022-06-11 22:52:54.109158
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    lst = ['\x1b[38;5;209mfoo\x1b[0m', 'bar']
    assert len_without_ansi(lst) == 3



# Generated at 2022-06-11 22:53:02.813916
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.split()) == 6
    assert len_without_ansi(text.split() * 2) == 12
    assert len_without_ansi(text.split() + text.split()) == 12
    assert len_without_ansi(text.split() + ['bar', 'baz']) == 9
    assert len_without_ansi(text.split() + ['bar', 'baz']) == 9
    assert len_without_ansi(text.split() * 2 + ['bar', 'baz']) == 15
test_len_without_ansi()



# Generated at 2022-06-11 22:53:10.598098
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text0 = 'foo'
    text1 = '\x1b[38;5;209mbar\x1b[0m'
    text2 = 'foobar'
    assert len_without_ansi([text0, text1, text2]) == 9



# Generated at 2022-06-11 22:53:52.843431
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = [
        'foo',
        '\x1b[38;5;209mbar',
        '\x1b[0m',
        'foo',
    ]
    assert len_without_ansi(text) == 9
    text = [
        'foo',
        '\x1b[38;5;209mbar',
        '\x1b[0m',
        'foobar',
    ]
    assert len_without_ansi(text) == 12



# Generated at 2022-06-11 22:53:57.235481
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-11 22:53:59.382978
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:54:01.461043
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert(len_without_ansi(text) == 6)



# Generated at 2022-06-11 22:54:03.431545
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-11 22:54:06.589172
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:54:14.659749
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0

    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6

    text = 'abc \\x1b[38;5;209mfoobar\\x1b[0m \\x1b[31mbaz\\x1b[0m'
    assert len_without_ansi(text) == 12

    text = ['a', 'b ', '\\x1b[38;5;209m', 'foobar', '\\x1b[0m']
    assert len_without_ansi(text) == 6


# Generated at 2022-06-11 22:54:22.884827
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\033[96mfoobar\033[0m') == 6
    assert len_without_ansi('foo\033[96mbar\033[0m') == 6
    assert len_without_ansi('\033[96mfoo\033[0mbar') == 6
    assert len_without_ansi('foo\033[96m\033[0mbar') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foo', '\033[96m', 'bar', '\033[0m']) == 6
    assert len_without_ansi(['\033[96m', 'foo', '\033[0m', 'bar']) == 6

# Generated at 2022-06-11 22:54:29.544076
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(
        ['\x1b[38;5;209mfoobar', ' ', '\x1b[0m\x1b[38;5;225mzebra']
    ) == 13

# Generated at 2022-06-11 22:54:34.046414
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Tests for flutils.txtutils.len_without_ansi"""
    from flutils.txtutils import len_without_ansi
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
test_len_without_ansi()



# Generated at 2022-06-11 22:55:22.504391
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foobar', '\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(('foobar', '\x1b[38;5;209mfoobar\x1b[0m')) == 6
    assert len_without_ansi([]) == 0
    assert len_without_ansi('') == 0
    assert len_without_ansi(()) == 0
    assert len_without_ansi(['']) == 0
    assert len_without_ansi(None) == 0
    assert len_without

# Generated at 2022-06-11 22:55:29.650368
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Arrange
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    _text_seq = ['\x1b[38;5;209m' + c + '\x1b[0m' for c in 'foobar']
    _expected = 6

    # Act
    _test = len_without_ansi(_text)
    _test_seq = len_without_ansi(_text_seq)

    # Assert
    assert _test == _expected
    assert _test_seq == _expected



# Generated at 2022-06-11 22:55:32.494133
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test the len_without_ansi function."""
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-11 22:55:36.986204
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Arrange
    text = '\x1b[38;5;209mfoobar\x1b[0m'

    # Act
    out = len_without_ansi(text)

    # Assert
    assert out == 6



# Generated at 2022-06-11 22:55:39.440974
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    from typing import Any
    text: Any = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:55:41.908143
# Unit test for function len_without_ansi
def test_len_without_ansi():
    txtA = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(txtA) == 6



# Generated at 2022-06-11 22:55:53.011150
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from itertools import permutations
    from string import ascii_lowercase
    from random import choice, randint

    for i in range(5000):
        s = ''.join(choice(ascii_lowercase) for i in range(randint(1, 10)))
        ansi_text = '\x1b[%dm%s\x1b[0m' % (randint(0, 255), s)
        ansi_list = ['\x1b[%dm%s' % (randint(0, 255), s),
                     '\x1b[%sm' % randint(0, 255)]
        assert len(ansi_text) - len(s) == len_without_ansi(ansi_text)
        assert len(ansi_text) - len(s) == len_without_ans

# Generated at 2022-06-11 22:55:55.222574
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-11 22:56:04.943387
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """test_len_without_ansi()
    """
    # Test a list of strings

# Generated at 2022-06-11 22:56:08.400642
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6

