

# Generated at 2022-06-25 17:47:12.327747
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_func = len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert test_func(text) == 6
    text = '\x1b[33mfoobar\x1b[0m'
    assert test_func(text) == 6
    text = '\x1b[1m\x1b[4m\x1b[38;5;208mfoobar\x1b[0m'
    assert test_func(text) == 6
    text = '\x1b[1m\x1b[4m\x1b[38;5;208mfoo\x1b[0mbar'
    assert test_func(text) == 6

# Generated at 2022-06-25 17:47:13.850366
# Unit test for function len_without_ansi
def test_len_without_ansi():
    out_0 = len_without_ansi(test_case_0)


# Generated at 2022-06-25 17:47:24.137909
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from unittest import TestCase

    class len_without_ansiTestCase(TestCase):
        def test_case_0(self):
            bool_0 = False
            int_0 = len_without_ansi(bool_0)
            self.assertEqual(int_0, 0)
        def test_case_1(self):
            int_0 = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
            self.assertEqual(int_0, 6)
        def test_case_2(self):
            tuple_0: tuple = ('\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m')
            int_0

# Generated at 2022-06-25 17:47:30.491159
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()

# Compiled regex which matches ANSI escape sequences.
# See http://man7.org/linux/man-pages/man4/console_codes.4.html
_ANSITEXTCODES = re.compile(r'\x1b\[(?:\??(\d+);)?(?:\[(?P<ansi>\w+)\])?')


# Generated at 2022-06-25 17:47:34.493057
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Test case for len_without_ansi.
    """
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(_text) == 6


# Generated at 2022-06-25 17:47:37.438735
# Unit test for function len_without_ansi
def test_len_without_ansi():
    bool_0 = True
    int_0 = len_without_ansi(bool_0)
    assert(int_0 == 1)
    assert(int_0 == 1)



# Generated at 2022-06-25 17:47:44.655562
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 7
    assert len_without_ansi(('\x1b[38;5;209mfoo', '\x1b[0mbar')) == 7


# Generated at 2022-06-25 17:47:49.734199
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()


# Generated at 2022-06-25 17:47:52.614873
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = len_without_ansi('test')
    assert int_0 == 4, "'test' is not equal to 4"
    int_1 = len_without_ansi(['test1', 'test2'])
    assert int_1 == 8, "'test1', 'test2' is not equal to 8"


# Generated at 2022-06-25 17:47:58.815947
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['']) == 0
    assert len_without_ansi([text]) == 6
    assert len_without_ansi(['foobar', text]) == 12
    assert len_without_ansi([text, 'foobar']) == 12
    assert len_without_ansi([text, 'foobar', text]) == 18
    assert len_without_ansi(['', text, 'foobar', text]) == 18
