

# Generated at 2022-06-25 17:45:50.073781
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text_0) == 6
    text_1 = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text_1) == 6
    text_2 = '\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;210mbazqux\x1b[0m'
    assert len_without_ansi(text_2) == 12

# Generated at 2022-06-25 17:45:54.513196
# Unit test for function len_without_ansi
def test_len_without_ansi():
    print('Testing function len_without_ansi...')
    # Some more tests here
    text_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'
    str_0 = len_without_ansi(text_0)
    print(str_0)


# Generated at 2022-06-25 17:45:57.085158
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(str_0)


# Generated at 2022-06-25 17:46:04.345085
# Unit test for function len_without_ansi
def test_len_without_ansi():
    def test_case_0():
        str_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'
        len_without_ansi(str_0)

    def test_case_1():
        tuple_0 = (['\\x1b[38;5;209mfoobar\\x1b[0m'], ['\\x1b[38;5;209mfoobar\\x1b[0m'])
        len_without_ansi(tuple_0)


# Generated at 2022-06-25 17:46:09.308505
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = ['\x1b[38;5;209mfoobar', '\x1b[0m']
    len_without_ansi_actual = len_without_ansi(text_0)
    len_without_ansi_actual_u = u.py2unicode(len_without_ansi_actual)
    assert len_without_ansi_actual_u == u.string_type(u'6')


# Generated at 2022-06-25 17:46:12.723878
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # in: str text
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    # expect: int out
    out_0 = 6
    assert out_0 == len_without_ansi(text_0)

# ...



# Generated at 2022-06-25 17:46:22.873450
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from random import randint as rint
    text = ''
    for _ in range(rint(1, 10)):
        if rint(0, 3) == 1:
            text += '\x1b[' + str(rint(1, 100)) + ';'
        else:
            text += chr(rint(32, 126))
        if rint(0, 1):
            text += 'm'
    text = text[::-1]
    i = 0
    while text:
        end = False
        if text.startswith('\x1b['):
            if 'm' in text:
                i2 = text.find('m')
                text = text[i2 + 1:]
            else:
                end = True
        else:
            text = text[1:]
            i += 1

# Generated at 2022-06-25 17:46:25.203592
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(text_0)
    assert int_0 == 6


# Generated at 2022-06-25 17:46:26.875843
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ret_val_0 = len_without_ansi(list())
    assert ret_val_0 == len(list())
    return


# Generated at 2022-06-25 17:46:30.199716
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:48:13.393265
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test 1
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(seq) == 6
    # Test 2
    seq = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mbar\x1b[0m']
    assert len_without_ansi(seq) == 13
    # Test 3
    seq = ['\x1b[38;5;209mfoobar\x1b[0m', 'bar']
    assert len_without_ansi(seq) == 9


# noinspection PyAbstractClass
# pylint: disable=too-many-ancestors,too-many-instance-attributes

# Generated at 2022-06-25 17:48:20.725103
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = []
    str_0 = "foobar"
    str_1 = "\\x1b[38;5;209mfoobar\\x1b[0m"
    int_0 = len_without_ansi(str_0)
    int_1 = len_without_ansi(str_1)
    str_2 = "foobar\\x1b[38;5;209mfoobar\\x1b[0m"



# Generated at 2022-06-25 17:48:23.439806
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = 'o6qhAs(9Q\n0jR^1N\\6'
    int_0 = len_without_ansi(str_0)
    assert(int_0 == 12)


# Generated at 2022-06-25 17:48:26.714266
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq_0 = ['']
    seq_0 = None
    ansi_text_wrapper_0 = AnsiTextWrapper()
    ansi_text_wrapper_0.fix_sentence_endings(seq_0)
    len_without_ansi(seq_0)



# Generated at 2022-06-25 17:48:30.200330
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    seq = len_without_ansi(text)
    assert seq == 6


# Generated at 2022-06-25 17:48:33.528542
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(text_0)
    assert len(text_0) == 11
    assert int_0 == 6


# Generated at 2022-06-25 17:48:35.345224
# Unit test for function len_without_ansi
def test_len_without_ansi():
    bool_0 = None
    int_0 = len_without_ansi(bool_0)
    # assert int_0 == 6



# Generated at 2022-06-25 17:48:36.975419
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq_0 = None
    int_0 = len_without_ansi(seq_0)
    print(int_0)


# Generated at 2022-06-25 17:48:38.915185
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = None
    int_0 = 0
    int_0 = len_without_ansi(text_0)
    assert(int_0 == 0)



# Generated at 2022-06-25 17:48:40.575556
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = "\x1b[38;5;209mfoobar\x1b[0m"
    length = len_without_ansi(text)
    assert length == 6


# Generated at 2022-06-25 17:50:33.489778
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m', ['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-25 17:50:38.352404
# Unit test for function len_without_ansi
def test_len_without_ansi():
    def len_without_ansi_test0(text):
        return len_without_ansi(text) == 6

    def len_without_ansi_test1(text):
        return len_without_ansi([text]) == 6

    assert len_without_ansi_test0('\x1b[38;5;209mfoobar\x1b[0m')
    assert len_without_ansi_test1('\x1b[38;5;209mfoobar\x1b[0m')


# Generated at 2022-06-25 17:50:40.703707
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assertAnsiTextWrapper_0 = AnsiTextWrapper("foo", "bar")
    assert assertAnsiTextWrapper_0.wrap("foobar") == 'foobar'


# Generated at 2022-06-25 17:50:41.559127
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:50:49.324225
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('abc\x1b[0;33mdef\x1b[0m') == 6
    assert len_without_ansi('abc\x1b[0;33mdef\x1b[0m') == len_without_ansi(  # noqa: E501
        ['abc\x1b[0;33m', 'def\x1b[0m'])
    assert len_without_ansi('abc\x1b[0;33mdef\x1b[0m') == len_without_ansi(  # noqa: E501
        ('abc\x1b[0;33m', 'def\x1b[0m'))

# Generated at 2022-06-25 17:50:59.245385
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Tests for len_without_ansi
    seq = [1, 3, 'a', 'b', 'c', 'd']
    int_0 = len_without_ansi(seq)
    seq = ' '
    int_1 = len_without_ansi(seq)
    seq = '\\x1b[38;5;209mfoobar\\x1b[0m'
    int_2 = len_without_ansi(seq)
    seq = '\\x1b[0m'
    int_3 = len_without_ansi(seq)
    seq = '\\x1b[38;5;209m'
    int_4 = len_without_ansi(seq)
    seq = ''
    int_5 = len_without_ansi(seq)

# Generated at 2022-06-25 17:51:01.995616
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    bool_0 = bool(len_without_ansi(text))



# Generated at 2022-06-25 17:51:08.719726
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Return the character length of the given
    # Sequence <typing.Sequence> without counting any ANSI codes
    #
    # Args:
    #     seq (:obj:`Sequence <typing.Sequence>`): A string or a
    #         list/tuple of strings.
    #
    # :rtype:
    #     :obj:`int`
    #
    # Example:
    #     >>> from flutils.txtutils import len_without_ansi
    #     >>> text = '\x1b[38;5;209mfoobar\x1b[0m'
    #     >>> len_without_ansi(text)
    #     6

    # Example:
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'


# Generated at 2022-06-25 17:51:16.154826
# Unit test for function len_without_ansi
def test_len_without_ansi():
    value_0 = '\x1b[0m'
    expected_0 = 0
    actual_0 = len_without_ansi(value_0)
    assert actual_0 == expected_0

    value_1 = '\x1b[38;5;209mfoobar\x1b[0m'
    expected_1 = 6
    actual_1 = len_without_ansi(value_1)
    assert actual_1 == expected_1


# Generated at 2022-06-25 17:51:19.462414
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(text_0)
    int_1 = 6
    assert(int_0 == int_1)
