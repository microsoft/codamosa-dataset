

# Generated at 2022-06-25 17:42:33.178618
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_0 = AnsiTextWrapper('author')
    str_0 = 'author'
    str_1 = 'g]kv$op>kaUu;"q8d'
    ansi_text_wrapper_0 = AnsiTextWrapper(str_1)
    list_0 = ansi_text_wrapper_0.wrap(str_0)
    len_0 = len_without_ansi((list_0[0] + ' ') * 45)
    print(len_0)
    str_2 = 'author'
    str_3 = 'g]kv$op>kaUu;"q8d'
    ansi_text_wrapper_1 = AnsiTextWrapper(str_3)
    list_1 = ansi_text_wrapper_1.wrap(str_2)


# Generated at 2022-06-25 17:42:40.168728
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[1;93mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[1;93mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m\x1b[1;93mbar\x1b[0m') == 6
    assert len_without_ans

# Generated at 2022-06-25 17:42:43.681716
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:42:51.904160
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = 'author'
    seq_1 = str_0
    int_0 = len_without_ansi(seq_1)
    assert int_0 == 6
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    seq_1 = str_0
    int_0 = len_without_ansi(seq_1)
    assert int_0 == 6
    str_0 = 'f\x1b[38;5;209mfoobar\x1b[0mbar'
    seq_1 = str_0
    int_0 = len_without_ansi(seq_1)
    assert int_0 == 9



# Generated at 2022-06-25 17:42:58.221309
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = 'author'
    str_1 = 'g]kv$op>kaUu;"q8d'
    ansi_text_wrapper_0 = AnsiTextWrapper(str_1)
    list_0 = ansi_text_wrapper_0.wrap(str_0)
    assert len_without_ansi(str_1) == len(str_1)



# Generated at 2022-06-25 17:43:08.487853
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(str_0) == 6

    def function_0():
        str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
        len_without_ansi(str_0)

    try:
        function_0()
    except Exception as exception_0:
        print(exception_0)

    def function_0():
        str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
        len_without_ansi(str_0)

    try:
        function_0()
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 17:43:12.960883
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = 'author'
    str_1 = 'g]kv$op>kaUu;"q8d'
    ansi_text_wrapper_0 = AnsiTextWrapper(str_1)
    list_0 = ansi_text_wrapper_0.wrap(str_0)
    assert len_without_ansi(str_0) == 6


# Generated at 2022-06-25 17:43:16.767008
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('8MvC_bx{fb&g<`y%e') == 15
    assert len_without_ansi('f?n8r\r$e)k') == 8
    assert len_without_ansi('*zJ|>') == 4


# Generated at 2022-06-25 17:43:18.545168
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test for case 0
    test_case_0()
    
# Class 'AnsiTextWrapper'

# Generated at 2022-06-25 17:43:25.370499
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(str_0) == 6
    str_1 = 'author.'
    str_0 = 'pK63ty[4dHx2cla6m\x1b[1K'
    ansi_text_wrapper_0 = AnsiTextWrapper(str_0)
    list_0 = ansi_text_wrapper_0.wrap(str_1)
    assert len_without_ansi(str_1) == 7



# Generated at 2022-06-25 17:45:01.885735
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    print(len_without_ansi(text))


# Generated at 2022-06-25 17:45:04.431010
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:45:09.047509
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("\x1b[38;5;209mprint('\x1b[38;5;209mHello World!\x1b[0m')\x1b[0m") == 20
    assert len_without_ansi("\x1b[32mHello World!\x1b[0m") == 12



# Generated at 2022-06-25 17:45:11.392239
# Unit test for function len_without_ansi
def test_len_without_ansi():
    sample_text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert(len_without_ansi(sample_text) == 6)


# Generated at 2022-06-25 17:45:14.068238
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi_0 = len_without_ansi(text)
    assert len_without_ansi_0 == 6



# Generated at 2022-06-25 17:45:21.550733
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seqofstrs = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(seqofstrs) == 12
    assert len_without_ansi('') == 0
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mfoobar\x1b[0m') == 12



# Generated at 2022-06-25 17:45:28.499391
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = [
        'this is some text',
        'with a \x1b[38;5;196;48;5;231;24m\x1b[38;2;255;255;0m\x1b[38;5;3mmix of ansi colors and formatting codes\x1b[0m',
        '\x1b[0m\x1b[0m but some of them are invalid',
    ]

    result = len_without_ansi(text)
    assert(result == 60)


# Generated at 2022-06-25 17:45:34.255561
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_0 = AnsiTextWrapper()
    seq_0 = []
    assert ansi_text_wrapper_0.len_without_ansi(seq_0) == 0
    seq_1 = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert ansi_text_wrapper_0.len_without_ansi(seq_1) == 6
    seq_2 = ['\x1b[38;5;209mfffoooo', '\x1b[0m', '\x1b[38;5;209mbar', '\x1b[0m']
    assert ansi_text_wrapper_0.len_without_ansi(seq_2) == 9

# Generated at 2022-06-25 17:45:41.373951
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('123') == 3
    assert len_without_ansi('\x1b[31m1\x1b[32m2\x1b[39m3') == 3
    assert len_without_ansi(['123']) == 3
    assert len_without_ansi(['\x1b[31m1\x1b[32m2\x1b[39m3']) == 3
    assert len_without_ansi(['\x1b[31m1\x1b[32m2\x1b[39m3', '123']) == 6


# Generated at 2022-06-25 17:45:44.939581
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[35mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[35mfoo', 'bar\x1b[0m']) == 6


# Generated at 2022-06-25 17:50:28.066746
# Unit test for function len_without_ansi
def test_len_without_ansi():
    s = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(s) == 6


# Generated at 2022-06-25 17:50:30.992003
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('hello world!') == 12
    assert len_without_ansi([]) == 0
    assert len_without_ansi(['hello']) == 5
    assert len_without_ansi(('hello')) == 5



# Generated at 2022-06-25 17:50:35.134019
# Unit test for function len_without_ansi
def test_len_without_ansi():
    string_0 = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(string_0) == 6
    string_0 = '\x1b[1mfoobar'
    assert len_without_ansi(string_0) == 6
    expected_value = len_without_ansi(string_0)
    assert expected_value == 6

# Generated at 2022-06-25 17:50:42.792000
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_seq_0 = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;0m\x1b[32mfoobar\x1b[0m']
    assert len_without_ansi(test_seq_0) == 6 # Test case 0
    test_seq_1 = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;0m\x1b[32;1mfoobar\x1b[0m']
    assert len_without_ansi(test_seq_1) == 11 # Test case 1

# Generated at 2022-06-25 17:50:45.634961
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    out_ref = 6
    ret = out == out_ref
    return ret


# Generated at 2022-06-25 17:50:47.645373
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:50:50.358829
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:51:00.031151
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0  = '\\x1b[38;5;209mfoobar\\x1b[0m'
    text_1 = [
        '\\x1b[38;5;209mfoobar\\x1b[0m',
        '\\x1b[38;5;209mfoobar\\x1b[0m'
    ]
    text_2 = (
        '\\x1b[38;5;209mfoobar\\x1b[0m',
        '\\x1b[38;5;209mfoobar\\x1b[0m'
    )

    assert len_without_ansi(text_0) == 6
    assert len_without_ansi(text_1) == 12
    assert len_without_ansi(text_2) == 12


# Generated at 2022-06-25 17:51:02.888214
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_1 = AnsiTextWrapper()
    test_case_1 = "\x1b[38;5;209mtest\x1b[0m"
    assert len_without_ansi(test_case_1) == 4


# Generated at 2022-06-25 17:51:09.466734
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test with string
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi('\x1b[1mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[7mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[4mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[31mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[31;1mfoobar\x1b[0m') == 6
    assert len_without_