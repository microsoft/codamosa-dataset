

# Generated at 2022-06-25 17:42:27.751356
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert(int_0 == 6)

# Test whether the function "len_without_ansi" is pure

# Generated at 2022-06-25 17:42:32.869536
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(24) == 2
    assert len_without_ansi('24') == 2
    assert len_without_ansi('24 hours') == 9
    assert len_without_ansi('24 hours in a day') == 16
    assert len_without_ansi(24 * 'hours in a day') == 16

test_case_0()
test_len_without_ansi()



# Generated at 2022-06-25 17:42:35.793590
# Unit test for function len_without_ansi
def test_len_without_ansi():

    # Testing List
    test_case_0()

    # Testing String
    # assert len_without_ansi('') == 0

    # Testing Tuple
    # assert len_without_ansi(()) == 0



# Generated at 2022-06-25 17:42:37.375723
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 24
    int_1 = len_without_ansi(int_0)
    assert(int_1==24)


# Generated at 2022-06-25 17:42:40.259798
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[1;31mFooooo\x1b[0m') == 5
    assert len_without_ansi('Fooooo') == 5



# Generated at 2022-06-25 17:42:44.429242
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 24
    int_0_result = len_without_ansi(int_0)
    # Check if the results of the function
    # len_without_ansi match
    assert int_0_result == int_0


# Generated at 2022-06-25 17:42:45.633325
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(24) == 2


# Generated at 2022-06-25 17:42:51.510750
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    int_0 = 6
    int_1 = len_without_ansi(text)
    assert int_1 == int_0
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    int_0 = 6
    int_1 = len_without_ansi(text)
    assert int_1 == int_0


# Generated at 2022-06-25 17:42:56.397661
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 24
    int_1 = len_without_ansi(int_0)
    int_2 = 6
    int_3 = len_without_ansi(int_2)
    assert int_1 != int_2
    assert int_3 == int_2



# Generated at 2022-06-25 17:43:00.140722
# Unit test for function len_without_ansi
def test_len_without_ansi():
    param_1 = '\x1b[38;5;209mfoobar\x1b[0m'
    out_1 = 6
    assert(len_without_ansi(param_1) == out_1)
    return None


# Generated at 2022-06-25 17:43:21.251942
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert callable(len_without_ansi)


# Generated at 2022-06-25 17:43:26.644409
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('foo\x1b[0m') == 3
    assert (
        len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') ==
        len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) ==
        6
    )
    assert len_without_ansi(['foobar', '\x1b[0m']) == 6



# Generated at 2022-06-25 17:43:27.387824
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:43:34.843919
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(24) == 24
    assert len_without_ansi('24') == 2
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(('\x1b[1mfoo\x1b[0m', '\x1b[2mbar\x1b[0m')) == 6
    assert len_without_ansi(['\x1b[1mfoo\x1b[0m', '\x1b[2mbar\x1b[0m']) == 6



# Generated at 2022-06-25 17:43:38.983075
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_2 = 24
    int_3 = len_without_ansi(int_2)
    assert int_3 == 24
    int_4 = ['24']
    int_5 = len_without_ansi(int_4)
    assert int_5 == 24



# Generated at 2022-06-25 17:43:40.520500
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(24) == 2


# Generated at 2022-06-25 17:43:44.994961
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import random
    import string
    import pytest
    for _ in range(1000):
        str_0 = str()
        for _ in range(random.randint(0, 1000)):
            str_0 += random.choice(string.printable)
        assert len_without_ansi(str_0) == len(str_0)



# Generated at 2022-06-25 17:43:53.763511
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()

from flutils.txtutils import len_without_ansi

from pytest import raises

from typing import (
    Any,
    Callable,
    Dict,
    Iterator,
    List,
    Optional,
    Sequence,
    Tuple,
    Type,
    Union,
)
from typing_extensions import Literal

from flutils.constraints import (
    IsDictLike,
    IsMapping,
    IsSeqLike,
    IsStrSeq,
    IsTupleSeq,
    IsTupleSeqLike,
    IsUnionSeq,
)
from flutils.txtutils import simple_text_filter


# Generated at 2022-06-25 17:44:00.620266
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(24) == 2
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi([24]) == 2
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(('foo', 'bar')) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:44:01.583363
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(24) == 24



# Generated at 2022-06-25 17:44:29.101955
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('abc123abc') == 9
    assert len_without_ansi('\\x1b[38;5;209m\\x1b[0m') == 0
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    assert len_without_ansi('\\x1b[1mbold\\x1b[0m') == 4
    assert len_without_ansi('\\x1b[2mdim\\x1b[0m') == 3
    assert len_without_ansi('\\x1b[4munderlined\\x1b[0m') == 11
    assert len_without_ansi('\\x1b[7minverted\\x1b[0m') == 8
    assert len_without_

# Generated at 2022-06-25 17:44:31.308624
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 24
    int_1 = len_without_ansi(int_0)



# Generated at 2022-06-25 17:44:41.358569
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # text_0
    text_0 = 'Hello World'
    int_0 = len(text_0)
    int_1 = len_without_ansi(text_0)
    if int_0 != int_1:
        raise AssertionError
    text_1 = 'o'
    int_2 = len(text_1)
    int_3 = len_without_ansi(text_1)
    if int_2 != int_3:
        raise AssertionError
    text_2 = '\x1b[38;5;209mHello World\x1b[0m'
    int_4 = len(text_2)
    int_5 = len_without_ansi(text_2)
    if int_4 != 11:
        raise AssertionError

# Generated at 2022-06-25 17:44:43.409026
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert test_case_0() == None


# Generated at 2022-06-25 17:44:44.995108
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()
    test_case_1()

# Test for len_without_ansi

# Generated at 2022-06-25 17:44:47.024514
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()

# Create a text wrapper with ANSI color codes stripped from the word
# wrap algorithm. This is useful for colored text which can throw of
# the formatting.

# Generated at 2022-06-25 17:44:51.003866
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(text_0)
    assert int_0 == 6


# Generated at 2022-06-25 17:44:52.308310
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:44:53.351913
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:45:02.969028
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import random
    import string
    for _ in range(10000):
        test_case_0()
        int_0 = random.randint(-5,5)
        int_1 = len_without_ansi(int_0)
        seq = [c for c in string.ascii_letters]
        len_without_ansi(seq)
        seq = [c for c in string.ascii_letters]
        len_without_ansi(seq)
        int_0 = random.randint(-5,5)
        int_1 = len_without_ansi(int_0)
        int_0 = random.randint(-5,5)
        int_1 = len_without_ansi(int_0)
        seq = [c for c in string.ascii_letters]
        len_without_

# Generated at 2022-06-25 17:45:28.516099
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    return

_REGISTER_WRAPPER = TextWrapper



# Generated at 2022-06-25 17:45:38.102141
# Unit test for function len_without_ansi
def test_len_without_ansi():
    len_without_ansi('')
    len_without_ansi([''])
    len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209msdf\x1b[0m')
    len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209msdf\x1b[0m'])
    len_without_ansi('\x1b[38;5;209mfoobar')

# Generated at 2022-06-25 17:45:39.754053
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 24
    int_1 = len_without_ansi(int_0)
    assert int_1 == 24


# Generated at 2022-06-25 17:45:42.664545
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_1 = ('\x1b[38;5;209mfoobar\x1b[0m')
    int_0 = 24
    int_1 = len_without_ansi(text_1)
    assert int_1 == 6


# Generated at 2022-06-25 17:45:46.947098
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_sequence = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mtest\x1b[0m']
    desired_value = 12
    test_len = len_without_ansi(test_sequence)
    assert test_len == desired_value



# Generated at 2022-06-25 17:45:52.330885
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3
    assert len_without_ansi(['foo', 'bar']) == 3
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', '\x1b[0m']) == 3



# Generated at 2022-06-25 17:45:55.312959
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test case 0
    int_0 = 24
    int_1 = len_without_ansi(int_0)
    assert int_1 == int_0


# Generated at 2022-06-25 17:45:57.250807
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:46:03.267362
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = [
        'foobar',
        'bar',
        'foo',
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mbar\x1b[0m',
        '\x1b[38;5;209mfoo\x1b[0m',
    ]
    assert len_without_ansi(text) == 15



# Generated at 2022-06-25 17:46:11.864560
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test the function :func:`flutils.txtutils.len_without_ansi`."""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text * 2) == 12
    assert len_without_ansi([text] * 3) == 18
    assert len_without_ansi([text] * 3 + [text]) == 24
    assert len_without_ansi(['a' * 10, text, 'b' * 12]) == 20
    assert len_without_ansi([text * 2, 'a' * 5, 'b' * 6]) == 24
    assert len_without_ansi([text * 2, text * 3, text * 4]) == 30
    assert len

# Generated at 2022-06-25 17:46:44.467470
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test for case 0
    int_in_0 = 24
    int_expected_0 = 24
    len_without_ansi(int_in_0)


# Generated at 2022-06-25 17:46:46.490667
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 24
    int_1 = len_without_ansi(int_0)
    assert int_1 == 24



# Generated at 2022-06-25 17:46:47.309840
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:46:49.161329
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 24
    int_1 = len_without_ansi(int_0)



# Generated at 2022-06-25 17:46:52.783046
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_1 = 24
    string_1 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_2 = len_without_ansi(string_1)
    int_3 = len_without_ansi(int_1)
    int_4 = len_without_ansi([string_1])
    return


# Generated at 2022-06-25 17:46:59.603951
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[1md\x1b[38;5;209mfoobar\x1b[0m') == 7
    assert len_without_ansi('\x1b[1md\x1b[38;5;209mfoobar\x1b[0m') == 7
    assert len_without_ansi('\x1b[1md\x1b[38;5;209mfoobar\x1b[0m') == 7
    assert len_without_ansi('\x1b[1md\x1b[38;5;209mfoobar\x1b[0m') == 7
    assert len_without_

# Generated at 2022-06-25 17:47:02.234384
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 24
    int_1 = len_without_ansi(int_0)

    # AssertionError: 24 != 0
    assert int_1 == 0


# Generated at 2022-06-25 17:47:02.669920
# Unit test for function len_without_ansi
def test_len_without_ansi():
    pass



# Generated at 2022-06-25 17:47:06.813519
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(text)
    assert int_0 == 6, "result was {0}, expected {1}".format(int_0, 6)



# Generated at 2022-06-25 17:47:10.665960
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Variants of str_0
    str_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'
    str_1 = '\\x1b[38;5;209mf\\x1b[0moobar\\x1b[0m'
    str_2 = '\\x1b[38;5;209mf\\x1b[0mo\\x1b[0mobar\\x1b[0m'
    str_3 = '\\x1b[38;5;209mf\\x1b[0mo\\x1b[0mo\\x1b[0mbar\\x1b[0m'

# Generated at 2022-06-25 17:48:09.856756
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:48:12.388716
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()

# Disable warnings for each test case
from warnings import filterwarnings
from flutils.constants import FlUtilsConstants
filterwarnings(action="ignore", module=FlUtilsConstants.warnings_module_name)



# Generated at 2022-06-25 17:48:17.603499
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[1mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[1m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi('\x1b[1mfoobar\x1b[0m \x1b[1mspam\x1b[0m') == 12
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foobar']) == 6
    assert len_without_ansi('foobar spam') == 12
    assert len_without_ansi(['foobar', 'spam']) == 12

# Generated at 2022-06-25 17:48:23.620443
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Make sure we can pass in a str
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    # Make sure we can pass in a list
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == 6
    # Make sure we can pass in a tuple
    assert len_without_ansi(('\x1b[38;5;209mfoo', 'bar\x1b[0m')) == 6
    # Make sure we can pass in a list of tuples
    assert len_without_ansi([('\x1b[38;5;209mfoo',), ('bar\x1b[0m',)]) == 6
    # Make sure we can

# Generated at 2022-06-25 17:48:26.301751
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 24
    int_1 = len_without_ansi(int_0)
    exp_len = 24
    assert int_1 == exp_len

# flake8: noqa: F811

# Generated at 2022-06-25 17:48:35.412195
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test function len_without_ansi with examples from the documentation
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = 6
    int_1 = len_without_ansi(text)
    # assert int_0 == int_1
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    int_2 = 6
    int_3 = len_without_ansi(text)
    # assert int_2 == int_3
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;208mbar'
    int_4 = 6
    int_5 = len_without_ansi(text)
    # assert int_4

# Generated at 2022-06-25 17:48:41.729345
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi"""

    # Test for checking the return type of len_without_ansi
    from pytest import raises
    from typing import Union, overload

    int_0 = 24
    @overload
    def test(arg0: str) -> int: ...
    def test(arg0: Union[str, Sequence[str]]) -> int:
        raise AttributeError
    with raises(AttributeError):
        test('24')
    @overload
    def test(arg0: str) -> int: ...
    def test(arg0: Union[str, Sequence[str]]) -> int:
        raise TypeError
    with raises(TypeError):
        test(int_0)
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    int

# Generated at 2022-06-25 17:48:44.240003
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = 6
    int_1 = len_without_ansi(text)
    assert int_1 == int_0



# Generated at 2022-06-25 17:48:45.884913
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = "foo"
    try:
        len_without_ansi(seq)
        success = True
    except:
        success = False
    assert success


# Generated at 2022-06-25 17:48:46.716911
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert test_case_0() == None
