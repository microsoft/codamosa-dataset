

# Generated at 2022-06-25 17:43:07.260771
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[1mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('foo\x1bbbar') == 6
    assert len_without_ansi(['foo\x1bbbar', 'bo\x1bbb']) == 8



# Generated at 2022-06-25 17:43:11.768396
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import unittest

    # Test Cases

    class len_without_ansi_TestCase(unittest.TestCase):
        def test_case_0(self):
            sequence_0 = None
            int_0 = len_without_ansi(sequence_0)
            self.assertEqual(int_0, 0)

    unittest.main()



# Generated at 2022-06-25 17:43:14.585651
# Unit test for function len_without_ansi
def test_len_without_ansi():
    sequence_0 = "a\x1b[3mb\x1b[1mc\x1b[0m"
    int_0 = len_without_ansi(sequence_0)
    assert int_0 == 3


# Generated at 2022-06-25 17:43:24.170634
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert [] == _ANSI_RE.split('\x1b[0m')
    assert ['\x1b[0m', '\x1b[0m'] == _ANSI_RE.split('\x1b[0m\x1b[0m')
    assert ['\x1b[0m\x1b[0m'] == _ANSI_RE.split('\x1b[0m\x1b[0m')
    assert ['\x1b[0m\x1b[0m', '\x1b[0m\x1b[0m'] == _ANSI_RE.split('\x1b[0m\x1b[0m\x1b[0m\x1b[0m')

# Generated at 2022-06-25 17:43:32.332339
# Unit test for function len_without_ansi
def test_len_without_ansi():
    sequence_0 = None
    int_0 = len_without_ansi(sequence_0)
    sequence_1 = ['\x1b[38;5;209mfoobar\x1b[0m']
    int_1 = len_without_ansi(sequence_1)
    sequence_2 = ['\x1b[38;5;209mfoobar\x1b[0m']
    int_2 = len_without_ansi(sequence_2)
    sequence_3 = ['\x1b[38;5;209mfoobar\x1b[0m']
    int_3 = len_without_ansi(sequence_3)
    assert int_0 == 0
    assert int_1 == 6
    assert int_2 == 6
    assert int_3 == 6


# Generated at 2022-06-25 17:43:39.040341
# Unit test for function len_without_ansi
def test_len_without_ansi():
    sequence_0 = None
    int_0 = len_without_ansi(sequence_0)
    int_1 = len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m'])
    assert(int_0 == 0)
    assert(int_1 == 48)



# Generated at 2022-06-25 17:43:47.887773
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Python Implementation
    sequence_0 = None
    int_0 = len_without_ansi(sequence_0)
    sequence_1 = ''
    int_1 = len_without_ansi(sequence_1)
    sequence_2 = 'Hello'
    int_2 = len_without_ansi(sequence_2)
    sequence_3 = 'Hello World!'
    int_3 = len_without_ansi(sequence_3)
    sequence_4 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_4 = len_without_ansi(sequence_4)

# Generated at 2022-06-25 17:43:51.273219
# Unit test for function len_without_ansi
def test_len_without_ansi():
    sequence_0 = "J\x1bo\x1b[0\x1bh\x1b[00n\x1b[0m \x1b[32mC\x1b[3oc\x1b[38m"
    int_0 = len_without_ansi(sequence_0)



# Generated at 2022-06-25 17:43:55.364067
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:43:57.144868
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert callable(len_without_ansi)



# Generated at 2022-06-25 17:44:46.283304
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'
    length_0 = len_without_ansi(text_0)
    assert length_0 == 6


# Generated at 2022-06-25 17:44:49.614553
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:44:56.195711
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_1 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text_1) == 6  # type: ignore[unreachable]
    text_2 = ['\x1b[38;5;209mfoo', 'bar\x1b[0m']
    assert len_without_ansi(text_2) == 6  # type: ignore[unreachable]


# Generated at 2022-06-25 17:45:00.629537
# Unit test for function len_without_ansi
def test_len_without_ansi():
    print(len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')) # 6
    print(len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', 'baz'])) # 6
    print('')


# Generated at 2022-06-25 17:45:07.513517
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m',)) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoo', '\x1b[38;5;208mbar\x1b[0m')) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[38;5;208mbar\x1b[0m']) == 6


# Generated at 2022-06-25 17:45:15.562254
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_0 = AnsiTextWrapper()
    ansi_text_wrapper_0.initial_indent = ''
    ansi_text_wrapper_0.subsequent_indent = ''
    ansi_text_wrapper_0._fix_sentence_endings = None
    ansi_text_wrapper_0.width = 14
    ansi_text_wrapper_0.drop_whitespace = True
    ansi_text_wrapper_0.replace_whitespace = False
    ansi_text_wrapper_0.expand_tabs = False
    ansi_text_wrapper_0.break_long_words = True
    ansi_text_wrapper_0.break_on_hyphens = True
    ansi_text_wrapper_0.wordsep_re = None
    ansi_

# Generated at 2022-06-25 17:45:17.447328
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:45:22.673688
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209m', 'foobar\x1b[0m')) == 6



# Generated at 2022-06-25 17:45:31.004981
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
   Unit test for `len_without_ansi` function.
    """
    from flutils.txtutils import len_without_ansi
    text_0 = '\033[38;5;209mfoobar\033[0m'
    text_1 = '\u001b[38;5;209mfoobar\u001b[0m'
    text_2 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text_0) is 6
    assert len_without_ansi(text_1) is 6
    assert len_without_ansi(text_2) is 6



# Generated at 2022-06-25 17:45:40.547021
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    ansi_text_wrapper_1 = AnsiTextWrapper()
    ansi_text_wrapper_1.width = 6
    ansi_text_wrapper_1.initial_indent = ""
    ansi_text_wrapper_1.subsequent_indent = ""

    print(text)
    ansi_text_wrapper_1.replace_whitespace = False
    ansi_text_wrapper_1.fix_sentence_endings = False
    ansi_text_wrapper_1.max_lines = None
    ansi_text_wrapper_1.drop_whitespace = False
    ansi_text_wrapper_1.break_long_words = False

# Generated at 2022-06-25 17:46:50.067526
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:46:56.844377
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test for string
    text = 'test\x1b[0m'
    assert len_without_ansi(text) == len('test')

    # Test for list
    text = ['test', '\x1b[0m']
    assert len_without_ansi(text) == len('test')

# class AnsiTextWrapper(TextWrapper):
#     """An extension of the :obj:`TextWrapper <textwrap.TextWrapper>` class
#     that ignores ANSI codes when calculating the length of each line,
#     and automatically removes them when the text is unwrapped.

#     *New in version 0.6*

#     Args:
#         width (:obj:`int`, optional): The character width of each line.
#             Defaults to ``70`` characters.

#    

# Generated at 2022-06-25 17:47:07.199169
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[mfooba\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[mfooba\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[foo\x1b[0m'
    assert len_without_ansi(text) == 0
    text = '\x1b[foo\x1b[0m'

# Generated at 2022-06-25 17:47:10.208207
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(test_text_0) == 6


# Generated at 2022-06-25 17:47:16.248887
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    assert len_without_ansi(['\\x1b[38;5;209mfoo\\x1b[0m', '\\x1b[38;5;209mbar\\x1b[0m']) == 6
    assert len_without_ansi(['\\x1b[38;5;209mfoobar\\x1b[0m']) == 6
    assert len_without_ansi(('\\x1b[38;5;209mfoobar\\x1b[0m',)) == 6



# Generated at 2022-06-25 17:47:19.453183
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('hello world!') == 12
    assert len_without_ansi(['hello world!']) == 12
    assert len_without_ansi(['hello ', 'world!']) == 12
    assert len_without_ansi(['hello ', 'world!', ' pink']) == 12


# Generated at 2022-06-25 17:47:30.864897
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Unit test for function len_without_ansi # 0
    assert len_without_ansi("blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah") == 43
    # Unit test for function len_without_ansi # 1
    assert len_without_ansi("blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah bla") == 42
    # Unit test for function len_without_ansi # 2
    assert len_without_ansi("blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah bl") == 41
    # Unit test for function len_without_ansi # 3
    assert len_without_ansi("WORD") == 4
    # Unit test for function len_without_ansi # 4

# Generated at 2022-06-25 17:47:36.905817
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_0 = AnsiTextWrapper()
    text_list = ['\x1b[38;5;209mfoobar\x1b[0m',
                 '\x1b[38;5;209mfoobar',
                 '\x1b[38;5;209mfoobar',
                 'foobar\x1b[0m',
                 'foobar\x1b[0m',
                ]
    assert len_without_ansi(text_list) == 36
    assert len_without_ansi(text_list[0]) == 6
    assert len_without_ansi(text_list[1]) == 6
    assert len_without_ansi(text_list[2]) == 6


# Generated at 2022-06-25 17:47:40.097492
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_0 = AnsiTextWrapper()
    # Test for proper return type
    assert isinstance(len_without_ansi(ansi_text_wrapper_0), int)


# Generated at 2022-06-25 17:47:42.945054
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:48:21.719410
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert(len_without_ansi(text) == 6)


# Generated at 2022-06-25 17:48:24.003315
# Unit test for function len_without_ansi
def test_len_without_ansi():
  x = '\x1b[38;5;209mfoobar\x1b[0m'
  return_value = len_without_ansi(x)
  assert return_value == 6


# Generated at 2022-06-25 17:48:28.625980
# Unit test for function len_without_ansi

# Generated at 2022-06-25 17:48:35.504467
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209m\x1b[0mfoo\x1b[38;5;209mbar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209m\x1b[0mfoobar\x1b[38;5;209m\x1b[0m') == 6



# Generated at 2022-06-25 17:48:37.207492
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi(text) == 6


# Generated at 2022-06-25 17:48:39.008853
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:48:40.544904
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:48:43.252083
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = "\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;208mbar\x1b[0m"
    assert len_without_ansi(str_0) == 6


# Generated at 2022-06-25 17:48:46.676047
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    text_1 = '\x1b[38;5;209mfoobar\x1b[0m'
    print(len_without_ansi(text_0))
    print(len_without_ansi(text_1))


# Generated at 2022-06-25 17:48:51.238761
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test for len_without_ansi"""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    result = len_without_ansi(text)
    expected = 6
    assert result == expected
    print("\nSUCCESS: len_without_ansi - text = '%s'" % text)



# Generated at 2022-06-25 17:50:33.886310
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Case 0
    text_0 = ("\x1b[38;5;208mThe \x1b[38;5;113mflutils\x1b[38;5;208m library "
            "\x1b[38;5;113m(version 0.1.0)\x1b[38;5;208m does "
            "\x1b[38;5;113mnot\x1b[38;5;208m depend on any external "
            "libraries.\x1b[0m")
    assert len_without_ansi(text_0) == 87


# Generated at 2022-06-25 17:50:35.712312
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[31mfoobar\x1b[0m'
    if len_without_ansi(text) != 6:
        raise ValueError("len_without_ansi failure.")


# Generated at 2022-06-25 17:50:39.428377
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[1mbar\x1b[0m']) == 6


# Generated at 2022-06-25 17:50:43.098875
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_inputs = [
        ('\\x1b[38;5;209mfoobar\\x1b[0m', 6),
    ]
    for test_inputs in test_inputs:
        assert len_without_ansi(test_inputs[0]) == test_inputs[1]
    return True

test_case_0()
test_len_without_ansi()



# Generated at 2022-06-25 17:50:45.303707
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text_0) == 6


# Generated at 2022-06-25 17:50:46.924349
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6


# Generated at 2022-06-25 17:50:50.979296
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi('') == 0
    assert len_without_ansi(['']) == 0


# Generated at 2022-06-25 17:51:01.138317
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = "Hello World"
    assert len_without_ansi(text) == len(text)
    text = "Hello \x1b[38;5;209mWorld\x1b[0m"
    assert len_without_ansi(text) == len(text) - len_without_ansi("\x1b[38;5;209mWorld\x1b[0m")
    text = "Hello \x1b[38;5;209mW\x1b[0morld"
    assert len_without_ansi(text) == len(text) - len_without_ansi("\x1b[38;5;209mW\x1b[0m")

# Generated at 2022-06-25 17:51:02.672266
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    value = len_without_ansi(text)
    return value


# Generated at 2022-06-25 17:51:05.631026
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    ansi_text_wrapper_0: int = len_without_ansi(text_0)
    # Test should fail
    assert (ansi_text_wrapper_0 == 7)

