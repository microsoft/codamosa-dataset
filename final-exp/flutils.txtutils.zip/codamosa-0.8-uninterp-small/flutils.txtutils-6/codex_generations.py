

# Generated at 2022-06-25 17:43:31.208647
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Expected length of text
    len_0 = 0
    # Expected length of text with ANSI codes
    len_1 = 4
    # To store length of text without ANSI codes
    len_2 = 0
    # Actual text
    text = "foo"
    # Actual text with ANSI codes
    text_0 = "\x1b[1;3mfoo\x1b[0m"
    # Comparing len_0 and len_1
    assert len_0 == len_without_ansi(text)
    # Comparing len_1 and len_2
    assert len_1 == len_without_ansi(text_0)


# Generated at 2022-06-25 17:43:34.641935
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_seq0 = 'foo \x1b[38;5;209mfoobar\x1b[0m baz'
    int_0 = len_without_ansi(str_seq0)
    assert int_0 == 9



# Generated at 2022-06-25 17:43:37.961743
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = "\\x1b[38;5;209mfoobar\\x1b[0m"
    assert len_without_ansi(text_0) == 6


# Generated at 2022-06-25 17:43:42.181329
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    bool_0 = bool(len(str_0))
    int_0 = len_without_ansi(str_0)
    bool_1 = bool(int_0)
    assert bool_0 != bool_1


# Generated at 2022-06-25 17:43:44.819205
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:43:51.427154
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Strings with and without ANSI codes
    string_0 = u'\x1b[38;5;209mfoobar\x1b[0m'
    string_1 = u'foobar'
    string_2 = u'foo bar'
    integer_0 = 6

    # Test for function len_without_ansi with float type of argument seq.
    try:
        float_0 = 0.1
        len_without_ansi(float_0)
    except TypeError:
        print('Argument seq is not of type str or a list/tuple of strings.')

    # The str argument is evaluated for the length without ANSI codes.
    assert len_without_ansi(string_0) == integer_0
    assert len_without_ansi(string_1) == integer_0
    assert len_without

# Generated at 2022-06-25 17:43:55.415372
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:43:58.512345
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(seq) == 6



# Generated at 2022-06-25 17:44:00.954763
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = 'f'
    bool_0 = len(str_0) == len_without_ansi(str_0)
    bool_1 = bool_0


# Generated at 2022-06-25 17:44:02.600032
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:44:37.536554
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert int_0 == 6

# Test case for function len_without_ansi
# Test if it can handle str input

# Generated at 2022-06-25 17:44:47.198082
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("") == 0
    assert len_without_ansi("a") == 1
    assert len_without_ansi("\x1b[38;2;255;100;0ma") == 1
    assert len_without_ansi("\x1b[38;2;255;100;0mhello\x1b[38;2;0;0;255m world\x1b[0m") == 11
    assert len_without_ansi("\x1b[32mA\x1b[0m") == 1
    assert len_without_ansi("\x1b[31mA\x1b[0m") == 1
    assert len_without_ansi("\x1b[33mA\x1b[0m") == 1

# Generated at 2022-06-25 17:44:50.383224
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:45:00.577011
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = ''
    ansi_re_0 = re.compile('(\x1b\\[[0-9;:]+[ABCDEFGHJKSTfhilmns])')
    seq_0 = [c for c in ansi_re_0.split(text_0) if c]
    seq_1 = [c for c in chain(*map(ansi_re_0.split, seq_0)) if c]
    seq_2 = [c for c in chain(*map(ansi_re_0.split, seq_1)) if c]
    seq_3 = [c for c in chain(*map(ansi_re_0.split, seq_2)) if c]
    seq_4 = [c for c in chain(*map(ansi_re_0.split, seq_3)) if c]
   

# Generated at 2022-06-25 17:45:04.043439
# Unit test for function len_without_ansi
def test_len_without_ansi():

    # Setup
    text = '\x1b[38;5;209mfoobar\x1b[0m'

    # Exercise
    result = len_without_ansi(text)

    # Verify
    expected = 6
    assert(result == expected)



# Generated at 2022-06-25 17:45:12.538982
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # For example
    text = 'foobar'
    text_len = len_without_ansi(text)
    assert text_len == 6
    # For example
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    text_len = len_without_ansi(text)
    assert text_len == 6
    # For example
    text = ['foo', '\x1b[38;5;209mbar', '\x1b[0m']
    text_len = len_without_ansi(text)
    assert text_len == 6
    # For example
    text = ['foo', '\x1b[38;5;209m', 'bar', '\x1b[0m']
    text_len = len_without_ansi(text)

# Generated at 2022-06-25 17:45:14.617485
# Unit test for function len_without_ansi
def test_len_without_ansi():
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi(_text)



# Generated at 2022-06-25 17:45:18.460778
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = ['\\x1b[38;5;209mfoobar\\x1b[0m', '\\x1b[38;5;209mfoobar\\x1b[0m']
    clambda_0 = lambda list_0: len_without_ansi(list_0)
    int_0 = clambda_0(list_0)



# Generated at 2022-06-25 17:45:28.001424
# Unit test for function len_without_ansi

# Generated at 2022-06-25 17:45:37.752386
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # test case 1
    bool_0 = False
    str_0 = "Hello"
    str_1 = ""
    assert len_without_ansi(str_0) == len(str_0)
    # test case 2
    str_2 = "Hello\u001b[38;5;209mfoobar\u001b[0m"
    str_3 = "\u001b[38;5;209mfoobar\u001b[0m"
    str_4 = "Hello"
    assert len_without_ansi(str_2) == len(str_4)
    # test case 3

# Generated at 2022-06-25 17:46:10.082882
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(None) == 0



# Generated at 2022-06-25 17:46:11.975214
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-25 17:46:15.117177
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(seq_0)
    print(int_0)


# noinspection PyUnresolvedReferences,PyUnresolvedReferences,PyUnresolvedReferences,PyShadowingBuiltins

# Generated at 2022-06-25 17:46:18.073358
# Unit test for function len_without_ansi
def test_len_without_ansi():

    # Test case 0
    test_case_0()


# Generated at 2022-06-25 17:46:19.186241
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test Case 0
    test_case_0()


# Generated at 2022-06-25 17:46:23.624559
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test exceptions
    try:
        len_without_ansi(123)
        flag_0 = True
    except:
        flag_0 = False
    assert flag_0 is False

    # Test return type
    value_0 = len_without_ansi("")
    assert isinstance(value_0, int)

    # Test return value
    value_1 = len_without_ansi("")
    assert value_1 == 0

    # Test return type
    value_2 = len_without_ansi("abc")
    assert isinstance(value_2, int)

    # Test return value
    value_3 = len_without_ansi("abc")
    assert value_3 == 3

    # Test return type
    value_4 = len_without_ansi("ab\x1b[6;10Hc")


# Generated at 2022-06-25 17:46:27.757493
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text_0) == 6, 'len_without_ansi(text_0) returned: ' + str(len_without_ansi(text_0))



# Generated at 2022-06-25 17:46:31.939933
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq_0 = ['$', '$', '$', '$', '$', '$']
    int_0 = len_without_ansi(seq_0)
    assert int_0 == 6


# Generated at 2022-06-25 17:46:33.524930
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:46:35.903681
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    # Test with str type 
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:47:16.687569
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6


# Generated at 2022-06-25 17:47:22.872050
# Unit test for function len_without_ansi
def test_len_without_ansi():
    out = len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m')
    assert out == 6
    out = len_without_ansi('\\x1b[38;5;209mfoobar')
    assert out == 6
    out = len_without_ansi('foobar\\x1b[0m')
    assert out == 6
    out = len_without_ansi('foobar')
    assert out == 6



# Generated at 2022-06-25 17:47:27.001336
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    result_0 = len_without_ansi(text_0)

    assert result_0 == 6


# Generated at 2022-06-25 17:47:29.628627
# Unit test for function len_without_ansi
def test_len_without_ansi():
    current_text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(current_text) == 6
    return


# Generated at 2022-06-25 17:47:32.769879
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test that len_without_ansi works for a single string
    str_0 = 'This is a test'
    int_0 = len_without_ansi(str_0)
    assert int_0 == len(str_0)


# Generated at 2022-06-25 17:47:34.326107
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("\\x1b[38;5;209mfoobar\\x1b[0m") == 6


# Generated at 2022-06-25 17:47:44.357213
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Assert that the output of the function under test is correct
    assert len_without_ansi("") == 0 # Assert that the output of the function under test is correct
    assert len_without_ansi([""]) == 0 # Assert that the output of the function under test is correct
    assert len_without_ansi("a") == 1 # Assert that the output of the function under test is correct
    assert len_without_ansi(["a"]) == 1 # Assert that the output of the function under test is correct
    assert len_without_ansi("ab") == 2 # Assert that the output of the function under test is correct
    assert len_without_ansi(["ab"]) == 2 # Assert that the output of the function under test is correct


# Generated at 2022-06-25 17:47:46.765592
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    a = len_without_ansi(text)
    assert a == 6


# Generated at 2022-06-25 17:47:53.153921
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Make sure the function doesn't screw up when there's no ANSI code
    text = 'foooo'
    assert len(text) == len_without_ansi(text)
    assert len(text) == 6
    assert len_without_ansi(text) == 6

    # Make sure the function does work if there's an ANSI code
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == len_without_ansi(text) + 8
    assert len(text) == 19
    assert len_without_ansi(text) == 11

    # Make sure the function works if there's multiple ANSI codes
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len(text) == len

# Generated at 2022-06-25 17:48:00.909452
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test cases
    class TestCase:
        text: Optional[str] = None
        chars: Optional[int] = None
        def __init__(self, t: str, c: int) -> None:
            self.text = t
            self.chars = c
    cases = [
        TestCase(
            '\x1b[38;5;209mfoobar\x1b[0m',
            6,
        ),
    ]
    for case in cases:
        # Test case 0
        actual = len_without_ansi(case.text)
        want = case.chars
        assert actual == want, \
            "len_without_ansi('{}') -> '{}', want '{}'".format(case.text, actual, want)



# Generated at 2022-06-25 17:48:47.181159
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = len_without_ansi('a')
    int_0 = len_without_ansi([])
    int_0 = len_without_ansi('')
    int_0 = len_without_ansi([''])
    int_1 = len_without_ansi(['a'])
    int_1 = len_without_ansi('a')
    if __name__ == '__main__':
        print(int_0, int_1)



# Generated at 2022-06-25 17:48:50.905128
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    try:
        assert len_without_ansi(text_0) == 6
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 17:48:52.688571
# Unit test for function len_without_ansi
def test_len_without_ansi():
    line = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(line)
    assert out == 6



# Generated at 2022-06-25 17:48:55.522862
# Unit test for function len_without_ansi
def test_len_without_ansi():
    s = "\\x1b[38;5;209mfoobar\\x1b[0m"
    assert len_without_ansi(s) == 6
    list = ["\\x1b[38;5;209mfoobar\\x1b[0m","123456"]
    assert len_without_ansi(list) == 12


# Generated at 2022-06-25 17:49:00.881131
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test Case #0
    test_case_0()
    # Test Case #1
    text_0 = 'foobar'
    expected_0 = 6
    actual_0 = len_without_ansi(text_0)
    try:
        assert actual_0 == expected_0
    except AssertionError:
        raise AssertionError(
            'Expected {0} but got {1}'.format(expected_0, actual_0)
        ) from None
    # Test Case #2
    text_1 = '\x1b[38;5;209mfoobar\x1b[0m'
    expected_1 = 6
    actual_1 = len_without_ansi(text_1)
    try:
        assert actual_1 == expected_1
    except AssertionError:
        raise Ass

# Generated at 2022-06-25 17:49:02.397855
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '[\\x1b[38;2;255;255;255m'
    expect = len(text) - 2
    actual = len_without_ansi(text)
    assert expect == actual


# Generated at 2022-06-25 17:49:04.442315
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    integer_0 = len_without_ansi(text)
    assert integer_0 == 6


# Generated at 2022-06-25 17:49:06.468669
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(str_0) == 6


# Generated at 2022-06-25 17:49:11.229664
# Unit test for function len_without_ansi
def test_len_without_ansi():
    bool_0 = False
    ansi_text_wrapper_0 = AnsiTextWrapper(bool_0)
    int_0 = 6
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_1 = len_without_ansi(str_0)
    bool_1 = int_0 == int_1
    assert bool_1



# Generated at 2022-06-25 17:49:13.693628
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:50:14.900402
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('▶ Test') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', 'hello']) == 11
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m', 'hello')) == 11


# Generated at 2022-06-25 17:50:18.585208
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq_0: List[str] = ["\x1b[38;5;209mfoobar\x1b[0m"]
    int_0: int = len_without_ansi(seq_0)
    assert(int_0 == 6)



# Generated at 2022-06-25 17:50:25.396789
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foo', '\x1b[38;5;209m', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(['foo', 'bar']) == 6


# Generated at 2022-06-25 17:50:28.344452
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi_0: int = len_without_ansi(text)
    assert len_without_ansi_0 == 6

# Generated at 2022-06-25 17:50:31.998275
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = 'foobar'
    ansi_text_wrapper_0 = AnsiTextWrapper()
    text_0x = ansi_text_wrapper_0.fill(text_0)
    len_0 = len_without_ansi(text_0x)
    assert len_0 == 6

# unit test for function AnsiTextWrapper.__init__

# Generated at 2022-06-25 17:50:37.638211
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq_0 = 'string'
    seq_1 = [
        'string'
    ]
    seq_2 = [
        'string',
        'string'
    ]
    seq_3 = [
        'string',
        '\x1b[38;5;209mstring\x1b[0m',
        'string'
    ]
    seq_4 = [
        '\x1b[38;5;209mstring\x1b[0m',
        '\x1b[38;5;209mstring\x1b[0m',
        '\x1b[38;5;209mstring\x1b[0m'
    ]

# Generated at 2022-06-25 17:50:39.752536
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    len_without_ansi(text)


# Generated at 2022-06-25 17:50:41.880320
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    value = len_without_ansi(text)
    assert value == 6



# Generated at 2022-06-25 17:50:45.608265
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    bool_0 = len_without_ansi(str_0)
    bool_1 = 6
    bool_2 = False
    if bool_0 != bool_1:
        bool_2 = True
    assert bool_2


# Generated at 2022-06-25 17:50:52.012644
# Unit test for function len_without_ansi
def test_len_without_ansi():

    func = len_without_ansi
    assert callable(func), f'{func} should be a callable.'

    text: str = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6, 'len_without_ansi should return 6.'

    seq: Sequence[str] = ('\x1b[38;5;209mfoo', 'bar\x1b[0m')
    assert len_without_ansi(seq) == 6, 'len_without_ansi should return 6.'
