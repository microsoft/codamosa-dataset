

# Generated at 2022-06-25 17:42:54.730774
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:43:05.802766
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # AnsiFormatter() is only available in Python 3.7 and above
    from sys import hexversion
    if hexversion < 0x03070000:
        return
    import colorama
    from ansiformatter import AnsiFormatter
    from flutils.txtutils import len_without_ansi
    import logging
    import pytest
    colorama.init(autoreset=True)
    text = 'foobar'
    f = AnsiFormatter()
    colored_text = f.format('{fg.underline}foobar{reset}')
    assert len_without_ansi(colored_text) == 6
    logging.basicConfig(
        format='{levelname}, {name}: {message}',
        style='{',
    )
    log = logging.getLogger()
    h = logging.StreamHandler()
   

# Generated at 2022-06-25 17:43:09.004165
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    out_0 = len_without_ansi(text_0)
    assert out_0 == 6


# Generated at 2022-06-25 17:43:15.045078
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(seq_0) == 6
    seq_1 = '\x1b[0mfoobar\x1b[0m'
    assert len_without_ansi(seq_1) == 6
    seq_2 = '\x1b[38;5;209mfoobar'
    assert len_without_ansi(seq_2) == 6
    seq_3 = 'foobar'
    assert len_without_ansi(seq_3) == 6



# Generated at 2022-06-25 17:43:24.596255
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Initialize test data
    bytes_0 = b'\x1b[0m\x1b[38;5;193;01m[\x1b[01m\x1b[38;5;93;01m+\x1b[01m\x1b[38;5;211;01m] \x1b[01m\x1b[38;5;255;01m[\x1b[01m\x1b[38;5;93;01m+\x1b[01m\x1b[38;5;211;01m]'
    bytes_expected_0 = b'[+] [+] '

    # Call the function
    int_0 = len_without_ansi(bytes_0)

    # Check if function returned expected value

# Generated at 2022-06-25 17:43:32.928300
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[2K\x1b[38;5;207m'
    str_1 = '\x1b[38;5;209m'
    str_2 = '\x1b[0m\x1b[38;5;191m\x1b[1m\n'
    str_3 = '\x1b[0m'
    str_4 = '\x1b[38;5;191m\x1b[1m\x1b[2K\x1b[38;5;207m'

# Generated at 2022-06-25 17:43:36.452103
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Setup
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    expected = 6

    # Exercise
    actual = len_without_ansi(text)

    # Verify
    assert actual == expected


# Generated at 2022-06-25 17:43:45.252067
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi([b'\x8a\xe5\x18\x85']) == 4
    assert len_without_ansi([b'\x8a\xe5\x18\x85', b'\xaa\x18\x85\xff']) == 8
    assert len_without_ansi(b'\x8a\xe5\x18\x85\xaa\x18\x85\xff') == 8
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi([]) == 0



# Generated at 2022-06-25 17:43:47.251505
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = "example"
    expected = len(text)
    actual = len_without_ansi(text)
    assert expected == actual



# Generated at 2022-06-25 17:43:49.345998
# Unit test for function len_without_ansi
def test_len_without_ansi():
    bytes_0 = b'\x8a\xe5\x18\x85'
    int_0 = len_without_ansi(bytes_0)



# Generated at 2022-06-25 17:44:10.760027
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-25 17:44:12.303498
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = 'foobar'
    expected_value = 6
    actual_value = len_without_ansi(seq)
    assert actual_value == expected_value
    return actual_value


# Generated at 2022-06-25 17:44:16.215092
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    result = len_without_ansi(text)
    assert result == 6

test_case_0()
test_len_without_ansi()



# Generated at 2022-06-25 17:44:26.153759
# Unit test for function len_without_ansi
def test_len_without_ansi():
    bytes_0 = b'\x8a\xe5\x18\x85'
    int_0 = len_without_ansi(bytes_0)
    assert int_0 == 4

    bytes_1 = b':;9\x9a'
    int_1 = len_without_ansi(bytes_1)
    assert int_1 == 4

    bytes_2 = b'80<\x0f;'
    int_2 = len_without_ansi(bytes_2)
    assert int_2 == 4

    bytes_3 = b'\x9dY\xf7\x94\xcdK\xa2'
    int_3 = len_without_ansi(bytes_3)
    assert int_3 == 7


# Generated at 2022-06-25 17:44:37.537115
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6, 'Failed!'
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mba\x1b[38;5;209mr\x1b[0m') == 6, 'Failed!'
    assert len_without_ansi('\x1b[38;5;209m\x1b[0mfoo\x1b[38;5;209m\x1b[0mba\x1b[38;5;209m\x1b[0mr\x1b[38;5;209m\x1b[0m') == 6, 'Failed!'

# Generated at 2022-06-25 17:44:40.185641
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    result = len_without_ansi(text)
    assert result == 6



# Generated at 2022-06-25 17:44:48.666552
# Unit test for function len_without_ansi
def test_len_without_ansi():
    out_1 = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert out_1 == 6
    out_2 = len_without_ansi('\x1b[38;5;209mf\x1b[38;5;208mo\x1b[38;5;207mo\x1b[38;5;206mb\x1b[38;5;205ma\x1b[38;5;204mr\x1b[0m')
    assert out_2 == 6
    out_3 = len_without_ansi(['\x1b[38;5;209m', 'f', 'o', 'o', 'b', 'a', 'r', '\x1b[0m'])
    assert out_3 == 6

# Generated at 2022-06-25 17:44:59.094142
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    (p[5])
    """
    def function_0():
        assert len_without_ansi('test') == 4

    def function_1():
        assert len_without_ansi(['test']) == 4

    def function_2():
        assert len_without_ansi(['test', 'test2']) == 8

    def function_3():
        text = '\x1b[38;5;209mfoobar\x1b[0m'
        assert len_without_ansi(text) == 6

    def function_4():
    #    assert len_without_ansi(b'\x8a\xe5\x18\x85') == 4
        return()

    functions = [function_0, function_1, function_2, function_3, function_4]

# Generated at 2022-06-25 17:45:01.964608
# Unit test for function len_without_ansi
def test_len_without_ansi():
    bytes_0 = b'\x8a\xe5\x18\x85'
    test_len_without_ansi_0(bytes_0)

# Called from test_len_without_ansi

# Generated at 2022-06-25 17:45:04.877152
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    n = len_without_ansi(text)
    return n == 6

test_case_0()


# Generated at 2022-06-25 17:45:26.753935
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()



# Generated at 2022-06-25 17:45:28.565282
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()

####################################################################
# TEXTWRAPPING FUNCTIONS
####################################################################


# Generated at 2022-06-25 17:45:30.520156
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:45:34.745038
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    expected = 6
    actual = len_without_ansi(text)
    assert actual == expected, 'Expected: {}, Actual: {}'.format(expected, actual)


# Generated at 2022-06-25 17:45:36.010407
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(b'test') == 4


# Generated at 2022-06-25 17:45:38.385403
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:45:44.898181
# Unit test for function len_without_ansi
def test_len_without_ansi():
    b'Check that len_without_ansi does not fail'
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(b'\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi([b'\x1b[38;5;209m', b'foobar', b'\x1b[0m']) == 6


# Generated at 2022-06-25 17:45:46.361196
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_passed = True
    test_case_0()
    return test_passed


# Generated at 2022-06-25 17:45:53.975770
# Unit test for function len_without_ansi
def test_len_without_ansi():
    plain_text = 'foobar'
    assert len(plain_text) == 6
    assert len_without_ansi(plain_text) == 6
    plain_text = 'foo\x1b[33m\x1b[1mbar\x1b[0m'
    assert len(plain_text) == 12
    assert len_without_ansi(plain_text) == 6
    plain_text = '\x1b[33m\x1b[1mfoo\x1b[0mbar'
    assert len(plain_text) == 12
    assert len_without_ansi(plain_text) == 6


# Generated at 2022-06-25 17:45:58.121238
# Unit test for function len_without_ansi
def test_len_without_ansi():
    b = b'"'
    assert len_without_ansi(b) == 0

# Compiled regex for detecting ANSI control codes.
_ANSI_RE = re.compile('(\x1b\\[[0-9;:]+[ABCDEFGHJKSTfhilmns])')



# Generated at 2022-06-25 17:47:32.544735
# Unit test for function len_without_ansi
def test_len_without_ansi():
    bytes_1 = b'\x8a\xe5\x18\x85'
    # In the case of a string
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    # In the case of a sequence of strings
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', 'baz']) == 9
    assert len_without_ansi([
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[48;5;208mbaz\x1b[0m',
        '\x1b[38;5;208mqux\x1b[0m',
    ]) == 12

# Generated at 2022-06-25 17:47:36.758669
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_str0 = '\x1b[38;5;209mfoobar\x1b[0m'
    test_str1 = '\x1b[38;5;209mfoobar\x1b[0m'

    assert len_without_ansi(test_str0) == 6
    assert len_without_ansi([test_str0]) == 6

    assert len_without_ansi(test_str1) == 6
    assert len_without_ansi([test_str1]) == 6



# Generated at 2022-06-25 17:47:47.347425
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m', '!']) == 7

    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 9
    assert len_without_ansi

# Generated at 2022-06-25 17:47:53.038358
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m', 'baz']
    assert len_without_ansi(text) == 14


# Generated at 2022-06-25 17:48:01.138324
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('Hello world') == 11
    assert len_without_ansi('Hello, \x1b[1;30mworld\x1b[0m!') == 11
    assert len_without_ansi([
        'Hello, ',
        '\x1b[1;30m',
        'world',
        '\x1b[0m',
        '!'
    ]) == 11
    assert len_without_ansi('Hello， 世界') == 11
    assert len_without_ansi([
        'Hello， ',
        '\x1b[1;30m',
        '世界',
        '\x1b[0m',
        '!'
    ]) == 11

# Generated at 2022-06-25 17:48:03.046535
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6


# Generated at 2022-06-25 17:48:09.014823
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209m') == 0

# Test docstring examples for function len_without_ansi

# Generated at 2022-06-25 17:48:09.632307
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert True


# Generated at 2022-06-25 17:48:15.839950
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    text2 = '\x1b[38;5;209mfoobar\x1b[0m'
    text3 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi([text, text2, text3]) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    text2 = '\x1b[38;5;209mfoobar\x1b[0m'

# Generated at 2022-06-25 17:48:23.550098
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    # Test for exceptions
    with raises(TypeError):
        len_without_ansi([])
    with raises(TypeError):
        len_without_ansi([1, 2, 3])
    # Test for return type
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    result = len_without_ansi(text)
    assert isinstance(result, int)
    assert result == 6


# Generated at 2022-06-25 17:50:03.813748
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 20
    seq_0 = ['\x1b[38;5;209mfoobar\x1b[0m']
    ret_1 = len_without_ansi(seq_0)
    assert ret_1 == 6



# Generated at 2022-06-25 17:50:09.764499
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 20
    ansi_text_wrapper_0 = AnsiTextWrapper(int_0)
    str_0 = '\x1b[38;5;209mfoobar'
    str_1 = '\x1b[0m'
    str_2 = str_0 + str_1
    int_2 = len_without_ansi(str_2)
    int_1 = 6
    assert(int_1 == int_2)
    ansi_text_wrapper_0.width = int_1
    ansi_text_wrapper_0.width = int_2


# Generated at 2022-06-25 17:50:15.375389
# Unit test for function len_without_ansi
def test_len_without_ansi():
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(_text) == 6
    _text = '\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(_text) == 12


# Generated at 2022-06-25 17:50:26.477333
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Make sure argument is not changed when using int as seq
    seq: int = 10
    seq_copy = seq
    len_without_ansi(seq_copy)
    assert seq == seq_copy

    # Test with ANSI code in sequence
    text: str = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi(text)

    # Test with ANSI code in sequence
    list_0 = ['\x1b[38;5;209mfoobar\x1b[0m']
    len_without_ansi(list_0)

    # Test for empty string
    text: str = ''
    len_without_ansi(text)

    # Test for empty list
    list_1: List[Optional[str]] = []
    len_without

# Generated at 2022-06-25 17:50:28.972822
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert cast(int, len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')) == cast(int, 6)


# Generated at 2022-06-25 17:50:35.939920
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    assert len_without_ansi('\\x1b[38;5;209mfoo\\x1b[0mbar') == 6
    assert len_without_ansi('\\x1b[38;5;209mf\\x1b[0moo\\x1b[0m') == 3
    assert len_without_ansi(['foo', 'bar', 'baz']) == 9


# Generated at 2022-06-25 17:50:43.412783
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = '\x1b[38;5;203moops\x1b[0m\x1b[38;5;204mfooo\x1b[0m\x1b[38;5;205moolaboola\x1b[0m'
    assert len_without_ansi(text) == 17

    text = '\x1b[38;5;203moops\x1b[0m'
    assert len_without_ansi(text) == 5


# Generated at 2022-06-25 17:50:45.710450
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("abcdefg") == 7
    assert len_without_ansi("abcdefg\x1b[1;34m") == 7


# Generated at 2022-06-25 17:50:48.357544
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    expected_output = 6
    actual_output = len_without_ansi(text)
    assert actual_output == expected_output


# Generated at 2022-06-25 17:50:49.046415
# Unit test for function len_without_ansi
def test_len_without_ansi():
    pass

