

# Generated at 2022-06-25 17:42:31.264483
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:42:39.256975
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from random import randint
    from random import randrange
    from random import shuffle
    from random import choice
    from random import uniform
    from collections import defaultdict
    from copy import deepcopy
    from decimal import Decimal
    from fractions import Fraction
    from math import floor
    from math import sqrt
    from os import urandom
    from random import sample
    from random import seed
    from random import gauss
    from random import triangular

    def get_num(int_0, int_1):
        return randint(int_0, int_1)

    def get_num_0(int_0):
        return triangular(int_0, int_0 * 2)

    def get_num_1(int_0):
        return triangular(int_0 * (1 / 2), int_0)


# Generated at 2022-06-25 17:42:40.055097
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:42:50.658457
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test 0
    int_0 = 2573
    str_0 = "\\x1b[38;5;209mfoobar\\x1b[0m"
    str_1 = "foobar"
    str_2 = "\\x1b[38;5;209mf\\x1b[0m"
    list_0 = [str_0]
    list_1 = [str_1]
    list_2 = [str_2]
    list_3 = [str_0, int_0]
    list_4 = [str_1, int_0]
    list_5 = [str_2, int_0]
    object_0 = len_without_ansi(int_0)
    object_1 = len_without_ansi(str_0)
    object_2 = len_without_

# Generated at 2022-06-25 17:42:59.617298
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(2573) == 0
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209m', 'foobar', '\x1b[0m')) == 6



# Generated at 2022-06-25 17:43:09.637223
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from typing import List

    text_0: str = '\x1b[38;5;209mfoobar\x1b[0m'
    text_0_0: str = 'foobar'
    text_1: str = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    text_1_0: str = 'foobar'
    text_2: str = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;204mbar\x1b[0m'

# Generated at 2022-06-25 17:43:11.943311
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:43:13.489917
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 2573
    assert len_without_ansi(int_0) == 4



# Generated at 2022-06-25 17:43:23.360239
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m') == 3
    assert len_without_ansi('\x1b[38;5;209m\x1b[0m') == 0
    assert len_without_ansi('\x1b[38;5;209mf\x1b[0m') == 1
    assert len_without_ansi(['\x1b[38;5;209mf\x1b[0m']) == 1
    assert len_

# Generated at 2022-06-25 17:43:30.045180
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 2573
    assert(len_without_ansi(int_0) == len(int_0))
    int_2 = ("\x1b[38;5;209mfoobar\x1b[0m")
    assert(len_without_ansi(int_2) == 6)
    int_3 = ("\x1b[38;5;209mfoo\x1b[0mbar")
    assert(len_without_ansi(int_3) == 6)
    int_4 = ("\x1b[38;5;209mfoobar\x1b[0m",)
    assert(len_without_ansi(int_4) == 6)
    int_5 = ('\x1b[38;5;209mfoo\x1b[0mbar',)
   

# Generated at 2022-06-25 17:44:05.324390
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(2573) == 4


# Generated at 2022-06-25 17:44:10.502132
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Very simple test to check exception is raised
    int_0 = 2573
    with pytest.raises(ValueError):
      len_without_ansi(int_0)

if __name__ == "__main__":
    test_len_without_ansi()
    test_case_0()

# TODO: maybe drop this?
__all__ = ['len_without_ansi']

# If the python version is >= 3.8
if hexversion >= 0x03080000:
    from functools import cached_property
else:
    from .decorators import cached_property  # type: ignore[misc]


# Generated at 2022-06-25 17:44:13.608316
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(text_0)
    assert int_0 == 6


# Generated at 2022-06-25 17:44:24.293885
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi"""

    # Test case 0
    int_0 = 2573
    int_1 = len_without_ansi(int_0)
    assert int_1 == 4

    # Test case 1
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_2 = len_without_ansi(str_0)
    assert int_2 == 6

    # Test case 2
    str_1 = '\x1b[0m\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209m'
    int_3 = len_without_ansi(str_1)
    assert int_3 == 6

    # Test case 3

# Generated at 2022-06-25 17:44:26.780312
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert int_0 == 6


# Generated at 2022-06-25 17:44:38.233048
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("") == 0
    assert len_without_ansi("Hello World") == 11
    assert len_without_ansi("Hello World\n") == 12
    assert len_without_ansi("Hello\tWorld\n") == 12
    assert len_without_ansi("Hello\nWorld\n") == 11
    assert len_without_ansi("Hello\nWorld\n\n") == 11
    assert len_without_ansi("Hello\nWorld") == 11
    assert len_without_ansi("Hello\nWorld\n\n\n") == 11
    assert len_without_ansi("\nHello") == 6
    assert len_without_ansi("\nHello\n") == 7
    assert len_without_ansi("Hello\n\n") == 6
    assert len

# Generated at 2022-06-25 17:44:47.727615
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(
        '\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    char_0 = '\x1b'
    int_0 = len_without_ansi(char_0)
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m', 'foo']) == 9

# Generated at 2022-06-25 17:44:50.258029
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = 2573
    int_1 = len_without_ansi(int_0)
    assert int_1 == 3



# Generated at 2022-06-25 17:44:50.781206
# Unit test for function len_without_ansi
def test_len_without_ansi():
    pass


# Generated at 2022-06-25 17:45:01.038658
# Unit test for function len_without_ansi
def test_len_without_ansi():
    lst_0: List[str] = ['\x1b[38;5;209mfoobar\x1b[0m']
    int_0 = len_without_ansi(lst_0)
    str_0 = str()
    str_1 = str()
    str_2 = str()
    str_3 = str()
    str_4 = str()
    str_5 = str()
    str_6 = str()
    str_7 = str()
    str_8 = str()
    str_9 = str()
    str_10 = str()
    str_11 = str()
    str_12 = str()
    str_13 = str()
    str_14 = str()
    str_15 = str()
    str_16 = str()
    str_17 = str()
    str_

# Generated at 2022-06-25 17:47:45.208603
# Unit test for function len_without_ansi
def test_len_without_ansi():
    len_without_ansi(2573)


# Generated at 2022-06-25 17:47:46.130554
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:47:49.530877
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Both args are of type int
    assert len_without_ansi(2573) == len(str(2573))
    # Both args are of type str
    assert len_without_ansi("2573") == len("2573")
    # Both args are of type list
    assert len_without_ansi([45, 8, 94]) == len(str([45, 8, 94]))
    # Both args are of type tuple
    assert len_without_ansi((38, 2, 6, 2)) == len(str((38, 2, 6, 2)))
    # First arg is of type int, second arg is of type str
    assert len_without_ansi(2573, "iamastring") == len(str(2573) + "iamastring")
    # First arg is of type int, second arg is of type list


# Generated at 2022-06-25 17:47:55.942305
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(0) == 0
    assert len_without_ansi('') == 0
    assert len_without_ansi(' ') == 1
    assert len_without_ansi('a') == 1
    assert len_without_ansi('hello world') == 11
    assert len_without_ansi('hello, \x1b[38;5;116mworld\x1b[0m') == 5
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar', '\x1b[0m']) == 6



# Generated at 2022-06-25 17:47:57.113625
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Try case 0
    test_case_0()


# Generated at 2022-06-25 17:48:07.669760
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Point out the action expected
    print("test_len_without_ansi()")
    int_0 = 2573
    int_1 = len_without_ansi(int_0)
    assert (int_1 == 4)

    # Point out the action expected
    print("test_len_without_ansi()")
    str_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert (int_0 == 6)

    # Point out the action expected
    print("test_len_without_ansi()")
    str_0 = "test string"
    int_0 = len_without_ansi(str_0)
    assert (int_0 == 11)


# Generated at 2022-06-25 17:48:09.965886
# Unit test for function len_without_ansi
def test_len_without_ansi():
    result = len_without_ansi(2573)
    expected = 4
    assert result == expected, "Expected: {0}, Got: {1}".format(expected, result)




# Generated at 2022-06-25 17:48:16.687465
# Unit test for function len_without_ansi
def test_len_without_ansi():
#    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    str_0 = 'foofasdasd'
    #assert(str_0.endswith("\x1b[0m") == False)
    int_0 = len_without_ansi(str_0)
    return(int_0)



# Generated at 2022-06-25 17:48:18.337070
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:48:25.998433
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = len_without_ansi('abc')
    int_1 = len_without_ansi([])
    int_2 = len_without_ansi('abc')
    int_3 = len_without_ansi('abc')
    int_4 = len_without_ansi('abc')
    int_5 = len_without_ansi([])
    int_6 = len_without_ansi([])
    int_7 = len_without_ansi('abc')
    int_8 = len_without_ansi('abc')
    int_9 = len_without_ansi('')
    int_10 = len_without_ansi('')
    int_11 = len_without_ansi('')
    int_12 = len_without_ansi('')
    int_13 = len_