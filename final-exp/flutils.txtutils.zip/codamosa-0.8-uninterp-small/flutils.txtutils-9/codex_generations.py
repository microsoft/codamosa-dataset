

# Generated at 2022-06-25 17:42:13.408422
# Unit test for function len_without_ansi
def test_len_without_ansi():
    bool_0 = False
    int_0 = len_without_ansi(bool_0)
    assert int_0 == 0



# Generated at 2022-06-25 17:42:22.622430
# Unit test for function len_without_ansi
def test_len_without_ansi():

    bool_0 = False
    int_0 = len_without_ansi(bool_0)
    bool_1 = True
    int_1 = len_without_ansi(bool_1)
    str_0 = 'foobar'
    int_2 = len_without_ansi(str_0)
    str_1 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_3 = len_without_ansi(str_1)
    str_2 = '\x1b[38;5;209mfoo\x1b[0m'
    str_3 = 'bar'
    int_4 = len_without_ansi([str_2, str_3])

# Generated at 2022-06-25 17:42:33.252245
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;208mf\x1b[38;5;209mo\x1b[38;5;210mo\x1b[38;5;211mb\x1b[38;5;212ma\x1b[38;5;213mr\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo') == 3
    assert len_without_ansi('foo\x1b[0m') == 3
    assert len_without_ansi('\x1b[38;9m') == 0
    assert len_without_ansi('foo')

# Generated at 2022-06-25 17:42:38.628199
# Unit test for function len_without_ansi
def test_len_without_ansi():
    for i in range(10):
        assert len_without_ansi(0) == 0

_ansi_textwrap_attrs: List[str] = list(TextWrapper.__dict__)
# Remove list of attrs which is not needed
for attr in [
    '_fix_sentence_endings',
    '_munge_whitespace',
    'replace_whitespace',
    '_drop_whitespace',
]:
    _ansi_textwrap_attrs.remove(attr)


# Generated at 2022-06-25 17:42:40.491805
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6


# Generated at 2022-06-25 17:42:51.082311
# Unit test for function len_without_ansi
def test_len_without_ansi():
    pass
    #App.Trace( 'test_len_without_ansi' )
    #App.Trace( '         len_without_ansi("\x1b[ABCDEFGHJKSTfhilmns") True' )
    #App.Trace( '            len_without_ansi("\x1b[ABCDEFGHJKSTfhilmns") ' + str(len_without_ansi("\x1b[ABCDEFGHJKSTfhilmns")))
    #App.Trace( '         len_without_ansi("foobar") True' )
    #App.Trace( '            len_without_ansi("foobar") ' + str(len_without_ansi("foobar")))
    #App.Trace( '         len_without_ansi("\x1

# Generated at 2022-06-25 17:42:54.346175
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Test case for function len_without_ansi
    """
    bool_0 = False
    int_0 = len_without_ansi(bool_0)



# Generated at 2022-06-25 17:43:04.109009
# Unit test for function len_without_ansi
def test_len_without_ansi():
    bool_0 = False
    int_0 = len_without_ansi(bool_0)
    assert int_0 == 0
    bool_1 = True
    int_1 = len_without_ansi(bool_1)
    assert int_1 == 0
    int_2 = len_without_ansi(1.0)
    assert int_2 == 0
    int_3 = len_without_ansi(1)
    assert int_3 == 1
    int_4 = len_without_ansi([1])
    assert int_4 == 1
    int_5 = len_without_ansi('1')
    assert int_5 == 1


# Generated at 2022-06-25 17:43:09.045246
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('') == 0
    assert len_without_ansi(('\x1b[38;5;209m', 'foobar', '\x1b[0m')) == 6


# noinspection PyPep8Naming

# Generated at 2022-06-25 17:43:11.120576
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test 1
    bool_0 = True
    int_0 = len_without_ansi(bool_0)


# Generated at 2022-06-25 17:44:09.601681
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:44:20.470962
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Converts text to all lower case (a-z).
    #text = ''.join(re.findall('[a-z]+', raw_text))
    text = 'hello world'
    assert len_without_ansi(text) == len('helloworld')
    text = 'hello'
    assert len_without_ansi(text) == len('hello')
    text = 'helloo world'
    assert len_without_ansi(text) == len('helloo world')
    text = 'hello woorld'
    assert len_without_ansi(text) == len('hello woorld')
    text = 'hello woorld'
    assert len_without_ansi(text) == len('hello woorld')
    text = 'hello worrld'
    assert len_without_ansi(text) == len

# Generated at 2022-06-25 17:44:22.592304
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:44:28.719842
# Unit test for function len_without_ansi
def test_len_without_ansi():
    print()
    print(len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m'))
    print(len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']))
    print(len_without_ansi(['\x1b[31m', 'foobar', '\x1b[0m']))
    print(len_without_ansi(['\x1b[31m', 'foo', '\x1b[33mbar', '\x1b[0m']))
    print(len_without_ansi('     '))



# Generated at 2022-06-25 17:44:31.560624
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:44:39.345586
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    expected_output = 6
    actual_output = len_without_ansi(text)

    try:
        assert actual_output == expected_output
        print('Test 0 passed')
    except:
        print('Test 0 failed')
        print('len_without_ansi({}) = {}'.format(text, actual_output))
        print('which disagrees with expected output {}'.format(expected_output))

# Test output of len_without_ansi when input is a list of strings

# Generated at 2022-06-25 17:44:41.710713
# Unit test for function len_without_ansi
def test_len_without_ansi():
    t = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(t) == 6


# Generated at 2022-06-25 17:44:49.960203
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import logging

    test_cases = ((['\x1b[38;5;209m', 'foobar', '\x1b[0m'], 6),
                  (['\x1b[38;5;209m', 'foo', '\x1b[0m', 'bar'], 6),
                  (['foo', '\x1b[38;5;209m', 'bar', '\x1b[0m', 'baz'], 9),
                  (['foo', '\x1b[38;5;209m', 'bar', '\x1b[0m', 17], 9))

    for case in test_cases:
        seq = case[0]
        expected = case[1]
        result = len_without_ansi(seq)


# Generated at 2022-06-25 17:44:57.214269
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;1mf\x1b[0mbar\x1b[38;5;209mfoobar\x1b[0m') == 8
    assert len_without_ansi(['foo', 'bar', '\x1b[38;5;209mfoobar\x1b[0m']) == 11


# Generated at 2022-06-25 17:44:59.516149
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_sequence = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(test_sequence) == 6


# Generated at 2022-06-25 17:45:41.825874
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi([]) == 0
    assert len_without_ansi([""]) == 0
    assert len_without_ansi(["a"]) == 1
    assert len_without_ansi(["ab"]) == 2
    assert len_without_ansi("ab") == 2
    assert len_without_ansi("") == 0
    assert len_without_ansi("a") == 1
    assert len_without_ansi("ab") == 2
    assert len_without_ansi("a" * 10) == 10
    assert len_without_ansi("ab" * 10) == 20
    assert len_without_ansi(["a" * 10]) == 10
    assert len_without_ansi(["ab" * 10]) == 20

# Generated at 2022-06-25 17:45:44.095418
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_0 = AnsiTextWrapper()
    assert len_without_ansi(ansi_text_wrapper_0._text) == 6


# Generated at 2022-06-25 17:45:53.497871
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert 3 == len_without_ansi(['a', '\x1b[38;5;209mb', 'c', '\x1b[0m'])
    assert 3 == len_without_ansi(['a', '\x1b[38;5;209mb', 'c', '\x1b[0m', 'd'])
    assert 3 == len_without_ansi(['a', '\x1b[38;5;209mb', 'c', '\x1b[0m', 'd', 'e'])
    assert 3 == len_without_ansi(['a', '\x1b[38;5;209mb', '\x1b[0mc', '\x1b[0md'])

# Generated at 2022-06-25 17:45:56.227407
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi(text) == 6



# Generated at 2022-06-25 17:45:59.122631
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    # Check if length of text_0 without ANSI codes is 6
    assert len_without_ansi(text_0) == 6


# Generated at 2022-06-25 17:46:02.130218
# Unit test for function len_without_ansi
def test_len_without_ansi():
    simple_text = 'foobar'
    expected_length = len(simple_text)
    actual_length = len_without_ansi(simple_text)
    assert expected_length == actual_length


# Generated at 2022-06-25 17:46:05.387522
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_string = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(ansi_string) == 6


# Generated at 2022-06-25 17:46:09.356171
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    text = ['\\x1b[38;5;209mfoobar', 'baz\\x1b[0m']
    assert len_without_ansi(text) == 9



# Generated at 2022-06-25 17:46:12.703486
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('abc') == 3
    assert len_without_ansi(['abc', 'xyz']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:46:14.906335
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('Hello') == len('Hello') # Edge case
    assert len_without_ansi('World') == len('World') # Edge case


# Generated at 2022-06-25 17:47:55.871513
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:47:57.700677
# Unit test for function len_without_ansi
def test_len_without_ansi():
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(_text) == 6


# Generated at 2022-06-25 17:47:59.990457
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:48:01.853885
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(test) == 6


# Generated at 2022-06-25 17:48:09.192051
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = 'abcd'
    text_list = ['abcd']
    text_list_with_ansi = 'ab\x1b[38;5;209mcd'
    output = len_without_ansi(text)
    assert output == 4
    output = len_without_ansi(text_list)
    assert output == 4
    output = len_without_ansi(text_list_with_ansi)
    assert output == 2



# Generated at 2022-06-25 17:48:12.291531
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(['\x1b[31;51mfoobar\x1b[0m', '\x1b[38;5;255m\x1b[48;5;255m\x1b[30mfoobar\x1b[0m\x1b[0m']) == 18


# Generated at 2022-06-25 17:48:15.030792
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_1 = "   Setting up a Python dev environment    "
    text_2 = "Setting up a Python dev environment"
    assert len_without_ansi(text_1) == len_without_ansi(text_2)
    #assert len_without_ansi(text_1) == len(text_2)



# Generated at 2022-06-25 17:48:19.293792
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:48:21.162160
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:48:28.167267
# Unit test for function len_without_ansi
def test_len_without_ansi():
    def wrapper(expected, actual):
        assert expected == actual, 'expected ' + \
            str(expected) + ', got ' + str(actual)

# Generated at 2022-06-25 17:50:30.686686
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:50:32.710452
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:50:34.232600
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6


# Generated at 2022-06-25 17:50:36.187302
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:50:41.523049
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test 1 - normal case
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    result = len_without_ansi(text)
    assert result == 6

    # Test 2 - normal case with list
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    result = len_without_ansi(text)
    assert result == 12
    

# Generated at 2022-06-25 17:50:49.103295
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_0 = AnsiTextWrapper()
    # str
    assert len_without_ansi('')                                 == 0
    assert len_without_ansi(' ')                                == 1
    assert len_without_ansi('  ')                               == 2
    assert len_without_ansi(' ')                                == 1
    assert len_without_ansi('  ')                               == 2
    assert len_without_ansi('   ')                              == 3
    assert len_without_ansi('foo')                              == 3
    assert len_without_ansi('foo  ')                            == 3
    assert len_without_ansi('foo     ')                         == 3

# Generated at 2022-06-25 17:50:57.742399
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text1 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text1) == 6
    text2 = '\x1b[38;5;209mdog\x1b[0m'
    assert len_without_ansi(text2) == 3
    text3 = '\x1b[38;5;209mcat\x1b[0m'
    assert len_without_ansi(text3) == 3
    text4 = '\x1b[38;5;209mgoose\x1b[0m'
    assert len_without_ansi(text4) == 5


# Generated at 2022-06-25 17:51:01.625482
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('123456') == 6
    assert len_without_ansi('123  456') == 7
    assert len_without_ansi(['123', '4', '56']) == 6


# noinspection PyUnresolvedReferences

# Generated at 2022-06-25 17:51:03.776571
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    text_len = len_without_ansi(text)
    assert text_len == 6



# Generated at 2022-06-25 17:51:05.664230
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
