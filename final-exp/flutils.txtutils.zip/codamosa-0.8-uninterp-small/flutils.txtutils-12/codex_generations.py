

# Generated at 2022-06-25 17:43:06.581120
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = "o`F)H^'X@!"
    assert len_without_ansi(str_0) == len(str_0)



# Generated at 2022-06-25 17:43:08.917377
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:43:11.333676
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_1 = "o`F)H^'X@!"
    num_5 = len_without_ansi(str_1)
    assert num_5 == 10


# Generated at 2022-06-25 17:43:18.542796
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from random import sample
    from flutils.txtutils import len_without_ansi
    from flutils.txtutils import AnsiTextWrapper
    txt = 'this is some example text'
    class_0 = AnsiTextWrapper(txt)
    assert len_without_ansi([txt]) == 22
    assert len_without_ansi(class_0) == 22
    # Sequence of length 1
    lst_0 = sample('abcdefgh', 1)
    assert len_without_ansi(lst_0) == 1
    assert len_without_ansi(('a',)) == 1
    # Sequence of length 3
    lst_1 = sample('abcdefgh', 3)
    assert len_without_ansi(lst_1) == 3

# Generated at 2022-06-25 17:43:21.531841
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = "o`F)H^'X@!"
    ansi_text_wrapper_0 = AnsiTextWrapper(str_0)


# Generated at 2022-06-25 17:43:23.116766
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6

##############################################################################

# Generated at 2022-06-25 17:43:25.145996
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = "o`F)H^'X@!"
    ansi_text_wrapper_0 = AnsiTextWrapper(str_0)


# Generated at 2022-06-25 17:43:33.736455
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq_0 = "o`F)H^'X@!"
    ansi_text_wrapper_0 = AnsiTextWrapper(seq_0)
    assert len_without_ansi(ansi_text_wrapper_0) == 10

    seq_1 = ["<>\"'{}:\"<>", ". {-=} .,!@#$%^&*()/<>{}[]|\\?", "0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM"]
    ansi_text_wrapper_1 = AnsiTextWrapper(seq_1)
    assert len_without_ansi(ansi_text_wrapper_1) == 212

    # Must fail
    seq_2 = "j"
    ansi_text

# Generated at 2022-06-25 17:43:44.208557
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = "k)NyT*LT(M{;&!n(M*MZn)pY$=+."
    sequence_0 = list()
    int_0 = len_without_ansi(sequence_0)
    str_1 = "C(o<<=Dv0+Wb]1^Je`4<XG"
    int_1 = len_without_ansi(str_1)
    str_2 = "5)+5;5:5<5=5>5?"
    bool_0 = str_2 in sequence_0
    str_3 = ";f[4pX/j|H[>RbS2)I'N&e3JjN=t`l)D]jM$*XOqH"
    sequence_1 = tuple()
    int_2

# Generated at 2022-06-25 17:43:51.026568
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = "o`F)H^'X@!"
    ansi_str = "\x1b[38;5;209mfoobar\x1b[0m"
    seq_0 = ["\x1b[38;5;209mfoobar\x1b[0m", "m@ljf.\n.y,"]
    seq_1 = [str_0, ansi_str, "m@ljf.\n.y,"]
    seq_2 = ["\x1b[38;5;209mfoobar\x1b[0m", str_0, "m@ljf.\n.y,"]
    out_0 = len_without_ansi(seq_0)
    out_1 = len_without_ansi(seq_1)

# Generated at 2022-06-25 17:45:31.580471
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("o`F)H^'X@!") == 10


# Generated at 2022-06-25 17:45:39.704923
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_0 = AnsiTextWrapper()
    ansi_text_wrapper_0._reset()
    list_1 = []
    ansi_text_wrapper_0.ansi_codes = list_1
    str_0 = "o`F)H^'X@!"
    len_0 = len_without_ansi(str_0)
    assert len_0 == 11, len_0
    ansi_text_wrapper_0.eol = str_0
    len_0 = len_without_ansi(ansi_text_wrapper_0)
    assert len_0 == 0, len_0


# Generated at 2022-06-25 17:45:47.097536
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = "\\x1b[38;5;209mfoobar\\x1b[0m"
    ansi_text_wrapper_0 = AnsiTextWrapper(str_0)
    assert ansi_text_wrapper_0.width == 6
    str_1 = "~h~-=\\x1b[38;5;209mfoobar\\x1b[0m\\x1b[38;5;209mfoobar\\x1b[0m"
    ansi_text_wrapper_1 = AnsiTextWrapper(str_1)
    assert ansi_text_wrapper_1.width == 24



# Generated at 2022-06-25 17:45:50.479111
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = """"Joining the biotechnology industry would give me a chance to do
    something I love every day and also be part of a growing and valuable
    industry."""
    assert len_without_ansi(str_0) == 119


# Generated at 2022-06-25 17:45:53.375173
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = "\\x1b[38;5;209mfoobar\\x1b[0m"
    assert len_without_ansi(str_0) == 6


# Generated at 2022-06-25 17:45:59.551084
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Build SAX events
    str_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'
    # Initialize class AnsiTextWrapper
    ansi_text_wrapper_0 = AnsiTextWrapper()
    # Call method
    ansi_text_wrapper_0.len_without_ansi(str_0)
    # Verify the results
    assert(len_without_ansi(str_0))
    print("Test case passed!")



# Generated at 2022-06-25 17:46:05.036302
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_values_0 = [(b'\x8c\xc1\xbb\x15\xaf\x8b\x82\xeb\xef\xe6\x9c\xda\xf0\x06\xf6\xc8', )]
    # Call len_without_ansi()
    len_without_ansi(*test_values_0)


# Generated at 2022-06-25 17:46:13.464483
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = "o`F)H^'X@!"
    ansi_text_wrapper_0 = AnsiTextWrapper(str_0)
    str_1 = "o`F)H^'X@!"
    ansi_text_wrapper_1 = AnsiTextWrapper(str_1)
    str_2 = "o`F)H^'X@!"
    ansi_text_wrapper_2 = AnsiTextWrapper(str_2)
    str_3 = "o`F)H^'X@!"
    ansi_text_wrapper_3 = AnsiTextWrapper(str_3)
    str_4 = "o`F)H^'X@!"
    ansi_text_wrapper_4 = AnsiTextWrapper(str_4)

# Generated at 2022-06-25 17:46:17.812350
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out_0 = len_without_ansi(text)
    assert out_0 == 6



# Generated at 2022-06-25 17:46:21.222824
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    _text: str = cast(str, text)
    seq = [c for c in _ANSI_RE.split(_text) if c]


# Generated at 2022-06-25 17:51:05.399190
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert(len_without_ansi(str_0) == 6)


# Generated at 2022-06-25 17:51:08.283298
# Unit test for function len_without_ansi
def test_len_without_ansi():
    try:
        test_case_0()
    except Exception as e:
        print('\nError: ' + str(e))



# Generated at 2022-06-25 17:51:10.949026
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test 0
    str_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'
    out_0 = len_without_ansi(str_0)
    assert out_0 == 6

# Generated at 2022-06-25 17:51:22.234285
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(str_0) == 6
    str_1 = '\\x1b[48;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(str_1) == 6
    str_2 = 'foobar\\x1b[0m'
    assert len_without_ansi(str_2) == 6
    str_3 = '\\x1b[38;5;209mfoobar'
    assert len_without_ansi(str_3) == 6

# Generated at 2022-06-25 17:51:30.900967
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Case 0
    try:
        test_case_0()
    except:
        # AssertionError: AssertionError: AssertionError: 6 != 5
        # AssertionError: 6 != 8
        error_msg = 'test_case_0() raised an exception!'
        assert False, error_msg
    # Case 1