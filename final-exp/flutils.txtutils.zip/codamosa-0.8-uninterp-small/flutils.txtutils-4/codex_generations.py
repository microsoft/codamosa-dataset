

# Generated at 2022-06-25 17:42:41.039262
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from random import randint
    from timeit import timeit
    from timeit import Timer


# Generated at 2022-06-25 17:42:51.374649
# Unit test for function len_without_ansi
def test_len_without_ansi():
    print('Testing function len_without_ansi... ', end='')

    test_case_0()

    output = len_without_ansi('foo')
    assert(output == 3)

    output = len_without_ansi('foo bar')
    assert(output == 7)

    output = len_without_ansi('foo\\nbar')
    assert(output == 7)

    output = len_without_ansi('foo\nbar')
    assert(output == 7)

    output = len_without_ansi('foo\\tbar')
    assert(output == 7)

    output = len_without_ansi('foo\tbar')
    assert(output == 7)

    output = len_without_ansi('foo\\x07bar')
    assert(output == 7)

    output = len_without_ansi

# Generated at 2022-06-25 17:42:57.154095
# Unit test for function len_without_ansi
def test_len_without_ansi():
    tuple_0 = None
    list_0 = None
    str_0 = None
    assert len_without_ansi(list_0) == 0
    assert len_without_ansi(str_0) == 0
    assert len_without_ansi(set()) == 0
    assert len_without_ansi(tuple_0) == 0


# Generated at 2022-06-25 17:43:00.518919
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    expected = 6
    assert len_without_ansi(text) == expected
    return True



# Generated at 2022-06-25 17:43:08.571552
# Unit test for function len_without_ansi
def test_len_without_ansi():
    _tests = [
        'foobar',
        ['foo', 'bar'],
        '\x1b[38;5;209mfoobar\x1b[0m',
        ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209mbar\x1b[0m'],
        ['\x1b[38;5;209mfoo', 'bar\x1b[0m'],
    ]
    for test in _tests:
        test_case_0()
        assert len_without_ansi(test) == 6



# Generated at 2022-06-25 17:43:10.640970
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert callable(len_without_ansi)
    assert isinstance(
        test_case_0(), 
        int
    )



# Generated at 2022-06-25 17:43:13.116904
# Unit test for function len_without_ansi
def test_len_without_ansi():

    s = '\x1b[38;5;209mfoobar\x1b[0m'

    assert len_without_ansi(s) == 6



# Generated at 2022-06-25 17:43:14.052704
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert test_case_0() == 0



# Generated at 2022-06-25 17:43:16.683148
# Unit test for function len_without_ansi
def test_len_without_ansi():
    tuple_0 = None
    set_0 = {tuple_0, tuple_0, tuple_0, tuple_0}
    int_0 = len_without_ansi(set_0)



# Generated at 2022-06-25 17:43:25.936139
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('a') == 1
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('(foobar)') == 8
    assert len_without_ansi('\x1b[37mHello, world!\x1b[0m') == 13
    assert len_without_ansi(['\x1b[31mHello\x1b[0m', ',', ' ', '\x1b[34mworld!\x1b[0m']) == 13

# Generated at 2022-06-25 17:44:04.868570
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert int_0 == 6
    list_0 = ['\x1b[38;5;209mfoo', '\x1b[0mbar']
    int_1 = len_without_ansi(list_0)
    assert int_1 == 6
    # int_2 = len_without_ansi(str_0, list_0)
    # assert int_2 == 6
    str_1 = '\x1b[38;5;209mfoo\x1b[0mbar\x1b[0m'
    int_3 = len_without_ansi(str_1)
    assert int_3 == 6


# Generated at 2022-06-25 17:44:11.190480
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi([]) == 0
    assert len_without_ansi('') == 0
    assert len_without_ansi(['a', 'b', 'c']) == 3
    assert len_without_ansi('abc') == 3
    assert len_without_ansi(['ab', 'c']) == 3
    assert len_without_ansi(['a', 'bc']) == 3
    assert len_without_ansi(['a', 'b', 'c', 'd', 'e', 'f']) == 6
    assert len_without_ansi('abcdef') == 6
    assert len_without_ansi(['abc', 'def']) == 6
    assert len_without_ansi(['ab', 'cd', 'ef']) == 6

# Generated at 2022-06-25 17:44:14.617231
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert int_0 == 6



# Generated at 2022-06-25 17:44:17.301158
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # test
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-25 17:44:19.200328
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:44:22.399114
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from unittest.mock import patch
    with patch('builtins.print') as mock_print:
        test_case_0()
        assert mock_print.called is False


# Generated at 2022-06-25 17:44:23.250827
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:44:27.306522
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert int_0 == 6

# Class AnsiTextWrapper

# Generated at 2022-06-25 17:44:38.742901
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert int_0 == 6
    str_1 = '\x1b[38;5;209mfoo\x1b[0mbar'
    int_1 = len_without_ansi(str_1)
    assert int_1 == 6
    str_2 = 'f\x1b[38;5;209mbar'
    int_2 = len_without_ansi(str_2)
    assert int_2 == 4

# Generated at 2022-06-25 17:44:41.864561
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)

    assert int_0 == 6


# Generated at 2022-06-25 17:45:41.252830
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi."""
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'

    # A string
    int_0 = len_without_ansi(str_0)
    assert int_0 == 6

    # A tuple of strings
    int_1 = len_without_ansi((str_0, str_0))
    assert int_1 == 12



# Generated at 2022-06-25 17:45:48.697653
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert int_0 == 6
    int_1 = len_without_ansi(['bob', '\x1b[38;5;209mfoobar\x1b[0m', 'doll'])
    assert int_1 == 12
    int_2 = len_without_ansi(['bob', '\x1b[38;5;209mfoobar', '\x1b[0m', 'doll'])
    assert int_2 == 12



# Generated at 2022-06-25 17:45:49.583999
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert test_case_0() is None


# Generated at 2022-06-25 17:45:59.331786
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert 6 == len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert 18 == len_without_ansi(
        '\x1b[38;5;209mThe Fox and the Grapes\x1b[0m')
    assert 18 == len_without_ansi(
        '\x1b[38;5;209mThe Fox and the Grapes\x1b[0m')
    assert 0 == len_without_ansi(
        '\x1b[38;5;209m\x1b[0m')
    assert 0 == len_without_ansi(
        '\x1b[38;5;209m\x1b[0m')

# Generated at 2022-06-25 17:46:01.436836
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    import doctest
    doctest.testmod()



# Generated at 2022-06-25 17:46:02.979158
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:46:04.042256
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()



# Generated at 2022-06-25 17:46:12.363047
# Unit test for function len_without_ansi
def test_len_without_ansi():

    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    str_1 = 'baz'
    int_0 = len_without_ansi(str_0)
    int_1 = len_without_ansi(str_1)
    int_2 = len_without_ansi(str_0+str_1)
    int_3 = len_without_ansi([str_0,str_1])
    print(str_0)
    print(str_1)
    print(int_0)
    print(int_1)
    print(int_2)
    print(int_3)
    assert int_0 == 6
    assert int_1 == 3
    assert int_2 == 9
    assert int_3 == 9



# Generated at 2022-06-25 17:46:14.741475
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Unit testing for len_without_ansi
    """
    # Change this test case to point to a file that contains your expected
    # results from running this function with specified inputs.
    test_case_0()


# Generated at 2022-06-25 17:46:19.434517
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Run unit tests for the len_without_ansi function.
    """
    test_case_0();
    test_count = 0;
    test_count += 1;
    print('%d tests passed' % test_count)


# Generated at 2022-06-25 17:48:19.904715
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    int_1 = 6
    assert int_0 == int_1


# Generated at 2022-06-25 17:48:20.655116
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:48:22.395395
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest # type: ignore[import]
    with pytest.raises(TypeError):
        len_without_ansi(123)



# Generated at 2022-06-25 17:48:27.437124
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert int_0 == 6
    str_1 = ['\x1b[38;5;209mfoo\x1b[0m', 'bar', '\x1b[38;5;209mbaz\x1b[0m']
    int_1 = len_without_ansi(str_1)
    assert int_1 == 6


# Generated at 2022-06-25 17:48:32.142072
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(('\x1b[38;5;209mf', 'oob', 'ar\x1b[0m')) == 6


# Generated at 2022-06-25 17:48:39.231469
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    str_1 = '\x1b[38;5;209mfoobar'
    int_1 = len_without_ansi(str_1)
    str_2 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_2 = len_without_ansi(str_2)

# Generated at 2022-06-25 17:48:39.885873
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:48:41.471763
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert 6 == len_without_ansi(str_0)



# Generated at 2022-06-25 17:48:43.966634
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert int_0 == 6



# Generated at 2022-06-25 17:48:46.039267
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)



# Generated at 2022-06-25 17:49:55.902460
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert int_0 == 6


# Generated at 2022-06-25 17:49:56.742001
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:50:00.328726
# Unit test for function len_without_ansi
def test_len_without_ansi():
    print(test_case_0.__name__)
    try:
        test_case_0()
    except Exception:
        import sys
        print("FAIL: unexpected error:", sys.exc_info()[0])
    else:
        print("OK")

test_len_without_ansi()



# Generated at 2022-06-25 17:50:01.473738
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:50:04.716814
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foo\x1b[0m', 'bar\x1b[0m', 'baz']) == 9



# Generated at 2022-06-25 17:50:07.450630
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    str_1 = 'foobar'
    assert len_without_ansi(str_0) == len(str_1)



# Generated at 2022-06-25 17:50:15.937678
# Unit test for function len_without_ansi

# Generated at 2022-06-25 17:50:17.034531
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert test_case_0() == None



# Generated at 2022-06-25 17:50:27.802515
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    str_1 = '\x1b[38;5;209mfoobarbaz\x1b[0m'
    int_1 = len_without_ansi(str_1)
    str_2 = '\x1b[38;5;209mfoobarbaz\x1b[0m\x1b[m'
    int_2 = len_without_ansi(str_2)
    str_3 = '\x1b[38;5;209mfoobar\x1b[0m \x1b[38;5;209mfoobarbaz\x1b[0m'
    int_3

# Generated at 2022-06-25 17:50:30.308156
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    assert int_0 == (6)

