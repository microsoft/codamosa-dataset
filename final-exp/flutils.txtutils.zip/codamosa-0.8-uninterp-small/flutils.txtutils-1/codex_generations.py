

# Generated at 2022-06-25 17:42:26.852424
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()


# Generated at 2022-06-25 17:42:28.218507
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert callable(len_without_ansi)



# Generated at 2022-06-25 17:42:32.620483
# Unit test for function len_without_ansi
def test_len_without_ansi():
    sequence_0 = ["{{", "\\x1b[38;5;209mfoobar\\x1b[0m", "}}"]
    int_0 = len_without_ansi(sequence_0)
    int_1 = len_without_ansi("{{foobar}}")
    assert (int_0 == int_1)



# Generated at 2022-06-25 17:42:34.306603
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:42:36.324793
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:42:38.716653
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Placeholder for actual unit test
    """
    # sequence_0 = None
    # int_0 = len_without_ansi(sequence_0)
    test_case_0()

# Define class AnsiTextWrapper

# Generated at 2022-06-25 17:42:40.259655
# Unit test for function len_without_ansi
def test_len_without_ansi():
    sequence_0 = None
    int_0 = len_without_ansi(sequence_0)


# Generated at 2022-06-25 17:42:44.800133
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Tests for function len_without_ansi
    sequence_0 = "\\x1b[38;5;209mfoobar\\x1b[0m"
    int_0 = len_without_ansi(sequence_0)
    assert int_0 == 6


# Generated at 2022-06-25 17:42:53.438354
# Unit test for function len_without_ansi
def test_len_without_ansi():
    def test_case_0():
        sequence_0 = None
        int_0 = len_without_ansi(sequence_0)
    def test_case_1():
        sequence_0 = ["\x1b[38;5;209mfoobar\x1b[0m", "\x1b[31mfoo\x1b[0m", "\x1b[31mbar\x1b[0m"]
        int_0 = len_without_ansi(sequence_0)
    def test_case_2():
        sequence_0 = ["\x1b[31mfoo\x1b[0m", "''", "\x1b[31mbar\x1b[0m", "''"]
        int_0 = len_without_ansi(sequence_0)

# Generated at 2022-06-25 17:43:00.257597
# Unit test for function len_without_ansi
def test_len_without_ansi():
    sequence_0 = 'foobar'
    int_0 = len_without_ansi(sequence_0)
    # :: ExpectedOutput(assert.failed:assertion.false)
    assert int_0 == 7
    sequence_0 = ('foobar', 'foobar')
    int_0 = len_without_ansi(sequence_0)
    # :: ExpectedOutput(assert.failed:assertion.false)
    assert int_0 == 7


# Generated at 2022-06-25 17:43:26.055545
# Unit test for function len_without_ansi
def test_len_without_ansi():
    r"""Test case for the function len_without_ansi

    If the python version is >= 3.8
    """
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    int_1 = 6
    assert int_0 == int_1


# Generated at 2022-06-25 17:43:33.133043
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test code for len_without_ansi
    test_case_0()



#-----------------------------------------------------------------------------#
#                              TextWrapper                                    #
#-----------------------------------------------------------------------------#

_BASE = 'textwrap.TextWrapper'
_BASE_WRAP = 'textwrap.TextWrapper.wrap'
_LEN_FUNC = 'flutils.txtutils.len_without_ansi'

_MSG: str = ('This argument is deprecated since version 0.6 and should no '
             'longer be used')
_MSG_LEN = f'{_MSG}. Use {_LEN_FUNC} instead.'



# Generated at 2022-06-25 17:43:34.107510
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert 0


# Generated at 2022-06-25 17:43:44.545403
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '^[38;5;202m'
    int_0 = len_without_ansi(str_0)
    assert (int_0 == 0)
    str_1 = 'test'
    int_0 = len_without_ansi(str_1)
    assert (int_0 == 4)
    str_2 = '\x1b[0;31mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_2)
    assert (int_0 == 6)
    lst_0 = ['\x1b[0;31mfoobar\x1b[0m']
    int_0 = len_without_ansi(lst_0)
    assert (int_0 == 6)

# Generated at 2022-06-25 17:43:47.810032
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_1 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(str_1) == 6

test_case_0()
test_len_without_ansi()



# Generated at 2022-06-25 17:43:51.721232
# Unit test for function len_without_ansi
def test_len_without_ansi():
    '''Tests for flutils.txtutils.len_without_ansi()'''
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_0 = len_without_ansi(str_0)
    int_1 = 6
    assert int_0 == int_1



# Generated at 2022-06-25 17:43:53.542634
# Unit test for function len_without_ansi
def test_len_without_ansi():
    (test_case_0)


# Generated at 2022-06-25 17:43:57.296562
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Default test
    out_1 = len_without_ansi()

    assert out_1 == 0

    # Default test
    out_1 = len_without_ansi()

    assert out_1 == 0



# Generated at 2022-06-25 17:44:01.937489
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(str_0) == 6
    str_1 = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(str_1) == 6


# Generated at 2022-06-25 17:44:08.240342
# Unit test for function len_without_ansi
def test_len_without_ansi():

    ansi_start = '\x1b[38;5;209m'
    ansi_end = '\x1b[0m'

    # Test empty string
    assert len_without_ansi('') == 0

    # Test a string with ansi
    assert len_without_ansi(f'{ansi_start}foobar{ansi_end}') == 6

    # Test a list of strings with ansi
    assert len_without_ansi([f'foo{ansi_start}bar']) == 6

    # Test a list with a non-string
    assert len_without_ansi([f'foo{ansi_start}bar', 1]) == 6



# Generated at 2022-06-25 17:44:42.182270
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(None) == 0
    assert len_without_ansi('') == 0
    assert len_without_ansi([]) == 0
    assert len_without_ansi('foo') == 3
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar'])

# Generated at 2022-06-25 17:44:49.136299
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi([]) == 0
    assert len_without_ansi((('foo', 'bar'))) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar\x1b[0mbaz') == 9



# Generated at 2022-06-25 17:44:50.384034
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()



# Generated at 2022-06-25 17:44:58.245054
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(['\033[1;31mfoo\033[0m', 'bar']) == 4
    assert len_without_ansi('\033[1;31mfoo\033[0m') == 3
    assert len_without_ansi(['foo\033[31m\033[0m', 'bar']) == 4
    assert len_without_ansi(['\033[1;31mfoo', '\033[0mbar']) == 4

# Wrapper for textwrap.TextWrapper class
# Adds methods for calculating the length of a string
# without ANSI escape codes.

# Generated at 2022-06-25 17:45:04.119221
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi([['\x1b[38;5;209m'], ['foobar'], ['\x1b[0m']]) == 6



# Generated at 2022-06-25 17:45:12.610138
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert callable(len_without_ansi), 'Function not callable'
    sequence_0 = None
    int_0 = len_without_ansi(sequence_0)
    assert int_0 == 0, 'Failed test 0'
    sequence_1 = ''
    int_1 = len_without_ansi(sequence_1)
    assert int_1 == 0, 'Failed test 1'
    sequence_2 = []
    int_2 = len_without_ansi(sequence_2)
    assert int_2 == 0, 'Failed test 2'
    sequence_3 = ()
    int_3 = len_without_ansi(sequence_3)
    assert int_3 == 0, 'Failed test 3'

# Generated at 2022-06-25 17:45:20.890230
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("foobar") == 6
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6
    assert len_without_ansi("foobar\x1b[0m") == 6
    assert len_without_ansi("") == 0
    assert len_without_ansi("\x1b[0m") == 0
    assert len_without_ansi("\x1b[0mfoobar\x1b[0m") == 6
    assert len_without_ansi("") == 0
    assert len_without_ansi("foobar\x1b[38;5;209m") == 6
    assert len_without_ansi("foobar\x1b[38;5;209mfoobar") == 12


# Generated at 2022-06-25 17:45:22.749550
# Unit test for function len_without_ansi
def test_len_without_ansi():
    sequence_0 = None
    int_0 = len_without_ansi(sequence_0)
    assert int_0 == 0


# Generated at 2022-06-25 17:45:29.998933
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[38;5;218mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[38;5;218mbar\x1b[0m'
    assert len(text) == 19


# Generated at 2022-06-25 17:45:33.430172
# Unit test for function len_without_ansi
def test_len_without_ansi():
    try:
        _result = len('\x1b[38;5;209mfoobar\x1b[0m')
    except Exception:
        raise AssertionError('Failed test')
    else:
        _result_2 = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
        assert (_result != _result_2)



# Generated at 2022-06-25 17:47:22.416621
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("A") == 1
    assert len_without_ansi("A\x1b[38;5;209mfoobar\x1b[0m") == 6
    assert len_without_ansi("abc") == 3
    assert len_without_ansi("ab") == 2
    assert len_without_ansi("a\nb") == 2
    assert len_without_ansi("\x1b[0m") == 0
    assert len_without_ansi("\x1b[0m\x1b[0m") == 0
    assert len_without_ansi("A\x1b[38;5;209mfoobar\x1b[0m\x1b[0m") == 6
    assert len_without_ansi("abc\nabc") == 6

# Generated at 2022-06-25 17:47:32.415746
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert callable(len_without_ansi)

    assert len_without_ansi('foo') == 3
    assert len_without_ansi('foo\x1b[6n') == 4

    assert len_without_ansi(['foo', 'bar', 'baz']) == 9

    assert len_without_ansi({'foo', 'bar', '42'}) == 8

    assert len_without_ansi(
        ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;34mbar\x1b[0m', 'baz']
    ) == 6


_WRAPPER_ATTRIBUTES = TextWrapper.__getattribute__('__attributes__')



# Generated at 2022-06-25 17:47:37.928245
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_sequence = None
    assert len_without_ansi(test_sequence) == 0

    test_sequence = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(test_sequence) == 6

    test_sequence = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mfoobar\x1b[0m'
    ]
    assert len_without_ansi(test_sequence) == 18


# Generated at 2022-06-25 17:47:48.304363
# Unit test for function len_without_ansi
def test_len_without_ansi():
    sequence_0 = None
    sequence_1 = b''
    sequence_2 = b'\x1b[38;5;209mfoobar\x1b[0m'
    sequence_3 = ['\x1b[38;5;209mfoobar\x1b[0m']
    sequence_4 = '\x1b[38;5;209mfoobar\x1b[0m'
    sequence_5 = ['\x1b[38;5;209mfoobar\x1b[0m', 'foo', 'bar']
    sequence_6 = b'foo'
    sequence_7 = ['foo']
    sequence_8 = 'foo'
    sequence_9 = ['foo', 'bar']

# Generated at 2022-06-25 17:47:54.432559
# Unit test for function len_without_ansi
def test_len_without_ansi():

    # Test 1
    sequence_0 = '\x1b[32mfoobar\x1b[0m'  # type: ignore
    int_0 = len_without_ansi(sequence_0)
    assert int_0 == 6

    # Test 2
    sequence_1 = ['\x1b[1m\x1b[38;5;209mfoo\x1b[0m', '\x1b[1m\x1b[38;5;202mbar\x1b[0m']  # type: ignore
    int_1 = len_without_ansi(sequence_1)
    assert int_1 == 6

    # Test 3
    sequence_2 = ''  # type: ignore
    int_2 = len_witho

# Generated at 2022-06-25 17:47:55.116966
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()



# Generated at 2022-06-25 17:48:03.021223
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

    sequence_0 : Optional[Sequence] = None
    int_0 = len_without_ansi(sequence_0)

    sequence_0 : Optional[Sequence] = None
    int_0 = len_without_ansi(sequence_0)
    assert int_0 == 0

    sequence_0 : Optional[Sequence] = (
        '\x1b[38;5;209mfoobar\x1b[0m',
    )
    int_0 = len_without_ansi(sequence_0)
    assert int_0 == 6


# Generated at 2022-06-25 17:48:12.641874
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(":abc:\x1b[0m") == 3
    assert len_without_ansi("-") == 1
    assert len_without_ansi("\x1b[0;33m\x1b[K") == 0
    assert len_without_ansi("\x1b[0;31m.\x1b[0m") == 1
    assert len_without_ansi("ab\x1b[42mcd\x1b[K") == 2
    assert len_without_ansi("\x1b[0m\x1b[0;33m\x1b[K") == 0
    assert len_without_ansi("child.\x1b[0m") == 7
    assert len_without_ansi("\x1b[K") == 0
   

# Generated at 2022-06-25 17:48:13.364630
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(None) == 0



# Generated at 2022-06-25 17:48:22.816278
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Initialize a variable for the value returned from
    # len_without_ansi
    sequence_0 = None  # type: Optional[Sequence[str]]
    int_0 = len_without_ansi(sequence_0)
    print(repr(int_0))

    # Initialize a variable for the value returned from
    # len_without_ansi
    sequence_1 = list()  # type: Optional[Sequence[str]]
    int_1 = len_without_ansi(sequence_1)
    print(repr(int_1))

    # Initialize a variable for the value returned from
    # len_without_ansi
    sequence_2 = ('foobar',)  # type: Optional[Sequence[str]]
    int_2 = len_without_ansi(sequence_2)