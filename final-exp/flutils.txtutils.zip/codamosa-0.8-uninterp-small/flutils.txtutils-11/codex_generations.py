

# Generated at 2022-06-25 17:42:33.549002
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # In the case that the code text to be wrapped is not a list of strings.
    # Assert that the string representation of the code text is returned.
    seq = [1, 2, 3]
    expected = str(seq)
    result = len_without_ansi(seq)
    assert expected == result
    
    # In the case that the code text to be wrapped is a list of strings.
    # Assert that the expected list of strings is returned.
    seq = ['\x1b[38;5;209mfoobar\x1b[0m']
    expected = 6
    result = len_without_ansi(seq)
    assert expected == result



# Generated at 2022-06-25 17:42:39.776942
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test case 1
    text1 = '\x1b[38;5;209mfoobar\x1b[0m'
    seq1 = text1
    assert len_without_ansi(seq1) == 6
    # Test case 2
    text2 = '\x1b[38;5;209mfoobar\x1b[0m'
    seq2 = list(text2)
    assert len_without_ansi(seq2) == 6
    # Test case 3
    text3 = '\x1b[38;5;209mfoobar\x1b[0m'
    seq3 = tuple(text3)
    assert len_without_ansi(seq3) == 6



# Generated at 2022-06-25 17:42:43.233134
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # param
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    res = len_without_ansi(seq)
    assert res == 6


# Generated at 2022-06-25 17:42:46.947598
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert(len_without_ansi(text_0) == 6)

#   \x1b[38;5;209mfoobar\x1b[0m')



# Generated at 2022-06-25 17:42:51.867269
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq_0 = ["\x1b[38;5;209mfoobar\x1b[0m"]
    assert len_without_ansi(seq_0) == 6
    seq_1 = ['\\x1b[38;5;209mfoobar\\x1b[0m']
    assert len_without_ansi(seq_1) == 6


# Generated at 2022-06-25 17:43:03.466715
# Unit test for function len_without_ansi
def test_len_without_ansi():
    uval_0 = ['\x1b[38;5;209mfoobar\x1b[0m']
    txt_0 = len_without_ansi(uval_0)
    assert(txt_0 == 6)
    txt_1 = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert(txt_1 == 6)
    txt_2 = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mbaz\x1b[0m')
    assert(txt_2 == 9)
    # verifies that the cache cleans up after itself

# Generated at 2022-06-25 17:43:05.526708
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert isinstance(len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m'), int)


# Generated at 2022-06-25 17:43:14.547663
# Unit test for function len_without_ansi
def test_len_without_ansi():
    str_0: str = 'P@rTlY $TylEd'
    num_0: int = len_without_ansi(str_0)
    a_few_ansi_sequences: str = '\x1b[30mm\x1b[0m'
    assert num_0 == len_without_ansi(a_few_ansi_sequences)
    assert num_0 == len_without_ansi(str_0)
    a_few_ansi_sequences_1: str = '\x1b[30m$\x1b[0m'
    assert num_0 == len_without_ansi(a_few_ansi_sequences_1)
    assert num_0 == len_without_ansi(str_0)
    a_few_ansi_sequences_

# Generated at 2022-06-25 17:43:18.919528
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'
    int_0 = len_without_ansi(seq_0)
    assert(int_0 == 6)

test_len_without_ansi()
test_case_0()

# Test that #41 is fixed

# Generated at 2022-06-25 17:43:27.014428
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Test 1: Testing the return of len_without_ansi against known values
    """
    assert len_without_ansi('foo bar') == 7
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m') == 3
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m bar') == 7
    assert len_without_ansi(['foobar']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m baz']) == 8
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'bar']) == 7
    assert len_without

# Generated at 2022-06-25 17:44:05.985605
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    #assert len_without_ansi([text]) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209mbar\x1b[0m']) == 6
    assert len_without_ansi(['foo', '\x1b[38;5;209mbar\x1b[0m']) == 6
    assert len_without_ansi(['_\x1b[33mfoo\x1b[0m', '_\x1b[33mbar\x1b[0m']) == 6



# Generated at 2022-06-25 17:44:14.917863
# Unit test for function len_without_ansi

# Generated at 2022-06-25 17:44:24.749807
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(
        ['\x1b[38;5;209mfoobar', '\x1b[0m']
    ) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar']) == 6
    assert len_without_ansi(('\x1b[38;5;209m', 'foobar')) == 6



# Generated at 2022-06-25 17:44:26.670432
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\u001b[38;5;209mfoobar\u001b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:44:30.304976
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:44:32.887104
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:44:35.767833
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:44:45.109662
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[0m']) == 3
    assert len_without_ansi(('\x1b[38;5;209mf', 'oo')) == 2
    assert len_without_ansi('\x1b[38;5;209m') == 0
    assert len_without_ansi(('\x1b[38;5;209m', 'foo')) == 3
    assert len_without_ansi(('foo', '\x1b[0m')) == 3


# Generated at 2022-06-25 17:44:46.846398
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:44:50.211733
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\\x1b[38;5;209mfoobar\\x1b[0m'

    assert len_without_ansi(text_0) == 6



# Generated at 2022-06-25 17:45:16.989560
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_str = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(test_str) == 6


# Generated at 2022-06-25 17:45:26.528514
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_text_1 = '\x1b[38;5;209mfoobar\x1b[0m'
    result_1 = len_without_ansi(test_text_1)
    assert result_1 == 6

    test_text_2 = '\x1b[38;5;209mfoo\x1b[0mbar'
    result_2 = len_without_ansi(test_text_2)
    assert result_2 == 6

    test_text_3 = '\x1b[38;5;209mfoobar\x1b[0m'
    result_3 = len_without_ansi(test_text_3)
    assert result_3 == 6


# Generated at 2022-06-25 17:45:27.767243
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_0 = AnsiTextWrapper()




# Generated at 2022-06-25 17:45:34.648414
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # case 0
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 18
    assert len_without_ansi(text) == 6

    # case 1
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len(text) == 2
    assert len_without_ansi(text) == 12


# Generated at 2022-06-25 17:45:37.065369
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    len_without_ansi(text)



# Generated at 2022-06-25 17:45:39.392773
# Unit test for function len_without_ansi
def test_len_without_ansi():
    cases = [
        ('\x1b[38;5;209mfoobar\x1b[0m', 6),
    ]
    for (seq, expected) in cases:
        actual = len_without_ansi(seq)
        assert actual == expected


# Generated at 2022-06-25 17:45:41.972504
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_seq = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(ansi_seq) == 6


# Generated at 2022-06-25 17:45:44.513803
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:45:49.850787
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    ansi_text_wrapper_0 = AnsiTextWrapper(width=6)
    assert len_without_ansi(ansi_text_wrapper_0.fill('foobar')) == 6
    assert len_without_ansi(ansi_text_wrapper_0.fill('\x1b[38;5;209mfoobar\x1b[0m')) == 6

# Generated at 2022-06-25 17:45:52.219506
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:46:19.957973
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6


# Generated at 2022-06-25 17:46:21.166180
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:46:22.377187
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-25 17:46:24.362315
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('foobar\x1b[9;10;11;12;13mfoobar') == 12



# Generated at 2022-06-25 17:46:33.987139
# Unit test for function len_without_ansi
def test_len_without_ansi():
    tst_str_0= "\\x1b[38;5;209mfoobar\\x1b[0m"
    assert len_without_ansi(tst_str_0) == 6
    tst_list_0 = ['\\x1b[38;5;209mfoobar\\x1b[0m']
    assert len_without_ansi(tst_list_0) == 6
    tst_list_1 = ['\\x1b[38;5;209mfoobar\\x1b[0m', '\\x1b[30;5;209mwizzbang\\x1b[0m']
    assert len_without_ansi(tst_list_1) == 12



# Generated at 2022-06-25 17:46:37.658175
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test case 1
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    expected_result = 6
    actual_result = len_without_ansi(text)
    assert(expected_result == actual_result)


# Generated at 2022-06-25 17:46:42.498728
# Unit test for function len_without_ansi
def test_len_without_ansi():
    out = len_without_ansi('THIS IS A TEST')
    assert isinstance(out, int)
    assert out == len('THIS IS A TEST')
    assert len_without_ansi('THIS IS A \x1b[0m TEST') == len('THIS IS A TEST')
    assert len_without_ansi('THIS IS A \x1b[38;5;200m TEST') == len('THIS IS A  TEST')


# Generated at 2022-06-25 17:46:50.408980
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi_0 = len_without_ansi(text_0)
    if len_without_ansi_0 != 6:
        raise Exception('Unit test failed for function len_without_ansi. Expected 6, got ' + str(len_without_ansi_0))

# Generated at 2022-06-25 17:46:52.547162
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Tests for function len_without_ansi."""
    assert 6 == len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')


# Generated at 2022-06-25 17:46:59.392349
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Unit test for function len_without_ansi in module txtutils
    """
    # Test 0 - Void string
    print("> Test 0 - Void string")
    text = ''
    assert len_without_ansi(text) == 0, len_without_ansi(text)

    # Test 1 - None object
    print("> Test 1 - None object")
    text = None
    assert len_without_ansi(text) == 0, len_without_ansi(text)

    # Test 2 - Integer
    print("> Test 2 - Integer")
    text = 1
    assert len_without_ansi(text) == 0, len_without_ansi(text)

    # Test 3 - Float
    print("> Test 3 - Float")
    text = 1.5

# Generated at 2022-06-25 17:47:33.898986
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Case 0
    text = 'foobar'
    assert len_without_ansi(text) == 6

    # Case 1
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    # Case 2
    text = ['\x1b[38;5;209mfoo', 'bar']
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:47:42.836024
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('\x1b[H\x1b[J') == 0
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('123\x1b[38;5;209mfoobar\x1b[0m') == 9
    ansi_text_wrapper_0 = AnsiTextWrapper()
    ansi_text_wrapper_0.width = 4
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6


# Generated at 2022-06-25 17:47:46.098649
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(ansi_text) == 6
    assert len_without_ansi([ansi_text]) == 6
    # pylint: disable=unsubscriptable-object
    assert len_without_ansi([ansi_text, ansi_text]) == 12
    # pylint: enable=unsubscriptable-object


# Generated at 2022-06-25 17:47:48.987937
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text_wrapped = " \x1b[38;5;209mfoobar\x1b[0m "
    length = len_without_ansi(text_wrapped)
    if length != 6:
        raise ValueError("Failed length check!")


# Generated at 2022-06-25 17:47:54.336770
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(seq='abc') == 3
    assert len_without_ansi(seq=('abc', 'd')) == 4
    assert len_without_ansi(seq=('abc', '\x1b[30mb')) == 4
    assert len_without_ansi(seq=('abc', '\x1b[30mb', 'c')) == 4
    assert len_without_ansi(seq=('\x1b[30m', 'abc')) == 3
    assert len_without_ansi(seq=('abc', 'd', '\x1b[30m')) == 4



# Generated at 2022-06-25 17:47:55.747060
# Unit test for function len_without_ansi
def test_len_without_ansi():
    content = 'Hello, World!'
    len_without_ansi(content) == len(content)


# Generated at 2022-06-25 17:47:57.347050
# Unit test for function len_without_ansi
def test_len_without_ansi():
    txt = "Hello world\x1b[0m\n"
    assert len_without_ansi(txt) == 11


# Generated at 2022-06-25 17:48:00.161377
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    expected_result = 6

    actual_result = len_without_ansi(text)

    assert expected_result == actual_result


# Generated at 2022-06-25 17:48:02.012006
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:48:12.029292
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[1mbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[1;38;5;209mbar') == 6
    assert len_without_ansi('foo\x1b[1mbar') == 6

# Generated at 2022-06-25 17:48:43.561327
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_str = '\x1b[38;5;209mfoobar\x1b[0m'

    assert len_without_ansi(test_str) == 6


# Generated at 2022-06-25 17:48:45.767839
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    _ = len_without_ansi(text)
    ansi_text_wrapper_1 = AnsiTextWrapper()


# Generated at 2022-06-25 17:48:50.236037
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()
    ansi_text = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi_0 = len_without_ansi(ansi_text)
    assert len_without_ansi_0 == 6, 'test_txtutils failed'



# Generated at 2022-06-25 17:48:51.929445
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi(text) == 6


# Generated at 2022-06-25 17:48:53.393621
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6


# Generated at 2022-06-25 17:48:59.069619
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test case 1
    test_seq_1 = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi(test_seq_1)
    returned_data = len_without_ansi(test_seq_1)
    assert returned_data == 6
    # Test case 2
    test_seq_2 = '\x1b[1;31m\x1b[4;32m\x1b[44m\x1b[1mfoobar\x1b[0m\x1b[0m\x1b[0m\x1b[0m'
    len_without_ansi(test_seq_2)
    returned_data = len_without_ansi(test_seq_2)
    assert returned_data == 6
   

# Generated at 2022-06-25 17:49:03.141821
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:49:04.570657
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:49:07.156369
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    print('len_without_ansi(text)')
    print(len_without_ansi(text))
    print("Correct answer: 6")
    return


# Generated at 2022-06-25 17:49:09.902965
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:50:30.308635
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfooba\x1b[1mr\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfooba\x1b[1mr\x1b[0m'
    text_len = len_without_ansi(text)
    assert text_len == 6
    assert text_len == len(text) - 7



# Generated at 2022-06-25 17:50:32.301217
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:50:37.761041
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test that len_without_ansi has correct output
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209m') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mxxx') == 9
    assert len_without_ans

# Generated at 2022-06-25 17:50:39.752288
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:50:41.884969
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    result = len_without_ansi(text)
    assert result == 6


# Generated at 2022-06-25 17:50:44.795091
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from nose.tools import assert_equal
    test_case_0()
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert_equal(len_without_ansi(text), 6)



# Generated at 2022-06-25 17:50:46.993478
# Unit test for function len_without_ansi
def test_len_without_ansi():
    #test_case_0
    assert (len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6)


# Generated at 2022-06-25 17:50:49.104432
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(seq) == 6



# Generated at 2022-06-25 17:50:58.942510
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert 0 == len_without_ansi('')
    assert 0 == len_without_ansi([])
    assert 0 == len_without_ansi({})
    assert 0 == len_without_ansi(())
    assert 6 == len_without_ansi('foobar')
    assert 6 == len_without_ansi('foobar')
    assert 6 == len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert 6 == len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar')
    assert 6 == len_without_ansi(['foo', 'bar'])

# Generated at 2022-06-25 17:51:02.553783
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text_wrapper_0 = AnsiTextWrapper()
    ansi_text_wrapper_0.len_without_ansi = len_without_ansi
    ansi_text_wrapper_0.len_without_ansi('')
