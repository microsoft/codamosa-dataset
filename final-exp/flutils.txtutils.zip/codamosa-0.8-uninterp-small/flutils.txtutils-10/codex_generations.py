

# Generated at 2022-06-25 17:42:16.572285
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6



# Generated at 2022-06-25 17:42:24.478702
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = [
        '\x1b[38;5;209mfi\x1b[0m',
        '\x1b[38;5;209m\x1b[38;5;209mfi\x1b[0m',
        'foobar',
        '\x1b[38;5;209m\x1b[38;5;209mfi\x1b[0m',
        '\x1b[38;5;209mfi\x1b[0m',
        '\x1b[38;5;209m\x1b[38;5;209mfi\x1b[0m',
    ]

# Generated at 2022-06-25 17:42:32.753025
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar')
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209m\x1b[0m', '\x1b[38;5;209m\x1b[0m', '\x1b[38;5;209mbar\x1b[0m']) == 6

# Generated at 2022-06-25 17:42:38.717097
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Unit test for function
    :obj:`~flutils.txtutils.len_without_ansi`
    """
    from flutils.txtutils import len_without_ansi

    test_str = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(test_str) == 6
    list_0 = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    int_0 = len_without_ansi(list_0)
    assert int_0 == 6



# Generated at 2022-06-25 17:42:44.927941
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = ['\x1b[0m\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    int_0 = len_without_ansi(list_0)
    assert int_0 == (12), f'Expected {(12)}, but got {int_0}'


# Generated at 2022-06-25 17:42:53.512564
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Simple case
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    # Simple list case
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    text_1 = '\x1b[38;5;210mfoobar\x1b[0m'
    text_2 = '\x1b[38;5;211mfoobar\x1b[0m'
    text_3 = '\x1b[38;5;212mfoobar\x1b[0m'
    texts: List[str] = [text_0, text_1, text_2, text_3]

# Generated at 2022-06-25 17:42:55.233857
# Unit test for function len_without_ansi
def test_len_without_ansi():
    for _ in range(1000):
        test_case_0()



# Generated at 2022-06-25 17:43:06.058889
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi([]) == 0
    assert len_without_ansi(['\x1b[5mfoo\x1b[0m']) == 3
    assert len_without_ansi(['\x1b[1;31mfoo\x1b[0m']) == 3
    assert len_without_ansi(['\x1b[33mbar\x1b[0m']) == 3
    assert len_without_ansi(['\x1b[31mfoo', '\x1b[33mbar\x1b[0m', 'baz']) == 3
    assert len_without_ansi(['foo']) == 3
    assert len_without_ansi('foo') == 3

# Generated at 2022-06-25 17:43:12.502204
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = [
            '\x1b[38;5;209mfoobar\x1b[0m',
            '\x1b[38;5;209mfoo\x1b[0m',
            '\x1b[38;5;209mfo\x1b[0m',
            '\x1b[38;5;209mf\x1b[0m']
    int_0 = len_without_ansi(list_0)
    assert int_0 == 30
    assert True


# Generated at 2022-06-25 17:43:18.425854
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_1 = None
    list_2 = ["\x1b[38;5;209mfoo\x1b[0m", "bar"]
    list_3 = ["foo", "\x1b[38;5;209mbar\x1b[0m"]
    assert len_without_ansi(list_1) == 0
    assert len_without_ansi(list_2) == 6
    assert len_without_ansi(list_3) == 6



# Generated at 2022-06-25 17:43:54.281379
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(None) == 0
    assert len_without_ansi('') == 0
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[0m', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar') == 6



# Generated at 2022-06-25 17:43:59.899027
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi([]) == 0
    assert len_without_ansi(' ') == 1
    assert len_without_ansi('   ') == 3
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-25 17:44:04.979015
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi"""
    # If the python version is >= 3.8
    if hexversion >= 0x03080000:
        import pytest
        value = pytest.raises(TypeError).value
        with value:
            len_without_ansi(None)  # pylint: disable=no-value-for-parameter
    else:
        len_without_ansi(None)  # pylint: disable=no-value-for-parameter



# Generated at 2022-06-25 17:44:08.935690
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = ["\x1b[38;5;209mfoobar\x1b[0m", "\x1b[38;5;209mfoobar\x1b[0m"]
    int_0 = len_without_ansi(list_0)
    int_1 = len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m")
    assert int_0 == 12
    assert int_1 == 6

#

# Generated at 2022-06-25 17:44:11.081747
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi."""
    list_0 = None
    int_0 = len_without_ansi(list_0)



# Generated at 2022-06-25 17:44:21.997515
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test case 0 - List
    list_0 = [
            'The',
            '\x1b[38;5;14mQUICK',
            '\x1b[38;5;208mBROWN',
            'FOX',
            'JUMPS'
    ]
    int_0 = len_without_ansi(list_0)
    assert int_0 == 20
    int_1 = len_without_ansi(list_0[0])
    assert int_1 == 3
    # Test case 1 - String
    str_0 = 'The \x1b[38;5;14mQUICK \x1b[38;5;208mBROWN FOX JUMPS'
    int_2 = len_without_ansi(str_0)
    assert int_2 == 20
    int_3 = len

# Generated at 2022-06-25 17:44:29.100927
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Some basic examples
    assert len_without_ansi('\x1b[31mfoo\x1b[0m') == 3
    assert len_without_ansi('foo\x1b[0m') == 3
    assert len_without_ansi('\x1b[41mfoo') == 3
    assert len_without_ansi('\x1b[31mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\x1b[7mbar\x1b[0m\x1b[31mfoo\x1b[0m') == 6

    # Test that multiple split strings works

# Generated at 2022-06-25 17:44:38.487766
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = []
    int_0 = len_without_ansi(list_0)
    assert int_0 == 0
    list_0 = ['foo']
    int_0 = len_without_ansi(list_0)
    assert int_0 == 3
    list_1 = ['foo', 'bar', 'baz']
    int_0 = len_without_ansi(list_1)
    assert int_0 == 9
    list_2 = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    int_0 = len_without_ansi(list_2)
    assert int_0 == 6



# Generated at 2022-06-25 17:44:48.492707
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6
   

# Generated at 2022-06-25 17:44:52.067006
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi == len_without_ansi
    assert len_without_ansi != len_without_ansi
    assert len_without_ansi == len_without_ansi
    return



# Generated at 2022-06-25 17:45:22.862332
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert (len_without_ansi(None) == 0)
    assert (len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6)
    assert (len_without_ansi('\x1b[38;5;209m\x1b[0m') == 0)
    assert (len_without_ansi('\x1b[38;5;209mfoo\x1b[0mbar') == 3)
    assert (len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m',
                              '\x1b[38;5;209mfoobar\x1b[0m']) == 12)



# Generated at 2022-06-25 17:45:32.469148
# Unit test for function len_without_ansi
def test_len_without_ansi():
    count = 0

    # TEST CASE: len_without_ansi(None)
    if len_without_ansi(None) == None:
        count = count + 1
    else:
        print("Error test case 1")

    # TEST CASE: len_without_ansi(1234)
    if len_without_ansi(1234) == None:
        count = count + 1
    else:
        print("Error test case 2")

    # TEST CASE: len_without_ansi('\x1b[1mbar\x1b[0m')
    if len_without_ansi('\x1b[1mbar\x1b[0m') == 3:
        count = count + 1
    else:
        print("Error test case 3")

    # TEST CASE: len_without_ansi('bar\

# Generated at 2022-06-25 17:45:41.721917
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('foo bar') == 7
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    # test that the function works with tuples
    assert len_without_ansi(('\x1b[38;5;209mfoobar', '\x1b[0m')) == 6
    # test that the function works with lists
    assert len_without_ansi(['\x1b[38;5;209mfoobar', '\x1b[0m']) == 6
    # test that the function works with lists of lists

# Generated at 2022-06-25 17:45:44.006162
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-25 17:45:53.376097
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Tests for case 0
    list_0 = None
    int_0 = len_without_ansi(list_0)

    # Tests for case 1
    text_0 = '\x1b[38;5;209mfoobar\x1b[0m'
    int_1 = len_without_ansi(text_0)

    # Tests for case 2
    list_1 = ['\x1b[1mba', 'r\x1b[0m']
    int_2 = len_without_ansi(list_1)

    # Tests for case 3
    list_2 = ['\x1b[1mfoo\x1b[0m', '\x1b[1mbar\x1b[0m']
    int_3 = len_without_ansi(list_2)

    #

# Generated at 2022-06-25 17:46:03.844902
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6
    assert len_without_ansi(["\x1b[38;5;209mfoobar\x1b[0m"]) == 6
    assert len_without_ansi(["\x1b[38;5;209mfoo\x1b[0m", "\x1b[38;5;209mbar\x1b[0m"]) == 6
    assert len_without_ansi(["\x1b[38;5;209mfoo", "\x1b[0m", "\x1b[38;5;209mbar\x1b[0m"]) == 6
    assert len_without_ansi("") == 0

# Generated at 2022-06-25 17:46:12.190283
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import random
    import string
    from random import choice
    from string import digits
    from string import ascii_letters
    from string import ascii_lowercase
    from string import ascii_uppercase

    # Test each byte length
    byte_length = random.randint(1, 100)
    print(byte_length)
    print('len_without_ansi(' + str(byte_length) + ')')
    a = ''.join(choice(digits) for _ in range(byte_length))
    print(a)
    print(len_without_ansi(a))
    print('')

    # Test each byte length
    byte_length = random.randint(1, 100)
    print(byte_length)

# Generated at 2022-06-25 17:46:13.861650
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# Generated at 2022-06-25 17:46:14.781598
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Call function to test
    test_case_0()



# Generated at 2022-06-25 17:46:16.501606
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = ['\x1b[38;5;209mfoobar\x1b[0m']
    int_0 = len_without_ansi(list_0)



# Generated at 2022-06-25 17:46:53.392509
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert 0 == len_without_ansi(None)
    assert 0 == len_without_ansi([])
    assert 0 == len_without_ansi(0)
    assert 0 == len_without_ansi('')
    assert 6 == len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert 6 == len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[0mbar'])
    assert 6 == len_without_ansi(['\x1b[38;5;209mfoo', 'bar'])

# Generated at 2022-06-25 17:46:57.400790
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = ['asdf', '\x1b[38;5;209mfoobar\x1b[0m']
    int_0 = len_without_ansi(list_0)
    int_1 = len_without_ansi(list_0[0])
    int_2 = len_without_ansi(list_0[1])


# Generated at 2022-06-25 17:46:58.690522
# Unit test for function len_without_ansi
def test_len_without_ansi():
    try:
        test_case_0()
    except:
        raise


# Generated at 2022-06-25 17:46:59.423550
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()
    assert True


# Generated at 2022-06-25 17:47:01.771776
# Unit test for function len_without_ansi
def test_len_without_ansi():
    int_0 = len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', 'tyler'])
    if(int_0 != 6):
        raise ValueError('Return Value: {}'.format(int_0))
        

# Generated at 2022-06-25 17:47:07.312530
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

    test_cases = [
        (
            'Test Case 0',
            (
                None,
            ),
            0,
        ),
    ]
    for case in test_cases:
        try:
            assert len_without_ansi(case[1][0]) == case[2]
        except AssertionError:
            print('Test case failed: "{}"'.format(case[0]))
            raise



# Generated at 2022-06-25 17:47:12.753285
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3

    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6

    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'bar']) == 6


# noinspection PyMethodMayBeStatic

# Generated at 2022-06-25 17:47:15.100609
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = ['\x1b[38;5;209mfoobar\x1b[0m']
    int_0 = len_without_ansi(list_0)
    assert int_0 == 6



# Generated at 2022-06-25 17:47:23.183301
# Unit test for function len_without_ansi
def test_len_without_ansi():
    t_str1 = '\x1b[38;5;209mfoobar\x1b[0m'
    t_str2 = 'This is a test'
    t_str3 = 'This \x1bis \x1ba test'
    t_tuple = ('\x1b[38;5;209mThis is a test', 'This is also a test')

    assert len_without_ansi(t_str1) == 6
    assert len_without_ansi(t_str2) == 14
    assert len_without_ansi(t_str3) == 14
    assert len_without_ansi(t_tuple) == 28



# Generated at 2022-06-25 17:47:24.401080
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_case_0()

# Test cases for function len_without_ansi

# Generated at 2022-06-25 17:47:52.394967
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(['Foo', 'bar']) == 6
    assert len_without_ansi(['Foo', 'bar', '\x1b[33mBaz']) == 6
    assert len_without_ansi('Foo \x1b[33mBar') == 6
    assert len_without_ansi('Foo \x1b[33;2mBar') == 6
    assert len_without_ansi('Foo \x1b[38;5;209mBar') == 6



# Generated at 2022-06-25 17:47:55.962551
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("f\x1b[38;5;209moob\x1b[0mar") == len("foobar")
    assert len_without_ansi(['f\x1b[38;5;209mo', 'ob\x1b[0mar']) == len("foobar")


# Generated at 2022-06-25 17:48:05.371719
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text0 = '\x1b[38;5;209mfoobar\x1b[0m'
    text1 = ['\x1b[38;5;209mfoobar\x1b[0m']
    text2 = ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209mbar\x1b[0m']
    text3 = ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209mbar', '\x1b[0m']

# Generated at 2022-06-25 17:48:12.465843
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from typing import List

    input_list: List[str] = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209m',
        'foobar',
        '\x1b[0m',
        '\x1b[38;5;209m',
        'foobar',
        '\x1b[0m',
    ]

    expected_value: int = 6
    actual_value: int = len_without_ansi(input_list)
    assert actual_value == expected_value, "Expected: " + str(expected_value) + " Actual: " + str(actual_value)


# Generated at 2022-06-25 17:48:16.843568
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(None) == 0
    assert len_without_ansi('abc') == 3
    assert len_without_ansi(['abc']) == 3
    assert len_without_ansi(['a', 'bc']) == 3
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']) == 12


# Generated at 2022-06-25 17:48:18.926573
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(None) == 0


# Generated at 2022-06-25 17:48:26.435014
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = []
    int_0 = len_without_ansi(list_0)
    assert int_0 == 0


# Generated at 2022-06-25 17:48:31.945522
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(["foo", "bar"]) == 6
    assert len_without_ansi(["foo", "\x1b[38;5;209m", "bar", "\x1b[0m"]) == 6
    assert len_without_ansi(["\x1b[38;5;209m", "foo", "\x1b[0m"]) == 3


# Generated at 2022-06-25 17:48:33.347528
# Unit test for function len_without_ansi
def test_len_without_ansi():
    list_0 = None
    int_0 = len_without_ansi(list_0)


# Generated at 2022-06-25 17:48:39.035793
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    # Call function len_without_ansi
    try:
        int_0 = len_without_ansi(text)
    except Exception as e:
        print('len_without_ansi() failed!')
        print(e)
    else:
        if int_0 != 6:
            print('Incorrect result of len_without_ansi(): '
                + str(int_0))
        else:
            print('len_without_ansi() passed.')


# pylint: disable=too-many-public-methods

# Generated at 2022-06-25 17:49:34.890408
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    int_0 = len_without_ansi(text)

# End of unit test for function len_without_ansi


# Generated at 2022-06-25 17:49:40.373064
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test case 1
    # If the sequence is empty, return zero length
    seq1 = ''
    len1 = len_without_ansi(seq1)
    assert len1 == 0

    # Test case 2
    # If the sequence is a valid string without ANSI codes but
    # include newline and space characters, return correct length
    seq2 = 'This is a valid string\nwith valid length!'
    len2 = len_without_ansi(seq2)
    assert len2 == 38

    # Test case 3
    # If the sequence is a invalid string with ANSI codes, return length
    # without ANSI codes

# Generated at 2022-06-25 17:49:41.166777
# Unit test for function len_without_ansi
def test_len_without_ansi():
    print('\n')
    test_case_0()
    return 0


# Generated at 2022-06-25 17:49:46.186310
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('') == 0
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', None]) == 6
    assert len_without_ansi(['', None]) == 0



# Generated at 2022-06-25 17:49:48.393460
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6


# Generated at 2022-06-25 17:49:53.304289
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # list_0 = \x1b[38;5;209mfoobar\x1b[0m
    list_0 = ['\x1b[38;5;209mfoobar\x1b[0m']
    int_0 = len_without_ansi(list_0)
    assert(int_0 == 6)



# Generated at 2022-06-25 17:49:56.974342
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi()."""
    list_0 = ['\x1b[38;5;209mfoobar\x1b[0m']
    int_0 = len_without_ansi(list_0)
    assert int_0 == 6



# Generated at 2022-06-25 17:50:05.340011
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(None) == 0
    assert len_without_ansi('') == 0
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar\x1b[38;5;209m') == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(['foo\x1b[38;5;209m', 'bar', '\x1b[0mbaz']) == 6
    assert len_without_ansi(['foo\x1b[38;5;209m', 'bar', '\x1b[0m', 'baz']) == 6



# Generated at 2022-06-25 17:50:14.697338
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("\x1b[38;5;209m") == 0
    assert len_without_ansi("foobar") == 6
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6
    assert len_without_ansi("foobar\x1b[38;5;209mbarfoo\x1b[0m") == 12
    assert len_without_ansi("foobar\x1b[38;5;209m\x1b[0mbarfoo") == 9
    assert len_without_ansi("\x1b[38;5;209mfoobar\x1b[0m") == 6

# Generated at 2022-06-25 17:50:26.293265
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test the :func:`flutils.txtutils.len_without_ansi` function."""
    from .testutils.parametrize import parametrize
    from .testutils.parametrize import parametrize_kwargs

    # Test for a single string

# Generated at 2022-06-25 17:51:06.865802
# Unit test for function len_without_ansi
def test_len_without_ansi():
    print('\n--- test_len_without_ansi ---')
    # arg_1 = None
    # func_0 = len_without_ansi(arg_1)
    func_0 = len_without_ansi(['\x1b[01;32mfoo\x1b[0m'])
    print(func_0)




# Generated at 2022-06-25 17:51:17.889146
# Unit test for function len_without_ansi
def test_len_without_ansi():
    arg0 = ['\x1b[38;5;209mfoobar\x1b[0m']
    expected_return = 6
    returned_return = len_without_ansi(arg0)
    assert returned_return == expected_return

    arg0 = ['\x1b[38;5;209mfoobar\x1b[0m', 'foo', 'bar']
    expected_return = 9
    returned_return = len_without_ansi(arg0)
    assert returned_return == expected_return

    arg0 = [('\x1b[38;5;209mfoobar\x1b[0m', 'foo', 'bar')]
    expected_return = 9
    returned_return = len_without_ansi(arg0)
    assert returned_return == expected_return

    arg0 = None

# Generated at 2022-06-25 17:51:23.186261
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    list_0 = ['\x1b[38;5;209mfoobar\x1b[0m']
    int_0 = len_without_ansi(list_0)
    int_1 = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')


# Generated at 2022-06-25 17:51:31.521055
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', '\x1b[38;5;208mbar\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoo', '\x1b[38;5;208mbar\x1b[0m')) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoo', '\x1b[38;5;208mbar\x1b[0m',)) == 6
    assert len_without_ansi