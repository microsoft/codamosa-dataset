

# Generated at 2022-06-21 13:06:30.981494
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi()."""

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[1;38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[1;38;5;209mfoobar'
    assert len_without_ansi(text) == 6
    text = '\x1b[0mfoobar'
    assert len_without_ansi(text) == 6
    text = 'foobar'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-21 13:06:41.037168
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:06:48.513251
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(
        '\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;209mbar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfo', 'obar\x1b[0m']) == 6



# Generated at 2022-06-21 13:06:52.500443
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test constructor of class AnsiTextWrapper"""
    lst = [
        # fmt: off
        ['', 0, ''],
        ['a', 0, ''],
        ['a', 1, ''],
        ['a', 2, 'a'],
        # fmt: on
    ]
    for word, width, expect in lst:
        wrapper = AnsiTextWrapper(width=width)
        result = wrapper._wrap_chunks([word])
        print('Testing: word = "{}", width = "{}". Result is "{}".'
              ' Expected is "{}"'.format(word, width, result, expect))
        assert result == expect



# Generated at 2022-06-21 13:06:57.341636
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:06.926402
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:18.759194
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from flutils.txtutils import AnsiTextWrapper

    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='> ',
        subsequent_indent='> ',
        expand_tabs=False,
        replace_whitespace=True,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=1,
        max_lines=None,
        placeholder=' [...]'
    )

# Generated at 2022-06-21 13:07:27.653699
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:07:37.709028
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    text = '\x1b[31m\x1b[1m\x1b[4m'
    text += 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
    text += 'Cras fermentum maximus auctor. Cras a varius ligula. '
    text += 'Phasellus ut ipsum eu erat consequat posuere. '
    text += '\x1b[0mPellentesque habitant morbi tristique senectus et '
    text += 'netus et malesuada fames ac turpis egestas. '
    text += 'Maecenas ultricies lacus id massa interdum dignissim. '

# Generated at 2022-06-21 13:07:48.867098
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-21 13:08:58.855511
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:09:07.129868
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import logging
    logger = logging.getLogger(__name__)
    logger.info('Called the test_AnsiTextWrapper() function.')

    assert repr(AnsiTextWrapper()) == '<AnsiTextWrapper object>'

    wrapper = AnsiTextWrapper(
        width=42,
        initial_indent='    ',
        subsequent_indent='*' * 4,
        expand_tabs=True,
        replace_whitespace=True,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=8,
        max_lines=None,
        placeholder=' [...]'
    )

# Generated at 2022-06-21 13:09:09.150902
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import doctest
    doctest.testmod(verbose=False, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 13:09:16.505997
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-21 13:09:26.283729
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:29.585497
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """pytest unit test for function len_without_ansi"""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-21 13:09:32.968647
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    result = len_without_ansi(text)
    assert result == 6
    result = len_without_ansi([text])
    assert result == 6



# Generated at 2022-06-21 13:09:44.119767
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    text = 'Text with ANSI codes:\n\n'
    text += '\\x1b[31m\\x1b[1m\\x1b[4mLorem ipsum dolor sit amet, '
    text += 'consectetur adipiscing elit. Cras fermentum maximus '
    text += 'auctor. Cras a varius ligula. Phasellus ut ipsum eu '
    text += 'erat consequat posuere.\\x1b[0m'
    text += '\nPellentesque habitant morbi tristique senectus et netus '
    text += 'et malesuada fames ac turpis egestas. Maecenas ultricies '

# Generated at 2022-06-21 13:09:54.227244
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper."""
    # https://stackoverflow.com/a/25740652/5087436
    from unittest import TestCase, main
    from io import StringIO
    from sys import stdout


# Generated at 2022-06-21 13:09:58.196432
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    >>> from flutils.txtutils import len_without_ansi
    >>> text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    >>> len_without_ansi(text)
    6
    """



# Generated at 2022-06-21 13:12:44.467224
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:12:56.721378
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=20)
    assert wrapper.width == 20

    wrapper = AnsiTextWrapper(width=20, initial_indent='>>> ')
    assert wrapper.width == 20
    assert wrapper.initial_indent == '>>> '
    assert wrapper.initial_indent_len == 5

    wrapper = AnsiTextWrapper(width=20, initial_indent='\\x1b[38;5;208m')
    assert wrapper.width == 20
    assert wrapper.initial_indent == '\\x1b[38;5;208m'
    assert wrapper.initial_indent_len == 0


# Generated at 2022-06-21 13:13:03.742884
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:17.591913
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """
    Unit test for method wrap.
    """
    # Set up test
    # -------------------------------------------------------------------------

# Generated at 2022-06-21 13:13:21.547010
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:13:34.558017
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from textwrap import TextWrapper
    from flutils.txtutils import AnsiTextWrapper
    from flutils.constants import RE_ANSI

# Generated at 2022-06-21 13:13:48.758768
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from textwrap import dedent
    from flutils.txtutils import AnsiTextWrapper

    # Text without ANSI codes

# Generated at 2022-06-21 13:13:58.482050
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper, dump_ansi_format
    from flutils.strings import _hex_to_rgb


# Generated at 2022-06-21 13:14:10.011118
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test of the AnsiTextWrapper class's wrap method."""

# Generated at 2022-06-21 13:14:22.302154
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from unittest.mock import Mock, call
    from unittest import TestCase