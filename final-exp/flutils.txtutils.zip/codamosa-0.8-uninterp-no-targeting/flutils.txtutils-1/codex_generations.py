

# Generated at 2022-06-21 13:07:20.367598
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    wrapper = AnsiTextWrapper(width=40)
    assert isinstance(wrapper, AnsiTextWrapper)
    assert isinstance(wrapper, textwrap.TextWrapper)
    assert isinstance(wrapper, object)
    assert isinstance(wrapper, textwrap.TextWrapper)

    wrapper = AnsiTextWrapper(width=40, subsequent_indent=' ')
    assert isinstance(wrapper, AnsiTextWrapper)
    assert isinstance(wrapper, textwrap.TextWrapper)
    assert isinstance(wrapper, object)
    assert isinstance(wrapper, textwrap.TextWrapper)

    test_string = 'test'
    wrapper = AnsiTextWrapper(width=len(test_string))
    assert isinstance(wrapper, AnsiTextWrapper)
    assert isinstance(wrapper, textwrap.TextWrapper)


# Generated at 2022-06-21 13:07:27.819318
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # noinspection SpellCheckingInspection
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    # noinspection SpellCheckingInspection
    text = '\x1b[38;5;209mfoobar \x1b[31m\x1b[1m\x1b[4mfoo\x1b[m'
    assert len_without_ansi(text) == 10



# Generated at 2022-06-21 13:07:34.251607
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:07:38.766169
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi(('', text, '')) == 6



# Generated at 2022-06-21 13:07:44.109681
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


_orig_wrap = TextWrapper.wrap
_orig_fill = TextWrapper.fill



# Generated at 2022-06-21 13:07:47.449822
# Unit test for function len_without_ansi
def test_len_without_ansi():
    x = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(x) == 6

# from textwrap.py

# Generated at 2022-06-21 13:07:53.593638
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = '\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;226mbaz\x1b[0m'
    assert len_without_ansi(text) == 9

    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;226mbaz\x1b[0m']
    assert len_without_ansi(text) == 9



# Generated at 2022-06-21 13:08:03.150841
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:08:15.927620
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper."""

    ###########################################################################

    _width: int = 40
    _initial_indent: str = ''
    _subsequent_indent: str = ''
    _expand_tabs: bool = True
    _replace_whitespace: bool = True
    _fix_sentence_endings: bool = False
    _break_long_words: bool = True
    _drop_whitespace: bool = True
    _break_on_hyphens: bool = True
    _tabsize: int = 8

    ###########################################################################


# Generated at 2022-06-21 13:08:18.397552
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:09:03.871184
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test the :meth:`tuple <flutils.txtutils.len_without_ansi>` function."""
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\\x1b[38;5;209mfoo\\x1b[0mbar'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\\x1b[38;5;209mfoo', 'bar']) == 6
    assert len_without_ansi([['\\x1b[38;5;209mfoo', 'bar']]) == 6



# Generated at 2022-06-21 13:09:12.926914
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit test for method fill of class AnsiTextWrapper"""

# Generated at 2022-06-21 13:09:18.671863
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:21.854906
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import doctest
    doctest.run_docstring_examples(
        AnsiTextWrapper.wrap, globals(),
        optionflags=doctest.NORMALIZE_WHITESPACE
    )


# Generated at 2022-06-21 13:09:31.847344
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:09:41.207767
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:44.863431
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """
    Run doctest on class AnsiTextWrapper's constructor.
    """
    doctest.testmod(verbose=False)


# Generated at 2022-06-21 13:09:54.532037
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Unit test for method fill of class AnsiTextWrapper
    """

# Generated at 2022-06-21 13:10:06.376773
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import textwrap
    # Initialize the text and the wrapper.
    # (:obj:`~flutils.txtutils.AnsiTextWrapper` can be used like
    # :obj:`textwrap.TextWrapper`.)

# Generated at 2022-06-21 13:10:16.194883
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = 'foobar'
    assert len_without_ansi(text) == 6
    text = 'foo\x1b[38;5;239mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = [text]
    assert len_without_ansi(text) == 6
    text += ['\x1b[38;5;209mqux\x1b[0m']
    assert len_without_ansi(text) == 9



# Generated at 2022-06-21 13:10:52.886105
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    lst = list(text)
    assert len_without_ansi(lst) == 12
    lst[0] = '\x1b[38;5;209m'
    lst[-1] = '\x1b[0m'
    assert len_without_ansi(lst) == 6
    text = '\x1b[38;5;209mfoo\x1b[0mbar\x1b[38;5;208mbaz\x1b[0m'
    assert len_without_ansi(text) == 9



# Generated at 2022-06-21 13:10:55.661688
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:11:05.444771
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:13.845269
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""


# Generated at 2022-06-21 13:11:25.009332
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    wrapper = AnsiTextWrapper(width=40)

    # Assert that there are no exceptions

# Generated at 2022-06-21 13:11:29.681816
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test sequence of strings
    seq = ['\x1b[38;5;209mfoobar', '\x1b[0m']
    assert len_without_ansi(seq) == 6
    # Test string
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:11:41.805859
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """ Test AnsiTextWrapper.fill()"""


# Generated at 2022-06-21 13:11:46.247163
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    for attr in dir(AnsiTextWrapper):
        if not attr.startswith('__') and attr not in ('fill', 'wrap'):
            val1 = getattr(AnsiTextWrapper, attr)
            val2 = getattr(textwrap.TextWrapper, attr)
            assert val1 == val2



# Generated at 2022-06-21 13:11:58.127038
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:12:04.351118
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Test each argument of the constructor

    # width
    wrapper = AnsiTextWrapper(width=-1)
    assert wrapper.width == -1
    wrapper = AnsiTextWrapper(width=0)
    assert wrapper.width == 0
    wrapper = AnsiTextWrapper(width=1)
    assert wrapper.width == 1

    # initial_indent
    wrapper = AnsiTextWrapper(initial_indent='--')
    assert wrapper.initial_indent == '--'
    wrapper = AnsiTextWrapper(initial_indent='')
    assert wrapper.initial_indent == ''

    # subsequent_indent
    wrapper = AnsiTextWrapper(subsequent_indent='--')
    assert wrapper.subsequent_indent == '--'

# Generated at 2022-06-21 13:12:59.681474
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit test for method fill of class AnsiTextWrapper."""

# Generated at 2022-06-21 13:13:06.666962
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:13:19.907373
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:21.050712
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-21 13:13:33.254189
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from tests import test_txtutils

    class Case:
        def __init__(self, seq: Sequence, expected: int) -> None:
            self._seq = seq
            self._expected = expected
        def __call__(self) -> None:
            result = len_without_ansi(self._seq)
            assert result == self._expected, 'Expected {}; got {}'.format(
                self._expected, result)


# Generated at 2022-06-21 13:13:44.565132
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:13:55.405124
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    :return: Unit test coverage for class  flutils.txtutils.AnsiTextWrapper
    :rtype: int
    """
    from random import randint as rand
    from typing import List, Sequence
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-21 13:14:06.230433
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:17.078443
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:19.815027
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
#



# Generated at 2022-06-21 13:15:04.410800
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """pytest unit test for function len_without_ansi"""

# Generated at 2022-06-21 13:15:11.603336
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:15:22.959725
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:15:31.203182
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:15:34.244664
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    text = "This is a test for a longer line which should be wrapped by AnsiTextWrapper."
    wrapper = AnsiTextWrapper(width=40)
    wrapped_text = wrapper.fill(text)
    print(wrapped_text)
    assert len(wrapped_text.splitlines()) == 2



# Generated at 2022-06-21 13:15:45.340843
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Create an AnsiTextWrapper object
    w = AnsiTextWrapper(width=40)
    # Run method wrap and store result in the variable s