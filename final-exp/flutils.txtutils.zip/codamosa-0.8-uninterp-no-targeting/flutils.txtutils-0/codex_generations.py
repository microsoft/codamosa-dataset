

# Generated at 2022-06-21 13:06:42.998581
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """AnsiTextWrapper.__init__"""
    try:
        AnsiTextWrapper(width=40, initial_indent='\x1b[1m',
                        subsequent_indent='\x1b[38;2;128;0;255m    ',
                        placeholder=' [...]\x1b[0m',
                        expand_tabs=False, replace_whitespace=True,
                        fix_sentence_endings=False, break_long_words=True,
                        drop_whitespace=True, break_on_hyphens=True,
                        tabsize=8, max_lines=None)
    except Exception as ex:
        assert 'placeholder too large for max width' in str(ex)


# Generated at 2022-06-21 13:06:43.642714
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    pass


# Generated at 2022-06-21 13:06:47.793030
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    wrapper = AnsiTextWrapper()
    output: List[str] = wrapper.wrap(text)
    print(output)



# Generated at 2022-06-21 13:06:52.372601
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:06:57.212216
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper
    from textwrap import TextWrapper

# Generated at 2022-06-21 13:07:06.568167
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Quick unit test for class AnsiTextWrapper."""

# Generated at 2022-06-21 13:07:10.293336
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa: D103
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# noinspection PyProtectedMember

# Generated at 2022-06-21 13:07:21.515258
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from .ansi import strip_ansi

    from flutils.txtutils import AnsiTextWrapper
    from textwrap import TextWrapper


# Generated at 2022-06-21 13:07:30.109415
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:41.243621
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:13.718996
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:24.971798
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper"""
    #
    # Initialize AnsiTextWrapper object
    #
    _wrapper = AnsiTextWrapper(width=40)
    #
    # text with ANSI codes
    #

# Generated at 2022-06-21 13:09:32.126884
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(('foo', 'bar')) == 6
    assert len_without_ansi(['foo', 'bar', '\x1b[38;5;209mfoobar']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    return



# Generated at 2022-06-21 13:09:39.159298
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:51.494533
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # noqa: D103
    from textwrap import TextWrapper


# Generated at 2022-06-21 13:10:02.052473
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:12.608198
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    cases = [
        [
            'Width must be at least 1.',
            dict(width=-1)
        ],
        [
            'Placeholder must be at least 1 character.',
            dict(placeholder='')
        ],
        [
            'Placeholder cannot be longer than width.',
            dict(placeholder='..................................................................', width=1)
        ],
        [
            'Initial indent cannot be longer than width.',
            dict(initial_indent='..................................................................', width=1)
        ],
        [
            'Subsequent indent cannot be longer than width.',
            dict(subsequent_indent='..................................................................', width=1)
        ]
    ]


# Generated at 2022-06-21 13:10:21.627428
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test for len_without_ansi()."""
    from pytest import raises

    assert len_without_ansi('') == 0

    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(('foo', 'bar')) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar']) == 6

# Generated at 2022-06-21 13:10:24.793385
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-21 13:10:33.252509
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    # No need to test multi-line strings because the function splits
    # on newlines before processing anyway.


# Based on textwrap.TextWrapper (and thus inherits the same attributes)

# Generated at 2022-06-21 13:11:17.953390
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # Empty string
    assert len_without_ansi('') == 0
    # Empty list
    assert len_without_ansi([]) == 0
    # Empty tuple
    assert len_without_ansi(tuple()) == 0
    # Empty list
    assert len_without_ansi(['']) == 0
    # Empty tuple
    assert len_without_ansi((tuple(),)) == 0
test_len_without_ansi()



# Generated at 2022-06-21 13:11:28.387479
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:40.099801
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # noqa: D103
    from flutils.txtutils import AnsiTextWrapper

    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:11:42.840102
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'  # noqa
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:11:49.115332
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from io import StringIO
    from sys import stdout
    from types import SimpleNamespace

    from flutils.txtutils import AnsiTextWrapper

    original_stdout = stdout


# Generated at 2022-06-21 13:11:54.445609
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import logging
    import sys
    import unittest


# Generated at 2022-06-21 13:12:02.108867
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:12:09.408318
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:12:17.985276
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    print()
    print('AnsiTextWrapper_wrap', end=' ', file=sys.stderr)
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:12:28.038533
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:22.973564
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;209mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['foo', '\x1b[38;5;209mbar\x1b[0m']
    assert len_without_ansi(text) == 6
    text = (['foo'], ['\x1b[38;5;209mbar\x1b[0m'])
    assert len_without_ansi(text) == 6

# Generated at 2022-06-21 13:13:30.522022
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    _test_AnsiTextWrapper_wrap(AnsiTextWrapper, False)
    _test_AnsiTextWrapper_wrap(AnsiTextWrapper, True)
    _test_AnsiTextWrapper_wrap(AnsiTextWrapper, False, break_on_hyphens=False)
    _test_AnsiTextWrapper_wrap(AnsiTextWrapper, True, break_on_hyphens=False)


# Generated at 2022-06-21 13:13:37.992850
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:50.109560
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Test the method fill of class AnsiTextWrapper.
    """


# Generated at 2022-06-21 13:13:59.217822
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:10.001718
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Tests for method wrap of class AnsiTextWrapper."""


# Generated at 2022-06-21 13:14:16.626697
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:28.221633
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:40.320946
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:50.310292
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from textwrap import dedent
    from flutils.txtutils import AnsiTextWrapper
    wrapper = AnsiTextWrapper(width=40, initial_indent='INITIAL> ', placeholder='...')
    text = dedent(
        """\
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
        hendrerit eros turpis, id lacinia ex egestas ac. Maecenas dictum, diam
        ac accumsan pretium, ex enim feugiat dolor, eu dignissim ligula mauris
        at turpis."""
    )
    result = wrapper.wrap(text)