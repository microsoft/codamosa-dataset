

# Generated at 2022-06-21 13:06:59.932231
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Docstring for unit test for function len_without_ansi."""
    text1 = '\x1b[38;5;209mfoobar\x1b[0m'
    text2 = ['\x1b[38;5;209mfoo', 'bar\x1b[0m']
    assert len_without_ansi(text1) == len_without_ansi(text2) == 6



# Generated at 2022-06-21 13:07:02.994631
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:07:08.408076
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[1m文字\x1b[0m'
    assert len_without_ansi(text) == 2
    seq = ['\x1b[1m', '文字', '\x1b[0m']
    assert len_without_ansi(seq) == 2



# Generated at 2022-06-21 13:07:20.030071
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi."""
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[0mbaz']) == 9
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m', '\x1b[0mbaz')) == 9
    assert len_without_ansi(['\x1b[38;5;209mf\x1b[0m', 'ooba', 'r']) == 6
    assert len_without

# Generated at 2022-06-21 13:07:22.070278
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import doctest
    doctest.testmod(globs={'AnsiTextWrapper': AnsiTextWrapper})



# Generated at 2022-06-21 13:07:24.018745
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import doctest
    return doctest.testmod()

if __name__ == '__main__':
    test_AnsiTextWrapper()

# Generated at 2022-06-21 13:07:31.898382
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:43.476947
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:52.505949
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:58.945717
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:55.931258
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import io
    import unittest


# Generated at 2022-06-21 13:10:07.645419
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:17.743144
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:28.280067
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:38.774502
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit test for method fill of class AnsiTextWrapper."""
    import textwrap
    width = 40

# Generated at 2022-06-21 13:10:50.194413
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Example taken from:
    # https://docs.python.org/3.7/library/textwrap.html
    s = "This is a very very very very very long string."

    print(textwrap.fill(s, 1))
    print(textwrap.fill(s, 2))
    print(textwrap.fill(s, 2, initial_indent='  ', subsequent_indent='  '))
    print(textwrap.fill(s, 30))
    print()

    print(AnsiTextWrapper(width=1, initial_indent='  ',
                          subsequent_indent='  ').fill(s))
    print(AnsiTextWrapper(width=2, initial_indent='  ',
                          subsequent_indent='  ').fill(s))

# Generated at 2022-06-21 13:11:00.894277
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\u001b[38;5;209mfoobar\u001b[0m') == 6
    assert len_without_ansi('\u001b[38;5;209mfoo\u001b[0mbar') == 6
    assert len_without_ansi('\u001b[38;5;209mfoo\u001b[0m\u001b[38;5;209mbar') == 6
    assert len_without_ansi(['\u001b[38;5;209mfoo\u001b[0m', '\u001b[38;5;209mbar']) == 6
    assert len_without_ansi(['\u001b[38;5;209mfoo\u001b[0m', 'bar']) == 8
    assert len_

# Generated at 2022-06-21 13:11:08.840521
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper
    from textwrap import TextWrapper
    assert AnsiTextWrapper(width=40).wrap('') == []
    assert AnsiTextWrapper(width=40).wrap('[...]') == []
    assert AnsiTextWrapper(width=40).wrap(' Lorem ipsum ') == ['Lorem ipsum']
    assert AnsiTextWrapper(
        width=40
    ).wrap(' Lorem ipsum dolor sit amet, consectetur adipiscing elit.') == [
        'Lorem ipsum dolor sit amet, consectetur',
        'adipiscing elit.',
    ]

# Generated at 2022-06-21 13:11:12.865824
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    result = len_without_ansi(text)
    assert result == 6
test_len_without_ansi()



# Generated at 2022-06-21 13:11:24.185720
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # If a max_lines is set to one, a call to wrap() should return a list
    # of one item, so that the first line can be used.
    assert AnsiTextWrapper(max_lines=1).wrap('abc 123 xy\nabc 123 xy\nabc 123 xy') == ['[...]']
    # The following is a functional test for method wrap() in
    # txtutils.AnsiTextWrapper.

# Generated at 2022-06-21 13:13:08.566468
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_data = [
        ('\x1b[38;5;209mfoobar\x1b[0m', 6),
        (('\x1b[38;5;209mfoobar\x1b[0m',), 6),
        (['\x1b[38;5;209mfoobar\x1b[0m'], 6),
    ]
    for data, expected in test_data:
        out = len_without_ansi(data)
        assert out == expected



# Generated at 2022-06-21 13:13:21.541714
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from random import randint
    from unittest.mock import Mock, patch

    seq = Mock(spec=Sequence)
    seq.__iter__.return_value = iter('\x1b[0m\x1b[31mfoobar\x1b[0m')
    seq.__len__.return_value = 42
    seq.__getitem__.side_effect = lambda i: '\x1b[0m\x1b[31mfoobar\x1b[0m'[i]

# Generated at 2022-06-21 13:13:27.569008
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text, text]) == 12
# /Unit test for function len_without_ansi



# Generated at 2022-06-21 13:13:28.907138
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    assert AnsiTextWrapper()


# Generated at 2022-06-21 13:13:36.175578
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[1mbold\x1b[0m') == 4
    assert len_without_ansi('\x1b[1m\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[1m', '\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-21 13:13:48.620504
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .txtutils import len_without_ansi
    from .types import StrOrListOfStr
    str_or_list_of_str: StrOrListOfStr
    assert len_without_ansi('') == 0
    assert len_without_ansi('a') == 1
    assert len_without_ansi('ab') == 2
    str_or_list_of_str = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(str_or_list_of_str) == 6
    str_or_list_of_str = '\x1b[38;5;209mfoobar\x1b[0m_foobar'
    assert len_without_ansi(str_or_list_of_str) == 12
   

# Generated at 2022-06-21 13:13:58.420240
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from flutils.txtutils import AnsiTextWrapper
    wrapper = AnsiTextWrapper()
    wrapper = AnsiTextWrapper(width=70)
    wrapper = AnsiTextWrapper(width=70, initial_indent='   ',
                              subsequent_indent='   ')
    wrapper = AnsiTextWrapper(width=70, initial_indent='   ',
                              subsequent_indent='   ', expand_tabs=False)
    wrapper = AnsiTextWrapper(width=70, initial_indent='   ',
                              subsequent_indent='   ', expand_tabs=False,
                              replace_whitespace=False)

# Generated at 2022-06-21 13:14:09.682042
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:14:16.454986
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:19.336208
# Unit test for function len_without_ansi
def test_len_without_ansi():
    mystr = "Hello\x1b[38;5;209mfoobar\x1b[0m"
    assert len_without_ansi(mystr) == 6
