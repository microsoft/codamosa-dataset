

# Generated at 2022-06-21 13:06:57.489371
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils._testing.test_len_without_ansi import _test
    _test()


# Generated at 2022-06-21 13:07:07.236857
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:16.766147
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    ansi_color = '\x1b[38;5;209m'
    text = ansi_color + 'foobar' + '\x1b[0m'
    assert len(text) == 16
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    list_of_text = [text, text]
    assert len_without_ansi(list_of_text) == 12
test_len_without_ansi()
del test_len_without_ansi



# Generated at 2022-06-21 13:07:20.581948
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', 'foo']) == 9


# Generated at 2022-06-21 13:07:29.345375
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper
    # We are not using -> str, because the output does not contain
    # line breaks, the output is an ANSI string.
    out = AnsiTextWrapper(width=40).fill('\x1b[0m\x1b[1mHello World!')
    assert repr(out) == repr('\x1b[0m\x1b[1mHello World!')

    # We are not using -> str, because the output does not contain
    # line breaks, the output is an ANSI string.
    out = AnsiTextWrapper(width=20).fill('\x1b[0m\x1b[1mHello World!')
    assert repr(out) == repr('\x1b[0m\x1b[1mHello\nWorld!')

# Generated at 2022-06-21 13:07:38.823507
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper"""
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.placeholder == ' [...]'
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None


# Generated at 2022-06-21 13:07:48.702373
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Unicode
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    # String
    assert len_without_ansi(b'\x1b[38;5;209mfoobar\x1b[0m') == 6
    # List of strings
    assert len_without_ansi([b'\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    # List of bytes
    assert len_without_ansi([b'\x1b[38;5;209m', b'foobar', b'\x1b[0m']) == 6



# Generated at 2022-06-21 13:07:50.896539
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """
    Run doctests on method wrap of class AnsiTextWrapper
    """
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-21 13:08:02.332315
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:08:15.032519
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:08:41.022536
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:08:43.494507
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:08:51.538412
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    def test_kwargs(**kwargs):
        wrapper = AnsiTextWrapper(**kwargs)
        wrapped_text = wrapper.fill(text)
        out_lines = wrapped_text.splitlines()
        assert len(out_lines) == correct_lines
        if correct_lines < 11:
            assert wrapper.placeholder not in out_lines
        else:
            assert (
                out_lines[10] ==
                '{}[...]'.format(wrapper.subsequent_indent)
            )
        for line in out_lines[:10]:
            assert len_without_ansi(line) == 40

# Generated at 2022-06-21 13:09:02.749317
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='\x1b[31m\x1b[1m\x1b[4m',
        subsequent_indent='\x1b[0m',
        placeholder=' [...]'
    )

# Generated at 2022-06-21 13:09:10.040917
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:09:17.052171
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:26.880049
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(
        width=40,
        max_lines=None,
        initial_indent='',
        subsequent_indent='',
        expand_tabs=True,
        replace_whitespace=True,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=8,
        placeholder=' [...]'
    )

# Generated at 2022-06-21 13:09:31.272215
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:39.789585
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:51.900463
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:19.353289
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:31.747309
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-21 13:10:40.339399
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None
    assert wrapper.placeholder.lstrip() == ' [...]'


# Generated at 2022-06-21 13:10:50.875847
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40, initial_indent='    ',
                              expand_tabs=False, replace_whitespace=False)

# Generated at 2022-06-21 13:10:53.911979
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:11:04.061712
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from io import StringIO
    from sys import stdout

    # Create a fresh wrapper each time
    def wrapper() -> AnsiTextWrapper:
        return AnsiTextWrapper(width=19, break_long_words=True)
    # A function to test the implementation
    def test(text: str, width: int = 19, sysout: bool = False):
        wrap = wrapper()
        if width:
            wrap.width = width
        wr = wrap.wrap(text)
        if sysout:
            stdout.writelines(wr)
        return wr
    # Finish this sentence... with wrap() method
    t = "The quick brown fox jumped over the lazy dog."
    assert test(t, 0) == ['The quick brown fox', 'jumped over the', 'lazy dog.']

# Generated at 2022-06-21 13:11:13.659597
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test wrap in class AnsiTextWrapper."""

# Generated at 2022-06-21 13:11:24.644603
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from .ansitextwrapper import AnsiTextWrapper
    wrapper = AnsiTextWrapper(
        width=40,
        subsequent_indent='    ',
        placeholder=' [...]'
    )

# Generated at 2022-06-21 13:11:30.069836
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from tests.txtutils import assert_function_output

    out1 = '\x1b[38;5;209mfoobar\x1b[0m'
    out2 = ('\x1b[31mfoo\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m', '\x1b[34mbaz\x1b[0m')
    assert_function_output(
        len_without_ansi,
        (out1, ),
        6,
    )
    assert_function_output(
        len_without_ansi,
        (out2, ),
        6,
    )



# Generated at 2022-06-21 13:11:42.402812
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:59.843323
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    return



# Generated at 2022-06-21 13:12:07.814325
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    import unittest

    class TestAnsiTextWrapper(unittest.TestCase):
        """Create a class to test the :obj:`AnsiTextWrapper` class."""

        # Test that AnsiTextWrapper constructor throws ValueError if placeholder
        # is too long.
        def test_ValueError_placeholder_too_long(self):
            """Test that AnsiTextWrapper constructor throws ValueError if
            placeholder is too long."""
            with self.assertRaises(ValueError):
                AnsiTextWrapper(max_lines=1, placeholder='abcde' * 7,
                                width=40)

        # Test that AnsiTextWrapper constructor throws ValueError if indent
        # is too long.

# Generated at 2022-06-21 13:12:17.254268
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=49)

# Generated at 2022-06-21 13:12:27.710978
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import ansiescapes
    from flutils.ansiutils import AnsiStr


# Generated at 2022-06-21 13:12:38.647098
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit test for method fill of class AnsiTextWrapper"""

# Generated at 2022-06-21 13:12:43.743121
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:12:55.537086
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:12:58.431733
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = ' \x1b[38;5;209mfoobar\x1b[0m '
    out = len_without_ansi(text)
    expected = 6
    assert out == expected



# Generated at 2022-06-21 13:13:10.289779
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:22.645099
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:48.900125
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:57.041834
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:04.562430
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        'bazquux!',
        '\x1b[38;5;209mThis is only a test.'
    ]
    assert len_without_ansi(text) == 28


# Generated at 2022-06-21 13:14:14.167148
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # A string
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len(text) == len('\x1b[38;5;209m') + len('foobar') + len('\x1b[0m')
    # A list
    text = ['\x1b[38;5;209mfoobar', '\x1b[0m']
    assert len_without_ansi(text) == 6
    assert len(text) == 2
    # A tuple
    text = ('\x1b[38;5;209mfoobar', '\x1b[0m')
    assert len_without_ansi(text) == 6
    assert len(text) == 2
    # A

# Generated at 2022-06-21 13:14:25.821306
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # arrange
    from . import AnsiTextWrapper
    from . import fix_text_with_ansi

# Generated at 2022-06-21 13:14:33.406944
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:34.751191
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    t = AnsiTextWrapper()
    assert t.width == 70


# Generated at 2022-06-21 13:14:45.753386
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:53.926788
# Unit test for function len_without_ansi
def test_len_without_ansi():
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(_text) == 6
    _list = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(_list) == 6
    _tuple = ('\x1b[38;5;209m', 'foobar', '\x1b[0m')
    assert len_without_ansi(_tuple) == 6
    _ansi = '\x1b[38;5;209m'
    assert len_without_ansi(_ansi) == 0
test_len_without_ansi()



# Generated at 2022-06-21 13:15:04.567114
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:15:31.806206
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit tests for :obj:`AnsiTextWrapper`."""
    wrapper = AnsiTextWrapper()
    assert len(wrapper.__dict__.keys()) == 16
    assert wrapper.__dict__['__initial_indent'] == ''
    assert len(wrapper.__dict__['__initial_indent']) == 0
    assert wrapper.__dict__['__subsequent_indent'] == ''
    assert len(wrapper.__dict__['__subsequent_indent']) == 0
    assert wrapper.__dict__['__placeholder'] == ''
    assert len(wrapper.__dict__['__placeholder']) == 0
    assert 'initial_indent_len' in wrapper.__dict__.keys()
    assert wrapper.__dict__['initial_indent_len'] == 0

# Generated at 2022-06-21 13:15:39.953996
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoo\x1b[0m', 'bar\x1b[0m']
    assert len_without_ansi(text) == 13



# Generated at 2022-06-21 13:15:43.881739
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6

