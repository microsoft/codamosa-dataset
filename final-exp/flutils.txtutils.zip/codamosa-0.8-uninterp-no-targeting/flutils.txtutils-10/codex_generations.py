

# Generated at 2022-06-21 13:07:12.325739
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper
    unless = unless_platform(platform='Windows', on_windows=False,
                             on_others=True)

# Generated at 2022-06-21 13:07:22.779146
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from copy import copy
    from random import randint
    from unittest import TestCase

    class LenWithoutAnsiTestCase(TestCase):
        def _check(self, text: str) -> None:
            self.assertEqual(len(text), len_without_ansi(text))

        def test_with_ansi_codes(self) -> None:
            self._check('\x1b[38;5;209mfoobar\x1b[0m')
            self._check('\x1b[38;5;209mfoo\x1b[0m')
            self._check('\x1b[38;5;209m\x1b[0m')
            self._check('\x1b[38;5;209m')
            self._check('\x1b[0m')

       

# Generated at 2022-06-21 13:07:31.143032
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper.

    Testing the wrap method of class AnsiTextWrapper in flutils.txtutils.
    """
    # Create a list of strings to test.

# Generated at 2022-06-21 13:07:33.206957
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    print(AnsiTextWrapper(width=40))


# Generated at 2022-06-21 13:07:36.069134
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:07:47.846696
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:52.603927
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:08:02.555402
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:08:15.337000
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # noqa: D103
    from flutils.txtutils import AnsiTextWrapper
    import pytest


# Generated at 2022-06-21 13:08:24.555453
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert (len_without_ansi(str('\x1b[38;5;209mfoobar\x1b[0m')) == 6)  # noqa: E501
    assert (len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6)
    assert (len_without_ansi(['\x1b[38;5;209mfoobar', '\x1b[0m']) == 6)
    assert (
        len_without_ansi(['\x1b[38;5;209m', 'foobar\x1b[0m']) == 6
    )  # noqa: E501



# Generated at 2022-06-21 13:10:20.309976
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:10:33.007668
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:35.904278
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# wrapper classes:

# Generated at 2022-06-21 13:10:40.470923
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from .tests import TEST_ANSI_STRING, test_AnsiTextWrapper_wrap_result
    from .txtutils import AnsiTextWrapper
    wrapper = AnsiTextWrapper(width=40)
    wrapped_text = wrapper.wrap(TEST_ANSI_STRING)
    assert '\n'.join(wrapped_text) == test_AnsiTextWrapper_wrap_result  # type: ignore[arg-type]


# Generated at 2022-06-21 13:10:48.320850
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """
    >>> AnsiTextWrapper(width=1)
    Traceback (most recent call last):
        ...
    ValueError: invalid width '1' (must be > 0)
    >>> AnsiTextWrapper(width=40, placeholder=' [...]', max_lines=2)
    Traceback (most recent call last):
        ...
    ValueError: placeholder too large for max width
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 13:10:59.930290
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:11:08.412767
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=5, initial_indent='> ', subsequent_indent='+', placeholder='>>')
    assert wrapper.width == 5
    assert wrapper.initial_indent == '> '
    assert wrapper.initial_indent_len == 2
    assert wrapper.subsequent_indent == '+'
    assert wrapper.subsequent_indent_len == 1
    assert wrapper.placeholder == '>>'
    assert wrapper.placeholder_len == 2
    assert wrapper.max_lines is None

    wrapper = AnsiTextWrapper(width=5, initial_indent='> ', subsequent_indent='+', placeholder='>>', max_lines=2)
    assert wrapper.width == 5
    assert wrapper.initial_indent == '> '
    assert wrapper.initial_indent_len == 2
   

# Generated at 2022-06-21 13:11:14.201616
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(
        initial_indent='\x1b[31m\x1b[1m\x1b[4m',
        subsequent_indent='\x1b[0m\x1b[38;5;208m',
        expand_tabs=False,
        width=40
    )
    print(wrapper.initial_indent)
    print(wrapper.subsequent_indent)
    print(wrapper.placeholder)
    print(wrapper.expand_tabs)
    print(wrapper.width)

if __name__ == '__main__':
    test_AnsiTextWrapper()

# Generated at 2022-06-21 13:11:25.463344
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:33.136677
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # width: int = 70,
    # initial_indent: str = '',
    # subsequent_indent: str = '',
    # expand_tabs: bool = True,
    # replace_whitespace: bool = True,
    # fix_sentence_endings: bool = False,
    # break_long_words: bool = True,
    # drop_whitespace: bool = True,
    # break_on_hyphens: bool = True,
    # tabsize: int = 8,
    # *,
    # max_lines: Optional[int] = None,
    # placeholder: str = ' [...]'
    wrapper = AnsiTextWrapper(width=40)
    # Width OK
    assert wrapper.width == 40
    # initial_indent OK
    assert wrapper.initial_indent == ''
   

# Generated at 2022-06-21 13:12:21.006710
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper

    text = (
        "This is a very long string that is helpful for testing purposes. It "
        "should wrap if the wrap method is called on this. Note  that  tabs "
        "should also be expanded and that this is quite a long string so it "
        "should definitely wrap on this. This is a very long string that is "
        "helpful for testing purposes. It should wrap if the wrap method is "
        "called on this. Note  that  tabs should also be expanded and that "
        "this is quite a long string so it should definitely wrap on this."
    )

    wrapper = AnsiTextWrapper(width=80)
    wrapped_text = wrapper.fill(text)
    assert '\n' in wrapped_text

# Generated at 2022-06-21 13:12:29.516648
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper


# Generated at 2022-06-21 13:12:32.405479
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-21 13:12:41.871601
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # noqa
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:12:53.605344
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:12:55.111836
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
test_len_without_ansi()



# Generated at 2022-06-21 13:12:57.987180
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'
    expected = ['Lorem ipsum dolor sit amet,', 'consectetur adipiscing', 'elit']
    wrapper = AnsiTextWrapper(width=25)
    wrapped_text = wrapper.wrap(text)
    assert wrapped_text == expected



# Generated at 2022-06-21 13:13:05.691771
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from string import printable
    from itertools import repeat

    # Make sure the AnsiTextWrapper instance is created as expected
    anstxtw = AnsiTextWrapper(
        width=50,
        initial_indent='\x1b[31m\x1b[1m\x1b[4m',
        subsequent_indent='\x1b[34m',
        placeholder='\x1b[0m\x1b[1m\x1b[2m[...]\x1b[0m',
    )
    assert anstxtw.initial_indent == '\x1b[31m\x1b[1m\x1b[4m'
    assert anstxtw.initial_indent_len == 0

# Generated at 2022-06-21 13:13:19.385795
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from textwrap import dedent
    text = dedent("""
           For more details, you can refer to the article:
           http://www.ugprice.com/products/dahua/bullet/
           IPC-HFW4300S-V2-3.6mm_price_20180426.html

           Thank you!
           """)
    wrapper = AnsiTextWrapper(initial_indent='* ', width=64,
                              subsequent_indent='  ')
    newtext = wrapper.fill(text)
    print(newtext)
    chars = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
    chars.reverse()
    print(chars)
    print()

# Generated at 2022-06-21 13:13:28.133614
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # noqa: D103
    from .txtutils import AnsiTextWrapper


# Generated at 2022-06-21 13:14:08.136535
# Unit test for function len_without_ansi
def test_len_without_ansi():
    r"""
    Unit tests for :func:`len_without_ansi`.

    Example:
        >>> from flutils.txtutils import len_without_ansi
        >>> len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
        6
    """
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-21 13:14:19.673620
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # noqa: D202; pylint: disable=unused-argument
    """Unit test for method wrap of class AnsiTextWrapper."""

    from flutils.txtutils import AnsiTextWrapper

    # Tests for wrap method:
    #
    #     1. Text that does not need to be wrapped
    #     2. Text that needs to be wrapped
    #     3. Text that is wrapped but has ANSI codes
    #     4. Text that has ANSI codes but does not need to be wrapped
    #     5. Text that has ANSI codes and needs to be wrapped
    #     6. Text that has ANSI codes, needs to be wrapped and has a placeholder
    #
    # For each test, we will use the same placeholder and width, so that
    # we can compare the results using difflib.
    #
    # For each test

# Generated at 2022-06-21 13:14:30.477082
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:42.011953
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:44.722394
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:14:46.465165
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    AnsiTextWrapper()


# Generated at 2022-06-21 13:14:51.540991
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text) == len(text.replace('\x1b[38;5;209m', '')
                                        .replace('\x1b[0m', ''))



# Generated at 2022-06-21 13:15:02.515575
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.tests.txtutils.test_AnsiTextWrapper_fill_data import test_fill_data
    for width, text, initial_indent, subsequent_indent, \
        placeholder, placeholder_len, placeholder_str, \
        indent_str, expected_result in test_fill_data:
        wrapper = AnsiTextWrapper(width=width,
                                  initial_indent=initial_indent,
                                  subsequent_indent=subsequent_indent,
                                  placeholder=placeholder)
        if placeholder_len != wrapper.placeholder_len:
            raise Exception('placeholder_len test failed')
        elif placeholder_str != wrapper.placeholder.lstrip():
            raise Exception('placeholder_str test failed')

# Generated at 2022-06-21 13:15:10.544498
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:15:21.957917
# Unit test for method fill of class AnsiTextWrapper