

# Generated at 2022-06-21 13:09:56.956977
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Loop through a tuple of tests varying indent parameters,
    and check the correct behavior.

    Returns:
        :obj:`True` if all tests have passed, :obj:`False` otherwise.
    """
    #
    # TEST #1
    #
    # Verify that passing invalid parameters to the constructor
    # raises the correct exceptions.
    #
    invalid_parameters = (
        (-5, ValueError),
        (-5, ValueError),
        (5, ValueError),
        (5, ValueError),
        (5, TypeError),
        (5, ValueError),
        (5, TypeError),
    )

# Generated at 2022-06-21 13:10:01.055346
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:10:11.788702
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:21.057223
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:10:34.156251
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""

    # Test 1
    wrapper = AnsiTextWrapper(width=40)
    assert (wrapper.width == 40 and
            wrapper.initial_indent == '' and
            wrapper.subsequent_indent == '' and
            wrapper.placeholder == ' [...]' and
            wrapper.expand_tabs is True and
            wrapper.replace_whitespace is True and
            wrapper.fix_sentence_endings is False and
            wrapper.break_long_words is True and
            wrapper.drop_whitespace is True and
            wrapper.break_on_hyphens is True and
            wrapper.tabsize == 8 and
            wrapper.max_lines is None)

    # Test 2
    # placeholder too large for max width

# Generated at 2022-06-21 13:10:41.200719
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    stderr = sys.stderr
    try:
        sys.stderr = StringIO()

        # Test invalid width
        with pytest.raises(ValueError):
            AnsiTextWrapper(width=-1)

        # Test invalid max_lines and width
        with pytest.raises(ValueError):
            AnsiTextWrapper(width=80, max_lines=1, placeholder=' (...)')

        # Test invalid max_lines, width and placeholder
        with pytest.raises(ValueError):
            AnsiTextWrapper(width=80, max_lines=2, placeholder=' (...)')

    finally:
        sys.stderr = stderr



# Generated at 2022-06-21 13:10:51.445984
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foobar', '\x1b[38;5;209m', 'baz']) == 9
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar']) == 6
    assert len_without_ansi(['foobar', '\x1b[0m']) == 6

# Generated at 2022-06-21 13:11:02.050956
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:08.048046
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(test_text) == 6
    test_text_2 = [
        '\x1b[38;5;209m',
        'foo',
        '\x1b[0m',
        '\x1b[38;5;199m',
        'bar',
        '\x1b[0m',
    ]
    assert len_without_ansi(test_text_2) == 6


# Generated at 2022-06-21 13:11:19.562484
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    _width: int = 70
    _max_lines: int = 5
    _initial_indent: str = '\x1b[1m\x1b[38;2;55;200;240m'
    _subsequent_indent: str = '\x1b[38;2;55;240;240m    '
    _placeholder: str = '\x1b[38;2;55;240;200m[...]\x1b[0m'
    _initial_indent_error: str = '\x1b[0m'
    _subsequent_indent_error: str = '\x1b[0m'
    _placeholder_error: str = '\x1b[0m'
    import io

# Generated at 2022-06-21 13:13:02.327571
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pytest import raises
    from flutils.txtutils import len_without_ansi
    from typing import Any
    from pytest import raises
    import flutils
    from sys import version_info as _version_info
    if flutils.compat.PYTHON_VERSION in (3, 8):
        assert len_without_ansi('foobar') == 6
        assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
        assert len_without_ansi(['foo', 'bar', 'baz']) == 6

# Generated at 2022-06-21 13:13:16.075220
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    FuncName = 'flutils.txtutils.AnsiTextWrapper.fill'

# Generated at 2022-06-21 13:13:26.141166
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils import __version__ as version
    from flutils.txtutils.utils import _get_xy, _get_tput_xy
    from flutils.txtutils.utils import _get_ansi_length, _get_shell_width

    _title = '\x1b[38;5;208mUnit test: flutils.txtutils.utils\x1b[0m' # type: str
    if hexversion >= 0x03080000:
        assert len(_title) == 39
    else:
        assert len(_title) == 42
    assert len_without_ansi(_title) == len(_title) - 12

    tw = AnsiTextWrapper(width=_get_shell_width([80,80], 'basic'))
    tw.subsequent_indent = ''

# Generated at 2022-06-21 13:13:29.304866
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-21 13:13:33.865983
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(('\x1b[38;5;209mf', 'o', 'o', 'bar\x1b[0m')) == 6

##############################################################################


# Generated at 2022-06-21 13:13:45.991783
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test wrap() method of the AnsiTextWrapper class."""
    from .txtutils import AnsiTextWrapper

    def _test(
            text: str,
            width: int,
            initial_indent: str,
            subsequent_indent: str,
            expand_tabs: bool,
            replace_whitespace: bool,
            fix_sentence_endings: bool,
            break_long_words: bool,
            drop_whitespace: bool,
            break_on_hyphens: bool,
            tabsize: int,
            expected_output: List[str]
    ) -> None:
        print(f'\n\nInput:\n{text!r}', '\n---')

# Generated at 2022-06-21 13:13:52.072864
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    olen = len(text)
    assert olen == 27
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text[:15]) == 0
    assert len_without_ansi(text[15:]) == 6
    assert len_without_ansi(text[15:15]) == 0



# Generated at 2022-06-21 13:14:00.426714
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:06.668470
# Unit test for function len_without_ansi

# Generated at 2022-06-21 13:14:18.129116
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper()