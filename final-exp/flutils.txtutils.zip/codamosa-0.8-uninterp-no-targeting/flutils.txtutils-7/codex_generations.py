

# Generated at 2022-06-21 13:07:52.786889
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Tests :func:`len_without_ansi <flutils.txtutils.len_without_ansi>`"""
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209m', 'foobar', '\x1b[0m')) == 6



# Generated at 2022-06-21 13:07:57.492904
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit test for method fill of class AnsiTextWrapper."""
    # Import modules & methods
    import doctest

    # Run the unit test(s)
    doctest.testmod(txtutils)


if __name__ == "__main__":
    test_AnsiTextWrapper_fill()

# Generated at 2022-06-21 13:08:00.028561
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:08:11.457664
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    colorama.init(True)

# Generated at 2022-06-21 13:08:18.712954
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test for flutils.txtutils.len_without_ansi."""
    assert len_without_ansi('foo') == 3

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = ['foo', '\x1b[38;5;209mfoobar\x1b[0m', 'bar']
    assert len_without_ansi(text) == 9



# Generated at 2022-06-21 13:08:27.481457
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    ''' Test AnsiTextWrapper's constructor. '''
    assert AnsiTextWrapper().initial_indent == ''
    assert AnsiTextWrapper().subsequent_indent == ''
    assert AnsiTextWrapper().placeholder == ' [...]'
    # pylint: disable=no-member
    assert AnsiTextWrapper().width == textwrap.TextWrapper().width
    assert AnsiTextWrapper().initial_indent == ''
    assert AnsiTextWrapper().subsequent_indent == ''
    assert AnsiTextWrapper().placeholder == ' [...]'
    # pylint: disable=no-member
    assert AnsiTextWrapper().width == textwrap.TextWrapper().width
    assert AnsiTextWrapper().initial_indent == ''
    assert AnsiTextWrapper().subsequent_indent == ''

# Generated at 2022-06-21 13:08:28.536803
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    return None


# Generated at 2022-06-21 13:08:39.820623
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:08:46.093220
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from . import txtutils
    from .txtutils import AnsiTextWrapper
    from .txtutils import len_without_ansi
    from .txtutils import lstrip_ansi
    from .txtutils import rstrip_ansi

    # Prepare the test data

# Generated at 2022-06-21 13:08:52.468351
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:18.081310
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:28.825792
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:39.210795
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi([
        'foobar',
        '\\x1b[38;5;209mfoobar\\x1b[0m'
    ]) == 12
    assert len_without_ansi([
        '\\x1b[38;5;209mfoobar\\x1b[0m',
        'foobar'
    ]) == 12
    assert len_without_ansi([
        '\\x1b[38;5;209mfoo',
        'bar\\x1b[0m'
    ]) == 6

# Generated at 2022-06-21 13:10:50.484145
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()

    # Test initial_indent
    #
    assert wrapper.initial_indent == ''
    with pytest.raises(TypeError) as excinfo:
        wrapper.initial_indent = None     # type: ignore
    assert str(excinfo.value) == 'initial_indent must be a string.'
    wrapper.initial_indent = '    '
    assert wrapper.initial_indent == '    '
    assert wrapper.initial_indent_len == 4
    wrapper.initial_indent = 'This is a string'
    assert wrapper.initial_indent == 'This is a string'
    assert wrapper.initial_indent_len == 16
    wrapper.initial_indent = '  \\x1b[31mred\\x1b[0m  '
    assert wrapper.initial

# Generated at 2022-06-21 13:11:01.363508
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for the constructor of class :class:`AnsiTextWrapper
    <flutils.txtutils.AnsiTextWrapper>`."""
    from flutils.txtutils import AnsiTextWrapper
    from io import StringIO
    import sys
    import textwrap
    import unittest


# Generated at 2022-06-21 13:11:09.143060
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:15.628150
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:26.486417
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    obj = AnsiTextWrapper(
        width=40,
        initial_indent='\\x1b[31m\\x1b[1m\\x1b[4m',
        subsequent_indent='\\x1b[0m',
        expand_tabs=True,
        replace_whitespace=True,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        max_lines=None,
        placeholder=' [...]'
    )

    if obj._AnsiTextWrapper__initial_indent != '\\x1b[31m\\x1b[1m\\x1b[4m':
        raise RuntimeError('Test failed')

# Generated at 2022-06-21 13:11:36.670720
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""

    # width
    wrapper = AnsiTextWrapper(width=82)
    assert wrapper.width == 82

    # initial_indent
    wrapper = AnsiTextWrapper(initial_indent='   ')
    assert len_without_ansi(wrapper.initial_indent) == 3

    # subsequent_indent
    wrapper = AnsiTextWrapper(subsequent_indent='   ')
    assert len_without_ansi(wrapper.subsequent_indent) == 3

    # expand_tabs
    wrapper = AnsiTextWrapper(expand_tabs=False)
    assert not wrapper.expand_tabs

    # replace_whitespace
    wrapper = AnsiTextWrapper(replace_whitespace=False)

# Generated at 2022-06-21 13:11:42.512509
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('foo\\x1bbaz') == 5
    assert len_without_ansi(['foo', '\x1bbaz']) == 5
    assert len_without_ansi(('foo', '\x1bbaz')) == 5

