

# Generated at 2022-06-21 13:08:37.797783
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:08:48.507515
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test to test method wrap of class AnsiTextWrapper."""
    print("Testing AnsiTextWrapper.wrap()...")

# Generated at 2022-06-21 13:09:00.750375
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:11.738110
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='\x1b[38;5;208m',
        subsequent_indent='\x1b[38;5;235m    ',
        expand_tabs=False,
        replace_whitespace=True,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=8,
        max_lines=None,
        placeholder=' [...]'
    )

# Generated at 2022-06-21 13:09:22.627359
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper
    from random import randrange


# Generated at 2022-06-21 13:09:26.174970
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    try:
        AnsiTextWrapper()
    except Exception as e:
        assert False, f'AnsiTextWrapper failed ({e})!'


# Generated at 2022-06-21 13:09:35.296675
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    # AnsiTextWrapper should wrap the text exactly like TextWrapper does,
    # except for ANSI codes
    for wrap_function in (AnsiTextWrapper, TextWrapper):
        assert wrap_function(width=40).fill(
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit. ') == \
            'Lorem ipsum dolor sit amet, consectetur\nadipiscing elit.'
        assert wrap_function(width=40, subsequent_indent='    ').fill(
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit. ') == \
            'Lorem ipsum dolor sit amet, consectetur\n    adipiscing elit.'

# Generated at 2022-06-21 13:09:47.669085
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test method ``wrap`` in class :obj:`AnsiTextWrapper`."""

# Generated at 2022-06-21 13:09:56.035356
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;9mtest\x1b[0m']
    assert len_without_ansi(text) == 13
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;9mtest\x1b[0m', '\x1b[38;5;9mtest\x1b[0m\x1b[38;5;9mtest\x1b[0m']
    assert len_without_ansi(text)

# Generated at 2022-06-21 13:10:07.929072
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Unit tests for :func:`~flutils.txtutils.AnsiTextWrapper.fill`.

    Tests:
        1. ANSI codes are stripped from input
        2. ANSI codes are added to output
        3. ANSI codes are not split by word

    """

# Generated at 2022-06-21 13:12:45.169655
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Pytest unit test for the len_without_ansi function.
    """
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text2 = ('\x1b[1m\x1b[38;5;209mfoo\x1b[0m\x1b[22m \x1b[38;5;'
             '209mbar\x1b[0m: \x1b[38;5;209mfoobar\x1b[0m')
    assert len_without_ansi(text2) == 10

# Generated at 2022-06-21 13:12:56.973201
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:05.533645
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:13:19.454607
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Default value of argument max_lines is None
    >>> wrapper = AnsiTextWrapper()
    >>> wrapper.max_lines is None
    True
    """
    pass


if __name__ == '__main__':
    # Test doctests
    import doctest
    doctest.testmod()

    # Test docstrings
    from flutils.core import _doctest
    _doctest(__name__)

    # Test the examples in the docstrings
    from flutils.core import _docstr_examples
    _docstr_examples(__name__)

    # Test the classmethod parse_ansi_colors

# Generated at 2022-06-21 13:13:24.759456
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    wrapper = AnsiTextWrapper(width=40)

    # from file ``lorem_ipsum.txt``

# Generated at 2022-06-21 13:13:35.596634
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper
    wrapper = AnsiTextWrapper()

# Generated at 2022-06-21 13:13:43.219333
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(initial_indent='a', subsequent_indent='b')
    wrapper.width = 6
    chunks = wrapper._split('a\u001b[1m\u001b[4mb')
    assert chunks == ['a', '\u001b[1m\u001b[4m', 'b']

# Test the _wrap_chunks method of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:54.535618
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:01.599540
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[38;5;196mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoo', '\x1b[38;5;196mbar\x1b[0m']
    assert len_without_ansi(text) == 6
    return True



# Generated at 2022-06-21 13:14:08.366210
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    atw = AnsiTextWrapper(
        width=40,
        initial_indent='\n\n    ',
        subsequent_indent='',
        placeholder=' [...]'
    )
    assert atw.width == 40
    assert atw.initial_indent == '\n\n    '
    assert atw.subsequent_indent == ''
    assert atw.placeholder == ' [...]'

