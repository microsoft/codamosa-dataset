

# Generated at 2022-06-21 13:08:12.318842
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    print('*'*80)

# Generated at 2022-06-21 13:08:23.212509
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest
    from .txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = r'\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 24
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mfoobar\x1b[0m',
    ]
    assert len_without_ansi(text) == 6

# Generated at 2022-06-21 13:08:29.707005
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test :obj:`AnsiTextWrapper`."""
    w = AnsiTextWrapper()
    assert w.width == 70

    w = AnsiTextWrapper(width=12)
    assert w.width == 12

    w = AnsiTextWrapper(width=0)
    assert w.width == 70

    w = AnsiTextWrapper(width=12, initial_indent='>>>')
    assert w.initial_indent == '>>>'

    w = AnsiTextWrapper(width=12, subsequent_indent='>>>')
    assert w.subsequent_indent == '>>>'

    w = AnsiTextWrapper(width=12, placeholder='>>>')
    assert w.placeholder == '>>>'


# Generated at 2022-06-21 13:08:40.733624
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from flutils.systemutils import get_terminal_size

    output_width, _ = get_terminal_size()
    output_width = min(output_width, 80)
    test_width = int(output_width * 0.25)

# Generated at 2022-06-21 13:08:49.964545
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:01.481299
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # pragma: no cover
    """Unit test for method fill of class AnsiTextWrapper"""
    import bz2
    import base64
    from io import BytesIO
    from unittest import TestCase
    from textwrap import TextWrapper
    from flutils.txtutils import AnsiTextWrapper
    from flutils.tests.testres import SAMPLE_TEXT
    from flutils.tests._helpers import ArgParseException

    class _AnsiTextWrapperTests(TestCase):

        def test_width_negative(self):
            text = SAMPLE_TEXT
            wrapper = AnsiTextWrapper(width=-1)
            with self.assertRaises(ValueError):
                wrapper.fill(text)

        def test_placeholder_larger_than_max_width(self):
            text = SAMPLE_TEXT


# Generated at 2022-06-21 13:09:09.749444
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text1 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text1) == 6
    text2 = 'hello'
    assert len_without_ansi(text2) == len(text2)
    text3 = ['hello', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text3) == (
        len_without_ansi(text3[1]) + len_without_ansi(text3[0]))


# Generated at 2022-06-21 13:09:16.848038
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[1mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[1mfoo\x1b[0mbar') == 6
    assert len_without_ansi(['\x1b[1mfoo', 'bar\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[1mfoo', 'bar\x1b[0m')) == 6
    assert len_without_ansi(['\x1b[1mfoo', '\x1b[0m', 'bar']) == 6
    assert len_without_ansi(('\x1b[1mfoo', '\x1b[0m', 'bar')) == 6
    assert len_without

# Generated at 2022-06-21 13:09:26.708686
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from argparse import Namespace
    from flutils.txtutils import AnsiTextWrapper

    # Start with default args.
    args = Namespace()
    wrapper = AnsiTextWrapper(**vars(args))
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None
    assert wrapper.placeholder == ' [...]'
    assert wrapper.width == 70

    args

# Generated at 2022-06-21 13:09:35.557917
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:21.959076
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.tests.helpers import assert_equal
    from flutils.tests.helpers import assert_is

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert_is(len_without_ansi(text), 6)

    text2 = '\x1b[38;5;209mthis is foobar\x1b[0m'
    assert_is(len_without_ansi(text2), 13)

    text3 = 'this is \x1b[38;5;209mfoobar\x1b[0m'
    assert_is(len_without_ansi(text3), 13)

    text4 = '\x1b[38;5;209mf\x1b[0mobar'

# Generated at 2022-06-21 13:10:34.708140
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for the :obj:`flutils.txtutils.AnsiTextWrapper` class."""

# Generated at 2022-06-21 13:10:47.647844
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:58.877476
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper
    from random import choice, randint
    from string import ascii_letters, digits

    for _ in range(10):
        width = choice((None, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 100))
        initial_indent = ''.join(choice(ascii_letters + digits)
                                 for _ in range(randint(0, 10)))
        subsequent_indent = ''.join(choice(ascii_letters + digits)
                                    for _ in range(randint(0, 10)))
        expand_tabs = choice((True, False))
        replace_whitespace = choice((True, False))
        fix_sentence_endings = choice((True, False))
        break_long_words = choice

# Generated at 2022-06-21 13:11:07.825516
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # noqa: D202
    """Test class :obj:`AnsiTextWrapper <flutils.txtutils.AnsiTextWrapper>`."""
    from io import StringIO
    from flutils.txtutils import AnsiTextWrapper

    def _test(
            max_length: int,
            expected_output: List[str],
            color: Optional[Tuple[int, int, int]] = None,
            background: Optional[Tuple[int, int, int]] = None
    ) -> None:
        """Test against expected output."""

# Generated at 2022-06-21 13:11:18.966212
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-21 13:11:20.518885
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar', '\x1b[0m']) == 6



# Generated at 2022-06-21 13:11:30.048532
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import textwrap
    tw1 = textwrap.TextWrapper()
    at1 = AnsiTextWrapper()
    text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    assert (
        tw1.wrap(text) == at1.wrap(text)
    ), 'AnsiTextWrapper.wrap() is not working as expected'
    text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n' \
           'Pellentesque habitant morbi tristique senectus et netus et ' \
           'malesuada fames ac turpis egestas. Maecenas ultricies lacus id ' \
           'massa interdum dignissim. Curabitur efficitur ante sit amet nibh '

# Generated at 2022-06-21 13:11:42.353689
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:49.327997
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper"""
    # NOTE: I have disabled coverage for this function because I have
    #       disabled coverage for the method AnsiTextWrapper._wrap_chunks:
    #       it is called only by the method AnsiTextWrapper.wrap, and
    #       the method AnsiTextWrapper.wrap is fully tested and covered
    #       by the method test_AnsiTextWrapper_fill.

# Generated at 2022-06-21 13:13:01.372097
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:14.348520
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:25.168257
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """
    Unit test for
    :obj:`~flutils.txtutils.AnsiTextWrapper.wrap` method of
    :obj:`~flutils.txtutils.AnsiTextWrapper` and
    :obj:`~flutils.txtutils.AnsiTextWrapper.fill` method of
    :obj:`~flutils.txtutils.AnsiTextWrapper`.
    """

# Generated at 2022-06-21 13:13:35.594274
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper
    text_wrapper = AnsiTextWrapper(
        width=40, placeholder=' [...]'
    )

# Generated at 2022-06-21 13:13:47.833063
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Test :obj:`fill <flutils.txtutils.AnsiTextWrapper>` of
    :obj:`~flutils.txtutils.AnsiTextWrapper`."""


# Generated at 2022-06-21 13:13:57.755941
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    t = AnsiTextWrapper(width=40)


# Generated at 2022-06-21 13:14:09.389279
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:20.312879
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    #
    # Basic sanity check
    #
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:14:30.796986
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:42.135317
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # pragma: no cover
    # TODO: Improve this test
    import sys
    import contextlib
    from io import StringIO
    from typing import Any
    from textwrap import indent

    @contextlib.contextmanager
    def stdout_redirect(where: Any) -> Any:
        sys.stdout = where
        try:
            yield where
        finally:
            sys.stdout = sys.__stdout__

    def run_and_capture_output(
            func: Callable[[], Any],
            *args: Any,
            **kwargs: Any) -> str:
        with stdout_redirect(StringIO()) as new_stdout:
            func(*args, **kwargs)
            return new_stdout.getvalue()
