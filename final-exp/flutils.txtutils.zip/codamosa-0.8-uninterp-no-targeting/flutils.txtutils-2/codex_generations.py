

# Generated at 2022-06-21 13:08:51.609836
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:02.786203
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:10.075850
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:11.346227
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import doctest  # type: ignore
    doctest.testmod()


# Generated at 2022-06-21 13:09:16.835129
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6
    text = 'foobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-21 13:09:24.683433
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\\x1b[38;5;209mfoobar\\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ('\\x1b[38;5;209m', 'foobar', '\\x1b[0m')
    assert len_without_ansi(text) == 6


# Unit tests for function len_without_ansi
#test_len_without_ansi()



# Generated at 2022-06-21 13:09:27.853980
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """
    """
    # Tests for the wrap method of the AnsiTextWrapper class
    #
    # Arrange

    #
    # Act

    #
    # Assert

    pass



# Generated at 2022-06-21 13:09:36.429527
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:48.938845
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:53.907889
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:10:21.850690
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:34.615927
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:47.554206
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    # Setup an AnsiTextWrapper instance
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:10:58.815555
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit tests for the ``AnsiTextWrapper`` class:
        1. Test that ``__init__`` does not raise an exception.
        2. Test that the text is not modified by ``AnsiTextWrapper``.
    """
    # Test that __init__ does not raise an exception
    # Initialize an AnsiTextWrapper object with all of its default values
    default_wrapper = AnsiTextWrapper()
    # Initialize an AnsiTextWrapper object with specified values

# Generated at 2022-06-21 13:11:07.795207
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:18.911771
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    # Get the long string text
    text = te_utils.get_text()

    # Test a string of length less than the limit, 70 by default
    wrapper = AnsiTextWrapper()
    wrapped_text = wrapper.fill(text[:30])
    assert len(wrapped_text) == len(text[:30])

    # Test a string of length greater than the limit, 70 by default
    wrapper = AnsiTextWrapper()
    wrapped_text = wrapper.fill(text)
    assert len(wrapped_text) == len(text)

    # Test the string without ANSI codes
    wrapper = AnsiTextWrapper()
    wrapped_text = wrapper.fill(text[3:])
    assert len(wrapped_text) == len(text[3:])

    # Test the string with ANSI codes
    wrapper = An

# Generated at 2022-06-21 13:11:29.207579
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:34.982374
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper"""
    from flutils.txtutils import AnsiTextWrapper
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:11:44.865792
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:57.061510
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.pyutils import Stopwatch
    from string import printable as printable_chars
    from random import choice

    def gen_text(length: int) -> str:
        """Generates a string of text of the specified length."""
        return ''.join(choice(printable_chars) for _ in range(length))

    def test_wrap(
            text: str,
            width: int,
            max_lines: Optional[int] = None
    ) -> None:
        """Tests the wrap method of AnsiTextWrapper without modification."""
        if max_lines:
            wrapper = textwrap.TextWrapper(
                width=width, max_lines=max_lines)
        else:
            wrapper = textwrap.TextWrapper(width=width)
        lines = wrapper.wrap(text)
        out

# Generated at 2022-06-21 13:12:23.322587
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:12:30.610335
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import textwrap
    # Get the example text from the AnsiTextWrapper docstring
    text = AnsiTextWrapper.__init__.__doc__.split(
        '**Example**:')[1].splitlines()[1:]
    # textwrap could not handle the ANSI codes
    if True:
        text = ''.join([x[x.find('\\x1b[') + 4: x.find('m', x.find('\\x1b[') +
                                                       4) + 1] for x in text])
        text = ''.join([x[x.find('\\x1b[') + 4: x.find('m', x.find('\\x1b[') +
                                                       4) + 1] for x in text])

# Generated at 2022-06-21 13:12:40.573342
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils import txtutils

    fpath = "./tests/test_txtutils/test_len_without_ansi.json"
    import json
    from flutils.jsonutils import load_list_of_dicts
    from os.path import isfile
    json_data: Optional[List[dict]]
    if isfile(fpath):
        json_data = load_list_of_dicts(fpath)

    def _assert_success(output: int, expect: int, text: str):
        assert output == expect, (
            '{!r} => {} != {}'.format(text, output, expect)
        )


# Generated at 2022-06-21 13:12:52.525105
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test for method ``flutils.txtutils.AnsiTextWrapper.wrap``

    Tests pairings of
    ``flutils.txtutils.AnsiTextWrapper(width, initial_indent, subsequent_indent,
    expand_tabs, replace_whitespace, fix_sentence_endings, break_long_words,
    drop_whitespace, break_on_hyphens, tabsize, max_lines, placeholder)``
    and the result of calling the ``.wrap`` method on the AnsiTextWrapper
    instance, with
    ``txtutils.AnsiTextWrapper(width=40, max_lines=None, placeholder=' [...]')``
    and the result of calling
    ``textwrap.TextWrapper(width=40, max_lines=None, placeholder=' [...]')``.
    """

# Generated at 2022-06-21 13:13:01.872386
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # We have to assert the inner text first because
    # it's likely to change the most, while the wrapped
    # text is likely to not change.
    from unittest.mock import call
    from .mock import patch
    from .mock import sentinel

    # Good string
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    exp = 6
    with patch('flutils.txtutils.AnsiTextWrapper.unwrapped_len_without_ansi',
               return_value=exp, new_callable=lambda: sentinel.func) as m:
        assert exp == len_without_ansi(text)
        m.assert_called_once_with(text)
    m.reset_mock()

    # List

# Generated at 2022-06-21 13:13:02.865241
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 13:13:16.490989
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""

    # Region test AnsiTextWrapper()
    wrapper = AnsiTextWrapper()
    assert isinstance(wrapper, AnsiTextWrapper)
    # Endregion

    # Region test AnsiTextWrapper(width)
    wrapper = AnsiTextWrapper(width=40)
    assert isinstance(wrapper, AnsiTextWrapper)
    # Endregion

    # Region test AnsiTextWrapper(width, initial_indent)
    wrapper = AnsiTextWrapper(width=40, initial_indent='> ')
    assert isinstance(wrapper, AnsiTextWrapper)
    # Endregion

    # Region test AnsiTextWrapper(width, initial_indent, subsequent_indent)

# Generated at 2022-06-21 13:13:26.312773
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Unit test for method fill of class AnsiTextWrapper.
    
    The test is based on the example
    in ``flutils.txtutils.AnsiTextWrapper.__doc__``.
    """
    import os
    import tempfile
    import pathlib
    from shutil import rmtree
    from flutils.txtutils import AnsiTextWrapper
    from flutils.txtutils import AnsiTextWrapper_example_result

# Generated at 2022-06-21 13:13:36.259777
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.ansitxtutils import AnsiTextWrapper

    ANSI_STRING = '\x1b[38;5;196mLorem ipsum dolor sit amet, consectetur adipiscing elit. \x1b[0m'
    result = AnsiTextWrapper(width=30).wrap(ANSI_STRING)

    assert result == [
        '\x1b[38;5;196mLorem ipsum dolor\x1b[0m',
        '\x1b[38;5;196msit amet, consectetur\x1b[0m',
        '\x1b[38;5;196madipiscing elit.\x1b[0m',
    ]


# Generated at 2022-06-21 13:13:48.675858
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-21 13:14:32.931695
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # width must be > 0
    with pytest.raises(ValueError) as excinfo:
        AnsiTextWrapper(width=0)
    assert excinfo.match("invalid width '0' (must be > 0)")
    with pytest.raises(ValueError) as excinfo:
        AnsiTextWrapper(width=-1)
    assert excinfo.match("invalid width '-1' (must be > 0)")
    # max_lines must be None or >= 1
    with pytest.raises(ValueError) as excinfo:
        AnsiTextWrapper(max_lines=0)
    assert excinfo.match("max_lines must be None or >= 1")
    # placeholder too large for max width

# Generated at 2022-06-21 13:14:43.833714
# Unit test for function len_without_ansi
def test_len_without_ansi():  # noqa: D103
    assert len_without_ansi('') == 0
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    assert len_without_ansi(['\\x1b[38;5;209m', 'foobar', '\\x1b[0m']) == 6
    assert len_without_ansi(['\\x1b[38;5;209mfoobar\\x1b[0m', '\\x1b[0m']) == 6

# Generated at 2022-06-21 13:14:53.358946
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    width = 40

# Generated at 2022-06-21 13:15:04.028027
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:15:11.313215
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper"""
    if __debug__:
        wrapper = AnsiTextWrapper(width=42)
        assert isinstance(wrapper, AnsiTextWrapper)
        assert isinstance(wrapper, TextWrapper)
        assert wrapper.__class__.__bases__[0].__name__ == 'TextWrapper'
        assert wrapper.__class__.__bases__[1].__name__ == 'object'
        assert wrapper.width == 42
        wrapper = AnsiTextWrapper(width=42, break_long_words=False)
        assert wrapper.width == 42
        assert wrapper.break_long_words is False
        assert wrapper.initial_indent == ''
        assert wrapper.initial_indent_len == 0

# Generated at 2022-06-21 13:15:22.579131
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import string


# Generated at 2022-06-21 13:15:29.252927
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    text = (
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras '
        'fermentum maximus auctor.'
    )
    wrapped_text = wrapper.fill(text)
    assert wrapped_text == (
        'Lorem ipsum dolor sit amet, consectetur\n'
        'adipiscing elit. Cras fermentum maximus\n'
        'auctor.'
    )
    # ... more tests here ...
    del text, wrapped_text, wrapper


# Generated at 2022-06-21 13:15:38.135919
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:15:48.237344
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    _initial_indent = '    '
    _subsequent_indent = '        '
    _placeholder = ' [...]'
    _expand_tabs = True
    _replace_whitespace = True
    _fix_sentence_endings = False
    _break_long_words = True
    _drop_whitespace = True
    _break_on_hyphens = True
    _tabsize = 8
    _max_lines = None
    _width = 70
    _chunks = ANSI_RE.split(text)
    _chunks = [c for c in _chunks if c]
    width_ = _width - len_without_ansi(_subsequent_indent)
    lines = []
    cur_line: List[str] = []
    cur_len = 0