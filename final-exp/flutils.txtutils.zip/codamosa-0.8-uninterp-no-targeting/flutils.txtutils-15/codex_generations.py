

# Generated at 2022-06-21 13:07:12.274674
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    atw = AnsiTextWrapper()

    assert atw.width == 70
    assert atw.initial_indent == ''
    assert atw.subsequent_indent == ''
    assert atw.expand_tabs is True
    assert atw.replace_whitespace is True
    assert atw.fix_sentence_endings is False
    assert atw.break_long_words is True
    assert atw.drop_whitespace is True
    assert atw.break_on_hyphens is True
    assert atw.tabsize == 8
    assert atw.max_lines is None
    assert atw.placeholder == ' [...]'


# Generated at 2022-06-21 13:07:22.664859
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:30.985351
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:42.753282
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from flutils.txtutils import AnsiTextWrapper
    wrapper = AnsiTextWrapper()
    assert isinstance(wrapper, AnsiTextWrapper)
    assert wrapper._getattr('width') == 70
    assert wrapper._getattr('initial_indent') == ''
    assert wrapper._getattr('subsequent_indent') == ''
    assert wrapper._getattr('expand_tabs') is True
    assert wrapper._getattr('replace_whitespace') is True
    assert wrapper._getattr('fix_sentence_endings') is False
    assert wrapper._getattr('break_long_words') is True
    assert wrapper._getattr('drop_whitespace') is True
    assert wrapper._getattr('break_on_hyphens') is True
    assert wrapper._getattr('tabsize') == 8
    assert wrapper._getattr

# Generated at 2022-06-21 13:07:47.747249
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    _text = 'This is a test.'
    _wrapper = AnsiTextWrapper(width=5)
    _output = _wrapper.fill(_text)
    assert _output == 'This\nis a\ntest.'
    _wrapper_2 = AnsiTextWrapper(width=5, initial_indent='\x1b[31m')
    _output_2 = _wrapper_2.fill(_text)
    assert _output_2 == '\x1b[31mThis\n\x1b[31mis a\n\x1b[31mtest.'
    _wrapper_3 = AnsiTextWrapper(width=5, initial_indent='\x1b[31m',
                                 subsequent_indent='|>')
    _output_3 = _wrapper_3.fill(_text)
    assert _output_

# Generated at 2022-06-21 13:07:52.350110
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:08:02.445386
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(
        width=50,
        initial_indent='',
        subsequent_indent=' ' * 4,
        placeholder='[...]',
        expand_tabs=True,
        replace_whitespace=True,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=8,
        max_lines=5
    )
    assert wrapper.width == 50
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ' ' * 4
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_

# Generated at 2022-06-21 13:08:15.190655
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    global _textfile_path  # pylint: disable=global-statement
    global _textfile_path_non_ascii  # pylint: disable=global-statement

    test_passed: bool = True

    if not _textfile_path:
        skip_test('Textfile path not available')

    try:
        # Read the textfile
        with open(_textfile_path, 'r', encoding='utf8') as textfile:
            text: str = textfile.read()
        text = text.strip()
    except OSError as e:
        raise_from(TestException('Unable to read textfile'), e)


# Generated at 2022-06-21 13:08:24.096520
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method :meth:`~flutils.txtutils.AnsiTextWrapper.wrap`.

    """

# Generated at 2022-06-21 13:08:35.471824
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi."""
    # Simple ANSI code
    text = '\x1b[0;31mredtext\x1b[0m'
    assert len_without_ansi(text) == 8
    # Code at the start
    text = '\x1b[0;31m\x1b[0;32myellowtext\x1b[0m'
    assert len_without_ansi(text) == 9
    # Code at the end
    text = '\x1b[0;31mredtext\x1b[0m\x1b[0;32m'
    assert len_without_ansi(text) == 8
    # Code in the middle

# Generated at 2022-06-21 13:09:20.291597
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit Test For AnsiTextWrapper wrap Method."""
    # Arrange

# Generated at 2022-06-21 13:09:30.814418
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for :obj:`~flutils.txtutils.AnsiTextWrapper`.

    Assumptions:
        1.  This test is only run when ::

                if __name__ == '__main__':

    Raises:
        AssertionError: if the test fails.

    Returns:
        :obj:`None`: if the test passes.
    """
    import sys
    if 'get_value' in sys._getframe(0).f_code.co_varnames:
        print()
        print('Running doctests instead of unit tests:')
        print('Use the following command to run unit tests with pytest:')
        print('python -m pytest -vv "{}"'.format(__file__))
        return
    import textwrap
    wrapper = AnsiTextWrapper()

# Generated at 2022-06-21 13:09:33.596282
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    #   GIVEN
    text = '''\x1b[31mThe quick brown fox jumped over the lazy dog. \x1b[0m'''
    #   WHEN
    wrapper = AnsiTextWrapper()
    #   THEN
    assert wrapper.width == 70
    assert wrapper.wrap(text) == [text]



# Generated at 2022-06-21 13:09:41.019540
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    t = AnsiTextWrapper(initial_indent='Initial indent',
                        subsequent_indent='Subsequent indent',
                        placeholder='Placeholder')
    assert t.initial_indent == 'Initial indent'
    assert t.initial_indent_len == 16
    assert t.subsequent_indent == 'Subsequent indent'
    assert t.subsequent_indent_len == 18
    assert t.placeholder == 'Placeholder'
    assert t.placeholder_len == 10
    assert t.width == 70
    assert t.max_lines is None


# Generated at 2022-06-21 13:09:52.683771
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(
        '\x1b[38;5;209mfoobar\x1b[0m'
    ) == 6
    assert len_without_ansi((
        '\x1b[38;5;209mfoo\x1b[0m',
        'bar\x1b[38;5;209m'
    )) == 6
    assert len_without_ansi([
        '\x1b[38;5;209m', 'foo', '\x1b[0m',
        'bar', '\x1b[38;5;209m'
    ]) == 6

# Generated at 2022-06-21 13:10:04.055180
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from unittest.mock import patch
    from contextlib import ExitStack
    from textwrap import TextWrapper
    with ExitStack() as stack:
        TextWrapper.__init__ = stack.enter_context(patch(
            'textwrap.TextWrapper.__init__',
            side_effect=TextWrapper.__init__
        ))
        AnsiTextWrapper(initial_indent='\x1b[1m')

# Generated at 2022-06-21 13:10:14.482430
# Unit test for function len_without_ansi
def test_len_without_ansi():
    t1 = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(t1) == 6
    t2 = ('foo', '\\x1b[38;5;209mb\\x1b[0mar')
    assert len_without_ansi(t2) == 7
    t3 = ('f\\x1b[38;5;209mo\\x1b[0mo', '\\x1b[38;5;209m', 'b\\x1b[0mar')
    assert len_without_ansi(t3) == 7
    t4 = ['f\\x1b[38;5;209mo\\x1b[0mo', '\\x1b[38;5;209m', 'b\\x1b[0mar']
   

# Generated at 2022-06-21 13:10:16.922068
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text1 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text1) == 6



# Generated at 2022-06-21 13:10:27.948202
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('abcde') == 5
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[38;5;209m') == 0
    assert len_without_ansi('\x1b[0m') == 0
    assert len_without_ansi('foobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', 'xyz']) == 9
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m', 'xyz')) == 9

# Generated at 2022-06-21 13:10:38.527483
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # noqa: D103
    import textwrap  # type: ignore
    import unittest  # type: ignore


# Generated at 2022-06-21 13:11:21.956661
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # pylint: disable=missing-docstring
    from .testing import assert_in, assert_not_in, assert_true
    from .txtutils import len_without_ansi

    assert_true(callable(len_without_ansi))

    # Test with a simple string
    string = '\x1b[38;5;209mfoobar\x1b[0m'
    assert_not_in(len_without_ansi(string), [7, 6])
    assert_in(len_without_ansi(string), [6, 7])

    # Test with a list of strings
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert_not_

# Generated at 2022-06-21 13:11:31.078455
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import pytest

    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:11:42.872154
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:49.138790
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from unittest import TestCase

    class AnsiTextWrapperTestCase(TestCase):
        """Unit test for ``AnsiTextWrapper`` class."""

        def test_AnsiTextWrapper_constructor(self):

            def _placeholder_too_large_for_max_width(
                    _placeholder: str,
                    _max_lines: int,
                    _max_width: int
            ) -> None:
                with self.assertRaises(ValueError):
                    AnsiTextWrapper(max_lines=_max_lines,
                                    width=_max_width,
                                    placeholder=_placeholder)

            #
            # placeholder too large for max width
            #

# Generated at 2022-06-21 13:11:56.263365
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    lines = ['\x1b[38;5;209mfoobar\x1b[0m', 'bar foo']
    assert len_without_ansi(lines) == 14
    lines = ['foo', 'bar foo']
    assert len_without_ansi(lines) == 9



# Generated at 2022-06-21 13:12:05.569360
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test class constructor of :obj:`~flutils.txtutils.AnsiTextWrapper`.
    """
    width = 40
    initial_indent = '> '
    subsequent_indent = '| '
    expand_tabs = True
    replace_whitespace = True
    fix_sentence_endings = False
    break_long_words = True
    drop_whitespace = True
    break_on_hyphens = True
    tabsize = 8
    max_lines = None
    placeholder = ' [...]'


# Generated at 2022-06-21 13:12:11.813488
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-21 13:12:20.471158
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-21 13:12:26.430400
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:12:37.383856
# Unit test for function len_without_ansi
def test_len_without_ansi():  # pragma: no cover

    from flutils.txtutils import len_without_ansi
    from nose import tools as nt

    text: str = '\x1b[38;5;209mfoobar\x1b[0m'
    nt.eq_(len_without_ansi(text), 6)

    nt.eq_(len_without_ansi(['foo', 'bar']), 6)
    nt.eq_(len_without_ansi(('foo', 'bar')), 6)
    nt.eq_(len_without_ansi(['foo', 'bar', '\x1b[38;5;209m', 'baz']), 9)

    nt.eq_(len_without_ansi('\x1b[0mblank\x1b[0m'), 6)
    nt

# Generated at 2022-06-21 13:13:22.518297
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from . import AnsiTextWrapper

# Generated at 2022-06-21 13:13:34.101441
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:46.109712
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:56.303896
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:02.632113
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit tests for method fill of class AnsiTextWrapper."""


# Generated at 2022-06-21 13:14:12.111760
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None
    assert wrapper.placeholder == ' [...]'


# Generated at 2022-06-21 13:14:17.405223
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-21 13:14:28.925339
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:40.588384
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():

    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-21 13:14:50.470139
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[1mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 6
    text = '\x1b[1mfoo\x1b[0m\x1b[4mbar'
    assert len_without_ansi(text) == 6
    text = '\x1b[1mfoo\x1b[0mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[1mfoo\x1b[0m\x1b[4mbar\x1b[0m'
    assert len_without_ansi(text) == 6