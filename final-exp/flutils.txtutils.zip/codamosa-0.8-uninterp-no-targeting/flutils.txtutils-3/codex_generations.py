

# Generated at 2022-06-21 13:06:54.609398
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:06:59.639457
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Test case: 2 (text.__class__ is not str)
    with pytest.raises(TypeError):
        AnsiTextWrapper().wrap(None)
    # Test case: 3 (text empty)
    assert AnsiTextWrapper().wrap('') == []
    # Test case: 4 (subsequent indent / placeholder too long for width)
    with pytest.raises(ValueError):
        AnsiTextWrapper(subsequent_indent=' ', placeholder='a', width=1)
    # Test case: 8, 9, 10, 11, 12, 13 (multiple consecutive newlines)
    assert AnsiTextWrapper(width=40, drop_whitespace=False).wrap('\n\n\n') == ['', '', '']

# Generated at 2022-06-21 13:07:12.148111
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # pragma: no cover
    """Unit test for method wrap of class AnsiTextWrapper"""
    text = (
        '\\x1b[31m\\x1b[1m\\x1b[4mLorem ipsum dolor sit amet, '
        'consectetur adipiscing elit. Cras fermentum maximus '
        'auctor.\\x1b[0m\\n'
        'Cras a varius ligula. Phasellus ut ipsum eu erat consequat '
        'posuere.\\x1b[0m Pellentesque habitant morbi tristique '
        'senectus et netus et malesuada fames ac turpis egestas.'
    )
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:07:17.997941
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from unittest import mock

    with mock.patch.object(AnsiTextWrapper, '_wrap_chunks') as mock_wrapped:
        text = 'Lorem ipsum'
        wrapper = AnsiTextWrapper(width=40)
        output = wrapper.fill(text)
        assert mock_wrapped.called
        assert output == text


# Generated at 2022-06-21 13:07:26.946143
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-21 13:07:37.497026
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:07:48.711438
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-21 13:08:01.242028
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test case for ``len_without_ansi``."""
    # pylint: disable=E0611, E1136, W0621
    from flutils.txtutils import len_without_ansi as _len_without_ansi
    from pytest import raises
    _text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert _len_without_ansi(_text) == 6

# Generated at 2022-06-21 13:08:13.429541
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:08:23.781997
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:08:48.202812
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:00.304306
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    a_str_1 = 'lorem ipsum dolor amet\n'.join(
        [''] + ['blah blah blah blah blah blah blah blah blah blah'] * 5
    )
    a_str_2 = u'foo\u3000bar'

    text = (
        'The quick brown fox jumps over the lazy dog.\n'
        '  The quick brown fox jumps over the lazy dog.\n'
        '\n'
        '    The quick brown fox jumps over the lazy dog.\n'
        '\n'
        '\n'
        '\n'
        '\n'
        '\n'
        '\n'
        '\n'
        '\n'
        '\n'
        '\n'
        '\n'
    )

    # Test with no indent

# Generated at 2022-06-21 13:09:11.636194
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from .utils import get_random_text
    from .txtutils import AnsiTextWrapper

    text = get_random_text()
    wrapper = AnsiTextWrapper()
    wrapped_text = wrapper.fill(text)
    assert isinstance(wrapped_text, str), \
        'Value of wrapped_text is not a string.'
    assert wrapped_text == text.replace('\n', ' '), \
        'Text was not properly wrapped.'

    text = text + '\n\n' + get_random_text()
    wrapper = AnsiTextWrapper()
    wrapped_text = wrapper.fill(text)
    assert isinstance(wrapped_text, str), \
        'Value of wrapped_text is not a string.'

# Generated at 2022-06-21 13:09:22.372079
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test the constructor of class :obj:`~flutils.txtutils.AnsiTextWrapper`.

    For example, if you provide ``width`` with a value of ``0`` or less,
    an exception should be raised.
    """
    wrapper = AnsiTextWrapper()
    assert isinstance(wrapper, AnsiTextWrapper)
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper

# Generated at 2022-06-21 13:09:32.326627
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:09:34.761087
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import doctest
    from flutils.txtutils import AnsiTextWrapper
    return doctest.run_docstring_examples(AnsiTextWrapper.fill, globals())

# Generated at 2022-06-21 13:09:46.833977
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for class AnsiTextWrapper.

    .. versionadded:: 0.7.0
    """

# Generated at 2022-06-21 13:09:55.555992
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:07.557395
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    import sys
    sys.path.append('..')

    from flutils.txtutils import AnsiTextWrapper

    wrapper = AnsiTextWrapper(width=32)
    lorem = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
    lorem += 'Cras fermentum maximus auctor. Cras a varius ligula. '
    lorem += 'Phasellus ut ipsum eu erat consequat posuere. '
    lorem += 'Pellentesque habitant morbi tristique senectus et netus '
    lorem += 'et malesuada fames ac turpis egestas. Maecenas ultricies '

# Generated at 2022-06-21 13:10:17.611241
# Unit test for function len_without_ansi
def test_len_without_ansi():
    r"""Test function ``len_without_ansi``."""
    from os import linesep
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6, 'Failed to return the character length'
    text = '\x1b[38;5;209mfoobar\x1b[0m' + linesep + '\x1b[38;5;209mfoobar\x1b[0m'  # noqa: E501
    assert len_without_ansi(text.splitlines()) == 6, 'Failed to return the character length of multiline string'  # noqa: E501

# Generated at 2022-06-21 13:10:39.466300
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:50.589856
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:10:53.962889
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-21 13:10:59.304328
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from io import StringIO
    from contextlib import redirect_stdout

    max_width = 50
    indent_spaces = 2
    indent = ' ' * indent_spaces
    output = StringIO()
    with redirect_stdout(output):
        print('\n')

        text = (
            'Sed posuere consectetur est at lobortis. Donec id elit non mi '
            'porta gravida at eget metus. Maecenas faucibus mollis interdum. '
            'Vestibulum id ligula porta felis euismod semper. Vestibulum id '
            'ligula porta felis euismod semper.'
        )
        print('\n{t!r}'.format(t=text))

# Generated at 2022-06-21 13:11:01.315151
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    assert isinstance(wrapper.width, int)


# Generated at 2022-06-21 13:11:08.841060
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from tested.testing import run_tests
    from .utils import randex, randex_list
    from .utils import randstr, randstr_list
    text = randstr()
    ansi_text = randex(text)
    assert len(ansi_text) > len(text)
    assert len_without_ansi(text) == len(text)
    assert len_without_ansi(ansi_text) == len(text)
    text = randstr_list()
    ansi_text = randex_list(text)
    assert len(ansi_text) > len(text)
    assert len_without_ansi(text) == len(text)
    assert len_without_ansi(ansi_text) == len(text)
    run_tests()



# Generated at 2022-06-21 13:11:11.884726
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-21 13:11:18.418679
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m',)) == 6


# Generated at 2022-06-21 13:11:28.784220
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:11:40.689752
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-21 13:12:05.997043
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    #
    # Testing default attribute values.
    #
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs
    assert wrapper.replace_whitespace
    assert not wrapper.fix_sentence_endings
    assert wrapper.break_long_words
    assert wrapper.drop_whitespace
    assert wrapper.break_on_hyphens
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None
    assert wrapper.placeholder == ' [...]'

    #
    # Testing constructor attributes.
    #

# Generated at 2022-06-21 13:12:13.468363
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test with string input
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    len_text = len_without_ansi(text)
    assert len_text == 6, '{!r}'.format(text)
    # Test with list input
    text = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    len_text = len_without_ansi(text)
    assert len_text == 6, '{!r}'.format(text)




# Generated at 2022-06-21 13:12:21.413525
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test constructor AnsiTextWrapper"""
    # pylint: disable=C0103
    # pylint: disable=R0913
    # pylint: disable=C0111
    import pytest
    from flutils.txtutils import AnsiTextWrapper
    from textwrap import TextWrapper

    # Test width
    with pytest.raises(ValueError) as excinfo:
        atw = AnsiTextWrapper(width=0)
    assert 'width' in str(excinfo.value)
    assert 'must be > 0' in str(excinfo.value)
    with pytest.raises(ValueError) as excinfo:
        atw = AnsiTextWrapper(width=-1)
    assert 'width' in str(excinfo.value)

# Generated at 2022-06-21 13:12:29.666480
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:12:39.901699
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:12:46.048629
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # ========================================================
    # For checking the functionality of the _split method
    class AnsiTextWrapper_test(_AnsiTextWrapper):
        def _split(self, text: str) -> List[str]:
            return super()._split(text)

    # ========================================================
    # For checking the functionality of the _wrap_chunks method
    class AnsiTextWrapper_test_test(_AnsiTextWrapper):
        def _wrap_chunks(self, chunks: List[str]) -> List[str]:
            return super()._wrap_chunks(chunks)

    # ========================================================

# Generated at 2022-06-21 13:12:56.988885
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # noqa: D103
    from doctest import testmod
    from tests.utils import FAILED_SUMMARY

    results = testmod(
        name='AnsiTextWrapper',
        globs={'AnsiTextWrapper': AnsiTextWrapper}
    )

    if (results.failed > 0 and FAILED_SUMMARY) or not results.failed:
        summary(results)

    return results.failed == 0

###############################################################################
# End of AnsiTextWrapper class
###############################################################################

# line_counter.py
###############################################################################
# This small script can be executed to count the number of lines of code
# in all of your Python scripts.
###############################################################################

# Import the function ``loc_counter`` from ``line_counter.py``.

# Generated at 2022-06-21 13:13:05.109351
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m\x1b[38;5;9mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;9mbar\x1b[0m']
    assert len_without_ansi(text) == 6

# Generated at 2022-06-21 13:13:18.182841
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:23.246647
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(('\x1b[48;5;15m', 'foobar', '\x1b[0m')) == 6
    assert len_without_ansi('foobar   ') == 6



# Generated at 2022-06-21 13:13:49.221597
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:13:58.548642
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\\x1b[38;5;209mfoo', '\\x1b[38;5;208mbar\\x1b[0m']
    assert len_without_ansi(text) == 6
    assert len_without_ansi('') == 0
    assert len_without_ansi(' ') == 1
    assert len_without_ansi([' ']) == 1
    assert len_without_ansi('\x1b[38;5;208m\x1b[0m') == 0
    assert len_without_ansi('\x1b[38;5;208m') == 0
    assert len_without_ansi

# Generated at 2022-06-21 13:14:09.640622
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # pragma: no cover
    _test_AnsiTextWrapper(initial_indent='> ', subsequent_indent='| ')
    _test_AnsiTextWrapper(initial_indent='> ', subsequent_indent='| ', max_lines=2)
    _test_AnsiTextWrapper(initial_indent='> ', subsequent_indent='| ', max_lines=3)
    _test_AnsiTextWrapper(initial_indent='> ', subsequent_indent='| ', max_lines=4)
    _test_AnsiTextWrapper(initial_indent='> ', subsequent_indent='| ', max_lines=5)
    _test_AnsiTextWrapper(initial_indent='> ', subsequent_indent='| ', max_lines=6)

# Generated at 2022-06-21 13:14:20.641063
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:31.027961
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-21 13:14:42.278609
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from unittest.mock import patch


# Generated at 2022-06-21 13:14:52.091812
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Test the default constructor
    atw = AnsiTextWrapper()
    assert atw.width == 70
    assert atw.initial_indent == ''
    assert atw.subsequent_indent == ''
    assert atw.expand_tabs == True
    assert atw.replace_whitespace == True
    assert atw.fix_sentence_endings == False
    assert atw.break_long_words == True
    assert atw.drop_whitespace == True
    assert atw.break_on_hyphens == True
    assert atw.tabsize == 8
    assert atw.max_lines == None
    assert atw.placeholder == ' [...]'

    # Test a constructor with all possible params

# Generated at 2022-06-21 13:15:03.002336
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Test for method fill of class AnsiTextWrapper."""

# Generated at 2022-06-21 13:15:10.704602
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Test with very small width
    wrapper = AnsiTextWrapper(width=1)

# Generated at 2022-06-21 13:15:21.958989
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-21 13:15:50.677591
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # All of the attributes should have the same type as their
    # corresponding :obj:`TextWrapper <textwrap.TextWrapper>` attributes.
    wrapper = AnsiTextWrapper()

    assert isinstance(wrapper.width, int)
    assert isinstance(wrapper.initial_indent, str)
    assert isinstance(wrapper.subsequent_indent, str)
    assert isinstance(wrapper.expand_tabs, bool)
    assert isinstance(wrapper.replace_whitespace, bool)
    assert isinstance(wrapper.fix_sentence_endings, bool)
    assert isinstance(wrapper.break_long_words, bool)
    assert isinstance(wrapper.drop_whitespace, bool)
    assert isinstance(wrapper.break_on_hyphens, bool)