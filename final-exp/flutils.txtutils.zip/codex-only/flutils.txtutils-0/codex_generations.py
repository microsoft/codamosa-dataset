

# Generated at 2022-06-23 18:27:03.308294
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:15.008031
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines == None
    assert wrapper.placeholder == ' [...]'
    try:
        AnsiTextWrapper(tabsize=12)
    except:
        print('Test passed.')
        return


# Generated at 2022-06-23 18:27:26.713784
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi as f
    from flutils.txtutils import ANSITextWrapper as a

    assert len_without_ansi("foobar") == 6
    assert len_without_ansi("") == 0
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m foobar']) == 12
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', 'foobar']) == 12

# Generated at 2022-06-23 18:27:36.269659
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(
        initial_indent='\\x1b[1mabc\\x1b[2mdef\\x1b[0m',
        subsequent_indent='\\x1b[3mghi\\x1b[4mjkl\\x1b[0m',
        width=10,
        placeholder='\\x1b[6;7m...\\x1b[0m',
        placeholder_len=4,
        initial_indent_len=6,
        subsequent_indent_len=5
    )

# Generated at 2022-06-23 18:27:47.778819
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from pprint import pformat
    from textwrap import TextWrapper
    from pkg_resources import resource_filename
    from flutils.txtutils import normalize_newlines

    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='',
        subsequent_indent='    ',
        expand_tabs=False,
        replace_whitespace=False,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=8,
    )


# Generated at 2022-06-23 18:27:57.369434
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Tests the instance method wrap of class AnsiTextWrapper"""
    from textwrap import TextWrapper


# Generated at 2022-06-23 18:28:01.185996
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Run the unit test for function len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:28:09.979444
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:28:19.633740
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:30.368789
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # pragma: no cover
    """
    Test for the method fill of flutils.txtutils.AnsiTextWrapper.
    """
    # from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:28:32.718337
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:28:42.469567
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # noqa: D103
    import textwrap

# Generated at 2022-06-23 18:28:54.970159
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:01.660498
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6, f'len_without_ansi() failed'
    text = ('\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;'
            '210mbar\x1b[0m', '\x1b[38;5;211mqux\x1b[0m', 'baz')
    assert len_without_ansi(text) == 9, f'len_without_ansi() failed'
test_len_without_ansi()  # noqa



# Generated at 2022-06-23 18:29:12.955818
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Test default parameters
    w = AnsiTextWrapper()
    assert w.width == 70
    assert w.initial_indent == ''
    assert w.subsequent_indent == ''
    assert w.expand_tabs is True
    assert w.replace_whitespace is True
    assert w.fix_sentence_endings is False
    assert w.break_long_words is True
    assert w.drop_whitespace is True
    assert w.break_on_hyphens is True
    assert w.tabsize == 8
    assert w.max_lines is None
    assert w.placeholder == ' [...]'

    # Test all parameters

# Generated at 2022-06-23 18:29:18.721978
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # the following ANSI-formatted string is contained in a separate module
    # for testing purposes. it is a single paragraph of lorem ipsum text
    # with a couple of words in bold, italic, and underlined, as well as
    # a couple of words with ANSI foreground colors.
    from flutils.testing.data import lorem_ipsum_ansi_formatted_text

    # test wrap method of class AnsiTextWrapper using the example
    # provided in the class documentation.
    wrapper = AnsiTextWrapper(width=40)
    wrapped_text = wrapper.wrap(lorem_ipsum_ansi_formatted_text)

# Generated at 2022-06-23 18:29:24.672200
# Unit test for function len_without_ansi
def test_len_without_ansi():
    tests = [
        (['foo', 'bar'], 7),
        ('foobar', 6),
        ('foo\x1bbaz\x1b', 6),
        (['foo', '\x1bb', 'az', '\x1b'], 6),
        ('', 0),
    ]
    for test, expected in tests:
        assert len_without_ansi(test) == expected



# Generated at 2022-06-23 18:29:32.127116
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Tests :meth:`AnsiTextWrapper.fill`."""


# Generated at 2022-06-23 18:29:40.571684
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:50.821968
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Test constructor can accept ANSI in 'initial_indent',
    # 'subsequent_indent' and 'placeholder'.
    wrapper = AnsiTextWrapper(
        width=30,
        initial_indent='\x1b[1mLorem',
        subsequent_indent='\x1b[38;2;255;0;0mipsum',
        placeholder='\x1b[38;2;0;255;0mate\x1b[0m'
    )
    assert wrapper.width == 30
    assert wrapper.initial_indent == '\x1b[1mLorem'
    assert wrapper.initial_indent_len == 5
    assert wrapper.subsequent_indent == '\x1b[38;2;255;0;0mipsum'
    assert wrapper.subsequent_indent_

# Generated at 2022-06-23 18:30:02.027724
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper."""

# Generated at 2022-06-23 18:30:08.686011
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:30:19.514628
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    width = 30

# Generated at 2022-06-23 18:30:31.325616
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from itertools import product
    import textwrap
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:30:36.504055
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = [
        'foo',
        '\x1b[38;5;240mo',
        'bar\x1b[0m',
    ]
    assert len_without_ansi(text) == 4



# Generated at 2022-06-23 18:30:37.311980
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    pass

# Generated at 2022-06-23 18:30:45.625047
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:57.140339
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:09.119317
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi"""

    def assert_len(seq: Sequence, expected: int) -> None:
        """Inner function to test the output of ``len_without_ansi(seq)``"""
        try:
            out = len_without_ansi(seq)
        except Exception as err:
            raise AssertionError(
                f'len_without_ansi({repr(seq)}) failed with: {err}'
            ) from err
        assert out == expected, (
            f'len_without_ansi({repr(seq)}) returned {repr(out)}, but '
            f'{repr(expected)} was expected.'
        )

    assert_len('foo bar', 7)

# Generated at 2022-06-23 18:31:20.558241
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import itertools
    import pprint
    from textwrap import TextWrapper


# Generated at 2022-06-23 18:31:30.347027
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:42.295565
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test method wrap of class AnsiTextWrapper."""

# Generated at 2022-06-23 18:31:53.635542
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    global _modules_loaded
    if not _modules_loaded:  # pragma: no cover
        _modules_loaded.add(__name__)
        import tests.test_txtutils
        tests.test_txtutils.test_AnsiTextWrapper_fill(globals()['AnsiTextWrapper'])


# List of all modules that have been loaded
_modules_loaded: Set[str] = set()
# Indicates whether the doctests my be run
_run_doctests: bool = False


# Run all doctests if we are being run as a script

# Generated at 2022-06-23 18:32:04.786186
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:08.024013
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:32:12.747194
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Make sure that the super class, `TextWrapper`'s constructor
    # is called.
    wrapper = AnsiTextWrapper(width=88)
    print(wrapper)

if __name__ == '__main__':
    test_AnsiTextWrapper()

# Generated at 2022-06-23 18:32:13.440741
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    pass

# Generated at 2022-06-23 18:32:21.743200
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from io import StringIO
    from contextlib import redirect_stdout
    from itertools import chain

    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:32:33.617134
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import re

# Generated at 2022-06-23 18:32:43.194399
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper"""
    # test:  width=70, initial_indent='', subsequent_indent='',
    #        expand_tabs=True, replace_whitespace=True,
    #        fix_sentence_endings=False, break_long_words=True,
    #        drop_whitespace=True, break_on_hyphens=True, tabsize=8

# Generated at 2022-06-23 18:32:47.169400
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Test the constructor of class AnsiTextWrapper to make sure
    # that it does not raise any exceptions.
    try:
        AnsiTextWrapper(width=75)
    except Exception as e:
        raise e


# Generated at 2022-06-23 18:32:59.171832
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:06.094573
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:33:16.350892
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:22.909738
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:34.441748
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:37.248712
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:33:41.796266
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:51.061690
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:01.099138
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:11.862288
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:34:14.900533
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    _len_without_ansi = len_without_ansi(text)
    assert _len_without_ansi == 6



# Generated at 2022-06-23 18:34:19.098246
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit tests for function len_without_ansi."""
    # pylint: disable=W0612
    from flutils.txtutils import len_without_ansi
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(('foo', 'bar')) == 6



# Generated at 2022-06-23 18:34:30.680756
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # No arguments:
    wrapper = AnsiTextWrapper()
    assert isinstance(wrapper, AnsiTextWrapper)

    # All arguments:
    wrapper = AnsiTextWrapper(
        width=42,
        initial_indent='\u001b[42m[',
        subsequent_indent='    ',
        expand_tabs=False,
        replace_whitespace=False,
        fix_sentence_endings=True,
        break_long_words=False,
        drop_whitespace=False,
        break_on_hyphens=False,
        tabsize=4,
        max_lines=3,
        placeholder='|>'
    )
    assert isinstance(wrapper, AnsiTextWrapper)
    assert wrapper.width == 42

# Generated at 2022-06-23 18:34:42.444370
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:53.577212
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert 6 == len_without_ansi(text)
    assert 6 == len_without_ansi([text])
    assert (
        6
        == len_without_ansi(
            ['\x1b[38;5;209mfoo', '\x1b[38;5;208mbar', '\x1b[0m']
        )
    )
    assert 6 == len_without_ansi('')
    assert 6 == len_without_ansi(['', '\x1b[38;5;209mfoobar', '\x1b[0m'])

# Generated at 2022-06-23 18:35:03.017618
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('hello') == 5
    assert len_without_ansi('\x1b[38;5;209mhello') == 5
    assert len_without_ansi(['\x1b[38;5;209mhello', 'hello']) == 10
    assert len_without_ansi('\x1b[38;5;209m') == 0
    assert len_without_ansi(('\x1b[38;5;209m', '\x1b[0m')) == 0
    assert len_without_ansi(('\x1b[38;5;209mhello', 'hello')) == 10


# Generated at 2022-06-23 18:35:11.664835
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:24.304809
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():

    # Set the logging level to DEBUG
    set_log_level(logging.DEBUG)

    # Create a sample string with ANSI codes.  This sample string is
    # a single paragraph.  The ANSI codes include escape sequences
    # (ESC), CSI sequences, and OSC sequences.

# Generated at 2022-06-23 18:35:32.905211
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:42.955014
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    # pylint: disable=protected-access
    # Test default width.
    assert AnsiTextWrapper().width == 70
    # Test width.
    assert AnsiTextWrapper(width=40).width == 40
    # Test invalid width.
    with pytest.raises(ValueError):
        AnsiTextWrapper(width=0)
    with pytest.raises(ValueError):
        AnsiTextWrapper(width=-1)
    # Test default indentation.
    assert AnsiTextWrapper()._initial_indent == ''
    assert AnsiTextWrapper()._subsequent_indent == ''
    # Test indentation.

# Generated at 2022-06-23 18:35:44.735989
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-23 18:35:55.107140
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Test the len_without_ansi function.
    """
    from .testutils import assert_text_equal

    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['a', '\x1b[38;5;209mfoobar\x1b[0m', 'b']) == 8

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['a', text, 'b']) == 8


# Generated at 2022-06-23 18:36:04.439185
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest
    from flutils.txtutils import len_without_ansi as _len_without_ansi
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    ans = 6
    assert _len_without_ansi(text) == ans, 'Failed for text'
    text = ('\\x1b[38;5;209mfoobar\\x1b[0m', '\\x1b[38;5;209mfoobar\\x1b[0m')
    ans = 12
    assert _len_without_ansi(text) == ans, 'Failed for text'
    with pytest.raises(TypeError):
        _len_without_ansi(('foobar', 'foobar'))


# Generated at 2022-06-23 18:36:15.189739
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    wrapper = AnsiTextWrapper(
        break_on_hyphens=False, break_long_words=False,
        width=55, initial_indent='', subsequent_indent='    '
    )
    string = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    expected = textwrap.dedent("""\
        Lorem ipsum dolor sit amet, consectetur
            adipiscing elit.""")
    result = wrapper.fill(string)
    assert result == expected

    wrapper = AnsiTextWrapper(
        break_on_hyphens=True, break_long_words=True,
        width=40, initial_indent='', subsequent_indent='    '
    )

# Generated at 2022-06-23 18:36:22.563976
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """This unit test was taken from the unit test for
    :obj:`~flutils.txtutils.AnsiTextWrapper`."""

    wrapper = AnsiTextWrapper(width=60, max_lines=3)

# Generated at 2022-06-23 18:36:34.765389
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from random import choice
    from string import whitespace
    from shutil import rmtree
    import os

    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:36:44.202706
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test to test the wrap method of class AnsiTextWrapper"""
    initial_indent = '>> '
    subsequent_indent = None

# Generated at 2022-06-23 18:36:55.162324
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Test :obj:`~flutils.txtutils.AnsiTextWrapper.fill` method."""
    from flutils.txtutils import AnsiTextWrapper