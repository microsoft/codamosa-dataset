

# Generated at 2022-06-23 18:27:06.465133
# Unit test for function len_without_ansi
def test_len_without_ansi():
    r"""
    >>> from flutils.txtutils import len_without_ansi
    >>> text = '\x1b[38;5;209mfoobar\x1b[0m'
    >>> len_without_ansi(text)
    6
    >>> text = [
    ...     '\x1b[38;5;209m',
    ...     'foobar',
    ...     '\x1b[0m',
    ... ]
    >>> len_without_ansi(text)
    6
    """
    pass



# Generated at 2022-06-23 18:27:11.562286
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # width must be positive
    for width in [0, -1]:
        with pytest.raises(ValueError):
            AnsiTextWrapper(width=width)

    # max_lines must be positive
    for max_lines in [0, -1]:
        with pytest.raises(ValueError):
            AnsiTextWrapper(max_lines=max_lines)

    # placeholder is too large for max_lines
    for placeholder in ['', 'A', 'B' * 11, 'B' * 12]:
        with pytest.raises(ValueError):
            AnsiTextWrapper(max_lines=1, placeholder=placeholder)

    # placeholder must be a non-empty string
    for placeholder in [1, True, False, [], {}]:
        with pytest.raises(ValueError):
            AnsiText

# Generated at 2022-06-23 18:27:23.566023
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test :func:`flutils.txtutils.len_without_ansi`.
    """
    from .txtutils import len_without_ansi

    _ANSIPRE = r'\x1b\\['
    _ANSI = r'\x1b[0m'

    _TEXT = f'{_ANSIPRE}38;5;209mfoobar{_ANSI}'

    _TEST = len_without_ansi(_TEXT)
    assert _TEST == 6

    _TEST = len_without_ansi([_TEXT, _TEXT])
    assert _TEST == 12

    _TEST = len_without_ansi([_TEXT])
    assert _TEST == 6

    _TEST = len_without_ansi([_TEXT, _ANSI])
    assert _TEST == 6

    _

# Generated at 2022-06-23 18:27:26.892582
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[39m\x1b[38;5;42mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mf\x1b[39m\x1b[38;5;42mo\x1b[0m\x1b[38;5;209mo\x1b[39m\x1b[38;5;42mbar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:27:36.418133
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    a = AnsiTextWrapper(initial_indent='\x1b[38;2;255;0;0m\x1b[1m\x1b[4m',
                        subsequent_indent='\x1b[38;2;0;255;0m\x1b[4m',
                        placeholder='\x1b[38;2;0;0;255mplaceholder', width=40)
    assert a.initial_indent_len == 30
    assert a.subsequent_indent_len == 30
    assert a.placeholder_len == 19
    assert a.width == 40
    a = AnsiTextWrapper(width=40)
    assert a.width == 40
    assert a.max_lines is None
    assert a.placeholder.lstrip() == 'placeholder'
    a = An

# Generated at 2022-06-23 18:27:47.941863
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test for the method wrap of class AnsiTextWrapper."""

    import sys
    import termcolor
    from .setup_logging import setup_logging
    from .txtutils import AnsiTextWrapper
    from .txtutils import Color

    # Warnings should be printed to STDERR
    if sys.stderr.isatty():
        def print_warning(msg: str) -> None:
            """Print a warning."""
            print(
                termcolor.colored(msg, color='red', attrs=['bold']),
                file=sys.stderr
            )
    else:
        def print_warning(msg: str) -> None:
            """Print a warning."""

# Generated at 2022-06-23 18:27:59.328442
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # These are the settings used by textwrap.TextWrapper
    # from the Python 3.6 standard library.
    default_settings = {
        'width': 70,
        'initial_indent': '',
        'subsequent_indent': '',
        'expand_tabs': True,
        'replace_whitespace': True,
        'fix_sentence_endings': False,
        'break_long_words': True,
        'drop_whitespace': True,
        'break_on_hyphens': True,
        'tabsize': 8,
    }

    # These are the settings to 'break' the constructor.

# Generated at 2022-06-23 18:28:04.432951
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foo', 'bar', 'baz']) == 6



# Generated at 2022-06-23 18:28:12.807501
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:15.584718
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import doctest
    assert doctest.testmod(
        module=AnsiTextWrapper,
        optionflags=doctest.NORMALIZE_WHITESPACE
    )[0] == 0



# Generated at 2022-06-23 18:28:27.126521
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    try:
        AnsiTextWrapper()
    except Exception as e:
        assert False, f'{e}'
    try:
        AnsiTextWrapper(width=-1)
    except ValueError as e:
        assert str(e) == 'invalid width -1 (must be > 0)', \
            f'{str(e)}'
    try:
        AnsiTextWrapper(placeholder='abc'*30, max_lines=2)
    except ValueError as e:
        assert str(e) == 'placeholder too large for max width', \
            f'{str(e)}'

# Generated at 2022-06-23 18:28:37.569005
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:45.314470
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:50.387267
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mbaz\x1b[0m']
    assert len_without_ansi(text) == 9
    return True



# Generated at 2022-06-23 18:28:59.869376
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """
    This will be used as the docstring for the tests.

    :return: :obj:`None`
    """

    #  Create a test AnsiTextWrapper object
    atw = AnsiTextWrapper(
        width=40,
        initial_indent='    ',
        subsequent_indent='' * 8,
        expand_tabs=False,
        replace_whitespace=False,
        fix_sentence_endings=True,
        break_long_words=False,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=4,
        max_lines=2,
        placeholder=''
    )

    # Check the default values
    assert atw.width == 40
    assert atw.initial_indent == '    '
    assert at

# Generated at 2022-06-23 18:29:11.577545
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for ``flutils.txtutils.AnsiTextWrapper``.

    Test the constructor of class ``flutils.txtutils.AnsiTextWrapper``.
    """
    from flutils.txtutils import AnsiTextWrapper

    AnsiTextWrapper()
    AnsiTextWrapper(width=80)
    AnsiTextWrapper(initial_indent=' ' * 4)
    AnsiTextWrapper(subsequent_indent=' ' * 4)
    AnsiTextWrapper(expand_tabs=True)
    AnsiTextWrapper(replace_whitespace=False)
    AnsiTextWrapper(fix_sentence_endings=False)
    AnsiTextWrapper(break_long_words=True)
    AnsiTextWrapper(drop_whitespace=True)
    AnsiText

# Generated at 2022-06-23 18:29:24.335272
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    w = AnsiTextWrapper(width=40)
    assert w.width == 40
    assert w.initial_indent is None
    assert w.initial_indent_len == 0
    assert w.subsequent_indent is None
    assert w.subsequent_indent_len == 0
    assert w.expand_tabs
    assert w.replace_whitespace
    assert not w.fix_sentence_endings
    assert w.break_long_words
    assert w.drop_whitespace
    assert w.break_on_hyphens
    assert w.tabsize == 8
    assert w.max_lines is None
    assert w.placeholder.lstrip() == ' [...]'
    assert w.placeholder_len == len_without_ansi(' [...]')


# Generated at 2022-06-23 18:29:36.439060
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    print('Testing constructor of class AnsiTextWrapper...')
    text = 'Long\tParagraph'

    wrapper = AnsiTextWrapper(replace_whitespace=True, expand_tabs=True)
    wrapped_text = wrapper.fill(text)
    assert wrapped_text == text

    wrapper = AnsiTextWrapper(replace_whitespace=True, expand_tabs=False)
    wrapped_text = wrapper.fill(text)
    assert wrapped_text == 'Long Paragraph'

    wrapper = AnsiTextWrapper(replace_whitespace=False, expand_tabs=True)
    wrapped_text = wrapper.fill(text)
    assert wrapped_text == 'Long \t Paragraph'

    wrapper = AnsiTextWrapper(replace_whitespace=False, expand_tabs=False)
    wrapped_

# Generated at 2022-06-23 18:29:48.292694
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Create an instance of the AnsiTextWrapper class
    wrapper = AnsiTextWrapper(initial_indent='* ', subsequent_indent='   ')

    # Add newlines so we can have multiple paragraphs.

# Generated at 2022-06-23 18:30:00.560305
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:09.059691
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # noqa: D103
    wrapper = AnsiTextWrapper(width=40)
    wrapped_text = wrapper.fill(text)

# Generated at 2022-06-23 18:30:19.902111
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    class Test(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def test_empty(self):
            wrapper = AnsiTextWrapper()
            actual = wrapper.wrap('')
            self.assertIsInstance(actual, list)
            self.assertListEqual(actual, [])

        def test_just_placeholder(self):
            wrapper = AnsiTextWrapper(placeholder='...')
            actual = wrapper.wrap('')
            self.assertIsInstance(actual, list)
            self.assertListEqual(actual, ['...'])

        def test_max_lines_1(self):
            wrapper = AnsiTextWrapper(max_lines=1)
            actual = wrapper.wrap('Lorem ipsum dolor sit amet.')

# Generated at 2022-06-23 18:30:23.285490
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:30:33.848094
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # noqa: D202
    """Unit test for method fill of class AnsiTextWrapper."""

    from textwrap import TextWrapper as _TextWrapper

    width = 40


# Generated at 2022-06-23 18:30:43.501161
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:55.915058
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    ##########################################################################
    # Test wrapping with very short width
    ##########################################################################
    wrapper = AnsiTextWrapper(width=3)
    # Check that the first 20 characters are not wrapped
    text = ' ' * 20 + 'Test'
    result = wrapper.wrap(text=text)
    assert result == [text]

    ##########################################################################
    # Test wrapping with a very big width
    ##########################################################################
    wrapper = AnsiTextWrapper(width=100)
    result = wrapper.wrap(text='Test line')
    assert result == ['Test line']

    ##########################################################################
    # Check that non-ASCII characters are not wrapped
    ##########################################################################
    wrapper = AnsiTextWrapper(width=16)

# Generated at 2022-06-23 18:31:07.789886
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text, 'baz']) == 9
    assert len_without_ansi([text, 'baz', text, 'baz']) == 18
    assert len_without_ansi(['\x1b[1mfoo', text, 'baz\x1b[0m']) == 9
    assert len_without_ansi(['\x1b[1mfoo', text, 'baz\x1b[0m']) == 9
    assert len_without_ansi(['\x1b[1mfoo\x1b[0m', text, 'baz\x1b[0m']) == 9


# Generated at 2022-06-23 18:31:19.093076
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # flake8: noqa=D103
    import pytest

    textwrap = AnsiTextWrapper(
        width=40,
        initial_indent='  - ',
        subsequent_indent='    ',
        placeholder=' [...]'
    )

# Generated at 2022-06-23 18:31:29.466324
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    textwrap = AnsiTextWrapper(width=40, initial_indent='> ', subsequent_indent='  ')

# Generated at 2022-06-23 18:31:30.368751
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    pass

# Generated at 2022-06-23 18:31:42.295195
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # noqa: D103
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:31:47.082809
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from doctest import testmod
    testmod(
        name='flutils.txtutils.AnsiTextWrapper',
        optionflags=(
            doctest.NORMALIZE_WHITESPACE |
            doctest.ELLIPSIS
        ),
        verbose=True
    )

# Generated at 2022-06-23 18:31:57.086241
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import textwrap
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:32:06.522976
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:17.981709
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test to verify the behavior of method wrap of class
    AnsiTextWrapper.
    """
    from pprint import pprint

    def print_lines(lines, indent=''):
        for line in lines:
            print(indent + line)


# Generated at 2022-06-23 18:32:27.822702
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:39.049313
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:32:50.664866
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from hypothesis import given, strategies as st
    from unittest.mock import patch
    from .ansi import ANSI_COLOR_CODES

    @given(st.text())
    def test_len_without_ansi_str(text):
        with patch('builtins.len') as mocklen:
            out = len_without_ansi(text)
        assert out == mocklen(text)

    @given(st.lists(st.text()))
    def test_len_without_ansi_list(texts: List[str]):
        with patch('builtins.len') as mocklen:
            out = len_without_ansi(texts)
        assert out == mocklen(''.join(texts))


# Generated at 2022-06-23 18:32:57.006163
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.max_lines is None
    assert wrapper.placeholder == ' [...]'
    assert not wrapper.expand_tabs
    assert wrapper.replace_whitespace
    assert not wrapper.fix_sentence_endings
    assert wrapper.break_long_words
    assert wrapper.drop_whitespace
    assert wrapper.break_on_hyphens

# Generated at 2022-06-23 18:33:04.776908
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:16.257283
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:26.323336
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[31mfoo\x1b[0m') == 3
    assert len_without_ansi('foo\x1b[31m') == 3
    assert 'foo\x1b[31m' == '\x1b[31mfoo\x1b[0m'
    ansi_str = '\x1b[31mfoo\x1b[0m \x1b[32mbar\x1b[0m'
    assert len_without_ansi(ansi_str) == 7
    ansi_list = ['\x1b[31mfoo\x1b[0m', '\x1b[32mbar\x1b[0m', '\x1b[33mbaz\x1b[0m']
    assert len_without

# Generated at 2022-06-23 18:33:38.993785
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:45.643364
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrap = AnsiTextWrapper(width=20, tabsize=4)
    tab = '\t'
    text = ' '.join(['a', tab, 'b'])
    print(wrap.fill(text))
    wrap.expand_tabs = False
    print(wrap.fill(text))
    wrap.replace_whitespace = False
    print(wrap.fill(text))

if __name__ == '__main__':
    test_AnsiTextWrapper()

# Generated at 2022-06-23 18:33:54.158601
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Test 1
    text = '\x1b[31mLorem ipsum dolor sit amet\x1b[0m consectetur'
    wrapper = AnsiTextWrapper(width=40)
    expected = [
        '\x1b[31mLorem ipsum dolor sit amet\x1b[0m',
        'consectetur'
    ]
    result = wrapper.wrap(text)
    assert result == expected

    # Test 2

# Generated at 2022-06-23 18:34:02.354624
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper."""
    def _test_AnsiTextWrapper_wrap(text: str, width: Optional[int] = None,
            max_lines: Optional[int] = None,
            placeholder: str = ' [...]') -> None:
        print('')
        print('text:')
        print('-' * 70)
        print(text)
        print('-' * 70)
        print('text len =', len_without_ansi(text))
        wrapper = AnsiTextWrapper(width=width, max_lines=max_lines,
                placeholder=placeholder)
        wrapped_text = wrapper.wrap(text)
        print('wrapper.width =', wrapper.width)
        print('wrapped_text:')
        print('-' * 70)

# Generated at 2022-06-23 18:34:12.918108
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('Test\x1b[0m\x1b[91m123\x1b[0mTest\x1b[0m') == 11
    assert len_without_ansi('\x1b[0mTest\x1b[91m\x1b[0m') == 4
    assert len_without_ansi('\x1b[0mTest\x1b[91m\x1b[0m\x1b[0m') == 4
    assert len_without_ansi(['\x1b[0mTest', '\x1b[91m\x1b[0m']) == 4
    assert len_without_

# Generated at 2022-06-23 18:34:23.957011
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    width = 40

# Generated at 2022-06-23 18:34:35.182358
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:37.586390
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    result = len_without_ansi(text)
    assert result == 6
    result = len_without_ansi(['', '\x1b[38;5;209mfoobar\x1b[0m'])
    assert result == 6


# Generated at 2022-06-23 18:34:47.465856
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # pragma: no cover
    from tempfile import TemporaryDirectory
    from flutils.txtutils import AnsiTextWrapper, len_without_ansi

    with TemporaryDirectory() as temp_path:
        temp_file = temp_path / 'AnsiTextWrapper_wrap_file'


# Generated at 2022-06-23 18:34:51.170739
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text: str = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:35:02.791453
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:11.532975
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:16.798571
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('foobar') == 6
    ansitext = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(ansitext) == 6



# Generated at 2022-06-23 18:35:28.940554
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """This function :func:`test_AnsiTextWrapper_wrap` tests the function
    :func:`wrap` of the class :class:`AnsiTextWrapper`.
    """

    for width in range(20, 80):
        for n_lines in range(2, 13):
            aw = AnsiTextWrapper(
                width=40, max_lines=n_lines, placeholder='...'
            )

# Generated at 2022-06-23 18:35:32.233625
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:35:42.692487
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # pragma: no cover
    from textwrap import dedent
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:35:45.743803
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:35:56.015808
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:58.713142
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert(len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6)



# Generated at 2022-06-23 18:36:07.126341
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Test method fill of class AnsiTextWrapper."""
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:36:09.663150
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    text = 'test'
    wrapper = AnsiTextWrapper()
    out = wrapper.wrap(text)
    expected = ['test']
    assert out == expected



# Generated at 2022-06-23 18:36:12.619775
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['a', '\x1b[38;5;209mf', 'oobar']) == 6

# Generated at 2022-06-23 18:36:13.928341
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    _ = AnsiTextWrapper()


# Generated at 2022-06-23 18:36:21.933061
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar', 'baz\x1b[0m']
    assert len_without_ansi(text) == 9
    text = ('\x1b[38;5;209m', 'foobar', 'baz', '\x1b[0m')
    assert len_without_ansi(text) == 9
    text = ('\x1b[38;5;209m', 'foobar\x1b[0m', 'baz')
    assert len_without_ansi(text) == 9
test_len_without_ansi()
del test_len_without_ansi




# Generated at 2022-06-23 18:36:33.518116
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:43.957206
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Test method fill of class AnsiTextWrapper
    """

    # Test 1
    # Test empty text
    # expected results:
    #   filled = []
    wrapper = AnsiTextWrapper(width=40)
    filled = wrapper.fill('')
    assert filled == ''

    # Test 2
    # expected results:
    #  filled = (
    #    'Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n'
    #    'Cras fermentum maximus auctor. Cras a varius ligula.\n'
    #    'Phasellus ut ipsum eu erat consequat posuere.\n'
    #    'Pellentesque habitant morbi tristique senectus et netus\n'
    #    'et

# Generated at 2022-06-23 18:36:55.038047
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:37:05.105571
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper."""