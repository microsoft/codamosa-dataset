

# Generated at 2022-06-23 18:27:10.888308
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import ANSI_CSI
    from flutils.txtutils import ANSI_CODES
    from flutils.txtutils import AnsiTextWrapper
    from flutils.txtutils import clear_screen
    from flutils.txtutils import cursor_save
    from flutils.txtutils import cursor_unsave
    from flutils.txtutils import echo_off
    from flutils.txtutils import echo_on
    import random
    import subprocess

    def rstr(length):
        ss = ''
        for i in range(length):
            ss += random.choice(string.ascii_letters)
        return ss

    # Should produce: '  abc de fghijkl mnopqrst u vwxyz'

# Generated at 2022-06-23 18:27:20.742354
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    _f = lambda *args, **kwargs: len_without_ansi(*args, **kwargs)
    assert _f('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert _f('\x1b[38;5;209mfoo\x1b[0mbar') == 6
    assert _f('foo\x1b[38;5;209mbar\x1b[0m') == 6
    assert _f(['foo\x1b[38;5;209m', 'bar\x1b[0m']) == 6

# Generated at 2022-06-23 18:27:32.187861
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:39.622317
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    text = 'a b c d e f g h i j l m n o p q r s t u v w x y z a b c d e f g ' \
           'h i j l m n o p q r s t u v w x y z a b c d e f g h i j l m n o ' \
           'p q r s t u v w x y z a b c d e f g h i j l m n o p q r s t u v w ' \
           'x y z a b c d e f g h i j l m n o p q r s t u v w x y z a b c d e ' \
           'f g h i j l m n o p q r s t u v w x y z'
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:27:44.594424
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    #
    # Test 1:
    #
    wrapper = AnsiTextWrapper()
    text = '\x1b[1mhello\x1b[0m'
    expected = ['\x1b[1mhello\x1b[0m']
    result = wrapper.wrap(text)
    assert result == expected
    #
    # Test 2:
    #
    wrapper = AnsiTextWrapper(width=5)
    text = '123 45  6789'
    expected = ['123', '45', '6789']
    result = wrapper.wrap(text)
    assert result == expected
    #
    # Test 3:
    #
    wrapper = AnsiTextWrapper(width=5)

# Generated at 2022-06-23 18:27:55.986813
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:07.125874
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:10.965494
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper
    from flutils.testutils import TestWrapper
    tw = TestWrapper(AnsiTextWrapper)
    tw.test_wrap()

# Generated at 2022-06-23 18:28:22.104774
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.placeholder == ' [...]'
    wrapper = AnsiTextWrapper(width=40, placeholder=' [...]')
    assert wrapper.placeholder == ' [...]'
    wrapper = AnsiTextWrapper(width=40, placeholder=' [...]', max_lines=1)
    assert wrapper.placeholder == ' [...]'
    wrapper.placeholder = '*...'
    assert wrapper.placeholder == '*...'
    wrapper.placeholder = '*...'
    assert wrapper.placeholder == '*...'
    wrapper = AnsiTextWrapper(width=40, placeholder='*...', max_lines=1)
    assert wrapper.placeholder == '*...'
    wrapper.initial_indent = '  '
    assert wrapper.initial_indent == '  '
    wrapper

# Generated at 2022-06-23 18:28:31.689497
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    t = AnsiTextWrapper(
        width=40,
        initial_indent='  ',
        subsequent_indent='  '
    )
    # Check for correct lengths for initial_indent_len, subsequent_indent_len
    # and placeholder_len
    assert t.initial_indent_len == len_without_ansi('  ')
    assert t.subsequent_indent_len == len_without_ansi('  ')
    assert t.placeholder_len == len_without_ansi(' [...]')

# Generated at 2022-06-23 18:28:41.668599
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper"""

# Generated at 2022-06-23 18:28:46.807975
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(list(text)) == 6
    assert len_without_ansi(('foo', 'bar')) == 6



# Generated at 2022-06-23 18:28:49.894624
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:29:01.412495
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from textwrap import TextWrapper

# Generated at 2022-06-23 18:29:12.801553
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:25.323084
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    wrapper = AnsiTextWrapper(width=40)


# Generated at 2022-06-23 18:29:37.715187
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:49.450646
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test method :func:`~flutils.txtutils.AnsiTextWrapper.wrap` of class
    :class:`~flutils.txtutils.AnsiTextWrapper`.

    :return: A :obj:`tuple` with these elements:

        0. An :obj:`int` with the number of test failures and errors.
        1. A :obj:`str` with a summary of the test results.
        2. A :obj:`str` with the test failure and error messages.
    """
    import os
    import inspect
    import tempfile

    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:30:01.070016
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:09.676163
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:18.622240
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """The purpose of this unit test is to test the constructor of class
    `AnsiTextWrapper`.
    """
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8


# Generated at 2022-06-23 18:30:21.431063
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Constructor should not raise an error.
    AnsiTextWrapper()


# Generated at 2022-06-23 18:30:27.251474
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Arrange and Act:
    #   create an instance of the class AnsiTextWrapper
    wrapper = AnsiTextWrapper(width=40)

    # Assert:
    #   the value of the attribute "placeholder_len" of the AnsiTextWrapper
    #   instance should be 7
    assert wrapper.placeholder_len == 7


# Generated at 2022-06-23 18:30:37.248805
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:41.946731
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text, text, text]) == 18
    assert len_without_ansi(['foo', text, 'bar']) == 8

# noinspection PyProtectedMember

# Generated at 2022-06-23 18:30:54.424863
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper"""
    text = 'The quick brown fox jumps over the lazy dog'
    # Default:
    result = AnsiTextWrapper().wrap(text)
    expected = text.splitlines()
    assert result == expected
    # width 50:
    expected = [
        'The quick brown fox jumps over the lazy dog'
    ]
    result = AnsiTextWrapper(width=50).wrap(text)
    assert result == expected
    # width 20:
    expected = [
        'The quick brown fox',
        'jumps over the lazy',
        'dog'
    ]
    result = AnsiTextWrapper(width=20).wrap(text)
    assert result == expected
    # width = len of text:

# Generated at 2022-06-23 18:30:59.262320
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi((text, text)) == 12
    assert len_without_ansi([text, text]) == 12
    assert len_without_ansi(text * 3) == 18



# Generated at 2022-06-23 18:31:02.436907
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert(len_without_ansi(text) == 6)

# Generated at 2022-06-23 18:31:13.261835
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:25.732674
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from textwrap import dedent  # type: ignore
    from flutils.txtutils import fmt


# Generated at 2022-06-23 18:31:27.750555
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-23 18:31:29.073719
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # FIXME: Unit test for function len_without_ansi
    ...



# Generated at 2022-06-23 18:31:34.452270
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['foo', '\x1b[38;5;209mbar\x1b[0m']) == 6



# Generated at 2022-06-23 18:31:43.836309
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    do_test = False
    if do_test:
        from textwrap import TextWrapper

        wrapper = TextWrapper(width=8)
        text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'

        wrapped_text = wrapper.wrap(text)
        print(wrapped_text)

        # The output:
        #    ['Lorem', 'ipsum', 'dolor', 'sit', 'amet,', 'consectetur',
        #     'adipisci', 'ng', 'elit.']


AnsiTextWrapper = _AnsiTextWrapper()  # type: ignore[misc]

# Generated at 2022-06-23 18:31:49.074663
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:58.250332
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:07.117477
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:18.341910
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # This test is kind of pointless...
    print(AnsiTextWrapper.__bases__)

# Generated at 2022-06-23 18:32:28.708466
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    #
    # Test initial_indent and subsequent_indent
    #
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.initial_indent == ''
    wrapper.initial_indent = '***'
    assert wrapper.initial_indent == '***'
    assert wrapper.subsequent_indent == ''
    wrapper.subsequent_indent = '+++'
    assert wrapper.subsequent_indent == '+++'
    assert wrapper.initial_indent == '***'
    wrapper.initial_indent = ''
    assert wrapper.subsequent_indent == '+++'
    del wrapper.subsequent_indent
    assert wrapper.subsequent_indent == ''
    del wrapper.initial_indent
    assert wrapper.initial_indent == ''
    wrapper.subsequent_indent = '+++'

# Generated at 2022-06-23 18:32:37.643402
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():

    from textwrap import dedent
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:32:43.814985
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:32:53.430026
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:01.233077
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[32mfoo\x1b[0m') == 3
    assert len_without_ansi('\x1b[32mfoo') == 3
    assert len_without_ansi('foo\x1b[0m') == 3
    assert len_without_ansi(['\x1b[32mfoo\x1b[0m']) == 3
    assert len_without_ansi(['\x1b[32mfoo', 'bar']) == 6
    assert len_without_ansi(('\x1b[32mfoo', 'bar')) == 6



# Generated at 2022-06-23 18:33:14.351409
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:25.192917
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():

    from flutils.testing.helpers import get_test_env_bool
    # If the texttest environment variable is set to "True"
    # (to test ANSI codes on Windows, for example), use the
    # formatting functions from the colorama package.
    global _wrap_text
    if get_test_env_bool('texttest'):
        from colorama import init, AnsiToWin32, Fore, Style
        # Wrap the stdout and stderr streams so they can handle ANSI codes.
        init(wrap=False)
        stream = AnsiToWin32(stream=sys.stdout).stream
        sys.stdout = stream
        stream = AnsiToWin32(stream=sys.stderr).stream
        sys.stderr = stream


# Generated at 2022-06-23 18:33:38.003871
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:40.726672
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:33:50.264429
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:57.557741
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Test method fill of class AnsiTextWrapper."""


# Generated at 2022-06-23 18:34:09.351281
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:16.220929
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:25.627631
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """ Unit test for method fill of class AnsiTextWrapper"""

# Generated at 2022-06-23 18:34:37.011081
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.placeholder == ' [...]'
    assert wrapper.max_lines == None
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder_len == 7

# Generated at 2022-06-23 18:34:47.111807
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from unittest.mock import patch
    import re


# Generated at 2022-06-23 18:34:56.424558
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:06.357770
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    #
    # AnsiTextWrapper()
    #

    wrapper = AnsiTextWrapper()

    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.break_long_words
    assert wrapper.drop_whitespace
    assert wrapper.break_on_hyphens
    assert wrapper.placeholder == ' [...]'

    #
    # AnsiTextWrapper(width=0)
    #

    with pytest.raises(ValueError):

        wrapper = AnsiTextWrapper(width=0)

    #
    # AnsiTextWrapper(placeholder=' [...] ')
    #

    wrapper = AnsiTextWrapper(placeholder=' [...] ')

    assert wrapper.placeholder == ' [...] '

    #
    # AnsiText

# Generated at 2022-06-23 18:35:08.983998
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # If no errors, the constructor is working
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper



# Generated at 2022-06-23 18:35:11.221074
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:35:17.519515
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m')
    assert len_without_ansi(('\\x1b[38;5;209mfoobar\\x1b[0m',))
    assert len_without_ansi(['\\x1b[38;5;209mfoobar\\x1b[0m'])



# Generated at 2022-06-23 18:35:29.427471
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:41.014724
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Tests for function flutils.txtutils.len_without_ansi"""
    from flutils.constants import RST_VERSION
    from flutils.txtutils import len_without_ansi
    from flutils.typesutils import is_type_tag
    from sys import version_info
    # Only run unit tests if restfl is running Python >= 3.6
    if version_info >= (3, 6):
        assert is_type_tag(RST_VERSION, '0.3b3')
        assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
        assert len_without_ansi(['\x1b[1mfoobar\x1b[0m']) == 6

# Generated at 2022-06-23 18:35:52.125694
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:01.543912
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    '''Unit test for method wrap of class AnsiTextWrapper.'''

# Generated at 2022-06-23 18:36:13.219319
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import re


# Generated at 2022-06-23 18:36:19.383208
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""

    class AnsiTextWrapperCustom(AnsiTextWrapper):
        """Subclass to test default arguments."""

        def __init__(self):
            super().__init__()

    wrapper = AnsiTextWrapper()
    wrapper_custom = AnsiTextWrapperCustom()
    assert wrapper.width == wrapper_custom.width == 70
    assert wrapper.initial_indent == wrapper_custom.initial_indent == ''
    assert wrapper.subsequent_indent == wrapper_custom.subsequent_indent == ''
    assert wrapper.placeholder == wrapper_custom.placeholder == ' [...]'
    assert wrapper.expand_tabs == wrapper_custom.expand_tabs == True

# Generated at 2022-06-23 18:36:30.279290
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:41.689058
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """
    Run unit tests for the :obj:`AnsiTextWrapper()` constructor.
    """
    from unittest.mock import patch

    def raise_value_error(*args, **kwargs):
        raise ValueError

    with patch('flutils.txtutils.len_without_ansi', return_value=0), \
         patch('textwrap.TextWrapper._split', return_value=[]), \
         patch('textwrap.TextWrapper._wrap_chunks', return_value=[]), \
         patch('textwrap.TextWrapper.__dict__.__setitem__',
               side_effect=raise_value_error), \
         patch('textwrap.TextWrapper._handle_long_word'):
        AnsiTextWrapper()
        AnsiTextWrapper(width=0)
        Ansi

# Generated at 2022-06-23 18:36:50.781602
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Tests the constructor of :obj:`~flutils.txtutils.AnsiTextWrapper`.

    Notes:
        The following messages should be printed:

        ``AnsiTextWrapper constructor: ok``

    """
    print("AnsiTextWrapper constructor: ", end='')
    with captured_output() as (out, err):
        wrapper = AnsiTextWrapper()

    for line in err.getvalue().strip().splitlines():
        print(line)

    if not err.getvalue():
        print("ok")


# Generated at 2022-06-23 18:37:02.593670
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    # Test with a unicode text
    text = """\
Lorem ipsum dolor sit amet,
consectetur adipiscing elit,
sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
Excepteur sint occaecat cupidatat non proident,
sunt in culpa qui officia deserunt mollit anim id est laborum."""
    # Test with a string with a few characters replaced with unicode characters