

# Generated at 2022-06-23 18:27:06.584475
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:27:19.053761
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:27:30.630121
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(subsequent_indent='    ')
    text = '    This is a\n    test.'
    expected = text
    assert wrapper.wrap(text) == expected.splitlines()

    result = wrap(text, subsequent_indent='    ')
    assert result == expected

    wrapper = AnsiTextWrapper(initial_indent='...', subsequent_indent='    ')
    text = '    This is a\n    test.'
    expected = '...This is a\n...    test.'
    assert wrapper.wrap(text) == expected.splitlines()

    result = wrap(text, initial_indent='...', subsequent_indent='    ')
    assert result == expected


# Generated at 2022-06-23 18:27:38.622905
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:50.167854
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    test_wrapper = AnsiTextWrapper()
    assert test_wrapper.width == 70
    assert test_wrapper.initial_indent == ''
    assert test_wrapper.initial_indent_len == 0
    assert test_wrapper.subsequent_indent == ''
    assert test_wrapper.subsequent_indent_len == 0
    assert test_wrapper.expand_tabs == True
    assert test_wrapper.replace_whitespace == True
    assert test_wrapper.fix_sentence_endings == False
    assert test_wrapper.break_long_words == True
    assert test_wrapper.break_on_hyphens == True
    assert test_wrapper.drop_whitespace == True
    assert test_wrapper.max_lines == None
    assert test_wrapper.placeholder == ' [...]'
    assert test_wrapper.place

# Generated at 2022-06-23 18:27:58.948789
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test for constructor of class AnsiTextWrapper"""

    wrapper = AnsiTextWrapper(width=40)

    assert isinstance(wrapper, TextWrapper)
    assert isinstance(wrapper, AnsiTextWrapper)

    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines == None
    assert wrapper.placeholder == ' [...]'


# Generated at 2022-06-23 18:28:02.354213
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mf', 'o', 'o', '\x1b[0mbar']
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['foo', 'bar']) == 6



# Generated at 2022-06-23 18:28:10.756493
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    with pytest.raises(TypeError):
        AnsiTextWrapper().fill()  # type: ignore
    with pytest.raises(ValueError):
        AnsiTextWrapper(width=0).fill('')  # type: ignore
    with pytest.raises(ValueError):
        AnsiTextWrapper(width=0).fill('abc')  # type: ignore
    with pytest.raises(ValueError):
        AnsiTextWrapper(width=0).fill('\x1b[1mabc\x1b[0m')  # type: ignore
    with pytest.raises(ValueError):
        AnsiTextWrapper(width=10).fill('\n')  # type: ignore

# Generated at 2022-06-23 18:28:20.271509
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from textwrap import wrap
    from flutils.txtutils import AnsiTextWrapper
    from flutils.pyutils import ReadOnlyChainMap, OrderedChainMap
    import inspect
    wrap_opts = dict(expand_tabs=True, drop_whitespace=True)
    wrapper = AnsiTextWrapper(initial_indent='Foobar',
                              subsequent_indent='||| ',
                              break_long_words=True,
                              **wrap_opts)
    # get the source
    source = inspect.getsource(len_without_ansi)
    # Remove comments and blank lines
    source = '\n'.join(line.split('#')[0].rstrip()
                       for line in source.splitlines())
    # Get each line of the function

# Generated at 2022-06-23 18:28:30.479683
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Test with max_lines = None, no placeholder
    print('Test with max_lines = None, no placeholder')

# Generated at 2022-06-23 18:28:32.850463
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:28:42.540223
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:28:47.928042
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=5)
    lines = wrapper.wrap('\\x1b[31mHello\\x1b[0m World!')
    assert lines == ['\\x1b[31m', 'Hello', '\\x1b[0m World!']



# Generated at 2022-06-23 18:28:59.160098
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    class Tester:
        def __init__(self, test_name, value, expected_value):
            self.test_name = test_name
            self.value = value
            self.expected_value = expected_value
            self.result = None

        def set_result(self, result):
            self.result = result

        def get_result(self):
            return self.result

        def get_test_name(self):
            return self.test_name

        def get_value(self):
            return self.value

    # Test 1: test AnsiTextWrapper.__init__()
    #         setAnsiTextWrapper_initial_indent
    #         setAnsiTextWrapper_subsequent_indent
    #         setAnsiTextWrapper_placeholder

# Generated at 2022-06-23 18:29:11.193610
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:13.852252
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[2;30;46;1mfoobar\x1b[0m') == 6



# Generated at 2022-06-23 18:29:21.482278
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from pprint import pprint  # noqa: WPS433
    from flutils.txtutils._testing import _AnsiTextWrapperTestCase

    class _TestCase(_AnsiTextWrapperTestCase):

        def _check(self, result: List[str], expected: List[str]) -> None:
            self.assertEqual(expected, result)

    # Test
    _TestCase('test_wrap').test()



# Generated at 2022-06-23 18:29:30.054758
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:40.551395
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:50.784275
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import dedent
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:30:01.983728
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    c = AnsiTextWrapper()
    assert c.width == 70
    assert c.initial_indent == ''
    assert c.subsequent_indent == ''
    assert c.expand_tabs == True
    assert c.replace_whitespace == True
    assert c.fix_sentence_endings == False
    assert c.break_long_words == True
    assert c.drop_whitespace == True
    assert c.break_on_hyphens == True
    assert c.tabsize == 8
    assert c.max_lines == None
    assert c.placeholder == ' [...]'


# Generated at 2022-06-23 18:30:08.666982
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:16.799856
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foobar']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0mbar']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'bar']) == 6



# Generated at 2022-06-23 18:30:21.156335
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6

# Add unit tests to module
setattr(len_without_ansi, '__test__', test_len_without_ansi)



# Generated at 2022-06-23 18:30:27.744754
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:29.023682
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6





# Generated at 2022-06-23 18:30:36.023530
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:44.910566
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # type: ignore
    """Unit test for method :meth:`AnsiTextWrapper.wrap`."""
    from flutils.txtutils import AnsiTextWrapper
    from flutils.txtutils import AnsiTextWrapper
    from flutils.txtutils import AnsiTextWrapper
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:30:51.135165
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(ansi_text) == len('foobar') + len('\x1b[0m') + 1
    _len = len_without_ansi(ansi_text)
    assert _len == len('foobar')



# Generated at 2022-06-23 18:31:00.844405
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoo\x1b[0m'
    assert len_without_ansi(text) == 3
    text = '\x1b[38;5;209m\x1b[38;5;210m\x1b[38;5;211mfoo\x1b[0m'
    assert len_without_ansi(text) == 3
    text = ['\x1b[38;5;209mfoo', '\x1b[0m']
    assert len_without_ansi(text) == 3
    text = ['\x1b[38;5;209mfoo', '\x1b[0m', '\x1b[38;5;209mfoo', '\x1b[0m']
    assert len_without_ansi

# Generated at 2022-06-23 18:31:12.036801
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:24.319568
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """
    Unit test for method wrap of class AnsiTextWrapper
    """

# Generated at 2022-06-23 18:31:27.984442
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .txtutils import len_without_ansi as _len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert _len_without_ansi(text) == 6



# Generated at 2022-06-23 18:31:39.788891
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:51.358567
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class :obj:`~flutils.txtutils.AnsiTextWrapper`."""

# Generated at 2022-06-23 18:32:03.814547
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # pragma: no cover
    import json
    import os.path
    import unittest

    from flutils.txtutils import AnsiTextWrapper

    _test_dir = os.path.join(os.path.split(__file__)[0], 'tests')
    with open(os.path.join(_test_dir, 'AnsiTextWrapper_fill.json')) as tfp:
        tests = json.load(tfp)

    class AnsiTextWrapperFillTest(unittest.TestCase):

        longMessage = True

        def test_ansi_text_wrapper_fill(self):
            for test in tests:
                with self.subTest(test=test):
                    wrap = AnsiTextWrapper(**test['kwargs'])
                    res = wrap.fill(test['text'])

# Generated at 2022-06-23 18:32:15.607295
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:26.339423
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class :obj:`~flutils.txtutils.AnsiTextWrapper`."""

# Generated at 2022-06-23 18:32:38.017110
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # noqa: D103
    wrapper = AnsiTextWrapper(width=40, initial_indent='  ', placeholder=' ...')

# Generated at 2022-06-23 18:32:43.979893
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoo', 'bar', '\x1b[0m']
    assert len_without_ansi(text) == 6
    text = 'foo\x1b[0m'
    assert len_without_ansi(text) == 3

# Generated at 2022-06-23 18:32:47.967820
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
# end unit test for function len_without_ansi



# Generated at 2022-06-23 18:32:59.791660
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:12.414747
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='\x1b[32m\x1b[1m',
        subsequent_indent='\x1b[0m',
        expand_tabs=False,
        replace_whitespace=False,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=4,
        max_lines=4,
        placeholder=''
    )
    assert wrapper.width == 40
    assert wrapper.initial_indent == '\x1b[32m\x1b[1m'
    assert wrapper.subsequent_indent == '\x1b[0m'
    assert wrapper.expand_

# Generated at 2022-06-23 18:33:23.793183
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi("%{foo}s" % {'foo': 'foobar'}) == 6
    text = ['\x1b[31mfoo\x1b[0m', '\x1b[33m', 'bar\x1b[0m']
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['foo', '', 'bar']) == 6
    assert len_without_ansi('\x1b[31mfoo\x1b[0m') == 3

# Generated at 2022-06-23 18:33:35.873427
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import pytest


# Generated at 2022-06-23 18:33:46.564570
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:48.836312
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:33:56.722576
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    from flutils.txtutils import AnsiTextWrapper

    wrapper = AnsiTextWrapper()

    # Test with empty string
    assert [] == wrapper.wrap('')

    # Test with short string
    text = 'Lorem ipsum dolor sit amet'
    assert [text] == wrapper.wrap(text)

    # Test with longer string

# Generated at 2022-06-23 18:34:04.002415
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for method len_without_ansi."""
    from flutils.txtutils import (
        _ANSI_RE,
        len_without_ansi,
    )
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(_ANSI_RE.split(text)) == 3
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:34:14.135633
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:21.146050
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    wrapper = AnsiTextWrapper()
    assert wrapper.wrap('') == []

    wrapper = AnsiTextWrapper(width=0)
    with pytest.raises(ValueError):
        wrapper.wrap('test')

    wrapper = AnsiTextWrapper(width=-1)
    with pytest.raises(ValueError):
        wrapper.wrap('test')

    wrapper = AnsiTextWrapper()
    assert wrapper.wrap('test') == ['test']

    wrapper = AnsiTextWrapper(break_long_words=False)
    assert wrapper.wrap('test') == ['test']
    assert wrapper.wrap('test test') == ['test', 'test']

    wrapper = AnsiTextWrapper(width=7)
    assert wrapper.wrap('test test') == ['test', 'test']

# Generated at 2022-06-23 18:34:32.460681
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:43.981318
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Test that an exception is raised for non-int values.
    with pytest.raises(TypeError):
        AnsiTextWrapper(width='40')
    with pytest.raises(TypeError):
        AnsiTextWrapper(width=(40,))
    with pytest.raises(TypeError):
        AnsiTextWrapper(width={'test': '40'})
    with pytest.raises(TypeError):
        AnsiTextWrapper(width=[40])

    # Test that an exception is raised if width is zero or less.
    with pytest.raises(ValueError):
        AnsiTextWrapper(width=0)
    with pytest.raises(ValueError):
        AnsiTextWrapper(width=-1)

    # Test that an exception is raised for non-str values for initial_indent

# Generated at 2022-06-23 18:34:51.160131
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Test that wrap does not return empty string or list
    text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'
    result = AnsiTextWrapper().wrap(text)
    assert result is not None
    assert result is not []
    assert result is not ''
    # Test that wrap handles empty string without error
    text = ''
    result = AnsiTextWrapper().wrap(text)
    assert result is not None
    assert result is not []
    assert result == ''
    # Test that wrap handles both ANSI codes and tabs

# Generated at 2022-06-23 18:34:56.602752
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('abcd efg') == 7
    assert len_without_ansi(['abcd', 'efg']) == 7
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-23 18:35:06.487395
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from flutils.txtutils import AnsiTextWrapper as _AnsiTextWrapper

# Generated at 2022-06-23 18:35:15.079324
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    assert AnsiTextWrapper().width == 70
    assert AnsiTextWrapper(width=80).width == 80

    assert AnsiTextWrapper().tabsize == 8
    assert AnsiTextWrapper(tabsize=2).tabsize == 2

    assert AnsiTextWrapper().placeholder == ' [...]'
    assert AnsiTextWrapper(placeholder='').placeholder == ''
    assert AnsiTextWrapper(placeholder='...').placeholder == '...'

    assert (AnsiTextWrapper().initial_indent == '' and
            AnsiTextWrapper().initial_indent_len == 0)
    assert (AnsiTextWrapper(initial_indent='  ').initial_indent == '  ' and
            AnsiTextWrapper(initial_indent='  ').initial_indent_len == 2)

   

# Generated at 2022-06-23 18:35:27.935083
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # noqa: D103
    import random
    from itertools import repeat
    from textwrap import TextWrapper as AnsiTextWrapper

    # Create a random string
    text = ''.join(random.choice(_PRINTABLE) for _ in range(10000))
    # Create an ANSI code
    ansi_code = random.choice(_ANSI_CODES)

    # Version 1
    text_v1 = ansi_code + text + '\x1b[0m'
    wrapper_v1 = AnsiTextWrapper(width=80, drop_whitespace=False)
    wrapped_v1 = wrapper_v1.wrap(text_v1)
    assert wrapped_v1 == textwrap.TextWrapper(
        width=80, drop_whitespace=False
    ).wrap(text)

    #

# Generated at 2022-06-23 18:35:40.255439
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:51.618570
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from contextlib import redirect_stdout
    from io import StringIO
    from flutils.txtutils import _ANSI_RE, len_without_ansi, AnsiTextWrapper

    # Test: when width is <= 0
    with pytest.raises(ValueError) as excinfo:
        wrapper = AnsiTextWrapper(width=0)  # type: ignore
        wrapper.wrap('foo')
    assert "invalid width '0' (must be > 0)" in str(excinfo.value)
    # Test: when max_lines is not None and placeholder is too big for max_width
    with pytest.raises(ValueError) as excinfo1:
        wrapper = AnsiTextWrapper(width=20, max_lines=2, placeholder='bar')
        wrapper.wrap('foo')

# Generated at 2022-06-23 18:36:01.134026
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:04.874592
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:36:15.515811
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Test method fill of class AnsiTextWrapper."""
    # Create the text to be wrapped

# Generated at 2022-06-23 18:36:23.772609
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """
    Unit test for :obj:`~flutils.txtutils.AnsiTextWrapper`
    :obj:`wrap <~flutils.txtutils.AnsiTextWrapper.wrap>` method.
    """


# Generated at 2022-06-23 18:36:36.170949
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper

# Generated at 2022-06-23 18:36:45.126083
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:36:55.467887
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test cases for :obj:`AnsiTextWrapper.__init__()`."""
    # A simple test case, with no ANSI codes

# Generated at 2022-06-23 18:37:05.366848
# Unit test for method fill of class AnsiTextWrapper