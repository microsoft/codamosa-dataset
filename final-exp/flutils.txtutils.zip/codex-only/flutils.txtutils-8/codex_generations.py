

# Generated at 2022-06-23 18:26:58.968906
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:27:10.606154
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:22.216077
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:25.839366
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:27:35.624474
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for AnsiTextWrapper constructor."""
    ansi_text_wrapper: AnsiTextWrapper = AnsiTextWrapper(
        width=40,
        initial_indent='  ',
        subsequent_indent='\\x1b[38;2;55;172;230m* \\x1b[0m',
        expand_tabs=True,
        replace_whitespace=True,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=8,
        max_lines=None,
        placeholder=' [...]'
    )  # type: ignore
    assert ansi_text_wrapper.width == 40

# Generated at 2022-06-23 18:27:39.576467
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = 'foobar'
    length = len_without_ansi(text)
    assert length == len(text),\
        "len_without_ansi({}) should have been {} instead of {}"\
        .format(repr(text), len(text), length)



# Generated at 2022-06-23 18:27:44.554969
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:55.945179
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Unit test for method fill of class AnsiTextWrapper.
    """
    wrapper = AnsiTextWrapper(
        width=40,
        # initial_indent="◆ ",
        # subsequent_indent="    ",
        placeholder=' [...]',
        expand_tabs=False,
        replace_whitespace=True,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=4,
        max_lines=None
    )

# Generated at 2022-06-23 18:28:02.459832
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function :obj:`len_without_ansi`."""
    assert len_without_ansi('\x1b[38;5;196mba') == 1
    assert len_without_ansi('ba\x1b[38;5;196m') == 1



# Generated at 2022-06-23 18:28:10.839991
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:28:14.121988
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = 6
    assert len_without_ansi(text) == out



# Generated at 2022-06-23 18:28:25.569584
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None
    assert wrapper.placeholder == ' [...]'


# Generated at 2022-06-23 18:28:33.827709
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:34.885115
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    pass



# Generated at 2022-06-23 18:28:44.066637
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:56.437092
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper"""
    import re
    import sys

    def _repr_name(value: Any) -> str:
        return re.sub(r'\s+<.*| at 0x[0-9a-zA-Z]+>$', '', repr(value))

    # Constructor should raise a TypeError if width is not an integer.
    with pytest.raises(TypeError) as err:
        AnsiTextWrapper('width')
    assert str(err.value) == (
        'width must be an integer greater than 0; '
        'not ' + _repr_name("width")
    )

    # Constructor should raise a ValueError if width is less than or equal
    # to zero.

# Generated at 2022-06-23 18:29:03.680381
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    assert(AnsiTextWrapper(
        initial_indent='\x1b[91m*\x1b[92m ',
        subsequent_indent='\x1b[34m',
    ).initial_indent == '\x1b[91m*\x1b[92m ')
    assert(AnsiTextWrapper(
        initial_indent='\x1b[91m*\x1b[92m ',
        subsequent_indent='\x1b[34m',
    ).subsequent_indent == '\x1b[34m')
    assert(AnsiTextWrapper(
        initial_indent='\x1b[91m*\x1b[92m ',
        subsequent_indent='\x1b[34m',
    ).placeholder == ' [...]')

# Generated at 2022-06-23 18:29:15.637743
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:20.800836
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = 6
    assert len_without_ansi(text) == out
    out = 0
    assert len_without_ansi('') == out


# Generated at 2022-06-23 18:29:29.733478
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:40.319399
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    # Test multiple paragraphs
    wrapper = AnsiTextWrapper(width=30,
                              max_lines=3,
                              placeholder=' [...]',
                              initial_indent='  ',
                              subsequent_indent='    ')

    text = (
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras '
        'fermentum maximus auctor. Cras a varius ligula. Phasellus ut '
        'ipsum eu erat consequat posuere. Pellentesque habitant morbi '
        'tristique senectus et netus et malesuada fames ac turpis '
        'egestas. Maecenas ultricies lacus id massa interdum dignissim. '
        'Curabitur sapien.'
    )

   

# Generated at 2022-06-23 18:29:50.588660
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit test for method fill of class AnsiTextWrapper."""

# Generated at 2022-06-23 18:29:55.902077
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\\x1b[1mfoobar\\x1b[0m\\x1b[2m\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 12



# Generated at 2022-06-23 18:30:05.393563
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[38;5;208mbar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['foo', '\x1b[38;5;208mbar\x1b[0m']) == 6
    assert len_without_ansi(['foo', '\x1b[38;5;208mbar', '\x1b[0m']) == 6

# Generated at 2022-06-23 18:30:15.729547
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

    # -------------------------------------------------------------------------
    # Wrap (and fill) a single paragraph.
    # -------------------------------------------------------------------------
    #
    # No wrapping, text is less than width.
    text = 'abcdef'
    wrapper = AnsiTextWrapper(width=len(text))
    result1 = wrapper.wrap(text)
    result2 = wrapper.fill(text)
    assert result1 == ['abcdef']
    assert result2 == 'abcdef'

    # No wrapping, text is exactly width.
    text = 'abcdef'
    wrapper = AnsiTextWrapper(width=len(text))
    result1 = wrapper.wrap(text)
    result2 = wrapper.fill(text)
    assert result1 == ['abcdef']
    assert result2 == 'abcdef'

    # Wrapping,

# Generated at 2022-06-23 18:30:23.645155
# Unit test for function len_without_ansi

# Generated at 2022-06-23 18:30:34.043900
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:43.683513
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:54.171389
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # fmt: off
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == 6
    # fmt: on


# noinspection PyMissingConstructor

# Generated at 2022-06-23 18:31:03.050354
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from flutils.testing import raise_if_not_super

    # Test calling constructor
    try:
        AnsiTextWrapper()
    except Exception:
        raise_if_not_super(AssertionError)

    # Test that initial indent and subsequent indent can contain ANSI codes
    try:
        AnsiTextWrapper(
            initial_indent='\\x1b[31m\\x1b[1m\\x1b[4m',
            subsequent_indent='\\x1b[31m\\x1b[1m'
        )
    except Exception:
        raise_if_not_super(AssertionError)

    # Test that placeholder can contain ANSI codes

# Generated at 2022-06-23 18:31:13.674905
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=70)
    text = 'one two three four five six seven eight nine ten eleven twelve'
    expected = ['one two three four five six seven eight nine ten eleven twelve']
    actual = wrapper.wrap(text)
    assert actual == expected
    text = 'one two three four five six seven eight nine ten eleven twelve '
    text += 'thirteen fourteen fifteen sixteen seventeen eighteen nineteen '
    text += 'twenty'
    expected = [
        'one two three four five six seven eight nine ten eleven twelve ',
        'thirteen fourteen fifteen sixteen seventeen eighteen nineteen ',
        'twenty'
    ]
    actual = wrapper.wrap(text)
    assert actual == expected

# Generated at 2022-06-23 18:31:26.164046
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:32.998469
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ('\x1b[38;5;209mfoo', 'bar\x1b[0m')
    assert len_without_ansi(text) == 6
    text = ('\x1b[38;5;209mfoo\x1b[0m', 'bar\x1b[0m')
    assert len_without_ansi(text) == 6
    text = ('foo', 'bar')
    assert len_without_ansi(text) == 6
    text = ('\x1b[38;5;209m', 'foobar')
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:31:44.690962
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Make sure that textwrap.TextWrapper does NOT handle ANSI codes
    wrapper = textwrap.TextWrapper(width=40)

# Generated at 2022-06-23 18:31:55.639749
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    res = AnsiTextWrapper().wrap("foo bar")
    assert res == ["foo bar"]

    res = AnsiTextWrapper().wrap("a b c d e f")
    assert res == ["a b c d e f"]

    res = AnsiTextWrapper(width=4).wrap("a b c d e f")
    assert res == ["a b", "c d", "e f"]

    res = AnsiTextWrapper(width=4,
                          initial_indent="     ").wrap("a b c d e f")
    assert res == ["     a b", "     c d", "     e f"]


# Generated at 2022-06-23 18:32:05.545152
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:17.158117
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:27.174172
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper

# Generated at 2022-06-23 18:32:38.513154
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:50.622368
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # pragma: no cover
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:32:58.411223
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method wrap of class AnsiTextWrapper."""

# Generated at 2022-06-23 18:33:10.563820
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:19.324581
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:33:28.041298
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:33.308315
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    # Check that the AnsiTextWrapper constructor does not raise
    # a TypeError.
    assert wrapper


if __name__ == '__main__':
    test_AnsiTextWrapper()

# Generated at 2022-06-23 18:33:44.347694
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    w = AnsiTextWrapper(placeholder=' [...]')
    lines = w.wrap('\x1b[31m\x1b[1m\x1b[4mLorem ipsum dolor sit amet, '
                   'consectetur adipiscing elit. Cras fermentum maximus '
                   'auctor. Cras a varius ligula.\x1b[0m')
    assert lines == ['\x1b[31m\x1b[1m\x1b[4mLorem ipsum dolor sit amet, '
                     'consectetur adipiscing elit. Cras fermentum maximus '
                     'auctor. Cras a varius ligula.\x1b[0m']

    w.width=40

# Generated at 2022-06-23 18:33:53.187310
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:00.591556
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.py23 import get_func_argspec
    from flutils.txtutils import len_without_ansi
    from inspect import _empty  # type: ignore[attr-defined]

    argspec = get_func_argspec(len_without_ansi)
    assert argspec.args == ('seq', )
    assert argspec.varargs is None
    assert argspec.varkw is None
    assert argspec.defaults is None
    assert argspec.kwonlyargs == []
    assert argspec.kwonlydefaults is _empty
    assert argspec.annotations == {'seq': Sequence}

# Generated at 2022-06-23 18:34:09.614456
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import sys


# Generated at 2022-06-23 18:34:12.734004
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:34:19.570079
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:34:31.309210
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Tests for fill method of class AnsiTextWrapper."""
    # Fixed values
    _width = 40
    _ansi_reset = '\x1b[0m'
    _ansi_bold = '\x1b[1m'
    _ansi_underline = '\x1b[4m'
    _ansi_red = '\x1b[31m'
    _ansi_blue = '\x1b[38;2;55;172;230m'
    _ansi_magenta = '\x1b[38;5;208m'
    _ansi_colors = (
        _ansi_red, _ansi_blue, _ansi_magenta
    )

    # Create the original text

# Generated at 2022-06-23 18:34:43.014155
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:34:54.142860
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Tests for the ``wrap`` method of the
    :obj:`~flutils.txtutils.AnsiTextWrapper` class.
    """
    #
    #  Example given in the docstring for AnsiTextWrapper
    #
    wrapper = AnsiTextWrapper(width=40)


# Generated at 2022-06-23 18:34:59.334365
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = 'foobar'
    text_with_ansi = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == len_without_ansi(text)
    assert len(text) == len_without_ansi(text_with_ansi)




# Generated at 2022-06-23 18:35:09.762527
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Test 1: Valid class instantiation
    wrapper = AnsiTextWrapper(width=40)
    assert isinstance(wrapper, AnsiTextWrapper)

    # Test 2: Valid class instantiation
    wrapper = AnsiTextWrapper(width=40, initial_indent='    ')
    assert isinstance(wrapper, AnsiTextWrapper)

    # Test 3: Valid class instantiation
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='    ',
        subsequent_indent='  '
    )
    assert isinstance(wrapper, AnsiTextWrapper)

    # Test 4: Valid class instantiation
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='    ',
        subsequent_indent='  ',
        expand_tabs=False
    )

# Generated at 2022-06-23 18:35:20.840659
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper


# Generated at 2022-06-23 18:35:31.384686
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # pylint: disable=protected-access
    # This is a unit test, so accessing protected members is ok.
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper._subsequent_indent == ''
    assert wrapper._initial_indent == ''
    assert wrapper._drop_whitespace is True
    assert wrapper._fix_sentence_endings is False
    assert wrapper._break_long_words is True
    assert wrapper._break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None
    assert wrapper._placeholder == ' [...]'
    wrapper = AnsiTextWrapper(width=80, initial_indent='+ ', break_long_words=False,
                              break_on_hyphens=False, placeholder='...')

# Generated at 2022-06-23 18:35:38.084493
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mf', 'oo', 'bar\x1b[0m']
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:35:49.715440
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.testutils import TestCase
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:35:52.609978
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_str = 'ab\x1b[30m\x1b[31m\x1b[32m\x1b[33m\x1b[34m\x1b[35m\x1b[36m\x1b[37m\x1b[38m\x1b[39m\x1b[0m'
    assert len_without_ansi(test_str) == 2

# Generated at 2022-06-23 18:36:01.579020
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:13.266466
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:36:22.134184
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:34.177965
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:40.520008
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['foo', 'bar', 'baz']
    assert len_without_ansi(text) == 9
    text = ('foo', 'bar', 'baz')
    assert len_without_ansi(text) == 9

# Generated at 2022-06-23 18:36:52.872565
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:37:03.935611
# Unit test for method wrap of class AnsiTextWrapper