

# Generated at 2022-06-23 18:27:06.847891
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    print("\nTest AnsiTextWrapper:")
    wrapper = AnsiTextWrapper(width=75, initial_indent='  ', placeholder='+')
    print("wrapper.width: {}".format(wrapper.width))
    print("wrapper.initial_indent: {}".format(wrapper.initial_indent))
    print("wrapper.initial_indent_len: {}".format(wrapper.initial_indent_len))
    print("wrapper.subsequent_indent: {}".format(wrapper.subsequent_indent))
    print("wrapper.subsequent_indent_len: {}".format(wrapper.subsequent_indent_len))
    print("wrapper.expand_tabs: {}".format(wrapper.expand_tabs))

# Generated at 2022-06-23 18:27:19.296155
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    out = 6
    assert out == len_without_ansi(text)
    text = '\\x1b[38;5;209mfoobar'
    out = 6
    assert out == len_without_ansi(text)
    text = ['\\x1b[38;5;209mfoobar\\x1b[0m', '\\x1b[38;5;209mfoobar\\x1b[0m']
    out = 12
    assert out == len_without_ansi(text)
    text = '\\x1b[fobar\\x1b[0m'
    out = 0
    assert out == len_without_ansi(text)

# Generated at 2022-06-23 18:27:30.905819
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for class AnsiTextWrapper"""

    x = AnsiTextWrapper(
        width=40, initial_indent='  | ', subsequent_indent='  | ',
        placeholder=' [...]'
    )
    y = AnsiTextWrapper(
        width=40, initial_indent='  | ', subsequent_indent='  | ',
        placeholder=' [...]'
    )
    z = AnsiTextWrapper(
        width=40, initial_indent='  | ', subsequent_indent='  | ',
        placeholder=' [...]'
    )
    assert x == y == z


# Generated at 2022-06-23 18:27:38.803310
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper
    from flutils.txtutils import len_without_ansi

    for width in [0, 1, 2, 3, 4, 5]:
        wrapper = AnsiTextWrapper(width=width)
        assert wrapper.wrap('') == []
        assert wrapper.wrap('a') == ['a']
        assert wrapper.wrap('a b') == ['ab']
        assert wrapper.wrap('a\nb') == ['a', 'b']
        wrapper = AnsiTextWrapper(width=width, drop_whitespace=False)
        assert wrapper.wrap('') == []
        assert wrapper.wrap('a') == ['a']
        assert wrapper.wrap('a b') == ['a', 'b']
        assert wrapper.wrap('a\nb') == ['a', 'b']

   

# Generated at 2022-06-23 18:27:42.164459
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:27:53.922894
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:05.681701
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from textwrap import TextWrapper as _TextWrapper
    from flutils.txtutils import AnsiTextWrapper
    from flutils.txtutils import AnsiTextWrapper as _AnsiTextWrapper


# Generated at 2022-06-23 18:28:16.056962
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Test function
    # ------------------
    results = [
        len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m'),
        len_without_ansi(['\x1b[38;5;209mfoobar', '\x1b[0m']),
    ]
    assert results == [6, 6]


_bases = frozenset(('', '\x1b[2m', '\x1b[4m', '\x1b[4m\x1b[1m', '\x1b[4m\x1b[1m\x1b[2m'))



# Generated at 2022-06-23 18:28:27.172597
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from .testing_helpers import print_diff


# Generated at 2022-06-23 18:28:31.616212
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for the function :func:`len_without_ansi`."""
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
# Unit test: flutils.txtutils.txtutils.test_len_without_ansi()



# Generated at 2022-06-23 18:28:41.668032
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit test for method fill of class AnsiTextWrapper."""

# Generated at 2022-06-23 18:28:54.252208
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:59.776671
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit testing for the method wrap of class AnsiTextWrapper."""

    from collections import defaultdict
    from itertools import repeat
    from typing import (
        Any,
        Callable,
        Counter,
        DefaultDict,
        Mapping,
        Optional,
        Tuple,
        Union
    )
    from unittest import mock
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from pathlib import Path
    from shutil import rmtree
    from sys import exit
    from tempfile import mkdtemp
    from time import time
    from uuid import uuid4
    from flutils.txtutils import AnsiTextWrapper

    # Maximum number of errors to display before aborting the test.
    MAX_ERRORS = 5
    # The path to the

# Generated at 2022-06-23 18:29:11.435100
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Test :meth:`flutils.txtutils.len_without_ansi`.
    """
    from flutils.testing import Raiser
    from flutils.txtutils import len_without_ansi
    from io import StringIO
    from sys import stdout
    from textwrap import TextWrapper
    from types import GeneratorType
    ansi_string = (
        '\x1b[38;5;209mfoobar\x1b[38;5;214m\x1b[0m'
        '\x1b[38;5;209mfoobar\x1b[38;5;214m\x1b[0m'
    )

# Generated at 2022-06-23 18:29:24.177273
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:36.092073
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:29:37.617719
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    assert AnsiTextWrapper().fill('') == ''



# Generated at 2022-06-23 18:29:44.669072
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """ Unit test for method wrap of class AnsiTextWrapper """

    ####
    # Test an empty string.
    ####
    _text = ''
    text_wrapper = AnsiTextWrapper(width=40)
    text_wrapped = text_wrapper.wrap(_text)
    assert text_wrapped == []

    ####
    # Test a single character string.
    ####
    _text = 'a'
    text_wrapper = AnsiTextWrapper(width=40)
    text_wrapped = text_wrapper.wrap(_text)
    assert text_wrapped == ['a']

    _text = 'abcd efg hijk lmnop qrst uvw xyz'
    ####
    # Test a string that ends with a newline.
    ####
    text_wrapper = AnsiTextWra

# Generated at 2022-06-23 18:29:53.032217
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == len(text) - 12
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']) == len(text) - 12
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m']) == len(text) - 12
    assert len_without_ansi(['foo', 'bar']) == len('foobar')
    assert len_without_ansi(('foo', 'bar')) == len('foobar')



# Generated at 2022-06-23 18:30:03.487356
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:09.212128
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper

    Creates a new AnsiTextWrapper object, then asserts that the attributes
    have the correct values.
    """
    _attr_name: str
    _attr_value: Any
    _expected_value: Any


# Generated at 2022-06-23 18:30:20.027446
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:31.497072
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pytest import raises
    from .typingutils import assert_type_or_raise

    for _ in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]:
        assert len_without_ansi('foo') == 3
        assert len_without_ansi(('foo', 'bar')) == 6
        assert len_without_ansi(['foo', 'bar']) == 6
    with raises(TypeError):
        len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m',
                            keep_ansi=True) == 21

# Generated at 2022-06-23 18:30:35.536818
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi(('foo', 'bar')) == 6


# Generated at 2022-06-23 18:30:38.480936
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:30:46.260039
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test the AnsiTextWrapper.wrap method."""
    # pylint: disable=bad-whitespace,line-too-long

# Generated at 2022-06-23 18:30:57.496927
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:09.613791
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:21.142182
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    from contextlib import redirect_stdout
    import io
    import sys
    import unittest

    def capture_stdout(func, *args):
        old_stdout = sys.stdout
        captured_output = io.StringIO()
        with redirect_stdout(captured_output):
            func(*args)
        sys.stdout = old_stdout
        return captured_output.getvalue().splitlines()

    class Test_AnsiTextWrapper(unittest.TestCase):

        def test_validation(self):
            wrapper = AnsiTextWrapper()
            with self.assertRaises(ValueError):
                wrapper.placeholder = 'x y z'
            with self.assertRaises(ValueError):
                wrapper.width = -1

# Generated at 2022-06-23 18:31:29.049571
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # pylint: disable=unused-variable
    '''Unit test for constructor of class AnsiTextWrapper.'''
    AnsiTextWrapper(width=42,
                    initial_indent='    ',
                    subsequent_indent='    ',
                    expand_tabs=True,
                    replace_whitespace=False,
                    fix_sentence_endings=False,
                    break_long_words=True,
                    drop_whitespace=True,
                    break_on_hyphens=True,
                    tabsize=8,
                    max_lines=10,
                    placeholder=' [...]')


# Generated at 2022-06-23 18:31:41.102625
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    with patch('builtins.input', return_value='test'):
        wrapper = AnsiTextWrapper(width=20)
        assert wrapper.width == 20
        wrapped = wrapper.wrap('This is a test')
        assert len(wrapped) == 2
        assert wrapped[0] == 'This is a test'
        assert wrapped[1] == ''
    with patch('builtins.input', return_value='test'):
        wrapper = AnsiTextWrapper(width=20, placeholder='...', max_lines=2)
        assert wrapper.width == 20
        wrapped = wrapper.wrap('This is a test')
        assert len(wrapped) == 1
        assert wrapped[0] == 'This is a test'

# Generated at 2022-06-23 18:31:50.580958
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None
    assert wrapper.placeholder == ' [...]'


# Generated at 2022-06-23 18:31:58.984597
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:03.905137
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:15.655014
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    # Test AnsiTextWrapper.wrap without ANSI codes
    text = "abc def ghi"
    wrapper = AnsiTextWrapper(width=3)
    wrapped_text = wrapper.wrap(text)
    assert wrapped_text == ['abc', 'def', 'ghi']

    wrapper = AnsiTextWrapper(width=3, subsequent_indent="   ")
    wrapped_text = wrapper.wrap(text)
    assert wrapped_text == ['abc', '   def', '   ghi']

    # Test AnsiTextWrapper.wrap with ANSI codes
    text = '\x1b[31mabc \x1b[32mdef ghi'
    wrapper = AnsiTextWrapper(width=3)
    wrapped_text = wrapper.wrap(text)

# Generated at 2022-06-23 18:32:26.412286
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:38.121802
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:50.578334
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit tests for method wrap of class AnsiTextWrapper."""


# Generated at 2022-06-23 18:32:55.800699
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


_TEXT_WRAPPER_INITIALIZED: Optional[bool] = None
_TEXT_WRAPPER_KWARGS: Optional[List[str]] = None



# Generated at 2022-06-23 18:33:07.202220
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    assert(isinstance(wrapper.width, int))
    assert(wrapper.width == 70)
    assert(isinstance(wrapper.initial_indent, str))
    assert(wrapper.initial_indent == '')
    assert(isinstance(wrapper.subsequent_indent, str))
    assert(wrapper.subsequent_indent == '')
    assert(isinstance(wrapper.expand_tabs, bool))
    assert(wrapper.expand_tabs is True)
    assert(isinstance(wrapper.replace_whitespace, bool))
    assert(wrapper.replace_whitespace is True)
    assert(isinstance(wrapper.fix_sentence_endings, bool))
    assert(wrapper.fix_sentence_endings is False)

# Generated at 2022-06-23 18:33:12.919181
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """
    Just verify that the constructor doesn't raise errors.
    """
    AnsiTextWrapper()
    AnsiTextWrapper(
        width=40,
        max_lines=3,
        initial_indent='\x1b[1m',
        subsequent_indent=' ' * 4,
        placeholder='\x1b[0m'
    )


# Generated at 2022-06-23 18:33:23.974963
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:33.580942
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from unittest.mock import patch

    from flutils.txtutils import AnsiTextWrapper

    with patch('flutils.txtutils.AnsiTextWrapper.fill') as _fill:
        with patch.multiple(AnsiTextWrapper, __init__=lambda self: None):
            wrapper = AnsiTextWrapper()
            lines = ['', '', '', '', '', '', '', '']
            text = '\n'.join(lines)
            wrapper.width = 80
            _fill.return_value = text
            assert wrapper.wrap(text) == lines


# Generated at 2022-06-23 18:33:39.044044
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from .txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:33:49.006327
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40, max_lines=None)
    assert wrapper.width == 40
    assert wrapper.max_lines == None
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder_len == 0
    assert wrapper.placeholder == ' [...]'
    wrapper = AnsiTextWrapper(width=40, max_lines=1)
    assert wrapper.width == 40
    assert wrapper.max_lines == 1
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder_len == 0
    assert wrapper.placeholder == ' [...]'
    wrapper = AnsiTextWrapper(width=40, max_lines=2)
    assert wrapper.width

# Generated at 2022-06-23 18:33:56.811067
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""

    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines == None
    assert wrapper.placeholder == ' [...]'


# Generated at 2022-06-23 18:34:08.749655
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from .txtutils import len_without_ansi
    from .fldicts import FLObjDict
    from .fldicts import FLDict
    from .fldicts import FLAttrDict
    from .fldicts import FLChainMap
    from .fldicts import FLChainMapDict
    from collections import UserDict

    # ------------------------------------
    # Test FLObjDict
    # ------------------------------------

    class Test1(FLObjDict):
        x = 'test'

    obj = Test1()
    out = len_without_ansi(obj)
    assert out == 4

    # ------------------------------------
    # Test FLDict
    # ------------------------------------

    obj = FLDict({'x': 'test'})
    out = len_without_ansi(obj)
    assert out == 4

    # ------------------------------------


# Generated at 2022-06-23 18:34:17.662419
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Test the handling of width
    # pylint: disable=protected-access
    wrapper = AnsiTextWrapper(width=0)
    assert (wrapper.width == 0 and
            wrapper.initial_indent == '' and
            wrapper.subsequent_indent == '' and
            wrapper.placeholder == ' [...]' and
            wrapper.placeholder_len == 6 and
            wrapper.initial_indent_len == 0 and
            wrapper.subsequent_indent_len == 0 and
            wrapper.expand_tabs is True and
            wrapper.replace_whitespace is True and
            wrapper.break_long_words is True and
            wrapper.break_on_hyphens is True and
            wrapper.tabsize == 8 and
            wrapper.max_lines is None)

# Generated at 2022-06-23 18:34:23.306428
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:34.665913
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import textwrap

# Generated at 2022-06-23 18:34:45.580464
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:34:51.931661
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6, f'len_without_ansi({text}) != 6'
    assert len_without_ansi(text.split()) == 6, f'len_without_ansi({text}) != 6'



# Generated at 2022-06-23 18:35:03.644490
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:12.084067
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function len_without_ansi."""
    import pytest
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6

    _text = '• This is a the foobar baz spam and eggs routine.'
    wrapped = '\x1b[38;5;209m•\x1b[0m This is a the foobar baz spam and eggs ' \
              'routine.'
    assert len_without_ansi(_text) == len(_text)
    assert len_without_ansi(wrapped) == len(_text)

    _text = '• This is a the foobar baz spam and eggs routine.'

# Generated at 2022-06-23 18:35:20.453534
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test len_without_ansi()."""
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi([text, 'foobar']) == 12

AnsiTextWrapperType = TextWrapper

# Generated at 2022-06-23 18:35:31.157314
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:42.034411
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    print("Testing constructor of class AnsiTextWrapper")
    wrapper = AnsiTextWrapper(width=30,
                              initial_indent='',
                              subsequent_indent='    ',
                              expand_tabs=True,
                              replace_whitespace=True,
                              fix_sentence_endings=False,
                              break_long_words=True,
                              drop_whitespace=True,
                              break_on_hyphens=True,
                              tabsize=8,
                              max_lines=3,
                              placeholder=' [...]')
    assert wrapper.wrap('a') == ['a']
    assert wrapper.wrap('ab') == ['ab']
    assert wrapper.wrap('abc') == ['abc']
    assert wrapper.wrap('abcd') == ['abcd']

# Generated at 2022-06-23 18:35:45.418728
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from doctest import testmod as Test
    from flutils.txtutils import AnsiTextWrapper

    Test(AnsiTextWrapper, verbose=False)


# Generated at 2022-06-23 18:35:55.745231
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:05.214311
# Unit test for function len_without_ansi
def test_len_without_ansi():
    "Tests the function len_without_ansi"
    assert len_without_ansi('\x1b[1mbold!\x1b[0m') == 5
    assert len_without_ansi('\x1b[1mbold!') == 5
    assert len_without_ansi('bold!\x1b[0m') == 5
    assert len_without_ansi('bold!') == 5
    assert len_without_ansi('some \x1b[4mtext\x1b[0m') == 10
    assert len_without_ansi(['some: ', '\x1b[4m', 'text', '\x1b[0m']) == 10
    assert len_without_ansi('\x1b[4msome text\x1b[0m') == 10
   

# Generated at 2022-06-23 18:36:15.791059
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:23.923587
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pytest import raises, warn
    from sys import maxsize
    from typing import Any

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6

    text = '\x1b[38;5;209mfoo\x1b[38;5;209mbar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6

    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    out = len_without_ansi(text)
    assert out == 6

    text = '\x1b[38;5;209mfoo\x1b[0mbar'
    out = len_

# Generated at 2022-06-23 18:36:31.290187
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoo', 'bar', '\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209mfoo', 'bar', '\x1b[0m')) == 6



# Generated at 2022-06-23 18:36:42.462121
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:54.173682
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:37:04.618897
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Tests the constructor of class :obj:`~flutils.txtutils.AnsiTextWrapper`
    """
    wrapper = AnsiTextWrapper(width=0)
    assert wrapper.width == 0

    wrapper = AnsiTextWrapper(width=None)
    assert wrapper.width == 0

    wrapper = AnsiTextWrapper(width='0')
    assert wrapper.width == 0

    wrapper = AnsiTextWrapper(width='foo')
    assert wrapper.width == 0

    wrapper = AnsiTextWrapper(width='')
    assert wrapper.width == 0

    wrapper = AnsiTextWrapper(width=1)
    assert wrapper.width == 1

    wrapper = AnsiTextWrapper(width=10)
    assert wrapper.width == 10

    wrapper = AnsiTextWrapper(width='10')