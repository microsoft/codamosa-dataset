

# Generated at 2022-06-23 18:26:59.959760
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    seq = (text, text)
    assert len_without_ansi(seq) == 12



# Generated at 2022-06-23 18:27:12.023510
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # pragma: no cover
    tw = AnsiTextWrapper(width=40, initial_indent='> ')

# Generated at 2022-06-23 18:27:14.851281
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:27:26.618708
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrap = AnsiTextWrapper(width=20)
    text = (
        '\x1b[31m\x1b[1m\x1b[4mThis is an '
        'example.\x1b[0m This is another '
        'example.\x1b[1m This is a third '
        'example.\x1b[0m'
    )
    result = wrap.wrap(text)
    assert result == [
        '\x1b[31m\x1b[1m\x1b[4mThis is an ',
        'example.\x1b[0m This is ',
        'another example.',
        '\x1b[1m This is a third ',
        'example.\x1b[0m',
    ]


# Generated at 2022-06-23 18:27:36.196815
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test AnsiTextWrapper's constructor

    Test the constructor of :obj:`flutils.txtutils.AnsiTextWrapper`
    """

    _AnsiTextWrapper = AnsiTextWrapper

    # Test that the constructor of AnsiTextWrapper asserts
    # that width is greater than the placeholder length
    def _test_width_placeholder_assertion(kwargs: Dict[str, Any]) -> None:
        """Test that the constructor of :obj:`AnsiTextWrapper` raises
        an assertion error when the length of ``placeholder`` is
        greater than or equal to ``max_width``.

        Args:
            kwargs (Dict[str, Any]): Keyword arguments passed to the
                constructor of :obj:`AnsiTextWrapper`.
        """

# Generated at 2022-06-23 18:27:47.517210
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    print('\ntest_AnsiTextWrapper:\n')

    # noinspection SpellCheckingInspection

# Generated at 2022-06-23 18:27:57.232569
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    wrapper = AnsiTextWrapper(width=40)


# Generated at 2022-06-23 18:28:03.872630
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # text is a str
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # text is a list of strs
    text = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(text) == 6
test_len_without_ansi()



# Generated at 2022-06-23 18:28:09.431887
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:19.282274
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:21.904195
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import doctest
    doctest.testmod(AnsiTextWrapper)


# Generated at 2022-06-23 18:28:31.504775
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:41.550683
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:54.152472
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    from flutils.txtutils import AnsiTextWrapper

    wrapper = AnsiTextWrapper(width=40)

    # No text.
    text = ''
    wrapped_text = wrapper.wrap(text)
    assert wrapped_text == []

    # Only whitespaces.
    text = ' \t \n \r \x0b \x0c '
    wrapped_text = wrapper.wrap(text)
    assert wrapped_text == []

    # No breakable characters.
    text = 'e' * 40
    wrapped_text = wrapper.wrap(text)
    assert wrapped_text == [text]

    # One line, no wrapping needed.
    text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    wrapped_text = wrapper.wrap(text)

# Generated at 2022-06-23 18:29:05.744655
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:17.670588
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from colorama import Fore, Back, Style, init
    init(autoreset=True)

    msg = ('\nTest of class AnsiTextWrapper:'
           '\n1. constructor'
           '\n2. \x1b[31m\x1b[1m\x1b[4mstring property getters/setters'
           '\n3. wrap() and fill() methods.\x1b[0m'
           '\nNote that while the string "placeholder" is long enough to'
           '\nbe truncated, the string actually used as the placeholder'
           '\nappears to have a length of zero because the ANSI codes are'
           '\ntreated as zero-length strings.')
    print(msg)

    # Use width of 80 so there will be room for the initial_indent

# Generated at 2022-06-23 18:29:28.172279
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:39.549992
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import random
    import string
    import flutils.txtutils as txtutils


# Generated at 2022-06-23 18:29:49.892325
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest

    test_data: List[dict] = [
        {'seq': '\x1b[38;5;209mfoobar\x1b[0m', 'expected': 6},
        {'seq': ['\x1b[38;5;209m', 'foobar', '\x1b[0m'], 'expected': 6},
        {'seq': 'foobar', 'expected': 6},
    ]


# Generated at 2022-06-23 18:30:01.386559
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    l = '{0}: {1}'.format('AnsiTextWrapper', '🦄')
    if sys.version_info < (3, 8):
        # Support for Python 3.6
        l = '{0}: {1}'.format('AnsiTextWrapper', '🦄'.encode('utf-8').decode('utf-8'))
    lines = ['\x1b[31m\x1b[1m\x1b[4m\x1b[5m{0}\x1b[0m'.format(l)]

# Generated at 2022-06-23 18:30:04.238972
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:30:10.835774
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test the function ``len_without_ansi``."""
    expected = [[6, ['hello', 'world']], [12, ['hello', ' ', 'world']],
                [6, ['\x1b[38;5;208m', 'hello', '\x1b[0m']],
                [12, ['\x1b[38;5;208m', 'hello', ' ', '\x1b[0m', 'world']],
                [12, ['\x1b[38;5;208m', 'hello\x1b[0m', ' ', 'world']]]
    for length, seq in expected:
        assert len_without_ansi(seq) == length



# Generated at 2022-06-23 18:30:21.094197
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Create an AnsiTextWrapper object with width 50
    wrapper = AnsiTextWrapper(width=50)

    # Create a text sequence with ANSI codes

# Generated at 2022-06-23 18:30:31.052594
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Test __init__ method
    try:
        atw = AnsiTextWrapper()
    except:
        assert False

    # Test initial_indent setter
    try:
        atw.initial_indent = '\x1b[31m'
    except:
        assert False
    try:
        atw.subsequent_indent = '\x1b[31m'
    except:
        assert False
    try:
        atw.placeholder = '\x1b[31m'
    except:
        assert False
    try:
        atw.subsequent_indent = '\x1b[;m'
    except:
        assert False



# Generated at 2022-06-23 18:30:33.547941
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(seq) == 6



# Generated at 2022-06-23 18:30:43.269312
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    # Check that all properties exist
    for attr in [
            'width',
            'initial_indent',
            'subsequent_indent',
            'expand_tabs',
            'replace_whitespace',
            'fix_sentence_endings',
            'break_long_words',
            'drop_whitespace',
            'break_on_hyphens',
            'tabsize',
            'max_lines',
            'placeholder'
    ]:
        getattr(wrapper, attr)
    # Check that ANSI codes are stripped from indent and placeholder

# Generated at 2022-06-23 18:30:55.512098
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """
    Unit test for method wrap of class AnsiTextWrapper
    """

# Generated at 2022-06-23 18:31:07.696882
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:31:18.861768
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pprint import pformat
    from flutils.txtutils import len_without_ansi
    from flutils.txtutils import _ANSI_RE

    def _assert(seq, expected):
        out: int = len_without_ansi(seq)
        if out == expected:
            return
        else:
            raise AssertionError(
                'Expected: %r\nActual:   %r' % (expected, out))

    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    _assert(text, 6)

# Generated at 2022-06-23 18:31:29.331638
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import unittest
    from textwrap import dedent
    from flutils.txtutils import len_without_ansi
    class Test(unittest.TestCase):
        def test_len(self):
            text = '\x1b[38;5;209mfoobar\x1b[0m'
            self.assertEqual(len(text), len_without_ansi(text))
            text = 'foo\x1b[38;5;209mfoobar\x1b[0mbar'
            self.assertEqual(len(text) - 8, len_without_ansi(text))

# Generated at 2022-06-23 18:31:38.765543
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209', 'foobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
test_len_without_ansi()
del test_len_without_ansi



# Generated at 2022-06-23 18:31:50.363115
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    # Initialize a simulated terminal, some text and a series of
    # ANSITextWrapper objects...
    terminal: Terminal = Terminal()
    terminal.width, terminal.height = 80, 8

# Generated at 2022-06-23 18:31:52.996813
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from . import txtutils
    txtutils.len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m')



# Generated at 2022-06-23 18:31:56.829322
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = 6
    assert len_without_ansi(text) == out
    text = ['ab' for i in range(2)]
    out = 4
    assert len_without_ansi(text) == out



# Generated at 2022-06-23 18:32:06.328599
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # noqa
    from textwrap import dedent

    wrapper = AnsiTextWrapper(width=30, initial_indent='$ ',
                              subsequent_indent='> ')


# Generated at 2022-06-23 18:32:17.860807
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:32:27.495163
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # pylint: disable=protected-access

    # Test the default parameters
    lines = _AnsiTextWrapper(width=40).wrap(input_text_1)
    assert lines == output_lines_1

    # Test the default text width
    lines = _AnsiTextWrapper().wrap(input_text_2)
    assert lines == output_lines_2

    # Test non-default initial indent
    lines = _AnsiTextWrapper(
        width=40, initial_indent='  `'
    ).wrap(input_text_1)
    assert lines == output_lines_1_initial_indent

    # Test non-default subsequent indent
    lines = _AnsiTextWrapper(
        width=40, subsequent_indent='  '
    ).wrap(input_text_1)
    assert lines == output_

# Generated at 2022-06-23 18:32:34.077280
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('help\x1b[0m') == 4
    assert len_without_ansi(['help', '\x1b[0m']) == 4
    assert len_without_ansi('help\x1b[38;5;208m\x1b[0m') == 4
    assert len_without_ansi(['help', '\x1b[38;5;208m\x1b[0m']) == 4



# Generated at 2022-06-23 18:32:43.454219
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:51.700342
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=15,
                              initial_indent='\\x1b[31m\\x1b[1m\\x1b[4m',
                              subsequent_indent='\\x1b[0m',
                              placeholder=' [...]')
    assert isinstance(wrapper, AnsiTextWrapper)
    assert wrapper.width == 15
    assert wrapper.initial_indent == '\\x1b[31m\\x1b[1m\\x1b[4m'
    assert wrapper.subsequent_indent == '\\x1b[0m'
    assert wrapper.placeholder == ' [...]'


# Generated at 2022-06-23 18:32:56.299909
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi((text, )) == 6



# Generated at 2022-06-23 18:32:57.411908
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    test_AnsiTextWrapper_placeholder()



# Generated at 2022-06-23 18:33:05.097825
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Tests the method ``wrap`` of the class
    :obj:`~flutils.txtutils.AnsiTextWrapper` by comparing the output of
    :obj:`~flutils.txtutils.AnsiTextWrapper` to that of
    :obj:`textwrap.TextWrapper` using text with ANSI codes in it.

    """
    max_width = 70

# Generated at 2022-06-23 18:33:16.326920
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Use :obj:`~flutils.txtutils.AnsiTextWrapper` the same way as using
    # :obj:`TextWrapper <textwrap.TextWrapper>`::
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:33:26.421144
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    with pytest.raises(TypeError):  # no type annotation given
        AnsiTextWrapper()  # type: ignore
    with pytest.raises(TypeError):  # no type annotation given
        AnsiTextWrapper(1)  # type: ignore
    with pytest.raises(TypeError):  # no type annotation given
        AnsiTextWrapper(a=1)  # type: ignore
    with pytest.raises(TypeError):  # too many positional arguments
        AnsiTextWrapper(1, 2, 3, 4, 5, 6, 7, 8, 9)  # type: ignore
    with pytest.raises(TypeError):  # keyword argument max_lines must be int
        AnsiTextWrapper(max_lines=1.0)

# Generated at 2022-06-23 18:33:39.127363
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    text = """
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras fermentum
    maximus auctor. Cras a varius ligula. Phasellus ut ipsum eu erat
    consequat posuere."""
    width = 40
    wrapper_desired = textwrap.TextWrapper(width=width)
    wrapper_actual = AnsiTextWrapper(width=width)

    list_desired = wrapper_desired.wrap(text)
    list_actual = wrapper_actual.wrap(text)

    assert list_desired == list_actual


# Generated at 2022-06-23 18:33:48.700882
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    >>> from flutils.txtutils import len_without_ansi
    >>> len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    6
    >>> len_without_ansi('\x1b[31m\x1b[1mfoo\x1b[0m')
    3
    >>> len_without_ansi('\x1b[34;1mbar\x1b[0m')
    3
    >>> len_without_ansi('\x1b[34;1mbaz')
    3
    >>> len_without_ansi(['\x1b[38;5;209mfoo', 'bar\x1b[0m'])
    6
    """
    pass



# Generated at 2022-06-23 18:33:56.599612
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:34:08.558820
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=41)
    assert wrapper.width == 41
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.placeholder == ' [...]'
    try:
        wrapper = AnsiTextWrapper(width=-1)
        raise Exception('test_AnsiTextWrapper failed: '
                        'AnsiTextWrapper() did not raise an exception for '
                        'invalid width')
    except ValueError:
        pass

# Generated at 2022-06-23 18:34:13.318871
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:19.945205
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=4)
    text = '\\x1b[31m\\x1b[1m\\x1b[4mLorem'
    wrapped_text = wrapper.fill(text)
    assert wrapped_text == \
        'Lorem'

    text = '\\x1b[31m\\x1b[1m\\x1b[4mLorem ipsum'
    wrapped_text = wrapper.fill(text)
    assert wrapped_text == \
        'Lorem' + os.linesep + 'ipsum'

    text = '\\x1b[31m\\x1b[1m\\x1b[4MLorem ipsum dolor'
    wrapped_text = wrapper.fill(text)

# Generated at 2022-06-23 18:34:31.743379
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # The object's attributes here should match the defaults found in
    # the class' `__init__` method.
    eta = AnsiTextWrapper()
    assert eta.width == 70
    assert eta.initial_indent == ''
    assert eta.subsequent_indent == ''
    assert eta.expand_tabs == True
    assert eta.replace_whitespace == True
    assert eta.fix_sentence_endings == False
    assert eta.break_long_words == True
    assert eta.drop_whitespace == True
    assert eta.break_on_hyphens == True
    assert eta.tabsize == 8
    assert eta.max_lines is None
    assert eta.placeholder == ' [...]'
    assert eta.initial_indent_len == 0

# Generated at 2022-06-23 18:34:43.429648
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:54.419091
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:35:04.814254
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import unittest.mock
    wrapper = AnsiTextWrapper()
    text = ''
    output_len = len(wrapper.fill(text))
    assert len(text) == output_len, \
        (
            '"{!r}" should have been equal to "{!r}"'
            .format(output_len, len(text))
        )
    # Test with a str containing ASCII characters
    text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    output_len = len(wrapper.fill(text))
    assert len(text) == output_len, \
        (
            '"{!r}" should have been equal to "{!r}"'
            .format(output_len, len(text))
        )
    # Test with a str containing ANSI codes


# Generated at 2022-06-23 18:35:13.975513
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    w = AnsiTextWrapper(width=40, break_on_hyphens=False)

# Generated at 2022-06-23 18:35:17.466991
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:35:20.841973
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[1mfoo\x1b[0m\x1b[31mbar\x1b[0mbaz'
    assert len_without_ansi(text) == 9



# Generated at 2022-06-23 18:35:31.384329
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:35:42.229659
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:48.757718
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Checks that :obj:`flutils.txtutils.AnsiTextWrapper.fill` is working
    correctly.
    """
    msg = (
        "When called with the same width and text, "
        + ":obj:`textwrap.TextWrapper.fill` and "
        + ":obj:`~flutils.txtutils.AnsiTextWrapper.fill` should return "
        + "the same results."
    )
    width = 70

# Generated at 2022-06-23 18:35:56.801132
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:04.158308
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:14.982220
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:23.318036
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    """

# Generated at 2022-06-23 18:36:35.664520
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:40.045499
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper()
    wrapped_text = wrapper.wrap('abc def')
    assert wrapped_text == ['abc def']
    wrapped_text = wrapper.wrap('abc\ndef')
    assert wrapped_text == ['abc', 'def']



# Generated at 2022-06-23 18:36:46.610848
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi('') == 0
    assert len_without_ansi('\x1b[38;5;209m') == 0
test_len_without_ansi()



# Generated at 2022-06-23 18:36:55.928612
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from random import choice, randint
    from string import ascii_letters
    from textwrap import fill
    from ansiwrap import shorten, split_ansi_sequences

    # define some string constants
    #
    # ANSI escape sequences that set a foreground color