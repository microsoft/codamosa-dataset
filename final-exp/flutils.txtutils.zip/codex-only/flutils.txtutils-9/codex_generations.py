

# Generated at 2022-06-23 18:27:08.734115
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from unittest import TestCase
    from unittest.mock import patch


# Generated at 2022-06-23 18:27:21.072604
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Test for method flutils.txtutils.AnsiTextWrapper.fill
    """

# Generated at 2022-06-23 18:27:32.530659
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:37.097808
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    #
    #   Test the method wrap of class AnsiTextWrapper from txtutils.py
    #
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-23 18:27:48.674010
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    from flutils.txtutils import AnsiTextWrapper

    wrapper = AnsiTextWrapper()
    text = 'A\nB'
    assert wrapper.wrap(text) == ['A', 'B']

    text = 'A\n'
    assert wrapper.wrap(text) == ['A']

    text = 'A\nB\n'
    assert wrapper.wrap(text) == ['A', 'B']

    text = '\nA\nB\n'
    assert wrapper.wrap(text) == ['A', 'B']

    text = '\n\nA\n\n'
    assert wrapper.wrap(text) == ['A']

    text = '\n\n\n'
    assert wrapper.wrap(text) == ['']

    text = '\nA\n\n'
    assert wrapper

# Generated at 2022-06-23 18:27:51.351848
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
test_len_without_ansi()



# Generated at 2022-06-23 18:28:02.492886
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for method
    :obj:`~flutils.txtutils.AnsiTextWrapper.wrap()` of class
    :obj:`~flutils.txtutils.AnsiTextWrapper`."""


# Generated at 2022-06-23 18:28:05.691669
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    text = 'A\nB\nC\nD\nE\nF\n'
    wrapper = AnsiTextWrapper(width=80)
    assert wrapper.wrap(text) == ['A', 'B', 'C', 'D', 'E', 'F']

# Generated at 2022-06-23 18:28:17.524586
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils._compat import StringIO
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:28:28.432925
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    width = 40

# Generated at 2022-06-23 18:28:38.325983
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Test for method fill of class AnsiTextWrapper
    """
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:28:50.432650
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test the function len_without_ansi"""
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = 'foo\x1b[38;5;209mfoobar\x1b[0mbar'
    assert len_without_ansi(text) == 9
    text = ['foo', '\x1b[38;5;209mfoobar\x1b[0m', 'bar']
    assert len_without_ansi(text) == 9
    text = ('foo', '\x1b[38;5;209mfoobar\x1b[0m', 'bar')
    assert len_without_ansi(text)

# Generated at 2022-06-23 18:28:52.078850
# Unit test for function len_without_ansi
def test_len_without_ansi():
    _text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(_text) == 6



# Generated at 2022-06-23 18:29:03.678208
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:15.638087
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Test that initial_indent, subsequent_indent, and placeholder
    # set the initial_indent_len, subsequent_indent_len, and
    # placeholder_len properties.
    wrapper = AnsiTextWrapper()
    wrapper.initial_indent = '*'
    wrapper.subsequent_indent = '**'
    wrapper.placeholder = ' [...]'
    assert wrapper.initial_indent_len == 1
    assert wrapper.subsequent_indent_len == 2
    assert wrapper.placeholder_len == 6

    # Test with ANSI codes
    wrapper = AnsiTextWrapper()
    wrapper.initial_indent = '\x1b[34m'
    wrapper.subsequent_indent = '\x1b[38;5;208m'
    wrapper.placeholder = ' [...]'

# Generated at 2022-06-23 18:29:26.837333
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    assert AnsiTextWrapper().width == 70
    assert AnsiTextWrapper(width=80).width == 80
    assert AnsiTextWrapper(placeholder='...').placeholder == '...'
    assert AnsiTextWrapper(break_long_words=False).break_long_words is False
    assert AnsiTextWrapper(subsequent_indent='   ').subsequent_indent == '   '
    assert AnsiTextWrapper(initial_indent='   ').initial_indent == '   '
    assert AnsiTextWrapper(initial_indent='   ',
                           subsequent_indent='   ').subsequent_indent == '   '
    assert issubclass(AnsiTextWrapper, textwrap.TextWrapper)


# Generated at 2022-06-23 18:29:38.691167
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:42.565009
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    wrapped_text = wrapper.fill('Lorem ipsum dolor sit amet, consectetur adipiscing elit.')
    print(wrapped_text)
    assert wrapped_text == (
        'Lorem ipsum dolor sit amet, consectetur\n'
        'adipiscing elit.'
    )


# Generated at 2022-06-23 18:29:52.247250
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import os
    import pytest
    from flutils.txtutils import _ANSI_RE, AnsiTextWrapper
    from inspect import signature
    from io import StringIO
    from pytest import fail

    def print_lines(lines):
        print('    ', '\n    '.join(lines))


# Generated at 2022-06-23 18:30:03.100460
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():

    def set_height(height: int) -> None:
        """Set the height of the output terminal."""
        rows, columns = os.popen('stty size', 'r').read().split()
        command = f'stty rows {height}; stty size'
        result = os.popen(command, 'r').read()
        _rows, _columns = result.split()
        if int(_rows) != height:
            raise RuntimeError(f'failed to set number of lines to {height}')

    def restore_height() -> None:
        """Restore the height of the output terminal."""
        os.popen('resize', 'r')


# Generated at 2022-06-23 18:30:09.059958
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:19.947217
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:31.500496
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:41.411489
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:43.066691
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import doctest

    doctest.testmod(flutils.txtutils, verbose=True)

# Generated at 2022-06-23 18:30:55.309109
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:03.609641
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:31:13.902694
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper"""

    wrapper = AnsiTextWrapper()
    assert (wrapper.width == 70)
    assert (wrapper.initial_indent == '')
    assert (wrapper.subsequent_indent == '')
    assert (wrapper.expand_tabs == True)
    assert (wrapper.replace_whitespace == True)
    assert (wrapper.fix_sentence_endings == False)
    assert (wrapper.break_long_words == True)
    assert (wrapper.drop_whitespace == True)
    assert (wrapper.break_on_hyphens == True)
    assert (wrapper.tabsize == 8)
    assert (wrapper.max_lines == None)
    assert (wrapper.placeholder == ' [...]')


# Generated at 2022-06-23 18:31:26.301714
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    msg = \
        'Incorrect result for ' \
        'flutils.txtutils.AnsiTextWrapper.wrap():\n' \
        '- Expected result: %s\n- Actual result: %s'


# Generated at 2022-06-23 18:31:37.773435
# Unit test for function len_without_ansi

# Generated at 2022-06-23 18:31:49.252015
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:31:57.810327
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    attw = AnsiTextWrapper()
    lines = attw.wrap('Lorem ipsum dolor sit amet, consectetur adipiscing elit.')
    assert len(lines) == 1
    assert lines[0] == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    print(lines)

    parag = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    lines = []
    for line in parag.splitlines():
        lines.extend(attw.wrap(line))
    assert lines == ['Lorem ipsum dolor sit amet, consectetur adipiscing elit.']
    print(lines)


# Generated at 2022-06-23 18:32:06.887956
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Unit test for method fill of class AnsiTextWrapper.

    """

# Generated at 2022-06-23 18:32:18.302881
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class :obj:`AnsiTextWrapper`."""

    wrapper = AnsiTextWrapper(width=40)


# Generated at 2022-06-23 18:32:27.754576
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """
    Unit test for method wrap of class AnsiTextWrapper
    """
    # test when the length of initial_indent exceeds the width
    wrapper = AnsiTextWrapper(width=12, initial_indent='initial_indent')
    with pytest.raises(ValueError):
        wrapper.wrap('There is no attempt to wrap long lines.')

    # test when the length of subsequent_indent exceeds the width
    wrapper = AnsiTextWrapper(width=12, subsequent_indent='Subsequent_indent')
    with pytest.raises(ValueError):
        wrapper.wrap('There is no attempt to wrap long lines.')

    # test when the length of placeholder exceeds the width
    wrapper = AnsiTextWrapper(width=12, placeholder='placeholder')

# Generated at 2022-06-23 18:32:39.008438
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:50.665005
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:57.992678
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12
    text = ['\x1b[38;5;209mfoobar\x1b[0m', 'foobar', '\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(text) == 18

# Generated at 2022-06-23 18:33:10.299860
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # pragma: no cover
    """Unit test for constructor of class AnsiTextWrapper."""
    output = AnsiTextWrapper(width=40)
    assert output.width == 40
    assert output.initial_indent == ''
    assert output.subsequent_indent == ''
    assert output.expand_tabs is True
    assert output.replace_whitespace is True
    assert output.fix_sentence_endings is False
    assert output.break_long_words is True
    assert output.drop_whitespace is True
    assert output.break_on_hyphens is True
    assert output.tabsize == 8
    assert output.max_lines is None
    assert output.placeholder == ' [...]'
    print('test_AnsiTextWrapper:  Done.')


# Generated at 2022-06-23 18:33:16.219098
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m',)) == 6
    assert len_without_ansi(('foo\x1b[38;5;209m', '\x1b[0mbar')) == 6


# Generated at 2022-06-23 18:33:26.388512
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:38.994394
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pytest import raises
    from typing import Any

    with raises(TypeError):
        # noinspection PyTypeChecker
        len_without_ansi(123)  # type: ignore[arg-type]

    # noinspection PyTypeChecker
    assert 0 == len_without_ansi('')  # type: ignore[arg-type]
    assert 0 == len_without_ansi([])  # type: ignore[arg-type]
    assert 0 == len_without_ansi((''))  # type: ignore[arg-type]
    assert 0 == len_without_ansi(['', ''])  # type: ignore[arg-type]
    assert 0 == len_without_ansi(('', ''))  # type: ignore[arg-type]


# Generated at 2022-06-23 18:33:41.733889
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    expected = 6
    out = len_without_ansi(text)
    assert out == expected



# Generated at 2022-06-23 18:33:50.978140
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:56.907229
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:08.557137
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""

    # Uncomment the next line of code to view the result of running the test.
    # from flutils.config import FLUTILS_TXTUTILS_TEST_DIR
    # import os
    # os.chdir(FLUTILS_TXTUTILS_TEST_DIR)
    # import sys
    # sys.argv.append("/d")
    # <...>
    # sys.exit(1)
    # <...>

    import doctest
    # Uncomment the next line of code to view the result of running the test.
    # doctest.testmod(verbose=True)
    # <...>
    # sys.exit(1)
    # <...>
    doctest.testmod()

# Generated at 2022-06-23 18:34:17.531217
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert not wrapper.expand_tabs
    assert not wrapper.replace_whitespace
    assert wrapper.break_long_words
    assert wrapper.drop_whitespace
    assert wrapper.break_on_hyphens
    assert wrapper.fix_sentence_endings
    assert wrapper.max_lines is None
    assert wrapper.placeholder == ' [...]'
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.tabsize == 8

# Generated at 2022-06-23 18:34:26.097138
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Test for invalid width argument
    wrapper = AnsiTextWrapper()
    wrapper.width = 0

# Generated at 2022-06-23 18:34:35.207213
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import textwrap


# Generated at 2022-06-23 18:34:44.127221
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:34:54.827679
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Tests the method AnsiTextWrapper.fill()
    """

    import flutils.txtutils
    import pytest


# Generated at 2022-06-23 18:34:56.550598
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Stub for method wrap of class AnsiTextWrapper
    pass


# Generated at 2022-06-23 18:35:06.446045
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Instantiate AnsiTextWrapper
    try:
        wrapper = AnsiTextWrapper()
    except Exception:
        # AnsiTextWrapper raised an exception for a default instantiation.
        # This should never happen. Raise an exception.
        raise Exception('Failed to instantiate default AnsiTextWrapper!')

    # Test string to use
    # NOTE: \x1b is the octal escape sequence for an ESC (\033) character.
    #       [0m is the ANSI code for resetting all attributes.
    #       [1m is the ANSI code for setting bold.
    #       [4m is the ANSI code for setting underline.
    #       [31m is the ANSI code for setting foreground color red.
    #       [38;2;55;172;230m is the ANSI code for setting the foreground

# Generated at 2022-06-23 18:35:15.054427
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:27.114223
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # noqa: D103
    import unittest.mock as mock

    # Test for method wrap of class AnsiTextWrapper
    # Create an instance of AnsiTextWrapper class
    wrapper = AnsiTextWrapper()

    # Create a 'wrapped' method
    wrapped = mock.Mock(return_value=['foo bar ', 'baz qux'])
    # Patch the wrap method and set the 'wrapped' method as its return value
    with mock.patch.object(wrapper, '_wrap', wrapped):
        with mock.patch.object(wrapper, '_dedent', lambda x: x):
            # The method under test
            assert wrapper.wrap('foo bar baz qux') == ['foo bar ', 'baz qux']



# Generated at 2022-06-23 18:35:39.218285
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit Test for :class:`AnsiTextWrapper`."""
    wrapper = AnsiTextWrapper(width=40)
    wrapped_text = wrapper.fill(MY_TEXT)

# Generated at 2022-06-23 18:35:48.678357
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.placeholder == ' [...]'

    assert wrapper.max_lines is None
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8


# Generated at 2022-06-23 18:35:53.692257
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:02.350164
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import unittest
    class Test_AnsiTextWrapper_fill(unittest.TestCase):
        def test_fill(self):
            from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:36:04.438931
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:36:11.964827
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    # Test AnsiTextWrapper.fill with a very long word, to try to cause a
    # bug. Such an error caused the flutils unit tests to fail.
    # https://github.com/kynan/flutils/issues/3
    text = (
        'aaabbbcccdddeee'
        'fffaabbcccddde'
        'eeefffaabbcccd'
        'ddeeefffaabbcccdddeeefff'
    )
    wrapper = AnsiTextWrapper(width=40)
    result = wrapper.fill(text)

# Generated at 2022-06-23 18:36:21.195088
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:32.397225
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi."""
    import pytest
    from time import time
    from .colors import str_to_fg256, str_to_bg256, str_to_ansi, AnsiStyle
    from .colors import str_to_fgfgpal, str_to_bgfgpal, str_to_style

    SECS = 25
    # These are only the colors that have the same length
    # as the color name string when converted to the base fg256,
    # bg256, fgfgpal, bgfgpal and ansi colors.  There are a
    # couple of exceptions.  These are handled below.
    COLORS = list('krgybmcpw')
    ANSISTYLE = AnsiStyle('bold', 'underline', 'blink', 'inverse')
   

# Generated at 2022-06-23 18:36:43.217334
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=80, initial_indent='', subsequent_indent='', expand_tabs=True, replace_whitespace=True, fix_sentence_endings=False, break_long_words=True, drop_whitespace=True, break_on_hyphens=True, tabsize=8, max_lines=None, placeholder=' [...]')
    assert wrapper.width == 80
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True

# Generated at 2022-06-23 18:36:54.748059
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for the len_without_ansi function"""
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar'
    assert len_without_ansi(text) == 0
    text = 'foobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoo\x1b[0m'
    assert len_without_ansi(text) == 3
    text = '\x1b[38;5;209m\x1b[0m'
    assert len_

# Generated at 2022-06-23 18:37:04.914522
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ret_val = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert ret_val == 6
    ret_val = len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m'])
    assert ret_val == 6
    ret_val = len_without_ansi(['\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m'])
    assert ret_val == 6
    ret_val = len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[0m'])
    assert ret_val == 6
    ret_val = len_