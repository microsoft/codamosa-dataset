

# Generated at 2022-06-23 18:27:11.972404
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    method_name = sys._getframe().f_code.co_name
    class_name = 'AnsiTextWrapper'
    print_debug_info(method_name, class_name, '', sep='\n')


# Generated at 2022-06-23 18:27:23.674850
# Unit test for function len_without_ansi

# Generated at 2022-06-23 18:27:33.994384
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # fmt: off
    # Tests for strings
    s1 = 'foo\x1b[38;5;209mbar\x1b[0mbaz'
    assert len_without_ansi(s1) == 6
    s2 = '\x1b[38;5;209mfoobar\x1b[0mbaz'
    assert len_without_ansi(s2) == 6
    s3 = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(s3) == 6

    # Tests for lists
    s4 = 'foo\x1b[38;5;209mbar\x1b[0mbaz'
    assert len_without_ansi([s4]) == 6

# Generated at 2022-06-23 18:27:44.458245
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:27:55.818361
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:07.433983
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test that method wrap of class AnsiTextWrapper wraps the given text
    correctly.
    """

# Generated at 2022-06-23 18:28:15.929132
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(text) == 6

    text = (
        '\x1b[38;5;209m',
        '\x1b[38;5;208m',
        'foobar',
        '\x1b[0m',
        '\x1b[0m',
    )
    assert len_without_ansi(text) == 6


# Generated at 2022-06-23 18:28:27.172482
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.max_lines is None
    assert wrapper.placeholder == ' [...]'
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.drop_whitespace is True
    assert wrapper.tabsize == 8


# Generated at 2022-06-23 18:28:34.978230
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Single string
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(_text) == 6

    # List of strings
    _text = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert len_without_ansi(_text) == 6

    # Tuple of strings
    _text = ('\x1b[38;5;209mfoobar\x1b[0m', )
    assert len_without_ansi(_text) == 6

    return



# Generated at 2022-06-23 18:28:44.154247
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Simplest case
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent == ''
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder == ''
    assert wrapper.placeholder_len == 0
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None


# Generated at 2022-06-23 18:28:56.522099
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    print("\nRunning test_AnsiTextWrapper_wrap()...")
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:28:59.915722
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    result = len_without_ansi(text)
    assert result == 6



# Generated at 2022-06-23 18:29:04.607595
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Function test for `len_without_ansi`."""
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6

# Generated at 2022-06-23 18:29:16.808891
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper

# Generated at 2022-06-23 18:29:17.510248
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    pass

# Generated at 2022-06-23 18:29:28.474649
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:37.760004
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == len(text) - 12
    assert len_without_ansi(text + text) == len(text + text) - 24
    assert len_without_ansi([text]) == len(text) - 12
    assert len_without_ansi((text, text)) == len(text) - 12
    assert len_without_ansi([text, text]) == len(text) - 12
# END unit test for function len_without_ansi


# Generated at 2022-06-23 18:29:47.571226
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines == None
    assert wrapper.placeholder == ' [...]'
    return True


# Generated at 2022-06-23 18:29:48.642454
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    pass



# Generated at 2022-06-23 18:30:00.560527
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    wrapper = AnsiTextWrapper(width=40,
                              initial_indent=' ',
                              subsequent_indent='    ',
                              max_lines=3,
                              placeholder='...')
    assert wrapper.placeholder == '...'
    assert wrapper.width == 40
    assert wrapper.placeholder_len == 3
    assert wrapper.initial_indent == ' '
    assert wrapper.subsequent_indent == '    '
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_

# Generated at 2022-06-23 18:30:03.689760
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """

        The test is based on the module doctest of Python.

        The test will print green OK in case of success and print FAIL in
        case of failure.

    """
    import test.support
    import doctest
    doctest.testmod(test.support, optionflags=doctest.ELLIPSIS)
# Class Divider

# Generated at 2022-06-23 18:30:09.334001
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)


# Generated at 2022-06-23 18:30:20.065555
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:25.282877
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('foo\x1b[foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-23 18:30:35.576361
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for the AnsiTextWrapper class."""

# Generated at 2022-06-23 18:30:44.627920
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from . import assert_eq
    from . import assert_ne
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert_eq(out, 6)
    assert_eq(len_without_ansi([text]), 6)
    assert_ne(len(text), len_without_ansi(text))
    assert_eq(len_without_ansi('foobar'), 6)
    assert_eq(len_without_ansi(''), 0)
    assert_eq(len_without_ansi(('foobar', )), 6)
    assert_eq(len_without_ansi(('baz', 'foo', 'bar')), 6)

# Generated at 2022-06-23 18:30:50.145410
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    assert len_without_ansi('foo') == 3
    assert len_without_ansi(['foo']) == 3
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-23 18:31:00.411432
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit test for method fill of class AnsiTextWrapper."""
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:31:11.595481
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test :class:`flutils.txtutils.AnsiTextWrapper`."""
    _ANSI_RE.sub('', '')
    result = AnsiTextWrapper(
        width=40,
        initial_indent='',
        subsequent_indent='',
        expand_tabs=True,
        replace_whitespace=True,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=8,
        max_lines=None,
        placeholder=' [...]'
    )
    assert isinstance(result, AnsiTextWrapper)
    assert isinstance(result.width, int)
    assert isinstance(result.initial_indent, str)

# Generated at 2022-06-23 18:31:23.784006
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:31.976974
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:44.077218
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Test for initial_indent parameter
    wrapper = AnsiTextWrapper()
    assert wrapper.initial_indent_len == 0

    wrapper = AnsiTextWrapper(initial_indent=' ')
    assert wrapper.initial_indent == ' '
    assert wrapper.initial_indent_len == 1

    wrapper = AnsiTextWrapper(initial_indent='  ')
    assert wrapper.initial_indent == '  '
    assert wrapper.initial_indent_len == 2

    wrapper = AnsiTextWrapper(initial_indent='\t')
    assert wrapper.initial_indent == '\t'
    assert wrapper.initial_indent_len == 8

    wrapper = AnsiTextWrapper(initial_indent='  \t  ')

# Generated at 2022-06-23 18:31:49.328981
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:58.404501
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    from io import StringIO
    from textwrap import TextWrapper
    from textwrap import wrap
    from textwrap import fill
    from textwrap import dedent

    wrapper = TextWrapper(
        width=40,
        initial_indent='  ',
        subsequent_indent='    ',
        replace_whitespace=False
    )

    ansi_wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='  ',
        subsequent_indent='    ',
        replace_whitespace=False
    )

    # -------------------------------------------------------------------------
    # Test wrap
    # -------------------------------------------------------------------------
    # simple_text = (
    #     'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras '
    #     'fermentum maximus auctor. Cras a var

# Generated at 2022-06-23 18:32:01.131866
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:32:11.705144
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper
    from functools import partial
    from copy import copy
    import pytest
    # Test with a text shorter than the specified width.
    wrapper = AnsiTextWrapper()
    text = 'Lorem ipsum dolor sit amet.'
    expected = text
    assert wrapper.wrap(text) == [expected]
    # Test with a text longer than the specified width but shorter
    # than the specified initial_indent.
    wrapper.width = 40
    text = _LOREM_IPSUM
    expected = text
    assert wrapper.wrap(text) == [expected]
    # Test with a text longer than the specified width but shorter
    # than the specified initial_indent, when the specified
    # initial_indent is not an empty string.
    # Test with an empty initial

# Generated at 2022-06-23 18:32:17.450197
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text1 = '\x1b[38;5;209mfoobar\x1b[0m'
    text2 = '\x1b[39mfoobar\x1b[0m'
    seq1 = [text1, text2]
    assert len_without_ansi(text1) == 6
    assert len_without_ansi(seq1) == 12
    return True



# Generated at 2022-06-23 18:32:27.306749
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    def _inner(**kwargs):
        # pylint: disable=unused-argument
        wrapper = AnsiTextWrapper(
            width=40,
            initial_indent='',
            subsequent_indent='',
            expand_tabs=True,
            replace_whitespace=True,
            fix_sentence_endings=False,
            break_long_words=True,
            drop_whitespace=True,
            break_on_hyphens=True,
            tabsize=8,
            placeholder=' [...]',
        )


# Generated at 2022-06-23 18:32:38.657073
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:50.622972
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:00.882024
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:13.648141
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:24.630542
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import string
    from random import choices

    from flutils.txtutils import AnsiTextWrapper

    def gen_width_list():
        for n in range(1, 10):
            yield from range(n, 30, n)
        yield from range(30, 100)
        yield from range(100, 1000, 100)
        yield from range(1000, 10000, 1000)
        yield from range(10000, 100000, 10000)
        yield from range(100000, 1000000, 100000)


# Generated at 2022-06-23 18:33:37.146497
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import sys
    import textwrap
    import unittest


# Generated at 2022-06-23 18:33:47.560069
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Begin test code
    # create an instance of AnsiTextWrapper
    wrapper = AnsiTextWrapper(width=40)

    # create the text to be wrapped

# Generated at 2022-06-23 18:33:49.926630
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper
    import doctest
    doctest.run_docstring_examples(AnsiTextWrapper.fill, globals())

# Generated at 2022-06-23 18:33:57.371280
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    # 1) Test that the wrap method works like TextWrapper.wrap when
    #    there are no ANSI codes present.
    # Initialize AnsiTextWrapper()
    aw = AnsiTextWrapper(width=40)
    # Initialize TextWrapper()
    tw = TextWrapper(width=40)
    # Get the list of lines wrapped by AnsiTextWrapper.wrap()

# Generated at 2022-06-23 18:34:09.220807
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:17.906298
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from textwrap import TextWrapper

# Generated at 2022-06-23 18:34:28.967868
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:34.964577
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ('\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;208mbar\x1b[0m')
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:34:39.475349
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:50.492807
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import collections
    import textwrap
    from textwrap import TextWrapper as _TextWrapper

    class TC:
        """Define test cases."""

        input: str
        expected: str
        width: int
        max_lines: Optional[int]
        initial_indent: str
        subsequent_indent: str
        placeholder: str

        def __init__(self, input: str, expected: str, width: int,
                     max_lines: Optional[int] = None,
                     initial_indent: str = '',
                     subsequent_indent: str = '',
                     placeholder: str = ' [...]') -> None:
            self.input = input
            self.expected = expected
            self.width = width
            self.max_lines = max_lines
            self.initial_indent = initial_indent

# Generated at 2022-06-23 18:34:54.805740
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi([]) == 0
# end function test_len_without_ansi



# Generated at 2022-06-23 18:35:05.077505
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    r"""The unit test for :obj:`AnsiTextWrapper.fill`.

    Run as:

        python3 -m doctest -v flutils/txtutils.py
    """

# Generated at 2022-06-23 18:35:14.197645
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from unittest import TestCase
    from unittest.mock import patch
    from unittest.mock import MagicMock
    import re
    import textwrap
    import flutils.txtutils

    tc = TestCase()

    # Test the constructor called with no arguments
    wrapper = flutils.txtutils.AnsiTextWrapper()
    tc.assertEqual(wrapper.width, 70)
    tc.assertEqual(wrapper.initial_indent, '')
    tc.assertEqual(wrapper.subsequent_indent, '')
    tc.assertEqual(wrapper.placeholder, ' [...]')
    tc.assertEqual(wrapper.expand_tabs, True)
    tc.assertEqual(wrapper.replace_whitespace, True)

# Generated at 2022-06-23 18:35:18.934113
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    assert AnsiTextWrapper(
        width=40,
        initial_indent='\\x1b[31m\\x1b[1m\\x1b[4m',
        subsequent_indent='\\x1b[0m',
    )


# Generated at 2022-06-23 18:35:30.275801
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    assert isinstance(wrapper, AnsiTextWrapper)

    wrapper = AnsiTextWrapper(width=0)
    assert isinstance(wrapper, AnsiTextWrapper)

    wrapper = AnsiTextWrapper(width=0,
                              initial_indent='',
                              subsequent_indent='',
                              expand_tabs='',
                              replace_whitespace=True,
                              fix_sentence_endings=False,
                              break_long_words=True,
                              drop_whitespace=True,
                              break_on_hyphens=True,
                              tabsize=8)
    assert isinstance(wrapper, AnsiTextWrapper)


# Generated at 2022-06-23 18:35:41.645085
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test the constructor of the class ``flutils.txtutils.AnsiTextWrapper``
    """
    # Call the constructor with no paramters.
    ansi_text_wrapper = AnsiTextWrapper()
    # Confirm that no errors were generated...
    assert ansi_text_wrapper is not None
    assert type(ansi_text_wrapper) is AnsiTextWrapper

    # Call the constructor with NO parameters, and a tuple of values
    # for each parameter.

# Generated at 2022-06-23 18:35:53.087748
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function :func:`~flutils.txtutils.len_without_ansi`."""
    text = '\x1b[38;5;209mfoobar'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text[:-1]) == 6
    text = '\x1b80mfoobar'
    assert len_without_ansi(text) == 7
    assert len_without_ansi(text[1:]) == 7
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 7
    text = '\x1b[38;5;209mf\x1b[0mobar'
    assert len_without_ansi(text) == 4

# Generated at 2022-06-23 18:36:01.939991
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for :obj:`AnsiTextWrapper`."""
    wrapper = AnsiTextWrapper(width=40)
    assert (wrapper.width == 40 and
            wrapper.initial_indent == '' and
            wrapper.subsequent_indent == '' and
            wrapper.expand_tabs and
            wrapper.replace_whitespace and
            not wrapper.fix_sentence_endings and
            wrapper.break_long_words and
            wrapper.drop_whitespace and
            wrapper.break_on_hyphens and
            wrapper.tabsize == 8 and
            wrapper.max_lines is None and
            wrapper.placeholder == ' [...]')


# Generated at 2022-06-23 18:36:13.927923
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():

    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:36:19.237735
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Testing the ``len_without_ansi`` function."""
    from flutils.testing import unittest

    class Test(unittest.TestCase):
        def test_len_without_ansi(self):
            text = '\x1b[38;5;209mfoobar\x1b[0m'
            self.assertEqual(len_without_ansi(text), 6)

    return Test


# Generated at 2022-06-23 18:36:23.079977
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function ``len_without_ansi``"""
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
test_len_without_ansi()  # noqa: F841



# Generated at 2022-06-23 18:36:23.664252
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    pass



# Generated at 2022-06-23 18:36:36.077217
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:45.037446
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from pytest import raises
    with raises(ValueError):
        AnsiTextWrapper(width=0)
        AnsiTextWrapper(width=1, placeholder=' [...]x')
        AnsiTextWrapper(width=2, placeholder=' [...]xx')
        AnsiTextWrapper(width=2, placeholder=' [...')
    a = AnsiTextWrapper(width=1)
    assert a.width == 1
    a = AnsiTextWrapper(width=1, initial_indent='1')
    assert a.width == 1
    a = AnsiTextWrapper(width=1, subsequent_indent='1')
    assert a.width == 1
    a = AnsiTextWrapper(width=2, initial_indent='1\x1b[31m1')
    assert a.width == 2

# Generated at 2022-06-23 18:36:48.188485
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.tests.demo_txtutils import test_AnsiTextWrapper_wrap
    test_AnsiTextWrapper_wrap()

# Generated at 2022-06-23 18:36:49.904997
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 18:37:01.906238
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """flutils.txtutils.len_without_ansi: Test function."""
    testlist = [
        '',
        'o',
        'foo',
        'foobar',
        'foobarfoobar',
        '',
        'o',
        'foo',
        'foobar',
        'foobarfoobar',
    ]
    lenlist = [0, 1, 3, 6, 12, 0, 1, 3, 6, 12]
    for test, _len in zip(testlist, lenlist):
        assert len_without_ansi(test) == _len
        assert len_without_ansi([test]) == _len
    # ANSI
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text)