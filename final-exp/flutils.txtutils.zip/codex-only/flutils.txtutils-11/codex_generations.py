

# Generated at 2022-06-23 18:27:11.225896
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:27:23.510968
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class :obj:`~flutils.txtutils.AnsiTextWrapper`."""

# Generated at 2022-06-23 18:27:27.601665
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # noqa: D103
    with pytest.raises(ValueError) as excinfo:
        AnsiTextWrapper(width=10, placeholder='xyz' * 100)
    assert str(excinfo.value) == 'placeholder too large for max width'



# Generated at 2022-06-23 18:27:36.902580
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:44.617902
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines == None
    assert wrapper.placeholder == ' [...]'


# Generated at 2022-06-23 18:27:55.986288
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:01.495735
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:28:08.349975
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    assert AnsiTextWrapper().width == 70
    assert AnsiTextWrapper().initial_indent == ''
    assert AnsiTextWrapper().subsequent_indent == ''
    assert AnsiTextWrapper().expand_tabs == True
    assert AnsiTextWrapper().replace_whitespace == True
    assert AnsiTextWrapper().fix_sentence_endings == False
    assert AnsiTextWrapper().break_long_words == True
    assert AnsiTextWrapper().drop_whitespace == True
    assert AnsiTextWrapper().break_on_hyphens == True
    assert AnsiTextWrapper().tabsize == 8
    assert AnsiTextWrapper().max_lines == None
    assert AnsiTextWrapper().placeholder == ' [...]'

    assert AnsiTextWrapper(width=80).width == 80

# Generated at 2022-06-23 18:28:18.691958
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:29.579605
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit tests for method wrap of class AnsiTextWrapper."""

# Generated at 2022-06-23 18:28:39.326739
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    def test(text: str, width: int, max_lines: Optional[int],
             placeholder: str = ' [...]', subsequent_indent_len: int = 0):
        wrapper = AnsiTextWrapper(
            width=width,
            max_lines=max_lines,
            placeholder=placeholder
        )
        wrapped_text = wrapper.wrap(text)
        return wrapped_text, subsequent_indent_len

    # No text
    assert test('', 0, None) == ([], 0)
    assert test('', 40, None) == ([], 0)

    # No wrapping
    assert test('Lorem ipsum dolor sit amet', 40, None) == (
        ['Lorem ipsum dolor sit amet'], 0
    )

# Generated at 2022-06-23 18:28:46.121660
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = r'\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text, text]) == 12
    assert len_without_ansi([text]) == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(['foo', 'bar']) == len('foobar')
    assert len_without_ansi(['foo', '', 'bar']) == len('foobar')
    assert len_without_ansi('foobar') == len('foobar')



# Generated at 2022-06-23 18:28:58.132040
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Coverage: 100%"""

# Generated at 2022-06-23 18:29:04.842765
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # noqa: D103

    def _test(
            txt: str,
            ansi_txt_wrapper: AnsiTextWrapper,
            width: int = 100,
            initial_indent: str = '',
            subsequent_indent: str = '',
            wrap_ansi: bool = True,
    ) -> None:
        # If `width` is less than `10`, set it to `100`.
        if width < 10:
            width = 100
        # If `width` is greater than `500`, set it to `500`.
        if width > 500:
            width = 500
        # If `initial_indent` is not a :obj:`str`, set it to the empty
        # :obj:`str`.
        if not isinstance(initial_indent, str):
            initial_indent = ''


# Generated at 2022-06-23 18:29:16.984511
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """
    Test flutils.txtutils.len_without_ansi.

    *New in version 0.6.2.dev0*
    """
    from .testutils import test_function_docstrings
    test_function_docstrings(len_without_ansi)

    import unittest

    class LenWithoutAnsiTestCase(unittest.TestCase):
        """
        Test flutils.txtutils.len_without_ansi.
        """

        def test_single_ansi_string(self):
            text = '\x1b[38;5;209mfoobar\x1b[0m'
            self.assertEqual(len_without_ansi(text), 6)


# Generated at 2022-06-23 18:29:27.759112
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    wrapper = AnsiTextWrapper(width=40)
    # wrapper.placeholder = ' .....'


# Generated at 2022-06-23 18:29:39.290682
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():

    """Unit test for method fill of class AnsiTextWrapper"""

    error = 'AnsiTextWrapper.fill() unit test produced results that did ' \
            'not match expected results'

# Generated at 2022-06-23 18:29:49.714674
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    from flutils.txtutils import AnsiTextWrapper

    wrapper = AnsiTextWrapper(width=40)


# Generated at 2022-06-23 18:29:53.615695
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    text = 'ALONG THE LONG ROAD OF LIFE'
    expected = 'ALONG THE LONG ROAD OF\nLIFE'
    result = AnsiTextWrapper(width=20).fill(text)
    assert result == expected

# Generated at 2022-06-23 18:29:56.282616
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import doctest
    doctest.testmod(raise_on_error=True)  # pragma: no cover


# Generated at 2022-06-23 18:30:05.641766
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:16.099688
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""

    wrapper = AnsiTextWrapper(width=40)


# Generated at 2022-06-23 18:30:23.852124
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:27.631115
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    try:
        AnsiTextWrapper(placeholder='')
    except TypeError:
        pass
    else:
        raise Exception('Empty placeholder not caught.')
    try:
        w = AnsiTextWrapper(placeholder='x')
        w.placeholder = ''
    except TypeError:
        pass
    else:
        raise Exception('Empty placeholder not caught.')



# Generated at 2022-06-23 18:30:37.664777
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:46.592141
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # pragma: nocover
    import doctest
    doctest.testmod(AnsiTextWrapper)


__all__ = [
    'AnsiTextWrapper', 'len_without_ansi', 'strip_ansi', 'ansi_as_len',
    'AnsiDict', 'AnsiList', 'test_AnsiTextWrapper_fill', 'AnsiSet', 'AnsiTuple'
]

if __name__ == '__main__':
    test_AnsiTextWrapper_fill()  # pragma: nocover

# Generated at 2022-06-23 18:30:47.967843
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(text) == 20
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:30:58.774294
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:02.339712
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:31:13.217289
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import unittest
    from collections import namedtuple
    from flutils.txtutils import AnsiTextWrapper
    from textwrap import TextWrapper

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.Test = namedtuple('Test', 'name input_ str_expected')

# Generated at 2022-06-23 18:31:25.628514
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest
    text = 'this is a test str'
    text_list = (
        'test1',
        'test2',
    )
    ansi_text = '\x1b[38;5;209mfoobar\x1b[0m'
    ansi_text_list = (
        'test1',
        '\x1b[38;5;209mfoobar\x1b[0m',
        'test2',
    )
    assert len_without_ansi(text) == 17
    assert len_without_ansi(text_list) == 8
    assert len_without_ansi(ansi_text) == 6
    assert len_without_ansi(ansi_text_list) == 8
    with pytest.raises(TypeError):
        len_without_

# Generated at 2022-06-23 18:31:36.418168
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:48.372687
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """ Tests AnsiTextWrapper Class.
    """
    # fmt: off

# Generated at 2022-06-23 18:31:57.746494
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test the constructor of :obj:`~flutils.txtutils.AnsiTextWrapper`."""
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines == None
    assert wrapper.placeholder == ' [...]'

    # The following tests "max_lines" and "placeholder" in the
    # constructor. If either of these raises

# Generated at 2022-06-23 18:32:06.859942
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    t = AnsiTextWrapper()
    assert isinstance(t, AnsiTextWrapper)
    assert t.width == 70
    assert t.initial_indent == ''
    assert t.subsequent_indent == ''
    assert t.expand_tabs == True
    assert t.replace_whitespace == True
    assert t.fix_sentence_endings == False
    assert t.break_long_words == True
    assert t.drop_whitespace == True
    assert t.break_on_hyphens == True
    assert t.tabsize == 8
    assert t.max_lines == None
    assert t.placeholder == ' [...]'

# Generated at 2022-06-23 18:32:18.263014
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:21.057634
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:32:33.299943
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:42.952308
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    from unittest.mock import patch
    from unittest.mock import call

    from textwrap import TextWrapper


# Generated at 2022-06-23 18:32:46.111199
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:32:54.434858
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pytest import raises
    from errno import ENOTDIR

    with raises(TypeError) as err:
        len_without_ansi(None)  # type: ignore[misc]
    assert str(err.value) == 'Expected a str, list, or tuple.'

    assert len_without_ansi('') == 0
    assert len_without_ansi('  ') == 2
    assert len_without_ansi('str\xff') == 4

    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(('\x1b[38;5;209m', 'foobar', '\x1b[0m')) == 6

# Generated at 2022-06-23 18:33:04.506312
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='\x1b[1m> \x1b[0m',
        subsequent_indent='  '
    )
    assert wrapper.initial_indent == '\x1b[1m> \x1b[0m'
    assert wrapper.subsequent_indent == '  '
    assert wrapper.placeholder == ' [...]'
    assert wrapper.width == 40
    assert wrapper.expand_tabs
    assert wrapper.replace_whitespace
    assert not wrapper.fix_sentence_endings
    assert wrapper.break_long_words
    assert wrapper.drop_whitespace
    assert wrapper.break_on_hyphens
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None
    assert wrapper.initial

# Generated at 2022-06-23 18:33:09.818928
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foo', 'bar', 'baz']) == 9
    return


# Generated at 2022-06-23 18:33:18.897740
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:21.716187
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:33:27.475888
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    w = AnsiTextWrapper(width=42, break_long_words=True,
                        drop_whitespace=True, initial_indent='',
                        subsequent_indent='  ', placeholder='...',
                        fix_sentence_endings=False, break_on_hyphens=True,
                        tabsize=8, max_lines=2, expand_tabs=True,
                        replace_whitespace=True)
    assert w.width == 42
    assert w.break_long_words is True
    assert w.drop_whitespace is True
    assert w.initial_indent == ''
    assert w.initial_indent_len == 0
    assert w.subsequent_indent == '  '
    assert w.subsequent_indent_len

# Generated at 2022-06-23 18:33:39.918542
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:49.883909
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foobar', '\x1b[38;5;209mfoobar\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar', 'foobar\x1b[0m']) == 6
    assert len_without_ansi(
        [
            '\x1b[38;5;209mfoobar',
            '',
            '\x1b[38;5;209mf',
            'oobar\x1b[0m'
        ]
    ) == 6

# Generated at 2022-06-23 18:33:52.072566
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:33:58.430501
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for ``AnsiTextWrapper.wrap``"""

# Generated at 2022-06-23 18:34:09.933688
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:18.312678
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Test the constructor for exceptions
    for test in (
            {'width': 'invalid', 'placeholder': 'placeholder'},
            {'width': -1, 'placeholder': 'placeholder'},
            {'width': 0, 'placeholder': 'placeholder'},
            {'width': 40, 'placeholder': 'placeholder too long'}
    ):
        with pytest.raises(ValueError):
            AnsiTextWrapper(**test)

    # Test the class

# Generated at 2022-06-23 18:34:29.637416
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:33.569216
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-23 18:34:44.734872
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:55.151028
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:05.396999
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    # Create a string of 4,000 ANSI characters
    ansi_str = ''.join(_ANSI_TEST_SEQ)

    # Wrap the string of ANSI characters into 10 lines
    # of 400 characters each (not including the ANSI characters)
    wrapper = AnsiTextWrapper(width=400, replace_whitespace=False)
    ansi_list = wrapper.wrap(ansi_str)

    # Verify that the output is correct
    assert isinstance(ansi_list, list)
    assert len(ansi_list) == 10
    for line in ansi_list:
        assert isinstance(line, str)
        assert len_without_ansi(line) <= 400
        m = _ANSI_RE.search(line)
        assert m is not None

# Generated at 2022-06-23 18:35:14.412346
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    print(f'\nUnit test for method wrap of class AnsiTextWrapper.\n')
    from flutils.txtutils import AnsiTextWrapper
    import textwrap
    from pprint import pprint

    wrapper = AnsiTextWrapper(width=70)


# Generated at 2022-06-23 18:35:27.485361
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:39.673028
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    wrapper1 = AnsiTextWrapper(width=40, initial_indent='    ')
    wrapper2 = AnsiTextWrapper(width=40, subsequent_indent='    ')
    print('*' * 40)

# Generated at 2022-06-23 18:35:45.798443
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """`Tests for constructor of class AnsiTextWrapper`"""
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    wrapper = AnsiTextWrapper(width=40, subsequent_indent='   ')
    assert wrapper.width == 40
    assert wrapper.subsequent_indent == '   '
    

# Generated at 2022-06-23 18:35:56.066801
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:00.743379
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    text = 'Lorem ipsum dolor sit amet'
    wrapper = AnsiTextWrapper()
    wrapped_text = wrapper.fill(text)
    print(wrapped_text)

    assert wrapped_text == text



# Generated at 2022-06-23 18:36:12.385490
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:21.547249
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from io import StringIO
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:36:32.895498
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    empty_str = ''
    text = "Test text"
    text_ansi = '\x1b[1mTest text\x1b[0m'
    text_ansi2 = '\x1b[2m Test text\x1b[0m'
    text_ansi3 = '\x1b[3mTest text\x1b[0m'
    text_ansi4 = '\x1b[4mTest text\x1b[0m'
    text_ansi5 = '\x1b[5mTest text\x1b[0m'
    text_ansi11 = '\x1b[11mTest text\x1b[0m'
    text_ansi12 = '\x1b[12mTest text\x1b[0m'
    text_

# Generated at 2022-06-23 18:36:43.545475
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:52.436425
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from pytest import raises
    from flutils.txtutils import len_without_ansi

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = (
        '\x1b[38;5;209mfoo\x1b[0m',
        '\x1b[38;5;214mbar\x1b[0m',
    )
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:36:59.267381
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Note: textwrap.TextWrapper.wrap breaks on ANSI codes.
    # Specifically, textwrap.TextWrapper.wrap is called by
    # textwrap.TextWrapper.fill. So, AnsiTextWrapper.wrap is tested by
    # testing AnsiTextWrapper.fill.
    # See the test_AnsiTextWrapper_fill test for more details.
    return True



# Generated at 2022-06-23 18:37:06.627486
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # pylint: disable=C0103
    def assert_str(x, *args, **kwargs):
        """Assert x is an instance of str."""
        assert isinstance(x, str), (x, args, kwargs)  # type: ignore

    def assert_list(x, *args, **kwargs):
        """Assert x is an instance of List[str]."""
        assert isinstance(x, list), (x, args, kwargs)  # type: ignore

    def assert_int(x, *args, **kwargs):
        """Assert x is an instance of int."""
        assert isinstance(x, int), (x, args, kwargs)  # type: ignore
