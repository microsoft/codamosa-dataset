

# Generated at 2022-06-23 18:27:04.390935
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:07.130322
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:27:10.652117
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:27:22.215550
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrap = AnsiTextWrapper
    # __init__()
    assert hasattr(wrap, '__init__')

    # All parameters are passed to the constructor

# Generated at 2022-06-23 18:27:33.452243
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=41, initial_indent='\x1b[31m',
                              subsequent_indent='\x1b[0m',
                              placeholder='\x1b[0m ...',
                              expand_tabs=True,
                              replace_whitespace=True,
                              fix_sentence_endings=False,
                              break_long_words=False,
                              drop_whitespace=False,
                              break_on_hyphens=False,
                              tabsize=4,
                              max_lines=3)
    assert wrapper.width == 41
    assert wrapper.initial_indent == '\x1b[31m'
    assert wrapper.subsequent_indent == '\x1b[0m'

# Generated at 2022-06-23 18:27:44.295074
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:55.647496
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:28:07.357318
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:16.801530
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    text = (
        '\x1b[35;1mFoo\x1b[0m \x1b[38;2;255;110;44mBar\x1b[0mBaz\x1b[35;1m-Baz'
        '\x1b[0m \x1b[38;2;255;110;44mDoom-Doom\x1b[0m'
    )
    wrapper = AnsiTextWrapper(width=14)
    wrapped_text = wrapper.wrap(text)

    # The contents of the returned list are not important for testing.
    assert isinstance(wrapped_text, list)


# Generated at 2022-06-23 18:28:25.110617
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest
    if hexversion < 0x03060000:
        pytest.xfail('This python version ({}) is not supported.'
            .format(hexversion))
    expected = 6
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    seq = [text]
    assert len_without_ansi(text) == expected
    assert len_without_ansi(seq) == expected
    seq = [text, text]
    assert len_without_ansi(seq) == expected * 2



# Generated at 2022-06-23 18:28:33.524156
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:39.604078
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    # Example of text from:
    #   https://github.com/csurfer/pyte/blob/master/tests/formatted_text.py

# Generated at 2022-06-23 18:28:40.683026
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    pass

# Generated at 2022-06-23 18:28:51.879335
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # type: () -> None
    """Unit test for function len_without_ansi"""
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\\n\x1b[38;5;209mfoobar\\x1b[0m \\n', '\\n\x1b[38;5;209mfoobar\\x1b[0m \\n']
    assert len_without_ansi(text) == 12
    return None
#
# class AnsiTextWrapper(TextWrapper):
#     """A text-wrapping class that counts ANSI escape codes as part
#     of the string length
#     """

# Generated at 2022-06-23 18:29:03.533254
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:29:09.462217
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(('\x1b[38;5;209mfoobar\x1b[0m', 'baz')) == 9



# Generated at 2022-06-23 18:29:22.079614
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:24.237031
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:29:36.248754
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:48.050030
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    '''
    Unit test for the constructor of the class AnsiTextWrapper.
    '''
    wrapper = AnsiTextWrapper(width=20)
    assert wrapper.width == 20
    assert wrapper.subsequent_indent == ''
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.initial_indent == ''
    assert wrapper.initial_indent_len == 0
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_on_hyphens is True
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.max_lines is None
    assert wrapper.placeholder == ' [...]'
    wrapper = AnsiTextWra

# Generated at 2022-06-23 18:30:00.514019
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import unittest
    from io import StringIO
    from textwrap import TextWrapper, dedent, fill
    wrapper = TextWrapper(width=40)

# Generated at 2022-06-23 18:30:09.016231
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:19.860368
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for the constructor of class ``AnsiTextWrapper``.  This
    tests that the constructor works correctly.

    Returns:
        True if the unit test passes, otherwise False.
    """
    from flutils.txtutils import AnsiTextWrapper
    try:
        wrapper = AnsiTextWrapper()
    except Exception as err:
        _, _, tb = sys.exc_info()
        print(
            'AnsiTextWrapper() raised {}: {}'.format(
                err.__class__.__name__,
                err
            ),
            file=sys.stderr,
            flush=True
        )
        traceback.print_tb(tb)
        return False

    try:
        wrapper = AnsiTextWrapper(width=40)
    except Exception as err:
        _,

# Generated at 2022-06-23 18:30:29.159398
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    print("Testing for constructor of class AnsiTextWrapper.")
    wrapper = AnsiTextWrapper()
    assert isinstance(wrapper, AnsiTextWrapper)
    wrapper = AnsiTextWrapper(width=40)
    assert isinstance(wrapper, AnsiTextWrapper)
    wrapper = AnsiTextWrapper(width=40, initial_indent=' ')
    assert isinstance(wrapper, AnsiTextWrapper)
    wrapper = AnsiTextWrapper(width=40, initial_indent=' ',
                              subsequent_indent=' ')
    assert isinstance(wrapper, AnsiTextWrapper)


# Generated at 2022-06-23 18:30:39.144676
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from textwrap import TextWrapper
    import sys

    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:30:51.720315
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:01.304347
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:12.261175
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    r"""Test the method AnsiTextWrapper.fill()."""
    import re

    # Test 1: simple test
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:31:14.840345
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:31:18.668947
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:31:29.254293
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    # Test the method fill - basic usage
    wrapper = AnsiTextWrapper()

# Generated at 2022-06-23 18:31:41.356266
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder_len == 6
    wrapper = AnsiTextWrapper(initial_indent='   ')
    assert wrapper.width == 70
    assert wrapper.initial_indent_len == 3
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder_len == 6
    wrapper = AnsiTextWrapper(subsequent_indent='\t')
    assert wrapper.width == 70
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent_len == 1
    assert wrapper.place

# Generated at 2022-06-23 18:31:52.817095
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:32:00.265345
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:08.626934
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:19.225451
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    def f(**kwargs):
        wrapper = AnsiTextWrapper(**kwargs)
        return wrapper

    with pytest.raises(ValueError) as e_info:
        f(width=-1)
    assert str(e_info.value) == "invalid width -1 (must be > 0)"

    with pytest.raises(ValueError):
        f(initial_indent='   ')
    with pytest.raises(TypeError):
        f(initial_indent=None)  # type: ignore

    with pytest.raises(ValueError):
        f(subsequent_indent='   ')
    with pytest.raises(TypeError):
        f(subsequent_indent=None)  # type: ignore


# Generated at 2022-06-23 18:32:28.223768
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:32:32.659341
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Construct a new AnsiTextWrapper object and set its instance variables
    # as follows:
    #   width = 40
    #   initial_indent = '\x1b[0;33;40m'
    #   subsequent_indent = ' '
    #   placeholder = ' [...]'
    wrapper = AnsiTextWrapper(width=40,
                              initial_indent='\x1b[0;33;40m',
                              subsequent_indent=' ',
                              placeholder=' [...]')

    # These are all the expected output lines.

# Generated at 2022-06-23 18:32:42.522173
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    wrapper = AnsiTextWrapper(width=40)
    print(f'{wrapper.__class__.__name__}: wrapper = {wrapper!r}')


# Generated at 2022-06-23 18:32:45.929990
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len(text) == 15



# Generated at 2022-06-23 18:32:47.021603
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(
        '\x1b[38;5;209mfoobar\x1b[0m'
    ) == 6

# Generated at 2022-06-23 18:32:55.018414
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m',
                             '\x1b[38;5;209mbaz\x1b[0m']) == 9
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m',
                             '\x1b[38;5;209mbar', '\x1b[0m']) == 6
    assert len_without_ansi('\x1b[38;5;209m\x1b[0m') == 0

# Generated at 2022-06-23 18:33:05.860189
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:16.822729
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:26.699321
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:33.580591
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\x1b[38;5;209mfoobar', '\x1b[0m\x1b[3m']
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:33:44.569221
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """test_AnsiTextWrapper() -> NoneType

    Run a unit test on the
    :obj:`~flutils.txtutils.AnsiTextWrapper.__init__` method.
    """
    print('Running unit test for AnsiTextWrapper.__init__')
    exc = None

    # Give the AnsiTextWrapper class a negative width.
    # It should raise a ValueError.
    try:
        Aw = AnsiTextWrapper(width= -1)
    except Exception as e:
        exc = e
    assert type(exc) == ValueError

    # Give the AnsiTextWrapper class a negative max_lines.
    # It should raise a ValueError.
    try:
        Aw = AnsiTextWrapper(max_lines= -1)
    except Exception as e:
        exc = e


# Generated at 2022-06-23 18:33:53.376369
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """ Unit test for method AnsiTextWrapper.fill. """

# Generated at 2022-06-23 18:33:56.725461
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:34:08.694321
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import pytest

    # test--1

# Generated at 2022-06-23 18:34:17.630233
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:25.412613
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text: str = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text2: str = '\x1b[38;5;209mf\x1b[0m\x1b[38;5;210mo\x1b[0mo\x1b[38;5;211mb\x1b[0m'
    assert len_without_ansi(text2) == 6
    text3: str = '\x1b[38;5;209mf\x1b[0mfoobar'
    assert len_without_ansi(text3) == 7



# Generated at 2022-06-23 18:34:34.595732
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:45.499317
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:55.691785
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper

# Generated at 2022-06-23 18:34:58.185077
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-23 18:35:05.963108
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Create the text to be wrapped
    text = (
        'The quick brown fox jumped over the lazy dog. The quick brown '
        'fox jumped over the lazy dog. The quick brown fox jumped '
        'over the lazy dog. The quick brown fox jumped over the '
        'lazy dog. The quick brown fox jumped over the lazy dog.'
    )
    # Create an AnsiTextWrapper object for 15 columns
    wrapper = AnsiTextWrapper(width=15)
    # Wrap the text
    wrapped_text = wrapper.wrap(text)
    # Print the output lines
    for line in wrapped_text:
        print(line)
    return


# Generated at 2022-06-23 18:35:14.761859
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    print('\nTesting class: AnsiTextWrapper')

    # Test max_lines
    wrapper = AnsiTextWrapper()
    text = '\n'.join(['Lorem ipsum dolor sit amet, consectetur adipiscing elit.'] * 7)
    wrapped_text = wrapper.wrap(text)
    assert len(wrapped_text) == 8
    assert wrapped_text[4] == 'Lorem ipsum dolor sit amet, consectetur'
    assert wrapped_text[5] == 'adipiscing elit. [...]'
    wrapper.max_lines = 5
    wrapped_text = wrapper.wrap(text)
    assert len(wrapped_text) == 5
    assert wrapped_text[2] == 'Lorem ipsum dolor sit amet, consectetur'


# Generated at 2022-06-23 18:35:27.628583
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Unit test for method wrap of flutils.txtutils.AnsiTextWrapper().

    from io import StringIO

    from flutils.txtutils import AnsiTextWrapper

    # With replace_whitespace=True (default), pysamwrap replaces newline
    # characters with spaces. This causes the next line to be appended to
    # the end of the preceding line.
    wrapper = AnsiTextWrapper()
    original_text = (
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n"
        "Cras fermentum maximus auctor.\n"
        "Cras a varius ligula."
    )
    print('replace_whitespace=True (default):')
    output = wrapper.wrap(original_text)
    print(' '.join(output))


# Generated at 2022-06-23 18:35:39.943639
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:51.337532
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:36:00.862721
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(ansi) == 6
    assert len_without_ansi([ansi, ansi]) == 12
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foobar', 'foobar']) == 12
    assert len_without_ansi(('foobar', 'foobar')) == 12
    assert len_without_ansi(('foobar', ansi)) == 6
    assert len_without_ansi(('foobar', '\x1b[0m')) == 6
    assert len_without_ansi(('foobar', '\x1b[1;2m')) == 6



# Generated at 2022-06-23 18:36:12.570965
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from re import compile as re_compile
    from sys import stdout

    # Wrap the text with the specified width, initial_indent,
    # and subsequent_indent

# Generated at 2022-06-23 18:36:21.699618
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import pytest
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:36:24.288197
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:36:27.692256
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:36:39.714417
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function :func:`len_without_ansi <flutils.txtutils.len_without_ansi>`
    """
    seqs = [
        '',
        'foo',
        b'foo',
        'foobar123',
        ['foo', 'bar'],
        ['fo', 'ob', 'ar'],
        '\x1b[38;5;209mfoobar\x1b[0m',
        ['\x1b[38;5;209m', 'foobar', '\x1b[0m'],
        ['\x1b[38;5;209mf', 'o', 'oba', 'r\x1b[0m'],
    ]

    answers = [0, 3, 3, 9, 6, 6, 6, 6, 6]


# Generated at 2022-06-23 18:36:52.867004
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Unit test for method fill of class AnsiTextWrapper
    """

# Generated at 2022-06-23 18:37:03.935902
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    class TestAnsiTextWrapper(AnsiTextWrapper):
        def __init__(self, width: int = 40, **kwargs):
            super().__init__(width=width, **kwargs)
