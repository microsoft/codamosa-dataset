

# Generated at 2022-06-23 18:27:05.948554
# Unit test for function len_without_ansi
def test_len_without_ansi():
    cases = [
        ('foobar', 6),
        (
            [
                'foobar',
                '\x1b[38;5;209mfoobar\x1b[0m',
                '\x1b[38;5;209mfoobar\x1b[0m'
            ],
            6
        ),
        (
            [
                '\x1b[38;5;209mfoo', 'bar\x1b[0m',
                '\x1b[38;5;209mfoobar\x1b[0m'
            ],
            6
        ),
    ]
    for text, exp in cases:
        got = len_without_ansi(text)
        assert got == exp, f'\n{text}\n!= {got}\n== {exp}'



# Generated at 2022-06-23 18:27:18.385887
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:29.864590
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:34.465127
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:27:41.018432
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:52.618607
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Instantiate a new AnsiTextWrapper instance
    wrapper = AnsiTextWrapper(width=40)

    # Text to be wrapped

# Generated at 2022-06-23 18:27:54.740335
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import doctest
    doctest.run_docstring_examples(AnsiTextWrapper.wrap, globals(), verbose=True)



# Generated at 2022-06-23 18:28:00.938005
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\\x1b[38;5;1mfoo\\x1b[0mbar']
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['foobar']) == 6
    assert len_without_ansi('') == 0
    assert len_without_ansi(['']) == 0
    assert len_without_ansi(['\x1b[38;5;4mfoo', 'bar', '\x1b[0m']) == 6

# Generated at 2022-06-23 18:28:09.819619
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:19.544608
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import unittest
    from io import StringIO
    from unittest import mock

    from flutils.txtutils import AnsiTextWrapper

    # noinspection PyUnresolvedReferences
    from flutils.tests.testutils import check_stdouterr


# Generated at 2022-06-23 18:28:29.659833
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    try:
        AnsiTextWrapper(width=0)
    except ValueError as err:
        assert err.args[0] == 'invalid width 0 (must be > 0)'

    try:
        AnsiTextWrapper(max_lines=1, width=7, placeholder=' [...]')
    except ValueError as err:
        assert err.args[0] == 'placeholder too large for max width'

    assert str(AnsiTextWrapper(drop_whitespace=False,
                               replace_whitespace=False)) == \
        '<AnsiTextWrapper drop_whitespace=False, replace_whitespace=False, width=70, initial_indent="", subsequent_indent="", max_lines=None>'


# Generated at 2022-06-23 18:28:31.801353
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:28:41.704359
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:54.302292
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:05.896324
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from typing import ClassVar, Final, Type, TypeVar, Callable
    from flutils.testingutils import CallsMe
    from flutils.txtutils import AnsiTextWrapper
    from textwrap import TextWrapper
    from unittest import TestCase
    from unittest.mock import Mock, patch


# Generated at 2022-06-23 18:29:17.888915
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper"""

    # Define the text.

# Generated at 2022-06-23 18:29:28.267749
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:39.624244
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import unittest

    class TestAnsiTextWrapperFill(unittest.TestCase):
        """Unit tests for the method fill of the class AnsiTextWrapper."""

        def test_correctly_wrapped_lines(self):
            """Checks if wrapping a text without ANSI codes results in the
            same output as returned by the class textwrap.TextWrapper.
            """
            import random
            import string

            from textwrap import TextWrapper

            for _ in range(100):
                w = random.randint(1, 80)
                text = ' '.join(
                    [''.join(random.choices(string.ascii_letters, k=w))
                     for _ in range(random.randint(1, 20))])

# Generated at 2022-06-23 18:29:49.975165
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:56.245667
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:05.602991
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import fill
    from .txtutils import AnsiTextWrapper

    text_wrappers = (
        AnsiTextWrapper(width=40, fix_sentence_endings=True),
        AnsiTextWrapper(width=40, fix_sentence_endings=False)
    )
    # Normal text

# Generated at 2022-06-23 18:30:16.046623
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:23.825894
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    try:
        AnsiTextWrapper(width=-1)
        # The above line should raise a ValueError
        assert 1 == 2
    except ValueError:
        pass

    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None
    assert wrapper.placeholder == ' [...]'

    wrapper = AnsiTextWra

# Generated at 2022-06-23 18:30:34.223881
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    # Case 1: Width > text length
    wrapper = AnsiTextWrapper(width=100)
    text = '''\x1b[1m\x1b[4mHello World!\x1b[0m Lorem ipsum dolor sit amet, consectetur adipiscing elit.'''
    ans = wrapper.wrap(text)
    exp = ['''\x1b[1m\x1b[4mHello World!\x1b[0m Lorem ipsum dolor sit amet, consectetur adipiscing elit.''']
    assert ans == exp

    # Case 2: Width < text length
    wrapper = AnsiTextWrapper(width=8)

# Generated at 2022-06-23 18:30:43.753482
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:49.655587
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test the :func:`len_without_ansi
    <flutils.txtutils.functions.len_without_ansi>` function."""
    text = '\u001b[38;5;209mfoobar\u001b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:31:00.004424
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:04.332930
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

    assert len_without_ansi('foo') == len('foo')
    assert len_without_ansi(['foo', 'bar']) == len('foobar')



# Generated at 2022-06-23 18:31:14.556626
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:26.945599
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:28.226544
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():  # noqa: D103
    pass  # pragma: nocover



# Generated at 2022-06-23 18:31:30.798469
# Unit test for function len_without_ansi
def test_len_without_ansi():
    expected = 6
    result = len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m')
    assert result == expected



# Generated at 2022-06-23 18:31:42.725008
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # pylint: disable=too-many-locals
    # pylint: disable=undefined-variable

    with pytest.raises(ValueError) as e:
        AnsiTextWrapper(placeholder='')
    assert 'placeholder too large for max width' in str(e.value)

    width = 40
    wrapper = AnsiTextWrapper(width=width)
    assert wrapper.width == width
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.initial_indent == ''
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
   

# Generated at 2022-06-23 18:31:47.542999
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    wrapper = AnsiTextWrapper(width=5,
        subsequent_indent=_ANSI_SEQ+'34m',
        placeholder=_ANSI_SEQ+'31;1m-=END=-'
        )

    assert isinstance(wrapper, AnsiTextWrapper)


# Generated at 2022-06-23 18:31:53.497747
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[1mfoo\x1b[0m']) == 9
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi('foobar') == 6



# Generated at 2022-06-23 18:32:04.668969
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from flutils.testutils import runtest
    from flutils.txtutils import AnsiTextWrapper
    # Capture stdout to simulate output for doctests.
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='\\x1b[1m',
        subsequent_indent='\\x1b[4m',
        placeholder='\\x1b[0m'
    )
    text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras '
    text += 'fermentum maximus auctor. Cras a varius ligula. Phasellus ut '
    text += 'ipsum eu erat consequat posuere. Pellentesque habitant morbi '

# Generated at 2022-06-23 18:32:10.295169
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # test str type
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    # test list type
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-23 18:32:20.083580
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # pylint: disable=unbalanced-tuple-unpacking,invalid-name
    """Unit test for constructor of class :obj:`~flutils.txtutils.AnsiTextWrapper`
    and :func:`~flutils.txtutils.len_without_ansi`.
    """

    # This will fail if class object AnsiTextWrapper is not defined.
    assert hasattr(flutils.txtutils, 'AnsiTextWrapper')

    # This will fail if function len_without_ansi is not defined.
    assert hasattr(flutils.txtutils, 'len_without_ansi')

    # This will fail if the value of MAX_COLORS is not an integer.
    assert isinstance(flutils.txtutils.MAX_COLORS, int)

    # This will fail if the value of MAX_COLORS is

# Generated at 2022-06-23 18:32:23.895746
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""

    text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    wrapper = AnsiTextWrapper()
    assert print(*(wrapper.wrap(text))) == print(*(textwrap.wrap(text)))

# Generated at 2022-06-23 18:32:36.219306
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:44.453369
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='',
        subsequent_indent=' ',
        placeholder='  [...]'
    )
    assert wrapper.initial_indent == ''
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent == ' '
    assert wrapper.subsequent_indent_len == 1
    assert wrapper.placeholder == '  [...]'
    assert wrapper.placeholder_len == 6
    assert wrapper.width == 40
    assert wrapper.expand_tabs
    assert wrapper.replace_whitespace
    assert not wrapper.fix_sentence_endings
    assert wrapper.break_long_words
    assert wrapper.drop_whitespace
    assert wrapper.break_on_hyphens
    assert wrapper.tabsize == 8

# Generated at 2022-06-23 18:32:54.862269
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import unittest

    class TestAnsiTextWrapper(unittest.TestCase):

        def test_placeholder_too_large_for_width(self):
            with self.assertRaises(ValueError):
                AnsiTextWrapper(
                    width=10, max_lines=3, placeholder=' abcde'
                )

        def test_placeholder_too_large_for_max_width(self):
            with self.assertRaises(ValueError):
                AnsiTextWrapper(width=10, max_lines=2, placeholder=' abcde')


# Generated at 2022-06-23 18:32:57.551237
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    try:
        AnsiTextWrapper()
    except:
        raise AssertionError('Constructor of class AnsiTextWrapper '
                             'should not raise an exception.')


# Generated at 2022-06-23 18:33:00.636331
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:33:13.141139
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    initial_indent = '    '
    subsequent_indent = '        '
    placeholder = ' [...]'

# Generated at 2022-06-23 18:33:24.151680
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:33:36.488649
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:41.025717
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:50.388512
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:57.622594
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    assert (AnsiTextWrapper(width=80).wrap(
        'abc'
    ) == ['abc'])
    assert (AnsiTextWrapper(width=80).wrap(
        'abc\n'
    ) == ['abc'])
    assert (AnsiTextWrapper(width=80).wrap(
        'abc\ndef'
    ) == ['abc', 'def'])
    assert (AnsiTextWrapper(width=80).wrap(
        'abc\ndef\n'
    ) == ['abc', 'def'])
    assert (AnsiTextWrapper(width=80).wrap(
        'abc\n\ndef'
    ) == ['abc', '', 'def'])

# Generated at 2022-06-23 18:34:09.449613
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    print('Testing constructor of class AnsiTextWrapper...', end='')
    # Test for constructor with no parameters
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines == None
    assert wrapper.placeholder == ' [...]'
    assert wrapper.initial_indent_len == 0

# Generated at 2022-06-23 18:34:18.033161
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test :meth:`~AnsiTextWrapper.wrap`"""

# Generated at 2022-06-23 18:34:29.178651
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:40.978317
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper
    text = '\x1b[1mlorem ipsum\x1b[0m'
    wrapper = AnsiTextWrapper()
    wrapped_text = wrapper.wrap(text)
    assert wrapped_text == ['\x1b[1mlorem ipsum\x1b[0m']
    wrapper.width = 12
    wrapped_text = wrapper.wrap(text)
    assert wrapped_text == ['\x1b[1mlorem ipsum\x1b[0m']
    wrapper.width = 11
    wrapped_text = wrapper.wrap(text)
    assert wrapped_text == ['\x1b[1mlorem ipsum\x1b[0m']
    wrapper.width = 10
    wrapped_text = wrapper.wrap(text)
   

# Generated at 2022-06-23 18:34:52.124679
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[1mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[1mfoo\x1b[0mbar'
    assert len_without_ansi(text) == 6
    text = '\x1b[1mfoo\x1b[0mbar\x1b[38;5;209m'
    assert len_without_ansi(text) == 6
    text = '\x1b[1mfoo\x1b[0mbar\x1b[38;5;209mbaz'
    assert len_without_

# Generated at 2022-06-23 18:35:03.733590
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:13.033595
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:26.398460
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:27.207477
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    AnsiTextWrapper()



# Generated at 2022-06-23 18:35:35.603822
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.tests.data import TEST_TEXT_WRAPPER_1
    print('Method wrap of class AnsiTextWrapper')
    print('------------------------------------')
    print(TEST_TEXT_WRAPPER_1)
    print('------------------------------------')
    wrapper = AnsiTextWrapper(width=40)
    wrapped_text = wrapper.wrap(TEST_TEXT_WRAPPER_1)
    print('\n'.join(wrapped_text))
    print('------------------------------------')



# Generated at 2022-06-23 18:35:44.272013
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import textwrap
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:35:47.195949
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:35:55.377714
# Unit test for function len_without_ansi

# Generated at 2022-06-23 18:36:04.941763
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from unittest import TestCase

    class test_len_without_ansi(TestCase):
        def test_len_without_ansi(self):
            text = '\x1b[38;5;209mfoobar\x1b[0m'
            self.assertEqual(len_without_ansi(text), 6)
            text = ['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mbaz\x1b[0m']
            self.assertEqual(len_without_ansi(text), 11)
            text = ['\x1b[38;5;209mfoobar\x1b[0m', 'baz']
            self.assertEqual(len_without_ansi(text), 9)
           

# Generated at 2022-06-23 18:36:12.587161
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:20.984906
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from contextlib import redirect_stderr, redirect_stdout
    from io import StringIO


# Generated at 2022-06-23 18:36:23.281334
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:36:26.359975
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    len_without_ansi(text) == 6



# Generated at 2022-06-23 18:36:38.588776
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:51.450935
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:37:03.189580
# Unit test for constructor of class AnsiTextWrapper