

# Generated at 2022-06-23 18:27:06.941012
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import unittest
    import doctest
    from flutils.txtutils import AnsiTextWrapper
    from . import txtutils as TxtTestModule
    from .utils import Timing
    # Unit test helpers
    from .logutils import (
        display_function_result,
        display_function_exception,
        display_function_header,
        display_unit_test_summary
    )
    from . import UnittestConfig
    from .pytestutils import PytestConfig, PytestTestCase

    # doctest options
    dc_opts = dict(
        optionflags=doctest.NORMALIZE_WHITESPACE | doctest.REPORT_ONLY_FIRST_FAILURE
    )

    # Get a copy of the unittest testcase class so we can add attributes to it
    # for testing

# Generated at 2022-06-23 18:27:19.436923
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:30.994050
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # pylint: disable=missing-docstring
    print('\nTesting AnsiTextWrapper:\n')

    actual_results = {}
    expected_results = {}

    print('\nTest AnsiTextWrapper.__init__():\n')

    # Test first 4 arguments of AnsiTextWrapper constructor
    tw = AnsiTextWrapper(width=28, initial_indent='test ', subsequent_indent='test ',
                         expand_tabs=False, replace_whitespace=False)
    actual_results['tw.width'] = tw.width
    actual_results['tw.initial_indent'] = tw.initial_indent
    actual_results['tw.initial_indent_len'] = tw.initial_indent_len
    actual_results['tw.subsequent_indent'] = tw.subsequent_ind

# Generated at 2022-06-23 18:27:42.226257
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import textwrap
    text = '\x1b[38;5;209mfoobar\x1b[0m'

    assert len_without_ansi(text) == 6

    wrapper = AnsiTextWrapper()
    result = textwrap.dedent("""\
        \x1b[38;5;209mfoobar\x1b[0m \x1b[38;5;209mfoobar\x1b[0m \x1b[38;5;209mfoobar\x1b[0m
        \x1b[38;5;209mfoobar\x1b[0m \x1b[38;5;209mfoobar\x1b[0m \x1b[38;5;209mfoobar\x1b[0m
        """)

    result_split

# Generated at 2022-06-23 18:27:54.010684
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Use AnsiTextWrapper the same way as using TextWrapper
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:28:05.814718
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:17.525235
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:28.433342
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:38.326005
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:50.480208
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:02.380829
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for the ``AnsiTextWrapper`` class."""

    def test_AnsiTextWrapper_constructor():
        """Unit test for the constructor of the ``AnsiTextWrapper`` class."""
        wrapper = AnsiTextWrapper()
        assert isinstance(wrapper, AnsiTextWrapper)
        assert wrapper.width == 70
        assert wrapper.initial_indent == ''
        assert wrapper.subsequent_indent == ''
        assert wrapper.placeholder == ' [...]'
        assert wrapper.expand_tabs is True
        assert wrapper.replace_whitespace is True
        assert wrapper.fix_sentence_endings is False
        assert wrapper.break_long_words is True
        assert wrapper.drop_whitespace is True
        assert wrapper.break_on_hyphens is True

# Generated at 2022-06-23 18:29:13.906657
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    from flutils.annotations import check_type

    actual = AnsiTextWrapper(width=40)

    assert isinstance(actual, AnsiTextWrapper)
    assert actual.width == 40
    assert actual.initial_indent == ''
    assert actual.subsequent_indent == ''
    assert actual.placeholder == ' [...]'
    assert actual.initial_indent_len == 0
    assert actual.subsequent_indent_len == 0
    assert actual.placeholder_len == 6
    assert actual.expand_tabs
    assert actual.replace_whitespace
    assert not actual.fix_sentence_endings
    assert actual.break_long_words
    assert actual.drop_whitespace
    assert actual.break_on_hyphens

# Generated at 2022-06-23 18:29:20.456760
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import textwrap
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.drop_whitespace == True
    assert wrapper.max_lines == None
    assert wrapper.placeholder == ' [...]'
    assert wrapper.tabsize == 8
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder_len == 6


# Generated at 2022-06-23 18:29:29.531664
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """https://docs.pytest.org/en/latest/assert.html"""

# Generated at 2022-06-23 18:29:40.216117
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test wrap method of class AnsiTextWrapper."""
    class TestAnsiTextWrapper(AnsiTextWrapper):
        """For testing."""

        def __init__(self, *args, **kwargs):
            self.__handle_long_word_called = False
            self.__handle_long_word_called_count = 0
            self.__handle_long_word_args = []
            self.__handle_long_word_kwargs = []

            super().__init__(*args, **kwargs)

        def _handle_long_word(
                self,
                chunks: List[str],
                cur_line: List[str],
                cur_len: int,
                width: int
        ) -> None:
            """For testing."""
            self.__handle_long_word_called = True


# Generated at 2022-06-23 18:29:50.507681
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:01.806081
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    assert AnsiTextWrapper(width=50).wrap('{0}'.format('a'*50)) == \
        ['aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa']
    assert AnsiTextWrapper(width=50).wrap('{0}'.format('a'*51)) == \
        ['aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa']
    assert AnsiTextWrapper(width=50).wrap('{0}'.format('a'*50+' ')) == \
        ['aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ']

# Generated at 2022-06-23 18:30:10.413875
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:20.782967
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """
    Test :meth:`~flutils.txtutils.AnsiTextWrapper.wrap` method.
    """

    class Testchunk(object):

        def __init__(self, value):
            self.value = value

        def __len__(self):
            return len_without_ansi(self.value)


# Generated at 2022-06-23 18:30:29.813588
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[1;32mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = 'foobar'
    assert len_without_ansi(text) == 6
    text = ['\x1b[1;32mfoobar\x1b[0m', '\x1b[1;32mfoobar\x1b[0m']
    assert len_without_ansi(text) == 12
    text = ['foobar', 'foobar']
    assert len_without_ansi(text) == 12



# Generated at 2022-06-23 18:30:39.698044
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6


# __ANSI_RE_STRIP = re.compile('(\x1b\\[[0-9;:]+[ABCDEFGHJKSTfhilmns])')
# def strip_ansi(seq: Sequence) -> List[Sequence]:
#     """Return a list of string sequences (strings, lists, tuples)
#     with ANSI codes removed.
#
#     *New in version 0.6*
#
#     Args:
#         seq (:obj:`Sequence <typing.Sequence>`): A string or a list/tuple
#             of strings.
#
#     :rtype:
#         :obj:`list`
#
#     Example

# Generated at 2022-06-23 18:30:52.847147
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import textwrap
    width = 40
    wrapper = AnsiTextWrapper(width=width)

# Generated at 2022-06-23 18:31:01.440319
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test for method wrap of class AnsiTextWrapper."""

    from flutils.txtutils import AnsiTextWrapper

    # The expected result from the example input.
    # Note: You may view the expected results, but do not alter them.
    expected_result = [
        'May I have a large container of coffee beans, please?',
        'This is just one line with a lot of text, '
        'and I don\'t want it to wrap.'
    ]

    # Example input
    input_text = (
        'May I have a large container of coffee beans, please?\n'
        'This is just one line with a lot of text, '
        'and I don\'t want it to wrap.'
    )

    # Invoke the method to be tested
    result = AnsiTextWrapper().wrap(input_text)

# Generated at 2022-06-23 18:31:06.935528
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from subprocess import check_output
    from sys import executable
    from os.path import dirname, join

    cmd = [executable, '-m', 'doctest', '-v', __file__]
    out = check_output(cmd).decode()

    if 'Failed' in out:
        raise AssertionError(out)



# Generated at 2022-06-23 18:31:08.458522
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import doctest

    doctest.testmod(verbose=False)



# Generated at 2022-06-23 18:31:11.197582
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from sys import hexversion

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:31:23.291741
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:31.037301
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from . import AnsiTextWrapper

    width = 50
    text = '\x1b[31m\x1b[1m\x1b[4m' + 'abc abc abc abc abc abc abc abc abc abc' + '\x1b[0m'
    wrapper = AnsiTextWrapper(width=width)
    result = wrapper.wrap(text)
    expected = ['\x1b[31m\x1b[1m\x1b[4m' + 'abc abc abc abc abc abc abc abc abc abc' + '\x1b[0m']
    assert result == expected



# Generated at 2022-06-23 18:31:43.135581
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:31:53.940867
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    aw = AnsiTextWrapper()
    assert aw.width == 70
    assert aw.initial_indent == ''
    assert aw.subsequent_indent == ''
    assert aw.expand_tabs == True
    assert aw.replace_whitespace == True
    assert aw.fix_sentence_endings == False
    assert aw.break_long_words == True
    assert aw.drop_whitespace == True
    assert aw.break_on_hyphens == True
    assert aw.tabsize == 8
    assert aw.max_lines == None
    assert aw.placeholder == ' [...]'
    assert aw.initial_indent_len == 0
    assert aw.subsequent_indent_len == 0
    assert aw.placeholder_len == 5


# Generated at 2022-06-23 18:31:58.294896
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    result = len_without_ansi(text)
    assert result == 6, result



# Generated at 2022-06-23 18:32:02.492357
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6

_TEXTWRAPPER_DEFAULT_WIDTH = 70



# Generated at 2022-06-23 18:32:13.281154
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:21.632915
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='\\x1b[31m\\x1b[1m\\x1b[4m',
        subsequent_indent='\\x1b[0m',
        placeholder=' [...]'
    )

# Generated at 2022-06-23 18:32:33.616539
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:43.194728
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test constructor of class ``AnsiTextWrapper``.

    """

    # Make sure the ``AnsiTextWrapper`` class can be initialized
    # when creating an instance of the class.
    wrapper = AnsiTextWrapper()
    # Make sure the class can be initialized with a ``width``
    # of `70` characters.
    wrapper = AnsiTextWrapper(width=70)
    # Make sure the class can be initialized with an initial
    # indent of two spaces.
    wrapper = AnsiTextWrapper(initial_indent='  ')
    # Make sure the class can be initialized with a subsequent
    # indent of four spaces.
    wrapper = AnsiTextWrapper(subsequent_indent='    ')
    # Make sure the class can be initialized with a placeholder
    # of ' [...]'.
    wrapper = AnsiText

# Generated at 2022-06-23 18:32:49.393829
# Unit test for function len_without_ansi
def test_len_without_ansi():
    m = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(m) == 6
    assert len_without_ansi([m]) == 6
    assert len_without_ansi((m,)) == 6
    assert len_without_ansi([m, m]) == 12
    assert len_without_ansi((m, m)) == 12



# Generated at 2022-06-23 18:32:56.964418
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text: str = '\x1b[38;5;209mfoobar\x1b[0m'
    seq: List[str] = ['\x1b[38;5;209mfoo', '\x1b[0mbar']
    assert len_without_ansi(text) == 6
    assert len_without_ansi(seq) == 6
test_len_without_ansi.__test__ = False  # Don't run as a unit test



# Generated at 2022-06-23 18:33:04.750307
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:16.219055
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    # pylint: disable=invalid-name
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:33:19.425901
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    w = AnsiTextWrapper(width=30)
    print(w.fill('Warning: \x1b[31mWARNING\x1b[0m'))

# Generated at 2022-06-23 18:33:28.094222
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    from flutils import txtutils


# Generated at 2022-06-23 18:33:40.816545
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

    def test_AnsiTextWrapper_wrap_no_args(output: str) -> None:
        text = 'Lorem ipsum dolor sit amet.'
        wrapper = AnsiTextWrapper()
        wrapped_text = wrapper.wrap(text)
        if wrapped_text:
            print(wrapped_text, end='')
            if not isinstance(wrapped_text, list):
                print()
        else:
            print(text)

        assert_equal(output, wrapped_text)

    def test_AnsiTextWrapper_wrap_width_12(output: str) -> None:
        text = 'Lorem ipsum dolor sit amet.'
        wrapper = AnsiTextWrapper(width=12)

# Generated at 2022-06-23 18:33:45.035228
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:53.449459
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = 'foobar'
    assert len_without_ansi(text) == 6

    text = 'f\x1bo\x1b[3mo\x1b[0;1mb\x1b[2m\x1b[38;5;209mar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = (
        'f\x1bo\x1b[3mo\x1b[0;1mb\x1b[2m\x1b[38;5;209mar\x1b[0m',
        '\x1b[38;5;209mfoobar\x1b[0m',
    )
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:34:02.300317
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:12.905750
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Testing the first constructor argument
    # Resetting AnsiTextWrapper to default
    wrapper = AnsiTextWrapper()

    # Testing the constructor's first argument width

# Generated at 2022-06-23 18:34:19.709741
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)
    wrapped_text = wrapper.wrap(TEST_TEXT)

# Generated at 2022-06-23 18:34:31.453711
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:43.155100
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test for method wrap of class AnsiTextWrapper."""
    # Test variable definition

# Generated at 2022-06-23 18:34:54.320650
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.tests import StringCapTestRunner
    from flutils.txtutils import AnsiTextWrapper

    def test_AnsiTextWrapper_wrap(text: str, width: int, max_lines: Optional[int],
                                  expected: str,
                                  **kwargs: Any) -> None:
        wrapper = AnsiTextWrapper(**kwargs)
        wrapper.width = width
        wrapper.max_lines = max_lines
        out = wrapper.wrap(text)
        out = '\n'.join(out)
        assert out == expected
        assert not out.endswith('\n')


# Generated at 2022-06-23 18:35:04.736157
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test constructor of class AnsiTextWrapper."""
    _width = 40
    _initial_indent = '>'
    _subsequent_indent = '-'
    _expand_tabs = True
    _replace_whitespace = True
    _fix_sentence_endings = False
    _break_long_words = True
    _drop_whitespace = True
    _break_on_hyphens = False
    _tabsize = 3

# Generated at 2022-06-23 18:35:13.946588
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:27.221257
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import pytest
    wrapper = AnsiTextWrapper()
    assert isinstance(wrapper, AnsiTextWrapper)
    wrapper = AnsiTextWrapper(width=12)
    assert wrapper.width == 12
    wrapper = AnsiTextWrapper(width=23, initial_indent='|')
    assert wrapper.width == 23
    assert wrapper.initial_indent == '|'
    wrapper = AnsiTextWrapper(max_lines=4)
    assert wrapper.max_lines == 4
    wrapper = AnsiTextWrapper(placeholder='---')
    assert wrapper.placeholder == '---'

# Generated at 2022-06-23 18:35:30.123397
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:35:41.543628
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # tt: type: ignore
    # tt: type: ignore
    # tt: type: ignore
    # tt: type: ignore
    # tt: type: ignore
    # tt: type: ignore
    # tt: type: ignore
    # tt: type: ignore
    wrapper = AnsiTextWrapper(
        width=20,
        initial_indent='\\x1b[33m\\x1b[1m',
        subsequent_indent='\\x1b[0m',
        placeholder='\\x1b[4m\\x1b[37m(MORE)\\x1b[0m'
    )

    # If a text is split into multiple lines, each line has a max width of
    # 20 characters, with the first line indented.
    # tt: type: ignore
   

# Generated at 2022-06-23 18:35:53.042852
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    text = "I have a dream..."

    # Test no arguments
    wrapper = AnsiTextWrapper()
    spc_len = len(text) - len_without_ansi(text)
    assert wrapper.width == 70, \
        f'AnsiTextWrapper.width should be 70, not {wrapper.width!r}'
    assert wrapper.initial_indent == '', \
        f'AnsiTextWrapper.initial_indent should be \'\', not ' \
        f'{wrapper.initial_indent!r}'
    assert wrapper.subsequent_indent == '', \
        f'AnsiTextWrapper.subsequent_indent should be \'\', not ' \
        f'{wrapper.subsequent_indent!r}'

# Generated at 2022-06-23 18:36:01.906989
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit test for method fill of class AnsiTextWrapper"""
    import pytest  # type: ignore[import]
    from textwrap import TextWrapper
    from typing import Any

    # from flutils.tests.test_txtutils import samples  # type: ignore[import]
    from .test_txtutils import samples  # type: ignore[import]

    text_wrapper = TextWrapper(
        width=40,
        initial_indent=' ',
        subsequent_indent=' ',
        replace_whitespace=False,
        expand_tabs=False
    )
    ansi_text_wrapper = AnsiTextWrapper(
        width=40,
        initial_indent=' ',
        subsequent_indent=' ',
        replace_whitespace=False,
        expand_tabs=False
    )
    widths

# Generated at 2022-06-23 18:36:08.972390
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """ Test AnsiTextWrapper constructor.
    """
    aw = AnsiTextWrapper(width=20,
                         initial_indent='A',
                         subsequent_indent='B',
                         placeholder='C')
    assert aw.initial_indent == 'A'
    assert aw.subsequent_indent == 'B'
    assert aw.placeholder == 'C'
    assert aw.width == 20


# Generated at 2022-06-23 18:36:12.383155
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    text = TEXT
    # width = 40
    width = 10
    wrapper = AnsiTextWrapper(width=width)
    wrapped_text = wrapper.fill(text)
    print(wrapped_text)


# Generated at 2022-06-23 18:36:20.836238
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit tests for method wrap of class AnsiTextWrapper."""

    wrapper = AnsiTextWrapper(width=10)
    text = 'Hello, World!'

    assert wrapper.wrap(text) == ['Hello,', 'World!']

    wrapper.subsequent_indent = '   '
    assert wrapper.wrap(text) == ['Hello,', '   World!']

    wrapper.subsequent_indent = ''
    wrapper.initial_indent = '   '
    assert wrapper.wrap(text) == ['   Hello,', 'World!']

    wrapper = AnsiTextWrapper(width=10, max_lines=2, placeholder='...')
    assert wrapper.wrap(text) == ['Hello,', 'World!...']

    text = 'Hello\nWorld!'

# Generated at 2022-06-23 18:36:26.763538
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='   ',
        subsequent_indent='      '
    )

# Generated at 2022-06-23 18:36:31.122993
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """The result of :meth:`~flutils.txtutils.AnsiTextWrapper.fill` should be
    identical to the result of :meth:`~textwrap.TextWrapper.fill`
    if the text contains no ANSI codes.
    """
    import random
    import string
    import textwrap

    # Randomly create a test string with no ANSI codes
    test_str = ''.join(
        random.choice(string.printable) for _ in range(1000)
    )

    s = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
    s += 'Cras fermentum maximus auctor. Cras a varius ligula. Phasellus '

# Generated at 2022-06-23 18:36:42.306054
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:36:54.018520
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:37:04.525242
# Unit test for method wrap of class AnsiTextWrapper