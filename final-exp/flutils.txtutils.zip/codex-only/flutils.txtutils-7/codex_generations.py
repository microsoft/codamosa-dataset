

# Generated at 2022-06-23 18:27:03.271763
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # noqa: D202  # Ignore AnsiTextWrapper test
    """Unit test for :obj:`AnsiTextWrapper
    <flutils.txtutils.AnsiTextWrapper>`

    Note:
        The unit test is a work in progress.
    """

# Generated at 2022-06-23 18:27:15.318433
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    width = 40

# Generated at 2022-06-23 18:27:27.053162
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import io
    from contextlib import redirect_stdout


# Generated at 2022-06-23 18:27:36.526001
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:48.052826
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # pragma: no cover
    """Unit test for constructor of class :obj:`AnsiTextWrapper`."""

# Generated at 2022-06-23 18:27:57.468228
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.pytest_utils import test_ansi_text_wrapper

    # https://github.com/PyCQA/pylint/issues/3582

# Generated at 2022-06-23 18:28:02.094840
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import textwrap
    assert(AnsiTextWrapper.__module__ == textwrap.__name__)
    assert(AnsiTextWrapper.__name__ == 'AnsiTextWrapper')

# Generated at 2022-06-23 18:28:10.606324
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """This is used for testing the :obj:`AnsiTextWrapper` class.

    This function instantiates a :obj:`AnsiTextWrapper` object and tests
    four methods of the class. The methods tested are listed below:

        * The constructor
        * :obj:`wrap`
        * :obj:`fill`
        * :obj:`__str__`

    The results of these tests are passed to :obj:`unittest` and provide
    feedback to the developer of the functionality of the
    :obj:`AnsiTextWrapper` class.
    """

    class TestAnsiTextWrapper(TestCase):
        """This is the test case class used to test
        :obj:`AnsiTextWrapper`.
        """


# Generated at 2022-06-23 18:28:19.999987
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:28:23.117122
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    for item in ([text, '', ' ', '\u0000'], text):
        assert len_without_ansi(item) == 6
# /Unit test for function len_without_ansi



# Generated at 2022-06-23 18:28:30.666866
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='\\x1b[31m\\x1b[1m\\x1b[4m',
        subsequent_indent='    ',
        placeholder='\\x1b[0m'
    )
    assert wrapper.width == 40
    assert (wrapper.initial_indent ==
            '\\x1b[31m\\x1b[1m\\x1b[4m')
    assert wrapper.subsequent_indent == '    '
    assert wrapper.placeholder == '\\x1b[0m'



# Generated at 2022-06-23 18:28:32.737257
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-23 18:28:38.066186
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foobar', 'baz']) == 10
    assert len_without_ansi(('foobar', 'baz')) == 10
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:28:50.338922
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=10, drop_whitespace=False)
    chunks = list(map(repr, wrapper._split(
        '\\x1b[39m\\x1b[0m\\x1b[32m\\x1b[39mab\\x1b[0m\\x1b[31mcd '
        '\\x1b[33m\\x1b[4mef\\x1b[0m\\x1b[31m\\x1b[4m\\x1b[0mgh '
        '\\x1b[38;5;208mijk\\x1b[39m\\x1b[38;2;55;172;230mlm\\x1b[39m'
    )))
    chunks[-1] += '\n'
    # print(ch

# Generated at 2022-06-23 18:29:02.224475
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():  # pragma: no cover

    from sys import _getframe
    from textwrap import dedent as ded

    _output: List[str] = []
    test_instance = AnsiTextWrapper()

    def _print(*args, **kwargs):
        from sys import stdout
        from textwrap import fill
        from typing import Optional
        nonlocal _output
        sep: Optional[str] = kwargs.pop('sep', ' ')
        end: Optional[str] = kwargs.pop('end', '\n')
        output = sep.join(map(str, args)) + end
        _output.append(fill(output,
                            width=stdout.get_columns(),
                            expand_tabs=False,
                            replace_whitespace=False))


# Generated at 2022-06-23 18:29:07.143591
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test that len_without_ansi works as expected
    """
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.split()) == 6



# Generated at 2022-06-23 18:29:19.494299
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Make sure AnsiTextWrapper works as expected.
    text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras fermentum maximus auctor.'
    wrapper = AnsiTextWrapper(width=40)
    wrapped_text = wrapper.fill(text)
    assert wrapped_text == text
    assert len(wrapped_text) == len(text)

    # Make sure AnsiTextWrapper works with ANSI codes.

# Generated at 2022-06-23 18:29:23.339916
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6



# Generated at 2022-06-23 18:29:26.239267
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6


# AnsiTextWrapper {{{

# Generated at 2022-06-23 18:29:38.212915
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from unittest import TestCase
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:29:49.583103
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from pytest import raises

    with raises(TypeError):
        # empty text
        wrapper = AnsiTextWrapper(width=40)
        wrapped_text = wrapper.fill()

    # No wrapping
    wrapper = AnsiTextWrapper(width=0)

# Generated at 2022-06-23 18:29:52.909853
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mhellomom\x1b[0m'
    assert len_without_ansi(text) == 9



# Generated at 2022-06-23 18:29:58.871010
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6



# Generated at 2022-06-23 18:30:07.344151
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import pytest
    from flutils.txtutils import AnsiTextWrapper
    from flutils.txtutils import wrap as wrap_with_ansi
    from flutils.txtutils import len_without_ansi

    # Test with no text
    text = ''
    assert AnsiTextWrapper().wrap(text) == []

    # Test with no text and a max width of 1
    assert AnsiTextWrapper(width=1).wrap(text) == []

    # Test initial indent of 1 character
    text = 'A'
    assert AnsiTextWrapper(width=1,
                           initial_indent='A').wrap(text) == ['A']

    # Test subsequent indent of 1 character
    text = 'A'
    assert AnsiTextWrapper(width=1,
                           subsequent_indent='A').wrap(text)

# Generated at 2022-06-23 18:30:18.433285
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""
    wrapper = AnsiTextWrapper()
    assert isinstance(wrapper, AnsiTextWrapper)
    assert isinstance(wrapper, TextWrapper)
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines == None
    assert wrapper.placeholder == ' [...]'

# Generated at 2022-06-23 18:30:30.423626
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.NORMALIZE_WHITESPACE)


# -----------------------------------------------------------------------------
# Copyright (C) 2020 Angelos Evripiotis.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ------------------------------ END-OF

# Generated at 2022-06-23 18:30:34.039069
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function ``len_without_ansi``."""
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# end function test_len_without_ansi



# Generated at 2022-06-23 18:30:43.683702
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:49.233744
# Unit test for function len_without_ansi
def test_len_without_ansi():
    test_text = ('\x1b[38;5;209mfoobar\x1b[0m', ['\x1b[38;5;209mfoobar\x1b[0m'])
    for seq in test_text:
        assert len_without_ansi(seq) == 6



# Generated at 2022-06-23 18:30:50.989391
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:30:54.663890
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi([text]) == 6

# Generated at 2022-06-23 18:31:03.307781
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('') == 0
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi('foobarbaz') == 9
    assert len_without_ansi('foo\\x1b[38;5;209mbar\\x1b[0m') == 6
    assert len_without_ansi('foo\\x1b[38;5;209mbar\\x1b[0mbaz') == 9
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(['foobar', 'baz']) == 9

# Generated at 2022-06-23 18:31:07.453537
# Unit test for function len_without_ansi
def test_len_without_ansi():
    ansi_string = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len(ansi_string) == 19
    assert len_without_ansi(ansi_string) == 6




# Generated at 2022-06-23 18:31:18.669662
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:29.248598
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:41.356249
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:46.386641
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:31:56.640690
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:06.197263
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:10.017889
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.max_lines == None
    assert wrapper.placeholder == ' [...]'


# Generated at 2022-06-23 18:32:19.926468
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():

    # Leading TAB
    text = '\tFirst line.\nSecond line.\nThird line.\nFourth line.'
    wrapper = AnsiTextWrapper(width=10, initial_indent='\t', subsequent_indent=' ' * 8)
    expected_result = '\tFirst line.\n        Second line.\n        Third line.\n        Fourth line.'
    assert wrapper.fill(text) == expected_result

    # Unicode
    text = '\tFirst line.\nSecond line.\nThird line.\nFourth line.'
    wrapper = AnsiTextWrapper(width=10, initial_indent='\t', subsequent_indent=' ' * 8)
    text = 'Αα \N{GREEK CAPITAL LETTER ALPHA WITH PSILI}'

# Generated at 2022-06-23 18:32:28.399291
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # String
    text1 = 'foo'
    text2 = '\x1b[1mbar\x1b[0m'
    text3 = '\x1b[4m\x1b[1mfoobar\x1b[0m\x1b[0m'
    text4 = '\x1b[1m@\x1b[1mbar\x1b[0m\x1b[0m\x1b[4m'
    text5 = '@\x1b[1mbar\x1b[0m\x1b[0m\x1b[4m'
    assert len_without_ansi(text1) == 3
    assert len_without_ansi(text2) == 3
    assert len_without_ansi(text3) == 6

# Generated at 2022-06-23 18:32:39.459084
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[1mbaz\x1b[0m'
    assert len_without_ansi(text) == 9
    text = '\x1b[38;5;209mfoo\x1b[0mbar\x1b[1mbaz\x1b[0m'
    assert len_without_ansi(text) == 9

# Generated at 2022-06-23 18:32:46.395583
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('\\x1b[38;5;209mfoobar\\x1b[0m') == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi(['\\x1b[38;5;209mfoo', 'bar']) == 6



# Generated at 2022-06-23 18:32:47.891113
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Test function flutils.txtutils.len_without_ansi"""
    from flutils.txtutils import len_without_ansi

    ex = '\x1b[38;5;223mfoobar\x1b[0m'
    assert len_without_ansi(ex) == 6



# Generated at 2022-06-23 18:32:55.635375
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:06.979314
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Execute the constructor of class AnsiTextWrapper."""

    logger = logging.getLogger(__name__)

    logger.info('AnsiTextWrapper()')
    wrapper = AnsiTextWrapper()
    logger.info(f'  wrapper.width:              {wrapper.width}')
    logger.info(f'  wrapper.initial_indent:     {wrapper.initial_indent!r}')
    logger.info(f'  wrapper.subsequent_indent:  {wrapper.subsequent_indent!r}')
    logger.info(f'  wrapper.expand_tabs:        {wrapper.expand_tabs}')
    logger.info(f'  wrapper.replace_whitespace: {wrapper.replace_whitespace}')

# Generated at 2022-06-23 18:33:15.693556
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m', '\x1b[38;5;209mfoobar\x1b[0m']) == 12
    assert len_without_ansi(['\x1b[38;5;209mfoo\x1b[0m', 'bar\x1b[0m']) == 6

# Generated at 2022-06-23 18:33:25.986907
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    print('Testing method AnsiTextWrapper.wrap:', end=' ')


# Generated at 2022-06-23 18:33:38.634611
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    text = (
        '\\x1b[1;34m'
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras '
        'fermentum maximus auctor. Cras a varius ligula. Phasellus ut '
        'ipsum eu erat consequat posuere.'
        '\\x1b[0m'
    )

# Generated at 2022-06-23 18:33:48.638784
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Test setting values through the class constructor
    ptf = AnsiTextWrapper(max_lines=1, width=9, placeholder='$')
    assert ptf.max_lines == 1
    assert ptf.width == 9
    assert ptf.placeholder == '$'

    # Test the len_without_ansi() function
    assert len_without_ansi('\x1b[31m\x1b[1m\x1b[4m\x1b[0m') == 0, (
        "function len_without_ansi() failed to ignore ANSI codes, "
        "returned 0."
    )

# Generated at 2022-06-23 18:33:56.567602
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import io
    import sys

    from unittest import mock
    from unittest.mock import call

    # The following code describes the following list comprehension:
    #
    # for chunk in chunks:
    #     for c in _ANSI_RE.split(chunk):
    #         if c:
    #             out.append(c)
    # return out
    from itertools import chain
    from typing import List

    from flutils.txtutils import AnsiTextWrapper

    text = u'Here is a paragraph.'
    width = 6
    wrapper = AnsiTextWrapper(width=width)
    wrapped_text = wrapper.wrap(text)
    assert wrapped_text == [u'Here ', u'is a ', u'paragr', u'aph.']

    text = u'Here is a longer paragraph.'

# Generated at 2022-06-23 18:34:08.511769
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Test for class :obj:`~flutils.txtutils.AnsiTextWrapper`."""

# Generated at 2022-06-23 18:34:17.583701
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:21.145993
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from unittest import TestCase
    from .case import CaseDataGetter

    class Test(TestCase, metaclass=CaseDataGetter):
        cases = [
            ('a', 1),
            ('ab', 2),
            ('A\x1b[31mB\x1b[0mC', 2),
        ]
        function = staticmethod(len_without_ansi)

    Test.create_case_data()



# Generated at 2022-06-23 18:34:29.075304
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ('\x1b[38;5;209mfoobar\x1b[0m', 'foobar', '\x1b[38;5;209mfoobar', '')
    assert len_without_ansi(text) == 18
    text = 'foobarfoobarfoobar'
    assert len_without_ansi(text) == 18



# Generated at 2022-06-23 18:34:40.869770
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:52.126214
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import textwrap


# Generated at 2022-06-23 18:35:03.732427
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:12.178201
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    text = '\x1b[31m\x1b[1m\x1b[4mLorem ipsum dolor sit amet, '
    text += 'consectetur adipiscing elit. Cras fermentum maximus auctor. '
    text += 'Cras a varius ligula. Phasellus ut ipsum eu erat consequat '
    text += 'posuere.\x1b[0m Pellentesque habitant morbi tristique '
    text += 'senectus et netus et malesuada fames ac turpis egestas. '
    text += 'Maecenas ultricies lacus id massa interdum dignissim. '
    text += 'Curabitur \x1b[38;2;55;172;230mefficitur ante sit amet '
   

# Generated at 2022-06-23 18:35:24.623845
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi"""
    from contextlib import ExitStack
    from os import getcwd
    from tempfile import mkdtemp
    from shutil import rmtree
    from typing import Iterator, Optional
    from unittest import TestCase
    from unittest.mock import patch
    from tmuxp import util
    from flutils.precision import repr_helper
    from flutils.txtutils import len_without_ansi
    from .context import redirect_stdout, redirected_stdout

    class Test(TestCase):
        """Unit test class"""

        @classmethod
        def setUpClass(cls) -> None:  # Unit test
            # type: ignore[override]
            """Set up test resources."""
            # Set up tmuxp test resources
            cls

# Generated at 2022-06-23 18:35:29.056984
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper"""
    AnsiTextWrapper()
    # Can't test default values, because the superclass' constructor
    # calls _setup(), which deletes all private attributes of the
    # subclass, which makes it impossible to check them.


# Generated at 2022-06-23 18:35:40.813742
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper
    from textwrap import wrap

# Generated at 2022-06-23 18:35:51.943244
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    for k, v in examples.items():
        for width in (80, 70, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1):
            wrapper = AnsiTextWrapper(width=width)
            wrapped_text = wrapper.fill(v['text'])
            if len(wrapped_text) > len(v['expect'][width]):
                print('Example', k)
                print('Text:', v['text'])
                print('Wrapped text (width={}):'.format(width))
                print(wrapped_text)
                assert(False)

# Unit test
if __name__ == '__main__':
    # Test the length of examples
    assert(len(examples) == 2)
    # Test whether all examples contain all keys
   

# Generated at 2022-06-23 18:36:01.360564
# Unit test for function len_without_ansi
def test_len_without_ansi(): # pylint: disable=unused-argument,missing-function-docstring
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    text = '\x1b[38;5;209mfoobar\x1b[0m\x1b[38;5;209mbaz\x1b[0m'
    assert len_without_ansi(text) == 9
    text = '\x1b[38;5;209mfoobar\x1b[0m \x1b[38;5;209mbaz\x1b[0m'
    assert len_without_ansi(text) == 11

# Generated at 2022-06-23 18:36:13.080307
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:36:19.244549
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:29.707210
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:41.410624
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Test the wrap method of :obj:`~flutils.txtutils.AnsiTextWrapper`
    """


# Generated at 2022-06-23 18:36:44.285484
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:36:46.380624
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # type: () -> None
    from flutils.txtutils import len_without_ansi
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:36:55.901090
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent == ''
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder == ' [...]'
    assert wrapper.placeholder_len == len_without_ansi(' [...]')
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.max_lines is None
    assert wrapper._AnsiTextWrapper__placeholder == ' [...]'
    assert wrapper._AnsiTextWrapper__initial_indent == ''
    assert wrapper._AnsiTextWrapper__subsequent_indent