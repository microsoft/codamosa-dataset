

# Generated at 2022-06-23 18:27:03.439769
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import textwrap
    from flutils.txtutils import AnsiTextWrapper
    from unittest.mock import MagicMock
    wrapper = AnsiTextWrapper(width=40)


# Generated at 2022-06-23 18:27:15.517627
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:27.247200
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:27:36.704326
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    '''
    Unit test for method wrap of class AnsiTextWrapper
    '''

# Generated at 2022-06-23 18:27:41.918132
# Unit test for function len_without_ansi
def test_len_without_ansi():
    '''Test function `len_without_ansi`'''
    _text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert_equals(len_without_ansi(_text), 6)
    assert_equals(len_without_ansi(['\x1b[38;5;209mfoobar\x1b[0m']), 6)



# Generated at 2022-06-23 18:27:53.700583
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:05.546306
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar') == 6
    assert len_without_ansi(('\x1b[38;5;209m', 'foobar')) == 6
    assert len_without_ansi(('\x1b[38;5;209m', '\x1b[0mfoobar')) == 6
    assert len_without_ansi(('\x1b[38;5;209m', 'foobar', '\x1b[0m')) == 6
    assert len_without_ansi(('\x1b[38;5;209m', 'foobar', 'baz')) == 9
    assert len_without_ansi(('foobar', 'baz')) == 9

# Generated at 2022-06-23 18:28:17.436095
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:28.298842
# Unit test for function len_without_ansi
def test_len_without_ansi():
    import pytest
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = 'foo\x1b[0m'
    assert len_without_ansi(text) == 3

    text = '\x1b[0mfoo'
    assert len_without_ansi(text) == 3

    text = '\x1b[0;0mfoo'
    assert len_without_ansi(text) == 3

    text = '\x1b[1;0mfoo'
    assert len_without_ansi(text) == 3

    text = '\x1b[0;1mfoo'
    assert len_without_ansi(text) == 3


# Generated at 2022-06-23 18:28:31.095686
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6, out



# Generated at 2022-06-23 18:28:37.973454
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:28:50.244747
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:02.121060
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:05.159262
# Unit test for function len_without_ansi
def test_len_without_ansi():
    seq = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(seq) == 6



# Generated at 2022-06-23 18:29:08.143688
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6


# Generated at 2022-06-23 18:29:20.539906
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Test to ensure that the :obj:`fill` method of
    :obj:`~flutils.txtutils.AnsiTextWrapper` works as expected.
    """

# Generated at 2022-06-23 18:29:25.343076
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

    text = '\x1b[38;5;209mfoobar\x1b[38;5;160mbaz\x1b[0m'
    assert len_without_ansi(text) == 9

    text = ['\x1b[38;5;209mfoobar', '\x1b[0m']
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:29:29.171433
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    out = len_without_ansi(text)
    assert out == 6



# Generated at 2022-06-23 18:29:33.963618
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text.split()) == 6



# Generated at 2022-06-23 18:29:42.506636
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:29:49.849804
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    t = AnsiTextWrapper(width=50)
    assert t.width == 50
    assert t.initial_indent == ''
    assert t.subsequent_indent == ''
    assert t.expand_tabs == True
    assert t.replace_whitespace == True
    assert t.initial_indent_len == 0
    assert t.subsequent_indent_len == 0
    assert t.placeholder == ' [...]'
    assert t.placeholder_len == 6
    assert t.max_lines is None


# Generated at 2022-06-23 18:30:01.392626
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Tests method fill of class AnsiTextWrapper."""
    from flutils.txtutils import AnsiTextWrapper


# Generated at 2022-06-23 18:30:10.087695
# Unit test for function len_without_ansi
def test_len_without_ansi():
    from flutils.assertutils import assert_equal

    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert_equal(len_without_ansi(text), 6)

    text = ['\x1b[38;5;209mfoobar\x1b[0m']
    assert_equal(len_without_ansi(text), 6)

    text = ['\x1b[38;5;209mfoobar\x1b[0m', 'baz']
    assert_equal(len_without_ansi(text), 10)

    text = ('\x1b[38;5;209mfoobar\x1b[0m', 'baz')
    assert_equal(len_without_ansi(text), 10)
# end def


# Generated at 2022-06-23 18:30:15.463441
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # text = '\x1b[90m\x1b[38;5;209mfoobar'  # I don't get how this is 7
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:30:23.535964
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from . import AnsiTextWrapper
    from random import randint
    from random import choice
    from random import choices
    from random import seed
    from string import ascii_letters


# Generated at 2022-06-23 18:30:27.747086
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foo', 'bar']) == 6
    assert len_without_ansi('foobar'.split()) == 6
test_len_without_ansi()



# Generated at 2022-06-23 18:30:32.819170
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;158mfoobar\x1b[0m'
    t_len = len_without_ansi(text)
    assert t_len == 6
    seq = ['\x1b[38;5;76mfoo\x1b[0m', 'bar']
    s_len = len_without_ansi(seq)
    assert s_len == 6



# Generated at 2022-06-23 18:30:42.690014
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import copy
    import doctest

    # Copy the original, basic, AnsiTextWrapper instance
    wrapper = copy.copy(_AnsiTextWrapper)

    # Use the default max_width of 70

# Generated at 2022-06-23 18:30:54.870869
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    print("test_AnsiTextWrapper_fill")

# Generated at 2022-06-23 18:31:03.392970
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:08.483457
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:19.786051
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    # Get the path and file name of this module.
    modpath = Path(inspect.getfile(test_AnsiTextWrapper_wrap)).resolve()
    modname = modpath.stem
    moddir = modpath.parent

    aw = AnsiTextWrapper(width=40, fix_sentence_endings=True)

# Generated at 2022-06-23 18:31:22.413723
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6



# Generated at 2022-06-23 18:31:31.280860
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:43.379888
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # pylint: disable=too-many-locals, unused-variable
    wrapper = AnsiTextWrapper(width=40)
    assert isinstance(wrapper, AnsiTextWrapper)
    wrapper = AnsiTextWrapper(width=40, placeholder=' [...]')
    assert isinstance(wrapper, AnsiTextWrapper)
    wrapper = AnsiTextWrapper(width=40, initial_indent='>>> ')
    assert isinstance(wrapper, AnsiTextWrapper)
    wrapper = AnsiTextWrapper(width=40, subsequent_indent='... ')
    assert isinstance(wrapper, AnsiTextWrapper)
    wrapper = AnsiTextWrapper(width=40, expand_tabs=True)
    assert isinstance(wrapper, AnsiTextWrapper)

# Generated at 2022-06-23 18:31:46.328624
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:31:51.306314
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Verify that the AnsiTextWrapper class constructor does not raise an
    exception.
    """
    try:
        AnsiTextWrapper()
    except Exception as e:
        pytest.fail(str(e))

# Function to test method fill of class AnsiTextWrapper.

# Generated at 2022-06-23 18:32:03.768736
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Unit test for :func:`~flutils.txtutils.AnsiTextWrapper.fill`."""
    #
    # test wrap
    #

# Generated at 2022-06-23 18:32:15.566215
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:19.202757
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    _assert_equals(len_without_ansi(text), 6)



# Generated at 2022-06-23 18:32:28.199874
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:32:39.379756
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of
    :obj:`~flutils.txtutils.AnsiTextWrapper`
    """
    # pylint: disable=unused-argument
    # pylint: disable=no-self-use
    # pylint: disable=too-many-arguments
    # pylint: disable=too-few-public-methods
    # pylint: disable=missing-docstring

# Generated at 2022-06-23 18:32:50.785206
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    tw = AnsiTextWrapper()

# Generated at 2022-06-23 18:33:01.001028
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import re

    try:
        from test.support import captured_stdout, captured_stderr

    except ImportError:
        from test.capture import captured_stdout, captured_stderr

    # Test attributes are initialized to correct values
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None
    assert wrapper.place

# Generated at 2022-06-23 18:33:03.113046
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # pragma: no cover
    assert AnsiTextWrapper()


# Generated at 2022-06-23 18:33:15.382003
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:18.454280
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6



# Generated at 2022-06-23 18:33:27.582488
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """ Tests the constructor of class AnsiTextWrapper """

    text_wrap_ansi = AnsiTextWrapper(width=40, subsequent_indent=' '*10)
    text_wrap_ansi.placeholder = ' ' * 8
    text_wrap_ansi.subsequent_indent = ' ' * 10
    text_wrap_ansi.initial_indent = ' ' * 8

# Generated at 2022-06-23 18:33:40.046613
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:49.969276
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('fòô') == 3
    assert len_without_ansi('foo bar baz') == 11
    assert len_without_ansi(['foo', 'bar', 'baz']) == 11
    assert len_without_ansi('f\x1b[1;5mòô\x1b[0m') == 3
    assert len_without_ansi('f\x1b[1;5mòô\x1b[0m b\x1b[1;5màz\x1b[0m') == 5
    assert len_without_ansi(['fòô', 'bàz']) == 5
test_len_without_ansi()



# Generated at 2022-06-23 18:33:57.395398
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(40)
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent == ''
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder == ' [...]'
    assert wrapper.placeholder_len == 6
    assert wrapper.max_lines is None

    wrapper = AnsiTextWrapper(
        40,
        initial_indent='   ',
        subsequent_indent='      ',
        placeholder='...',
        max_lines=100
    )
    assert wrapper.width == 40
    assert wrapper.initial_indent == '   '
    assert wrapper.initial_indent_len == 3
    assert wrapper.subsequent_indent == '      '
   

# Generated at 2022-06-23 18:34:05.692215
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit tests for len_without_ansi()"""
    text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(text) == 6
    text = ['\\x1b[38;5;209mfoo', 'bar\\x1b[0m']
    assert len_without_ansi(text) == 6
    text = 'foo'
    assert len_without_ansi(text) == 3
    


# Generated at 2022-06-23 18:34:15.257577
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent == ''
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder == ' [...]'
    assert wrapper.placeholder_len == 6
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None


# Generated at 2022-06-23 18:34:25.348623
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:26.904627
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    pass



# Generated at 2022-06-23 18:34:38.539335
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:41.952363
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    # Test placeholder too large for max width
    with pytest.raises(ValueError):
        AnsiTextWrapper(width=18, max_lines=2, placeholder='[...] ')


# Generated at 2022-06-23 18:34:49.882697
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    print('')
    print('Testing constructor of AnsiTextWrapper')
    print('----------------------------')
    wrapper = AnsiTextWrapper()
    print(
        'Default AnsiTextWrapper:\n'
        '{!r}'.format(wrapper)
    )
    print(
        '  width: {!r}'.format(wrapper.width)
    )
    print(
        '  initial_indent: {!r}'.format(wrapper.initial_indent)
    )
    print(
        '  subsequent_indent: {!r}'.format(wrapper.subsequent_indent)
    )
    print(
        '  expand_tabs: {!r}'.format(wrapper.expand_tabs)
    )

# Generated at 2022-06-23 18:34:57.325924
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():

    # Create an instance of class AnsiTextWrapper
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70, 'wrapper.width should be 70'
    assert wrapper.initial_indent == '', 'wrapper.initial_indent should be empty string'
    assert wrapper.subsequent_indent == '', 'wrapper.subsequent_indent should be empty string'
    assert wrapper.initial_indent_len == 0, 'wrapper.initial_indent_len should be 0'
    assert wrapper.subsequent_indent_len == 0, 'wrapper.subsequent_indent_len should be 0'
    assert wrapper.expand_tabs == True, 'wrapper.expand_tabs should be True'
    assert wrapper.replace_whitespace == True, 'wrapper.replace_whitespace should be True'
    assert wrapper

# Generated at 2022-06-23 18:35:05.656368
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import doctest
    doctest.testfile('../tests/txtutils.AnsiTextWrapper.rst',
                     __file__, 'AnsiTextWrapper.fill', module_relative=True)
    # doctest.testmod(__file__)
    # doctest.testfile('../tests/txtutils.AnsiTextWrapper.rst',
    #                  __file__, 'AnsiTextWrapper.fill',
    #                  module_relative=True)
    # doctest.testfile('../tests/txtutils.AnsiTextWrapper.rst',
    #                  __file__, 'AnsiTextWrapper.fill', module_relative=True)

# Generated at 2022-06-23 18:35:14.592247
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70

    wrapper = AnsiTextWrapper(width = 80)
    assert wrapper.width == 80

    wrapper = AnsiTextWrapper(expand_tabs = False)
    assert wrapper.expand_tabs == False

    wrapper = AnsiTextWrapper(replace_whitespace = False)
    assert wrapper.replace_whitespace == False

    wrapper = AnsiTextWrapper(fix_sentence_endings = True)
    assert wrapper.fix_sentence_endings == True

    wrapper = AnsiTextWrapper(break_long_words = False)
    assert wrapper.break_long_words == False

    wrapper = AnsiTextWrapper(drop_whitespace = False)
    assert wrapper.drop_whitespace == False

    wrapper = Ansi

# Generated at 2022-06-23 18:35:27.536146
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:39.764249
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:35:51.106802
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():  # pragma: no cover
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='   ',
        subsequent_indent='      ',
        placeholder=' [...]'
    )

# Generated at 2022-06-23 18:36:00.702239
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:12.287448
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo') == 3
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi([
        '\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;208mbar\x1b[0m'
    ]) == 6

if hexversion >= 0x03080000:
    _from_opt_kwargs = ('expand_tabs', 'replace_whitespace', 'drop_whitespace',
                        'break_long_words', 'break_on_hyphens',
                        'preserve_paragraphs', 'max_lines')

# Generated at 2022-06-23 18:36:18.525289
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = [
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mfoo\x1b[0m',
        '\x1b[38;5;209mfoobar\x1b[0m',
        '\x1b[38;5;209mfoobar\x1b[0m',
    ]
    assert len_without_ansi(text) == 12



# Generated at 2022-06-23 18:36:28.363468
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:40.360300
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for ``AnsiTextWrapper``.

    Prints the results to stdout.
    """
    import os
    import shutil
    import sys

    green_bold = '\x1b[1;38;2;152;251;152m'
    yellow_bold = '\x1b[1;38;2;255;255;148m'
    red_bold = '\x1b[1;38;2;255;120;120m'
    white_bold = '\x1b[1;38;2;255;255;255m'
    end = '\x1b[0m'

    # Get the terminal dimensions
    rows, cols = shutil.get_terminal_size(fallback=(80, 24))


# Generated at 2022-06-23 18:36:43.269335
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:36:54.814912
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Tests the constructor of class AnsiTextWrapper.

    The purpose of this tests is to make sure the constructor and its
    setters perform the expected validations against the arguments.

    """
    # -------------------------------------------------------------------------
    # Width
    # -------------------------------------------------------------------------
    # width is less than 1
    with raises(ValueError):
        AnsiTextWrapper(width=-1)
    # width is not an integer
    with raises(TypeError):
        AnsiTextWrapper(width=1.0)
    # width is not a string