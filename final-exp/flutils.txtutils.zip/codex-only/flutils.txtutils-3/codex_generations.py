

# Generated at 2022-06-23 18:27:03.991961
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper
    wrapper = AnsiTextWrapper(width=30, initial_indent='    ')
    text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nec ipsum tortor. Proin eget ullamcorper est, ac ultricies dui. Proin in gravida leo, a tincidunt neque. In egestas, libero vitae fermentum vulputate, velit velit consectetur erat, in dictum lectus lorem id sem."
    wrapped_text = wrapper.fill(text)

# Generated at 2022-06-23 18:27:14.135835
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(placeholder='', width=70)
    assert wrapper.width == 70
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.expand_tabs == True
    assert wrapper.replace_whitespace == True
    assert wrapper.fix_sentence_endings == False
    assert wrapper.break_long_words == True
    assert wrapper.drop_whitespace == True
    assert wrapper.break_on_hyphens == True
    assert wrapper.tabsize == 8
    assert wrapper.placeholder == ''
    assert wrapper.max_lines == None


# Generated at 2022-06-23 18:27:25.893869
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:35.662989
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:46.838121
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:27:54.850022
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    text2 = ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;206mbar\x1b[0m']
    text3 = ['\x1b[38;5;209mfoo\x1b[0m', '\x1b[38;5;206', 'mbar\x1b[0m']
    assert len_without_ansi(text) == 6
    assert len_without_ansi(text2) == 6
    assert len_without_ansi(text3) == 6



# Generated at 2022-06-23 18:28:00.272928
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foo\x1b[0;32mbar\x1b[0m') == 3
    assert len_without_ansi(['foo\x1b[0;32mbar\x1b[0m']) == 3



# Generated at 2022-06-23 18:28:02.603383
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    ansitextwrapper = AnsiTextWrapper()
    assert isinstance(ansitextwrapper, AnsiTextWrapper)


# Generated at 2022-06-23 18:28:05.930917
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)
    assert wrapper.width == 40
    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.placeholder == ' [...]'
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None



# Generated at 2022-06-23 18:28:07.786726
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    assert AnsiTextWrapper()


# Generated at 2022-06-23 18:28:10.322768
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    import doctest
    doctest.run_docstring_examples(AnsiTextWrapper, globals(), verbose=True)


# Generated at 2022-06-23 18:28:19.836643
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:28:24.538597
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # Testing string
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # Testing tuple
    text = ('\x1b[38;5;209m', 'foobar', '\x1b[0m')
    assert len_without_ansi(text) == 6
    # Testing list
    text = ['\x1b[38;5;209m', 'foobar', '\x1b[0m']
    assert len_without_ansi(text) == 6

# Generated at 2022-06-23 18:28:35.564751
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """Test method ``fill`` of class :obj:`~flutils.txtutils.AnsiTextWrapper`.
    """

# Generated at 2022-06-23 18:28:44.277539
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[1mfoobar') == 6
    assert len_without_ansi('foobar\x1b[0m') == 6
    assert len_without_ansi('\x1b[1mfoo\x1b[0mbar') == 6
    assert len_without_ansi('\x1b[1m\x1b[0mbar') == 3
    assert len_without_ansi('\x1b[1m') == 0
    assert len_without_ansi(['\x1b[1mfoo', '\x1b[0m', 'bar']) == 6
    assert len_without_ansi(['\x1b[1mfoo', '\x1b[0m', 'bar\x1b[0m']) == 6
   

# Generated at 2022-06-23 18:28:56.648248
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from flutils import txtutils
    import textwrap


# Generated at 2022-06-23 18:29:08.612455
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:11.577138
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
test_len_without_ansi()



# Generated at 2022-06-23 18:29:24.229168
# Unit test for function len_without_ansi
def test_len_without_ansi():
    # pylint: disable=no-member
    from pytest import raises
    from typing import Sequence
    from .typedefs import TextSequence

    _text = '\\x1b[38;5;209mfoobar\\x1b[0m'
    assert len_without_ansi(_text) == 6
    assert len_without_ansi([]) == 0
    assert len_without_ansi(['']) == 0
    assert len_without_ansi(['', '']) == 0
    assert len_without_ansi([_text]) == 6
    assert len_without_ansi([_text, _text]) == 12

    with raises(TypeError):
        len_without_ansi(('foo',))  # type: ignore[arg-type]
    with raises(TypeError):
        len_without_ans

# Generated at 2022-06-23 18:29:36.248391
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:29:48.102384
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # Initialize wrapper
    wrapper = AnsiTextWrapper(
        width=40,
        initial_indent='\\x1b[1m\\x1b[38;2;123;225;0m',
        subsequent_indent='    ',
        expand_tabs=False,
        placeholder='\\x1b[38;2;240;0;0m...\\x1b[0m',
        max_lines=10
    )
    # Text to be wrapped

# Generated at 2022-06-23 18:29:55.254035
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:29:58.746622
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
# end test_len_without_ansi



# Generated at 2022-06-23 18:30:07.275262
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    from os import linesep as LSEP
    from textwrap import indent, dedent
    wrapper = AnsiTextWrapper(
        width=40, subsequent_indent='\\x1b[38;2;255;0;0m> \\x1b[0m'
    )

# Generated at 2022-06-23 18:30:18.341063
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:30.328836
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():

    # Test wrap when the width is zero
    wrapper = AnsiTextWrapper(width=0)
    text = 'Hello world!'
    try:
        wrapped_text = wrapper.wrap(text)
    except ValueError as exc:
        assert str(exc) == 'invalid width 0 (must be > 0)'
    else:
        print(wrapped_text)
        assert False

    # Test wrap when the width is less than zero
    wrapper = AnsiTextWrapper(width=-100)
    text = 'Hello world!'
    try:
        wrapped_text = wrapper.wrap(text)
    except ValueError as exc:
        assert str(exc) == 'invalid width -100 (must be > 0)'
    else:
        print(wrapped_text)
        assert False

    # Test wrap when the text contains no whitespace


# Generated at 2022-06-23 18:30:36.709393
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:38.246034
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi("foo") == 3



# Generated at 2022-06-23 18:30:46.133011
# Unit test for constructor of class AnsiTextWrapper

# Generated at 2022-06-23 18:30:47.815599
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper()
    assert wrapper.width == 70


# Generated at 2022-06-23 18:30:58.652619
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.txtutils import AnsiTextWrapper

# Generated at 2022-06-23 18:31:10.711705
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:22.687282
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:31.426287
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:31:34.396432
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import doctest
    doctest.testmod()


# https://stackoverflow.com/a/38321055/

# Generated at 2022-06-23 18:31:46.115304
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    # tests that the ansi codes are not included in the line length
    # Note, this does NOT test for correct line wrapping.
    # That's done in the 'test_txtutils' function.
    from flutils.txtutils import AnsiTextWrapper
    wrapper = AnsiTextWrapper(width=39)
    result = wrapper.wrap('\\x1b[1m\\x1b[31mFoo Bar\\x1b[0m')
    # result = ['\x1b[1m\x1b[31mFoo Bar\x1b[0m']
    assert result == ['\\x1b[1m\\x1b[31mFoo Bar\\x1b[0m']

# Generated at 2022-06-23 18:31:51.502778
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    """Unit test for constructor of class AnsiTextWrapper."""

    # Create an AnsiTextWrapper in the same way as a textwrap.TextWrapper
    # instance would be created
    AnsiTextWrapper()

    # But it can also be created using keyword arguments
    AnsiTextWrapper(width=60)



# Generated at 2022-06-23 18:32:03.813932
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    """
    Unit test for method fill of class AnsiTextWrapper

    """


# Generated at 2022-06-23 18:32:15.606761
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    wrapper = AnsiTextWrapper(width=20, initial_indent=' 1. ',
                              subsequent_indent=' \:: ')

# Generated at 2022-06-23 18:32:18.262864
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;209mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
    # TODO: Add more tests


# Generated at 2022-06-23 18:32:27.728201
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """
    Unit test for method :obj:`wrap` of class
    :obj:`~flutils.txtutils.AnsiTextWrapper`.

    """


# Generated at 2022-06-23 18:32:38.967338
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from io import StringIO
    from contextlib import redirect_stdout
    from flutils.txtutils import AnsiTextWrapper
    max_lines = 5
    width = 60

# Generated at 2022-06-23 18:32:50.675882
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import TextWrapper
    from random import choice, randrange
    from random import sample as random_sample
    from string import ascii_lowercase
    from string import digits
    from string import whitespace
    from string import punctuation
    from re import findall

    from flutils.txtutils import AnsiTextWrapper
    from flutils.txtutils import strip_ansi

    # Create a list of colored strings with ansi codes randomly inserted,
    # and also a list of the same strings, but with the ansi codes stripped.

# Generated at 2022-06-23 18:32:58.411856
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:33:10.568110
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    try:
        AnsiTextWrapper(-1)
        assert False
    except ValueError:
        pass
    try:
        AnsiTextWrapper(0)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-23 18:33:21.956014
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from flutils.colortext import ColorText

# Generated at 2022-06-23 18:33:33.255165
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)

    assert wrapper.initial_indent == ''
    assert wrapper.subsequent_indent == ''
    assert wrapper.placeholder == ' [...]'
    assert wrapper.width == 40
    assert wrapper.expand_tabs is True
    assert wrapper.replace_whitespace is True
    assert wrapper.fix_sentence_endings is False
    assert wrapper.break_long_words is True
    assert wrapper.drop_whitespace is True
    assert wrapper.break_on_hyphens is True
    assert wrapper.tabsize == 8
    assert wrapper.max_lines is None

    assert wrapper.initial_indent_len == 0
    assert wrapper.subsequent_indent_len == 0
    assert wrapper.placeholder_len == 6


# Generated at 2022-06-23 18:33:44.304495
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    """Unit test for the 'wrap' method of class AnsiTextWrapper."""
    import sys  # nosec
    # pylint: disable=unused-import
    try:
        import pytest  # type: ignore
    except ImportError:
        print('Pytest not installed. Skipping unit tests.', file=sys.stderr)  # pragma: no cover
        return

# Generated at 2022-06-23 18:33:53.146385
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:02.178292
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    ''' Unit test for method wrap of class AnsiTextWrapper '''

    # Get the name of this module
    mod_name = inspect.currentframe().f_code.co_name

    # Get the filename of this module
    mod_file = inspect.getfile(inspect.currentframe())

# Generated at 2022-06-23 18:34:04.886060
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('foobar') == 6
    assert len_without_ansi(['foo', 'bar']) == 6



# Generated at 2022-06-23 18:34:10.726099
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi(['\x1b[38;5;209m', 'foo', 'bar', '\x1b[0m']) == 6



# Generated at 2022-06-23 18:34:19.192236
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:30.872658
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:34:42.592574
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:34:52.352621
# Unit test for function len_without_ansi
def test_len_without_ansi():
    """Unit test for function len_without_ansi."""
    from flutils.txtutils import len_without_ansi
    text1 = '\x1b[38;5;209mfoobar\x1b[0m'
    text2 = '\x1b[38;5;209mfoobar'
    text3 = 'foobar\x1b[0m'
    text4 = 'foobar'
    assert len_without_ansi(text1) == 6
    assert len_without_ansi(text2) == 6
    assert len_without_ansi(text3) == 6
    assert len_without_ansi(text4) == 6



# Generated at 2022-06-23 18:35:03.734214
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    import io
    import sys
    import unittest
    import unittest.mock

    from flutils.txtutils import AnsiTextWrapper

    class TestAnsiTextWrapper(unittest.TestCase):

        def test_AnsiTextWrapper(self):

            def ansi_escape(value: str = '') -> AnyStr:
                return ("\x1b[%sm" % value) if value else "\x1b[0m"

            # Initialize the ansi_text variable

# Generated at 2022-06-23 18:35:13.033216
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:23.928281
# Unit test for function len_without_ansi
def test_len_without_ansi():
    assert len_without_ansi([]) == 0
    assert len_without_ansi('') == 0
    assert len_without_ansi(['', '', '']) == 0
    assert len_without_ansi(['\x1b[38;5;209m', 'foobar', '\x1b[0m']) == 6
    assert len_without_ansi('\x1b[38;5;209mfoobar\x1b[0m') == 6
    assert len_without_ansi(['foo', 'bar', 'baz']) == 9
    assert len_without_ansi('foobarbaz') == 9


# Generated at 2022-06-23 18:35:32.734259
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:42.893232
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:35:53.826428
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:02.436355
# Unit test for method fill of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:10.165235
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    import textwrap
    wrapper_1 = textwrap.TextWrapper(
        width=40,
        initial_indent='',
        subsequent_indent='',
        expand_tabs=True,
        replace_whitespace=True,
        fix_sentence_endings=False,
        break_long_words=True,
        drop_whitespace=True,
        break_on_hyphens=True,
        tabsize=4,
        max_lines=None,
        placeholder=' [...]'
    )


# Generated at 2022-06-23 18:36:19.732492
# Unit test for method wrap of class AnsiTextWrapper

# Generated at 2022-06-23 18:36:26.236470
# Unit test for method fill of class AnsiTextWrapper
def test_AnsiTextWrapper_fill():
    from textwrap import AnsiTextWrapper  # type: ignore


# Generated at 2022-06-23 18:36:29.603068
# Unit test for function len_without_ansi
def test_len_without_ansi():
    text = '\x1b[38;5;120mfoobar\x1b[0m'
    assert len_without_ansi(text) == 6
# end test_len_without_ansi



# Generated at 2022-06-23 18:36:41.050869
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    assert AnsiTextWrapper().width == 70
    assert AnsiTextWrapper().initial_indent == ''
    assert AnsiTextWrapper().subsequent_indent == ''
    assert AnsiTextWrapper().expand_tabs is True
    assert AnsiTextWrapper().replace_whitespace is True
    assert AnsiTextWrapper().fix_sentence_endings is False
    assert AnsiTextWrapper().break_long_words is True
    assert AnsiTextWrapper().drop_whitespace is True
    assert AnsiTextWrapper().break_on_hyphens is True
    assert AnsiTextWrapper().tabsize == 8
    assert AnsiTextWrapper().max_lines is None
    assert AnsiTextWrapper().placeholder == ' [...]'


# Generated at 2022-06-23 18:36:53.085643
# Unit test for constructor of class AnsiTextWrapper
def test_AnsiTextWrapper():
    wrapper = AnsiTextWrapper(width=40)

# Generated at 2022-06-23 18:37:04.005339
# Unit test for method wrap of class AnsiTextWrapper
def test_AnsiTextWrapper_wrap():
    from io import StringIO
    from unittest.mock import patch

    from flutils.txtutils import AnsiTextWrapper, ansi_wrap, ansi_fill
