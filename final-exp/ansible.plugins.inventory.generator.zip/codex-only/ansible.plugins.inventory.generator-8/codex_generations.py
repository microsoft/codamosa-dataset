

# Generated at 2022-06-23 10:46:56.705185
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert inventory
    assert 'verify_file' in dir(inventory)
    assert 'template' in dir(inventory)
    assert 'add_parents' in dir(inventory)
    assert 'parse' in dir(inventory)

# Generated at 2022-06-23 10:47:05.566481
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    """Unit test for method template of class InventoryModule"""
    invmod = InventoryModule()
    invmod.templar = C.get_configuration_definition().get_base_plugin('template')()
    invmod.templar.available_variables = {
        'key1': 'var1',
        'key2': 'var2',
    }
    assert invmod.template('{{ key1 }}_{{ key2 }}', {}) == 'var1_var2'
    assert invmod.template('|> {{ key1 }}_{{ key2 }}', {}) == 'var1_var2'

# Generated at 2022-06-23 10:47:14.636467
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory.vars = dict()
    inventory.templar = dict()
    #layers_dict = dict()
    layers_dict = dict()
    layers_dict['host1'] = 'localhost'
    layers_dict['host2'] = 'localhost'
    layers_dict['host3'] = 'localhost'
    config = dict()
    config['layers'] = dict()
    config['layers']['host1'] = ['10.0.0.1', '172.0.0.1']
    config['layers']['host2'] = ['10.0.0.2', '172.0.0.2']
    config['layers']['host3'] = ['10.0.0.3', '172.0.0.3']

# Generated at 2022-06-23 10:47:15.317384
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    pass

# Generated at 2022-06-23 10:47:23.549998
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import tempfile
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Load the inventory file in memory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=tempfile.mkstemp()[1])
    inventory_path = C.DEFAULT_LOCALHOST_PLUGIN_PATH[0]
    gen_inv = InventoryModule()
    gen_inv.parse(inventory, loader, inventory_path)

    def recursive_assert_group(parent, group_list):
        assert parent in group_list
        for group_name in group_list[parent]:
            group = group_list[group_name]
            assert group['parent'] == parent
            assert isinstance(group['children'], list)

# Generated at 2022-06-23 10:47:26.045963
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''Unit test for constructor of class InventoryModule'''
    # Pass
    print("\n\nTest 1/1: Run Unit test for constructor of class InventoryModule")
    my_plugin = InventoryModule()


# Generated at 2022-06-23 10:47:38.256629
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import unittest
    from ansible.plugins.loader import remove_plugin_from_loaders_list, add_all_plugin_dirs
    from ansible.parsing.vault import VaultLib

    add_all_plugin_dirs()
    # Load the plugin
    for plugin_loader in list(C.DEFAULT_INVENTORY_PLUGINS_PATH):
        try:
            plugin_loader.find_plugin('generator')
        except ValueError:
            remove_plugin_from_loaders_list(plugin_loader)

    class TestInventoryModule(unittest.TestCase):
        def test_template(self):
            # remove the plugin from plugin_loader as we want to create an instance of the plugin
            # without loading it
            remove_plugin_from_loaders_list(plugin_loader)


# Generated at 2022-06-23 10:47:46.549616
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    obj = InventoryModule()
    
    # This tests that a file that is not a config
    result = obj.verify_file('C:\\Users\\Arul\\Desktop\\test.txt')
    assert(result == False)
    
    # This tests that a config file with no extension is considered valid
    result = obj.verify_file('C:\\Users\\Arul\\Desktop\\test')
    assert(result == True)
    
    # This tests that a file with .config extension is valid
    result = obj.verify_file('C:\\Users\\Arul\\Desktop\\test.config')
    assert(result == True)
    
    # This tests that a yaml file with yaml extension is valid
    result = obj.verify_file('C:\\Users\\Arul\\Desktop\\test.yaml')

# Generated at 2022-06-23 10:47:52.651737
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()

    assert inventory_module.verify_file(
        os.path.join(C.DEFAULT_INVENTORY_PLUGIN_PATH, "generator.py")) == True
    assert inventory_module.verify_file("test_without_extension") == False
    assert inventory_module.verify_file("/tmp/inventory") == False
    assert inventory_module.verify_file("/tmp/inventory.config") == True

# Generated at 2022-06-23 10:48:00.854986
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    templates = [ '{{ operation }}', '{{ application }}', '{{ environment }}' ]

    inputs = [ {'operation': 'build', 'application': 'web', 'environment': 'dev'} ]

    expected_results = [ 'build', 'web', 'dev' ]

    results = []

    for input in inputs:
        for template in templates:
            results.append(InventoryModule().template(template, input))

    assert expected_results == results

# Generated at 2022-06-23 10:48:10.159630
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # Initialization
    from ansible.plugins.inventory import InventoryModule
    inventoryModule = InventoryModule()

    # Invalid extentions
    assert not inventoryModule.verify_file('unrecognized_extention.bad')
    assert not inventoryModule.verify_file('unknown_extention')
    assert not inventoryModule.verify_file('no_extention.')
    assert not inventoryModule.verify_file('no_extention_')

    # Valid extentions
    assert inventoryModule.verify_file('accepted_extention.yaml')
    assert inventoryModule.verify_file('accepted_extention.yml')
    assert inventoryModule.verify_file('accepted_extention.json')
    assert inventoryModule.verify_file('accepted_extention.config')

# Generated at 2022-06-23 10:48:21.687076
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import re
    import sys
    import __main__
    module_name = 'game_machines'
    if module_name in sys.modules:
        del sys.modules[module_name]
    sys.modules[module_name] = __main__

    inventory = {}
    inventory['_meta'] = {}
    inventory['_meta']['hostvars'] = {}
    item = {'parents': [{'name': '{{ region }}'}, {'name': '{{ application }}'}], 'name': '{{ region }}_{{ application }}_{{ server_type }}'}
    template_vars = {'region': 'ap-southeast-1', 'application': 'web', 'server_type': 'runner'}

    generator_obj = InventoryModule()
    generator_obj.templar = __main__
    generator

# Generated at 2022-06-23 10:48:23.025896
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    return inventory_module

# Generated at 2022-06-23 10:48:25.196578
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    plugin = InventoryModule()
    assert plugin.NAME == "generator"
    

# Generated at 2022-06-23 10:48:27.755720
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    if len(inventory.parse(None, None, "test")) > 0:
        print("Error: parse() takes 3 arguments, not 4")

# Generated at 2022-06-23 10:48:30.189938
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    module = InventoryModule()
    assert module.template("{{ one }} {{ two }} {{ one }}{{ two }}", {"one": "foo", "two": "bar"}) == "foo bar foobar"


# Generated at 2022-06-23 10:48:32.893447
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory = InventoryModule()
    template_values = {
        'first': 'hello',
        'second': 'world',
        'third': '!',
    }

    result = inventory.template("{{first}} {{second}}{{third}}", template_values)
    assert result == "hello world!"

# Generated at 2022-06-23 10:48:33.711685
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Should not throw an exception if executed without parameters
    InventoryModule()

# Generated at 2022-06-23 10:48:42.043212
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()

    file_path = "./test.yaml"
    os.system("touch " + file_path)
    actual_result = inventory_module.verify_file(file_path)
    assert actual_result == True
    os.system("rm " + file_path)

    file_path = "./test.yaml.config"
    os.system("touch " + file_path)
    actual_result = inventory_module.verify_file(file_path)
    assert actual_result == True
    os.system("rm " + file_path)

    file_path = "./test.config"
    os.system("touch " + file_path)
    actual_result = inventory_module.verify_file(file_path)
    assert actual_result == True
    os.system

# Generated at 2022-06-23 10:48:51.953140
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ''' unit test for method parse of class InventoryModule '''

    config = {'hosts': {'name': 'web_{{ server_type }}_{{ location }}'},
              'layers': {'server_type': ['web', 'app', 'db'], 'location': ['us-east-1', 'us-east-2']}}

    inventory = FakeInventory()
    loader = FakeLoader()
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, config, cache=False)


# Generated at 2022-06-23 10:48:58.212489
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    """ Unit test for method add_parents of class InventoryModule """
    from ansible.plugins.inventory import Inventory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    class InventoryModuleTest(InventoryModule):
        def template(self, pattern, variables):
            return pattern % variables


# Generated at 2022-06-23 10:49:00.554726
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule('localhost')
    assert isinstance(obj, InventoryModule)


# Generated at 2022-06-23 10:49:12.722983
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    # Test a good variable
    inventory = {}
    child = {'name': 'my_child'}
    parents = [
        {'name': 'my_parent', 'parents': [{'name': 'my_grandparent'},
                                          {'name': 'my_other_grandparent'}]},
        {'name': 'my_other_parent', 'parents': [{'name': 'my_other_grandparent'}]}
    ]
    template_vars = {'var': 'value'}

# Generated at 2022-06-23 10:49:13.561306
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()

# Generated at 2022-06-23 10:49:17.192520
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    m = InventoryModule()
    assert m.verify_file('inventory.config')
    assert m.verify_file('inventory.yaml')
    assert m.verify_file('inventory.yml')
    assert not m.verify_file('inventory.ymls')



# Generated at 2022-06-23 10:49:21.066839
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = object()
    loader = object()
    path = "path"
    cache = False
    plugin = InventoryModule()
    plugin.parse(inventory, loader, path, cache)

# Generated at 2022-06-23 10:49:30.146695
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.plugins.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(loader=DataLoader())
    gen = InventoryModule()

# Generated at 2022-06-23 10:49:39.424385
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    loader = DictDataLoader({})
    inv = InventoryManager(loader=loader, sources=[])
    for plugin in inv.inventory._get_plugins():
        if plugin.get_name() == 'generator':
            break
    generator = plugin()
    template_vars = {
        'operation': 'build',
        'environment': 'dev',
        'application': 'web'
    }
    result = generator.template("{{ operation }}_{{ application }}_{{ environment }}_runner", template_vars)
    assert result == "build_web_dev_runner"


from ansible import context
from ansible.inventory.manager import InventoryManager
from ansible.parsing.dataloader import DataLoader
from ansible.vars.manager import VariableManager
from ansible.template import Templar
from ansible.inventory.host import Host

# Generated at 2022-06-23 10:49:45.190763
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    inventory = InventoryModule()
    inventory.add_host("host1")

    # simple parent group
    parents = [
        {
            'name': '{{ name }}',
            'vars': {'name': '{{ name }}'}
        }
    ]
    inventory.add_parents(inventory.groups['all'], "host1", parents, {'name': "parent"})
    assert 'parent' in inventory.groups
    assert 'all' in inventory.groups['parent']._parents
    assert "host1" in inventory.groups['parent']._children
    assert 'name' in inventory.groups['parent']._vars

    # three level parent group with children at each level

# Generated at 2022-06-23 10:49:55.278085
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_path = 'test/hosts.config'
    inventry_cache = False

    # Primary test driver
    inventory_plugin = InventoryModule()
    test_inventory = inventory_plugin.parse(inventory_path)

    assert isinstance(test_inventory, dict)

    # Confirm expected groups exist
    assert test_inventory['groups'] is not None
    assert 'web_dev' in (test_inventory['groups'])
    assert test_inventory['groups']['web_dev']['vars'] is not None

    # Confirm expected hosts exist
    assert test_inventory['_meta']['hostvars'] is not None
    assert 'build_web_dev_runner' in (test_inventory['_meta']['hostvars'])

# Generated at 2022-06-23 10:50:00.960225
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.compat.tests import mock
    mock.patch.object(InventoryModule, 'add_parents')
    mock.patch.object(InventoryModule, 'template')
    instance = InventoryModule()
    result = instance.parse("inventory","loader","path","cache")
    assert False, "Missing unit test for method 'parse' of class 'InventoryModule'"

# Generated at 2022-06-23 10:50:02.661765
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule is not None, "Failed to import InventoryModule"


# Generated at 2022-06-23 10:50:13.024579
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import unittest2 as unittest
    from ansible.parsing import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    class TestInventoryModule(unittest.TestCase):
        def setUp(self):
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.inventory = Inventory(loader=self.loader, variable_manager=self.variable_manager, host_list=[])

        def tearDown(self):
            self.inventory = None

        def test_add_parents(self):
            generator = InventoryModule()

# Generated at 2022-06-23 10:50:19.513741
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert hasattr(InventoryModule, 'NAME')
    assert hasattr(InventoryModule, 'parse')
    assert hasattr(InventoryModule, 'verify_file')
    assert hasattr(InventoryModule, 'template')
    assert hasattr(InventoryModule, 'add_parents')
    assert hasattr(InventoryModule, 'parse')


# Generated at 2022-06-23 10:50:20.844075
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == 'generator'

# Generated at 2022-06-23 10:50:28.976410
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryModule()
    loader = DataLoader()
    path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'generator_test_inventory.config')
    config = inventory._read_config_data(path)
    assert config['layers'] == {
        'operation': ['build', 'launch'],
        'environment': ['dev', 'test', 'prod'],
        'application': ['web', 'api']
    }
    host = inventory.template(config['hosts']['name'], {
        'operation': 'build',
        'environment': 'dev',
        'application': 'web'
    })
    assert host == 'build_web_dev_runner'

# Generated at 2022-06-23 10:50:38.777057
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # this test requires ansible 2.6
    import ansible.plugins.inventory.generator
    plugin = ansible.plugins.inventory.generator.InventoryModule()
    # initializes a test inventory, with a path variable
    # because it's needed to read the config files
    test_inventory = ansible.plugins.inventory.InventoryModule()
    test_inventory._options['host_list'] = 'tests/inventory.config'
    test_inventory._options['cache'] = False
    test_inventory._options['plugin'] = 'generator'
    plugin.parse(test_inventory, None, 'tests/inventory.config', cache=False)
    runner_hosts = len(test_inventory.get_groups_dict()['runner']['hosts'])
    assert runner_hosts == 6
    # 3 layer x 2 layers x 1

# Generated at 2022-06-23 10:50:46.413613
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Creating an object of class InventoryModule
    from ansible.plugins.inventory.generator import InventoryModule
    inventorymodule_obj = InventoryModule()

    # Checking value of variable 'valid' when file_extension is config
    file_extension = ".config"
    if (file_extension in ['.config'] + C.YAML_FILENAME_EXTENSIONS):
        valid = True
    else:
        valid = False

    assert valid == True, "verify_file method is not returning the expected value."


# Generated at 2022-06-23 10:50:58.284084
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Create an InventoryModule object
    invmod = InventoryModule()

    # Create a BaseInventory object
    inventory = BaseInventory()
    invmod.add_parents(inventory, 'runner',\
        [{'name': '{{ operation }}_{{ application }}_{{ environment }}',\
        'parents': [{'name':'{{ operation }}_{{ application }}'},\
        {'name':'{{ application }}_{{ environment }}'}]},\
        {'name': 'runner'}],\
        {'operation': 'build', 'application': 'web', 'environment': 'dev'})

    # Execute function add_host and add_child from BaseInventory
    inventory.add_host('build_web_dev_runner')
    inventory.add_child('build_web_dev', 'build_web_dev_runner')



# Generated at 2022-06-23 10:51:00.564092
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory = InventoryModule()
    inventory.add_host("localhost")
    inventory.add_group("local")
    inventory.add_child("local","localhost")

# Generated at 2022-06-23 10:51:10.114488
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Test empty config
    path = 'tests/inventory_plugins/generator/empty_config.yml'
    result = InventoryModule().parse(inventory=None, loader=None, path=path, cache=False)
    assert result is None

    # Test empty config with empty layers
    path = 'tests/inventory_plugins/generator/empty_config_layers.yml'
    result = InventoryModule().parse(inventory=None, loader=None, path=path, cache=False)
    assert result is None

    # Test empty config with empty hosts
    path = 'tests/inventory_plugins/generator/empty_config_hosts.yml'
    result = InventoryModule().parse(inventory=None, loader=None, path=path, cache=False)
    assert result is None

    # Test bad hosts name

# Generated at 2022-06-23 10:51:20.678916
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    plugin = InventoryModule()

    # Create a mock inventory to pass in
    inventory = type('', (), {})()
    inventory.add_host = type('', (), {})()
    setattr(inventory.add_host, '__call__', lambda x : None)
    inventory.add_group = type('', (), {})()
    setattr(inventory.add_group, '__call__', lambda x : None)
    inventory.groups = {}
    inventory.add_child = type('', (), {})()
    setattr(inventory.add_child, '__call__', lambda x, y : None)


# Generated at 2022-06-23 10:51:26.084822
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import pytest, os
    test_cases = [
        # test_case, expected
        (1, False)
    ]
    for test_case, expected in test_cases:
        # arrange
        inventory_module = InventoryModule()
        test_path = 'test_path'

        # act
        actual = inventory_module.verify_file(test_path)

        # assert
        assert actual == expected


# Generated at 2022-06-23 10:51:38.629802
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # GIVEN
    inventory_module = InventoryModule()
    # WHEN
    #      file_type   #
    #      ----------  #
    #   1. config_file #
    #   2. yaml_file   #
    #   3. other_file  #
    config_file = "test.config"
    yaml_file = "test.yaml"
    other_file = "test.other"

    # THEN
    #  config_file, yaml_file are return True, other_file is return False
    assert inventory_module.verify_file(config_file) is True
    assert inventory_module.verify_file(yaml_file) is True
    assert inventory_module.verify_file(other_file) is False


# Generated at 2022-06-23 10:51:47.041393
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    #setup
    config = {
        'hosts': {
            'name': 'myhost_{{ op }}_{{ env }}_{{ app }}',
            'parents': [
                {
                    'name': 'mygroup_{{ env }}_{{ app }}',
                    'parents': [
                        {
                            'name': 'mygroup_{{ app }}',
                            'parents': [
                                {
                                    'name': 'mygroup_{{ env }}',
                                },
                            ],
                        },
                    ],
                },
            ],
        },
        'layers': {
            'op': ['boot', 'shutdown'],
            'env': ['dev', 'test', 'prod'],
            'app': ['web', 'api'],
        },
    }

    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-23 10:51:52.683038
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    plugin = InventoryModule()

    # Test file with YAML extension
    path = 'test_files/inventory.config'
    valid_file = plugin.verify_file(path)
    assert valid_file is True

    # Test non existent file
    path = 'test_files/foobar.config'
    valid_file = plugin.verify_file(path)
    assert valid_file is False

    # Test directory
    path = 'test_files/'
    valid_file = plugin.verify_file(path)
    assert valid_file is False

    # Test file with txt extension
    path = 'test_files/inventory.txt'
    valid_file = plugin.verify_file(path)
    assert valid_file is False

# Generated at 2022-06-23 10:52:00.194169
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # create instance of class InventoryModule
    inventory_module = InventoryModule()
    # create a fake inventory loader
    loader = FakeLoader()
    # create a fake inventory object
    inventory = FakeInventory()
    # call function parse of class InventoryModule
    inventory_module.parse(inventory, loader, None)
    # call function parse of class InventoryModule, with an error
    try:
        inventory_module.parse(inventory, loader, None)
    except Exception:
        pass
    # create and return a fake loader
    loader = FakeLoader.fakeLoader()

# Generated at 2022-06-23 10:52:08.546507
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory = InventoryModule()
    mock_inventory = MockInventory()
    inventory.add_parents(mock_inventory, "runner", [{"name": "{{ operation }}_{{ application }}_{{ environment }}"}], {"operation": "build", "application": "web", "environment": "prod"})
    assert mock_inventory.called == ['add_group', 'add_group', 'add_group']
    assert mock_inventory.args == [['build_runner'], ['build_web_runner'], ['build_web_prod_runner']]


# Generated at 2022-06-23 10:52:12.269574
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module = InventoryModule()
    assert inventory_module.template('{{ foo }}', {'foo': 'bar'}) == 'bar'

# Generated at 2022-06-23 10:52:13.365396
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """Unit Test for InventoryModule constructor"""

    InventoryModule()

# Generated at 2022-06-23 10:52:15.079814
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert inv_mod.NAME == 'generator'


# Generated at 2022-06-23 10:52:18.694901
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.template import Templar

    module = InventoryModule()
    module.templar = Templar(loader=None)
    assert module.template("{{ foo }}", {"foo": "bar"}) == "bar"
    assert module.template("{{ foo }}", {"foo": 5}) == "5"

# Generated at 2022-06-23 10:52:31.143676
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Test parse function of InventoryModule class with valid input"""
    # valid input as per the document
    host_name = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    name = "{{ operation }}_{{ application }}_{{ environment }}"
    name1 = "{{ operation }}_{{ application }}"
    name2 = "{{ application }}_{{ environment }}"
    name3 = "{{ operation }}"
    name4 = "{{ application }}"
    name5 = "{{ environment }}"
    name6 = "{{ application }}"
    name7 = "{{ environment }}"
    layers = {'application': ['web', 'api'], 'environment': ['dev', 'test', 'prod'], 'operation': ['build', 'launch']}

# Generated at 2022-06-23 10:52:37.818058
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory = InventoryModule()
    template_string = "{{ ansible_ssh_private_key_file }}"
    input_string = "/root/key"
    variables = {'ansible_ssh_private_key_file': input_string}
    output_string = inventory.template(template_string, variables)
    assert (output_string == input_string)

# Generated at 2022-06-23 10:52:47.038094
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    INVENTORY_FILENAME = 'inventory.config'

    inventory_path = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', '..', '..', 'test', 'unit', 'plugins',
        'inventory', INVENTORY_FILENAME))

    inventory = InventoryModule()
    inventory.parse( inventory, '', inventory_path, cache=False )
    inventory.parse( inventory, '', inventory_path, cache=False )

    assert inventory._plugin_options is not None
    assert inventory._option_cache is not None
    assert inventory._dict is not None
    assert inventory._hosts is not None
    assert inventory._loader is not None
    assert inventory._cache is not None
    assert inventory._loader is not None
    assert inventory.inventory is not None


# Generated at 2022-06-23 10:52:49.288307
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass



# Generated at 2022-06-23 10:52:57.837311
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()

    assert plugin.verify_file("/home/zhaoweiguo/ansible/inventory/inventory.config")
    assert plugin.verify_file("/home/zhaoweiguo/ansible/inventory/inventory.yml")
    assert plugin.verify_file("/home/zhaoweiguo/ansible/inventory/inventory.yaml")
    assert not plugin.verify_file("/home/zhaoweiguo/ansible/inventory/inventory.json")


# Generated at 2022-06-23 10:53:07.456721
# Unit test for method verify_file of class InventoryModule

# Generated at 2022-06-23 10:53:18.048654
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import pdb
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import inventory_loader

    plugin_name = os.path.splitext(os.path.basename(__file__))[0]

    class AnsibleOptions(object):
        verbosity = 0
        extra_vars = []
        connections = 'local'

        def __init__(self, **kwargs):
            self.__dict__.update(**kwargs)

    parser_options = AnsibleOptions(
        plugin_list=[plugin_name],
    )

    inventory = inventory_loader.get_inventory_plugin(parser_options)

    inventory._get_plugin_option = lambda x, y: None
    inventory._get_host_option = lambda x, y: None
    inventory._get

# Generated at 2022-06-23 10:53:29.615557
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import ansible.plugins.inventory.generator

    inventory = ansible.plugins.inventory.generator.InventoryModule()
    inventory.templar = ansible.parsing.dataloader.DataLoader()

    assert inventory.template('{{ a }}', {'a':'a'}) == 'a'
    print(inventory.template('{{ a }}{{ a }}', {'a': 'a'}))
    assert inventory.template('{{ a }}{{ a }}', {'a': 'a'}) == 'aa'
    assert inventory.template('{{ a }}{{ b }}', {'a': 'a'}) == 'a'
    assert inventory.template('{{ a.b }}', {'a': {'b': 'a'}}) == 'a'

# Generated at 2022-06-23 10:53:37.536180
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    plugin = inventory_module.NAME
    file_name, file_ext = 'inventory_file', '.config'
    inventory_file = '%s%s' % (file_name, file_ext)
    # Test with negative scenarios
    # verify_file should return false when plugin is not 'generator'
    assert inventory_module.verify_file(inventory_file) == False
    # Test with positive scenarios
    # verify_file should return false when plugin is 'generator' and file extension is not '.config' or '.yaml'
    inventory_module.NAME = plugin
    assert inventory_module.verify_file(file_name) == False
    # verify_file should return true when file extension is '.config' or '.yaml'
    inventory_module.NAME = plugin

# Generated at 2022-06-23 10:53:50.016807
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    m = InventoryModule()
    class Inventory(object):
        def __init__(self):
            self.vars = dict()
            self.groups = dict()

        def add_host(self, name):
            self.groups[name] = {}

        def get_host(self, name):
            return self.groups[name]
            
        def set_variable(self, name, value):
            self.vars[name] = value
            
        def add_group(self, name):
            self.groups[name] = {}

        def add_child(self, groupname, host):
            self.groups[groupname]['children'] = self.groups[groupname].get('children', []) + [host]
            
           
    class Loader(object):
        def get_basedir(self):
            return C

# Generated at 2022-06-23 10:54:00.974381
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    import os

    # If file extension is not .yml or .yaml
    test_object_1 = InventoryModule()
    test_object_1.path_to_yaml_file = 'C:\\Users\\user1\\Documents\\ansible_inventory\\inventory.txt'
    assert test_object_1.verify_file(test_object_1.path_to_yaml_file) == False

    # If file extension is .yml or .yaml
    test_object_2 = InventoryModule()
    test_object_2.path_to_yaml_file = 'C:\\Users\\user1\\Documents\\ansible_inventory\\inventory.yaml'
    assert test_object_2.verify_file(test_object_2.path_to_yaml_file) == True

    # If file name is not

# Generated at 2022-06-23 10:54:11.623121
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    class inventory:
        def __init__(self, config):
            self.config=dict(plugin='generator', layers=config)
    # Unit test 1
    config = dict(layers= dict(a=[1,2], b=['a', 'b']))
    inventory_obj = inventory(config)
    obj = InventoryModule()
    pattern = '{{a}}{{b}}'
    result_expected = ['1a', '1b', '2a', '2b']
    result = obj.template(pattern, inventory_obj)
    assert result == result_expected, "Test Case Failed: {} != {}".format(result, result_expected)
    # Unit test 2
    config = dict(layers= dict(a=[1,2], b=['a', 'b']))
    inventory_obj = inventory(config)
   

# Generated at 2022-06-23 10:54:24.565837
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-23 10:54:28.613611
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-23 10:54:39.373616
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    '''
    Unit test function for method add_parents of class InventoryModule
    '''
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    parent_host = Host('localhost')
    parent_host.vars = dict()
    parent_host_2 = Host('localhost')
    parent_host_2.vars = dict()
    parent_host_3 = Host('localhost')
    parent_host_3.vars = dict()

    group_1 = Group('group1')
    group_1.vars = dict()
    group_2 = Group('group2')
    group_2.vars = dict()
    group_3 = Group('group3')
    group_3.vars = dict()
    group_4 = Group('group4')
    group_4.vars

# Generated at 2022-06-23 10:54:43.986027
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

# Generated at 2022-06-23 10:54:53.835399
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import action_loader

    def mock_get_loader(name):
        from ansible.plugins.loader import module_loader
        return module_loader

    import ansible
    ansible.plugins.loader.get_loader = mock_get_loader

    inv=InventoryModule()

# Generated at 2022-06-23 10:55:00.329347
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Arrange
    inventory_module = InventoryModule()
    extension_filenames = ['.config'] + C.YAML_FILENAME_EXTENSIONS
    true_filenames = ["inventory.config"]
    false_filenames = ["inventory.txt"]

    # Act
    true_results = [inventory_module.verify_file(name) for name in true_filenames]
    false_results = [inventory_module.verify_file(name) for name in false_filenames]

    # Assert
    assert all(true_results) and not any(false_results)

# Generated at 2022-06-23 10:55:07.850574
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import os
    import copy
    import sys
    import tempfile

    # Pylint's static analysis can't see Ansible's dynamic import,
    # so we need to disable the warning
    # pylint: disable=import-error
    from ansible.parsing.dataloader import DataLoader

    # Create a tempory directory
    tmpdir = tempfile.mkdtemp()

    # Create a tempory file
    script_file = tempfile.NamedTemporaryFile(dir=tmpdir, prefix="test_InventoryModule_", delete=False)

# Generated at 2022-06-23 10:55:12.273362
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import yaml

    yaml_data = yaml.safe_load(EXAMPLES)
    inventory = {}
    loader = None
    path = 'inventory.config'
    plugin = InventoryModule()
    plugin.parse(inventory, loader, path)
    assert inventory == yaml_data

# Generated at 2022-06-23 10:55:21.815093
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.plugins.inventory import generate_inventory_plugin_class
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from jinja2 import Template
    from io import StringIO


# Generated at 2022-06-23 10:55:30.359279
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Create a mock inventory object
    class MockInventory:
        def __init__(self):
            self.groups = dict()

        def add_group(self, name):
            self.groups[name] = MockGroup(name)

        def add_child(self, parent, child):
            self.groups[parent].add_child(child)

        def add_host(self, name):
            self.groups[name] = MockGroup(name)

    # Create a mock group object
    class MockGroup:
        def __init__(self, name):
            self.name = name
            self.children = []
            self.variables = {}

        def add_child(self, child):
            self.children.append(child)


# Generated at 2022-06-23 10:55:38.038337
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()

    config = {'hosts': {'name': 'test_case', 'parents': [{'name': '{{ operation }}'}]}, 'layers': {'operation': ['build']}}
    inventory = BaseInventoryPlugin()
    inventory.variable_manager = variable_manager
    inventory.loader = loader

    inventory.add_host(config['hosts']['name'])
    InventoryModule.add_parents(inventory, config['hosts']['name'], config['hosts']['parents'], config['layers'])

    assert 'build' in inventory.groups
    assert inventory.groups['build'].hosts == ['test_case']

# Generated at 2022-06-23 10:55:44.364644
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # pylint: disable=too-many-locals
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["file:/tmp/inventory.config"])
    variables = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variables)

    # create example config file
    example_file = open("/tmp/inventory.config", "wb")
    example_file.write(to_bytes(EXAMPLES))
    example_file.close()
    # read config file


# Generated at 2022-06-23 10:55:53.697020
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    # FIXME: This has to be refactored
    # These are just inline tests to get it working.
    # A proper set of unit tests should be added
    import os
    import sys
    import ansible
    from ansible.utils.vars import load_extra_vars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.errors import AnsibleParserError

    def check(data, expected_hosts, expected_groups):
        assert sorted(data['hosts']) == sorted(expected_hosts)
        assert sorted(data['_meta']['hostvars']) == sorted(expected_hosts)
        assert sorted(data['groups']) == sorted(expected_groups)

   

# Generated at 2022-06-23 10:55:58.299814
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import ansible.plugins.inventory.generator as generator
    _module = generator.InventoryModule()
    test_output = _module.template("{{ key1 }}_{{ key2 }}", {"key1":"value1", "key2":"value2"})
    assert test_output == "value1_value2"

# Generated at 2022-06-23 10:56:05.286068
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    wdir_parent = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(wdir_parent, "data/inventory/layers.config")
    plugin = InventoryModule()
    inventory = plugin.parse(inventory=None, loader=None, path=path)
    assert len(inventory.groups) == 11
    assert len(inventory.hosts) == 6
    assert list(inventory.hosts.keys()) == ['build_web_dev_runner', 'build_web_test_runner', 'build_web_prod_runner', 'build_api_dev_runner', 'build_api_test_runner', 'build_api_prod_runner']

# Generated at 2022-06-23 10:56:08.377262
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    # Test data
    pattern = "{{ operation }}{{ environment }}{{ application }}"
    variables = {'operation': 'build', 'environment': 'dev', 'application': 'web'}

    # Create object of class InventoryModule
    inventory_module = InventoryModule()

    # Test template method of InventoryModule to return the evaluated value of
    # pattern with template variables
    assert inventory_module.template(pattern, variables) == "builddevweb"

# Generated at 2022-06-23 10:56:12.400377
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    # Create a dictionary of layer variables
    template_vars = {
        "layer1": "value1",
        "layer2": "value2",
        "layer3": "value3"
    }

    # Create an instance of the class with a template pattern
    test_instance = InventoryModule()
    test_instance.templar = {}
    test_instance.templar.do_template = {}

    # Call the template method and verify it returns the expected value
    pattern = "{{ layer1 }}_{{ layer2 }}_{{ layer3 }}"
    expected = "value1_value2_value3"
    actual = test_instance.template(pattern, template_vars)
    assert expected == actual


# Generated at 2022-06-23 10:56:21.498685
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    class Inventory:
        def __init__(self):
            self.groups = {}
        def add_group(self, group):
            self.groups[group] = InventoryGroup(group)
        def add_child(self, child, parent):
            self.groups[parent].add_child(child)
    class InventoryGroup:
        def __init__(self, name):
            self.name = name
            self.children = []
            self.vars = {}
        def add_child(self, child_name):
            self.children.append(child_name)
        def set_variable(self, key, value):
            self.vars[key] = value
    class InventoryModuleTest:
        def __init__(self):
            self.templar = dict()

# Generated at 2022-06-23 10:56:31.254346
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    from ansible.parsing.yaml.objects import AnsibleUnicode

    inventory = dict()
    inventory['groups'] = dict()
    inventory['children'] = dict()

    def assert_in(obj, collection):
        assert obj in collection

    def add_group(name):
        inventory['groups'][name] = dict()
        inventory['groups'][name]['vars'] = dict()

    def add_child(parent, child):
        if parent not in inventory['children']:
            inventory['children'][parent] = list()
        inventory['children'][parent].append(child)

    def set_variable(group, key, value):
        inventory['groups'][group]['vars'][key] = value

    module = InventoryModule()
    module.add_group = add_group
    module.add_

# Generated at 2022-06-23 10:56:38.827099
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    class MockConfigParser:

        def __init__(self, path=None):
            pass

        def _read_config_data(self, path):
            return eval(open(path).read())

    class MockDataLoader:

        pass

    class MockVarsManager:

        def add_host_vars_from_inventory(self, host, inventory):
            pass

    class MockInventory:

        def __init__(self):
            self.groups = dict()

        def add_host(self, host):
            self.host = host

        def add_group(self, group):
            self.groups[group] = dict(vars=dict(), hosts=list())

        def add_child(self, group, child):
            self.groups[group]['hosts'].append(child)

    # Parsing inventory.config

# Generated at 2022-06-23 10:56:48.191613
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    import os
    import sys
    import inspect

    script_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    inv_module_dir = os.path.dirname(os.path.abspath(inspect.getfile(InventoryModule)))

    sys.path.append(script_dir)

    import test_utils

    InventoryModule.templar = test_utils.dummy_templar()

    script_realpath = os.path.realpath(os.path.join(script_dir, "../../lib/ansible"))
    if os.path.exists(os.path.join(script_realpath, '__init__.py')):
        sys.path.insert(0, script_realpath)
    else:
        sys

# Generated at 2022-06-23 10:56:49.291538
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule



# Generated at 2022-06-23 10:56:54.048669
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory = InventoryModule()
    inventory.templar = UnitTestTemplar()
    template_vars = {'operation': 'build', 'application': 'web', 'environment': 'dev'}
    output = inventory.template('{{ operation }}_{{ application }}_{{ environment }}_runner', template_vars)
    assert output == 'build_web_dev_runner'
