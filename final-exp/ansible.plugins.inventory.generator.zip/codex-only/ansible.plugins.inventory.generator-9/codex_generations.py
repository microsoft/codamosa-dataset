

# Generated at 2022-06-23 10:46:59.654625
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import sys
    import os
    import unittest

    from ansible.plugins.loader import InventoryLoader

    class InventoryTestCase(unittest.TestCase):
        def setUp(self):
            import ansible.plugins.inventory as inventory
            self.tmpdir = os.path.realpath(os.path.join(os.path.dirname(__file__), '../test/test_inventory_module'))
            self.loader = InventoryLoader()

        def tearDown(self):
            pass

        def test_add_parents(self):
            my_test_conf_file = os.path.join(self.tmpdir, 'test_inventory_module.yml')
            inventory = inventory.Inventory('localhost')
            im = InventoryModule()

# Generated at 2022-06-23 10:47:05.113778
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader

    inv_source = inventory_loader.get('generator')
    inv = inv_source.parse(path=None, cache=False)

    #assert all variables set in inventory
    assert(inv['all']['vars']['application'] == 'api')
    assert(inv['all']['vars']['environment'] == 'test')
    assert(inv['all']['vars']['operation'] == 'launch')

    #assert all group memberships
    assert(inv['api']['hosts'].keys() == ['launch_api_test_runner'])
    assert(inv['test']['hosts'].keys() == ['launch_api_test_runner'])

# Generated at 2022-06-23 10:47:17.158442
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import ansible.plugins.inventory
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    inventory_module = ansible.plugins.inventory.InventoryModule()

    # init `templar` attribute
    inventory_module.templar = Templar(loader=loader, variables=variable_manager)

    # Instantiate InventoryModule class and call it's `template` method
    test_class = InventoryModule()

    # test_vars = {'foo': 'bar', 'bar': 'foo'}
    # result_

# Generated at 2022-06-23 10:47:19.009628
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # testing init
    obj = InventoryModule()
    assert issubclass(obj.__class__, BaseInventoryPlugin), "failed to initiate InventoryModule"

# Generated at 2022-06-23 10:47:19.882172
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file()

# Generated at 2022-06-23 10:47:29.302065
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    def dict_to_host(hdict):
        h = Host(hdict['name'])
        h.vars = hdict['vars']
        return h

    def dict_to_group(gdict):
        g = Group(gdict['name'])
        g.vars = gdict['vars']
        return g

    inventory = dict_to_group({'name': 'g0', 'vars': {}})
    child = dict_to_host({'name': 'h0', 'vars': {}})
    # test multiple groups with different depth

# Generated at 2022-06-23 10:47:41.021179
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    import tempfile

    def write_file(path, text):
        with open(path, "w") as f:
            f.write(text)

    # Test successful call
    # config.config
    try:
        tmpdir = tempfile.mkdtemp()
        try:
            input_file = os.path.join(tmpdir, 'config.config')
            write_file(input_file, 'YAML')
            result = InventoryModule().verify_file(input_file)
            assert result == True
        finally:
            # Remove directory
            shutil.rmtree(tmpdir)
    except:
        assert False

    # Test successful call
    # config.yml

# Generated at 2022-06-23 10:47:45.213508
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    result = inventory_module.verify_file("inventory.config")
    assert result == True

# Generated at 2022-06-23 10:47:54.883678
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    try:
        from ansible.playbook.play import Play
    except Exception as e:
        raise ImportError("test_InventoryModule_add_parents requires ansible_playbook_play")
    try:
        from ansible.vars import VariableManager
    except Exception as e:
        raise ImportError("test_InventoryModule_add_parents requires ansible_vars")
    

# Generated at 2022-06-23 10:48:07.992874
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Create a generator.InventoryModule object for testing
    inventory_module_object = InventoryModule()
    inventory_module_object.inventory_basedir = os.path.join(os.path.dirname(os.path.abspath(__file__)))

    # Test config file with valid extension
    path_yaml = os.path.join(inventory_module_object.inventory_basedir, 'files', 'inventory.config')
    result_yaml = inventory_module_object.verify_file(path_yaml)
    assert result_yaml is True

    # Test config file with no extension
    path_noext = os.path.join(inventory_module_object.inventory_basedir, 'files', 'inventory.yml')
    result_noext = inventory_module_object.verify_file(path_noext)

# Generated at 2022-06-23 10:48:14.005681
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    plugin = InventoryModule()

    assert plugin.NAME == 'generator'
    assert plugin.verify_file('inventory.config')
    assert plugin.verify_file('inventory.yml')
    assert not plugin.verify_file('inventory.yaml')
    assert not plugin.verify_file('inventory.txt')
    assert not plugin.verify_file('inventory')
    assert not plugin.verify_file('')



# Generated at 2022-06-23 10:48:16.633216
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_instance = InventoryModule()
    assert inventory_module_instance.verify_file('/root/test.config') == True

# Generated at 2022-06-23 10:48:27.118793
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from collections import namedtuple
    from unittest import TestCase

    class GroupMock(object):
        def __init__(self, name):
            self.name = name
            self.nested_groups = list()
            self.vars = dict()

        def set_variable(self, name, value):
            self.vars[name] = value

    class InventoryMock(object):
        def __init__(self):
            self.hosts = dict()
            self.groups = dict()

        def add_host(self, hostname):
            if hostname not in self.hosts:
                self.hosts[hostname] = GroupMock(hostname)

        def add_group(self, groupname):
            if groupname not in self.groups:
                self.groups[groupname] = GroupM

# Generated at 2022-06-23 10:48:35.183342
# Unit test for method verify_file of class InventoryModule

# Generated at 2022-06-23 10:48:44.008984
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    ''' Test of the verify_file method of class InventoryModule.
    '''
    invmodule = InventoryModule()
    assert invmodule.verify_file('inventory.config') == True
    assert invmodule.verify_file('inventory.yml') == True
    assert invmodule.verify_file('inventory.yaml') == True
    assert invmodule.verify_file('inventory') == True
    assert invmodule.verify_file('inventory.conf') == False

# Generated at 2022-06-23 10:48:48.817681
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    # Arrange
    generator = InventoryModule()
    template = '{{ foo.bar }}'
    variables = {'foo': {'bar': 42}}
    expected = '42'

    # Act
    actual = generator.template(template, variables)

    # Assert
    assert actual == expected



# Generated at 2022-06-23 10:48:51.382467
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' constructor of class InventoryModule '''

    obj = InventoryModule()
    assert obj is not None, "Failed to build InventoryModule object"

# Generated at 2022-06-23 10:48:59.277139
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Create an inventory module object
    inventory_module = InventoryModule()

    # Create an inventory object
    inventory = InventoryModule()

    # Create the template variables
    template_vars = {
        'operation': 'build',
        'environment': 'dev',
        'application': 'web',
        'env': 'dev'
    }

    # Create a sample host object
    host = 'build_web_dev_runner'

    # Create a parent object

# Generated at 2022-06-23 10:49:06.151365
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.inventory import Inventory

    inventory_path = './tests/inventory.config'
    inventory_module = InventoryModule()
    inventory_object = Inventory(loader=None, variable_manager=None, host_list=None)
    inventory_module.parse(inventory_object, loader=None, path=inventory_path)
    assert len(inventory_object.groups) == 12

# Generated at 2022-06-23 10:49:16.199747
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create an inventory module object
    im = InventoryModule()

    # Create an inventory object
    i = BaseInventoryPlugin()

    # Create a loader object
    l = BaseInventoryPlugin()

    # Create a sample configuration file

# Generated at 2022-06-23 10:49:20.014657
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import tempfile
    import os
    
    temp_dir = tempfile.mkdtemp()
    file = os.path.join(temp_dir, 'inventory.config')

# Generated at 2022-06-23 10:49:29.727857
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    fd, path = tempfile.mkstemp()

# Generated at 2022-06-23 10:49:39.194277
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.data import InventoryData
    from ansible.playbook.play import Play
    import os
    import sys

    # Create a host object
    host_obj = Host('localhost')

    # Create a group object
    group_obj = Group()
    group_obj.add_host(host_obj)

    # read inventory file
    filename = os.path.join(sys.path[0], 'inventory.config')
    with open(filename) as f:
        host_data = f.read()
    # Create inventory data object
    inventory_data_

# Generated at 2022-06-23 10:49:44.066225
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    inventory.verify_file = "inventory.config"
    inventory.template = "{{operation}}_{{application}}_{{environment}}"
    inventory.add_parents = "{{operation}}_{{environment}}"
    inventory.parse = "{{operation}}__{{application}}__{{environment}}"

    assert inventory.verify_file == "inventory.config"
    assert inventory.template == "{{operation}}_{{application}}_{{environment}}"
    assert inventory.add_parents == "{{operation}}_{{environment}}"
    assert inventory.parse == "{{operation}}__{{application}}__{{environment}}"

# Generated at 2022-06-23 10:49:50.204072
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory = InventoryModule()
    inventory.templar = Any
    pattern = "{{ operation }}_{{ application }}_{{ environment }}"
    variables = {'operation': 'build', 'application': 'web', 'environment': 'dev'}
    assert inventory.template(pattern, variables) == 'build_web_dev'


# Generated at 2022-06-23 10:49:51.898311
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inv_m = InventoryModule()
    dict = dict()
    dict['variable'] = "myvar"
    pattern = "{{ variable }}"
    assert inv_m.template(pattern, dict) == "myvar"

# Generated at 2022-06-23 10:49:53.349865
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    mod = InventoryModule()
    assert mod.verify_file("/tmp/inventory.config") == True
    assert mod.verify_file("/tmp/inventory.yaml") == True

# Generated at 2022-06-23 10:50:01.901508
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    ''' test template method of InventoryModule '''

    # When
    mock_templar = MagicMock()
    mock_variables = {'key': 'value'}
    mock_pattern = 'template {{ key }}'
    mm = InventoryModule()
    mm.templar = mock_templar
    mm.template(mock_pattern, mock_variables)

    # Then
    mock_templar.do_template.assert_called_once_with(mock_pattern)
    mock_templar.available_variables = mock_variables

# Generated at 2022-06-23 10:50:02.574323
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass

# Generated at 2022-06-23 10:50:12.990849
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    ''' Unit test for InventoryModule.add_parents() '''

    from ansible.inventory.group import Group  # pylint: disable=import-error
    from ansible.inventory.host import Host  # pylint: disable=import-error

    config = dict()

    config['hosts'] = dict()
    config['hosts']['name'] = "{{ operation }}_{{ application }}_{{ environment }}_runner"

# Generated at 2022-06-23 10:50:24.008627
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}

    # _read_config_data returns a dictionary with the following structure:
    # {'hosts': {'name': '', 'vars': {}, 'parents': {'name': '', 'parents': []}}}
    # Note that 'vars' and 'parents' are optional, and that the list of parents has the same structure as the hosts variable,
    # meaning that you can have a list of parents with a list of parents, etc.
    # For the sake of the test, we will assume the dictionary alreay contains the optional variables.

    # We will test the case where there are no hosts, no layers, no parents, and no vars.
    config = {'hosts': {'name': '', 'vars': {}, 'parents': {'name': '', 'parents': []}}, 'layers': {}}
    decode

# Generated at 2022-06-23 10:50:35.369994
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    module = InventoryModule()

    # Simple pattern and vars
    assert module.template('{{ a }}_{{ b }}', {'a': 'avar', 'b': 'bvar'}) == 'avar_bvar'

    # Pattern with conditional and vars
    assert module.template('{{ a }}_{{ b if c==1 }}', {'a': 'avar', 'b': 'bvar', 'c': 1}) == 'avar_bvar'
    assert module.template('{{ a }}_{{ b if c==1 }}', {'a': 'avar', 'b': 'bvar', 'c': 2}) == 'avar_'

    # Pattern and vars with ascii chars
    assert module.template('{{ a }}_{{ b }}', {'a': 'avar', 'b': 'bvár'})

# Generated at 2022-06-23 10:50:43.295274
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Load inventory
    im = InventoryModule()
    
    # Create temporary inventory file
    tmp_inv_file = NamedTemporaryFile(suffix=".yml", delete=False)

# Generated at 2022-06-23 10:50:47.983508
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """ Unit test for method verify_file of class InventoryModule"""
    inventory_module = InventoryModule()
    path = "./test.config"
    assert inventory_module.verify_file(path)
    assert not inventory_module.verify_file("./test.conf")
    assert not inventory_module.verify_file("./test.yaml")


# Generated at 2022-06-23 10:50:49.420733
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert isinstance(obj, InventoryModule)

# Generated at 2022-06-23 10:51:01.312541
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    import jinja2

    from ansible.template import Templar

    env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    templar = Templar(loader=None, variables={})

    testee = InventoryModule()
    testee.templar = templar

    actual = testee.template('{{foo|bar}}', dict(foo='hello'))
    assert actual == 'hello', 'UNEXPECTED VALUE OF %s' % actual

    actual = testee.template('{% set foo = "bar" %}{{foo|bar}}', dict(foo='hello'))
    assert actual == 'hello', 'UNEXPECTED VALUE OF %s' % actual

    actual = testee.template('{% set foo = "bar" %}{{foo}}', dict())

# Generated at 2022-06-23 10:51:10.439475
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import ansible.plugins.inventory as inventory
    import ansible.plugins.loader as loader
    import ansible.template as template
    import ansible.vars.manager as manager
    import ansible.vars.unsafe_proxy as unsafe_proxy

    c = inventory.InventoryModule()

    c.templar = template.AnsibleTemplar(
        loader=loader.DataLoader(),
        variables=manager.VariableManager(loader=loader.DataLoader(), inventory=inventory.Inventory()),
        fail_on_undefined=True)

    assert c.template('{{ foobar }}', { 'foobar': 'ok' }) == 'ok'
    assert c.template('{{ foobar }}', { 'foobar': ['ok'] }) == 'ok'

# Generated at 2022-06-23 10:51:20.980890
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import pytest

    # Calling add_parents with a parent key that has no name key
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.inventory import BaseInventoryPlugin
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError

    config = {'hosts': {'name': 'test', 'parents': [{}]}}
    data_loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 10:51:24.745729
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_data = """myhost-00.example.com   myhost-01.example.com"""
    inventory = InventoryModule()
    loader = AnsibleVaultEncryptedUnicode()
    path = '/path/to/hostfile'

    inventory.parse(inventory, loader, path, cache=True)

# Generated at 2022-06-23 10:51:30.949588
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    from ansible.parsing.dataloader import DataLoader
    inventory_module = InventoryModule()
    path = "./plugins/inventory/generator.py"
    assert inventory_module.verify_file(path)
    path = "./plugins/inventory/generator.pyc"
    assert inventory_module.verify_file(path)
    path = "./plugins/inventory/plugin.yml"
    assert inventory_module.verify_file(path)
    path = "./plugins/inventory/plugin.config"
    assert inventory_module.verify_file(path)
    path = "./plugins/inventory/plugin.yaml"
    assert inventory_module.verify_file(path)
    path = "./plugins/inventory/README"
    assert not inventory_module.verify_file

# Generated at 2022-06-23 10:51:42.130212
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Create a config object
    config_object = InventoryModule()

    # Create a fake path for the file name
    test_file_name_1 = os.path.join('test_path_1', 'test_file.config')

    # Create a fake path for the file name
    test_file_name_2 = os.path.join('test_path_2', 'test_file.yaml')

    # Create a fake path for the file name
    test_file_name_3 = os.path.join('test_path_3', 'test_file.yml')

    # Create a fake path for the file name
    test_file_name_4 = os.path.join('test_path_4', 'test_file')

    # Create a fake path for the file name
    test_file_name_5 = os.path

# Generated at 2022-06-23 10:51:45.223915
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    assert inv.verify_file('inventory.config')
    assert inv.verify_file('inventory.yml')
    assert inv.verify_file('inventory.yaml')
    assert not inv.verify_file('inventory')


# Generated at 2022-06-23 10:51:55.781645
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import os
    import sys
    import json
    import unittest

    # Fake inv_path.
    tmp_file = None
    INV_PATH = '/tmp/inventory.config'

# Generated at 2022-06-23 10:51:57.017639
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import pytest
    with pytest.raises(TypeError):
        InventoryModule()

# Generated at 2022-06-23 10:52:00.830098
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    class Inventory:
        def __init__(self):
            self.groups = {}
            self.hosts = {}

        def add_group(self, groupname):
            groups[groupname] = groupname

        def add_host(self, hostname):
            self.hosts[hostname] = hostname

        def add_child(self, groupname, child):
            self.groups[groupname][child] = child

    inventory = Inventory()
    module = InventoryModule()

    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')


# Generated at 2022-06-23 10:52:13.052972
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    '''
    Uses a YAML configuration file with a valid YAML or C(.config) extension to define var expressions and group conditionals
    Create a template pattern that describes each host, and then use independent configuration layers
    Every element of every layer is combined to create a host for every layer combination
    Parent groups can be defined with reference to hosts and other groups using the same template variables
    '''
    # Adds parents to specified child and its parents
    #
    # Args:
    #    inventory (Inventory): reference to the inventory object
    #    child (Host | Group): the child to add parents to
    #    parents (list): list of parent groups that should be added
    #    template_vars (dict): dictionary of variables created from the layers
    #
    # Returns:
    #    None
    # Example:
    #    If the group

# Generated at 2022-06-23 10:52:22.153355
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inv_mod = InventoryModule()
    emp_dict = {}
    assert inv_mod.template("{{test}}", emp_dict) == None
    assert inv_mod.template("{{test}}", {"test" : "test"}) == "test"
    assert inv_mod.template("test", {"test" : "test"}) == "test"
    assert inv_mod.template("test_{{test}}", {"test" : "test"}) == "test_test"
    assert inv_mod.template("test_{{test}}", {"test" : "test"}) == "test_test"
    assert inv_mod.template("{{test}}_{{test}}", {"test" : "test"}) == "test_test"

# Generated at 2022-06-23 10:52:29.951194
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    import tempfile

    plugin = InventoryModule()

    fd, filename = tempfile.mkstemp()
    try:
        os.close(fd)

        assert plugin.verify_file(filename) == True
        assert plugin.verify_file(filename + '.config') == True
        assert plugin.verify_file(filename + '.yaml') == True
        assert plugin.verify_file(filename + '.yml') == True
        assert plugin.verify_file(filename + '.json') == True

    finally:
        os.remove(filename)

# Generated at 2022-06-23 10:52:36.353445
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='inventory.config')

    inventory.parse_inventory(inventory)


# Generated at 2022-06-23 10:52:37.867700
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.NAME == 'generator'


# Generated at 2022-06-23 10:52:41.075392
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_module = InventoryModule()
    assert inv_module.verify_file("/tmp/foo.config")
    assert not inv_module.verify_file("/tmp/foo.txt")

# Generated at 2022-06-23 10:52:48.728464
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    class TestInventory():
        def __init__(self):
            self.groups = {}
        def add_group(self, name):
            self.groups[name] = {}
        def add_child(self, child_name, parent_name):
            self.groups[child_name][parent_name] = True
        def set_variable(self, key, value):
            self.groups[key] = value

    test_inventory = TestInventory()
    test_vars = {'a': 'b'}
    test_parents = [{'name': 'a'}, {'name': '{{ a }}'}]
    test_inventory_module = InventoryModule()

    assert isinstance(test_inventory_module, InventoryModule)

# Generated at 2022-06-23 10:52:52.945130
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.inventory.data import InventoryData
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    inventory = InventoryData()
    templar = Templar(loader=None, variables={},
                      shared_loader_obj=None,
                      basedir=None,
                      run_adds=False,
                      fail_on_undefined=True,
                      disable_lookups=False,
                      disable_lookup_plugins=False,
                      no_log=False,
                      play_context=PlayContext())
    im = InventoryModule()
    im.templar = templar

# Generated at 2022-06-23 10:52:54.930381
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.NAME == 'generator'

# Generated at 2022-06-23 10:53:03.329684
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()

    # Test when file extension is YAML
    assert inventory.verify_file("./plugins/inventory/generator.yaml") == True

    # Test when file extension is yml
    assert inventory.verify_file("./plugins/inventory/generator.yml") == True

    # Test when file extension is config
    assert inventory.verify_file("./plugins/inventory/generator.config") == True

    # Test when file extension is None
    assert inventory.verify_file("./plugins/inventory/generator") == True

    # Test when file extension is txt
    assert inventory.verify_file("./plugins/inventory/generator.txt") == False


# Generated at 2022-06-23 10:53:16.002655
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class MockInventory(object):
        def __init__(self):
            self.groups = dict()
            self.hosts = dict()

        def add_group(self, name):
            self.groups[name] = dict()
            return self.groups[name]

        def add_host(self, name):
            self.hosts[name] = dict()
            return self.hosts[name]

        def add_child(self, group, host):
            self.groups[group][host] = dict()

    im = InventoryModule()
    im._read_config_data = lambda path: dict()


# Generated at 2022-06-23 10:53:28.240754
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    #global DOCUMENTATION
    import os
    import sys
    import inspect
    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    cwd = os.getcwd()

    os.chdir(cwd)

# Generated at 2022-06-23 10:53:36.995336
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    group = InventoryManager(loader=loader, sources=["tests/generator.config"])
    groups_dict = group.groups
    vars_manager = VariableManager(loader=loader, inventory=group)

# Generated at 2022-06-23 10:53:47.700513
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inv = InventoryModule()
    assert inv.template('{{ a }}', dict(a = 'b')) == 'b'
    assert inv.template('{{ a }}_{{ b }}', dict(a = 'x', b = 'y')) == 'x_y'
    assert inv.template('{{ b }}_{{ a }}', dict(a = 'x', b = 'y')) == 'y_x'
    try:
        inv.template('{{ b }}_{{ a }}', dict(a = 'x'))
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleParserError)


# Generated at 2022-06-23 10:53:50.858832
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    i = InventoryModule()
    assert i.verify_file('/tmp/junk.config') is True
    assert i.verify_file('/tmp/junk.ini') is False
    assert i.verify_file('/tmp/junk.yaml') is True
    assert i.verify_file('/tmp/junk.yml') is True

# Generated at 2022-06-23 10:54:01.523253
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.templar = AnsibleMockTemplar()
#   inv.inventory = ansible.vars.hosts.Inventory()
#   inv.inventory.vars = {}

# Generated at 2022-06-23 10:54:11.782819
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    loader = DictDataLoader({'inventory.config': 'plugin: generator\n'
                                                 'hosts:\n'
                                                 '  name: "{{ foo }}"\n'
                                                 '  parents:\n'
                                                 '    - name: "{{ bar }}"\n'
                                                 'layers:\n'
                                                 '  foo: [a, b, c]\n'
                                                 '  bar: [1, 2, 3]\n'})

    inventory = Inventory(loader)
    inventory.parse_inventory(host_list=['inventory.config'])

    templar = Templar(loader=loader, inventory=inventory, variables={})
    templar._available_variables

# Generated at 2022-06-23 10:54:21.659189
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    assert(inv.verify_file('config.yml'))
    assert(inv.verify_file('config.yaml'))
    assert(inv.verify_file('config.config'))
    assert(not inv.verify_file('config'))
    assert(not inv.verify_file('config.yml.txt'))
    assert(not inv.verify_file('config.txt.yml'))
    assert(not inv.verify_file('config.txt.config'))

# Generated at 2022-06-23 10:54:34.118741
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    InventoryModule_obj = InventoryModule()
    inventory_mock = InventoryMock()
    child_mock = ChildMock()
    InventoryModule_obj.add_parents(inventory_mock, child_mock, [{'name': 'test'}, {}], {})
    assert(len(inventory_mock.add_child_args) == 2)
    add_child_arg_list = inventory_mock.add_child_args
    assert(add_child_arg_list[0][0] == 'test')
    assert(add_child_arg_list[0][1] == child_mock)
    assert(add_child_arg_list[1][0] == None)
    assert(add_child_arg_list[1][1] == child_mock)


# Generated at 2022-06-23 10:54:39.032234
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    path_valid = 'inventory.config'
    path_invalid_extension = 'inventory.txt'
    path_invalid_file = 'test.config'
    assert inv_mod.verify_file(path_valid) == True
    assert inv_mod.verify_file(path_invalid_extension) == False
    assert inv_mod.verify_file(path_invalid_file) == False

# Generated at 2022-06-23 10:54:54.582588
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import ansible.plugins.loader as plugin_loader
    import ansible.inventory.manager
    import jinja2

    inventory = ansible.inventory.manager.InventoryManager(loader=plugin_loader, sources=['localhost'])
    im = InventoryModule()
    im.templar = ansible.template.AnsibleTemplar(loader=plugin_loader)
    assert im.template('{{ foo }}', {'foo': 'bar'}) == 'bar'
    assert im.template('{{ foo }}{{ bar }}', {'foo': 'bar', 'bar': 'baz'}) == 'barbaz'
    assert im.template('{{ foo }}', {'foo': {'bar': 'baz'}}) == {'bar': 'baz'}

# Generated at 2022-06-23 10:55:02.393871
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    # True when extension is YAML_FILENAME_EXTENSION
    assert True == inventory_module.verify_file('inventory.yml')
    # True when extension is empty
    assert True == inventory_module.verify_file('inventory')
    # True when ext is .config
    assert True == inventory_module.verify_file('inventory.config')
    # False when ext is not valid
    assert False == inventory_module.verify_file('inventory.invalid')
    # False when file does not exist
    assert False == inventory_module.verify_file('does_not_exist')

# Generated at 2022-06-23 10:55:09.243394
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import os

    this_dir, this_filename = os.path.split(__file__)
    test_file = os.path.join(this_dir, "test.config")

    assert os.path.isfile(test_file)

    test_plugin = InventoryModule()
    config = test_plugin._read_config_data(test_file)

    assert 'layers' in config

    template_inputs = product(*config['layers'].values())
    for item in template_inputs:
        template_vars = dict()
        for i, key in enumerate(config['layers'].keys()):
            template_vars[key] = item[i]
        host = test_plugin.template(config['hosts']['name'], template_vars)
        assert host



# Generated at 2022-06-23 10:55:18.335149
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()

    TEST_INVENTORY = 'inventory.config'
    assert inventory.verify_file(TEST_INVENTORY)

    TEST_INVENTORY_EXTENSION = 'inventory.config.yml'
    assert inventory.verify_file(TEST_INVENTORY_EXTENSION)

    TEST_INVENTORY_EXTENSION = 'inventory.config.yaml'
    assert inventory.verify_file(TEST_INVENTORY_EXTENSION)

    TEST_INVENTORY_EXTENSION = 'inventory.config.json'
    assert inventory.verify_file(TEST_INVENTORY_EXTENSION)

# Generated at 2022-06-23 10:55:19.305403
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert obj != None

# Generated at 2022-06-23 10:55:26.728424
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    class mock_templar:
        def do_template(self, pattern):
            return "template({})".format(pattern)

    class mock_loader:
        def __init__(self):
            self.templar = mock_templar()
    inputs = {
        "my_var": 'my input'
    }
    expected = "template(my input)"
    actual = InventoryModule().template("{{my_var}}", inputs)
    assert expected == actual


# Generated at 2022-06-23 10:55:27.733417
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule().NAME == 'generator'

# Generated at 2022-06-23 10:55:31.753832
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Execute constructor with no parameter
    inv_mod = InventoryModule()
    assert inv_mod

    # Execute constructor with two parameters
    loader = object()
    cache = True
    inv_mod = InventoryModule(loader=loader, cache=cache)

    assert inv_mod.loader == loader
    assert inv_mod.cache == cache


# Generated at 2022-06-23 10:55:36.889941
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    filename = 'filename.config'
    assert InventoryModule.verify_file(filename)
    filename = 'filename.yaml'
    assert InventoryModule.verify_file(filename)
    filename = 'filename.yml'
    assert InventoryModule.verify_file(filename)
    filename = 'filename.yaml.txt'
    assert InventoryModule.verify_file(filename)


# Generated at 2022-06-23 10:55:44.455681
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import jinja2
    from ansible.template import Templar

    inv = InventoryModule()

    template = 'red_{{ color }}'
    variables = {'color': 'apple'}
    result = inv.template(template, variables)

    assert result == 'red_apple'

    # Test template error
    template_error = 'red_{{ colorss }}'
    result_error = inv.template(template_error, variables)

    assert result_error == 'ERROR!'


# Generated at 2022-06-23 10:55:46.023412
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert 'generator' == inventory.NAME

# Generated at 2022-06-23 10:55:54.669699
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    class InvFileExists(InventoryModule):
        ''' A simple implementation of the InventoryModule.verify_file without
        other dependencies.'''
        def verify_file(self, path):
            return True

    # tests
    inv_obj = InvFileExists()
    cwd = os.getcwd()

    # Should be True
    path = cwd + '/test.yaml'
    assert inv_obj.verify_file(path)

    # Should be True
    path = cwd + '/test.yml'
    assert inv_obj.verify_file(path)

    # Should be True
    path = cwd + '/test.config'
    assert inv_obj.verify_file(path)

    # Should be False
    path = cwd + '/test.json'
    assert inv_obj.ver

# Generated at 2022-06-23 10:55:57.241196
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    assert True

# Generated at 2022-06-23 10:55:57.821339
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()

# Generated at 2022-06-23 10:56:05.254767
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Setup stage
    inv = InventoryModule()
    path = "/I/am/path/to/file"
    ext = ".yaml"
    not_ext = ".json"
    expected = True

    # Test 1
    if not inv.verify_file(path):
        # If condition is true then It should fail.
        raise AssertionError("Unit test 1 failed as it should had pass")

    # Test 2
    if not inv.verify_file(path + ext):
        # If condition is true then It should fail.
        raise AssertionError("Unit test 2 failed as it should had pass")

    # Test 3
    if not inv.verify_file(path + not_ext):
        # If condition is true then It should fail.
        raise AssertionError("Unit test 3 failed as it should had pass")



# Generated at 2022-06-23 10:56:14.922956
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-23 10:56:18.001600
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' InventoryModule(BaseInventoryPlugin) -> InventoryModule '''

    assert isinstance(InventoryModule(), BaseInventoryPlugin)


# Generated at 2022-06-23 10:56:28.914926
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    obj = InventoryModule()
    obj.templar = Templar()
    inventory = Inventory()
    inventory.add_host('host1')
    obj.add_parents(inventory, 'host1', [{'name': 'group1', 'vars': {'var1': 'val1'}, 'parents': [{'name': 'group2', 'vars': {'var2': 'val2'}}]}], {'layer': 'val'})
    obj.add_parents(inventory, 'group1', [{'name': 'group2', 'vars': {'var2': 'val2'}}], {'layer': 'val'})

    assert inventory.groups['group2'].get_variables()['var2'] == 'val2'
    assert 'host1' in inventory.groups['group1'].get_hosts()

# Generated at 2022-06-23 10:56:36.061448
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import yaml

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)

    config = yaml.safe_load(EXAMPLES)
    
    inventory_manager = InventoryModule()
    inventory_manager.add_parents(inventory, config['hosts']['name'], config['hosts']['parents'], config['layers'])

    assert inventory.groups['build_web_dev'].children['build_web_dev_runner']

# Generated at 2022-06-23 10:56:46.156562
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    import os
    import shutil
    import tempfile

    from ansible.plugins.inventory import BaseInventoryPlugin

    if C.INVENTORY_ENABLED:
        return

    temp_path = tempfile.mkdtemp()
    config_file = os.path.join(temp_path, 'inventory.config')


# Generated at 2022-06-23 10:56:50.817155
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import pytest
    templar = unittest_template()
    module = InventoryModule()
    module.templar = templar
    variables = {
        'application': 'web',
        'environment': 'dev'
    }
    assert module.template("{{ application }}_{{ environment }}", variables) == "web_dev"


# Generated at 2022-06-23 10:56:59.287257
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import ansible.inventory.manager
    import ansible.playbook.play

    i = ansible.inventory.manager.InventoryManager(None, None)

    test_source_file = "./test_inventory.config"

    im = InventoryModule()
    im.templar = ansible.playbook.play.Play()._load_tmpl_class()
    im.parse(i, None, test_source_file, cache=False)

    # Test all hosts have been loaded
    assert len(i.hosts) == 6

    web_prod_host = i.get_host("web_prod_runner")

    # Test groups have been created
    assert len(i.groups) == 19

    # Test correct parent groups
    assert i.get_group("runner").get_hosts()[0] == web_prod