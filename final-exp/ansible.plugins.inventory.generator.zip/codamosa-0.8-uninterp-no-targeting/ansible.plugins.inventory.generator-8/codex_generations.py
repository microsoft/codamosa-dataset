

# Generated at 2022-06-21 05:11:48.122907
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test data
    plugin = 'generator'

# Generated at 2022-06-21 05:12:00.213069
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    # Arrange
    inventory = type('a', (object,), {})()
    child = 'child'
    parents = [['parent1_v1'], ['parent2_v1', 'parent2_v2']]
    template_vars = dict({'a': 1, 'b': 2})
    # Act
    InventoryModule.add_parents(InventoryModule(), inventory, child, parents, template_vars)
    # Assert
    assert inventory.groups['parent1_v1']._parents == set()
    assert inventory.groups['parent2_v1']._parents == set(['parent1_v1'])
    assert inventory.groups['parent2_v2']._parents == set(['parent1_v1'])

# Generated at 2022-06-21 05:12:11.858697
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_class = InventoryModule()

    # Return True for a file with YAML extention
    assert inventory_class.verify_file('inventory.yaml') == True

    # Return True for a file with YAML extention
    assert inventory_class.verify_file('inventory.config') == True

    # Return True for a file with YAML extention
    assert inventory_class.verify_file('inventory.yml') == True

    # Return False for a file with csv extention
    assert inventory_class.verify_file('inventory.csv') == False

    # Return False for a file with no extention
    assert inventory_class.verify_file('inventory') == False

# Generated at 2022-06-21 05:12:20.534904
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import os
    import tempfile
    import collections

    # Create a temporary files
    fd, path = tempfile.mkstemp(suffix='.config')
    f = os.fdopen(fd, "w")

# Generated at 2022-06-21 05:12:33.293931
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inv = InventoryModule()
    class inventory_class:
        def __init__(self):
            self.groups = {}
        def add_child(self, parent, child):
            self.groups[parent].add(child)
        def add_group(self, groupname):
            self.groups[groupname] = set()
        def add_host(self, host):
            self.groups[host] = set()
    inventory = inventory_class()
    inventory.add_group('top')

    child = dict(name='parent')
    parent_list = [ dict(name='grandparent1'), dict(name='grandparent2') ]
    inv.add_parents(inventory, child, parent_list, dict())
    assert "grandparent1" in inventory.groups.keys()
    assert "grandparent2" in inventory.groups.keys

# Generated at 2022-06-21 05:12:43.619240
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    import sys

    path = os.path.join(os.path.dirname(__file__), 'inventory.config')

    inventory = InventoryManager(loader=DataLoader(), sources=path)

    # Load the desired plugin
    gen_finder = inventory_loader._get_finder(InventoryModule.NAME)()
    inventory.extra_vars = {}

    # Add a host to the inventory
    inventory.add_host('web_dev_runner')

    # Create a group
    inventory.add_group('baddies')

    # Add a host to a group
    inventory.add_child('baddies', 'web_dev_runner')

    gen_finder

# Generated at 2022-06-21 05:12:53.612937
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.template import Templar
    import types
    import pkg_resources
    import tempfile
    import shutil
    import os
    import sys

    templar = Templar(loader=None)

    test_inventory = InventoryModule()

    variables_input = {
        'test1': '1',
        'test2': '2',
        'test3': '3'
    }

    input_str1 = '{{ test1 }} {{ test2 }} {{ test3 }}'
    output_str1 = '1 2 3'

    input_str2 = '{{ test2 }} {{ test3 }} {{ test1 }}'
    output_str2 = '2 3 1'

    assert test_inventory.template(input_str1, variables_input) == output_str1

# Generated at 2022-06-21 05:13:02.909378
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    inventory_module = InventoryModule()
    inventory = type('inventory', (), {'hosts': {}, 'groups': {}})()
    inventory.add_host = lambda hostname: inventory.hosts.__setitem__(hostname, Host(hostname))
    inventory.add_group = lambda groupname: inventory.groups.__setitem__(groupname, Group(groupname))
    inventory.add_child = lambda groupname, child: inventory.groups.get(groupname).add_child(inventory.hosts.get(child))

    # Build test data

# Generated at 2022-06-21 05:13:10.949134
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    m = InventoryModule()

    # Test that we can not provide a variable that does not exist
    template = '{{does_not_exist}}'
    variables = dict()
    try:
        m.template(template, variables)
        assert False
    except AnsibleParserError:
        assert True

    # Test with valid variables
    template = '{{key}}'
    variables = dict(key='value')
    assert m.template(template, variables) == 'value'

    # Test with a longer template
    template = '{{key1}}_{{key2}}'
    variables = dict(key1='value1', key2='value2')
    assert m.template(template, variables) == 'value1_value2'

# Generated at 2022-06-21 05:13:15.683256
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    testmod = InventoryModule()
    assert testmod is not None


# Generated at 2022-06-21 05:13:21.683186
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    path = 'tests/unit/plugins/inventory/test_inventory_module.config'
    im = InventoryModule()

    try:
        im.parse(host_list=[], cache=False, cache_key='fubar', loader=None, sources='fubar')
    except AttributeError:
        pass

    assert im.verify_file(path) is True
    assert im.verify_file(path + 'z') is False



# Generated at 2022-06-21 05:13:33.064943
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager

    file_path = os.path.join(os.path.dirname(__file__), 'inventory.config')

    config = {'is_file': False, 'config_file': file_path, 'cache': False}
    inventory = VariableManager()

    loader = DataLoader()
    inventory.set_loader(loader)

    plugin = inventory_loader.get_plugin_loader('generator')
    generator = plugin.load()

    generator.parse(inventory, loader, file_path)

    assert len(inventory.get_hosts()) == 18, "Inventory should have 18 hosts!"

# Generated at 2022-06-21 05:13:40.336845
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
        from jinja2 import Environment, DictLoader
        env = Environment(loader=DictLoader({}))
        data = "{{ test_var }}{{ test_var }}"
        kwargs = {"test_var": "success"}
        templar = env.from_string(data)
        output = templar.render(**kwargs)
        assert output == "successsuccess"

# Generated at 2022-06-21 05:13:54.435233
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import unittest
    from ansible.plugins.inventory.generator import InventoryModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    class TestInventoryModule(unittest.TestCase):

        def setUp(self):
            loader = DataLoader()
            self.inv = InventoryModule(loader=loader)

        def test_parse(self):
            inv = InventoryManager(loader=self.inv.loader, sources='stuff')
            vars = VariableManager(loader=self.inv.loader, inventory=inv)
            self.inv.inventory = inv


# Generated at 2022-06-21 05:14:04.358994
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    plugin = InventoryModule()

    inventory = InventoryModule.Inventory(loader=None, variable_manager=None, host_list=None)

    plugin.add_host(inventory,'all',groups=['group1','group2'])
    host = inventory.get_host(hostname="all")
    assert(len(host.get_groups())) == 2
    assert (host.get_groups()[0].get_name() == "group1")
    assert (host.get_groups()[1].get_name() == "group2")

    plugin.add_group(inventory,'group1',parents=['group3'])
    group = inventory.get_group(groupname="group1")
    assert(len(group.get_groups()))

# Generated at 2022-06-21 05:14:14.447954
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from io import BytesIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.module_utils.six import string_types


# Generated at 2022-06-21 05:14:22.415168
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    p = InventoryModule()
    ans = p.verify_file('config.yml')
    assert ans == True

    ans = p.verify_file('config.config')
    assert ans == True

    ans = p.verify_file('config')
    assert ans == False

    ans = p.verify_file('.config')
    assert ans == False

    ans = p.verify_file('config.cfg')
    assert ans == False



# Generated at 2022-06-21 05:14:32.897075
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    im = InventoryModule()

    # Returns False if given file is not a config file
    assert im.verify_file(path='./_test_data/inventory/inventory.py') == False

    # Returns True if given file is a config file
    assert im.verify_file(path='./_test_data/inventory/inventory.config') == True

    # Returns False if given file is a config file with invalid extension
    assert im.verify_file(path='./_test_data/inventory/inventory.yml') == False


# Generated at 2022-06-21 05:14:42.751534
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    class AnsibleConfig:
        def __init__(self, data):
            self.data = data

    config = AnsibleConfig({'yaml_filenames':['.config', '.yms']})
    C.config = config

    path = './test.yms'
    module = InventoryModule()
    result = module.verify_file(path)
    assert result == True, 'Verify file returns True if extension is in yml_filenames.'

    path = './test.config'
    module = InventoryModule()
    result = module.verify_file(path)
    assert result == True, 'Verify file returns True if extension is config.'

    path = './test.json'
    module = InventoryModule()
    result = module.verify_file(path)

# Generated at 2022-06-21 05:14:57.733109
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import tempfile

    def write_file(path, data):
        f = open(path, 'w')
        f.write(data)
        f.close()

    fd, config_path = tempfile.mkstemp(suffix='.config')
    fd, _ = tempfile.mkstemp(suffix='.config')

# Generated at 2022-06-21 05:15:11.830411
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.utils.template import Templar
    from ansible.plugins.loader import add_all_plugin_dirs
    test_plugin = './test/test_inventory_generator'
    add_all_plugin_dirs([test_plugin])

    from ansible.plugins.inventory.generator import InventoryModule
    templar = Templar(variables={'a': '2'})
    inv_mod = InventoryModule()
    inv_mod.templar = templar

    assert inv_mod.template('{{a}}', {'a': '1'}) == '1'
    assert inv_mod.template('aa', {'a': '1'}) == 'aa'



# Generated at 2022-06-21 05:15:23.991170
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    data_path=os.path.join(os.path.dirname(__file__), 'data')
    json_file=os.path.join(data_path, 'inventory.json')
    yaml_file=os.path.join(data_path, 'inventory.yaml')
    normal_file=os.path.join(data_path, 'inventory.normal')
    config_file=os.path.join(data_path, 'inventory.config')

    i = InventoryModule()

    assert i.verify_file(json_file) == False
    assert i.verify_file(yaml_file) == False
    assert i.verify_file(normal_file) == False
    assert i.verify_file(config_file) == True

# Generated at 2022-06-21 05:15:26.561270
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory = InventoryModule()
    assert inventory.template('{{ "foo" }}', {}) == 'foo'

# Generated at 2022-06-21 05:15:39.001532
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    """Test the templar expansion for the generation plugin"""
    import unittest.mock as mock
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.inventory.manager import InventoryManager

    TEST_MODULE = 'ansible.plugins.inventory.generator'

    def templar_do_template_side_effect(tpl):
        return tpl

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['empty_file'])
    generator = InventoryModule()
    generator.templar = mock.MagicMock()
    generator.templar.available_variables = dict()
    generator.templar.do_template.side_effect = templar_do_template_

# Generated at 2022-06-21 05:15:47.946767
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from collections import defaultdict
    from ansible.inventory.manager import InventoryManager
    fname = 'inventory.config'
    def read_config_data(path):
        yaml = YAML(typ='safe')
        with open(path, 'r') as f:
            data = yaml.load(f.read())
        return data
    def template(pattern, variables):
        templar = Templar(loader=None, variables=variables)
        return templar.do_template(pattern)
    inventory = InventoryManager(host_list=[])
    config = read_config_data(fname)
    template_inputs = product(*config['layers'].values())
    template_input_list = []
    for item in template_inputs:
        template_vars = dict()

# Generated at 2022-06-21 05:15:54.621088
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import jinja2
    inventory = BaseInventoryPlugin()
    inventory.templar = jinja2.Environment()
    inventory_module = InventoryModule()
    inventory_module.templar = jinja2.Environment()
    host_template = 'test_{{ layer1 }}{{ layer2 }}_{{ layer3 }}'
    template_vars = {'layer1': 'val1', 'layer2': 'val2', 'layer3': 'val3'}
    host = inventory_module.template(host_template, template_vars)
    assert host == 'test_val1val2_val3'

# Generated at 2022-06-21 05:15:56.102037
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    x = InventoryModule()
    assert x.NAME == 'generator'

# Generated at 2022-06-21 05:15:59.689502
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    '''
    Tests the generator plugin method add_parents
    '''
    import ansible.inventory.manager
    inventory = ansible.inventory.manager.InventoryManager(loader=None, sources=None)
    INV_PLUGIN = InventoryModule()
    child = "child"
    parent = {
        "name": "parent",
        "parents": [
            {"name": "grand_parent"},
        ],
    }
    INV_PLUGIN.add_parents(inventory, child, [parent], {})
    assert child in inventory.groups['parent'].get_hosts()
    assert child in inventory.groups['grand_parent'].get_hosts()

# Generated at 2022-06-21 05:16:01.001542
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule


# Generated at 2022-06-21 05:16:12.997351
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    inventory_module = InventoryModule()

    # Expected behavior
    assert inventory_module.verify_file('/dev/null')
    assert not inventory_module.verify_file('/dev/null.json')
    assert not inventory_module.verify_file('/dev/null.yaml')

# Generated at 2022-06-21 05:16:22.102668
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    from ansible.plugins.inventory.generator import InventoryModule
    x = InventoryModule()
    e = None
    try:
      x.verify_file('/tmp')
    except Exception as e:
      pass
    if e is None:
      assert False, "Expected False but got True"
    try:
      x.verify_file('/tmp/' + 'inventory.config')
    except Exception as e:
      pass
    if e is None:
      assert False, "Expected False but got True"
    try:
      x.verify_file('/tmp/' + 'inventory.config.bak')
    except Exception as e:
      pass
    if e is None:
      assert False, "Expected False but got True"

# Generated at 2022-06-21 05:16:36.281157
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    path = '.'
    loader = None
    cache = False
    inventory = BaseInventoryPlugin()
    test_inventory_module = InventoryModule()
    test_inventory_module.parse(inventory, loader, path, cache)
    hosts = inventory.get_hosts()
    groups = inventory.get_groups()

    assert(len(hosts) == 6)
    for h in hosts:
        assert(isinstance(h, Host))
        assert(h.name in ['build_web_dev_runner', 'build_web_test_runner', 'build_web_prod_runner',
            'build_api_dev_runner', 'build_api_test_runner', 'build_api_prod_runner'])

# Generated at 2022-06-21 05:16:37.584195
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert not inventory is None

# Generated at 2022-06-21 05:16:52.011541
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = dict()
    loader = dict()
    config = dict()
    config['layers'] = dict()
    config['layers']['operation'] = ['build', 'launch']
    config['layers']['environment'] = ['dev', 'test', 'prod']
    config['layers']['application'] = ['web', 'api']
    config['hosts'] = dict()
    config['hosts']['name'] = '{{ operation }}_{{ application }}_{{ environment }}_runner'
    config['hosts']['parents'] = [{'name': '{{ operation }}_{{ application }}_{{ environment }}'}]
    inventory_module.parse(inventory, loader, config)
    assert len(inventory['_meta']['hostvars']) == 6

# Generated at 2022-06-21 05:17:02.506163
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    import tempfile
    import shutil
    from ansible.plugins.inventory.generator import InventoryModule
    from ansible.errors import AnsibleParserError

    # create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # create the temporary inventory file
    fd, tmp_path = tempfile.mkstemp(dir=tmp_dir)
    os.close(fd)
    # create a new InventoryModule object
    inventory_module = InventoryModule()
    # the temporary path must be a valid file
    assert inventory_module.verify_file(tmp_path)
    # now remove the temporary directory and all its contents
    shutil.rmtree(tmp_dir)
    # and verify that the temporary file is no longer verified
    assert not inventory_module.verify_file(tmp_path)

# Generated at 2022-06-21 05:17:10.289026
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    plugin = InventoryModule()
    plugin._loader = None

    template_vars = {
      'operation': 'build',
      'environment': 'dev',
      'application': 'web'
    }

    pattern = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    result = plugin.template(pattern, template_vars)
    assert result == 'build_web_dev_runner'

# Generated at 2022-06-21 05:17:12.874457
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    t = InventoryModule()
    t.templar = t.loader.load_contr

# Generated at 2022-06-21 05:17:22.775514
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory.parse(InventoryModule, "../../../../examples/inventory/inventory.config")
    assert "api_dev_runner" in inventory.hosts
    assert "build_web" in inventory.groups
    assert "build" in inventory.groups["build_web"].vars
    assert "api_dev" in inventory.groups["build_web"].get_hosts()
    assert inventory.groups["api_dev"].get_host("api_dev_runner").name == "api_dev_runner"

# Generated at 2022-06-21 05:17:24.703121
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    tester = InventoryModule()
    # TODO Add real unit test
    assert True

# Generated at 2022-06-21 05:17:33.645273
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    host_name = 'test_host'
    path = os.path.join(os.path.dirname(__file__), 'test_data', 'inventory.config')
    inventory = inventory_loader.get('generator', path)
    loader = inventory_loader.get('file', path)
    plugin = InventoryModule()
    plugin.parse(inventory, loader, path)

    # Test if test_host was added
    assert host_name in inventory.hosts
    assert isinstance(inventory.hosts[host_name], Host)

    # Test if groups have been created

# Generated at 2022-06-21 05:17:38.337189
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert obj
    #assert isinstance(obj, InventoryModule)

# Generated at 2022-06-21 05:17:53.601426
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    """ Unit test for add_parents method of class InventoryModule """

    import collections
    import random
    import string
    import unittest

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.plugins.inventory.generator import InventoryModule

    # Create a random name generator to be used as a simple template engine
    from random import randint
    def random_name(length):
        return ''.join(random.sample(string.ascii_lowercase, length))

    # Create a mock inventory object and loader object to be used in the tests
    class MockInventory(object):
        def __init__(self):
            self.hosts = dict()
            self.groups = dict()
            self.parents = collections.defaultdict(list)


# Generated at 2022-06-21 05:17:57.679318
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    inventory = {}
    inventory['groups'] = {}
    inventory['_hosts_cache'] = {}
    inventory['_pattern_cache'] = {}
    inventory['_restriction'] = None
    inventory['_subset'] = None
    inventory['_unsafe_proxy_user'] = False
    inventory['_vars_plugins'] = []
    inventory['_script_vars'] = {}
    inventory['_is_file'] = False

    inventory['add_host'] = lambda host: inventory['_hosts_cache'].setdefault(host, {})
    inventory['add_group'] = lambda group: inventory['groups'].setdefault(group, {})
    inventory['add_child'] = lambda group, child: inventory['groups'][group].setdefault('children', []).append(child)

# Generated at 2022-06-21 05:18:05.354307
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ hosts }}')), register='debug_output')
         ]
    )


# Generated at 2022-06-21 05:18:09.776096
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Init
    inventory_module = InventoryModule()

    # Test
    test_result = inventory_module.verify_file('test_path.config')

    # Verify
    assert test_result == True



# Generated at 2022-06-21 05:18:17.307273
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test
    invmod = InventoryModule()
    inventory = dict(hosts=dict(), groups=dict())
    invmod.parse(inventory, None, 'inventories/good/inventory.config')
    hosts = inventory['hosts']
    groups = inventory['groups']
    # Test assertion
    assert(len(hosts) == 12)

# Generated at 2022-06-21 05:18:21.339379
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    invmod = InventoryModule()
    invmod.templar = ansible.plugins.template.Templar(loader=None)
    assert invmod.template("this is a test", {}) == "this is a test"
    assert invmod.template("test {{ var }}", {"var": "string"}) == "test string"


# Generated at 2022-06-21 05:18:33.218437
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = {}
    path = 'tests/inventory/valid_yaml_config'
    cache = False
    test = InventoryModule()
    test.parse(inventory, loader, path, cache)

# Generated at 2022-06-21 05:18:39.415277
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.plugins.inventory import BaseInventoryPlugin
    m = InventoryModule()

    # setup templar
    class InventoryModule_BaseInventoryPlugin(BaseInventoryPlugin):
        options = None
        def __init__(self):
            self.option_plugins = {}
    base = InventoryModule_BaseInventoryPlugin()
    m.vars_plugins = []
    m.templar = base._templar()

    # setup private module attributes
    m.hostvars = {}
    m.groups = {}
    m.inventory = InventoryModule()

    # setup module variables
    m.vars = {}

    pattern = '{{ test_var }}'
    variables = {'test_var': 'test_val'}
    assert m.template(pattern, variables) == 'test_val'

# Generated at 2022-06-21 05:18:43.554597
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    inventory.parse("inventory.config", "/etc/ansible")

# Unit test, to execute this test uncomment below line
test_InventoryModule()

# Generated at 2022-06-21 05:18:53.637674
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:18:56.782105
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class inventory:
        add_host = lambda self, x: 0
        add_group = lambda self, x: 0
        add_child = lambda self, x, y: 0
        groups = {}
    class loader:
        pass
    path = '/tmp/inventory.config'

    c = InventoryModule()
    assert c.verify_file(path) == True
    c.parse(inventory(), loader(), path) == True

if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-21 05:19:01.604123
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_obj = InventoryModule()
    assert test_obj.verify_file("test.yml") == True
    assert test_obj.verify_file("test.cfg") == True
    assert test_obj.verify_file("test.yaml") == True
    assert test_obj.verify_file("test.json") == False


# Generated at 2022-06-21 05:19:15.260487
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    inv = inventory_loader.get('generator', vault_password='secret')
    inv.parse('./test/assets/generator.yaml')

# Generated at 2022-06-21 05:19:20.789401
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # inittialize class InventoryModule
    inventory_module = InventoryModule()

    # initialize input parameter path with valid file
    path = '/home/vagrant/ansible_collections/ansible_collections/ansible/community/azure/plugins/inventory/az.yml'

    # get the result for above initialized path variable
    result = inventory_module.verify_file(path)

    # Assert if result is equal to True
    assert result == True



# Generated at 2022-06-21 05:19:33.810090
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.plugins.inventory.generator import InventoryModule
    from ansible.parsing.yaml.loader import AnsibleLoader
    class MockTemplar():
        def __init__(self):
            self.available_variables = {}
        def do_template(self, pattern):
            return pattern.replace('{{', '').replace('}}', '')
    class MockAnsibleInventory():
        def __init__(self):
            self.parent = None
    class MockAnsibleInventoryHost():
        def __init__(self):
            self.name = None
    class MockAnsibleInventoryGroup():
        def __init__(self):
            self.name = None
            self.vars = {}
        def set_variable(self, k, v):
            self.vars[k] = v

# Generated at 2022-06-21 05:19:44.805285
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import unittest
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryModule()
    inventory.templar = unittest.mock.Mock()
    template_source = "template"
    variables = {"var1": "val1", "var2": "val2"}

    # Test case 1
    inventory.template(template_source, variables)
    inventory.templar.do_template.assert_called_with(template_source)
    inventory.templar.available_variables = variables

    # Test case 2
    inventory.template(None, variables)
    assert inventory.templar.do_template.call_count == 2
    inventory.templar.available_variables = variables

    # Test case 3

# Generated at 2022-06-21 05:19:55.821523
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager = VariableManager(loader=loader)
    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-21 05:20:02.963433
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    plugin = InventoryModule()
    from ansible.plugins import inventory
    inventory = inventory.InventoryDirectory(None)

    # Test that adding a host works correctly
    plugin.add_parents(inventory, "myhost", [{'name': 'myparent1'}], {})
    assert 'myparent1' in inventory.groups
    assert 'myhost' in inventory.groups['myparent1'].children

    # Test that adding host to one parent works correctly
    plugin.add_parents(inventory, "myhost", [{'name': 'myparent2'}], {})
    assert 'myhost' in inventory.groups['myparent2'].children

    # Test that adding host to parent with other parent works correctly

# Generated at 2022-06-21 05:20:15.048851
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    '''
    Unit test for add_parents method of class InventoryModule
    Validating method add_parents(self, inventory, child, parents, template_vars) of class InventoryModule.
    '''
    class InventoryModule_Mock():
        """Mock class for InventoryModule used for testing add_parents method of InventoryModule"""
        def __init__(self):
            self.templar = Templar()

        def template(self, pattern, variables):
            """ Method to mock template of class InventoryModule"""
            return self.templar.do_template(pattern)

        def add_parents(self, inventory, child, parents, template_vars):
            """ Method to mock add_parents of class InventoryModule"""

# Generated at 2022-06-21 05:20:33.582085
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os.path
    inventory = InventoryModule()
    assert inventory.verify_file("inventory.config") is True
    inventory.parse(inventory, None, "./inventory_plugin_examples/inventory.config")
    assert inventory.get_host("build_api_dev_runner").get_vars() == {'inventory_hostname': 'build_api_dev_runner'}
    assert inventory.get_host("build_api_dev_runner").get_groups() == ['build', 'build_api', 'build_api_dev',
                                                                        'api', 'api_dev', 'dev', 'runner']
    assert inventory.get_group('build').get_vars() == {'inventory_hostname': 'build'}

# Generated at 2022-06-21 05:20:44.514181
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from jinja2 import Template
    global mock_Template
    def mock_Template(*args):
        return Template(*args)
    mock_Template.environment = Template("{{ var1 }}{{ var2 }}").environment
    global mock_Template_safe_render
    def mock_Template_safe_render(*args):
        return Template("{{ var2 }}{{ var1 }}").render(*args)
    mock_Template.safe_render = mock_Template_safe_render
    global mock_Template_do_template
    def mock_Template_do_template(*args):
        return Template("{{ var1 }}{{ var2 }}").render(*args)
    mock_Template.do_template = mock_Template_do_template
    global mock_Template_render

# Generated at 2022-06-21 05:20:48.444468
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    """ test method template of class InventoryModule """

    inventory = InventoryModule()
    assert inventory.template('{{ foo }}', {'foo': 'bar'}) == 'bar'

# Generated at 2022-06-21 05:20:56.449045
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''Unit test for method parse of class InventoryModule'''
    # Test a typical case, with very simple configuration file
    # inventory.config file in YAML format
    # remember to enable this inventory plugin in the ansible.cfg before using
    # View the output using `ansible-inventory -i inventory.config --list`
    plugin: generator

# Generated at 2022-06-21 05:21:08.125314
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleUnicode

    m = InventoryModule()

    # Non nested case
    r = m.template("{{ var1 }}{{ var2 }}", {'var1': '1', 'var2': '2'})
    assert r == '12'

    # Nested case
    r = m.template("{{ var3.child1 }}", {'var3': {'child1': 1}})
    assert r == '1'

    # Nested case using unicode
    r = m.template("{{ var3.child1 }}", {'var3': {'child1': AnsibleUnicode('foo')}})
    assert r == 'foo'

    # Nested case with unicode and mock iteration

# Generated at 2022-06-21 05:21:17.079114
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,127.0.0.1,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    im = InventoryModule()

    # add_parents() creates an inventory.groups entry for each parent
    # in the configuration file
    im.add_parents(inventory, 'host_base', parents=[{'name': 'test1'}, {'name': 'test2'}], template_vars={})
    assert len(inventory.groups) == 2

    # it also creates an inventory.hosts entry for each host

# Generated at 2022-06-21 05:21:19.601704
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    test_obj = InventoryModule()
    assert test_obj.NAME == 'generator'


# Generated at 2022-06-21 05:21:28.484964
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    """
    Unit test for method add_parents of class InventoryModule
    """
    from unittest import TestCase, mock
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    class TestInventoryModule(TestCase):
        def setUp(self):
            self._test_inventory = Inventory(loader=mock.Mock(), variable_manager=VariableManager(), host_list=[])
            self._test_inventory.add_group('test_group')
            self._test_inventory.add_host(Host(name='test_host'))

# Generated at 2022-06-21 05:21:37.672313
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    from ansible.plugins.loader import inventory_loader
    # Create an instance of our plugin class
    test_inv = inventory_loader.get('generator')
    # Make sure we can handle YAML
    assert test_inv.verify_file(os.path.join(os.path.dirname(__file__), "test_yaml.yml"))
    # Make sure we can handle JSON
    assert test_inv.verify_file(os.path.join(os.path.dirname(__file__), "test_json.json"))
    # Make sure we can handle an empty extension
    assert test_inv.verify_file(os.path.join(os.path.dirname(__file__), "test_empty_ext"))
    # Make sure we can handle a config extension
    assert test_inv