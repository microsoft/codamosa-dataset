

# Generated at 2022-06-11 14:30:03.089471
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from test.support.ansible_helper import get_hosts, get_config
    plugin = InventoryModule()
    inventory = get_hosts()
    template_vars = {'operation': 'build', 'environment': 'dev', 'application': 'web'}
    child = 'build_web_dev_runner'

# Generated at 2022-06-11 14:30:05.200357
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    inv = inventory_loader.get("generator")
    inv.parse("inventory.config", loader=None, path='inventory.config')


# Generated at 2022-06-11 14:30:15.167398
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    # Create mock inventory object
    class MockInventory(object):
        def __init__(self):
            self.groups = {}
            self.hosts = {}

        def add_host(self, name):
            self.hosts[name] = name

        def add_group(self, name):
            self.groups[name] = MockGroup(name)

        def add_child(self, child, parent):
            self.groups[parent].add_child(self.hosts.get(child, child))

    # Create mock group object
    class MockGroup(object):
        def __init__(self, name):
            self.name = name
            self.vars = {}
            self.children = {}

        def set_variable(self, key, value):
            self.vars[key] = value


# Generated at 2022-06-11 14:30:15.987631
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # TODO

    return False


# Generated at 2022-06-11 14:30:23.202663
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    class TestTemplar(object):
        def __init__(self):
            self.available_variables = {}

        def do_template(self, template):
            return template
    t = InventoryModule()
    t.templar = TestTemplar()
    assert(t.template('{{ foo }}', {'foo': 'bar'})=='bar')

# Generated at 2022-06-11 14:30:26.829148
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Setup
    inventory_module = InventoryModule()
    inventory = object()
    loader = object()
    path = object()
    cache = object()

    # Test
    inventory_module.parse(inventory, loader, path, cache)

# Generated at 2022-06-11 14:30:32.597481
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import pprint
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    path = 'testdata'
    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list=path)
    inv_module = InventoryModule()

    config = {'layers': {'operation': ['build'],
                         'application': ['web']},
              'hosts': {'name': '{{ application }}_{{ operation }}_runner'}}

# Generated at 2022-06-11 14:30:41.565587
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    #init InventoryModule class
    test_inventory_module = InventoryModule()

    #test case 1
    file_path = '/etc/ansible/hosts'
    expected_result = True
    actual_result = test_inventory_module.verify_file(file_path)
    assert(actual_result == expected_result)

    #test case 2
    file_path = '/etc/ansible/hosts.config'
    actual_result = test_inventory_module.verify_file(file_path)
    assert(actual_result == expected_result)

    #test case 3
    file_path = '/etc/ansible/hosts.yaml'
    actual_result = test_inventory_module.verify_file(file_path)
    assert(actual_result == expected_result)

    #test case 4
   

# Generated at 2022-06-11 14:30:43.220944
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    assert inv_mod.verify_file("inventory.config")


# Generated at 2022-06-11 14:30:55.333732
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import yaml
    loader = yaml.SafeLoader

    inventory = object()
    child = object()

    parents = yaml.load('''
    - name: "{{ operation }}_{{ application }}_{{ environment }}"
      parents:
        - name: "{{ operation }}_{{ application }}"
          parents:
            - name: "{{ operation }}"
            - name: "{{ application }}"
        - name: "{{ application }}_{{ environment }}"
          parents:
            - name: "{{ application }}"
              vars:
                application: "{{ application }}"
            - name: "{{ environment }}"
              vars:
                environment: "{{ environment }}"
    ''', Loader=loader)


# Generated at 2022-06-11 14:31:01.210177
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = None
    path = None
    cache = False

    obj = InventoryModule()

    # Normal behavior
    obj.parse(inventory, loader, path, cache)

# Generated at 2022-06-11 14:31:12.721463
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError

    # a config file that is not valid YAML

# Generated at 2022-06-11 14:31:24.340511
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import tempfile
    tmp = tempfile.NamedTemporaryFile()

# Generated at 2022-06-11 14:31:27.911366
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Verify that verify_file returns True if config file extension is correct
    path = 'ansible.cfg'
    result = InventoryModule().verify_file(path)
    assert result == True

    # Verify that verify_file returns False if config file extension is not correct
    path = 'ansible.conf'
    result = InventoryModule().verify_file(path)
    assert result == False

# Generated at 2022-06-11 14:31:32.326954
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    # Test verify_file with a valid path
    assert inventory.verify_file('test.txt') == False
    assert inventory.verify_file('test.config') == True
    assert inventory.verify_file('test.yml') == True
    assert inventory.verify_file('test.yaml') == True

# Generated at 2022-06-11 14:31:41.848994
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager

    plugin = InventoryModule()
    inventory = plugin.inventory
    hostvar = plugin.variable_manager = VariableManager()

    path = {'path': 'sample_data/inventory.config'}
    plugin.parse(inventory, None, path, cache=False)

    # Test some groups whether or not they are in groups dictionary
    assert inventory.groups['dev'].name == 'dev'
    assert inventory.groups['web_dev'].name == 'web_dev'
    assert inventory.groups['build_web_dev'].name == 'build_web_dev'

    # Test some hosts whether or not they are in hosts dictionary

# Generated at 2022-06-11 14:31:52.590796
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Create a dummy inventory
    inventory = generate_dummy_inventory()

    # Create a config file
    path = "test.config"
    config = {'hosts': {'name': 'test_runner', 'parents': [{'name': 'test', 'parents': [{'name': 'test_parent'}]}]}}
    config = generate_dummy_config(path, config)

    # Load config file into inventory
    plugin = InventoryModule()
    plugin.parse(inventory, loader, path, cache=False)
    group = inventory.get_group('test')
    group_parent = inventory.get_group('test_parent')
    assert group == {'children': {'test_runner': {}}, 'hosts': {}, 'vars': {}}

# Generated at 2022-06-11 14:32:04.154292
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    class YAMLInventoryModule(InventoryModule):
        NAME = 'generator'

        # Override method to just check parent and child
        def add_child(self, groupname, child):
            print("%s -> %s" % (groupname, child))

    test_vars = {
        'operation': 'build',
        'environment': 'test',
        'application': 'api'
    }

# Generated at 2022-06-11 14:32:10.307532
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['inventory/inventory.config'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    result =  InventoryModule().parse(inventory, loader, 'inventory/inventory.config', cache=False)
    assert result == True

# Generated at 2022-06-11 14:32:19.182332
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    config = {'hosts': {'name': '{{ operation}}_{{ application}}_{{ environment}}_runner',
                        'parents': [{'name': '{{ operation}}_{{ application}}_{{ environment}}'},
                                    {'name': '{{ operation}}_{{ application}}'},
                                    {'name': '{{ application}}_{{ environment}}'}]},
              'layers': {'operation': ['build', 'launch'],
                         'environment': ['dev', 'test', 'prod'],
                         'application': ['web', 'api']}}

    parent = {'name': '{{ operation}}_{{ application}}',
              'parents': [{'name': '{{ operation}}'},
                          {'name': '{{ application}}'}]}

    self = object()
    self.templar = object()


# Generated at 2022-06-11 14:32:33.642090
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    # Create test file and load it as a config
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    inventory_string = 'plugin: generator\nlayers:\n  hosts:\n    - test_host\n  vars:\n    test_var: test_value\n'
    config_fd, config_path = tempfile.mkstemp()
    os.close(config_fd)
    with open(config_path, 'w') as f:
        f.write(inventory_string)

    config = InventoryModule()._read_config_data(config_path)
    os.unlink(config_path)
    assert isinstance(config, dict)

# Generated at 2022-06-11 14:32:40.446891
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    IM = InventoryModule()
    inventory = Inventory()

    IM.add_parents(inventory, 'web_dev', [
        {
            'name': '{{ application }}_{{ environment }}',
            'parents': [
                {
                    'name': 'web',
                    'vars': {
                        'application': 'web'
                    }
                },
                {
                    'name': '{{ environment }}',
                    'vars': {
                        'environment': 'dev'
                    }
                }
            ]
        }
    ], {
        'application': 'web',
        'environment': 'dev'
    })
    assert(inventory.hosts['web_dev'] == ['web'])
    assert(inventory.hosts['web'] == ['dev'])
    assert(inventory.hosts['dev'] == [])

# Generated at 2022-06-11 14:32:46.138322
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    assert inventory.verify_file('inventory.config') == True
    assert inventory.verify_file('inventory.conf') == False
    assert inventory.verify_file('inventory.yaml') == True
    assert inventory.verify_file('inventory') == False
    assert inventory.verify_file('inventory.py') == False

# Generated at 2022-06-11 14:32:53.794503
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import tempfile
    import os
    import sys

    if 'unittest' in sys.modules:
        # Load the test data:
        from .test_data import test_data
    else:
        from test_data import test_data

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'inventory.config'), 'w')
    f.write(test_data)
    f.close()

    # Create an inventory object
    inventory = InventoryModule()

    # Create a dummy loader object
    loader = object()

    # Parse the file
    inventory.parse(inventory, loader, f.name)

    # This is the expected data, note the format here is different so that the code can be shorter.


# Generated at 2022-06-11 14:33:04.607591
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # This is a unit test for the parse method of class InventoryModule
    # The test checks the first two hosts in the inventory file generated by
    # the inventory file provided in the EXAMPLES

    # initialize InventoryModule object
    invmod = InventoryModule()

    # create inventory object
    inv = {}
    inv["vars"] = {}
    inv["groups"] = {}

    # Call parse method
    # The EXAMPLES file is used as the input file
    invmod.parse(inv, "loader", "/tmp/inv", cache=False)

    # Test the results of the parse method
    # Test the first host
    assert("build_api_dev_runner" in inv["groups"]["build"]["children"])
    assert("build_api_dev_runner" in inv["groups"]["api"]["children"])


# Generated at 2022-06-11 14:33:13.540728
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import os
    import sys
    import os.path
    import tempfile
    import shutil
    from ansible.plugins.inventory import BaseInventoryPlugin
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group


# Generated at 2022-06-11 14:33:24.872830
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    """
    Test for InventoryModule parse method.
    Test is run with a memory inventory file content.
    """
    from ansible.cli import CLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 14:33:33.418908
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    res = inventory.verify_file(path = '/file/path/with/yaml/extension.yaml')
    assert res == True
    res = inventory.verify_file(path = '/file/path/with/yml/extension.yml')
    assert res == True
    res = inventory.verify_file(path = '/file/path/with/config/extension.config')
    assert res == True
    res = inventory.verify_file(path = '/file/path/with/foo/extension.foo')
    assert res == False


# Generated at 2022-06-11 14:33:44.703832
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    def test_case(input_vars, expected_results, test_name):
        inventory = InventoryManager(loader=DataLoader(), sources='')

        # Setup inventory
        config = dict(
            hosts=dict(
                name='test',
                parents=input_vars['parents']
            ),
            layers=dict(
                application=['web', 'api'],
                environment=['staging', 'production']
            )
        )

        template_inputs = product(*config['layers'].values())
        for item in template_inputs:
            template_vars = dict()
            for i, key in enumerate(config['layers'].keys()):
                template_vars[key]

# Generated at 2022-06-11 14:33:54.278254
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import unittest
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class Config:
        YAML_FILENAME_EXTENSIONS = list(C.YAML_FILENAME_EXTENSIONS)
        YAML_FILENAME_EXTENSIONS.append('config')
        def __init__(self, cfg):
            self.cfg = cfg

    class TestInventoryModule(unittest.TestCase):
        def setUp(self):
            self.options = {'plugin': ['plugin']}
            self.loader = DataLoader()
            self.variable_manager = VariableManager()


# Generated at 2022-06-11 14:34:06.350984
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    assert module.verify_file('inventory.config')
    assert module.verify_file('inventory.yml')
    assert module.verify_file('inventory.yaml')
    assert module.verify_file('inventory.json')
    assert not module.verify_file('inventory.py')
    assert not module.verify_file('inventory')
    assert not module.verify_file('')


# Generated at 2022-06-11 14:34:14.233067
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    import os
    import ansible.inventory.manager

    plugin = InventoryModule()
    inventory = ansible.inventory.manager.InventoryManager(loader=None, sources='localhost,')
    plugin.parse(inventory, None, os.path.dirname(__file__) + '/generator_example.config')
    #print(inventory.hosts.keys())
    assert 'build_web_dev_runner' in inventory.hosts
    assert 'build_web_dev' in inventory.groups
    assert 'build_web' in inventory.groups
    assert 'build' in inventory.groups

# Generated at 2022-06-11 14:34:16.155388
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    _test_InventoryModule_parse()


# Generated at 2022-06-11 14:34:23.597534
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    path = create_temp_file(
        '''
        plugin: generator
        hosts:
            name: "{{ operation }}_{{ application }}_{{ environment }}_runner"
        layers:
            operation:
                - build
                - launch
            environment:
                - dev
                - test
                - prod
            application:
                - web
                - api
        '''
    )
    config = InventoryModule()._read_config_data(path)

    template_inputs = product(*config['layers'].values())
    for item in template_inputs:
        template_vars = dict()
        for i, key in enumerate(config['layers'].keys()):
            template_vars[key] = item[i]

# Generated at 2022-06-11 14:34:27.860153
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    # Check for valid input
    assert inv_mod.verify_file("inventory.config") is True
    # Check for invalid input
    assert inv_mod.verify_file("/home/user/inventory.yml") is False

# Generated at 2022-06-11 14:34:29.472361
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.plugins.inventory.yaml import InventoryModule

    loader = 'fake_loader'
    path = 'fake_path'
    inventory = 'fake_inventory'
    assert isinstance(InventoryModule(), InventoryModule)
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, path)

# Generated at 2022-06-11 14:34:36.288516
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # Tests that verify_file:
    # - Returns false for incorrect file types
    # - Returns True for correct YAML file types
    # - Returns True for correct C(.config) file types

    valid_yaml_file = "inventory.yml"
    valid_config_file = "inventory.config"
    invalid_file = "inventory.json"
    test_instance = InventoryModule()
    assert test_instance.verify_file(valid_yaml_file) == True
    assert test_instance.verify_file(valid_config_file) == True
    assert test_instance.verify_file(invalid_file) != True


# Generated at 2022-06-11 14:34:40.820561
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()
    assert plugin.verify_file('/path/to/inventory.yml')
    assert not plugin.verify_file('/path/to/inventory.cfg')
    assert plugin.verify_file('/path/to/inventory.config')

# Generated at 2022-06-11 14:34:41.869590
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass

# Generated at 2022-06-11 14:34:51.741964
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """ Unit test for method verify_file of class InventoryModule

        Expected behaviour:
            - verify_file should return True if file extension is .yaml, .yml or .config

        Test Case:
            - verify_file called with .yaml or .yml or .config file as input
    """

    test_file_extensions = ['.yaml', '.yml', '.config']
    test_file_name = "test_file"
    test_file_path = ""
    generated_file_paths = []

    inventory_module = InventoryModule()

    # Create test files with different extensions
    for ext in test_file_extensions:
        test_file_path = test_file_name + ext
        generated_file_paths.append(test_file_path)

# Generated at 2022-06-11 14:35:15.449421
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.plugins import InventoryModule
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.template import Templar

    # initialize template engine and inventory
    templar = Templar(loader=None)
    inventory = InventoryManager(loader=None, sources=[])
    inventory.add_host(Host(name='test_host_name'))
    inventory.add_host(Host(name='empty_host_name'))
    inventory.add_host(Host(name='invalid_parent_name'))

    # initialize class under test
    class_under_test = InventoryModule()
    class_under_test.templar = templar

   

# Generated at 2022-06-11 14:35:23.440117
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    module = InventoryModule()


# Generated at 2022-06-11 14:35:32.547016
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    '''
    unit test for method add_parents of class InventoryModule
    '''
    from ansible.plugins.inventory.ini import InventoryModule
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 14:35:42.229319
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import tempfile

    class_ = InventoryModule()
    loader = AnsibleLoader()
    inventory = AnsibleInventory()

    # InventoryModule.parse() should raise AnsibleParserError if an element of a parent has no name

# Generated at 2022-06-11 14:35:50.193360
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    class FakeInventory(object):
        def __init__(self):
            self.groups = dict()

        def add_group(self, group_name):
            self.groups[group_name] = {'vars': {}}
            return self.groups[group_name]

        def add_child(self, group_name, child_name):
            self.groups[group_name]['children'] = child_name

    inventory = FakeInventory()
    inventory_module = InventoryModule()
    child_name = 'child'
    parent = dict()
    parent['name'] = 'parent_{{foo}}'
    inventory_module.add_parents(inventory, child_name, [parent], dict(foo='bar'))
    assert 'parent_bar' in inventory.groups

# Generated at 2022-06-11 14:35:56.293048
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Mock object of class InventoryModule.
    class MockInventoryModule(InventoryModule):
        pass

    mock_inventory = MockInventoryModule()
    # Case 1: Non-existant file does not exists
    assert(mock_inventory.verify_file('non-existant.config') == False)
    # Case 2: A valid file exists
    assert(mock_inventory.verify_file('test_generator_plugin.yml') == True)


# Generated at 2022-06-11 14:35:58.209030
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    plugin = InventoryModule()
    assert plugin.template('Test {{ var }}', {'var': 'foo'}) == 'Test foo'

# Generated at 2022-06-11 14:36:02.460419
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    inventory = Inventory(loader=DataLoader(), variable_manager=None, host_list=None)
    # TODO: add some tests

    return inventory

# Generated at 2022-06-11 14:36:12.344479
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import sys
    import unittest

    test_class_name = 'InventoryModuleTest'

    class InventoryMock:
        def __init__(self, _):
            self.inventory = dict()

        def add_host(self, hostname):
            self.inventory[hostname] = dict()

        def add_group(self, groupname):
            self.inventory[groupname] = dict()

        def add_child(self, groupname, child):
            self.inventory[groupname]['children'] = self.inventory[groupname].get('children', set())
            self.inventory[groupname]['children'].add(child)

        def get_host(self, hostname):
            return self.inventory[hostname]


# Generated at 2022-06-11 14:36:21.912469
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=None,
                                 vault_password=loader.vault_password)

    im = InventoryModule()

    im.parse(inventory, loader, 'tests/inventory/' +
             'test_generator_inventory_config.yaml')

    # verify that 10 groups have been created
    assert len(inventory.groups) == 10
    # verify that web-api-dev and web-api-prod child groups have been created
    assert 'web-api-dev' in inventory.groups
    assert 'web-api-prod' in inventory.groups
    # verify that web-api-dev has 3 hosts and web-api-prod has 5 hosts


# Generated at 2022-06-11 14:36:49.327482
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file('inventory.config')
    assert InventoryModule().verify_file('inventory.yaml')
    assert InventoryModule().verify_file('inventory.yml')
    assert not InventoryModule().verify_file('inventory.xml')
    assert not InventoryModule().verify_file('inventory.pl')

# Generated at 2022-06-11 14:36:56.567498
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''Unit test for method parse of class InventoryModule'''

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryConfig({}, loader=loader)
    generator = InventoryModule()
    config = loader.load_from_file("inventory-generator.config")
    results = generator._parse(inventory, loader, config, cache=False)
    assert results == [("build_web_dev_runner", \
        {"children": ['build_web_dev', 'web_dev', 'build_dev', 'build_web', 'web', 'dev', 'web_dev_runner', 'runner']})]

# Generated at 2022-06-11 14:37:08.318364
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 14:37:10.634958
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    path = 'inventory_sample.yml'
    if module.verify_file(path):
        print(path, 'is valid')
    else:
        print(path, 'is invalid')

# Generated at 2022-06-11 14:37:21.939212
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import sys
    mod = sys.modules[__name__]
    import ansible.plugins.inventory
    ansi = ansible.plugins.inventory
    inv = ansi.Inventory(loader=None)
    inv_module = mod.InventoryModule()
    host = {'name': 'host'}
    parents = [{'name': 'parent', 'parents': [{'name': 'grandparent'}]}, {'name': 'parent2'}]
    template_vars = {'test': 'value'}
    inv_module.add_parents(inv, host, parents, template_vars)
    assert inv.groups['parent'].vars['test'] == 'value'
    assert inv.groups['parent2'].vars['test'] == 'value'

# Generated at 2022-06-11 14:37:26.513077
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """
        Unit test to verify_file of class InventoryModule
    """
    plugin = InventoryModule()
    assert plugin.verify_file('./mytest.txt') == False
    assert plugin.verify_file('./mytest.config') == True

# Generated at 2022-06-11 14:37:36.016689
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import tempfile
    import os
    import shutil
    from ansible.plugins.inventory import Host
    from ansible.parsing.dataloader import DataLoader

    test_file = os.path.join(tempfile.gettempdir(), 'test_generator_method_add_parents.config')


# Generated at 2022-06-11 14:37:45.995021
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory = dict()
    child = dict()
    child['name'] = 'hostname'
    parents = [
        {'name': '{{ application }}{{environment}}', 'vars': {'application': '{{ application }}'}},
        {'name': '{{ application }}'}
        ]
    template_vars = dict()
    template_vars['application'] = 'app'
    template_vars['environment'] = 'dev'
    inventory['groups']['appdev'] = dict()
    inventory['groups']['appdev']['vars'] = dict()
    inventory['groups']['appdev']['children'] = dict()
    inventory['groups']['appdev']['vars']['application'] = 'app'
    inventory['groups']['app'] = dict()

# Generated at 2022-06-11 14:37:50.316749
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # pylint: disable=invalid-name
    mock_path = '/tmp/ansible_inventory'
    test_inventory_module = InventoryModule()
    test_inventory_module.verify_file(mock_path)

# Generated at 2022-06-11 14:37:54.397339
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()
    assert plugin.verify_file('file.yaml')
    assert plugin.verify_file('file.yml')
    assert plugin.verify_file('file.config')
    assert plugin.verify_file('file.')
    assert not plugin.verify_file('file.not')


# Generated at 2022-06-11 14:38:53.980827
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Test prep
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    import yaml
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    test_path = os.path.join(os.path.dirname(__file__), 'test_data/generator/inventory.config')
    path_data = file(test_path, 'rb')
    loader = DataLoader()
    config = yaml.safe_load(path_data)
    inventory = Group()
    inventory.add_host(Host('dummy_host'))
    inventory.add_group(Group('dummy_group'))

# Generated at 2022-06-11 14:39:05.539362
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    plugin = InventoryModule()

    loader = DataLoader()
    variableManager = VariableManager()
    inventory = Inventory(loader=loader, variableManager=variableManager)
    host = plugin.template('{{ operation }}_{{ application }}_{{ environment }}_runner', {'operation': 'build', 'application': 'web', 'environment': 'dev'})
    assert host == 'build_web_dev_runner'

    loader = DataLoader()
    variableManager = VariableManager()
    inventory = Inventory(loader=loader, variableManager=variableManager)
    host = plugin.template('{{ operation }}_{{ application }}_{{ environment }}_runner', dict(operation='build', application='web', environment='dev'))


# Generated at 2022-06-11 14:39:11.623665
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory_module = InventoryModule()

    inventory_module.templar = VariableManager()

    loader = DataLoader()
    inventory_module.templar.set_available_variables(loader.set_vault_password('secret').get_basedir())

    variables = {'name': 'bob'}

    result = inventory_module.template('Hello {{ name }}', variables)

    assert result == 'Hello bob'

# Generated at 2022-06-11 14:39:23.471070
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.inventory.manager import InventoryManager

    test_data = dict()
    test_data['plugin'] = 'generator'
    test_data['layers'] = dict()
    test_data['layers']['operation'] = ['build', 'launch']
    test_data['layers']['env'] = ['dev', 'test']
    test_data['layers']['app'] = ['web', 'api']
    test_data['hosts'] = dict()
    test_data['hosts']['name'] = "{{ operation }}_{{ app }}_{{ env }}_runner"
    test_data['hosts']['parents'] = []
    host_parent = dict()
    host_parent['name'] = "{{ operation }}_{{ app }}_{{ env }}"

# Generated at 2022-06-11 14:39:34.944816
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import pytest
    from ansible import context
    from ansible.plugins.loader import inventory_loader

    context.CLIARGS = {'vault_password_files': []}

    test_instance = inventory_loader.get('generator')()

    assert(test_instance.template('{{ foo }}', {}) == '{{ foo }}')
    assert(test_instance.template('{{ foo }}', {'foo': 'bar'}) == 'bar')
    with pytest.raises(AnsibleParserError):
        test_instance.template('{{ foo }}', {'foo': 'bar', 'baz': 'qux'})

    assert(test_instance.template('{{ var }}', {'var': 'var'}) == 'var')

# Generated at 2022-06-11 14:39:47.261493
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = os.path.dirname(os.path.realpath(__file__)) + '/../templates/inventory.config'
    instance = InventoryModule()
    inventory = {
        'hosts': [],
        'groups': {},
        'child_groups': {},
        'vars': {},
    }
    config = instance._read_config_data(path)
    assert config["hosts"]["name"] == "{{ operation }}_{{ application }}_{{ environment }}_runner"
    template_inputs = product(*config['layers'].values())
    for item in template_inputs:
        template_vars = dict()
        for i, key in enumerate(config['layers'].keys()):
            template_vars[key] = item[i]

# Generated at 2022-06-11 14:39:53.224018
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    '''
    Tests for the add_parents() method of the InventoryModule class
    '''

    # The method relies on the jinja2 templating so a mock is created in order to
    # get control of the value returned by the templating operations
    class MockTemplar(object):
        def __init__(self):
            self.available_variables = None

        def do_template(self, pattern):
            if self.available_variables is None:
                raise Exception('MockTemplar.do_template() has not been given any available variables')
            else:
                return pattern.format(**self.available_variables)

    class MockInventory(object):
        def __init__(self):
            self.groups = { }
            self.groups['parent_group'] = 'group_object'
