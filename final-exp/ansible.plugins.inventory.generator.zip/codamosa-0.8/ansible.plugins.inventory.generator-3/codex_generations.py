

# Generated at 2022-06-11 14:29:59.266620
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import unittest

    class TestStringMethods(unittest.TestCase):
        def test_upper(self):
            inventory = InventoryModule()

            pattern = 'test/{{ var1 }}/{{ var2 }}'
            variables = {'var1': 'foo', 'var2': 'bar'}
            result = inventory.template(pattern, variables)
            self.assertEqual('test/foo/bar', result)
            self.assertTrue(result.startswith('test/'))

    unittest.main()

# Generated at 2022-06-11 14:30:06.207515
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import unittest
    from ansible.parsing.mod_args import ModuleArgsParser
    parser = ModuleArgsParser()
    global_vars = {}
    templar = parser.template()
    test_obj = InventoryModule()
    test_obj.templar = templar
    test_obj.templar.available_variables = global_vars
    input_pattern = '{{ operation }}_{{ application }}_{{ environment }}_runner'
    test_variables = {'operation': 'build', 'environment': 'dev', 'application': 'web'}
    test_output = 'build_web_dev_runner'
    assert test_output == test_obj.template(input_pattern, test_variables)


# Generated at 2022-06-11 14:30:06.905241
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass

# Generated at 2022-06-11 14:30:13.527385
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.plugins.inventory import InventoryPlugin
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    inventory_plugin = InventoryPlugin(filename='/path/to/plugin')
    inventory_module = InventoryModule()
    inventory_module.templar = Templar()
    inventory_module.templar.loader = AnsibleLoader(None, None, None)
    assert inventory_module.template("{{ test }}", {'test': 'match'}) == 'match'

# Generated at 2022-06-11 14:30:25.763070
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:30:35.979277
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/ansible/inventory/generator.config'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    plugin = InventoryModule()
    plugin.parse(inventory, loader, 'test/ansible/inventory/generator.config')

    hosts = inventory.get_hosts()
    assert len(hosts) == 6
    variables = hosts[0].get_vars()
    assert variables['operation'] == 'build'
    assert variables['environment'] == 'dev'
    assert variables['application'] == 'web'

    groups = inventory.get_groups()

# Generated at 2022-06-11 14:30:46.906420
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Ensure that the parse method does what we need 
    '''
    # create a fake inventory plugin to test class InventoryModule
    from ansible.plugins import inventory
    from ansible.plugins.inventory.manager import InventoryManager
    class TestInventoryModule(inventory.BaseInventoryPlugin):
        NAME = 'test'
        def verify_file(self, path):
            return False
        def parse(self, inventory, loader, path, cache=False):
            pass
    # replace original InventoryManager class with the fake one
    original_manager_class = inventory.InventoryManager
    inventory.InventoryManager = TestInventoryModule
    # test InventoryModule class
    invmod = InventoryModule()

# Generated at 2022-06-11 14:30:52.738935
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
   import ansible.plugins.loader 
   plugin = ansible.plugins.loader.inventory_loader.get("generator", class_only=True)()
   assert plugin.template("hello", {"name":"world"}) == "hello"
   assert plugin.template("hello {{ name }}", {"name":"world"}) == "hello world"
   assert plugin.template("hello {{ name }}", {"name":"{{ name }}"}) == "hello {{ name }}"
   assert plugin.template("hello {{ name }}", {}) == "hello "
   assert plugin.template("hello", {"name":"{{ name }}"}) == "hello"

# Generated at 2022-06-11 14:31:02.005415
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Create a mock inventory object
    inventory = InventoryManager(loader)

    # Create a mock child Host object
    child = Host('child')

    # Create a mock parents list

# Generated at 2022-06-11 14:31:07.981967
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    plugin = InventoryModule()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='Generator Test')
    variable_mgr = VariableManager()
    plugin.parse(inventory, loader, 'Generator Test', cache=True)

    group = inventory.groups.get('launch_web_prod')
    assert group.get_variables()['environment'] == 'prod'

    host = inventory.get_host('launch_web_prod_runner')
    assert host.name == 'launch_web_prod_runner'

# Generated at 2022-06-11 14:31:21.782346
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    """
    Unit test for method add_parents of class InventoryModule.
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    import pytest
    test_loader = DataLoader()
    test_inv = InventoryManager(loader=test_loader, sources=[])
    test_add_parents = InventoryModule().add_parents

    # add some hosts
    test_inv.add_host(Host("web-runner"))
    test_inv.add_host(Host("product-api-dev"))
    test_inv.add_host(Host("product-api-prod"))
    test_inv.add_host(Host("cart-api-dev"))

# Generated at 2022-06-11 14:31:22.420600
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert False

# Generated at 2022-06-11 14:31:28.052399
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # arrange
    inventory = object
    loader = object
    path = "ansible-config-test/test_ansible_config_ok.config"
    cache = False
    inventory_obj = InventoryModule()

    # act
    inventory_obj.parse(inventory, loader, path, cache)

    # assert
    assert inventory.hosts.get('web_build_dev_runner') is not None

# Generated at 2022-06-11 14:31:38.409684
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=DataLoader(), sources='./test_sources')
    inventory_module = InventoryModule()
    inventory_module.add_parents = InventoryModule.add_parents

    # Test for all the nodes in a tree
    #
    #       /  \
    #      a    b
    #     / \  / \
    #    c   d e   f
    #
    # Expected result
    #
    # Host: a
    #   Parents: None
    # Host: b
    #   Parents: None
    # Host: c
    #   Parent: a
    # Host: d
    #   Parent: a
    # Host: e

# Generated at 2022-06-11 14:31:49.222167
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import os
    import sys
    import unittest
    import ansible.plugins.inventory.generator

    script_dir = os.path.dirname(ansible.plugins.inventory.generator.__file__)
    sys.path.insert(0, os.path.join(script_dir, '..', '..', '..', 'lib', 'ansible'))

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    empty_inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager()

    inventory_module = InventoryModule()

    # Test case for empty parents list
   

# Generated at 2022-06-11 14:31:53.934233
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    inv = InventoryModule()
    assert inv.verify_file("sample.config")
    assert inv.verify_file("sample.yml")
    assert inv.verify_file("sample.yaml")
    assert not inv.verify_file("sample")
    assert not inv.verify_file(os.path.join("sample", "sample.yaml"))
    assert not inv.verify_file("sample.txt")

# Generated at 2022-06-11 14:32:05.015241
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import pytest
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    inventoryModule = InventoryModule()

    class mock_Inventory:
        def __init__(self):
            self.groups = dict()

        def add_group(self, group):
            self.groups[group] = Group(group)

        def add_host(self, host):
            self.hosts[host] = Host(host)

        def add_child(self, group, child):
            self.groups[group].add_child(child)

    class MockTemplar:
        def __init__(self):
            self.available_variables = dict()

        def do_template(self, pattern):
            return pattern

    inventoryModule.templar = MockTemplar()

    inventory = mock_In

# Generated at 2022-06-11 14:32:14.004916
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import copy
    import unittest
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.ini import InventoryParser

    class TestInventoryModule(InventoryModule):
        def __init__(self):
            super(TestInventoryModule, self).__init__()

        def template(self, pattern, variables):
            return pattern.format(**variables)

    # initial load of the plugin
    inventory = InventoryParser([], [], None, cache=False)
    plugin = TestInventoryModule()

# Generated at 2022-06-11 14:32:15.315623
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory.parse("inventory.config")

# Generated at 2022-06-11 14:32:23.775279
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    from ansible.plugins.inventory import InventoryModule
    import jinja2

    class Inventory:
        def __init__(self):
            self.groups = dict()
        def add_group(self, name):
            self.groups[name] = InventoryGroup()
        def add_child(self, gname, hname):
            self.groups[gname].add_child(hname)
        def add_host(self, name):
            self.groups[name] = InventoryGroup()
            self.groups[name].name = name

    class InventoryGroup:
        def __init__(self):
            self.children = []
            self.variables = dict()
        def add_child(self, name):
            self.children.append(name)
        def set_variable(self, k, v):
            self.variables

# Generated at 2022-06-11 14:32:34.634706
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from ansible.plugins.inventory.generator import InventoryModule
    from ansible.plugins.inventory import BaseInventoryPlugin
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    class TestInventory(BaseInventoryPlugin):
        def __init__(self):
            self.inventory = {
                '_meta': {
                    'hostvars': HostVars()
                }
            }
            self.cache = {}
            self.vars = VariableManager()


# Generated at 2022-06-11 14:32:46.235691
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from collections import namedtuple

    class ExampleInventoryPlugin(BaseInventoryPlugin):
        def parse(self, inventory, loader, path, cache=False):
            pass

    ExampleInventoryModule = namedtuple('ExampleInventoryModule', ['plugin', 'hosts', 'layers'])

# Generated at 2022-06-11 14:32:57.709919
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {
        "plugin": "generator",
        "hosts": {
            "name": "{{operation}}_{{application}}_{{environment}}_runner"
        },
        "layers": {
            "operation": [
                "build",
                "launch"
            ],
            "environment": [
                "dev",
                "test",
                "prod"
            ],
            "application": [
                "web",
                "api"
            ]
        }
    }

    inventory_module = InventoryModule()

    # Load cache
    cache_file = "/tmp/generator_parse_test.cache"
    with open(cache_file, 'w') as cache:
        import json
        json.dump(
            {"hosts": {}, "groups": {}},
            cache,
        )


# Generated at 2022-06-11 14:33:08.357453
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = unittest.mock.MagicMock()
    inventory = unittest.mock.MagicMock()
    inventory_module = InventoryModule()
    inventory_module.parser = unittest.mock.MagicMock()
    inventory_module.parser.templar = unittest.mock.MagicMock()
    inventory_module.parser.templar.do_template = unittest.mock.MagicMock()
    inventory_module.templar = unittest.mock.MagicMock()
    inventory_module.templar.do_template = unittest.mock.MagicMock()
    inventory_module._read_config_data = unittest.mock.MagicMock()
    config

# Generated at 2022-06-11 14:33:16.673006
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class Inventory(object):
        def __init__(self):
            self.hosts = dict()
            self.groups = dict()

        def add_host(self, host):
            self.hosts[host] = host
            if host not in self.groups:
                self.groups[host] = dict()

        def add_group(self, group):
            self.groups[group] = dict()

        def add_child(self, group, child):
            if group not in self.groups:
                print('ERROR: group %s not found in self.groups' % group)
                return
            if 'children' in self.groups[group]:
                self.groups[group]['children'].append(child)
            else:
                self.groups[group]['children'] = [child]
                
    inventory = Inventory()


# Generated at 2022-06-11 14:33:26.764118
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins import inventory
    from ansible.parsing.dataloader import DataLoader

    # Load the inventory plugin class
    inv = inventory.get_inventory_plugin_class(InventoryModule.NAME)()

    # Create an empty inventory object
    inv_obj = inv.construct_inventory([])

    # Create a dataloader
    loader = DataLoader()

    # Void function, so test coverage
    inv_obj = inv.parse(inv_obj, loader, "inventory.config")

    # Test the result

# Generated at 2022-06-11 14:33:31.316305
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    inventory = inventory_loader.get('generator', loader=None, b_path="/etc/")
    plugin = InventoryModule()
    result = plugin.parse(inventory, loader=None, path="inventory")

    assert True # No error was raised


# Generated at 2022-06-11 14:33:42.940810
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import unittest
    import ansible.plugins.inventory.generator as generator
    import ansible.inventory.host, ansible.inventory.group, ansible.inventory.manager
    import ansible.vars.manager
    loader = unittest.mock.Mock()
    host1 = ansible.inventory.host.Host('host1')
    host2 = ansible.inventory.host.Host('host2')
    group1 = ansible.inventory.group.Group('group1')
    group1.add_host(host1)
    group2 = ansible.inventory.group.Group('group2')
    group2.add_host(host2)
    inventory = ansible.inventory.manager.InventoryManager(loader, host_list=[host1, host2])
    vars_manager = ansible.vars.manager

# Generated at 2022-06-11 14:33:50.435879
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ''' test method InventoryModule.parse '''
    module = InventoryModule()
    class loader:
        pass
    class inventory:
        ''' fake inventory class '''
        def __init__(self):
            self.hosts = {}
            self.groups = {}
        def add_host(self, hostname):
            self.hosts[hostname] = hostname
        def add_group(self, groupname):
            self.groups[groupname] = groupname
        def add_child(self, groupname, hostname):
            self.groups[groupname].add(hostname)
    class group:
        ''' fake group class '''
        def __init__(self):
            self.vars = {}
        def set_variable(self, key, value):
            self.vars[key] = value
   

# Generated at 2022-06-11 14:33:58.284000
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import ansible.plugins.loader as plugin_loader
    import sys

    if sys.version_info >= (3, 0):
        import io
        builtin_open = 'builtins.open'
        raw = io.StringIO
    else:
        import StringIO
        builtin_open = '__builtin__.open'
        raw = StringIO.StringIO

    loader = plugin_loader.PluginLoader()
    invmod = loader.get('generator')()
    invmod.inventory = loader.get('inventory')()
    invmod.templar = loader.get('template')()
    invmod.templar.set_available_variables({'foo': 'foo'})
    invmod.templar._basedir = os.path.dirname('/a/b/c/d.yaml')
    inv

# Generated at 2022-06-11 14:34:19.185625
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:34:31.221218
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import ansible.plugins.inventory.generator
    inventory = ansible.plugins.inventory.HostInventory()
    plugin = ansible.plugins.inventory.generator.InventoryModule()

# Generated at 2022-06-11 14:34:42.516678
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from collections import namedtuple
    import unittest

    class InventoryModuleTest(unittest.TestCase):
        def setUp(self):
            c = config = namedtuple('config', 'layers hosts')
            hosts = namedtuple('hosts', 'name parents')
            hosts.parents = [
                namedtuple('parent', 'name parents vars'),
                namedtuple('parent', 'name parents'),
                namedtuple('parent', 'name parents vars')
            ]
            hosts.parents[0].name = "{{ operation }}_{{ application }}_{{ environment }}"
            hosts.parents[0].parents = [
                namedtuple('parent', 'name parents vars'),
                namedtuple('parent', 'name parents')
            ]

# Generated at 2022-06-11 14:34:49.707386
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    assert InventoryModule().verify_file('inventory.config') is True, "Verify with expected valid file"
    assert InventoryModule().verify_file('inventory.yml') is True, "Verify with expected valid file"
    assert InventoryModule().verify_file('inventory.yaml') is True, "Verify with expected valid file"
    assert InventoryModule().verify_file('inventory.cfg') is True, "Verify with expected valid file"
    assert InventoryModule().verify_file('inventory.txt') is False, "Verify with expected invalid file"

# Generated at 2022-06-11 14:34:51.426800
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    assert module.parse(None, None, 'resources/generator/inventory.config') is None

# Generated at 2022-06-11 14:35:01.908196
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Setup
    inventory = InventoryModule()
    loader = AnsibleFileLoader('hosts.yml', 'inventory.config', 
        'ansible.cfg', 'python-2.7.5', '0.0.1')
    path = '/home/test/ansible/inventory.config'
    cache = False

    # Exercise
    inventory.parse(inventory, loader, path, cache)
    
    # Verify
    assert len(inventory.groups) == 11
    assert len(inventory.get_hosts()) == 12
    assert 'prod' in inventory.groups
    assert inventory.groups['prod'].get_vars()['environment'] == 'prod'

# Generated at 2022-06-11 14:35:09.644409
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host


# Generated at 2022-06-11 14:35:20.608346
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = "plugin: generator\n"
    inventory += "hosts:\n"
    inventory += "  name: '{{ operation }}_{{ application }}_{{ environment }}_runner'\n"
    inventory += "  parents:\n"
    inventory += "    - name: '{{ operation }}_{{ application }}_{{ environment }}'\n"
    inventory += "      parents:\n"
    inventory += "        - name: '{{ operation }}_{{ application }}'\n"
    inventory += "          parents:\n"
    inventory += "            - name: '{{ operation }}'\n"
    inventory += "            - name: '{{ application }}'\n"
    inventory += "        - name: '{{ application }}_{{ environment }}'\n"
    inventory += "          parents:\n"

# Generated at 2022-06-11 14:35:26.014774
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    invmod = InventoryModule()
    assert invmod.verify_file("/path/to/something.config")
    assert invmod.verify_file("/path/to/something.yaml")
    assert invmod.verify_file("/path/to/something.yml")
    assert not invmod.verify_file("/path/to/something.ini")



# Generated at 2022-06-11 14:35:33.723851
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:36:02.619523
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # initialize inventory
    inventory = BaseInventoryPlugin()
    inventory.add_host = MagicMock(name="add_host")
    inventory.add_group = MagicMock(name="add_group")
    inventory.add_child = MagicMock(name="add_child")

    # initialize callable
    obj = InventoryModule()
    obj.template = MagicMock(name="template_mock")
    obj.template.return_value = "template_return"

    # create sample object and call add_parents

# Generated at 2022-06-11 14:36:03.727809
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass


# Generated at 2022-06-11 14:36:13.381756
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create an instance of class InventoryModule
    inventoryModule = InventoryModule(None, None)

    # Create a list of hosts with name and parents
    # Hosts contain the following:
    #   - name with template for the hostname
    #   - parents with parent groups and variables
    #       - name with template for the parent group name
    #       - parents with list of parent groups
    #           - name with template for the parent group name
    #           - parents with list of parent groups
    #                 - name with template for the parent group name

# Generated at 2022-06-11 14:36:22.966093
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory = MockInventory()
    generator = InventoryModule()

# Generated at 2022-06-11 14:36:33.816467
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Tests for method add_parents
    # of class InventoryModule.
    import ansible.plugins.inventory.generator
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.utils.vars

    def _template(pattern, variables):
        ansible.plugins.inventory.generator.InventoryModule.templar.available_variables = variables
        return ansible.plugins.inventory.generator.InventoryModule.templar.do_template(pattern)

    inventory_Module = ansible.plugins.inventory.generator.InventoryModule()
    inventory = ansible.inventory.host.HostInventory()

    template_vars = {}
    child = "runner"

# Generated at 2022-06-11 14:36:45.181964
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Create inventory and set groupname
    ini = InventoryModule()
    inventory = ini.inventory
    inventory.groups = {'app_api_prod': None,
                     'app_api': None,
                     'app': None,
                     'api': None,
                     'app_prod': None,
                     'app_api_dev': None,
                     'prod': None,
                     'app_api_test': None,
                     'app_test': None,
                     'test': None,
                     'app_dev': None,
                     'dev': None}

    # Add child, parent and vars to parent
    child = 'app_api_prod_runner'
    parents = [{'name': '{{ operation }}_{{ application }}_{{ environment }}'},
               {'name': 'runner'}]
    template

# Generated at 2022-06-11 14:36:51.913015
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = None
    path = "/Users/fantastico/git/ansible/plugins/inventory/generator/test_data/test.config"
    cache = False

    inventory = InventoryModule().parse(inventory, loader, path, cache)
    assert 'test_ansible_runner' in inventory
    assert 'dev' in inventory['test_ansible_runner']['children']
    assert 'test' in inventory['test_ansible_runner']['children']
    assert 'prod' in inventory['test_ansible_runner']['children']

# Generated at 2022-06-11 14:37:03.049975
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    import tempfile

    from ansible.module_utils.six.moves import StringIO

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager


# Generated at 2022-06-11 14:37:12.150124
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    from __main__ import InventoryModule
    from collections import namedtuple
    from ansible.parsing.yaml import objects
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.inventory import BaseInventoryPlugin

    obj = InventoryModule()

    # Create a variable manager object
    variable_manager = VariableManager()

    # Create a data loader object
    dataloader = DataLoader()

    # Create an inventory object and add it to variable manager
    inventory = InventoryManager(loader=dataloader, sources='')
    variable_manager.set_inventory(inventory)

    # Create a template variables object and add it to variable manager
    template_vars = dict()
    variable_manager

# Generated at 2022-06-11 14:37:23.321191
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    def setup_mock_loader(file_data):
        if file_data:
            loader = MagicMock(BaseLoader)
            loader.load_from_file.return_value = file_data
            return loader

    def get_mock_inventory():
        inventory = MagicMock(InventoryManager)
        inventory.add_host = MagicMock()
        inventory.add_group = MagicMock()
        inventory.add_child = MagicMock()
        return inventory

    def assert_host_added_to_group(groupname, hostname, inventory):
        group = inventory.groups[groupname]
        assert group.name == groupname
        assert group.hosts[hostname]
        assert inventory.add_child.call_count == 1
        assert inventory.add_child.call_args_list[0][0]

# Generated at 2022-06-11 14:38:14.135521
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Create a temp directory to work in
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Create a test config file in YAML format
    filename = tmpdir + os.sep + 'test.config'

# Generated at 2022-06-11 14:38:23.057882
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from __main__ import InventoryModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    obj = InventoryModule()
    loader = DataLoader()
    path = 'tests/inventory/inventory.config'

    inventory = InventoryManager(loader=loader, sources=path)
    obj._read_config_data = lambda x: {
        'layers': {
            'operation': ['build', 'launch'],
            'environment': ['dev', 'test', 'prod'],
            'application': ['web', 'api']
        },
        'hosts': {
            'name': '{{ operation }}_{{ application }}_{{ environment }}_runner'
        }
    }
    obj.parse(inventory, loader, path, cache=False)


# Generated at 2022-06-11 14:38:33.925763
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import ansible.plugins.loader as plugin_loader

    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../'))

    # Test that a valid generator inventory fails because the generator plugin
    # is not enabled
    inventory = BaseInventoryPlugin(loader=None)
    inventory_path = os.path.join(os.path.dirname(__file__), '../generator/inventory_tests/inventory_file.config')
    config_data = {}

# Generated at 2022-06-11 14:38:41.743467
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    """ Test adding groups to inventory with host as child """
    # Initialize inventory object
    new_inv = BaseInventoryPlugin()

    # Check is adding host with one parent group is added
    test_Inv = InventoryModule()
    child = "test_add_parents_0001"
    groupname = "test"
    new_inv.add_host(child)
    new_inv.add_group(groupname)
    host_var_dict = {
        'hosts': {
            'name': child,
            'parents': [
                {'name': groupname}
            ]
        },
        'layers': {}
    }
    test_Inv.add_parents(new_inv, child, host_var_dict['hosts']['parents'], {})

# Generated at 2022-06-11 14:38:52.652718
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # ansible/inventory/plugins/generator
    project_root_path = os.path.join(os.path.dirname(__file__), '../../../')

    inventory_path = os.path.join(project_root_path, 'test/support/generator-inventory.config')

    inventory_module = InventoryModule()

    inventory = inventory_module.inventory
    loader = inventory_module.loader
    cache = False
    inventory_module.parse(inventory, loader, inventory_path, cache)

    # Check result of parse
    assert inventory.hosts['build_web_dev_runner'] == {'hostvars': {}, 'has_key': False, 'vars': {}}

# Generated at 2022-06-11 14:39:03.497784
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import copy
    import unittest
    import ansible.plugins.inventory
    import ansible.parsing.dataloader
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.vars.manager

    class TestInventoryModule(unittest.TestCase):
        def test_add_parents(self):
            loader = ansible.parsing.dataloader.DataLoader()

            inventory_path = "/tmp/test_InventoryModule_add_parents"
            inventory_file = open(inventory_path, 'w')

# Generated at 2022-06-11 14:39:12.719772
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    def get_hosts(inv):
        # walk the dicts of dicts and return hosts
        hosts = set()
        for group_name, group in inv.groups.items():
            for h in group.get_hosts():
                hosts.add(h.name)
        return hosts

    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    from ansible.vars.manager import VariableManager
    vars_mgr = VariableManager()

    from ansible.inventory import Inventory
    inv = Inventory(loader=loader, variable_manager=vars_mgr, host_list=['localhost'])
    inv_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'inventory.config')
    gen_p = InventoryModule()


# Generated at 2022-06-11 14:39:16.354229
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    file_name = "/tmp/inventory.config"
    ext = ".config"
    result = inventory.verify_file(file_name)
    assert result is True

# Generated at 2022-06-11 14:39:25.519576
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    class Config:
        pass
    config = Config()
    setattr(config, 'jinja2_extensions', [])
    setattr(config, 'jinja2_native', True)

    import jinja2
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader, variables={})

    invm = InventoryModule()
    invm.templar = templar

    template =  "{{ foo }}{{ bar }}"
    variables = {'foo': 'foo', 'bar': 'bar'}

    assert(invm.template(template, variables) == 'foobar')

# Generated at 2022-06-11 14:39:36.628048
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    import yaml
    import tempfile
    import os
    import shutil

    display = Display()
    loader = DataLoader()

    host_test = Host(name='web')
    group_test = Group(name='web')

    inventory_path = tempfile.mkdtemp()