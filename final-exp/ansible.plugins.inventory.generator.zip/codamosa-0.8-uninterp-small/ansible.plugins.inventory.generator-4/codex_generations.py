

# Generated at 2022-06-25 09:50:56.868543
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryManager(loader=None, sources=[])
    path_0 = u'inventory.config'
    inventory_module_0.parse(inventory_0, loader=None, path=path_0)


# Generated at 2022-06-25 09:51:02.859034
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    # Test with a known example
    assert isinstance(inventory_module_0.parse(inventory, loader, path, cache=False), bool) is True

if __name__ == "__main__":
    print('Executing tests for inventory_generator')
    test_InventoryModule_parse()
    print('Tests finished')

# Generated at 2022-06-25 09:51:05.594474
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert not inventory_module_0.parse(inventory=None, loader=None, path=None, cache=False)


# Generated at 2022-06-25 09:51:10.098050
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("inventory") == False
    assert inventory_module.verify_file("inventory.config") == True
    assert inventory_module.verify_file("inventory.yaml") == True


# Generated at 2022-06-25 09:51:20.698642
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import copy
    import jinja2.exceptions
    from jinja2 import Template

    inventory_module_0 = InventoryModule()

    template_string_0 = '''{{ operation }}_{{ application }}_{{ environment }}_runner'''

    template_vars = {}

    if isinstance(template_string_0, str):
        template_0 = Template(template_string_0)
    else:
        template_0 = copy.deepcopy(template_string_0)


# Generated at 2022-06-25 09:51:23.100174
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()

    # Test1: Valid input file
    res = inventory_module.verify_file('test_generator.config')
    assert res == True

    # Test2: Invalid input file
    res = inventory_module.verify_file('test_generator.conf')
    assert res == False



# Generated at 2022-06-25 09:51:31.656087
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    def inventory_module_verify_file(path):
        return InventoryModule().verify_file(path)

    inventory_module_verify_file_case_0_path_value = ''
    inventory_module_verify_file_case_0_expected_value = False

    assert inventory_module_verify_file(inventory_module_verify_file_case_0_path_value) \
        == inventory_module_verify_file_case_0_expected_value

    inventory_module_verify_file_case_1_path_value = 'fake.yml'
    inventory_module_verify_file_case_1_expected_value = True

    assert inventory_module_verify_file(inventory_module_verify_file_case_1_path_value) \
        == inventory_module_verify

# Generated at 2022-06-25 09:51:33.840315
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents(inventory=inventory(),child="child",parents=parents(),template_vars=template_vars())


# Generated at 2022-06-25 09:51:41.067347
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    class inventory_0_mock:
        def __init__(self):
            self.hosts = dict()
            self.groups = dict()
        def add_host(self, str_0):
            self.hosts[str_0] = dict()
        def add_group(self, str_0):
            self.groups[str_0] = dict()
            self.groups[str_0]['children'] = dict()
        def add_child(self, str_0, str_1):
            if str_1 in self.groups[str_0]['children']:
                pass
            else:
                self.groups[str_0]['children'][str_1] = dict()

# Generated at 2022-06-25 09:51:45.026905
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    inventory_module_1 = InventoryModule()
    test_template = inventory_module_1.template('{{test_pattern}}, {{test_variable}}', {'test_pattern': 'test successful!', 'test_variable': 'test!'})
    assert test_template == 'test successful!, test!'

# Generated at 2022-06-25 09:51:54.783589
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    ''' test for method template of class InventoryModule '''

    inventory_module = InventoryModule()
    assert inventory_module.template('{{ foo }}', {'foo': 'bar'}) == 'bar'
    assert inventory_module.template('{{ foo }}', {}) == '{{ foo }}'
    assert inventory_module.template('{{ foo * 2 }}', {'foo': 2}) == 4


# Generated at 2022-06-25 09:51:59.565540
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents()



# Generated at 2022-06-25 09:52:04.992261
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    # inventory_module_0 = InventoryModule()
    inventory_module_0 = InventoryModule()
    # Template pattern given as parameter
    pattern = '{{ operation }}_{{ application }}_{{ environment }}_runner'
    # Dictionary of template variables given as a parameter
    variables = {'operation': 'build', 'application': 'web', 'environment': 'dev'}
    expected = 'build_web_dev_runner'
    actual = inventory_module_0.template(pattern, variables)
    assert actual == expected


# Generated at 2022-06-25 09:52:09.108284
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    temp_pattern = '{{ operation }}_{{ application }}_{{ environment }}_runner'
    temp_variables = [{'operation': 'build', 'application': 'web', 'environment': 'dev'}]
    assert inventory_module_1.template(temp_pattern, temp_variables) == 'build_web_dev_runner'


# Generated at 2022-06-25 09:52:13.542534
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert inventory_module_0.verify_file('inventory.config') == True
    assert inventory_module_0.verify_file('inventory.yml') == True
    assert inventory_module_0.verify_file('inventory.yaml') == True
    assert inventory_module_0.verify_file('inventory.yaml') == True
    assert inventory_module_0.verify_file('inventory') == False
    assert inventory_module_0.verify_file('inventory.json') == False


# Generated at 2022-06-25 09:52:19.210519
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = '/usr/local/etc/ansible/inventory/inventory.config'
    result = inventory_module_0.verify_file(path)
    assert result == True

# Generated at 2022-06-25 09:52:23.293284
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
   inventory_module_1 = InventoryModule()
   inventory_module_1.parse()


# Generated at 2022-06-25 09:52:33.900511
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Testing YAML config file with .config extension
    inventory_module_1 = InventoryModule()
    inv_1 = {}
    inv_1['plugin'] = 'generator'
    inv_1['hosts'] = {}
    inv_1['hosts']['name'] = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    inv_1['hosts']['parents'] = []
    inv_1['layers'] = {}
    inv_1['layers']['operation'] = ['build', 'launch']
    inv_1['layers']['environment'] = ['dev', 'test', 'prod']
    inv_1['layers']['application'] = ['web', 'api']
    inventory_module_1.parse({},'','test_case_0.config')

# Unit test

# Generated at 2022-06-25 09:52:36.193246
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass

# Generated at 2022-06-25 09:52:42.971921
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

# Generated at 2022-06-25 09:52:54.222093
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_vars = dict(
            inventory=None,
            loader=None,
            path=None,
            cache=False
        )
    inventory_module_0 = InventoryModule()
    expected = inventory_module_0.parse(**inventory_module_vars)
    actual = inventory_module_0.parse(**inventory_module_vars)
    assert expected == actual, 'Expected: %s, Actual: %s' % (expected, actual)


# Generated at 2022-06-25 09:53:02.916963
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern_0 = 'build'

# Generated at 2022-06-25 09:53:03.902925
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(None,None,None,None)

# Generated at 2022-06-25 09:53:13.483805
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # verify_file(self, path)
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file("/etc/ansible/hosts")
    assert inventory_module_1.verify_file("/etc/ansible/hosts.config")
    assert not inventory_module_1.verify_file("/etc/ansible/hosts.conf")
    assert inventory_module_1.verify_file("/etc/ansible/hosts.yaml")
    assert inventory_module_1.verify_file("/etc/ansible/hosts.yml")
    assert not inventory_module_1.verify_file("/etc/ansible/hosts.json")


# Generated at 2022-06-25 09:53:15.529523
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents(inventory, child, parents, template_vars)



# Generated at 2022-06-25 09:53:18.342787
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    ret = inventory_module_1.add_parents("",{"a":3},"",[])
    assert(ret == None)


# Generated at 2022-06-25 09:53:25.534746
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    config1 = dict()
    config1['hosts'] = dict()
    config1['hosts']['name'] = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    config1['hosts']['parents'] = list()
    config1['hosts']['parents'].append(dict())
    config1['hosts']['parents'][0]['name'] = "{{ operation }}_{{ application }}_{{ environment }}"
    config1['hosts']['parents'][0]['parents'] = list()
    config1['hosts']['parents'][0]['parents'].append(dict())
    config1['hosts']['parents'][0]['parents'][0]['name'] = "{{ operation }}_{{ application }}"

# Generated at 2022-06-25 09:53:26.967495
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse({}, {}, "TEST_PATH")

# Generated at 2022-06-25 09:53:28.354544
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    assert 1 == 1


# Generated at 2022-06-25 09:53:38.552006
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    config_string = """
    plugin: generator

    hosts:
        name: "{{ operation }}_{{ application }}_{{ environment }}_runner"
        parents:
          - name: "{{ operation }}_{{ application }}_{{ environment }}"
            parents:
              - name: "{{ operation }}_{{ application }}"
              - name: "{{ application }}_{{ environment }}"
          - name: runner
    layers:
        operation:
            - build
            - launch
        environment:
            - dev
            - test
            - prod
        application:
            - web
            - api
    """
    file_obj = open("test_0.config", "w")
    file_obj.write(config_string)
    file_obj.close()

    # Instantiate InventoryModule
    inventory_module_0 = InventoryModule()
    #

# Generated at 2022-06-25 09:53:53.856292
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert inventory_module_0.verify_file('test')

# Generated at 2022-06-25 09:54:03.245459
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    ext_list = ['.config'] + C.YAML_FILENAME_EXTENSIONS
    inventory_module_1 = InventoryModule()
    path = 'test.config'
    assert inventory_module_1.verify_file(path)
    path = 'test.yml'
    assert inventory_module_1.verify_file(path)
    path = 'test.yaml'
    assert inventory_module_1.verify_file(path)
    path = 'test.txt'
    assert inventory_module_1.verify_file(path) == False


# Generated at 2022-06-25 09:54:05.801031
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_verify_file = InventoryModule()
    inventory_module_verify_file.verify_file('/home/ansible/sample.config')


# Generated at 2022-06-25 09:54:09.081473
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    inventory_module_1.verify_file("inventory.config")


# Generated at 2022-06-25 09:54:11.047815
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    pattern = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    variables = dict()
    variables['operation'] = 'build'
    variables['application'] = 'web'
    variables['environment'] = 'dev'
    result = inventory_module_1.template(pattern, variables)
    assert result == "build_web_dev_runner"


# Generated at 2022-06-25 09:54:12.358988
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inv_mod_0 = InventoryModule()
    inv_mod_0.add_parents()



# Generated at 2022-06-25 09:54:22.677020
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_add_parents = InventoryModule()

    def mock_template(self, pattern, variables):
        return pattern

    inventory_module_add_parents.template = mock_template.__get__(inventory_module_add_parents, InventoryModule)

    inventory_add_parents = InventoryModule()

    def mock_add_child(self, group, child):
        pass

    def mock_add_group(self, group):
        pass

    inventory_add_parents.add_child = mock_add_child.__get__(inventory_add_parents, InventoryModule)
    inventory_add_parents.add_group = mock_add_group.__get__(inventory_add_parents, InventoryModule)


# Generated at 2022-06-25 09:54:31.330749
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents(Host(name='web_build_dev_runner'))
    inventory_module_0.add_parents(Host(name='web_build_test_runner'))
    inventory_module_0.add_parents(Host(name='web_build_prod_runner'))
    inventory_module_0.add_parents(Host(name='web_launch_dev_runner'))
    inventory_module_0.add_parents(Host(name='web_launch_test_runner'))
    inventory_module_0.add_parents(Host(name='web_launch_prod_runner'))
    inventory_module_0.add_parents(Host(name='api_build_dev_runner'))

# Generated at 2022-06-25 09:54:39.054066
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    # Initialize the emulated inventory plugin
    inventory_module_1 = InventoryModule()
    # Initialize the emulated test input
    inventory_module_1.templar = None
    pattern_1 = "pattern"
    variables_1 = {}
    inventory_module_1.templar.available_variables = variables_1
    # Verify expected results
    #assert (inventory_module_1.template(pattern_1, variables_1) == "pattern")


# Generated at 2022-06-25 09:54:49.959164
# Unit test for method template of class InventoryModule

# Generated at 2022-06-25 09:55:30.996370
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    # Default value for variable template_vars is None

# Generated at 2022-06-25 09:55:38.012253
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Test parse

    :return:
    """

    # test_case_0
    inventory_module_0 = InventoryModule()
    inventory_0 = inventory_module_0.inventory
    loader_0 = inventory_module_0.loader
    path_0 = inventory_module_0.path
    cache_0 = inventory_module_0.cache
    # call the parse method
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:55:47.291740
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    """
    Constructs Jinja2 template expressions
    """

    # From examples
    # inventory.config file in YAML format
    # remember to enable this inventory plugin in the ansible.cfg before using
    # View the output using `ansible-inventory -i inventory.config --list`
    # plugin: generator
    # hosts:
    #    name: "{{ operation }}_{{ application }}_{{ environment }}_runner"
    #    parents:
    #      - name: "{{ operation }}_{{ application }}_{{ environment }}"
    #        parents:
    #          - name: "{{ operation }}_{{ application }}"
    #            parents:
    #              - name: "{{ operation }}"
    #              - name: "{{ application }}"
    #          - name: "{{ application }}_{{ environment }}"
    #            parents

# Generated at 2022-06-25 09:55:54.545293
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    """
    Test case for add_parents of class `InventoryModule`

    """
    print("Inside test_InventoryModule_add_parents")
    inventory_module = InventoryModule()
    inventory = {}
    child = 'foo'
    parent0 = {'name': 'bar_0', 'vars': {'nested_vars': '4'}}
    parent1 = {'name': 'bar_1', 'parents': [parent0]}
    parent2 = {'name': 'bar_2', 'parents': [parent0]}
    parents = [parent1, parent2]
    template_vars = {'bar_0': 'nested'}
    inventory_module.add_parents(inventory, child, parents, template_vars)
    print("inventory: ", inventory)

# Generated at 2022-06-25 09:55:56.592521
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("inventory_module_1.inventory","loader_1","path_1",True)


# Generated at 2022-06-25 09:56:00.349344
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file('abcd.config') ==  True


# Generated at 2022-06-25 09:56:07.301492
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    config = {}
    config['hosts'] = {}
    config['hosts']['parents'] = {}
    config['hosts']['parents'][0] = {}
    config['hosts']['parents'][0]['name'] = "{{ application }}"
    config['hosts']['parents'][0]['vars'] = {}
    config['hosts']['parents'][0]['vars']['application'] = "{{ application }}"
    config['hosts']['parents'][1] = {}
    config['hosts']['parents'][1]['name'] = "{{ environment }}"
    config['hosts']['parents'][1]['vars'] = {}

# Generated at 2022-06-25 09:56:12.373275
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    var = '{{ operation }}_{{ application }}_{{ environment }}_runner'
    var_1 = {'environment': 'dev', 'operation': 'build', 'application': 'web'}
    result = inventory_module_0.template(var, var_1)
    assert result == 'build_web_dev_runner'



# Generated at 2022-06-25 09:56:15.918365
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    result = InventoryModule().parse(inventory, loader, path, cache=False)
    assert result == base

# Generated at 2022-06-25 09:56:17.841541
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()



# Generated at 2022-06-25 09:56:38.773443
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_0 = InventoryModule()

    # set up test data
    path_0 = "/tmp/ansible_inventory_generator_payload.txt"

    # perform the test action
    ret_0 = inventory_module_0.verify_file(path_0)

    assert ret_0


# Generated at 2022-06-25 09:56:49.148885
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:56:52.653976
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    pattern_1 = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    variables_1 = {"operation": "build", "application": "web", "environment": "dev"}
    test_value = inventory_module_1.template(pattern_1, variables_1)
    assert test_value == "build_web_dev_runner"


# Generated at 2022-06-25 09:56:59.421117
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_obj = InventoryModule()

    #  Test positive case

    # Test cases for case 0
    # Test positive case

    # Test cases for case 0


# Generated at 2022-06-25 09:57:06.070722
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()

    inventory_1 = inventory_module_1.Inventory()
    inventory_1.add_host('host')
    inventory_1.add_group('group')

    inventory_1.add_child('group', 'host')

    assert 'host' in inventory_1.groups['group'].hosts


# Generated at 2022-06-25 09:57:11.347407
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern = 'foo_bar'
    variables = dict()
    expected = 'foo_bar'
    actual = inventory_module_0.template(pattern, variables)
    assert actual == expected



# Generated at 2022-06-25 09:57:18.240448
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    test_parse_src_dir = os.path.dirname(os.path.realpath(__file__))
    test_parse_src_path = os.path.join(test_parse_src_dir, "inventory.config")
    inventory_module_1.parse(inventory_module_1.inventory, "", test_parse_src_path)


# Generated at 2022-06-25 09:57:19.834441
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(inventory_module_0, 'loader', 'path', cache='cache') == None


# Generated at 2022-06-25 09:57:26.350105
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module = InventoryModule()

    inventory = InventoryParser(loader=None, host_list=[])
    path = './ansible/inventory/generator/test_case_0'
    inventory_module.parse(inventory, loader=None, path=path)

    assert(inventory.groups.__len__() == 11)
    assert(inventory.groups['web_dev_runner'].__len__() == 1)
    assert(inventory.groups['build_web_dev'].hosts.__len__() == 1)
    assert(inventory.groups['runner'].__len__() == 12)
    assert(inventory.groups['web_dev'].vars['application'] == 'web')
    assert(inventory.groups['test'].vars['environment'] == 'test')

# Generated at 2022-06-25 09:57:29.944581
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    hostvars = {}
    hostnames = []
    for host in InventoryModule().parse(hostvars, '', './tests/inventory.config'):
        hostnames.append(host)
    assert(hostnames[0] == "build_web_dev_runner")

# Generated at 2022-06-25 09:58:18.233322
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    config = dict()
    config['layers'] = dict()
    config['layers']['operation'] = ['build', 'launch']
    config['layers']['environment'] = ['dev', 'test', 'prod']
    config['layers']['application'] = ['web', 'api']
    config['hosts'] = dict()
    config['hosts']['name'] = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    config['hosts']['parents'] = list()
    config['hosts']['parents'].append(dict())
    config['hosts']['parents'][0]['name'] = "{{ operation }}_{{ application }}_{{ environment }}"
    config['hosts']['parents'][0]['parents']

# Generated at 2022-06-25 09:58:24.557906
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern = 'myhost_'
    variables = {'environment': 'dev', 'application': 'web', 'operation': 'build'}
    assert inventory_module_0.template(pattern, variables) == 'myhost_'
    variables = {'environment': 'test', 'application': 'web', 'operation': 'build'}
    assert inventory_module_0.template(pattern, variables) == 'myhost_'
    variables = {'environment': 'dev', 'application': 'api', 'operation': 'build'}
    assert inventory_module_0.template(pattern, variables) == 'myhost_'
    variables = {'environment': 'prod', 'application': 'web', 'operation': 'launch'}

# Generated at 2022-06-25 09:58:31.513033
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    inventory_module_0 = InventoryModule()
    pattern = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    variables = {
        "operation": "build",
        "application": "web",
        "environment": "dev"
    }

    result = inventory_module_0.template(pattern, variables)

    assert("build_web_dev_runner" == result)

# Generated at 2022-06-25 09:58:35.283092
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('a', 'b', 'c', 'd')


# Generated at 2022-06-25 09:58:36.965501
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = BaseInventoryPlugin()
    inventory_module_1.parse(inventory_1, loader=None, path=None, cache=None)


# Generated at 2022-06-25 09:58:42.139223
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    pattern = 'build_web_prod_runner'
    variables = {'operation': 'build', 'application': 'web', 'environment': 'prod'}
    inventory_module_1.template(pattern, variables)
    # ToDo: should we be checking the output result is as expected?


# Generated at 2022-06-25 09:58:46.871859
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    
    module = InventoryModule()
    inventory = dict()
    loader = dict()
    path = dict()
    cache = dict()
    module.parse(inventory, loader, path, cache)



if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:58:53.284998
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import yaml

    test_file_path_0 = yaml.load(EXAMPLES)
    inventory_module_0 = InventoryModule()
    input_template = test_file_path_0['hosts']['name']
    input_variables = test_file_path_0['layers']
    inventory_module_0.template(input_template, input_variables)


# Generated at 2022-06-25 09:58:54.744810
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_add_parents_0 = InventoryModule()
    inventory_add_parents_0.parse()

# Generated at 2022-06-25 09:59:01.271626
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_loader_mock_0 = mock.MagicMock()
    inventory_mock_0 = mock.MagicMock()
    inventory_mock_0.__getitem__.return_value = None
    inventory_mock_0.__contains__.return_value = None
    inventory_module_0.parse(inventory_mock_0, inventory_loader_mock_0, '/dev/null/hosts')



# Generated at 2022-06-25 10:00:35.349962
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    print("\n===TESTING add_parents===\n")
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_extra_path("/fake/path")
    inventory_module_1.patterns = [
        "/fake/path/inventory.config",
    ]

# Generated at 2022-06-25 10:00:42.525918
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # GIVEN
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    host_list = [
        'host1',
        'host2',
        'host3'
    ]

    inventory = InventoryManager(loader=loader, sources=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    test_obj = InventoryModule()
    test_dict = dict()
    test_dict['plugin'] = 'generator'
    test_dict['hosts'] = dict()
    test_dict['hosts']['name'] = "{{ operation }}_{{ application }}_{{ environment }}_runner"

# Generated at 2022-06-25 10:00:52.506224
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config = {
        'hosts': {
            'name': '{{ operation }}_{{ application }}_{{ environment }}_runner'
        },
        'hosts.parents': [
            {
                'name': '{{ operation }}_{{ application }}_{{ environment }}'
            },
            {
                'name': 'runner'
            }
        ],
        'layers': {
            'operation': [
                'build',
                'launch'
            ],
            'environment': [
                'dev',
                'test',
                'prod'
            ],
            'application': [
                'web',
                'api'
            ]
        }
    }
        
    inventory_module_0 = InventoryModule()
    inventory_module_0._read_config_data = lambda x: config