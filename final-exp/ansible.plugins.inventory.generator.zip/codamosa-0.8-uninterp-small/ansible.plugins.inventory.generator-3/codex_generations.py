

# Generated at 2022-06-25 09:51:03.685087
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Set up a Inventory instance with a single host
    inventory_module = InventoryModule()
    inventory = Inventory(loader=None, variable_manager=None, host_list=None)

    input_data = {
        'plugin': 'generator',
        'hosts': {
            'name': "{{ operation }}_{{ application }}_{{ environment }}_runner",
            'parents': [
                {'name': "{{ operation }}_{{ application }}_{{ environment }}"},
                {'name': "runner"}
            ]
        },
        'layers': {
            'operation': ['build', 'launch'],
            'environment': ['dev', 'test', 'prod'],
            'application': ['web', 'api']
        }
    }

    # Change working directory so that the inventory config file is found

# Generated at 2022-06-25 09:51:10.003248
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # create InventoryModule() instance
    inventory_module_1 = InventoryModule()

    # create Inventory() instance
    inventory_2 = Inventory()

    # create TemplateFile() instance
    loader_3 = TemplateFile()

    # create str instance
    path_4 = str()

    # Invoke method
    InventoryModule.parse(inventory_module_1, inventory_2, loader_3, path_4)


# Generated at 2022-06-25 09:51:12.154347
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    plugin = InventoryModule()
    assert plugin.template('{{ item1 }}{{ item2 }}', {'item2': 2, 'item1': 1}) == '12'


# Generated at 2022-06-25 09:51:13.245219
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()



# Generated at 2022-06-25 09:51:17.829244
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Create the inventory object
    inventory_obj = InventoryModule()

    # Create the file path
    file_path = "./file_path"

    # Load the contents of the inventory file
    loader_obj = loader.DataLoader()

    # Test the parser
    inventory_obj.parse(loader_obj, file_path, cache=False)


# Generated at 2022-06-25 09:51:19.041126
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 09:51:29.736022
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
  inventory_module_0 = InventoryModule()
  inventory1 = InventoryModule()
  inventory_module_0.add_parents(inventory1, "web_dev_runner", "[{u'name':  u'{{ operation }}_{{ application }}_{{ environment }}'}, {u'name': u'{{ operation }}_{{ application }}'}, {u'name': u'{{ operation }}'}, {u'name': u'{{ application }}'}, {u'name': u'{{ application }}_{{ environment }}'}, {u'name': u'{{ application }}'}, {u'name': u'{{ environment }}'}, {u'name':  u'runner'}]", 
  "{u'environment': u'dev', u'application': u'web', u'operation': u'build'}")


# Generated at 2022-06-25 09:51:35.319171
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_0 = InventoryModule()
    path = 'temp.config'

    assert inventory_module_0.verify_file(path) == True


# Generated at 2022-06-25 09:51:43.551947
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = inventory_module_0.parse(None, None, '/etc/ansible/hosts')
    assert inventory is not None
    assert inventory is None
    assert inventory is not None
    assert inventory is None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None
    assert inventory is not None

# Generated at 2022-06-25 09:51:51.565154
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_1 ='/home/arvind/proj/ansible-generator/inventory/inventory.config'
    path_2 ='/home/arvind/proj/ansible-generator/inventory/inventory'
    path_3 ='/home/arvind/proj/ansible-generator/inventory/inventory.yml'
    path_4 ='/home/arvind/proj/ansible-generator/inventory/inventory.yaml'
    path_5 ='/home/arvind/proj/ansible-generator/inventory/inventory.foo'
    path_6 ='/home/arvind/proj/ansible-generator/inventory/inventory.YAML'

# Generated at 2022-06-25 09:51:58.833966
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Initialize the object
    inventory_module_1 = InventoryModule()

    # Create the inventory object
    inventory_2 = inventory_module_1.inventory
    # Create the loader object
    loader_3 = inventory_module_1.loader
    # Create the path object
    path_4 = inventory_module_1.path

    # Run the parse method of the object for valid input
    inventory_module_1.parse(inventory_2, loader_3, path_4)

# Generated at 2022-06-25 09:52:04.115907
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = {}
    loader_0 = {}
    path_0 = 'inventory.config'
    inventory_module_0.parse(inventory_0, loader_0, path_0)

if __name__ == "__main__":
    import sys
    import doctest

    count, _ = doctest.testmod()

    if count == 0:
        print("OK")

    sys.exit(count)

# Generated at 2022-06-25 09:52:06.517107
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path = '../plugins/generator/inventory.config'
    inventory_module_0 = InventoryModule()
    result = inventory_module_0.verify_file(path)
    assert result == True


# Generated at 2022-06-25 09:52:11.750409
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule().parse
    input_0 = [
        {
            'path': 'inventory.config',
            'cache': False
        },
        'loader',
        'path',
    ]
    inventory_module_parse(*input_0)


# Generated at 2022-06-25 09:52:13.946945
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    print("Unit test for method verify_file of class InventoryModule")
    print("Input: inventory.config")
    print("Expected output: 1")
    assert(inventory_module_0.verify_file("inventory.config"))


# Generated at 2022-06-25 09:52:22.299218
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:52:24.003739
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("inventory.config") == True


# Generated at 2022-06-25 09:52:27.577107
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    loader_0 = object
    path_0 = './inventory.config'
    inventory_module_0.parse(foo, loader_0, path_0)



# Generated at 2022-06-25 09:52:37.226327
# Unit test for method add_parents of class InventoryModule

# Generated at 2022-06-25 09:52:42.880774
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()

    try:
        inventory_module_1.add_parents(None, None, None, None)
    except TypeError:
        pass



# Generated at 2022-06-25 09:52:50.270676
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()

    # test with invalid variables
    # jinja templating will fail
    with pytest.raises(AnsibleParserError) as excinfo:
        inventory_module_0.template("{{ foo }}", {'bar': 'baz'})
    assert "invalid key 'foo'" in str(excinfo.value)


# Generated at 2022-06-25 09:52:57.422572
# Unit test for method add_parents of class InventoryModule

# Generated at 2022-06-25 09:53:06.356987
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()

    # case 1:
    test_inventory = FakeInventory()
    parent = {'name': 'parent_name'}
    inventory_module.add_parents(test_inventory, 'child', [parent], {'test_key': 'test_value'})

    assert 'parent_name' in test_inventory.groups
    assert 'child' in test_inventory.groups['parent_name'].get_hosts()


# Generated at 2022-06-25 09:53:09.579539
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = dict()
    pattern = dict()
    variables = dict()
    assert inventory_module_0.template(pattern, variables) is None


# Generated at 2022-06-25 09:53:10.889145
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse()


# Generated at 2022-06-25 09:53:15.034171
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_obj = InventoryModule()
    filelist = ['./test', './inventory_generator/test_case_0.config']
    for x in filelist:
        assert inventory_module_obj.verify_file(x) == True


# Generated at 2022-06-25 09:53:17.852732
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern = "host"
    variables = {}
    assert inventory_module_0.template(pattern, variables) == "host"


# Generated at 2022-06-25 09:53:25.278615
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Initial setup from constructor
    inventory_module = InventoryModule()

    # This is an empty inventory.
    inventory = BaseInventoryPlugin.parse_inventory_memory(
        inventory_config='',
        inventory_loader=None
    )

    # This is the setup given in the example of the documentation.

# Generated at 2022-06-25 09:53:32.956649
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse_0 = InventoryModule()
    def mockreturn_read_config_data(config_file):
        return config_file
    inventory_module_parse_0._read_config_data = mockreturn_read_config_data
    inventory_module_parse_0.parse = MagicMock()
    inventory = object()
    loader = object()
    path = object()
    inventory_module_parse_0.parse(inventory, loader, path)
    inventory_module_parse_0.parse.assert_called_once_with(inventory, loader, path)


# Generated at 2022-06-25 09:53:35.656798
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.verify_file = lambda x: True
    inventory_module.parse = lambda inventory, loader, path, cache: [host, group, child]
    assert inventory_module.parse() == []

# Generated at 2022-06-25 09:53:53.845907
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory = "inventory"
    child = "child"
    parents = [dict(name='build_{{ application }}')]
    template_vars = {"application" : "application"}
    inventory_module.add_parents(inventory, child, parents, template_vars)

if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_add_parents()

# Generated at 2022-06-25 09:54:01.924790
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert (inventory_module_1.verify_file('/path/to/inventory/file/inventory.config') == False)
    assert (inventory_module_1.verify_file('/path/to/inventory/file/inventory.yaml') == True)
    assert (inventory_module_1.verify_file('/path/to/inventory/file/inventory.yml') == True)


# Generated at 2022-06-25 09:54:06.689841
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path_list = ["/home/user/inventory.config",
                "/home/user/inventory.yaml",
                "/home/user/inventory.yml",
                "/home/user/inventory.json",
                "/home/user/inventory.txt",
                "/home/user/requirements.yml"]
    expected_output = [True, True, True, True, False, False]
    output = []
    inventory_module = InventoryModule()
    for path in path_list:
        output.append(inventory_module.verify_file(path))
    assert output == expected_output

# Generated at 2022-06-25 09:54:14.756945
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory = { }
    child = { }
    parents = [ { 'name': '{{ operation }}_{{ application }}_{{ environment }}', 'parents': [ { 'name': '{{ operation }}_{{ application }}', 'parents': [ { 'name': '{{ operation }}' }, { 'name': '{{ application }}' } ] }, { 'name': '{{ application }}_{{ environment }}', 'parents': [ { 'vars': { 'application': '{{ application }}' }, 'name': '{{ application }}' }, { 'vars': { 'environment': '{{ environment }}' }, 'name': '{{ environment }}' } ] } ] }, { 'name': 'runner' } ]
    template_vars = { }
    inventory_module_0.add_parents(inventory, child, parents, template_vars)



# Generated at 2022-06-25 09:54:20.352565
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory = object()
    child = object()
    parents = object()
    template_vars = object()
    inventory_module_1.add_parents(inventory, child, parents, template_vars)

    assert True


# Generated at 2022-06-25 09:54:23.141900
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:54:27.234620
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = inventory_module.parse(inventory, loader, path, cache=False)
    assert inventory is not None

# Generated at 2022-06-25 09:54:30.311865
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_1 = InventoryModule()
    path = 'test_case_0'
    result = inventory_module_1.verify_file(path)
    assert result == True


# Generated at 2022-06-25 09:54:37.183831
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    test_inventory = InventoryModule()

    host = 'test_host_1'
    groups_list = [{'name': 'test_parent_1'}, {'name': 'test_parent_2'}]
    list_of_parents = ['test_parent_1', 'test_parent_2']
    vars_list_0 = {'name': 'test_parent_0'}
    vars_list_1 = {'name': 'test_parent_1'}

    test_inventory.add_host(host)
    inventory_module.add_parents(test_inventory, host, groups_list, vars_list_0)
    inventory_module.add_parents(test_inventory, host, groups_list, vars_list_1)


# Generated at 2022-06-25 09:54:39.627379
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents('inventory_module_0.inventory', 'child', [{'name': 'parent'}], {})



# Generated at 2022-06-25 09:54:48.133825
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('inventory.config') == True


# Generated at 2022-06-25 09:54:51.558400
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory = ""
    child = ""
    parents = ""
    template_vars = ""
    inventory_module_0.add_parents(inventory, child, parents, template_vars)

# Generated at 2022-06-25 09:54:59.389488
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents("build_web_dev_runner", [{"name": "{{operation}}_{{application}}_{{environment}}"}], [{"name": "{{operation}}_{{application}}_{{environment}}"}, {"name": "{{operation}}_{{application}}"}, {"name": "{{operation}}"}, {"name": "{{application}}"}, {"name": "{{application}}_{{environment}}"}, {"name": "{{application}}", "vars": {"application": "{{application}}"}}, {"name": "{{environment}}", "vars": {"environment": "{{environment}}"}}], {"environment": "dev", "application": "web", "operation": "build"})


# Generated at 2022-06-25 09:55:09.222789
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    ansible_loader_0 = DataLoader()
    ansible_loader_1 = DataLoader()
    ansible_inventory_manager_0 = InventoryManager(loader=ansible_loader_0, sources='/opt/stackstorm/ansible/inventory')
    ansible_playbook_path_0 = ''
    inventory_module_0.parse(ansible_inventory_manager_0, loader=ansible_loader_1, path=ansible_playbook_path_0, cache=False)

# Generated at 2022-06-25 09:55:20.977632
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Initialize inventory with class Inventory, argv, and print
    inventory = DummyInventory()
    argv = ['ansible-inventory', '-i', 'inventory.config', '--list']
    print()

    # Initialize inventory_module with class InventoryModule and run parse
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, 'loader', argv[2])

    # Assert that the "hosts" key in inventory.hosts with inventory.host and inventory.group
    # match expected dictionary

# Generated at 2022-06-25 09:55:30.784564
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Load sample config
    import os
    path = os.path.dirname(__file__) + '/tests/inventory.config'
    inventory_module_1 = InventoryModule()
    inventory_1 = inventory_1=inventory_module_1.inventory

    # Get the inventory
    inventory_module_1.parse(inventory_1, None, path)

    # Verify that host is added
    assert "build_web_test_runner" in inventory_1.hosts

    # Verify that child is added
    assert "build_web_test_runner" in inventory_1.groups["test_runner"].get_hosts()

    # Verify that host is added
    assert "build_web_test_runner" in inventory_1.groups["build_web_test"].get_hosts()

    # Verify that host is added

# Generated at 2022-06-25 09:55:39.159850
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    # Test file with .config extension
    path='test_config'
    assert inventory_module_0.verify_file(path) == True
    # Test file with .yaml extension
    path='test_yaml'
    assert inventory_module_0.verify_file(path) == True
    # Test file with no extension
    path='test'
    assert inventory_module_0.verify_file(path) == True
    # Test file with .foo extension
    path='test_foo'
    assert inventory_module_0.verify_file(path) == False


# Generated at 2022-06-25 09:55:43.121709
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.read_config_data("./inventory.config")
    inventory_module_1.parse("./inventory.config")
    inventory_module_1.print_groups()
    inventory_module_1.print_hosts()
#    inventory_module_1.print_tree()


# Generated at 2022-06-25 09:55:52.472762
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_1 = inventory_module_1.inventory
    child_1 = 'c'
    parents_1 = [{'name': 'p1'},
                 {'name': 'p2'},
                 {'name': 'p2',
                  'parents': [{'name': 'p3',
                               'vars': {'p3': 'p3'}}]},
                 {'name': 'p2',
                  'parents': [{'name': 'p4'},
                              {'name': 'p4',
                               'parents': [{'name': 'p5',
                                            'vars': {'p5': 'p5'}}]}],
                  'vars': {'p2': 'p2'}}]

# Generated at 2022-06-25 09:55:55.979564
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    print("**** TEST: test_InventoryModule_template ****")
    inventory_module_1 = InventoryModule()
    print("**** End of test_InventoryModule_template ****")


# Generated at 2022-06-25 09:56:09.681074
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
# Test cases for arguments list of method add_parents of class InventoryModule
    print (inventory_module_0)

# Generated at 2022-06-25 09:56:16.395541
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    plugin = InventoryModule()

    # Prepare data for test
    inventory = 'inventory'
    child =   {
            "name": "db_test_test_test",
            "variable_3": "test",
            "variable_2": "test",
            "variable_1": "test",
            "variable_0": "db"
        }

# Generated at 2022-06-25 09:56:17.874469
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    assert True == True


# Generated at 2022-06-25 09:56:19.945490
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.add_parents(inventory = None, child = None, parents = [], template_vars = {}) == None


# Generated at 2022-06-25 09:56:22.187341
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # Test of function parse of class InventoryModule;
    # test provided by Miguel Grinberg in issue #25761


if __name__ == '__main__':
    import sys
    sys.exit(0)

# Generated at 2022-06-25 09:56:31.453925
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.inventory = InventoryModule()
    inventory_module_0.inventory.groups = InventoryModule()
    inventory_module_0.inventory.groups['runner'] = InventoryModule()
    inventory_module_0.inventory.groups['runner'].set_variable = InventoryModule()
    inventory_module_0.templar = InventoryModule()
    inventory_module_0.templar.do_template = InventoryModule()
    inventory_module_0.inventory.add_child = InventoryModule()
    inventory_module_0.inventory.add_group = InventoryModule()
    inventory_module_0.inventory.add_host = InventoryModule()
    inventory_module_0._read_config_data = InventoryModule()
    inventory_module_0.verify_file = InventoryModule()
    inventory

# Generated at 2022-06-25 09:56:35.200224
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = { }
    inventory_module_0.templar = None
    loader_0 = { }
    assert inventory_module_0.parse(inventory_0, loader_0, None, False) is None


# Generated at 2022-06-25 09:56:41.301083
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module = InventoryModule()
    inventory_module.templar = MockTemplar()
    
    # Test case: when variables is empty
    assert inventory_module.template("text", {}) == "text"

    # Test case: when variables is not empty
    variables = {"env": "prod", "type": "api", "name": "web"}
    assert inventory_module.template("{{ env }}_{{ type }}_{{ name }}", variables) == "prod_api_web"



# Generated at 2022-06-25 09:56:48.246298
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    example_paths = ['inventory.config', 'something.yaml', 'something.yml']
    invalid_paths = ['something.txt', 'something.conf', 'something.py']
    inventory_module_1 = InventoryModule()

    for example_path in example_paths:
        assert inventory_module_1.verify_file(example_path) is True

    for invalid_path in invalid_paths:
        assert inventory_module_1.verify_file(invalid_path) is False



# Generated at 2022-06-25 09:56:51.225622
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    patrn = '{{ operation }}_{{ application }}_{{ environment }}'
    variables = {'environment': 'dev', 'application': 'web', 'operation': 'build'}
    inventory_module_0.template(patrn, variables)


# Generated at 2022-06-25 09:57:03.353214
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:57:11.237031
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_verify_file = InventoryModule()
    assert inventory_module_verify_file.verify_file("filepath_for_test") is False
    assert inventory_module_verify_file.verify_file("filepath_for_test.conf") is True
    assert inventory_module_verify_file.verify_file("filepath_for_test.yml") is True


# Generated at 2022-06-25 09:57:20.987917
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_host = MagicMock()
    inventory_module_0._read_config_data = MagicMock()
    inventory_module_0._read_config_data.return_value = {'hosts': {'name': "{{ operation }}_{{ application }}_{{ environment }}_runner"}, 'layers': {'environment': ['dev', 'test']}}
    inventory_module_0.add_child = MagicMock()
    inventory_module_0.set_variable = MagicMock()
    inventory_module_0.add_group = MagicMock()
    inventory_module_0.parse("inventory", "loader", "path", cache=False)
    assert inventory_module_0.add_host.call_count == 4
    assert inventory_module_0.add

# Generated at 2022-06-25 09:57:25.842227
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.templar = Templar()
    inventory_module_1.add_parents(Inventory(), 'web_dev_runner', [{'name': 'web_dev'}, {'name': 'web', 'vars': {'application': 'web'}}, {'name': 'dev', 'vars': {'environment': 'dev'}}], {})

if __name__ == "__main__":
    from ansible.template import Templar
    from ansible.inventory import Inventory
    test_case_0()
    test_InventoryModule_add_parents()

# Generated at 2022-06-25 09:57:29.322425
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_template_0 = InventoryModule()
    pattern = 'pattern'
    variables = dict()

    # call the InventoryModule method using a known set of inputs
    result = inventory_module_template_0.template(pattern, variables)


# Generated at 2022-06-25 09:57:35.956767
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    test_folder = os.path.dirname(os.path.realpath(__file__))
    test_data = os.path.join(test_folder, 'unit_test_data')
    test_file_name = 'valid_file.config'
    valid_file = os.path.join(test_data, test_file_name)

    if not inventory_module.verify_file(valid_file):
        raise AssertionError("Valid file failed verification")
    invalid_file = os.path.join(test_data, 'invalid_file.config')
    if inventory_module.verify_file(invalid_file):
        raise AssertionError("Invalid file passed verification")
    invalid_file_name = 'invalid_file_name.txt'
    invalid_file

# Generated at 2022-06-25 09:57:43.675368
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Initialization
    inventory_module_0 = InventoryModule()
    self = inventory_module_0
    
    # Initialization of variable inventory
    inventory = None
    
    # Initialization of variable child
    child = None
    
    # Initialization of variable parents
    parents = None
    
    # Initialization of variable template_vars
    template_vars = None
    
    # Call to add_parents(inventory, child, parents, template_vars)
    # No output
    try:
        inventory_module_0.add_parents(inventory, child, parents, template_vars)
    except Exception as e:
        print(e)
    

# Generated at 2022-06-25 09:57:48.106746
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  import os
  from ansible.parsing.dataloader import DataLoader
  from ansible.inventory.manager import InventoryManager
  from ansible.vars.manager import VariableManager

  loader = DataLoader()
  inventory = InventoryManager(loader=loader, sources=os.path.join(os.getcwd(), 'inventory', 'inventory.config'))
  variable_manager = VariableManager(loader=loader, inventory=inventory)

  inventory_module_0 = InventoryModule()
  inventory_module_0.parse(inventory, loader, os.path.join(os.getcwd(), 'inventory', 'inventory.config'))

  assert(len(inventory.groups) == 13)
  assert(len(inventory.hosts) == 18)

# Generated at 2022-06-25 09:57:55.088759
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory = {"_meta": {"hostvars": {}}, "all": {"children": ["ungrouped"]}, "ungrouped": {}}
    child = "runner"

# Generated at 2022-06-25 09:57:58.745519
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = object()

    assert not inventory_module_0.template(
        "{{ operation }}_{{ application }}_{{ environment }}_runner",
        "product(*config['layers'].values())",
    )


# Generated at 2022-06-25 09:58:23.606079
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse()

# Generated at 2022-06-25 09:58:35.533330
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    loader = object()
    inventory = object()
    class Inventory:
        def add_child(child, name):
            return
        def groups(self):
            return
        def add_group(name):
            return
    class Loader:
        def load_from_file(name):
            class obj:
                values = {}
                def get(key, default=None):
                    return obj.values[key]
                def __getitem__(key):
                    return obj.values[key]
                def __setitem__(key, value):
                    obj.values[key] = value
            return (obj())
    # Test Parse fails with wrong file
    try:
        module.parse(inventory, loader, './tests/inventory.yml')
    except AnsibleParserError as e:
        pass

# Generated at 2022-06-25 09:58:38.478702
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:58:42.459854
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    print("test_InventoryModule_add_parents")
    inventory = {"_meta": {"hostvars": {}}}
    inventory_module = InventoryModule()
    inventory_module.add_parents(inventory, 'child0', [{'name': 'parent0'}, {'name': 'parent1', 'vars': {'test0': 'test_val0'}}], {'test1': 'test_val1'})
    assert inventory['_meta']['hostvars']['child0']['parent0'] == 'parent0'
    assert inventory['_meta']['hostvars']['child0']['parent1'] == 'parent1'
    assert inventory['parent0'] == {'children': ['child0'], '_meta': {}}

# Generated at 2022-06-25 09:58:53.103904
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    config = {
        'hosts': {
            'name': '{{ operation }}_{{ application }}_{{ environment }}_runner'
        },
        'layers': {
            'operation': ['build', 'launch'],
            'environment': ['dev', 'test', 'prod'],
            'application': ['web', 'api']
        }
    }


# Generated at 2022-06-25 09:58:57.901954
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert not (inventory_module_1.verify_file('my_inventory.config'))
    assert inventory_module_1.verify_file('my_inventory.yml')
    assert not (inventory_module_1.verify_file('my_inventory.yaml'))
    assert inventory_module_1.verify_file('my_inventory')



# Generated at 2022-06-25 09:59:01.273240
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    try:
        inventory_module_0.parse("inventory", loader="loader", path="path", cache=False)
    except:
        pass

test_InventoryModule_parse()

# Generated at 2022-06-25 09:59:02.209720
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_add_parents = InventoryModule()


# Generated at 2022-06-25 09:59:12.672644
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    inventory = inventory_module_0.parse(inventory_module_0, loader, path, cache=False)

# Generated at 2022-06-25 09:59:22.823389
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Test Case 1
    set_inventory = InventoryModule()
    test_layers = {'key1': ['val1'], 'key2': ['val2'], 'key3': ['val3']}
    test_config = {'layers': test_layers}
    set_inventory.parse(inventory=None, loader=None, path=None, cache=False, config=test_config)
    test_child = "child"
    test_parents = [{
        'name': 'parent',
        'parents': [{
            'name': 'grandparent',
            'vars': {
                'k1': '{{ key1 }}',
            }
        }],
    }]

# Generated at 2022-06-25 10:00:15.797104
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.templar = {}
    inventory_module_1.add_parents({}, "test_host", [{"name": "test_group", "vars": {"test_var": "test_value"}, "parents": [{"name": "test_parent_group"}]}], {"test_var": "test_value"})

# Generated at 2022-06-25 10:00:24.019190
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    """ Tests that the add_parents method correctly adds the parents
        and sets the variables of the parent group properly 
    """
    inv = InventoryModule()


# Generated at 2022-06-25 10:00:33.827146
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import ansible.inventory.host as host
    import ansible.inventory.group as group
    inventory_module_1 = InventoryModule()
    inventory = ansible.inventory.Inventory()
    inventory.add_host('localhost')

    hosts = { 'name': '{{ operation }}_{{ application }}_{{ environment }}_worker' }
    hosts['parents'] = [{'name': '{{ operation }}_{{ application }}_{{ environment }}'}]
    hosts['parents'][0]['parents'] = [{'name': '{{ operation }}_{{ application }}'}, {'name': '{{ environment }}'}]
    hosts['parents'][0]['parents'][0]['parents'] = [{'name': '{{ operation }}'}, {'name': '{{ application }}'}]

# Generated at 2022-06-25 10:00:36.327062
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    assert isinstance(inventory_module_0, InventoryModule)


# Generated at 2022-06-25 10:00:38.548072
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # instantiating the class
    inventory_module = InventoryModule()

    # Verify the method is generated correctly
    generator_function = inventory_module.parse
    assert generator_function

# Generated at 2022-06-25 10:00:43.107809
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory=..., loader=..., path=..., cache=...)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-25 10:00:43.974433
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass


# Generated at 2022-06-25 10:00:54.415204
# Unit test for method parse of class InventoryModule