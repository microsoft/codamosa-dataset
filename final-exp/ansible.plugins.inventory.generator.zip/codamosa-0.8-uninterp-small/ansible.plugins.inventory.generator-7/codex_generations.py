

# Generated at 2022-06-25 09:50:54.812196
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    with pytest.raises(AnsibleParserError):
        inventory_module_0 = InventoryModule('path', 1, 'extensions')


# Generated at 2022-06-25 09:51:02.418150
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1 = InventoryModule()
    loader_0 = DataLoader()
    inventory_2 = Inventory(loader=loader_0)
    path_0 = str()
    test_case_0 = inventory_module_1.parse(inventory_2, loader_0, path_0)
    assert test_case_0 == None


# Generated at 2022-06-25 09:51:05.173837
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    hostname = ""
    data = {}
    inventory_module_0.add_parents(hostname, data)


# Generated at 2022-06-25 09:51:10.049873
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    template_0 = 'ywjw'
    variables_0 = {'os': 'k', 'platform': 'uc'}
    assert inventory_module_0.template(template_0, variables_0) == 'ywjw'


# Generated at 2022-06-25 09:51:13.680845
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = dict()
    loader_0 = dict()
    path_0 = 'inventory.config'
    cache_0 = True
    result_0 = inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)


# Generated at 2022-06-25 09:51:20.439448
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:51:25.138386
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents( inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:51:31.941792
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    print("test_InventoryModule_add_parents")
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    child_0 = object()
    parents_0 = object()
    template_vars_0 = object()
    inventory_module_0.add_parents(inventory_0, child_0, parents_0, template_vars_0)


# Generated at 2022-06-25 09:51:34.992205
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_0 = BaseInventoryPlugin()
    child = 'child'
    parents = 'parents'
    template_vars = {'key': 'value'}
    inventory_module_0.add_parents(inventory_0, child, parents, template_vars)


# Generated at 2022-06-25 09:51:35.842749
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 09:51:44.321558
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    path_0 = "./tests/inventory.config"
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)

# Generated at 2022-06-25 09:51:52.227171
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    class MockAnsibleInventory:
        pass
    class MockAnsibleInventory_add_host:
        pass
    class MockAnsibleInventory_add_group:
        pass
    class MockAnsibleInventory_add_child:
        pass
    mock_inventory = MockAnsibleInventory()
    mock_inventory.add_host = MockAnsibleInventory_add_host
    mock_inventory.add_group = MockAnsibleInventory_add_group
    mock_inventory.add_child = MockAnsibleInventory_add_child

# Generated at 2022-06-25 09:51:55.341521
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    p = InventoryModule()
    inventory = dict()
    c = 'c'
    p2 = 'p2'
    tv = dict()
    p.add_parents(inventory, c, p2, tv)

# Generated at 2022-06-25 09:52:00.705060
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config_data = {'hosts': {'name': '{{ operation }}_{{ application }}_{{ environment }}'},
                   'layers': {'operation': ['build', 'launch'], 'environment': ['prod'], 'application': ['web']}}
    inventory_0 = InventoryModule()
    inventory_module_0 = InventoryModule()
    loader_0 = loader.DataLoader()
    path_0 = '/etc/ansible/hosts'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)
    assert inventory_0.groups['prod']['application'] == 'web'

# Generated at 2022-06-25 09:52:03.456788
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.template = (lambda x, y: 'operation_application_environment_runner')
    inventory_module_0.add_parents('inventory', 'child', 'parents', 'template_vars')

# Generated at 2022-06-25 09:52:10.085237
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_object_0 = InventoryModule.Inventory(loader=None, variable_manager=None, host_list='hosts')
    assert not inventory_module_0.add_parents(inventory_object_0, 'child', [{'name': 'parent'}], {'key': 'value'})


# Generated at 2022-06-25 09:52:10.894413
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, path, cache=False)

# Generated at 2022-06-25 09:52:16.082596
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    group_2 = 0
    group_3 = 0
    group_1 = InventoryData(host_list=[])
    group_1.add_group("group_1")
    template_vars_1 = {}
    inventory_module_1.add_parents(group_1, "group_1", [], template_vars_1)
    inventory_module_1.add_parents(group_1, "group_1", [{}], template_vars_1)
    inventory_module_1.add_parents(group_1, "group_1", [{"name": "group_2", "parents": [], "vars": {"var_1": "value_1"}}], template_vars_1)

# Generated at 2022-06-25 09:52:18.584483
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = InventoryLoader()
    inventory_loader_1 = InventoryLoader(vars_plugins=('test_plugin.LookupModule',))
    test_case_0 = InventoryLoader()


# Generated at 2022-06-25 09:52:27.611141
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:52:37.134202
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    ansible_hosts = "[web]\nweb.example.com\n\n[web:children]\nbar\n\n[bar]\nfoo.example.com\n"
    loader = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.Inventory(loader, host_list=ansible_hosts)
    path = '/etc/ansible/hosts'
    cache = False
    inventory_module_0.parse(inventory, loader, path, cache)



# Generated at 2022-06-25 09:52:42.959599
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    config = {'layers': {'operation': ['build', 'launch'], 'application': ['web', 'api'], 'environment': ['dev', 'test', 'prod']}, 'hosts': {'name': '{{ operation }}_{{ application }}_{{ environment }}_runner', 'parents': [{'name': '{{ operation }}_{{ application }}_{{ environment }}'}, {'name': '{{ operation }}_{{ application }}'}, {'name': '{{ application }}_{{ environment }}'}, {'name': '{{ application }}'}, {'name': '{{ operation }}'}, {'name': '{{ environment }}'}]}}
    host = 'build_web_dev_runner'

# Generated at 2022-06-25 09:52:44.556690
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Perform unit testing for method parse of class InventoryModule
    test_case_0()


# Generated at 2022-06-25 09:52:48.465132
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.template('a', {'b': 'c'}) == "a", "If the pattern contains no jinja2 variables then template should return the pattern. Fails if the pattern is 'a' and template variables are {'b':'c'}"

# Generated at 2022-06-25 09:52:52.469852
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern_0 = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    variables_0 = {'environment': 'dev', 'operation': 'build', 'application': 'web'}
    result = inventory_module_0.template(pattern_0, variables_0)
    assert result == "build_web_dev_runner"


# Generated at 2022-06-25 09:52:56.491506
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    loader = 0
    path = 'test.yml'
    cache = False
    inventory.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:52:59.821722
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file("inventory.config") == True

# Generated at 2022-06-25 09:53:05.277553
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # testcase 1 : 
    inventory_module_1 = InventoryModule()

    # testcase 2 : 
    inventory_module_2 = InventoryModule()

    # testcase 3 : 
    inventory_module_3 = InventoryModule()



# Generated at 2022-06-25 09:53:07.240439
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, path, cache=False)


# Generated at 2022-06-25 09:53:08.782565
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents()

# Generated at 2022-06-25 09:53:17.811397
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "../ansible-2.6.2/test/integration/inventory")
    path = os.path.join(path, "static_hosts.yaml")
    myreturn = inventory_module_0.verify_file(path)
    assert myreturn == True



# Generated at 2022-06-25 09:53:24.847048
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('/tmp/inventory.config') is True
    assert inventory_module.verify_file('/tmp/inventory.yml') is True
    assert inventory_module.verify_file('/tmp/inventory.yaml') is True
    assert inventory_module.verify_file('/tmp/inventory.yaml') is True
    assert inventory_module.verify_file('/tmp/inventory.yml') is True
    assert inventory_module.verify_file('/tmp/inventory') is False
    assert inventory_module.verify_file('/tmp/inventory.cfg') is False
    assert inventory_module.verify_file('/tmp/inventory.yaml.cfg') is False

# Generated at 2022-06-25 09:53:29.563852
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = object
    loader = object
    path = object
    cache = False
    inventory_module_0.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:53:38.636855
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    template_0 = inventory_module_1.template(pattern="{{ operation }}_{{ application }}_{{ environment }}_runner", variables={"operation":"build", "application":"web", "environment":"dev" })
    assert('build_web_dev_runner' == template_0)
    template_1 = inventory_module_1.template(pattern="{{ operation }}_{{ application }}_{{ environment }}_runner", variables={"operation":"launch", "application":"web", "environment":"dev" })
    assert('launch_web_dev_runner' == template_1)
    template_2 = inventory_module_1.template(pattern="{{ operation }}_{{ application }}_{{ environment }}_runner", variables={"operation":"build", "application":"web", "environment":"test" })

# Generated at 2022-06-25 09:53:46.451220
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    test_input = {'hosts': {'name': 'host', 'parents': [{'name': 'parent1'}, {'name': 'parent2'}]}, 'layers': {'alpha': ['a', 'b'], 'beta': ['1', '2'], 'gamma': ['x', 'y']}}
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents(None, 'host', [{'name': 'parent1'}, {'name': 'parent2'}], test_input)



# Generated at 2022-06-25 09:53:49.376419
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # inventory_module_0.parse
    with pytest.raises(AnsibleParserError):
        inventory_module_0.parse(inventory, loader, path, cache=False)


# Generated at 2022-06-25 09:54:00.683701
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """ Test parse of class InventoryModule """

    inventory_module_1 = InventoryModule()

    config = {
        'hosts': {
            'name': 'server_{{ test_name }}',
            'parents': [
                {'name': 'test_group_{{ test_name }}'},
                {'name': 'test_group',
                 'parents': [
                     {'name': 'other_group',
                      'vars': {'other_var': 'other_value_{{ test_name }}'}
                     },
                 ]
                },
            ]
        },
        'layers': {
            'test_name': [
                'asdf',
                'qwerty',
            ],
        }
    }

    inventory = dict()
    inventory['_meta'] = dict()

# Generated at 2022-06-25 09:54:11.144476
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    '''
    Test:
        - Inputs:
            - inventory (Inventory object)
            - child (string)
            - parents (list of objects)
            - template_vars (dictionary)
        - Expected output:
            - No return value, but inventory object is modified
    '''
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = MockTemplar()
    inventory_module_0.templar.do_template = lambda x: x

    inventory = Inventory()
    inventory.add_group = lambda x: None
    inventory.add_host = lambda x: None
    inventory.add_child = lambda x,y: None


# Generated at 2022-06-25 09:54:21.560890
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ''' inventory generator - run a simple config to generate a few hosts and groups '''
    import os
    import tempfile
    import json

    # Instantiate the plugin
    inventory_module_parse = InventoryModule()

    # Create a dummy data file to use
    fd, data_file = tempfile.mkstemp()

# Generated at 2022-06-25 09:54:29.051803
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    from ansible.plugins.loader import InventoryLoader
    loader_1 = InventoryLoader()
    inventory_1 = loader_1.load_inventory('/home/simonaoliver/forge/ansible-inventory/ansible/inventory')
    inventory_module_1.parse(inventory_1, loader_1, '/etc/ansible/hosts')


# Generated at 2022-06-25 09:54:41.971403
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    # Path is not a directory
    result = inventory_module_1.verify_file("/etc/shadow")
    assert result == False
    # Path is a directory
    result = inventory_module_1.verify_file("/dev")
    assert result == False
    # Path is a valid config file
    file_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = "inventory.config"
    result = inventory_module_1.verify_file(os.path.join(file_dir, file_path))
    assert result == True
    # Path is a valid config file
    file_dir = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-25 09:54:46.687182
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    inventory_module_0.verify_file('/tmp/test/test_case_0')


# Generated at 2022-06-25 09:54:48.877648
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents(inventory_module_1, child, parents, template_vars)

# Generated at 2022-06-25 09:54:51.246835
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert inventory_module_0.verify_file("/home/kai/workspace/ansible/inventory/inventory.config") is True


# Generated at 2022-06-25 09:54:55.737773
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert inventory_module_0 != None
    result = inventory_module_0.verify_file("/etc/ansible/hosts")
    assert result == True


# Generated at 2022-06-25 09:54:57.075470
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = 'test.config'
    assert inventory_module_0.verify_file(path_0) == True


# Generated at 2022-06-25 09:55:02.094457
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    test_inventory = {'groups': {}}
    test_child = 'test_child'
    test_parents = [{'name': 'test'}]
    test_template_vars = {'test': 'test'}
    inventory_module_1.add_parents(test_inventory, test_child, test_parents, test_template_vars)
    assert(test_inventory == {'groups': {'test': {'hosts': {'test_child'}, 'children': []}}})


# Generated at 2022-06-25 09:55:07.951397
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = "/etc/ansible/hosts"
    result_0 = inventory_module_0.verify_file(path)
    assert result_0 == True

test_case_0()
test_InventoryModule_verify_file()

# Generated at 2022-06-25 09:55:13.978224
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # create an instance of the class
    inventory_module = InventoryModule()
    # create a fake inventory class
    class Inventory:
        def __init__(self):
            self.groups = {}
            self.hosts = {}
        def add_group(self, group):
            self.groups[group] = {'children': []}
        def add_child(self, group, child):
            self.groups[group]['children'].append(child)
        def add_host(self, host):
            self.hosts[host] = {}
        def set_variable(self, host, variable, value):
            self.hosts[host][variable] = value
    # create an instance of the class
    inventory = Inventory()
    # create a fake loader class

# Generated at 2022-06-25 09:55:15.537530
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse(inventory,loader,path,cache=False)

# Generated at 2022-06-25 09:55:21.764043
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()

    assert inventory_module_0.verify_file("ansible_hosts.config")
    assert inventory_module_0.verify_file("ansible_hosts.yml")
    assert not inventory_module_0.verify_file("ansible_hosts.cfg")

# Generated at 2022-06-25 09:55:23.797901
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents(None, None, None, None)


# Generated at 2022-06-25 09:55:29.925828
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory_module.template = MagicMock(return_value='host1')

    config_0 = {'host': {'name': 'host1'}, 'layers': {'operation': ['build']}}

    inventory_0 = MagicMock()
    inventory_0.groups = {'runner': 'runner'}
    inventory_0.add_child = MagicMock()
    inventory_0.add_group = MagicMock()

    inventory_module.add_parents(inventory_0, 'host1', [{'name': '{{ operation }}'}], {'operation': 'build'})


# Generated at 2022-06-25 09:55:31.344282
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass

# Generated at 2022-06-25 09:55:34.566331
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_test_obj = InventoryModule()
    inventory_module_test_obj.parse(inventory=None, loader=None, path=None, cache=False)

# Generated at 2022-06-25 09:55:41.745608
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert inventory_module_0.verify_file(path='/tmp/inventory.config') == True
    assert inventory_module_0.verify_file(path='/tmp/inventory.not.config') == False
    assert inventory_module_0.verify_file(path='/tmp/inventory.yaml') == True
    assert inventory_module_0.verify_file(path='/tmp/inventory.yml') == True
    assert inventory_module_0.verify_file(path='/tmp/inventory.json') == True
    assert inventory_module_0.verify_file(path='/tmp/inventory') == False

# Generated at 2022-06-25 09:55:49.498261
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    data_file_path_0 = os.path.join(os.path.dirname(__file__), 'data', 'inventory.config')
    inventory_loader_0 = None
    inventory_0 = None
    assert inventory_module_0.verify_file(data_file_path_0) == True
    assert inventory_module_0.plugin in ('generator',)
    assert isinstance(type_dictionary_1, dict)
    assert inventory_module_0.parse(inventory_0, inventory_loader_0, data_file_path_0) == None

# Generated at 2022-06-25 09:55:55.356896
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory_module_0,loader,path,cache=False)


# Generated at 2022-06-25 09:56:06.185642
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = os.getcwd() + "/tools/inventory_plugins/ansible/plugins/inventory/generator.py"
    config = {'layers': {'environment': ['dev', 'test', 'prod'], 'application': ['web', 'api'], 'operation': ['build', 'launch']},
          'hosts': {'name': '{{operation}}_{{application}}_{{environment}}'}}
    inventory = InventoryModule()
    loader = None
    cache = False
    inventory.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:56:11.700996
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()

    inventory = object()
    loader = object()
    path = object()
    inventory_module_parse.parse(inventory, loader, path)


# Generated at 2022-06-25 09:56:19.686836
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    inventory_module = InventoryModule()

    # Test if ExpanderException is raised when macro expansion fails
    template_vars = {}
    try:
        inventory_module.template("{{ var }}", template_vars)
        assert False
    except AnsibleParserError:
        assert True

    # Test if the code passes when a macro expansion is successful
    inventory_module.template("{{ var }}", {"var":"val"})
    assert True


# Generated at 2022-06-25 09:56:23.585594
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('/home/ansible/test.config') is True
    assert inventory_module.verify_file('/home/ansible/test.yaml') is True
    assert inventory_module.verify_file('/home/ansible/test.yml') is True
    assert inventory_module.verify_file('/home/ansible/test') is False


# Generated at 2022-06-25 09:56:25.538226
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()

# Generated at 2022-06-25 09:56:29.780101
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    pass
    #inventory_module_0 = InventoryModule()
    #inventory_0 = Inventory()


# Generated at 2022-06-25 09:56:39.205807
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.verify_file = MagicMock()
    inventory_module_1.verify_file.return_value = True
    inventory_module_1.add_host = MagicMock()
    inventory_module_1.add_group = MagicMock()
    inventory_module_1.add_child = MagicMock()
    inventory_module_1.template = MagicMock()
    inventory_module_1.template.return_value = "operation_application_environment_runner"
    inventory_1 = MagicMock()
    loader_1 = MagicMock()
    path_1 = "inventory"
    cache_1 = False
    inventory_module_1.parse(inventory_1, loader_1, path_1, cache_1)
    inventory_1.add

# Generated at 2022-06-25 09:56:42.477380
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = []
    loader = []
    path = "test"
    cache = False

    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:56:48.618774
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['inventory.config'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, path='inventory.config', cache=False)

# Generated at 2022-06-25 09:56:50.737476
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents(inventory_module_1, 'build_web_runner', inventory_module_1, inventory_module_1)


# Generated at 2022-06-25 09:56:52.308153
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents('inventory', 'child', 'parents', 'template_vars')

# Generated at 2022-06-25 09:56:52.963309
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    pass



# Generated at 2022-06-25 09:56:59.703792
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader =  {}
    path =  'inventory.config'
    cache = False
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:57:04.272344
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory = dict()
    inventory['_hosts'] = dict()
    inventory['_hosts']['host1'] = dict()
    inventory['_hosts']['host1']['parents'] = list()
    inventory['_groups'] = dict()
    inventory['_groups']['group1'] = dict()
    inventory['_groups']['group1']['vars'] = dict()
    inventory['_groups']['group1']['parents'] = list()
    child = inventory['_hosts']['host1']
    parents = [{'name':'{{ application }}_{{ environment }}'}, {'name':'{{ operation }}'}]

# Generated at 2022-06-25 09:57:14.026598
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    loader_0 = object()
    path_0 = object()
    cache_0 = object()

    inventory_0 = object()
    loader_1 = object()
    path_1 = object()
    cache_1 = object()
    setattr(inventory_module_0, 'inventory', inventory_0)
    setattr(inventory_module_0, 'loader', loader_1)
    setattr(inventory_module_0, 'path', path_1)
    setattr(inventory_module_0, 'cache', cache_1)

    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)



# Generated at 2022-06-25 09:57:16.952109
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass
#    inventory_module_0 = InventoryModule()
#    inventory_module_0.parse()

# Generated at 2022-06-25 09:57:18.858396
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = dict()
    loader = dict()
    path = "/path/to/wanted/file"
    inventory_module.parse(inventory, loader, path)

# Generated at 2022-06-25 09:57:23.246883
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Instantiates a InventoryModule object
    inventory_module_parse = InventoryModule()

    # Creates a inventory to be passed to parse method
    inventory_module_parse_inventory = dict()

    # Creates a loader to be passed to parse method
    inventory_module_parse_loader = dict()

    # Creates a path to be passed to parse method
    inventory_module_parse_path = dict()

    # Executes parse method passing inventory, loader and path as arguments
    inventory_module_parse.parse(inventory_module_parse_inventory, inventory_module_parse_loader, inventory_module_parse_path)

# Generated at 2022-06-25 09:57:26.047762
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    generator = InventoryModule()


# Generated at 2022-06-25 09:57:33.180941
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory = None
    child = "vTzWG"
    parents = [{"name": "yUYXP"}, {"name": "WCnd_"}, {"name": "JSWbW"}, {"name": "Fq5g5"}]
    template_vars = {'TxJxD': 'Pz5eH', 'Q9V9O': '2UKC_', '4t4G7': 'c1JwS', 'ZFzSb': '9FhEa'}
    inventory_module_0.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:57:44.407500
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory_module.templar = MockTemplar()
    inventory = MockInventoryV2()

# Generated at 2022-06-25 09:57:50.000012
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory_module.add_parents(0)
    inventory_module.add_parents(0)
    inventory_module.add_parents(0)
    inventory_module.add_parents(0)


# Generated at 2022-06-25 09:58:07.791172
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:58:17.462653
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['/home/dmayday/dev-ansible/code/ansible/test/test_data/test_inventory_generator.config'])

    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info=C.version_info)

    inventory_module_0 = InventoryModule()

    inventory_module_0.parse(inventory, loader, '/home/dmayday/dev-ansible/code/ansible/test/test_data/test_inventory_generator.config')
    group_0 = inventory.groups['build_api_dev']
    assert group

# Generated at 2022-06-25 09:58:18.049667
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert False == False

# Generated at 2022-06-25 09:58:20.270409
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()

    # Test 1
    path_0 = '/etc/ansible/hosts'
    assert inventory_module_0.verify_file(path_0)

# Generated at 2022-06-25 09:58:25.206962
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = 'inventory.yml'
    result = inventory_module_0.verify_file(path)
    assert result is True, "test_InventoryModule_verify_file: expected: True, actual: %s" % result


# Generated at 2022-06-25 09:58:30.955410
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = []
    loader_1 = []
    path_1 = "path"
    cache_1 = False
    inventory_module_1.parse(inventory_1, loader_1, path_1, cache_1)


# Generated at 2022-06-25 09:58:33.496019
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = InventoryModule()
    loader = InventoryModule()
    path = "."
    cache = False
    inventory_module.parse(inventory, loader, path, cache=cache)


# Generated at 2022-06-25 09:58:39.610843
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # First test whether the constructor works
    inventory_module_0 = InventoryModule()

    # Test InventoryModule.parse with a valid host
    inventory_0 = {}
    loader_0 = {}
    path_0 = '/etc/ansible/hosts'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:58:47.273765
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = "Inventory"
    loader_1 = "Loader"
    path_1 = "Path"
    cache_1 = False
    result_call = inventory_module_1.parse(inventory_1, loader_1, path_1, cache_1)
    assert result_call == None


# Generated at 2022-06-25 09:58:57.901195
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("\nCalled method test_InventoryModule_parse")
    inventory_module_0 = InventoryModule()
    config = {
        'layers': {
            'layer1': [
                'value1',
                'value2',
                'value3'
            ],
            'layer2': [
                'valuea',
                'valueb',
                'valuec'
            ]
        },
        'hosts': {
            'name': '{{ layer1 }}_{{ layer2 }}_runner'
        }
    }
    inventory_module_0._read_config_data = lambda filename: config
    inventory_module_0.template = lambda pattern, variables: pattern.replace('{{ layer1 }}', variables['layer1']).replace('{{ layer2 }}', variables['layer2'])
    inventory_0 = BaseInventory

# Generated at 2022-06-25 09:59:23.067247
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = inventory_module_1.parse(inventory_module_1.inventory, 
                                           inventory_module_1.loader,
                                           inventory_module_1.path,
                                           inventory_module_1.cache)

test_case_0()
test_InventoryModule_parse()

# Generated at 2022-06-25 09:59:29.361864
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    # Instantiate object
    inventory = AnsibleInventory('/tmp/inventory')

    # Instantiate object
    loader = DataLoader()

    # Declare path
    path = "/tmp/inventory"

    # Declare cache
    cache = False

    inventory_module.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:59:31.755897
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()

# Generated at 2022-06-25 09:59:39.880787
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Creating InventoryModule object
    inventory_module_1 = InventoryModule()
    # Variable to store inventory
    inventory = list()
    # Variable to store child
    child = 'test_child'
    # Variable to store parents
    parents_list = ['test_parent']
    # Variable to store template_vars
    template_vars = {"test":0}
    # Calling add_parents method of InventoryModule class
    inventory_module_1.add_parents(inventory,child,parents_list,template_vars)


# Generated at 2022-06-25 09:59:45.577408
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()

# Generated at 2022-06-25 09:59:49.018844
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    
    inventory_module_1.parse()

    inventory_module_2 = InventoryModule()
    inventory_1 = inventory_module_2.inventory
    loader_1 = inventory_module_2.loader
    path_1 = inventory_module_2.path
    cache_1 = inventory_module_2.cache
    
    inventory_module_2.parse(inventory_1, loader_1, path_1, cache_1)

    assert True

# Generated at 2022-06-25 09:59:54.814823
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("Testing function InventoryModule.parse")

    # Testing class InventoryModule.parse on valid case 0 with 'plugin: generator' config file.
    test_case_0_config_file = os.path.dirname(os.path.realpath(__file__)) + '/test_files/test_case_0.config'
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(None, None, test_case_0_config_file, False)

    # Testing class InventoryModule.parse on valid case 1 with 'plugin: generator' yaml file.
    test_case_1_config_file = os.path.dirname(os.path.realpath(__file__)) + '/test_files/test_case_1.yml'
    inventory_module_1 = InventoryModule()
    assert inventory_module

# Generated at 2022-06-25 09:59:59.417624
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.template = lambda x,y: x
    inventory_module_1.add_parents(1,2,3)


# Generated at 2022-06-25 10:00:02.952610
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Initialize InventoryModule object
    inventory_module = InventoryModule()
    # Initialize Inventory object
    inventory = 'Inventory'
    # Initialize child
    child = 'child'
    # Initialize parents
    parents = ['parent1', 'parent2']
    assert inventory_module.add_parents(inventory, child, parents)


# Generated at 2022-06-25 10:00:05.085834
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory_module_1, 'loader', 'path', cache=False)
