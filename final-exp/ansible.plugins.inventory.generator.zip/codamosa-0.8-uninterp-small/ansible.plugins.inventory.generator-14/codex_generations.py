

# Generated at 2022-06-25 09:50:55.904275
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.verify_file("inventory/inventory.config")

# Generated at 2022-06-25 09:51:00.217304
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_obj = InventoryModule()
    file_name_0 = "test_file.yml"
    result_0 = test_obj.verify_file(file_name_0)
    assert result_0 == True


# Generated at 2022-06-25 09:51:05.852217
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    # Initialize objects for testing
    inventory_module = InventoryModule()
    inventory_module.template = lambda s, v: s.format(**v)
    inventory_module.add_parents(None, 'child', [{'name': 'parent[{key}]', 'vars': {'name': 'parent[{key}]'}}], {'key': 0})


# Generated at 2022-06-25 09:51:08.965945
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    file_path = "test_file_name.yaml"
    result = inventory_module.verify_file(file_path)
    assert result == True


# Generated at 2022-06-25 09:51:11.443562
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    InventoryModule_parse_0 = InventoryModule()
    inventory_0 = InventoryModule_parse_0.parse()

    assert True


# Generated at 2022-06-25 09:51:14.858343
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # Test 1
    inventory_module_0 = InventoryModule()
    path = "test_0.config"

    # Test 1.1 Verify method return value
    assert inventory_module_0.verify_file(path)

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_verify_file()

# Generated at 2022-06-25 09:51:17.109243
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern = 'string test'
    variables = dict()
    assert(inventory_module_0.template(pattern, variables)=='string test')


# Generated at 2022-06-25 09:51:18.964790
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory_module.add_parents("inventory","child","parents","vars")


# Generated at 2022-06-25 09:51:19.637233
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 09:51:30.490937
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Load files and verify
    sample_file_name_1 = os.path.join("sam_inventory", "test_inventory.config")
    expected_result_1 = {
        "test_host": {
            "hosts": [
                "test_host"
            ]
        },
        "test_group": {
            "hosts": [
                "test_host"
            ],
            "vars": {
                "test_key": "test_value"
            }
        }
    }

    # Read file
    inventory_module_1 = InventoryModule()
    parsed_inventory_1 = inventory_module_1.parse({}, {}, sample_file_name_1)

    # Assert
    assert parsed_inventory_1 == expected_result_1

# Generated at 2022-06-25 09:51:36.117693
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = object()
    loader = object()
    path = object()
    cache = object()
    inventory_module.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:51:41.242252
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = '' #TODO: define
    loader = '' #TODO: define
    path = '' #TODO: define
    result = inventory_module.parse(inventory, loader, path)
    assert isinstance(result, None)


# Generated at 2022-06-25 09:51:44.020140
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module = InventoryModule()
    inventory_module.templar.available_variables = {'var1': 'value1'}
    expected = 'value1_value2'
    actual = inventory_module.template('{{ var1 }}_{{ var2 }}', {'var1': 'value1', 'var2': 'value2'})
    assert expected == actual


# Generated at 2022-06-25 09:51:48.349927
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = 'inventory.config'
    value = inventory_module_0.verify_file(path)
    assert value == True

# Generated at 2022-06-25 09:51:54.963486
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module = InventoryModule()

    inventory = None
    loader = None
    path = None
    cache = False

    # Call method
    inventory_module.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:52:00.780017
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern = u''
    variables = dict()
    result = inventory_module_0.template(pattern, variables)
    assert result == None


# Generated at 2022-06-25 09:52:08.426732
# Unit test for method verify_file of class InventoryModule

# Generated at 2022-06-25 09:52:12.141421
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    inventory_module_1.template(None, None)


# Generated at 2022-06-25 09:52:18.104738
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_p = InventoryModule()
    try:
        inventory_module_p.parse(None)
    except NotImplementedError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-25 09:52:23.033348
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:52:29.547794
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    assert inventory.verify_file('inventory.config') == True


# Generated at 2022-06-25 09:52:38.516621
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = 'inventory.config'
    res = inventory_module_0.verify_file(path)
    assert(res)
    path = 'inventory.yaml'
    res = inventory_module_0.verify_file(path)
    assert(res)
    path = 'inventory.yml'
    res = inventory_module_0.verify_file(path)
    assert(res)
    path = 'inventory'
    res = inventory_module_0.verify_file(path)
    assert(res == False)
    path = 'inventory.cfg'
    res = inventory_module_0.verify_file(path)
    assert(res == False)
    path = 'inventory.txt'

# Generated at 2022-06-25 09:52:48.997618
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = BaseInventoryPlugin()
    loader_0 = AnsibleLoader()
    template_inputs = product(*config['layers'].values())
    for item in template_inputs:
        template_vars = dict()
        for i, key in enumerate(config['layers'].keys()):
            template_vars[key] = item[i]
        host = self.template(config['hosts']['name'], template_vars)
        inventory.add_host(host)
        self.add_parents(inventory, host, config['hosts'].get('parents', []), template_vars)
    inventory_module_0.parse(inventory_0, loader_0, 'path_0')



# Generated at 2022-06-25 09:52:56.423018
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_2 = mock.Mock()
    inventory_2.__contains__.return_value = True
    inventory_2.__getitem__.return_value = True
    loader_3 = mock.Mock()
    path_4 = mock.Mock()
    cache_5 = True
    inventory_module_1.parse(inventory_2, loader_3, path_4, cache_5)
    ansible_hostname_6 = mock.Mock(name='ansible_hostname')
    ansible_host_7 = mock.Mock(name='ansible_host')
    ansible_ssh_port_8 = mock.Mock(name='ansible_ssh_port')
    ansible_connection_9 = mock.Mock(name='ansible_connection')


# Generated at 2022-06-25 09:53:01.219044
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = AnsibleInventory()
    loader_0 = AnsibleLoader()
    path_0 = 'inventory.config'
    cache_0 = False
    inventory_module_0.parse(inventory=inventory_0, loader=loader_0, path=path_0, cache=cache_0)

# Generated at 2022-06-25 09:53:11.998396
# Unit test for method add_parents of class InventoryModule

# Generated at 2022-06-25 09:53:19.393980
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    file_list = ["./generator.py", "inventory-generator.config", "inventory-generator.ini", "inventory-generator.yaml",
                 "inventory-generator.yml", "inventory-generator.txt", "inventory-generator.json"]
    expected_result = [1, 1, 0, 1, 1, 0, 0]
    output = []

    for f in file_list:
        output.append(inventory_module.verify_file(f))

    assert output == expected_result


# Generated at 2022-06-25 09:53:22.416772
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    # Valid case
    assert inventory_module_0.verify_file("inventory.config")
    # Invalid case
    assert not inventory_module_0.verify_file("inventory.ini")


# Generated at 2022-06-25 09:53:29.020353
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = {}
    loader_0 = {}
    path_0 = 'inventory.config'
    cache_0 = False
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:53:32.355903
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern = '{{ operation }}_{{ application }}_{{ environment }}_runner'
    variables = {'application': 'web', 'environment': 'test', 'operation': 'launch'}
    assert inventory_module_0.template(pattern, variables) == 'launch_web_test_runner'

# Generated at 2022-06-25 09:53:45.603290
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents(inventory = ansible.inventory.Inventory(), child = "", parents = [], template_vars = {})


# Generated at 2022-06-25 09:53:53.575520
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = {
        '_meta': {
            'hostvars': {}
        },
        'all': {
            'hosts': {}
        }
    }
    loader = {}
    path = './inventory.config'
    cache = False
    assert inventory_module_1.parse(inventory, loader, path, cache) == None

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:54:01.395398
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # In this test case, assert that verify_file returns true for
    # a config file with '.config' extension and false for a '.yaml'
    # file extension
    inventory_module_0 = InventoryModule()
    test_case_0_0 = "C:/Users/Workstation/Ansible/InventoryPlugins/inventory.config"
    test_case_0_1 = "C:/Users/Workstation/Ansible/InventoryPlugins/inventory.yaml"
    assert inventory_module_0.verify_file(test_case_0_0) == True
    assert inventory_module_0.verify_file(test_case_0_1) == False


# Generated at 2022-06-25 09:54:06.924282
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    # Execution of add_parents() method from class InventoryModule
    test_add_parents = InventoryModule()

    # Creation of a dummy object of class Inventory for input parameter inventory
    test_inventory = "inventory"

    # Creation of a dummy object of class Inventory for input parameter child
    test_child = "child"

    # Creation of a dummy object of class Inventory for input parameter parents
    test_parents = "parents"

    # Creation of a dummy object of class Inventory for input parameter template_vars
    test_template_vars = "template_vars"

    test_add_parents.add_parents(test_inventory, test_child, test_parents, test_template_vars)

# Generated at 2022-06-25 09:54:10.767767
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    path = "test.config"
    # expected = True
    expected = False
    ver = InventoryModule().verify_file(path)

    assert ver == expected



# Generated at 2022-06-25 09:54:21.033903
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory_module._read_config_data = lambda x: {
        'hosts': {
            'name': 'test_case_0',
            'parents': [
                {'name': 'test_case_0_0'},
                {
                    'name': 'test_case_0_1',
                    'parents': [
                        {'name': 'test_case_0_1_0'},
                    ]
                },
                {
                    'name': 'test_case_0_2',
                    'parents': [
                        {'name': 'test_case_0_2_0'},
                    ]
                }
            ]
        }
    }['hosts']['parents']
    inventory_module.template = lambda x, y: x
    inventory_module.add_parents

# Generated at 2022-06-25 09:54:31.091434
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_1 = InventoryModule()
    path_tuple_1 = [".", "inventory.config"]
    path_tuple_2 = [".", "inventory.yml"]
    path_tuple_3 = [".", "inventory"]
    path_1 = os.path.join(*path_tuple_1)
    path_2 = os.path.join(*path_tuple_2)
    path_3 = os.path.join(*path_tuple_3)
    print("Checking verify_file method for valid inputs")
    assert inventory_module_1.verify_file(path_1) == True
    assert inventory_module_1.verify_file(path_2) == True
    print("Checking verify_file method for invalid inputs")

# Generated at 2022-06-25 09:54:41.755675
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

# Generated at 2022-06-25 09:54:45.066003
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = inventory_module_1.parse(inventory, loader, path)


# Generated at 2022-06-25 09:54:52.344512
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule()
    inventory_0.hosts = dict()
    inventory_0.groups = dict()
    inventory_0.pattern_cache = dict()
    inventory_0.get_host = dict()
    loader_0 = InventoryModule()
    path_0 = '/etc/ansible/hosts'
    result = inventory_module_0.parse(inventory_0, loader_0, path_0)
    assert result is None


# Generated at 2022-06-25 09:55:17.133668
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule()
    loader_0 = InventoryModule()
    path_0 = InventoryModule()
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=False)


test_case_0()
test_case_1()
test_case_2()
test_case_3()
test_case_4()

# Generated at 2022-06-25 09:55:20.180446
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    # Test case 1
    path_1 = "test/test.yml"
    assert inventory_module.verify_file(path_1) == True

#  Unit test for method template of class InventoryModule

# Generated at 2022-06-25 09:55:21.760044
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = dict()
    inventory_module.parse(inventory, "loader", "path")


# Generated at 2022-06-25 09:55:27.116652
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = None
    pattern = 'abc'
    variables = {}
    assert inventory_module_0.template(pattern, variables) is None


# Generated at 2022-06-25 09:55:29.957823
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Setup test class
    inventory_module_0 = InventoryModule()
    path_0 = unicode('/tmp/example.yml')

    # Execute test
    result_0 = inventory_module_0.verify_file(path_0)
    assert result_0 is True


# Generated at 2022-06-25 09:55:40.685253
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()


# Generated at 2022-06-25 09:55:50.164081
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    result1 = inventory_module_0.verify_file('/etc/ansible/inventory.config')
    result2 = inventory_module_0.verify_file('/etc/ansible/inventory.yaml')
    result3 = inventory_module_0.verify_file('/etc/ansible/inventory.yml')
    result4 = inventory_module_0.verify_file('/etc/ansible/inventory.json')
    result5 = inventory_module_0.verify_file('/etc/ansible/inventory.txt')
    print("verify_file result for '/etc/ansible/inventory.config' : ", result1)
    print("verify_file result for '/etc/ansible/inventory.yaml' : ", result2)

# Generated at 2022-06-25 09:55:57.970760
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Test 1
    inventory_module_1 = InventoryModule()
    inventory_module_1.verify_file('invalid_name')
    # Test 2
    inventory_module_2 = InventoryModule()
    inventory_module_2.verify_file('.config')
    inventory_module_2.verify_file('inventory.config')
    inventory_module_2.verify_file('inventory.yaml')
    inventory_module_2.verify_file('inventory.yml')


# Generated at 2022-06-25 09:56:01.280238
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file ('inventory.config')



# Generated at 2022-06-25 09:56:04.175115
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = None
    loader = None
    path = None
    cache = None
    test1 = inventory_module.parse(inventory, loader, path, cache)
    # assert
    assert not test1


# Generated at 2022-06-25 09:56:45.974615
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory_module_1.inventory, inventory_module_1.loader, 'inventory.config')

# Run all of the tests when the file is executed
if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:56:50.873449
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('test.yml') == True
    assert inventory_module.verify_file('test') == False
    assert inventory_module.verify_file('test.config') == True


# Generated at 2022-06-25 09:56:51.911548
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:56:53.070826
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory_module_parse.parse()


# Generated at 2022-06-25 09:56:58.288512
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = inventory_module.parse(inventory, loader, path, cache=False)
    assert(inventory.hosts.keys() == {'build_api_dev_runner', 'build_web_prod_runner', 'launch_api_dev_runner'})
    assert(inventory.groups['build'].hosts.keys() == {'build_api_dev_runner', 'build_web_prod_runner', 'launch_api_dev_runner'})
    assert(inventory.groups['api'].hosts.keys() == {'build_api_dev_runner'})

# Generated at 2022-06-25 09:57:00.765882
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_test = InventoryModule()
    assert inventory_module_test.template(pattern="{{ operation }}_{{ application }}_{{ environment }}_runner", variables=dict(operation="launch", application="web", environment="prod")) == "launch_web_prod_runner"


# Generated at 2022-06-25 09:57:01.377531
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    return

# Generated at 2022-06-25 09:57:03.297210
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.template = lambda pattern, variables: pattern
    inventory_module_1.add_parents(inventory_module_1.Inventory({}), 'child', [{'name': 'parent'}], {})


# Generated at 2022-06-25 09:57:14.168078
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:57:18.827985
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    input_template = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    variables = {'operation': 'build', 'application': 'web', 'environment': 'test'}
    inventory_module = InventoryModule()
    assert inventory_module.template(input_template, variables) == "build_web_test_runner"


# Generated at 2022-06-25 09:58:46.793575
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = dict()
    inventory['all'] = dict()
    inventory['_meta'] = dict()
    loader = dict()
    path = dict()
    assert inventory_module.parse(inventory, loader, path)
    inventory_module.parse(inventory, loader, path)
# Test AnsibleModule.get_bin_path
#   input: overrides
#   output: BINARY_DATA
#   Expected: BINARY_DATA

# Generated at 2022-06-25 09:58:57.856967
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:59:08.112890
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
        inventory_module_0 = InventoryModule()
        self.inventory = Mock(spec_set=Inventory)
        host = "runner2"
        parents = [{'name': '{{ operation }}_{{ application }}_{{ environment }}', 'parents': [{'name': '{{ operation }}_{{ application }}', 'parents': [{'name': '{{ operation }}', 'parents': []}, {'name': '{{ application }}', 'parents': []}]}, {'name': '{{ application }}_{{ environment }}', 'parents': [{'name': '{{ application }}', 'vars': {'application': '{{ application }}'}}, {'name': '{{ environment }}', 'vars': {'environment': '{{ environment }}'}}]}]}]
        template_vars = {"operation": "launch", "environment": "test", "application": "api"}


# Generated at 2022-06-25 09:59:10.751903
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents('inventory', 'child', 'parents', 'template_vars')


# Generated at 2022-06-25 09:59:21.035241
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

# Generated at 2022-06-25 09:59:27.417333
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    Inventory._hosts_cache = None
    Inventory._pattern_cache = None

    Options = namedtuple('Options', ['listtags', 'listtasks', 'listhosts', 'syntax', 'connection','module_path', 'forks', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check', 'diff'])


# Generated at 2022-06-25 09:59:35.383921
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    class Mock_groupnames(object):
        def __init__(self):
            self.group = "runners"
        def __getitem__(self, groupname):
            return self

    class Mock_hosts(object):
        def __init__(self):
            self.host = "runners"
        def __getitem__(self, hostname):
            return self

    class Mock_inventory_module_0(object):
        def __init__(self):
            self.hosts = Mock_hosts()
            self.groups = Mock_groupnames()

    inventory_module_0 = Mock_inventory_module_0()

# Generated at 2022-06-25 09:59:38.435109
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    class_inv_module = InventoryModule()
    inventory = {"groups": {}, "hosts": []}
    inventory_module.add_parents(inventory, "host1", "parents", "template_vars")
    assert inventory["groups"] == {}


# Generated at 2022-06-25 09:59:42.163565
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_inventory_module = InventoryModule()
    test_inventory_module.parse(
        {},
        {},
        '',
        cache=True
    )

# Generated at 2022-06-25 09:59:47.627854
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.template("http://{{ ansible_hostname }}", {"ansible_hostname": "c1host1.ansible.com"}) == "http://c1host1.ansible.com"
