

# Generated at 2022-06-25 09:51:02.643978
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    inventory_module_0 = InventoryModule()
    inventory = BaseInventoryPlugin()
    inventory_module_0.add_parents(inventory, 'build_web_prod_runner', [{'name': 'build_web_prod_runner'}], {})
    inventory_module_0.add_parents(inventory, 'build_web_prod_runner', [{'name': 'build_web_prod_runner'}],
                                   {})
    inventory_module_0.add_parents(inventory, 'b', [{'name': 'build_web_prod_runner', 'vars': {'p': 'build_web_prod'}}], {})


# Generated at 2022-06-25 09:51:07.369823
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    # Call method "parse" of class InventoryModule with parameters:
    # {"inventory": "inventory", "loader": "loader", "path": "path", "cache": "cache"}
    # inventory_module_0.parse({"inventory": "inventory", "loader": "loader", "path": "path", "cache": "cache"})

# Generated at 2022-06-25 09:51:16.267717
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory = object()
    child = object()
    template_vars = {}

    mock_self_template = mocker.patch.object(InventoryModule, 'template')
    mock_inventory_add_child = mocker.patch.object(inventory, 'add_child')
    mock_inventory_add_group = mocker.patch.object(inventory, 'add_group')
    mock_group_set_variable = mocker.patch.object(inventory.groups, 'set_variable')
    mock_self_add_parents = mocker.patch.object(InventoryModule, 'add_parents')

    # With all elements

# Generated at 2022-06-25 09:51:19.037198
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("", "", "/home/user/inventory.config")
    inventory_module_1.add_parents("", "", "", "")

test_case_0()

# Generated at 2022-06-25 09:51:24.301514
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    values_1 = []
    values_1.append({'key': 'plugin', 'required': True, 'choices': ['generator']})
    values_1.append({'parents': {'name': '{{ operation }}_{{ application }}_{{ environment }}', 'parents': [{'name': '{{ operation }}_{{ application }}'}, {'name': '{{ application }}_{{ environment }}'}]}, 'name': '{{ operation }}_{{ application }}_{{ environment }}_runner'})
    values_1.append({'application': ['web', 'api'], 'environment': ['dev', 'test', 'prod'], 'operation': ['build', 'launch']})
    assert inventory_module_1.test(values_1) == "False"


# Generated at 2022-06-25 09:51:34.032191
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file("inventory.yaml") == True
    assert inventory_module_1.verify_file("inventory.config") == True
    assert inventory_module_1.verify_file("inventory.yaml.config") == True
    assert inventory_module_1.verify_file("inventory.txt") == False
    assert inventory_module_1.verify_file("inventory.yml.config") == False
    assert inventory_module_1.verify_file("inventory.yml.txt") == False
    assert inventory_module_1.verify_file("inventory") == False



# Generated at 2022-06-25 09:51:36.503942
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents(inventory=None, child=None, parents=None, template_vars=None)

# Generated at 2022-06-25 09:51:41.831671
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config = dict()
    config['layers'] = dict()
    config['layers']['operation'] = ['build', 'launch']
    config['layers']['environment'] = ['dev', 'test', 'prod']
    config['layers']['application'] = ['web', 'api']
    config['hosts'] = dict()
    config['hosts']['name'] = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    config['hosts']['parents'] =[dict()]
    config['hosts']['parents'][0]['name'] = "{{ operation }}_{{ application }}"
    config['hosts']['parents'][0]['parents'] = [dict()]

# Generated at 2022-06-25 09:51:50.332486
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config = {
        'layers': {
            'operation': ['build', 'launch'],
            'environment': ['dev', 'test', 'prod'],
            'application': ['web', 'api']
        },
        'hosts': {
            'name': "{{ operation }}_{{ application }}_{{ environment }}_runner",
            'parents': [
                {
                    'name': "{{ operation }}_{{ application }}_{{ environment }}"
                },
                {
                    'name': "runner"
                }
            ]
        }
    }
    inventory_module_parse = InventoryModule()
    inventory_object = inventory_module_parse.parse(config, {}, {}, {}, {}, "inventory.config")
    for item in inventory_object.groups:
        print(item)

# Generated at 2022-06-25 09:51:52.721234
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = MockInventory()
    loader = MockLoader()
    path = "inventory.config"
    inventory_module_0.parse(inventory, loader, path)


# Generated at 2022-06-25 09:51:58.080974
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file("inventory.config") == True
    

if __name__ == '__main__':
    test_case_0();
    test_InventoryModule_verify_file();

# Generated at 2022-06-25 09:51:59.605885
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents()

# Generated at 2022-06-25 09:52:00.621518
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert True


# Generated at 2022-06-25 09:52:03.055373
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_1 = InventoryModule()
    test_file_1 = 'test_file_1.config'
    assert inventory_module_1.verify_file(test_file_1) is True


# Generated at 2022-06-25 09:52:08.159917
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_parse = InventoryModule()
    inventory_module_parse.parse('inventory', 'loader', 'path', 'cache')

# Generated at 2022-06-25 09:52:13.654819
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse_0 = InventoryModule()
    inventory_module_parse_0.parse('inventory_module_parse_0.inventory',
                                   'inventory_module_parse_0.loader',
                                   'inventory_module_parse_0.path',
                                   False)


# Generated at 2022-06-25 09:52:20.321953
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  inventory_module = InventoryModule()
  assert inventory_module.verify_file("inventory.yml") == True
  assert inventory_module.verify_file("inventory.config") == True
  assert inventory_module.verify_file("inventory.yaml") == True
  assert inventory_module.verify_file("inventory.json") == True
  assert inventory_module.verify_file("inventory.txt") == False

# Generated at 2022-06-25 09:52:22.563843
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    # No exception should be raised
    assert inventory_module_0.verify_file('foo') == False


# Generated at 2022-06-25 09:52:31.970941
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config = {
        "plugin": "generator",
        "hosts": {
            "name": "{{ operation }}_{{ application }}_{{ environment }}_runner"
        },
        "layers": {
            "operation": [
                "build",
                "launch"
            ],
            "environment": [
                "dev",
                "test",
                "prod"
            ],
            "application": [
                "web",
                "api"
            ]
        }
    }

    inventory_module_parse = InventoryModule()
    inventory_module_parse.parse('inventory', 'loader', 'path')
    assert config == inventory_module_parse._read_config_data('path')


# Generated at 2022-06-25 09:52:36.714165
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("inventory.yml") == True
    assert inventory_module.verify_file("inventory.config") == True
    assert inventory_module.verify_file("inventory") == False

# Generated at 2022-06-25 09:52:46.660596
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('/etc/ansible/hosts.config')
    assert inventory_module.verify_file('/etc/ansible/hosts.yaml')
    assert inventory_module.verify_file('/etc/ansible/hosts.yml')
    assert not inventory_module.verify_file('/etc/ansible/hosts.txt')
    assert not inventory_module.verify_file('/etc/ansible/hosts')


# Generated at 2022-06-25 09:52:49.757250
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents(inventory_module_1, "{{ operation }}_{{ application }}_{{ environment }}_runner", "{{ operation }}_{{ application }}_{{ environment }}", "launcher")


# Generated at 2022-06-25 09:52:54.382513
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()

    assert inventory_module_1.template('', {}) == ''
    assert inventory_module_1.template('', {'a': 'b'}) == ''
    assert inventory_module_1.template('a{{x}}b', {'x': None}) == 'ab'
    assert inventory_module_1.template('a{{x}}b', {'x': 'c'}) == 'abc'


# Generated at 2022-06-25 09:52:57.313173
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # Test for valid extention
    assert inventory_module_0.verify_file("test.config")

    # Test for valid extention
    assert inventory_module_0.verify_file("test.yml")

    # Test for invalid extention
    assert not inventory_module_0.verify_file("test.txt")

# Generated at 2022-06-25 09:53:06.995901
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    inventory_module_template = InventoryModule()
    for op in ['build', 'launch']:
        for app in ['web', 'api']:
            for env in ['dev', 'test', 'prod']:
                expected = op + '_' + app + '_' + env + '_runner'
                variables = {'operation': op, 'application': app, 'environment': env}
                actual = inventory_module_template.template('{{ operation }}_{{ application }}_{{ environment }}_runner', variables)
                assert expected == actual


# Generated at 2022-06-25 09:53:13.207389
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()

    inventory_module_1.inventory = None

    inventory_module_1.add_parents(inventory_module_1.inventory, "host", [{'name': "operation_application_environment_runner", 'vars': {}}, {'name': "runner", 'vars': {}}], {'operation': "build", 'application': "web", 'environment': "dev"})


# Generated at 2022-06-25 09:53:14.909081
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    try:
        inventory_module_0 = InventoryModule()
    except:
        assert False
    assert True

# Generated at 2022-06-25 09:53:23.640310
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()

#     Return True if the path is a valid inventory file.
#     This method basically checks the file extension to see
#     if it is anything we are considering a valid file.
#     If not, it must not be a valid inventory file.

#     :param path: The path to the inventory file
#     :type path: str

#     :return: True if it's a valid inventory file, else False.
#     :rtype: bool
#
#     Example:
#
#     >>> def verify_file(self, path):
#         valid = False
#         if super(InventoryModule, self).verify_file(path):
#             file_name, ext = os.path.splitext(path)
#
#             if not ext or ext in ['.config'] + C.YAM

# Generated at 2022-06-25 09:53:31.656868
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_1 = InventoryModule.Inventory(loader=None, variable_manager=None, host_list=None)
    loader_1 = InventoryModule.DataLoader()
    path_1 = "/etc/ansible/hosts"
    cache_1 = False
    assert inventory_module_0.parse(inventory=inventory_1, loader=loader_1, path=path_1, cache=cache_1) is None

# Generated at 2022-06-25 09:53:34.438472
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory = object()
    child = object()
    parents = object()
    template_vars = object()
    inventory_module_1.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:53:44.791141
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = '/endpoint/'
    var_return = inventory_module_0.verify_file(path)
    assert var_return == True


# Generated at 2022-06-25 09:53:47.408282
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = {}
    loader = {}
    path = "inventory.config"
    cache = False
    inventory_module.parse(inventory, loader, path, cache)
#    print(inventory)

# Generated at 2022-06-25 09:53:52.463067
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_0 = inventory_module_1.parse(path='inventory.config')
    inventory_1 = inventory_module_1.parse(inventory, loader, path, cache=False)

test_case_0()
test_InventoryModule_parse()

# Generated at 2022-06-25 09:53:59.157596
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory = {}

    config = {'layers': {'operation': ['build'], 'application': ['web'], 'environment': ['dev']}}

    child = 'build_web_dev'
    parents = [{'name': '{{ application }}_{{ environment }}'}, {'name': '{{ operation }}_{{ application }}'}]
    template_vars = {'operation': 'build', 'application': 'web', 'environment': 'dev'}

    inventory_module = InventoryModule()
    result = inventory_module.add_parents(inventory, child, parents, template_vars)
    assert result == None


# Generated at 2022-06-25 09:54:00.723241
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory_module.add_parents()

# Generated at 2022-06-25 09:54:02.545842
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_verify_file = InventoryModule()
    assert inventory_module_verify_file.verify_file(path ="inventory.config") is True


# Generated at 2022-06-25 09:54:11.365443
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # load the plugin
    inventory_module_0 = InventoryModule()

    # define ansible inventory object
    inventory_0 = InventoryModule.Inventory(loader='', host_list='')

    # define the plugin options

# Generated at 2022-06-25 09:54:14.084275
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    file_list = ["inventory.config","inventory.yml","inventory.yaml"]
    for file_name in file_list:
        result = inventory_module.verify_file(file_name)
        assert result == True


# Generated at 2022-06-25 09:54:19.181601
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = {}
    loader = {}
    path = {}
    cache = {}
    try:
        inventory_module_1.parse(inventory, loader, path, cache=cache)
    except Exception as e:
        assert False, 'Unexpected exception raised: ' + str(e)
    assert True


# Generated at 2022-06-25 09:54:21.745074
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file('inventory.config') == True


# Generated at 2022-06-25 09:54:35.307308
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()

    # Failure case
    # input: path = ""
    assert inventory_module_1.verify_file("") == False
    # input: path = "test_inv.file"
    assert inventory_module_1.verify_file("test_inv.file") == False
    # input: path = "test_inv.config"
    assert inventory_module_1.verify_file("test_inv.config") == True
    # input: path = "test_inv.yml"
    assert inventory_module_1.verify_file("test_inv.yml") == True
    # input: path = "test_inv.yaml"
    assert inventory_module_1.verify_file("test_inv.yaml") == True


# Generated at 2022-06-25 09:54:40.781373
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module = InventoryModule()

    assert inventory_module.verify_file('tests/test_inventory_generator/inventory_generator_test_case_0.config') == True

    assert inventory_module.verify_file('tests/test_inventory_generator/inventory_generator_test_case_0.ini') == False

    assert inventory_module.verify_file('tests/test_inventory_generator/inventory_generator_test_case_0.yml') == True


# Generated at 2022-06-25 09:54:47.143020
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_0 = BaseInventoryPlugin()
    child_0 = "runner"
    parents_0 = []
    template_vars_0 = {}
    inventory_module_0.add_parents(inventory_0, child_0, parents_0, template_vars_0)


# Generated at 2022-06-25 09:54:50.966225
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse("inventory_module_0", "loader", "path", True)


# Generated at 2022-06-25 09:54:56.836336
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_obj = InventoryModule()
    assert not inventory_module_obj.verify_file('/etc/hosts')
    assert not inventory_module_obj.verify_file('/etc/hosts.txt')
    assert inventory_module_obj.verify_file('/etc/hosts.yaml')


# Generated at 2022-06-25 09:54:59.170566
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    template_vars = dict()
    child = 'child'
    inventory = 'inventory'
    parents = 'parents'
    inventory_module_0.add_parents(inventory=inventory, child=child, parents=parents, template_vars=template_vars)


# Generated at 2022-06-25 09:55:05.130112
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file('./inventory/inventory.config')
    assert inventory_module_1.verify_file('inventory.yml')


# Generated at 2022-06-25 09:55:12.538437
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    import json
    import os.path
    # Load the test data
    test_input_file = os.path.join(os.path.dirname(__file__), 'ansible_test_data.json')
    test_data = json.load(open(test_input_file, 'r'))
    # Set test data as class variables
    inventory_module_1 = InventoryModule()
    inventory_module_1.templar = test_data["templar"]
    inventory_module_1.template(test_data["template_pattern"], test_data["template_variables"])


# Generated at 2022-06-25 09:55:18.867327
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    filename_1 = 'test_case_1.config'
    filename_2 = 'test_case_2.yml'
    filename_3 = 'test_case_3.txt'

    inventory_module_1 = InventoryModule()

    assert inventory_module_1.verify_file(filename_1) == True
    assert inventory_module_1.verify_file(filename_2) == True
    assert inventory_module_1.verify_file(filename_3) == False


# Generated at 2022-06-25 09:55:21.846031
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = "/usr/local/etc/ansible/hosts"
    actual_return_value = inventory_module_0.verify_file(path_0)
    assert actual_return_value == False


# Generated at 2022-06-25 09:55:36.985610
# Unit test for method add_parents of class InventoryModule

# Generated at 2022-06-25 09:55:39.148721
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = object()
    pattern = 'template_pattern'
    variables = {'variables': 'variable'}
    result = inventory_module_0.template(pattern, variables)


# Generated at 2022-06-25 09:55:42.756080
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_module = InventoryModule()
    inv_module.parse('inventory','loader','path','cache')

# Generated at 2022-06-25 09:55:45.489339
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 09:55:51.027730
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    data = dict(plugin = 'generator',
                hosts = dict(name = '{{ operation }}_{{ application }}_{{ environment }}_runner'),
                layers = dict(operation = ['build', 'launch'],
                              environment = ['dev', 'test', 'prod'],
                              application = ['web', 'api']))
    inventory_module_0 = InventoryModule()
    loader = None
    path = 'test_file'
    inventory = None
    cache = False
    inventory_module_0.parse(inventory, loader, path, cache)
    assert True

# Generated at 2022-06-25 09:55:55.184038
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('./test_hosts.config')


# Generated at 2022-06-25 09:56:00.058365
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule.parse(inventory_module_0)


# Generated at 2022-06-25 09:56:04.460625
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    path_1 = 'inventory.config'
    result_1 = True
    assert inventory_module_1.verify_file(path_1) == result_1
    path_2 = 'inventory.yml'
    result_2 = True
    assert inventory_module_1.verify_file(path_2) == result_2
    path_3 = 'inventory.txt'
    result_3 = False
    assert inventory_module_1.verify_file(path_3) == result_3
    path_4 = 'inventory.yaml'
    result_4 = True
    assert inventory_module_1.verify_file(path_4) == result_4


# Generated at 2022-06-25 09:56:05.046577
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Not used.
    pass

# Generated at 2022-06-25 09:56:06.683150
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert_that(inventory_module_0.verify_file(path)).is_true()


# Generated at 2022-06-25 09:56:24.397169
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    test_inventory_1 = InventoryModule()
    test_child_1 = 'test_child_1'
    test_parents_1 = [{'name': 'test_parent_1'}, {'name': 'test_parent_2'}]
    test_template_vars_1 = {'test_key_1': 'test_value_1', 'test_key_2': 'test_value_2'}
    inventory_module_1.add_parents(test_inventory_1, test_child_1, test_parents_1, test_template_vars_1)


# Generated at 2022-06-25 09:56:32.389262
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()

# Generated at 2022-06-25 09:56:40.479913
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = dict()
    loader = dict()
    path = dict()
    cache = dict()
    inventory_module_0 = InventoryModule()
    ansible_dict = dict()

    ansible_dict['operation'] = ['build', 'launch']
    ansible_dict['environment'] = ['dev', 'test', 'prod']
    ansible_dict['application'] = ['web', 'api']

    config = dict()
    config['hosts'] = dict()
    config['hosts']['name'] = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    config['hosts']['parents'] = list()

    config['hosts']['parents'].append(dict())
    config['hosts']['parents'][0]['name'] = "{{ operation }}_{{ application }}_{{ environment }}"

# Generated at 2022-06-25 09:56:48.764749
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    test_case_1_inventory = object()
    test_case_1_loader = object()
    test_case_1_path = 'test_case_1_path'
    test_case_1_cache = False
    inventory_module_1.parse(test_case_1_inventory, test_case_1_loader, test_case_1_path, test_case_1_cache)

# Test that the InventoryModule.parse function can be called with None as the inventory argument.
# This is a sign that it is safe to call the method with None parameters

# Generated at 2022-06-25 09:56:52.792024
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    class_0 = inventory_module_0
    pattern_0 = '{{ operation }}_{{ application }}_{{ environment }}_runner'
    variables_0 = {'environment': 'dev', 'application': 'web', 'operation': 'build'}
    return_value_0 = class_0.template(pattern_0, variables_0)
    assert return_value_0 == 'build_web_dev_runner'


# Generated at 2022-06-25 09:56:53.474207
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:56:56.059083
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory = object()
    child = object()
    parents = object()
    template_vars = object()
    inventory_module_1.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:56:59.452610
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule()
    child_0 = 'hilbert'
    parents_0 = ['debian-members']
    template_vars_0 = {}
    inventory_module_0.add_parents(inventory_0, child_0, parents_0, template_vars_0)


# Generated at 2022-06-25 09:57:08.926640
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    filename = 'inventory.config'
    template_vars = {'operation': 'build', 'environment': 'dev', 'application': 'web'}
    # Constructor
    inventory_module_1 = InventoryModule()
    inventory_module_1.verify_file(filename)

    # Read config data from file
    inventory_module_2 = InventoryModule()
    config = inventory_module_2._read_config_data(filename)

# Generated at 2022-06-25 09:57:11.008791
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents(inventory=inventory_module_0,child="test",parents="test",template_vars="test")

# Generated at 2022-06-25 09:57:42.939417
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern = 'hostname_{{ item }}'
    variables = dict()
    variables['item'] = '0'
    inventory_module_0.templar = MagicMock()
    inventory_module_0.templar.do_template = mock_do_template
    retval = inventory_module_0.template(pattern, variables)
    pprint(retval)
    assert retval == 'hostname_0'


# Generated at 2022-06-25 09:57:46.088253
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('/etc/ansible/inventory.config') == True
    assert inventory_module.verify_file('/etc/ansible/inventory.yml') == True
    assert inventory_module.verify_file('/etc/ansible/inventory.yaml') == True
    assert inventory_module.verify_file('/etc/ansible/inventory.txt') == False

# Generated at 2022-06-25 09:57:54.984422
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("-----------------")
    print("Starting unit tests for method parse of class InventoryModule")
    print("-----------------")

# Generated at 2022-06-25 09:58:04.069999
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule.parse(inventory_module_0,loader,path,cache=False)
    inventory_0.add_host("{ operation }_{ application }_{ environment }_runner")
    inventory_0.add_group("{ operation }_{ application }_{ environment }")
    inventory_0.add_group("{ operation }_{ application }")
    inventory_0.add_group("{ operation }")
    inventory_0.add_group("{ application }")
    inventory_0.add_group("{ application }_{ environment }")
    inventory_0.add_group("runner")

# Generated at 2022-06-25 09:58:07.925139
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    pattern_2 = "{{ application }}_{{ environment }}"
    variables_3 = {"application": "web", "environment": "dev"}
    inventory_module_1.template(pattern_2, variables_3)


# Generated at 2022-06-25 09:58:15.356698
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create an instance of InventoryModule
    inventory_module_0 = InventoryModule()
    # Create an instance of Inventory
    inventory_1 = Inventory()
    # Create the first template input
    template_input_0 = product()
    # Create an instance of AnsibleLoader
    ansible_loader_0 = AnsibleLoader()
    # Store path in path
    path = ''
    # Call method parse of inventory_module_0
    return_value = inventory_module_0.parse(inventory_1, ansible_loader_0, path)
    assert return_value == None

# Generated at 2022-06-25 09:58:22.577598
# Unit test for method add_parents of class InventoryModule

# Generated at 2022-06-25 09:58:24.824926
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('inventory', 'loader', 'path', cache=False)

# Generated at 2022-06-25 09:58:27.660864
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert InventoryModule().parse({}, {}, {}, {}) == None

# Generated at 2022-06-25 09:58:38.742150
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:59:47.185644
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    # Unit test for method template of class InventoryModule
    pattern = "http://private_host:private_port"
    variables = dict()
    variables['private_host'] = "myhost.mydomain.com"
    variables['private_port'] = "8080"
    result = inventory_module_0.template(pattern, variables)
    assert result == "http://myhost.mydomain.com:8080"
    # Unit test for method template of class InventoryModule
    pattern = "http://private_host:private_port"
    variables = dict()
    variables['private_port'] = "8080"
    variables['private_host'] = "myhost.mydomain.com"
    result = inventory_module_0.template(pattern, variables)

# Generated at 2022-06-25 09:59:54.330658
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = MockTemplar()
    template_0 = inventory_module_0.template("{% for foo in bar %}{{ foo }}{% endfor %}", dict(bar=[1,2,3]))
    assert template_0 == "123"


# Generated at 2022-06-25 09:59:58.506966
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_instance_0 = InventoryModule()
    inventory_module_instance_0.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 10:00:06.364388
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    INVENTORY_CONFIG_TEST = os.path.join(C.DEFAULT_LOCAL_TMP, 'inventory_generator_test')
    if os.path.exists(INVENTORY_CONFIG_TEST):
        shutil.rmtree(INVENTORY_CONFIG_TEST)
    inventory_module = InventoryModule()

    config_content = '''
    plugin: generator
    layers:
        layer0: ["option0_0", "option0_1"]
        layer1: ["option1_0", "option1_1"]
    hosts:
        name: {{ layer0 }}__{{ layer1 }}
        parents:
            - name: {{ layer0 }}
            - name: {{ layer1 }}
    '''

# Generated at 2022-06-25 10:00:11.686990
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory = None
    child = 'web_dev_runner'
    parents = [
        {'name': '{{ web }}_{{ dev }}', 'parents': [{'name': 'web', 'vars': {'application': 'web'}}, {'name': 'dev', 'vars': {'environment': 'dev'}}]},
        {'name': '{{ web }}_{{ dev }}', 'parents': [{'name': 'web'}, {'name': 'dev'}]}
    ]
    template_vars = {'web': 'web', 'dev': 'dev'}
    inventory_module.add_parents(inventory, child, parents, template_vars)

# Generated at 2022-06-25 10:00:20.258431
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 10:00:30.735876
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create object
    inventory_module_0 = InventoryModule()
    inventory_module_0.verify_file = MagicMock()
    inventory_module_0.verify_file.return_value = True
    inventory_module_0._read_config_data = MagicMock()

    inventory_module_0.parse(inventory, loader, path, cache=False)
    inventory_module_0.verify_file.assert_called_with(path)
    inventory_module_0._read_config_data.assert_called_with(path)

# Generated at 2022-06-25 10:00:36.749127
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_2 = InventoryModule()
    inventory_module_2.parse(inventory=None, loader=None, path="/usr/share/ansible/plugins/inventory/generator.yaml", cache=True)


# Generated at 2022-06-25 10:00:39.489768
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern="{{ operation }}_{{ application }}_{{ environment }}_runner"
    variables={"operation":"build", "application":"web", "environment":"dev"}
    print(inventory_module_0.template(pattern, variables))


# Generated at 2022-06-25 10:00:42.316856
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory = object()
    child = object()
    parents = []
    template_vars = {}
    result = inventory_module_0.add_parents(inventory, child, parents, template_vars)
    assert result is None
