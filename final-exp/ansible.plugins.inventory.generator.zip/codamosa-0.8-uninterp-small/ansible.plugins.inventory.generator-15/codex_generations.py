

# Generated at 2022-06-25 09:50:56.001000
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = InventoryModule()
    loader_1 = InventoryModule()
    path_1 = InventoryModule()
    result_1 = inventory_module_1.parse(inventory_1, loader_1, path_1)


# Generated at 2022-06-25 09:51:07.369338
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()
    with pytest.raises(AnsibleParserError) as excinfo:
        inventory_module_1.parse(inventory_module_0, loader, path)
    assert 'Element %s has a parent with no name element' in str(excinfo.value)
    with pytest.raises(AnsibleParserError) as excinfo:
        inventory_module_1.parse(inventory_module_0, loader, path)
    assert 'Element %s has a parent with no name element' in str(excinfo.value)
    with pytest.raises(AnsibleParserError) as excinfo:
        inventory_module_1.parse(inventory_module_0, loader, path)
    assert 'Element %s has a parent with no name element'

# Generated at 2022-06-25 09:51:10.509511
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents() # doctest: +ELLIPSIS


# Generated at 2022-06-25 09:51:17.430853
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory = {}
    inventory['_meta'] = {'hostvars': {}}
    inventory['children'] = {}
    inventory['groups'] = {}
    children = {'name': 'runner', 'parents': []}
    inventory_module.add_parents(inventory, children, [], {})
    assert inventory['groups']['runner']['hosts'] == ['runner']


# Generated at 2022-06-25 09:51:23.564480
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    print("\n\n#####  Constructs groups and vars using Jinja2 template expressions #####\n")

    inventory_module_0 = InventoryModule()

    inventory_0 = {}

    child_0 = 'launch_web_dev_runner'


# Generated at 2022-06-25 09:51:26.852204
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    host_cfg_yaml_path = './tests/host_cfg_yaml.config'

    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(path=host_cfg_yaml_path)


# Generated at 2022-06-25 09:51:33.943618
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()

    inventory = BaseInventoryPlugin()
    child = 'www1'
    parents = [
        {'name': 'webservers'},
        {'name': '{{ environment }}'},
        {'name': '{{ environment }}_{{ application }}',
         'vars': {
             'application': '{{ application }}'
            }
         }
    ]
    template_vars = {'environment': 'prod', 'application': 'web'}

    inventory_module_1.add_parents(inventory, child, parents, template_vars)
    assert len(inventory.groups) == 5
    assert inventory.hosts['www1'].get_vars() == {}



# Generated at 2022-06-25 09:51:41.133874
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory = InventoryModule()
    inventory.add_host = MagicMock(return_value=None)
    inventory.add_child = MagicMock(return_value=None)
    inventory.add_group = MagicMock(return_value=None)
    inventory.groups = dict()
    inventory.groups['group1'] = dict()
    inventory.groups['group1'].set_variable = MagicMock(return_value=None)
    inventory.groups['group2'] = dict()
    inventory.groups['group2'].set_variable = MagicMock(return_value=None)
    inventory.groups['group3'] = dict()
    inventory.groups['group3'].set_variable = MagicMock(return_value=None)
    inventory.groups['group4'] = dict()
    inventory.groups['group4'].set

# Generated at 2022-06-25 09:51:50.153397
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    # Host with no parent
    host_0 = {'name': 'host_0'}
    parents_0 = []
    template_vars_0 = {'template_vars_0': 'template_vars_0'}

    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents(inventory, host_0, parents_0, template_vars_0)
    assert inventory.hosts() == ['host_0']
    assert inventory.groups() == []

    # Host with 1 parent
    host_1 = {'name': 'host_1'}
    parents_1 = [{'name': 'parent_1'}]
    template_vars_1 = {'template_vars_1': 'template_vars_1'}

    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 09:51:54.781991
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = ()
    assert inventory_module_0.template("", "") == ""

# Generated at 2022-06-25 09:52:06.418175
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # inventory = <ansible.parsing.dataloader.DataLoader object at 0x7f6303e36490>
    # loader = <ansible.parsing.dataloader.DataLoader object at 0x7f6303e36490>
    # path = "../temp/inventory.config"
    # cache = False

    # initializing object
    test_object = InventoryModule()

    # initializing variables
    inventory = '''<ansible.parsing.dataloader.DataLoader object at 0x7f6303e36490>'''
    loader = '''<ansible.parsing.dataloader.DataLoader object at 0x7f6303e36490>'''
    path = '''"../temp/inventory.config"'''
    cache = False

    # invoking method

# Generated at 2022-06-25 09:52:12.551168
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = Inventory(loader=None, variable_manager=None, host_list=None)
    loader_0 = None
    path_0 = '/tmp/yaml_inventory0'
    cache_0 = False
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)

# Generated at 2022-06-25 09:52:21.686112
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_verify_file = InventoryModule()
    # Test Case 0
    # Testing valid file extensions
    try:

        inventory_module_verify_file.verify_file('abcdefgh.yml')
        assert True
    except:
        assert False

    # Test Case 1
    # Testing valid file extensions
    try:
        inventory_module_verify_file.verify_file('a.config')
        assert True
    except:
        assert False

    # Test Case 2
    # Testing invalid file extensions
    try:
        inventory_module_verify_file.verify_file('abcdefgh.yaml')
        assert False
    except:
        assert True

# Generated at 2022-06-25 09:52:32.428097
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_add_parents = InventoryModule()
    inventory_module_add_parents.template = lambda x,y: y['application']
    inventory = {}

# Generated at 2022-06-25 09:52:39.333576
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    template_inputs_0 = product(*config['layers'].values())
    for item in template_inputs_0:
        template_vars_0 = dict()
        for i, key in enumerate(config['layers'].keys()):
            template_vars_0[key] = item[i]
        host_0 = inventory_module_0.template(config['hosts']['name'], template_vars_0)
        inventory_module_0.add_parents(inventory, host_0, config['hosts'].get('parents', []), template_vars_0)


# Generated at 2022-06-25 09:52:41.833070
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:52:46.244324
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    path = "/path/to/file"
    assert inventory_module.verify_file(path) == False
    path = "/path/to/file.config"
    assert inventory_module.verify_file(path) == True
    path = "/path/to/file.yml"
    assert inventory_module.verify_file(path) == True


# Generated at 2022-06-25 09:52:50.646068
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    assert inventory_module.plugin == 'generator'
    assert inventory_module.verify_file("/tmp/inventory.config") == True
    assert inventory_module.verify_file("/tmp/inventory.yaml") == True
    assert inventory_module.verify_file("/tmp/inventory.yml") == True
    assert inventory_module.verify_file("/tmp/inventory") == False


# Generated at 2022-06-25 09:52:55.246098
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()

if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_add_parents()

# Generated at 2022-06-25 09:52:56.418665
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse()

# Generated at 2022-06-25 09:53:06.221130
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    inventory_module = InventoryModule()

    pattern = "{{ env }}_{{ role_name }}_runner"
    variables = {"env": "qa", "role_name": "web"}

    result = inventory_module.template(pattern, variables)

    assert result == "qa_web_runner"


# Generated at 2022-06-25 09:53:08.781962
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    try:
        inventory_module_0.add_parents("inventory_module_0", "child", "parents", "template_vars")
    except:
        assert True


# Generated at 2022-06-25 09:53:11.235538
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    inventory_module_1.parse(inventory=None, loader=None, path=None, cache=False)


# Generated at 2022-06-25 09:53:14.266178
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory=None, loader=None, path=None, cache=None)


# Generated at 2022-06-25 09:53:23.286871
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = mock.Mock()
    inventory_module_0.templar.do_template.return_value = 'mock_result_0'
    inventory_module_0.templar.available_variables = dict()
    inventory_module_0.templar.available_variables = dict()
    inventory_module_0.templar.available_variables = dict()
    inventory_module_0.templar.available_variables = dict()
    inventory_module_0.templar.available_variables = dict()
    inventory_module_0.templar.available_variables = dict()
    inventory_module_0.templar.available_variables = dict()
    inventory_module_0.templar

# Generated at 2022-06-25 09:53:33.857792
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    test_data = {
        'layers': {
            'operation': ['build', 'launch'],
            'environment': ['dev', 'test', 'prod'],
            'application': ['web', 'api']
        },
        'hosts': {
            'name': "{{ operation }}_{{ application }}_{{ environment }}_runner"
        }
    }
    inventory_module_1 = InventoryModule()
    result = inventory_module_1.template("{{ operation }}_{{ application }}_{{ environment }}_runner", test_data['layers'])
    assert result=="build_web_dev_runner" or result == 'launch_web_test_runner' or result == 'build_api_prod_runner'


# Generated at 2022-06-25 09:53:35.928510
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents(inventory_0, name_0, parents_0, variables_0)


# Generated at 2022-06-25 09:53:38.372056
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():

    inventory_module_template = InventoryModule()

    pattern = '{{ key1 }}_{{ key2 }}'
    variables = {'key1': 'value1', 'key2': 'value2'}
    inventory_module_template.template(pattern, variables)

# Generated at 2022-06-25 09:53:42.433955
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # check that file extensions are handled correctly
    assert not inventory_module_0.verify_file('./test')
    assert not inventory_module_0.verify_file('./test.yml')
    assert inventory_module_0.verify_file('./test.config')


# Generated at 2022-06-25 09:53:50.655707
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    try:
        # Invalid path
        assert not inventory_module_0.verify_file("/invalid/path")
        # Valid path
        assert inventory_module_0.verify_file("/usr/ansible/ansible/plugins/inventory/generator.py")
        # Invalid extension
        assert not inventory_module_0.verify_file("invalid_ext.txt")
    except:
        print("Unit test for method verify_file of class InventoryModule failed")
        return -1

    return 0


# Generated at 2022-06-25 09:54:05.079182
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file("inventory.config") == True
    assert inventory_module_0.verify_file("inventory.yml") == True
    assert inventory_module_0.verify_file("inventory.yaml") == True
    print("test_InventoryModule_verify_file: test_case_0")


# Generated at 2022-06-25 09:54:11.192106
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert(inventory_module_1.verify_file('inventory.config') == True)
    assert(inventory_module_1.verify_file('inventory.txt') == False)


# Generated at 2022-06-25 09:54:21.636272
# Unit test for method add_parents of class InventoryModule

# Generated at 2022-06-25 09:54:29.265527
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory_module.inventory = object()
    child = object()
    parents = object()
    template_vars = object()
    try:
        inventory_module.add_parents(inventory_module.inventory, child, parents, template_vars)
    except AnsibleParserError:
        return True
    raise Exception("add_parents did not raise AnsibleParserError on parents with no name element")


# Generated at 2022-06-25 09:54:30.803978
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = {'groups': {}}
    loader = 'loader'
    path = 'path'
    inventory_module.parse(inventory, loader, path)

# Generated at 2022-06-25 09:54:41.689685
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import yaml

# Generated at 2022-06-25 09:54:47.190550
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    assert not inventory_module_0.template("{{ operation }}_{{ application }}_{{ environment }}_runner", {"application": "web", "operation": "build", "environment": "dev"})

# Generated at 2022-06-25 09:54:58.103173
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:55:08.506219
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_config_file_path = 'unit_test_parse_inventory.config'
    inventory_module = InventoryModule()
    inventory = dict()
    inventory_module.parse(inventory, None, inventory_config_file_path)

# Generated at 2022-06-25 09:55:17.825563
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  # Test invalid file extension
  assert inventory_module_0.verify_file('inventory.yaml') is True
  assert inventory_module_0.verify_file('inventory.j2') is True
  assert inventory_module_0.verify_file('inventory.config') is True
  assert inventory_module_0.verify_file('inventory.yml') is True

  # Test valid file extension
  assert inventory_module_0.verify_file('inventory.py') is False


# Generated at 2022-06-25 09:55:31.812192
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_2 = InventoryModule()
    inventory_module_2.parse()

# Generated at 2022-06-25 09:55:41.574370
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:55:51.098930
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Note: the inventory file is defined in the docstring
    # inputs
    inventory = DictInventory()
    loader = DictLoader()
    path = 'inventory.config'
    cache = False

    # invocation
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, path, cache = cache)

    # assertions
    assert inventory['web_test_runner']['hosts'] == ['web_test_runner']
    assert inventory['web_test_runner']['vars'] == {}
    assert inventory['test']['hosts'] == ['web_test_runner', 'api_test_runner']
    assert inventory['test']['vars'] == {}
    assert inventory['api_test_runner']['hosts'] == ['api_test_runner']

# Generated at 2022-06-25 09:56:02.000733
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    config_file_name = "config.yml"
    config_file_name_1 = "config.yaml"
    config_file_name_2 = "config"
    config_file_name_3 = "config.config"
    config_file_name_4 = "config.txt"
    config_file_name_5 = "config.xaml"

    # config file name is config.yml
    assert(inventory_module.verify_file(config_file_name))
    # config file name is config.yaml
    assert(inventory_module.verify_file(config_file_name_1))
    # config file name is config
    assert(inventory_module.verify_file(config_file_name_2))
    # config file name is config.config


# Generated at 2022-06-25 09:56:04.344653
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()

    # Test case 01
    # inventory_module_0.add_parents()
    # assert inventory_module_0.add_parents() == True


# Generated at 2022-06-25 09:56:07.110368
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()

    # test case 0
    # expect: 
    #  return:
    inventory_module.add_parents()


# Generated at 2022-06-25 09:56:12.820823
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    pattern = '{{ operation }}_{{ application }}_{{ environment }}_runner'
    variables = {'operation': 'build', 'application': 'web', 'environment': 'dev'}
    assert inventory_module_1.template(pattern, variables) == 'build_web_dev_runner'


# Generated at 2022-06-25 09:56:17.982704
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    # Test raise AnsibleError for no config option
    inventory_configuration = {}
    inventory_module.parse(inventory_configuration)


# Generated at 2022-06-25 09:56:24.211446
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    inventory_module_1 = InventoryModule()
    loader_1 = DataLoader()
    inventory_1 = InventoryManager(loader_1, [])
    var_manager_1 = VariableManager(loader_1, inventory_1)
    path_1 = None
    cache_1 = True
    inventory_module_1.parse(inventory_1, loader_1, path_1, cache_1)
    path_2 = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../plugins/inventory/test/unit/inventory'))

# Generated at 2022-06-25 09:56:29.975953
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = None
    loader_0 = None
    path_0 = None
    cache_0 = None
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)

# Generated at 2022-06-25 09:56:54.562506
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.template("{{ data_0 }}", {"data_0": "data_0"}) == "data_0"
    assert inventory_module_1.template("{{ data_1 }}", {"data_0": "data_0"}) == ""
    assert inventory_module_1.template("{{ data_0 }}", {}) == ""
    assert inventory_module_1.template("{{ data_0 }}", None) == ""


# Generated at 2022-06-25 09:56:57.718444
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    inventory_module_0 = InventoryModule()

    # There's no way to test this method without using an instance of
    # ansible.inventory.Inventory, which is too complex to build without
    # a full environment.
    #
    # To avoid it, the method is not tested here.
    #
    assert True



# Generated at 2022-06-25 09:57:00.966571
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    generator_vars_0 = {"operation": "build",
                      "environment": "dev",
                      "application": "web"}
    result = inventory_module_0.template("{{ operation }}_{{ application }}_{{ environment }}_runner", generator_vars_0)
    assert result == "build_web_dev_runner"

# Generated at 2022-06-25 09:57:09.761310
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = {}
    loader = {}
    inventory_module.parse(inventory, loader, 'inventory.config')

# Generated at 2022-06-25 09:57:11.488947
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_1 = InventoryModule()
    obj1 = inventory_module_1.parse('inventory', 'loader', 'path', False)



# Generated at 2022-06-25 09:57:16.489936
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test the methods of InventoryModule
    inventory_module = InventoryModule()

    # Test InventoryModule.parse
    assert inventory_module.parse(inventory, loader, path, cache=False) is None

# Generated at 2022-06-25 09:57:18.210780
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    try:
        inventory_module = InventoryModule()
        inventory_module.parse(None, None, None, cache=False)
    except:
        return False

    return True

# Generated at 2022-06-25 09:57:23.475214
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    
    currentDirectory = os.getcwd()
    inventory_module_1 = InventoryModule()

    # Testing for valid input
    assert(inventory_module_1.verify_file(currentDirectory + "/test/test_case_1_inventory.config") == True)
    assert(inventory_module_1.verify_file(currentDirectory + "/test/test_case_1_inventory.yml") == True)

    # Testing for invalid input
    assert(inventory_module_1.verify_file(currentDirectory + "/test/test_case_1_inventory.yaml") == False)
    assert(inventory_module_1.verify_file(currentDirectory + "/test/test_case_1_inventory.txt") == False)


# Generated at 2022-06-25 09:57:28.566682
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    with pytest.raises(AnsibleParserError) as e_info:
        inventory_module_0.parse(inventory=object(), loader=object(), path=object(), cache='cache')

# Generated at 2022-06-25 09:57:31.672708
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_11 = InventoryModule()
    inventory = dict()
    template_vars = dict()
    inventory_module_11.add_parents(inventory, 'child1', 'parents1', 'template_vars1')
    assert inventory == dict()
    assert template_vars == dict()


# Generated at 2022-06-25 09:58:03.226640
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:58:06.009100
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = 0
    loader = 0
    path = "../inventory/inventory.config"
    return_value = inventory_module.parse(inventory,loader,path)
    assert return_value == 'template_vars'


# Generated at 2022-06-25 09:58:16.523727
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:58:19.471248
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('inventory_module_inventory_0', 'loader_0', 'path_0', False)

if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:58:27.403903
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()

    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory_module_0.loader = loader

    inventory = InventoryManager(loader, sources='localhost,')
    inventory.subset('template')

    inventory_module_0.inventory = inventory

    child = 'template1'

    groupname = 'template_test'
    group = inventory.groups[groupname]

    inventory.add_child(groupname, child)
    inventory_module_0.add_parents(inventory, groupname, group.parents, group.vars)


# Generated at 2022-06-25 09:58:31.790876
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("./generator.config")
    assert inventory_module.verify_file("./generator.yml")
    assert not inventory_module.verify_file("./generator.py")


# Generated at 2022-06-25 09:58:34.862273
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:58:36.785394
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory = 0
    child = 0
    parents = 0
    template_vars = 0
    inventory_module_0.add_parents(inventory, child, parents, template_vars)



# Generated at 2022-06-25 09:58:40.061462
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    assert(inventory_module_0.verify_file('config.yml') == True)


# Generated at 2022-06-25 09:58:44.309549
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # InventoryModule with default configuration
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 09:59:16.450902
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    file_path_1 = 'inventory.config'
    child_mock_1 = MagicMock()
    child_mock_1.verify_file.return_value = False
    child_mock_1.verify_file.assert_called_once_with(file_path_1)
    child_mock_1.setattr(self)
    inventory_module_1.verify_file(file_path_1)

    file_path_2 = 'inventory.txt'
    child_mock_2 = MagicMock()
    child_mock_2.verify_file.return_value = False
    child_mock_2.verify_file.assert_called_once_with(file_path_2)
    child_mock_2.set

# Generated at 2022-06-25 09:59:23.407659
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = {}
    loader_0 = {}
    path_0 = 'inventory.config'
    cache_0 = False

# Generated at 2022-06-25 09:59:32.478873
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.template = lambda pattern, variables: pattern
    inventory_module_1.add_parents(inventory_module_1.parse(None, None, C.config.get_config_file()), "test_case_1_inventory.config", {'name':'{{ operation }}_{{ application }}_{{ environment }}_runner'}, {'operation':'build', 'application':'web', 'environment':'dev'})

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_add_parents()

# Generated at 2022-06-25 09:59:37.544025
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents(inventory_module_1.self, "child", inventory_module_1.self, "template_vars")


# Generated at 2022-06-25 09:59:39.461035
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()

    # Call method verify_file of InventoryModule with arguments
    # Return Value:
    #    None

    assert inventory_module_0.verify_file('inventory.config')==True


# Generated at 2022-06-25 09:59:45.185714
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = inventory_module_0.parse()
    print(type(inventory_module_0))
    print(type(inventory_module_0.NAME))
    print(type(inventory_module_0.NAME))
    print(type(inventory_module_0.NAME))
    print(type(inventory_module_0.NAME))
    print(type(inventory_module_0.NAME))
    print(type(inventory_module_0.NAME))
    print(type(inventory_module_0.NAME))
    print(type(inventory_module_0.NAME))
    print(type(inventory_module_0.NAME))
    print(type(inventory_module_0.NAME))
    print(type(inventory_module_0.NAME))

# Generated at 2022-06-25 09:59:51.690284
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    import tempfile
    import os
    from ansible.parsing.dataloader import DataLoader

    inventory_module_1 = InventoryModule()
    inventory_module_1.loader = DataLoader()

    # initializes some example inventory data
    host_1 = '{{ operation }}_{{ application }}_{{ environment }}_runner'

# Generated at 2022-06-25 09:59:55.091431
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.parse("inventory_1", "loader_1", "path_1", cache=False) == None


# Generated at 2022-06-25 10:00:01.526390
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    item = {'name': 'test_runner', 'parents': [{'name': 'test'}, {'name': 'runner'}]}
    inventory_module.add_parents(item , 'test_runner' , [{'name': 'test'}, {'name': 'runner'}], {'test': 'test', 'runner': 'runner'})


# Generated at 2022-06-25 10:00:05.774507
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    file_name = 'inventory.config'
    f = open(file_name, 'w')
    f.close()
    ext = os.path.splitext(file_name)
    if not ext or ext in ['.config'] + C.YAML_FILENAME_EXTENSIONS:
        valid = True
    inventory_module.verify_file(file_name)

# Generated at 2022-06-25 10:00:36.929143
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = ansible.utils.unsafe_proxy.AnsibleUnsafeText("AnsibleUnsafeText")
    inventory_module_0.add_parents("AnsibleList")


# Generated at 2022-06-25 10:00:43.144859
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule()
    host_0 = 'lotus'
    group_0 = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    
    parent_vars_0 = {'name':"{{ operation }}_{{ application }}_{{ environment }}"}
    parent_vars_1 = {'name':"{{ operation }}_{{ application }}"}
    parent_vars_2 = {'name':"{{ operation }}"}
    parent_vars_3 = {'name':"{{ application }}"}
    parent_vars_4 = {'name':"{{ application }}_{{ environment }}", 'vars':{'application':"{{ application }}"}}

# Generated at 2022-06-25 10:00:53.131926
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()