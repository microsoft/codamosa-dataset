

# Generated at 2022-06-25 09:51:03.946164
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    inventory = {}
    loader = {}
    path = './inventory.config'
    cache = False

    inventory_module_0.parse(inventory, loader, path, cache)
    assert inventory['web_dev_runner'] is not None
    assert inventory['web_dev'] is not None
    assert inventory['dev'] is not None
    assert inventory['web'] is not None
    assert inventory['runner'] is not None
    assert inventory['web_dev_runner'].get_variables() == {'environment': 'dev', 'application': 'web'}
    assert inventory['web_dev'].get_variables() == {'environment': 'dev', 'application': 'web'}
    assert inventory['dev'].get_variables() == {'environment': 'dev'}

# Generated at 2022-06-25 09:51:07.038711
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:51:10.876702
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents(inventory, child="child", parents=["parent1", "parent2"], template_vars=["vars"])

# Generated at 2022-06-25 09:51:18.383234
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_data = []
    test_data.append(('test_inventory_file.config', True))
    test_data.append(('test_inventory_file.yml', True))
    test_data.append(('test_inventory_file.yaml', True))
    test_data.append(('test_inventory_file.txt', False))

    inventory_module = InventoryModule()
    for data in test_data:
        result = inventory_module.verify_file(data[0])
        assert result is data[1]


# Generated at 2022-06-25 09:51:19.553772
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory = MagicMock()
    inventory_module_0.add_parents(inventory, "child", [{"name": "parent"}], "template_vars")


# Generated at 2022-06-25 09:51:27.745748
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory_module.templar = None
    input_inventory = {}
    input_child = {}
    input_parents = {}
    input_template_vars = {}
    expectedResult = {}
    actualResult = inventory_module.add_parents(input_inventory, input_child, input_parents,
                                                input_template_vars)
    assert actualResult == expectedResult


# Generated at 2022-06-25 09:51:37.341516
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert(inventory_module_1.verify_file('/test/path/inventory.config'))
    assert(inventory_module_1.verify_file('/test/path/inventory.yml'))
    assert(inventory_module_1.verify_file('/test/path/inventory.yaml'))
    assert(inventory_module_1.verify_file('/test/path/inventory.json'))
    assert(inventory_module_1.verify_file('/test/path/inventory'))
    assert(inventory_module_1.verify_file('/test/path/inventory.txt'))
    assert(inventory_module_1.verify_file('/test/path/inventory.text'))

# Generated at 2022-06-25 09:51:42.566950
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()

    path_0 = "~/../ansible_generator_inventory/inventory.config"
    verify_file_return_value = inventory_module_0.verify_file(path_0)

    print(verify_file_return_value)


# Generated at 2022-06-25 09:51:50.908384
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    f = 'tests/unit/inventory_plugins/generator_test_0'
    assert inventory_module_1.verify_file(f) == True
    f = 'inventory.hosts'
    assert inventory_module_1.verify_file(f) == False
    f = 'inventory.hosts.yml'
    assert inventory_module_1.verify_file(f) == True
    f = 'inventory.hosts.yaml'
    assert inventory_module_1.verify_file(f) == True
    f = 'inventory.hosts.yaml.config'
    assert inventory_module_1.verify_file(f) == True
    f = 'inventory.hosts.yaml.config.config'
    assert inventory_module_1.verify

# Generated at 2022-06-25 09:51:54.539108
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    inventory_module_1.template(pattern="{{ operation }}{{ application }}", variables=[operation, application])

# Generated at 2022-06-25 09:52:01.671099
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = None
    assert isinstance(inventory_module_0.add_parents(inventory_module_0.inventory, "child", "parents", "template_vars"), None)

# Generated at 2022-06-25 09:52:03.805989
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    loader = None
    path = 'inventory_file'
    cache = True
    inventory_module_0.parse(loader, path, cache)

# Generated at 2022-06-25 09:52:05.473285
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    inventory_module_1 = InventoryModule()
    assert not inventory_module_1.add_parents(1, 2, 3, 4)


# Generated at 2022-06-25 09:52:09.075250
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = {}
    inventory_module_0.parse(inventory_0, loader=None, path="file/path")


# Generated at 2022-06-25 09:52:11.271251
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents(inventory_module_1, child, parents, template_vars)


# Generated at 2022-06-25 09:52:14.885474
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Not a YAML or config file
    assert InventoryModule().verify_file('/tmp/file.txt') == False
    # Extension not valid
    assert InventoryModule().verify_file('/tmp/file.test') == False
    # Valid YAML file
    assert InventoryModule().verify_file('/tmp/file.yaml') == True
    # Valid YAML config file
    assert InventoryModule().verify_file('/tmp/file.config') == True


# Generated at 2022-06-25 09:52:19.463458
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    file_name, ext = os.path.splitext('inventory.yml')
    assert ext in ['.config'] + C.YAML_FILENAME_EXTENSIONS
    file_name, ext = os.path.splitext('inventory.config')
    assert ext in ['.config'] + C.YAML_FILENAME_EXTENSIONS
    file_name, ext = os.path.splitext('inventory')
    assert not ext or ext in ['.config'] + C.YAML_FILENAME_EXTENSIONS



# Generated at 2022-06-25 09:52:25.214688
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert inventory_module_0.verify_file('filename_with_no_extension') == True
    assert inventory_module_0.verify_file('filename.config') == True
    assert inventory_module_0.verify_file('filename.yml') == True
    assert inventory_module_0.verify_file('filename.yaml') == True

# Generated at 2022-06-25 09:52:29.410745
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.templar = True
    assert inventory_module_0.add_parents(True, True, True, True) == None


# Generated at 2022-06-25 09:52:33.900295
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    assert hasattr(inventory_module_0, "_read_config_data")
    assert hasattr(inventory_module_0, "template")
    assert hasattr(inventory_module_0, "parse")
    assert hasattr(inventory_module_0, "verify_file")


# Generated at 2022-06-25 09:52:43.872566
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_2 = InventoryModule()
    inventory_3 = object()
    loader_4 = object()
    path_5 = 'inventory.config'
    cache_6 = False
    inventory_module_2.parse(inventory_3, loader_4, path_5, cache_6)

# Generated at 2022-06-25 09:52:46.785369
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory = {}
    inventory_module = InventoryModule()
    inventory_module.parse(inventory = inventory, loader = None, path = None, cache = False)

    assert(len(inventory.items()) == 0)



# Generated at 2022-06-25 09:52:49.840846
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    fake_inventory = 'fake inventory'
    fake_loader = 'fake loader'
    fake_path = 'fake path'
    inventory_module_0.parse(fake_inventory, fake_loader, fake_path)


# Generated at 2022-06-25 09:52:53.188533
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_0 = InventoryModule()
    pattern = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    variables = ["build", "web", "dev"]
    result = inventory_module_0.template(pattern, variables)
    assert result == "build_web_dev_runner"


# Generated at 2022-06-25 09:52:57.563218
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    mock_path = "inventory/test_cases/test_case_0"
    assert inventory_module_1.verify_file(mock_path) == True

# Generated at 2022-06-25 09:53:04.903357
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # Create an instance of the InventoryModule class
    inventory_module = InventoryModule()

    # Invoke the verify_file method
    result = inventory_module.verify_file('inventory.config')

    # Verify that the result is True
    assert result == True


test_case_0()
test_InventoryModule_verify_file()

# Generated at 2022-06-25 09:53:08.905955
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = None
    loader_0 = None
    path_0 = './test_file'
    cache_0 = False
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)

# Generated at 2022-06-25 09:53:13.845749
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    #Call method verify_file of class InventoryModule on the variable inventory_module_1
    assert inventory_module_1.verify_file("inventory.config")
    assert inventory_module_1.verify_file("inventory.yml")

#Unit test for method parse of class InventoryModule.

# Generated at 2022-06-25 09:53:23.037940
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    class inventory_mock:
        def __init__(self):
            self.groups = {
                u'api_dev': [],
                u'api_prod': [],
                u'api_test': [],
                u'build_api': [],
                u'build_web': [],
                u'launch_api': [],
                u'launch_web': [],
                u'web_dev': [],
                u'web_prod': [],
                u'web_test': [],
                u'dev': [],
                u'prod': [],
                u'test': [],
                u'api': [],
                u'web': [],
                u'runner': []
            }


# Generated at 2022-06-25 09:53:34.201989
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    hostname = "test-host"
    parent_name = "parent-group"
    template_vars = {
        'foo': 'baz'
    }
    def add_group(name):
        nonlocal group
        group = InventoryModule.create_group(name)

    def add_child(name, child):
        nonlocal group
        group.add_host(child)

    inventory = {
        'add_group': add_group,
        'add_child': add_child
    }
    parent_config = {
        'name': parent_name,
        'vars': {
            'foo': '{{ foo }}'
        }
    }
    InventoryModule.add_parents(inventory, hostname, [parent_config], template_vars)
    assert group
    assert group.name == parent_name

# Generated at 2022-06-25 09:53:46.203553
# Unit test for method template of class InventoryModule
def test_InventoryModule_template():
    inventory_module_1 = InventoryModule()
    input_pattern = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    input_variables = {}
    actual_result = inventory_module_1.template(input_pattern, input_variables)
    assert actual_result == "{{ operation }}_{{ application }}_{{ environment }}_runner"



# Generated at 2022-06-25 09:53:51.905081
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file('inventory.config') == True
    assert inventory_module_1.verify_file('inventory.ini') == False


# Generated at 2022-06-25 09:53:57.791808
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file(path='test.config')
    assert not inventory_module.verify_file(path='inventory.ini')
    assert not inventory_module.verify_file(path='inventory.yaml')
    assert inventory_module.verify_file(path='inventory.yml')
    assert not inventory_module.verify_file(path='inventory.json')


# Generated at 2022-06-25 09:54:04.975048
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # static test cases
    static_test_cases = [
        {"__ansible_vault": "AQAAAAt/xMkBAwABAhQNAAAABQ8AAAACAAAAAQAAAAdzZXJ2aWNlLWNhdGFsb2VyCgAAAAEAAABdAAAAAQ==\n", "inventory_hostname": "dummy_host1"},
        {"inventory_hostname": "dummy_host2"},
        {"inventory_hostname": "dummy_host3"}
    ]

    for static_test_case in static_test_cases:
        assert static_test_case == static_test_case


# Generated at 2022-06-25 09:54:11.157598
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = dict()
    loader_1 = dict()
    path_1 = dict()
    inventory_module_1.parse(inventory_1, loader_1, path_1)


# Generated at 2022-06-25 09:54:13.916436
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module = InventoryModule()
    inventory = BaseInventoryPlugin()
    child = 'child1'
    parents = [{'name': 'father1'}]
    template_vars = {'layer1': 'value1'}
    assert inventory.hos

# Generated at 2022-06-25 09:54:16.808058
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:54:23.557337
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory = InventoryModule()
    inventory.add_host('db001')
    inventory.add_group('db')
    inventory.add_group('vagrant')

    config = {}
    config['hosts'] = {}
    config['hosts']['name'] = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    config['hosts']['parents'] = [{'name': "{{ operation }}_{{ application }}_{{ environment }}"},
                                  {'name': "{{ operation }}_{{ application }}"},
                                  {'name': "{{ operation }}"},
                                  {'name': "{{ application }}"},
                                  {'name': "{{ application }}_{{ environment }}"},
                                  {'name': "{{ environment }}"},
                                  {'name': "runner"}]
    config['layers'] = {}
   

# Generated at 2022-06-25 09:54:27.612161
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    temp = 'inventory_module_parse'
    assert temp == 'inventory_module_parse'


# Generated at 2022-06-25 09:54:29.674277
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents()


# Generated at 2022-06-25 09:54:47.241511
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory = object()
    child = object()
    parents = []
    template_vars = dict()
    inventory_module = InventoryModule()

    # invoke method
    inventory_module.add_parents(inventory, child, parents, template_vars)

    # Assert equal
    assert 0


# Invoke test_case_0
test_case_0()

# Generated at 2022-06-25 09:54:51.166878
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    test_cases = [('inventory.yml', False),
                  ('inventory.config', True),
                  ('inventory.my', False)]

    for (test_case, result) in test_cases:
        assert InventoryModule().verify_file(test_case) == result


# Generated at 2022-06-25 09:55:00.141134
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    # Set up template_vars for use in test
    template_vars = {}
    template_vars['operation'] = operation = 'build'
    template_vars['application'] = application = 'web'
    template_vars['environment'] = environment = 'dev'

    # Set up config for use in test
    config = {}
    config['hosts'] = {}
    config['hosts']['name'] = host_name = '{{ operation }}_{{ application }}_{{ environment }}_runner'
    parent_group_1 = {}
    parent_group_1['name'] = host_name = '{{ operation }}_{{ application }}_{{ environment }}'
    parent_group_1['parents'] = parents_1 = []

    parent_group_2 = {}

# Generated at 2022-06-25 09:55:02.932502
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    test_inventory_module_add_parents = InventoryModule()
    inventory_module_obj = InventoryModule()
    inventory = inventory_module_obj.inventory
    child = 'child'
    parents = [{"name" : "parent1"},{"name" : "parent2"}]
    template_vars = {'key1' : 'val1', 'key2' : 'val2'}
    test_inventory_module_add_parents.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:55:09.283638
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_0 = inventory_module_0.inventory
    inventory_module_0.add_parents(inventory_0, 'child', 'parents', 'template_vars')

if __name__ == '__main__':
    print("Test run: add_parents")
    test_InventoryModule_add_parents()

# Generated at 2022-06-25 09:55:20.978307
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    inventory_module = InventoryModule()

    class Inventory:

        groups = {}

        def add_child(self, child, parent):
            print("add_child called with %s, %s" % (child, parent))

        def add_host(self, host):
            print("add_host called with %s" % host)

        def add_group(self, group):
            print("add_group called with %s" % group)
            group_obj = Group(group)
            self.groups[group] = group_obj

    class Group:

        def __init__(self, group):
            self.group = group
            self.children = []
            self.vars = {}

        def set_variable(self, key, value):
            self.vars[key] = value


# Generated at 2022-06-25 09:55:29.116219
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()

    file_0 = 'D:\\GitHub\\ansible\\lib\\ansible\\plugins\\inventory\\test_0_inventory.config'
    file_name_0, ext_0 = os.path.splitext(file_0)
    assert (file_name_0 == 'D:\\GitHub\\ansible\\lib\\ansible\\plugins\\inventory\\test_0_inventory')
    assert (ext_0 == '.config')

    valid_0 = inventory_module_1.verify_file(file_0)
    assert (valid_0 == True)


# Generated at 2022-06-25 09:55:35.297597
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()

    template_vars = {}
    child = 'child'
    parents = [{'name': 'parent'}]
    inventory = {}

    inventory_module_0.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:55:43.746918
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()

    # NOTE: The following line is necessary because it makes the unit test
    #       independent of the environment.
    inventory_module_0.templar = Templar(loader=None, variables=None)

    inventory_module_0.templar._available_variables = {
        'foo': 'foo',
        'bar': 'bar',
        'baz': 'baz'
    }
    inventory_module_0._read_config_data = lambda x : {
        'layers': {
            'foo': ['1'],
            'bar': ['2'],
            'baz': ['3']
        },
        'hosts': {
            'name': '{{foo}}{{bar}}{{baz}}'
        }
    }

    inventory_module_0._is_

# Generated at 2022-06-25 09:55:51.422755
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config_path = os.path.join(os.path.dirname(__file__), '../../tests/inventory/plugins/generator/inventory.yaml')
    inventory_module = InventoryModule()
    inventory = BaseInventoryPlugin()
    cache = None

    inventory_module.parse(inventory, None, config_path, cache=cache)

if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:56:12.374584
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    inv_module_obj = InventoryModule()
    test_children = {'name': 'test_child'}
    test_template_vars = {'test_group': 'test_group'}
    group_1 = {'name': '{{test_group}}', 'vars': {}}
    group_2 = {'name': '{{test_group}}', 'parents': [], 'vars': {}}
    inv_module_obj.add_parents(group_1, test_children, test_template_vars)
    inv_module_obj.add_parents(group_2, test_children, test_template_vars)



# Generated at 2022-06-25 09:56:18.967089
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory = inventory_module_0
    child = "child"
    parents = [[{"name":"parent"}]]
    template_vars = "template_vars"
    inventory_module_0.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:56:21.315574
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    inventory_module_0.verify_file('/etc/ansible/inventory.config')


# Generated at 2022-06-25 09:56:29.351953
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("/path/to/file.txt") == False
    assert inventory_module.verify_file("/path/to/file.yml") == True
    assert inventory_module.verify_file("/path/to/file.yaml") == True
    assert inventory_module.verify_file("/path/to/file.config") == True

if __name__ == '__main__':
    test_InventoryModule_verify_file()

# Generated at 2022-06-25 09:56:30.491158
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()


# Generated at 2022-06-25 09:56:35.512142
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    path = "inventory.config"
    assert (inventory_module.verify_file(path)) == True


# Generated at 2022-06-25 09:56:40.129539
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory_module_parse._read_config_data = Mock(return_value="MOCK_READ_CONFIG_DATA")
    inventory_module_parse.cache = Mock()
    inventory_module_parse.parse(inventory, loader, path, cache=False)


# Generated at 2022-06-25 09:56:47.065537
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = {"_meta": {"hostvars": {}}}
    loader = None
    path = "./test_case_1.config"
    cache = False
    inventory_module_1.parse(inventory, loader, path, cache)
    result = inventory

# Generated at 2022-06-25 09:56:49.578363
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory_module_0.add_parents(inventory=inventory_module_0, child=inventory_module_0, parents=inventory_module_0, template_vars=inventory_module_0)


# Generated at 2022-06-25 09:56:56.169508
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Input parameters
    path = 'inventory.config'
    # Expected output
    expected_hostnames = ['launch_web_dev_runner',
                          'launch_web_test_runner',
                          'launch_web_prod_runner',
                          'launch_api_dev_runner',
                          'launch_api_test_runner',
                          'launch_api_prod_runner',
                          'build_web_dev_runner',
                          'build_web_test_runner',
                          'build_web_prod_runner',
                          'build_api_dev_runner',
                          'build_api_test_runner',
                          'build_api_prod_runner']

# Generated at 2022-06-25 09:57:24.315397
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():

    inventory_module = InventoryModule()
    inventory_module_add_parents_1 = inventory_module.add_parents(None, None, None, None)
    # unit test assertion
    assert (inventory_module_add_parents_1 is None)


# Generated at 2022-06-25 09:57:30.489241
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    # Verify that InventoryModule.verify_file returns true when it gets the file with name './sample_inventory.config'
    assert inventory_module.verify_file('./sample_inventory.config')
    # Verify that InventoryModule.verify_file returns false when it gets the file which is not exist
    assert not inventory_module.verify_file('/not_exist')



# Generated at 2022-06-25 09:57:33.618265
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory = "inventory"
    child = "child"
    parents = "parents"
    template_vars = "template_vars"
    inventory_module_0.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:57:38.854604
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = "inventory.config"
    assert inventory_module_0.verify_file(path)


# Generated at 2022-06-25 09:57:45.775365
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    config = dict()
    config['layers'] = dict()
    config['layers']['operation'] = ['build','launch']
    config['layers']['environment'] = ['dev','test','prod']
    config['layers']['application'] = ['web','api']
    config['hosts'] = dict()
    config['hosts']['name'] = "{{ operation }}_{{ application }}_{{ environment }}_runner"
    config['hosts']['parents'] = list()
    parent_0 = dict()
    parent_0['name'] = "{{ operation }}_{{ application }}_{{ environment }}"
    parent_0['parents'] = list()
    parent_0['parents'].append(dict())
    parent_0['parents'][0]['name'] = "{{ operation }}_{{ application }}"


# Generated at 2022-06-25 09:57:51.204075
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    path = os.path.join(os.path.dirname(__file__), './data/inventory.config')
    result = inventory_module.verify_file(path)
    assert result == True


# Generated at 2022-06-25 09:58:02.395077
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    play = Play()
    host = inventory.add_group("all")

    inventory_module_1 = InventoryModule()
    # load file in memory
    with open(os.path.join(os.path.dirname(__file__), "./fixtures/inventory.config"), 'r') as data_file:
        data = data_file.read()

    cache = False

    inventory_module_1.parse

# Generated at 2022-06-25 09:58:04.098759
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_0 = InventoryModule()
    inventory = {}
    child = {}
    parents = {}
    template_vars = {}
    inventory_module_0.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:58:14.373878
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:58:18.233818
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module=InventoryModule()

    # define input parameters
    inventory = { }
    loader = "string"
    path = "string"
    cache = False

    # test the parse method
    inventory_module.parse(inventory, loader, path, cache)

    # assert the test results
    assert True


# Generated at 2022-06-25 09:59:22.800368
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory = {}
    child = {}
    parents = {}
    template_vars = {}
    result = inventory_module_1.add_parents(inventory, child, parents, template_vars)


# Generated at 2022-06-25 09:59:32.450545
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    inventory_module.verify_file('inventory.config')  #True
    inventory_module.verify_file('inventory.yml')  #True
    inventory_module.verify_file('inventory.yaml')  #True
    inventory_module.verify_file('inventory.yml.yaml')  #True
    inventory_module.verify_file('inventory.config.yaml')  #True
    inventory_module.verify_file('inventory')  #False
    inventory_module.verify_file('inventory.txt')  #False


# Generated at 2022-06-25 09:59:37.767086
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    path_0 = object()
    inventory_module_0.parse(inventory_0, loader_0, path_0)


# Generated at 2022-06-25 09:59:43.597832
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test data
    inventory = None
    loader = None
    path = None
    cache = False
    inventory_module_0 = InventoryModule()

    # Invoke method
    return_value = inventory_module_0.parse(inventory, loader, path, cache)

    # Check for expected result
    assert return_value == None


# Generated at 2022-06-25 09:59:45.865052
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = mock("inventory")
    loader = mock("loader")
    path = mock("path")
    cache = mock("cache")
    inventory_module_1.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:59:47.637674
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert isinstance(inventory_module.verify_file("/path/to/config_file.config"), bool)


# Generated at 2022-06-25 09:59:55.466968
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_config_0 = {'plugin': 'generator', 'hosts': {'parents': [{'name': '{{ application }}'}], 'name': '{{ application }}_{{ run }}_runner'}, 'layers': {'run': ['run1', 'run2'], 'application': ['app1', 'app2']}}
    inventory_0 = InventoryModule()
    assert inventory_0.parse(inventory_0, 'loader', 'inventory.config', cache=False) == None

test_InventoryModule_parse()

# Generated at 2022-06-25 09:59:58.846573
# Unit test for method add_parents of class InventoryModule
def test_InventoryModule_add_parents():
    inventory_module_1 = InventoryModule()
    inventory_module_1.add_parents()


# Generated at 2022-06-25 10:00:02.952580
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = inventory_module_1.get_option('inventory')
    loader_1 = inventory_module_1.get_option('loader')
    path_1 = inventory_module_1.get_option('path')
    cache_1 = False
    inventory_module_1.parse(inventory_1, loader_1, path_1, cache_1)


# Generated at 2022-06-25 10:00:06.618106
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    YAML_FILE_PATH = os.path.join(os.path.dirname(__file__), 'test_case_0.yml')

    loader = None
    cache = False
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(Inventory(loader), loader, YAML_FILE_PATH, cache)