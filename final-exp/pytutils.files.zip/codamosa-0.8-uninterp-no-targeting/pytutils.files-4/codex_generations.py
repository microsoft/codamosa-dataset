

# Generated at 2022-06-21 21:33:58.899995
# Unit test for function islurp
def test_islurp():
    import os
    import sys
    import tempfile
    import unittest

    class TestIslurp(unittest.TestCase):
        def setUp(self):
            self.tmp_fh, self.tmp_filename = tempfile.mkstemp()
            os.close(self.tmp_fh)  # Close file handle so I can open in text mode
            self.tmp_fh = open(self.tmp_filename, 'w')

        def tearDown(self):
            self.tmp_fh.close()
            os.remove(self.tmp_filename)

        def test_islurp_from_file(self):
            self.tmp_fh.write("ABC\n")
            self.tmp_fh.write("123\n")

# Generated at 2022-06-21 21:34:03.809846
# Unit test for function islurp
def test_islurp():
    slurp_file = "test/fixtures/slurp_file"
    lines = islurp(slurp_file)
    assert next(lines) == "line1\n"
    assert next(lines) == "line2\n"
    assert next(lines) == "line3\n"
    assert next(lines) == "line4\n"
    assert next(lines) == "line5\n"


# Generated at 2022-06-21 21:34:06.053911
# Unit test for function burp
def test_burp():
    filename = 'test-burp'
    contents = 'Hello World!'

    burp(filename, contents)
    assert slurp(filename).next().rstrip() == contents

    os.remove(filename)


# Generated at 2022-06-21 21:34:09.608164
# Unit test for function burp
def test_burp():
    with open("test.txt", "w") as f:
        f.write("test.txt")
    with open("test.txt") as f:
        assert f.read() == "test.txt"

# Only run if not imported as a module
if __name__ == '__main__':
    test_burp()

# Generated at 2022-06-21 21:34:19.310222
# Unit test for function burp
def test_burp():
    import tempfile, os, unittest
    class TestBurp(unittest.TestCase):
        def setUp(self):
            self.test_filepath = tempfile.gettempdir()+os.path.sep+'spoon.txt'
        def test_burp(self):
            burp(self.test_filepath, "The secret of life is not to mind some of the things people say")
            self.assertEquals(slurp(self.test_filepath), "The secret of life is not to mind some of the things people say")
        def tearDown(self):
            os.remove(self.test_filepath)

    unittest.main()

# Generated at 2022-06-21 21:34:20.773223
# Unit test for function islurp
def test_islurp():
    assert islurp('-') == sys.stdin
  #assert islurp('.') == os.path.abspath('.')

# Generated at 2022-06-21 21:34:22.954200
# Unit test for function burp
def test_burp():
    burp("temp.txt", "Hello World!")
    assert slurp("temp.txt") == "Hello World!"
    return True


# Generated at 2022-06-21 21:34:33.947196
# Unit test for function burp

# Generated at 2022-06-21 21:34:39.124877
# Unit test for function islurp
def test_islurp():
    """
    Test for function islurp
    """
    lines = islurp('../test/resources/test_islurp.txt')
    i = 0
    for line in lines:
        i += 1
        assert line
    assert i == 2

# Generated at 2022-06-21 21:34:43.473188
# Unit test for function islurp
def test_islurp():
    with open('./file_utils.py', 'r') as fh:
        for i, expected_line in enumerate(fh):
            for line in islurp('./file_utils.py', iter_by=islurp.LINEMODE):
                assert line == expected_line



# Generated at 2022-06-21 21:34:57.276477
# Unit test for function islurp
def test_islurp():
    assert list(islurp(__file__))[0].startswith('"""')
    with open(__file__, 'r') as fh:
        assert list(islurp(fh))[0].startswith('"""')

    assert list(islurp('-'))[0].startswith('"""')
    import io
    assert list(islurp(io.BytesIO(b'foo\nbar'))) == [b'foo\n', b'bar']
    assert list(islurp(io.StringIO('foo\nbar'))) == ['foo\n', 'bar']



# Generated at 2022-06-21 21:35:06.953719
# Unit test for function islurp
def test_islurp():
    # Test 1: Reading from string
    test_string = 'Your name is XYZ.'
    result = ''
    for chunk in islurp(test_string):
        result = result + chunk
    assert(result == test_string)
    print('Test 1 passed')

    # Test 2: Reading from file
    test_file = 'test_islurp.txt'
    test_string = 'Your name is XYZ.'
    burp(test_file, test_string)
    result = ''
    for chunk in islurp(test_file):
        result = result + chunk
    assert(result == test_string)
    os.remove(test_file)
    print('Test 2 passed')


# Generated at 2022-06-21 21:35:10.234879
# Unit test for function burp
def test_burp():
    os.system('mkdir tmp')
    burp('tmp/test.txt', 'hello world\n')
    os.system('tail -n 1 tmp/test.txt')
    os.system('rm -rf tmp')


# Generated at 2022-06-21 21:35:15.560582
# Unit test for function burp
def test_burp():
    import tempfile
    mode = 'w'
    # UNUSED_fd, filename = tempfile.mkstemp()
    with tempfile.NamedTemporaryFile(suffix='.tmp', delete=False) as fh:
        fh.write(b'burp burp')
        filename = fh.name
    assert os.path.exists(filename)
    contents = 'burp burp'
    burp(filename, contents, mode)
    assert os.path.getsize(filename) == len(contents)
    os.unlink(filename)

# Generated at 2022-06-21 21:35:23.168397
# Unit test for function islurp
def test_islurp():
    import re
    import tempfile

    def make_temp_file(contents):
        fd, path = tempfile.mkstemp(prefix="tmp-islurp-")
        os.close(fd)
        burp(path, contents)
        return path

    def slurp_in(i):
        return list(islurp(i, iter_by=512, expanduser=False))

    def slurp_in_byline(i):
        return list(islurp(i, allow_stdin=False, expanduser=False))

    # slurp in a file
    filename = make_temp_file("1234567890\n")
    assert slurp_in(filename) == ["1234567890\n"]
    assert slurp_in_byline(filename) == ["1234567890\n"]



# Generated at 2022-06-21 21:35:35.038977
# Unit test for function burp
def test_burp():
    """
    Unit test for burp function.
    """
    import tempfile
    # Test file open modes
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as fh:
        burp(fh.name, 'foo', mode='w')
    try:
        with tempfile.NamedTemporaryFile(mode='wb', delete=False) as fh:
            burp(fh.name, 'foo', mode='wb')
    except TypeError:
        # Python 2 does not have binary mode for files
        pass

    # Test stdout
    burp('-', 'foo', allow_stdout=True)

    # Test that ~ is resolved

# Generated at 2022-06-21 21:35:38.821824
# Unit test for function burp
def test_burp():
    with open("test_output.txt", "w") as fp:
        fp.write("Hello World")
    assert burp("test_output.txt", "Hello World") == None


# Generated at 2022-06-21 21:35:44.583743
# Unit test for function islurp
def test_islurp():
    assert list(islurp(__file__))[-1] == "test_islurp()\n"
    assert list(islurp(__file__, iter_by=4096))[-1].endswith("test_islurp()\n")
    assert list(islurp('-', allow_stdin=True))[-1] == "\n"



# Generated at 2022-06-21 21:35:49.304046
# Unit test for function burp
def test_burp():
    #Testing to ensure the contents of the file are the same
    burp("test_output.txt", "Test file output")
    assert("Test file output" == slurp("test_output.txt"))



# Generated at 2022-06-21 21:35:54.552994
# Unit test for function burp
def test_burp():
    """
    Test function burp.
    """
    burp('test_burp.txt', 'Testing burp...\n')
    # and now assert that it worked
    with open('test_burp.txt') as fh:
        assert fh.read() == 'Testing burp...\n'
    os.remove('test_burp.txt')



# Generated at 2022-06-21 21:36:03.290069
# Unit test for function islurp
def test_islurp():

    # test reading size
    assert sys.getsizeof(islurp('test_files/test_data/it_should_be_slurped')) == 224

    # test reading line mode
    assert list(islurp('test_files/test_data/test_islurp')) == ['This is a test.\n', 'It should be slurped.\n', '    ']

    # test reading by bytes
    assert list(islurp('test_files/test_data/islurp_test', 'r', iter_by=5)) == ['This ', 'is a ', 'test.\nIt ', 'shoul', 'd be ', 'slurp', 'ed.\n    ']

    # test reading standard in
    # foo = ['This is a test.\n', 'It should be slurped.\n

# Generated at 2022-06-21 21:36:08.508520
# Unit test for function burp
def test_burp():
    filename, contents = 'dt-test.txt', 'spam\neggs\n'
    try:
        burp(filename, contents)
        with open(filename) as fh:
            assert fh.read() == contents
    except IOError as e:
        raise AssertionError(e)
    finally:
        os.remove(filename)


# Generated at 2022-06-21 21:36:15.823809
# Unit test for function islurp
def test_islurp():
    from . import randutil  # TODO: change imports to relative
    import tempfile
    import shutil
    from .redirect import redirect_stdin

    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'test_slurp')
    random_file_contents = ''.join(randutil.choose(randutil.ALPHANUMERIC, length=12) for _ in xrange(1000))

    burp(tmpfile, random_file_contents)

    # Test
    with open(tmpfile, 'r') as fh:
        assert random_file_contents == fh.read()

    assert list(islurp(tmpfile)) == random_file_contents.splitlines()

# Generated at 2022-06-21 21:36:18.483008
# Unit test for function burp
def test_burp():
    s = 'test\n'
    burp('test_file_name.txt', s, mode='w')
    with open('test_file_name.txt', 'r') as f:
        assert f.read() == s
    os.remove('test_file_name.txt')


# Generated at 2022-06-21 21:36:22.773810
# Unit test for function burp
def test_burp():
    filename = 'burp.txt'
    if os.path.isfile(filename):
        os.remove(filename)
    burp(filename, 'hello world')
    assert os.path.isfile(filename)
    with open(filename, 'r') as f:
        ret = f.read()
    assert ret == 'hello world'
    os.remove(filename)


# Generated at 2022-06-21 21:36:34.664055
# Unit test for function islurp
def test_islurp():
    # Test parsing by line
    test_string = "1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n"
    if sys.version_info[0] < 3:
        import io
        fp = io.BytesIO(test_string)
    else:
        fp = io.StringIO(test_string)
    fp_next = fp.readline
    while True:
        buf = fp_next()
        if buf == '': #EOF
            break
        assert buf != '10\n'
        assert buf == test_string[test_string.find(buf):test_string.find(buf)+len(buf)]
    # Test parsing by size
    fp.seek(0)

# Generated at 2022-06-21 21:36:38.308122
# Unit test for function islurp
def test_islurp():
    """
    Test islurp by printing out its contents
    """

    for line in islurp('test_islurp_data.txt'):
        print(line)


# Generated at 2022-06-21 21:36:45.171825
# Unit test for function burp
def test_burp():
    # content and filename
    c = "This is a test\n"
    fn = "/tmp/test_burp"

    # write the content to the file
    burp(fn, c)

    # slurp the content from the file
    d = next(islurp(fn))

    # remove the file
    os.remove(fn)

    # check the slurped content against the original
    assert(d == c)


if __name__ == '__main__':
    test_burp()

# Generated at 2022-06-21 21:36:50.420829
# Unit test for function burp
def test_burp():
    from StringIO import StringIO
    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()

    burp('{0}/test_burp'.format(tmpdir), 'Test Text')
    assert os.path.isfile('{0}/test_burp'.format(tmpdir))

    test_data = StringIO('Test Text')
    burp('{0}/test_burp'.format(tmpdir), test_data.read())
    assert os.path.isfile('{0}/test_burp'.format(tmpdir))
    shutil.rmtree(tmpdir)


# Generated at 2022-06-21 21:36:55.110135
# Unit test for function islurp
def test_islurp():
    filename = 'test.txt'
    with open(filename, 'w') as txt:
        txt.write('lurp me')
        txt.close()
    assert 'urp me' == islurp(filename).next()
    os.remove(filename)


# Generated at 2022-06-21 21:36:59.518776
# Unit test for function islurp
def test_islurp():
    print("Testing function islurp")
    res = islurp('./testfiles/testislurpfile1.txt')
    for line in res:
        print(line)


# Generated at 2022-06-21 21:37:10.826183
# Unit test for function islurp
def test_islurp():
    lines = ['Line 1', 'Line 2', 'Line 3']
    fulltext = '\n'.join(lines)

    # test LINEMODE
    assert list(islurp('-', 'w+')) == []
    assert list(islurp('-', 'r')) == []

    with open('__testfile', 'w+') as fh:
        fh.write(fulltext)

    assert list(islurp('__testfile', 'r')) == lines

    # test chunking
    list(islurp('__testfile', 'rb', 8)) == ['Line 1', '\nLine 2\nL', 'ine 3\n']



# Generated at 2022-06-21 21:37:15.398339
# Unit test for function islurp
def test_islurp():
    import tempfile
    import contextlib
    with contextlib.closing(tempfile.NamedTemporaryFile(delete=False)) as fh:
        fh.write('a\nb\nc')
    slurped = list(slurp(fh.name))
    assert slurped == ['a\n', 'b\n', 'c']
    os.remove(fh.name)



# Generated at 2022-06-21 21:37:17.020943
# Unit test for function burp
def test_burp():
    burp("/tmp/temp_file.txt","Testing burp")


# Generated at 2022-06-21 21:37:22.439818
# Unit test for function burp
def test_burp():
    """
    Returns true if the file created is equal to the contents string
    """
    test_string = "Test\n"
    test_file = "./test_output.txt"
    burp(test_file, test_string)
    with open(test_file) as fh:
        read_test_string = fh.read()
    os.remove(test_file)
    assert(read_test_string == test_string)
    return True

# Generated at 2022-06-21 21:37:24.663370
# Unit test for function burp
def test_burp():
    burp('/tmp/foo', 'Hello')
    assert slurp('/tmp/foo').next() == 'Hello'
    os.remove('/tmp/foo')

# Generated at 2022-06-21 21:37:31.298156
# Unit test for function burp
def test_burp():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'tmpfile')
    expected = 'My first file\n'
    burp(tmpfile, expected)
    contents = slurp(tmpfile)
    assert contents == expected
    if os.path.exists(tmpdir):
        os.rmdir(tmpdir)
    if os.path.exists(tmpfile):
        os.unlink(tmpfile)


# Generated at 2022-06-21 21:37:38.447382
# Unit test for function burp
def test_burp():
    test_file = 'test_burp.txt'
    try:
        os.remove(test_file)
    except OSError:
        pass

    contents = 'some contents'
    burp(test_file, contents)
    assert open(test_file).read() == contents
    assert os.path.exists(test_file)

    os.remove(test_file)
    assert not os.path.exists(test_file)



# Generated at 2022-06-21 21:37:41.043822
# Unit test for function burp
def test_burp():
    filename = 'test.txt'
    content = 'burp'
    burp(filename, content)
    output = slurp(filename, 'r')
    assert next(output) == content


# Generated at 2022-06-21 21:37:48.209334
# Unit test for function burp
def test_burp():
    file_path = 'test_file.txt'
    contents = 'blah blah blah'
    burp(file_path, contents)
    s = slurp(file_path)
    first_line = s.next()
    assert first_line == contents, 'Expected contents{} != Actual contents{}'.format(contents, first_line)
    assert s.next() == ''



# Generated at 2022-06-21 21:37:53.227749
# Unit test for function burp
def test_burp():
    "burp"
    #noinspection PyUnresolvedReferences
    import fffile

    fffile.burp('test.txt', 'foo')
    assert 'foo' == fffile.slurp('test.txt')



# Generated at 2022-06-21 21:37:58.899016
# Unit test for function burp
def test_burp():
    burp('temp.txt', 'testing')
    assert "testing" in open('temp.txt').read()
    os.remove('temp.txt')
    assert "testing" not in open('temp.txt', 'r').read()



# Generated at 2022-06-21 21:38:10.338442
# Unit test for function islurp
def test_islurp():
    filename = 'testfile'
    contents = 'hello world\n'

    # islurp should return an object that can be iterated over
    # The object returned by islurp should yield the contents of the file line by line
    # when called with the default iter_by argument.
    slurp_contents = ''

    burp(filename, contents)

    for line in islurp(filename):
        slurp_contents += line

    assert slurp_contents == contents

    # When called with iter_by different than LINEMODE, islurp should return an object that
    # yields the contents of the file by that number of bytes at a time.
    burp(filename, contents)

    slurp_contents = ''
    for chunk in islurp(filename, iter_by=3):
        slurp

# Generated at 2022-06-21 21:38:15.971585
# Unit test for function burp
def test_burp():
    # Do a simple write test
    filename = os.path.splitext(__file__)[0] + '.tmp'
    contents = 'A\nB\nC\n'
    burp(filename, contents)

    # Do a stdout test
    contents = 'A\nB\nC\n'
    burp('-', contents)

    # Do a stdout test with bytes
    contents = b'A\nB\nC\n'
    burp('-', contents)

    # Now cleanup
    os.remove(filename)

# Generated at 2022-06-21 21:38:20.435505
# Unit test for function burp
def test_burp():
    burp('test_burp', 'test')
    assert(open('test_burp', 'r').read() == 'test')
    os.remove('test_burp')

# Unit tests for function islurp

# Generated at 2022-06-21 21:38:30.500714
# Unit test for function islurp
def test_islurp():
    test_file = open('test_file.txt', 'w')
    test_file.write('line 1\nline 2\nline 3\nline 4')
    test_file.close()

    assert [line.rstrip('\n') for line in islurp('test_file.txt')] == [
        'line 1', 'line 2', 'line 3', 'line 4'
    ]

    assert [line.rstrip('\n') for line in islurp('test_file.txt', iter_by=16)] == [
        'line 1\nline 2\nline 3\nline 4'
    ]


# Generated at 2022-06-21 21:38:36.077482
# Unit test for function burp
def test_burp():
    if os.path.exists('test_burp.txt'):
        os.remove('test_burp.txt')
    burp('test_burp.txt', 'Hello world!')
    assert open('test_burp.txt', 'r').read() == 'Hello world!'
    os.remove('test_burp.txt')


# Generated at 2022-06-21 21:38:39.901158
# Unit test for function burp
def test_burp():
    expected_contents = 'Hello'
    filename = '/tmp/test_burp'
    burp(filename, expected_contents)
    with open(filename) as fh:
        actual_contents = fh.read()
    assert actual_contents == expected_contents
    os.remove(filename)



# Generated at 2022-06-21 21:38:42.279102
# Unit test for function burp
def test_burp():
    contents = 'hello world\n'
    filename = '/tmp/foo.txt'

    burp(filename, contents)

    assert os.path.exists(filename)

    buf = slurp(filename)

    assert buf == contents



# Generated at 2022-06-21 21:38:48.729789
# Unit test for function burp
def test_burp():
    with open('test_burp.txt', 'w') as f:
        f.write('')
    burp('test_burp.txt', 'Hello world!')
    assert islurp('test_burp.txt', iter_by=LINEMODE) == ['Hello world!']
    os.remove('test_burp.txt')


# Generated at 2022-06-21 21:39:00.270706
# Unit test for function burp
def test_burp():
    fname = "test_file.txt"
    contents = "This is a test file for burp.\n"
    burp(fname, contents)
    with open(fname, 'r') as fh:
        assert fh.read() == contents


# Generated at 2022-06-21 21:39:04.297714
# Unit test for function islurp
def test_islurp():
    # Generated from file testdata/test_islurp.txt
    expected = [
        'Line 1\n', 'Line 2\n', 'Line 3\n'
    ]
    actual = list(islurp('testdata/test_islurp.txt'))

    assert expected == actual

# Generated at 2022-06-21 21:39:15.437042
# Unit test for function burp
def test_burp():
    # Test burp with '-' argument for stdout
    burp('-', 'Hello World\n', allow_stdout=True)

    # Test burp with '-' argument for stdout and bytes mode
    burp('-', b'Hello World\n', mode='wb', allow_stdout=True)

    # Test burp with temporary file
    import tempfile
    with tempfile.NamedTemporaryFile('w', delete=False) as fh:
        burp(fh.name, 'Hello World\n')
        # check if the contents of the file are as expected
        assert slurp(fh.name) == 'Hello World\n'

    # Test burp with temporary file and bytes mode

# Generated at 2022-06-21 21:39:26.038529
# Unit test for function burp
def test_burp():
    from tests.test_utils import unittest_file

    filename = "__file_utils_burp_test__"
    contents = b"foobar"
    burp(filename, contents, mode='wb')

    with open(filename, 'rb') as fh:
        assert fh.read() == contents

    os.unlink(filename)

    @unittest_file
    def test(filename):
        contents = b"foobar"
        burp(filename, contents, mode='wb')

        with open(filename, 'rb') as fh:
            assert fh.read() == contents

    # Unit test for function islurp

# Generated at 2022-06-21 21:39:36.878054
# Unit test for function islurp
def test_islurp():
    from pytest import raises
    with raises(TypeError):
        islurp(1)

    with raises(FileNotFoundError):
        islurp('__unreal__', allow_stdin=False)

    assert list(islurp('-', allow_stdin=False)) == []
    assert list(islurp('-', allow_stdin=False, iter_by=1)) == []
    assert list(islurp('-', allow_stdin=False, iter_by=10)) == []
    assert list(islurp('-', allow_stdin=False, iter_by=100)) == []


# Generated at 2022-06-21 21:39:43.916882
# Unit test for function burp
def test_burp():
    import tempfile
    tmpfile_name = next(tempfile._get_candidate_names())
    burp(tmpfile_name, "This is a test\n")
    lines = []
    for line in islurp(tmpfile_name, allow_stdout=False):
        lines.append(line)
    assert lines == ["This is a test\n"]
    os.remove(tmpfile_name)

# Generated at 2022-06-21 21:39:45.800006
# Unit test for function burp
def test_burp():
    assert isinstance(burp('foo.txt', 'hello world', 'w'),type(None))

# Generated at 2022-06-21 21:39:50.879726
# Unit test for function burp
def test_burp():
    """
    Test function burp.
    """
    import tempfile
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, "test.txt")

    content = "Hello world!\n"
    burp(tmp_file, content)
    slurped = slurp(tmp_file)

    assert content == slurped


# Generated at 2022-06-21 21:39:56.383446
# Unit test for function burp
def test_burp():
    filename = 'test_burp.txt'
    contents = 'test_burp'
    burp(filename, contents)
    try:
        with open(filename) as fh:
            c = fh.read()
        assert c == contents
    finally:
        os.unlink(filename)


# Generated at 2022-06-21 21:40:04.727409
# Unit test for function burp
def test_burp():
    import tempfile
    import shutil
    import os
    import imp

    #Set up temp dir
    TEMP_DIR = tempfile.gettempdir()
    temp_dir_path = os.path.join(TEMP_DIR, 'test_burp')
    if not os.path.exists(temp_dir_path):
        os.makedirs(temp_dir_path)

    #Get module
    module_path = imp.find_module('burp',['/home/nathan/Desktop/toolkit/python/toolkit/files'])[1]

    #Create file in temp dir
    file_path = os.path.join(temp_dir_path, 'text.txt')

    #Test burp, write to file and check contents
    burp(file_path, 'test')

# Generated at 2022-06-21 21:40:21.787710
# Unit test for function islurp
def test_islurp():
    print("\nRunning tests for islurp...")
    # Test islurp.py by reading in the file test_islurp.txt
    # and comparing it to the expected string "this is a test"
    with open("test_islurp.txt", 'r') as fh:
        test_string = ""
        for line in islurp("test_islurp.txt"):
            test_string += (line.strip() + " ")
        # Compare the two strings
        assert test_string == "this is a test"
    print("test_islurp passed")



# Generated at 2022-06-21 21:40:25.939592
# Unit test for function burp
def test_burp():
    # create a file called /tmp/file.txt
    burp('/tmp/file.txt', 'Hello World')
    # open it for reading
    with open('/tmp/file.txt', 'r') as f:
        # read the file
        contents = f.read().strip()
    # delete the file
    os.remove('/tmp/file.txt')
    # return the contents
    assert contents == 'Hello World'

# Generated at 2022-06-21 21:40:35.732684
# Unit test for function burp
def test_burp():
    # make a directory
    dirname = 'test_burp'
    try:
        os.mkdir(dirname)
        os.chdir(dirname)
        # create a file
        filename = 'burpme.txt'
        contents = 'burp me!'
        burp(filename, contents)
        # verify contents
        with open(filename) as fh:
            assert fh.read() == contents
        # cleanup
        os.chdir('..')
        os.remove(os.path.join(dirname, filename))
        os.rmdir(dirname)
    except:
        raise

# Generated at 2022-06-21 21:40:40.817888
# Unit test for function burp
def test_burp():
    # Test 1: write simple string to file
    assert burp('testfile1', 'test')
    with open('testfile1', 'r') as f:
        assert f.read() == 'test'

    # Test 2: write string to stdout if filename is '-'
    assert burp('-', 'test') == 18



# Generated at 2022-06-21 21:40:46.867928
# Unit test for function islurp
def test_islurp():
    # Create dummy file
    with open('tmp_file.txt', 'w') as out:
        out.write('123\nabc\n')
    # Create dummy list
    test_data = ['123', '\n', 'abc', '\n']
    # Test
    assert list(islurp('tmp_file.txt')) == test_data
    # Delete dummy file
    os.remove('tmp_file.txt')

# Run unit tests

# Generated at 2022-06-21 21:40:50.353340
# Unit test for function burp
def test_burp():
    import tempfile
    import random
    n = random.randint(1, 1024)
    contents = os.urandom(n)
    with tempfile.NamedTemporaryFile() as f:
        burp(f.name, contents)
        f.seek(0)
        assert f.read() == contents

# Generated at 2022-06-21 21:41:01.056715
# Unit test for function burp
def test_burp():
    import tempfile
    import os

    contents = "this is a test"

    with tempfile.TemporaryDirectory() as tmp:
        burp('test', contents, expanduser=False, expandvars=False)
        assert contents == open('test', 'r').read()
        assert os.path.isfile(tmp + '/test')

        burp('/test', contents, expanduser=False, expandvars=False)
        assert contents == open('/test', 'r').read()
        assert os.path.isfile('/test')

        burp(tmp + '/test', contents, expanduser=False, expandvars=False)
        assert contents == open(tmp + '/test', 'r').read()
        assert os.path.isfile(tmp + '/test')


# Generated at 2022-06-21 21:41:10.999415
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil

    d = tempfile.mkdtemp()
    try:
        with open(os.path.join(d, 'hello.txt'), 'w') as fh:
            fh.write('Hello world!')

        test_data = []
        for line in islurp(os.path.join(d, 'hello.txt')):
            test_data.append(line)
        assert test_data == ['Hello world!\n'], test_data

        test_data = ''.join(islurp(os.path.join(d, 'hello.txt'), iter_by=1024))
        assert test_data == 'Hello world!\n', test_data
    finally:
        shutil.rmtree(d)


# Generated at 2022-06-21 21:41:14.263632
# Unit test for function burp
def test_burp():
    """
    Unit test for function burp
    """
    contents = 'Hello World!'
    burp('test.txt', contents)
    assert 'Hello World!' == slurp('test.txt', iter_by=LINEMODE)
    os.remove('test.txt')


# Generated at 2022-06-21 21:41:20.431552
# Unit test for function islurp
def test_islurp():
    # Test reading from a file
    filename = 'test_file.txt'
    with open(filename, 'w') as f:
        f.write('Test file\n')
    lines = list(islurp(filename))
    assert lines == ['Test file\n']

    # Test reading from stdin
    lines = list(islurp('-', allow_stdin=True))
    assert lines == ['Test file\n']

    # Test reading from a text stream
    lines = list(islurp(f, allow_stdin=False))
    assert lines == ['Test file\n']

    # Test reading from a binary stream
    filename = 'test_file.bin'
    with open(filename, 'wb') as f:
        f.write(b'Test file\n')

# Generated at 2022-06-21 21:41:44.096291
# Unit test for function burp
def test_burp():
    filename = 'test_file_creation.txt'
    contents = 'This is a test file.'
    burp(filename, contents)
    with open(filename, mode='r') as fh:
        file_contents = fh.read()
    os.remove(filename)
    assert(file_contents == contents)

# Generated at 2022-06-21 21:41:50.648845
# Unit test for function burp
def test_burp():
    """
    Test burp
    """
    fh = open('testBurp.txt', "w")
    fh.write("Test")
    impt = burp('testBurp.txt', 'burp')
    fh.close()
    assert impt == None
    # Test contents
    fh = open('testBurp.txt', "r")
    assert fh.read() == 'burp'
    fh.close()
    # remove file
    os.remove('testBurp.txt')

# Generated at 2022-06-21 21:41:52.579372
# Unit test for function islurp
def test_islurp():
    contents = list(islurp('tests/test_utils.py'))
    assert len(contents) > 0



# Generated at 2022-06-21 21:42:00.014574
# Unit test for function islurp
def test_islurp():
    assert list(islurp('/etc/passwd', expanduser=False, allow_stdin=False)) == slurp('/etc/passwd', expanduser=False, allow_stdin=False)
    assert list(islurp('/etc/passwd', expanduser=False)) == slurp('/etc/passwd', expanduser=False)
    assert list(islurp(os.path.expanduser('~/'), expanduser=False)) == slurp(os.path.expanduser('~/'), expanduser=False)


# Generated at 2022-06-21 21:42:06.582870
# Unit test for function burp
def test_burp():

    def _burp(filename, contents, msg, **kwargs):
        burp(filename, contents, **kwargs)
        assert contents == slurp(filename).next(), msg

    _burp("./test.txt", "1", "Should create a new file and write contents")
    _burp("./test.txt", "2", "Should overwrite the previous file and write contents")
    burp("./test.txt", "3", mode="a")
    assert "23" == slurp("./test.txt").next(), "Should append the previous file and write contents"
    os.remove("./test.txt")



# Generated at 2022-06-21 21:42:09.195432
# Unit test for function burp
def test_burp():
    """
    Test function burp
    """
    # Test writing to stdout
    filename = '-'
    contents = 'Test writing to stdout'
    burp(filename, contents)

    # Test writing to a non-existent file
    filename = 'test_burp.txt'
    contents = 'Test writing to a non-existent file'
    burp(filename, contents)

    # Test writing to an existing file
    contents = 'Test writing to an existing file'
    burp(filename, contents)
    os.unlink(filename)


# Generated at 2022-06-21 21:42:19.415689
# Unit test for function islurp
def test_islurp():
    # Test slurping from a file
    filename = "test_islurp.txt"
    x = "asdfasdf\n1234\n"
    with open(filename, "w") as fh:
        fh.write(x)
    for line in islurp(filename):
        assert line == x, "islurp failed to slurp from file"

    # Test slurping from stdin
    x = "asdfasdf\n1234\n"
    sys.stdin = open(filename, "r")
    for line in islurp(filename, allow_stdin=True):
        assert line == x, "islurp failed to slurp from stdin"

    # Test slurping by line
    x = "asdfasdf\n1234\n"

# Generated at 2022-06-21 21:42:24.124334
# Unit test for function islurp
def test_islurp():
    """
    Test function islurp
    """
    lines = list(islurp('../../LICENSE'))
    assert len(lines) == 24
    assert lines[0].startswith('Copyright (c) 2017, Zlati Varszegi (zlativarszegi@gmail.com)')
    assert lines[-1].startswith('SPDX-License-Identifier: Apache-2.0')



# Generated at 2022-06-21 21:42:29.641186
# Unit test for function islurp
def test_islurp():
    assert list(islurp(__file__))[0].startswith('"""')
    assert list(islurp(__file__, iter_by=1))[0].startswith('"""')
    assert list(islurp(__file__, iter_by=1))[0].startswith('"""')

if __name__ == '__main__':
    sys.exit(test_islurp())

# Generated at 2022-06-21 21:42:31.169279
# Unit test for function islurp
def test_islurp():
    assert "this\n" in islurp("test_files/islurp.txt")

