

# Generated at 2022-06-21 21:33:44.719689
# Unit test for function islurp
def test_islurp():
    filename = 'data/quotes.json'
    for line in islurp(filename):
        # just print out each line. we don't mind the exceptions raised.
        print(line)



# Generated at 2022-06-21 21:33:47.646754
# Unit test for function burp
def test_burp():
    filename = "test_burp.txt"
    contents = "Hello, World!\n"

    burp(filename, contents)

    f = open(filename, "r")
    test = f.read()
    f.close()
    assert(test == contents)


# Generated at 2022-06-21 21:33:51.922107
# Unit test for function burp
def test_burp():
    burp('test.txt', 'Who let the dogs out?')
    assert(slurp('test.txt').next() == 'Who let the dogs out?')
    os.remove('test.txt')

# alias
spit = burp

# Generated at 2022-06-21 21:34:01.338516
# Unit test for function islurp

# Generated at 2022-06-21 21:34:04.519204
# Unit test for function burp
def test_burp():
    fname = 'xxx'
    linetext = '\n'.join(['hello', 'world'])
    burp(fname, linetext)
    assert open(fname).read() == linetext
    os.unlink(fname)

# convenience
burp.LINEMODE = LINEMODE

# Generated at 2022-06-21 21:34:11.236029
# Unit test for function burp
def test_burp():
    from cStringIO import StringIO
    import tempfile

    # We don't need a real file
    th = tempfile.NamedTemporaryFile()

    # This is the data that should be written to the file
    data = 'hello world'

    # Write data to the file
    burp(th.name, data)

    # Get file content
    f = StringIO()
    with open(th.name, 'r') as fh:
        for line in fh:
            f.write(line)

    # Make sure that the content of the file is the same as data
    assert f.getvalue() == data

    th.close()


# Generated at 2022-06-21 21:34:16.120590
# Unit test for function burp
def test_burp():
    """
        Test for function burp with random content 'foobar'
    """
    from StringIO import StringIO
    import sys

    capturedOutput = StringIO()
    sys.stdout = capturedOutput
    burp(filename='-', contents='foobar')
    assert capturedOutput.getvalue() == 'foobar'
    sys.stdout = sys.__stdout__



# Generated at 2022-06-21 21:34:21.854887
# Unit test for function islurp
def test_islurp():
    test_str = "Apple\nOrange\nMelon"
    slurp_result = ''.join(islurp('-', iter_by=LINEMODE, allow_stdin=True, expanduser=True, expandvars=True))
    assert slurp_result == test_str

# Generated at 2022-06-21 21:34:27.559355
# Unit test for function burp
def test_burp():
    test_file = '.test_burp_file'
    try:
        burp(test_file, "test string")
        if not "test string" in slurp(test_file):
            print("Unable to write to file {}".format(test_file))
            return False
    except:
        print("Unable to write to file {}".format(test_file))
        return False
    finally:
        os.remove(test_file)
    return True


# Generated at 2022-06-21 21:34:35.067597
# Unit test for function burp
def test_burp():
    burp('test.txt', 'abc')
    assert 'abc' == open('test.txt', 'r').read()

    burp('test2.txt', 'abc')
    assert 'abc' == open('test2.txt', 'r').read()

    burp('test3.txt', 'abc')
    assert 'abc' == open('test3.txt', 'r').read()


"""
Unit tests.
"""
if __name__ == "__main__":
    test_burp()

# Generated at 2022-06-21 21:34:41.850452
# Unit test for function islurp
def test_islurp():
    lines = list(islurp(__file__, 'rU'))
    assert len(lines) > 0
    assert lines[0].rstrip() == '#!/usr/bin/env python'


# Generated at 2022-06-21 21:34:43.744501
# Unit test for function burp
def test_burp():
    f = '~/burp_test_file'
    burp(f, 'foo')
    assert 'foo' == slurp(f).next()

# Generated at 2022-06-21 21:34:53.025247
# Unit test for function islurp
def test_islurp():
    filename = "test.txt"
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as fh:
        fh.write("one\ntwo\nthree\n")
        fh.close()
        filename = fh.name
    for i, line in enumerate(islurp(filename=filename)):
        assert line == '%s\n' % ['one', 'two', 'three'][i]
    os.remove(filename)

# Generated at 2022-06-21 21:34:55.281878
# Unit test for function islurp
def test_islurp():
    t = islurp('tmp_file_for_islurp')
    assert(t is None)


# Generated at 2022-06-21 21:35:00.409993
# Unit test for function burp
def test_burp():
    import tempfile
    tempFile = tempfile.mkstemp()
    burp(tempFile[1],'This is a test string.')
    res = slurp(tempFile[1]).next()
    assert res == 'This is a test string.', 'Expected This is a test string. Got %s' % res
    os.remove(tempFile[1])

# Generated at 2022-06-21 21:35:10.903433
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, 'islurp.txt')


# Generated at 2022-06-21 21:35:21.585726
# Unit test for function burp
def test_burp():
    burp("test.file", "hello world", allow_stdout=False)

    file_contents = ""
    for line in slurp("test.file", allow_stdin=False):
        file_contents += line

    assert file_contents == "hello world"

if __name__ == '__main__':
    import sys
    import optparse

    usage = 'Usage: %prog [options] [--] [FILENAME(s)]'
    parser = optparse.OptionParser(usage=usage)

    parser.add_option('-s', '--slurp', dest='slurp', action='store_true',
                      help='Print contents of files to stdout (default). '
                           'If `-` is given, read from stdin.')

# Generated at 2022-06-21 21:35:33.998036
# Unit test for function islurp
def test_islurp():
    from mock import patch, mock_open
    from os.path import join
    from sys import version_info

    import nose.tools
    from nose.tools import assert_equal, assert_is
    from nose.tools import assert_true, assert_false

    testing_data = join(
        os.path.dirname(os.path.realpath(__file__)),
        'test_islurp.txt'
    )

    # prepare the mocker
    open_mock = mock_open(read_data='line1\nline2\nline3\n')

    if version_info[0] <= 2:  # python 2
        open_mock.return_value.__iter__ = lambda self: self
        open_mock.return_value.next = lambda self: self.readline()

# Generated at 2022-06-21 21:35:40.812141
# Unit test for function burp
def test_burp():
    import io
    import os
    import tempfile
    import unittest

    class TestStreamWrapper(io.RawIOBase):
        def __init__(self, test_obj, must_raise=False):
            self.test_obj = test_obj
            self.must_raise = must_raise

        def read(self, size=-1):
            return self.test_obj.fail()

        def readinto(self, b):
            return self.test_obj.fail()

        def write(self, b):
            if self.must_raise:
                self.test_obj.fail()
            return len(b)

    class TestCase(unittest.TestCase):
        def setUp(self):
            self._orig_stdin = sys.stdin
            self._orig_stdout = sys.stdout


# Generated at 2022-06-21 21:35:48.587510
# Unit test for function islurp
def test_islurp():
    """
    A test function for function islurp
    """
    # Test for iterating by 1 byte
    count = 0
    for _ in islurp(__file__, iter_by=1):
        count += 1
    print('Test for iterating by 1 byte: ' + str(count))

    # Test for iterating by 1 line
    count = 0
    for _ in islurp(__file__, iter_by=LINEMODE):
        count += 1
    print('Test for iterating by 1 line: ' + str(count))

    # Test for iterating by 1024 bytes
    count = 0
    for _ in islurp(__file__, iter_by=1024):
        count += 1
    print('Test for iterating by 1024 bytes: ' + str(count))

    # Test for iterating

# Generated at 2022-06-21 21:35:57.251758
# Unit test for function burp
def test_burp():
    burp("/tmp/test_burp.txt","This is a test")


# Generated at 2022-06-21 21:36:03.503239
# Unit test for function burp
def test_burp():
    burp('./test-burp.txt', 'test-burp message')

    contents = list(islurp('./test-burp.txt'))
    assert(len(contents) == 1)
    assert(contents[0] == 'test-burp message\n')

    os.remove('./test-burp.txt')



# Generated at 2022-06-21 21:36:04.537410
# Unit test for function burp
def test_burp():
    burp('/tmp/obvious.txt', "Test String\n")

# Generated at 2022-06-21 21:36:08.094388
# Unit test for function islurp
def test_islurp():
    lines = []
    for line in islurp('../test/test_islurp.txt'):
        lines.append(line)
    assert lines == islurp('../test/test_islurp.txt').readlines()

# Generated at 2022-06-21 21:36:11.992702
# Unit test for function burp
def test_burp():
    filename = "test_file.txt"
    with open(filename, 'w') as fh:
        pass
    with open(filename, 'w') as fh:
        contents = 'This is a test file!\n'
        fh.write(contents)
    burp(filename, contents)


# Generated at 2022-06-21 21:36:17.932141
# Unit test for function islurp
def test_islurp():
    file = islurp('test_data/slurp', iter_by=LINEMODE)
    res = [line for line in file]
    assert res[0] == 'slurp,\n'
    assert res[1] == 'sink,\n'
    assert res[2] == 'sleep tight.\n'
    assert res[3] == '\n'



# Generated at 2022-06-21 21:36:25.548481
# Unit test for function islurp
def test_islurp():
    fpath = '../test_data/test_file.txt'
    # Reader can be used as a context manager
    with islurp(fpath) as f:
        for line in f:
            assert line == 'This is a test line of text.\n'

    # You can also just slurp through a for loop
    for line in islurp(fpath):
        assert line == 'This is a test line of text.\n'


# Generated at 2022-06-21 21:36:36.866356
# Unit test for function islurp
def test_islurp():
    test_fh = islurp(os.path.join(os.path.dirname(__file__), 'test', 'fileutils.py'))
    assert test_fh.next().startswith('"""')
    assert test_fh.next().startswith('Utilities to work with files.')
    assert test_fh.next().startswith('import')

    test_fh = islurp(os.path.join(os.path.dirname(__file__), 'test', 'fileutils_non_existant.py'))
    assert test_fh.next().startswith('"""')

    test_fh = islurp('-', allow_stdin=True)
    assert test_fh.next().startswith('"""')

    test_fh = islur

# Generated at 2022-06-21 21:36:46.871891
# Unit test for function burp
def test_burp():
    """
    Test function burp
    """
    # Test 1: Write to file
    try:
        burp('test_burp.txt', 'This is a test')
        # Open the file, read and check that the first line has the right text
        with open('test_burp.txt') as f:
            text = f.readline()
        assert(text=='This is a test')
    finally:
        # Delete the file
        os.remove('test_burp.txt')

    # Test 2: Write to stdout
    # Capture stdout
    old_stdout = sys.stdout
    from cStringIO import StringIO
    sys.stdout = mystdout = StringIO()

# Generated at 2022-06-21 21:36:51.690735
# Unit test for function burp
def test_burp():
    import tempfile
    tf = tempfile.NamedTemporaryFile(delete=False)
    tf.close()
    burp(tf.name, "1")
    with open(tf.name) as fh:
        assert fh.read() == "1"

# Unit tests for functions slurp and islurp

# Generated at 2022-06-21 21:36:58.889088
# Unit test for function burp
def test_burp():
    print("Unit test for burp")
    burp("test_burp", "test_burp")
    with open("test_burp") as f:
        contents = f.read()
        assert (contents == "test_burp")
    os.remove("test_burp")



# Generated at 2022-06-21 21:37:11.516898
# Unit test for function islurp
def test_islurp():
    # Test 1: slurp/burp of a simple file
    filename = "./testfile.txt"
    burp(filename, 'pizza\n')
    ll = islurp(filename, 'r')
    assert next(ll) == 'pizza\n'

    # Test 2: slurp/burp with LINEMODE
    filename = "./testfile.txt"
    burp(filename, 'pizza\n')
    ll = islurp(filename, 'r', iter_by=islurp.LINEMODE)
    assert next(ll) == 'pizza\n'

    # Test 3: slurp/burp with binary mode
    filename = "./testfile.bin"
    burp(filename, b'pizza\n')

# Generated at 2022-06-21 21:37:14.932059
# Unit test for function burp
def test_burp():
    fname = 'tmp.txt'
    burp(fname, 'hello world!\n'*5)
    try:
        assert all(x == 'hello world!\n' for x in islurp(fname, iter_by = 'LINEMODE'))
    finally:
        os.remove(fname)


# Generated at 2022-06-21 21:37:24.750191
# Unit test for function burp
def test_burp():
    import io
    import os
    import sys
    import subprocess

    # Create a temporary file to store data written by burp
    temp_filename = 'scratch.tmp.txt'
    if sys.platform == 'win32':
        # Handle the case of Windows not allowing ':' in file names
        root_dir = os.path.expanduser('~')
        temp_filename = os.path.join(root_dir, 'scratch.tmp.txt')
    with open(temp_filename, 'w') as temp_file:
        temp_file.write('Before burp writes to me.\n')
    assert os.path.exists(temp_filename)

    # Burp some data into the temporary file
    burp(temp_filename, 'This is the data written by burp.\n')

    # Check that burp

# Generated at 2022-06-21 21:37:29.809133
# Unit test for function islurp
def test_islurp():
    """
    Test function `islurp`
    """
    filename = os.path.join(os.path.dirname(__file__), 'test_islurp.txt')
    result = islurp(filename)
    assert result is not None, "islurp failed"
    assert "foo" in result, "islurp failed, result=%r" % result

# Generated at 2022-06-21 21:37:40.446433
# Unit test for function islurp
def test_islurp():
    import io
    import tempfile

    # test slurp() with filehandle
    with tempfile.TemporaryFile('w+t') as fh:
        fh.write('line1\nline2')
        fh.seek(0)
        assert fh.readline() == 'line1\n'
        assert fh.readline() == 'line2'

    # test slurp() with filename
    fh = io.BytesIO()
    fh.name = 'filename'
    assert fh.name == 'filename'

    # test islurp
    def test_fh(iter_by=None):
        fh = io.BytesIO()
        fh.name = 'filename'
        fh.write('line1\nline2')
        fh.seek(0)


# Generated at 2022-06-21 21:37:45.055766
# Unit test for function islurp
def test_islurp():
    # Note: this will fail if run automatically.
    # To test:
    print(list(islurp('../test.txt')))


if __name__ == "__main__":
    test_islurp()

# Generated at 2022-06-21 21:37:54.778626
# Unit test for function islurp
def test_islurp():
    # Test reading lines
    expected = 'Hello\nWorld\n'
    contents = [line for line in islurp('test.txt', iter_by=LINEMODE)]
    assert ''.join(contents) == expected

    # Test reading bytes
    expected = '636f6e74656e7473\n'
    contents = [line for line in islurp('test.txt', mode='rb', iter_by=2)]
    assert ''.join(contents) == expected

    # Test expanduser
    expected = 'Hello\nWorld\n'
    contents = [line for line in islurp('./test.txt', expanduser=True)]
    assert  ''.join(contents) == expected

    # Test expanding env vars
    expected = 'Hello\nWorld\n'

# Generated at 2022-06-21 21:37:59.915207
# Unit test for function burp
def test_burp():
    burp('test_burp.txt','test_burp')
    assert open('test_burp.txt').read() == 'test_burp'

if __name__ == '__main__':
    test_burp()

# Generated at 2022-06-21 21:38:02.992928
# Unit test for function islurp
def test_islurp():
    data = '\n'.join(islurp('/proc/self/status'))
    assert 'VmPeak' in data

if __name__ == '__main__':
    test_islurp()

# Generated at 2022-06-21 21:39:19.190107
# Unit test for function burp
def test_burp():
    assert burp(filename='test.txt',contents='Test Write to File') == None


# Generated at 2022-06-21 21:39:23.903197
# Unit test for function burp
def test_burp():
    filename = "test_file.txt"
    contents = "This is a file\n"
    burp(filename, contents)
    assert contents == slurp(filename)[0]


# Generated at 2022-06-21 21:39:32.027017
# Unit test for function islurp
def test_islurp():
    from os import path

    # default mode is r (read text)
    with open('test_islurp', 'wb') as fh:
        fh.write(b"line1\nline2")

    assert list(islurp('test_islurp')) == ["line1\n", "line2"]
    assert list(islurp('test_islurp', 'rb')) == [b"line1\n", b"line2"]

    # iter_by (chunk mode)
    assert list(islurp('test_islurp', iter_by=3)) == [b"lin", b"e1\n", b"lin", b"e2"]

    # allow_stdin
    assert list(islurp('-', allow_stdin=True)) == []

    # expanduser

# Generated at 2022-06-21 21:39:34.994266
# Unit test for function islurp
def test_islurp():
    for i, line in enumerate(islurp(__file__)):
        if i == 30:
            break
    assert i == 30


if __name__ == '__main__':
    # Unit test for function islurp
    test_islurp()

# Generated at 2022-06-21 21:39:44.201159
# Unit test for function islurp
def test_islurp():
    from nose.tools import ok_, assert_equal
    # test both modes and see if they return the same thing
    lines = list(islurp(__file__))
    lines2 = list(islurp(__file__, iter_by=islurp.LINEMODE))
    assert_equal(lines, lines2)
    # test it doesn't work for directories
    ok_(not islurp('/tmp'))
    # test it works with stdin
    ok_(not islurp('-'))
    # line mode is default
    ok_(islurp.LINEMODE == 0)


# Generated at 2022-06-21 21:39:47.723049
# Unit test for function islurp
def test_islurp():
    assert '\n'.join(islurp(__file__, mode='rb', expanduser=False, expandvars=False, allow_stdin=False)) == open(__file__, 'rb').read()

# Generated at 2022-06-21 21:39:50.845639
# Unit test for function burp
def test_burp():
    burp('test-out.txt', 'this is the file contents')
    assert os.path.exists('test-out.txt')
    assert 'file contents' in islurp('test-out.txt')
    os.remove('test-out.txt')



# Generated at 2022-06-21 21:39:57.129821
# Unit test for function islurp
def test_islurp():
    for i, buf in enumerate(islurp('files.py', 'rb', LINEMODE + 1)):
        assert isinstance(buf, bytes)
        assert len(buf) == LINEMODE + 1
        if i > 10:
            break


if __name__ == "__main__":
    # Test the utility functions
    test_islurp()

# Generated at 2022-06-21 21:40:05.021416
# Unit test for function islurp
def test_islurp():
    # test for correct output for reading a file
    input_islurp = list(islurp('test.txt'))
    assert 'firstline\n' in input_islurp
    assert 'secondline\n' in input_islurp
    assert 'thirdline\n' in input_islurp

    # test for correct output for reading from stdin
    input_islurp = list(islurp('-', allow_stdin=True))
    assert 'firstline\n' in input_islurp
    assert 'secondline\n' in input_islurp
    assert 'thirdline\n' in input_islurp

    # test for correct output for reading a file with variable expansion - expandvars=True
    os.environ['FILE'] = 'test.txt'

# Generated at 2022-06-21 21:40:08.778713
# Unit test for function islurp
def test_islurp():
    for result in islurp("test_data/test_islurp.txt"):
        print(result)


# Generated at 2022-06-21 21:40:43.797642
# Unit test for function burp
def test_burp():
    burp('./test_burp.txt','this is a test for burp')
    file = open('./test_burp.txt')
    assert file.read() == 'this is a test for burp'
    file.close()
    os.remove('./test_burp.txt')


# Generated at 2022-06-21 21:40:49.718001
# Unit test for function islurp
def test_islurp():
    lines = list(islurp('/etc/passwd'))
    assert lines[0].startswith('root:x:0:0')
    assert lines[1].startswith('daemon:x:1:1')
    assert lines[2].startswith('bin:x:2:2')
    assert lines[3].startswith('sys:x:3:3')
    assert lines[4].startswith('sync:x:4:65534')



# Generated at 2022-06-21 21:40:56.136025
# Unit test for function burp
def test_burp():
    source_dir = os.path.dirname(os.path.realpath(__file__))
    content = "test\n"
    filename = 'temp.txt'
    burp(filename, content)
    assert ('test\n') == slurp(filename).next()

    with open(filename, 'r') as myfile:
        data = myfile.read()
        assert ('test\n') == data

    os.remove(os.path.join(source_dir, filename))

# Generated at 2022-06-21 21:41:01.965875
# Unit test for function burp
def test_burp():
    burp('/tmp/file.txt', 'this is a test')
    assert open('/tmp/file.txt').readline() == 'this is a test'
    burp('/tmp/file2.txt', 'this is a\nmultiline\ntest')
    assert open('/tmp/file2.txt').readline() == 'this is a\n'

if __name__ == "__main__":
    test_burp()

# Generated at 2022-06-21 21:41:05.308199
# Unit test for function burp
def test_burp():
    burp("test_burp.txt", "Hello, World!", "w")
    assert open("test_burp.txt", "r").read() == "Hello, World!"
    os.remove("test_burp.txt")


# Generated at 2022-06-21 21:41:09.909288
# Unit test for function burp
def test_burp():
    if os.path.exists('./temp.txt'):
        os.remove('./temp.txt')
    burp('./temp.txt', 'foobar')
    assert open('./temp.txt', 'r').read() == 'foobar'
    os.remove('./temp.txt')


# Generated at 2022-06-21 21:41:15.892231
# Unit test for function islurp
def test_islurp():
    filename = os.path.abspath('islurp_test.txt')
    with open(filename, 'w') as fh:
        contents = "A\nB\nC\nD"
        fh.write(contents)
    slurped = []
    for line in islurp(filename):
        slurped.append(line)
    os.remove(filename)

    assert slurped == ['A\n', 'B\n', 'C\n', 'D']



# Generated at 2022-06-21 21:41:17.664211
# Unit test for function burp
def test_burp():
    burp("file", b"Hello")
    from os import remove
    remove("file")


# Generated at 2022-06-21 21:41:20.587533
# Unit test for function burp
def test_burp():
    burp("test.txt", "contents")
    assert open("test.txt", "r").read() == "contents"
    os.remove("test.txt")



# Generated at 2022-06-21 21:41:26.690229
# Unit test for function burp
def test_burp():
    # Write to stdout
    burp('-', 'foo')
    # Write to file
    burp('/tmp/foo', 'bar')
    assert open('/tmp/foo').read() == 'bar'
    # Write to file with env vars
    burp('/tmp/$foo', 'bar', expandvars=True)
    assert open('/tmp/bar').read() == 'bar'


if __name__ == '__main__':
    test_burp()

# Generated at 2022-06-21 21:41:36.112719
# Unit test for function burp
def test_burp():
    import tempfile
    (fd, fname) = tempfile.mkstemp() # fd is file descriptor and fname is filename
    try:
        burp(fname, "Hello\n")
        assert islurp(fname).next() == "Hello\n"
    finally:
        os.remove(fname)

if __name__ == '__main__':
    test_burp()

# Generated at 2022-06-21 21:41:41.686241
# Unit test for function burp
def test_burp():
    f = 'foo.txt'
    s = 'apple'
    burp(f, s)
    assert os.access(f, os.R_OK) == True
    with open(f, 'r') as fh:
        assert fh.read() == s
    os.remove(f)
    assert os.access(f, os.R_OK) == False

# Generated at 2022-06-21 21:41:48.437629
# Unit test for function islurp
def test_islurp():
    data_string = """Some content
with
3
lines"""
    with open('foo.txt', 'w') as fh:
        fh.write(data_string)

    for line in islurp('foo.txt', allow_stdin=False):
        assert(line == line)
        assert(line in data_string)

    for line in slurp('foo.txt', allow_stdin=False):
        assert(line == line)
        assert(line in data_string)



# Generated at 2022-06-21 21:41:58.034737
# Unit test for function islurp
def test_islurp():
    #
    # test with LINEMODE=0 and default allow_stdin=True
    #
    slurped = list(islurp('-', iter_by=0, allow_stdin=True))
    assert slurped == ['This is a test file.\n', 'This is the second line.\n']
    #
    # test with LINEMODE=0 and allow_stdin=False
    #
    slurped = list(islurp('-', iter_by=0, allow_stdin=False))
    assert slurped == []
    #
    # test with LINEMODE=1 and default allow_stdin=True
    #
    slurped = list(islurp('-', iter_by=1, allow_stdin=True))

# Generated at 2022-06-21 21:42:07.041777
# Unit test for function burp
def test_burp():
    """
    Test function burp
    """
    import tempfile
    # Test write to file
    (fd, filename) = tempfile.mkstemp()
    burp(filename, 'Test writing to file\n')
    file_contents = ''
    for line in slurp(filename):
        file_contents = file_contents + line
    assert file_contents == 'Test writing to file\n'
    # Test write to stdout
    import io
    import sys
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput
    burp('-', 'Test writing to stdout\n')
    sys.stdout = sys.__stdout__
    assert capturedOutput.getvalue() == 'Test writing to stdout\n'
    # Clean up
    os.close(fd)
    os

# Generated at 2022-06-21 21:42:13.261050
# Unit test for function burp
def test_burp():
    """
    Test burp function
    """
    filename = 'test_burp_file'
    contents = "test"
    burp(filename, contents)
    with open(filename, 'r') as burp_fh:
        rl = burp_fh.readline()
    assert(rl == contents)
    os.remove(filename)


# Generated at 2022-06-21 21:42:19.677066
# Unit test for function islurp
def test_islurp():
    # Test 1
    filename = 'testfile'
    contents = 'line 1\nline 2\nline 3\n'
    burp(filename, contents)
    assert ''.join(islurp(filename)) == contents
    os.remove(filename)

    # Test 2
    contents = 'line 1\nline 2\nline 3\n'
    assert ''.join(islurp('-', allow_stdin=True)) == contents


if __name__ == '__main__':
    test_islurp()

# Generated at 2022-06-21 21:42:26.048221
# Unit test for function burp
def test_burp():
    import tempfile, os, os.path
    tf = tempfile.mktemp()
    try:
        burp(tf, "Test")
        assert os.path.exists(tf), "File not created"
        assert os.path.getsize(tf) > 0, "File not written to"
        assert open(tf, 'r').read() == 'Test', "File contents are not correct"
    finally:
        if os.path.exists(tf):
            os.unlink(tf)

if __name__ == '__main__':
    test_burp()

# Generated at 2022-06-21 21:42:27.754276
# Unit test for function islurp
def test_islurp():
    assert list(islurp(__file__)) == open(__file__).readlines()



# Generated at 2022-06-21 21:42:31.856020
# Unit test for function burp
def test_burp():
    filename = "test_burp.txt"
    contents = "Hello world!"
    burp(filename, contents)
    with open(filename, "r") as file:
        data = file.read()
        assert data == contents  # check the contents are equal
    os.remove(filename)  # cleanup

