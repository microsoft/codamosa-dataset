

# Generated at 2022-06-21 21:33:57.774136
# Unit test for function islurp

# Generated at 2022-06-21 21:34:01.695183
# Unit test for function burp
def test_burp():
    file_name = 'test.txt'
    contents = 'Hello World'
    burp(file_name, contents)
    assert open(file_name, 'r').read() == 'Hello World'
    os.remove(file_name)


# Generated at 2022-06-21 21:34:04.767528
# Unit test for function burp
def test_burp():
    burp("/home/hongjian/Downloads/some-file.txt", "hello world")

if __name__ == '__main__':
    test_burp()

# Generated at 2022-06-21 21:34:12.877039
# Unit test for function islurp
def test_islurp():
    """
    Test function islurp.
    """
    # Test LINEMODE works
    test_string = 'Hello\nWorld\n'
    test_fh = islurp(filename=None, mode='r', iter_by=LINEMODE)
    test_fh.send(test_string)
    assert 'Hello' == test_fh.next()
    assert 'World' == test_fh.next()
    try:
        test_fh.next()
    except StopIteration:
        pass
    else:
        assert False, "Expected StopIteration after reading all lines"

    # Test binary works
    test_string = 'Hello\nWorld\n'
    test_fh = islurp(filename=None, mode='rb')

# Generated at 2022-06-21 21:34:23.932568
# Unit test for function islurp
def test_islurp():
    # Test 1: standard file
    with open('file.txt', 'w') as fp:
        fp.write('Hello World!')
    assert list(islurp('file.txt')) == ['Hello World!']
    assert list(islurp('file.txt', mode='rb')) == ['Hello World!']
    assert list(islurp('file.txt', mode='rb', iter_by=1)) == ['Hello World!']
    os.remove('file.txt')

    # Test 2: from stdin
    try:
        input = raw_input
    except NameError:
        pass
    with open('temp', 'w') as fp:
        fp.write('Hello World!')
    os.system('cat temp')

# Generated at 2022-06-21 21:34:29.214490
# Unit test for function islurp
def test_islurp():
    """
    >>> data = os.linesep.join(['a', 'b', 'c'])
    >>> islurp('-', data, islurp.LINEMODE)
    >>> islurp('-', data, 1)
    >>> islurp('-', data, 3)
    """
    pass


# Generated at 2022-06-21 21:34:33.775418
# Unit test for function burp
def test_burp():
    burp('foo.txt', 'Hello, world!')
    with open('foo.txt', 'r') as f:
        assert f.read() == 'Hello, world!'
    os.remove('foo.txt')


# Generated at 2022-06-21 21:34:44.989797
# Unit test for function islurp
def test_islurp():
    import tempfile

    txt = "abc\ndef\n"


# Generated at 2022-06-21 21:34:50.518160
# Unit test for function burp
def test_burp():
    for filename in ('/tmp/test.txt', '/tmp/test.csv', '/tmp/test.json'):
        file_contents = "{} contents".format(filename)
        burp(filename, file_contents)
        assert open(filename).read() == file_contents


# Generated at 2022-06-21 21:34:54.190564
# Unit test for function burp
def test_burp():
    burp("test_burp.txt","TEST")
    assert(slurp("test_burp.txt")[0]=="TEST\n")
    os.remove("test_burp.txt")


# Generated at 2022-06-21 21:37:31.305572
# Unit test for function burp
def test_burp():
    """
    test function burp.
    """
    assert burp("filename", "content")


# Generated at 2022-06-21 21:37:39.190507
# Unit test for function islurp
def test_islurp():
    filename = "test.txt"
    contents = "Hello, world!\n"
    expected = [str(contents)]
    
    burp(filename, contents)
    result = list(islurp(filename))
    assert result == expected
    
    contents = "Hello, world!\nAgain!"
    expected = ["Hello, world!\n", "Again!"]
    
    burp(filename, contents)
    result = list(islurp(filename, iter_by=9))
    assert result == expected


# Generated at 2022-06-21 21:37:43.340204
# Unit test for function islurp
def test_islurp():
    """
    Test islurp
    """

# Generated at 2022-06-21 21:37:47.416660
# Unit test for function burp
def test_burp():
    burp('test_burp.txt', 'Content', 'w')
    assert 'Content' == slurp('test_burp.txt').next()
    os.remove('test_burp.txt')


# Generated at 2022-06-21 21:37:56.106069
# Unit test for function islurp
def test_islurp():
    import tempfile
    import os

    # Temporary file definition
    fp = tempfile.NamedTemporaryFile()
    fp.write("This is line 1.\nThis is line 2.\n")
    fp.flush()

    # Testing the function islurp
    slurp = islurp(fp.name, allow_stdin=False)

    slurplines = list(islurp(fp.name, allow_stdin=False, iter_by=LINEMODE))
    assert len(slurplines) == 2
    assert slurplines[0] == "This is line 1.\n"
    assert slurplines[1] == "This is line 2.\n"

    slurpchunks = list(islurp(fp.name, allow_stdin=False, iter_by=11))

# Generated at 2022-06-21 21:38:00.985651
# Unit test for function burp
def test_burp():
    filename = r'C:\temp\hello.txt'
    contents = 'Hello World'
    burp(filename, contents)
    r_contents = slurp(filename)
    assert contents == r_contents


# Generated at 2022-06-21 21:38:03.234445
# Unit test for function burp
def test_burp():
    assert burp('bla.txt', 'lorem ipsum') == None

# Alias
spit = burp



# Generated at 2022-06-21 21:38:06.817540
# Unit test for function islurp
def test_islurp():
    for filename in ['../README.md', '-', '~/tmp', '$HOME/tmp']:
        print(filename)
        for line in islurp(filename):
            print(line.strip())
        print()


# Generated at 2022-06-21 21:38:16.309675
# Unit test for function islurp

# Generated at 2022-06-21 21:38:25.898441
# Unit test for function burp
def test_burp():
    print("Test case 1", end=' ')
    s = "Hello\n"
    burp("test_burp.txt", s)
    with open("test_burp.txt", "r") as f:
        t = f.read()
    assert t == s
    print("passed")

    print("Test case 2", end=' ')
    s = "Hello\n"
    burp("~/test_burp.txt", s)
    with open("~/test_burp.txt", "r") as f:
        t = f.read()
    assert t == s
    print("passed")


# Generated at 2022-06-21 21:38:51.189744
# Unit test for function burp
def test_burp():
    filename1 = './testfile_burp_1.txt'
    content1 = 'Hello world!'
    filemode = 'w'
    burp(filename1, content1, filemode)
    with open(filename1, 'r') as fh:
        assert(fh.read() == content1)
    os.remove(filename1)

    filename2 = './testfile_burp_2.txt'
    content2 = 'Hello world!'
    filemode = 'wb'
    burp(filename2, content2, filemode)
    with open(filename2, 'rb') as fh:
        assert(fh.read() == content2)
    os.remove(filename2)

if __name__ == '__main__':
    test_burp()

# Generated at 2022-06-21 21:38:58.941366
# Unit test for function burp
def test_burp():
    import tempfile

    filename = tempfile.mktemp()
    try:
        burp(filename, 'foo')
        assert islurp(filename).next() == 'foo'
    finally:
        os.unlink(filename)

    try:
        burp(filename, 'foo')
        assert islurp(filename).next() == 'foo'
    finally:
        os.unlink(filename)

test_burp()


# Generated at 2022-06-21 21:39:01.896085
# Unit test for function burp
def test_burp():
    assert burp('test_burp.txt', 'test') is None
    with open('test_burp.txt') as f:
        line = f.readline()
        assert line == 'test'



# Generated at 2022-06-21 21:39:09.232413
# Unit test for function burp
def test_burp():
    # write a file
    burp('test.txt', 'Hello World\n', mode='w')

    # read a file
    assert slurp('test.txt')[0] == 'Hello World\n'

    # write a file
    burp('test.txt', 'Goodbye World\n', mode='w')

    # read a file
    assert slurp('test.txt')[0] == 'Goodbye World\n'


if __name__ == '__main__':
    test_burp()

# Generated at 2022-06-21 21:39:18.968062
# Unit test for function islurp
def test_islurp():

    # Test reading file & iterating by line.
    contents = []
    for line in islurp('islurp.py'):
        contents.append(line)

    assert len(contents) == 17  # 16 lines + newline (\n) on the last line
    assert contents[0].startswith('#!/usr/bin/env python')
    assert contents[1].startswith('"""')
    assert contents[-1].startswith('    return fh')
    assert contents[-1].endswith('\n')
    assert contents[-2].endswith('\n')

    # Test reading file & iterating by chunk.
    contents = []
    for chunk in islurp('islurp.py', iter_by=100):
        contents.append(chunk)


# Generated at 2022-06-21 21:39:29.392387
# Unit test for function islurp
def test_islurp():
    """
    Unit test for function islurp
    """
    # initialize
    i = 0
    # print (globals())
    # enable stdin redirection
    saved_stdin = sys.stdin
    saved_stdout = sys.stdout
    sys.stdin = open("test_file")
    sys.stdout = open("test_islurp.out", "w")
    # print (dir(sys.stdin))
    # line iterate
    for line in islurp("test_file"):
        # print (line)
        print (line, end='')
        i += 1
    # print (i)
    # dump of file contents
    print (islurp("test_file").read())
    # Test for LINEMODE
    # print (islurp.LINEMODE

# Generated at 2022-06-21 21:39:39.954145
# Unit test for function islurp
def test_islurp():
    # Create a test file
    file_path = './test_file.txt'
    with open(file_path, 'w') as f:
        f.write('Line1\nLine2\nLine3\n')

    # Default mode is read line by line
    assert list(islurp(file_path)) == ['Line1\n', 'Line2\n', 'Line3\n']

    # Change mode to read by chunk of size 8 bytes
    assert list(islurp(file_path, mode='r', iter_by=8)) == ['Line1\nLin', 'e2\nLine', '3\n']

    # Create a test file
    file_path = './test_file.txt'

# Generated at 2022-06-21 21:39:45.245888
# Unit test for function islurp
def test_islurp():
    filename = 'test_file.txt'
    contents = '\n'.join('line' + str(n) for n in range(10))
    expected = contents

    # Create test file
    burp(filename, contents)
    assert islurp(filename) == expected
    # Clean up
    os.remove(filename)



# Generated at 2022-06-21 21:39:49.453643
# Unit test for function burp
def test_burp():
    burp("input.txt","input\n")
    fh = open("input.txt", "r")
    s = fh.read()
    fh.close()
    assert(s=="input\n")
    os.remove("input.txt")

test_burp()

# Generated at 2022-06-21 21:39:53.185841
# Unit test for function burp
def test_burp():
    test_filename = os.path.abspath('test_burp.txt')
    test_contents_1 = "Test burp function."
    test_contents_2 = "Test burp function 2."
    # Test 1
    burp(test_filename, test_contents_1)
    for line in islurp(test_filename):
        assert line == test_contents_1+os.linesep

    # Test 2
    burp(test_filename, test_contents_2)
    for line in islurp(test_filename):
        assert line == test_contents_2+os.linesep

    # Test 3
    burp(test_filename, test_contents_1)
    for line in islurp(test_filename):
        assert line == test_contents_1

# Generated at 2022-06-21 21:40:39.085004
# Unit test for function islurp
def test_islurp():
    # FIXME: This is an invalid test
    assert [line for line in islurp('/proc/sys/kernel/ostype')] == [line for line in open('/proc/sys/kernel/ostype')]



# Generated at 2022-06-21 21:40:49.075556
# Unit test for function islurp
def test_islurp():
    os.system('touch /tmp/testfile')

# Generated at 2022-06-21 21:40:55.734913
# Unit test for function burp
def test_burp():
    import tempfile

    tempfile.tempdir = "."
    tmp = tempfile.NamedTemporaryFile(delete=False)
    tmp.write('SOME data\n')
    tmp.close()
    burp(tmp.name, 'This is a test', 'a')
    output = open(tmp.name, 'r').read()
    assert output == 'SOME data\nThis is a test'
    os.remove(tmp.name)


# Generated at 2022-06-21 21:41:03.192896
# Unit test for function islurp
def test_islurp():
    import os
    import tempfile

    tmp = tempfile.NamedTemporaryFile(delete=False)
    try:
        contents = ['line 1', 'line 2', 'line 3', 'line 4']
        tmp.writelines(m+os.linesep for m in contents)
        tmp.close()

        assert list(islurp(tmp.name)) == contents
        assert list(islurp(tmp.name, iter_by=1)) == contents
        assert list(islurp(tmp.name, iter_by=2)) == contents
    finally:
        os.remove(tmp.name)


# Generated at 2022-06-21 21:41:13.662810
# Unit test for function islurp
def test_islurp():
    import six

    ret = [line.rstrip() for line in islurp('/dev/null')]
    assert ret == []

    is_cm = six.PY2
    if is_cm:
        ret = [line.rstrip() for line in islurp('/dev/urandom', iter_by=16)]
        assert len(ret) == 2  # two chunks of size 16

        ret = [line.rstrip() for line in islurp('/dev/urandom', iter_by=16, mode='rb')]
        assert len(ret) == 2  # two chunks of size 16
    else:
        ret = [line.rstrip() for line in islurp('/dev/urandom', iter_by=16)]
        assert len(ret) == 2  # two chunks of size 16



# Generated at 2022-06-21 21:41:24.933251
# Unit test for function islurp
def test_islurp():
    # Read a simple text file
    out = slurp('simple.txt')
    assert list(out) == ['This is a simple test text file\n',
                         'with two lines, plain and simple.\n']

    # Read a simple text file using 'rb'
    out = slurp('simple.txt', mode='rb')
    assert list(out) == ['This is a simple test text file\n',
                         'with two lines, plain and simple.\n']

    # Read a file using LINEMODE
    out = slurp('simple.txt', iter_by=LINEMODE)
    assert list(out) == ['This is a simple test text file\n',
                         'with two lines, plain and simple.\n']

    # Read a file with a tilde in the path

# Generated at 2022-06-21 21:41:35.208112
# Unit test for function islurp
def test_islurp():
    """
    test islurp
    """
    assert list(islurp('-', 'r', allow_stdin=True)) == ['this is a test\n']
    assert list(islurp('-', 'r', allow_stdin=True, iter_by=2)) == ['th', 'is', ' ', 'is', ' ', 'a ', 'te', 'st', '\n']
    import tempfile
    tf = tempfile.NamedTemporaryFile(delete=False)
    tf.write('this is a test\n')
    tf.close()
    assert list(islurp(tf.name, 'r')) == ['this is a test\n']

# Generated at 2022-06-21 21:41:37.518506
# Unit test for function islurp
def test_islurp():
    file = islurp('../tests/fixtures/chars.txt')
    for line in file:
        print(line)


# Generated at 2022-06-21 21:41:40.956676
# Unit test for function islurp
def test_islurp():
    contents = islurp('test_islurp.txt')
    for line in contents:
        print(line)

if __name__ == "__main__":
    test_islurp()

# Generated at 2022-06-21 21:41:49.055429
# Unit test for function islurp
def test_islurp():
    print("Testing function islurp.")
    wd = os.path.dirname(os.path.realpath(__file__))
    filename = os.path.join(wd, 'test_files', 'little_words.txt')
    print("Testing file %s" % filename)
    with open(filename, 'r') as fh:
        expected = [word.strip() for word in fh]
    print("Expected %s" % expected)
    results = [word.strip() for word in islurp(filename, iter_by=LINEMODE)]
    print("Results %s" % results)
    assert expected == results

# Generated at 2022-06-21 21:43:08.995948
# Unit test for function islurp
def test_islurp():
    # Test without any parameters
    print("Useless function - no parameters")
    print(islurp())
    print("Testing text")
    for i in islurp('test/test1.txt'):
        print(i)
    print("Testing by 4, text file")
    for i in islurp('test/test1.txt', iter_by=4):
        print(i)
    print("Testing by 4, binary file")
    for i in islurp('test/test.jpg.txt', iter_by=4, mode='rb'):
        print(i)
    print("Testing that it does not expand vars")
    for i in islurp('$TEST1', iter_by=4, expandvars=False):
        print(i)

# Generated at 2022-06-21 21:43:19.655423
# Unit test for function islurp
def test_islurp():
    import os
    import shutil
    import tempfile
    import doctest
    import logging
    import contextlib
    import io
    import sys

    @contextlib.contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old

    logging.disable(logging.CRITICAL)
    td = tempfile.mkdtemp()
    contents = list()

    file_name = os.path.join(td, "testfile")
    # Describe the file to be created
    contents.append(u'\n')
    contents.append(u'Hello World\n')
    contents.append(u'Foo bar\n')

# Generated at 2022-06-21 21:43:23.481043
# Unit test for function islurp
def test_islurp():
    f = open('test_islurp.txt','w')
    f.write('This is a test file')
    f.close()
    i = islurp('test_islurp.txt')
    res = next(i)
    assert res == "This is a test file"


# Generated at 2022-06-21 21:43:25.795581
# Unit test for function islurp
def test_islurp():
    assert [l.strip() for l in islurp('dummy_input.txt')] == ['foo', 'bar', 'baz', 'qux']


# Generated at 2022-06-21 21:43:29.365650
# Unit test for function islurp
def test_islurp():
    assert list(islurp(__file__))[0].startswith('"""')
    assert list(islurp('-', allow_stdin=True))[0].startswith('"""')
    assert list(islurp('-', allow_stdin=False))[0].startswith('"""')


# Generated at 2022-06-21 21:43:33.703941
# Unit test for function burp
def test_burp():
    burp('burp.txt', 'this is a test\n')
    assert 'this is a test\n' == slurp('burp.txt')


# Generated at 2022-06-21 21:43:38.243337
# Unit test for function burp
def test_burp():
    burp('test.txt', 'Hello World')
    assert os.path.exists('test.txt')
    assert open('test.txt').read() == 'Hello World'
    os.remove('test.txt')

test_burp()


# Generated at 2022-06-21 21:43:41.888535
# Unit test for function islurp
def test_islurp():
    output = []
    for line in islurp("test.txt", mode="r"):
        output.append(line)
    
    assert(output == ["a\n", "b\n", "c"])


# Generated at 2022-06-21 21:43:45.989031
# Unit test for function burp
def test_burp():
    import os
    import sys
    import tempfile
    import filecmp

    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    contents = u'Hello\nworld'
    fd, tmp_filename = tempfile.mkstemp()
    burp(tmp_filename, contents)

    with open(tmp_filename, 'r') as fh:
        assert fh.read() == contents

    fh = StringIO()
    burp(fh, contents)
    assert fh.getvalue() == contents

    os.remove(tmp_filename)