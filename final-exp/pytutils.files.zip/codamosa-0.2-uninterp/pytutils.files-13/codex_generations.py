

# Generated at 2022-06-18 04:03:35.252186
# Unit test for function islurp
def test_islurp():
    import tempfile
    import os

    def _test_islurp(filename, mode, iter_by, allow_stdin, expanduser, expandvars):
        with tempfile.NamedTemporaryFile(mode='w') as fh:
            fh.write('line1\nline2\nline3\n')
            fh.flush()
            lines = list(islurp(filename, mode, iter_by, allow_stdin, expanduser, expandvars))
            assert lines == ['line1\n', 'line2\n', 'line3\n']

    _test_islurp(__file__, 'r', LINEMODE, False, False, False)
    _test_islurp(__file__, 'r', LINEMODE, False, True, False)

# Generated at 2022-06-18 04:03:41.817301
# Unit test for function burp
def test_burp():
    import tempfile
    import os

    # Create a temporary file
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    # Write to the file
    burp(fname, 'Hello World!')

    # Read the file
    with open(fname, 'r') as fh:
        assert fh.read() == 'Hello World!'

    # Clean up
    os.remove(fname)



# Generated at 2022-06-18 04:03:52.867624
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 04:04:03.705330
# Unit test for function islurp
def test_islurp():
    assert list(islurp('/etc/passwd')) == list(islurp('/etc/passwd'))
    assert list(islurp('/etc/passwd', iter_by=1024)) == list(islurp('/etc/passwd', iter_by=1024))
    assert list(islurp('/etc/passwd', iter_by=1024)) != list(islurp('/etc/passwd'))
    assert list(islurp('/etc/passwd', iter_by=1024)) != list(islurp('/etc/passwd', iter_by=512))
    assert list(islurp('/etc/passwd', iter_by=1024)) != list(islurp('/etc/passwd', iter_by=2048))

# Generated at 2022-06-18 04:04:14.664985
# Unit test for function islurp
def test_islurp():
    """
    Test function islurp
    """
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    fh = os.fdopen(fd, 'w')
    fh.write("Hello World\n")
    fh.write("Goodbye World\n")
    fh.close()

    # Test islurp
    for line in islurp(fname):
        print(line)

    # Clean up
    shutil.rmtree(tmpdir)

if __name__ == '__main__':
    test_islurp()

# Generated at 2022-06-18 04:04:21.564933
# Unit test for function islurp
def test_islurp():
    import tempfile
    import os

    # Test reading from stdin
    with tempfile.TemporaryFile() as fh:
        fh.write(b'hello world\n')
        fh.seek(0)
        sys.stdin = fh
        assert list(islurp('-')) == ['hello world\n']
        sys.stdin = sys.__stdin__

    # Test reading from file
    with tempfile.NamedTemporaryFile() as fh:
        fh.write(b'hello world\n')
        fh.seek(0)
        assert list(islurp(fh.name)) == ['hello world\n']

    # Test reading from file with no newline
    with tempfile.NamedTemporaryFile() as fh:
        fh.write(b'hello world')

# Generated at 2022-06-18 04:04:31.744889
# Unit test for function islurp
def test_islurp():
    # Test for LINEMODE
    assert list(islurp('test_files/test_islurp.txt')) == ['This is a test file\n', 'This is the second line\n', 'This is the third line\n']
    # Test for chunk mode
    assert list(islurp('test_files/test_islurp.txt', iter_by=5)) == ['This ', 'is a ', 'test ', 'file\n', 'This ', 'is th', 'e seco', 'nd lin', 'e\n', 'This ', 'is th', 'e thir', 'd line', '\n']
    # Test for stdin

# Generated at 2022-06-18 04:04:40.469691
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fname = os.path.join(tmpdir, 'test.txt')
    with open(fname, 'w') as f:
        f.write('Hello World!')

    # Test islurp
    for line in islurp(fname):
        assert line == 'Hello World!\n'

    # Clean up
    shutil.rmtree(tmpdir)



# Generated at 2022-06-18 04:04:50.222602
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    import os


# Generated at 2022-06-18 04:05:01.589148
# Unit test for function islurp
def test_islurp():
    assert list(islurp(__file__)) == list(open(__file__))
    assert list(islurp(__file__, iter_by=1024)) == list(open(__file__))
    assert list(islurp('-')) == list(sys.stdin)
    assert list(islurp('-', allow_stdin=False)) == []
    assert list(islurp('~/')) == list(islurp(os.path.expanduser('~/')))
    assert list(islurp('$HOME/')) == list(islurp(os.path.expandvars('$HOME/')))
    assert list(islurp('$HOME/', expandvars=False)) == list(islurp('$HOME/'))

# Generated at 2022-06-18 04:05:08.042189
# Unit test for function burp
def test_burp():
    burp('test_burp.txt', 'This is a test')
    assert islurp('test_burp.txt') == ['This is a test']
    os.remove('test_burp.txt')


# Generated at 2022-06-18 04:05:13.043855
# Unit test for function burp
def test_burp():
    burp('test_burp.txt', 'test')
    assert os.path.exists('test_burp.txt')
    assert os.path.isfile('test_burp.txt')
    assert os.path.getsize('test_burp.txt') == 4
    os.remove('test_burp.txt')


# Generated at 2022-06-18 04:05:22.360995
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        # Test with a file
        fname = os.path.join(tmpdir, 'test_islurp.txt')
        with open(fname, 'w') as fh:
            fh.write('line1\nline2\nline3\n')
        lines = [line for line in islurp(fname)]
        assert lines == ['line1\n', 'line2\n', 'line3\n']

        # Test with stdin
        lines = [line for line in islurp('-')]
        assert lines == ['line1\n', 'line2\n', 'line3\n']
    finally:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-18 04:05:32.014927
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    import os

    # test for LINEMODE
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 04:05:43.587740
# Unit test for function islurp
def test_islurp():
    assert list(islurp('/dev/null')) == []
    assert list(islurp('/dev/null', iter_by=1)) == []
    assert list(islurp('/dev/null', iter_by=2)) == []
    assert list(islurp('/dev/null', iter_by=3)) == []
    assert list(islurp('/dev/null', iter_by=4)) == []
    assert list(islurp('/dev/null', iter_by=5)) == []
    assert list(islurp('/dev/null', iter_by=6)) == []
    assert list(islurp('/dev/null', iter_by=7)) == []
    assert list(islurp('/dev/null', iter_by=8)) == []

# Generated at 2022-06-18 04:05:46.992148
# Unit test for function burp
def test_burp():
    burp('test.txt', 'test')
    assert slurp('test.txt') == 'test'
    os.remove('test.txt')


# Generated at 2022-06-18 04:05:58.316930
# Unit test for function burp
def test_burp():
    import tempfile
    import os
    import shutil
    import filecmp

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    print("Created temporary directory: %s" % tmpdir)

    # Create a file
    filepath = os.path.join(tmpdir, "test_burp.txt")
    print("Created file: %s" % filepath)

    # Write to the file
    burp(filepath, "Hello World!")

    # Check that the file was created
    assert os.path.exists(filepath)

    # Check that the file contains the correct contents
    assert filecmp.cmp(filepath, "test_burp.txt")

    # Remove the directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 04:06:06.341041
# Unit test for function islurp
def test_islurp():
    """
    Test function islurp
    """
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test_islurp.txt"), "w")
    f.write("Hello World\n")
    f.close()

    # Test function islurp
    for line in islurp(os.path.join(tmpdir, "test_islurp.txt")):
        assert line == "Hello World\n"

    # Remove the directory after the test
    shutil.rmtree(tmpdir)



# Generated at 2022-06-18 04:06:17.531465
# Unit test for function islurp
def test_islurp():
    assert list(islurp('/dev/null')) == []
    assert list(islurp('/dev/null', iter_by=1)) == []
    assert list(islurp('/dev/null', iter_by=2)) == []
    assert list(islurp('/dev/null', iter_by=3)) == []
    assert list(islurp('/dev/null', iter_by=4)) == []
    assert list(islurp('/dev/null', iter_by=5)) == []
    assert list(islurp('/dev/null', iter_by=6)) == []
    assert list(islurp('/dev/null', iter_by=7)) == []
    assert list(islurp('/dev/null', iter_by=8)) == []

# Generated at 2022-06-18 04:06:27.848121
# Unit test for function burp
def test_burp():
    import tempfile
    import os
    import shutil
    import sys
    import io

    # Test writing to file
    tmpdir = tempfile.mkdtemp()
    try:
        fname = os.path.join(tmpdir, 'test.txt')
        burp(fname, 'Hello World!')
        with open(fname, 'r') as fh:
            assert fh.read() == 'Hello World!'
    finally:
        shutil.rmtree(tmpdir)

    # Test writing to stdout
    old_stdout = sys.stdout
    try:
        sys.stdout = io.StringIO()
        burp('-', 'Hello World!')
        assert sys.stdout.getvalue() == 'Hello World!'
    finally:
        sys.stdout = old_stdout



# Generated at 2022-06-18 04:06:40.380615
# Unit test for function islurp
def test_islurp():
    assert list(islurp('/etc/passwd'))[0].startswith('root:')
    assert list(islurp('/etc/passwd', iter_by=1024))[0].startswith('root:')
    assert list(islurp('/etc/passwd', iter_by=1024))[0].startswith('root:')
    assert list(islurp('/etc/passwd', iter_by=1024))[0].startswith('root:')
    assert list(islurp('/etc/passwd', iter_by=1024))[0].startswith('root:')
    assert list(islurp('/etc/passwd', iter_by=1024))[0].startswith('root:')

# Generated at 2022-06-18 04:06:50.990262
# Unit test for function islurp
def test_islurp():
    """
    Test function islurp
    """
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create the test file
    test_file = os.path.join(tmpdir, "test_file")
    with open(test_file, "w") as fh:
        fh.write("This is a test file\n")
        fh.write("This is a test file\n")
        fh.write("This is a test file\n")

    # test the function
    for line in islurp(test_file):
        assert line == "This is a test file\n"

    # test the function

# Generated at 2022-06-18 04:06:56.057401
# Unit test for function islurp
def test_islurp():
    """
    Test function islurp
    """
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('This is a test file\n')
    f.close()

    # Test islurp
    for line in islurp(os.path.join(tmpdir, 'test.txt')):
        assert line == 'This is a test file\n'

    # Remove the directory after the test
    shutil.rmtree(tmpdir)


# Generated at 2022-06-18 04:07:02.541833
# Unit test for function islurp
def test_islurp():
    """
    Test function islurp
    """
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, fname = tempfile.mkstemp(dir=tmpdir)

    # Write some data to the file
    os.write(fd, b"Hello World\n")
    os.write(fd, b"Hello World\n")
    os.write(fd, b"Hello World\n")
    os.write(fd, b"Hello World\n")
    os.write(fd, b"Hello World\n")
    os.write(fd, b"Hello World\n")
    os.write(fd, b"Hello World\n")

# Generated at 2022-06-18 04:07:10.836391
# Unit test for function burp
def test_burp():
    import tempfile
    import os
    import shutil
    import sys
    import io
    import contextlib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    fname = os.path.join(tmpdir, 'test.txt')
    # Write to the file
    burp(fname, "Hello World")
    # Check if the file exists
    assert os.path.exists(fname)
    # Check if the file is not empty
    assert os.path.getsize(fname) > 0
    # Read the file
    with open(fname, 'r') as f:
        assert f.read() == "Hello World"
    # Remove the directory after the test
    shutil.rmtree(tmpdir)

    # Test writing to std

# Generated at 2022-06-18 04:07:21.193060
# Unit test for function islurp
def test_islurp():
    """
    Test function islurp
    """
    import tempfile
    import os
    import shutil
    import sys

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a file
    filename = os.path.join(tmpdir, 'testfile')
    with open(filename, 'w') as fh:
        fh.write('line1\nline2\nline3\n')

    # test islurp
    lines = list(islurp(filename))
    assert lines == ['line1\n', 'line2\n', 'line3\n']

    # test islurp with LINEMODE
    lines = list(islurp(filename, iter_by=islurp.LINEMODE))

# Generated at 2022-06-18 04:07:32.112515
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 04:07:38.040333
# Unit test for function islurp
def test_islurp():
    # Test with a file
    filename = 'test_islurp.txt'
    with open(filename, 'w') as fh:
        fh.write('Hello World!\n')
    assert list(islurp(filename)) == ['Hello World!\n']
    os.remove(filename)

    # Test with stdin
    assert list(islurp('-', allow_stdin=True)) == ['Hello World!\n']


# Generated at 2022-06-18 04:07:45.092243
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    import os

    # Test reading from stdin
    with tempfile.NamedTemporaryFile() as fh:
        fh.write(b'hello world')
        fh.flush()
        old_stdin = sys.stdin
        sys.stdin = open(fh.name)
        assert list(islurp('-')) == ['hello world']
        sys.stdin = old_stdin

    # Test reading from file
    with tempfile.NamedTemporaryFile() as fh:
        fh.write(b'hello world')
        fh.flush()
        assert list(islurp(fh.name)) == ['hello world']

    # Test reading from file with ~

# Generated at 2022-06-18 04:07:54.395567
# Unit test for function islurp
def test_islurp():
    # Test for LINEMODE
    assert list(islurp('test.txt')) == ['This is a test file.\n', 'This is the second line.\n', 'This is the third line.\n']

    # Test for binary mode
    assert list(islurp('test.txt', 'rb', 1)) == ['This is a test file.\nThis is the second line.\nThis is the third line.\n']

    # Test for stdin
    assert list(islurp('-', 'rb', 1)) == ['This is a test file.\nThis is the second line.\nThis is the third line.\n']

    # Test for expanduser

# Generated at 2022-06-18 04:08:45.379987
# Unit test for function islurp
def test_islurp():
    # Test with a file that exists
    filename = 'test.txt'
    with open(filename, 'w') as fh:
        fh.write('hello world')
    assert list(islurp(filename)) == ['hello world']
    os.remove(filename)

    # Test with a file that does not exist
    filename = 'test.txt'
    try:
        list(islurp(filename))
    except IOError:
        pass
    else:
        assert False, 'Expected IOError'

    # Test with a file that exists, but is empty
    filename = 'test.txt'
    with open(filename, 'w') as fh:
        fh.write('')
    assert list(islurp(filename)) == ['']
    os.remove(filename)

    # Test with a file that

# Generated at 2022-06-18 04:08:56.559600
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 04:09:01.094413
# Unit test for function islurp
def test_islurp():
    import tempfile
    import os

    # Test islurp with LINEMODE
    with tempfile.NamedTemporaryFile(mode='w+') as fh:
        fh.write('line1\nline2\nline3\n')
        fh.flush()
        fh.seek(0)
        lines = [line for line in islurp(fh.name)]
        assert lines == ['line1\n', 'line2\n', 'line3\n']

    # Test islurp with chunk mode
    with tempfile.NamedTemporaryFile(mode='w+') as fh:
        fh.write('line1\nline2\nline3\n')
        fh.flush()
        fh.seek(0)

# Generated at 2022-06-18 04:09:04.265417
# Unit test for function burp
def test_burp():
    burp('test_burp.txt', 'This is a test')
    assert islurp('test_burp.txt') == ['This is a test']
    os.remove('test_burp.txt')


# Generated at 2022-06-18 04:09:14.232531
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 04:09:24.248984
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 04:09:28.253995
# Unit test for function burp
def test_burp():
    burp('test_burp.txt', 'hello world')
    assert 'hello world' == slurp('test_burp.txt').next()
    os.remove('test_burp.txt')


# Generated at 2022-06-18 04:09:35.230401
# Unit test for function burp
def test_burp():
    import tempfile
    import os
    import shutil
    import sys
    import io
    import contextlib
    import random
    import string
    import subprocess
    import time
    import sys
    import os
    import shutil
    import tempfile
    import io
    import contextlib
    import random
    import string
    import subprocess
    import time
    import sys
    import os
    import shutil
    import tempfile
    import io
    import contextlib
    import random
    import string
    import subprocess
    import time
    import sys
    import os
    import shutil
    import tempfile
    import io
    import contextlib
    import random
    import string
    import subprocess
    import time
    import sys
    import os
    import shutil
    import tempfile
    import io
   

# Generated at 2022-06-18 04:09:42.294062
# Unit test for function islurp
def test_islurp():
    import tempfile
    import os
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('Hello World!')
    f.close()

    # Test islurp
    assert list(islurp(os.path.join(tmpdir, 'test.txt'))) == ['Hello World!']

    # Remove the directory after the test
    shutil.rmtree(tmpdir)


# Generated at 2022-06-18 04:09:52.137501
# Unit test for function islurp
def test_islurp():
    # Test for islurp
    # Test for islurp with LINEMODE
    assert list(islurp('test_islurp.py', iter_by=islurp.LINEMODE)) == list(islurp('test_islurp.py'))
    # Test for islurp with iter_by=1

# Generated at 2022-06-18 04:10:28.775293
# Unit test for function islurp
def test_islurp():
    # Test with a file
    f = open('test_islurp.txt', 'w')
    f.write('This is a test\n')
    f.write('This is a test\n')
    f.write('This is a test\n')
    f.close()

    # Test with a file
    f = open('test_islurp.txt', 'r')
    for line in f:
        assert line == 'This is a test\n'
    f.close()

    # Test with islurp
    for line in islurp('test_islurp.txt'):
        assert line == 'This is a test\n'

    # Test with islurp

# Generated at 2022-06-18 04:10:39.637774
# Unit test for function islurp
def test_islurp():
    assert list(islurp('/etc/passwd')) == list(islurp('/etc/passwd', iter_by=LINEMODE))
    assert list(islurp('/etc/passwd', iter_by=LINEMODE)) == list(islurp('/etc/passwd', iter_by='LINEMODE'))
    assert list(islurp('/etc/passwd', iter_by=LINEMODE)) == list(islurp('/etc/passwd', iter_by=LINEMODE))
    assert list(islurp('/etc/passwd', iter_by=LINEMODE)) == list(islurp('/etc/passwd', iter_by=LINEMODE))

# Generated at 2022-06-18 04:10:49.885681
# Unit test for function burp
def test_burp():
    import tempfile
    import shutil
    import os
    import os.path
    import sys

    tmpdir = tempfile.mkdtemp()
    try:
        test_file = os.path.join(tmpdir, 'test_file.txt')
        test_contents = 'test contents'
        burp(test_file, test_contents)
        with open(test_file, 'r') as fh:
            assert fh.read() == test_contents
        burp('-', test_contents)
        assert sys.stdout.getvalue() == test_contents
    finally:
        shutil.rmtree(tmpdir)


# Generated at 2022-06-18 04:11:00.790350
# Unit test for function islurp
def test_islurp():
    """
    Test function islurp
    """
    assert list(islurp('/etc/passwd', iter_by=LINEMODE)) == list(islurp('/etc/passwd', iter_by=LINEMODE, allow_stdin=False))
    assert list(islurp('/etc/passwd', iter_by=LINEMODE)) == list(islurp('/etc/passwd', iter_by=LINEMODE, expanduser=False))
    assert list(islurp('/etc/passwd', iter_by=LINEMODE)) == list(islurp('/etc/passwd', iter_by=LINEMODE, expandvars=False))

# Generated at 2022-06-18 04:11:11.344732
# Unit test for function burp
def test_burp():
    import tempfile
    import shutil
    import os
    import sys

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 04:11:20.722373
# Unit test for function burp
def test_burp():
    import tempfile
    import os
    import shutil
    import sys
    import io

    # Test file creation
    with tempfile.TemporaryDirectory() as tmpdir:
        burp(os.path.join(tmpdir, 'test.txt'), 'Test')
        assert os.path.exists(os.path.join(tmpdir, 'test.txt'))

    # Test file creation with expanduser
    with tempfile.TemporaryDirectory() as tmpdir:
        burp(os.path.join(tmpdir, 'test.txt'), 'Test', expanduser=True)
        assert os.path.exists(os.path.join(tmpdir, 'test.txt'))

    # Test file creation with expandvars

# Generated at 2022-06-18 04:11:31.113152
# Unit test for function islurp
def test_islurp():
    assert list(islurp('/etc/passwd')) == list(islurp('/etc/passwd', iter_by=islurp.LINEMODE))
    assert list(islurp('/etc/passwd', iter_by=islurp.LINEMODE)) == list(islurp('/etc/passwd', iter_by=islurp.LINEMODE, allow_stdin=False))
    assert list(islurp('/etc/passwd', iter_by=islurp.LINEMODE, allow_stdin=False)) == list(islurp('/etc/passwd', iter_by=islurp.LINEMODE, allow_stdin=False, expanduser=False))

# Generated at 2022-06-18 04:11:37.687106
# Unit test for function islurp
def test_islurp():
    import tempfile
    import os
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)

    # Write some data to the file
    os.write(fd, b"Hello World")
    os.close(fd)

    # Read the file contents
    for line in islurp(tmpfile):
        print(line)

    # Clean up the temporary file
    os.remove(tmpfile)

    # Clean up the temporary directory
    shutil.rmtree(tmpdir)


# Generated at 2022-06-18 04:11:46.101255
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil
    import os
    import os.path

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('hello\nworld\n')
    f.close()

    # Read the file
    for line in islurp(os.path.join(tmpdir, 'test.txt')):
        print(line)

    # Clean up the temporary directory
    shutil.rmtree(tmpdir)


# Generated at 2022-06-18 04:11:57.022578
# Unit test for function islurp
def test_islurp():
    import tempfile
    import random
    import string

    # Test reading from stdin
    with tempfile.TemporaryFile() as fh:
        fh.write(b'hello world')
        fh.seek(0)
        sys.stdin = fh
        assert list(islurp('-')) == ['hello world']

    # Test reading from file
    with tempfile.NamedTemporaryFile() as fh:
        fh.write(b'hello world')
        fh.seek(0)
        assert list(islurp(fh.name)) == ['hello world']

    # Test reading from file with LINEMODE
    with tempfile.NamedTemporaryFile() as fh:
        fh.write(b'hello world\n')
        fh.seek(0)