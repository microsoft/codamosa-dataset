

# Generated at 2022-06-12 07:33:41.252011
# Unit test for function islurp
def test_islurp():
    """
    Tests for islurp

    $ python3 -m pburg.utils.files --test-islurp
    """
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('-t', '--test-islurp', action='store_true')
    p.add_argument('--outdir', default='.')
    p.add_argument('--indir', default='.')
    p.add_argument('--chars', default=10)
    args = p.parse_args()

    if args.test_islurp:
        import tempfile
        import shutil

        # Test 1:  Write a file, read it by lines.

# Generated at 2022-06-12 07:33:48.597453
# Unit test for function islurp
def test_islurp():
    # test file
    f = "test.txt"
    try:
        with open(f, "w") as fh:
            for x in range(4):
                fh.write("line %d\n" % x)

        res = list(islurp(f))
        assert len(res) == 4
        assert res == ["line 0\n", "line 1\n", "line 2\n", "line 3\n"]
    finally:
        os.remove(f)

if __name__ == '__main__':
    test_islurp()

# Generated at 2022-06-12 07:33:52.908781
# Unit test for function islurp
def test_islurp():
    text1 = '''
    aaa
    bbb
    ccc\n'''
    text2 = '''
    aaa
    bbb
    ccc\n'''
    test1 = islurp('test1.txt')
    test2 = islurp('test2.txt')
    i = 0
    for item1, item2 in zip(test1, test2):
        assert item1 == item2
        i += 1
    assert i == 3

# Generated at 2022-06-12 07:33:57.688319
# Unit test for function islurp
def test_islurp():
    """
    Test function islurp
    :return:
    """
    assert list(islurp("tests/test_files/islurp")) == ['baz\n', 'qux\n']


# Generated at 2022-06-12 07:34:00.702751
# Unit test for function islurp
def test_islurp():
    # Print contents of file
    for chunk in islurp('README.md'):
        print(chunk)

# Unit test function burp

# Generated at 2022-06-12 07:34:09.425174
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil

    test_dir = 'test_file_util'
    test_file = os.path.join(test_dir, 'test_islurp.txt')

    # Create test directory
    os.makedirs(test_dir, exist_ok=True)
    with open(test_file, 'w') as fh:
        fh.write('abc\ndef\nghi\njkl\n')
    with open(test_file, 'rb') as fh:
        content_bytes = fh.read()

    # Test
    slurp_iter = slurp(test_file)
    slurp_iter_lines = [a for a in slurp_iter]

# Generated at 2022-06-12 07:34:13.599478
# Unit test for function islurp
def test_islurp():
    assert list(islurp('/dev/null')) == []
    assert list(islurp(os.path.join(os.path.dirname(__file__), 'data.txt'))) == ['line 1\n', 'line 2\n']



# Generated at 2022-06-12 07:34:23.797509
# Unit test for function islurp
def test_islurp():
    from io import StringIO

    def check(fh, contents):
        for d, l in zip(fh, contents.splitlines()):
            assert l == d

    # Test: Islurp.
    check(islurp('testfile'), 'This is a test\nfile.\n')

    # Test: Command line mode
    fh = islurp('-', allow_stdin=True)
    assert fh.readline() == 'This is a test\n'

    # Test: Iterate by chunks
    check(islurp('testfile', iter_by=3), 'This is a test\nfile.\n')

    # Test: No expandvars
    fh = islurp('$HOME/testfile', expandvars=False)

# Generated at 2022-06-12 07:34:28.715631
# Unit test for function islurp
def test_islurp():
    import tempfile as tf
    import shutil
    import os

    test_file = tf.NamedTemporaryFile(delete=False)

    test_file.write(b"this is the test string")
    test_file.close()

    test_islurp = islurp(test_file.name)
    test_islurp_contents = next(test_islurp)

    os.unlink(test_file.name)

    assert test_islurp_contents == b"this is the test string"



# Generated at 2022-06-12 07:34:34.200685
# Unit test for function burp
def test_burp():
    filename = "/tmp/test_burp.txt"
    try:
        os.remove(filename)
    except OSError:
        pass
    burp(filename, "burp")
    contents = os.popen("cat " + filename).read()
    assert "burp" == contents
    os.remove(filename)

# Generated at 2022-06-12 07:34:45.622168
# Unit test for function islurp
def test_islurp():
    """
    Create a small test file and perform a few tests on the contents:
    """
    from utils import mktempf
    from utils import rm
    from utils import md5hash
    from utils import list2d_to_csv

    # Create a temporary file holding a csv
    csvf = mktempf('csv')
    list2d_to_csv(csvf, [['a','b','c','d'],['1','2','3','4'],['5','6','7','8']])

    # Test islurp
    # 1. Read lines
    lines = [ line for line in islurp(csvf) ]
    assert(lines[0] == 'a,b,c,d\n')

# Generated at 2022-06-12 07:34:55.808549
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 07:34:58.754102
# Unit test for function islurp
def test_islurp():
    lines = list(islurp('/etc/motd'))
    assert len(lines) == 3
    assert 'Ubuntu' in lines[0]


# Generated at 2022-06-12 07:35:04.764487
# Unit test for function islurp
def test_islurp():
    """
    Test the islurp function
    """
    stream = islurp('../test-data/test-data-1.txt')
    lines = [line.rstrip() for line in stream]
    assert(lines[0] == "This is file 1.")

if __name__ == '__main__':
    print("Running test suite for file utilities.")
    test_islurp()
    print("done")

# Generated at 2022-06-12 07:35:08.118062
# Unit test for function islurp
def test_islurp():
    assert list(islurp(__file__, iter_by=10000))
    assert list(islurp(__file__, iter_by=1))
    assert list(islurp(__file__))

# Generated at 2022-06-12 07:35:15.770876
# Unit test for function islurp
def test_islurp():
    """Test islurp function with a file as input"""
    try:
        f = open('test_file.txt', 'w')
        f.write('Hello world!\n')
        f.write('Hello world!\n')
        f.write('Hello world!\n')
        f.write('Hello world!\n')
        f.close()
        f_name = 'test_file.txt'
        for line in islurp(f_name):
            assert line == 'Hello world!\n'
        os.remove(f_name)
    except AssertionError:
        print('Test Failed')
        os.remove(f_name)


# Generated at 2022-06-12 07:35:27.324731
# Unit test for function islurp
def test_islurp():
    import random
    import tempfile
    import random
    import pytest

    #
    # Test by lines:
    #

    # Test a file of random lines
    n_lines = 200
    lines = [str(random.randint(1,1000000)) for _ in xrange(n_lines)]
    tmpf = tempfile.NamedTemporaryFile()
    with open(tmpf.name, 'w') as fh:
        for line in lines:
            fh.write(line)
            fh.write(os.linesep)

    # Check that all lines are read
    n_read = 0
    for line in islurp(tmpf.name):
        n_read += 1
    assert n_read == n_lines

    # Check that all lines are read
    n_read = 0

# Generated at 2022-06-12 07:35:35.137512
# Unit test for function burp
def test_burp():
    import tempfile

    tmpdir = tempfile.gettempdir()
    tmpdir = os.path.normpath(tmpdir)
    test_file = os.path.join(tmpdir, "test_file.txt")
    try:
        burp(test_file, "This is a test")
        with open(test_file) as fh:
            return fh.read() == "This is a test"
    finally:
        os.unlink(test_file)


# Generated at 2022-06-12 07:35:46.540256
# Unit test for function islurp
def test_islurp():
    fh = sys.stdout

    print('islurp.LINEMODE: {}'.format(islurp.LINEMODE), file=fh)

    print('\nislurp(__file__)', file=fh)
    for line in islurp(__file__):
        print(line.rstrip(), file=fh)

    print('\nislurp(__file__, iter_by=islurp.LINEMODE)', file=fh)
    for line in islurp(__file__, iter_by=islurp.LINEMODE):
        print(line.rstrip(), file=fh)

    print('\nislurp(__file__, iter_by=8)', file=fh)

# Generated at 2022-06-12 07:35:49.780439
# Unit test for function islurp
def test_islurp():
    assert [x for x in islurp('-')] == [x for x in sys.stdin]
    assert [x for x in islurp('-', allow_stdin=False)] == []



# Generated at 2022-06-12 07:35:59.553975
# Unit test for function islurp
def test_islurp():
    buf = '\n'.join(islurp(__file__))
    assert buf.startswith("#!/usr/bin/env python")
    assert not buf.startswith("\n")

    buf = b''.join(islurp(__file__, 'rb', 1))
    assert buf.startswith(b"#!/usr/bin/env python")
    assert not buf.startswith(b"\n")


# Generated at 2022-06-12 07:36:05.987554
# Unit test for function islurp
def test_islurp():
    assert list(islurp(__file__, iter_by=1)) == open(__file__).readlines()
    assert list(islurp(__file__, iter_by=512)) == open(__file__).readlines()
    assert list(islurp(__file__, iter_by=islurp.LINEMODE)) == open(__file__).readlines()


# Generated at 2022-06-12 07:36:14.785787
# Unit test for function islurp
def test_islurp():
    test_fname = 'test_islurp.txt'
    test_contents = ['123\n456\n789\n',
                     '123\n45\n67\n89\n',
                     '1\n23\n45\n67\n89\n']
    for test_content in test_contents:
        burp(test_fname, test_content)
        str_out = ''
        for line in islurp(test_fname):
            str_out += line
        assert str_out == test_content, 'test_islurp: test_content = %s, str_out = %s' % (test_content, str_out)
    os.remove(test_fname)



# Generated at 2022-06-12 07:36:23.091587
# Unit test for function islurp
def test_islurp():
    # Test for LINEMODE
    for chunk in islurp('test_file.txt'):
        assert chunk == 'this is just a test file\n'

    # Test for LINEMODE with expansion of user directory
    for chunk in islurp('~/test_file.txt', expanduser=True):
        assert chunk == 'this is just a test file\n'

    # Test for LINEMODE with expansion of environment variables
    for chunk in islurp('$HOME/test_file.txt', expandvars=True):
        assert chunk == 'this is just a test file\n'

    # Test for chunk mode
    for chunk in islurp('test_file.txt', iter_by=20):
        assert chunk == 'this is just a test f'

    # Test for chunk mode with expansion of user directory
   

# Generated at 2022-06-12 07:36:32.939405
# Unit test for function islurp
def test_islurp():
    # Default
    contents = islurp("test.txt")
    assert '\n'.join(contents) == "abc\n123\n\n"

    # Specify mode
    contents = islurp("test.txt", mode="r")
    assert '\n'.join(contents) == "abc\n123\n\n"

    # Iterate by byte
    contents = islurp("test.txt", iter_by=1)
    assert '\n'.join(contents) == "abc\n123\n\n"

    # Disallow stdin
    contents = islurp("-", allow_stdin=False)
    assert '\n'.join(contents) == "abc\n123\n\n"

    # Allow stdin

# Generated at 2022-06-12 07:36:42.624785
# Unit test for function islurp
def test_islurp():
    """ Unit test for function slurp """
    from io import StringIO
    from tempfile import TemporaryFile

    # Test with stdin
    stdin_contents = 'abc\n123\nxyz'
    sys.stdin = StringIO(stdin_contents)
    buf = ''
    for line in islurp('-', allow_stdin=True):
        buf += line
    assert buf == stdin_contents

    # Test with slurping lines
    with TemporaryFile('w+t') as fh:
        fh.write(stdin_contents)
        fh.seek(0)
        buf = ''
        for line in islurp(fh.name):
            buf += line
        assert buf == stdin_contents

    # Test with slurping bytes

# Generated at 2022-06-12 07:36:46.155450
# Unit test for function burp
def test_burp():
    import os
    import shutil

    # Create file
    burp("/tmp/file.txt", "Hello World")

    # Check file exists
    assert os.path.isfile("/tmp/file.txt")

    # Cleanup
    shutil.rmtree("/tmp/file.txt")


# Generated at 2022-06-12 07:36:50.840704
# Unit test for function islurp
def test_islurp():
    f = islurp('test_files/test_islurp.txt')
    assert type(f) == type(islurp('test_files/test_islurp.txt'))



# Generated at 2022-06-12 07:36:56.140581
# Unit test for function islurp
def test_islurp():
    with open('~/Desktop/test_islurp.txt', 'w') as fh:
        fh.write('Test1\nTest2\nTest3')

    for line in islurp('~/Desktop/test_islurp.txt'):
        assert line.strip() == 'Test1' or line.strip() == 'Test2' or line.strip() == 'Test3'

test_islurp()


# Generated at 2022-06-12 07:37:04.825302
# Unit test for function islurp
def test_islurp():
    import tempfile
    import shutil

    tempdir = None

# Generated at 2022-06-12 07:37:18.999868
# Unit test for function islurp
def test_islurp():
    """
    Unit test for islurp
    """
    import os
    import random
    import string
    import tempfile

    BUF = ''.join(random.sample(string.ascii_letters + string.digits, random.randint(0, 1024))) + '\n'
    CHUNK_SIZE = 10
    ITER = 5

    testdir = None

# Generated at 2022-06-12 07:37:23.419575
# Unit test for function islurp
def test_islurp():
    """All files passed to islurp should be iterable"""
    assert isiterable(islurp("-"))
    assert isiterable(islurp("testfile"))
    assert isiterable(islurp("testfile", mode='rb'))
    assert isiterable(islurp("testfile", iter_by=1))


# Generated at 2022-06-12 07:37:34.686104
# Unit test for function islurp
def test_islurp():
    import os
    import uuid

    # test basic functionality
    test_filename = '/tmp/%s' % uuid.uuid4().hex
    contents = ['line %d\n' % i for i in xrange(100)]
    with open(test_filename, 'w') as fh:
        fh.writelines(contents)

    filename = test_filename
    lines = [line for line in islurp(filename)]
    assert lines == contents

    filename = test_filename
    lines = [line for line in islurp(filename, iter_by=8)]
    assert lines[:1] == contents[:1]
    assert lines[-1] == contents[-1]

    filename = test_filename
    lines = [line for line in islurp(filename, allow_stdin=False)]

# Generated at 2022-06-12 07:37:43.176034
# Unit test for function islurp
def test_islurp():
    """ Unit test for function islurp
    """
    from sys import stdin
    from shlex import split as shsplit
    from functools import partial

    # test islurp
    from fileutils import islurp, slurp

    # test reading from stdin
    for chunk in islurp('-'):  # will read from stdin
        print(repr(chunk))

    # test reading lines
    for chunk in islurp(__file__):
        print(repr(chunk))

    # test reading chunks (mode rb)
    chunksize = 5
    for chunk in islurp(__file__, 'rb', chunksize):
        print(repr(chunk))

    # test reading chunks (divide lines by chunksize)

# Generated at 2022-06-12 07:37:53.906534
# Unit test for function islurp
def test_islurp():
    # test islurp with LINEMODE
    result = slurp('test.txt')
    expected_result = ['This is a test file.\n', '\n', 'The quick brown fox jumps over the lazy dog.']
    assert(result == expected_result)

    # test islurp with CHUNKMODE
    result = slurp('test.txt', iter_by=30)
    expected_result = ['This is a test file.\n', '\n', 'The quick brown fox jumps over the lazy dog.']
    assert(result == expected_result)

    # test islurp with stdin
    with open('test.txt') as f:
        sys.stdin = f
        result = slurp('-', iter_by=30)
        assert(result == expected_result)

    # test islur

# Generated at 2022-06-12 07:37:57.627117
# Unit test for function islurp
def test_islurp():
    from itertools import islice
    f = islurp('test.txt')
    result = ''.join(islice(f, 2))
    assert result == 'Lorem ipsum\ndolor sit amet,\n'
    f.close()

# Generated at 2022-06-12 07:38:08.614090
# Unit test for function islurp
def test_islurp():
    import tempfile
    import random
    import string
    import contextlib

    def _chunksize(size):
        while True:
            chars = random.choice(string.ascii_letters) * size
            yield chars

    @contextlib.contextmanager
    def _tmpfile():
        fd, fn = tempfile.mkstemp(text=True)
        with os.fdopen(fd, 'r+') as fh:
            try:
                yield fh
            finally:
                os.unlink(fn)

    def _full_test(size):
        with _tmpfile() as fh:
            ref_chunks = []
            for i, chunk in enumerate(_chunksize(size), 1):
                ref_chunks.append(chunk)

# Generated at 2022-06-12 07:38:18.159752
# Unit test for function islurp
def test_islurp():
    import os

    # test1: test the iterator
    path = os.path.dirname(os.path.realpath(__file__))
    n = 0
    for line in islurp(path + '/data/test.csv', mode='r'):
        n += 1
    assert n == 45

    # test2: test the read-line-at-a-time mode
    path = os.path.dirname(os.path.realpath(__file__))
    buf = ''
    for line in islurp(path + '/data/test.csv', mode='rb'):
        buf += line
    assert buf != ''

    # test3: test the read-chunk-at-a-time mode
    path = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-12 07:38:20.445176
# Unit test for function islurp
def test_islurp():
    for line in islurp('tests/test_islurp.txt'):
        assert line == 'foo'


# Generated at 2022-06-12 07:38:24.861891
# Unit test for function islurp
def test_islurp():
    assert list(islurp('/dev/null')) == []
    assert list(islurp('/dev/null', mode='rb')) == []


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 07:38:37.298405
# Unit test for function islurp
def test_islurp():
    test_file = 'test_file.txt'
    test_content = '\n'.join(["abc", "123"])
    fh = open(test_file, 'w')
    fh.write(test_content)
    fh.close()

    result = ''.join(islurp(test_file))
    os.remove(test_file)
    assert test_content == result


# Generated at 2022-06-12 07:38:49.163070
# Unit test for function islurp
def test_islurp():
    """
    Test islurp() function
    """
    from StringIO import StringIO
    from os import devnull
    from nose.tools import eq_ as eq
    from nose.plugins.attrib import attr

    n = -1
    for i, line in zip(range(3), islurp(StringIO('1\n2\n3\n'))):
        n += 1
        eq(line, str(i + 1) + '\n')
    eq(n, 2)

    n = -1
    for i, line in zip(range(3), islurp(StringIO(u'1\n2\n3\n'))):
        n += 1
        eq(line, str(i + 1) + '\n')
    eq(n, 2)

    n = -1


# Generated at 2022-06-12 07:38:50.704978
# Unit test for function islurp
def test_islurp():
    assert islurp("testfiles/test_islurp.txt").next() == "LOREM\n"

# Generated at 2022-06-12 07:39:02.734834
# Unit test for function islurp
def test_islurp():
    # Test slurping stdin
    assert list(islurp(-1, chr(0))) == ['test\n']

    # Test slurping a file
    fname = 'testdata/t0.txt'
    assert list(islurp(fname)) == ['test\n', 'test\n']
    assert list(islurp(fname, iter_by=3)) == ['tes', 't\nt', 'est\n']
    assert list(islurp(fname, iter_by=10)) == ['test\ntest\n']

    # Test slurping a file with ~ in filename
    fname = '~/testdata/t0.txt'
    assert list(islurp(fname)) == ['test\n', 'test\n']

    # Test slurping a file with environment variable in filename
   

# Generated at 2022-06-12 07:39:13.800615
# Unit test for function islurp
def test_islurp():
    # Test case: read from file
    from StringIO import StringIO
    from contextlib import closing
    contents = 'abc'
    fd = StringIO()
    with closing(fd):
        fd.write(contents)
        fd.seek(0)
        assert(''.join(islurp(fd)) == contents)
    # Test case: read from stdin
    try:
        __builtins__.raw_input
    except AttributeError:
        # Python 3
        import builtins
        builtins.input = lambda _: contents
    else:
        # Python 2
        __builtins__.raw_input = lambda _: contents
    assert(''.join(islurp('-')) == contents)

test_islurp()


# Generated at 2022-06-12 07:39:21.682114
# Unit test for function islurp
def test_islurp():
    from itertools import islice

    data = 'Hello World!\n'

    # test readline
    result = islurp('-', iter_by=LINEMODE)
    assert list(islice(result, 2)) == ['Hello World!\n', '']

    # test read chunk
    result = islurp('-', iter_by=5)
    assert list(islice(result, 2)) == [data[:5], data[5:]]

    result = islurp('-', iter_by=len(data))
    assert list(islice(result, 3)) == [data, '', '']


# Generated at 2022-06-12 07:39:32.294516
# Unit test for function islurp
def test_islurp():
    fh = open('exists.txt', 'w')
    fh.write('a\nb\nc\nd\ne\n')
    fh.close()

    # Iterate through file line by line
    line_by_line = [line for line in islurp('exists.txt')]
    expected_line_by_line = [line for line in open('exists.txt', 'r')]
    assert(line_by_line == expected_line_by_line)

    # Iterate through file by 2 bytes
    chunk_by_2_bytes = [chunk for chunk in islurp('exists.txt', iter_by=2)]
    expected_chunk_by_2_bytes = [chunk for chunk in open('exists.txt', 'r').readlines()]

# Generated at 2022-06-12 07:39:40.058971
# Unit test for function islurp
def test_islurp():
    # Test reading from stdin
    assert list(islurp('-', 'r', allow_stdin=True)) == ['line1\n', 'line2\n', 'line3\n']

    # Test basic reading
    assert list(islurp('test_files/testfile', 'r')) == ['line1\n', 'line2\n', 'line3\n']
    assert list(islurp('test_files/testfile', 'rb')) == [b'line1\n', b'line2\n', b'line3\n']

    # Test reading by chunks

# Generated at 2022-06-12 07:39:50.427736
# Unit test for function islurp
def test_islurp():
    import os, sys

    def makefile(filename, contents):
        with open(filename, 'w') as fh:
            fh.write(contents)

    testfile = 'test.txt'


# Generated at 2022-06-12 07:40:00.506077
# Unit test for function islurp
def test_islurp():
    # islurp
    assert list(islurp('-', 'r')) == ['hello\n', 'world\n']
    assert list(islurp('-', 'r', iter_by=1)) == ['h', 'e', 'l', 'l', 'o', '\n', 'w', 'o', 'r', 'l', 'd', '\n']
    assert list(islurp('./test_utils.py', 'r', LINEMODE))[0] == '# Unit test for function islurp\n'
    assert list(islurp('./test_utils.py', 'rb', iter_by=100))[0] == '# Unit test for function islurp\n#\n# '

# Generated at 2022-06-12 07:40:21.939002
# Unit test for function islurp
def test_islurp():
    data = ''
    for line in islurp('test_utils_file.py'):
        data += line

    assert 'Unit test for function islurp' in data


# Generated at 2022-06-12 07:40:28.849598
# Unit test for function islurp
def test_islurp():
    assert next(islurp('/etc/hosts')) == '##\n'
    assert next(islurp('/etc/hosts', 'rb')) == b'##\n'
    assert next(islurp('/etc/hosts', iter_by=8192)) == '##\n'

    try:
        next(islurp('not-a-file'))
    except IOError:
        pass
    else:
        assert False

    try:
        next(islurp('not-a-file', expanduser=False))
    except IOError:
        pass
    else:
        assert False

    assert next(islurp('/etc/hosts', expanduser=False)) == '##\n'
    assert next(islurp('~/not-a-file', expanduser=False))

# Generated at 2022-06-12 07:40:38.649247
# Unit test for function islurp
def test_islurp():
    
    # Test with a correct file 
    #
    # Function islurp will be tested with a correct file (a file that contains 7 lines)
    # Each lines in the file will be read and will be checked
    # Creates the file
    filename = 'test_file'
    fo = open(filename, 'w')
    fo.write('line1\n')
    fo.write('line2')
    fo.write('line3')
    fo.write('line4')
    fo.write('line5')
    fo.write('line6\n')
    fo.write('line7')
    fo.close()
    
    # Open the file and read each lines
    fh = open(filename, 'r')
    line1 = fh.readline()
    line2 = fh.readline()
   

# Generated at 2022-06-12 07:40:42.728343
# Unit test for function islurp
def test_islurp():
    import StringIO
    fh = StringIO.StringIO('a\nb\n')
    lines = list(islurp(fh, 'r', expanduser=False, expandvars=False))
    assert len(lines) == 2
    assert lines[0] == 'a\n'
    assert lines[1] == 'b\n'

# Generated at 2022-06-12 07:40:43.954010
# Unit test for function islurp
def test_islurp():
    assert len(list(islurp("files.py", iter_by=islurp.LINEMODE))) == 120

# Generated at 2022-06-12 07:40:49.823572
# Unit test for function islurp
def test_islurp():
    """
    Usage:
        python -m lib.fileutils [src_file_path]
        python -m lib.fileutils
    """
    from pprint import pprint

    # If no src file path provided, read from stdin
    if (len(sys.argv) == 1):
        filename = '-'
    else:
        filename = sys.argv[1]

    # Read a file line-by-line
    for input_line in islurp(filename):
        print('Input line:', input_line)

    # Read a file into a string
    with open(filename, 'r') as fh:
        f_contents_ref = fh.read()
    f_contents = ''.join(islurp(filename, iter_by=65536))

# Generated at 2022-06-12 07:40:58.629414
# Unit test for function islurp
def test_islurp():

    # Check mode
    # if 'b' in open('test.txt').mode:
    #     print('Binary file.')
    # else:
    #     print('Text file')

    # Standard case
    with open('test.txt', 'r') as f:
        # print(f.read(1))
        for line in f.readlines():
            print(line)

    # Alternate
    for line in open('test.txt', 'r'):
        print(line)

    # Alternate 2
    f = open('test.txt', 'r')
    for line in f:
        print(line)
    f.close()

    # Alternate 3
    with open('test.txt', 'r') as f:
        print(f.readline())

    # Alternate 4

# Generated at 2022-06-12 07:41:09.129630
# Unit test for function islurp
def test_islurp():
    """
    Unit test for function islurp
    """
    # Create test file
    filename = 'test_islurp.txt'
    burp(filename, 'line1\nline2\nline3\n')

    # Read each line of file using islurp
    read_lines = []
    for line in islurp(filename):
        read_lines.append(line)

    # Check number of lines read
    assert len(read_lines) == 3

    # Check contents of each line
    for ii in range(3):
        assert read_lines[ii] == 'line%d\n'%(ii+1)


    # Cleanup: delete file
    os.unlink(filename)




# Generated at 2022-06-12 07:41:20.103178
# Unit test for function islurp
def test_islurp():
    # Create a temporary file
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile('w') as tmpfile:
        tmpfile.write("line1\nline2\nline3\n")
        tmpfile.seek(0)

        myislurp = islurp(tmpfile.name)

        assert isinstance(myislurp, functools.partial)
        assert myislurp.keywords == {'allow_stdin': True,
                                     'expanduser': True,
                                     'expandvars': True,
                                     'iter_by': 0,
                                     'mode': 'r'}

        # Now iterate through the lines
        lines = []
        for line in islurp(tmpfile.name):
            lines.append(line)


# Generated at 2022-06-12 07:41:22.416021
# Unit test for function islurp
def test_islurp():
    for line in islurp('test/test_files.py'):
        print(line)
        assert isinstance(line, str), "line is not string"
        break

test_islurp()

# Generated at 2022-06-12 07:42:05.117654
# Unit test for function islurp
def test_islurp():
    assert islurp('-').next() == '\n'
    assert islurp('-', expanduser=False).next() == '\n'
    assert islurp('-').next() == '\n'
    assert islurp('-').next() == '\n'
    assert islurp('-').next() == '\n'
    assert islurp('-').next() == '\n'
    assert islurp('-').next() == '\n'
    assert islurp('-').next() == '\n'
    assert islurp('-').next() == '\n'
    assert islurp('-').next() == '\n'

# Generated at 2022-06-12 07:42:09.549383
# Unit test for function islurp
def test_islurp():
    assert [x for x in islurp(__file__)] == open(__file__).readlines()
    assert [x for x in islurp(__file__, allow_stdin=False)] == open(__file__).readlines()
    assert [x for x in islurp('-', allow_stdin=True)] == sys.stdin.readlines()


# Generated at 2022-06-12 07:42:12.189195
# Unit test for function islurp
def test_islurp():
    assert list(islurp(__file__))[0].startswith('#!/usr/bin/env python')



# Generated at 2022-06-12 07:42:13.895828
# Unit test for function islurp
def test_islurp():
    for x in islurp(sys.argv[0]):
        print(x)



# Generated at 2022-06-12 07:42:23.221224
# Unit test for function islurp
def test_islurp():
    """
    Unit test
    """
    import unittest

    class Tests(unittest.TestCase):

        def test_islurp_exceptions(self):
            """
            Tests for islurp exceptions
            """
            import io
            from io import BytesIO

            with self.assertRaises(ValueError):
                for _ in islurp(None):
                    pass

            with self.assertRaises(ValueError):
                for _ in islurp(1):
                    pass

            with self.assertRaises(ValueError):
                for _ in islurp(io.StringIO()):
                    pass

            with self.assertRaises(ValueError):
                for _ in islurp(BytesIO()):
                    pass


# Generated at 2022-06-12 07:42:24.153607
# Unit test for function islurp
def test_islurp():
    pass


# Generated at 2022-06-12 07:42:35.030410
# Unit test for function islurp
def test_islurp():

    # Read and print contents of file.
    assert list(islurp('testfile.txt')) == ['test_file\n']
    assert list(islurp('testfile.txt', mode='rb')) == [b'test_file\n']
    assert list(islurp('testfile.txt', mode='rb', iter_by=10)) == [b'test_file\n']
    assert list(islurp('testfile.txt', mode='rb', iter_by='LINEMODE')) == [b'test_file\n']
    assert list(islurp('testfile.txt', mode='rb', iter_by=LINEMODE)) == [b'test_file\n']

    # Test if program can read from standard input by default.
    # Create testfile and write to standard output using the file descriptor .


# Generated at 2022-06-12 07:42:40.198474
# Unit test for function islurp
def test_islurp():
    with open('/tmp/islurp_test.txt', 'w') as fh:
        fh.write('This is a test file')
    x = slurp('/tmp/islurp_test.txt')
    x = list(islurp('/tmp/islurp_test.txt'))
    assert x == ['This is a test file']
    y = list(islurp('/tmp/islurp_test.txt', iter_by=30))
    assert y == ['This is a test file']
    os.unlink('/tmp/islurp_test.txt')


# Generated at 2022-06-12 07:42:51.051556
# Unit test for function islurp
def test_islurp():
    content = '''
This is a test.

This is another test.

This is a final test.
'''

    assert content == ''.join(islurp(__file__))

    content = '''
This is a test.

This is another test.

This is a final test.
'''

    assert content == ''.join(islurp('-', allow_stdin=True))

    content = '''
This is a test.

This is another test.

This is a final test.
'''

    assert content == ''.join(islurp('-', allow_stdin=False))

    content = '''
This is a test.
'''

    assert content == ''.join(islurp(__file__, iter_by=32))


# Generated at 2022-06-12 07:42:53.850384
# Unit test for function burp
def test_burp():
    tmp_file = './tmp.txt'
    content = 'Hello there'
    burp(tmp_file, content)
    assert slurp(tmp_file) == content
    os.remove(tmp_file)