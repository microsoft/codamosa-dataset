

# Generated at 2022-06-26 02:02:30.419797
# Unit test for function islurp
def test_islurp():
    # Test Error conditions
    # Test Regular cases
    if False :
        test_case_0()

    pass


# Generated at 2022-06-26 02:02:31.369112
# Unit test for function islurp
def test_islurp():
    assert islurp() == None


# Generated at 2022-06-26 02:02:31.941394
# Unit test for function islurp
def test_islurp():
    assert 1 == 1

# Generated at 2022-06-26 02:02:33.319720
# Unit test for function islurp
def test_islurp():
    assert callable(islurp)


# Generated at 2022-06-26 02:02:36.931624
# Unit test for function islurp
def test_islurp():
    exp = 123
    inp = 123
    assert islurp(inp) == exp, 'Input: {0}, Expected: {1}, Got: {2}'.format(inp, exp, islurp(inp))


# Generated at 2022-06-26 02:02:42.546712
# Unit test for function burp
def test_burp():
    contents = 'contents'
    filename = 'file'
    mode = 'w'
    allow_stdout = False
    expanduser = False
    expandvars = False
    expected = 3
    actual = burp(filename, contents, mode, allow_stdout, expanduser, expandvars)
    assert actual == expected, 'Expected: %r\nActual: %r' % (expected, actual)


# Generated at 2022-06-26 02:02:46.665049
# Unit test for function islurp
def test_islurp():
    assert slurp('test_islurp.txt', b'a\nb\nc\nd') == b'abc'


# Generated at 2022-06-26 02:02:56.233157
# Unit test for function islurp
def test_islurp():
    # -------------------------------------------------------------------
    # Test 0:
    # -------------------------------------------------------------------
    # Case 0:
    # -------------------------------------------------------------------
    print("Testing Case 0")
    # Test 0 Part 1
    test0 = islurp(None)
    for line in test0:
        print(line)
    # Test 0 Part 2
    test0 = islurp(None,iter_by='LINEMODE')
    for line in test0:
        print(line)
    # Test 0 Part 3
    
    # Test 0 Part 4
    
    # -------------------------------------------------------------------
    # Test 1:
    # -------------------------------------------------------------------
    # Case 1:
    # -------------------------------------------------------------------
    print("Testing Case 1")
    # Test 1 Part 1
    test1 = islurp(None)
    for line in test1:
        print(line)
    # Test 1

# Generated at 2022-06-26 02:02:59.557488
# Unit test for function islurp
def test_islurp():
    try:
        assert test_case_0() == 1
        print("islurp.py tests passed")
    except NotImplementedError:
        print("Unit tests for islurp.py are not implemented")

# Generated at 2022-06-26 02:03:04.666163
# Unit test for function burp
def test_burp():
    assert burp(True, True) == True
    assert burp(True, True, True) == True
    assert burp(True, True, True, True) == True
    assert burp(True, True, True, True, True) == True
    assert burp(True, True, True, True, True, True) == True


# Generated at 2022-06-26 02:03:12.047442
# Unit test for function islurp
def test_islurp():
    # Consider the following Python program:
    b = islurp('test_islurp')
    assert list(b) == ['Hello, world!\n'], 'test_islurp() failed'


# Generated at 2022-06-26 02:03:20.504256
# Unit test for function islurp

# Generated at 2022-06-26 02:03:26.538739
# Unit test for function islurp
def test_islurp():
    """
    Input arguments:  (1) filename/path
    Expected output (for this test): contents of test file
    """
    file_contents = islurp(filename="./test/files/testfile.txt")

    # Check that result is the expected output
    assert file_contents == "This is a test file\n"
    # Check that result type is the expected output
    assert type(file_contents) == str

# Generated at 2022-06-26 02:03:33.984974
# Unit test for function burp
def test_burp():

    # load test case scenario
    # WARNING: this test case assumes that the 
    # function burp(filename, contents, mode='w', allow_stdout=True, expanduser=True, expandvars=True)
    # does not change the contents of the text file
    # the test case is based on.
    with open("data/burp_test_case.txt") as test_case_file:
        test_case_data = test_case_file.read()

    test_results = []
    # change the sequence of tests here
    tests = [test_case_0,]

    # run test cases
    print("Running test cases...")
    for test_case in tests:
        # run test case
        print("Running test case " + str(test_case))
        test_case()
        # check test case results


# Generated at 2022-06-26 02:03:41.882594
# Unit test for function islurp
def test_islurp():
    assert islurp(b'\x01\x02\x03') == ['\x01', '\x02', '\x03']
    assert islurp(b'\x01\x02\x03', iter_by=1) == b'\x01\x02\x03'
    assert list(islurp('file_0', iter_by=2)) == ["A quick brown fox jumps over the lazy dog.", ""]
    assert list(islurp('file_1')) == ['AAA quick BBB brown CCC fox DDD jumps EEE over FFF the GGG lazy HHH dog. I',
                                      '',
                                      'JJJ You KK']

# Generated at 2022-06-26 02:03:54.855363
# Unit test for function islurp
def test_islurp():
    test_dict = {
        'b': bytes,
        'r': str,
        'rb': bytes,
        'r+': str,
        'w': str,
        'w+': str,
        'a': str,
        'a+': str
    }

    for mode in test_dict:
        with open('testfile.txt', 'w+') as file:
            file.write('Now is the time for all good men to come to the aid of their country.')

            for line in islurp('testfile.txt', mode=mode):
                assert isinstance(line, test_dict[mode])
                assert line == 'Now is the time for all good men to come to the aid of their country.\n'

    os.remove('testfile.txt')


# Generated at 2022-06-26 02:03:59.856505
# Unit test for function islurp
def test_islurp():
    assert islurp('-') == sys.stdin


# Generated at 2022-06-26 02:04:10.625150
# Unit test for function islurp
def test_islurp():
    for expected, filename, args, kwargs in [
        ('abc', 'abc', (None,), {}),
    ]:
        for mode in ['r', 'rb']:
            for iter_by in [LINEMODE, 1, 2]:
                for allow_stdin in [False, True]:
                    for expanduser in [False, True]:
                        for expandvars in [False, True]:
                            yield check_islurp, expected, filename, mode, iter_by, allow_stdin, expanduser, expandvars, args, kwargs

                    #  Forced stdin
                    filename = '-'
                    expected = 'abc'
                    sys.stdin = sys.__stdin__
                    yield check_islurp, expected, filename, mode, iter_by, allow_stdin, expanduser, expandvars, args, k

# Generated at 2022-06-26 02:04:19.993278
# Unit test for function islurp
def test_islurp():
    test_file = 'test.txt'
    lines = list(islurp(test_file))
    assert len(lines) == 2
    assert lines[0] == 'This is line 1.\n'
    assert lines[1] == 'This is line 2.\n'
    with open(test_file, 'w') as f:
        f.write('abcdefghijklmnopqrstuvwxyz')
    it = islurp(test_file)
    assert next(it) == 'abcdefghijkgjhgklmnopqqrstuvwxyz'
with open(test_file, 'w') as f:
    f.write('This is line 1.\nThis is line 2.\n')

# Generated at 2022-06-26 02:04:28.241796
# Unit test for function islurp
def test_islurp():
    ####
    # Setup
    ####
    # filename, mode, iter_by, allow_stdin, expanduser, expandvars

    test_cases = [
        {},  # #0
    ]

    for test_case in test_cases:
        filename = test_case.get('filename', None)
        mode = test_case.get('mode', None)
        iter_by = test_case.get('iter_by', None)
        allow_stdin = test_case.get('allow_stdin', None)
        expanduser = test_case.get('expanduser', None)
        expandvars = test_case.get('expandvars', None)

        ####
        # Exercise
        ####

# Generated at 2022-06-26 02:04:36.979960
# Unit test for function islurp
def test_islurp():
    fname = "test_islurp.tmp"
    with open(fname, 'w') as fh:
        fh.write("line 1")
        fh.write("line 2")
        fh.write("line 3")

    try:
        lines = [line for line in islurp(fname)]
        assert lines == ["line 1", "line 2", "line 3"]
    finally:
        os.remove(fname)



# Generated at 2022-06-26 02:04:38.871296
# Unit test for function islurp
def test_islurp():
    result1 = islurp.slurp
    assert result1 == '-', 'Must return -'

# Generated at 2022-06-26 02:04:44.748256
# Unit test for function islurp
def test_islurp():
    assert 'islurp' in globals(), "Function `islurp` is not defined."
    assert isinstance(islurp('testcase', r, LINEMODE, True,
                             True, True), list), "Function `islurp` is not working properly."
    assert isinstance(islurp('testcase', rb, LINEMODE, True,
                             True, True), list), "Function `islurp` is not working properly."


# Generated at 2022-06-26 02:04:49.514917
# Unit test for function islurp
def test_islurp():
    # Init
    test_file = 'pytest.txt'

    fh = open(test_file, 'w')
    fh.write('Great is the power of steady misrepresentation.')
    fh.close()
    bytes_0 = b'\xb7X'
    int_0 = -4103
    var_0 = burp(bytes_0, int_0)

# Generated at 2022-06-26 02:04:58.979435
# Unit test for function islurp
def test_islurp():
    d = os.path.dirname(os.path.abspath(__file__))
    t = os.path.join(d, 'islurp.test')
    if os.path.exists(t):
        os.remove(t)

    # Test a file with one line and a trailing newline.
    with open(t, 'w') as f:
        f.write(b'a\nb\nc\n')
    assert list(islurp(t)) == [b'a\n', b'b\n', b'c\n']
    os.remove(t)

    # Test a file with no lines.
    with open(t, 'w') as f:
        f.write('')
    assert list(islurp(t)) == []
    os.remove(t)

    #

# Generated at 2022-06-26 02:05:08.796194
# Unit test for function islurp
def test_islurp():
    import argparse
    import os
    import tempfile
    import shutil
    import sys

    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('-i', '--input', type=str, help='input file')
    parser.add_argument('-c', '--chunk-size', type=int, default=LINEMODE, help='iterate by character size (default %s)' % LINEMODE)
    parser.add_argument('-n', '--no-expanduser', action='store_true', help='disable ~ expansion')
    parser.add_argument('-e', '--no-expandvars', action='store_true', help='disable variable expansion')
    args = parser.parse_args()

    err = False
    out = None

# Generated at 2022-06-26 02:05:12.348812
# Unit test for function islurp
def test_islurp():
    # this test might fail on some systems
    # that is OK for now
    for i in islurp(__file__, iter_by=4096):
        if i.find('\0') != -1:
            raise RuntimeError('Unexpected NUL character in file')



# Generated at 2022-06-26 02:05:22.047063
# Unit test for function islurp
def test_islurp():

    # Test #0:
    # Tested: False
    # Test #0: mypy complains "Too many arguments for "islurp" (too many positional, 3)
    # Test #0: mypy complains "Too many arguments for "islurp" (too many positional, 3)"
    # Test #0: mypy complains "Too many arguments for "islurp" (too many positional, 3)"
    # Test #0: mypy complains "Too many arguments for "islurp" (too many positional, 3)"
    var_0 = islurp(True, True, 'LINEMODE')
    # Test #1:
    # Tested: False
    # Test #1: mypy complains "Too many arguments for "islurp" (too many positional, 3)"
    # Test #1: mypy complains "Too many arguments for "isl

# Generated at 2022-06-26 02:05:23.230204
# Unit test for function islurp
def test_islurp():
    assert islurp.LINEMODE == 0


# Generated at 2022-06-26 02:05:28.725737
# Unit test for function islurp
def test_islurp():
    # Test normal case
    data = b'\xb7X'
    try:
        var_0 = islurp(bytes_0, iter_by=1)
        t_0 = os.fstat(var_0.fileno())
        var_1 = t_0.st_size
        var_0.close()
    except Exception:
        var_0.close()
        raise



# Generated at 2022-06-26 02:05:42.528051
# Unit test for function islurp
def test_islurp():
    """
    Test case for function islurp
    """
    # Input parameters
    # str filename = 
    # str mode = 
    # int iter_by = 
    # bool allow_stdin = 
    # bool expanduser = 
    # bool expandvars = 
    # assert func(...) == ...
    pass

# Generated at 2022-06-26 02:05:51.290699
# Unit test for function islurp
def test_islurp():
    import tempfile

    temp_file = tempfile.NamedTemporaryFile()
    test_text = 'This is a test!\n'
    temp_file.write(test_text.encode('utf-8'))
    temp_file.flush()

    test_islurp_0 = islurp(temp_file.name, mode='r')
    assert(next(test_islurp_0) == test_text)
    test_islurp_0.close()

    test_islurp_1 = islurp(temp_file.name, mode='r')
    assert(next(test_islurp_1) == test_text)
    test_islurp_1.close()


# Generated at 2022-06-26 02:05:56.330895
# Unit test for function islurp
def test_islurp():
    # contents of test.csv
    test_csv = 'a,b,c\n1,2,3\n4,5,6\n'

    # When we read test.csv as a CSV, we get:
    assert (list(islurp('test.csv', iter_by=',', mode='rb')) ==
            ['a,b,c', '1,2,3', '4,5,6'])

    # When we read test.csv as a CSV, we get:
    assert (list(islurp('test.csv', iter_by=',', mode='rb')) ==
            ['a,b,c', '1,2,3', '4,5,6'])

    # When we read test.csv as a line, we get:

# Generated at 2022-06-26 02:06:05.595618
# Unit test for function islurp
def test_islurp():
    assert islurp('testdata/file.0', 'rb', expanduser=False, expandvars=False).next() == b'\xb7X'
    assert islurp('testdata/file.0', 'r', expanduser=False, expandvars=False).next() == b'\xb7X'
    assert islurp('testdata/file.0', 'r', expanduser=False, expandvars=False).next() == '\u25c3\n'
    assert islurp('testdata/file.0').next() == '\u25c3\n'
    assert islurp('-') is not None
    assert islurp('testdata/file.0', 'rb', iter_by=1).next() == b'\xb7'

# Generated at 2022-06-26 02:06:16.691533
# Unit test for function islurp
def test_islurp():
    assert islurp(b'foo') == (
        b''
    )
    assert islurp('foo') == (
        ''
    )
    assert not islurp(b'foo') == (
        ''
    )
    assert islurp('foo') == (
        b''
    )
    assert islurp(b'foo') == (
        ''
    )
    assert not islurp(b'foo') == (
        '', '\n'
    )
    assert islurp('foo', 'rb') == (
        b''
    )
    assert not islurp('foo', 'rb') == (
        '', '\n'
    )
    assert not islurp(b'foo', b'rb') == (
        b''
    )

# Generated at 2022-06-26 02:06:18.272401
# Unit test for function burp
def test_burp():
    test_case_0()


# Generated at 2022-06-26 02:06:24.582586
# Unit test for function islurp

# Generated at 2022-06-26 02:06:33.639710
# Unit test for function islurp
def test_islurp():
    assert islurp("testfile.txt",mode='r') == islurp("testfile.txt",mode='r')
    assert islurp("testfile.txt",mode='r') == islurp("testfile.txt",mode='r')
    assert islurp("testfile.txt",mode='r') == islurp("testfile.txt",mode='r')
    assert islurp("testfile.txt",mode='r') == islurp("testfile.txt",mode='r')


# Generated at 2022-06-26 02:06:35.613834
# Unit test for function islurp
def test_islurp():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:06:37.486252
# Unit test for function islurp
def test_islurp():
    assert True


# Generated at 2022-06-26 02:06:49.675040
# Unit test for function burp
def test_burp():
    test_case_0()

# Generated at 2022-06-26 02:06:54.142958
# Unit test for function burp
def test_burp():
    try:
        test_case_0()
    except:
        print('Test case 0 failed.')


if __name__ == '__main__':
    test_burp()

# Generated at 2022-06-26 02:06:57.355019
# Unit test for function islurp
def test_islurp():
    assert len(list(islurp('/dev/null', 'rb', iter_by=1))) == 0
    assert len(list(islurp('/dev/random', 'rb', iter_by=1))) == 0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:07:02.400685
# Unit test for function islurp
def test_islurp():
    assert islurp('~/examples/src/main.py', mode='r')
    assert slurp('~/examples/src/main.py', mode='r')



# Generated at 2022-06-26 02:07:06.020108
# Unit test for function burp
def test_burp():
    bytes_0 = b'\xb7X'
    int_0 = -4103
    var_0 = burp(bytes_0, int_0)
    assert var_0 == 1


# Generated at 2022-06-26 02:07:15.620845
# Unit test for function islurp
def test_islurp():
    fname = "file.txt"
    fmode = "w+"
    fdata = "foo bar\n"
    with open(fname, fmode) as fh:
        fh.write(fdata)

    with open(fname, fmode) as rh:
        for f in islurp(fname):
            assert f == fdata

if __name__ == '__main__':
    test_case_0()
    test_islurp()

# Generated at 2022-06-26 02:07:27.637346
# Unit test for function islurp
def test_islurp():
    """
    Test islurp function.
    """
    # Test to ensure that the function generates an iterator
    assert iter(islurp('test_data.txt'))

    # Test to ensure that the expected output can be generated using the slurp function
    assert list(islurp('test_data.txt')) == list(slurp('test_data.txt'))

    # Test to ensure no errors are thrown when the expanduser option is active
    assert list(islurp('~/test_data.txt', expanduser=True)) == list(islurp('~/test_data.txt', expanduser=False))

    # Test to ensure no errors are thrown when the expandvars option is active

# Generated at 2022-06-26 02:07:35.677418
# Unit test for function burp
def test_burp():
    filename = '~/foo.txt'
    contents = 'Hello world!'

    burp(filename, contents, expanduser=True)

    data = slurp(filename)
    assert data == 'Hello world!', 'Data written to file mismatch.'

    burp(filename, contents, allow_stdout=True)
    assert data == contents, 'Stdout failed.'

# Generated at 2022-06-26 02:07:44.694792
# Unit test for function islurp
def test_islurp():
    global LINEMODE
    islurp.LINEMODE = 0
    global LINEMODE
    LINEMODE = 0

    assert(islurp("-") is not None)
    assert(islurp("-") is not None)
    assert(islurp("-") is not None)
    assert(islurp("-") is not None)
    assert(islurp("-") is not None)
    assert(islurp("-") is not None)
    assert(islurp("-") is not None)
    assert(islurp("-") is not None)
    assert(islurp("-") is not None)
    assert(islurp("-") is not None)
    assert(islurp("-") is not None)
    assert(islurp("-") is not None)


# Generated at 2022-06-26 02:07:57.553304
# Unit test for function islurp
def test_islurp():
    assert islurp.__doc__

    # test:
    # Example:
    # 
    # >>> for line in islurp('/etc/passwd'):
    # ...   print line.split(':')[0]
    # ...
    # root
    # bin
    # daemon
    # adm
    # ...
    # ...

    # test:
    # Example:
    # 
    # >>> for chunk in islurp('/etc/passwd', iter_by=32):
    # ...   print chunk
    # ... 
    # root:x:0:0:root:/root:/bin/bash
    # 
    # bin:x:1:1:bin:/bin:/sbin/nologin
    # 
    # daemon:x:2:2:daemon:/sbin

# Generated at 2022-06-26 02:09:42.892806
# Unit test for function islurp
def test_islurp():
    filename = 'VERSION'
    mode = 'r'
    iter_by = LINEMODE
    allow_stdin = None
    expanduser = True
    expandvars = True

    version = slurp(filename, mode=mode, iter_by=iter_by, allow_stdin=allow_stdin, expanduser=expanduser, expandvars=expandvars)
    t = [ln for ln in version]
    if t[0].strip() != '0.2.4':
        raise AssertionError('islurp failed')
    print('OK HEAD')

    version = slurp(filename, mode=mode, iter_by=iter_by, allow_stdin=allow_stdin, expanduser=expanduser, expandvars=expandvars)
    t = [ln for ln in version]


# Generated at 2022-06-26 02:09:53.337314
# Unit test for function islurp
def test_islurp():
    bytes_0 = b'\xb7X'
    var_0 = islurp(bytes_0)
    assert repr(var_0) == "<generator object islurp at 0x7faf7aeea9e8>"
    bytes_1 = b'\x00'
    var_1 = islurp(bytes_1)
    assert repr(var_1) == "<generator object islurp at 0x7faf7aeea9e8>"
    bytes_2 = b'\xad\x0c\x0e'
    var_2 = islurp(bytes_2)
    assert repr(var_2) == "<generator object islurp at 0x7faf7aeea9e8>"

# Generated at 2022-06-26 02:10:01.294749
# Unit test for function islurp
def test_islurp():
    input_filename = 'input.txt'
    expected_output = 'Hello'

    with open(input_filename, 'w') as f:
        f.write(expected_output)

    output = ''
    for line in islurp(input_filename):
        output += line
    
    assert output == expected_output, "Unit test failed."


# Generated at 2022-06-26 02:10:11.267792
# Unit test for function islurp
def test_islurp():
    filename = b'./islurp.txt'
    burp(filename, b'1\n2\n3\n4\n5\n')
    test_result = []
    for line in islurp(filename):
        test_result.append(int(line))

    assert len(test_result) == 5
    assert test_result[0] == 1
    assert test_result[1] == 2
    assert test_result[2] == 3
    assert test_result[3] == 4
    assert test_result[4] == 5



# Generated at 2022-06-26 02:10:22.991321
# Unit test for function islurp
def test_islurp():
    # Make sure islurp works with all good arguments
    file_name = "test_file"
    test_data = "hello world!"
    with open(file_name, 'w') as file_obj:
        file_obj.write(test_data)
        file_obj.flush()

    slurped_data = []
    for val in islurp(file_name, 'r', LINEMODE, False, False, False):
        slurped_data.append(val)
    assert len(slurped_data) == 1
    assert slurped_data[0] == test_data

    # Test islurp with invalid args

# Generated at 2022-06-26 02:10:28.320676
# Unit test for function islurp
def test_islurp():
    # test for no-op
    # test for value of file
    assert(slurp('/bin/bash', LINEMODE) == '#!/bin/bash')
    # test for value of file
    assert(slurp('/etc/passwd', LINEMODE) == 'root:x:0:0:root:/root:/bin/bash')
    # test for value of file

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == '--pydoc':
        help(__name__)
    else:
        # test_isdigit()
        test_islurp()

# Generated at 2022-06-26 02:10:36.180842
# Unit test for function islurp
def test_islurp():

    assert list(islurp('/etc/passwd', 'rb', 1))[0] == b'\n'
    assert list(islurp('/etc/passwd', 'rb', 10))[0] == b'\n'
    assert list(islurp('/etc/passwd', 'rb', 100))[0] == b'\n'
    assert list(islurp('/etc/passwd', 'rb', 1000))[0] == b'\n'

    assert list(islurp('/etc/passwd', 'r', LINEMODE))[0] == '\n'
    assert list(islurp('/etc/passwd', 'r', 1))[0] == b'\n'
    assert list(islurp('/etc/passwd', 'r', 10))[0] == b

# Generated at 2022-06-26 02:10:45.182804
# Unit test for function burp
def test_burp():
    # Print test header
    print("\n--- Test burp ---")

    # Test case 0
    print("\nTest case 0")

    assert test_case_0() is None
    # Test case 1
    print("\nTest case 1")
    assert burp("test.txt", "Hello, World!") is None
    # Test case 2
    print("\nTest case 2")

    assert burp("test.txt", "Hello, World again!") is None
    # Test case 3
    print("\nTest case 3")
    assert burp("test.txt", "Hello, World again again!") is None



# Generated at 2022-06-26 02:10:56.703170
# Unit test for function islurp
def test_islurp():
    bytes_0 = b'\xb7X'
    int_0 = -4103
    int_1 = 28
    int_2 = 0
    lines_0 = []
    str_0 = "slurp_file.txt"
    str_1 = ""
    str_2 = ""
    str_3 = ""
    str_4 = ""
    for line_0 in islurp(str_0, iter_by=int_2):
        lines_0.append(line_0)
    for int_0 in range(int_1, 0, int_1):
        if int_0 < int_0:
            str_1 = str(int_0)
        str_2 = lines_0[int_0]
        str_3 = lines_0[int_0]
        str_4 = lines_

# Generated at 2022-06-26 02:11:07.349404
# Unit test for function islurp
def test_islurp():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        filename = '{}/test.txt'.format(tmpdirname)
        with open(filename, 'w') as fh:
            fh.write('1\n2\n3\n')

    assert islurp(filename) == ['1\n', '2\n', '3\n']
    assert [x for x in islurp(filename)] == ['1\n', '2\n', '3\n']
    assert islurp(filename, iter_by=1) == [b'1\n', b'2\n', b'3\n']

    # TODO: Can't get slurp to work with stdin
    #slurp('-', '1\n2\n3\n')
   