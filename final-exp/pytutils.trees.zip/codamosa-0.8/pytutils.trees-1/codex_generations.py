

# Generated at 2022-06-12 08:20:10.530511
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree_fixture, 'qux:quux') == 'corge'
    assert get_tree_node(tree_fixture, 'qux') == {'quux': 'corge'}
    assert get_tree_node(tree_fixture, 'foo:bar:baz') == 'qwerty'
    assert get_tree_node(tree_fixture, 'foo:bar') == {'baz': 'qwerty'}
    assert get_tree_node(tree_fixture, 'foo:bar:baz', parent=True) == {'baz': 'qwerty'}
    assert get_tree_node(tree_fixture, 'foo:bar:baz', default=None) is None

# Generated at 2022-06-12 08:20:16.564806
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': 'b',
        'c': {
            'a': 'b'
        }
    }
    assert get_tree_node(tree, 'a') == 'b'
    assert get_tree_node(tree, 'c:a') == 'b'
    assert get_tree_node(tree, 'c:a:b') == _sentinel
    assert get_tree_node(tree, 'q') == _sentinel
    assert get_tree_node(tree, 'q', default='w') == 'w'



# Generated at 2022-06-12 08:20:19.204043
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, 'a:b:c', 'd')
    assert a['a']['b']['c'] == 'd'



# Generated at 2022-06-12 08:20:30.595102
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 3,
            'foobar': 3
        },
        'bar': 'BAR'
    }

    assert get_tree_node(mapping, 'bar') == 'BAR'
    assert get_tree_node(mapping, 'foo:bar') == 3
    assert get_tree_node(mapping, 'foo:foobar') == 3
    assert get_tree_node(mapping, 'foo:bar') == 3
    assert get_tree_node(mapping, 'foo:bar', default=None) == 3
    assert get_tree_node(mapping, 'foo:baz', default=None) is None
    assert get_tree_node(mapping, 'foo:baz')[0] == 3



# Generated at 2022-06-12 08:20:38.457649
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': 1, 'd': 2}}, 'e': 3}
    node = get_tree_node(mapping, 'a:b:c')
    assert node == 1
    mapping = {'a': {'b': {'c': 1, 'd': 2}}, 'e': 3}
    node = get_tree_node(mapping, 'a:b')
    assert node == {'c': 1, 'd': 2}
    mapping = {'a': {'b': {'c': 1, 'd': 2}}, 'e': 3}
    node = get_tree_node(mapping, 'a:b:c:d')
    assert node is _sentinel



# Generated at 2022-06-12 08:20:42.585931
# Unit test for function get_tree_node
def test_get_tree_node():
    sample_dict = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(sample_dict, 'a:b:c') == 'd'
    # Todo: Test default



# Generated at 2022-06-12 08:20:46.887138
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(tree, key='a:b:c') == 'd'
    assert get_tree_node(tree, key='a:b:c', parent=True) == {'c': 'd'}



# Generated at 2022-06-12 08:20:56.206160
# Unit test for function get_tree_node
def test_get_tree_node():
    # Simple examples
    assert get_tree_node({'a': 1}, 'a') == 1
    assert get_tree_node({'a': {'b': 1}}, 'a:b') == 1

    # Multiple colons
    assert get_tree_node({'a': {'b': 1}}, 'a:b') == 1
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c') == 1

    # Complicated examples
    assert get_tree_node({'a': {'b': [1, 2, 3, 4]}}, 'a:b:0') == 1
    assert get_tree_node({'a': {'b': [1, 2, 3, 4]}}, 'a:b:1') == 2

# Generated at 2022-06-12 08:21:00.433522
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    d = {}
    set_tree_node(d, 'a:b:c', 'value')
    assert d == {'a': {'b': {'c': 'value'}}}



# Generated at 2022-06-12 08:21:10.319467
# Unit test for function get_tree_node
def test_get_tree_node():

    root = tree()

    root['a']['x'] = 'x'
    root['a']['b']['c']['d']['e']['f']['g']['h']['i'] = 'i'
    root['a']['k'] = 'k'
    root['a']['l'] = 'l'

    assert get_tree_node(root, 'a') == {
        'x': 'x', 'k': 'k', 'l': 'l', 'b':
        {'c': {'d': {'e': {'f': {'g': {'h': {'i': 'i'}}}}}}}
    }

# Generated at 2022-06-12 08:21:22.406398
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_dict = {}
    set_tree_node(tree_dict, 'a:b:c', 'd')
    assert tree_dict['a']['b']['c'] == 'd'

    tree_dict = {}
    set_tree_node(tree_dict, 'a:b:c', 'd')
    set_tree_node(tree_dict, 'a:b:c:d:e:f', 'g')
    assert tree_dict['a']['b']['c']['d']['e']['f'] == 'g'


# Generated at 2022-06-12 08:21:26.028520
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b') == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c', default=None) == 'd'
    assert get_tree_node(tree, 'a:d:c') is None
    assert get_tree_node(tree, 'a:b:c', parent=True) == {'c': 'd'}


# Unit tests for function set_tree_node

# Generated at 2022-06-12 08:21:32.366834
# Unit test for function set_tree_node
def test_set_tree_node():
    from copy import deepcopy
    test_dict = {'test': {'a': 2}}
    test_set_tree_node = set_tree_node(test_dict, 'test:b', 6)
    assert(test_set_tree_node == {'a': 2, 'b': 6})
    test_deepcopy = deepcopy(test_dict)
    test_set_tree_node2 = set_tree_node(test_deepcopy, 'test:c', {'d': [0, 1, 2]})

# Generated at 2022-06-12 08:21:42.369334
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({
        'one': {
            'two': {
                'three': 'val'
            }
        }
    }, 'one:two:three') == 'val'
    assert get_tree_node({
        'one': {
            'two': {
                'three': 'val'
            }
        }
    }, 'one:two:three:four') == _sentinel
    assert get_tree_node({
        'one': {
            'two': {
                'three': 'val'
            }
        }
    }, 'one:two:three:four', default='nope') == 'nope'

# Generated at 2022-06-12 08:21:52.936971
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test function for set_tree_node"""
    test = {}
    set_tree_node(test, 'baz', 4)
    assert test['baz'] == 4
    set_tree_node(test, 'bar:0', 'b')
    assert test['bar'][0] == 'b'
    set_tree_node(test, 'foo:0:A', 'a')
    set_tree_node(test, 'foo:0:B', 'b')
    set_tree_node(test, 'foo:1:B', 'b')
    set_tree_node(test, 'foo:1:C', 'c')
    assert test['foo'][0]['A'] == 'a'
    assert test['foo'][0]['B'] == 'b'

# Generated at 2022-06-12 08:22:03.482184
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test data
    struct = {
        'A': 'B',
        'C': {
            'D': 'E'
        }
    }

    # Test lookup
    assert get_tree_node(struct, 'A') == 'B'
    assert get_tree_node(struct, 'C:D') == 'E'
    assert get_tree_node(struct, 'C:E') is _sentinel

    # Test default
    assert get_tree_node(struct, 'C:E', default='F') == 'F'
    assert get_tree_node(struct, 'C:E', default='E') is not _sentinel
    assert get_tree_node(struct, 'C:E', default=struct) is struct



# Generated at 2022-06-12 08:22:10.159517
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    set_tree_node(d, 'a:b:c', '1')
    set_tree_node(d, 'a:b:d', '2')
    set_tree_node(d, 'a:e', '3')
    set_tree_node(d, 'f', '4')

    # Expected tree structure:
    # {'a': {'b': {'c': '1', 'd': '2'}, 'e': '3'}, 'f': '4'}
    assert len(d) == 2
    assert d['a']['b']['c'] == '1'
    assert d['a']['b']['d'] == '2'
    assert d['a']['e'] == '3'
    assert d['f'] == '4'

# Generated at 2022-06-12 08:22:20.798982
# Unit test for function get_tree_node
def test_get_tree_node():
    """Testing the function `get_tree_node`."""
    from types import ModuleType
    from contextlib import contextmanager

    @contextmanager
    def _test_get_tree_node_init(key, value, default=_sentinel):
        try:
            tree = {
                'foobar': {
                    'baz': value
                }
            }
            yield tree, key, default
        except KeyError as exc:
            assert default is _sentinel, \
                'Value: %r, %r. Key: %r. Default: %r' % (value, exc, key, default)


# Generated at 2022-06-12 08:22:27.749714
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Confirm that get_tree_node returns expected values for a typical case.
    """
    import pytest

    with pytest.raises(KeyError):
        get_tree_node(tree(), 'i:do:not:exist')

    data = tree()
    data['foo']['bar']['baz'] = 'quux'
    assert get_tree_node(data, 'foo:bar:baz') == 'quux'

# Generated at 2022-06-12 08:22:36.557008
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import raises

    test_dict = {
        'things': {
            'animals': {
                'dogs': {
                    'collies': ['Lassie', 'Benji'],
                    'dnes': ['Shaggy', 'Scooby Doo']
                },
                'cats': ['Garfield', 'Felix the Cat']
            },
            'fruits': ['apple', 'orange']
        }
    }

    assert get_tree_node(test_dict, 'things:animals:dogs:dnes') == ['Shaggy', 'Scooby Doo']
    assert get_tree_node(test_dict, 'things:animals:dogs:dnes', default=list()) == ['Shaggy', 'Scooby Doo']


# Generated at 2022-06-12 08:22:45.778794
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3',
            'key4': 'value4',
        },
    }

    assert get_tree_node(tree, 'key1') == 'value1'
    assert get_tree_node(tree, 'key2:key3') == 'value3'
    assert get_tree_node(tree, 'key2:key3:key3') == None



# Generated at 2022-06-12 08:22:53.982234
# Unit test for function get_tree_node
def test_get_tree_node():
    # test_get_tree_node_success
    data = {
        'a': {
            'b': {
                'c': 1
            }
        }
    }
    assert get_tree_node(data, 'a:b:c') == 1
    assert get_tree_node(data, 'a:b:c', parent=True) == {'c': 1}

    # test_get_tree_node_success_with_default
    assert get_tree_node(data, 'a:b:c:d', default=-1) == -1
    assert get_tree_node(data, 'a:b:c:d', default=-1, parent=True) == {'d': -1}

    # test_get_tree_node_failure
    with pytest.raises(KeyError):
        get

# Generated at 2022-06-12 08:23:05.375225
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    a = {}
    assert set_tree_node(a, 'foo', 0) == {'foo': 0}
    assert a['foo'] == 0
    assert set_tree_node(a, 'foo', 1) == {'foo': 1}
    assert a['foo'] == 1
    assert set_tree_node(a, 'foo:bar', 2) == {'foo': {'bar': 2}}
    assert a['foo']['bar'] == 2
    assert set_tree_node(a, 'foo:baz', 3) == {'foo': {'bar': 2, 'baz': 3}}
    assert a['foo']['bar'] == 2
    assert a['foo']['baz'] == 3

# Generated at 2022-06-12 08:23:13.430619
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c', default='e') == 'd'
    assert get_tree_node(test_tree, 'a:c:c', default='e') == 'e'
    assert get_tree_node(test_tree, 'a:c:c') == _sentinel
    assert get_tree_node(test_tree, 'a:c:c', default='e') == 'e'
    assert get_tree_node(test_tree, 'a:c:c') == _sentinel

    # Ensure __eq__ is

# Generated at 2022-06-12 08:23:18.270579
# Unit test for function get_tree_node
def test_get_tree_node():
    z = {'k1': {'k2': 2}, 'k3': 3, 'k4': 4}
    assert get_tree_node(z, 'k1:k2') == 2
    assert get_tree_node(z, 'k4') == 4
    assert get_tree_node(z, 'k1') == {'k2': 2}
    assert get_tree_node(z, 'k1:k3', default=3) == 3



# Generated at 2022-06-12 08:23:23.055600
# Unit test for function set_tree_node
def test_set_tree_node():
    root = tree()
    set_tree_node(root, 'key', 'value')
    assert get_tree_node(root, 'key') == 'value'
    set_tree_node(root, 'key:next', 'value2')
    assert get_tree_node(root, 'key:next') == 'value2'



# Generated at 2022-06-12 08:23:31.312980
# Unit test for function get_tree_node
def test_get_tree_node():
    from hamcrest import assert_that, has_length, contains, raises, calling, is_, equal_to
    from nose.tools import assert_raises

    # Setup
    mapping = tree()
    mapping['a']['b']['c'] = 'cedwards'
    mapping['a']['b']['c:d'] = 'conan'
    mapping['a']['b']['e'] = 'shooter'
    mapping['a']['b']['e:f'] = 'smith'
    mapping['a']['b']['e:f:g'] = 'secrets'
    mapping['a']['b']['e:f:g:h'] = 'lame'
    mapping['a']['b']['e:f:g:i'] = 'secrets'

# Generated at 2022-06-12 08:23:42.216207
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'items': {
            'item_01': 'item01_value',
            'item_02': {
                'sub_item_01': 'sub_item_01_value',
                'sub_item_02': 'sub_item_02_value',
            },
            'item_03': 'item03_value'
        }
    }

    assert get_tree_node(test_mapping, 'items') == test_mapping['items']
    assert get_tree_node(test_mapping, 'items:item_02') == test_mapping['items']['item_02']
    assert get_tree_node(test_mapping, 'items:item_02:sub_item_01') == 'sub_item_01_value'

# Generated at 2022-06-12 08:23:46.661389
# Unit test for function set_tree_node
def test_set_tree_node():
    mytree = collections.defaultdict(dict)
    set_tree_node(mytree, 'ns:key:value:another', 'foo')
    assert mytree['ns']['key']['value']['another'] == 'foo'

# Generated at 2022-06-12 08:23:49.501036
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c:d', 'this is the value')

    assert tree['a']['b']['c']['d'] == 'this is the value'

# Generated at 2022-06-12 08:24:02.390911
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'A': {
            'A': 1,
            'B': 2,
            'C': 3
        },

        'B': {
            'A': 4,
            'B': 5,
            'C': 6
        }
    }
    assert get_tree_node(mapping, 'A') == {'A': 1, 'B': 2, 'C': 3}
    assert get_tree_node(mapping, 'B') == {'A': 4, 'B': 5, 'C': 6}
    assert get_tree_node(mapping, 'A:A') == 1
    assert get_tree_node(mapping, 'A:B') == 2
    assert get_tree_node(mapping, 'A:C') == 3

# Generated at 2022-06-12 08:24:06.059838
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {
            'b': 1,
            'c': 2,
        },
    }
    assert get_tree_node(d, 'a:b') == 1
    assert get_tree_node(d, 'a:c') == 2



# Generated at 2022-06-12 08:24:14.853030
# Unit test for function get_tree_node
def test_get_tree_node():
    results = get_tree_node({'a': {'b': {'c': 5, 'd': 4}}}, 'a:b:c')
    print('tree node c: ', results)

    results = get_tree_node({'a': {'b': {'c': 5, 'd': 4}}}, 'a:b:d')
    print('tree node d: ', results)

    results = get_tree_node({'a': {'b': {'c': 5, 'd': 4}}}, 'a:b:c:d:e', default=None)
    print('default tree node e: ', results)


test_get_tree_node()

# Generated at 2022-06-12 08:24:21.655024
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a:b:c', 'abc') == {'a': {'b': {'c': 'abc'}}}
    assert set_tree_node({'a': {'b': {'c': 'abc'}}}, 'd:e', 'de') == {'a': {'b': {'c': 'abc'}}, 'd': {'e': 'de'}}



# Generated at 2022-06-12 08:24:26.240314
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['foo']['bar'] = 'ok'
    assert mapping == {'foo': {'bar': 'ok'}}
    assert mapping['foo:bar'] == 'ok'
    assert mapping['foo:bar'] == mapping['foo']['bar']

    # TODO Test the exc stuff...?



# Generated at 2022-06-12 08:24:29.742029
# Unit test for function set_tree_node
def test_set_tree_node():
    d = collections.defaultdict(collections.defaultdict)
    set_tree_node(d, 'socket:emit', lambda: None)
    assert d['socket']['emit']() is None
    assert d['socket']['emit'] is not None



# Generated at 2022-06-12 08:24:35.146290
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {'foo': {'bar': 'woot', 'blah': 'sdfsdfsdfsdf'}, 'other': {'blah': 'whee'}}
    set_tree_node(tree, 'foo:bar:baz', 'abcdef')
    assert(tree['foo']['bar'] == 'abcdef')
    assert(tree['other']['blah'] == 'whee')


# Generated at 2022-06-12 08:24:39.469011
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function `get_tree_node`."""
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert(get_tree_node(tree, 'a:b:c') == 'd')



# Generated at 2022-06-12 08:24:44.503661
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.OrderedDict()
    set_tree_node(mapping, 'a:b:c:d:e:foo', 'bar')
    assert mapping['a']['b']['c']['d']['e']['foo'] == 'bar'



# Generated at 2022-06-12 08:24:53.129452
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': [1,2],
            'c': {'d': 123}
        }
    }

    # Fetch root node `a`
    assert get_tree_node(tree, 'a') == {
        'b': [1,2],
        'c': {'d': 123}
    }

    # Fetch child node `a:b`
    assert get_tree_node(tree, 'a:b') == [1, 2]

    # Fetch grandchild node `a:c:d`
    assert get_tree_node(tree, 'a:c:d') == 123

    # Fetch non-existing node
    with pytest.raises(KeyError):
        get_tree_node(tree, 'z')

    # Fetch non-existing node

# Generated at 2022-06-12 08:25:04.291253
# Unit test for function get_tree_node
def test_get_tree_node():

    mytree = {
        '1': 'a',
        '2': 'b',
        '3': 'c',
        '4': {
            '1': 'd',
            '2': 'e',
            '3': 'f'
        }
    }

    # Test single level
    assert get_tree_node(mytree, '3') == 'c'

    # Test multi level
    assert get_tree_node(mytree, '4:2') == 'e'

    # Test non-existent
    with pytest.raises(KeyError):
        get_tree_node(mytree, '4:4')

    # Test default value
    assert get_tree_node(mytree, '4:4', default='moo') == 'moo'



# Generated at 2022-06-12 08:25:10.199528
# Unit test for function set_tree_node
def test_set_tree_node():
    my_tree = tree()
    set_tree_node(my_tree, 'A:B:C', 'foo')
    set_tree_node(my_tree, 'A:B:D', 'bar')
    assert my_tree['A']['B']['C'] == 'foo'
    assert my_tree['A']['B']['D'] == 'bar'



# Generated at 2022-06-12 08:25:15.856958
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test for set_tree_node"""
    mapping = {}
    set_tree_node(mapping, '0:0:0', 'foo')
    set_tree_node(mapping, '0:1:1', 'bar')
    assert mapping['0']['0']['0'] == 'foo'
    assert mapping['0']['1']['1'] == 'bar'



# Generated at 2022-06-12 08:25:24.273227
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a', 1)
    assert d == {'a': 1}
    set_tree_node(d, 'a:b', 2)
    assert d == {'a': {'b': 2}}
    set_tree_node(d, 'a:b:c', 3)
    assert d == {'a': {'b': {'c': 3}}}
    set_tree_node(d, 'a:c', 4)
    assert d == {'a': {'b': {'c': 3}, 'c': 4}}



# Generated at 2022-06-12 08:25:30.642923
# Unit test for function get_tree_node
def test_get_tree_node():
    _test_tree = {
        'one': 1,
        'two': {
            'two_one': 21,
        },
        'three': {
            'three_one': {
                'three_one_one': 311,
            },
        },
    }

    assert get_tree_node(_test_tree, 'one') == 1
    assert get_tree_node(_test_tree, 'two:two_one') == 21
    assert get_tree_node(_test_tree, 'three:three_one:three_one_one') == 311
    assert get_tree_node(_test_tree, 'three:three_one:three_one_one') == 311

# Generated at 2022-06-12 08:25:37.065670
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': 1,
                },
            },
        },
    }

    assert get_tree_node(mapping, 'a:b:c:d') == 1
    assert get_tree_node(mapping, 'a:b:c:e') is _sentinel

    mapping = tree()
    mapping['a']['b']['c']['d'] = 1

    assert get_tree_node(mapping, 'a:b:c:d') == 1
    assert get_tree_node(mapping, 'a:b:c:e') is _sentinel



# Generated at 2022-06-12 08:25:42.337508
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        'one': {
            'two': 2,
        }
    }
    set_tree_node(mapping, 'one:two', 2)
    set_tree_node(mapping, 'one:two:three', 3)
    assert mapping['one']['two'] == 2
    assert mapping['one']['two']['three'] == 3



# Generated at 2022-06-12 08:25:51.317984
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['a']['b']['c'] = 3
    mapping['a']['d'] = 42
    mapping['e'] = 9001
    assert 42 == get_tree_node(mapping, 'a:d')
    with pytest.raises(KeyError) as exc:
        get_tree_node(mapping, 'a:e')
    assert exc.value.args[0] == 'e'
    assert 9001 == get_tree_node(mapping, 'e')
    assert _sentinel == get_tree_node(mapping, 'a:e', default=_sentinel)

# Generated at 2022-06-12 08:25:57.607933
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'A': {
            'B': {
                'C': 'D'
            }
        }
    }

    assert get_tree_node(mapping, 'A:B') == {'C': 'D'}
    assert get_tree_node(mapping, 'A:B:C') == 'D'
    assert get_tree_node(mapping, 'A:B:C:C') == 'D'



# Generated at 2022-06-12 08:26:02.154329
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test `get_tree_node` function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 42
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 42
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is None



# Generated at 2022-06-12 08:26:14.412924
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = Tree(
        {
            'foo': {
                'bar': {
                    'baz': 42
                },
                'baz': 'foobar'
            }
        }
    )

    assert tree['foo'] == {'bar': {'baz': 42}, 'baz': 'foobar'}
    assert tree['foo:bar'] == {'baz': 42}
    assert tree['foo:bar:baz'] == 42



# Generated at 2022-06-12 08:26:17.007140
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({'a': {'b': 2}}, 'a:b', 3) == {'a': {'b': 3}}


# Generated at 2022-06-12 08:26:23.500725
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'foo': {
            'baz': {
                'a': 1,
                'b': 2,
                'c': 3,
            },
        },
    }
    assert get_tree_node(test_dict, 'foo:baz:a') == 1

    assert get_tree_node(test_dict, 'foo:bar:a', default=None) is None

    assert get_tree_node(test_dict, 'jimmy:butler') == _sentinel

    # Test parent
    assert get_tree_node(test_dict, 'foo:baz:a', parent=True) == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-12 08:26:31.476000
# Unit test for function set_tree_node
def test_set_tree_node():
    obj = tree()
    obj = set_tree_node(obj, 'a:b:c', 1)
    obj = set_tree_node(obj, 'a:b:d', 2)
    obj = set_tree_node(obj, 'a:e:f', 3)
    obj = set_tree_node(obj, 'g', 4)

    assert obj['a']['b']['c'] == 1
    assert obj['a']['b']['d'] == 2
    assert obj['a']['e']['f'] == 3
    assert obj['g'] == 4



# Generated at 2022-06-12 08:26:42.153800
# Unit test for function set_tree_node
def test_set_tree_node():
    # Dict
    d = {}
    set_tree_node(d, 'a:b:c', 'x')
    assert d.get('a').get('b').get('c') == 'x'
    set_tree_node(d, 'a', 'x')
    assert d.get('a') == 'x'
    set_tree_node(d, 'a:b', 'x')
    assert d.get('a').get('b') == 'x'
    set_tree_node(d, 'a', 'x')
    assert d.get('a') == 'x'
    set_tree_node(d, 'a:b', 'x')
    assert d.get('a').get('b') == 'x'

    # Tree
    t = Tree()

# Generated at 2022-06-12 08:26:48.985299
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""

    assert set_tree_node({}, 'a:b:c', 'foo') == {'a': {'b': {'c': 'foo'}}}
    assert set_tree_node({'a': {'b': {'c': 'a'}}}, 'a:b:c', 'foo') == {'a': {'b': {'c': 'foo'}}}



# Generated at 2022-06-12 08:26:54.994920
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = Tree({
        'key1': {
            'key1a': {
                'key1aa': 'value1aa'
            }
        },
        'key2': {
            'key2a': {
                'key2aa': 'value2aa'
            },
            'key2b': {
                'key2ba': 'value2ba'
            }
        }
    })

# Generated at 2022-06-12 08:26:56.877128
# Unit test for function set_tree_node
def test_set_tree_node():
    m = tree()
    set_tree_node(m, 'a:b:c', 'd')
    assert m['a']['b']['c'] == 'd'



# Generated at 2022-06-12 08:26:59.893797
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'hello:world', 'foo')
    assert mapping == {'hello': {'world': 'foo'}}



# Generated at 2022-06-12 08:27:03.228284
# Unit test for function set_tree_node
def test_set_tree_node():
    mytree = tree()
    set_tree_node(mytree, 'foo:bar:baz', 'value')
    assert mytree['foo']['bar']['baz'] == 'value'



# Generated at 2022-06-12 08:27:16.350593
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo', 'bar')
    assert tree == {'foo': 'bar'}
    s

# Generated at 2022-06-12 08:27:23.169885
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': {'baz': 'a'}}}
    assert get_tree_node(mapping, 'foo:bar:baz') == 'a'
    assert get_tree_node(mapping, 'foo:bar') == {'baz': 'a'}
    assert get_tree_node(mapping, 'foo:bar:baz', default='x') == 'a'
    assert get_tree_node(mapping, 'foo:bar:qux', default='x') == 'x'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'a'}


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:27:31.298098
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test function `get_tree_node()`."""
    mapping = {
        'foo': 1,
        'bar': {
            'baz': {
                'qux': 2,
            },
        },
    }

    assert get_tree_node(mapping, 'bar:baz') == {'qux': 2}
    assert get_tree_node(mapping, 'bar:baz:qux') == 2
    assert get_tree_node(mapping, 'bar:baz:notexistant') is _sentinel



# Generated at 2022-06-12 08:27:32.414882
# Unit test for function set_tree_node
def test_set_tree_node():
    abc = tree()
    set_tree_node(abc, 'a:b:c', 'somevalue')
    assert abc['a']['b']['c'] == 'somevalue'



# Generated at 2022-06-12 08:27:35.795218
# Unit test for function set_tree_node
def test_set_tree_node():
    x = dict(a=dict(b=dict(c=dict(d=dict()))))
    set_tree_node(x, 'a:b:c:d:f', 'hello')
    assert x['a']['b']['c']['d']['f'] == 'hello'



# Generated at 2022-06-12 08:27:47.181199
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {'foo': [1, 2, 3], 'bar': {'baz': 42}}
    assert get_tree_node(test_dict, 'foo') == test_dict['foo']
    assert get_tree_node(test_dict, 'bar') == test_dict['bar']
    assert get_tree_node(test_dict, 'bar:baz') == 42
    with pytest.raises(KeyError):
        get_tree_node(test_dict, 'foo:2')
    assert get_tree_node(test_dict, 'foo:2', None) is None
    assert get_tree_node(test_dict, 'baz', None) is None
    with pytest.raises(KeyError):
        get_tree_node(test_dict, 'baz')



# Generated at 2022-06-12 08:27:50.553432
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    assert set_tree_node(d, 'a:b:c', 'd') == d['a']['b']
    assert d['a']['b']['c'] == 'd'



# Generated at 2022-06-12 08:27:56.348220
# Unit test for function get_tree_node
def test_get_tree_node():
    """Function get_tree_node should traverse a dict tree and return the appropriate value"""
    t = {
        'a': {
            'b': {
                'c': 'hi'
            }
        }
    }
    assert get_tree_node(t, 'a:b:c') == 'hi'



# Generated at 2022-06-12 08:28:06.915171
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(dict)
    key_path = 'foo:bar'
    set_tree_node(tree, key_path, 'baz')
    assert tree == {'foo': {'bar': 'baz'}}

    # Test behaviour when overwriting values
    set_tree_node(tree, key_path, 'baz')
    assert tree == {'foo': {'bar': 'baz'}}


if __name__ == '__main__':
    test_set_tree_node()


# TODO Separate nested dict from flattening + key prefixes
# TODO Make work like collections.Mapping

# Generated at 2022-06-12 08:28:16.025219
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_node_test_dict = {
        'level_1': {
            'level_1_1': {
                'level_1_1_1': 1,
            },
            'level_1_2': 2,
        },
        'level_2': {
            'level_2_1': 3,
        },
    }

    # Test fetching tree node via full path
    gathered_node = get_tree_node(tree_node_test_dict, 'level_1:level_1_1:level_1_1_1')
    assert gathered_node == 1

    # Test fetching tree node via partial path
    gathered_node = get_tree_node(tree_node_test_dict, ':level_1:level_1_1:')

# Generated at 2022-06-12 08:28:50.706373
# Unit test for function get_tree_node
def test_get_tree_node():
    test = {
        'a': {
            'b': {
                'c': 1
            },
            'd': 2
        }
    }
    assert get_tree_node(test, 'a:b:c') == 1
    assert get_tree_node(test, 'a:d') == 2
    assert get_tree_node(test, 'a:b:c') == 1
    assert get_tree_node(test, 'a:b:c', parent=True) == {'c': 1}
    assert get_tree_node(test, 'a:d', parent=True) == {'d': 2}



# Generated at 2022-06-12 08:29:00.050294
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {'depth0': {'depth1': {'depth2': {'depth3': {'depth4': {'depth5': 'Hello World'}}}}}}

    assert get_tree_node(data, 'depth0:depth1:depth2:depth3:depth4:depth5') == 'Hello World'
    assert get_tree_node(data, 'depth0:depth1:depth2:depth3:depth4', parent=True) == {'depth5': 'Hello World'}
    assert get_tree_node(data, 'depth0:depth1:depth2:depth3:depth4:depth5:depth6', default=None) is None



# Generated at 2022-06-12 08:29:09.670565
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {
            'b': {
                'c': 'd'
            },
            'e': 'f'
        }
    }

    assert get_tree_node(d, 'a:e') == 'f'
    assert get_tree_node(d, 'a:e', 'g') == 'f'
    assert get_tree_node(d, 'a:e', 'g', parent=True) == {'b': {'c': 'd'}, 'e': 'f'}

    with pytest.raises(KeyError):
        get_tree_node(d, 'a:x')
    with pytest.raises(KeyError):
        get_tree_node(d, 'x:y')


# Generated at 2022-06-12 08:29:16.987118
# Unit test for function get_tree_node
def test_get_tree_node():
    from copy import deepcopy
    from .utils import TestCase

    class Test(TestCase):

        def setUp(self):
            super(Test, self).setUp()
            self.data = tree()
            self.data[':1'] = {':2': {':3': 1}}

        def test_get_from_simple_tree(self):
            self.assertEquals(get_tree_node(self.data, ':1'),
                              self.data[':1'])

        def test_get_from_simple_tree_with_colon(self):
            self.assertEquals(get_tree_node(self.data, ':1:2:3'),
                              self.data[':1'][':2'][':3'])


# Generated at 2022-06-12 08:29:25.728650
# Unit test for function set_tree_node
def test_set_tree_node():
    # Initialize a tree
    tree = collections.defaultdict(dict)

    # Set some values
    set_tree_node(tree, 'foo:bar:baz', 1)
    set_tree_node(tree, 'foo:bar:qux', 2)
    set_tree_node(tree, 'foo:bar:qux', 3)
    set_tree_node(tree, 'foo:bar:quux', 4)

    # The tree should look like this:
    # tree
    #     ['foo']
    #         ['bar']
    #             ['baz'] == 1
    #             ['qux'] == 3
    #             ['quux'] == 4

    assert tree['foo']['bar']['baz'] == 1



# Generated at 2022-06-12 08:29:32.334612
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:d') is _sentinel

    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default=None) == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:d', default=None) is None



# Generated at 2022-06-12 08:29:40.691937
# Unit test for function get_tree_node
def test_get_tree_node():
    # Basic usecases:
    tree = {'foo': 'bar'}
    assert get_tree_node(tree, 'foo') == 'bar'
    # Traversing:
    tree = {'foo': {'bar': 'baz'}}
    assert get_tree_node(tree, 'foo:bar') == 'baz'
    # With default:
    assert get_tree_node(tree, 'foo:nothing', default=None) is None
    # Without default:
    with pytest.raises(KeyError):
        get_tree_node(tree, 'foo:nothing')
    # With parent:
    assert get_tree_node(tree, 'foo:bar', parent=True) == tree['foo']
    # Works with list:
    tree = {'foo': ['bar']}
    assert get_tree_

# Generated at 2022-06-12 08:29:51.185251
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'foobarbaz')
    assert tree['foo']['bar']['baz'] == 'foobarbaz'
    set_tree_node(tree, 'foo:bar:baz', 'foobarbaz_update')
    assert tree['foo']['bar']['baz'] == 'foobarbaz_update'
    set_tree_node(tree, 'bar:baz:foo', 'barbazfoo')
    assert tree['bar']['baz']['foo'] == 'barbazfoo'
    set_tree_node(tree, 'blubb:blabla', 'blubbblabla')
    assert tree['blubb']['blabla'] == 'blubbblabla'


#

# Generated at 2022-06-12 08:29:54.298962
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    test_data = {'node': 'parent', 'child_node': 'child'}
    for key, value in test_data.items():
        set_tree_node(mapping, key, value)
    assert mapping == test_data



# Generated at 2022-06-12 08:30:04.307053
# Unit test for function get_tree_node