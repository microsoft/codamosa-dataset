

# Generated at 2022-06-12 08:20:04.771795
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': {'baz': 'abc'}}}, 'foo') == {'bar': {'baz': 'abc'}}
    assert get_tree_node({'foo': {'bar': {'baz': 'abc'}}}, 'foo:bar') == {'baz': 'abc'}
    assert get_tree_node({'foo': {'bar': {'baz': 'abc'}}}, 'foo:bar:baz') == 'abc'

# Generated at 2022-06-12 08:20:10.782577
# Unit test for function get_tree_node
def test_get_tree_node():
    # Unit test for function get_tree_node
    data = {
        'a': {'x': 1, 'y': 2},
        'b': {'x': 3, 'y': 4},
    }
    assert get_tree_node(data, 'a') == {'x': 1, 'y': 2}
    assert get_tree_node(data, 'b:x') == 3
    assert get_tree_node(data, 'b:y') == 4
    assert get_tree_node(data, 'b', None) == {'x': 3, 'y': 4}

    assert get_tree_node(data, 'c:x', default=None) is None



# Generated at 2022-06-12 08:20:16.745938
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {
        '1': {
            '2': {
                '3': {
                    '4': {
                        '5': 'test'
                    }
                }
            }
        }
    }
    res = set_tree_node(d, '1:2:3:4:5', 'THIS IS TEST STRING')
    assert d['1']['2']['3']['4']['5'] == 'THIS IS TEST STRING'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:20:27.786304
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equal
    test_tree = {
        'foo': 1,
        'bar': {
            'baz': 2,
            'qux': {
                'quux': 3,
                'corge': {
                    'grault': 4,
                },
            },
        },
    }

    assert_equal(get_tree_node(test_tree, 'foo'), 1)
    assert_equal(get_tree_node(test_tree, 'bar:baz'), 2)
    assert_equal(get_tree_node(test_tree, 'bar:qux:quux'), 3)
    assert_equal(get_tree_node(test_tree, 'bar:qux:corge:grault'), 4)

# Generated at 2022-06-12 08:20:37.210443
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function `get_tree_node`.
    """
    tree = {
        'people': {
            'admins': {
                'names': ["Mr. X", "Ms. Y"],
                'sexes': ['m', 'f'],
            },
            'regulars': {
                'names': ["Person One", "Person Two"],
                'sexes': ['m', 'f'],
            },
        }
    }

    assert get_tree_node(tree, 'people:admins:names') == ["Mr. X", "Ms. Y"]
    assert get_tree_node(tree, 'people:admins:names:0') == "Mr. X"
    assert get_tree_node(tree, 'people:admins:names:1') == "Ms. Y"
    assert get_tree

# Generated at 2022-06-12 08:20:47.235388
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'hi!',
            },
            'b2': {
                'c': 'hi!'
            }
        }
    }

    assert get_tree_node(tree, 'a:b:c') == 'hi!'
    assert get_tree_node(tree, 'a:b:c', 10) == 'hi!'
    assert get_tree_node(tree, 'a:b2:c', 10) == 'hi!'
    assert get_tree_node(tree, 'a:b2:c', default=11) == 'hi!'
    assert get_tree_node(tree, 'a:b2:d', default=11) == 11


# Generated at 2022-06-12 08:20:52.555279
# Unit test for function get_tree_node
def test_get_tree_node():
    mytree = {'a': {'b': {'c': 3}}}
    assert get_tree_node(mytree, 'a:b:c') == 3
    assert get_tree_node(mytree, 'a:b') == {'c': 3}
    assert get_tree_node(mytree, 'c:b:a', default=None) is None



# Generated at 2022-06-12 08:20:56.076783
# Unit test for function get_tree_node
def test_get_tree_node():
    test = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test, 'a:b:c') == 'd'
    assert get_tree_node(test, 'a:b:c:d') == _sentinel



# Generated at 2022-06-12 08:21:03.013015
# Unit test for function set_tree_node
def test_set_tree_node():
    from pprint import pprint
    d = {}
    d = set_tree_node(d, 'a', 1)
    assert d == {'a': 1}
    d = set_tree_node(d, 'b:c', 2)
    assert d == {'a': 1, 'b': {'c': 2}}
    d = set_tree_node(d, 'do:re:mi', 3)
    assert d == {'a': 1, 'b': {'c': 2}, 'do': {'re': {'mi': 3}}}



# Generated at 2022-06-12 08:21:10.181566
# Unit test for function get_tree_node
def test_get_tree_node():
    mytree = {
        'a': {
            'b': {
                'c': 'd',
                }
            },
        }

    assert get_tree_node(mytree, 'a:b:c') == 'd'
    try:
        get_tree_node(mytree, 'a:b:c:d', default=None)
    except KeyError as exc:
        assert exc.args[0] == 'c:d'
    else:
        assert False



# Generated at 2022-06-12 08:21:18.302254
# Unit test for function set_tree_node
def test_set_tree_node():
    # Setup
    mapping = tree()
    key = 'a:b:c'
    value = 'value'

    # Test
    set_tree_node(mapping, key, value)

    # Validate
    assert mapping['a']['b']['c'] == value



# Generated at 2022-06-12 08:21:21.501399
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'root': {'foo': {'bar': 1}}}
    assert get_tree_node('root:foo:bar') == 1
    assert get_tree_node('root:foo:bar:baz') == None



# Generated at 2022-06-12 08:21:27.800353
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'a': {
            'aa': {
                'aaa': 1,
            },
            'ab': {
                'aba': 0
            },
        }
    }

    assert get_tree_node(test_mapping, 'a') == {'aa': {'aaa': 1}, 'ab': {'aba': 0}}
    assert get_tree_node(test_mapping, 'a:aa') == {'aaa': 1}
    assert get_tree_node(test_mapping, 'a:aa:aaa') == 1
    assert get_tree_node(test_mapping, 'a:ab:aba') == 0

    assert get_tree_node(test_mapping, 'a:ab:aba', parent=True) == {'aba': 0}
    assert get_tree_node

# Generated at 2022-06-12 08:21:29.815046
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': 1}}
    assert get_tree_node(mapping, 'a:b') == 1



# Generated at 2022-06-12 08:21:38.812882
# Unit test for function set_tree_node
def test_set_tree_node():
    from .capture import Captured

    m = {}
    set_tree_node(m, 'a:b:c:d', 'value')
    assert m['a']['b']['c']['d'] == 'value'

    with Captured(streams=['stderr']) as c:
        set_tree_node(m, 'a:b:c:f', 'garbage')
    assert c.stderr == "WARNING:root:WARNING: Key a:b:c:f is not present! Creating it!\n"
    assert m['a']['b']['c']['f'] == 'garbage'



# Generated at 2022-06-12 08:21:45.597054
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Tests
    - That get_tree_node properly fetches tree nodes
    - That get_tree_node properly raises KeyError when node is not found and no default is set
    - That get_tree_node properly returns default value if node is not found and default is set
    """
    structure = {
        'foo': {
            'bar': 'bar-value'
        },
        'baz': 'baz-value'
    }

    assert get_tree_node(structure, 'foo:bar') == 'bar-value'
    assert get_tree_node(structure, 'baz') == 'baz-value'
    assert get_tree_node(structure, 'foo:spam', default='ham') == 'ham'

# Generated at 2022-06-12 08:21:54.405044
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    mapping = {'a': {'b': {'c':'d'}}}
    assert get_tree_node(mapping, 'a') == {'b': {'c':'d'}}
    assert get_tree_node(mapping, 'a:b') == {'c':'d'}
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c':'d'}
    assert get_tree_node(mapping, 'a:b:c', parent=True) == get_tree_node(mapping, 'a:b')

# Generated at 2022-06-12 08:22:05.483564
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Tests for `set_tree_node`.
    """
    test_data = tree()
    test_data = {
        'foo': {
            'bar': {
                'baz': 'bs'
            },
            'biz': {
                'bap': 'bs'
            }
        }
    }

    # Delve down several times
    set_tree_node(test_data, 'foo:bar:baz', 'bs')
    assert test_data['foo']['bar']['baz'] == 'bs'

    # Set at root level
    set_tree_node(test_data, 'root', 'bs')
    assert test_data['root'] == 'bs'

    # Modify an existing value

# Generated at 2022-06-12 08:22:09.570879
# Unit test for function get_tree_node
def test_get_tree_node():
    foo_bar = {'foo': {'bar': 42}}
    assert get_tree_node(foo_bar, 'foo:bar') == 42
    assert get_tree_node(foo_bar, 'foo:bar:foobar') == _sentinel



# Generated at 2022-06-12 08:22:15.609612
# Unit test for function set_tree_node
def test_set_tree_node():
    """Function: set_tree_node"""
    assert set_tree_node({}, 'one:two:three', 'four') == {
        'one': {
            'two': {
                'three': 'four',
            },
        },
    }
    assert set_tree_node({}, 'three', 'four') == {
        'three': 'four',
    }



# Generated at 2022-06-12 08:22:29.703361
# Unit test for function get_tree_node
def test_get_tree_node():
    import json
    import pprint
    from io import open

    with open('test/test.json', 'r') as f:
        test = json.load(f, encoding='utf-8')


# Generated at 2022-06-12 08:22:37.607698
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = Tree()
    assert get_tree_node(mapping, 'unsafe:traverse:me', parent=True) == {'traverse': {}}
    mapping['unsafe:traverse:me'] = 'pikachu'
    assert mapping['unsafe:traverse:me'] == 'pikachu'
    assert get_tree_node(mapping, 'unsafe:traverse:me', parent=True) == {'traverse': {'me': 'pikachu'}}
    assert get_tree_node(mapping, 'unsafe:traverse:me') == 'pikachu'
    assert get_tree_node(mapping, 'unsafe:traverse:me', parent=True) == {'traverse': {'me': 'pikachu'}}

# Generated at 2022-06-12 08:22:44.225968
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['foo']['bar'] = 'test'
    assert get_tree_node(mapping, 'foo:bar') == 'test'
    assert get_tree_node(mapping, 'foo')['bar'] == 'test'
    assert get_tree_node(mapping, 'foo:bar:baz', default='test') == 'test'
    assert get_tree_node(mapping, 'baz:baz', default='test') == 'test'



# Generated at 2022-06-12 08:22:53.235445
# Unit test for function set_tree_node
def test_set_tree_node():
    obj = {}
    set_tree_node(obj, 'key:a:b:c:d', 42)
    assert obj['key']['a']['b']['c']['d'] == 42

    obj = {}
    set_tree_node(obj, 'key2:a:b:c:d', 42)
    assert obj['key2']['a']['b']['c']['d'] == 42

    obj = {}
    set_tree_node(obj, 'key.a.b.c.d', 42)
    assert obj['key']['a']['b']['c']['d'] == 42

    obj = {}
    set_tree_node(obj, 'key.a:b:c.d', 42)

# Generated at 2022-06-12 08:23:05.253790
# Unit test for function get_tree_node
def test_get_tree_node():

    foo = {
        'a': 'b',
        'c': {
            'd': 'e'
        }
    }

    assert(get_tree_node(foo, 'a') == 'b')
    assert(get_tree_node(foo, 'c:d') == 'e')
    assert(get_tree_node(foo, 'c') == {'d': 'e'})
    assert(get_tree_node(foo, 'c:d:e', default='lol') == 'lol')
    assert(get_tree_node(foo, 'c:d:e', default='lol', parent=True) == 'e')
    # TODO assert(get_tree_node(foo, 'c:d:e', parent=True) == {'d': 'e'})

# Generated at 2022-06-12 08:23:09.971684
# Unit test for function set_tree_node
def test_set_tree_node():
    import collections
    a = collections.defaultdict(dict)
    set_tree_node(a, 'foo:bar:baz', 1)
    set_tree_node(a, 'foo:bar:fizz', 2)
    assert a['foo']['bar']['baz'] == 1
    assert a['foo']['bar']['fizz'] == 2



# Generated at 2022-06-12 08:23:15.164400
# Unit test for function set_tree_node
def test_set_tree_node():
    dic = {}
    set_tree_node(dic, "com.example.foo", "bar")
    assert dic.get("com:example:foo") == "bar"
    dic = {}
    set_tree_node(dic, "com.example.foo.bar", "baz")
    assert dic.get("com:example:foo:bar") == "baz"



# Generated at 2022-06-12 08:23:17.631144
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(m, 'a:b:c') == 'd'



# Generated at 2022-06-12 08:23:27.784252
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test for :meth:`get_tree_node`"""
    tree = {
        'key1': {
            'key2': {
                'key3': 'value1'
            },
            'key4': 'value2',
            'key3': 'value3'
        },
        'key2': 'value4'
    }


# Generated at 2022-06-12 08:23:35.964694
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test dictionary
    test_dict = Tree({
        'a': {
            'b': {
                'c': 'd',
                'e': {
                    'f': 'g'
                }
            }
        },
        'h': 'i'
    })

    # Test cases
    assert get_tree_node(test_dict, 'h') == 'i'
    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:e:f') == 'g'
    assert get_tree_node(test_dict, 'a:b:e:g') is _sentinel



# Generated at 2022-06-12 08:23:49.739102
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'top': {
            'middle': {
                'bottom': 'value',
            },
            'shortcut': 'value2',
        },
    }
    assert get_tree_node(mapping, 'top:middle:bottom') == 'value'
    assert get_tree_node(mapping, 'top:shortcut') == 'value2'



# Generated at 2022-06-12 08:24:01.098699
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', 'baz') == {'foo': {'bar': 'baz'}}
    assert set_tree_node({}, 'foo:bar', 'baz') == {'foo': {'bar': 'baz'}}
    assert set_tree_node({'foo': {'bar': 'baz'}}, 'foo:baz', 'baz') == {'foo': {'bar': 'baz', 'baz': 'baz'}}
    assert set_tree_node({'foo': {'bar': 'baz'}}, 'baz:baz', 'baz') == {'foo': {'bar': 'baz'},
                                                                         'baz': {'baz': 'baz'}}




# Generated at 2022-06-12 08:24:05.253389
# Unit test for function set_tree_node
def test_set_tree_node():
    # Setup
    tree = {}
    key = 'foo:bar:baz'
    value = 'foobarbaz'
    # Call
    parent_node = set_tree_node(tree, key, value)
    # Check
    assert parent_node['baz'] == value
    assert tree['foo']['bar'] == parent_node



# Generated at 2022-06-12 08:24:15.045526
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['a'] = 1
    t['b'] = 2

    t['c']['d'] = 33
    t['c']['e'] = 44

    assert get_tree_node(t, 'a', default=None) == 1
    assert get_tree_node(t, 'b', default=None) == 2
    assert get_tree_node(t, 'c:d', default=None) == 33
    assert get_tree_node(t, 'c:e', default=None) == 44
    assert get_tree_node(t, 'd:e', default=None) is None
    assert get_tree_node(t, 'c:d:e', default=None) is None

# Generated at 2022-06-12 08:24:17.925874
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'baz:bar', 'value')
    assert d['baz']['bar'] == 'value'



# Generated at 2022-06-12 08:24:28.549522
# Unit test for function get_tree_node
def test_get_tree_node():
    # Sample data
    data = {
        'key1': 'value1',
        'foo': {
            'bar': 'baz'
        }
    }

    # Raise KeyError if not found
    try:
        get_tree_node(data, 'key2')
        assert False, 'KeyError should have been raised'
    except KeyError:
        pass

    # Default value if not found
    assert get_tree_node(data, 'key2', 'default') == 'default'

    # Return Value at key
    assert get_tree_node(data, 'key1') == 'value1'

    # Return parent node
    assert get_tree_node(data, 'foo:bar', parent=True) == data['foo']

    # Return nested value
    assert get_tree_node(data, 'foo:bar')

# Generated at 2022-06-12 08:24:31.018984
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    >>> test = {}
    >>> set_tree_node(test, "a", 1)
    {'a': 1}
    """



# Generated at 2022-06-12 08:24:39.856850
# Unit test for function get_tree_node
def test_get_tree_node():
    _mapping = tree()

    _mapping['first']['second']['third'] = '4th'

    assert get_tree_node(_mapping, 'first:second:third') == '4th'
    assert get_tree_node(_mapping, 'first:second:third:0') is _sentinel
    assert get_tree_node(_mapping, 'first:second:third:0', _sentinel) is _sentinel
    assert get_tree_node(_mapping, 'first:second:third:0', default='meh') == 'meh'
    assert get_tree_node(_mapping, 'first:second:third:0', default=None) is None



# Generated at 2022-06-12 08:24:45.958880
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'test': {'test2': 'test3'}}
    assert get_tree_node(tree, 'test:test2') == 'test3'
    assert get_tree_node(tree, 'test') == {'test2': 'test3'}
    assert get_tree_node(tree, 'test:test2:test4') is None



# Generated at 2022-06-12 08:24:48.826623
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': dict(b=dict(c='d'))}



# Generated at 2022-06-12 08:25:03.633101
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test for function :function:`set_tree_node`
    """
    mapping = {
        'foo': {
            'bar': 1
        }
    }

    assert set_tree_node(mapping, 'foo:bar', 2)[1] == 2
    assert set_tree_node(mapping, 'foo:bar:baz', 3)['baz'] == 3
    assert set_tree_node(mapping, 'foo:bar:baz:more:deep', 4)['more']['deep'] == 4



# Generated at 2022-06-12 08:25:08.895306
# Unit test for function set_tree_node
def test_set_tree_node():
    """Set a tree node and assert it is set."""
    mapping = {}
    set_tree_node(mapping, 'a:b:c:d:e:f:g', 'foo bar')
    assert mapping['a']['b']['c']['d']['e']['f']['g'] == 'foo bar'



# Generated at 2022-06-12 08:25:20.079688
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    test_data = {
        'a': {'b': {'c': 42}},
        'd': {'e': {'f': 43}}
    }

    assert get_tree_node(test_data, 'a') == {'b': {'c': 42}}, "Simple dimension fetch failed :("
    # TODO: God damn. Redo this shit.
    assert get_tree_node(test_data, 'a:b') == {'c': 42}, "Dimension fetch failed :("
    assert get_tree_node(test_data, 'a:b:c') == 42, "Leaf fetch failed :("

# Generated at 2022-06-12 08:25:26.363769
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = collections.defaultdict(dict)
    tree['c']['b']['a'] = 'test'

    assert get_tree_node(tree, 'c:b:a') == 'test'
    assert get_tree_node(tree, 'c:b:a:d', default='test') == 'test'
    assert get_tree_node(tree, 'c:b:a:d', default='test', parent=True) == tree['c']['b']

    # TODO add tests for set_tree_node



# Generated at 2022-06-12 08:25:36.160990
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'one': '1',
        'two': {
            'three': '3',
        }
    }
    assert get_tree_node(data, 'one') == '1'
    assert get_tree_node(data, 'one:three') is _sentinel
    assert get_tree_node(data, 'two:three') == '3'

    # Test with parent=True
    assert get_tree_node(data, 'two:three', parent=True) == {'three': '3'}

    # Test with default
    assert get_tree_node(data, 'one:three', default='3') == '3'

    # Test with namespace set
    assert get_tree_node(data, 'two:three', namespace='tw') == '3'



# Generated at 2022-06-12 08:25:44.956998
# Unit test for function get_tree_node
def test_get_tree_node():
    mock_tree = tree()
    mock_tree['foo']['bar'] = 1

# Generated at 2022-06-12 08:25:55.988665
# Unit test for function set_tree_node
def test_set_tree_node():
    m = tree()
    try:
        set_tree_node(m, 'a:b:c', 1)
    except KeyError:
        pass
    assert m['a']['b']['c'] == 1
    set_tree_node(m, 'a:b:d', 2)
    assert m['a']['b']['d'] == 2
    set_tree_node(m, 'a:b:f:g:d:e', 5)
    assert m['a']['b']['f']['g']['d']['e'] == 5
    set_tree_node(m, 'a:b:f:g', 3)
    assert m['a']['b']['f']['g'] == 3

# Generated at 2022-06-12 08:26:03.006663
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    data = tree()
    data['a']['b']['c'] = 'd'
    data['e'] = data['a']['b']

    assert get_tree_node(data, 'a:b:c') == 'd'
    assert get_tree_node(data, 'e:c') == 'd'

    assert get_tree_node(data, 'a:b:c:d', default=None) is None

    try:
        get_tree_node(data, 'e:f')
        assert False
    except KeyError:
        pass



# Generated at 2022-06-12 08:26:09.489388
# Unit test for function get_tree_node
def test_get_tree_node():

    fake_mapping = {
        'foo': {
            'bar': 'baz',
            'lulz': {
                'ponies': 'unicorn',
                'tardis': [1, 2, 3]
            }
        }
    }

    assert get_tree_node(fake_mapping, 'foo:bar') == 'baz'
    assert get_tree_node(fake_mapping, 'foo:lulz:tardis') == [1, 2, 3]

# Generated at 2022-06-12 08:26:13.953086
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'key', 'value')
    assert mapping == {'key': 'value'}

    mapping = {}
    set_tree_node(mapping, 'key:subkey', 'value')
    assert mapping == {'key': {'subkey': 'value'}}

    mapping = {'key': {}}
    set_tree_node(mapping, 'key:subkey', 'value')
    assert mapping == {'key': {'subkey': 'value'}}

    mapping = tree()
    set_tree_node(mapping, 'key', 'value')
    assert mapping == {'key': 'value'}

    mapping = tree()
    set_tree_node(mapping, 'key:subkey', 'value')

# Generated at 2022-06-12 08:26:31.936921
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit tests for get_tree_node."""
    mapping = tree()
    mapping['foo']['bar']['baz'] = 'qux'

    # Basic usage
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'

    # Negative tests
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'moo')

    # Default usage
    assert get_tree_node(mapping, 'moo', default='moo') == 'moo'

    # Parent usage
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == mapping['foo']['bar']

# Generated at 2022-06-12 08:26:34.396498
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'a:b:c') == tree()['a']['b']['c']



# Generated at 2022-06-12 08:26:41.876350
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': 'a',
        'b': {'b': 'b'},
        'c': {'d': {'e': 'e'}}
    }
    result = get_tree_node(mapping, 'a')
    assert result == 'a'
    result = get_tree_node(mapping, 'b:b')
    assert result == 'b'
    result = get_tree_node(mapping, 'c:d:e')
    assert result == 'e'



# Generated at 2022-06-12 08:26:52.377790
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit-test for get_tree_node()."""
    data = {
        'one': {
            'two': 'three'
        },
        'four': {
            'five': {
                'six': 'seven'
            }
        }
    }

    assert get_tree_node(data, 'one:two') == 'three'
    assert get_tree_node(data, 'four:five:six') == 'seven'
    assert get_tree_node(data, 'four:five:six', default='egg') == 'seven'
    assert get_tree_node(data, 'one:zwei', default='egg') == 'egg'
    assert get_tree_node(data, 'one', parent=True) == {'two': 'three'}

# Generated at 2022-06-12 08:26:54.697507
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': [1, 2, 3]}}, 'a:b[2]') == 3



# Generated at 2022-06-12 08:27:00.915154
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'parent': {'child': {'grandchild': 'value'}}}
    assert 'value' == get_tree_node(mapping, 'parent:child:grandchild')

    try:
        assert get_tree_node(mapping, 'parent:child:grandchild:greatgrandchild')
        assert False, 'KeyError not raised on invalid key'
    except KeyError:
        assert True



# Generated at 2022-06-12 08:27:07.792414
# Unit test for function get_tree_node
def test_get_tree_node():
    _dict = {
        'foo': [],
        'bar': {
            'baz': 1,
            'bop': {
                'ber': 2,
                'barp': 5,
            }
        }
    }
    assert get_tree_node(_dict, 'foo', default=False) == []
    assert get_tree_node(_dict, 'foo:0') is None
    assert get_tree_node(_dict, 'bar:baz') == 1
    assert get_tree_node(_dict, 'bar:bop:ber') == 2
    assert get_tree_node(_dict, 'bar:bop:ber', default=False) == 2
    assert get_tree_node(_dict, 'bar:bop:bee', default=False) is False

# Generated at 2022-06-12 08:27:16.483385
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for :func:`get_tree_node`."""
    import pytest

    test_tree = tree()
    test_tree['key1'] = 'value1'
    test_tree['key2'] = {'inner': 'value2'}
    assert get_tree_node(test_tree, 'key1') == 'value1'
    assert get_tree_node(test_tree, 'key2') == {'inner': 'value2'}
    assert get_tree_node(test_tree, 'key2:inner') == 'value2'
    assert get_tree_node(test_tree, 'key2:inner:error') == _sentinel
    with pytest.raises(KeyError):
        get_tree_node(test_tree, 'key2:inner:error', _sentinel)
   

# Generated at 2022-06-12 08:27:23.410085
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test getting tree nodes"""
    mapping = Tree()
    mapping['foo'] = 'bar'
    mapping['bar'] = 'bar'
    mapping['foo:bar'] = 'bar'
    mapping['foo:bar:baz'] = 'bar'
    mapping['foo:bar:baz:biff'] = 'bar'
    mapping['foo:bar:baz:biff:bobby'] = 'bar'
    mapping['foo:bar:baz:biff:bobby:blow'] = 'bar'


# Generated at 2022-06-12 08:27:33.932937
# Unit test for function get_tree_node
def test_get_tree_node():
    # Single dimension
    result = get_tree_node({'a': 'b'}, 'a')
    expected = 'b'
    assert expected == result

    # Multi dimension
    result = get_tree_node({'a': {'b': 'c'}}, 'a:b')
    expected = 'c'
    assert expected == result

    # Multi multi dimension
    result = get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c')
    expected = 'd'
    assert expected == result

    # Multi dimension with parent
    result = get_tree_node({'a': {'b': 'c'}}, 'a:b', parent=True)
    expected = {'b': 'c'}
    assert expected == result

    # Multi multi dimension with parent


# Generated at 2022-06-12 08:27:57.503852
# Unit test for function get_tree_node
def test_get_tree_node():
    input_dict = {
        'test': {
            'test2': 'test_value'
        }
    }
    target_output = 'test_value'
    test_output = get_tree_node(input_dict, 'test:test2')
    assert test_output == target_output



# Generated at 2022-06-12 08:28:05.198005
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {'foo': {'bar': {'baz': 'bing'}}}
    assert get_tree_node(test_dict, 'foo') == test_dict['foo']
    assert get_tree_node(test_dict, 'foo:bar') == test_dict['foo']['bar']
    assert get_tree_node(test_dict, 'foo:bar:baz') == test_dict['foo']['bar']['baz']



# Generated at 2022-06-12 08:28:13.712721
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(
        {
            'foo': {1: {2: {3: 4}}}
        },
        'foo:1:2:3',
    ) == 4

    assert get_tree_node(
        {
            'foo': [1, 2, 3]
        },
        'foo:2',
    ) == 3

    assert get_tree_node(
        {
            'foo': [1, 2, 3]
        },
        'foo:4',
        default='nothing',
    ) == 'nothing'

    assert get_tree_node(
        {
            'foo': [1, 2, 3]
        },
        'foo:4',
    ) == 3


# Generated at 2022-06-12 08:28:23.146673
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': 'c'
        }
    }
    # Test for KeyError
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:c')
    # Test for None
    # TODO: Should return None, not default. Should default be sentinel?
    assert get_tree_node(mapping, 'a:b:c', default=None) is _sentinel

    # Test for Sentinel
    assert get_tree_node(mapping, 'a:b') == 'c'
    # Test for Default
    assert get_tree_node(mapping, 'a:c', default=None) is None
    # Test parent=True
    assert get_tree_node(mapping, 'a:b:c', parent=True)

# Generated at 2022-06-12 08:28:31.213953
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {'b': {'c': 'x'}},
    }

    assert get_tree_node(mapping, 'a:b:c') == 'x'
    assert get_tree_node(mapping, 'a:b:c:d:e') == _sentinel

    # Testing method get_tree_node
    tree = RegistryTree()
    tree.update({'a': {'b': {'c': 'x'}}})

    assert tree.get('a:b:c') == 'x'


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:28:40.942546
# Unit test for function get_tree_node

# Generated at 2022-06-12 08:28:51.480998
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b') == {'c': 'd'}
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    # Test it raise
    try:
        get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:f', default=_sentinel)
    except KeyError:
        pass
    else:
        raise Exception("Expected to raise when no default and key not found")
    # Test default value
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:f', default=None) is None

# Generated at 2022-06-12 08:29:00.485986
# Unit test for function get_tree_node
def test_get_tree_node():
    an_tree = collections.OrderedDict([('a', 1), ('b', {'c': {'d': 4}})])
    assert get_tree_node(an_tree, 'a') == 1
    assert get_tree_node(an_tree, 'b:c:d') == 4
    assert get_tree_node(an_tree, 'b:c', default=_sentinel) == {'d': 4}
    with pytest.raises(KeyError):
        get_tree_node(an_tree, 'b:c:e')
    assert get_tree_node(an_tree, 'b:c:e', default=5) == 5



# Generated at 2022-06-12 08:29:08.860697
# Unit test for function get_tree_node
def test_get_tree_node():
    from itertools import count
    tree = collections.defaultdict(tree)
    tree[1][2][3] = 'foo'
    tree[4][5][6] = 'bar'
    tree[7][8][9] = 'baz'
    tree[1][2][10][11] = 'qux'

    assert get_tree_node(tree, ':'.join(map(str, count(1)))) == 'baz'
    assert get_tree_node(tree, ':'.join(map(str, count(1, 2)))) == 'qux'
    assert get_tree_node(tree, '7:8', default=None) == None



# Generated at 2022-06-12 08:29:15.103422
# Unit test for function get_tree_node
def test_get_tree_node():
    my_data = {
        'a': 'b',
        'c': {
            'd': 'e'
        }
    }
    assert get_tree_node(my_data, 'c:d') == 'e'
    assert get_tree_node(my_data, 'a') == 'b'
    with pytest.raises(KeyError):
        get_tree_node(my_data, 'b:c')
    assert get_tree_node(my_data, 'b:c', default='not found') == 'not found'

