

# Generated at 2022-06-12 08:20:06.982005
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'foo')
    set_tree_node(tree, 'a:b:d', 'bar')
    assert tree['a']['b']['c'] == 'foo'
    assert tree['a']['b']['d'] == 'bar'



# Generated at 2022-06-12 08:20:13.652805
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'foo': {
            'bar': {
                'cat': 'meow',
                'bird': 'chirp'
            }
        }
    }

    assert test_dict['foo']['bar']['cat'] == get_tree_node(test_dict, 'foo:bar:cat')
    assert test_dict['foo']['bar']['bird'] == get_tree_node(test_dict, 'foo:bar:bird')


# Generated at 2022-06-12 08:20:22.789598
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data = tree()

    # Simple set by dimension
    set_tree_node(test_data, 'a:b:c', 'foo')
    assert test_data['a']['b']['c'] == 'foo'

    # Ensure overwriting works
    set_tree_node(test_data, 'a:b:c', 'bar')
    assert test_data['a']['b']['c'] == 'bar'

    # Ensure overwriting works via get
    assert get_tree_node(test_data, 'a:b:c') == 'bar'

    # Ensure list gets index
    set_tree_node(test_data, 'foo:0:bar', 'baz')
    assert test_data['foo'][0]['bar'] == 'baz'

    # Ensure changing the list

# Generated at 2022-06-12 08:20:27.693583
# Unit test for function set_tree_node
def test_set_tree_node():
    x = {}
    set_tree_node(x, 'foo:bar:baz', 'qux')
    assert x == {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }



# Generated at 2022-06-12 08:20:30.730809
# Unit test for function set_tree_node
def test_set_tree_node():
    test_obj = {}
    set_tree_node(test_obj, "key1:key2", "value")
    assert test_obj["key1"]["key2"] == "value"



# Generated at 2022-06-12 08:20:38.283894
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a_key': 'a_value',
        'another': {
            'a_key': 'b_value'
        },
        'another:yet_another': {
            'a_key': 'c_value'
        },
    }

    assert get_tree_node(mapping, 'a_key') == 'a_value'
    assert get_tree_node(mapping, 'another:a_key') == 'b_value'
    assert get_tree_node(mapping, 'another:yet_another:a_key') == 'c_value'
    assert get_tree_node(mapping, 'nothing:here', default='no value') == 'no value'



# Generated at 2022-06-12 08:20:46.014591
# Unit test for function set_tree_node
def test_set_tree_node():
    from nose.tools import assert_equal

    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 42)
    assert_equal(tree['foo']['bar']['baz'], 42)
    set_tree_node(tree, 'bar', {})
    set_tree_node(tree, 'baz', 42)
    assert_equal(tree['baz'], 42)
    set_tree_node(tree, 'bar:baz', 42)
    assert_equal(tree['bar']['baz'], 42)

# Generated at 2022-06-12 08:20:51.445997
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = Tree({
        'foo': {
            'bar': {
                'baz': 'foobarbaz'
            }
        }
    })

    assert tree['foo:bar:baz'] == 'foobarbaz'


if __name__ == '__main__':
    test_get_tree_node()
    sys.exit(0)

# Generated at 2022-06-12 08:20:56.581379
# Unit test for function get_tree_node
def test_get_tree_node():
    t = Tree({'a': {'b': {'c': 'd'}}})
    assert get_tree_node(t, 'a:b:c') == 'd'
    assert get_tree_node(t, 'a', default=None) == {'b': {'c': 'd'}}
    assert get_tree_node(t, 'a:z', default=None) is None
    assert get_tree_node(t, 'a:z') == KeyError



# Generated at 2022-06-12 08:21:04.995808
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for get_tree_node"""
    mapping = {'a': {'aa': {'aaa': 'AAA', 'aab': 'AAB'}, 'ab': {'aba': 'ABA', 'abb': 'ABB'}},
               'b': {'ba': {'baa': 'BAA', 'bab': 'BAB'}, 'bb': {'bba': 'BBA', 'bbb': 'BBB'}}}

    assert get_tree_node(mapping, 'b:bb:bbb') == 'BBB'
    assert get_tree_node(mapping, 'b:bb') == {'bba': 'BBA', 'bbb': 'BBB'}
    assert get_tree_node(mapping, 'b:bb:bbb', 0) == 'BBB'

# Generated at 2022-06-12 08:21:12.985792
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': {
                            'f': 'g'
                        }
                    }
                }
            }
        }
    }

    g = get_tree_node(tree, 'a:b:c:d:e:f')
    assert g == 'g'

    e = get_tree_node(tree, 'a:b:c:d:e', default='h')
    assert e == 'h'

    e = get_tree_node(tree, 'a:b:c:d:e')
    assert isinstance(e, dict)

    c = get_tree_node(tree, 'a:b:c', parent=True)

# Generated at 2022-06-12 08:21:14.784484
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': 1}, 'foo') == 1



# Generated at 2022-06-12 08:21:23.875571
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': {'b': {'c': 'd'}}}
    assert  get_tree_node(d, 'a:b:c') == 'd'
    assert  get_tree_node(d, 'a:b') == {'c': 'd'}
    assert  get_tree_node(d, 'a:b:c:d', default='z') == 'z'
    assert  get_tree_node(d, 'a:b:e', default='z') == 'z'
    assert  get_tree_node(d, 'a:c:e', default='z') == 'z'
    try:
        get_tree_node(d, 'a:b:c:d')
    except Exception:
        assert True

# Generated at 2022-06-12 08:21:27.652953
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(dict(a=1), 'a') == 1
    assert get_tree_node(dict(a=1), 'b', 2) == 2
    with pytest.raises(KeyError):
        get_tree_node(dict(a=1), 'b')

    assert get_tree_node(dict(a=dict(b=1)), 'a') == dict(b=1)
    assert get_tree_node(dict(a=dict(b=1)), 'a:b') == 1
    assert get_tree_node(dict(a=dict(b=1)), 'b', 2) == 2
    with pytest.raises(KeyError):
        get_tree_node(dict(a=dict(b=1)), 'b')
    with pytest.raises(KeyError):
        get

# Generated at 2022-06-12 08:21:33.121725
# Unit test for function set_tree_node
def test_set_tree_node():
    # Create dict
    test_dict = {}

    # Create mapping
    test_mapping = {
        'first': 'thing',
        'second': test_dict
    }

    # Set path for value
    result = set_tree_node(test_mapping, 'second:new', 'thing')
    assert result == test_dict

    # Check result
    assert test_dict == {
        'new': 'thing'
    }



# Generated at 2022-06-12 08:21:42.010356
# Unit test for function set_tree_node
def test_set_tree_node():
    setup = {
        'base': {
            'first': 'one',
            'second': 'two'
        }
    }
    set_tree_node(setup, 'base:fourth', 'four')
    assert setup == {
        'base': {
            'first': 'one',
            'second': 'two',
            'fourth': 'four'
        }
    }, 'failed'
    set_tree_node(setup, 'base:third', 'three')
    assert setup == {
        'base': {
            'first': 'one',
            'second': 'two',
            'third': 'three',
            'fourth': 'four'
        }
    }, 'failed'



# Generated at 2022-06-12 08:21:48.290827
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz'
        }
    }
    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo', 'default') == {
        'bar': 'baz'
    }
    assert get_tree_node(mapping, 'foobar', 'default') == 'default'

# Generated at 2022-06-12 08:21:51.377184
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {'a': {'b': 1}}
    set_tree_node(d, 'a:b', 2)
    assert d['a']['b'] == 2



# Generated at 2022-06-12 08:22:01.204950
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test helper function get_tree_node"""
    mapping = {
        'a': {
            'b': {
                'c': [1, 2, 3]
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == [1, 2, 3]
    assert get_tree_node(mapping, 'a:b:c', default=None) == [1, 2, 3]
    assert get_tree_node(mapping, 'a:b:d', default=None) is None
    assert get_tree_node(mapping, 'a:b:d') is _sentinel



# Generated at 2022-06-12 08:22:08.454680
# Unit test for function set_tree_node
def test_set_tree_node():
    mydict = {}
    set_tree_node(mydict, 'eggs:spam', 42)
    set_tree_node(mydict, 'eggs:more_spam', 'bacon')
    set_tree_node(mydict, 'spam:beans', 'yay')
    set_tree_node(mydict, 'turtles', 'wow')
    assert mydict == {
        'eggs': {
            'spam': 42,
            'more_spam': 'bacon',
        },
        'spam': {
            'beans': 'yay',
        },
        'turtles': 'wow',
    }



# Generated at 2022-06-12 08:22:23.005129
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'works',
            },
            'c': 'as long as a:c is accessed',
        },
        'b': 'as long as b is not',
    }
    assert get_tree_node(test_tree, 'a:b:c') == 'works'
    assert get_tree_node(test_tree, 'a:c') == 'as long as a:c is accessed'
    try:
        get_tree_node(test_tree, 'a:c:b')
        assert False
    except KeyError:
        pass
    assert get_tree_node(test_tree, 'a:c:b', default='You did well') == 'You did well'

# Generated at 2022-06-12 08:22:31.202193
# Unit test for function get_tree_node
def test_get_tree_node():
    # Create a sample tree
    t = {
        'a': [
            {
                'c': 3
            },
            {
                'd': 4
            }
        ],
        'b': [
            {
                'e': 5
            },
            {
                'f': 6
            }
        ],
    }

    # Test getting an item at the root
    assert get_tree_node(t, 'a') == t['a']

    # Test getting an item at a deeper dimension
    assert get_tree_node(t, 'a:0') == t['a'][0]
    assert get_tree_node(t, 'a:1') == t['a'][1]

    # Test getting an item at an even deeper dimension

# Generated at 2022-06-12 08:22:36.729088
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'a': {'b': {'c': {'d': 'e'}}}}
    assert get_tree_node(tree, 'a:b:c:d') == 'e'
    assert get_tree_node(tree, 'a:b:c') == {'d': 'e'}
    assert get_tree_node(tree, 'a:b:c:d:e', default='x') == 'x'
    assert get_tree_node(tree, 'a:b:c:d:e') == _sentinel



# Generated at 2022-06-12 08:22:47.130573
# Unit test for function get_tree_node
def test_get_tree_node():
    from pprint import pprint

    tree = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(tree, 'a:b:c') == 'd', 'get_tree_node isn\'t fetching nested nodes'
    assert get_tree_node(tree, 'a:b:c', parent=True) is tree['a']['b']
    assert get_tree_node(tree, 'a:b:d') is _sentinel, 'get_tree_node isn\'t KeyError\'ing on missing keys'
    assert get_tree_node(tree, 'a:b:d') == 'foo', 'get_tree_node isn\'t correctly defaulting'

# Generated at 2022-06-12 08:22:53.364010
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(test_data, 'a:b:c') == 'd'
    assert get_tree_node(test_data, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_data, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    with pytest.raises(KeyError):
        get_tree_node(test_data, 'a:b:c:d')

# Generated at 2022-06-12 08:22:58.505232
# Unit test for function set_tree_node
def test_set_tree_node():
    root = collections.defaultdict(collections.defaultdict)
    set_tree_node(root, 'foo:bar:baz', 'test')
    if root['foo']['bar']['baz'] != 'test':
        raise ValueError("Failed to set subkey")



# Generated at 2022-06-12 08:23:03.854021
# Unit test for function set_tree_node
def test_set_tree_node():
    import pprint
    data = tree()
    set_tree_node(data, "test:test:test", "value")
    pprint.pprint(data)
    assert get_tree_node(data, "test:test:test") == "value"


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-12 08:23:10.707799
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    print('Running unit test for get_tree_node')
    tree = {
        'a': ['b', 'c'],
        'd': {'e': ['f']}
    }
    print('----')
    print('a:0:1:2:3')
    print(get_tree_node(tree, 'a:0:1:2:3'))
    print('----')
    print('d:e:0')
    print(get_tree_node(tree, 'd:e:0'))



# Generated at 2022-06-12 08:23:18.628142
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'foo': 'bar', 'baz': {'fizz': {'buzz': 'fizzbuzz'}}}
    value = get_tree_node(d, 'baz')
    assert isinstance(value, dict)
    assert value['fizz'].get('buzz') == 'fizzbuzz'

    # Test parent node
    value = get_tree_node(d, 'baz', parent=True)
    assert value == d

    # Test default value
    value = get_tree_node(d, 'fizz', default='default')
    assert value == 'default'

    # Test ValueError!
    with pytest.raises(KeyError):
        get_tree_node(d, 'fizz')



# Generated at 2022-06-12 08:23:28.325316
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'test', 'hello')
    assert tree == {'test': 'hello'}
    set_tree_node(tree, 'a:b', 'hello')
    assert tree == {'test': 'hello', 'a': {'b': 'hello'}}
    set_tree_node(tree, 'abc:def', 'hello')
    assert tree == {'test': 'hello', 'a': {'b': 'hello'}, 'abc': {'def': 'hello'}}
    set_tree_node(tree, 'abc:def:fds', 'hello')
    assert tree == {'test': 'hello', 'a': {'b': 'hello'}, 'abc': {'def': {'fds': 'hello'}}}



# Generated at 2022-06-12 08:23:40.935442
# Unit test for function set_tree_node
def test_set_tree_node():
    h = {'age': {'name': 'age'}}
    assert set_tree_node(h, 'age:name', 'm') is {'name': 'm'}
    assert h == {'age': {'name': 'm'}}



# Generated at 2022-06-12 08:23:50.521567
# Unit test for function set_tree_node
def test_set_tree_node():
    # TODO use pytest
    d = {}
    set_tree_node(d, 'foo:bar:baz', 'blerg')

    assert d == {'foo': {'bar': {'baz': 'blerg'}}}

    set_tree_node(d, 'foo:bar:moo', 'blarg')
    assert d == {'foo': {'bar': {'baz': 'blerg', 'moo': 'blarg'}}}

    set_tree_node(d, 'foo:bar2:moo', 'blarg')
    assert d == {'foo': {'bar': {'baz': 'blerg', 'moo': 'blarg'}, 'bar2': {'moo': 'blarg'}}}

# Generated at 2022-06-12 08:24:01.959745
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 1,
                'd': 2,
            },
            'e': {
                'f': 3,
            },
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 1
    assert get_tree_node(mapping, 'a:i:j', default=False) is False
    assert get_tree_node(mapping, 'a:i:j', default=_sentinel) is _sentinel
    assert get_tree_node(mapping, 'a:e:f') == 3
    assert get_tree_node(mapping, 'a:e:f', parent=True) == {'f': 3}

    with pytest.raises(KeyError):
        assert get_tree

# Generated at 2022-06-12 08:24:09.735309
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b:c') == _sentinel

    assert get_tree_node({'a': {'b': 'c'}}, 'a:b:c', default='d') == 'd'

    with pytest.raises(KeyError):
        get_tree_node({'a': {'b': 'c'}}, 'a:b:c')



# Generated at 2022-06-12 08:24:15.598061
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for get_tree_node.
    """
    mapping = {
        'a': {
            'b': 'c',
        },
    }
    assert get_tree_node(mapping, 'a:b') == 'c'
    try:
        get_tree_node(mapping, 'a:b:c')
    except KeyError:
        # Expected KeyError
        pass
    else:
        assert False, 'KeyError expected'



# Generated at 2022-06-12 08:24:23.818095
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test function `set_tree_node`."""
    test_dict = {}
    set_tree_node(test_dict, "a:b:c", 1)
    set_tree_node(test_dict, "a:b:d", 2)
    set_tree_node(test_dict, "a:e:d", 3)

    assert test_dict["a"]["b"]["c"] == 1
    assert test_dict["a"]["b"]["d"] == 2
    assert test_dict["a"]["e"]["d"] == 3



# Generated at 2022-06-12 08:24:32.158590
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c') == 'd'

    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:x', default='z') == 'z'

    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c:e:f', default={}) == {}

    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:x:c:e:f', default=_sentinel) is _sentinel


# Generated at 2022-06-12 08:24:42.898016
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f'
            },
            'g': 'h'
        },
        'i': 'j'
    }
    assert get_tree_node(mapping, 'a:b') == {'c': 'd', 'e': 'f'}
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:e') == 'f'
    assert get_tree_node(mapping, 'a:g') == 'h'
    assert get_tree_node(mapping, 'i') == 'j'


# Generated at 2022-06-12 08:24:47.695831
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'test:1:2:3:4:5', 'hello')
    assert test_dict == {'test': {'1': {'2': {'3': {'4': {'5': 'hello'}}}}}}



# Generated at 2022-06-12 08:24:54.698131
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd',
            },
            'e': 'f',
        },
        'g': 'h',
    }

    assert (
        get_tree_node(tree, 'a:b:c') == 'd'
    )
    assert (
        get_tree_node(tree, 'a:b:c:d') is _sentinel
    )
    assert (
        get_tree_node(tree, 'a:b:c:d', default='j') == 'j'
    )
    assert (
        get_tree_node(tree, 'a:b:c:d', parent=True) == {'c': 'd'}
    )


# Generated at 2022-06-12 08:25:20.390638
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': {'bar': 3}}, 'foo:bar') == 3
    with pytest.raises(KeyError):
        get_tree_node({'foo': 'bar'}, 'baz')
    with pytest.raises(KeyError):
        get_tree_node({'foo': 'bar'}, 'foo:baz')
    assert get_tree_node({'foo': 'bar'}, 'baz', default=None) is None
    assert get_tree_node({'foo': 'bar'}, 'foo:baz', default=None) is None



# Generated at 2022-06-12 08:25:28.581198
# Unit test for function get_tree_node
def test_get_tree_node():
    import pytest
    tree = {'node': {'subnode': 'subnode_value'}}

    # Test getting nested values
    out = get_tree_node(tree, 'node:subnode')
    assert out == 'subnode_value'

    # Test KeyError
    with pytest.raises(KeyError):
        get_tree_node(tree, 'node:subnode:subsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubnode')

    # Test default value
    out = get_tree_node(tree, 'node:subnode:subsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubnode', default='x')
    assert out == 'x'

    # Test parent

# Generated at 2022-06-12 08:25:36.536305
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test basic functionality
    test_tree = {'foo': 'bar'}
    assert get_tree_node(test_tree, 'foo') == 'bar'

    # Test it fails if it's supposed to:
    assert get_tree_node(test_tree, 'baz') is _sentinel

    # Test nested trees
    test_tree['baz'] = {
        'eggs': {
            'ham': 'spam'
        }
    }
    assert get_tree_node(test_tree, 'baz:eggs:ham') == 'spam'
    assert get_tree_node(test_tree, 'baz:eggs') == {'ham': 'spam'}



# Generated at 2022-06-12 08:25:42.106374
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    test_set_tree_node
    """
    a = {}
    set_tree_node(a, 'foo:bar', 'bar')
    assert a['foo']['bar'] == 'bar'

    b = {}
    set_tree_node(b, 'foo', 'bar')
    assert b['foo'] == 'bar'



# Generated at 2022-06-12 08:25:45.560238
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node"""
    tree = {}
    set_tree_node(tree, 'foo:bar:boom', 'value')
    assert tree == {'foo': {'bar': {'boom': 'value'}}}



# Generated at 2022-06-12 08:25:51.317693
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    mapping = {
        'a': {
            'b': {
                'c': 1
            }
        }
    }

    # Test
    assert get_tree_node(mapping, 'a:b:c') == 1
    assert get_tree_node(mapping, 'a:b:c', default=2) == 1
    return True



# Generated at 2022-06-12 08:26:01.010629
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node."""
    from pytest import raises

    tree = {
        'foo': None,
        'bar': {
            'baz': {
                'string': 'unittest'
            }
        }
    }

    assert get_tree_node(tree, 'foo') is None
    assert get_tree_node(tree, 'bar') == {'baz': {'string': 'unittest'}}
    assert get_tree_node(tree, 'bar:baz') == {'string': 'unittest'}
    assert get_tree_node(tree, 'bar:baz:string') == 'unittest'
    with raises(KeyError):
        get_tree_node(tree, 'invalid')

# Generated at 2022-06-12 08:26:07.014151
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': 1,
        'b': 'two',
        'c': {
            1: 44,
            'd': {
                'e': 3
            }
        }
    }
    assert get_tree_node(mapping, 'd') is None
    assert get_tree_node(mapping, 'a') == 1
    assert get_tree_node(mapping, 'b') == 'two'
    assert get_tree_node(mapping, 'c') == {
        1: 44,
        'd': {
            'e': 3
        }
    }
    assert get_tree_node(mapping, 'c:1') == 44
    assert get_tree_node(mapping, 'c:d:e') == 3

# Generated at 2022-06-12 08:26:13.643182
# Unit test for function get_tree_node
def test_get_tree_node():
    test_map = {'foo': {'bar': {'baz': 'qux'}}}
    test_key = 'foo:bar:baz'
    assert get_tree_node(test_map, test_key) == 'qux'

    test_key = 'foo:bar'
    assert get_tree_node(test_map, test_key) == {'baz': 'qux'}



# Generated at 2022-06-12 08:26:22.168993
# Unit test for function get_tree_node
def test_get_tree_node():
    t = Tree()
    t['a'] = 'a'
    t['b:c'] = 'abc'
    t['d:e:f'] = 'def'
    t['d:e:g:h'] = 'defg'
    t['d:i:j'] = 'dij'
    t['k:l:m:n'] = 'klmn'

    assert t['a'] == 'a'
    assert t['b:c'] == 'abc'
    assert t['d:e:f'] == 'def'
    assert t['d:e:g:h'] == 'defg'
    assert t['d:e:g:h'] == 'defg'
    assert t['d:i:j'] == 'dij'
    assert t['k:l:m:n'] == 'klmn'

# Generated at 2022-06-12 08:26:50.743010
# Unit test for function get_tree_node
def test_get_tree_node():
    """Simple unit test for function get_tree_node"""
    t = {'a': {'b': 'c'}}

    x = get_tree_node(t, 'a:b')
    assert x == 'c', x

    x = get_tree_node(t, 'a:b', 'x')
    assert x == 'c', x

    try:
        x = get_tree_node(t, 'a:c')
    except Exception:
        assert True
    else:
        assert False, 'Did not raise KeyError'

    try:
        x = get_tree_node(t, 'a:c', 'x')
    except Exception:
        assert False, 'Raised KeyError'
    assert x == 'x', x


# Generated at 2022-06-12 08:26:54.003317
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    set_tree_node(d, 'a:b:c', 'value')
    assert d['a']['b']['c'] == 'value'



# Generated at 2022-06-12 08:27:03.180972
# Unit test for function get_tree_node
def test_get_tree_node():
    result = get_tree_node({'a': {'a': {'a': 'hello'}}}, 'a:a:a')
    assert result == 'hello'
    result = get_tree_node({'a': 'hello'}, 'a')
    assert result == 'hello'
    result = get_tree_node({'a': {'a': 'hello'}}, 'a:a')
    assert result == 'hello'

    result = get_tree_node({'a': {'a': {'a': 'hello'}}}, 'a:a:a:a')
    assert result is _sentinel



# Generated at 2022-06-12 08:27:12.551344
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'a.b.c': 0}

    # New node, no parent
    set_tree_node(mapping, 'a.b.c', 1)
    assert mapping['a']['b']['c'] == 1
    set_tree_node(mapping, 'a.b.c', 0)

    # New node, existing parent
    set_tree_node(mapping, 'a.b.d', 2)
    assert mapping['a']['b']['d'] == 2
    set_tree_node(mapping, 'a.b.d', 0)

    # New node, new parent
    set_tree_node(mapping, 'a.e.f', 3)
    assert mapping['a']['e']['f'] == 3



# Generated at 2022-06-12 08:27:15.427911
# Unit test for function set_tree_node
def test_set_tree_node():
    test_mapping = {}
    set_tree_node(test_mapping, 'test:child', 'child')
    assert test_mapping.get('test').get('child') == 'child'



# Generated at 2022-06-12 08:27:22.883927
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'foo': {
            'bar': 1,
            'baz': {
                'qux': 2
            },
            'qux': 3,
        }
    }

    assert get_tree_node(test_dict, 'foo:bar') == 1
    assert get_tree_node(test_dict, 'foo:baz:qux') == 2
    assert get_tree_node(test_dict, 'foo:qux') == 3

    try:
        get_tree_node(test_dict, 'foo:nonexistent')
    except KeyError:
        pass
    else:
        raise AssertionError('Get should failed.')

    try:
        get_tree_node(test_dict, 'foo:baz:nonexistent')
    except KeyError:
        pass

# Generated at 2022-06-12 08:27:32.489457
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': 1,
        'b': {
            'c': 2
        }
    }

    assert get_tree_node(mapping, 'a') == 1
    assert get_tree_node(mapping, 'b:c') == 2
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'd')

    # Test default
    assert get_tree_node(mapping, 'd', _sentinel) is _sentinel
    assert get_tree_node(mapping, 'e', 3) == 3

    # Test parent
    assert get_tree_node(mapping, 'b:c', parent=True) == mapping['b']



# Generated at 2022-06-12 08:27:35.293918
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'foo:bar:baz', 'buz')
    assert test_dict['foo']['bar']['baz'] == 'buz'



# Generated at 2022-06-12 08:27:45.056873
# Unit test for function get_tree_node
def test_get_tree_node():
    from unittest import TestCase

    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    class TestMethods(TestCase):
        def test_get_tree_node(self):
            self.assertEqual(get_tree_node(tree, 'a:b:c'), 'd')
            self.assertEqual(get_tree_node(tree, 'a:b:c:d:e:f', default='g'), 'g')
            self.assertEqual(get_tree_node(tree, 'a:b:c', parent=True), {'c': 'd'})

    return TestMethods



# Generated at 2022-06-12 08:27:53.717705
# Unit test for function get_tree_node
def test_get_tree_node():
    my_tree = {'a': {'b': {'c': 'foo'}, 'd': {'e': 'bar'}}}

    value = get_tree_node(my_tree, 'a:b:c')
    assert value == 'foo'

    value = get_tree_node(my_tree, 'a:b:c:d:e')
    assert value is _sentinel

    value = get_tree_node(my_tree, 'a:b:c:d:e', default=None)
    assert value is None

    value = get_tree_node(my_tree, 'a:b:c:d:e', default=False)
    assert value is False

    value = get_tree_node(my_tree, 'a:b', parent=True)

# Generated at 2022-06-12 08:28:44.764691
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test for key that should be two levels
    mapping = {}
    set_tree_node(mapping, 'foo:bar', 'foobar')
    assert mapping['foo']['bar'] == 'foobar'

    # Test for key that should be one level
    mapping = {}
    set_tree_node(mapping, 'foo', 'foobar')
    assert mapping['foo'] == 'foobar'

    # Test for key that should be one level and should raise an error
    mapping = {}
    with pytest.raises(KeyError) as exc:
        set_tree_node(mapping, 'foo:bar', 'foobar')
    assert 'foo' == exc.value.args[0]



# Generated at 2022-06-12 08:28:53.653482
# Unit test for function get_tree_node
def test_get_tree_node():
    import json
    import os
    import pkg_resources
    with open(pkg_resources.resource_filename(__name__, './test_tree.json'), 'r') as f:
        mapping = json.loads(f.read())

    assert get_tree_node(mapping, 'key') == 'value'
    assert get_tree_node(mapping, 'deeper:key') == 'value'
    assert get_tree_node(mapping, 'deeper:nested:key') == 'value'
    assert get_tree_node(mapping, 'deeper:nested:nested_list:0:key') == 'value'
    assert get_tree_node(mapping, 'deeper:nested:nested_list:1:key') == 'value2'

# Generated at 2022-06-12 08:29:02.703544
# Unit test for function get_tree_node
def test_get_tree_node():
    main_tree = tree()
    main_tree['key1'] = 'value1'
    main_tree['key2'] = tree()
    main_tree['key2']['key2.1'] = 'value2.1'
    main_tree['key3'] = 'value3'
    assert get_tree_node(main_tree, 'key1') == 'value1'
    assert get_tree_node(main_tree, 'key2:key2.1') == 'value2.1'
    with pytest.raises(KeyError):
        get_tree_node(main_tree, 'key4')
    assert get_tree_node(main_tree, 'key4', default='value4') == 'value4'



# Generated at 2022-06-12 08:29:06.601598
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    set_tree_node(test_tree, 'foo:bar:baz', 'hello')
    assert test_tree['foo']['bar']['baz'] == 'hello'


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-12 08:29:15.645670
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = tree()

    # Set up tree
    test_tree['one']['two']['three']['four']['five'] = 'test!'
    test_tree['one']['2']['3']['4']['5'] = 'test 2!'

    # Tests keys and exceptions
    assert get_tree_node(test_tree, 'one:2:3:4:5') == 'test 2!'
    assert get_tree_node(test_tree, 'one:two:three:four:five') == 'test!'
    assert get_tree_node(test_tree, 'one:two') == {'three': {'four': {'five': 'test!'}}}
    with raises(KeyError):
        get_tree_node(test_tree, 'one:1')


# Unit test

# Generated at 2022-06-12 08:29:21.361523
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}, 'e': 'f'}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}, 'e': 'f'}}, 'a:b:c', parent=True) == {'c': 'd'}



# Generated at 2022-06-12 08:29:26.441484
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:bleh') == _sentinel
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:bleh', default='super') == 'super'



# Generated at 2022-06-12 08:29:34.329414
# Unit test for function set_tree_node
def test_set_tree_node():
    from nose.tools import eq_
    obj = {}
    set_tree_node(obj, "unicorn:toster:armadillo", 42)
    eq_(
        obj,
        {"unicorn": {"toster": {"armadillo": 42}}},
    )
    set_tree_node(obj, "unicorn:toster:armadillo", 24)
    eq_(
        obj,
        {"unicorn": {"toster": {"armadillo": 24}}},
    )
    set_tree_node(obj, "unicorn:toster:unicorn", 24)
    eq_(
        obj,
        {"unicorn": {"toster": {"armadillo": 24, "unicorn": 24}}},
    )



# Generated at 2022-06-12 08:29:37.018112
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b') == {'c': 1}



# Generated at 2022-06-12 08:29:39.784500
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'views', 1)

    assert mapping == {'views': 1}

    set_tree_node(mapping, 'views:index', 1)
    assert mapping == {'views': {'index': 1}}

