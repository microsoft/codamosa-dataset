

# Generated at 2022-06-12 08:20:11.113121
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'one', 1)
    set_tree_node(mapping, 'two', 2)
    set_tree_node(mapping, 'three', 3)
    set_tree_node(mapping, 'four', 4)
    set_tree_node(mapping, 'five', 5)
    set_tree_node(mapping, 'six', 6)
    set_tree_node(mapping, 'seven', 7)
    assert mapping.get('one') == 1
    assert mapping.get('two') == 2
    assert mapping.get('three') == 3
    assert mapping.get('four') == 4
    assert mapping.get('five') == 5
    assert mapping.get('six') == 6
    assert mapping.get('seven') == 7

    mapping = tree

# Generated at 2022-06-12 08:20:17.016145
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        "hello": {
            "world": True
        },
        "hello:world:2": "some string"
    }
    assert get_tree_node(mapping, "hello:world") is True
    assert get_tree_node(mapping, "hello:world:2") == "some string"
    assert get_tree_node(mapping, "hello:world:2", default='def') == "some string"
    assert get_tree_node(mapping, "hello:world:3", default='def') == "def"



# Generated at 2022-06-12 08:20:25.087247
# Unit test for function get_tree_node
def test_get_tree_node():
    o = {'foo': {
        'bar': 1,
        'baz': 2
    }}

    assert get_tree_node(o, 'foo:bar') == 1
    assert get_tree_node(o, 'foo:baz') == 2
    assert get_tree_node(o, 'foo:xyzzy', default=3) == 3

    with pytest.raises(KeyError):
        get_tree_node(o, 'foo:baz:lol')
        get_tree_node(o, 'foo:xyzzy')



# Generated at 2022-06-12 08:20:32.738736
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {'b': {'c': {'d': {'e': {'f': 'g'}}}}}
    }
    assert get_tree_node(tree, 'a:b:c:d:e:f') == 'g'
    assert get_tree_node(tree, 'a:b:c:d:e:f:g', default='default') == 'default'
    with pytest.raises(KeyError):
        get_tree_node(tree, 'a:b:c:d:e:f:g')



# Generated at 2022-06-12 08:20:36.457187
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'foo': 'bar'}
    set_tree_node(mapping, 'key:that:has:stuff:and:stuff', 'baz')
    assert mapping['key']['that']['has']['stuff']['and']['stuff'] == 'baz'



# Generated at 2022-06-12 08:20:46.823740
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test the function set_tree_node"""
    assert set_tree_node({}, 'foo', 'foo') == {'foo': 'foo'}
    assert set_tree_node({}, 'foo:bar', 'bar') == {'foo': {'bar': 'bar'}}
    assert set_tree_node({}, 'foo:bar:baz', 'baz') == {'foo': {'bar': {'baz': 'baz'}}}
    assert set_tree_node({'bar': {'foo': 'foo'}}, 'bar:foo', 'bar') == {'bar': {'foo': 'bar'}}
    assert set_tree_node({}, 'bar:baz', 'baz') == {'bar': {'baz': 'baz'}}

# Generated at 2022-06-12 08:20:54.492976
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_tree = {
    ...     'foo': {
    ...         'bar': 'baz',
    ...     },
    ... }
    >>> get_tree_node(test_tree, 'foo:bar')
    'baz'
    >>> get_tree_node(test_tree, 'foo:bar:baz')
    Traceback (most recent call last):
        ...
    KeyError: 'baz'

    >>> get_tree_node(test_tree, 'foo:bar', parent=True) == {'bar': 'baz'}
    True
    """



# Generated at 2022-06-12 08:21:00.750527
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'foo': {
            'bar': 'baz'
        },
        'qux': {
            'quux': 'quuz'
        }
    }
    assert get_tree_node(test_dict, key='foo:bar') == 'baz'
    assert get_tree_node(test_dict, key='qux:quux') == 'quuz'


if __name__ == '__main__':
    print(tree())

# Generated at 2022-06-12 08:21:05.612095
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, "a:b:c", 1234)
    assert test_dict == {'a': {'b': {'c': 1234}}}


if __name__ == '__main__':
    print(__doc__)

# Generated at 2022-06-12 08:21:13.094485
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    d = {'a': {'b': {'c': 'd'}}}

    assert 'd' == get_tree_node(d, 'a:b:c')

    # Assert KeyError when key not found in tree
    with pytest.raises(KeyError):
        get_tree_node(d, 'a:x:x')

    # Assert KeyError when get_tree_node called but returns default
    assert None is get_tree_node(d, 'z:x:x', default=None)



# Generated at 2022-06-12 08:21:24.719986
# Unit test for function get_tree_node
def test_get_tree_node():

    # initialize tree
    tree_ = tree()
    assert isinstance(tree_, collections.defaultdict)
    assert tree_.__class__ is collections.defaultdict

    # set some random namespaces
    tree_['base']['level1']['level2'] = 'foo'
    tree_['base']['level1']['level3']['level4'] = 'bar'

    # assert valid keys
    assert get_tree_node(tree_, 'base:level1:level2') == 'foo'
    assert get_tree_node(tree_, 'base:level1:level3:level4') == 'bar'

    # assert invalid keys
    with pytest.raises(KeyError):
        get_tree_node(tree_, 'base:level2:level3')



# Generated at 2022-06-12 08:21:26.472717
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'



# Generated at 2022-06-12 08:21:35.950148
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    test1 = {
        "test": {
            "test2": {
                "test3": {
                    "test4": "testvalue"
                }
            }
        }
    }
    assert get_tree_node(test1, "test:test2:test3:test4") == "testvalue"

    assert get_tree_node(test1, "test:test2:test3") == {'test4': 'testvalue'}

    assert get_tree_node(test1, "test:test2:test3:test4", parent=True) == {'test4': 'testvalue'}


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:21:44.437679
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'playbooks': {
            'playbook_name': {
                'description': 'description of playbook',
                'layout': {
                    'role_name': {
                        'description': 'description of role',
                        'hosts': ['host1', 'host2'],
                        'roles': ['role1', 'role2'],
                        'vars': {'var1': 'value1', 'var2': 'value2'},
                        'meta': {'meta1': 'value1', 'meta2': 'value2'}
                    }
                }
            }
        }
    }

    print(get_tree_node(mapping, 'playbooks:playbook_name'))
    print(get_tree_node(mapping, 'playbooks:playbook_name:layout'))

# Generated at 2022-06-12 08:21:53.869540
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test whether `get_tree_node` properly fetches keys.
    """
    struct = {
        'key': 'value',
        'key2': [1, 2, 3],
        'key3': {
            'key4': 'value4',
            'key5': 'value5'
        }
    }

    assert get_tree_node(struct, 'key') == 'value'
    assert get_tree_node(struct, 'key2') == [1, 2, 3]
    assert get_tree_node(struct, 'key3') == {'key4': 'value4', 'key5': 'value5'}
    assert get_tree_node(struct, 'key3:key5') == 'value5'
    assert get_tree_node(struct, 'key2:0') == 1
   

# Generated at 2022-06-12 08:22:02.344011
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'test1', 'test1')
    assert test_dict['test1'] == 'test1'
    set_tree_node(test_dict, 'test2', 'test2')
    assert test_dict['test2'] == 'test2'
    set_tree_node(test_dict, 'test:test:test:test:test', 'test2')
    assert test_dict['test']['test']['test']['test']['test'] == 'test2'



# Generated at 2022-06-12 08:22:09.753342
# Unit test for function get_tree_node
def test_get_tree_node():
    # Basic
    test_data = Tree({
        'a:b:c': 1,
        'a:b:d': 2,
        'a:e': 3,
        'a:f:g': 4,
        'h': 5,
    })

    # Basic get
    assert test_data['a:b:c'] == 1
    assert test_data['a:b:d'] == 2
    assert test_data['a:e'] == 3
    assert test_data['a:f:g'] == 4
    assert test_data['h'] == 5

    # Invalid key
    with pytest.raises(KeyError):
        test_data['i']

    # Invalid dimension
    with pytest.raises(KeyError):
        test_data['a:f:c']

    # Basic get parent
   

# Generated at 2022-06-12 08:22:20.266944
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'forrest': {
            'trees': [
                {'height': 50, 'name': 'oak'},
            ]
        }
    }
    assert get_tree_node(tree, 'forrest:trees:0:name') == 'oak'
    try:
        get_tree_node(tree, 'forrest:trees:1:name')
        raise AssertionError('`forrest:trees:1:name` does not exist, should fail.')
    except KeyError:
        pass
    assert get_tree_node(tree, 'forrest:trees:1:name', default='maple') == 'maple'


if __name__ == '__main__':
    import nose
    nose.main()

# Generated at 2022-06-12 08:22:25.294956
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> tree = {'one': {'tow': 'tow_value'}}
    >>> get_tree_node(tree, 'one:tow')
    'tow_value'

    """



# Generated at 2022-06-12 08:22:27.603618
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': [{'c': 1}]}
    assert get_tree_node(d, 'a:0:c') == 1



# Generated at 2022-06-12 08:22:34.976688
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for method get_tree_node"""
    d = {'tree': {'branch': {'leaf': 'jill'}}}
    assert get_tree_node(d, 'tree:branch:leaf') == 'jill'
    assert get_tree_node(d, 'tree:branch') == {'leaf': 'jill'}



# Generated at 2022-06-12 08:22:40.525518
# Unit test for function set_tree_node
def test_set_tree_node():
    target = collections.defaultdict(dict)
    set_tree_node(target, 'some:key', 'some_value')
    assert target['some']['key'] == 'some_value'
    set_tree_node(target, 'some:other_key', 'some_other_value')
    assert target == {'some': {'other_key': 'some_other_value', 'key': 'some_value'}}



# Generated at 2022-06-12 08:22:45.964235
# Unit test for function get_tree_node
def test_get_tree_node():
    t = collections.defaultdict(dict, {'a': {'b': {'c': 1}}})
    assert get_tree_node(t, 'a:b:c') == 1
    try:
        get_tree_node(t, 'a:b:d')
    except KeyError:
        assert True
    else:
        assert False



# Generated at 2022-06-12 08:22:54.046719
# Unit test for function get_tree_node
def test_get_tree_node():
    from collections import OrderedDict

    mapping = OrderedDict()
    mapping['a'] = OrderedDict()
    mapping['a']['b'] = OrderedDict()
    mapping['a']['b']['c'] = OrderedDict()
    mapping['a']['b']['c']['d'] = OrderedDict()
    mapping['a']['e'] = OrderedDict()

    value = get_tree_node(mapping, 'a:b:c:d')
    assert value == mapping['a']['b']['c']['d']
    value = get_tree_node(mapping, 'a')
    assert value == mapping['a']


# Generated at 2022-06-12 08:23:02.859992
# Unit test for function get_tree_node
def test_get_tree_node():
    test_obj = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    assert get_tree_node(test_obj, 'foo:bar:baz') == 'qux'


test_tree = Tree({
    'foo.bar.baz': 'Hello World!',
    'foo.bar.qux': 2,
    'foo.quxx': {
        'quux': 9,
        'joe': 'schmo'
    }
})



# Generated at 2022-06-12 08:23:09.826242
# Unit test for function set_tree_node
def test_set_tree_node():
    test = {}
    set_tree_node(test, "a", 1)
    assert test == {"a": 1}
    set_tree_node(test, "b", 2)
    assert test == {"a": 1, "b": 2}
    set_tree_node(test, "a:aa", 3)
    assert test == {"a": 1, "b": 2, "a:aa": 3}
    set_tree_node(test, "a:ab", 4)
    assert test == {"a": 1, "b": 2, "a:aa": 3, "a:ab": 4}



# Generated at 2022-06-12 08:23:18.523667
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'one': {
            'two': {
                'three': True,
            },
        },
    }

    assert get_tree_node(mapping, 'one:two:three') is True
    assert get_tree_node(mapping, 'one:two:three:four', default=None) is None
    assert get_tree_node(mapping, 'one:two:three:four') is _sentinel
    assert get_tree_node(mapping, 'one:two:three:four', default=False) is False
    assert get_tree_node(mapping, 'one:two:three:four', parent=True)['four'] is True
    assert get_tree_node(mapping, 'one:two', parent=True)['two']['three'] is True



# Generated at 2022-06-12 08:23:24.822321
# Unit test for function set_tree_node
def test_set_tree_node():

    # Create a handler registry
    registry = tree()

    # Register at a nested level
    set_tree_node(registry, 'foo:bar:baz', 'FOO')

    assert registry.get('foo:bar:baz') == 'FOO'

    # Change value
    set_tree_node(registry, 'foo:bar:baz', 'BAR')

    assert registry.get('foo:bar:baz') == 'BAR'



# Generated at 2022-06-12 08:23:32.178140
# Unit test for function get_tree_node
def test_get_tree_node():

    # Set up test tree
    tree = {'a': {'b': {'c': {'d': 456}}}}

    # check if all nodes exist
    assert get_tree_node(tree, 'a:b:c:d') == 456
    assert get_tree_node(tree, 'a:b:c')['d'] == 456

    # check if missing nodes exist
    with pytest.raises(KeyError):
        get_tree_node(tree, 'a:b:c:d:e')

    # check if missing nodes with parent arg work
    assert get_tree_node(tree, 'a:b:c:d:e', parent=True) == {'d': 456}

    # check if default value is returned

# Generated at 2022-06-12 08:23:42.066111
# Unit test for function set_tree_node
def test_set_tree_node():
    # Lets start by building a tree
    tree = {}
    # Set a data item on the tree
    set_tree_node(tree, 'apples:sam', 'I like apples')
    set_tree_node(tree, 'apples:tom', 'I like green apples')
    assert get_tree_node(tree, 'apples:sam') == 'I like apples'
    assert get_tree_node(tree, 'apples:tom') == 'I like green apples'
    # Lets update sam's comment
    set_tree_node(tree, 'apples:sam', 'I like red apples')
    assert get_tree_node(tree, 'apples:sam') == 'I like red apples'



# Generated at 2022-06-12 08:23:53.405720
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': 'baz',
        }
    }
    assert get_tree_node(tree, 'foo:bar') == 'baz'



# Generated at 2022-06-12 08:24:03.210236
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test :func:`get_tree_node`: Fetch arbitrary node from a tree-like mapping structure with traversal help.
    """

# Generated at 2022-06-12 08:24:07.058952
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'test:test2:test3', 'value')
    assert test_dict['test']['test2']['test3'] == 'value', 'set_tree_node did not work'



# Generated at 2022-06-12 08:24:10.949924
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    set_tree_node(d, 'a:b:c', 'hello world')
    assert d['a']['b']['c'] == 'hello world'



# Generated at 2022-06-12 08:24:18.379529
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux',
            'corge': {
                'grault': 'garply'
            },
            'waldo': 'fred'
        }
    }

    assert get_tree_node(data, 'foo') == 'bar'
    assert get_tree_node(data, 'baz:qux') == 'quux'
    assert get_tree_node(data, 'baz:corge') == {'grault': 'garply'}
    assert get_tree_node(data, 'baz:corge:grault') == 'garply'

    assert get_tree_node(data, 'baz:corge', default='wut') == 'wut'

# Generated at 2022-06-12 08:24:28.887870
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    OK
    """
    import random
    import string
    random_numbers = [random.randint(1, 10) for _ in range(10)]
    random_chars = [random.choice(string.ascii_letters) for _ in range(10)]

    namespaces = [
        'a:b:c',
        'a:b',
        'a',
        ''
    ]

    test_tree = {
        'a': {
            'b': {
                'c': random_chars[0]
            }
        }
    }

    assert get_tree_node(test_tree, 'a:b:c') == random_chars[0]
    assert get_tree_node(test_tree, 'd') is None

   

# Generated at 2022-06-12 08:24:33.182451
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'one': {'two': {'three': 3}}}
    assert (get_tree_node(tree, 'one:two:three') == 3)
    assert (get_tree_node(tree, 'one:two:four') is _sentinel)
    assert(get_tree_node(tree, 'one:two:four', default=False) is False)



# Generated at 2022-06-12 08:24:43.762062
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'a': {
            'a': 'a',
            'b': 1
        },
        'b': {
            'a': 'aa',
            'b': 2
        },
        'c': []
    }

    assert get_tree_node(test_data, 'a:a') == 'a'
    assert get_tree_node(test_data, 'a:b') == 1
    assert get_tree_node(test_data, 'b:a') == 'aa'
    assert get_tree_node(test_data, 'b:b') == 2

    assert get_tree_node(test_data, 'd:a', default='None') == 'None'
    assert get_tree_node(test_data, 'c:b', default='None') == 'None'

   

# Generated at 2022-06-12 08:24:49.170609
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:quux', default=None) is None



# Generated at 2022-06-12 08:24:55.333847
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data = {
        'foo': {
            'bar': {
                'baz': 'this is an old value'
            }
        }
    }

    set_tree_node(test_data, 'foo:bar:baz', 'this is a new value')
    assert test_data['foo']['bar']['baz'] == 'this is a new value'

    set_tree_node(test_data, 'foo:bar:quux', 'this is a test')
    assert test_data['foo']['bar']['quux'] == 'this is a test'

    set_tree_node(test_data, 'foo:bar', 'this is an overwritten value')
    assert test_data['foo']['bar'] == 'this is an overwritten value'


# Generated at 2022-06-12 08:25:11.851132
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': {'d': 'e'}}}}, 'a:b:c') == {'d': 'e'}
    assert get_tree_node({'a': {'b': {'c': {'d': 'e'}}}}, 'a:b:c:d') == 'e'
    assert get_tree_node({'a': {'b': {'c': {'d': 'e'}}}}, 'a:b:c', default=False) == {'d': 'e'}
    assert get_tree_node({'a': {'b': {'c': {'d': 'e'}}}}, 'a:b:n', default=False) is False

# Generated at 2022-06-12 08:25:22.355827
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': {'b': 'c'}}
    assert get_tree_node(d, 'a:b') == 'c'
    assert get_tree_node(d, 'a:b:c') is _sentinel
    assert get_tree_node(d, 'a:b:c', 'default') == 'default'

    # tree() returns defaultdict(tree)
    d = tree()
    d['a']['b']['c'] = 'd'
    assert get_tree_node(d, 'a:b:c') == 'd'
    assert get_tree_node(d, 'a:b:c:d') == tree()

    
if __name__ == 'main':
    test_get_tree_node()

# Generated at 2022-06-12 08:25:26.399425
# Unit test for function get_tree_node
def test_get_tree_node():
    data = Tree(
        {
            'foo': {
                'bar': 'baz',
                'bop': {
                    'snorfling': 'snorfled'
                }
            }
        }
    )

    assert get_tree_node(data, 'foo:bar') == 'baz'

# Generated at 2022-06-12 08:25:35.903362
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    True
    """
    test = Tree({'a': {'b': {'c': 'd'}}})
    # By key
    assert test['a'] == {'b': {'c': 'd'}}
    # By : notation
    assert test['a:b'] == {'c': 'd'}
    assert test['a:b:c'] == 'd'
    # Ensure KeyError exception is raised properly
    try:
        test['a:b:c:d']
        assert False, 'KeyError should have been raised'
    except KeyError:
        pass
    # Ensure default is returned correctly

# Generated at 2022-06-12 08:25:44.483046
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {'bar': {'baz': 'Hello!'}},
        'quux': {'ar': {'ma': 'World!'}},
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'Hello!'
    assert get_tree_node(mapping, 'quux:ar:ma') == 'World!'
    assert get_tree_node(mapping, 'does_not_exist:i_promise') is _sentinel
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'does_not_exist:i_promise', _sentinel)



# Generated at 2022-06-12 08:25:55.551084
# Unit test for function get_tree_node
def test_get_tree_node():

    class Foo(object):
        BAZ = 'baz'

    foo = Foo()

    # Simple case
    mapping = {
        'foo': 'bar'
    }
    assert get_tree_node(mapping, 'foo') == 'bar'

    # Three levels deep
    mapping = {
        'foo': {
            'bar': {
                'baz': {
                    'buzz': 'fizz'
                }
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz:buzz') == 'fizz'

    # Attribute
    assert get_tree_node(foo, 'BAZ') == 'baz'

    # Element in list
    mapping = {
        'foo': ['bar']
    }

# Generated at 2022-06-12 08:26:03.460333
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(test_mapping, 'foo', parent=True) == {'baz': 'qux'}
    with pytest.raises(KeyError):
        get_tree_node(test_mapping, 'bar')
    with pytest.raises(KeyError):
        get_tree_node(test_mapping, 'biz')

    assert get_tree_node(test_mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(test_mapping, 'foo:baz:biz') is None



# Generated at 2022-06-12 08:26:11.292424
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'apples': {'fuji': {'crisp': 'good'}}}, 'apples:fuji:crisp') == 'good'
    assert get_tree_node({'apples': {'fuji': {'crisp': 'good'}}}, 'apples:fuji:crisp:bad:joke') is _sentinel
    assert get_tree_node({'apples': {'fuji': {'crisp': 'good'}}}, 'apples:fuji:crisp:bad:joke', default='default') == 'default'



# Generated at 2022-06-12 08:26:20.991159
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'foo': {
            'bar': 'bar',
            'baz': ['foo', 'bar'],
            'fuz': {
                'foo': 'bar',
            },
        },
        'bar': 'foo',
        'foobar': {
            'baz': {
                'fuz': [1, 2, 3],
                'foo': [4, 5, 6],
            },
        },
    }

    assert get_tree_node(d, 'foo') == {
        'bar': 'bar',
        'baz': ['foo', 'bar'],
        'fuz': {
            'foo': 'bar',
        },
    }

    assert get_tree_node(d, 'foo:bar') == 'bar'


# Generated at 2022-06-12 08:26:30.836314
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function `set_tree_node`.
    """
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree['foo']['bar']['baz'] == 'qux'

    tree = {'foo': {'bar': {'baz': 'quux'}}}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree['foo']['bar']['baz'] == 'qux'

    tree = {'foo': {'bar': {'baz': 'quux'}}}
    set_tree_node(tree, 'foo:bar:quux', 'qux')
    assert tree['foo']['bar']['quux'] == 'qux'

    tree

# Generated at 2022-06-12 08:26:50.743910
# Unit test for function get_tree_node
def test_get_tree_node():

    # Define the test data
    test_dict = {
        'd': {
            'e': {
                'f': 3,
            },
        },
        'e': 2
    }

    # Test step 1
    assert get_tree_node(test_dict, 'd:e:f') == 3
    assert get_tree_node(test_dict, 'd:e:f:x') == _sentinel
    assert get_tree_node(test_dict, 'e:f') == _sentinel



# Generated at 2022-06-12 08:27:02.140580
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'foo': {'bar': 'baz'}}
    # NOTE: keys should be ordered and returned as a tuple
    assert get_tree_node(d, 'foo', default=_sentinel) == {'bar': 'baz'}
    assert get_tree_node(d, 'foo:bar', default=_sentinel) == 'baz'
    assert get_tree_node(d, 'foo:bar:baz', default=_sentinel) is _sentinel
    assert get_tree_node(d, 'foo:bar:baz', default='default') == 'default'
    # NOTE: keys should be ordered and returned as a tuple
    assert get_tree_node(d, 'foo:bar:baz', default=_sentinel, parent=True) == {'bar': 'baz'}

# Generated at 2022-06-12 08:27:08.535792
# Unit test for function get_tree_node
def test_get_tree_node():

    # Test that default is returned for missing key
    assert get_tree_node({}, 'foo', default="bar") == 'bar'

    # Test that multiple options are possible to specify
    assert get_tree_node({'bar': {'baz': 'zap'}}, 'bar:baz') == 'zap'

    # Test that KeyError is raised when default is not set
    with pytest.raises(KeyError):
        get_tree_node({}, 'foo')

    # Test that KeyError is raised when default is not set
    with pytest.raises(KeyError):
        get_tree_node({'bar': {'baz': 'zap'}}, 'bar:baz:foo')

    # Test parent is auto-created if it does not exist

# Generated at 2022-06-12 08:27:11.160507
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'



# Generated at 2022-06-12 08:27:20.292054
# Unit test for function get_tree_node
def test_get_tree_node():
    from assertpy import assert_that

    foo = {'key': {'down': 'level'}}
    # Oneliners
    assert_that(get_tree_node(foo, 'key')).is_equal_to({'down': 'level'})
    assert_that(get_tree_node(foo, 'key:down')).is_equal_to('level')
    assert_that(get_tree_node(foo, 'key:down:level')).is_equal_to(None)
    # Multi-level
    bar = {'foo': {'bar': {'baz': 'boo'}}}
    assert_that(get_tree_node(bar, 'foo:bar:baz')).is_equal_to('boo')
    # Parent

# Generated at 2022-06-12 08:27:30.889495
# Unit test for function get_tree_node
def test_get_tree_node():
    # Set up a test dict
    test_dict = {'a': 1,
                 'b': {'c': 1,
                       'd': 2,
                       'e': 3,
                       'f': {'g': 4,
                             'h': 5,
                             'i': 6}}}

    # Assert: Get tree node
    assert get_tree_node(test_dict, 'a') == 1
    assert get_tree_node(test_dict, 'b:c') == 1
    assert get_tree_node(test_dict, 'b:d') == 2
    assert get_tree_node(test_dict, 'b:e') == 3
    assert get_tree_node(test_dict, 'b:f:g') == 4

# Generated at 2022-06-12 08:27:35.467676
# Unit test for function set_tree_node
def test_set_tree_node():
    result = dict()
    set_tree_node(result, 'foo', 'bar')
    assert result['foo'] == 'bar', 'result should have foo:bar'

    result = dict()
    set_tree_node(result, 'foo:bar', 'baz')
    assert result['foo']['bar'] == 'baz', 'result should have foo:bar:baz'



# Generated at 2022-06-12 08:27:46.546449
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree, '')
    assert get_tree_node(tree(), '')
    assert get_tree_node({'hello': 'world'}, 'hello') == 'world'
    assert get_tree_node(tree, 'hello:world')
    assert get_tree_node(tree, 'hello', default='world') == 'world'
    assert get_tree_node({'hello': {'world': '.'}}, 'hello:world') == '.'
    assert get_tree_node({'hello': {'world': '.'}}, 'hello') == {'world': '.'}
    assert get_tree_node({'hello': {'world': '.'}}, 'hello:world:.') is None
    assert get_tree_node('hello', 'world') is None

# Generated at 2022-06-12 08:27:50.983100
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    new_node = set_tree_node(t, 'a:b:c', 'foo')
    assert isinstance(new_node, collections.defaultdict)
    assert t['a']['b']['c'] == 'foo'
    assert new_node['c'] == 'foo'


# Generated at 2022-06-12 08:27:57.185832
# Unit test for function set_tree_node
def test_set_tree_node():
    # test_dict = {'foo': {'bar': {'baz': {'qux': 'quux'} } } }
    test_dict = tree()
    set_tree_node(test_dict, 'foo:bar:baz:qux', 'quux')
    assert test_dict['foo']['bar']['baz']['qux'] == 'quux'



# Generated at 2022-06-12 08:28:33.828921
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test if get_tree_node provides correct output.

    """
    test_dict = {
        'foo': {
            'bar': 'baz'
        },
        'foo2': {
        },
        'foo3': {
            'foo4': {
            }
        }
    }

    assert get_tree_node(test_dict, 'foo') == test_dict['foo']
    assert get_tree_node(test_dict, 'foo:bar') == 'baz'
    assert get_tree_node(test_dict, 'foo:nosuchkey') == _sentinel

    with pytest.raises(KeyError):
        get_tree_node(test_dict, 'foo:nosuchkey')


# Generated at 2022-06-12 08:28:38.784087
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'value'
            }
        },
        'foo2': 'value2'
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'value'
    assert get_tree_node(mapping, 'foo2') == 'value2'



# Generated at 2022-06-12 08:28:44.975292
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['foo']['bar']['baz'] = 'Hello'
    assert get_tree_node(t, 'foo:bar:baz') == 'Hello'
    assert get_tree_node(t, 'foo:bar:ba') is _sentinel
    assert get_tree_node(t, 'foo:bar:ba', default=None) is None

    t2 = RegistryTree(namespace='test')
    t2.register('foo', 'Hello')
    assert t2.get('test:foo') == 'Hello'


if __name__ == '__main__':
    test_get_tree_node()
    print('All tests passed')

# Generated at 2022-06-12 08:28:52.543054
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'one': {
            'two': 'four',
            'three': {
                'four': 'eight',
            }
        }
    }
    assert get_tree_node(mapping, 'one:two') == 'four'
    assert get_tree_node(mapping, 'one:three:four') == 'eight'
    assert get_tree_node(mapping, 'one:four', default='seven') == 'seven'
    try:
        get_tree_node(mapping, 'one:four')
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-12 08:29:02.657815
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': 1,
        'b': {'bad': 'joke'},
        'c': (1, 2, 'foo'),
        'd': None
    }
    assert get_tree_node(mapping, 'a') == 1
    assert get_tree_node(mapping, 'b:bad') == 'joke'
    assert get_tree_node(mapping, 'c') == (1, 2, 'foo')
    assert get_tree_node(mapping, 'd') is None
    assert get_tree_node(mapping, 'e', default='FAIL') == 'FAIL'
    assert get_tree_node(mapping, 'e') == 'FAIL'
    mapping['e'] = 'WIN'

# Generated at 2022-06-12 08:29:12.626085
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'fru': {'bar': 'baz', 'apple': 'fruit'},
            'app': {'foo': 'bar', 'apple': 'computer'}}
    assert get_tree_node(tree, 'app:foo') == 'bar'
    assert get_tree_node(tree, 'app:apple') == 'computer'
    assert get_tree_node(tree, 'fru:bar') == 'baz'
    assert get_tree_node(tree, 'fru:apple') == 'fruit'
    assert get_tree_node(tree, 'fru') == {'bar': 'baz', 'apple': 'fruit'}
    assert get_tree_node(tree, 'app') == {'foo': 'bar', 'apple': 'computer'}



# Generated at 2022-06-12 08:29:22.295165
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'toplevel': {
            'a': {
                'b': {
                    'c': '3'
                },
                'd': '2'
            }
        },
        'base': '1'
    }

    assert get_tree_node(d, 'base') == '1'
    assert get_tree_node(d, 'toplevel:a:d') == '2'
    assert get_tree_node(d, 'toplevel') == {'a': {'b': {'c': '3'}, 'd': '2'}}

    assert get_tree_node(d, 'toplevel:a:b:c') == '3'

# Generated at 2022-06-12 08:29:30.862911
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': {'baz': 'foobarbaz'}},
               'meh': 'meh'}
    assert 'meh' == get_tree_node(mapping, 'meh')
    assert 'foobarbaz' == get_tree_node(mapping, 'foo:bar:baz')
    assert 'meh' == get_tree_node(mapping, 'foo:bar:baz:meh', default='meh')
    assert 'foobarbaz' == get_tree_node(mapping, 'foo:bar:baz:meh', default='foobarbaz')
    assert 'foobarbaz' == get_tree_node(mapping, 'foo:bar:baz')

# Generated at 2022-06-12 08:29:35.954572
# Unit test for function set_tree_node
def test_set_tree_node():
    root = tree()
    mapping = tree()
    mapping['level2'] = "level2"
    mapping['level3'] = tree()
    mapping['level3']['level4'] = "something"
    root['testing'] = mapping
    result = set_tree_node(root, "testing:level3:level4", "something else")
    assert result['level4'] == "something else"



# Generated at 2022-06-12 08:29:42.351502
# Unit test for function get_tree_node
def test_get_tree_node():
    import json
    import os

    # Load dataset
    tree_base_dir = os.path.dirname(__file__)
    with open(os.path.join(tree_base_dir, 'tree.json'), 'rb') as f:
        mapping = json.load(f, strict=False)

    # Test sentinel
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'spam')

    # Test parent
    egg = get_tree_node(mapping, 'foo:bar:egg', parent=True)
    assert egg == mapping['foo']['bar']

    # Test default
    egg = get_tree_node(mapping, 'spam:ham', default='egg')
    assert egg == 'egg'

    # Test normal