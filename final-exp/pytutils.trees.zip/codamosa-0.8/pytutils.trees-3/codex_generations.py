

# Generated at 2022-06-12 08:20:13.152529
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'a': 'A',
        'b': {
            'c': {
                'd': {
                    'e': 'E'
                }
            }
        },
        'c': {
            1: 'one',
            2: 'two',
            3: 'three',
            4: 'four',
            5: 'five',
            6: 'six'
        }
    }
    assert get_tree_node(test_data, 'a') == 'A'
    assert get_tree_node(test_data, 'b:c:d:e') == 'E'
    assert get_tree_node(test_data, 'c:1') == 'one'
    assert get_tree_node(test_data, 'c:2') == 'two'
    assert get_tree

# Generated at 2022-06-12 08:20:22.221505
# Unit test for function get_tree_node
def test_get_tree_node():
    # set up
    tree = {'key1': {'key1a': {'key1a1': 'value1'}}, 'key2': 'value2'}

    # test existence
    assert get_tree_node(tree, 'key1:key1a:key1a1') == 'value1'
    assert get_tree_node(tree, 'key2') == 'value2'

    # test non existence with default value
    assert get_tree_node(tree, 'non_existent', 'default') == 'default'

    # test non existence with exception
    try:
        get_tree_node(tree, 'non_existent')
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised')

    # test non existence with exception, but with a default value

# Generated at 2022-06-12 08:20:27.167754
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'home': {
            'test': {
                'user': 'foo',
                'pass': 'bar',
            },
        },
    }
    assert get_tree_node(tree, 'home:test:user') == 'foo'



# Generated at 2022-06-12 08:20:31.358230
# Unit test for function set_tree_node
def test_set_tree_node():
    my_tree = {}
    assert set_tree_node(my_tree, 'a', 123) == {'a': 123}
    assert set_tree_node(my_tree, 'b:c', 345) == {'a': 123, 'b': {'c': 345}}



# Generated at 2022-06-12 08:20:39.291510
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': 'f'
                    }
                }
            }
        }
    }, 'a:b:c:d:e') == 'f'

    assert get_tree_node({
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': 'f'
                    }
                }
            }
        }
    }, 'a:b:c:d:e:no_such_key', default=42) == 42


# Generated at 2022-06-12 08:20:47.909964
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {'a': {'a': 'A'},
         'b': {'b': 'B'},
         'c': {'c': 'C'},
         'deep': {'level': {'x': 'X'}}}

    assert get_tree_node(m, 'a') == {'a': 'A'}
    assert get_tree_node(m, 'a:a') == 'A'
    assert get_tree_node(m, 'deep:level:x') == 'X'
    assert get_tree_node(m, 'does:not:exist', default='foo') == 'foo'
    assert get_tree_node(m, 'does:not:exist') == {}

    try:
        get_tree_node(m, 'does:not:exist')
    except KeyError:
        pass

# Generated at 2022-06-12 08:20:56.791693
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test to see if the function get_tree_node works as planned.
    """
    mapping = {'stuff': {'more': {'really': {'very': {'very': {'interesting': 'yup'}}}}}}
    assert get_tree_node(mapping, 'stuff:more') == {'really': {'very': {'very': {'interesting': 'yup'}}}}
    assert get_tree_node(mapping, 'stuff:more:really') == {'very': {'very': {'interesting': 'yup'}}}
    assert get_tree_node(mapping, 'stuff:more:really:very') == {'very': {'interesting': 'yup'}}

# Generated at 2022-06-12 08:21:05.121037
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'l1': {
            'l2': [
                'l4',
                {
                    'l51': 'foo',
                    'l52': 'bar',
                }
            ],
            'l3': {
                'l5': 'foo'
            }
        },
        'l2': 'baz'
    }
    nodes = {
        'l2': 'baz',
        'l3': {'l5': 'foo'},
        'l4': 'l4',
        'l51': 'foo',
        'l52': 'bar',
    }
    for key, excepted in nodes.items():
        assert get_tree_node(tree, key) == excepted
    # Error testing

# Generated at 2022-06-12 08:21:08.202804
# Unit test for function set_tree_node
def test_set_tree_node():
    d = dict()
    set_tree_node(d, 'a:b:c', 'd')
    d['a']['b']['c'] == 'd'



# Generated at 2022-06-12 08:21:17.258873
# Unit test for function set_tree_node
def test_set_tree_node():
    from nose.tools import assert_equal

    mapping = tree()
    set_tree_node(mapping, 'a:b:c', 'd')
    assert_equal(mapping, {'a': {'b': {'c': 'd'}}})
    del mapping['a']['b']['c']
    mapping['a']['b']['c'] = 'd'
    assert_equal(mapping, {'a': {'b': {'c': 'd'}}})
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert_equal(mapping, {'a': {'b': {'c': 'd'}}, 'foo': {'bar': 'baz'}})

# Generated at 2022-06-12 08:21:25.590422
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'foo': {
            'bar': 1,
            'baz': {
                'qaz': 2
            }
        }
    }

    assert get_tree_node(test_data, 'foo:bar'), 1
    assert get_tree_node(test_data, 'foo:baz:qaz'), 2

    assert get_tree_node(test_data, 'foo:bar', default=3), 1
    assert get_tree_node(test_data, 'foo:baz:qaz', default=3), 2

    try:
        get_tree_node(test_data, 'foo:baz:doesnotexist')
    except KeyError as exc:
        assert True
    else:
        assert False

# Generated at 2022-06-12 08:21:34.249030
# Unit test for function get_tree_node
def test_get_tree_node():
    """Ensure :func:get_tree_node returns expected values."""
    mapping = {'a': {'b': {'c': {'value': 'd'}}}}

    assert get_tree_node(mapping, 'a:b:c:value') == 'd'
    assert get_tree_node(mapping, 'a:b:c:value', parent=True) == {'value': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', 'no value') == 'no value'
    assert get_tree_node(mapping, 'a:b:c:d', 'no value', parent=True) == {'value': 'd'}



# Generated at 2022-06-12 08:21:41.026973
# Unit test for function get_tree_node
def test_get_tree_node():
    mydict = {'k1': {'k3': {'key1': 'value1', 'key2': 'value2'}}}
    assert get_tree_node(mydict, 'k1:k3:key1') == 'value1'
    assert get_tree_node(mydict, 'k1:k3') == {'key1': 'value1', 'key2': 'value2'}
    assert get_tree_node(mydict, 'k1:k3:key3') is _sentinel



# Generated at 2022-06-12 08:21:47.312197
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': True
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar') == {'baz': True}
    assert get_tree_node(mapping, 'foo:bar:baz') is True



# Generated at 2022-06-12 08:21:52.684982
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping.update({
        'test': {
            'test2': {
                'test3': 'test4'
            }
        }
    })
    assert get_tree_node(mapping, 'test') == mapping['test']
    assert get_tree_node(mapping, 'test:test2') == mapping['test']['test2']
    assert get_tree_node(mapping, 'test:test2:test3') == mapping['test']['test2']['test3']



# Generated at 2022-06-12 08:22:00.553581
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'x:y:z', True)
    assert d['x']['y']['z']

    d = {}
    set_tree_node(d, 'x:y:z', False)
    assert not d['x']['y']['z']

    d = {}
    set_tree_node(d, 'x:y:z', 'foo')
    assert d['x']['y']['z'] == 'foo'



# Generated at 2022-06-12 08:22:06.144559
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c:d:e', 1)
    set_tree_node(d, 'a:b:c:d:f', 5)
    assert d['a']['b']['c']['d']['e'] == 1
    assert d['a']['b']['c']['d']['f'] == 5



# Generated at 2022-06-12 08:22:14.110647
# Unit test for function get_tree_node
def test_get_tree_node():
    my_dict = {"foo": ["bar", "baz"]}
    assert get_tree_node(my_dict, "foo") == ["bar", "baz"]
    assert get_tree_node(my_dict, "foo:0") == "bar"
    try:
        get_tree_node(my_dict, "asdf")
    except KeyError as e:
        assert e.args[0] == "asdf"
    assert get_tree_node(my_dict, "asdf", "default") == "default"



# Generated at 2022-06-12 08:22:22.868210
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """

# Generated at 2022-06-12 08:22:30.487101
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {}
    mapping['a:b:c'] = 1
    mapping['a:b'] = {
        'c': 1
    }
    mapping['a:b:d'] = [
        1
    ]
    mapping['a'] = {
        'b': {
            'c': 1
        }
    }
    mapping['a:e'] = 'f'
    mapping['a:b:e'] = 'f'
    mapping['a:b:e:f'] = 'f'
    mapping['a:b:e:f:g'] = 'f'

    mapping = tree()
    mapping['a']['b']['c'] = 1



# Generated at 2022-06-12 08:22:45.481390
# Unit test for function set_tree_node
def test_set_tree_node():

    from pprint import pprint

    data = {}

    # Set key by traversing path
    set_tree_node(data, 'a:b:c', 'test_value')

    # Key was set
    assert data['a']['b']['c'] == 'test_value'

    # Set key with no traversal
    set_tree_node(data, 'd', 'test_value2')

    # Key was set
    assert data['d'] == 'test_value2'

    pprint(data)

    # Unit test for function get_tree_node
    # Fetch key with no default
    assert get_tree_node(data, 'a:b:c') == 'test_value'

    # Fetch leaf node
    assert get_tree_node(data, 'a:b:c', parent=True)

# Generated at 2022-06-12 08:22:48.433557
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, "key1:key2:stuff", "value")
    assert mapping["key1"]["key2"]["stuff"] == "value"



# Generated at 2022-06-12 08:22:55.890456
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': {'baz': 1}}}, 'foo:bar:baz') == 1
    assert get_tree_node(
        {'foo': {'bar': {'baz': 1, 'barf': 2}}},
        'foo:bar',
        default=_sentinel) == {'baz': 1, 'barf': 2}

    try:
        get_tree_node({'foo': {'bar': {'baz': 1}}}, 'foo:bar:baz:quux', default=_sentinel)
    except Exception as e:
        assert isinstance(e, KeyError)



# Generated at 2022-06-12 08:23:03.380860
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function :func:`get_tree_node`
    """
    # Setup test
    test_data = {
        'first': {
            'second': {
                'third': 'final_value'
            }
        }
    }

    # Run test
    test = get_tree_node(test_data, 'first:second:third')

    # Evaluate test
    assert test == 'final_value'


# Generated at 2022-06-12 08:23:12.301055
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['foo']['bar'] = 1
    t['foo:bar:baz'] = 2
    t['foo']['bar']['baz'] = 3
    t['foo']['bar']['baz']['qux'] = 4
    assert get_tree_node(t, 'foo:bar:baz') == 2
    assert get_tree_node(t, 'foo:bar') == {'baz': 3}
    assert get_tree_node(t, 'foo:bar:baz', parent=True) == {'baz': 3}


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:23:15.692477
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(dict)
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-12 08:23:24.498937
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': {'baz': 'value'}}}, 'foo:bar:baz') == 'value'
    assert get_tree_node({'foo': {'bar': {'baz': 'value'}}}, 'baz:baz', default=_sentinel) is _sentinel
    assert get_tree_node({'foo': {'bar': {'baz': 'value'}}}, 'foo:bar:baz', default=_sentinel) == 'value'
    assert get_tree_node({'foo': {'bar': {'baz': 'value'}}}, 'foo:bar', parent=True) == \
        {'baz': 'value'}



# Generated at 2022-06-12 08:23:29.994386
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['abc']['def']['ghi'] = 1
    assert get_tree_node(data, 'abc:def:ghi') == 1

    # try:
    #     get_tree_node(data, 'abc:def:ghi')
    # except KeyError:
    #     print('Key not found')
    #     pass


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:23:34.570626
# Unit test for function get_tree_node
def test_get_tree_node():
    foo = Tree({'bar': 'biz'})
    bar = foo['bar']
    assert bar == 'biz'

    foo['biz:baz'] = 'buzz'
    assert foo['biz:baz'] == 'buzz'

if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:23:41.569088
# Unit test for function get_tree_node
def test_get_tree_node():
    mydict = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mydict, 'a:b:c') == 'd'
    assert get_tree_node(mydict, 'a:b:c:e:f:g:h:i') is _sentinel
    assert get_tree_node(mydict, 'a:b:c:e:f:g:h:i', default='d') == 'd'



# Generated at 2022-06-12 08:23:55.340980
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    test_tree = set_tree_node(test_tree, "a:b:c", "test")
    assert test_tree["a"]["b"]["c"] == "test"



# Generated at 2022-06-12 08:24:04.810019
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': 'f'
                    }
                }
            }
        }
    }

    node = get_tree_node(mapping, 'a:b:c:d')
    assert node == {
        'e': 'f'
    }

    node = get_tree_node(mapping, 'a:b:c:d:e')
    assert node == 'f'

    try:
        node = get_tree_node(mapping, 'a:b:c:d:f')
        assert False
    except KeyError:
        assert True

    node = get_tree_node(mapping, 'a:b:c:d:f', default='g')

# Generated at 2022-06-12 08:24:10.491632
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    expected = {
        'test': {
            'test': {
                'test:test': 1
            }
        }
    }
    got = tree()
    set_tree_node(got, 'test:test:test:test', 1)
    assert got == expected



# Generated at 2022-06-12 08:24:17.120566
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': 'd', 'e': 'f'}}}

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    with pytest.raises(KeyError) as exc:
        get_tree_node(mapping, 'a:b:c:wtf')
    assert get_tree_node(mapping, 'a:b:c:wtf', default='nope') == 'nope'
    assert get_tree_node(mapping, 'a:b:c:wtf', default='nope', parent=True) == 'd'



# Generated at 2022-06-12 08:24:27.765129
# Unit test for function set_tree_node
def test_set_tree_node():
    # Initialize
    mapping = Tree()

    # Set set_tree_node and assert correct
    set_tree_node(mapping, 'my_key', 'my_value')
    assert mapping['my_key'] == 'my_value'

    set_tree_node(mapping, 'my_ns:my_key', 'my_other_value')
    assert mapping['my_ns:my_key'] == 'my_other_value'

    set_tree_node(mapping, 'my_ns:my_key:more', 'my_other_other_value')
    assert mapping['my_ns:my_key:more'] == 'my_other_other_value'
    assert mapping['my_ns']['my_key']['more'] == 'my_other_other_value'



# Generated at 2022-06-12 08:24:35.313315
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'a': {'b': 'c'}, 'd': {'e': {'f': 'g'}}}

    assert get_tree_node(tree, 'a:b') == 'c'
    assert get_tree_node(tree, 'd:e:f') == 'g'
    assert get_tree_node(tree, 'd:e') == {'f': 'g'}
    assert get_tree_node(tree, 'd') == {'e': {'f': 'g'}}

    with pytest.raises(KeyError):
        assert get_tree_node(tree, 'a:e')



# Generated at 2022-06-12 08:24:46.716561
# Unit test for function set_tree_node
def test_set_tree_node():
    from copy import deepcopy
    from nose.tools import assert_raises, eq_
    struct = Tree()

    struct.set_tree_node('a:b:c', 'd')
    eq_(struct, {'a': {'b': {'c': 'd'}}})
    # Set the same key to something else
    struct.set_tree_node('a:b:c', 'D')
    eq_(struct, {'a': {'b': {'c': 'D'}}})

    # Set the same key with a different name
    struct.set_tree_node('X:b:c', 'D')
    eq_(struct, {'a': {'b': {'c': 'D'}}, 'X': {'b': {'c': 'D'}}})

    # Try setting a key that causes us

# Generated at 2022-06-12 08:24:52.642238
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for set_tree_node.

    This is a unit test for set_tree_node.

    Returns:
        True

    """
    p = tree()
    for k in 'abc:def:ghi', 'rst', 'xyz:uvw':
        assert set_tree_node(p, k, '%s-value' % k) is p['%s' % k.rsplit(':', 1)[0]]

# Generated at 2022-06-12 08:25:02.032936
# Unit test for function get_tree_node
def test_get_tree_node():
    import unittest
    _orig_sentinel = _sentinel
    _sentinel = object()

    class TestGetTreeNode(unittest.TestCase):
        def test_get_tree_node_ok(self):
            mapping = {'a': {'b': 'c'}}
            self.assertEqual(get_tree_node(mapping, 'a:b'), 'c')

        def test_get_tree_node_key_error(self):
            mapping = {'a': {'b': 'c'}}
            self.assertRaises(KeyError, lambda: get_tree_node(mapping, 'a:c'))

        # NOTE: Set sentinel to object() to fix `global` scope leakage.

# Generated at 2022-06-12 08:25:12.251490
# Unit test for function get_tree_node
def test_get_tree_node():
    import pytest
    tree, branch, twig = (
        {"a": {"b": "elm"}},
        {"elm": "leaf"},
        {"leaf": "blatt"}
    )

    def get_subtree(subtree, keys, default=None):
        if not keys:
            return subtree
        key = keys.pop(0)
        try:
            return get_subtree(subtree[key], keys)
        except KeyError:
            if default is not None:
                return default
            raise

    assert get_tree_node(tree, "") == tree
    assert get_tree_node(tree, "a") == branch
    assert get_tree_node(tree, "a:b") == twig['leaf']
    assert get_tree_node(tree, "a:b:leaf") == tw

# Generated at 2022-06-12 08:25:33.132766
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz'
        }
    }
    assert get_tree_node(mapping, 'foo:bar') == 'baz'

# Generated at 2022-06-12 08:25:34.544994
# Unit test for function get_tree_node
def test_get_tree_node():
    assert True


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:25:44.372683
# Unit test for function get_tree_node
def test_get_tree_node():
    """Verify :func:`get_tree_node` returns sane results."""
    # Setup
    initial = {
        'foo': {
            'bar': 1,
            'baz': 2,
        },
        'baz': 3,
    }
    assert get_tree_node(initial, 'foo:bar') == 1
    assert get_tree_node(initial, 'foo:bar', default=None) == 1
    assert get_tree_node(initial, 'foo:banana', default=None) is None
    assert get_tree_node(initial, 'banana', default=None) is None
    assert get_tree_node(initial, 'banana', parent=True) is initial



# Generated at 2022-06-12 08:25:52.257321
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c:d:e', 1)
    assert t['a']['b']['c']['d']['e'] == 1
    # Test assignment on existing value
    set_tree_node(t, 'a:b:c:d:e', 2)
    assert t['a']['b']['c']['d']['e'] == 2


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-12 08:26:00.433801
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'foo': 'bar',
        'items': {
            'foo': 'bar',
            'baz': 'faz'
        }
    }

    assert get_tree_node(test_dict, 'foo') == 'bar'
    assert get_tree_node(test_dict, 'items:foo') == 'bar'
    assert get_tree_node(test_dict, 'items:baz', parent=True) == {'foo': 'bar', 'baz': 'faz'}
    with pytest.raises(KeyError):
        get_tree_node(test_dict, 'baz')



# Generated at 2022-06-12 08:26:03.915188
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}

    set_tree_node(d, 'a:b:c', 'd')
    set_tree_node(d, 'g:h', 'j')

    assert d == {
        'a': {'b': {'c': 'd'}},
        'g': {'h': 'j'}
    }



# Generated at 2022-06-12 08:26:12.672275
# Unit test for function get_tree_node
def test_get_tree_node():
    d = tree()
    d['this']['is']['awesome'] = True
    assert get_tree_node(d, 'this:is:awesome') is True
    assert get_tree_node(d, 'this:is:awesome') is True
    assert get_tree_node(d, 'this:is') == {'awesome': True}
    assert get_tree_node(d, 'this') == {'is': {'awesome': True}}
    assert get_tree_node(d, 'this:is', parent=True) == {'awesome': True}
    assert get_tree_node(d, 'this:is:not', default=False) is False

# Generated at 2022-06-12 08:26:17.007110
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    key = 'foo:bar:baz'
    value = 'foobar'

    set_tree_node(mapping, key, value)

    assert key == 'foo:bar:baz'
    assert mapping['foo']['bar']['baz'] == value



# Generated at 2022-06-12 08:26:20.856058
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'foo': {'bar': 'baz'}}
    assert get_tree_node(tree, 'foo:bar') == 'baz'
    assert get_tree_node(tree, 'foo:bar:') == 'baz'
    assert get_tree_node.__module__ == 'pyccel.utils'



# Generated at 2022-06-12 08:26:24.123062
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    mapping = {'baz': {'foo': 'bar'}}
    # Assert
    assert get_tree_node(mapping, 'baz:foo') == 'bar'


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:26:46.603329
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {'a': {'b': {'c': {'d': {'e': {'f': {'g': 'h'}}}}}}}
    test_key = 'a:b:c:d:e:f:g'
    value = get_tree_node(test_dict, test_key)
    assert value == 'h'



# Generated at 2022-06-12 08:26:54.355581
# Unit test for function get_tree_node
def test_get_tree_node():
    class TestMapping(collections.Mapping):
        def __init__(self, sequence, flat=True):
            self.flat = flat
            self.sequence = sequence

        def __getitem__(self, key):
            if self.flat:
                return self.sequence[key]
            return TestMapping(self.sequence[key])

        def __iter__(self):
            return self.sequence.__iter__()

        def __len__(self):
            return self.sequence.__len__()

        def __contains__(self, key):
            return self.__getitem__(key)

    # Flat mapping


# Generated at 2022-06-12 08:26:56.808754
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'



# Generated at 2022-06-12 08:27:02.439681
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'l1': {
            'l2': {
                'l3': 'foo',
            },
        },
    }

    assert get_tree_node(mapping, 'l1:l2:l3') == 'foo'
    assert get_tree_node(mapping, 'l1:l2:l3:l4') is _sentinel



# Generated at 2022-06-12 08:27:08.764430
# Unit test for function get_tree_node
def test_get_tree_node():
    # create a tree-like mapping structure
    mapping = {
        'a': '1',
        'foo': {
            'b': '2',
            'bar': {
                'c': '3',
            },
        },
    }

    # check that it finds values
    assert get_tree_node(mapping, 'a') == '1'
    assert get_tree_node(mapping, 'foo:b') == '2'
    assert get_tree_node(mapping, 'foo:bar:c') == '3'

    # and check that it fails where it should
    try:
        get_tree_node(mapping, 'foo:b:c')
    except KeyError:
        pass
    else:
        assert False, "get_tree_node should have raised KeyError"


# Generated at 2022-06-12 08:27:10.804323
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 1)
    assert mapping['a']['b']['c'] == 1



# Generated at 2022-06-12 08:27:19.067410
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test dictionary
    test = {'foo': {'bar': {'baz': {'g': 'g'}}}}

    # Test cases
    test_cases = (
        ('foo:bar:baz', {'g': 'g'}),
        ('foo:bar:baz:g', 'g'),
        ('foo:bar', {'baz': {'g': 'g'}}),
        ('foo', {'bar': {'baz': {'g': 'g'}}}),
        ('foo:foo', None),
    )

    # Assertion test
    for key, expected in test_cases:
        assert get_tree_node(test, key) == expected



# Generated at 2022-06-12 08:27:27.902549
# Unit test for function get_tree_node
def test_get_tree_node():
    # simple
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'

    three_layer = {
        'top': {
            'mid': {
                'bottom': 'eggs'
            }
        }
    }
    # multiple layer dict
    assert get_tree_node(three_layer, 'top:mid:bottom') == 'eggs'

    # default value
    assert get_tree_node({}, 'foo', 'bar') == 'bar'

    # empty
    assert get_tree_node({}, 'foo') is _sentinel

    # Test with a tree
    tree = Tree({'foo': 'bar', 'baz': {'egg': 'spam'}})
    assert tree.get('foo') == 'bar'

# Generated at 2022-06-12 08:27:32.406919
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> mapping = dict(a=dict(b=dict(c='d')))
    >>> assert get_tree_node(mapping, 'a:b')['c'] == 'd'
    """



# Generated at 2022-06-12 08:27:34.594940
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data = tree()
    set_tree_node(test_data, "name", "test")
    assert test_data["name"] == "test"



# Generated at 2022-06-12 08:28:14.753951
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'unix': {
            'linux': {
                'ubuntu': {
                    'version': '16.04'
                }
            },
            'bsd': {
                'freebsd': {
                    'version': '11.1'
                }
            }
        },
        'windows': {
            'version': '7'
        }
    }
    assert get_tree_node(test_dict, 'unix:linux:ubuntu:version') == '16.04'


test_get_tree_node()

# Generated at 2022-06-12 08:28:19.410788
# Unit test for function get_tree_node
def test_get_tree_node():
    mock_path = 'foo:bar:baz'
    mock_tree = {'foo': {'bar': {'baz': 'qux'}}}
    assert get_tree_node(mock_tree, mock_path) == 'qux'



# Generated at 2022-06-12 08:28:27.289168
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {'foo': {'bar': 'baz'}}
    assert get_tree_node(data, 'foo:bar') == 'baz'

    # test default value
    assert get_tree_node(data, 'foo:baz', default='qux') == 'qux'

    # test parent node
    assert get_tree_node(data, 'foo:bar', parent=True) == {'bar': 'baz'}
    assert get_tree_node({}, 'foo:bar', parent=True) == {}



# Generated at 2022-06-12 08:28:31.787920
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equal

    config = {'a': 1}
    assert_equal(get_tree_node(config, 'a'), 1)

    config = {'a': {'b': 1}}
    assert_equal(get_tree_node(config, 'a:b'), 1)
    assert_equal(get_tree_node(config, 'a'), {'b': 1})



# Generated at 2022-06-12 08:28:41.494715
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = Tree({
        'a': 'abc',
        'b': {
            'ba': 'babc',
            'bb': {
                'bba': 'bbabc',
                'bbb': 'def',
            }
        },
        'c': 'ghi',
    })

    # Compat
    assert get_tree_node(tree, 'a', default='moo') == 'abc'
    assert get_tree_node(tree, 'a:b', default='moo') == 'moo'
    assert get_tree_node(tree, 'b:bb:bba', default='moo') == 'bbabc'
    assert get_tree_node(tree, 'b:bb:bbb', default='moo') == 'def'

# Generated at 2022-06-12 08:28:45.819336
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'foo:bar:baz', 'xyz')
    assert d == {
        'foo': {
            'bar': {
                'baz': 'xyz'
            }
        }
    }



# Generated at 2022-06-12 08:28:52.712953
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'bleh': {},
            }

        }
    }
    assert get_tree_node(tree, 'foo:bar:bleh') == {}, 'Fetching arbitrary tree node failed'
    assert get_tree_node(tree, 'foo:bar:bleh', default=None) is None, 'Fetching arbitrary tree node failed'
    try:
        get_tree_node(tree, 'foo:bar:bleh', _sentinel)
    except KeyError:
        pass  # This is the desired behaviour



# Generated at 2022-06-12 08:29:02.831498
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup test data
    mapping = {'ubuntu': {'16.04': {'x86_64': 'amd64'}, '12.04': {'x86': 'i386'}},
               'freebsd': {'10': {'amd64': 'amd64'}, '9': {'x86_64': 'amd64'}}}

    # Test get_tree_node
    print(get_tree_node(mapping, 'ubuntu', _sentinel))
    print(get_tree_node(mapping, 'ubuntu:16.04', _sentinel))
    print(get_tree_node(mapping, 'ubuntu:16.04:x86_64', _sentinel))
    print(get_tree_node(mapping, 'ubuntu:16.04:x86', default='missing'))



# Generated at 2022-06-12 08:29:08.112397
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test get_tree_node
    test_tree = {
        'test': {
            'test': 'value'
        }
    }
    assert get_tree_node(test_tree, 'test:test') == 'value'
    assert get_tree_node(test_tree, 'test:test:test:test:test') is _sentinel



# Generated at 2022-06-12 08:29:14.571778
# Unit test for function set_tree_node
def test_set_tree_node():
    example_tree = tree()
    example_tree['a'] = 'b'
    set_tree_node(example_tree, 'c:d:e:f:g:h:i', 'j')
    assert example_tree == {
        'a': 'b',
        'c': {
            'd': {
                'e': {
                    'f': {
                        'g': {
                            'h': {
                                'i': 'j',
                            }
                        }
                    }
                }
            }
        }
    }

