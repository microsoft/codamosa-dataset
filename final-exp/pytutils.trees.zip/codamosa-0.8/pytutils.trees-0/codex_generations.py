

# Generated at 2022-06-12 08:20:01.986404
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree()
    tree.set_tree_node('foo:bar:baz', 'qux')
    assert tree['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-12 08:20:08.008520
# Unit test for function set_tree_node
def test_set_tree_node():
    my_tree = tree()
    set_tree_node(my_tree, 'baz:foo:boo', 'baz')
    set_tree_node(my_tree, 'baz:foo:bar', 'boo')
    assert get_tree_node(my_tree, 'baz:foo:boo') == 'baz'
    assert get_tree_node(my_tree, 'baz:foo:bar') == 'boo'
    return my_tree



# Generated at 2022-06-12 08:20:17.022977
# Unit test for function set_tree_node
def test_set_tree_node():
    """Tests `set_tree_node`."""
    a = {}
    assert set_tree_node(a, 'a', 1) == {
        'a': 1
    }
    assert a == {
        'a': 1
    }
    assert set_tree_node(a, 'a:b', 2) == {
        'a': {
            'b': 2
        }
    }
    assert a == {
        'a': {
            'b': 2
        }
    }
    assert set_tree_node(a, 'a:c', 3) == {
        'a': {
            'b': 2,
            'c': 3
        }
    }
    assert a == {
        'a': {
            'b': 2,
            'c': 3
        }
    }


# Generated at 2022-06-12 08:20:22.654484
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'bar': {'baz': 'baz'}}
    mapping_1 = {'bar': {'baz': 'baz'}, ('bar',): {'baz': 'baz'}}
    assert get_tree_node(mapping_1, 'bar:baz') == 'baz'
    assert get_tree_node(mapping, 'bar:baz') == 'baz'



# Generated at 2022-06-12 08:20:29.955785
# Unit test for function get_tree_node
def test_get_tree_node():
    t = Tree({'A': {'B': {'C': 3}}})
    _3 = get_tree_node(t, 'A:B:C')
    assert _3 == 3
    try:
        o_o = get_tree_node(t, 'A:B:C:D')
    except KeyError:
        pass
    else:
        raise AssertionError("Expected KeyError, got %s" % o_o)



# Generated at 2022-06-12 08:20:34.971019
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar', 1)

# Generated at 2022-06-12 08:20:37.980041
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    node = set_tree_node(d, 'foo:bar:baz', 'HELLO')
    assert node == {'baz': 'HELLO'}
    assert d['foo']['bar'] == {'baz': 'HELLO'}



# Generated at 2022-06-12 08:20:46.622356
# Unit test for function get_tree_node
def test_get_tree_node():
    import json
    import pytest

    d = json.loads('{"a": {"b": {"c": {"d": "foo"}}}}')

    assert get_tree_node(d, 'a:b:c:d') == 'foo'

    with pytest.raises(KeyError):
        get_tree_node(d, 'a:b:c:e')

    with pytest.raises(KeyError):
        get_tree_node(d, 'a:b:c:e', False)

    assert get_tree_node(d, 'a:b:c:e', False, True) == {'d': 'foo'}



# Generated at 2022-06-12 08:20:56.045537
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for get_tree_node"""
    foo = {'bar': {'baz': 'qux'}}
    assert get_tree_node(foo, 'bar') == {'baz': 'qux'}
    assert get_tree_node(foo, 'bar') == {'baz': 'qux'}
    assert get_tree_node(foo, 'bar:baz') == 'qux'
    assert get_tree_node(foo, 'bar:baz') == 'qux'
    assert get_tree_node(foo, 'bar:baz:qux') is None
    assert get_tree_node(foo, 'bar:baz:qux') is None
    assert get_tree_node(foo, 'bar:baz:qux', default='foolish') == 'foolish'

# Generated at 2022-06-12 08:21:04.682178
# Unit test for function set_tree_node
def test_set_tree_node():

    tree = {}
    set_tree_node(tree, 'a:b:c', 'blah')
    assert 'a' in tree
    assert 'b' in tree['a']
    assert 'c' in tree['a']['b']
    assert tree['a']['b']['c'] == 'blah'
    set_tree_node(tree, 'a:b:c', 'bah')
    assert tree['a']['b']['c'] == 'bah'
    set_tree_node(tree, 'a:b:d', 'blah')
    assert 'a' in tree
    assert 'b' in tree['a']
    assert 'c' in tree['a']['b']
    assert 'd' in tree['a']['b']

# Generated at 2022-06-12 08:21:16.767989
# Unit test for function get_tree_node
def test_get_tree_node():
    from collections import Mapping

    m = {
        'a': {
            'b': {
                'c': 5,
                'd': 7,
            },
            'e': {
                'f': 9,
            },
        },
    }
    assert isinstance(m, Mapping)

    # Dimension = 1
    assert get_tree_node(m, 'a') == m['a']
    assert get_tree_node(m, 'a', parent=True) == m

    # Dimension = 2
    assert get_tree_node(m, 'a:b') == m['a']['b']
    assert get_tree_node(m, 'a:b', parent=True) == m['a']

    # Dimension = 3

# Generated at 2022-06-12 08:21:20.355502
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', {'d': 'e'})
    assert d['a']['b']['c']['d'] == 'e'



# Generated at 2022-06-12 08:21:21.687084
# Unit test for function get_tree_node
def test_get_tree_node():
    test_node = get_tree_node({
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }, key='a:b:c')

    assert test_node == 'd'



# Generated at 2022-06-12 08:21:25.723669
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'key_a': 'value_a',
        'key_b': {
            'key_1': 'value_1',
            'key_2': 'value_2'
        }
    }

    # Simple
    assert get_tree_node(test_tree, 'key_a') == 'value_a'

    # Parent
    assert get_tree_node(test_tree, 'key_b:key_2', parent=True) == {
        'key_1': 'value_1',
        'key_2': 'value_2'
    }

    # Default
    assert get_tree_node(test_tree, 'key_c', 'This is a default value') == 'This is a default value'

    # Recursive

# Generated at 2022-06-12 08:21:30.094067
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'a': {'b': {'c': 'd'}}}

    # set_tree_node
    assert set_tree_node(mapping, 'a:b', 'e') == {'b': 'e'}
    assert set_tree_node(mapping, 'a:b:c', 'f') == {'c': 'f'}



# Generated at 2022-06-12 08:21:35.678871
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test function `set_tree_node`."""
    mapping = {'foo': {'bar': 'baz'}}
    new_node = set_tree_node(mapping, 'foo:bar:quux', 'quuz')
    assert mapping == {'foo': {'bar': {'quux': 'quuz'}}}
    assert new_node == {'quux': 'quuz'}



# Generated at 2022-06-12 08:21:42.598997
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'one': '1',
        'two': {'three': '3', 'four': '4'},
    }

    assert get_tree_node(test_tree, 'two:three') == '3'
    assert get_tree_node(test_tree, 'two:four') == '4'
    assert get_tree_node(test_tree, 'two:five', default=None) is None

    with pytest.raises(KeyError):
        get_tree_node(test_tree, 'two:five')



# Generated at 2022-06-12 08:21:48.895559
# Unit test for function set_tree_node
def test_set_tree_node():
    server_config = {}
    set_tree_node(server_config, 'name', 'iax-server')
    set_tree_node(server_config, 'foo:bar:baz', 'qux')
    assert server_config == {
        'name': 'iax-server',
        'foo': {'bar': {'baz': 'qux'}}
    }



# Generated at 2022-06-12 08:21:52.360913
# Unit test for function set_tree_node
def test_set_tree_node():
    obj = {}
    set_tree_node(obj, 'a:b', 'test')
    set_tree_node(obj, 'a:c', 'test1')
    assert eq({'a': {'b': 'test', 'c': 'test1'}}, obj)



# Generated at 2022-06-12 08:21:56.016886
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'



# Generated at 2022-06-12 08:22:08.710876
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'key': 10,
        'key2': {
            'another_key': 20,
            'yet_another_key': {
                'the_last_key': 100,
            }
        },
        'key3': {
            'foo': 'bar',
            'baz': {
                'woot': 'hooray',
            }
        },
        'sweet': 'bread',
    }

    assert get_tree_node(mapping, 'key3:baz:woot') == 'hooray'

    assert get_tree_node(mapping, 'key3:baz:woot', default='hello') == 'hooray'
    assert get_tree_node(mapping, 'key3:baz:sweet', default='hello') == 'hello'

    assert get_tree

# Generated at 2022-06-12 08:22:16.637585
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    key_name = 'key:name'
    value = "value1"
    try:
        set_tree_node(tree, key_name, value)
    except KeyError:
        pass
    except:
        assert False, "Wrong Exception"
    assert len(tree) == 1, "Wrong number of elements"
    assert 'key' in tree, "Wrong key"
    assert 'name' in tree['key'], "Wrong key"
    assert tree['key']['name'] == value, "Wrong Value"



# Generated at 2022-06-12 08:22:24.301423
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    >>>
    """
    mapping = Tree(
        {
            'numeric': {
                'int42': 42,
                'float42': 42.0,
            },
            'str': {
                'foobar': 'foobar',
                'foo:bar': 'foo:bar',
                'list': ['foo', 'bar'],
                'dict': {'foo': 'bar'},
            }
        }
    )

    assert get_tree_node(mapping, 'numeric:int42') == 42
    assert get_tree_node(mapping, 'numeric:float42') == 42

    assert get_tree_node(mapping, 'str:foobar') == 'foobar'

# Generated at 2022-06-12 08:22:27.230280
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'foo:bar:baz', 'value')
    assert d == {'foo': {'bar': {'baz': 'value'}}}



# Generated at 2022-06-12 08:22:36.278931
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'yay',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'yay'
    assert get_tree_node(mapping, 'foo') == {'bar': {'baz': 'yay'}}
    assert get_tree_node(mapping, 'foo:bar') == {'baz': 'yay'}
    try:
        assert get_tree_node(mapping, 'foo:bar:paz')
    except KeyError:
        pass
    else:
        assert False, "Shouldn't get here"

# Generated at 2022-06-12 08:22:39.729190
# Unit test for function set_tree_node
def test_set_tree_node():
    _t = {}
    assert set_tree_node(_t, 'hello:world', 'planet') == {'hello': {'world': 'planet'}}
    assert set_tree_node(_t, 'test', 'value') == {'test': 'value'}



# Generated at 2022-06-12 08:22:42.539294
# Unit test for function set_tree_node
def test_set_tree_node():
    foo = tree()
    set_tree_node(foo, 'a:b', 'c')
    assert foo['a']['b'] == 'c'



# Generated at 2022-06-12 08:22:45.481228
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {"foo": {"bar": 'baz'}}
    assert get_tree_node(mapping, "foo:bar") == "baz"



# Generated at 2022-06-12 08:22:50.424454
# Unit test for function get_tree_node
def test_get_tree_node():
    root = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(root, 'a:b:c') == 'd'
    assert get_tree_node(root, 'a:b:c:d') == _sentinel
    assert get_tree_node(root, 'a:b:c:d', default='nope') == 'nope'



# Generated at 2022-06-12 08:22:57.858811
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'test': {
            'test': ['foo', 'bar']
        }
    }
    assert get_tree_node(mapping, 'test:test') == ['foo', 'bar']
    assert get_tree_node(mapping, 'test:test:0') == 'foo'
    assert get_tree_node(mapping, 'test:test', parent=True) == {'test': ['foo', 'bar']}
    assert get_tree_node(mapping, 'spam', default='ham') == 'ham'



# Generated at 2022-06-12 08:23:13.580978
# Unit test for function get_tree_node
def test_get_tree_node():
    from pprint import pprint
    from infi.pyutils.lazy import cached_method

    class Animal(object):
        def __init__(self, name, parents=None, children=None):
            self.name = name
            self.parents = parents or []
            self.children = children or []

        def __repr__(self):
            return self.name

        def get_parents(self):
            return [self.__class__(parent_name) for parent_name in self.parents]

        @cached_method
        def get_child(self, child_name):
            return self.__class__(child_name, parents=[self.name])


# Generated at 2022-06-12 08:23:20.433099
# Unit test for function get_tree_node
def test_get_tree_node():
    def test_get_tree_node_single(mapping):
        assert get_tree_node(mapping, 'foo') == mapping['foo']

    test_get_tree_node_single({'foo': 'bar'})

    def test_get_tree_node_dimension(mapping):
        assert get_tree_node(mapping, 'foo:bar') == mapping['foo']['bar']

    test_get_tree_node_dimension({'foo': {'bar': 'bazz'}})

    def test_get_tree_node_dimension_parent(mapping):
        assert get_tree_node(mapping, 'foo:bar', parent=True) == mapping['foo']

    test_get_tree_node_dimension_parent({'foo': {'bar': 'bazz'}})


# Generated at 2022-06-12 08:23:29.867783
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'foo') is _sentinel

    mapping = {
        'foo': {
            'bar': {}
        },
        'baz': {
            'qux': {
                'wtf': 'foo'
            }
        },
        'a': 'b',
        'c': [0, 1, 2]
    }
    assert get_tree_node(mapping, 'foo:bar') == {}
    assert get_tree_node(mapping, 'baz:qux:wtf') == 'foo'
    assert get_tree_node(mapping, 'c') == [0, 1, 2]

    # Default value
    assert get_tree_node({}, 'foo', default=[]).__class__ == list
    assert get_tree_node({}, 'foo', default=[])

# Generated at 2022-06-12 08:23:39.741518
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node."""
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'value')
    assert tree == {'foo': {'bar': {'baz': 'value'}}}
    set_tree_node(tree, 'foo:bar:nested', 'value')
    assert tree == {'foo': {'bar': {'baz': 'value', 'nested': 'value'}}}
    set_tree_node(tree, 'foo:bar:baz', 'new value')
    assert tree == {'foo': {'bar': {'baz': 'new value', 'nested': 'value'}}}
    return True



# Generated at 2022-06-12 08:23:44.997321
# Unit test for function set_tree_node
def test_set_tree_node():
    import unittest

    data = collections.OrderedDict()
    key = 'alpha:bravo:charlie'
    value = 'delta'
    result = set_tree_node(data, key, value)
    data_expect = {
        'alpha': {
            'bravo': {
                'charlie': value,
            }
        }
    }
    result_expect = {'charlie': value}
    assert data == data_expect
    assert result == result_expect


# Generated at 2022-06-12 08:23:48.264521
# Unit test for function set_tree_node
def test_set_tree_node():
    data = tree()
    set_tree_node(data, 'foo:bar:baz', 'testdata')
    assert data['foo']['bar']['baz'] == 'testdata'



# Generated at 2022-06-12 08:23:59.852322
# Unit test for function set_tree_node
def test_set_tree_node():
    import unittest
    from collections import Mapping

    class Test(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
            a = collections.defaultdict(dict)
            namespace = 'test'
            set_tree_node(a, '%s:b:c' % namespace, 'test')
            set_tree_node(a, '%s:b:d' % namespace, 'test')
            self.a = a
            self.namespace = namespace

        def test_type(self):
            assert isinstance(self.a, Mapping)

        def test_keys(self):
            assert 'test' in self.a, "Parent level key test not found in tree dictionary"

# Generated at 2022-06-12 08:24:09.781632
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {
        'a': {
            'b': 'c',
        },
        'd': {
            'e': {
                'f': 'g',
            },
        },
    }
    assert get_tree_node(t, 'a:b') == 'c'
    assert get_tree_node(t, 'a') == {
        'b': 'c',
    }
    assert get_tree_node(t, 'd:e') == {
        'f': 'g',
    }
    assert get_tree_node(t, 'd:e:f') == 'g'

    # Test default-based nonexistence
    assert get_tree_node(t, 'nonexistent') is _sentinel
    assert get_tree_node(t, 'nonexistent', default=None) is None

# Generated at 2022-06-12 08:24:13.432015
# Unit test for function get_tree_node
def test_get_tree_node():
    input = {
        'foo': {
            'bar': {
                'baz': 'This is baz'
            }
        }
    }
    assert get_tree_node(input, 'foo:bar:baz') == 'This is baz'

# Generated at 2022-06-12 08:24:24.318218
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.OrderedDict()
    mapping['foo'] = collections.OrderedDict()
    mapping['foo']['bar'] = collections.OrderedDict()
    mapping['foo']['bar']['baz'] = 'Hello, World!'
    assert mapping == {'foo': {'bar': {'baz': 'Hello, World!'}}}
    node = set_tree_node(mapping, 'foo:bar:baz', 'Goodbye, World!')
    assert mapping['foo']['bar']['baz'] == 'Goodbye, World!'
    assert node == set_tree_node(mapping, 'foo', 'Goodbye, World!')


if __name__ == '__main__':
    import sys
    import pytest

# Generated at 2022-06-12 08:24:50.483602
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(m, 'a:b') == {'c': 'd'}
    assert get_tree_node(m, 'a') == {'b': {'c': 'd'}}
    assert get_tree_node(m, 'a:b:c', default=True) == 'd'
    assert get_tree_node(m, 'a:b:c:d') == {'c': 'd'}
    assert get_tree_node(m, 'a:b:c:d', default=True) is True
    assert get_tree_node(m, 'a:b:c:d', default=_sentinel) is _sentinel



# Generated at 2022-06-12 08:24:57.551676
# Unit test for function get_tree_node
def test_get_tree_node():
    factoid = {
        'sits': {
            'on': {
                'potato': 'box'
            }
        }
    }

    assert get_tree_node(factoid, 'sits:on:potato') == 'box'
    assert get_tree_node(factoid, 'sits:on', default='not found') == 'not found'
    assert get_tree_node(factoid, 'sits:on:doesnotexist') is KeyError
    assert get_tree_node(factoid, 'sits:on:doesnotexist', default='not found') == 'not found'



# Generated at 2022-06-12 08:25:05.461710
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'test'
            }
        }
    }

    set_tree_node(mapping, 'xxx:yyy', 'Hello world!')
    assert mapping == {
        'foo': {
            'bar': {
                'baz': 'test'
            }
        },
        'xxx': {
            'yyy': 'Hello world!'
        }
    }

    set_tree_node(mapping, 'foo:bar:baz', 'haha')
    assert mapping == {
        'foo': {
            'bar': {
                'baz': 'haha'
            }
        },
        'xxx': {
            'yyy': 'Hello world!'
        }
    }



# Generated at 2022-06-12 08:25:09.822416
# Unit test for function get_tree_node
def test_get_tree_node():

    d = {
        'foo': {
            'bar': {
                'baz': 'dong',
            }
        }
    }

    assert get_tree_node(d, 'foo:bar') == {'baz': 'dong'}



# Generated at 2022-06-12 08:25:21.048903
# Unit test for function set_tree_node
def test_set_tree_node():
    from json import loads, dumps
    test_data = {
        'a': {
            'b': {
                'c': 'd',
            }
        }
    }

    # Test root-level set
    set_tree_node(test_data, 'a:b:c', 'd')
    assert test_data['a']['b']['c'] == 'd'

    # Test new-node set
    set_tree_node(test_data, 'a:b:e', 'f')
    assert test_data['a']['b']['e'] == 'f'

    # Test top-level set
    set_tree_node(test_data, 'g', 'h')
    assert test_data['g'] == 'h'

    # Test reset

# Generated at 2022-06-12 08:25:24.987694
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 5}}}, 'a:b:c') is 5
    assert get_tree_node({'a': {'b': {'c': 5}}}, 'a:b:d', default=_sentinel) is _sentinel



# Generated at 2022-06-12 08:25:27.198665
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'a:b:c', 'beep')
    assert mapping['a']['b']['c'] == 'beep'



# Generated at 2022-06-12 08:25:36.395239
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 1,
            },
        },
    }
    test_cases = [
        # (args, kwargs, expected output)
        (('a:b:c',), {}, 1),
        (('a:b:c',), {'parent': True}, {'c': 1}),
        (('a:b:d',), {}, _sentinel),
    ]
    for case, kwargs, expected in test_cases:
        rv = get_tree_node(tree, *case, **kwargs)
        assert rv == expected, 'Test case failed: get_tree_node(%r, %r) returned %r, expected %r' % (
            tree, case, rv, expected
        )

# Generated at 2022-06-12 08:25:43.458869
# Unit test for function set_tree_node
def test_set_tree_node():
    # Initialize needed variables
    base_object = {'foo': {'bar': 'baz'}}
    # This is a test for namespaces
    assert set_tree_node(base_object, 'foo:bar', 'quux') == {'foo': {'bar': 'quux'}}
    # This is a test for multiple "deep" modifications
    assert set_tree_node(base_object, 'foo:bar:baz', 'quux') == {'foo': {'bar': 'quux'}}



# Generated at 2022-06-12 08:25:53.551304
# Unit test for function get_tree_node
def test_get_tree_node():
    # Testing KeyError
    d = {'foo': {'bar': {'baz': 'lel'}}}
    assert get_tree_node(d, 'foo:bar:baz') == 'lel'
    assert get_tree_node(d, 'foo:bar:baz:wat') is _sentinel
    assert get_tree_node(d, 'foo:bar:baz', default='meow') == 'lel'
    assert get_tree_node(d, 'foo:bar:baz:wat', default='meow') == 'meow'
    # Testing parent node
    assert d == get_tree_node(d, 'foo:bar:baz', parent=True)



# Generated at 2022-06-12 08:26:16.923949
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'test': 'success'}, 'test') == 'success'
    assert get_tree_node({'test': {'nested': 'success'}}, 'test:nested') == 'success'
    assert get_tree_node({'test': {'nested': 'success'}}, 'test:nested:') == 'success'
    assert get_tree_node({'test': {'nested': 'success'}}, 'test:foo') == _sentinel


# Generated at 2022-06-12 08:26:23.456673
# Unit test for function get_tree_node
def test_get_tree_node():
    print("Testing get_tree_node() function")
    d = dict(a=dict(b=dict(c=1, d=2), e=3))
    assert(get_tree_node(d, 'a:b:c') == 1)
    assert(get_tree_node(d, 'a:e') == 3)
    assert(get_tree_node(d, 'a:b') == dict(c=1, d=2))
    assert(get_tree_node(d, 'a:f', default=5) == 5)
    try:
        get_tree_node(d, 'a:f')
    except KeyError:
        pass
    else:
        raise RuntimeError("Expected KeyError")



# Generated at 2022-06-12 08:26:29.641249
# Unit test for function get_tree_node
def test_get_tree_node():

    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    # Test finding a key
    assert get_tree_node(mapping, 'a:b:c') == 'd'

    # Test returning a parent node
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd'}



# Generated at 2022-06-12 08:26:35.734039
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='c', parent=True) == 'c'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b', default='c', parent=True) == 'c'



# Generated at 2022-06-12 08:26:39.279706
# Unit test for function set_tree_node
def test_set_tree_node():
    registry = tree()
    set_tree_node(registry, 'core:database:name', 'proba')
    assert registry['core']['database']['name'] == 'proba'



# Generated at 2022-06-12 08:26:41.650771
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    set_tree_node(a, 'a:b:c', 'foo')
    assert a['a']['b']['c'] == 'foo'

# Generated at 2022-06-12 08:26:52.159958
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': 'baz'}, 'bar': {'foo': 'baz'}}
    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'bar:foo') == 'baz'
    assert get_tree_node(mapping, 'foo') == {'bar': 'baz'}
    assert get_tree_node(mapping, 'bar') == {'foo': 'baz'}
    assert get_tree_node(mapping, 'bar', default='baz') == {'foo': 'baz'}
    assert get_tree_node(mapping, 'foo', default=['baz']) == {'bar': 'baz'}



# Generated at 2022-06-12 08:27:03.295628
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': {
            'bar': 'baz',
            'baz': [
                {'beer': 'yum'}
            ]
        },
        'abc': 'def',
    }

    assert get_tree_node(data, 'abc') == 'def'
    assert get_tree_node(data, 'foo') == data['foo']
    assert get_tree_node(data, 'foo:bar') == 'baz'
    assert get_tree_node(data, 'foo:baz:0:beer') == 'yum'

    try:
        get_tree_node(data, 'foo:baz:0:meh')
    except KeyError:
        pass
    else:
        raise AssertionError('get_tree_node did not raise an KeyError.')

   

# Generated at 2022-06-12 08:27:12.553473
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'test': {
            'test2': {
                'test3': 'hello',
            }
        }
    }

    assert get_tree_node(test_dict, 'test:test2:test3') == 'hello'
    assert get_tree_node(test_dict, 'test:test2:test3', default=_sentinel) == 'hello'
    assert get_tree_node(test_dict, 'test:test2:test3:test4', default=_sentinel) is _sentinel
    assert get_tree_node(test_dict, 'test:test2:test3:test4', default=False) is False
    assert get_tree_node(test_dict, 'test:test2:test3:test4', default='fail') == 'fail'
    assert get_

# Generated at 2022-06-12 08:27:19.030833
# Unit test for function get_tree_node
def test_get_tree_node():
    import json
    import os
    import tempfile
    tf = tempfile.mktemp()

    with open(tf, 'w') as f:
        json.dump({'a': {'b': {'c': 'd'}}}, f)

    try:
        mapping = json.load(open(tf, 'r'))
        os.remove(tf)
        assert get_tree_node(mapping, 'a:b:c') == 'd'
    except IOError as e:
        print(e)



# Generated at 2022-06-12 08:27:55.956191
# Unit test for function get_tree_node
def test_get_tree_node():
    my_dict = tree()
    my_dict[:int:is_odd] = 23
    assert get_tree_node(my_dict, ':int:is_odd') == 23



# Generated at 2022-06-12 08:27:58.964562
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': 'bar'}, 'baz') == {}
    assert get_tree_node({'foo': 'bar'}, 'baz', 'buz') == 'buz'

# Generated at 2022-06-12 08:28:09.320951
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = {}
    assert test_tree == {}
    set_tree_node(test_tree, 'a', 1)
    assert test_tree == {'a': 1}
    set_tree_node(test_tree, 'b:c', 2)
    assert test_tree == {'a': 1, 'b': {'c': 2}}
    set_tree_node(test_tree, 'd:e:f', 3)
    assert test_tree == {'a': 1, 'b': {'c': 2}, 'd': {'e': {'f': 3}}}
    set_tree_node(test_tree, 'd:g', 4)

# Generated at 2022-06-12 08:28:16.710444
# Unit test for function set_tree_node

# Generated at 2022-06-12 08:28:23.721637
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    assert get_tree_node({'foo': {'bar': {'baz': 'lorum'}}}, 'foo:bar:baz') == 'lorum'
    assert get_tree_node({'foo': {'bar': {'baz': 'lorum'}}}, 'foo:bar:baz', parent=True) == {'baz': 'lorum'}
    assert get_tree_node({'foo': {'bar': {'baz': 'lorum'}}}, 'foo', parent=True) == {'bar': {'baz': 'lorum'}}
    assert get_tree_node({'foo': {'bar': {'baz': 'lorum'}}}, 'foo:bar:baz:plop') is _sentinel


# Unit test

# Generated at 2022-06-12 08:28:29.667794
# Unit test for function set_tree_node
def test_set_tree_node():
    b = {}
    assert set_tree_node(b, 'a:b:c', "value") == {'b': {'c': "value"}}

# Generated at 2022-06-12 08:28:39.385130
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    test_data = {
        'foo': {
            'bar': {
                'baz': 1,
                'boo': 'Hello world!'
            }
        }
    }

    # Test parent
    parent = get_tree_node(test_data, 'foo:bar:baz', default=_sentinel, parent=True)
    assert parent == {
        'baz': 1,
        'boo': 'Hello world!'
    }

    parent = get_tree_node(test_data, 'foo:bar:baz', default={}, parent=True)
    assert parent == {
        'baz': 1,
        'boo': 'Hello world!'
    }

    # Test non-existent key

# Generated at 2022-06-12 08:28:42.740627
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'bop'
            }
        },
        'fizz': 'buzz'
    }
    assert get_tree_node(tree, 'foo:bar:baz') == 'bop'
    assert get_tree_node(tree, 'fizz') == 'buzz'



# Generated at 2022-06-12 08:28:50.564982
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'toplevel': {
            'a': {
                'b': 'c'
            }
        },
        'toplevel2': 'foo'
    }
    result = get_tree_node(mapping, 'toplevel:a:b')
    assert result == 'c'
    result = get_tree_node(mapping, 'toplevel2')
    assert result == 'foo'
    result = get_tree_node(mapping, 'toplevel3:foo:bar', default='nothing')
    assert result == 'nothing'

# Generated at 2022-06-12 08:28:59.851389
# Unit test for function get_tree_node
def test_get_tree_node():
    _in = {
        'foo': 'bar',
        'spam': {
            'ham': {
                'foo': 'baz',
            },
            'eggs': 'foo',
        },
    }

    assert get_tree_node(_in, 'foo') == 'bar'
    assert get_tree_node(_in, 'spam.ham.foo') == 'baz'
    assert get_tree_node(_in, 'spam.ham.foo', parent=True) == {'foo': 'baz'}
    with pytest.raises(KeyError):
        assert get_tree_node(_in, 'spam.ham.foo.bar')