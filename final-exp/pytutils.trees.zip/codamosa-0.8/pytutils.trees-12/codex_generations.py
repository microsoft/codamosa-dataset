

# Generated at 2022-06-12 08:20:02.677500
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['my']['fail']['whale'] = '1234'
    mapping['my']['fail']['wail'] = '5678'
    assert get_tree_node(mapping, 'my:fail:whale') == '1234'



# Generated at 2022-06-12 08:20:07.675389
# Unit test for function set_tree_node
def test_set_tree_node():
    node = tree()
    set_tree_node(node, 'a:b:c', 'TEST')
    assert node['a']['b']['c'] == 'TEST'

    # Exception test
    try:
        set_tree_node(node, 'a:b:d', 'TEST')
        assert False
    except AttributeError:
        pass



# Generated at 2022-06-12 08:20:14.661397
# Unit test for function get_tree_node
def test_get_tree_node():

    test_tree = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz'
            }
        }
    }

    assert get_tree_node(test_tree, 'foo') == {'bar': {'baz': 'foobarbaz'}}
    assert get_tree_node(test_tree, 'foo:bar') == {'baz': 'foobarbaz'}
    assert get_tree_node(test_tree, 'foo:bar:baz') == 'foobarbaz'

# Generated at 2022-06-12 08:20:17.144544
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'foo:bar:baz', 'ok')
    assert d.get('foo:bar:baz') == 'ok'



# Generated at 2022-06-12 08:20:28.375617
# Unit test for function get_tree_node
def test_get_tree_node():
    dic = {
        'k0': 'v0',
        'k1': {
            'k1.1': {
                'k1.1.1': 'v1.1.1',
            },
            'k1.2': 'v1.2',
        },
        'k2': ['v2.0', 'v2.1', 'v2.2'],
    }
    assert 'v0' == get_tree_node(dic, 'k0')
    assert 'v1.1.1' == get_tree_node(dic, 'k1:k1.1:k1.1.1')
    assert ['v2.0', 'v2.1', 'v2.2'] == get_tree_node(dic, 'k2')
    assert 'v2.2'

# Generated at 2022-06-12 08:20:34.559968
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'db': {
            'default': {
                'user': 'dbuser',
                'password': 'dbpass',
            }
        }
    }
    assert get_tree_node(data, 'db:default:user') == 'dbuser'
    try:
        get_tree_node(data, 'db:nonexistent')
    except KeyError:
        pass
    else:
        assert False, 'Failed to raise KeyError'



# Generated at 2022-06-12 08:20:37.403016
# Unit test for function get_tree_node
def test_get_tree_node():
    b = collections.defaultdict(dict)
    b['foo']['bar'] = 'baz'
    assert b['foo']['bar'] == 'baz'
    assert get_tree_node(b, 'foo:bar') == 'baz'



# Generated at 2022-06-12 08:20:47.124804
# Unit test for function get_tree_node
def test_get_tree_node():
    import pytest
    deep = {'name': {'first': 'Ryan', 'last': 'Florence'}}
    assert get_tree_node(deep, 'name:first') == 'Ryan', 'get_tree_node should return the value at a deep key.'
    assert get_tree_node(deep, 'name:last') == 'Florence', 'get_tree_node should return the value at a deep key.'
    assert get_tree_node(deep, 'name'), 'get_tree_node should return the parent node.'
    with pytest.raises(KeyError) as excinfo:
        get_tree_node(deep, 'missing')
    assert 'missing' in str(excinfo), 'get_tree_node should raise a key error if the mapping is missing.'



# Generated at 2022-06-12 08:20:56.360669
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        '_': {
            'inner_1': {
                'inner_2': {
                    'inner_3': {},
                },
            },
        },
    }

    # Assert that it can retrieve a leaf node
    test_leaf = get_tree_node(test_dict, '_:inner_1:inner_2:inner_3')

    # Assert that it can retrieve a non-leaf node
    test_non_leaf = get_tree_node(test_dict, '_:inner_1:inner_2')

    # Assert that it returns default value when desired
    test_default = get_tree_node(test_dict, '_:inner_1:inner_2:inner_9', default={})

    # Assert that it raises when desired
    def inner():
        get

# Generated at 2022-06-12 08:21:03.519205
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == {'d': 'e'}
    assert get_tree_node(tree, 'a:b') == {'c': {'d': 'e'}}
    assert get_tree_node(tree, 'a:b:c:d') == 'e'
    assert get_tree_node(tree, 'a:b:c:d:e') == KeyError

# Generated at 2022-06-12 08:21:15.067914
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'key': 'value',
        'key2': {
            'key3': {
                'key4': 'value2'
            }
        }
    }
    tests = [
        ('key', 'value'),
        ('key2:key3:key4', 'value2'),
        ('key5:key6', _sentinel),
    ]
    for test in tests:
        key, value = test

# Generated at 2022-06-12 08:21:18.346569
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    set_tree_node(test_tree, 'a:b:c', 'foo')
    assert test_tree['a']['b']['c'] == 'foo'



# Generated at 2022-06-12 08:21:24.752595
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node."""
    from tree import get_tree_node
    #_sentinel = object()
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is None
    assert get_tree_node(mapping, 'a:b:c:d', default=_sentinel) is _sentinel



# Generated at 2022-06-12 08:21:34.298227
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'about': {'version': 1.0, 'author': 'foobar'}}

    # Test for node at key with : notation
    assert get_tree_node(tree, 'about:version') == 1.0

    # Test for non-existent key, and default=None
    assert get_tree_node(tree, 'about:language', default=None) is None

    # Test for non-existent key, and default=_sentinel
    try:
        get_tree_node(tree, 'about:language')
    except KeyError:
        pass
    else:
        assert False, 'KeyError not raised on non-existent key.'

    # Test for key with non-existent parent
    try:
        get_tree_node(tree, 'about:foo:bar')
    except KeyError:
        pass

# Generated at 2022-06-12 08:21:43.397187
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_a = tree()
    tree_a['a']['b'] = 1
    assert get_tree_node(tree_a, 'a:b') == 1

    tree_b = {'a': {'b': {'c': 1}}}
    assert get_tree_node(tree_b, 'a:b:c') == 1

    tree_c = {'a': {'b': {'c': 1}}}
    assert get_tree_node(tree_c, 'a:b:c', parent=True) == tree_c['a']['b']

    with pytest.raises(KeyError):
        get_tree_node(tree_a, 'a:b:c')


# Generated at 2022-06-12 08:21:49.576418
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node."""
    tree = {}
    set_tree_node(tree, 'key:tree:node:0', 1)
    assert tree['key']['tree']['node'] == {0: 1}, 'set_tree_node did not set specified node'


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-12 08:21:52.498238
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test method to ensure that tree nodes may be set.
    """
    data = tree()
    set_tree_node(data, 'test:test', 'hello')
    assert data['test']['test'] == 'hello'



# Generated at 2022-06-12 08:21:56.488252
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c:d:e:f', 3)
    assert mapping == {'a': {'b': {'c': {'d': {'e': {'f': 3}}}}}}



# Generated at 2022-06-12 08:22:01.716561
# Unit test for function set_tree_node
def test_set_tree_node():
    class EmptyMapping(object):
        """Empty mapping object to test set_tree_node."""

    empty_mapping = EmptyMapping()
    set_tree_node(empty_mapping, 'foo:bar:baz', 'value')

    assert empty_mapping.foo.bar.baz == 'value'



# Generated at 2022-06-12 08:22:09.560509
# Unit test for function get_tree_node
def test_get_tree_node():
    """get_tree_node function test suite."""
    tree = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': {
                            'F': 'Hello',
                        }
                    }
                }
            }
        }
    }

    assert get_tree_node(tree, 'a') == tree['a']
    assert get_tree_node(tree, 'a:b:c:d') == tree['a']['b']['c']['d']
    assert get_tree_node(tree, 'a:b:c:d:e') == tree['a']['b']['c']['d']['e']

# Generated at 2022-06-12 08:22:19.298889
# Unit test for function get_tree_node
def test_get_tree_node():

    mapping = tree()
    mapping['foo']['bar'] = 'baz'

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'bar', default='baz') == 'baz'
    assert get_tree_node(mapping, 'bar') == _sentinel



# Generated at 2022-06-12 08:22:21.609140
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_data = {}
    node = set_tree_node(tree_data, 'subtree:node', 'node value')
    assert node == {'subtree': {'node': 'node value'}}

# Generated at 2022-06-12 08:22:29.798627
# Unit test for function get_tree_node
def test_get_tree_node():
    # Create a tree-like mapping structure
    testDict = dict(a=1, b=2, c='a', d=dict(e=3, f=dict(g=4)))
    # Test that we can fetch a top-level key
    assert get_tree_node(testDict, 'c') == 'a'
    # Test that we can fetch a bottom-level key
    assert get_tree_node(testDict, 'd:f:g') == 4
    # Test that we get a KeyError if node does not exist
    try:
        get_tree_node(testDict, 'z')
    except KeyError:
        pass



# Generated at 2022-06-12 08:22:35.277125
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> x = tree()
    >>> x['a']['b']['c'] = 'd'
    >>> assert get_tree_node(x, 'a:b:c') == 'd'
    >>> assert get_tree_node(x, 'a:b', parent=True) == x['a']['b']
    >>> assert get_tree_node(x, 'a:g:h', default=None) is None
    """
    pass



# Generated at 2022-06-12 08:22:38.936396
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    expected = {
        'foo': {
            'bar': {
                'baz': 1,
            }
        }
    }
    assert set_tree_node(test_dict, 'foo:bar:baz', 1) == expected
    assert test_dict == expected



# Generated at 2022-06-12 08:22:42.634878
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 1}}, 'foo:bar') == 1
    assert get_tree_node({'foo': {'bar': 1}}, 'foo:bar:baz') == {}



# Generated at 2022-06-12 08:22:48.386452
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'a': {
            'b': {
                'c': 'd'
            }
        },
        'a:b:c': 'd',
    }
    assert get_tree_node(data, 'a:b:c') == 'd'
    assert get_tree_node(data, 'a:b:c') == 'd'
    return True



# Generated at 2022-06-12 08:22:57.808333
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = Tree()

    tree['test:test'] = 'test'
    assert tree.get_tree_node('test:test') == 'test'

    tree['test:test:test'] = 'test'
    assert tree.get_tree_node('test:test:test') == 'test'

    tree['test:test:test:test'] = 'test'
    assert tree.get_tree_node('test:test:test:test') == 'test'

    with pytest.raises(KeyError):
        tree.get_tree_node('missing:missing')

    with pytest.raises(KeyError):
        tree.get_tree_node('missing:missing:missing:missing:missing')

    with pytest.raises(KeyError):
        tree.get_tree_node('missing')

    assert tree.get_

# Generated at 2022-06-12 08:23:08.450056
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'a': {'b': {'c': 'x'}},
        'd': {'e': 'f'},
    }

    # Basic usage
    assert get_tree_node(test_mapping, 'a:b:c') == 'x'

    # To test default, set to a sentinel
    assert get_tree_node(test_mapping, 'b:c', default=_sentinel) is _sentinel

    # Raise if sentinel is not specified
    with pytest.raises(KeyError):
        get_tree_node(test_mapping, 'b:c')

    # Parent node
    assert get_tree_node(test_mapping, 'a:b:c', parent=True) == {'c': 'x'}



# Generated at 2022-06-12 08:23:11.284930
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    d['a'] = {}
    set_tree_node(d, 'a:b', 4)
    assert d['a']['b'] == 4
    assert set_tree_node(d, 'a:b', 7) == d['a']



# Generated at 2022-06-12 08:23:20.291727
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': 'A',
        'b': {
            'c': 'C',
            'd': {
                'e': 'E'
            }
        }
    }
    assert get_tree_node(d, 'a') == 'A'
    assert get_tree_node(d, 'b:c') == 'C'
    assert get_tree_node(d, 'b:d:e') == 'E'
    assert get_tree_node(d, '123', default='ABC') == 'ABC'
    with pytest.raises(KeyError):
        get_tree_node(d, '123')



# Generated at 2022-06-12 08:23:25.141300
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['foo']['bar'] = 'baz'

    assert get_tree_node(data, 'foo') == { 'bar': 'baz' }
    assert get_tree_node(data, 'foo:bar') == 'baz'
    assert get_tree_node(data, 'bar:foo') is None



# Generated at 2022-06-12 08:23:32.302093
# Unit test for function set_tree_node
def test_set_tree_node():
    from copy import copy
    import collections
    import json

    data = collections.OrderedDict()
    set_tree_node(data, 'one:two:three:four:five:six:seven', True)
    set_tree_node(data, 'one:two:three:four:five:six:eight:nine:ten', False)

    assert data == json.loads(json.dumps({
        'one': {
            'two': {
                'three': {
                    'four': {
                        'five': {
                            'six': {
                                'seven': True,
                                'eight': {
                                    'nine': {
                                        'ten': False
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }))

    assert get_tree

# Generated at 2022-06-12 08:23:41.259311
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': 'b',
        'c': {
            'd': 'e',
        },
    }
    # First, test the very shallow
    assert get_tree_node(mapping, 'a') == 'b'
    assert get_tree_node(mapping, 'c:d') == 'e'
    assert get_tree_node(mapping, 'x') is _sentinel
    assert get_tree_node(mapping, 'x:y') is _sentinel
    assert get_tree_node(mapping, 'a:b') is _sentinel



# Generated at 2022-06-12 08:23:49.431898
# Unit test for function get_tree_node
def test_get_tree_node():
    import pytest

    t = tree(int)
    t[1][1][1] = 'test'

    assert get_tree_node(t, '1:1:1') == 'test'
    with pytest.raises(KeyError):
        get_tree_node(t, '1:1:1:1')

    assert get_tree_node(t, '1:1:1:1', default='default') == 'default'

    assert get_tree_node(t, '1', parent=True) == {1: {1: 'test'}}



# Generated at 2022-06-12 08:24:00.796093
# Unit test for function get_tree_node
def test_get_tree_node():
    node = {
        'test': {
            'test': {
                'test': 'b',
                'test2': 'c',
            },
        }
    }
    # Test lookup
    assert get_tree_node(node, 'test:test:test') == 'b'
    assert get_tree_node(node, 'test:test:test2') == 'c'

    # Test default
    assert get_tree_node(node, 'test:test:test3', default=1) == 1
    try:
        assert get_tree_node(node, 'test:test:test3')
    except KeyError:
        pass
    else:
        assert False, 'Expected KeyError'

    # Test parent

# Generated at 2022-06-12 08:24:08.627501
# Unit test for function get_tree_node
def test_get_tree_node():
    class Mapping(dict):
        pass

    mapping = Mapping({
        'a': {
            'b': {
                'c': 'd',
            }
        }
    })
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='foo') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='foo') == 'foo'
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel



# Generated at 2022-06-12 08:24:15.269404
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'foo': {
            'bar': 'foobar',
        },
    }

    # Test for valid lookup
    assert get_tree_node(test_dict, 'foo:bar') == 'foobar'

    # Test for invalid lookup
    with pytest.raises(KeyError):
        get_tree_node(test_dict, 'foo:baz')

    # Test for optional default
    assert get_tree_node(test_dict, 'foo:baz', default='default') == 'default'


# Generated at 2022-06-12 08:24:23.770185
# Unit test for function get_tree_node
def test_get_tree_node():
    t1 = { 'a' : { 'b' : 1 } }
    assert get_tree_node(t1, 'a') == {'b': 1}
    assert get_tree_node(t1, 'a:b') == 1
    assert get_tree_node([1, 2], '1') == 2
    assert get_tree_node([1, 2], '2', default=None) is None
    assert get_tree_node([1, 2], '2', default=None) is None
    assert get_tree_node([1, 2], '2') == 2



# Generated at 2022-06-12 08:24:28.662817
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {
        'a': {
            'b': {
                'c': 'd',
            },
        }
    }
    assert set_tree_node(d, 'a:b:c', 'x') == d['a']['b']
    assert d['a']['b']['c'] == 'x'



# Generated at 2022-06-12 08:24:44.924039
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'mapping': {
            'tree_like': {
                'mapping': 'pass'
            }
        }
    }

    assert get_tree_node(tree, 'mapping:tree_like:mapping') == 'pass'

    # Test default value
    assert get_tree_node(tree, 'missing:key:that:does:not:exist', default=_sentinel) is _sentinel

    # Test KeyError is raised
    with pytest.raises(KeyError):
        get_tree_node(tree, 'missing:key:that:does:not:exist')



# Generated at 2022-06-12 08:24:53.340380
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {'a': {'b': {'c': {'d': 'e'}}}, 'f': 'g'}

    assert get_tree_node(data, 'a:b:c:d') == 'e'
    assert get_tree_node(data, 'doesnotexist') is _sentinel
    assert get_tree_node(data, 'doesnotexist', default='foo') == 'foo'
    assert get_tree_node(data, 'doesnotexist', default=_sentinel) is _sentinel
    assert get_tree_node(data, 'f') == 'g'
    assert get_tree_node(data, 'a:b:c', parent=True) == {'d': 'e'}
    assert get_tree_node(data, 'f', parent=True) is None
    assert get_

# Generated at 2022-06-12 08:25:01.501734
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'top:mid:bottom', 'value')
    set_tree_node(mapping, 'top:top', 'value')

    test_cases = dict(
        top=lambda: mapping['top'],
        mid=lambda: mapping['top']['mid'],
        bottom=lambda: mapping['top']['mid']['bottom'],
        top_top=lambda: mapping['top']['top'],
    )

    for key, func in test_cases.items():
        try:
            func()
        except KeyError:
            raise Exception('Key %s not found in mapping' % key)

# Generated at 2022-06-12 08:25:11.985668
# Unit test for function get_tree_node
def test_get_tree_node():
    from pytest import raises

    test_dict = {
        'foo': {
            'bar': 'bat',
            'baz': {
                'res': 'bat',
                'foo': 'bar',
            }
        }
    }

    assert get_tree_node(test_dict, 'foo:bar') == 'bat'
    assert get_tree_node(test_dict, 'foo:baz') == {'res': 'bat', 'foo': 'bar'}
    assert get_tree_node(test_dict, 'foo:baz:res') == 'bat'
    assert get_tree_node(test_dict, 'foo:baz:foo') == 'bar'

    # Test default
    assert get_tree_node(test_dict, 'not:here', default='foobar') == 'foobar'



# Generated at 2022-06-12 08:25:23.036350
# Unit test for function get_tree_node
def test_get_tree_node():
    import pytest
    test = {
        'foo': 'bar',
        'moo': {
            'boo': 'far',
            'too': {
                'mar': 'jar',
            }
        },
        'doo': [
            'war',
            {
                'sar': 'tar',
            },
        ]
    }
    assert get_tree_node(test, 'foo') == 'bar'
    assert get_tree_node(test, 'moo') == {'boo': 'far', 'too': {'mar': 'jar'}}
    assert get_tree_node(test, 'doo') == ['war', {'sar': 'tar'}]
    assert get_tree_node(test, 'doo:1') == {'sar': 'tar'}
    assert get

# Generated at 2022-06-12 08:25:28.458930
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    >>> mapping = tree()
    >>> mapping.set_tree_node('a:b', 1)
    {'a': {'b': 1}}
    >>> mapping.set_tree_node('a:b:c', 2)
    {'a': {'b': {'c': 2}}}
    >>> mapping.set_tree_node('d', 3)
    {'d': 3}
    """



# Generated at 2022-06-12 08:25:35.776207
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    assert set_tree_node(mapping, 'name', 1) == mapping
    assert set_tree_node(mapping, 'name:foo', 2) == mapping['name']
    assert set_tree_node(mapping, 'name:bar', 3) == mapping['name']
    assert set_tree_node(mapping, 'name:foo:baz', 4) == mapping['name']['foo']
    assert mapping == {'name': {'bar': 3, 'foo': {'baz': 4}}}


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-12 08:25:41.571398
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['dim_one']['dim_two']['value'] = 'It Works!'
    assert get_tree_node(t, 'dim_one:dim_two:value') == 'It Works!'
    assert get_tree_node(t, 'dim_one:value') == _sentinel
    assert get_tree_node(t, 'dim_two:value') == _sentinel


# Generated at 2022-06-12 08:25:52.865872
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'key') == {}

    assert get_tree_node({'key': 'value'}, 'key') == 'value'
    assert get_tree_node({'key': 'value'}, 'another_key', default=1) == 1

    tree_dict = {'key_1': {'key_2': {'key_3': {'key_4': 'value'}}}}
    assert get_tree_node(tree_dict, 'key_1:key_2:key_3:key_4') == 'value'
    assert get_tree_node(tree_dict, 'key_1:key_2:key_3') == {'key_4': 'value'}


# Generated at 2022-06-12 08:26:02.042227
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function `get_tree_node`
    """
    import pytest


# Generated at 2022-06-12 08:26:19.661114
# Unit test for function get_tree_node
def test_get_tree_node():
    """ """
    t = tree()
    t['a']['b']['c'] = True
    t['a']['b']['d'] = True
    t['human']['a']['body']['head']['mouth'] = 'yeah'
    t['human']['a']['body']['head']['ears'] = 'nope'
    t['human']['a']['eyes'] = 'lasers'
    assert t['a']['b'] == {'c': True, 'd': True}
    assert get_tree_node(t, 'a') == {'b': {'c': True, 'd': True}}

# Generated at 2022-06-12 08:26:29.551208
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'one': 1,
        'two': [2, {'three': 3, 'four': [4, {'five': 5}]}, 6],
        'seven': [7, 8],
        'nine': 9
    }

    assert get_tree_node(mapping, 'one') == 1
    assert get_tree_node(mapping, 'two:1:three') == 3
    assert get_tree_node(mapping, 'two:1:four:1:five') == 5
    assert get_tree_node(mapping, 'two:2') == 6
    assert get_tree_node(mapping, 'twelve') is _sentinel
    try:
        assert get_tree_node(mapping, 'twelve')
    except KeyError:
        pass
    else:
        raise Ass

# Generated at 2022-06-12 08:26:35.168540
# Unit test for function set_tree_node
def test_set_tree_node():
    import unittest

    class TestSetTreeNodeCase(unittest.TestCase):
        def test(self):
            m = {}
            set_tree_node(m, 'foo:bar:baz', 'foobarbaz')
            self.assertEqual(m['foo']['bar']['baz'], 'foobarbaz')
            set_tree_node(m, 'foo:bar:baz:quux', 'foobarbazquux')
            self.assertEqual(m['foo']['bar']['baz']['quux'], 'foobarbazquux')

    unittest.main()

# Generated at 2022-06-12 08:26:40.951950
# Unit test for function get_tree_node
def test_get_tree_node():
    map = {
        'lol': {
            'hello': 'world',
        }
    }

    assert get_tree_node(map, 'lol:hello') == 'world'
    assert get_tree_node(map, 'lol')['hello'] == 'world'
    assert get_tree_node(map, 'lol:hello:huh') is _sentinel



# Generated at 2022-06-12 08:26:51.718644
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    test_tree = {
        'foo': {
            'bar': 'baz',
            'spam': {
                'eggs': 'ham'
            }
        }
    }

    # Test looking up stuff that's there
    assert u'baz' == get_tree_node(test_tree, 'foo:bar')
    assert u'ham' == get_tree_node(test_tree, 'foo:spam:eggs')

    # Test looking up stuff that's not there
    with pytest.raises(KeyError):
        get_tree_node(test_tree, 'spam:eggs:ham')

    # Test default values
    assert u'ham' == get_tree_node(test_tree, 'spam:eggs:ham', default=u'ham')

# Generated at 2022-06-12 08:26:53.409402
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': {
            'bar': 'baz'
        }
    }



# Generated at 2022-06-12 08:27:04.151801
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        "key1": "value1",
        "key2": {
            "key3": "value3",
            "key4": "value4",
            "key5": {
                "key6": "value6"
            }
        }
    }

    assert "value1" == get_tree_node(test_data, "key1")

    assert "value6" == get_tree_node(test_data, "key2:key5:key6")

    assert "value6" == get_tree_node(test_data, "key2:key5:key6", parent=True)["key6"]

    # Missing Key
    try:
        get_tree_node(test_data, "key2:key5:keyX")
        assert False
    except KeyError:
        pass

# Generated at 2022-06-12 08:27:10.204998
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'user': {
            'name': 'John Doe',
            'role': 'admin',
            'groups': ['system', 'admins']
        }
    }
    result = get_tree_node(mapping, 'user:groups:1')
    expected = 'admins'
    print('Testing get_tree_node: expected: %s, actual: %s' % (expected, result))
    assert result == expected



# Generated at 2022-06-12 08:27:18.449873
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> example = {
    ...   'one': [
    ...     'two': {
    ...       'three': 'four'
    ...     }
    ...   ]
    ... }
    >>> get_tree_node(example, 'one:two:three')
    'four'
    >>> get_tree_node(example, 'one:two:three:four', default='hello')
    'hello'
    >>> get_tree_node(example, 'one:two:three', parent=True)
    {'three': 'four'}
    >>> get_tree_node(example, 'one:two:three:four', parent=True)
    'four'
    """



# Generated at 2022-06-12 08:27:21.694660
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['/']['foo/']['bar']['baz'] = 'moo'
    assert get_tree_node(mapping, 'foo:bar')['baz'] == 'moo'
    assert get_tree_node(mapping, 'foo:bar:baz') == 'moo'



# Generated at 2022-06-12 08:27:36.752052
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'hey:you', 'fool')
    assert t['hey:you'] == 'fool'
    assert t['hey'] == {'you': 'fool'}
    set_tree_node(t, 'hey:friend', 'fool2')
    assert t['hey'] == {'you': 'fool', 'friend': 'fool2'}
    set_tree_node(t, 'hey', 'fool')
    assert t == {'hey': 'fool'}


test_set_tree_node()



# Generated at 2022-06-12 08:27:48.296876
# Unit test for function set_tree_node
def test_set_tree_node():

    # Try setting a node at level 1
    test_data1 = {}
    test_data1 = set_tree_node(test_data1, 'foo', 'bar')

    assert test_data1['foo'] == 'bar'

    # Try setting a node at level 2
    test_data2 = {
        'level1': {
        }
    }
    test_data2 = set_tree_node(test_data2, 'level1:foo', 'bar')

    assert test_data2['level1']['foo'] == 'bar'

    # Try setting a node at level 3
    test_data3 = {
        'level1': {
            'level2': {
            }
        }
    }

# Generated at 2022-06-12 08:27:57.775610
# Unit test for function get_tree_node
def test_get_tree_node():
    treedict = {
        'a': 1,
        'b': 3,
        'c': {
            'd': 4,
            'e': {
                'f': 6,
                'g': 7,
            }
        }
    }
    assert get_tree_node(treedict, 'c:d') == 4
    assert get_tree_node(treedict, 'c:e:f') == 6
    assert get_tree_node(treedict, 'c:e:f', parent=True) == {'f': 6, 'g': 7}
    assert get_tree_node(treedict, 'c:e:g', parent=True) == {'f': 6, 'g': 7}

# Generated at 2022-06-12 08:28:06.184661
# Unit test for function get_tree_node
def test_get_tree_node():
    # test dictionary
    d = {
        'a': {
            'b': 1,
            'c': {
                'd': 2,
            },
       },
    }

    # test get_tree_node
    assert(get_tree_node(d, 'a:b') == 1)
    assert(get_tree_node(d, 'a:c:d') == 2)
    with pytest.raises(KeyError):
        get_tree_node(d, 'a:c:c')



# Generated at 2022-06-12 08:28:15.223357
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for `get_tree_node`
    """
    mapping = tree()
    mapping['test']['first']['second']['third'] = 'final'
    assert get_tree_node(mapping, 'test:first:second:third') == 'final'
    assert get_tree_node(mapping, 'test:first:second:third', parent=True) == mapping['test']['first']['second']
    assert get_tree_node(mapping, 'test:first:second', parent=True) == mapping['test']['first']
    assert get_tree_node(mapping, 'test:first:second', default=None) is None
    assert get_tree_node(mapping, 'test:second:third') is _sentinel



# Generated at 2022-06-12 08:28:22.281230
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {'a': 1, 'b': {'c': 3, 'x': 4}, 'c': {'d': {'e': 5}}}
    assert get_tree_node(test_tree, 'b:x') == 4
    assert get_tree_node(test_tree, 'b:c') == 3
    assert get_tree_node(test_tree, 'c:d:e') == 5
    assert get_tree_node(test_tree, 'c:something:e') is _sentinel
    assert get_tree_node(test_tree, 'b:something', default=None) is None



# Generated at 2022-06-12 08:28:33.325505
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function `set_tree_node`
    """
    node = {}
    assert set_tree_node(node, 'a:a:a', True) == {'a': {'a': {'a': True}}}
    assert node == {'a': {'a': {'a': True}}}

    node = {}
    assert set_tree_node(node, 'a:a:a', True) == {'a': {'a': {'a': True}}}
    assert node == {'a': {'a': {'a': True}}}

    node = {}
    set_tree_node(node, 'a:a', {'a': True})
    assert node == {'a': {'a': {'a': True}}}
    set_tree_node(node, 'a:b', True)


# Generated at 2022-06-12 08:28:37.991921
# Unit test for function set_tree_node
def test_set_tree_node():
    x = tree()
    y = set_tree_node(x, 'bar:baz:baz', 'baz')
    assert y['baz'] == 'baz'

    z = set_tree_node(x, 'bar:baz:bar', 'bar')
    assert z['bar'] == 'bar'



# Generated at 2022-06-12 08:28:43.160857
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    root = tree()
    set_tree_node(root, 'a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p', 'value')
    assert root['a']['b']['c']['d']['e']['f']['g']['h']['i']['j']['k']['l']['m']['n']['o']['p'] == 'value'



# Generated at 2022-06-12 08:28:46.339549
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'foo:bar', 'baz')
    assert d == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-12 08:29:13.012207
# Unit test for function set_tree_node
def test_set_tree_node():
    test = Tree()
    test["foo"] = "bar"
    test["baz:blah"] = "bleh"
    test["bleh:blah"] = "foo"
    test["bleh:flam"] = ["bar", "baz"]

    assert test is test[""]
    assert test["foo"] == "bar"
    assert test["baz"]["blah"] == "bleh"
    assert test["bleh"]["blah"] == "foo"
    assert test["bleh"]["flam"] == ["bar", "baz"]

    assert test.get("bleh:blah:flam") is None
    assert test.get("bleh:blah", default=42) == "foo"
    assert test.get("baz:blah:flam", default=42) == 42



# Generated at 2022-06-12 08:29:22.366240
# Unit test for function set_tree_node
def test_set_tree_node():
    test_node_data = tree()
    set_tree_node(test_node_data, u'a:b:c', u'foo')
    set_tree_node(test_node_data, u'e:f:g', u'bar')
    assert test_node_data == {u'a': {u'b': {u'c': u'foo'}}, u'e': {u'f': {u'g': u'bar'}}}
    assert get_tree_node(test_node_data, u'a:b:c') == u'foo'
    assert get_tree_node(test_node_data, u'e:f:g') == u'bar'
    assert get_tree_node(test_node_data, u'a:b:c:d') is _sentinel



# Generated at 2022-06-12 08:29:29.346230
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree({'a': {'b': {'c': 'd'}}})
    assert tree['a']
    assert tree['a:b:c'] == 'd'

    tree['a:b:c'] = 'f'
    assert tree['a:b:c'] == 'f'

    tree['b:c:d'] = 'e'
    assert tree['b:c:d'] == 'e'

    tree['b:c:d'] = 'g'
    assert tree['b:c:d'] == 'g'


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-12 08:29:36.370652
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'C'}}}, 'a:b:c') == 'C'
    assert get_tree_node({'a': {'b': {'c': 'C'}}}, 'a:b:d', default='NOT FOUND') == 'NOT FOUND'
    try:
        get_tree_node({'a': {'b': {'c': 'C'}}}, 'a:b:d')
        raise AssertionError('get_tree_node failed to raise on missing key')
    except KeyError:
        pass



# Generated at 2022-06-12 08:29:42.587526
# Unit test for function get_tree_node
def test_get_tree_node():
    # Simple, single-dimensional tree
    a = tree()

    a['foo']['bar'] = 'baz'

    assert 'baz' == get_tree_node(a, 'foo:bar')

    # Multi-dimensional tree
    a = tree()

    a['foo']['bar']['baz'] = 'lol'

    assert 'lol' == get_tree_node(a, 'foo:bar:baz')

    # Multi-dimensional tree, with default
    a = tree()

    a['foo']['bar'] = 'baz'

    assert 'baz' == get_tree_node(a, 'foo:bar:baz:lol:lol:lol', default='baz')

    # Multi-dimensional tree, with parent
    a = tree()


# Generated at 2022-06-12 08:29:46.795753
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, "foo:bar:baz", "foobarbaz")
    assert test_dict["foo"]["bar"]["baz"] == "foobarbaz"

# Generated at 2022-06-12 08:29:55.104519
# Unit test for function get_tree_node

# Generated at 2022-06-12 08:30:03.361349
# Unit test for function set_tree_node
def test_set_tree_node():
    """An example of (very) simple unit test"""
    mapping = tree()
    expected_mapping = {
        'foo': {
            'bar': {
                'baz': {
                    'quux': 'spam',
                    'quuux': 'eggs'
                }
            }
        }
    }
    set_tree_node(mapping, 'foo:bar:baz:quux', 'spam')
    set_tree_node(mapping, 'foo:bar:baz:quuux', 'eggs')
    assert dict(mapping) == expected_mapping

