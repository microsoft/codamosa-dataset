

# Generated at 2022-06-12 08:20:08.973850
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'hello': {'world': {'foo': 'bar'}}}, 'hello:world:foo') == 'bar'
    assert get_tree_node({'hello': {'world': {'foo': 'bar'}}}, 'world:hello:foo') is _sentinel
    assert get_tree_node({'hello': {'world': {'foo': 'bar'}}}, 'world:hello:foo', default='baz') == 'baz'
    with pytest.raises(KeyError):
        get_tree_node({'hello': {'world': {'foo': 'bar'}}}, 'world:hello:foo')

# Generated at 2022-06-12 08:20:14.045954
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    t = set_tree_node(t, 'foo:bar', 'blah')
    assert t['foo']['bar'] == 'blah'
    assert t['foo'] is not None
    assert t['foo']['bar'] is not None
    assert t['foo']['bar'] == t['foo:bar']



# Generated at 2022-06-12 08:20:17.101470
# Unit test for function get_tree_node
def test_get_tree_node():
    print('Testing get_tree_node')
    x = {'y': {'z': 6}}
    assert get_tree_node(x, 'y:z') == 6
    print('Passed')


# # Unit test for function set_tree_node

# Generated at 2022-06-12 08:20:19.975189
# Unit test for function set_tree_node
def test_set_tree_node():
    root = tree()
    set_tree_node(root, 'a:b:c:d', 'hi')
    assert root['a']['b']['c']['d'] == 'hi'



# Generated at 2022-06-12 08:20:31.221090
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'foo', 'bar') == 'bar'
    assert get_tree_node(tree(), 'foo', parent=True) == {}
    assert get_tree_node(tree(), 'foo:bar') == {}
    assert get_tree_node(tree(), 'foo:bar', parent=True) == {}
    assert get_tree_node(tree(), 'foo:bar:baz', parent=True) == {}

    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': 'bar'}, 'foo', parent=True) == {}
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'

# Generated at 2022-06-12 08:20:34.384944
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    set_tree_node(d, 'foo:bar', 'baz')
    assert d['foo']
    assert d['foo']['bar'] == 'baz'



# Generated at 2022-06-12 08:20:40.119173
# Unit test for function get_tree_node
def test_get_tree_node():
    testmapping = tree()
    testmapping['foo']['bar'] = {'baz': 'buz'}
    assert get_tree_node(testmapping, 'foo:bar:baz') == 'buz'
    assert get_tree_node(testmapping, 'foo:bar')['baz'] == 'buz'



# Generated at 2022-06-12 08:20:46.887462
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['a']['b']['c']['d'] = True
    assert get_tree_node(mapping, 'a:b:c:d') is True
    assert get_tree_node(mapping, 'a:b:x:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:x:d', parent=True) is mapping['a']['b']['x']
    assert get_tree_node(mapping, 'a:b:x:d', default=False) is False



# Generated at 2022-06-12 08:20:56.237413
# Unit test for function set_tree_node
def test_set_tree_node():
    test_mapping = tree()
    test_key = 'a:b:c'
    # Set something
    test_node = set_tree_node(test_mapping, test_key, 'meow')
    # Check that it gets returned
    assert test_node == test_node['a']['b']
    # Check that it got there correctly
    assert test_mapping['a']['b']['c'] == 'meow'

    # Check that KeyError gets raised when it doesn't exist
    with pytest.raises(KeyError):
        test_node = get_tree_node(test_mapping, 'p:q:r:s')

    # Check that the default gets returned if we specify one

# Generated at 2022-06-12 08:21:03.419982
# Unit test for function get_tree_node
def test_get_tree_node():
    lexicon = {
        'A': {
            'A1': 'Alpha',
            'A2': 'Alpha2',
        },
        'B': {
            'B1': {
                'B1A': 'Bravo'
            }
        }
    }
    assert get_tree_node(lexicon, 'A:A1') == 'Alpha'
    assert get_tree_node(lexicon, 'B:B1:B1A') == 'Bravo'
    assert get_tree_node(lexicon, 'A:A1:A1B') == _sentinel



# Generated at 2022-06-12 08:21:11.118473
# Unit test for function set_tree_node
def test_set_tree_node():
    top_node = tree()
    set_tree_node(top_node, 'first:second:third', 'test value')
    assert top_node['first']['second']['third'] == 'test value'



# Generated at 2022-06-12 08:21:19.551596
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': {
            'bar': 'baz'
        },
        'hax': 'meh'
    }

    # Basic tests
    assert get_tree_node(data, 'foo:bar') == 'baz'
    assert get_tree_node(data, 'hax') == 'meh'
    assert get_tree_node(data, 'asd', default='foo') == 'foo'
    assert get_tree_node(data, 'foo:bar', parent=True) == data['foo']
    try:
        get_tree_node(data, 'foo:asd')
    except KeyError:
        pass



# Generated at 2022-06-12 08:21:26.763773
# Unit test for function set_tree_node
def test_set_tree_node():
    sample_tree = tree()
    sample_tree['fruit']['banana']['colors']['yellow'] = True
    sample_tree['fruit']['apple']['colors']['green'] = True
    sample_tree['fruit']['apple']['colors']['red'] = True
    sample_tree['vegetable']['lettuce']['colors']['green'] = True
    sample_tree['vegetable']['carrot']['colors']['orange'] = True
    sample_tree['vegetable']['squash']['colors']['yellow'] = True
    sample_tree['vegetable']['squash']['colors']['green'] = True


# Generated at 2022-06-12 08:21:34.803058
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = dict()
    # Set a basic nested dict
    mapping['a'] = dict()
    mapping['a']['b'] = dict()
    mapping['a']['b']['c'] = 'd'

    # Test absolute notation
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    # Test with missing key
    assert get_tree_node(mapping, 'a:z:c') is None
    # Test with parent node
    assert get_tree_node(mapping, 'a:b:c', parent=True) == dict(c='d')



# Generated at 2022-06-12 08:21:41.332529
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            },
            'e': 'f'
        }
    }
    expected = {
        'a:b:c': 'd',
        'a:e': 'f'
    }
    for k, v in expected.items():
        assert get_tree_node(test_dict, k) == v


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:21:51.952388
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree({
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': 12,
                    },
                },
            },
        },
    })

    assert get_tree_node(mapping, 'a:b:c:d:e') == 12
    assert get_tree_node(mapping, 'a:b:c:d:e:f:g:h', None) is None
    assert mapping['a']['b']['c']['d']['e'] == 12

    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:c:d:e:f:g:h')



# Generated at 2022-06-12 08:22:00.367313
# Unit test for function get_tree_node
def test_get_tree_node():

    tree = {
        'a': {
            'b': {
                'c': 'value',
            },
        },
        'foo:bar:bazz': 'bazz',
    }

    assert get_tree_node(tree, 'a:b:c') == 'value'
    assert get_tree_node(tree, 'foo:bar:bazz') == 'bazz'

    # keyerror
    try:
        get_tree_node(tree, 'foo:nonexistent')
    except KeyError as exc:
        assert True
    else:
        assert False

# Generated at 2022-06-12 08:22:08.846342
# Unit test for function set_tree_node
def test_set_tree_node():
    """Docstring"""
    tree = {}
    set_tree_node(tree, 'foo:bar', 'baz')
    foo = tree['foo']
    assert foo == {'bar': 'baz'}

    tree = {}
    set_tree_node(tree, 'foo:bar:foobar', 'baz')
    foo = tree['foo']
    assert foo == {'bar': {'foobar': 'baz'}}

    tree = {}
    set_tree_node(tree, 'foo:bar:foobar', 'baz')
    set_tree_node(tree, 'foo:bar:foobar2', 'baz')
    assert tree == {'foo': {'bar': {'foobar': 'baz', 'foobar2': 'baz'}}}



# Generated at 2022-06-12 08:22:19.924211
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    key = 'a:b:c'
    value = 'd'
    assert set_tree_node(mapping, key, value) == {'a': {'b': {'c': 'd'}}}
    key = 'a:b:c:d'
    assert set_tree_node(mapping, key, value) == {'a': {'b': {'c': {'d': 'd'}}}}
    key = 'a:b:c:d:e:f:g:h:i'
    assert set_tree_node(mapping, key, value) == {'a': {'b': {'c': {'d': {'e': {'f': {'g': {'h': {'i': 'd'}}}}}}}}}

# Generated at 2022-06-12 08:22:30.215529
# Unit test for function get_tree_node
def test_get_tree_node():
    # Create test dicts
    test_dict = {'foo': {'bar': {'baz': 'quux'}}}
    test_dict_parent = test_dict['foo']
    test_dict_child = test_dict['foo']['bar']

    # Test it
    assert get_tree_node(test_dict, 'foo') == test_dict_parent
    assert get_tree_node(test_dict, 'foo:bar') == test_dict_child
    assert get_tree_node(test_dict, 'foo:bar:baz') == test_dict_child['baz']
    assert get_tree_node(test_dict, 'foo:bar:baz') == get_tree_node(test_dict, 'foo:bar:baz')

    # Test it with parent flag
    assert get_tree_

# Generated at 2022-06-12 08:22:39.638713
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': True}}
    assert get_tree_node(mapping, 'foo:bar') is True



# Generated at 2022-06-12 08:22:45.964802
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(data, 'a:b:c') == data['a']['b']['c']
    assert get_tree_node(data, 'c:d', default='e') == 'e'
    with pytest.raises(KeyError):
        get_tree_node(data, 'c:d')



# Generated at 2022-06-12 08:22:52.565342
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'test': {
            'test2': {
                'test3': {'blarg': 'foo'},
            },
        },
    }

    assert get_tree_node(mapping, 'test:test2:test3:blarg') == 'foo'
    assert get_tree_node(mapping, 'test:test2:test3:nonexistant', None) == None

    import pytest

    with pytest.raises(KeyError):
        get_tree_node(mapping, 'test:test2:test3:nonexistant')



# Generated at 2022-06-12 08:22:58.780241
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test function `get_tree_node`."""
    x = {
        'foo': [{
            'bar': [
                {'baz': 'qux'},
                {'baz': 'quux'},
            ]
        }]
    }
    assert get_tree_node(x, 'foo:0:bar:0:baz', default='') == 'qux'



# Generated at 2022-06-12 08:23:09.304565
# Unit test for function get_tree_node
def test_get_tree_node():
    my_mapping = collections.OrderedDict()
    my_mapping['one'] = 1

    my_mapping['two'] = collections.OrderedDict()
    my_mapping['two']['two-one'] = 2
    my_mapping['two']['two-two'] = 'Two 2'

    my_mapping['three'] = collections.OrderedDict()
    my_mapping['three']['three-one'] = 3
    my_mapping['three']['three-two'] = collections.OrderedDict()
    my_mapping['three']['three-two']['three-two-one'] = 3.2
    my_mapping['three']['three-two']['three-two-two'] = 'Three Two Two'


# Generated at 2022-06-12 08:23:18.460510
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = collections.OrderedDict([('a', collections.OrderedDict([('b', 1)])), ('c', 2)])
    assert get_tree_node(mapping, 'c') == 2
    assert get_tree_node(mapping, 'a:b') == 1
    assert get_tree_node(mapping, 'a:c') == _sentinel
    try:
        get_tree_node(mapping, 'a:c', default=_sentinel)
        assert False, "get_tree_node should have raised KeyError"
    except KeyError:
        pass
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:c', default=_sentinel)

# Generated at 2022-06-12 08:23:22.481006
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'root:tree:leaf', 'foo')
    assert t == {
        'root': {
            'tree': {
                'leaf': 'foo'
            }
        }
    }



# Generated at 2022-06-12 08:23:29.292333
# Unit test for function set_tree_node
def test_set_tree_node():
    var = {}
    set_tree_node(var, 'a:b:c', 3)
    set_tree_node(var, 'a:b:d', 4)
    print(var)
    assert var == {'a': {'b': {'c': 3, 'd': 4}}}
    # test for overwriting an existing item
    set_tree_node(var, 'a:b:c', 5)
    print(var)
    assert var == {'a': {'b': {'c': 5, 'd': 4}}}


# Generated at 2022-06-12 08:23:40.246298
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {'test': {'test': 'passed'}}
    assert get_tree_node(data, 'test:test') == 'passed'
    assert get_tree_node(data, 'test:test', default='failed') == 'passed'
    assert get_tree_node(data, 'test:test2', default='failed') == 'failed'
    assert get_tree_node(data, 'test:test2', parent=True) == {'test': 'passed'}
    data = {'test': {'test': [{'test': 'passed'}, {'test': 'failed'}]}}
    assert get_tree_node(data, 'test:test:0:test') == 'passed'
    assert get_tree_node(data, 'test:test:1:test') == 'failed'

# Generated at 2022-06-12 08:23:42.764754
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'key:sub', 1)
    assert d == {'key': {'sub': 1}}



# Generated at 2022-06-12 08:23:53.188169
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'a:b') == _sentinel
    assert get_tree_node({'a': {}}, 'a:b') == _sentinel

    a = {'a': {'x': {'y': 'value'}}, 'b': 'value'}
    assert get_tree_node(a, 'a:x') == {'y': 'value'}
    assert get_tree_node(a, 'a:x:y') == 'value'
    assert get_tree_node(a, 'b') == 'value'

    assert get_tree_node(a, 'a:x:y', parent=True) == {'x': {'y': 'value'}, 'y': 'value'}

# Generated at 2022-06-12 08:24:01.776464
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test function get_tree_node."""
    tree = {'foo': {'bar': 'baz'}}
    assert get_tree_node(tree, 'foo:bar') == 'baz'
    assert get_tree_node(tree, 'foo') == {'bar': 'baz'}
    assert get_tree_node(tree, 'foo:bar:really') is _sentinel
    assert get_tree_node(tree, 'foo:bar:really', default='test') == 'test'
    assert get_tree_node(tree, 'foo:bar', parent=True) == {'foo': {'bar': 'baz'}}

# Generated at 2022-06-12 08:24:05.347875
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_ = {
        'test': {'test': {'test': 'value'}}
    }
    assert get_tree_node(tree_, 'test:test:test', default=None) == 'value'


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:24:10.598221
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'b:c:d')



# Generated at 2022-06-12 08:24:15.849636
# Unit test for function set_tree_node
def test_set_tree_node():
    import random
    mapping = tree()
    keys = ['one', 'two:%s' % random.randint(0, 9), 'three:%s:%s' % (random.randint(0, 9), random.randint(0, 9))]
    for key in keys:
        set_tree_node(mapping, key, random.randint(0, 9))

    for key in keys:
        get_tree_node(mapping, key)

# Generated at 2022-06-12 08:24:26.240379
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': 'foo',
        },
        'b': {
            'c': {
                'd': 'bar'
            }
        }
    }

    # Simple value
    assert get_tree_node(tree, 'a:b') == 'foo'
    assert get_tree_node(tree, 'b:c:d') == 'bar'

    # Value from partial key
    assert get_tree_node(tree, 'a:b:c:d') == 'bar'

    # Default value
    assert get_tree_node(tree, 'x:y:z', default='default') == 'default'

    # Parent key
    assert get_tree_node(tree, 'b:c:d', parent=True) == {'d': 'bar'}

    # Key

# Generated at 2022-06-12 08:24:33.527021
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'root': [1, 2]}, 'root') == [1, 2]
    assert get_tree_node({'root': [1, 2]}, 'root:1') == 2
    assert get_tree_node({'root': {'level2': 3}}, 'root:level2') == 3
    assert get_tree_node({'root': {'level2': {'level3': 4}}}, 'root:level2:level3') == 4
    assert get_tree_node({'root': {'level2': {'level3': 4}}}, 'root:level2') == {'level3': 4}

# Generated at 2022-06-12 08:24:36.330166
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node
    """
    root = {}
    set_tree_node(root, 'foo', 'bar')
    assert root == {'foo': 'bar'}



# Generated at 2022-06-12 08:24:46.675359
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 42
        },
        'baz': {
            'bax': 'foobar'
        }
    }
    assert get_tree_node(mapping, 'foo:bar') == 42
    assert get_tree_node(mapping, 'baz:bax') == 'foobar'
    assert get_tree_node(mapping, 'baz:bax', default=1337) == 'foobar'
    assert get_tree_node(mapping, 'baz:bax:blah', default=1337) == 1337
    assert get_tree_node(mapping, 'baz:bax:blah') is None

# Generated at 2022-06-12 08:24:54.188723
# Unit test for function get_tree_node
def test_get_tree_node():
    container = {'one': {'a': 1, 'b': 2, 'c': {'foo': 'bar'}}}
    assert get_tree_node(container, 'one') == {'a': 1, 'b': 2, 'c': {'foo': 'bar'}}
    assert get_tree_node(container, 'one:c') == {'foo': 'bar'}
    assert get_tree_node(container, 'one:a') == 1
    assert get_tree_node(container, 'one:c:foo') == 'bar'
    with pytest.raises(KeyError):
        get_tree_node(container, 'one:d')
    assert get_tree_node(container, 'one:d', default=None) is None

# Generated at 2022-06-12 08:25:09.316394
# Unit test for function get_tree_node
def test_get_tree_node():

    t = {
        'a': {
            'b': 'foobar'
        }
    }

    assert get_tree_node(t, 'a:b') == 'foobar'
    assert get_tree_node(t, 'a:b', parent=True) == {'b': 'foobar'}
    # TODO Test default param
    # TODO Test keyerror
    # TODO Test _sentinel
    # TODO Test list



# Generated at 2022-06-12 08:25:19.717449
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mappings = {
        'simple': {
            'key': 'value',
        },
        'complex': {
            'level1': {
                'level2': {
                    'level3': 'value',
                },
            },
        },
    }

    for name, mapping in test_mappings.items():
        yield check_get_tree_node, mapping, 'key', 'value', name
        yield check_get_tree_node, mapping, 'level1:level2:level3', 'value', name
        try:
            get_tree_node(mapping, 'invalid_key')
        except KeyError:
            pass
        else:
            assert False, 'Did not raise KeyError for invalid key'



# Generated at 2022-06-12 08:25:27.702392
# Unit test for function get_tree_node
def test_get_tree_node():
    nested = {'level1': {'level2': {'level3': {'leaf': 'green'}}}}
    assert 'green' == get_tree_node(nested, 'level1:level2:level3:leaf')
    assert 'green' == get_tree_node(nested, 'level1:level2:level3:leaf',
                                    parent=True)
    nope = get_tree_node(nested, 'level1:level2:level3:leaf',
                         default='black')
    assert 'black' == nope
    fail = get_tree_node(nested, 'level1:level2:level3:leaf',
                         default='black', parent=True)
    assert 'green' == fail



# Generated at 2022-06-12 08:25:36.671053
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test `get_tree_node` function against known data."""
    nested = {
        'a': {'aa': 1, 'ab': 2},
        'b': 3,
        'c': ['a', 'b', 'c'],
    }

    # Non-nested keys
    assert get_tree_node(nested, 'b') == 3
    assert get_tree_node(nested, 'd') == _sentinel
    # Nested keys
    assert get_tree_node(nested, 'a:aa') == 1
    assert get_tree_node(nested, 'a:ab') == 2
    # Nested keys with default
    assert get_tree_node(nested, 'b:a', default='foo') == 'foo'

# Generated at 2022-06-12 08:25:41.041257
# Unit test for function set_tree_node
def test_set_tree_node():
    my_dict = {}
    expected_output = {'a': {'b': {'c': 12}}}
    set_tree_node(my_dict, 'a:b:c', 12)
    assert my_dict == expected_output, 'Set value in nested dictionary'



# Generated at 2022-06-12 08:25:45.875185
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Get nested key test. Non-existant keys should raise KeyError
    """
    mapping = dict(a=dict(b=dict(c=123)))
    assert get_tree_node(mapping, 'a:b:c') == 123
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'nope')



# Generated at 2022-06-12 08:25:54.222702
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {'a': {'b': {'c': {'d': 1}}}}
    set_tree_node(data, 'a:b:c:e', 2)
    assert data == {'a': {'b': {'c': {'d': 1, 'e': 2}}}}
    set_tree_node(data, 'f:g:h:i', 3)
    assert data == {'a': {'b': {'c': {'d': 1, 'e': 2}}}, 'f': {'g': {'h': {'i': 3}}}}

# Generated at 2022-06-12 08:26:00.339972
# Unit test for function set_tree_node
def test_set_tree_node():

    # Define the initial object
    tree_node = collections.OrderedDict([('a', 5)])

    # Set node b
    set_tree_node(tree_node, 'b', 6)
    assert tree_node == {'a': 5, 'b': 6}

    # Set node b:c
    set_tree_node(tree_node, 'b:c', 7)
    assert tree_node == {'a': 5, 'b': 6, 'b:c': 7}



# Generated at 2022-06-12 08:26:06.661704
# Unit test for function get_tree_node
def test_get_tree_node():
    obj = {
        'a': {
            'b': {
                'c': 3,
                'd': 4,
            },
            'e': {
                'c': 5,
                'd': 6,
            },
        }
    }
    assert get_tree_node(obj, 'a:b:c') == 3
    assert get_tree_node(obj, 'a:b:d') == 4
    assert get_tree_node(obj, 'a:e:c') == 5
    assert get_tree_node(obj, 'a:e:d') == 6

    assert get_tree_node(obj, 'a:e:c', parent=True)['c'] == 5
    assert get_tree_node(obj, 'a:e:d', parent=True)['d'] == 6


# Generated at 2022-06-12 08:26:17.543667
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': {
            'dog': {
                'first': 'Spot',
                'second': 'Rover',
            },
            'cat': {
                'first': 'Felix',
                'second': 'Garfield',
            },
            'bat': None,
        }
    }
    first_dog = get_tree_node(data, 'foo:dog:first')
    assert first_dog == 'Spot'
    second_dog = get_tree_node(data, 'foo:dog:second')
    assert second_dog == 'Rover'
    none_bat = get_tree_node(data, 'foo:bat')
    assert none_bat is None
    none_obj = get_tree_node(data, 'foo:bat:first')
    assert none_obj is _sentinel
   

# Generated at 2022-06-12 08:26:43.357335
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node.

    Returns:
        bool: True.
    """
    node = {}
    set_tree_node(node, 'test', 'yay')
    assert node == {'test': 'yay'}
    set_tree_node(node, 'test:1', 'yay')
    assert node['test'] == {1: 'yay'}
    set_tree_node(node, 'test:2:3', 'yay')
    assert node['test'][2] == {3: 'yay'}
    set_tree_node(node, 'test:2:4', 'yay')
    assert node['test'][2] == {3: 'yay', 4: 'yay'}

# Generated at 2022-06-12 08:26:52.613567
# Unit test for function get_tree_node
def test_get_tree_node():
    r = RegistryTree()
    r.register('foo', 'bar')
    assert(r.get('foo') == 'bar')
    r.register('foo:bar', 'baz')
    assert r.get('foo') == {'bar': 'baz'}
    assert r.get('foo:bar') == 'baz'

    # Test default
    assert r.get('nothere', default={'foo': 'foo'}) == {'foo': 'foo'}

    # Test parent
    assert r.get('foo:bar', parent=True) == {'bar': 'baz'}

    # Test KeyError raised when default not passed
    with pytest.raises(KeyError):
        r.get('nothere')



# Generated at 2022-06-12 08:27:03.669144
# Unit test for function get_tree_node
def test_get_tree_node():
    _example = {'a': {'b': {'c': {'d': 1}, 'd': 0}, 'f': []}, 'g': None}

    assert get_tree_node(_example, 'a') == {'b': {'c': {'d': 1}, 'd': 0}, 'f': []}
    assert get_tree_node(_example, 'a:b') == {'c': {'d': 1}, 'd': 0}
    assert get_tree_node(_example, 'a:b:c') == {'d': 1}
    assert get_tree_node(_example, 'a:b:c:d') == 1
    assert get_tree_node(_example, 'a:f') == []
    assert get_tree_node(_example, 'g') is None

    # with default
    assert get_

# Generated at 2022-06-12 08:27:12.575539
# Unit test for function get_tree_node
def test_get_tree_node():
    # Simple case
    assert get_tree_node({'a': 'b'}, 'a') == 'b'

    # A little bit more complex
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'

    # Now for the for-real tests.
    data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    # Test looping
    assert get_tree_node(data, 'a:b:c') == 'd'

    # Make sure we don't die on a missing key
    assert get_tree_node(data, 'a:z') is _sentinel

    # Test default value

# Generated at 2022-06-12 08:27:14.654130
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree, 'a') == {}
    assert get_tree_node(tree(), 'a:b:c') == {}
    assert get_tree_node(tree(), 'a:b:c', 5) == 5
    assert get_tree_node(tree(), 'a:b:c', _sentinel) is _sentinel


tree = Tree()

# Generated at 2022-06-12 08:27:22.486784
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_dict = {
        'one': {
            'two': {
                'four': 'Baz',
                'five': 'Quux'
            },
            'three': 'asdf',
        }
    }

    assert get_tree_node(tree_dict, 'one:three') == 'asdf'
    assert get_tree_node(tree_dict, 'one:three', parent=True)['three'] == 'asdf'
    assert get_tree_node(tree_dict, 'one:three', parent=True) is tree_dict['one']
    assert get_tree_node(tree_dict, 'one:three', default='fish') == 'asdf'
    assert get_tree_node(tree_dict, 'one:nothing', default='fish') == 'fish'

# Generated at 2022-06-12 08:27:26.361721
# Unit test for function set_tree_node
def test_set_tree_node():
    # Set up
    a = collections.defaultdict(dict)

    # Test
    assert set_tree_node(a, ':foo:bar:baz', 'qux') == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-12 08:27:36.113934
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for get_tree_node.

    Confirm that :py:func:`get_tree_node` is able to return all the appropriate results.
    This function, when the test is ran, should return None and raise no errors.

    """

    test_tree = {
        '1': {
            '2': {
                '3': 3
            }
        },
        '1:2': {
            '3': {
                '4': 4
            }
        }
    }
    assert get_tree_node(test_tree, '2', _sentinel) is _sentinel
    assert get_tree_node(test_tree, '2', default=None) is None
    assert get_tree_node(test_tree, '1:2:3:4') is 4

# Generated at 2022-06-12 08:27:43.529398
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = collections.defaultdict(lambda: 'default')
    mapping['foo.bar.baz'] = 'baz'

    assert get_tree_node(mapping, 'foo:bar:baz') == 'baz'
    assert get_tree_node(mapping, 'foo.bar.baz') == 'baz'
    assert get_tree_node(mapping, 'foo.baz.bar') == 'default'
    assert get_tree_node(mapping, 'foo.baz.bar', default='baz') == 'baz'



# Generated at 2022-06-12 08:27:53.437198
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function `get_tree_node`"""
    test_data = {
        'a': {
            'b': 'c',
        },
    }
    assert get_tree_node(test_data, 'a:b') == 'c'
    assert get_tree_node(test_data, 'a:b', default=None) == 'c'
    assert get_tree_node(test_data, 'a:c') is None
    assert get_tree_node(test_data, 'a:c', default=None) is None
    assert get_tree_node(test_data, 'a:c', default='lol') == 'lol'
    assert get_tree_node(test_data, 'a:c', default='lol', parent=True) == {'b': 'c'}
    assert get_

# Generated at 2022-06-12 08:28:38.977889
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    tree_dict = {
        'one': {
            'two': {
                'three': {
                    'four': {
                        'five': 'six'
                    }
                }
            }
        }
    }

    # Asserts
    assert get_tree_node(tree_dict, 'one') == {'two': {'three': {'four': {'five': 'six'}}}}
    assert get_tree_node(tree_dict, 'one:two') == {'three': {'four': {'five': 'six'}}}
    assert get_tree_node(tree_dict, 'one:two:three') == {'four': {'five': 'six'}}

# Generated at 2022-06-12 08:28:43.467694
# Unit test for function get_tree_node
def test_get_tree_node():
    source = {
        'foo': {
            'bar': {
                'baz': [
                    {'test': 'one'},
                ],
            },
        },
    }

    result = get_tree_node(source, 'foo:bar:baz:0:test')
    assert result == 'one'
    try:
        get_tree_node(source, 'foo:bar:baz:0:test2')
    except KeyError:
        pass
    else:
        assert False



# Generated at 2022-06-12 08:28:52.992727
# Unit test for function get_tree_node
def test_get_tree_node():
    config = {
        'a': {
            'b': {
                'c': 42
            }
        }
    }

    assert get_tree_node(config, 'a:b:c') == 42

    assert get_tree_node(config, 'a:b:c', default=23) == 42

    assert get_tree_node(config, 'a:b:d', default=23) == 23

    with raises(KeyError):
        get_tree_node(config, 'a:b:d')

    with raises(KeyError):
        get_tree_node(config, 'a:c')

    assert get_tree_node(config, 'a:b:c', parent=True) == {'c': 42}

# Generated at 2022-06-12 08:28:56.906362
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node"""
    tree = {}
    set_tree_node(tree, 'one:two:three', 'four')
    assert tree['one']['two']['three'] == 'four'



# Generated at 2022-06-12 08:28:59.040750
# Unit test for function get_tree_node
def test_get_tree_node():
    # This is a stupid shallow test.
    assert 'foo' == get_tree_node({'foo': 'bar'}, 'foo')



# Generated at 2022-06-12 08:29:06.064647
# Unit test for function get_tree_node
def test_get_tree_node():
    nested = {
        'outer': {
            'inner': {
                'my_key': 'my_value'
            }
        }
    }

    assert get_tree_node(nested, 'outer:inner:my_key') == 'my_value'

    nested = {
        'outer': {
        }
    }
    with pytest.raises(KeyError):
        get_tree_node(nested, 'outer:inner:my_key')

    assert get_tree_node(nested, 'outer:inner:my_key', default='my_default') == 'my_default'



# Generated at 2022-06-12 08:29:14.667527
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a', 1) == {'a': 1}
    assert set_tree_node({}, 'a:b', 1) == {'a': {'b': 1}}
    assert set_tree_node({'a': 'c'}, 'a:b', 1) == {'a': 'c', 'b': 1}
    assert set_tree_node({'a': {'b': 2}}, 'a:b', 1) == {'a': {'b': 1}}
    assert set_tree_node({'a': {'b': 2}}, 'a:c', 1) == {'a': {'b': 2, 'c': 1}}



# Generated at 2022-06-12 08:29:24.224942
# Unit test for function set_tree_node
def test_set_tree_node():
    input_mapping = {
        'a': {
            'b': {
                'c': {
                    'd': 'value1'
                }
            },
            'f': {
                'g': 'value2'
            },
            'h': 'value1'
        },
        'i': 'value2'
    }


# Generated at 2022-06-12 08:29:28.824126
# Unit test for function get_tree_node
def test_get_tree_node():
    expected = {'a': {'b': {'c': 42}}}
    res = get_tree_node(expected, 'a:b:c')
    assert res == 42
    assert get_tree_node(expected, 'a:b:c:d') == _sentinel
    res = get_tree_node(expected, 'a:b:c:d', default=None)
    assert res is None



# Generated at 2022-06-12 08:29:37.065942
# Unit test for function get_tree_node
def test_get_tree_node():
    mydict = {
        'a': 'foo',
        'b': {
            'bar': 'baz',
            'baz': {
                'qux': 'qux',
            },
        },
    }

    assert get_tree_node(mydict, 'a') == 'foo'
    assert get_tree_node(mydict, 'a:newkey') is _sentinel
    assert get_tree_node(mydict, 'a:newkey', default='something') == 'something'
    assert get_tree_node(mydict, 'a:b:c') is _sentinel
    assert get_tree_node(mydict, 'a:b:c', default='something') == 'something'

