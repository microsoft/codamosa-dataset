

# Generated at 2022-06-12 08:20:08.940341
# Unit test for function get_tree_node
def test_get_tree_node():
    trees = {'dict': {'a': {'b': 2}},
             'defaultdict': collections.defaultdict(dict, {'a': {'b': 2}}),
             'tree': tree(),
             'Tree': Tree(),
             'RegistryTree': RegistryTree(namespace='test')
             }

    for tree_name, tree in trees.items():
        tree['a.b'] = 1
        print('Testing get_tree_node on', tree_name)
        print(get_tree_node(tree, 'a.b'))
        print(get_tree_node(tree, 'a.b.c'))
        print(get_tree_node(tree, 'a.c'))
        print('\n')

    print('Testing get_tree_node on RegistryTree with namespace')

# Generated at 2022-06-12 08:20:17.409115
# Unit test for function get_tree_node
def test_get_tree_node():
    # If not key is specified, the full tree should be returned
    assert get_tree_node(tree({'foo': 'bar'}), '') == {'foo': 'bar'}

    # If keying doesn't exist, KeyError should be raised
    try:
        get_tree_node(tree({'foo': 'bar'}), 'bar')
    except KeyError:
        pass
    else:
        raise Exception("KeyError not raised on non-existent key")

    # If keying doesn't exist, and default is specified, default should be returned
    assert get_tree_node(tree({'foo': 'bar'}), 'baz', 'bam') == 'bam'

    # If keying exists, but not to a node of the tree, KeyError should be raised

# Generated at 2022-06-12 08:20:23.062183
# Unit test for function set_tree_node
def test_set_tree_node():
    import json
    data = json.loads('{ "node": { "foo": [ { "bar": { "baz": [ 1, 2, 3 ] }, "count": 100 } ] } }')
    set_tree_node(data, 'node:foo:0:bar:baz:0', 9999)
    assert data['node']['foo'][0]['bar']['baz'][0] == 9999



# Generated at 2022-06-12 08:20:34.475493
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
            '1': 1,
            'dict': {'this': 'is', 'a': 'dict'},
        },
        '1': 2,
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:dict:a', default='nope') == 'dict'
    assert get_tree_node(mapping, 'foo:dict:a:this') == {'this': 'is', 'a': 'dict'}
    assert get_tree_node(mapping, 'foo:dict:b', default='nope') == 'nope'


# Generated at 2022-06-12 08:20:42.307828
# Unit test for function get_tree_node
def test_get_tree_node():
    # Set up test data
    data = {'foo': {'bar': 'baz'}}
    key = 'foo:bar'
    # Test success
    result = get_tree_node(data, key)
    assert result == 'baz'
    # Test key error
    try:
        get_tree_node(data, 'bla:meh')
    except KeyError:
        pass
    # Test default
    result = get_tree_node(data, 'bla:meh', 'not found')
    assert result == 'not found'

# Generated at 2022-06-12 08:20:46.952734
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': 2
        }
    }
    assert get_tree_node(mapping, 'a:b') == 2
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:c')
    assert get_tree_node(mapping, 'a:c', 'mydefault') == 'mydefault'



# Generated at 2022-06-12 08:20:56.237211
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {
        'foo': {
            'foobar': {
                'bar': 'foo',
                'barfoo': 'bar',
            },
        },
    }
    set_tree_node(test_dict, 'foo:foobar:test', 'test_string')
    assert set_tree_node(test_dict, 'foo:foobar:test', 'foobar')['bar'] == 'foo'

    # Make sure that the function does not return the last key
    test_dict = {}
    set_tree_node(test_dict, 'foo:foobar', 'foobar')
    assert 'foobar' not in test_dict

    # Make sure that the function raises a KeyError when not found
    test_dict = {}

# Generated at 2022-06-12 08:21:01.142196
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {
        'b': {
            'c': {
                'd': 'woah'
            }
        }
    }
    assert get_tree_node(a, 'b:c:d') == 'woah'
    assert get_tree_node(a, 'b:c') == {'d': 'woah'}



# Generated at 2022-06-12 08:21:09.734304
# Unit test for function get_tree_node
def test_get_tree_node():
    foo = {
        "one": {
            "two": {
                "three": "value"
            }
        }
    }
    assert get_tree_node(foo, 'one:two:three', default="raise") == "value"
    assert get_tree_node(foo, 'one:two:three', default="raise") == "value"
    try:
        get_tree_node(foo, 'one:two:four', default="raise")
    except KeyError:
        pass
    else:
        assert False, "Should raise"

# Generated at 2022-06-12 08:21:19.238755
# Unit test for function set_tree_node
def test_set_tree_node():
    m = tree()
    set_tree_node(m, "a:a:a", 1)
    assert m["a"]["a"]["a"] == 1

    m = tree()
    set_tree_node(m, "a:a:a", 2)
    set_tree_node(m, "a:a:b", 3)
    assert m["a"]["a"]["b"] == 3
    assert m["a"]["a"]["a"] == 2

    m = tree()
    set_tree_node(m, "a:b:a", 1)
    set_tree_node(m, "a:b:a", 2)
    assert m["a"]["b"]["a"] == 2



# Generated at 2022-06-12 08:21:27.596973
# Unit test for function set_tree_node
def test_set_tree_node():
    "Simple unit test for `set_tree_node` function."
    # Setup
    tree = {}
    expected = {'foo': {'bar': 'baz'}}

    # Test
    set_tree_node(tree, 'foo:bar', 'baz')
    assert tree == expected



# Generated at 2022-06-12 08:21:37.777025
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test function set_tree_node"""
    assert set_tree_node(tree(), 'a', 1) == {'a': 1}
    assert set_tree_node(tree(), 'a:b', 2) == {'a': {'b': 2}}
    assert set_tree_node(tree(), 'a:b:c', 3) == {'a': {'b': {'c': 3}}}

    parent_tree = tree()
    assert set_tree_node(parent_tree, 'a:b:c', 3) == {'a': {'b': {'c': 3}}}
    assert set_tree_node(parent_tree, 'd', 4) == {'d': 4}
    assert set_tree_node(parent_tree, 'e:f', 5) == {'e': {'f': 5}}


# Generated at 2022-06-12 08:21:44.089760
# Unit test for function get_tree_node
def test_get_tree_node():
    print(get_tree_node({1: {'a': 'foo'}}, '1', default=_sentinel))
    print(get_tree_node({1: {'a': 'foo'}}, '1:a', default=_sentinel))
    print(get_tree_node({1: {'a': 'foo'}}, '2', default=_sentinel))
    print(get_tree_node({1: {'a': 'foo'}}, '3', default=_sentinel))


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:21:53.810498
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}

    set_tree_node(d, 't', 1)
    set_tree_node(d, 't:a', 2)
    set_tree_node(d, 't:a:b', 3)
    set_tree_node(d, 't:z', 4)
    set_tree_node(d, 't:z:x', 5)
    set_tree_node(d, 't:z:x:c', 6)
    set_tree_node(d, 't:z:x:c:v', 7)
    set_tree_node(d, 't:z:x:c:v:b', 8)

    assert d['t'] == 1
    assert d['t']['a'] == 2
    assert d['t']['a']['b'] == 3

# Generated at 2022-06-12 08:22:03.055214
# Unit test for function get_tree_node
def test_get_tree_node():
    node = tree()
    node['a']['b']['c'] = 1
    assert get_tree_node(node, 'a:b:c') == 1
    assert get_tree_node(node, 'a:b:c', parent=True) == {'c': 1}
    assert get_tree_node(node, 'a:b:c', default='asdf') == 1
    assert get_tree_node(node, 'a:b:c', default='asdf', parent=True) == {'c': 1}
    assert get_tree_node(node, 'a:b:d') == _sentinel



# Generated at 2022-06-12 08:22:06.035058
# Unit test for function set_tree_node
def test_set_tree_node():
    items = {'a': {'b': {'c': 5}}}
    set_tree_node(items, 'a:b:c', 6)
    assert items == {'a': {'b': {'c': 6}}}



# Generated at 2022-06-12 08:22:16.349533
# Unit test for function set_tree_node
def test_set_tree_node():
    """Testing function set_tree_node."""
    existing = {
        'a': {
            'b': {
                'c': {
                    'd': 'this is d',
                }
            }
        }
    }
    expected = {
        'a': {
            'b': {
                'c': {
                    'd': 'this is d',
                    'e': 1,
                }
            }
        }
    }
    assert set_tree_node(existing, 'a:b:c:e', 1) == expected
    assert set_tree_node(expected, 'a:b:c', 'c string') == {
        'a': {
            'b': 'c string',
        }
    }

# Generated at 2022-06-12 08:22:20.934791
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 1)
    set_tree_node(t, 'd:e:f', 2)
    assert t == {'a': {'b': {'c': 1}}, 'd': {'e': {'f': 2}}}



# Generated at 2022-06-12 08:22:26.850836
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {
        'one': 1,
        'two': 2,
        'three': {
            'three': {
                'three': 3
            }
        }
    }
    assert get_tree_node(t, 'one') == 1
    assert get_tree_node(t, 'one', default=0) == 1
 

# Generated at 2022-06-12 08:22:36.024604
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'my_key': 'my:value',
        'my_tree': {
            'level1': {
                'key1': 'value1',
                'key2': 'value2',
            },
            'level2': {
                'key3': {
                    'level3-1': 'value3:1',
                    'level3-2': 'value3:2',
                },
            },
        },
    }

    #  Test exact match
    assert get_tree_node(tree, 'my_key') == 'my:value'

    #  Test non-exact match
    assert get_tree_node(tree, 'my_tree') == tree['my_tree']

    #  Test non-exact match with sub-keys

# Generated at 2022-06-12 08:22:52.034138
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {
        'foo': {
            'bar': {
                'foobar': 'test'
            }
        }
    }

    assert get_tree_node(m, 'foo:bar:foobar') == 'test'
    assert get_tree_node(m, 'foo:bar')['foobar'] == 'test'
    assert get_tree_node(m, 'foo:bar1', default='blah') == 'blah'

    try:
        get_tree_node(m, 'foo1:bar:foobar')
        raise RuntimeError
    except KeyError:
        pass



# Generated at 2022-06-12 08:23:00.507196
# Unit test for function get_tree_node
def test_get_tree_node():
    one = {'one': {'two': {'three': 'four'}}}
    assert get_tree_node(one, 'one:two:three') == 'four'
    assert get_tree_node(one, 'one:two') == {'three': 'four'}
    assert get_tree_node(one, 'one:two:three', default=_sentinel) == 'four'
    assert get_tree_node(one, 'one:three:four', default=_sentinel) is _sentinel



# Generated at 2022-06-12 08:23:03.961264
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': 1,
        'b': 2,
        'c': {'d': 3}
    }

    assert get_tree_node(tree, 'a') == 1
    assert get_tree_node(tree, 'c:d') == 3
    assert get_tree_node(tree, 'c:e') is _sentinel
    assert get_tree_node(tree, 'c:e', 4) == 4
    assert get_tree_node(tree, 'c:e', parent=True) == {'d': 3}
    assert get_tree_node(tree, 'c:d:e', parent=True) == {'d': 3}



# Generated at 2022-06-12 08:23:12.539151
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node()
    """
    data = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz',
            },
            'baz': 'foobaz',
        },
        'bar': {
            'baz': 'barbaz',
        }
    }

    assert get_tree_node(data, 'foo:bar:baz') == 'foobarbaz'
    assert get_tree_node(data, 'bar:baz') == 'barbaz'
    assert get_tree_node(data, 'foo:baz') == 'foobaz'
    assert get_tree_node(data, 'foo:bar:olololol') is None

# Generated at 2022-06-12 08:23:15.097325
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': {
                'g': 'h'
            }
        }
    }
    assert get_tree_node(mapping, 'c:f:g') == 'h'



# Generated at 2022-06-12 08:23:19.548216
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a', 'b')
    assert tree['a'] == 'b'

    set_tree_node(tree, 'a:b', 'c')
    assert tree['a']['b'] == 'c'

    set_tree_node(tree, 'a:b:c', 'd')
    assert tree['a']['b']['c'] == 'd'


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-12 08:23:29.254065
# Unit test for function set_tree_node
def test_set_tree_node():
    import pytest
    mapping = {
        'a': {
            'b': {
                'c': {
                    '_value': 'foo',
                }
            }
        }
    }
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'x:y:z')

    mapping['x'] = {
        'y': {
            'z': {
                '_value': 'bar',
            }
        }
    }
    assert get_tree_node(mapping, 'x:y:z') == 'bar'
    assert get_tree_node(mapping, 'a:b') == {'c': {'_value': 'foo'}}
    assert get_tree_node(mapping, 'a:b:c') == {'_value': 'foo'}

# Generated at 2022-06-12 08:23:31.896364
# Unit test for function set_tree_node
def test_set_tree_node():
    abc = tree()
    set_tree_node(abc, 'a:b:c', "Hello World")
    assert abc['a']['b']['c'] == "Hello World"



# Generated at 2022-06-12 08:23:42.694866
# Unit test for function get_tree_node
def test_get_tree_node():
    f = {
        'a': {'b': 1, 'c': 2, 'd': 'thing'},
        'b': {'b': 3, 'c': 4}
    }
    assert get_tree_node(mapping=f, key='a') == f['a']
    assert get_tree_node(mapping=f, key='a:b') == 1
    assert get_tree_node(mapping=f, key='a:d') == 'thing'
    assert get_tree_node(mapping=f, key='a:e') == _sentinel
    assert get_tree_node(mapping=f, key='b:c') == 4
    assert get_tree_node(mapping=f, key='b:c:d') == _sentinel

# Generated at 2022-06-12 08:23:47.897420
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    # Create the following tree structure:
    # d['a']['b']['c'] = "Hello world!"
    set_tree_node(d, 'a:b:c', "Hello world!")
    assert d['a']['b']['c'] == "Hello world!"

# Generated at 2022-06-12 08:24:16.193617
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'some': {
            'mapping': {
                'data': 'some_value'
            }
        }
    }
    assert get_tree_node(mapping, 'some:mapping:data') == 'some_value'
    assert get_tree_node(mapping, 'some')['mapping']['data'] == 'some_value'
    assert get_tree_node(mapping, 'some:mapping')['data'] == 'some_value'
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'some:mapping:data:does:not:exist')
    assert get_tree_node(mapping, 'some:mapping:data:does:not:exist', default=None) is None

# Generated at 2022-06-12 08:24:23.274002
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
        },
    }

    assert get_tree_node(mapping, 'foo') == {'bar': 'baz'}
    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:car') == _sentinel
    assert get_tree_node(mapping, 'foo:car', default='baz') == 'baz'



# Generated at 2022-06-12 08:24:31.096327
# Unit test for function get_tree_node
def test_get_tree_node():
    dict_ = {'one': 1, 'two': 2, 'three': {'four': 4, 'five': {'six': 6}}}

    assert 1 == get_tree_node(dict_, 'one')
    assert 1 == get_tree_node(dict_, 'one', default=None)
    assert 4 == get_tree_node(dict_, 'three:four')
    assert 6 == get_tree_node(dict_, 'three:five:six')
    assert {'six': 6} == get_tree_node(dict_, 'three:five', parent=True)
    assert 6 == get_tree_node(dict_, 'three:five:six', parent=True)


# Generated at 2022-06-12 08:24:38.759150
# Unit test for function get_tree_node
def test_get_tree_node():
    test_paren = {"foo": "bar"}
    assert get_tree_node(test_paren, 'foo') == 'bar'
    test_child = {"foo": {"bar": "baz"}}
    assert get_tree_node(test_child, 'foo:bar') == 'baz'
    test_grandchild = {"foo": {"bar": {"baz": "quux"}}}
    assert get_tree_node(test_grandchild, 'foo:bar:baz') == 'quux'
    assert get_tree_node(test_grandchild, 'foo:bar') == {"baz": "quux"}

# Generated at 2022-06-12 08:24:42.189125
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'hello:world', 'MyNameIsEarl')
    assert t['hello']['world'] == 'MyNameIsEarl'



# Generated at 2022-06-12 08:24:51.890959
# Unit test for function get_tree_node
def test_get_tree_node():

    t = {
        'a': {
            'b': {
                'c': 'd',
            }
        }
    }

    get_tree_node(t, 'a:b:c') == 'd'


if __name__ == '__main__':

    tree = RegistryTree()
    tree.register('foo', 1)
    tree.register('f:o:o', 2)
    tree.register('a', 3)
    tree.register('a:b', 4)

    print(tree)
    # {'a': {'b': 4}, 'f': {'o': {'o': 2}}, 'foo': 1}

    print(tree.get('a'))
    # 3

    print(tree.get('a:b'))
    # 4


# Generated at 2022-06-12 08:24:59.662993
# Unit test for function set_tree_node
def test_set_tree_node():
    test_mapping = {
        'test': {
            'test': {
                'test': True,
            },
            'test2': True
        },
        'test2': True
    }

    assert set_tree_node(test_mapping, 'test:test3', True)['test'] == {'test3': True, 'test': {'test': True}}
    assert set_tree_node(test_mapping, 'test2:test2', True)['test2'] == {'test2': True}
    assert set_tree_node(test_mapping, 'test2', True)['test2'] == True



# Generated at 2022-06-12 08:25:06.624064
# Unit test for function get_tree_node
def test_get_tree_node():
    # Basic
    mapping = {
        'a': {
            'b': {
                'c': 1,
                'd': 2,
                'e': 3,
            },
            'b2': {
                'c2': 2,
                'd2': 3,
                'e2': 4,
            },
        },
        'a2': {
            'b2': {
                'c2': 3,
                'd2': 4,
                'e2': 5,
            },
            'b3': {
                'c3': 4,
                'd3': 5,
                'e3': 6,
            },
        },
    }

    # Basic
    assert get_tree_node(mapping, 'a:b:c') == 1

# Generated at 2022-06-12 08:25:17.368643
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for various set_tree_node use cases."""
    # Bad input
    with pytest.raises(KeyError):
        assert get_tree_node({}, 'bad_method', _sentinel)
    # Good input
    assert get_tree_node({'test': 'value'}, 'test') == 'value'
    # Invalid key
    assert get_tree_node({'test': 'value'}, 'bad_method', default='default') == 'default'
    # Complex input
    assert get_tree_node({'test': {'subnode': 'value'}}, 'test:subnode') == 'value'
    # Invalid key in complex input
    assert get_tree_node({'test': {'subnode': 'value'}}, 'test:bad_method', default='default') == 'default'

# Generated at 2022-06-12 08:25:27.198797
# Unit test for function get_tree_node
def test_get_tree_node():
    import pytest

    mapping = {
        'foo': {
            'bar': 'baz',
            'buzz': {
                'quux': 'quuz'
            }
        },
        'oof': 'rab',
        'b': 1,
        'c': 2,
        'd': {
            'e': 3,
        }
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:buzz:quux') == 'quuz'
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'oof:rab')
    assert get_tree_node(mapping, 'b') == 1
    assert get_tree_node(mapping, 'c') == 2


# Generated at 2022-06-12 08:26:14.636638
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 1)
    assert d == {'a': {'b': {'c': 1}}}
    set_tree_node(d, 'a:b:d', 1)
    assert d == {'a': {'b': {'c': 1, 'd': 1}}}
    set_tree_node(d, 'a:b:c', 2)
    assert d == {'a': {'b': {'c': 2, 'd': 1}}}
    set_tree_node(d, 'a:c:f', 3)
    assert d == {'a': {'b': {'c': 2, 'd': 1}, 'c': {'f': 3}}}

    # Overwrite key

# Generated at 2022-06-12 08:26:22.717394
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for `dpf.utils.get_tree_node`
    """
    a = {
        'a': {
            'a': 'aaa',
            'b': 'abb',
            'c': 'acc'
        },
        'b': {
            'a': 'baa',
            'b': 'bbb',
            'c': 'bcc'
        },
        'c': {
            'a': 'caa',
            'b': 'cbb',
            'c': 'ccc'
        }
    }

    assert get_tree_node(a, 'a:b') == 'abb'
    assert get_tree_node(a, 'b:a') == 'baa'
    assert get_tree_node(a, 'c:c') == 'ccc'




# Generated at 2022-06-12 08:26:32.529611
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_mapping = {
        'foo': 'bar',
        'baz': {
            'boo': {
                'foo': 'bar',
                'baz': 'baz',
            }
        },
        'list': [
            'foo',
            'bar',
            'baz'
        ]
    }
    assert 'bar' == get_tree_node(tree_mapping, 'foo')
    assert 'bar' == get_tree_node(tree_mapping, 'baz:boo:foo')
    assert 'baz' == get_tree_node(tree_mapping, 'baz:boo:baz')
    assert tree_mapping['baz']['boo'] == get_tree_node(tree_mapping, 'baz:boo', parent=True)
   

# Generated at 2022-06-12 08:26:36.383241
# Unit test for function set_tree_node
def test_set_tree_node():
    # Setup
    foo = tree()
    # Test
    set_tree_node(foo, 'bar', 'baz')
    # Check
    assert 'baz' == foo['bar']



# Generated at 2022-06-12 08:26:44.080563
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    unit test for function get_tree_node()
    """
    mapping = {
        'hello': {'world': 'foo'},
        'void': '',
        'foobar': {
            'foo': {
                'bar': 'bar',
                'foo': 'foo'
            }
        },
        'barfoo': {}
    }
    assert get_tree_node(mapping, 'foobar:foo:bar') == 'bar'
    try:
        get_tree_node(mapping, 'hello:foo')
    except KeyError:
        pass
    else:
        raise AssertionError('No exception raised')
    assert get_tree_node(mapping, 'hello:foo', default=None) is None
    assert get_tree_node(mapping, 'void') == ''

# Generated at 2022-06-12 08:26:53.318265
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {
            'b': {
                'c': 'f'
            },
            'e': 'd'
        }
    }

    assert get_tree_node(d, 'a') == d['a']
    assert get_tree_node(d, 'a:b') == d['a']['b']
    assert get_tree_node(d, 'a:b:c') == 'f'
    assert get_tree_node(d, 'a:e') == 'd'
    assert get_tree_node(d, 'a:e:f') is _sentinel

    assert get_tree_node(d, 'a:b:c', default=0) == 'f'
    assert get_tree_node(d, 'a:e:f', default=0) == 0

# Generated at 2022-06-12 08:27:04.152423
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_node = {"foo1": {"bar1": {"baz1": {"bin1": "foo.bar.baz.bin"}}, "bar2": "foo.bar.bin"},
                 "foo2": "foo.baz"}

    # test return value
    assert get_tree_node(tree_node, 'foo1:bar1:baz1:bin1') == 'foo.bar.baz.bin'
    assert get_tree_node(tree_node, 'foo1:bar1:baz2:bin2') is _sentinel

    # test default value
    assert get_tree_node(tree_node, 'foo1:bar1:baz2:bin2', default='foo.bar.baz.bin.bin') == 'foo.bar.baz.bin.bin'

    # test parent node

# Generated at 2022-06-12 08:27:12.770431
# Unit test for function get_tree_node

# Generated at 2022-06-12 08:27:21.389890
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'a': 1,
        'b': {
            'c': 1,
            'd': 2,
            'f': {
                'g': 1,
                'h': 2,
                'i': {
                    'j': 1,
                    'k': 2,
                    'l': 3,
                }
            }
        }
    }

    assert get_tree_node(test_dict, 'a') == 1
    assert get_tree_node(test_dict, 'b') == {'c': 1, 'd': 2, 'f': {'g': 1, 'h': 2, 'i': {'j': 1, 'k': 2, 'l': 3}}}
    assert get_tree_node(test_dict, 'b:c') == 1
    assert get_tree_node

# Generated at 2022-06-12 08:27:24.954571
# Unit test for function set_tree_node
def test_set_tree_node():
    import pudb
    pudb.set_trace()
    tree = Tree()
    set_tree_node(tree, 'a:b:c', 10)
    assert tree['a']['b']['c'] == 10

# Generated at 2022-06-12 08:28:48.619690
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    set_tree_node(test_tree, 'key1:key2:key3', 'value')
    assert(test_tree['key1']['key2']['key3'] == 'value')



# Generated at 2022-06-12 08:28:50.471960
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'stuff')
    assert test_dict['a']['b']['c'] == 'stuff'



# Generated at 2022-06-12 08:28:59.212028
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', default=123) == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', default=123, parent=True) == {'bar': 'baz'}
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:qux', default=123) == 123



# Generated at 2022-06-12 08:29:09.014288
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""

    # Test nested structure
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    value = get_tree_node(mapping, 'a:b:c')
    assert value == 'd'

    # Test nested structure with multiple keys
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    value = get_tree_node(mapping, 'a')
    assert value == {'b': {'c': 'd'}}

    # Test non-existent key
    mapping = {
        'a': {
            'b': 'c',
        },
    }

# Generated at 2022-06-12 08:29:16.631681
# Unit test for function get_tree_node

# Generated at 2022-06-12 08:29:19.698159
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    key = 'a:b:c'
    value = 'd'
    set_tree_node(mapping, key, value)
    assert mapping['a']['b']['c'] == 'd'



# Generated at 2022-06-12 08:29:24.065532
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['a:b']['c:d'] = 'ABCD'
    assert get_tree_node(t, 'a:b:c:d') == 'ABCD'
    try:
        get_tree_node(t, 'a:b:d:e')
        assert False
    except KeyError as exc:
        assert True



# Generated at 2022-06-12 08:29:32.603960
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'a': {
            'b': {
                'c': 'abc',
                'd': 'abd',
            }
        },
        'e': 'e',
        'f': {
            'g': 'fg',
        },
        'h': {
            'i': 'hi',
            'j': {
                'k': 'hjk',
            },
            'l': {
                'm': 'hlm',
                'n': 'hln',
            },
        },
    }

    assert get_tree_node(test_dict, 'e') == 'e'
    assert get_tree_node(test_dict, 'f:g') == 'fg'

# Generated at 2022-06-12 08:29:38.209685
# Unit test for function set_tree_node
def test_set_tree_node():
    from nose.tools import assert_equal
    my_tree = tree()

    set_tree_node(my_tree, 'one:two:three', 'value')
    assert_equal(my_tree['one:two:three'], 'value')

    set_tree_node(my_tree, 'one:two:four', 'value2')
    assert_equal(my_tree['one:two:four'], 'value2')



# Generated at 2022-06-12 08:29:46.806226
# Unit test for function set_tree_node
def test_set_tree_node():
    data = tree()
    set_tree_node(data, "foo", "bar")
    assert data["foo"] == "bar"
    set_tree_node(data, "foo:bar", "baz")
    assert data["foo"]["bar"] == "baz"
    set_tree_node(data, "foo:bar:baz:foo:bar:baz", "baz")
    assert data["foo"]["bar"]["baz"]["foo"]["bar"]["baz"] == "baz"
