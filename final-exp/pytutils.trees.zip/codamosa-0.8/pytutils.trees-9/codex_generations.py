

# Generated at 2022-06-12 08:20:09.205397
# Unit test for function get_tree_node
def test_get_tree_node():

    TREE = tree()
    TREE['some']['value'] = 'some_value'
    TREE['some']['other']['value'] = 'other_value'
    TREE['some']['parent'] = {'child': 'child_value', 'child2': 'child2_value'}
    TREE['some']['parent']['child2'] = {'child': 'child_value', 'child2': 'child2_value'}

    assert get_tree_node(TREE, 'some:child') == 'child_value'
    assert get_tree_node(TREE, 'some:child', default='default') == 'default'

    with pytest.raises(KeyError):
        get_tree_node(TREE, 'missing:key')



# Generated at 2022-06-12 08:20:17.459344
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': 1, 'b': {'c': 3, 'd': 4}, 'g': [1, 2, 3]}
    assert get_tree_node(d, 'a') == 1
    assert get_tree_node(d, 'b:c') == 3
    assert get_tree_node(d, 'b:c', parent=True) == {'c': 3, 'd': 4}
    assert get_tree_node(d, 'b:c', default=0) == 3
    assert get_tree_node(d, 'b:e', default=0) == 0
    assert get_tree_node(d, 'b:e', None) is None
    assert get_tree_node(d, 'g', None) is None
    assert get_tree_node(d, 'f', default=0)

# Generated at 2022-06-12 08:20:20.676573
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(dict)
    set_tree_node(tree, 'a:b:c', 'hello world')
    assert tree['a']['b']['c'] == 'hello world'



# Generated at 2022-06-12 08:20:27.693343
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 1)
    set_tree_node(mapping, 'a:b:d', 2)
    set_tree_node(mapping, 'a:b', 3)
    set_tree_node(mapping, 'a', 4)

# Generated at 2022-06-12 08:20:33.153371
# Unit test for function set_tree_node
def test_set_tree_node():

    # Make your own dictionary, or use an existing one
    # collection.defaultdict(dict) might be suitable for building a tree
    d = collections.defaultdict(dict)

    # find_or_create a subdictionary
    set_tree_node(d, 'a:b:c', 42)

    # Assert values
    assert d['a']['b']['c'] == 42



# Generated at 2022-06-12 08:20:40.927050
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'key:subkey:subsubkey', 'value')
    assert tree == {'key': {'subkey': {'subsubkey': 'value'}}}

    set_tree_node(tree, 'key:subkey2:subsubkey2', 'value2')
    assert tree == {'key': {'subkey': {'subsubkey': 'value'},
                            'subkey2': {'subsubkey2': 'value2'}}}



# Generated at 2022-06-12 08:20:46.344624
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 3}}, 'a:b') == 3
    try:
        get_tree_node({'a': {'b': 3}}, 'a:c')
        assert False
    except KeyError:
        assert True

    assert get_tree_node({'a': {'b': 3}}, 'a:c', default='d') == 'd'



# Generated at 2022-06-12 08:20:55.805415
# Unit test for function get_tree_node
def test_get_tree_node():
    root = collections.OrderedDict({
        'foo': {
            'bar': {
                'baz': 'foo-bar-baz-value',
                'another-baz': 'foo-bar-another-baz-value',
            }
        },
        'alpha': {
            'beta': {
                'gamma': 'alpha-beta-gamma-value',
            }
        },
    })

    assert get_tree_node(root, 'foo:bar:baz') == 'foo-bar-baz-value'
    assert get_tree_node(root, 'foo:bar:another-baz') == 'foo-bar-another-baz-value'
    assert get_tree_node(root, 'alpha:beta:gamma') == 'alpha-beta-gamma-value'
    assert get

# Generated at 2022-06-12 08:21:00.341278
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'foo:bar:baz', 'foobarbaz')

    expected = {'foo': {'bar': {'baz': 'foobarbaz'}}}
    assert data == expected, 'set_tree_node works'



# Generated at 2022-06-12 08:21:02.871146
# Unit test for function get_tree_node
def test_get_tree_node():
    print(get_tree_node({'a': {'b': 'c'}}, 'a:b'))



# Generated at 2022-06-12 08:21:14.867022
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'test': {
            'test2': {
                'test3': {
                    'test4': 'test5',
                },
            },
        },
    }
    assert get_tree_node(mapping, 'test:test2', default='test') == {'test3': {'test4': 'test5'}}
    assert get_tree_node(mapping, 'test:test2:test3:test4', default='test') == 'test5'
    assert get_tree_node(mapping, 'test:test2:test3:test4:test5', default='test') == 'test'


# Generated at 2022-06-12 08:21:18.062097
# Unit test for function get_tree_node
def test_get_tree_node():
    input_ = {
        'foo': {
            'bar': {
                'baz': 'zab',
            }
        }
    }
    foo = get_tree_node(input_, 'foo')
    assert 'bar' in foo
    assert 'baz' in get_tree_node(input_, 'foo:bar')
    assert 'zab' == get_tree_node(input_, 'foo:bar:baz')
    assert get_tree_node(input_, 'foo:bar:baz:zab') is None



# Generated at 2022-06-12 08:21:25.080247
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'c': {
                'd': 'hello'
            }
        },
        'b': {
            'f': 'foobar'
        }
    }
    assert get_tree_node(mapping, 'a:c:d') == 'hello'
    assert get_tree_node(mapping, 'b:f') == 'foobar'
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'b:f:g') == 'foobar'
    assert get_tree_node(mapping, 'b:f:g', default='notfound') == 'notfound'



# Generated at 2022-06-12 08:21:31.599579
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a') == {'b': {'c': 'd'}}
    assert get_tree_node(mapping, 'a:b') == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-12 08:21:39.029687
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a', 1) == {'a': 1}
    assert set_tree_node({}, 'a:b', 1) == {'a': {'b': 1}}
    assert set_tree_node({'a': {'b': 2}}, 'a:b', 1) == {'a': {'b': 1}}
    assert set_tree_node({'a': {'b': 2}}, 'a:c', 1) == {'a': {'b': 2, 'c': 1}}



# Generated at 2022-06-12 08:21:47.122974
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = collections.defaultdict(dict)
    set_tree_node(test_dict, 'test:test2:test3', 'hello')

    assert test_dict == {'test': {'test2': {'test3': 'hello'}}}

    test_dict = {'test': {'test2': {'test3': 'hello'}}}
    set_tree_node(test_dict, 'test:test2:test4', 'hello2')

    assert test_dict == {'test': {'test2': {'test3': 'hello', 'test4': 'hello2'}}}



# Generated at 2022-06-12 08:21:50.186940
# Unit test for function set_tree_node
def test_set_tree_node():
    import random

    test_mapping = {}
    test_key = 'foo:bar:baz'
    test_value = random.random()

    set_tree_node(test_mapping, test_key, test_value)

    assert test_mapping['foo']['bar']['baz'] == test_value



# Generated at 2022-06-12 08:21:57.224101
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    print("~~~ TEST get_tree_node ~~~")
    tree = {
        "some": {
            "key": {
                "in": {
                    "a": {
                        "tree": 42
                    }
                }
            }
        }
    }

    assert 42 == get_tree_node(tree, 'some:key:in:a:tree')
    assert collections.OrderedDict == get_tree_node(tree, 'some:key:in').__class__
    assert collections.OrderedDict == get_tree_node(tree, 'some').__class__

    assert None is get_tree_node(tree, 'some:key:in:a:tree:another', default=None)

    with pytest.raises(KeyError):
        get

# Generated at 2022-06-12 08:22:07.291361
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    sample_tree = {
        "root1": {
            "sub1": {
                "subsub1": "matched value",
                "subsub2": "other value",
            },
            "sub2": {
                "subsub2": "other value",
            },
        },
        "root2": {
            "sub1": {
                "subsub1": "other value",
                "subsub2": "other value",
            },
            "sub2": {
                "subsub2": "other value",
            },
        },
        "root3": "other value",
    }
    assert get_tree_node(sample_tree, 'root1', default=False)

# Generated at 2022-06-12 08:22:11.414394
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 1)
    assert tree == {
        'a': {
            'b': {
                'c': 1
            }
        }
    }



# Generated at 2022-06-12 08:22:24.485015
# Unit test for function get_tree_node
def test_get_tree_node():
    mapper = collections.OrderedDict((
        ('a', collections.OrderedDict((
            ('b', collections.OrderedDict((
                ('c', 'value'),
            ))),
        ))),
    ))

    assert 'value' == get_tree_node(mapper, 'a:b:c')
    assert 'value' == get_tree_node(mapper, 'a.b.c', default='value')
    assert get_tree_node(mapper, 'a:b:d', default=False) is False
    assert get_tree_node(mapper, 'a:b:d') == KeyError



# Generated at 2022-06-12 08:22:27.960927
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': 'bar', 'inner': {'value': 'baz'}}
    assert get_tree_node(mapping, 'foo') == 'bar'
    assert get_tree_node(mapping, 'inner:value') == 'baz'

# Generated at 2022-06-12 08:22:31.330814
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'foo:bar:baz', 'fizzbuzz')
    assert t['foo']['bar']['baz'] == 'fizzbuzz'



# Generated at 2022-06-12 08:22:36.339467
# Unit test for function get_tree_node
def test_get_tree_node():
    testdict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(testdict, 'a') == {'b': {'c': 'd'}}
    assert get_tree_node(testdict, 'a:b') == {'c': 'd'}
    assert get_tree_node(testdict, 'a:b:c') == 'd'



# Generated at 2022-06-12 08:22:46.607570
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'one': 1,
        'two': 2,
        'three': {
            'four': 4,
            'five': 5,
            'six': {
                'seven': 7
            },
            'seven': 7
        }
    }

    # Basic
    assert get_tree_node(test_tree, 'one') == 1
    assert get_tree_node(test_tree, 'two') == 2

    # Dimensional
    assert get_tree_node(test_tree, 'three:four') == 4
    assert get_tree_node(test_tree, 'three:five') == 5
    assert get_tree_node(test_tree, 'three:six:seven') == 7

    # Default handling
    assert get_tree_node(test_tree, 'four') is _sentinel

# Generated at 2022-06-12 08:22:54.379859
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_node_dict = {}
    set_tree_node(tree_node_dict, 'bio:current-affiliations:institution', 'MIT')
    set_tree_node(tree_node_dict, 'bio:current-affiliations:position', 'student')
    set_tree_node(tree_node_dict, 'bio:current-affiliations:years-active', '2012-present')
    assert tree_node_dict['bio']['current-affiliations']['institution'] == 'MIT'
    assert tree_node_dict['bio']['current-affiliations']['position'] == 'student'
    assert tree_node_dict['bio']['current-affiliations']['years-active'] == '2012-present'



# Generated at 2022-06-12 08:23:00.753624
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    t = {}
    set_tree_node(t, 'a', 1)
    assert t['a'] == 1
    set_tree_node(t, 'b:c', 2)
    assert t['b']['c'] == 2
    print('Test passed: set_tree_node')



# Generated at 2022-06-12 08:23:10.043116
# Unit test for function get_tree_node
def test_get_tree_node():  # {{{
    class TestDict(dict):
        pass

    data = TestDict({
        # root
        'foo': {
            'bar': {
                'x': 1,
                'y': 2,
                'z': 3,
                'dict': {
                    'a': 1,
                    'b': 2,
                    'c': 3,
                },
                'list': [5, 6, 7, 8],
            }
        },
        'qux': [
            1, 2, 3, 4, {
                'a': 1,
                'b': 2,
                'c': 3,
            }
        ]
    })

    # Fetch a 'leaf'
    assert get_tree_node(data, 'foo:bar:x') == 1

# Generated at 2022-06-12 08:23:16.800651
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo', 'bar')
    assert tree['foo'] == 'bar'

    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'zip')
    assert tree['foo']['bar']['baz'] == 'zip'

    tree = {}
    set_tree_node(tree, 'foo:bar:baz', ['foo', 'bar'])
    assert tree['foo']['bar']['baz'] == ['foo', 'bar']



# Generated at 2022-06-12 08:23:26.896050
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    set_tree_node(test_tree, 'x', 'X')
    set_tree_node(test_tree, 'a:b:c:d', 'D')
    set_tree_node(test_tree, 'a:b:c:e', 'E')
    set_tree_node(test_tree, 'a:b:c:f', 'F')
    set_tree_node(test_tree, 'y:z', 'Z')
    assert test_tree['x'] == 'X'
    assert test_tree['a']['b']['c']['d'] == 'D'
    assert test_tree['a']['b']['c']['e'] == 'E'

# Generated at 2022-06-12 08:23:58.090778
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    # print(mapping)
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-12 08:24:01.285728
# Unit test for function set_tree_node
def test_set_tree_node():
    x = tree()
    #x = {}
    set_tree_node(x, 'foo:bar:baz', 'huh')
    assert x['foo']['bar']['baz'] == 'huh'



# Generated at 2022-06-12 08:24:11.632707
# Unit test for function get_tree_node

# Generated at 2022-06-12 08:24:20.980518
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['a'] = tree()
    t['a']['b'] = tree()
    t['a']['b']['c'] = tree()
    t['a']['b']['c']['d'] = 'e'
    assert get_tree_node(t, 'a:b:c:d') == 'e'
    assert get_tree_node(t, 'a:b:c:d:e', default='f') == 'f'
    with pytest.raises(KeyError):
        get_tree_node(t, 'a:b:c:d:e')



# Generated at 2022-06-12 08:24:24.581401
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    assert set_tree_node(mapping, 'key:0:name', 'foo') == mapping['key'][0]
    assert set_tree_node(mapping, 'key:0:name', 'foo') == mapping['key'][0]
    assert mapping['key'][0]['name'] == 'foo'

# Generated at 2022-06-12 08:24:27.806818
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 'value')

# Generated at 2022-06-12 08:24:36.011372
# Unit test for function get_tree_node
def test_get_tree_node():
    my_tree = {
        'object_1': {
            'attribute_1': {
                'attribute_2': 'value_1',
                'attribute_3': 'value_2'
            },
            'attribute_4': 'value_3'
        },
        'object_2': 'value_4'
    }

    assert get_tree_node(my_tree, 'object_2') == 'value_4'
    assert get_tree_node(my_tree, 'object_1:attribute_4') == 'value_3'
    assert get_tree_node(my_tree, 'object_1:attribute_1:attribute_2') == 'value_1'



# Generated at 2022-06-12 08:24:43.624094
# Unit test for function get_tree_node
def test_get_tree_node():
    result = 'value'
    mapping = {'key1': {'key2': result}}
    assert get_tree_node(mapping, 'key1:key2') == result
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'key1:key3')
    assert get_tree_node(mapping, 'key1:key3', default=None) is None
    assert get_tree_node(mapping, 'key1:key2', parent=True) == {'key2': result}

# Generated at 2022-06-12 08:24:49.170630
# Unit test for function get_tree_node
def test_get_tree_node():
    dict = {'foo': {'bar': 'baz'}}
    assert get_tree_node(dict, 'foo:bar') == 'baz'
    assert get_tree_node(dict, 'foo') == {'bar': 'baz'}


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 08:24:55.315215
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        '1': {},
        '2': {},
        '3': {},
        '4': {},
        '5': {
            '1': {
                '1': {},
                '2': {}
            }
        }
    }
    first = get_tree_node(data, '1')
    assert first is not None
    assert first == {}

    second = get_tree_node(data, '5:1')
    assert second is not None
    assert second == {
        '1': {},
        '2': {}
    }

    last = get_tree_node(data, '5:1:1')
    assert last is not None
    assert last == {}

    # Verify that KeyError is thrown

# Generated at 2022-06-12 08:25:31.990976
# Unit test for function set_tree_node
def test_set_tree_node():
    node = {}
    set_tree_node(node, 'a:b:c:d:e:f', '')
    assert node['a']['b']['c']['d']['e']['f'] == ''



# Generated at 2022-06-12 08:25:39.467729
# Unit test for function get_tree_node
def test_get_tree_node():
    # Prepare
    test_tree = tree()
    test_key = 'root:first_child:second_child'
    test_value = 'test'
    set_tree_node(mapping=test_tree, key=test_key, value=test_value)
    # Action
    actual = get_tree_node(mapping=test_tree, key=test_key)
    # Assert
    assert actual == test_value



# Generated at 2022-06-12 08:25:47.452901
# Unit test for function get_tree_node
def test_get_tree_node():
    q = {'a': {'a': 'aa', 'b': 'ab'},
         'b': {'a': 'ba', 'b': 'bb'}}

    assert 'aa' == get_tree_node(q, 'a:a')
    assert 'bb' == get_tree_node(q, 'b:b')

    assert collections.Mapping == get_tree_node(q, 'b').__class__
    assert 'aa' == get_tree_node(q, 'a:a', parent=True)['a']

    try:
        get_tree_node(q, 'c:c')
        assert False
    except KeyError:
        assert True

    try:
        get_tree_node(q, 'a:c')
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-12 08:25:58.248177
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    try:
        get_tree_node(tree, 'invalid node')
        assert False
    except KeyError:
        assert True
    assert 'qux' == get_tree_node(tree, 'foo:bar:baz')
    assert 'qux' == get_tree_node(tree, 'foo:bar:baz')
    assert 'bar' == get_tree_node(tree, 'foo:bar:baz', parent=True)
    assert 'qux' == get_tree_node(tree, 'foo:bar:baz:invalid', default=tree['foo']['bar']['baz'])



# Generated at 2022-06-12 08:26:02.713525
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = tree()
    test_string = 'root:some:key:some:other:key'
    test_value = 'test value'
    set_tree_node(test_dict, test_string, test_value)
    assert test_dict['root']['some']['key']['some']['other']['key'] == 'test value'



# Generated at 2022-06-12 08:26:13.120496
# Unit test for function get_tree_node
def test_get_tree_node():

    # Setup
    data = {
        'a': {
            'b': {
                'c': 1
            }
        }
    }

    # Test absolute path
    assert get_tree_node(data, 'a:b:c') == 1

    # Test relative path
    assert get_tree_node(data, ':b:c') == 1

    # Test relative path with non-matching root
    assert get_tree_node(data, ':b:c', default=None) == None

    # Test relative path with default value
    assert get_tree_node(data, ':b:d', default=None) == None

    # Test relative path with parent node
    assert get_tree_node(data, ':b:c', parent=True) == {'c': 1}

    # Test relative path with parent node

# Generated at 2022-06-12 08:26:15.957292
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar', 'baz')
    assert tree['foo']['bar'] == 'baz'



# Generated at 2022-06-12 08:26:23.346791
# Unit test for function get_tree_node
def test_get_tree_node():
    import sys
    import six

    mapping = {
        'foo': {
            'bar': {
                'baz': 'banana',
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'banana'

    # Should raise exception if default not specified
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'foo:bar:baz:sucks')

    # Should return default
    assert get_tree_node(mapping, 'foo:bar:baz:until_it_doesnt', default=1337) == 1337

    # Should return parent node

# Generated at 2022-06-12 08:26:33.065687
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test function get_tree_node."""
    assert get_tree_node({'world': {'hello': 'bye'}}, 'world:hello') == 'bye'
    assert get_tree_node({'world': {'hello': 'bye'}}, 'world:hello', default='bye') == 'bye'
    assert get_tree_node({'world': {'hello': 'bye'}}, 'world:hello', default=None) == 'bye'
    assert get_tree_node({'world': {'hello': 'bye'}}, 'world:hi', default='bye') == 'bye'
    assert get_tree_node({'world': {'hello': 'bye'}}, 'world:hi', default='bye') == 'bye'

# Generated at 2022-06-12 08:26:42.945705
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': 'bar',
        'baz': [1, 2, 3],
        'qux': {
            'quux': [{'corge': 'grault'}, 4, 5, 6]
        }
    }

    assert get_tree_node(mapping, 'foo', default=None) == 'bar'
    assert get_tree_node(mapping, 'baz') == [1, 2, 3]
    assert get_tree_node(mapping, 'baz:0') == 1
    assert get_tree_node(mapping, 'baz:0') == mapping['baz'][0]
    assert get_tree_node(mapping, 'baz:3', default=None) is None

# Generated at 2022-06-12 08:27:52.575796
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': 'bar'}
    assert get_tree_node(mapping, 'foo') == 'bar'
    mapping = {'foo': {'bar': 'baz'}}
    assert get_tree_node(mapping, 'foo:bar') == 'baz'



# Generated at 2022-06-12 08:27:58.869196
# Unit test for function get_tree_node
def test_get_tree_node():
    """Tests for function get_tree_node"""
    assert get_tree_node({'a': {'b': 1}}, 'a:b') == 1
    assert get_tree_node({'a': {'b': {'c': 2}}}, 'a:b') == {'c': 2}
    assert get_tree_node({'a': {'b': {'c': 2}}}, 'a:b:c') == 2
    assert get_tree_node({}, 'a:b')



# Generated at 2022-06-12 08:28:09.295223
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {
        'a': {'b': {'c': 'd'}},
        'c': {},
        'e': 'f'
    }
    assert get_tree_node(a, 'a:b:c') == 'd'
    assert get_tree_node(a, 'a:b') == {'c': 'd'}
    assert get_tree_node(a, 'a:b:c:d') is _sentinel
    assert get_tree_node(a, 'a:b:c:d', default='d') == 'd'
    assert get_tree_node(a, 'c:d') == {}
    assert get_tree_node(a, 'c:d:b') is _sentinel
    assert get_tree_node(a, 'c:d', default='b')

# Generated at 2022-06-12 08:28:13.778598
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'quux'
            }
        }
    }
    assert get_tree_node(tree, 'foo:bar:baz') == 'quux'
    assert get_tree_node(tree, 'foo:bar') == {'baz': 'quux'}



# Generated at 2022-06-12 08:28:23.147572
# Unit test for function set_tree_node
def test_set_tree_node():
    testTree = Tree()
    set_tree_node(testTree, 'a:b:c', 'foo')
    assert testTree['a']['b']['c'] == 'foo'
    set_tree_node(testTree, 'a:b:d', 'bar')
    assert testTree['a']['b']['d'] == 'bar'
    testTree['a']['b']['zab'] = 'zab'
    assert testTree['a']['b']['zab'] == 'zab'
    testTree['x:y:z'] = 'quux'
    assert testTree['x:y:z'] == 'quux'
    assert testTree['x']['y']['z'] == 'quux'

# Generated at 2022-06-12 08:28:29.198447
# Unit test for function set_tree_node
def test_set_tree_node():
    foo = tree()
    set_tree_node(foo, 'foo:bar:baz', 'baz')
    assert foo['foo']['bar']['baz'] == 'baz'
    # Test namespace
    foo['namespace:bar']['baz'] = 'baz'
    assert foo['namespace']['bar']['baz'] == 'baz'



# Generated at 2022-06-12 08:28:38.939700
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'a': {
            'b': {
                'c': '123',
                'd': '456'
            },
            'e': '789'
        },
        'r': '999'
    }

    assert get_tree_node(data, 'a:b:c') == '123'
    assert get_tree_node(data, 'a:b:d') == '456'
    assert get_tree_node(data, 'a:e') == '789'
    assert get_tree_node(data, 'r') == '999'

    try:
        get_tree_node(data, 'a:b:f')
    except KeyError:
        pass
    else:
        raise AssertionError('Should raise')


# Generated at 2022-06-12 08:28:45.913156
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup test
    tree = {
        "one": {
            'A': 'foo',
            'B': 'bar',
            'C': 'zoo'
        }
    }

    # Test
    assert get_tree_node(tree, "one:A") == 'foo'
    assert get_tree_node(tree, "one:B") == 'bar'
    assert get_tree_node(tree, "one") == {'A': 'foo', 'B': 'bar', 'C': 'zoo'}
    with pytest.raises(KeyError):
        get_tree_node(tree, "one:Z")
    assert get_tree_node(tree, "one:Z", default='nope') == 'nope'
    assert get_tree_node(tree, "one:B", parent=True)

# Generated at 2022-06-12 08:28:53.940009
# Unit test for function get_tree_node
def test_get_tree_node():
    from .assertions import assert_equal

    test1 = {'foo': {'bar': 'baz'}}
    assert_equal(get_tree_node(test1, 'foo'), {'bar': 'baz'})
    assert_equal(get_tree_node(test1, 'foo:bar'), 'baz')
    try:
        get_tree_node(test1, 'nope')
    except KeyError:
        pass

    test2 = {'foo': {'bar': 'baz'}}
    assert_equal(get_tree_node(test2, 'foo'), {'bar': 'baz'})
    assert_equal(get_tree_node(test2, 'foo:bar'), 'baz')

# Generated at 2022-06-12 08:29:02.871243
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'foobar': 'foo'
            },
            'baz': 'bar'
        }
    }
    assert get_tree_node(mapping, 'foo:bar:foobar') == 'foo'
    assert get_tree_node(mapping, 'foo:baz') == 'bar'
    assert get_tree_node(mapping, 'foo:baz', parent=True) == {
        'bar': {
            'foobar': 'foo'
        },
        'baz': 'bar'
    }
    with pytest.raises(KeyError):
        assert get_tree_node(mapping, 'foo:qux')

