

# Generated at 2022-06-12 08:20:07.900656
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {'a': {'b': {'c': 3}}}
    assert get_tree_node(a, 'a:b:c') == 3
    assert get_tree_node(a, 'a:b') == {'c': 3}
    assert get_tree_node(a, 'a:b:c:d') == _sentinel
    assert get_tree_node(a, 'a:b:c:d', default='d') == 'd'
    assert get_tree_node(a, 'a:b:c:d:e', default='e') == 'e'



# Generated at 2022-06-12 08:20:13.245756
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({':admin:foo:bar:baz': 'huehuehue'}, ':foo:bar:baz') == 'huehuehue'
    assert get_tree_node({':admin:foo:bar:baz': 'huehuehue'}, ':foo:bar:baz') == 'huehuehue'

# Generated at 2022-06-12 08:20:18.810007
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 42,
            'baz': 'string',
        },
        'qux': True,
    }

    assert get_tree_node(mapping, 'foo:bar') == mapping['foo']['bar']
    assert get_tree_node(mapping, 'foo:baz') == mapping['foo']['baz']
    assert get_tree_node(mapping, 'qux') == mapping['qux']



# Generated at 2022-06-12 08:20:30.124278
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {'test': {'test2': {'test3': 'test4'}}}
    assert get_tree_node(test_dict, 'test:test2:test3') == 'test4'
    assert get_tree_node(test_dict, 'test:test2:test3:test9', default='fail') == 'fail'
    assert get_tree_node(test_dict, 'test:test2:test3:test9', default='fail', parent=True) == {'test3': 'test4'}
    assert get_tree_node(test_dict, 'test:test2', default='fail', parent=True) == test_dict
    assert get_tree_node(test_dict, 'test:test2', default='fail') == {'test3': 'test4'}
    assert get_tree

# Generated at 2022-06-12 08:20:38.400545
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'test'
            },
        },
    }
    set_tree_node(mapping, 'cats', 'dogs')
    assert mapping['cats'] == 'dogs'

    set_tree_node(mapping, 'foo:bar:baz', 'test2')
    assert mapping['foo']['bar']['baz'] == 'test2'

    set_tree_node(mapping, 'foo:cats', 'dogs')
    assert mapping['foo']['cats'] == 'dogs'

    set_tree_node(mapping, 'foo:bar:cats', 'dogs')
    assert mapping['foo']['bar']['cats'] == 'dogs'



# Generated at 2022-06-12 08:20:39.550276
# Unit test for function get_tree_node
def test_get_tree_node():
    pass

# Generated at 2022-06-12 08:20:48.024553
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for get_tree_node"""
    mapping = {
        'foo': {
            'bar': True,
        },
        'baz': 1
    }
    assert not get_tree_node(mapping, 'baz:corge', default=False)
    assert not get_tree_node(mapping, 'foo:corge', default=False)
    assert get_tree_node(mapping, 'foo:bar', default=False)
    assert get_tree_node(mapping, 'baz', default=False)
    assert get_tree_node(mapping, 'baz') == 1

    try:
        get_tree_node(mapping, 'baz:corge')
        assert False, "Should have raised KeyError"
    except KeyError:
        pass


# Generated at 2022-06-12 08:20:55.909742
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'hello world'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'hello world'
    assert get_tree_node(mapping, 'foo:bar:baz', default='foobar') == 'hello world'
    assert get_tree_node(mapping, 'foo:bar:baz:foobar', default='foobar') == 'foobar'
    assert get_tree_node(mapping, 'foo', parent=True) == {'bar': {'baz': 'hello world'}}



# Generated at 2022-06-12 08:20:59.057855
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, key='a:b:c', value=12)
    assert mapping['a']['b']['c'] == 12



# Generated at 2022-06-12 08:21:03.808349
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'key', 'value')
    set_tree_node(t, 'key:key2', 'value2')
    assert t['key']['key2'] == 'value2'
    set_tree_node(t, 'key:key2:key3', 'value3')
    assert t['key']['key2']['key3'] == 'value3'



# Generated at 2022-06-12 08:21:15.407419
# Unit test for function get_tree_node
def test_get_tree_node():
    # Usage
    assert get_tree_node({'foo': 'bar'}, 'foo', default='xxx') == 'bar'
    assert get_tree_node({'foo': {'bar': 'x'}}, 'foo', default='xxx') == {'bar': 'x'}
    assert get_tree_node({'foo': {'bar': 'x'}}, 'foo:bar', default='xxx') == 'x'

    # Usage with parent=True
    assert get_tree_node({'foo': {'bar': 'x'}}, 'foo:bar', default='xxx', parent=True) == {'bar': 'x'}

    # Handle exceptions

# Generated at 2022-06-12 08:21:17.937827
# Unit test for function get_tree_node
def test_get_tree_node():
    assert (get_tree_node({
        'a': {
            'b': 'c'
        }
    }, 'a:b') == 'c')



# Generated at 2022-06-12 08:21:25.963269
# Unit test for function get_tree_node
def test_get_tree_node():
    # Tree structure
    tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    # Test single key
    assert get_tree_node(tree, 'a') == {'b': {'c': 'd'}}
    assert get_tree_node(tree, 'a:b') == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c') == 'd'

    # Test single key with default
    assert get_tree_node(tree, 'a:b:NONE') is None
    assert get_tree_node(tree, 'a:b:NONE', default=None) is None

    # Test single key with default _sentinel

# Generated at 2022-06-12 08:21:29.603317
# Unit test for function set_tree_node
def test_set_tree_node():
    dummy_tree = tree()
    set_tree_node(dummy_tree, 'nugget', 'foo')
    set_tree_node(dummy_tree, 'foo:bar', 'baz')
    assert dummy_tree['foo']['bar'] == 'baz'



# Generated at 2022-06-12 08:21:40.110130
# Unit test for function set_tree_node
def test_set_tree_node():
    import json
    initial_data = {
        "a": {
            "b": {
                "c": "c",
                "d": "d",
                "e": "e",
            },
            "f": {
                "g": "g",
            },
        },
    }

    test_data = {
        "a:b:c": "c",
        "a:b:d": "d",
        "a:b:e": "e",
        "a:f:g": "g",
    }

    test_subject = tree()
    test_subject.update(initial_data)

    for k, v in test_data.items():
        set_tree_node(test_subject, k, v)

# Generated at 2022-06-12 08:21:51.416902
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping_schema = {
        'a': {
            'b': {
                'c': {
                    'd': 1
                },
                'e': 2
            },
            'f': 3
        }
    }
    assert get_tree_node(mapping_schema, 'a:b:c:d') == 1
    assert get_tree_node(mapping_schema, 'a:b:e') == 2
    assert get_tree_node(mapping_schema, 'a:f') == 3
    assert get_tree_node(mapping_schema, 'a:g') is _sentinel
    assert get_tree_node(mapping_schema, 'a:g', default=None) is None

# Generated at 2022-06-12 08:21:59.697581
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    assert set_tree_node(d, 'foo:bar', 'ALALALA') == {'foo': {'bar': 'ALALALA'}}
    assert set_tree_node(d, 'foo:bar:baz', 'BLABLABLA') == {'foo': {'bar': {'baz': 'BLABLABLA'}}}
    assert set_tree_node(d, 'foo:bar', 'FIIISH') == {'foo': {'bar': 'FIIISH'}}



# Generated at 2022-06-12 08:22:08.425730
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    set_tree_node(a, 'a:b:c:d', 1)
    assert (a['a']['b']['c']['d'] == 1)
    set_tree_node(a, 'a:b:c:d:e:f:g:h', 2)
    assert (a['a']['b']['c']['d']['e']['f']['g']['h'] == 2)
    set_tree_node(a, 'a:k:l:m', 3)
    assert (a['a']['k']['l']['m'] == 3)
    set_tree_node(a, 'a:z', 4)
    assert (a['a']['z'] == 4)

# Generated at 2022-06-12 08:22:16.472749
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
            'baz': 'bar'
        },
        'bar': {
            'foo': 'baz',
            'baz': 'foo'
        }
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'bar:baz') == 'foo'
    assert get_tree_node(mapping, 'foo:bar:bar:baz') is _sentinel



# Generated at 2022-06-12 08:22:24.277002
# Unit test for function get_tree_node
def test_get_tree_node():
    from functools import partial

    simple_list = [1, 2, 3]
    simple_dict = {'a': 4, 'b': 5, 'c': 6}
    simple_tree = {'a': {'b': 'c'}, 'x': simple_list, 'y': simple_dict}

    # Simple tests
    assert 1 == get_tree_node(simple_list, 2, parent=True)
    assert 2 == get_tree_node(simple_list, 2)
    assert 'c' == get_tree_node(simple_tree, 'a:b')
    assert [] == get_tree_node(simple_tree, 'a:b:c')
    assert simple_tree['x'][0] == get_tree_node(simple_tree, 'x:0')
    assert simple_dict == get_tree

# Generated at 2022-06-12 08:22:36.496354
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(dict)
    set_tree_node(tree, 'cheese:burger:fries', 1)
    set_tree_node(tree, 'cheese:burger:soda', 1)
    set_tree_node(tree, 'cheese:burger:taco', 1)
    set_tree_node(tree, 'cheese:burger:pizza', 1)
    set_tree_node(tree, 'cheese:burger:fries:onion', 1)
    set_tree_node(tree, 'cheese:burger:fries:tomato', 1)

# Generated at 2022-06-12 08:22:38.668582
# Unit test for function set_tree_node
def test_set_tree_node():
    test = {}
    set_tree_node(test, 'a.b.c', 1)
    assert test['a']['b']['c'] == 1



# Generated at 2022-06-12 08:22:42.775704
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(tree, 'foo:bar:baz') == 'qux'


# Generated at 2022-06-12 08:22:51.712660
# Unit test for function get_tree_node
def test_get_tree_node():
    node = {
        'test': {
            'test1': {
                'test2': 'Foo'
            },
            'test3': 'Bar'
        }
    }

    assert(get_tree_node(node, 'test:test1:test2') == 'Foo')
    assert(get_tree_node(node, 'test:test3') == 'Bar')
    assert(get_tree_node(node, 'test:test2', default=None) is None)
    assert(get_tree_node(node, 'test:test1:test4', default=None) is None)
    with pytest.raises(KeyError):
        get_tree_node(node, 'test:test4')



# Generated at 2022-06-12 08:22:54.825766
# Unit test for function set_tree_node
def test_set_tree_node():
    d = dict()
    assert set_tree_node(d, 'one:two:three', 'Hello world') == {'one': {'two': {'three': 'Hello world'}}}



# Generated at 2022-06-12 08:23:00.753355
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': 'baz'
        }
    }
    assert get_tree_node(tree, 'foo:bar', default=_sentinel) == 'baz'
    assert get_tree_node(tree, 'foo:bar:baz', default='FU') == 'FU'



# Generated at 2022-06-12 08:23:02.788864
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'key', 'value')
    assert tree == {'key': 'value'}

    set_tree_node(tree, 'key2:key3', 'value3')
    assert tree == {'key': 'value', 'key2': {'key3': 'value3'}}



# Generated at 2022-06-12 08:23:13.089495
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': ['d', 'e'],
                'f': 'g',
            },
            'h': 'i',
        },
        'j': 'k',
    }

    assert get_tree_node(mapping, 'a:b:c:0', default='test') == 'd'
    try:
        get_tree_node(mapping, 'a:b:c:1', default='test')
        assert False
    except KeyError:
        assert True

    assert get_tree_node(mapping, 'a:b:c:1') == 'e'
    try:
        get_tree_node(mapping, 'a:b:c:9')
        assert False
    except KeyError:
        assert True

    assert get

# Generated at 2022-06-12 08:23:15.123270
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 123, 'baz': 456}}, 'foo:bar') == 123



# Generated at 2022-06-12 08:23:20.848357
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': {'d': {'e': 'f'}}}}}
    assert get_tree_node(mapping, 'a:b:c:d:e') == 'f'
    assert get_tree_node(mapping, 'a:b:c:d:e:asfdsaf') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d:e:asfdsaf', default=False) is False



# Generated at 2022-06-12 08:23:29.515226
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {'a': {'b': 1, 'c': 2}, 'b': {'c': 1, 'b': 2}}
    assert get_tree_node(m, 'a') == {'b': 1, 'c': 2}
    assert get_tree_node(m, 'a:c') == 2
    with pytest.raises(KeyError):
        get_tree_node(m, 'a:d')



# Generated at 2022-06-12 08:23:36.747280
# Unit test for function set_tree_node
def test_set_tree_node():
    m = {}
    set_tree_node(m, 'foo:bar:baz:qux', 'quuux')

    try:
        set_tree_node(m, 'foo:bar:baz:wibble', 'wobble')
    except KeyError as exc:
        assert False, "Caught KeyError on foo:bar:baz:wibble when foo:bar:baz is already there"

    assert m['foo']['bar']['baz']['qux'] == 'quuux'



# Generated at 2022-06-12 08:23:45.494493
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    # Create test dictionary
    test_mapping = {'root': {'middle': {'bottom': 'BOTTOM_VALUE', 'middle': {'bottom': 'BOTTOM_VALUE'}}}}

    test_mapping # Test complete

    # Test leaf
    assert get_tree_node(test_mapping, 'root:middle:bottom') == 'BOTTOM_VALUE'

    # Test node
    assert get_tree_node(test_mapping, 'root:middle') == test_mapping['root']['middle']

    # Test parent
    assert get_tree_node(test_mapping, 'root:middle', parent=True) == test_mapping['root']

    # Test error
    with pytest.raises(KeyError):
        get_tree_node

# Generated at 2022-06-12 08:23:52.714343
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function `get_tree_node`

    Returns:
        None
    """
    test_data = {
        'a': {
            'b': 'c',
            'd': {
                'e': {
                    'f': 'g'
                },
                'h': 'i',
                'j': {
                    'k': {
                        'l': 'm'
                    },
                    'n': 'o'
                }
            },
            'p': {
                'q': 'r'
            },
            's': 't'
        }
    }

    # Get leaf node
    assert get_tree_node(test_data, 'a:b') == 'c'
    assert get_tree_node(test_data, 'a:d:e:f') == 'g'
   

# Generated at 2022-06-12 08:24:02.897247
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'one': 1, 'two': {'three': 3}}
    assert get_tree_node(mapping, 'one') == 1
    assert get_tree_node(mapping, 'two:three') == 3
    get_tree_node(mapping, 'two:three', default='foo') == 3
    assert get_tree_node(mapping, 'two:three', parent=True) == {'three': 3}
    get_tree_node(mapping, 'two:three', default='foo', parent=True) == {'three': 3}
    try:
        get_tree_node(mapping, 'two:four') == 4
    except KeyError as exc:
        pass
    else:
        raise RuntimeError('Didn\'t raise KeyError.')

# Generated at 2022-06-12 08:24:13.638233
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test :func:`get_tree_node`
    """
    mapping = {'a': {'b': {'c': {'d': 2}}}}
    assert get_tree_node(mapping, 'a:b:c:d') == 2
    assert get_tree_node(mapping, 'a:b:c:f', default='eh') == 'eh'
    assert get_tree_node(mapping, 'a:b:c:f:e')
    assert get_tree_node(mapping, 'a:b:c:f', parent=True) == {'d': 2}
    assert get_tree_node(mapping, 'a:b:c:f', parent=True, default='eh') == 'eh'

    # It should be possible to get a tree node from a tree node
   

# Generated at 2022-06-12 08:24:23.139031
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Just a test function.
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'c_value')
    set_tree_node(test_dict, 'a:b:d', 'd_value')
    set_tree_node(test_dict, 'a:e:f', 'f_value')

    assert test_dict == {
        'a': {
            'b': {
                'c': 'c_value',
                'd': 'd_value',
            },
            'e': {
                'f': 'f_value',
            },
        },
    }



# Generated at 2022-06-12 08:24:27.914888
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Tree node getter works as expected.
    """
    for case, result in (
            ({'a': 'b'}, 'b'),
            ({'a': {'b': 'c'}}, 'c'),
            ({'a': {'b': 'c'}}, 'd', _sentinel),
            ({'a': {'b': 'c'}}, 'a', _sentinel),
    ):
        assert get_tree_node(case, 'a', default=_sentinel) is result
        assert get_tree_node(case, 'b', default=_sentinel) is _sentinel


# Generated at 2022-06-12 08:24:37.699132
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'qux',
                'quux': {
                    'corge': 'grault'
                }
            }
        }
    }
    # Basic screen
    assert get_tree_node(tree, 'foo') == tree['foo'], 'simple tree access fails.'
    # Simple dimension
    assert get_tree_node(tree, 'foo:bar') == tree['foo']['bar'], 'simple dimension access fails.'
    # Basic dimension
    assert get_tree_node(tree, 'foo:bar:baz') == 'qux', 'basic dimension access fails.'
    # Falsey dimension
    assert get_tree_node(tree, 'foo:bar:quux:corge') == 'grault', 'falsey dimension access fails.'



# Generated at 2022-06-12 08:24:43.339145
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'foo', 1)
    assert t['foo'] == 1
    set_tree_node(t, 'bar:baz', 2)
    assert t['bar:baz'] == 2
    set_tree_node(t, 'bar:quux', 3)
    assert t['bar:quux'] == 3



# Generated at 2022-06-12 08:24:53.258354
# Unit test for function set_tree_node
def test_set_tree_node():
    reg = RegistryTree()
    reg.register('a:b:c', 'd')
    assert reg['a']['b']['c'] == 'd'
    assert reg['a:b:c'] == 'd'



# Generated at 2022-06-12 08:24:55.858940
# Unit test for function set_tree_node
def test_set_tree_node():
    m = {}
    set_tree_node(m, 'the:fox:jumped', 'over')
    assert m['the']['fox']['jumped'] == 'over'



# Generated at 2022-06-12 08:24:59.752868
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for get_tree_node.
    """
    mapping = {'foo': {'bar': 'baz'}}
    value = get_tree_node(mapping, 'foo:bar')
    assert value == 'baz'



# Generated at 2022-06-12 08:25:06.673500
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'one': {
            'two': {
                'three': 'FOUR'
            }
        }
    }

    node = get_tree_node(mapping, key='one:two:three')
    assert node == 'FOUR'

    node = get_tree_node(mapping, key='one:two')
    assert node == {'three': 'FOUR'}

    node = get_tree_node(mapping, key='one:two:three', parent=True)
    assert node == {'three': 'FOUR'}

    node = get_tree_node(mapping, key='one:two:this:has:to:fail', default='The force is with you')
    assert node == 'The force is with you'


# Generated at 2022-06-12 08:25:14.043566
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> nested_dict = {'a': {'b': 'c'}}
    >>> assert get_tree_node(nested_dict, 'a:b') == 'c'
    >>> assert get_tree_node(nested_dict, 'a:b', parent=True) == {'b': 'c'}
    >>> try:
    ...     get_tree_node(nested_dict, 'a:b:c')
    ... except KeyError:
    ...     pass
    """



# Generated at 2022-06-12 08:25:24.627560
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {
            'b': 'c',
            'd': {
                'e': 'f',
                'g': {
                    'h': 'i',
                    'j': {
                        'k': 'l',
                    },
                },
            },
        }
    }
    # Base:
    assert get_tree_node(d, 'a') == d['a']
    assert get_tree_node(d, 'a:b') == d['a']['b']
    assert get_tree_node(d, 'a:d:g:j:k') == d['a']['d']['g']['j']['k']

    # Make sure we return default
    assert get_tree_node(d, 'doesnotexist', default=None) is None

   

# Generated at 2022-06-12 08:25:30.839412
# Unit test for function get_tree_node
def test_get_tree_node():
    x = {'k1': {'x': {'k1': 'y'}},
         'k2': 'xyz',
         'k3': {'k4': ['abc', 'def', 'ghi']}}
    assert get_tree_node(x, 'k1:x') == {'k1': 'y'}
    assert get_tree_node(x, 'k2') == 'xyz'
    assert get_tree_node(x, 'k3:k4:2') == 'ghi'
    assert get_tree_node(x, 'k1:x:k1') == 'y'
    assert get_tree_node(x, 'k3:k4:5', default='abc') == 'abc'

# Generated at 2022-06-12 08:25:37.682928
# Unit test for function get_tree_node
def test_get_tree_node():
    from pprint import pprint
    l = {'aa': {'bb': {'cc': 'dd'},
                'ee': 'ff'},
         'bb': {'cc': {'dd': 'ee'}}}

    pprint(l)

# Generated at 2022-06-12 08:25:46.952631
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}

    set_tree_node(tree, 'test', 'value')
    assert tree == {'test': 'value'}

    set_tree_node(tree, 'test:test', 'value')
    assert tree == {'test': {'test': 'value'}}

    set_tree_node(tree, 'test:test:test:test:test:test:test:test:test', 'value')

# Generated at 2022-06-12 08:25:57.771236
# Unit test for function get_tree_node
def test_get_tree_node():
    class Test(object):
        tree = dict(one=1, two=dict(three=3), four=dict(five=dict(six=6)))

    assert get_tree_node(Test.tree, 'one') == 1
    assert get_tree_node(Test.tree, 'two') == Test.tree['two']
    assert get_tree_node(Test.tree, 'four') == Test.tree['four']
    assert get_tree_node(Test.tree, 'two:three') == 3
    assert get_tree_node(Test.tree, 'four:five') == Test.tree['four']['five']
    assert get_tree_node(Test.tree, 'four:five:six') == 6

# Generated at 2022-06-12 08:26:22.569307
# Unit test for function get_tree_node
def test_get_tree_node():
    # Initialize test dictionary
    _dict = {
        'foo': 'foo value',
        'bar': {
            'baz': 'baz value'
        }
    }

    # Test top level
    assert get_tree_node(_dict, 'foo') == 'foo value'

    # Test nested
    assert get_tree_node(_dict, 'bar:baz') == 'baz value'

    # Test nested single dimension
    assert get_tree_node(_dict, 'bar')['baz'] == 'baz value'

    # Test KeyError
    with pytest.raises(KeyError) as exc:
        get_tree_node(_dict, 'bar:baz:bing')
    exc.match('baz:bing')

    # Test default fallback

# Generated at 2022-06-12 08:26:32.390807
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for `get_tree_node`
    """
    original = tree()
    original['a'] = '1'
    original['b'] = tree()
    original['b']['c'] = '2'
    original['b']['d'] = '3'

    assert get_tree_node(original, 'a') == '1'
    assert get_tree_node(original, 'b:c') == '2'
    assert get_tree_node(original, 'b:d') == '3'
    assert get_tree_node(original, 'b') == {'c': '2', 'd': '3'}
    assert get_tree_node(original, ['b', 'c']) == '2'

# Generated at 2022-06-12 08:26:36.242906
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, "foo:bar:basename", "Value!")
    assert mapping['foo']['bar']['basename'] == "Value!"



# Generated at 2022-06-12 08:26:44.043374
# Unit test for function get_tree_node

# Generated at 2022-06-12 08:26:53.318614
# Unit test for function get_tree_node
def test_get_tree_node():
    assert_equal(
        get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c'),
        'd',
    )
    assert_equal(
        get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='bla'),
        'd',
    )
    assert_equal(
        get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:d', default='bla'),
        'bla',
    )
    assert_raises(KeyError, lambda: get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:d'))



# Generated at 2022-06-12 08:27:04.120661
# Unit test for function get_tree_node
def test_get_tree_node():

    # Setup
    mytree = RegistryTree()

    mytree.register('test:a:a', 'A')
    mytree.register('test:a:b:b', 'B')
    mytree.register('test:a:b:c', 'C')

    # Assertion
    assert mytree['test:a:a'] == 'A'
    assert mytree['test:a:b:b'] == 'B'
    assert mytree['test:a:b:c'] == 'C'

    assert mytree.get('test:a:a') == 'A'
    assert mytree.get('test:a:b:b') == 'B'
    assert mytree.get('test:a:b:c') == 'C'

    # Test for KeyError

# Generated at 2022-06-12 08:27:11.667698
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {'a': {'b': {'c': 'foo'}}}
    assert get_tree_node(data, 'a') == {'b': {'c': 'foo'}}
    assert get_tree_node(data, 'a:b') == {'c': 'foo'}
    assert get_tree_node(data, 'a:b:c') == 'foo'
    assert get_tree_node(data, 'a:b:c:d:e:f') is None
    assert get_tree_node(data, 'a:b:c:d:e:f', default='bar') == 'bar'



# Generated at 2022-06-12 08:27:19.105718
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, "a", 1)
    assert d == {"a": 1}
    set_tree_node(d, "b:c", 2)
    assert d == {"a": 1, "b": {"c": 2}}
    set_tree_node(d, "b:c:d", 3)
    assert d == {"a": 1, "b": {"c": {"d": 3}}}
    set_tree_node(d, "b:c:d:e", 4)
    assert d == {"a": 1, "b": {"c": {"d": {"e": 4}}}}



# Generated at 2022-06-12 08:27:23.157585
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {'b': {'c': 'd'}},
        'e': {'f': {'g': 'h'}},
    }

    assert get_tree_node(tree, 'a:b:c') == 'd'
    with pytest.raises(KeyError):
        get_tree_node(tree, 'e:b:c')

# Generated at 2022-06-12 08:27:33.732554
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'lorem': {
            'ipsum': {
                'dolor': 'sit'
            }
        }
    }

    assert get_tree_node(d, 'lorem:ipsum:dolor') == 'sit'
    assert get_tree_node(d, 'lorem:ipsum') == {'dolor': 'sit'}
    assert get_tree_node(d, 'lorem') == {'ipsum': {'dolor': 'sit'}}

    assert get_tree_node(d, 'lorem:ipsum:dolor', default=False) == 'sit'
    assert get_tree_node(d, 'lorem:ipsum', default=None) == {'dolor': 'sit'}

# Generated at 2022-06-12 08:28:34.855538
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}

    # Basic assignmant
    set_tree_node(tree, 'foo', 'bar')
    assert tree['foo'] == 'bar'

    # Two separate levels
    set_tree_node(tree, 'foo:bar', 'spam')
    assert tree['foo'] == {'bar': 'spam'}

    # Three separate levels, testing return value
    ret = set_tree_node(tree, 'foo:bar:spam', 'eggs')
    assert tree['foo'] == {'bar': {'spam': 'eggs'}}

    # Four separate levels, testing return value
    ret = set_tree_node(tree, 'foo:bar:spam:eggs', 'bacon')

# Generated at 2022-06-12 08:28:42.353331
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = tree()
    expected = 'baz'

    test_tree['foo']['bar'] = 'baz'
    test_tree['foo']['baz']['bar'] = 'foo'
    assert expected == get_tree_node(test_tree, 'foo:bar')
    assert expected == get_tree_node(test_tree, 'foo:bar:')
    assert expected == get_tree_node(test_tree, 'foo:bar::')
    assert expected == get_tree_node(test_tree, 'foo:bar:::')
    assert test_tree['foo']['baz'] == get_tree_node(test_tree, 'foo:baz')



# Generated at 2022-06-12 08:28:52.161019
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': 'bar',
        'baz': {
            'fiz': 'buz',
            'fin': {
                'fan': 'ban',
            },
        },
    }
    assert get_tree_node(mapping, 'foo') == 'bar'
    assert get_tree_node(mapping, 'baz:fiz') == 'buz'
    assert get_tree_node(mapping, 'baz:fin:fan') == 'ban'
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'not:a:valid:key')
    assert get_tree_node(mapping, 'not:a:valid:key', default='def') == 'def'



# Generated at 2022-06-12 08:29:02.299992
# Unit test for function get_tree_node
def test_get_tree_node():
    # Creating a tree from a nested dict
    tree_data = {'a': {'b': {'c': {'d': 1}}}}
    assert get_tree_node(tree_data, 'a:b:c:d') == 1
    assert get_tree_node(tree_data, 'a:b:c') == {'d': 1}
    assert get_tree_node(tree_data, 'a:b') == {'c': {'d': 1}}
    assert get_tree_node(tree_data, 'a') == {'b': {'c': {'d': 1}}}

    # Creating a tree from a flat dict
    tree_data = {
        'a:b:c:d': 1,
        'a:b:c:e': 2
    }

# Generated at 2022-06-12 08:29:06.550063
# Unit test for function get_tree_node
def test_get_tree_node():
    node = {
        'foo': {
            'bar': 'baz',
            'qux': 'quux',
        }
    }
    assert get_tree_node(node, 'foo:bar') == 'baz'
    assert get_tree_node(node, 'foo:baz') is _sentinel



# Generated at 2022-06-12 08:29:15.644646
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        "v1": "a",
        "v2": {
            "v2.1": "b"
        },
        "v3": {
            "v3.1": "c",
            "v3.2": {
                "v3.2.1": "d"
            },
            "v3.3": {
                "v3.3.1": "e",
                "v3.3.2": "f"
            }
        }
    }

    assert get_tree_node(d, "v1") == "a"
    assert get_tree_node(d, "v2:v2.1") == "b"
    assert get_tree_node(d, "v3:v3.2:v3.2.1") == "d"
    assert get

# Generated at 2022-06-12 08:29:23.627341
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'foo': {
            'bar': {
                'baz': 'quux'
            }
        }
    }
    assert get_tree_node(test_data, 'foo:bar') == {'baz': 'quux'}
    assert get_tree_node(test_data, 'foo:bar:baz') == 'quux'
    assert get_tree_node(test_data, 'foo:bar:quux') is _sentinel
    assert get_tree_node(test_data, 'foo:bar:quux', default='notfound') == 'notfound'

# Generated at 2022-06-12 08:29:32.178820
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup test data
    data = tree()
    data['a'] = 1
    data['b'] = tree()
    data['b']['a'] = 3
    data['b']['c'] = 4
    data['c'] = 5
    data['d'] = tree()
    data['d']['a'] = 7
    data['d']['b'] = 8
    data['d']['c'] = 9

    # Setup tests

# Generated at 2022-06-12 08:29:40.592785
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        1: {
            'one': {
                1: 'One',
                True: 'True',
                False: 'False',
            },
            'two': {
                True: 'True',
                False: 'False',
                1: 'One',
                2: 'Two',
                'hey': {
                    'you': 'You',
                }
            },
            'three': True,
        },
        2: {
            'one': False,
            'two': True,
            'three': False,
        },
    }

    assert get_tree_node(mapping, '1:one:1') == 'One'
    assert get_tree_node(mapping, '2:one:True:1', parent=True) == (2, 'one')



# Generated at 2022-06-12 08:29:50.185582
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node function."""
    mapping = {
        'key1': 1,
        'key2': {
            'key3': 2,
            'key4': {
                'key5': 3,
            },
        },
    }

    # This is supposed to work
    assert get_tree_node(mapping, 'key1') == 1
    assert get_tree_node(mapping, 'key2:key3') == 2
    assert get_tree_node(mapping, 'key2:key4:key5') == 3

    # This is supposed to fail
    with pytest.raises(AttributeError):
        get_tree_node(mapping, 'key2:key3:key4:key5')

