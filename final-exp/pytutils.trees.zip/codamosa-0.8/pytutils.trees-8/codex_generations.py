

# Generated at 2022-06-12 08:20:08.326072
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'foo', 'bar') == {'foo': 'bar'}
    assert set_tree_node({}, 'foo:bar', 'baz') == {'foo': {'bar': 'baz'}}
    assert set_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', 'qux') == {'foo': {'bar': 'qux'}}



# Generated at 2022-06-12 08:20:12.208841
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 3
            }
        }
    }

    result = get_tree_node(tree, 'a:b:c')

    assert result == 3



# Generated at 2022-06-12 08:20:18.683817
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    mapping = {
        'c': {
            'e': {'f': 3},
            'd': 5,
        },
        'b': 2,
        'a': {
            'a1': 1,
            'a2': {
                'a2b': 'b',
            },
        },
    }
    assert get_tree_node(mapping, 'a') == mapping['a']
    assert get_tree_node(mapping, 'a:a1') == 1
    assert get_tree_node(mapping, 'a:a2') == {'a2b': 'b'}
    assert get_tree_node(mapping, 'a:a2:a2b') == 'b'

# Generated at 2022-06-12 08:20:30.000974
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': 1,
        'b': {
            'c': 2,
        },
        'd': {
            'e': 3,
        },
    }

    # Test basic access
    assert get_tree_node(mapping, 'a') == 1

    # Test nested access
    assert get_tree_node(mapping, 'b:c') == 2

    # Test non-nested access
    assert get_tree_node(mapping, 'a:b') is _sentinel

    # Test default values
    assert get_tree_node(mapping, 'a:b', default=10) == 10

    assert get_tree_node(mapping, 'a:b', default=10) == 10
    assert get_tree_node(mapping, 'a:b', default=10) == 10

# Generated at 2022-06-12 08:20:35.324944
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz'
            }
        }
    }

    assert get_tree_node(data, 'foo:bar') == {
        'baz': 'foobarbaz'
    }

    assert get_tree_node(data, 'foo:bar:baz') == 'foobarbaz'



# Generated at 2022-06-12 08:20:39.184295
# Unit test for function set_tree_node
def test_set_tree_node():
    m = collections.defaultdict(dict)
    set_tree_node(m, 'joe:bob', 'steve')

# Generated at 2022-06-12 08:20:46.307291
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 'c'}}, 'a') == {'b': 'c'}
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'
    with pytest.raises(KeyError):
        get_tree_node({'a': {'b': 'c'}}, 'a:d')

    assert get_tree_node({'a': {'b': 'c'}}, 'a:b:c', default=None) == None



# Generated at 2022-06-12 08:20:55.804722
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test :func:get_tree_node.
    """
    from nose.tools import assert_equals, assert_raises, assert_true
    tree = {
        'a': {
            'b': {
                'c': 'Hello, world!',
                'd': 'foo',
            },
            'e': 'bar',
        }
    }
    assert_equals(get_tree_node(tree, 'a:b:c'), 'Hello, world!')
    assert_equals(get_tree_node(tree, 'a:b:d'), 'foo')
    assert_equals(get_tree_node(tree, 'a:e'), 'bar')
    assert_raises(KeyError, get_tree_node, tree, 'a:b:f')

# Generated at 2022-06-12 08:21:04.518120
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'n1': {'n2': {'n3': {'n4': 'foo'}}}}
    assert get_tree_node(d, 'n1:n2:n3') == {'n4': 'foo'}
    assert get_tree_node(d, 'n1:n2:n3', default='nope') == {'n4': 'foo'}
    assert get_tree_node(d, 'n1:n2:n3:n4') == 'foo'
    assert get_tree_node(d, 'n1:n2:n3', default='nope') == {'n4': 'foo'}
    assert get_tree_node(d, 'n1:n2', default='nope') == {'n3': {'n4': 'foo'}}
   

# Generated at 2022-06-12 08:21:14.867395
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'0': {'1': {'2': 3, '3': 'four'}}}
    assert get_tree_node(mapping, '0:1:2') == 3
    assert get_tree_node(mapping, '0:1:3') == 'four'
    assert get_tree_node(mapping, '0:1:4', default='five') == 'five'
    with pytest.raises(KeyError):
        get_tree_node(mapping, '0:1:42')
    assert get_tree_node(mapping, '0:1:42', parent=True) == {'2': 3, '3': 'four'}
    assert get_tree_node(mapping, '0:1:2:3') == _sentinel



# Generated at 2022-06-12 08:21:26.486860
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node"""
    d = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    t = Tree(d)

    assert get_tree_node(t, 'nope') == _sentinel
    assert get_tree_node(t, 'nope', default=None) == None
    assert get_tree_node(t, 'a:b:c') == 'd'
    assert get_tree_node(t, 'a:b:c', parent=True) == {'c': 'd'}

    with pytest.raises(KeyError):
        get_tree_node(t, 'a:b:wrong')



# Generated at 2022-06-12 08:21:33.778716
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'hello')
    assert set_tree_node(mapping, 'foo:bar:baz', 'hello') == 'hello'
    assert set_tree_node(mapping, 'foo:bar:bar', 'goodbye') == 'goodbye'
    assert set_tree_node(mapping, 'foo:bar:bar') == 'goodbye'
    assert set_tree_node(mapping, 'foo:bar:baz') == 'hello'



# Generated at 2022-06-12 08:21:39.618487
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    test_tree = Tree()
    test_tree.register('foo:bar:baz', 1)
    result = set_tree_node(test_tree, 'foo:bar:baz', 2)
    expected = {
        'foo': {
            'bar': {
                'baz': 2
            }
        }
    }
    assert result == expected



# Generated at 2022-06-12 08:21:50.628736
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    test_data = {
        'a': {
            'b': {
                'c': 'c',
            },
        },
    }
    assert get_tree_node(test_data, 'a:b:c') == 'c'
    assert get_tree_node(test_data, 'a:b:c:d') == _sentinel
    assert get_tree_node(test_data, 'a:b:c:d', default='_default_') == '_default_'
    assert get_tree_node(test_data, 'a:b') == {'c': 'c'}
    assert get_tree_node(test_data, 'a:b:c:d', parent=True) == {'c': 'c'}

# Generated at 2022-06-12 08:21:55.368500
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = tree()
    test_key = 'alpha:beta:gamma'
    test_value = 'delta'
    set_tree_node(test_dict, test_key, test_value)
    assert test_dict['alpha']['beta']['gamma'] == test_value



# Generated at 2022-06-12 08:22:05.405795
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'registry': {
            'core:foo123': {
                'bar123': 'baz123'
            }
        }
    }
    assert get_tree_node(mapping, 'registry') == mapping['registry']
    assert get_tree_node(mapping, 'registry:core:foo123') == mapping['registry']['core']['foo123']
    assert get_tree_node(mapping, 'registry:core:foo123:bar123') == mapping['registry']['core']['foo123']['bar123']
    assert get_tree_node(mapping, 'registry:core:foo123', default='qux123') == 'qux123'

# Generated at 2022-06-12 08:22:14.551347
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 0, 'd': 1}}}, 'a:d') == 1
    assert get_tree_node({'a': {'b': {'c': 0, 'd': 1}}}, 'a:b:c') == 0
    assert get_tree_node({'a': {'b': {'c': 0, 'd': 1}}}, 'a:b:e', default=2) == 2
    assert get_tree_node({'a': {'b': {'c': 0, 'd': 1}}}, 'a:b:e') == _sentinel



# Generated at 2022-06-12 08:22:21.767088
# Unit test for function get_tree_node
def test_get_tree_node():
    t = Tree({
        'a': {
            'b': {
                'c': 'd',
                'e': {
                    'f': 'g',
                },
            },
        },
    })

    assert t.get('a:b:c') == 'd'
    assert t.get('a:b:e:f') == 'g'
    assert t.get('h:i:j', default='k') == 'k'
    assert t.get('a:b:c:d:e:f:g:h', default='i') == 'i'



# Generated at 2022-06-12 08:22:26.198494
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.defaultdict(dict)
    set_tree_node(mapping, 'a:b:c:d', 'e')
    assert mapping['a']['b']['c'] == {'d': 'e'}



# Generated at 2022-06-12 08:22:33.385599
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    mapping = {'one': 1, 'two': {'three': 3, 'four': {'five': 5}}}
    assert get_tree_node(mapping, 'one') == 1
    assert get_tree_node(mapping, 'two:three') == 3
    assert get_tree_node(mapping, 'two:four:five') == 5
    assert get_tree_node(mapping, 'two:five', default=1) == 1



# Generated at 2022-06-12 08:22:48.929405
# Unit test for function get_tree_node
def test_get_tree_node():
    import pytest
    test_data = {
        'foo': {
            'bar': 1,
            'baz': {
                'buz': 2
            }
        }
    }

    assert get_tree_node(test_data, 'foo', _sentinel) == test_data['foo']
    assert get_tree_node(test_data, 'foo:bar') == test_data['foo']['bar']
    assert get_tree_node(test_data, 'foo:baz:buz') == test_data['foo']['baz']['buz']

    with pytest.raises(KeyError):
        get_tree_node(test_data, 'nonexistent:value:hohoho')


# Generated at 2022-06-12 08:22:58.362224
# Unit test for function get_tree_node
def test_get_tree_node():
    # Create a tree mapping
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            },
            'f': 'g'
        }
    }

    assert get_tree_node(mapping, 'a:b:c:d') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d:notexist', default='e') == 'e'

    try:
        get_tree_node(mapping, 'a:b:c:d:notexist')
    except KeyError:
        pass
    else:
        raise AssertionError

    assert get_tree_node(mapping, 'a:f') == 'g'

# Generated at 2022-06-12 08:23:04.453387
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': 'c'}}
    assert get_tree_node(mapping, 'a:b') == 'c'
    assert get_tree_node(mapping, 'a:b:c', default='d') == 'd'
    assert get_tree_node(mapping, 'x:y:z', default=_sentinel) == _sentinel



# Generated at 2022-06-12 08:23:12.774208
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_mapping = {
        'foo': {
            'bar': 'BAR',
            'baz': {
                'bat': 'BAT',
            },
        },
        'egg': 'EGG',
    }

    assert get_tree_node(tree_mapping, 'egg') == 'EGG'
    assert get_tree_node(tree_mapping, 'foo:bar') == 'BAR'
    assert get_tree_node(tree_mapping, 'foo:baz:bat') == 'BAT'

    try:
        get_tree_node(tree_mapping, 'abc:xyz')
        raise AssertionError('Failed to raise KeyError when given invalid path')
    except KeyError:
        pass


# Generated at 2022-06-12 08:23:20.062716
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Expected behaviour:

        >>> test_get_tree_node()
        (None, False)
        >>> test_get_tree_node(False)
        (None, False)
        >>> test_get_tree_node('FALSE')
        (None, False)
        >>> test_get_tree_node(True)
        (None, False)
        >>> test_get_tree_node('TRUE')
        (None, False)

    """

# Generated at 2022-06-12 08:23:29.587763
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()

    assert get_tree_node(mapping, 'a') == mapping['a']
    assert get_tree_node(mapping, 'a:b') == mapping['a']['b']
    assert get_tree_node(mapping, 'a:b:c') == mapping['a']['b']['c']
    assert get_tree_node(mapping, 'a:b:c', default=None) == None
    assert get_tree_node(mapping, 'a:b:c', default=None, parent=True) == mapping['a']['b']
    set_tree_node(mapping, 'a:b:c', 'foo')
    assert get_tree_node(mapping, 'a:b:c') == 'foo'



# Generated at 2022-06-12 08:23:40.671444
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'a') == _sentinel
    assert get_tree_node({'a': 'A'}, 'a') == 'A'
    assert get_tree_node({'a': {'b': 'B', 'c': 'C'}}, 'a:b') == 'B'
    # Default values
    assert get_tree_node({'a': {'b': 'B', 'c': 'C'}}, 'a:b:c', default=-1) == -1
    # Parent node
    assert get_tree_node({'a': {'b': 'B', 'c': 'C'}}, 'a:b:c', parent=True)['c'] == 'C'
    # Special values for separate testing, if using regular values can't test for _sentinel
    assert get_tree_node

# Generated at 2022-06-12 08:23:48.106036
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {
        'foo': 'bar',
        'var': {
            'foo': 'bar',
            'baz': {
                'foo': 'bar',
            }
        },
    }

    for k, v in [
        ('foo', 'bar'),
        ('var:foo', 'bar'),
        ('var:baz:foo', 'bar'),
    ]:
        assert get_tree_node(t, k) == v



# Generated at 2022-06-12 08:23:59.039029
# Unit test for function set_tree_node
def test_set_tree_node():
    x = tree()
    set_tree_node(x, 'x:y:z', 'something')
    assert x['x']['y']['z'] == 'something'
    set_tree_node(x, 'x:y:z:w', 'else')
    assert x['x']['y']['z']['w'] == 'else'
    set_tree_node(x, 'x:y:q:r:s', 'stuff')
    assert x['x']['y']['q']['r']['s'] == 'stuff'
    set_tree_node(x, 'a:b:c', 'blub')
    assert x['a']['b']['c'] == 'blub'

# Generated at 2022-06-12 08:24:04.293692
# Unit test for function set_tree_node
def test_set_tree_node():
    data = tree()

    set_tree_node(data, 'a:b', 5)
    set_tree_node(data, 'a:c', 6)
    set_tree_node(data, 'a:d:e:f:g:h:i', 7)

    assert data['a']['b'] == 5
    assert data['a']['c'] == 6
    assert data['a']['d']['e']['f']['g']['h']['i'] == 7



# Generated at 2022-06-12 08:24:13.876960
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'pets:cat', 'Irene')
    set_tree_node(tree, 'pets:dog', 'Spooky')
    assert tree['pets']['cat'] == 'Irene'
    assert tree['pets']['dog'] == 'Spooky'



# Generated at 2022-06-12 08:24:22.955059
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': 'b',
        'c': {
            'd': 'e',
        },
        'f': {
            'g': 'h',
            'i': {
                'j': 'k',
            }
        }
    }
    assert get_tree_node(mapping, 'a') == 'b'
    assert get_tree_node(mapping, 'c:d') == 'e'
    assert get_tree_node(mapping, 'f:g') == 'h'
    assert get_tree_node(mapping, 'f:i:j') == 'k'



# Generated at 2022-06-12 08:24:27.168280
# Unit test for function set_tree_node
def test_set_tree_node():
    test = {}
    set_tree_node(test, 'test', 'value')
    assert test['test'] == 'value'

    test = {}
    set_tree_node(test, 'test:test', 'value')
    assert test['test']['test'] == 'value'



# Generated at 2022-06-12 08:24:33.887818
# Unit test for function get_tree_node
def test_get_tree_node():
    # Should get the value of the node regardless of parent's type
    assert get_tree_node({'test': [0, 1, 2]}, 'test:1') == 1
    assert get_tree_node(tree(), 'test:0') == {}
    assert get_tree_node({'test': tree()}, 'test:0') == {}
    assert get_tree_node(tree(), 'test:0:0:0:0:0:0:0:0:0') == {}
    # Should return the default value
    assert get_tree_node(tree(), 'test:0', default=0) == 0
    assert get_tree_node({}, 'test:0', default=0) == 0
    # Should raise a KeyError if no default value is specified
    with pytest.raises(KeyError):
        get_tree_node

# Generated at 2022-06-12 08:24:39.032428
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {'foo': {'bar': {'baz': [{'sku': 'sku_001'}]}}}
    baz_node = get_tree_node(test_mapping, 'foo:bar:baz')
    assert id(test_mapping['foo']['bar']['baz']) == id(baz_node)



# Generated at 2022-06-12 08:24:41.940755
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['label']['foo'] = 'bar'

    assert(get_tree_node(t, 'label:foo') == 'bar')


# Generated at 2022-06-12 08:24:45.276381
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b', 'c')
    assert t == {'a': {'b': 'c'}}



# Generated at 2022-06-12 08:24:53.421751
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        "a": {
            "b": {
                "c": "d",
            },
        },
    }

    # Complete key works
    assert get_tree_node(mapping, 'a:b:c') == 'd'

    # Partial key works
    assert get_tree_node(mapping, 'a:b') == {'c': 'd'}

    # Fallback works
    assert get_tree_node(mapping, 'a:b:non-existent', default='fallback') == 'fallback'
    assert get_tree_node(mapping, 'a:b:non-existent', default='fallback') == 'fallback'

    # Fallback does not work if default is _sentinel

# Generated at 2022-06-12 08:24:59.809737
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'one:two:three', 'four') == {'one': {'two': {'three': 'four'}}}
    assert set_tree_node({}, 'one:two:three', 'four', parent=True) == {'one': {'two': {}}}
    assert set_tree_node({}, 'one:two', 'four', parent=True) == {'one': {}}
    assert set_tree_node({}, 'one', 'four', parent=True) == {}



# Generated at 2022-06-12 08:25:04.390198
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a':{'b':123}}, 'a:b') == 123
    assert get_tree_node({'a':{'b':123}}, 'a:b:c:d', default='foo') == 'foo'
    try:
        assert get_tree_node({'a':{'b':123}}, 'a:b:c:d')
    except KeyError:
        pass



# Generated at 2022-06-12 08:25:18.131258
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': 'baz'}}
    assert get_tree_node(mapping, 'foo:bar', default='default') == 'baz'
    assert get_tree_node(mapping, 'foo:baz', default='default') == 'default'

# Generated at 2022-06-12 08:25:22.982495
# Unit test for function set_tree_node
def test_set_tree_node():

    # Test case none
    # Expectation none

    # Test case namespace
    # Expectation namespace

    # Test case namespace:key
    # Expectation namespace.key

    mapping = tree()
    set_tree_node(mapping, 'ns:key:key:key:key:key', 'val')

# Generated at 2022-06-12 08:25:29.934450
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c':'d'}}}

    assert get_tree_node(mapping, 'a') == {'b': {'c':'d'}}
    assert get_tree_node(mapping, 'a:b') == {'c':'d'}
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c':'d'}
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'

    try:
        get_tree_node(mapping, 'a:b:c:d')
    except KeyError:
        assert True
    else:
        assert False

# Generated at 2022-06-12 08:25:37.521924
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    # Normal fetch
    assert get_tree_node(t, 'a:b:c') == 'd'
    # Fetch using alternate parent node
    assert get_tree_node(t, 'a:b:c', parent=True)['c'] == 'd'
    # Fetch with default
    assert get_tree_node(t, 'a:b:e', default='notfound') == 'notfound'
    # Fetch non-existent key, use default
    assert get_tree_node(t, 'a:b:e', default='notfound') == 'notfound'
    # Fetch non-existent key, raise KeyError

# Generated at 2022-06-12 08:25:45.815814
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {'foo': {'bar': 0}}
    set_tree_node(data, 'foo:baz', 'baz')
    set_tree_node(data, 'foo:baz:biz', 'biz')
    assert data['foo']['baz'] == {'biz': 'biz'}
    assert data['foo']['baz']['biz'] == 'biz'
    set_tree_node(data, 'foo:baz:biz', 1)
    assert data['foo']['baz']['biz'] == 1
    set_tree_node(data, 'foo:baz', 3)
    assert data['foo']['baz'] == 3



# Generated at 2022-06-12 08:25:48.149088
# Unit test for function set_tree_node
def test_set_tree_node():
    f = tree()
    f['pew'] = 'pew'
    assert f['pew'] == 'pew'


# Generated at 2022-06-12 08:25:51.890143
# Unit test for function set_tree_node
def test_set_tree_node():
    root = {}
    ns = 'dummy'
    set_tree_node(root, '%s:test' % ns, 3)
    assert root[ns]['test'] == 3



# Generated at 2022-06-12 08:25:54.578824
# Unit test for function set_tree_node
def test_set_tree_node():
    _dict = {}
    set_tree_node(_dict, 'hello:world', 42)
    assert _dict['hello']['world'] == 42



# Generated at 2022-06-12 08:26:03.359770
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equals, assert_raises
    from nose.plugins.attrib import attr

    # Tree is just a dict
    tree = {
        'a': {
            'b': {
                'c': 1,
                'd': 2,
            },
            'e': {
                'f': 3,
                'g': {
                    'h': 4,
                    'i': 5,
                }
            }
        }
    }

    # No default, we get the node
    assert_equals(get_tree_node(tree, 'a:b:d'), 2)

    # No default, but it's not there, we raise a KeyError as expected
    assert_raises(KeyError, get_tree_node, tree, 'a:b:z')

    # Default has been set

# Generated at 2022-06-12 08:26:13.998519
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    d1 = set_tree_node(d, 'a:b:c', 'd')
    assert d == {'a': {'b': {'c': 'd'}}}
    d2 = set_tree_node(d, 'a:b:c', 'd')
    assert d1 is d2
    d3 = set_tree_node(d, 'a:b', 'd')
    assert d3 is d1['a']['b']
    d0 = set_tree_node(d, 'a:b:c:d:e:f:g:h', 'i')
    assert d0 == {'c': {'d': {'e': {'f': {'g': {'h': 'i'}}}}}}, d0



# Generated at 2022-06-12 08:26:28.280599
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'one:two', 1)
    set_tree_node(tree, 'one:three', 2)
    set_tree_node(tree, 'one:four:extra:nested', 3)

# Generated at 2022-06-12 08:26:35.493631
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['a'] = 'value'
    mapping['b']['c'] = 'value2'
    mapping['d']['e']['f'] = 'value3'
    mapping['b']['g'] = 'value4'
    mapping['b']['h']['i'] = 'value5'

    assert get_tree_node(mapping, 'a') == 'value'
    assert get_tree_node(mapping, 'b:c') == 'value2'
    assert get_tree_node(mapping, 'd:e:f') == 'value3'
    assert get_tree_node(mapping, 'b:g') == 'value4'
    assert get_tree_node(mapping, 'b:h:i') == 'value5'


# Generated at 2022-06-12 08:26:40.745992
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = Tree({
        'foo': 'bar',
        'baz': {
            'quux': 'quuz',
        },
    })
    assert get_tree_node(tree, 'foo') == 'bar'
    assert get_tree_node(tree, 'baz:quux') == 'quuz'



# Generated at 2022-06-12 08:26:51.720367
# Unit test for function get_tree_node
def test_get_tree_node():
    treenode = tree()
    treenode['one']['two']['three'] = 4

    treenode2 = tree()
    treenode2['one']['two']['three'] = 4


# Generated at 2022-06-12 08:26:54.687000
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'c:b:a', 'lol')
    assert tree == {'c': {'b': {'a': 'lol'}}}



# Generated at 2022-06-12 08:27:03.372699
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    testdict = {'a': {'b': 10, 'c': 11}}

    # Run
    res = get_tree_node(testdict, 'a')

    # Verify
    assert res == {'b': 10, 'c': 11}
    assert get_tree_node(testdict, 'a:b') == 10
    assert get_tree_node(testdict, 'a:c') == 11

    # Now with default
    res = get_tree_node(testdict, 'a:d', default='foobar')

    # Verify
    assert res == 'foobar'

# Generated at 2022-06-12 08:27:11.182036
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:baz') == None
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:baz', parent=True) == {'bar': 'baz'}
    assert get_tree_node({'foo': {'bar': {'baz': 'qux'}}}, 'foo:bar:baz') == 'qux'

# Generated at 2022-06-12 08:27:16.639840
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'foo', 'bar') == {'foo': 'bar'}
    assert set_tree_node({}, 'foo:bar', 'baz') == {'foo': {'baz': 'bar'}}
    assert set_tree_node({}, 'foo:bar:baz', 'quux') == {'foo': {'bar': {'baz': 'quux'}}}



# Generated at 2022-06-12 08:27:23.487484
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    in_tree = {
        'root': {
            'dimension1': {
                'dimension2': {
                    'dimension3': 'value'
                }
            }
        }
    }

    # Normal behavior
    get_tree_node(in_tree, 'root:dimension1:dimension2') == {'dimension3': 'value'}
    get_tree_node(in_tree, 'root') == {'dimension1': {'dimension2': {'dimension3': 'value'}}}
    get_tree_node(in_tree, 'root:dimension1:dimension2:dimension3') == 'value'

    # Behavior if the key is not in the tree

# Generated at 2022-06-12 08:27:26.553291
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'one:two:three', 3)
    assert mapping == {'one': {'two': {'three': 3}}}



# Generated at 2022-06-12 08:27:54.831713
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'list': [
            'foo',
            'bar',
            {
                'baz': 'baz'
            }
        ],
        'dict': {
            'foo': 'foo',
            'bar': 'bar',
            'baz': {
                'baz': 'baz'
            }
        }
    }
    expected_mappings = {
        'list:0': 'foo',
        'list:1': 'bar',
        'list:2:baz': 'baz',
        'dict:foo': 'foo',
        'dict:bar': 'bar',
        'dict:baz:baz': 'baz',
    }
    for key, exp_node in expected_mappings.items():
        node = get_tree_node(mapping, key)


# Generated at 2022-06-12 08:27:57.221655
# Unit test for function set_tree_node
def test_set_tree_node():
    foo = {}
    set_tree_node(foo, 'a:b:c', 1)
    assert foo['a']['b']['c'] == 1



# Generated at 2022-06-12 08:28:06.879356
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz'
        }
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz', 'tree_node exists and is accessible'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'bar': 'baz'}, 'parent node can be returned'
    assert get_tree_node(mapping, 'baz:bar:baz') == _sentinel, 'default value is returned if not found'



# Generated at 2022-06-12 08:28:16.002961
# Unit test for function set_tree_node
def test_set_tree_node():
    complex_dict = {
        'top': {
            'second': {
                'third': 'value'
            }
        }
    }
    set_tree_node(complex_dict, 'top:second:third', 'other_value')
    assert complex_dict['top']['second']['third'] == 'other_value'

    complex_dict = {
        'top1': {
            'second': {
                'third': 'value'
            }
        },
        'top2': {
            'second': {
                'third': 'value'
            }
        }
    }
    set_tree_node(complex_dict, 'top2:second:third', 'other_value')
    assert complex_dict['top2']['second']['third'] == 'other_value'
    assert complex

# Generated at 2022-06-12 08:28:23.458807
# Unit test for function set_tree_node
def test_set_tree_node():

    m = {'food': {'for':'asdfasdf'}}
    set_tree_node(m, 'food:for', 'work')
    assert m == {'food': {'for': 'work'}}

    m = {'food': {'for':'asdfasdf'}}
    set_tree_node(m, 'food:for:cat', 'cat')
    assert m == {'food': {'for': {'cat': 'cat'}}}

    m = tree()
    set_tree_node(m, 'food:for:cat', 'cat')
    assert m == {'food': {'for': {'cat': 'cat'}}}

    m = tree()
    set_tree_node(m, 'food:for:cat', 'cat')

# Generated at 2022-06-12 08:28:33.868196
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'FOOO',
            }
        }
    }

    # Check for normal->parent->parent
    assert get_tree_node(mapping, 'a:b:c', parent=False) == 'FOOO'
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'FOOO'}
    assert get_tree_node(mapping, 'a:b:c', parent=2) == mapping['a']

    # Check for normal->parent->parent too high
    with pytest.raises(KeyError):
        assert get_tree_node(mapping, 'a:b:c', parent=3)

    # Check for normal->parent not in

# Generated at 2022-06-12 08:28:42.353139
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for get_tree_node

    """
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a') == {'b': {'c': 'd'}}
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b') == {'c': 'd'}
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', parent=True) == {'c': 'd'}

# Generated at 2022-06-12 08:28:51.116227
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    test_get_tree_node tests function get_tree_node.
    """
    # Test for basic tree with default value
    test_dict = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(test_dict, 'a:b:c', default=5) == 'd'
    # Test for basic tree without default value
    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    # Test for basic tree with wrong key
    assert get_tree_node(test_dict, 'a:b:d', default=5) == 5



# Generated at 2022-06-12 08:28:54.715494
# Unit test for function set_tree_node
def test_set_tree_node():
    a = []
    set_tree_node(a, 'a:b:c', 'test')
    assert a == [{'a': {'b': {'c': 'test'}}}]



# Generated at 2022-06-12 08:29:04.505838
# Unit test for function get_tree_node
def test_get_tree_node():
    valid_structure = tree()
    valid_structure['a'][1] = 2
    valid_structure['a'][3] = 4
    valid_structure['b'][1] = 2
    valid_structure['b'][3] = 4
    assert get_tree_node(valid_structure, 'a:1') == 2
    assert get_tree_node(valid_structure, 'a:3') == 4
    assert get_tree_node(valid_structure, 'b:1') == 2
    assert get_tree_node(valid_structure, 'b:3') == 4
    assert get_tree_node(valid_structure, 'a') == {1: 2, 3: 4}

# Generated at 2022-06-12 08:30:03.610496
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test with actual mapping
    mapping = {'a': {'b': {'c': {'d': {'e': 'f'}}}}}
    assert get_tree_node(mapping, 'a:b:c:d:e') == 'f'

    # Test with custom parent
    assert get_tree_node(mapping, 'a:b:c:d:e', parent=True) == {'e': 'f'}

    # Test with custom default
    assert get_tree_node(mapping, 'a:b:x:y:z', default='h') == 'h'

    # Test with raise
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:x:y:z')

