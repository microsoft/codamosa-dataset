

# Generated at 2022-06-12 08:20:09.853121
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test `modules.utils.set_tree_node` and `modules.utils.get_tree_node`
    """
    t = tree()
    set_tree_node(t, 'foo:bar:baz', value=1)
    assert get_tree_node(t, 'foo:bar:baz') == 1, 'Basic nested dict traversal'

    set_tree_node(t, 'foo:bar:bar', value=2)
    assert get_tree_node(t, 'foo:bar:bar') == 2, 'Support multiple keys with same second-highest dimension'

    set_tree_node(t, 'foo:bar', value=3)
    assert get_tree_node(t, 'foo:bar') == 3, 'If a single-dimensional key is passed, set that'

    set_tree_node

# Generated at 2022-06-12 08:20:17.573332
# Unit test for function set_tree_node
def test_set_tree_node():
    mydict = {}
    set_tree_node(mydict, 'a:b:c:d:e:f:g:h:i:j', 'foo')
    assert mydict['a']['b']['c']['d']['e']['f']['g']['h']['i']['j'] == 'foo'

    mydict = collections.defaultdict(lambda: {})
    set_tree_node(mydict, 'a:b:c:d:e:f:g:h:i:j', 'foo')
    assert mydict['a']['b']['c']['d']['e']['f']['g']['h']['i']['j'] == 'foo'

# Generated at 2022-06-12 08:20:25.902530
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': 2}}}
    assert get_tree_node(mapping, 'a:b:c') == 2
    assert get_tree_node(mapping, 'a:b', parent=True) == {'b': {'c': 2}}
    mapping = Tree({'a': {'b': {'c': 2}}})
    assert mapping.get('a:b:c') == 2
    assert mapping.get('a:b', parent=True) == {'b': {'c': 2}}



# Generated at 2022-06-12 08:20:35.878574
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'test': {'test': {'test': 'a'}}}, 'test:test:test') == 'a'
    assert get_tree_node({'test': {'test': {'test': 'a'}}}, 'test:test:test', default='b') == 'a'
    assert get_tree_node({'test': {'test': {'test': 'a'}}}, 'test:test:test:test', default='b') == 'b'
    assert get_tree_node({'test': {'test': {'test': 'a'}}}, 'test:test:test:test') == 'a'

# Generated at 2022-06-12 08:20:43.676023
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node.
    """
    mapping = {
        'test': {
            'foo': 'bar'
        }
    }
    assert get_tree_node(mapping, 'test:foo') == 'bar'
    assert get_tree_node(mapping, 'test:foo:baz') is _sentinel
    assert get_tree_node(mapping, 'test:foo:baz', parent=True) == {'foo': 'bar'}

# Generated at 2022-06-12 08:20:48.526777
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {'a': {'a1': 1, 'a2': 2}, 'b': 3}
    assert get_tree_node(m, 'a:a1') == 1
    assert get_tree_node(m, 'a:a2') == 2
    assert get_tree_node(m, 'b') == 3



# Generated at 2022-06-12 08:20:56.532174
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function
    """
    test = {
        'one': 1,
        'two': {
            'three': 3,
            'four': {
                'five': 5,
            }
        }
    }
    assert get_tree_node(test, 'one') == 1
    assert get_tree_node(test, 'two:three') == 3
    assert get_tree_node(test, 'two:four:five') == 5
    assert get_tree_node(test, 'two:four:six') is _sentinel
    assert get_tree_node(test, 'two:four:six', default='default') == 'default'



# Generated at 2022-06-12 08:21:04.323188
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': {
                    'one': 1,
                    'two': 1,
                    'three': 1,
                },
            },
        },
    }

    assert get_tree_node(tree, 'foo:bar:baz', default=False) is not False
    assert get_tree_node(tree, 'foo:bar:baz:two') == 1
    assert get_tree_node(tree, 'foo:bar:baz:two', parent=True) == {'one': 1, 'two': 1, 'three': 1}


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-12 08:21:08.393905
# Unit test for function set_tree_node
def test_set_tree_node():
    """Set tree node in mapping."""
    m = {}
    set_tree_node(m, 'foo:bar:baz', 'Baz')
    assert m['foo']['bar']['baz'] == 'Baz'



# Generated at 2022-06-12 08:21:12.730167
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': {
            'bar': 5,
        }
    }

    assert get_tree_node(data, 'foo:bar') == 5

    data['foo']['bar']['baz'] = 7
    assert get_tree_node(data, 'foo:bar:baz') == 7



# Generated at 2022-06-12 08:21:24.615971
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'foo': {'bar': {'baz': {'bing': 'bong'}}}}
    assert 'bong' == get_tree_node(tree, 'foo:bar:baz:bing')
    assert 'bong' == get_tree_node(tree, 'foo:bar:baz:bing', parent=True)['bing']
    assert 'bong' == get_tree_node(tree, 'foo:bar:baz:bing', default='bong')
    assert tree['foo']['bar']['baz'] == get_tree_node(tree, 'foo:bar:baz:bing', default='bong', parent=True)
    with pytest.raises(KeyError):
        get_tree_node(tree, 'foo:bar:baz:nope')

# Generated at 2022-06-12 08:21:34.108713
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    mapping = {
        'a': {
            'a': {
                'a': 'aa',
                'b': {
                    'a': 'aba',
                    'b': 'abb',
                },
            },
            'b': 'ba',
            'c': {
                'a': 'caa',
                'b': 'cab',
            },
        },
        'b': {
            'a': 'ba',
            'b': 'bb',
        },
        'c': 'c',
    }

    assert get_tree_node(mapping, 'a:a') == {'a': 'aa', 'b': {'a': 'aba', 'b': 'abb'}}

# Generated at 2022-06-12 08:21:43.307559
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equal, assert_raises, assert_dict_equal
    test_data = {
        'foo': {
            'bar': 'value',
            'baz': {
                'one': 'two'
            }
        }
    }

    def assert_equal_g(expected, *args, **kwargs):
        assert_equal(expected, get_tree_node(test_data, *args, **kwargs))

    def g(*args, **kwargs):
        return get_tree_node(test_data, *args, **kwargs)

    assert_equal_g('value', 'foo:bar')
    assert_equal_g('two', 'foo:baz:one')
    assert_raises(KeyError, g, 'foo:baz:one:three')
    assert_equal

# Generated at 2022-06-12 08:21:53.585782
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    function get_tree_node

    >>> nested_dict = {'names': {'first_name': 'John', 'last_name': 'Doe'}, 'job': 'Python developper'}
    >>> get_tree_node(nested_dict, 'names:first_name')
    'John'
    >>> get_tree_node(nested_dict, 'job')
    'Python developper'
    >>> get_tree_node(nested_dict, 'names:surname') # doctest: +ELLIPSIS
    Traceback (most recent call last):
    ...
    KeyError: 'surname'
    >>> get_tree_node(nested_dict, 'names:surname', default='Surname')
    'Surname'
    """



# Generated at 2022-06-12 08:22:04.773059
# Unit test for function get_tree_node
def test_get_tree_node():
    my_dict = {
        'a': {
            'b': {
                'c': {
                    'd': 1
                }
            },
            'c': {
                'd': 2
            }
        },
        'b': {
            'c': {
                'd': 3
            }
        }
    }

    assert 5 == get_tree_node(my_dict, "a:b:c:e", default=5)
    assert 1 == get_tree_node(my_dict, "a:b:c:d")
    assert 1 == get_tree_node(my_dict, "a:b:c:d", default=None)
    assert 3 == get_tree_node(my_dict, "b:c:d")

# Generated at 2022-06-12 08:22:08.783028
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function `set_tree_node`
    """
    d = {}
    set_tree_node(d, 'a:b:c', 'd')
    assert d['a']['b']['c'] == 'd'



# Generated at 2022-06-12 08:22:16.984094
# Unit test for function get_tree_node
def test_get_tree_node():

    assert get_tree_node({}, 'nope') == {}, 'Should return {}'
    assert get_tree_node({'test': 'success'}, 'test', default='blargh') == 'success', 'Should return "success"'
    assert get_tree_node({'test': 'success'}, 'test_fail', default='blargh') == 'blargh', 'Should return "blargh"'
    with pytest.raises(KeyError):
        get_tree_node({'test': 'success'}, 'test_fail', default=_sentinel)

# Generated at 2022-06-12 08:22:20.606909
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'foo': {'bar': 'baz'}}

    assert get_tree_node(tree, 'foo:bar') == 'baz'
    assert get_tree_node(tree, 'notfoo:bar') is _sentinel



# Generated at 2022-06-12 08:22:25.616699
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'a': {'b': 2}}
    assert get_tree_node(tree, 'a:b') == 2
    assert get_tree_node(tree, 'a') == {'b': 2}



# Generated at 2022-06-12 08:22:33.341583
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': 'baz'
        }
    }

    assert get_tree_node(tree, 'foo:bar') == tree['foo']['bar']
    assert get_tree_node(tree, 'foo:bar:nope') == _sentinel
    assert get_tree_node(tree, 'foo:bar:nope', parent=True) == tree['foo']['bar']
    with pytest.raises(KeyError):
        get_tree_node(tree, 'foo:bar:nope') is _sentinel



# Generated at 2022-06-12 08:22:45.482800
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = collections.defaultdict(tree)
    tree['test']['test2'] = 'this works'
    tree['test']['test3'] = 'this works3'

    assert(get_tree_node(tree, 'test:test2') == 'this works')
    assert(get_tree_node(tree, 'test:test3') == 'this works3')
    assert(get_tree_node(tree, 'test') == tree['test'])
    assert(get_tree_node(tree, 'test:test:test') == tree['test']['test'])
    assert(get_tree_node(tree, 'test4:test4:test4') == _sentinel)



# Generated at 2022-06-12 08:22:53.783918
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
            'qux': {
                'quux': 'quuz',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:qux:quux') == 'quuz'

    try:
        get_tree_node(mapping, 'foo:baz')
        raise AssertionError('should have raised KeyError')
    except KeyError:
        pass

    assert get_tree_node(mapping, 'foo:baz', default='quux') == 'quux'


# Generated at 2022-06-12 08:23:03.422355
# Unit test for function set_tree_node
def test_set_tree_node():
    m = {}
    # Simple one-dimensional set
    set_tree_node(m, 'a', 'A')
    assert m.get('a') == 'A'

    # Simple two-dimensional set
    set_tree_node(m, 'a:b', 'B')
    assert m.get('a', {}).get('b') == 'B'

    # Multi-dimensional set
    set_tree_node(m, 'a:b:c:d', 'C')
    assert m.get('a', {}).get('b', {}).get('c', {}).get('d') == 'C'



# Generated at 2022-06-12 08:23:13.881755
# Unit test for function set_tree_node
def test_set_tree_node():
    test = {
        'a': {
            'b': {
                'c': 'ccc',
                'x': 'xxx',
            },
            'd': 'ddd',
        },
    }
    assert set_tree_node(test, 'a:b:c', 'CCC') == test['a']['b'], (set_tree_node(test, 'a:b', 'CCC'), test['a']['b'])
    assert test['a']['b']['c'] == 'CCC', test['a']['b']['c']
    assert set_tree_node(test, 'a:d', 'DDD') == test['a'], test['a']
    assert test['a']['d'] == 'DDD', test['a']['d']
    assert set_tree

# Generated at 2022-06-12 08:23:20.533465
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {},
        'b': {'x': 'p'},
        'c': {'y': 'q'},
        'd': {'y': {'z': 'r'}},
        'e': {'y': {'z': 's'}},
        'f': {'y': {'z': {'w': 't'}}},
        'g': {'y': {'z': {'w': 'u'}}},
        'h': {'y': {'z': {'w': {'v': 'v'}}}}
    }

    # Check basic functionality.
    assert get_tree_node(d, 'h:y:z:w:v') == 'v'

    # Check default parameter.

# Generated at 2022-06-12 08:23:29.933014
# Unit test for function get_tree_node
def test_get_tree_node():
    test = Tree()
    test.update({'a': {'b': {'c': {'d': 'e'}}}})
    assert get_tree_node(test, 'a:b:c:d') == 'e'
    assert get_tree_node(test, 'a:b:c:d', default={})
    assert get_tree_node(test, 'a:b:c:d', default={}) == 'e'
    assert get_tree_node(test, 'a:b:c:f') is _sentinel
    assert get_tree_node(test, 'a:b:c:f', default='no') == 'no'
    assert get_tree_node(test, 'a:b:c:f', default='no', parent=True)['f'] == 'no'

# Generated at 2022-06-12 08:23:40.975682
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        "a": {"b": "c"},
        "d": {"e": {"f": "g"}},
        "h": {"i": {"j": "k", "l": "m", "n": {"o": "p"}}}
    }

    assert get_tree_node(d, "h:i", default=_sentinel) == {"j": "k", "l": "m", "n": {"o": "p"}}
    assert get_tree_node(d, "h", default=_sentinel) == {"i": {"j": "k", "l": "m", "n": {"o": "p"}}}
    assert get_tree_node(d, "h:i:j") == "k"
    assert get_tree_node(d, "h:i:j:k") is None


# Generated at 2022-06-12 08:23:48.603908
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'foo.bar', 'qux')
    set_tree_node(test_dict, 'baz.quux', 'quuz')
    assert set_tree_node(test_dict, 'baz:quux', 'quuz') == test_dict['baz']
    assert test_dict['foo']['bar'] == 'qux'
    assert test_dict['baz']['quux'] == 'quuz'



# Generated at 2022-06-12 08:23:59.988051
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': 'a',
        'b': {
            'c': {'d': 'e'}
        }
    }
    tree_default = {
        'a': 'a',
        'b': {
            'c': {'d': 'e'}
        }
    }

    def assert_get(key, expected, default=None):
        assert get_tree_node(tree, key, default=default) is expected
        assert get_tree_node(tree_default, key, default=default) is expected

    def assert_raises(key):
        with pytest.raises(KeyError):
            get_tree_node(tree, key)

    assert_get('a', 'a')
    assert_get('b:c:d', 'e')

# Generated at 2022-06-12 08:24:03.864598
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for get_tree_node"""
    assert get_tree_node({'a': {'b': {'c': {'d': 5}}}}, 'a:b:c:d') == 5
    assert get_tree_node({'a': {'b': {'c': {'d': 5}}}}, 'a:b:d:c') == _sentinel



# Generated at 2022-06-12 08:24:17.602204
# Unit test for function get_tree_node
def test_get_tree_node():
    d = tree()
    d['a']['b']['c'] = "baz"

    # Test key with no separator
    r = get_tree_node(d, 'a')
    assert r['b']['c'] == "baz"

    # Test key with separator
    r = get_tree_node(d, 'a:b')
    assert r['c'] == "baz"

    # Test KeyError
    try:
        r = get_tree_node(d, 'a:b:d')
    except KeyError:
        assert True
        return
    assert False


if __name__ == "__main__":
    test_get_tree_node()

# Generated at 2022-06-12 08:24:20.705352
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'



# Generated at 2022-06-12 08:24:27.194648
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Function get_tree_node

    Args:
        mapping collections.Mapping: Mapping to fetch from
        key str|unicode: Key to lookup, allowing for : notation
        default object: Default value. If set to `:module:_sentinel`, raise KeyError if not found.
        parent bool: If True, return parent node. Defaults to False.

    Returns:
        object: Value at specified key

    """
    data = {
        'foo': {
            'bar': "Bam",
            'foo': {
                'bar': "Baz"
            }
        }
    }
    r = get_tree_node(data, 'foo:bar')
    assert r == data['foo']['bar']
    r = get_tree_node(data, 'foo:foo:bar')
    assert r

# Generated at 2022-06-12 08:24:33.888225
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': {
                'g': 'h',
            }
        }
    }

    node = get_tree_node(mapping, 'a')
    assert node == 'b'

    node = get_tree_node(mapping, 'f:g')
    assert node == 'h'

    with pytest.raises(KeyError):
        node = get_tree_node(mapping, 'f:j')

    node = get_tree_node(mapping, 'f:j', default=None)
    assert node is None

    node = get_tree_node(mapping, 'f:g', parent=True)
    assert node == {'g': 'h'}

# Generated at 2022-06-12 08:24:42.617919
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'one': {'two': {'three': 'threshold'}}}
    assert get_tree_node(mapping, 'one:two:three') == 'threshold'
    assert get_tree_node(mapping, 'one') == {'two': {'three': 'threshold'}}
    assert get_tree_node(mapping, 'one:two') == {'three': 'threshold'}
    try:
        get_tree_node(mapping, 'one:two:three:four')
    except KeyError:
        pass
    else:
        assert False, 'Should raise KeyError if key is not found.'



# Generated at 2022-06-12 08:24:50.556881
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function :func:`get_tree_node`.
    """
    mapping = {'foo': {'bar': {'baz': 'qux'}}}
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default=42) == 'qux'
    assert get_tree_node(mapping, 'foo:bar:bax', default=42) == 42
    assert get_tree_node(mapping, 'foo:bar:bax') == KeyError



# Generated at 2022-06-12 08:24:55.419388
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({
        'key': 'value',
    }, 'key') == 'value'
    assert get_tree_node({
        'dict': {
            'key': 'value',
        }
    }, 'dict:key') == 'value'
    assert get_tree_node({
        'key': 'value',
    }, 'wrong_key', default=_sentinel) == _sentinel



# Generated at 2022-06-12 08:25:04.349331
# Unit test for function set_tree_node
def test_set_tree_node():
    document = {}
    value = 'value'

    # Set a root key
    set_tree_node(document, 'key', value)

    assert 'key' in document
    assert document['key'] == value

    # Set a second-level key
    set_tree_node(document, 'key:key', value)

    assert 'key' in document
    assert isinstance(document['key'], dict)
    assert 'key' in document['key']
    assert document['key']['key'] == value

    # Set a third-level key
    set_tree_node(document, 'key:key:key', value)

    assert 'key' in document
    assert isinstance(document['key'], dict)
    assert 'key' in document['key']
    assert isinstance(document['key']['key'], dict)


# Generated at 2022-06-12 08:25:15.299036
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, '', 'nada')
    assert tree == {}

    tree = {}
    set_tree_node(tree, 'foo', 'bar')
    assert tree == {'foo': 'bar'}

    tree = {}
    set_tree_node(tree, 'foo:bar', 'baz')
    assert tree == {'foo': {'bar': 'baz'}}

    tree = {'foo': {'bar': 'baz'}}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree == {
        'foo': {'bar': {'baz': 'qux'}}
    }

    tree = {'foo': 'bar'}

# Generated at 2022-06-12 08:25:25.662845
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test basic set_tree_node
    tree = {}
    key = 'hello:world:this:is:a:test'
    value = 'value'
    set_tree_node(tree, key, value)
    assert tree['hello']['world']['this']['is']['a']['test'] == value

    # Test when key is a list
    tree = {}
    key = ['hello', 'world', 'this', 'is', 'a', 'test']
    value = 'value'
    set_tree_node(tree, key, value)
    assert tree['hello']['world']['this']['is']['a']['test'] == value

    # Test when key is an int
    tree = {}
    key = 5
    value = 'value'
    assert set_tree

# Generated at 2022-06-12 08:25:51.890481
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 40
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 40
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default=50) == 50
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 40}
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', parent=True, default=50) == 50


# Generated at 2022-06-12 08:25:57.690227
# Unit test for function set_tree_node
def test_set_tree_node():
    data = tree()
    set_tree_node(data, 'test:test2:test3', 42)
    assert data['test']['test2']['test3'] == 42

    data = {
        'initialized': True,
    }
    set_tree_node(data, 'test:test2:test3', 42)
    assert data['test']['test2']['test3'] == 42



# Generated at 2022-06-12 08:25:59.662253
# Unit test for function set_tree_node
def test_set_tree_node():
    test = {}
    set_tree_node(test, 'foo', 'bar')
    assert test['foo'] == 'bar'



# Generated at 2022-06-12 08:26:04.737316
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'hello',
            },
            'c': 'world',
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'hello'
    assert get_tree_node(mapping, 'a:c') == 'world'
    assert get_tree_node(mapping, 'a:c', parent=True) == {'b': {'c': 'hello'}, 'c': 'world'}



# Generated at 2022-06-12 08:26:09.200767
# Unit test for function set_tree_node
def test_set_tree_node():
    in_dict = {'a': {'b': 'c'}}
    assert not set_tree_node(in_dict, 'd:e:f', 'g')
    assert in_dict == {'a': {'b': 'c'}, 'd': {'e': {'f': 'g'}}}

# Generated at 2022-06-12 08:26:15.277321
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for :func:`set_tree_node`

    Returns:
        bool: True on success, False otherwise.
    """
    mapping = collections.defaultdict(collections.defaultdict)

    set_tree_node(mapping, 'first:second:third:fourth:fifth', 'chuthulu')
    return mapping['first']['second']['third']['fourth']['fifth'] == 'chuthulu'



# Generated at 2022-06-12 08:26:20.237320
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {'one': 1}
    set_tree_node(test_dict, 'one:two', 2)
    assert test_dict['one']['two'] == 2

    # KeyError test
    try:
        set_tree_node(test_dict, 'one:two:three', 3)
    except KeyError:
        pass
    else:
        assert None


# Generated at 2022-06-12 08:26:25.280123
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    assert set_tree_node(mapping, 'key', 'value') == {}
    assert mapping == {'key': 'value'}
    mapping = {}
    assert set_tree_node(mapping, 'key:key2', 'value') == {'key': {'key2': 'value'}}
    assert mapping == {'key': {'key2': 'value'}}



# Generated at 2022-06-12 08:26:33.932340
# Unit test for function set_tree_node
def test_set_tree_node():
    m = dict(a=1, b=dict(a=1, b=dict(a=1, b=dict(a=1, b=5))))
    set_tree_node(m, 'a', 2)
    assert m == dict(a=2, b=dict(a=1, b=dict(a=1, b=dict(a=1, b=5))))
    set_tree_node(m, 'b:b', 2)
    assert m == dict(a=2, b=dict(a=1, b=dict(a=2, b=dict(a=1, b=5))))
    set_tree_node(m, 'b:b:b', 2)

# Generated at 2022-06-12 08:26:41.342486
# Unit test for function set_tree_node
def test_set_tree_node():
    testdict = {}

    def check(testdict, key, value):
        assert set_tree_node(testdict, key, value) == value
        assert testdict[key] == value

    d = {}
    check(d, 'key', 'value')
    check(d, 'key:subkey', 'value')
    check(d, 'parent:child:grandchild', 'value')
    check(d, 'c1:c2:c3:c4:c5', 'value')



# Generated at 2022-06-12 08:27:13.044404
# Unit test for function get_tree_node
def test_get_tree_node():
    test = {
        'a': {
            'a': {
                'a': 'a',
            },
            'b': {
                'b': 'b',
            },
            'c': {
                'c': 'c',
            },
        },
        'b': {
            'a': {
                'a': 'a',
            },
            'b': {
                'b': 'b',
            },
            'c': {
                'c': 'c',
            },
        },
        'c': {
            'a': {
                'a': 'a',
            },
            'b': {
                'b': 'b',
            },
            'c': {
                'c': 'c',
            },
        },
    }
    # Tree:
    # a
    #

# Generated at 2022-06-12 08:27:19.736529
# Unit test for function set_tree_node
def test_set_tree_node():
    p = tree()
    set_tree_node(p, 'asdf', 'asdf')
    set_tree_node(p, 'asdf:asfd', 'asfd')
    set_tree_node(p, 'asdf:asfd:asfd', 'asfd')
    set_tree_node(p, 'asdf:asfd:asfd:asdf', {'d': 'asdf'})
    assert get_tree_node(p, 'asdf:asfd:asfd:asdf') == {'d': 'asdf'}



# Generated at 2022-06-12 08:27:22.811435
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'foobarbaz'



# Generated at 2022-06-12 08:27:31.398200
# Unit test for function get_tree_node
def test_get_tree_node():

    mapping = {
        'test': 'value',
        'test_dict': {
            'test_dict_test': 'value',
        },
    }

    assert 'value' == get_tree_node(mapping, 'test')
    assert 'value' == get_tree_node(mapping, 'test_dict:test_dict_test')
    assert 'value' == get_tree_node(mapping, 'test_dict:test_dict_test')
    assert _sentinel != get_tree_node(mapping, 'test_dict:test_dict_test2', default=_sentinel)

# Generated at 2022-06-12 08:27:38.826155
# Unit test for function get_tree_node
def test_get_tree_node():
    from sys import modules
    from . import get_tree_node

    container = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(container, 'a:b:c') == 'd'
    assert get_tree_node(container, 'a') == {'b': {'c': 'd'}}
    assert get_tree_node(container, 'a:b') == {'c': 'd'}
    assert get_tree_node(container, 'a:b:c:d') is _sentinel

    try:
        get_tree_node(container, 'a:b:c:d')
        assert False
    except KeyError:
        pass

    # Test that we can traverse through top-level modules

# Generated at 2022-06-12 08:27:50.482229
# Unit test for function get_tree_node
def test_get_tree_node():
    import unittest


# Generated at 2022-06-12 08:27:59.306129
# Unit test for function set_tree_node
def test_set_tree_node():
    from collections import OrderedDict
    m = OrderedDict()
    set_tree_node(m, 'a:b:c:d', 1)
    assert m == {'a': {'b': {'c': {'d': 1}}}}

    # FIXME I can't be arsed to test the get-function
    # get_tree_node(m, 'a:b:c:d:e', default=_sentinel)
    # get_tree_node(m, 'a:b:c:d:e', default=_sentinel, parent=True)
    # get_tree_node(m, 'a:b:c:d:e:f:g', default=_sentinel)

# Generated at 2022-06-12 08:28:09.046229
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'this': {
            'is': {
                'a': {
                    'test': 'yo'
                }
            }
        }
    }

    assert 'yo' == get_tree_node(tree, 'this:is:a:test')
    assert 'yo' == get_tree_node(tree, 'this:is:a:test', default='neato')

    try:
        get_tree_node(tree, 'this:is:a:test:neato')
    except KeyError:
        pass
    else:
        assert False

    # Test parent arg
    assert {'test': 'yo'} == get_tree_node(tree, 'this:is:a:test', parent=True)



# Generated at 2022-06-12 08:28:12.063137
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'logger.console.level', 'DEBUG')
    assert tree['logger']['console']['level'] == 'DEBUG'



# Generated at 2022-06-12 08:28:21.605306
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {'parent': {'child': {'grand-child': 'value'}}}

    assert isinstance(get_tree_node(test_tree, 'parent:child:grand-child'), str)
    assert get_tree_node(test_tree, 'parent:child:grand-child') == 'value'
    assert get_tree_node(test_tree, 'parent:child') == {'grand-child': 'value'}
    assert get_tree_node(test_tree, 'parent') == {'child': {'grand-child': 'value'}}
    assert get_tree_node(test_tree, 'parent:child:grand-child', default=False) is False

# Generated at 2022-06-12 08:28:52.129802
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'a': {
            'b': {
                'c': 1,
            },
        },
    }
    assert get_tree_node(test_data, 'a:b:c') == 1
    assert get_tree_node(test_data, 'a:b:c', default=2) == 1
    assert get_tree_node(test_data, 'a:b:z', default=2) == 2

# Generated at 2022-06-12 08:29:02.255450
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = dict(
        dict(
            first=1,
        ),
        second=2,
        third=3,
    )

    # This module fails once, but that's because of the nature of the test.
    import pytest
    with pytest.raises(KeyError):
        assert get_tree_node(mapping, 'missing') == _sentinel
        assert get_tree_node(mapping, 'missing', 'default') == 'default'
        assert get_tree_node(mapping, 'first') == 1
        assert get_tree_node(mapping, 'dict:first') == 1
        assert get_tree_node(mapping, 'second') == 2
        assert get_tree_node(mapping, 'second', 'other') == 2

# Generated at 2022-06-12 08:29:09.276887
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test function get_tree_node"""
    my_dict = {
        'a': {
            'b': {
                'c': {
                    'd': 1,
                },
                'f': 3,
            },
        },
    }

    assert get_tree_node(my_dict, 'a:b:c:d') == 1
    assert get_tree_node(my_dict, 'a:b:f') == 3
    assert get_tree_node(my_dict, 'a:b:e') is _sentinel

# Generated at 2022-06-12 08:29:16.787601
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {
        'number': 1,
        'string': 'one',
        'list': ['one', 'two', 'three'],
        'dict': {
            'number': 1,
            'string': 'one',
            'list': ['one', 'two', 'three'],
        },
    }

    set_tree_node(a, 'number', 42)
    assert a['number'] == 42

    set_tree_node(a, 'string', 'forty-two')
    assert a['string'] == 'forty-two'

    set_tree_node(a, 'list:0', 'forty-two')
    assert a['list'][0] == 'forty-two'

    set_tree_node(a, 'dict:dict:number', 42)

# Generated at 2022-06-12 08:29:25.969760
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    DEPRECATED: See test_tree.py
    """
    # TODO: Unlist me.
    print('DEPRECATED: See test_tree.py')
    return
    data = tree()
    data['john']['surname'] = 'smith'
    data['john']['age'] = 20
    data['mary']['surname'] = 'brown'
    data['mary']['age'] = 19

    assert get_tree_node(data, 'john:surname') == 'smith'
    assert get_tree_node(data, 'john:age') == 20

    # Case where item not found
    with pytest.raises(KeyError):
        get_tree_node(data, 'john:address')
    # Case where specifying default value
    assert get_tree_node

# Generated at 2022-06-12 08:29:34.479225
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'a': {
            'b': {
                'c': {
                    'd': 'e',
                }
            },
            'f': 'g'
        }
    }
    assert get_tree_node(test_dict, 'a:b:c:d') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d:f') is _sentinel
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d:f', default='g') == 'g'
    test_dict = {'a': ['b', 'c']}

# Generated at 2022-06-12 08:29:38.694488
# Unit test for function set_tree_node
def test_set_tree_node():
    """Simple unit test for Tree.set_tree_node."""
    tree = Tree()
    tree.set_tree_node('foo:bar:baz', 'test')
    assert tree['foo:bar:baz'] == 'test'
    assert tree['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-12 08:29:48.655256
# Unit test for function get_tree_node

# Generated at 2022-06-12 08:29:51.292401
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for get_tree_node."""
    treenode = Tree()
    treenode["foo:bar:baz"] = "spam"
    assert treenode["foo:bar:baz"] == "spam"
    assert get_tree_node(treenode, "foo:bar:baz") == "spam"



# Generated at 2022-06-12 08:29:56.021691
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 2}}, 'a') == {'b': 2}, 'Basic first level test failed'
    assert get_tree_node({'a': {'b': 2}}, 'a:b') == 2, 'Basic deep-level test failed'
    assert get_tree_node({'a': {'b': 2}}, 'a:c', default=3) == 3, 'Basic deep-level default test failed'


if __name__ == '__main__':
    test_get_tree_node()