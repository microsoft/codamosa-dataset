

# Generated at 2022-06-12 08:20:07.725018
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
        },
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo') == {'bar': 'baz'}

    with pytest.raises(KeyError):
        get_tree_node(mapping, 'hello:world')

    assert get_tree_node(mapping, 'hello:world', default='hello') == 'hello'



# Generated at 2022-06-12 08:20:16.104486
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test if get_tree_node works correctly
    test_dict = {
        'layer1': {
            'layer2': {
                'layer3': {
                    'layer4': {
                        'value': 'value'
                    }
                }
            }
        }
    }
    assert get_tree_node(test_dict, 'layer1:layer2:layer3:layer4:value') == 'value'
    assert get_tree_node(test_dict, 'layer1:layer2:layer3:layer4:value', default=None) == 'value'
    assert get_tree_node(test_dict, 'layer1:layer2:layer3:layer5:value', default=None) is None



# Generated at 2022-06-12 08:20:20.632373
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'a': {'b': {'c': 1}}}
    set_tree_node(mapping, 'a:b:c', 2)
    set_tree_node(mapping, 'a:b:d', 3)
    assert mapping['a']['b']['c'] == 2
    assert mapping['a']['b']['d'] == 3

# Generated at 2022-06-12 08:20:32.071525
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'test_dict': {
            'test_key': 'test_value'
        }
    }
    assert get_tree_node(test_dict, 'test_non-existing_key', 'default_value') == 'default_value'
    assert get_tree_node(test_dict, 'test_dict:test_key') == 'test_value'
    assert get_tree_node(test_dict, 'test_dict:test_non-existent_key') == 'default_value'
    assert get_tree_node(test_dict, 'test_dict:test_non-existent_key', 'default_value') == 'default_value'
    # Test parent node

# Generated at 2022-06-12 08:20:36.776053
# Unit test for function get_tree_node
def test_get_tree_node():

    my_map = {
        'foo': {
            'bar': 'baz',
            'buzz': {
                'fizz': 'bang'
            }
        }
    }

    assert get_tree_node(my_map, 'foo:bar') == 'baz'
    assert get_tree_node(my_map, 'foo:bar:fizz') == 'bang'



# Generated at 2022-06-12 08:20:44.436813
# Unit test for function get_tree_node
def test_get_tree_node():
    import pytest
    node = {'a': {'b': {'c': 123}}}
    assert get_tree_node(node, 'a:b:c', _sentinel) == 123
    assert get_tree_node(node, 'a:d:c', _sentinel) is _sentinel
    assert get_tree_node(node, 'a:d:c', -1) == -1
    with pytest.raises(KeyError):
        get_tree_node(node, 'a:d:c')



# Generated at 2022-06-12 08:20:49.855617
# Unit test for function set_tree_node
def test_set_tree_node():
    test_mapping = {
        'foo': {
            'bar': 'baz',
            'biz': 'boz'
        }
    }
    set_tree_node(test_mapping, 'foo:bar:boz', 'baz')
    assert test_mapping['foo']['bar'] == {'boz': 'baz'}, test_mapping



# Generated at 2022-06-12 08:20:54.383895
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {
        'a': {
            'b': 1,
            'c': 2,
            'd': 3,
        }
    }
    set_tree_node(tree, 'a:b', 'once upon a time')
    assert tree['a']['b'] == 'once upon a time'



# Generated at 2022-06-12 08:21:03.585659
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = Tree({
        'foo': {
            'bar': {
                'foo': 1
            }
        },
        'baz': {
            'bar': {
                'baz': 2
            }
        },
        'bar': {
            'foo': {'foo': 3}
        }
    })

    # Error
    try:
        test_data.get('asdf:asdf')
    except KeyError:
        pass
    else:
        raise AssertionError('Expected KeyError from test_data.get(asdf:asdf)')

    # Basic
    assert test_data.get('foo:bar:foo') == 1

    # Default, not found
    assert test_data.get('asdf:asdf', 17) == 17

    # Default, found
    assert test_

# Generated at 2022-06-12 08:21:09.417317
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'a': {
            'b': {
                'c': {
                    'd': 'e',
                    'f': ['g', 'h', 'i'],
                },
            },
        },
    }
    assert 'f' == get_tree_node(test_data, 'a:b:c', 'f')



# Generated at 2022-06-12 08:21:20.601152
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    None
    """

    mapping = {'a': {'b': {'c': 'd'}}}
    first_node = get_tree_node(mapping, 'a')
    assert first_node == {'b': {'c': 'd'}}
    second_node = get_tree_node(mapping, 'a:b')
    assert second_node == {'c': 'd'}
    third_node = get_tree_node(mapping, 'a:b:c')
    assert third_node == 'd'



# Generated at 2022-06-12 08:21:25.672757
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'xyzzy'
            }
        }
    }
    assert mapping['foo']['bar']['baz'] == get_tree_node(mapping, 'foo:bar:baz')
    assert mapping == get_tree_node(mapping, 'foo', parent=True)
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'invalid', default=_sentinel)



# Generated at 2022-06-12 08:21:32.750407
# Unit test for function get_tree_node
def test_get_tree_node():
    n = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(n, 'a:b:c') == 'd'
    assert get_tree_node(n, 'a:b:c:z', default='d') == 'd'
    assert get_tree_node(n, 'a:b:c', parent=True) == {'c': 'd'}
    # Test that we're raising a KeyError when no default is specified
    pytest.raises(KeyError, get_tree_node, n, 'a:b:c:z')



# Generated at 2022-06-12 08:21:42.631829
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': 1
                }
            },
            'e': 2
        },
        'f': {
            'g': {
                'h': {
                    'i': 3
                }
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c:d') == 1
    assert get_tree_node(mapping, 'a:e') == 2
    assert get_tree_node(mapping, 'f:g:h') == {'i': 3}
    assert get_tree_node(mapping, 'f:g:h:i') == 3

# Generated at 2022-06-12 08:21:51.688577
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a', 1)
    set_tree_node(tree, 'a:b', 2)
    set_tree_node(tree, 'c:b:a', 3)
    set_tree_node(tree, 'c:b:a:f:e', 4)
    assert tree['a'] == 1
    assert tree['a']['b'] == 2
    assert tree['c']['b']['a']['f']['e'] == 4
    assert tree['c']['b']['a']['f'] == {'e': 4}



# Generated at 2022-06-12 08:22:03.149498
# Unit test for function get_tree_node
def test_get_tree_node():
    from pytest import raises
    list_tree = [
        {
            'z' : 5,
            'y' : [ 6, 7],
            'x' : {
                'a': 1,
                'b': 2,
                'c': 3,
            },
        }
    ]
    assert get_tree_node(list_tree, 'x:a') == 1
    assert get_tree_node(list_tree, 'x:b') == 2
    assert get_tree_node(list_tree, 'x:c') == 3
    assert get_tree_node(list_tree, 'y:0', parent=True) == [6, 7]
    assert get_tree_node(list_tree, 'x:d') == _sentinel

# Generated at 2022-06-12 08:22:06.373996
# Unit test for function get_tree_node
def test_get_tree_node():
    import pprint
    struct = tree()
    struct['one']['two']['three']['four'] = 'success'
    pprint.pprint(dict(struct))
    assert get_tree_node(struct, 'one:two:three:four') == 'success'



# Generated at 2022-06-12 08:22:09.769995
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test function set_tree_node"""
    mapping = tree()
    assert set_tree_node(mapping, 'foo:bar', 'baz') == {'bar': 'baz'}

# Generated at 2022-06-12 08:22:20.571323
# Unit test for function get_tree_node
def test_get_tree_node():

    b = {
        'bla': {
            'blubb': {
                'foo': 'bar'
            }
        }
    }
    assert get_tree_node(b, 'bla:blubb:foo') == 'bar'
    assert get_tree_node(b, 'bla:blubb') == {'foo': 'bar'}
    assert get_tree_node(b, 'bla:blubb:bar', default=None) is None
    assert get_tree_node(b, 'bla:blubb:bar', default=None) is None
    assert get_tree_node(b, 'bla:blubb:bar', default='foobar') == 'foobar'

# Generated at 2022-06-12 08:22:25.569692
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz'
        }
    }
    val = get_tree_node(mapping, 'foo:bar')
    assert val == 'baz'



# Generated at 2022-06-12 08:22:39.639953
# Unit test for function get_tree_node
def test_get_tree_node():
    # Example mapping data
    data = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': {
                'g': 'h',
            },
        },
    }

    # Tests
    assert get_tree_node(data, 'a') == 'b'
    assert get_tree_node(data, 'c:d') == 'e'
    assert get_tree_node(data, 'c:f:g') == 'h'
    assert get_tree_node(data, 'c:f:g:h') is None
    try:
        assert get_tree_node(data, 'c:g') is None
    except KeyError:
        assert True

# Generated at 2022-06-12 08:22:48.705194
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Verify that get_tree_node actually works.
    """
    # Setup - create a tree
    tree = {'a': {'b': {'c': 1}}}

    # Test - check it actually works
    assert get_tree_node(tree, 'a:b:c') == 1
    assert get_tree_node(tree, 'a:b') == {'c': 1}
    assert get_tree_node(tree, 'a') == {'b': {'c': 1}}
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel


if __name__ == "__main__":
    test_get_tree_node()

# Generated at 2022-06-12 08:22:58.361869
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test function get_tree_node"""
    tree = {
        'a': {
            'b': {
                'c': {
                    'd': 'D',
                },
                'D': 'B',
            },
        },
    }

    # Basic test
    assert get_tree_node(tree, 'a:b:c:d') == 'D'

    # Test KeyError.
    with pytest.raises(KeyError):
        get_tree_node(tree, 'a:c')

    # Test default value.
    assert get_tree_node(tree, 'a:c', default='C') == 'C'
    with pytest.raises(KeyError):
        get_tree_node(tree, 'a:c')

    # Test parent.

# Generated at 2022-06-12 08:23:05.668036
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'unimportant') is _sentinel
    assert get_tree_node({'unimportant': 2}, 'unimportant') == 2
    assert get_tree_node({'unimportant': 2}, 'non_existent') is _sentinel
    assert get_tree_node({'unimportant': 2}, 'non_existent', 3) == 3
    assert get_tree_node({'unimportant': {'nested': 2}}, 'unimportant:nested') == 2



# Generated at 2022-06-12 08:23:13.635855
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {'a': {'b': {'c': 'value'}}}
    assert get_tree_node(data, 'a:b:c') == 'value'
    assert get_tree_node(data, 'a:b:c:d') is _sentinel
    assert get_tree_node(data, 'a:b:c', default='nope') == 'value'
    assert get_tree_node(data, 'a:b:c:d', default='nope') == 'nope'
    assert get_tree_node(data, 'a:b:c:d') is _sentinel
    assert get_tree_node(data, 'a:b', parent=True) == {'b': {'c': 'value'}}

# Generated at 2022-06-12 08:23:20.468464
# Unit test for function set_tree_node
def test_set_tree_node():
    m = collections.OrderedDict([('test', {})])

# Generated at 2022-06-12 08:23:29.866704
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit testing for `get_tree_node`."""
    test_mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert 'd' == get_tree_node(test_mapping, 'a:b:c')
    assert 'd' == get_tree_node(test_mapping, 'a:b:c:')
    assert 'd' == get_tree_node(test_mapping, 'a:b:c::')
    assert 'd' == get_tree_node(test_mapping, 'a::b:c')
    assert 'd' == get_tree_node(test_mapping, ':a:b:c')

# Generated at 2022-06-12 08:23:40.889403
# Unit test for function get_tree_node
def test_get_tree_node():
    a = tree()
    a['a'] = 'A'
    a['b'] = 'B'
    b = tree()
    b['c'] = 'C'
    b['d'] = 'D'
    a['b:c:d'] = b
    assert get_tree_node(a, 'a') == 'A'
    assert get_tree_node(a, ':a:b') == 'B'
    assert get_tree_node(a, 'b') == 'B'
    assert get_tree_node(a, 'b:c:d') == {'c': {'d': {'c': {'d': {}}}}}
    assert get_tree_node(a, 'b:c:d') == {'c': {'d': {'c': {'d': {}}}}}

# Generated at 2022-06-12 08:23:49.467140
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    d = set_tree_node(d, 'a:b:c:e:f:g', 'bar')
    assert d == {'a': {'b': {'c': {'e': {'f': {'g': 'bar'}}}}}}

    d = set_tree_node(d, 'a:b:c:e:f:h', 'bar')

# Generated at 2022-06-12 08:23:55.920383
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 1)
    set_tree_node(d, 'a:b:d', 1)
    set_tree_node(d, 'a:e:f', 1)
    assert d == {'a': {'b': {'c': 1, 'd': 1}, 'e': {'f': 1}}}



# Generated at 2022-06-12 08:24:13.434034
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup a tree for the unit test that looks like:
    # {
    #     'a': {
    #         'b': {
    #             'c': 10,
    #             'd': [1, 2, 3]
    #         }
    #     }
    # }
    test_tree = {
        'a': {
            'b': {
                'c': 10,
                'd': [1, 2, 3]
            }
        }
    }
    # Get the right leaf node
    node = get_tree_node(test_tree, 'a:b:c')
    assert node == 10
    # Get the right leaf node with a default value
    node = get_tree_node(test_tree, 'a:b:e', default=1)
    assert node == 1
    # Get

# Generated at 2022-06-12 08:24:24.317819
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    d = {}
    d['a'] = 1
    d['b'] = {'a': 1, 'b': 2, 'c': 3}
    d['c'] = {'a': {'x': 12, 'y': 14}, 'b': 2, 'c': 3}
    assert get_tree_node(d, 'b:a') == 1
    assert get_tree_node(d, 'b:b') == 2
    assert get_tree_node(d, 'b:c') == 3
    assert get_tree_node(d, 'c:b') == 2
    assert get_tree_node(d, 'c:a:x') == 12
    assert get_tree_node(d, 'c:a:y') == 14

# Generated at 2022-06-12 08:24:31.594497
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {"foo": {"bar": "baz", "qux": "quux"}}
    assert get_tree_node(data, "foo:bar") == "baz"

    data = {"foo": {"bar": {"baz": {"qux": "quux"}}}}
    assert get_tree_node(data, "foo:bar:baz:qux") == "quux"

    assert get_tree_node(data, "foo:bar:baz:qux:xyzzy", default=None) is None

    with pytest.raises(KeyError):
        get_tree_node(data, "foo:bar:baz:qux:xyzzy")



# Generated at 2022-06-12 08:24:42.246716
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': {
            'bar': {
                'bizz': 1,
                'buzz': 2,
            }
        },
    }
    assert get_tree_node(data, 'foo:bar:bizz') == 1
    assert get_tree_node(data, 'foo:bar:buzz') == 2

    # Missing
    with pytest.raises(KeyError):
        get_tree_node(data, 'foo:bar:bang')

    assert get_tree_node(data, 'foo:bar:bang', default=None) is None

    # Traversal
    assert get_tree_node(data, 'foo:bar', default=None) == {
        'bizz': 1,
        'buzz': 2,
    }

    # Parent
    assert get_tree_node

# Generated at 2022-06-12 08:24:48.503306
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test setting of arbitrary node in tree-like structure"""
    tree = collections.defaultdict(collections.defaultdict)
    # Test standard setting
    set_tree_node(tree, 'foo', 'bar')
    assert tree['foo'] == 'bar'
    # Test nested setting
    set_tree_node(tree, 'bar:foo', 'xxx')
    assert tree['bar']['foo'] == 'xxx'



# Generated at 2022-06-12 08:24:52.836347
# Unit test for function get_tree_node
def test_get_tree_node():
    # test_dict = {
    #     'foo': {
    #         'bar': {
    #             'baz': 'qux'
    #         }
    #     }
    # }
    test_dict = Tree()
    test_dict['foo:bar:baz'] = 'qux'
    assert get_tree_node(test_dict, 'foo:bar:baz') == 'qux'



# Generated at 2022-06-12 08:24:59.797960
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'a': 123,
        'b': {
            'c': 234,
            'd': {
                'f': 345
            }
        }
    }
    assert get_tree_node(test_mapping, 'a') == 123
    assert get_tree_node(test_mapping, 'b:c') == 234
    assert get_tree_node(test_mapping, 'b:d:f') == 345
    assert get_tree_node(test_mapping, 'b:d:f:g') is _sentinel



# Generated at 2022-06-12 08:25:04.997792
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'hi'
            }
        }
    }

    assert get_tree_node(tree, 'foo:bar:baz') == 'hi'
    assert get_tree_node(tree, 'foo:bar:baz', default='there') == 'hi'
    assert get_tree_node(tree, 'foo:bar:ding') is _sentinel


# Unit tests for get_tree_node

# Generated at 2022-06-12 08:25:15.998879
# Unit test for function get_tree_node
def test_get_tree_node():
    class TestValue(object):
        def __init__(self, value):
            self.value = value

    registry = Tree({
        'a': {
            'b': {
                'c': {
                    'd': TestValue(1),
                    'e': TestValue(2),
                },
                'f': {
                    'g': TestValue(3),
                    'h': TestValue(4)
                }
            }
        },
        'i': {
            'j': {
                'k': TestValue(5),
                'm': {
                    'n': TestValue(6)
                }
            }
        }
    }, initial_is_ref=True)


# Generated at 2022-06-12 08:25:26.254954
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c') == 1
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c', default=0) == 1
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:d', default=2) == 2
    with pytest.raises(KeyError):
        get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:d')
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b', parent=True) == {'b': {'c': 1}}



# Generated at 2022-06-12 08:25:51.434427
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    data = collections.OrderedDict([
        ('first', collections.OrderedDict([
            ('second', collections.OrderedDict([
                ('third', 'Fourth'),
            ])),
        ])),
        ('foo', collections.OrderedDict([
            ('bar', collections.OrderedDict([
                ('baz', 'quux'),
            ])),
        ])),
    ])

    assert get_tree_node(data, 'first',) == data['first']

    assert get_tree_node(data, 'first:second:third',) == 'Fourth'
    assert get_tree_node(data, 'first:second:third',) == 'Fourth'

# Generated at 2022-06-12 08:26:01.087334
# Unit test for function get_tree_node
def test_get_tree_node():
    class RegistryTree(Tree):
        pass

    test_data = {
        'default': 'default',
        'foo': {
            'default': 'foo',
            'bar': {
                'default': 'foobar',
                'baz': 'baz'
            }
        },
        'bar': {
            'default': 'bar',
            'baz': 'baz'
        },
        'baz': 'xxx'
    }

    reg = RegistryTree(test_data)


# Generated at 2022-06-12 08:26:03.652207
# Unit test for function set_tree_node
def test_set_tree_node():
    test = tree()
    node = set_tree_node(test, 'foo:bar:baz', 'quux')
    assert node == {'foo': {'bar': {'baz': 'quux'}}}


# Generated at 2022-06-12 08:26:13.850828
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'node1', 'value1')
    assert tree['node1'] == 'value1'
    set_tree_node(tree, 'node2', 'value2')
    assert tree['node2'] == 'value2'
    set_tree_node(tree, 'node2:node3', 'value3')
    assert tree['node2']['node3'] == 'value3'
    set_tree_node(tree, 'node4:node5', 'value5')
    assert tree['node4']['node5'] == 'value5'
    set_tree_node(tree, 'node4:node6', 'value6')
    assert tree['node4']['node6'] == 'value6'



# Generated at 2022-06-12 08:26:22.279849
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node.
    """
    import pytest

    test_tree = tree()
    test_tree['a']['b']['c']['d'] = 1
    test_tree['a']['b']['c']['e'] = 2
    test_tree['a']['f']['c']['d'] = 3

    assert get_tree_node(test_tree, 'a') == {'b': {'c': {'d': 1, 'e': 2}}, 'f': {'c': {'d': 3}}}
    assert get_tree_node(test_tree, 'a:f:c') == {'d': 3}

# Generated at 2022-06-12 08:26:32.130140
# Unit test for function get_tree_node
def test_get_tree_node():
    class Foo(object):
        pass
    tree = {'a': {'b': {'c': {'d': {'e': Foo()}}}}}

    # Basic traversal
    assert get_tree_node(tree, 'a:b:c:d:e') is Foo()

    # Parent node
    assert get_tree_node(tree, 'a:b:c:d:e', parent=True) == {'e': Foo()}

    # Default value
    assert get_tree_node(tree, 'a:b:c:d:f', 'foo') == 'foo'

    # No default value, KeyError
    from pytest import raises
    with raises(KeyError):
        get_tree_node(tree, 'a:b:c:d:f')



# Generated at 2022-06-12 08:26:41.377748
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'name': 'Django',
        'version': '1.5',
        'children': {
            'name': 'Reinhardt',
            'version': '1.1.1',
        }
    }

    assert get_tree_node(mapping, 'name') == 'Django'
    assert get_tree_node(mapping, 'version') == '1.5'
    assert get_tree_node(mapping, 'children:name') == 'Reinhardt'
    assert get_tree_node(mapping, 'children:version') == '1.1.1'



# Generated at 2022-06-12 08:26:44.795161
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c:d', 'value')
    assert d['a']['b']['c']['d'] == 'value'


# Generated at 2022-06-12 08:26:53.671176
# Unit test for function get_tree_node
def test_get_tree_node():
    _test_tree = {
        'level_1_a': tree(),
        'level_1_b': tree(),
    }
    _test_tree['level_1_a']['level_2_a'] = tree()
    _test_tree['level_1_a']['level_2_a']['level_3_a'] = 'foo'
    _test_tree['level_1_a']['level_2_a']['level_3_b'] = 'bar'
    _test_tree['level_1_a']['level_2_a']['level_3_c'] = 'baz'
    _test_tree['level_1_a']['level_2_b'] = 'qux'

# Generated at 2022-06-12 08:27:03.482926
# Unit test for function get_tree_node
def test_get_tree_node():
    import pprint
    test_data = {
        'one': {
            'two': {
                'three': 'value',
            }
        },
        'four': {
            'five': {
                True: {
                    'ten': 'value',
                },
                False: {
                    'eleven': 'value',
                },
            }
        }
    }


# Generated at 2022-06-12 08:27:35.578700
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'test:test1', 'Test 1')
    set_tree_node(mapping, 'test:test2', 'Test 2')

    assert mapping == {
        'test': {
            'test1': 'Test 1',
            'test2': 'Test 2',
        }
    }

# Generated at 2022-06-12 08:27:46.821748
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(
        {'a': {'b': {'c': 5} }, },
        'a:b:c') == 5
    try:
        get_tree_node(
            {'a': {'b': {'c': 5} }, },
            'a:b:c:d')
        assert False, 'Should have thrown KeyError'
    except KeyError:
        pass
    assert get_tree_node(
        {'a': {'b': {'c': 5} }, },
        'a:b:c:d',
        default=None) is None
    assert get_tree_node(
        {'a': {'b': {'c': 5} }, },
        'a:b',
        parent=True) == {'c': 5}
    assert get_tree_

# Generated at 2022-06-12 08:27:54.493782
# Unit test for function set_tree_node
def test_set_tree_node():
    from pprint import pprint
    from copy import deepcopy
    import os
    import sys

    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

    # Set up
    from io import StringIO
    namespace = {
        'a': {
            'b': {
                'c': {
                    'd': 'EBOLA',
                },
                'e': 'THE SUN',
            },
            'f': 'THREE',
        },
        'z': {
            'k': 'four',
        }
    }
    key = 'a:b:c:d'
    value = 'Japan'

    new = deepcopy(namespace)
    set_tree_node(new, key, value)

    # Assert that the output

# Generated at 2022-06-12 08:28:00.832993
# Unit test for function get_tree_node
def test_get_tree_node():

    test_tree = {'a': {'b': 'c', 'd': 'e'}, 'g': {'h': 1}}
    assert get_tree_node(test_tree, 'a') == {'b': 'c', 'd': 'e'}
    assert get_tree_node(test_tree, 'a:b') == 'c'
    assert get_tree_node(test_tree, 'a:d') == 'e'
    assert get_tree_node(test_tree, 'a:b:', default='f') == 'f'
    try:
        get_tree_node(test_tree, 'a:b:')
        raise AssertionError()
    except KeyError:
        pass



# Generated at 2022-06-12 08:28:07.505273
# Unit test for function set_tree_node
def test_set_tree_node():

    tree = {}
    tree = set_tree_node(tree, 'foo', 'bar')
    assert tree == dict(foo='bar')
    tree = set_tree_node(tree, 'foo:bar', 'x')
    assert tree == dict(foo=dict(bar='x'))
    tree = set_tree_node(tree, 'x:y', 'z')
    assert tree == dict(foo=dict(bar='x'), x=dict(y='z'))



# Generated at 2022-06-12 08:28:15.804438
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()

    # Test non-existent key
    with pytest.raises(KeyError):
        assert get_tree_node(mapping, 'key') == _sentinel

    # Test explicit default
    assert get_tree_node(mapping, 'key', default='default') == 'default'

    # Test setting value
    set_tree_node(mapping, 'key', 'value')
    assert get_tree_node(mapping, 'key') == 'value'

    # Test value at parent node
    set_tree_node(mapping, 'key1:key2', 'value')
    assert get_tree_node(mapping, 'key1', parent=True) == {'key2': 'value'}



# Generated at 2022-06-12 08:28:19.370060
# Unit test for function set_tree_node
def test_set_tree_node():
    test_mapping = {'a': {'x': 1, 'b': 2}}
    assert set_tree_node(test_mapping, 'a:x', 9) == {'x': 9, 'b': 2}



# Generated at 2022-06-12 08:28:30.114558
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': {'d': {'e': {'f': {'g': 1}}}}}}}

    expected = mapping
    result = get_tree_node(mapping, 'a', default=None)
    assert expected == result

    expected = mapping['a']
    result = get_tree_node(mapping, 'a:b', default=None)
    assert expected == result

    expected = mapping['a']['b']['c']
    result = get_tree_node(mapping, 'a:b:c', default=None)
    assert expected == result

    expected = 1
    result = get_tree_node(mapping, 'a:b:c:d:e:f:g', default=None)
    assert expected == result

    expected = 2
    result

# Generated at 2022-06-12 08:28:38.309692
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node(mapping, key, default)"""

    # testing with dict
    dict_test = {'a': {'b': {'c': 'd'}}, 'f': 'g'}
    assert get_tree_node(dict_test, 'a:b:c', default='test') == 'd'
    assert get_tree_node(dict_test, 'a:h:i', default='test') == 'test'
    assert get_tree_node(dict_test, 'f') == 'g'


if __name__ == "__main__":
    test_get_tree_node()

# Generated at 2022-06-12 08:28:40.906578
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_dict = {'a': 1}
    set_tree_node(tree_dict, 'b:c:d', 3)
    assert tree_dict['b']['c']['d'] == 3



# Generated at 2022-06-12 08:29:54.182643
# Unit test for function get_tree_node
def test_get_tree_node():
    # test empty key
    assert get_tree_node({}, '') == {}

    # test normal use
    assert get_tree_node({'a': 1}, 'a') == 1
    assert get_tree_node({'a': 1}, 'a', default=2) == 1

    # test with depth
    assert get_tree_node({'a': {'b': 1}}, 'a:b') == 1
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c') == 1

    # test default
    assert get_tree_node({'a': {'b': 1}}, 'b', default=2) == 2

# Generated at 2022-06-12 08:29:56.125462
# Unit test for function get_tree_node
def test_get_tree_node():
    pass



# Generated at 2022-06-12 08:29:58.033087
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'foo')



# Generated at 2022-06-12 08:30:04.042621
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c:d:e:f:g:h:i:j:k:l:m:n', 'value')