

# Generated at 2022-06-12 08:20:07.561534
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'parent': {
            'child': 'test',
        },
    }
    assert 'test' == get_tree_node(test_dict, 'parent:child')
    assert 'test' == get_tree_node(test_dict, 'parent:child', default=None)
    assert 'test' == get_tree_node(test_dict, 'parent:child', default=None)
    assert None is get_tree_node(test_dict, 'parent:child:potato', default=None)



# Generated at 2022-06-12 08:20:13.570499
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {'a': {}}
    set_tree_node(d, 'a:b:c', 50)
    assert d['a']['b']['c'] == 50

    d = {'a': [5, {'b': {}}]}
    set_tree_node(d, 'a:1:b:c', 50)
    assert d['a'][1]['b']['c'] == 50



# Generated at 2022-06-12 08:20:17.929982
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'foo:bar:baz', 'Hello, world!')
    assert t['foo']['bar']['baz'] == 'Hello, world!'
    set_tree_node(t, 'foo:bar:baz', 'Goodbye')
    assert t['foo']['bar']['baz'] == 'Goodbye'



# Generated at 2022-06-12 08:20:21.997566
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {
            'b': {
                'c': {
                    'd': 'value'
                }
            }
        }
    }

    assert get_tree_node(d, 'a:b:c:d') == 'value'



# Generated at 2022-06-12 08:20:33.491059
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Tests for function `get_tree_node`
    """
    import pytest

    test_data = Tree({'a': 1, 'b': {'c': 2, 'd': {'e': 3, 'f': {'g': 4}}}})

    # Check right value is returned
    assert get_tree_node(test_data, 'a') == 1

    # Check that it correctly transverses the tree
    assert get_tree_node(test_data, 'b:d:f:g') == 4

    # Check that not existing keys return default if given, but raise error if not
    with pytest.raises(KeyError):
        assert get_tree_node(test_data, 'test')
    assert get_tree_node(test_data, 'test', default=False) is False

    # Check node

# Generated at 2022-06-12 08:20:44.261398
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = collections.OrderedDict([
        ('k', {'key': 'value'}),
        ('key', {'two': 'value'})
    ])

    assert get_tree_node(mapping, 'k:key') == 'value'
    assert get_tree_node(mapping, 'key:two') == 'value'
    assert get_tree_node(mapping, 'k:key2', default='default value') == 'default value'
    assert get_tree_node(mapping, 'key:two:', default='default value') == 'default value'
    try:
        get_tree_node(mapping, 'key:two:')
        assert False, 'Should not reach this point, expected KeyError'
    except KeyError:
        pass

# Generated at 2022-06-12 08:20:47.345980
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    tree = RegistryTree()
    tree.register('foo', 'bar')

    assert get_tree_node(tree, 'foo') == 'bar'

    # Teardown


# Generated at 2022-06-12 08:20:51.445654
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': ['d'],
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c:0') == 'd'



# Generated at 2022-06-12 08:20:58.173239
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'foo': {
            'bar': {
                'baz': {
                    'data': 'I am nesting!'
                }
            }
        }
    }

    # Test return of nested value
    assert get_tree_node(test_mapping, 'foo:bar:baz')['data'] == 'I am nesting!'

    # Test return of value
    assert get_tree_node(test_mapping, 'foo:bar')['baz']['data'] == 'I am nesting!'

    # Test return of invalid key
    try:
        get_tree_node(test_mapping, 'foo:bar:baz:wat')
    except KeyError:
        pass
    else:
        raise Exception('KeyError not raised for invalid tree key')

    # Test return of invalid key + default

# Generated at 2022-06-12 08:21:05.808037
# Unit test for function set_tree_node
def test_set_tree_node():
    import copy
    import json

    mapping = json.loads(
        '''
        {
            "a": {
                "b": {
                    "c": 1,
                    "d": 2
                },
                "c": {
                    "d": 4,
                    "e": 5
                }
            },
            "b": {
                "c": {
                    "d": {
                        "e": 6
                    },
                    "e": 7
                },
                "d": {
                    "e": {
                        "f": 8
                    }
                }
            }
        }
        '''
    )

    # Fetch single key
    assert get_tree_node(mapping, 'a:b:c') == 1

    # Fetch parent

# Generated at 2022-06-12 08:21:12.825622
# Unit test for function set_tree_node
def test_set_tree_node():
    my_tree = {'foo': {'bar': 'baz'}}
    set_tree_node(my_tree, 'a:b:c:d:e:f:g', 'h')
    assert my_tree['a']['b']['c']['d']['e']['f']['g'] == 'h'



# Generated at 2022-06-12 08:21:19.507059
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node to ensure it sets values correctly."""
    d = collections.defaultdict(dict)
    d['nodes']['node2']['node3']['node4'] = {}
    set_tree_node(d, ':nodes:node2:node3:node4:node5:node6', 1)
    assert d['nodes']['node2']['node3']['node4']['node5']['node6'] == 1



# Generated at 2022-06-12 08:21:26.739039
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for :meth:`get_tree_node`"""
    from copy import copy
    from pprint import pprint
    from hamcrest import (
        assert_that,
        equal_to,
        none,
    )

    mapping = tree()
    mapping['foo']['bar']['goo'] = 'foo:bar:goo'
    mapping['foo']['bar']['gah'] = 'foo:bar:gah'
    mapping['foo']['gah']['boo'] = 'foo:gah:boo'

    # Get all nodes at depth 1 (foo:bar:goo, foo:bar:gah, foo:gah:boo)
    for node in mapping.values():
        assert_that(node, instance_of(collections.defaultdict))

# Generated at 2022-06-12 08:21:29.394878
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {'foo': {'bar': {'baz': 'qux'}}}
    assert get_tree_node(a, 'foo:bar:baz') == 'qux'



# Generated at 2022-06-12 08:21:32.320802
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'test:test:test', "value")
    assert d['test']['test']['test'] == "value"



# Generated at 2022-06-12 08:21:41.448221
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'foo': {
            'bar': 'baz',
        },
        'spam': {
            'eggs': {
                'ham': 'yum',
            },
        },
    }

    assert get_tree_node(d, 'foo:bar') == 'baz'
    assert get_tree_node(d, 'spam:eggs:ham') == 'yum'
    assert get_tree_node(d, 'spam:eggs:does_not_exist', default='does_exist') == 'does_exist'
    assert get_tree_node(d, 'spam:eggs:does_not_exist') == 'yum'



# Generated at 2022-06-12 08:21:51.337170
# Unit test for function set_tree_node
def test_set_tree_node():

    tests = [
        {
            'key': 'foo:baz',
            'value': 'value',
            'input': {
                'foo': {
                    'bar': 'value',
                }
            },
            'expected': {
                'foo': {
                    'baz': 'value',
                    'bar': 'value',
                }
            }
        }
    ]
    for test in tests:
        test_mapping = test['input']
        key, value = test['key'], test['value']
        set_tree_node(test_mapping, key, value)
        assert test_mapping == test['expected']



# Generated at 2022-06-12 08:22:03.052853
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node."""
    import nose
    data = {
        'name': 'Test',
        'children': {
            'name': 'Child 1',
            'children': {
                'name': 'Child 2',
            },
        },
    }
    nose.tools.eq_(get_tree_node(data, 'name'), 'Test')
    nose.tools.eq_(get_tree_node(data, 'children:name'), 'Child 1')
    nose.tools.eq_(get_tree_node(data, 'children:children:name'), 'Child 2')
    nose.tools.eq_(get_tree_node(data, 'children:children:name', default='Default'), 'Child 2')

# Generated at 2022-06-12 08:22:12.889158
# Unit test for function get_tree_node
def test_get_tree_node():

    test_tree = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    res = get_tree_node(test_tree, 'foo:bar:baz')
    assert res == 'qux'

    res = get_tree_node(test_tree, 'foo:bar')
    assert res == {'baz': 'qux'}

    res = get_tree_node(test_tree, 'foo')
    assert res == {'bar': {'baz': 'qux'}}

    with pytest.raises(KeyError):
        get_tree_node(test_tree, 'foo:bar:qux')

    res = get_tree_node(test_tree, 'foo:bar:qux', default='quux')
   

# Generated at 2022-06-12 08:22:22.344296
# Unit test for function set_tree_node
def test_set_tree_node():
    # Testing base case
    tree = {}
    set_tree_node(tree, 'hi', 'hi')
    assert tree == {'hi': 'hi'}, '{!r} != {!r}'.format(tree, 'hi')
    # Testing with depth greater than 1
    tree = {}
    set_tree_node(tree, 'hi:ho', 'hi')
    assert tree == {'hi': {'ho': 'hi'}}, '{!r} != {!r}'.format(tree, {'hi': {'ho': 'hi'}})
    # Testing with depth greater than 2
    tree = {}
    set_tree_node(tree, 'hi:ho:wow', 'hi')

# Generated at 2022-06-12 08:22:30.019306
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 'd')
    assert d == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-12 08:22:36.951929
# Unit test for function set_tree_node
def test_set_tree_node():
    """Tests set_tree_node function."""

    # Initialise a tree
    mapping = tree()

    # Set a value to a node
    mapping['something']['funky']['this']['way'] = 'comes'

    # Set using the function
    set_tree_node(mapping, 'hello:there:good:sir', 'hello')

    # Ensure the value has been set
    assert mapping['hello']['there']['good']['sir'] == 'hello'

    # Ensure the value has been set
    assert mapping['something']['funky']['this']['way'] == 'comes'



# Generated at 2022-06-12 08:22:47.367604
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test the function _get_tree_node_()."""
    def f(o):
        return True
    mapping = {'a': {'a': {'f': f}}}
    assert get_tree_node(mapping, 'a:a:f') is f
    assert get_tree_node(mapping, 'a:a:f') is mapping['a']['a']['f']
    assert get_tree_node(mapping, 'a:a:f') == get_tree_node(mapping, 'a:a:f',
                                                            default=None)
    assert get_tree_node(mapping, 'a:b:f') is None
    assert get_tree_node(mapping, 'a:b:f', default=None) is None

# Generated at 2022-06-12 08:22:53.971965
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'a': {'b': {'branch': True}, 'branch': {'leaf': '1'}},
            'b': {'leaf': '2'}}
    assert get_tree_node(tree, 'a:branch:leaf', default='def') == '1'
    assert get_tree_node(tree, 'a:branch:nothere', default='def') == 'def'
    assert get_tree_node(tree, 'b:leaf') == '2'

    with pytest.raises(KeyError):
        get_tree_node(tree, 'c:nothere')

    # TODO Add test for parent parameter


# Generated at 2022-06-12 08:23:05.376611
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test function :func:`atramhasis.util.get_tree_node`"""
    # Set up test data
    test_data = {
        'first': {
            'second': 'foo',
            }
        }

    # Test on existing path
    node = get_tree_node(test_data, 'first:second')
    assert node == 'foo'

    # Test on existing path with default
    node = get_tree_node(test_data, 'first:second', default='bar')
    assert node == 'foo'

    # Test on existing path with default
    node = get_tree_node(test_data, 'first:second', 'bar')
    assert node == 'foo'

    # Test on non-existing path with default

# Generated at 2022-06-12 08:23:13.431229
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['foo']['bar'] = 'baz'

    assert get_tree_node(data, ':foo:bar') == 'baz'
    assert get_tree_node(data, 'foo:bar') == 'baz'
    assert get_tree_node(data, 'foo:bar:') == 'baz'
    assert get_tree_node(data, 'foo:bar:baz') == 'baz'
    assert get_tree_node(data, 'foo:bar:baz:boop') is None
    assert get_tree_node(data, 'foo:bar:baz:boop', 'err') == 'err'
    assert get_tree_node(data, 'foo:bar:baz:boop', default='err') == 'err'



# Generated at 2022-06-12 08:23:18.042637
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['foo']['bar'] = 'baz'
    mapping['foo']['qux'] = 'quux'
    mapping['foo']['qux']['quuz'] = 'grault'

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:quuz', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:qux:quuz') == 'grault'
    assert get_tree_node(mapping['foo']['bar']) == ['foo', 'bar', 'baz']
    assert len(get_tree_node(mapping, 'foo', parent=True)) == 2

# Generated at 2022-06-12 08:23:21.539971
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    set_tree_node(a, 'a:b:c', 1)
    if a != {'a': {'b': {'c': 1}}}:
        raise AssertionError



# Generated at 2022-06-12 08:23:30.561657
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    get_tree_node should accept a mapping, string, and value, then traverse to the specified branch using :
    """
    tree = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz'
            }
        }
    }

    tree_node = get_tree_node(tree, 'foo:bar:baz')
    assert tree_node == 'foobarbaz'

    # Test with default value
    tree_node = get_tree_node(tree, 'foo:bar:nope', default='foo')
    assert tree_node == 'foo'
    tree_node = get_tree_node(tree, 'foo:bar:nope', default='foo', parent=True)
    assert tree_node == tree['foo']['bar']

    # Test KeyError raised


# Generated at 2022-06-12 08:23:41.269695
# Unit test for function set_tree_node
def test_set_tree_node():
    from pprint import pprint
    import copy

    test = tree()
    set_tree_node(test, 'foo:bar', 'baz')

    pprint(test)
    assert test['foo']['bar'] == 'baz'

    test = {
        'foo': {
            'bar': 'baz',
        },
        'bar': {},
    }

    test_copy = copy.deepcopy(test)

    set_tree_node(test, 'bar:baz', 'foo')
    set_tree_node(test, 'foo:bar', 'foobar')

    pprint(test)
    assert test['foo']['bar'] == 'foobar'
    assert test['bar']['baz'] == 'foo'



# Generated at 2022-06-12 08:23:54.893807
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'foo:bar:baz', 'Asdf')
    assert d['foo']['bar']['baz'] == 'Asdf'



# Generated at 2022-06-12 08:24:04.468828
# Unit test for function set_tree_node
def test_set_tree_node():
    import json

    toplevel = {}
    initial = 'meow'
    toplevel[initial] = initial
    assert isinstance(toplevel, dict)
    assert json.dumps(toplevel) == json.dumps({'meow': 'meow'})

    deeper = {}
    initial = 'meow'
    deeper[initial] = initial
    toplevel['deeper'] = deeper
    assert json.dumps(toplevel) == json.dumps({'meow': 'meow', 'deeper':
                                               {'meow': 'meow'}})

    set_tree_node(toplevel, 'deeper:deeper:meow', 'meow')

# Generated at 2022-06-12 08:24:08.465027
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:fizz', 'buzz')
    assert mapping == {'foo': {'bar': {'fizz': 'buzz'}}}



# Generated at 2022-06-12 08:24:17.321265
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node."""
    # print('Running test_get_tree_node')
    my_dict = {
        'a': 1,
        'b': {
            'b1': 3
        },
        'c': [
            'c1',
            'c2'
        ]
    }
    assert get_tree_node(my_dict, 'a') == 1
    assert get_tree_node(my_dict, 'b') == {'b1': 3}
    assert get_tree_node(my_dict, 'b:b1') == 3
    assert get_tree_node(my_dict, 'c') == ['c1', 'c2']
    assert get_tree_node(my_dict, 'c:1') == 'c2'
    assert get_tree_

# Generated at 2022-06-12 08:24:27.959889
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz'
        }
    }
    node = get_tree_node(mapping, 'foo:bar')
    assert node == 'baz'

    node = get_tree_node(mapping, 'foo:bar:nein')
    assert node is None

    node = get_tree_node(mapping, 'no', default='wait')
    assert node == 'wait'

    exc = None
    try:
        node = get_tree_node(mapping, 'foo:nein')
    except Exception as e:
        exc = e
    assert exc is not None

    node = get_tree_node(mapping, 'foo:nein', default='wait', parent=True)
    assert node == mapping['foo']



# Generated at 2022-06-12 08:24:36.529192
# Unit test for function get_tree_node
def test_get_tree_node():
    example_tree = {
        'foo': {
            'bar': True,
            'baz': False,
            'qux': {
                'quux': True,
                'spam': False,
                }
        }
    }
    assert get_tree_node(example_tree, 'foo:bar') is True
    assert get_tree_node(example_tree, 'foo:baz') is False
    assert get_tree_node(example_tree, 'foo:qux:quux') is True
    assert get_tree_node(example_tree, 'foo:qux:spam') is False
    assert get_tree_node(example_tree, 'foo:foo') is _sentinel


# Generated at 2022-06-12 08:24:44.742627
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    data = {
        'foo': {
            'bar': {
                'baz': 1,
            },
        },
    }
    
    assert get_tree_node(data, 'foo:bar:baz') == 1
    assert get_tree_node(data, 'foo:bar:baz:nonexistent', default=False) is False
    assert get_tree_node(data, 'foo:bar:baz:nonexistent') == KeyError



# Generated at 2022-06-12 08:24:53.254056
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['a'] = 1
    data['b']['c'] = 2
    data['b']['d'] = 3

    assert data == get_tree_node(data, '')
    assert data['b'] == get_tree_node(data, 'b')
    assert data['b']['c'] == get_tree_node(data, 'b:c')
    assert data['b']['d'] == get_tree_node(data, 'b:d')
    assert data['a'] == get_tree_node(data, 'a')
    assert data['b'] == get_tree_node(data, 'b', parent=True)
    assert data['b'] == get_tree_node(data, 'b:c', parent=True)
    assert data['b'] == get_tree

# Generated at 2022-06-12 08:25:02.621396
# Unit test for function get_tree_node
def test_get_tree_node():
    sample_dict = {
        'a': {
            'b': {
                'c': 'foo',
                'f': 9,
            },
            'd': [1, 2, 3],
            'e': True,
        },
        'z': [
            0,
            1,
        ],
    }

    # a.b.c
    x = sample_dict.get('a:b:c', 'foo')
    assert x == 'foo'

    # a.b.f
    x = sample_dict.get('a:b:f', 'foo')
    assert x == 9

    # a.d
    x = sample_dict.get('a:d', 'foo')
    assert x == [1, 2, 3]

    # a.d[0]
    x = sample_dict.get

# Generated at 2022-06-12 08:25:13.000967
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    assert get_tree_node({1: {2: {3: 4}}, 0: 1}, '1:2:3') == 4
    assert get_tree_node({1: {2: {3: 4}}, 0: 1}, '1:2:3', default=0) == 4
    assert get_tree_node({1: {2: {3: 4}}, 0: 1}, '0', default=0) == 1
    assert get_tree_node({1: {2: {3: 4}}, 0: 1}, '1:2:3:4', default=0) == 0
    assert get_tree_node({1: {2: {3: 4}}, 0: 1}, '0:foo', default=0) == 0
    assert get_tree

# Generated at 2022-06-12 08:25:29.563295
# Unit test for function set_tree_node
def test_set_tree_node():
    import pytest
    mapping = tree()
    set_tree_node(mapping, 'one:two:three:four', 'good')
    set_tree_node(mapping, 'one:two:three:five', 'bad')
    set_tree_node(mapping, 'one:two:three:six', 10)
    set_tree_node(mapping, 'one:two:three:seven', dict(a=2, b=3))

    expected = tree()
    expected['one']['two']['three']['four'] = 'good'
    expected['one']['two']['three']['five'] = 'bad'
    expected['one']['two']['three']['six'] = 10

# Generated at 2022-06-12 08:25:33.041882
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(collections.defaultdict)
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree['a']['b']['c'] == 'd'



# Generated at 2022-06-12 08:25:38.007194
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 100,
            }
        }
    }

    assert 100 == get_tree_node(mapping, 'a:b:c')
    assert mapping['a'] == get_tree_node(mapping, 'a:b')



# Generated at 2022-06-12 08:25:46.940543
# Unit test for function get_tree_node
def test_get_tree_node():
    input = {
        'a': {
            'b': {
                'c': 'val'
            }
        }
    }

    # Test direct access
    assert get_tree_node(input, 'a:b:c') == 'val', 'Direct access'
    # No default provided
    with pytest.raises(KeyError):
        get_tree_node(input, 'a:b:c:d')
    # Default provided
    assert get_tree_node(input, 'a:b:c:d', default='arbitrary') == 'arbitrary', 'Default'
    # Parent
    assert get_tree_node(input, 'a:b:c:d', default='arbitrary', parent=True) == {'c': 'val'}



# Generated at 2022-06-12 08:25:53.915159
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'parent': {
            'child': {
                'grandchild': 'grandchild_value'
            }
        }
    }

    # Test basic retrieval
    assert get_tree_node(data, 'parent:child:grandchild') == 'grandchild_value'
    # Test returning parent
    assert get_tree_node(data, 'parent:child:grandchild', parent=True) == {'grandchild': 'grandchild_value'}



# Generated at 2022-06-12 08:26:02.898456
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function `set_tree_node` to ensure it creates all provided keys and sets the value.
    Returns:
        None
    """
    mapping = tree()
    set_tree_node(mapping, 'test:foreign:test', 'foo')
    assert mapping['test']['foreign']['test'] == 'foo'
    assert mapping == {'test': {'foreign': {'test': 'foo'}}}

    # Test that existing paths are not overwritten, but only filled in
    set_tree_node(mapping, 'test:foreign:test:baz', 'foo')
    assert mapping['test']['foreign']['test'] == 'foo'
    assert mapping['test']['foreign']['test']['baz'] == 'foo'

    # Test parent node retrieval
    assert set_tree_

# Generated at 2022-06-12 08:26:06.111713
# Unit test for function set_tree_node
def test_set_tree_node():
    my_map = tree()
    my_map['a']['b']['c'] = True
    assert set_tree_node(my_map, 'a:b:c', False)['c'] is False



# Generated at 2022-06-12 08:26:15.912445
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c') == 1



# Generated at 2022-06-12 08:26:19.735525
# Unit test for function get_tree_node
def test_get_tree_node():
    x = {'a': {'b': {'c': {'x': 1, 'y': 2, 'z': 3}}}}
    assert get_tree_node(x, 'a:b:c:x') == 1
    assert get_tree_node(x, 'a:b:c:z') == 3

# Generated at 2022-06-12 08:26:28.008401
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test for KeyError
    with pytest.raises(KeyError):
        get_tree_node({}, 'somekey')

    # Test for default value
    default = object()
    assert default is get_tree_node({}, 'somekey', default=default)

    # Test for normal functionality
    item = object()
    assert item is get_tree_node({'somekey': item}, 'somekey')

    # Test for multiple dimensions
    item = object()
    assert item is get_tree_node({'sub_tree': {'another_tree': {'some_key': item}}}, 'sub_tree:another_tree:some_key')



# Generated at 2022-06-12 08:26:51.679223
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    # TODO Support for nested unit tests.
    tree_dict = tree()
    set_tree_node(tree_dict, 'foo:bar:baz', 'qux')
    assert tree_dict['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-12 08:27:01.044012
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    items = ('key', 'value')
    set_tree_node(tree, 'key', 'value')
    assert tree == {'key': 'value'}

    items = ('foo:bar', 'baz')
    set_tree_node(tree, 'foo:bar', 'baz')
    assert tree == {'key': 'value', 'foo': {'bar': 'baz'}}

    set_tree_node(tree, 'foo:bar:baz:bap', 'baa')
    assert tree == {'key': 'value', 'foo': {'bar': {'baz': {'bap': 'baa'}}}}



# Generated at 2022-06-12 08:27:04.425488
# Unit test for function set_tree_node
def test_set_tree_node():
    foo = {}
    set_tree_node(foo, 'a:b:c', 'foo')
    assert foo == {
        'a': {
            'b': {
                'c': 'foo'
            }
        }
    }



# Generated at 2022-06-12 08:27:11.841824
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': 'ok',
                },
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c:d') == 'ok'
    assert get_tree_node(mapping, 'a:b:c')['d'] == 'ok'
    assert get_tree_node(mapping, 'a:b:c:d:e', default=None) is None
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:c:d:e')

# Generated at 2022-06-12 08:27:19.255772
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_mapping = {
        'a': {
            'b': {
                'c': 'd'
            },
            'e': 'f'
        }
    }

    assert get_tree_node(tree_mapping, 'a:b:c') == 'd'
    assert get_tree_node(tree_mapping, 'a:e') == 'f'
    assert get_tree_node(tree_mapping, 'a:e:f', default=_sentinel) == _sentinel
    assert get_tree_node(tree_mapping, 'a:e:f', default='g') == 'g'

# Generated at 2022-06-12 08:27:28.091355
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 123,
            'baz': {
                'qux': 456,
                'lol': 'foo',
            },
        },
    }

    assert get_tree_node(mapping, 'foo') == {
        'bar': 123,
        'baz': {
            'qux': 456,
            'lol': 'foo',
        },
    }

    assert get_tree_node(mapping, 'foo:bar') == 123
    assert get_tree_node(mapping, 'foo:baz') == {
        'qux': 456,
        'lol': 'foo',
    }

    assert get_tree_node(mapping, 'foo:baz:qux') == 456

# Generated at 2022-06-12 08:27:37.622482
# Unit test for function get_tree_node
def test_get_tree_node():
    import unittest

    class GetTreeNodeTest(unittest.TestCase):

        def setUp(self):
            self.mapping = {
                'a': 1,
                'b': 2,
                'c': {
                    'd': 4,
                    'e': 5,
                },
                'f': ['g', 'h', 'i'],
            }

        def test_get_leaf_node(self):
            self.assertEqual(get_tree_node(self.mapping, 'a'), 1)
            self.assertEqual(get_tree_node(self.mapping, 'b'), 2)

        def test_get_g_node(self):
            self.assertEqual(get_tree_node(self.mapping, 'f:0'), 'g')
            self.assertEqual

# Generated at 2022-06-12 08:27:42.803321
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    assert set_tree_node(d, 'test:test:test', 'value') == {'test': {'test': {'test': 'value'}}}
    assert set_tree_node(d, 'test1:test2', 'value2') == {'test1': {'test2': 'value2'}}



# Generated at 2022-06-12 08:27:52.929725
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node.

    :return:
    """

    # Define a mapping to test with
    test_mapping = {
        'foo': 'bar',
        'bar': {
            'baz': 'quux',
            'quux': {
                'fuz': 'faz',
                'faz': {
                    'faz': 'foo'
                }
            }
        }
    }

    # Test simple retrieval
    assert get_tree_node(test_mapping, 'foo') == 'bar'

    # Test nested retrieval
    assert get_tree_node(test_mapping, 'bar:baz') == 'quux'

    # Test nested retrieval of non-existent item

# Generated at 2022-06-12 08:27:57.399272
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', parent=True) == {'bar': 'baz'}



# Generated at 2022-06-12 08:28:45.007139
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'quz'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'quz'
    assert get_tree_node(mapping, 'foo', default=None)
    assert get_tree_node(mapping, 'foo:bar:baz', default=None)
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == 'quz'
    assert get_tree_node(mapping, 'foo:bar:baz', default=None, parent=True) is None



# Generated at 2022-06-12 08:28:53.816226
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()

    # Test funny corner cases for set_tree_node
    set_tree_node(mapping, 'foo', 'bar')
    assert get_tree_node(mapping, 'foo') == 'bar'

    set_tree_node(mapping, 'baz.zap.zop', 'gum')
    assert get_tree_node(mapping, 'baz.zap.zop') == 'gum'

    set_tree_node(mapping, 'baz.zap.zor.baz', 'zap')
    assert get_tree_node(mapping, 'baz.zap.zor.baz') == 'zap'
    assert get_tree_node(mapping, 'baz.zap.zor') == {'baz': 'zap'}
   

# Generated at 2022-06-12 08:28:56.016244
# Unit test for function set_tree_node
def test_set_tree_node():
    """TODO: Docstring for set_tree_node.
    :returns: TODO

    """
    assert False



# Generated at 2022-06-12 08:29:01.288286
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}

    set_tree_node(tree, 'foo', 'bar')
    set_tree_node(tree, 'foo', 'bar')
    assert tree.get('foo') == 'bar'

    set_tree_node(tree, 'foo:bar:baz', 'quux')
    assert tree.get('foo').get('bar').get('baz') == 'quux'



# Generated at 2022-06-12 08:29:04.461498
# Unit test for function set_tree_node
def test_set_tree_node():
    obj = {}
    value = object()
    set_tree_node(obj, 'foo:bar:baz', value)
    assert obj == {'foo': {'bar': {'baz': value}}}



# Generated at 2022-06-12 08:29:12.508146
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar', 1)
    set_tree_node(tree, 'foo:baz', 2)
    assert tree == {'foo': {'bar': 1, 'baz': 2}}
    assert set_tree_node(tree, 'foo:bar:foo:bar:foo:bar', 3) == {'bar': 3, 'foo': {'bar': 3}}
    assert tree == {'foo': {'bar': {'foo': {'bar': {'foo': {'bar': 3}}}}, 'baz': 2}}



# Generated at 2022-06-12 08:29:18.398998
# Unit test for function get_tree_node
def test_get_tree_node():
    # Arrange
    data = {
        'foo': {
            'bar': 'baz'
        }
    }

    # Act
    result = get_tree_node(data, 'foo:bar')
    result_fail = get_tree_node(data, 'foo:baz')

    # Assert
    assert result == 'baz'
    with pytest.raises(KeyError):
        result_fail



# Generated at 2022-06-12 08:29:27.291533
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'hi': 1}, 'hi') == 1
    assert get_tree_node({'hi': {'there': 1}}, 'hi:there') == 1
    assert get_tree_node({'hi:there': 1}, 'hi:there') == 1
    assert get_tree_node({'hi:there': {'dude': 1}}, 'hi:there:dude') == 1
    assert get_tree_node({'hi': 1}, 'hi:there:dude', default=_sentinel) == _sentinel
    assert get_tree_node({'hi': 1}, 'hi:there:dude', default=0) == 0
    # parent
    assert get_tree_node({'hi': {'there': {'dude': 1}}}, 'hi:there:dude', parent=True)

# Generated at 2022-06-12 08:29:36.221998
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': '1',
            'baz': '2',
            'yolo': {
                'swag': '3'
            }
        }
    }
    assert get_tree_node(tree, 'foo') == {
        'bar': '1',
        'baz': '2',
        'yolo': {
            'swag': '3'
        }
    }

    assert get_tree_node(tree, 'foo:bar') == '1'
    assert get_tree_node(tree, 'foo:yolo:swag') == '3'
    assert get_tree_node(tree, 'foo:yolo:swag:foo') is _sentinel


# Generated at 2022-06-12 08:29:40.302861
# Unit test for function get_tree_node
def test_get_tree_node():
    from collections import defaultdict

    tree = defaultdict(dict)
    tree['foo']['bar'] = 'baz'

    assert get_tree_node(tree, 'foo') == {'bar': 'baz'}
    assert get_tree_node(tree, 'foo:bar') == 'baz'
    assert get_tree_node(tree, 'foo:baz') is None

