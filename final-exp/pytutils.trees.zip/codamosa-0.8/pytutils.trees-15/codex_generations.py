

# Generated at 2022-06-12 08:20:05.015300
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {'a': {}}
    assert set_tree_node(tree, 'b:c', 'value') == {'a': {}, 'b': {'c': 'value'}}



# Generated at 2022-06-12 08:20:10.160520
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        'foo': {
            'bar': 1,
            'baz': 2
        }
    }

    set_tree_node(mapping, 'foo:bar', 'quux')
    assert mapping['foo']['bar'] == 'quux'

    set_tree_node(mapping, 'bar:baz', 5)
    assert mapping['bar']['baz'] == 5

    set_tree_node(mapping, 'kaboom', [])
    assert mapping['kaboom'] == []



# Generated at 2022-06-12 08:20:17.081191
# Unit test for function get_tree_node
def test_get_tree_node():
    testdata = dict(
        a=dict(
            b=dict(
                c=1,
            ),
        ),
    )

    assert get_tree_node(testdata, 'a') == dict(b=dict(c=1))
    assert get_tree_node(testdata, 'a:c') is _sentinel
    assert get_tree_node(testdata, 'a:c', default=None) is None
    assert get_tree_node(testdata, 'a:b', default=None) == dict(c=1)
    assert get_tree_node(testdata, 'a:b:c', default=None) == 1



# Generated at 2022-06-12 08:20:21.409596
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        },
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:d') is _sentinel



# Generated at 2022-06-12 08:20:32.821563
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 'o' == get_tree_node({'a': 'o'}, 'a')  # Test for single dimension key
    assert 'o' == get_tree_node({'a': {'b': 'o'}}, 'a:b')  # Test for double dimension key
    assert 'o' == get_tree_node({'a': {'b': {'c': 'o'}}}, 'a:b:c')  # Test for 3 dimensions
    assert 'o' == get_tree_node({'a': {'b': {'c': 'o'}}}, 'a:b:c:d')  # Test for too many dimensions
    assert 'o' == get_tree_node({'a': {'b': {'c': 'o'}}}, 'a:b:d:c')  # Test for different order dimensions


# Generated at 2022-06-12 08:20:35.646989
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'foo')
    assert mapping == {'a': {'b': {'c': 'foo'}}}



# Generated at 2022-06-12 08:20:45.548269
# Unit test for function get_tree_node
def test_get_tree_node():
    """Tests for :func:`get_tree_node`."""
    assert get_tree_node(tree, 'foo') == {}
    assert get_tree_node(tree(), 'foo:bar') == {}
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': tree()}, 'foo:bar:baz') == {}
    assert get_tree_node({'foo': tree()}, 'foo:bar:baz', default='no node') == 'no node'
    assert get_tree_node({}, 'foo:bar:baz', default='no node') == 'no node'



# Generated at 2022-06-12 08:20:49.745679
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {
        'b': {
            'c': 'd',
        }
    }

    assert get_tree_node(a, 'b:c') == 'd'
    assert get_tree_node(a, 'c:b') is None



# Generated at 2022-06-12 08:20:57.283056
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['aisle']['section']['shelf']['book'] = {'title': 'The Alchemist'}
    assert(get_tree_node(data, 'aisle:section:shelf:book:title') == 'The Alchemist')
    assert(get_tree_node(data, 'aisle:section:shelf:book', default='nope') == {'title': 'The Alchemist'})
    assert(get_tree_node(data, 'aisle:section:shelf:book:author', default='nope') == 'nope')
    with pytest.raises(KeyError):
        get_tree_node(data, 'aisle:section:shelf:book:author')



# Generated at 2022-06-12 08:21:05.435223
# Unit test for function set_tree_node
def test_set_tree_node():
    """test_set_tree_node"""
    original = {
        'clients': {
            'redis': {
                'client': 'aio_redis.RedisClient',
                'endpoint': 'redis://:password@10.1.1.1:6112/0',
                'connector': 'aio_redis.RedisConnector',
            },
            'seed': {
                'client': 'seth.networking.zmq.tree.ZmqClient',
                'endpoint': 'tcp://10.1.1.1:6112',
            }
        }
    }

# Generated at 2022-06-12 08:21:13.218172
# Unit test for function set_tree_node
def test_set_tree_node():
    data = tree()

    set_tree_node(data, 'a:b:c:d:e', 5)
    assert data['a']['b']['c']['d']['e'] == 5, 'Tree node setter has failed.'



# Generated at 2022-06-12 08:21:16.213777
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['a']['b']['c'] = 'd'

    assert get_tree_node(mapping, 'a:b')['c'] == 'd'



# Generated at 2022-06-12 08:21:24.919338
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': {'baz': {'qux': 'quux'}}}, 'foo:baz:qux') == 'quux'
    assert get_tree_node({'foo': {'baz': {'qux': 'quux'}}}, 'foo:baz:qux:bar') is _sentinel
    assert get_tree_node({'foo': {'baz': {'qux': 'quux'}}}, 'foo:baz:qux:bar', None) is None
    assert get_tree_node({'foo': {'baz': {'qux': 'quux'}}}, 'foo:baz:qux', None) == 'quux'
    assert get_

# Generated at 2022-06-12 08:21:34.532670
# Unit test for function get_tree_node
def test_get_tree_node():
    from collections import namedtuple
    from .helpers import random_string
    from . import assert_equal

    # Setup
    tree = namedtuple('Tree', 'a b c')

    node = tree(
        tree(
            # Node
            tree(
                a='A',
                b='B',
                c='C',
            ),
        ),
    )

    # Test simple get
    assert_equal(
        get_tree_node(node, 'a:a:a'),
        'A'
    )

    # Test weird key
    random_str = random_string()
    assert_equal(
        get_tree_node(node, random_str),
        _sentinel
    )

    # Test default

# Generated at 2022-06-12 08:21:43.083970
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['a']['b']['c'] = 'd'
    assert get_tree_node(data, 'a:b:c') == 'd'
    assert get_tree_node(data, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(data, 'a:b:c:d', default='e', parent=True) == data['a']['b']
    assert get_tree_node(data, 'a:b:c:d', parent=True) == data['a']['b']
    assert get_tree_node(data, 'a:b:d', parent=True) == data['a']



# Generated at 2022-06-12 08:21:53.424503
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test for function `set_tree_node`"""
    import unittest
    import json

    class TestSetTreeNode(unittest.TestCase):

        def test_set(self):
            d = tree()
            set_tree_node(d, 'foo', 'bar')
            self.assertEqual(d, {'foo': 'bar'})

        def test_set_deep(self):
            d = tree()
            set_tree_node(d, 'foo:bar', 'baz')
            self.assertEqual(json.dumps(d, indent=2), '{\n  "foo": {\n    "bar": "baz"\n  }\n}')

        def test_replace(self):
            d = tree()
            set_tree_node(d, 'foo', 'bar')


# Generated at 2022-06-12 08:22:02.010986
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({'a': 'b'}, 'a:b:c', 'd') == {'a': {'b': {'c': 'd'}}}
    assert set_tree_node({'a': {'b': 'c'}}, 'a:x:y', 'd') == {'a': {'b': 'c', 'x': {'y': 'd'}}}
    assert set_tree_node({'a': 'b'}, 'c:d:e', 'f') == {'a': 'b', 'c': {'d': {'e': 'f'}}}



# Generated at 2022-06-12 08:22:09.635612
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'A:B:C': 1,
        'A:D:E': 2,
        'A:D:F': 3
    }

    assert get_tree_node(mapping, 'A:D') == {'E': 2, 'F': 3}
    assert get_tree_node(mapping, 'A:D:X') is _sentinel
    assert get_tree_node(mapping, 'A:D:X', default="foo") == "foo"
    assert get_tree_node(mapping, 'A:D:E') == 2
    assert get_tree_node(mapping, 'A:D:E', parent=True) == {'E': 2, 'F': 3}

# Generated at 2022-06-12 08:22:14.904413
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'first', 'Top of tree')
    assert tree['first'] == 'Top of tree'
    set_tree_node(tree, 'first:level2', 'Level 2 of tree')
    assert tree['first']['level2'] == 'Level 2 of tree'



# Generated at 2022-06-12 08:22:20.033607
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': 'value'}}
    assert get_tree_node(mapping, 'foo:bar') == 'value'
    assert get_tree_node(mapping, 'foo:baz') is _sentinel
    assert get_tree_node(mapping, 'foo:baz', 'value') == 'value'



# Generated at 2022-06-12 08:22:37.065870
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test suite for `get_tree_node`.
    """
    tree = {'foo': {'bar': [1, 2, 3]}}

    # Test fetching multiple nodes (fetch bar first)
    assert get_tree_node(tree, 'foo') == tree['foo']
    assert get_tree_node(tree, 'foo:bar') == tree['foo']['bar']
    assert get_tree_node(tree, 'foo:bar:2') == 3

    # Test get_tree_node will raise exception for defaults
    with pytest.raises(IndexError):
        get_tree_node(tree, 'foo:bar:5')

    # Test get_tree_node will return default for exceptions
    assert get_tree_node(tree, 'foo:bar:5', default='test') == 'test'



# Generated at 2022-06-12 08:22:44.448121
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    <BLANKLINE>
    >>> tree = {'foo': {'bar': {'baz': 1}}}
    <BLANKLINE>
    >>> get_tree_node(tree, 'foo:bar:baz')
    1
    <BLANKLINE>
    >>> get_tree_node(tree, 'foo:bar')
    {'baz': 1}
    <BLANKLINE>
    >>> get_tree_node(tree, 'foo:bar:baz', parent=True)
    {'baz': 1}
    """



# Generated at 2022-06-12 08:22:48.083105
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': 1}}
    assert get_tree_node(mapping, 'a:b') == 1
    assert get_tree_node(mapping, 'b') is _sentinel



# Generated at 2022-06-12 08:22:51.276202
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equals
    test_dict = {'abc': {'def': {'hij': 'test'}}}
    assert_equals(get_tree_node(test_dict, 'abc:def:hij'), 'test')



# Generated at 2022-06-12 08:22:52.034398
# Unit test for function get_tree_node
def test_get_tree_node():
    pass


# Generated at 2022-06-12 08:23:03.657966
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test :py:func:`~utlz.functions.pytree.get_tree_node` against known good data."""
    test_data = {
        'foo': {
            'bar': [1, 2, 3],
            'baz': 4,
        },
    }

    # Test existing key
    assert get_tree_node(test_data, 'foo:bar') == test_data['foo']['bar']

    # Test incorrect existing key
    with pytest.raises(AssertionError):
        assert get_tree_node(test_data, 'foo:bar') == test_data['foo']['baz']

    # Test non-existent key
    with pytest.raises(KeyError):
        assert get_tree_node(test_data, 'foo:buz') is not None

# Generated at 2022-06-12 08:23:06.769335
# Unit test for function set_tree_node
def test_set_tree_node():
    m = {}
    set_tree_node(m, 'a:b:c', True)
    assert m == {'a': {'b': {'c': True}}}



# Generated at 2022-06-12 08:23:14.437747
# Unit test for function set_tree_node
def test_set_tree_node():
    import json
    import yaml

    dct = {}
    assert set_tree_node(dct, 'one:two:three', 3) == {'one': {'two': {'three': 3}}}
    assert dct == {'one': {'two': {'three': 3}}}

    dct = {}
    assert set_tree_node(dct, 'one:two:three', 3) == {'one': {'two': {'three': 3}}}
    assert set_tree_node(dct, 'one:two:four', 4) == {'one': {'two': {'three': 3, 'four': 4}}}
    assert dct == {'one': {'two': {'three': 3, 'four': 4}}}


# Generated at 2022-06-12 08:23:16.317751
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping['foo:bar'] == 'baz'

# Generated at 2022-06-12 08:23:26.207029
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(d, 'a:b:c') == 'd'
    assert get_tree_node(d, 'a:b:c:d') == _sentinel
    assert get_tree_node(d, 'a:b:c:d', 'e') == 'e'

    assert get_tree_node(d, 'a') == {'b': {'c': 'd'}}
    assert get_tree_node(d, 'a:b') == {'c': 'd'}
    assert get_tree_node(d, 'a:b:c', parent=True) == {'c': 'd'}
    assert get_tree_node(d, 'a:b:c:d', parent=True)

# Generated at 2022-06-12 08:23:44.777661
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {'l': {'l2': 'test'}}
    assert get_tree_node(t, 'l:l2') == 'test'
    assert get_tree_node(t, 'l:l2', default=None) == 'test'
    assert get_tree_node(t, 'l:l2', default=_sentinel) == 'test'
    assert get_tree_node(t, 'l:l2', default=_sentinel, parent=True) == {'l2': 'test'}
    assert get_tree_node(t, 'l:l3', default=_sentinel) == _sentinel
    assert get_tree_node(t, 'l:l3') is None
    assert get_tree_node(t, 'l:l3', default=None) is None
    assert get

# Generated at 2022-06-12 08:23:52.620505
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'key1': {
            'key1-1': 'value',
            'key1-2': 'value',
            'key1-3': 'value',
        },
        'key2': {
            'key2-1': 'value',
            'key2-2': 'value',
            'key2-3': 'value',
        }
    }

    assert get_tree_node(tree, 'key2:key2-1') == 'value'
    assert get_tree_node(tree, 'key2:key2-1', 'value_default') == 'value'
    assert get_tree_node(tree, 'key3:key3-3', 'value_default') == 'value_default'

# Generated at 2022-06-12 08:24:02.285202
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equal, assert_raises

    mapping = {'foo': 'bar',
               'bar': {'baz': 'lol'}
               }

    assert_equal(get_tree_node(mapping, 'foo'), 'bar')
    assert_equal(get_tree_node(mapping, 'bar:baz'), 'lol')
    assert_raises(KeyError, get_tree_node, mapping, 'bar:lol')
    assert_equal(get_tree_node(mapping, 'bar:lol', default='derp'), 'derp')
    assert_equal(get_tree_node(mapping, 'bar:lol', default='derp', parent=True), {'baz': 'lol'})

# Generated at 2022-06-12 08:24:12.973917
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_test = {
        'b': {
            'a': {
                'r': {
                    'c': {
                        'l': 1,
                    },
                    'u': 2,
                    'b': {
                        's': 3
                    },
                },
            },
        },
    }

    # Exists
    assert get_tree_node(tree_test, 'b:a:r:c:l') == 1
    assert get_tree_node(tree_test, 'b:a:r:u') == 2
    assert get_tree_node(tree_test, 'b:a:r:b:s') == 3

    # Not exists
    assert get_tree_node(tree_test, 'b:a:r:c:long', default=None) is None

    # KeyError

# Generated at 2022-06-12 08:24:15.416622
# Unit test for function set_tree_node
def test_set_tree_node():

    # Given
    mapping = {
        'a': {
            'b': 'foo',
            'c': 'bar',
        }
    }

    # When

# Generated at 2022-06-12 08:24:18.391047
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c:d', 123)
    assert d == {'a': {'b': {'c': {'d': 123}}}}



# Generated at 2022-06-12 08:24:28.265490
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        1: {
            2: {
                3: {
                    4: {
                        5: 'test',
                    },
                },
            },
        },
    }

    assert get_tree_node(mapping, '1:2:3:4:5') == 'test'
    assert get_tree_node(mapping, '1:2:3') == {4: {5: 'test'}}

    with pytest.raises(KeyError):
        get_tree_node(mapping, '1:2:3:4:5:6')

    assert get_tree_node(mapping, '1:2:3:4:5:6', default=False) == False



# Generated at 2022-06-12 08:24:37.855705
# Unit test for function set_tree_node
def test_set_tree_node():
    import json
    m = {}
    set_tree_node(m, 'a:b:c:d:e:f:g:h:i:j:k', 'k')
    expected = {'a': {'b': {'c': {'d': {'e': {'f': {'g': {'h': {'i': {'j': {'k': 'k'}}}}}}}}}}}
    assert expected == m
    set_tree_node(m, 'a:b:c:d:e:f:g:h:i:j:k', 'l')
    expected = {'a': {'b': {'c': {'d': {'e': {'f': {'g': {'h': {'i': {'j': {'k': 'l'}}}}}}}}}}}


# Generated at 2022-06-12 08:24:44.740339
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.defaultdict(dict)

    set_tree_node(mapping, 'foo', 'bar')
    set_tree_node(mapping, 'foo:baz', 'qux')
    set_tree_node(mapping, 'foo:baz:quux', 'garply')

    assert mapping['foo'] == {
        'baz': {
            'quux': 'garply'
        }
    }

# Generated at 2022-06-12 08:24:53.254105
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': {'b': {'c': '123'}}}
    value = get_tree_node(d, 'a:b:c')
    assert value == '123'

    d = {'a': {'b': {'c': '123'}}}
    value = get_tree_node(d, 'a:b:d')
    assert value is None

    d = {'a': {'b': {'c': '123'}}}
    value = get_tree_node(d, 'a:b:d', '456')
    assert value == '456'

    d = {'a': {'b': {'c': '123'}}}
    value = get_tree_node(d, 'a:b:d', _sentinel)
    assert value is _sentinel

    # Test parent functionality


# Generated at 2022-06-12 08:25:24.067037
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    b = set_tree_node(a, 'foo', 1)
    c = set_tree_node(a, 'foo:bar', 2)
    d = set_tree_node(a, 'foo:bar:baz', 3)
    e = set_tree_node(a, 'foo:bar:baz:boo', 4)
    f = set_tree_node(a, 'foo:bar:baz:bla', 5)
    g = set_tree_node(a, 'foo:bar:baz:zuw', 6)
    assert a == {'foo': {'bar': {'baz': {'boo': 4, 'bla': 5, 'zuw': 6}}}}
    assert b == a['foo']
    assert c == a['foo']['bar']
   

# Generated at 2022-06-12 08:25:30.528549
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node()."""
    mapping = {
        'a': {'b': {'c': {'d': 10, 'e': 11}, 'f': 12}},
        'g': {'h': {'i': 13, 'j': 14}},
        'k': {'l': {'m': 15, 'n': {'o': 16, 'p': 17}}},
        'q': 18
    }
    assert get_tree_node(mapping, 'a:b:c:d') == 10
    assert get_tree_node(mapping, 'a:b:c:d', None) == 10
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:c:d:e', None)

# Generated at 2022-06-12 08:25:37.723869
# Unit test for function get_tree_node
def test_get_tree_node():
    my_tree = {
        'who': 'who',
        'where': {
            'where': 'where',
            'when': {
                'when': 'when',
                'what': {
                    'what': 'what',
                    'why': {
                        'why': 'why',
                    },
                },
            },
        },
    }

    assert get_tree_node(my_tree, 'who') == 'who'
    assert get_tree_node(my_tree, ':who') == 'who'
    assert get_tree_node(my_tree, 'where:where') == 'where'
    assert get_tree_node(my_tree, 'where:when:when') == 'when'
    assert get_tree_node(my_tree, 'where:when:what')['what'] == 'what'

# Generated at 2022-06-12 08:25:43.994322
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a', 'foo')
    assert tree['a'] == 'foo'

    set_tree_node(tree, 'b:c:d', 'bar')
    assert tree['b']['c']['d'] == 'bar'

    set_tree_node(tree, 'b:c:d:e', 'baz')
    assert tree['b']['c']['d']['e'] == 'baz'

# Generated at 2022-06-12 08:25:51.433866
# Unit test for function set_tree_node
def test_set_tree_node():
    assertRegExp = unittest.TestCase().assertRegexpMatches

    # Create a new tree
    tree = collections.defaultdict(collections.defaultdict)
    assert id(set_tree_node(tree, 'hello:world', ':)')) == id(tree['hello'])
    assertRegExp(tree['hello']['world'], ':\\)')
    assert id(set_tree_node(tree, 'hello:world', ':)')) == id(tree['hello'])



# Generated at 2022-06-12 08:25:56.153812
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'foo', 1)
    set_tree_node(d, 'foo:bar', 2)
    set_tree_node(d, 'foo:bar:baz', 3)
    assert d == {'foo': {'bar': {'baz': 3}}}



# Generated at 2022-06-12 08:26:04.378420
# Unit test for function get_tree_node
def test_get_tree_node():
    import unittest
    import json


# Generated at 2022-06-12 08:26:08.389220
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {'a': {'b': {'c': 'd'}}}
    set_tree_node(a, 'e:f:g', 'h')
    assert a['e']['f']['g'] == 'h'



# Generated at 2022-06-12 08:26:18.486019
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['foo']['beep']['beep'] = 123456
    assert get_tree_node(t, 'foo:beep:beep') == 123456
    assert get_tree_node(t, 'foo:beep:beep', default=0) == 123456
    assert get_tree_node(t, 'foo:beep:bap', default=0) == 0
    assert get_tree_node(t, 'foo:beep:bap') == _sentinel
    assert get_tree_node(t, 'foo:beep:bap', parent=True) == {'beep': 123456}
    get_tree_node(t, 'foo:beep:bap', default=_sentinel)



# Generated at 2022-06-12 08:26:21.261767
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 'hello')
    assert t['a']['b']['c'] == 'hello'



# Generated at 2022-06-12 08:27:11.181125
# Unit test for function get_tree_node
def test_get_tree_node():
    '''
    Tests function `get_tree_node`
    '''
    # Passing test
    mapping1 = {'a': {'b': 2}}
    assert get_tree_node(mapping1, 'a:b') == 2
    assert get_tree_node(mapping1, 'a:b', default='default') == 2
    assert get_tree_node(mapping1, 'a:b', parent=True) == {'b': 2}
    assert get_tree_node(mapping1, 'c:b', default='default') == 'default'
    assert get_tree_node(mapping1, 'c:b') is None

    # Failing test
    mapping2 = {'a': {'b': 2}}

# Generated at 2022-06-12 08:27:18.148826
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', default='dflt') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:baz', default='dflt') == 'dflt'



# Generated at 2022-06-12 08:27:24.043926
# Unit test for function get_tree_node
def test_get_tree_node():
    # Given
    mapping = {
        'foo': {
            'bar': 'baz'
        }
    }

    # When, Then
    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:bar', default='spam') == 'baz'
    assert get_tree_node(mapping, 'foo:baz', default='eggs') == 'eggs'
    try:
        get_tree_node(mapping, 'foo:baz', default='eggs')
        assert False
    except KeyError:
        pass
    assert get_tree_node(mapping, 'foo', parent=True) == {'bar': 'baz'}



# Generated at 2022-06-12 08:27:34.443293
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': "hello",
        'b': {
            'c': "world",
            'd': 'foo'
        }
    }
    assert get_tree_node(mapping, 'a') == "hello"
    assert get_tree_node(mapping, 'b:c') == "world"
    assert get_tree_node(mapping, 'b:c') == "world"
    assert get_tree_node(mapping, 'b:d') == 'foo'
    assert get_tree_node(mapping, 'b:d', parent=True) == {'c': 'world', 'd': 'foo'}
    assert get_tree_node(mapping, 'b:e', default=True)
    assert get_tree_node(mapping, 'b:e') is None


# Generated at 2022-06-12 08:27:40.519684
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'test_key': 'test_value',
        'test_key2': 'test_value2',
        'test_key3': {
            'test_key4': 'x',
            'test_key5': 'y',
        },
        'test_key6': 'test_value6',
        'test_key7': {
            'test_key8': {
                'test_key9': 'a',
                'test_key10': 'b',
                'test_key11': {
                    'test_key12': 'c',
                },
            },
        },

    }
    assert get_tree_node(test_mapping, 'test_key') == 'test_value'

# Generated at 2022-06-12 08:27:44.788153
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'



# Generated at 2022-06-12 08:27:53.607173
# Unit test for function get_tree_node
def test_get_tree_node():
    from unittest import TestCase

    class TestGetTreeNode(TestCase):
        """Test suite for function get_tree_node()"""

        def setUp(self):
            self.test_tree = collections.defaultdict(dict)
            self.test_tree['a']['b']['c'] = 1
            self.test_tree['a']['b']['d'] = 2
            self.test_tree['a']['e'] = 3

        def test_root_key(self):
            """Test fetching root node"""
            expected = self.test_tree['a']
            value = get_tree_node(self.test_tree, 'a')
            self.assertEqual(value, expected)

        def test_first_level_key(self):
            """Test fetching from first level"""


# Generated at 2022-06-12 08:27:58.205077
# Unit test for function get_tree_node
def test_get_tree_node():
    config = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3
        }
    }

    assert get_tree_node(config, 'a') == 1
    assert get_tree_node(config, 'b:c') == 2
    assert get_tree_node(config, 'b:d') == 3



# Generated at 2022-06-12 08:28:09.076521
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'A:B:C', True)
    assert tree == {'A': {'B': {'C': True}}}
    set_tree_node(tree, 'A:B:C', False)
    assert tree == {'A': {'B': {'C': False}}}
    set_tree_node(tree, 'A:B:D', True)
    assert tree == {'A': {'B': {'C': False, 'D': True}}}
    set_tree_node(tree, 'A:B:F:G', False)
    assert tree == {'A': {'B': {'C': False, 'D': True, 'F': {'G': False}}}}
    set_tree_node(tree, 'A:B:F:G', True)

# Generated at 2022-06-12 08:28:11.752983
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test the function set_tree_node"""
    assert set_tree_node({}, "foo", "bar") == {'foo': 'bar'}



# Generated at 2022-06-12 08:29:47.568783
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'a:b:c:d')
    assert get_tree_node(tree(), 'a:b:c:d', default=True)
    with pytest.raises(KeyError):
        get_tree_node(tree(), 'a:b:c:d', parent=True)
    assert get_tree_node(tree(), 'a:b') is None



# Generated at 2022-06-12 08:29:50.242843
# Unit test for function set_tree_node
def test_set_tree_node():
    my_mapping = tree()
    set_tree_node(my_mapping, 'hey:there:man', 'woo')
    assert my_mapping['hey']['there']['man'] == 'woo'



# Generated at 2022-06-12 08:29:57.422786
# Unit test for function get_tree_node

# Generated at 2022-06-12 08:30:02.816584
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': 1}}
    assert get_tree_node(mapping, 'a:b') == 1
    assert get_tree_node(mapping, 'a:b', default=2) == 1
    assert get_tree_node(mapping, 'a:c') == _sentinel
    assert get_tree_node(mapping, 'a:c', default=2) == 2

