

# Generated at 2022-06-18 04:47:23.684601
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='default', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:47:27.613421
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d') is _sentinel
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:47:37.931964
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default=None) == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default=None, parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=None) is None
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=None, parent=True) is None

# Generated at 2022-06-18 04:47:46.320696
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:47:49.884670
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == _sentinel



# Generated at 2022-06-18 04:47:56.340604
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:48:00.259906
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    set_tree_node(test_tree, 'a:b:c', 'd')
    assert test_tree['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:48:04.423605
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d') == _sentinel
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:48:07.000605
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default=_sentinel) == _sentinel



# Generated at 2022-06-18 04:48:13.191371
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:48:22.514262
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping['foo']['bar'] == 'baz'



# Generated at 2022-06-18 04:48:26.971331
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'quux')
    assert mapping['foo']['bar']['baz'] == 'quux'



# Generated at 2022-06-18 04:48:30.440826
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:48:33.604029
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    set_tree_node(test_tree, 'a:b:c', 'd')
    assert test_tree['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:48:41.676876
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:48:44.173829
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='default', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:48:48.942497
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'



# Generated at 2022-06-18 04:48:54.886459
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'



# Generated at 2022-06-18 04:48:57.190224
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:49:01.318012
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'foo:bar:baz', 'qux')
    assert data == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:49:14.884486
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:49:22.285678
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:49:24.845235
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 'd')
    assert d['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:49:35.144319
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'

    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'

    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'

    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'

# Generated at 2022-06-18 04:49:41.113492
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='e') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:49:44.226368
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'value')
    assert mapping == {'a': {'b': {'c': 'value'}}}



# Generated at 2022-06-18 04:49:50.819907
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:49:53.352911
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(test_tree, 'foo:bar:baz') == 'qux'
    assert get_tree_node(test_tree, 'foo:bar:baz:quux') is _sentinel



# Generated at 2022-06-18 04:49:55.272215
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:49:59.017565
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:50:26.544799
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux:quux', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:bar:baz:qux:quux', default=_sentinel) == _sentinel



# Generated at 2022-06-18 04:50:29.885752
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:50:34.027437
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:50:38.663899
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel



# Generated at 2022-06-18 04:50:45.167776
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d') is _sentinel
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:50:55.862542
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    # Test basic functionality
    mapping = {'foo': {'bar': 'baz'}}
    assert get_tree_node(mapping, 'foo:bar') == 'baz'

    # Test default value
    assert get_tree_node(mapping, 'foo:bar:baz', default=None) is None

    # Test KeyError
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'foo:bar:baz')

    # Test parent
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'bar': 'baz'}

    # Test parent KeyError

# Generated at 2022-06-18 04:50:57.788139
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    set_tree_node(test_tree, 'a:b:c', 'd')
    assert test_tree['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:51:01.339024
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:51:10.681530
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}

    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:c:d')



# Generated at 2022-06-18 04:51:18.301503
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'foobarbaz'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='qux') == 'qux'



# Generated at 2022-06-18 04:51:59.172229
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node.
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:52:01.549006
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:52:09.187874
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:52:12.702737
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:52:19.823124
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'quux'
            }
        }
    }
    set_tree_node(mapping, 'foo:bar:baz', 'quux')
    set_tree_node(mapping, 'foo:bar:baz', 'quux')
    assert mapping == {
        'foo': {
            'bar': {
                'baz': 'quux'
            }
        }
    }



# Generated at 2022-06-18 04:52:22.405815
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:52:25.400874
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'test')
    assert tree['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:52:28.152620
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    set_tree_node(test_tree, 'a:b:c:d', 'e')
    assert test_tree['a']['b']['c']['d'] == 'e'



# Generated at 2022-06-18 04:52:30.870219
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node.
    """
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:52:35.517377
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:53:55.596870
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:54:03.886842
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default=None) is None
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:54:07.090213
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:54:15.519208
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:54:19.457090
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:54:22.037332
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'baz')
    assert mapping['foo']['bar']['baz'] == 'baz'



# Generated at 2022-06-18 04:54:24.396201
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:54:30.018438
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:54:37.925850
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': {
                    'qux': 'quux',
                },
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar:baz:qux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux:corge') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux:corge', default='grault') == 'grault'



# Generated at 2022-06-18 04:54:40.959593
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'

