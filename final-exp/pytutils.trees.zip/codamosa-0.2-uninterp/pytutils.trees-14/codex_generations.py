

# Generated at 2022-06-18 04:47:19.752286
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:47:24.129854
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'



# Generated at 2022-06-18 04:47:28.462426
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:47:38.786250
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node."""
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='e') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}

# Generated at 2022-06-18 04:47:42.321743
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    test_tree = tree()
    set_tree_node(test_tree, 'foo:bar:baz', 'test')
    assert test_tree['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:47:46.035830
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node.
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:47:48.879911
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:47:58.616453
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c', default='e') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d') == _sentinel
    assert get_tree_node(test_dict, 'a:b:c:d', default=_sentinel) == _sentinel



# Generated at 2022-06-18 04:48:00.577870
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node function."""
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:48:08.563086
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test tree
    tree = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    }

    # Test cases
    test_cases = (
        ('a:b:c:d', 'e'),
        ('a:b:c', {'d': 'e'}),
        ('a:b', {'c': {'d': 'e'}}),
        ('a', {'b': {'c': {'d': 'e'}}}),
        ('a:b:c:d:e', _sentinel),
    )

    # Test
    for key, expected in test_cases:
        assert get_tree_node(tree, key, default=_sentinel) == expected



# Generated at 2022-06-18 04:48:17.290588
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': 'e',
                },
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c:d') == 'e'



# Generated at 2022-06-18 04:48:28.072046
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    test_dict = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(test_dict, 'foo:bar:baz') == 'qux'
    assert get_tree_node(test_dict, 'foo:bar:baz', default='default') == 'qux'
    assert get_tree_node(test_dict, 'foo:bar:baz', default='default', parent=True) == {'baz': 'qux'}
    assert get_tree_node(test_dict, 'foo:bar:baz:quux', default='default') == 'default'

# Generated at 2022-06-18 04:48:36.712836
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    try:
        get_tree_node(mapping, 'a:b:c:d')
    except KeyError:
        pass
    else:
        assert False, 'KeyError not raised'



# Generated at 2022-06-18 04:48:45.278867
# Unit test for function get_tree_node
def test_get_tree_node():
    import unittest
    import mock

    class TestGetTreeNode(unittest.TestCase):
        def test_get_tree_node(self):
            mapping = {
                'foo': {
                    'bar': 'baz'
                }
            }
            self.assertEqual(get_tree_node(mapping, 'foo:bar'), 'baz')

        def test_get_tree_node_parent(self):
            mapping = {
                'foo': {
                    'bar': 'baz'
                }
            }
            self.assertEqual(get_tree_node(mapping, 'foo:bar', parent=True), {'bar': 'baz'})


# Generated at 2022-06-18 04:48:53.515096
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'baz',
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'baz'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='qux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == 'baz'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', parent=True) == {'baz': 'baz'}



# Generated at 2022-06-18 04:48:59.361117
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:49:02.942596
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar', 'baz')
    assert tree['foo']['bar'] == 'baz'



# Generated at 2022-06-18 04:49:11.806717
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    try:
        get_tree_node(mapping, 'a:b:c:d')
    except KeyError:
        pass
    else:
        assert False, 'KeyError not raised'



# Generated at 2022-06-18 04:49:22.883177
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    test_data = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f',
            },
            'g': 'h',
        },
        'i': 'j',
    }

    assert get_tree_node(test_data, 'a:b:c') == 'd'
    assert get_tree_node(test_data, 'a:b:e') == 'f'
    assert get_tree_node(test_data, 'a:g') == 'h'
    assert get_tree_node(test_data, 'i') == 'j'

    # Test default value
    assert get_tree_node(test_data, 'a:b:f', default='g') == 'g'

# Generated at 2022-06-18 04:49:25.838184
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default=_sentinel) is _sentinel



# Generated at 2022-06-18 04:49:40.711475
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar') == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:49:43.727284
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'value')
    assert mapping == {'foo': {'bar': {'baz': 'value'}}}



# Generated at 2022-06-18 04:49:48.116659
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node function."""
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:49:53.060718
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:50:01.404075
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test with a dict
    test_dict = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b') == {'c': 'd'}
    assert get_tree_node(test_dict, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}

    # Test with a defaultdict

# Generated at 2022-06-18 04:50:04.874066
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:50:15.497312
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'a:b:c:d', 'foo')
    assert mapping['a']['b']['c']['d'] == 'foo'

    mapping = tree()
    set_tree_node(mapping, 'a:b:c:d', 'foo')
    assert mapping['a:b:c:d'] == 'foo'

    mapping = tree()
    set_tree_node(mapping, 'a:b:c:d', 'foo')
    assert mapping['a:b:c']['d'] == 'foo'

    mapping = tree()
    set_tree_node(mapping, 'a:b:c:d', 'foo')

# Generated at 2022-06-18 04:50:18.672919
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node function."""
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:50:26.855839
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:50:37.088851
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) is _sentinel



# Generated at 2022-06-18 04:50:54.366232
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:50:56.950383
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:51:01.200872
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b:c') is _sentinel
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b:c', default='d') == 'd'
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b:c', default='d', parent=True) == {'b': 'c'}



# Generated at 2022-06-18 04:51:05.574924
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:51:09.355616
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:51:19.405451
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c', default='e') == 'd'
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d') == _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default=_sentinel) == _sentinel



# Generated at 2022-06-18 04:51:22.530267
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:51:28.442335
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'



# Generated at 2022-06-18 04:51:36.855330
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}

# Generated at 2022-06-18 04:51:39.640657
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:52:04.011971
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:52:10.441831
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    with pytest.raises(KeyError):
        get_tree_node(test_tree, 'a:b:c:d')



# Generated at 2022-06-18 04:52:16.458810
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    test_dict = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:52:23.832878
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:52:30.138913
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default=_sentinel) == _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default=_sentinel, parent=True) == tree['a']['b']



# Generated at 2022-06-18 04:52:35.192843
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:52:39.201740
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:52:41.659058
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:52:48.576531
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='e') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:52:54.971413
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:53:38.738670
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:53:47.357575
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    assert set_tree_node({}, 'a', 1) == {'a': 1}
    assert set_tree_node({}, 'a:b', 1) == {'a': {'b': 1}}
    assert set_tree_node({}, 'a:b:c', 1) == {'a': {'b': {'c': 1}}}
    assert set_tree_node({'a': {}}, 'a:b', 1) == {'a': {'b': 1}}
    assert set_tree_node({'a': {}}, 'a:b:c', 1) == {'a': {'b': {'c': 1}}}

# Generated at 2022-06-18 04:53:49.145759
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    tree = {}
    set_tree_node(tree, 'foo:bar', 'baz')
    assert tree['foo']['bar'] == 'baz'



# Generated at 2022-06-18 04:53:52.195832
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:53:58.164948
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    test_dict = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    set_tree_node(test_dict, 'foo:bar:baz', 'quux')
    assert test_dict['foo']['bar']['baz'] == 'quux'



# Generated at 2022-06-18 04:54:05.833826
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default=None) == 'd'
    assert get_tree_node(mapping, 'a:b:c', default=None, parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c', default=None, parent=False) == 'd'
    assert get_tree_node(mapping, 'a:b:c', default=None, parent=True) == {'c': 'd'}

# Generated at 2022-06-18 04:54:11.481066
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping['foo']['bar'] == 'baz'



# Generated at 2022-06-18 04:54:17.794104
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'



# Generated at 2022-06-18 04:54:23.988243
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    test_dict = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    }
    assert get_tree_node(test_dict, 'a:b:c:d') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d:e') is _sentinel



# Generated at 2022-06-18 04:54:31.496061
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test for simple key
    assert get_tree_node({'a': 1}, 'a') == 1

    # Test for nested key
    assert get_tree_node({'a': {'b': 2}}, 'a:b') == 2

    # Test for nested key with default
    assert get_tree_node({'a': {'b': 2}}, 'a:c', default=3) == 3

    # Test for nested key with default
    assert get_tree_node({'a': {'b': 2}}, 'a:c', default=3) == 3

    # Test for nested key with default
    assert get_tree_node({'a': {'b': 2}}, 'a:c', default=3) == 3

    # Test for nested key with default

# Generated at 2022-06-18 04:56:00.940106
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_data, 'a:b:c') == 'd'
    assert get_tree_node(test_data, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_data, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:56:03.169205
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:56:09.111770
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function `set_tree_node`
    """
    mapping = {}
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-18 04:56:13.974743
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node
    """
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:56:19.734910
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=None) is None

    try:
        get_tree_node(mapping, 'foo:bar:baz:quux')
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised')



# Generated at 2022-06-18 04:56:28.704593
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d') is _sentinel
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default=None) is None



# Generated at 2022-06-18 04:56:38.197000
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node.
    """
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:56:40.036924
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:56:48.197345
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'



# Generated at 2022-06-18 04:56:55.492413
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default=None) == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default=None, parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=None) is None
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=None, parent=True) == {'baz': 'qux'}