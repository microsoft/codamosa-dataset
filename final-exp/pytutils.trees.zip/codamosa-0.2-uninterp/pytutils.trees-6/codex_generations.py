

# Generated at 2022-06-18 04:47:23.572668
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:47:25.709206
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:47:30.661646
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:47:39.899561
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    test_dict = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(test_dict, 'foo:bar:baz') == 'qux'
    assert get_tree_node(test_dict, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(test_dict, 'foo:bar:quux', default='quux') == 'quux'
    assert get_tree_node(test_dict, 'foo:bar:quux') == KeyError



# Generated at 2022-06-18 04:47:46.908988
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='e') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:47:50.905069
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:47:57.604115
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:48:05.046590
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:48:06.672653
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:48:12.540944
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node
    """
    test_dict = {}
    set_tree_node(test_dict, 'foo:bar:baz', 'test')
    assert test_dict['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:48:18.712570
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:48:26.642238
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:48:36.436861
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:48:37.656339
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping == {'foo': {'bar': {'baz': 'test'}}}



# Generated at 2022-06-18 04:48:44.037239
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:48:53.394765
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') == _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:49:01.560044
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d') is _sentinel
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:49:11.467667
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default=None) is None
    assert get_tree_node(tree, 'a:b:c:d') == 'd'
    assert get_tree_node(tree, 'a:b:c:d:e', default=None) is None
    assert get_tree_node(tree, 'a:b:c:d:e') == 'd'



# Generated at 2022-06-18 04:49:19.144021
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:49:25.433314
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:49:41.823931
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:e') == 'f'
    assert get_tree_node(mapping, 'a:b:f') is _sentinel
    assert get_tree_node(mapping, 'a:b:f', default='g') == 'g'
    assert get_tree_node(mapping, 'a:b:f', default='g', parent=True) == {'c': 'd', 'e': 'f'}



# Generated at 2022-06-18 04:49:50.838392
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:49:52.337674
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 'd')
    assert d == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:50:01.055924
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
            'baz': 'qux',
        },
        'bar': {
            'foo': 'baz',
        },
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'bar:foo') == 'baz'
    assert get_tree_node(mapping, 'foo:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:baz:qux', default='quux') == 'quux'

# Generated at 2022-06-18 04:50:05.256838
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:50:15.651935
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c:d', parent=True) == {'c': 'd'}

    with pytest.raises(KeyError):
        get_tree_node(tree, 'a:b:c:d')



# Generated at 2022-06-18 04:50:21.661954
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'baz'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'baz'
    assert get_tree_node(mapping, 'foo:bar:baz', default='default') == 'baz'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'baz'}
    assert get_tree_node(mapping, 'foo:bar:baz', default='default', parent=True) == {'baz': 'baz'}
    assert get_tree_node(mapping, 'foo:bar:baz:baz', default='default') == 'default'
    assert get_

# Generated at 2022-06-18 04:50:28.557850
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:50:38.240483
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}

    try:
        get_tree_node(mapping, 'a:b:c:d')
    except KeyError:
        pass
    else:
        assert False, 'KeyError not raised'



# Generated at 2022-06-18 04:50:42.161313
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node.
    """
    test_tree = tree()
    set_tree_node(test_tree, 'a:b:c', 'd')
    assert test_tree['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:51:09.167485
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node
    """
    mapping = {}
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-18 04:51:20.478091
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c') == 1
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c', default=2) == 1
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:d', default=2) == 2
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:d', default=2, parent=True) == {'c': 1}
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:d', default=2, parent=True) == {'c': 1}
    assert get_tree

# Generated at 2022-06-18 04:51:26.470927
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:51:31.103112
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    test_data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_data, 'a:b:c') == 'd'
    assert get_tree_node(test_data, 'a:b:c', default='e') == 'd'
    assert get_tree_node(test_data, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:51:33.636721
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:51:42.496278
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:51:49.514768
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:51:55.041298
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping == {'foo': {'bar': {'baz': 'test'}}}



# Generated at 2022-06-18 04:52:03.465736
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:e', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:e', default='e', parent=True) == {'c': 'd'}


# Generated at 2022-06-18 04:52:11.019798
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node
    """
    # Test for a simple case
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c') == 'd'

    # Test for a case where the key is not found
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel

    # Test for a case where the key is not found and default is set
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'

    # Test for a case where the

# Generated at 2022-06-18 04:52:44.772463
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar') == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == _sentinel



# Generated at 2022-06-18 04:52:47.760970
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:52:56.847706
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:53:01.595435
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': {
                            'f': 'g'
                        }
                    }
                }
            }
        }
    }
    set_tree_node(mapping, 'a:b:c:d:e:f', 'h')
    assert mapping['a']['b']['c']['d']['e']['f'] == 'h'



# Generated at 2022-06-18 04:53:10.313433
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:53:19.064909
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:53:23.921288
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:53:29.634720
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:53:37.658807
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node
    """
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c', default='e') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d') == _sentinel



# Generated at 2022-06-18 04:53:40.975603
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node"""
    tree = {}
    set_tree_node(tree, 'foo:bar', 'baz')
    assert tree == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-18 04:54:55.029056
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:55:05.418700
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    # Test with a simple dictionary
    d = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(d, 'a:b:c') == 'd'

    # Test with a simple dictionary and a default value
    d = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(d, 'a:b:d', default='e') == 'e'

    # Test with a simple dictionary and a default value
    d = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(d, 'a:b:c', default='e') == 'd'

    # Test with a simple dictionary and a default value

# Generated at 2022-06-18 04:55:13.459445
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    test_data = {
        'a': {
            'b': {
                'c': {
                    'd': 'e',
                },
            },
        },
    }
    assert get_tree_node(test_data, 'a:b:c:d') == 'e'
    assert get_tree_node(test_data, 'a:b:c:d:e', default='f') == 'f'
    with pytest.raises(KeyError):
        get_tree_node(test_data, 'a:b:c:d:e')



# Generated at 2022-06-18 04:55:21.028033
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:55:24.436691
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:55:29.515392
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:55:36.534249
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b') == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel



# Generated at 2022-06-18 04:55:39.688566
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'



# Generated at 2022-06-18 04:55:42.658038
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node.
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:55:45.149258
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}

