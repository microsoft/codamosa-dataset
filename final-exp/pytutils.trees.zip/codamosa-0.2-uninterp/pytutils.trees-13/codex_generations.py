

# Generated at 2022-06-18 04:47:26.104783
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    test_dict = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(test_dict, 'foo:bar:baz') == 'qux'
    assert get_tree_node(test_dict, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(test_dict, 'foo:bar:quux', default='quux') == 'quux'
    assert get_tree_node(test_dict, 'foo:bar:quux') == KeyError



# Generated at 2022-06-18 04:47:33.143085
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:47:37.074537
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:47:43.537605
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:47:50.129153
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:48:00.010015
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    # Test basic functionality
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'

    # Test default functionality
    assert get_tree_node({'foo': 'bar'}, 'baz', default='qux') == 'qux'

    # Test parent functionality
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', parent=True) == {'bar': 'baz'}

    # Test KeyError functionality
    with pytest.raises(KeyError):
        get_tree_node({'foo': 'bar'}, 'baz')



# Generated at 2022-06-18 04:48:01.635547
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:48:04.418828
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:48:07.247206
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:48:17.738458
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    }

    assert get_tree_node(test_dict, 'a:b:c:d') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d', default='f') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d:e', default='f') == 'f'
    assert get_tree_node(test_dict, 'a:b:c:d:e') == _sentinel



# Generated at 2022-06-18 04:48:26.495130
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping['a']['b']['c'] == 'd'
    set_tree_node(mapping, 'a:b:c', 'e')
    assert mapping['a']['b']['c'] == 'e'



# Generated at 2022-06-18 04:48:31.826376
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel



# Generated at 2022-06-18 04:48:34.187883
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping['foo']['bar'] == 'baz'



# Generated at 2022-06-18 04:48:43.997862
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel) == _sentinel

# Generated at 2022-06-18 04:48:51.887398
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:48:58.776526
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'

# Generated at 2022-06-18 04:49:08.437021
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:49:11.219916
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping['foo']['bar'] == 'baz'



# Generated at 2022-06-18 04:49:15.017551
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:49:25.296847
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c:d', parent=True) == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c:d') == 'd'
    assert get_tree_node(tree, 'a:b:c:d:e')

# Generated at 2022-06-18 04:49:31.877663
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    test_tree = tree()
    set_tree_node(test_tree, 'a:b:c', 'd')
    assert test_tree['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:49:38.315152
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:49:41.922349
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_data, 'a:b:c') == 'd'



# Generated at 2022-06-18 04:49:50.030131
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:baz') == _sentinel
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:baz', default='qux') == 'qux'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:baz', default='qux', parent=True) == {'bar': 'baz'}



# Generated at 2022-06-18 04:49:55.304785
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node.
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:50:05.012253
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default=None) == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=None) is None
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel) is _sentinel

# Generated at 2022-06-18 04:50:15.693414
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    # Test basic functionality
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'

    # Test default value
    assert get_tree_node(mapping, 'foo:bar:qux', default='quux') == 'quux'

    # Test parent node
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}

    # Test KeyError
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'foo:bar:qux')


#

# Generated at 2022-06-18 04:50:20.843969
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux') == 'quux'
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'foo:bar:quux')



# Generated at 2022-06-18 04:50:26.327357
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel



# Generated at 2022-06-18 04:50:29.725188
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:50:39.555290
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel



# Generated at 2022-06-18 04:50:50.416676
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='default') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='default', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='default') == 'default'

# Generated at 2022-06-18 04:50:57.502340
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'



# Generated at 2022-06-18 04:51:03.381051
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}

# Generated at 2022-06-18 04:51:10.336610
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:51:17.483485
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'



# Generated at 2022-06-18 04:51:21.295068
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node.
    """
    test_dict = {}
    set_tree_node(test_dict, 'foo:bar:baz', 'test')
    assert test_dict['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:51:24.759197
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test for function `set_tree_node`.
    """
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:51:30.133399
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:51:37.373735
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}


# Generated at 2022-06-18 04:51:50.108393
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c:d') == 'e'
    assert get_tree_node(tree, 'a:b:c:d:e') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d:e', default='f') == 'f'



# Generated at 2022-06-18 04:52:00.750052
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
            'baz': 'qux',
        },
        'qux': 'quux',
    }
    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:baz') == 'qux'
    assert get_tree_node(mapping, 'qux') == 'quux'
    assert get_tree_node(mapping, 'foo:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:qux', default='quux') == 'quux'

# Generated at 2022-06-18 04:52:05.888403
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:c:d')



# Generated at 2022-06-18 04:52:08.093944
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:52:16.864436
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:quux', parent=True) is _sentinel



# Generated at 2022-06-18 04:52:25.403159
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:quux', parent=True, default='quux') == 'quux'


#

# Generated at 2022-06-18 04:52:29.373658
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel



# Generated at 2022-06-18 04:52:35.151932
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default=None) == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default=None, parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default=None) is None

# Generated at 2022-06-18 04:52:37.844738
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d', default=None) is None



# Generated at 2022-06-18 04:52:46.693381
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    # Test basic functionality
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'

    # Test default value
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:d', default='e') == 'e'

    # Test parent node
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', parent=True) == {'c': 'd'}

    # Test KeyError

# Generated at 2022-06-18 04:53:17.669805
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'a:b:c', 'foo')
    assert mapping['a']['b']['c'] == 'foo'



# Generated at 2022-06-18 04:53:20.028658
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 'd')
    assert t['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:53:28.117050
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d') == 'd'



# Generated at 2022-06-18 04:53:32.017823
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping['foo']['bar'] == 'baz'



# Generated at 2022-06-18 04:53:34.930258
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:53:40.975030
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel) is _sentinel



# Generated at 2022-06-18 04:53:47.994681
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:53:55.762867
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node.
    """
    test_tree = tree()
    test_tree['a']['b']['c'] = 'd'
    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_tree, 'a:b:c:d', default='e', parent=True) == test_tree['a']['b']



# Generated at 2022-06-18 04:53:59.443953
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:54:04.831413
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:54:48.813938
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test that get_tree_node works as expected.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:54:51.456648
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz'
        }
    }
    assert get_tree_node(mapping, 'foo:bar') == 'baz'



# Generated at 2022-06-18 04:54:59.195075
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:55:09.110234
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:55:15.973567
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:quux') == 'quux'



# Generated at 2022-06-18 04:55:19.909601
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'test')
    assert tree['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:55:25.321933
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:55:28.112836
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:55:31.332900
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel



# Generated at 2022-06-18 04:55:40.603522
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node
    """
    mapping = {}
    set_tree_node(mapping, 'foo', 'bar')
    assert mapping == {'foo': 'bar'}

    mapping = {}
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping == {'foo': {'bar': 'baz'}}

    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping == {'foo': {'bar': {'baz': 'qux'}}}

    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz:qux', 'quux')