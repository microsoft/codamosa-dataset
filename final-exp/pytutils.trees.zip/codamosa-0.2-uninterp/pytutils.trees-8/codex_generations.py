

# Generated at 2022-06-18 04:47:23.801580
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c:d') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d:e') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d:e', default='f') == 'f'
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'d': 'e'}



# Generated at 2022-06-18 04:47:31.165269
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:quux') == 'quux'



# Generated at 2022-06-18 04:47:40.732993
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    # Test simple case
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c') == 'd'

    # Test default
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'

    # Test parent
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd'}

    # Test KeyError
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:c:d')



# Generated at 2022-06-18 04:47:43.501630
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node"""
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'test')
    assert tree['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:47:46.681584
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:47:55.504973
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel) == _sentinel



# Generated at 2022-06-18 04:48:05.238408
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f',
            },
            'g': 'h',
        },
        'i': 'j',
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:e') == 'f'
    assert get_tree_node(mapping, 'a:g') == 'h'
    assert get_tree_node(mapping, 'i') == 'j'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='x') == 'x'




# Generated at 2022-06-18 04:48:08.023705
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel) == _sentinel



# Generated at 2022-06-18 04:48:17.206396
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'

    with pytest.raises(KeyError):
        get_tree_node(mapping, 'foo:bar:baz:quux')



# Generated at 2022-06-18 04:48:27.976084
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test basic functionality
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'

    # Test default value
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'

    # Test parent node
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', parent=True) == {'c': 'd'}

    # Test KeyError
    with pytest.raises(KeyError):
        get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d')



# Generated at 2022-06-18 04:48:42.027985
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='default') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='default', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='default') == 'default'

# Generated at 2022-06-18 04:48:47.160194
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default=_sentinel) is _sentinel



# Generated at 2022-06-18 04:48:48.720142
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 'd')
    assert t['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:48:52.423121
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default=None) is None
    assert get_tree_node(mapping, 'a:b:c:d', default=None, parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:48:57.046449
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b:c', default='d') == 'd'
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b:c', default='d', parent=True) == {'b': 'c'}



# Generated at 2022-06-18 04:49:01.560515
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:49:07.667722
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:49:11.606554
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:49:19.816058
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default=None) is None
    assert get_tree_node(tree, 'a:b:c:d', default=False) is False



# Generated at 2022-06-18 04:49:26.124092
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'



# Generated at 2022-06-18 04:49:41.994352
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c', default='e') == 'd'
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d') == 'd'



# Generated at 2022-06-18 04:49:50.888549
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test for normal use
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'

    # Test for default value
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'

    # Test for parent node
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', parent=True) == {'c': 'd'}

    # Test for KeyError
    with pytest.raises(KeyError):
        get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d')


# Unit

# Generated at 2022-06-18 04:49:54.579125
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'



# Generated at 2022-06-18 04:50:02.452685
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel) == _sentinel



# Generated at 2022-06-18 04:50:08.748758
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:50:16.184793
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel



# Generated at 2022-06-18 04:50:19.934555
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:50:28.224047
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:50:31.219717
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:50:39.228240
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='e') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:d') == KeyError



# Generated at 2022-06-18 04:50:59.915585
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:51:02.324957
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:51:10.708259
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:51:13.638656
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:51:20.985533
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel) is _sentinel



# Generated at 2022-06-18 04:51:25.121888
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:51:31.496850
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:51:37.752350
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux', parent=True) == {'baz': 'qux'}

# Generated at 2022-06-18 04:51:46.493111
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux', parent=True) == {'baz': 'qux'}

# Generated at 2022-06-18 04:51:53.236104
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c:d', parent=True) == {'c': 'd'}

# Generated at 2022-06-18 04:52:28.872742
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:52:40.139004
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node
    """
    test_dict = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    # Test basic functionality
    assert get_tree_node(test_dict, 'a:b:c') == 'd'

    # Test default value
    assert get_tree_node(test_dict, 'a:b:d', default='e') == 'e'

    # Test parent node
    assert get_tree_node(test_dict, 'a:b:c', parent=True) == {'c': 'd'}

    # Test KeyError
    with pytest.raises(KeyError):
        get_tree_node(test_dict, 'a:b:d')



# Generated at 2022-06-18 04:52:42.517484
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:52:45.030171
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar', 'baz')
    assert tree['foo']['bar'] == 'baz'



# Generated at 2022-06-18 04:52:52.729630
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'



# Generated at 2022-06-18 04:52:56.138112
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'value')
    assert mapping['foo']['bar']['baz'] == 'value'



# Generated at 2022-06-18 04:52:59.380602
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test for function set_tree_node
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:53:04.508474
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default=None) == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default=None) is None
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:53:10.590268
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'



# Generated at 2022-06-18 04:53:20.094384
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:54:51.411496
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d') == 'd'

# Generated at 2022-06-18 04:55:01.722138
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='default') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == KeyError
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel) == KeyError

# Generated at 2022-06-18 04:55:12.340982
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}


# Generated at 2022-06-18 04:55:20.304906
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node

    """
    test_dict = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:55:22.769733
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:55:28.333231
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default=None) == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=None) is None
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'



# Generated at 2022-06-18 04:55:36.205508
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:55:38.534895
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:55:41.017396
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 'd')
    assert d['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:55:46.972491
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d') == 'd'

