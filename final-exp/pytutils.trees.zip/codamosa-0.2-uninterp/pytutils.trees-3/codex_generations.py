

# Generated at 2022-06-18 04:47:20.326318
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:47:25.486316
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:47:29.652565
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node function."""
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:47:32.638413
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:47:40.892505
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:47:47.701993
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
            'baz': {
                'qux': 'quux',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:baz:qux') == 'quux'
    assert get_tree_node(mapping, 'foo:baz:qux:quux', default='quuux') == 'quuux'
    assert get_tree_node(mapping, 'foo:baz:qux:quux') == 'quux'

# Generated at 2022-06-18 04:47:51.340951
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:48:00.135345
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default=None) is None
    assert get_tree_node(mapping, 'a:b:c:d', default=_sentinel) is _sentinel



# Generated at 2022-06-18 04:48:03.182834
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default=None) is None
    assert get_tree_node(mapping, 'a:b:c:d') == 'd'



# Generated at 2022-06-18 04:48:05.678971
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:48:16.992670
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default=None) is None
    assert get_tree_node(mapping, 'a:b:c:d', default=None, parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:48:20.957948
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'foo:bar:baz', 'test')
    assert test_dict['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:48:23.529994
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:48:31.212833
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c', default=None) == 'd'
    assert get_tree_node(tree, 'a:b:c', default=None, parent=True) == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c:d', default=None) is None
    assert get_tree_node(tree, 'a:b:c:d', default=None, parent=True) == {'c': 'd'}


#

# Generated at 2022-06-18 04:48:41.172263
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(data, 'a:b:c') == 'd'
    assert get_tree_node(data, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(data, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(data, 'a:b:c:d', parent=True) == {'c': 'd'}

    with pytest.raises(KeyError):
        get_tree_node(data, 'a:b:c:d')



# Generated at 2022-06-18 04:48:43.521172
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping == {'foo': {'bar': {'baz': 'test'}}}



# Generated at 2022-06-18 04:48:54.621031
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.

    Returns:
        bool: True if test passes.

    """
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}

    return True



# Generated at 2022-06-18 04:49:01.412634
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:49:11.326144
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux') == 'quux'

# Generated at 2022-06-18 04:49:17.935194
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:49:27.701230
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default=None) is None



# Generated at 2022-06-18 04:49:35.558883
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:49:38.983057
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node
    """
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:49:42.796063
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function
    """
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:49:49.576064
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel



# Generated at 2022-06-18 04:49:55.262027
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:50:00.237864
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:50:06.299318
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c:d') == 'e'
    assert get_tree_node(tree, 'a:b:c:d:e') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d:e', default='f') == 'f'
    assert get_tree_node(tree, 'a:b:c:d', parent=True) == {'d': 'e'}
    assert get_tree_node(tree, 'a:b:c:d', parent=True) == {'d': 'e'}

# Generated at 2022-06-18 04:50:12.106938
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel



# Generated at 2022-06-18 04:50:18.487890
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'

    try:
        get_tree_node(mapping, 'a:b:c:d')
    except KeyError:
        pass
    else:
        assert False, 'KeyError not raised'



# Generated at 2022-06-18 04:50:34.181443
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'



# Generated at 2022-06-18 04:50:39.834394
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == _sentinel



# Generated at 2022-06-18 04:50:47.040524
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:50:51.990481
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel



# Generated at 2022-06-18 04:50:59.370961
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='default') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:qux', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:bar:qux') == KeyError



# Generated at 2022-06-18 04:51:07.017367
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel) == _sentinel



# Generated at 2022-06-18 04:51:08.993676
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:51:20.467759
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f',
            },
            'g': 'h',
        },
        'i': 'j',
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:e') == 'f'
    assert get_tree_node(mapping, 'a:g') == 'h'
    assert get_tree_node(mapping, 'i') == 'j'

    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd', 'e': 'f'}

# Generated at 2022-06-18 04:51:27.369653
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:51:31.412653
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:51:58.292712
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:52:06.200582
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:52:11.776939
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:52:15.573850
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:52:22.415237
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:52:27.961089
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b') == {'c': 'd'}
    assert get_tree_node(test_dict, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:52:37.126703
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:52:40.307479
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'a:b:c', 'd')
    assert data['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:52:47.875019
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node
    """
    test_tree = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f',
            },
            'g': 'h',
        },
        'i': 'j',
    }

    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:e') == 'f'
    assert get_tree_node(test_tree, 'a:g') == 'h'
    assert get_tree_node(test_tree, 'i') == 'j'


# Generated at 2022-06-18 04:52:57.133625
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default=None) is None
    assert get_tree_node(mapping, 'a:b:c:d') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:53:42.233918
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node.
    """
    # Test data
    test_data = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    # Test cases
    test_cases = (
        ('a:b:c', 'd'),
        ('a:b', {'c': 'd'}),
        ('a', {'b': {'c': 'd'}}),
        ('a:b:c:d', KeyError),
    )

    # Run test cases
    for key, expected in test_cases:
        try:
            result = get_tree_node(test_data, key)
        except KeyError as exc:
            result = exc


# Generated at 2022-06-18 04:53:48.286057
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    tree = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz',
            },
        },
    }

    assert get_tree_node(tree, 'foo:bar:baz') == 'foobarbaz'
    assert get_tree_node(tree, 'foo:bar:baz:qux') == _sentinel
    assert get_tree_node(tree, 'foo:bar:baz:qux', default='foobarbazqux') == 'foobarbazqux'



# Generated at 2022-06-18 04:53:55.526779
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='default') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == KeyError



# Generated at 2022-06-18 04:54:02.642880
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
        },
        'bar': {
            'foo': 'baz',
        },
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'bar:foo') == 'baz'
    assert get_tree_node(mapping, 'foo:bar:baz') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz', default='baz') == 'baz'



# Generated at 2022-06-18 04:54:12.171012
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    test_data = {
        'a': {
            'b': {
                'c': 'd',
            },
            'e': 'f',
        },
        'g': 'h',
    }

    assert get_tree_node(test_data, 'a:b:c') == 'd'
    assert get_tree_node(test_data, 'a:e') == 'f'
    assert get_tree_node(test_data, 'g') == 'h'
    assert get_tree_node(test_data, 'a:b:c:d') is None
    assert get_tree_node(test_data, 'a:b:c:d', default='foo') == 'foo'

# Generated at 2022-06-18 04:54:20.399633
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node.
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:54:23.502783
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:54:31.146294
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c:d', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:54:37.925798
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
        }
    }
    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:bar', default='qux') == 'baz'
    assert get_tree_node(mapping, 'foo:baz', default='qux') == 'qux'
    assert get_tree_node(mapping, 'foo:baz') == _sentinel



# Generated at 2022-06-18 04:54:47.502463
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default=None) is None
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default=None) is None
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default=None) is None
    assert get_tree

# Generated at 2022-06-18 04:56:32.591539
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='e') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:56:40.493737
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    # Test basic functionality
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c') == 'd'

    # Test default value
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'

    # Test parent node
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd'}

    # Test KeyError
    try:
        get_tree_node(mapping, 'a:b:c:d')
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised')


# Unit test

# Generated at 2022-06-18 04:56:46.530816
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel



# Generated at 2022-06-18 04:56:52.270459
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:56:58.321616
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:57:04.724175
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:57:09.630942
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:57:15.860030
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == _sentinel

