

# Generated at 2022-06-18 04:47:25.226003
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c', default='e', parent=False) == 'd'

# Generated at 2022-06-18 04:47:33.191071
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=None) is None



# Generated at 2022-06-18 04:47:42.511811
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_tree, 'a:b:c:d') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d', parent=True) == {'c': 'd'}
    assert get_tree_node(test_tree, 'a:b:c:d', parent=True, default='e') == 'e'



# Generated at 2022-06-18 04:47:46.284142
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:47:50.829220
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel) == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=_sentinel, parent=True) == {'baz': 'qux'}

# Generated at 2022-06-18 04:47:58.572772
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    test_dict = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:48:02.455853
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    test_dict = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    assert get_tree_node(test_dict, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d') == _sentinel



# Generated at 2022-06-18 04:48:07.622092
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:48:12.835670
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'value')
    assert mapping == {'foo': {'bar': {'baz': 'value'}}}



# Generated at 2022-06-18 04:48:19.156328
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default=None) is None
    assert get_tree_node(mapping, 'a:b:c:d', default=None, parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:48:31.171090
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test simple case
    mapping = {'a': 1}
    assert get_tree_node(mapping, 'a') == 1

    # Test nested case
    mapping = {'a': {'b': 2}}
    assert get_tree_node(mapping, 'a:b') == 2

    # Test nested case with default
    mapping = {'a': {'b': 2}}
    assert get_tree_node(mapping, 'a:c', default=3) == 3

    # Test nested case with default and parent
    mapping = {'a': {'b': 2}}
    assert get_tree_node(mapping, 'a:c', default=3, parent=True) == {'b': 2}

    # Test nested case with default and parent
    mapping = {'a': {'b': 2}}

# Generated at 2022-06-18 04:48:33.920493
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:48:43.780870
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='e') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', default='e', parent=True) == {'c': 'd'}

# Generated at 2022-06-18 04:48:48.225322
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'value')
    assert mapping['foo']['bar']['baz'] == 'value'



# Generated at 2022-06-18 04:48:54.232559
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:48:56.420336
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:49:03.127161
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    # Test
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel



# Generated at 2022-06-18 04:49:09.132146
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel



# Generated at 2022-06-18 04:49:15.393435
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c', default='e') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_tree, 'a:b:c:d') == _sentinel



# Generated at 2022-06-18 04:49:19.305578
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    set_tree_node(test_tree, 'foo:bar:baz', 'test')
    assert test_tree['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:49:32.177167
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping['foo']['bar'] == 'baz'



# Generated at 2022-06-18 04:49:35.751040
# Unit test for function set_tree_node
def test_set_tree_node():
    test_mapping = {}
    set_tree_node(test_mapping, 'foo:bar:baz', 'test')
    assert test_mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:49:46.460592
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=False) == 'e'

# Generated at 2022-06-18 04:49:54.028051
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    test_mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_mapping, 'a:b:c') == 'd'
    assert get_tree_node(test_mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:49:56.357475
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar', 'baz')
    assert tree == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-18 04:50:00.314148
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel



# Generated at 2022-06-18 04:50:07.540164
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:50:14.680263
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default=None) is None



# Generated at 2022-06-18 04:50:20.297046
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='default') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == KeyError



# Generated at 2022-06-18 04:50:28.696604
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default=_sentinel) is _sentinel
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default=_sentinel, parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:50:49.675803
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node function."""
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:50:57.502977
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:51:01.283450
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:51:07.776245
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:51:11.130624
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 'd')
    assert t['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:51:18.655629
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    # Setup
    test_dict = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    }

    # Test
    assert get_tree_node(test_dict, 'a:b:c:d') == 'e'
    assert get_tree_node(test_dict, 'a:b:c:d:e') is _sentinel



# Generated at 2022-06-18 04:51:22.485883
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:51:27.232090
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:51:31.616438
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:51:36.082497
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:52:18.299588
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:52:24.505619
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node."""
    test_data = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(test_data, 'foo:bar:baz') == 'qux'
    assert get_tree_node(test_data, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(test_data, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:52:31.985211
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default=None) is None
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:quux', parent=True, default=None) is None



# Generated at 2022-06-18 04:52:36.450669
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:52:45.626398
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(tree, 'foo:bar:baz') == 'qux'
    assert get_tree_node(tree, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(tree, 'foo:bar:baz:qux') == 'qux'
    assert get_tree_node(tree, 'foo:bar:baz:qux', parent=True) == {'baz': 'qux'}
    assert get_tree_node(tree, 'foo:bar:baz:qux', parent=True, default='quux') == 'quux'
    assert get_tree_node

# Generated at 2022-06-18 04:52:54.859707
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:53:01.413706
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    tree = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:53:07.392199
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:53:17.777890
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux', parent=True) == {'baz': 'qux'}

# Generated at 2022-06-18 04:53:20.094225
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:55:04.890283
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:55:14.756290
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c') == 1
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c', default=2) == 1
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:d', default=2) == 2
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c', parent=True) == {'c': 1}
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:d', parent=True) == {'c': 1}

# Generated at 2022-06-18 04:55:24.426109
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True, default='quux') == {'baz': 'qux'}
    assert get

# Generated at 2022-06-18 04:55:28.698963
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node"""
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:55:36.062778
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node.
    """
    mapping = {
        'one': {
            'two': {
                'three': 'four'
            }
        }
    }
    assert get_tree_node(mapping, 'one:two:three') == 'four'
    assert get_tree_node(mapping, 'one:two:three', default='five') == 'four'
    assert get_tree_node(mapping, 'one:two:five', default='five') == 'five'
    assert get_tree_node(mapping, 'one:two:five') == KeyError



# Generated at 2022-06-18 04:55:42.120351
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz'
        }
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:bar:baz') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz', default='wut') == 'wut'
    assert get_tree_node(mapping, 'foo:bar:baz', default='wut', parent=True) == {'bar': 'baz'}



# Generated at 2022-06-18 04:55:50.397800
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux') == 'quux'

# Generated at 2022-06-18 04:55:54.521641
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node function."""
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:55:57.146384
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:56:04.340733
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default=_sentinel) == _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default=_sentinel, parent=True) == {'c': 'd'}

