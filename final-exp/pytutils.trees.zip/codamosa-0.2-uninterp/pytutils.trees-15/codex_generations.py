

# Generated at 2022-06-18 04:47:22.902661
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    """
    test_tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d', default=None) is None
    assert get_tree_node(test_tree, 'a:b:c:d') == 'd'



# Generated at 2022-06-18 04:47:32.048309
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    # Test basic set
    test_dict = {}
    set_tree_node(test_dict, 'foo', 'bar')
    assert test_dict['foo'] == 'bar'

    # Test set with dimension
    test_dict = {}
    set_tree_node(test_dict, 'foo:bar', 'baz')
    assert test_dict['foo']['bar'] == 'baz'

    # Test set with dimension and existing node
    test_dict = {'foo': {'bar': 'baz'}}
    set_tree_node(test_dict, 'foo:bar', 'baz')
    assert test_dict['foo']['bar'] == 'baz'

    # Test set with dimension and existing node

# Generated at 2022-06-18 04:47:40.692751
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': 'f'
                    }
                }
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c:d:e') == 'f'
    assert get_tree_node(mapping, 'a:b:c:d:e', default='g') == 'f'
    assert get_tree_node(mapping, 'a:b:c:d:e:f', default='g') == 'g'



# Generated at 2022-06-18 04:47:43.800395
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    mapping = tree()
    set_tree_node(mapping, 'a:b:c', 'value')
    assert mapping['a']['b']['c'] == 'value'



# Generated at 2022-06-18 04:47:54.883612
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    # Setup
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    # Test
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd'}

# Generated at 2022-06-18 04:47:59.629122
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test for `set_tree_node`
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:48:02.616349
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:c:d')



# Generated at 2022-06-18 04:48:08.267385
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:48:16.905614
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:48:26.802572
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:48:36.074471
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node function."""
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') is _sentinel



# Generated at 2022-06-18 04:48:40.249440
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test `set_tree_node` function.
    """
    test_mapping = {}
    set_tree_node(test_mapping, 'a:b:c', 'd')
    assert test_mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:48:47.457538
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test for KeyError
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default=None) is None
    assert get_tree_node(mapping, 'a:b:c:d', default=False) is False

    # Test for parent
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) is _sentinel
    assert get

# Generated at 2022-06-18 04:48:53.783634
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_data, 'a:b:c') == 'd'
    assert get_tree_node(test_data, 'a:b:c:d', default='e') == 'e'
    with pytest.raises(KeyError):
        get_tree_node(test_data, 'a:b:c:d')



# Generated at 2022-06-18 04:48:58.316822
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:49:03.323733
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'qux')
    assert tree == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-18 04:49:06.070179
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-18 04:49:10.211068
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:49:19.816269
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:baz', default='qux') == 'qux'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:baz', default='qux', parent=True) == {'bar': 'baz'}
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:baz', parent=True) == {'bar': 'baz'}
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:baz') == 'baz'

# Generated at 2022-06-18 04:49:22.882814
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:49:32.807440
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    # Initialize tree
    tree = {'a': {'b': {'c': 'd'}}}

    # Set tree node
    set_tree_node(tree, 'a:b:c', 'e')

    # Assert
    assert tree['a']['b']['c'] == 'e'



# Generated at 2022-06-18 04:49:39.125405
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'd',
            }
        }
    }
    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:49:49.265884
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:d', default='e', parent=True) == {'c': 'd'}

    with pytest.raises(KeyError):
        get_tree

# Generated at 2022-06-18 04:49:58.570621
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node."""
    tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:50:00.947857
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:50:08.339078
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:50:10.718511
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 'd')
    assert d['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:50:17.581383
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == 'qux'



# Generated at 2022-06-18 04:50:20.037018
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:50:25.418132
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:50:39.835407
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node
    """
    test_tree = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    }

    assert get_tree_node(test_tree, 'a:b:c:d') == 'e'
    assert get_tree_node(test_tree, 'a:b:c:d:e') is _sentinel
    assert get_tree_node(test_tree, 'a:b:c:d:e', default='f') == 'f'



# Generated at 2022-06-18 04:50:44.472322
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'



# Generated at 2022-06-18 04:50:50.549609
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    test_data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_data, 'a:b:c') == 'd'
    assert get_tree_node(test_data, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:50:59.546388
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:51:06.308444
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:51:11.838393
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='default') == 'default'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:51:16.423256
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node.
    """
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'value')
    assert mapping['foo']['bar']['baz'] == 'value'



# Generated at 2022-06-18 04:51:20.633568
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel



# Generated at 2022-06-18 04:51:26.916749
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b') == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'



# Generated at 2022-06-18 04:51:29.590377
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'test')
    assert mapping['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-18 04:51:48.564843
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'hello')
    assert mapping['foo']['bar']['baz'] == 'hello'



# Generated at 2022-06-18 04:51:51.789216
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:51:56.763069
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node.
    """
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:52:04.744861
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz:quux', parent=True, default='quux') == 'quux'


#

# Generated at 2022-06-18 04:52:09.324903
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz'
            }
        }
    }
    set_tree_node(mapping, 'foo:bar:baz', 'foobarbaz')
    assert mapping['foo']['bar']['baz'] == 'foobarbaz'



# Generated at 2022-06-18 04:52:11.523910
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:52:21.697617
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c:d', parent=True) == {'c': 'd'}

    try:
        get_tree_node(tree, 'a:b:c:d')
    except KeyError:
        pass

# Generated at 2022-06-18 04:52:29.730479
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default=None) == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:baz', default=None, parent=True) == {'baz': 'qux'}
    assert get_tree

# Generated at 2022-06-18 04:52:32.914400
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:52:40.414927
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default='default') == 'default'



# Generated at 2022-06-18 04:53:27.744044
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux') is _sentinel



# Generated at 2022-06-18 04:53:34.356822
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:53:43.543364
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node function.
    """
    # Test basic functionality
    test_tree = tree()
    set_tree_node(test_tree, 'foo', 'bar')
    assert test_tree['foo'] == 'bar'

    # Test multiple dimensions
    set_tree_node(test_tree, 'foo:bar', 'baz')
    assert test_tree['foo']['bar'] == 'baz'

    # Test multiple dimensions with a list
    set_tree_node(test_tree, 'foo:bar:baz', ['a', 'b', 'c'])
    assert test_tree['foo']['bar']['baz'] == ['a', 'b', 'c']

    # Test multiple dimensions with a dict

# Generated at 2022-06-18 04:53:49.852200
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', parent=True) == {'baz': 'qux'}



# Generated at 2022-06-18 04:53:58.408665
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'quux'



# Generated at 2022-06-18 04:54:04.385382
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c:d', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:54:12.758029
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    test_tree = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }

    assert get_tree_node(test_tree, 'foo:bar:baz') == 'qux'
    assert get_tree_node(test_tree, 'foo:bar:baz:quux', default='quux') == 'quux'
    assert get_tree_node(test_tree, 'foo:bar:baz:quux') == _sentinel



# Generated at 2022-06-18 04:54:16.404305
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'value')
    assert mapping['foo']['bar']['baz'] == 'value'



# Generated at 2022-06-18 04:54:23.730765
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test tree
    tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    # Test cases
    test_cases = [
        ('a:b:c', 'd'),
        ('a:b:c:d', _sentinel),
        ('a:b:c:d', 'e', 'e'),
    ]

    for key, expected, default in test_cases:
        assert get_tree_node(tree, key, default=default) == expected



# Generated at 2022-06-18 04:54:26.299078
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'hello')
    assert tree['foo']['bar']['baz'] == 'hello'



# Generated at 2022-06-18 04:55:59.460292
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:56:06.273631
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': {'baz': 'qux'}}}
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quux', parent=True) == {'baz': 'qux'}
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux') == 'quux'
    assert get_tree_node(mapping, 'foo:bar:quux', default='quux', parent=True) == {'baz': 'qux'}

# Generated at 2022-06-18 04:56:17.302043
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    tree = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f',
            },
            'g': 'h',
        },
        'i': 'j',
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:e') == 'f'
    assert get_tree_node(tree, 'a:g') == 'h'
    assert get_tree_node(tree, 'i') == 'j'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel

# Generated at 2022-06-18 04:56:27.947153
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.

    Returns:
        bool: True if test passed.

    """
    test_mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(test_mapping, 'a:b:c') == 'd'
    assert get_tree_node(test_mapping, 'a:b:c:d') is _sentinel
    assert get_tree_node(test_mapping, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_mapping, 'a:b:c', parent=True) == {'c': 'd'}

# Generated at 2022-06-18 04:56:30.097626
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 'd')
    assert d['a']['b']['c'] == 'd'



# Generated at 2022-06-18 04:56:38.062899
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    mapping = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:qux', default=None) is None
    assert get_tree_node(mapping, 'foo:bar:baz:qux') == 'qux'



# Generated at 2022-06-18 04:56:39.562175
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a:b:c', 'd') == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:56:43.838343
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 'd')
    assert d == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-18 04:56:50.421314
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(test_tree, 'a:b:c') == 'd'
    assert get_tree_node(test_tree, 'a:b:c:d', default='e') == 'e'
    assert get_tree_node(test_tree, 'a:b:c:d', default='e', parent=True) == {'c': 'd'}



# Generated at 2022-06-18 04:56:53.052608
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node.
    """
    mapping = tree()
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping['foo']['bar'] == 'baz'

