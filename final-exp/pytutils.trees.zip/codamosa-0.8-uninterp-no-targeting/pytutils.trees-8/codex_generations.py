

# Generated at 2022-06-21 22:18:05.937312
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Basic test
    t = Tree()
    assert t.get('x') is None
    t['x'] = 'y'
    assert t.get('x') == 'y'

    # Basic test with namespace
    t = Tree(namespace='a')
    assert t.get('x') is None
    t['x'] = 'y'
    assert t.get('x') == 'y'
    assert t.get('a:x') == 'y'

    # Test prefixing
    t = Tree()
    t['a:b:c'] = 'd'
    assert t['a:b:c'] == 'd'

    # Test default
    assert t.get('a:b:e', 'f') == 'f'

    # Test node traversal

# Generated at 2022-06-21 22:18:09.798649
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """This just tests parsing of the ':' character."""
    tree = RegistryTree()
    for key in range(4):
        tree.register('foo:bar:baz:boo', key)

    assert tree['foo:bar:baz:boo'] == 3

# Generated at 2022-06-21 22:18:15.990774
# Unit test for function set_tree_node
def test_set_tree_node():
    # Fixture
    d = {
        'a': {
            'b': {
                'c': {
                }
            }
        }
    }
    k, v = 'a:b:d', 'magik'

    # Invoke
    parent_node = set_tree_node(d, k, v)

    # Validate node was correctly set
    assert parent_node == d['a']['b']
    assert parent_node['d'] == v


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-21 22:18:27.185196
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'application': {
            'name': 'test',
            'version': '0.0.1'
        },
        'browser': {
            'name': 'firefox',
            'version': '20'
        }
    }
    assert get_tree_node(test_data, 'application:name') == 'test'
    assert get_tree_node(test_data, 'browser') == {
        'name': 'firefox',
        'version': '20'
    }
    assert get_tree_node(test_data, 'browser:name') == 'firefox'
    assert get_tree_node(test_data, 'foo', default='bar') == 'bar'



# Generated at 2022-06-21 22:18:30.755860
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('data:foo', {
        'bar': {
            'baz': 'qux',
        },
    })

    assert tree['data:foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-21 22:18:39.852067
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    class MyRegistryTree(RegistryTree):
        pass

    reg = MyRegistryTree()

    # Check default namespace is used
    reg.register('foo', namespace='bar')

# Generated at 2022-06-21 22:18:47.520824
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test basic tree
    a = tree()
    set_tree_node(a, 'foo', 'bar')
    assert get_tree_node(a, 'foo') == 'bar'

    # Test nested tree
    b = tree()
    set_tree_node(b, '1:2:3:foo', 'bar')
    assert get_tree_node(b, '1:2:3:foo') == 'bar'

    # Test nested tree with Tree class
    c = Tree()
    c.set_tree_node('1:2:3:foo', 'bar')
    assert c.get_tree_node('1:2:3:foo') == 'bar'



# Generated at 2022-06-21 22:18:49.538480
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a:b:c'] = 'foo'
    assert t['a']['b']['c'] == 'foo'

# Generated at 2022-06-21 22:18:50.335246
# Unit test for function get_tree_node
def test_get_tree_node():
    pass

# Generated at 2022-06-21 22:18:55.082519
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree(namespace='ns')
    t['a'] = 1
    t['b'] = 2
    assert t['a'] == 1
    assert t['ns:a'] == 1
    assert t['b'] == 2
    assert t['ns:b'] == 2

# Generated at 2022-06-21 22:19:04.547662
# Unit test for function tree
def test_tree():
    """Unit test for :func:`tree`."""
    t = tree()
    t['one']['two']['three'] = 1
    assert t['one']['two']['three'] == 1
    try:
        assert t['one']['two']['four'] != 1
    except KeyError:
        pass


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-21 22:19:09.807361
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('a:b:c:foo', 12, namespace='x')
    assert rt['x:a:b:c:foo'] == [12]


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-21 22:19:19.376057
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(initial={
        'a': {
            'b': 'c',
            'd': {
                'e': 'f',
            },
        },
    })

    assert isinstance(tree, collections.Mapping)
    assert isinstance(tree, collections.defaultdict)

    assert tree['a:b'] == 'c'
    assert tree['a:d:e'] == 'f'

    # Test __setitem__
    tree.register('a', 'b')
    assert tree['a'] == 'b'

    tree.register('a', 'z')
    assert tree['a'] == 'z'



# Generated at 2022-06-21 22:19:30.185324
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    # Use dict unpacking as shortcut
    test_mapping = {'foo': {'bar': {'baz': 'foobarbaz', 'spam': 'foobarspam'}}}

    # Initialize a RegistryTree passing it all the arguments
    test_registry = RegistryTree(initial=test_mapping, namespace='test', initial_is_ref=False)

    # Ensure that the values are correctly set in the RegistryTree
    assert test_registry['test:foo:bar:baz'] == 'foobarbaz'
    assert test_registry['test:foo:bar:spam'] == 'foobarspam'

    # Overwrite the value 'baz'
    test_registry['test:foo:bar:baz'] = 'This is baz'

# Generated at 2022-06-21 22:19:33.606655
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('a:b:c', 'value')
    assert registry['a:b:c'] == 'value'



# Generated at 2022-06-21 22:19:40.271875
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node
    """
    mapping = {}
    set_tree_node(mapping, 'fred:flintstone', 'age')
    assert mapping['fred']['flintstone'] == 'age'

    set_tree_node(mapping, 'barney:rubble', 'age')
    assert mapping['barney']['rubble'] == 'age'

    set_tree_node(mapping, 'barney:rubble', 'size')
    assert mapping['barney']['rubble'] == 'size'

# Generated at 2022-06-21 22:19:49.348250
# Unit test for function get_tree_node
def test_get_tree_node():
    # Make sure it does what it's supposed to.
    mapping = {"foo": "bar", "fizz": {"buzz": "pow", "bing": "bang"}}

    assert(get_tree_node(mapping, "foo") == "bar")
    assert(get_tree_node(mapping, "fizz:buzz") == "pow")

    # Make sure it preserves the idiomatic Python behaviour of raising a
    # KeyError if it can't find anything.
    with pytest.raises(KeyError):
        get_tree_node(mapping, "nope")

    # Make sure it returns our default value if we request one.
    assert(get_tree_node(mapping, "nope", default=True) is True)

    # Make sure it traverses the node structure correctly.

# Generated at 2022-06-21 22:19:50.790788
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': {'b': 'c'}})
    assert t['a:b'] == 'c'



# Generated at 2022-06-21 22:20:01.925323
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        '1': {
            '2': {
                '3': {
                    '4': 'value',
                },
            },
        },
    }
    assert get_tree_node(test_data, '1:2:3:4') == 'value'
    assert get_tree_node(test_data, '1') == {'2': {'3': {'4': 'value'}}}
    assert get_tree_node(test_data, '1:2') == {'3': {'4': 'value'}}
    assert get_tree_node(test_data, '1:2:3') == {'4': 'value'}
    assert get_tree_node(test_data, '1:2:3:4') == 'value'



# Generated at 2022-06-21 22:20:09.968258
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function `get_tree_node`."""
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': 4,
                },
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c:d') == 4
    assert get_tree_node(mapping, 'a:b:c:d:e') is _sentinel



# Generated at 2022-06-21 22:20:15.515822
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = {'a': 1, 'b': 2, 'c': 3}
    b = Tree()
    b.update(a)
    assert b['a'] == 1
    assert b['b'] == 2
    assert b['c'] == 3



# Generated at 2022-06-21 22:20:25.386374
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar'] = 'baz'
    assert t['foo']['bar'] == 'baz', "Failed to insert baz into foo:bar"
    t['a']['b']['c']['d'] = 'e'
    assert t['a']['b']['c']['d'] == 'e', "Failed to insert e into a:b:c:d"
    t['foo']['bar']['hello']['world'] = 'foobar'
    # TODO Check if python works on this.
    assert t['foo:bar:hello:world'] == 'foobar'

if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-21 22:20:32.233524
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # defaultdict(<class 'Tree'>, {'x': defaultdict(<class 'Tree'>, {})})
    t = Tree()
    t['x'] = {}
    assert 'x' in t

    # defaultdict(<class 'Tree'>, {'a': defaultdict(<class 'Tree'>, {'b': defaultdict(<class 'Tree'>, {})})})
    t = Tree()
    t['a:b'] = {}
    assert 'a' in t
    assert 'b' in t['a']



# Generated at 2022-06-21 22:20:42.960515
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'foo', 'foo_val')
    assert data['foo'] == 'foo_val'
    assert data == {'foo': 'foo_val'}

    set_tree_node(data, 'foo:bar', 'bar_val')
    assert data['foo']['bar'] == 'bar_val'
    assert data == {'foo': {'bar': 'bar_val'}}

    set_tree_node(data, 'foo:bar:baz', 'baz_val')
    assert data['foo']['bar'] == 'bar_val'
    assert data['foo']['bar']['baz'] == 'baz_val'
    assert data == {'foo': {'bar': {'baz': 'baz_val'}}}

    set_

# Generated at 2022-06-21 22:20:47.024325
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from pprint import pprint
    tree=Tree()
    pprint(tree)
    tree['one']=1
    tree['two']=2
    tree['three']=3
    tree['one:one']=11
    tree['one:two']=12
    tree['one:three']=13
    pprint(tree)
    assert(tree['one']==1)
    assert(tree['one:one']==11)


# Generated at 2022-06-21 22:20:50.745266
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'foo:bar:baz', 'foobar')
    assert t['foo']['bar']['baz'] == 'foobar'



# Generated at 2022-06-21 22:20:57.347584
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    reg = RegistryTree(namespace='test')
    reg.register('test', 'foo')

    assert reg['test'] == 'foo'
    assert reg.get('test') == 'foo'
    assert reg['test:test'] == 'foo'
    assert reg.get('test:test') == 'foo'

    val = reg.register('bar:baz', 'baz')

    assert val['baz'] == 'baz'
    assert reg['test:bar:baz'] == 'baz'
    assert reg.get('test:bar:baz') == 'baz'



# Generated at 2022-06-21 22:21:01.105995
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('test.test', 'Hello world')
    tree.register('test.test1', 'Hello world 2')

    assert tree['test'] == {'test': 'Hello world', 'test1': 'Hello world 2'}



# Generated at 2022-06-21 22:21:12.072797
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Test if it can fetch arbitrary node from a tree-like mapping structure with traversal help"""
    matrix = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(matrix, 'a') == matrix['a']
    assert get_tree_node(matrix, 'a:b') == matrix['a']['b']
    assert get_tree_node(matrix, 'a:b:c') == matrix['a']['b']['c']

    matrix = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(matrix, 'a:b:c', default='nothing') == matrix['a']['b']['c']

# Generated at 2022-06-21 22:21:20.612755
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial_is_ref=True)
    assert t.namespace == ''
    assert t.data == {}

    t = Tree(namespace='chess')
    assert t.namespace == 'chess'
    assert t.data == {}

    t = Tree(['a', 'b'], namespace='chess')
    assert t.namespace == 'chess'
    assert t == {'a': {}, 'b': {}}
    assert t.data == t

    t = Tree(['a', 'b'])
    assert t.namespace == ''
    assert t == {'a': {}, 'b': {}}


# Generated at 2022-06-21 22:21:34.013088
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    Constructor of RegistryTree should behave as expected.
    """
    tree = RegistryTree(namespace='my_namespace')
    tree['a'] = 'A!'
    assert tree.get('a') == 'A!'
    assert tree.get('my_namespace:a') == 'A!'
    assert tree.get('my_namespace:b', default='ValueNotFound') == 'ValueNotFound'

# Generated at 2022-06-21 22:21:36.314751
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    instance = Tree()
    instance['a'] = '1'
    assert instance['a'] == '1'



# Generated at 2022-06-21 22:21:38.818024
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Create a new instance
    x = RegistryTree({'x': {'y': 'z'}})
    # Check that tree instance is correctly created
    assert isinstance(x, RegistryTree)
    # Check that tree instance is correctly populated
    assert x.get('x:y') == 'z'

# Generated at 2022-06-21 22:21:47.461392
# Unit test for function get_tree_node
def test_get_tree_node():
    data_a = {
        'a': 1,
        'b': 2,
        'c': {
            'a': 1,
            'b': 2,
            'c': 3,
        }
    }

    assert get_tree_node(data_a, 'a') == 1
    assert get_tree_node(data_a, 'b') == 2
    assert get_tree_node(data_a, 'c:b') == 2
    assert get_tree_node(data_a, 'c', default='foo') == {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    assert get_tree_node(data_a, 'd', default='foo') == 'foo'

# Generated at 2022-06-21 22:21:50.387426
# Unit test for function set_tree_node
def test_set_tree_node():
    test = {}
    set_tree_node(test, 'apples:red', 'green')
    assert test == {'apples': {'red': 'green'}}



# Generated at 2022-06-21 22:21:53.188399
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register('a', {'b': 'c'})
    assert r.get('a') == {'b': 'c'}

# Generated at 2022-06-21 22:22:00.261677
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from types import ModuleType

    def test_getitem(cls):
        class Foo(object):
            pass

        class Foo2(object):
            pass

        t = cls()
        t['foo'] = Foo
        t['foo:bar'] = 'spam'
        t['foo:bar:qux'] = 'eggs'
        t['bar:baz'] = 1
        t['bar:baz:qux'] = 2
        assert t['foo'] == Foo
        assert t['foo:bar'] == 'spam'
        assert t['foo:bar:qux'] == 'eggs'
        assert t['bar:baz'] == 1
        assert t['bar:baz:qux'] == 2

# Generated at 2022-06-21 22:22:03.111716
# Unit test for function set_tree_node
def test_set_tree_node():
    structure = Tree()
    structure['a:b:c'] = 'Hello!'
    assert structure['a']['b']['c'] == 'Hello!'



# Generated at 2022-06-21 22:22:11.263929
# Unit test for function tree
def test_tree():
    # First time
    tree_ = tree()
    tree_[1]['a']['b']['c'] = 4
    assert tree_[1]['a']['b']['c'] == 4

    # Next time
    tree_[1]['a']['b']['c'] = 7
    assert tree_[1]['a']['b']['c'] == 7

    # with prefix
    tree_ = tree()
    tree_[1]['a']['b']['c'] = 4
    assert tree_['1:a:b:c'] == 4



# Generated at 2022-06-21 22:22:15.031474
# Unit test for function set_tree_node
def test_set_tree_node():
    d = collections.defaultdict(dict)
    set_tree_node(d, 'a:b:c', 3)
    assert d['a']['b']['c'] == 3



# Generated at 2022-06-21 22:22:37.756265
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert Tree()['foo'] == Tree.get('foo')
    assert Tree({'foo': 'bar'})['foo'] == Tree.get('foo', {'foo': 'bar'})
    assert Tree({'foo': 'bar'})['foo'] == Tree.get('foo', {'foo': 'bar'})
    assert Tree({'foo': 'bar'})['foo'] == Tree.get('foo', {'foo': 'bar'})

 # Unit test for method __setitem__ of class Tree

# Generated at 2022-06-21 22:22:45.767305
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Create a registry tree
    REGISTRY_TREE = RegistryTree()

    # Create a test proxy class
    import inspect
    import pytest

    class Proxy(object):

        def __init__(self):
            self.__doc__ = inspect.getdoc(self.__wrapped__)

        def __get__(self, instance, owner):
            if instance is None:
                return self
            return self.__wrapped__(instance)

        def __call__(self, *args, **kwargs):
            return self.__wrapped__(*args, **kwargs)

        def __getattr__(self, name):
            return getattr(self.__wrapped__, name)


# Generated at 2022-06-21 22:22:54.003958
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    mapping = {
        'foo': {
            'bar': True,
        },
    }

    assert get_tree_node(mapping, 'foo:bar') is True
    assert get_tree_node(mapping, 'foo:bar:baz', default=None) is None
    try:
        get_tree_node(mapping, 'foo:bar:baz')
    except KeyError:
        assert True
    else:
        assert False, 'Did not raise KeyError'



# Generated at 2022-06-21 22:22:58.579100
# Unit test for function set_tree_node
def test_set_tree_node():
    class TreeNode(dict):
        pass

    tree = TreeNode({
        'a': {
            'b': {
                'c': 1,
                'd': 2,
            },
        },
    })
    result = set_tree_node(tree, 'a:b:c', 3)
    assert result['c'] == 3



# Generated at 2022-06-21 22:23:04.249836
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(namespace='foo')
    tree['1'] = '1'
    tree['1'] = '2'
    tree['2'] = '3'

    assert tree.get('1') == '2'
    assert tree.get('2', default='4') == '3'
    assert tree.get('3', default='4') == '4'



# Generated at 2022-06-21 22:23:11.342404
# Unit test for function tree
def test_tree():
    assert get_tree_node(tree, 'foo') == {}
    assert get_tree_node(tree, 'foo:bar') == {}
    assert get_tree_node(tree, 'foo:bar:baz') == {}

    assert get_tree_node(tree, 'foo', default='NOOP') == {}
    assert get_tree_node(tree, 'foo:bar', default='NOOP') == {}
    assert get_tree_node(tree, 'foo:bar:baz', default='NOOP') == {}

    assert get_tree_node(tree, 'foo', default=_sentinel) == {}
    assert get_tree_node(tree, 'foo:bar', default=_sentinel) == {}
    assert get_tree_node(tree, 'foo:bar:baz', default=_sentinel) == {}

   

# Generated at 2022-06-21 22:23:14.323512
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'Test')
    assert mapping == {'a': {'b': {'c': 'Test'}}}



# Generated at 2022-06-21 22:23:24.051561
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test for `:func:set_tree_node`
    """
    mapping = tree()
    key = 'foo'
    value = 'bar'
    expected_result = tree()
    expected_result['foo'] = 'bar'
    assert expected_result == set_tree_node(mapping, key, value)

    mapping = tree()
    key = 'foo:bar'
    value = 'baz'
    expected_result = tree()
    expected_result['foo']['bar'] = 'baz'
    assert expected_result == set_tree_node(mapping, key, value)



# Generated at 2022-06-21 22:23:30.450819
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_data = [
        (
            (1, 'key', 'default', 'namespace'),
            {'__getitem__': '_Tree__getitem__'},
            ['Error!'],
            'Tests failure cases (1)',
            True,
        ),
        (
            (2, 'key', 'default', 'namespace'),
            {'__getitem__': '_Tree__getitem__'},
            ['Return self.__getitem__(key) if default is _sentinel else self.__getitem__(key, default)'],
            'Tests success cases (2)',
            False,
        ),
    ]

    return test_data



# Generated at 2022-06-21 22:23:33.765177
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Test RegistryTree class constructor."""
    r = RegistryTree(namespace='foo')
    r.register('bar', 'cheese')
    assert r['foo:bar'] == 'cheese'

# Generated at 2022-06-21 22:24:07.191835
# Unit test for function tree
def test_tree():
    test = tree()
    test['a']['b']['c'] = 1
    assert test['a']['b']['c'] == 1
    assert test['a:b']['c'] == 1



# Generated at 2022-06-21 22:24:14.040136
# Unit test for function get_tree_node
def test_get_tree_node():
    result = get_tree_node({'one': {'two': {'three': {'four': 4}}}})
    assert result == {'two': {'three': {'four': 4}}}, repr(result)

    result = get_tree_node({'one': {'two': {'three': {'four': 4}}}}, 'one')
    assert result == {'two': {'three': {'four': 4}}}, repr(result)

    result = get_tree_node({'one': {'two': {'three': {'four': 4}}}}, 'one:three')
    assert result == {'four': 4}, repr(result)

    result = get_tree_node({'one': {'two': {'three': {'four': 4}}}}, 'one:three:four')

# Generated at 2022-06-21 22:24:18.758900
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree({'a': 'b'}) == {'a': 'b'}
    assert Tree({'a': 'b'}, 'foo') == {'foo': {'a': 'b'}}
    assert Tree(namespace='foo') == {'foo': {}}



# Generated at 2022-06-21 22:24:23.085607
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    d = Tree({'a': {'b': {'c': 'd'}}})
    assert d.get('a') == {'b': {'c': 'd'}}
    assert d.get('a:b:c') == 'd'
    try:
        d.get('x')
    except Exception as exc:
        assert exc
    return

# Generated at 2022-06-21 22:24:32.438286
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    T = Tree()
    T['bla1'] = 1
    T['bla2'] = 2
    T['bla3'] = 3
    T['blu1'] = 4
    T['blu2'] = 5
    T['blu3'] = 6

    assert T['bla1'] == 1
    assert T['blu2'] == 5
    assert T['blu3'] == 6



# Generated at 2022-06-21 22:24:42.837925
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['foo'] = {'bar': {'baz': 'hi'}}
    assert get_tree_node(data, 'foo:bar:baz') == 'hi'
    assert get_tree_node(data, 'foo:bar') == data['foo']['bar']
    assert get_tree_node(data, 'foo', default='other') == 'other'
    assert get_tree_node(data, 'foo:baz', default='other') == 'other'



# Generated at 2022-06-21 22:24:47.009453
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Create a new instance of RegistryTree
    tree = RegistryTree()

    class Foo(object):
        pass

    tree.register(Foo)
    tree.Foo


# Generated at 2022-06-21 22:24:51.730731
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    set_tree_node(a, 'a:b', 'c')
    assert a['a']['b'] == 'c'
    set_tree_node(a, 'a:b', 'd')
    assert a['a']['b'] == 'd'
    set_tree_node(a, 'a:b:e', 'f')
    assert a['a']['b']['e'] == 'f'

# Generated at 2022-06-21 22:25:03.544114
# Unit test for function tree
def test_tree():
    """Tests the tree code."""
    t = tree()
    t['a']['b']['c']['d'] = 1
    t['e']['f']['g']['h'] = 2
    t['i']['j']['k']['l'] = 3
    t['m']['n']['o']['p'] = 4

    assert t['a:b:c:d'] == 1
    assert t['e:f:g:h'] == 2
    assert t['i:j:k:l'] == 3
    assert t['m:n:o:p'] == 4

    assert t['c:d'] == t['a']['b']['c']['d']

# Generated at 2022-06-21 22:25:09.428410
# Unit test for function tree
def test_tree():
    my_tree = tree()
    my_tree[ 'a' ][ 'b' ][ 'c' ] = 'd'
    my_tree[ 'a' ][ 'b' ][ 'e' ][ 'f' ][ 'g' ][ 'h' ][ 'i' ][ 'j' ][ 'k' ][ 'l' ][ 'm' ][ 'n' ][ 'o' ][ 'p' ][ 'q' ][ 'r' ][ 's' ] = 't'

# Generated at 2022-06-21 22:26:13.280809
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Tests that constructor of RegistryTree does not raise exceptions."""
    t = RegistryTree()

# Generated at 2022-06-21 22:26:16.888568
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    assert set_tree_node(data, 'foo:bar:baz:quux', 'quux') == {'foo': {'bar': {'baz': 'quux'}}}



# Generated at 2022-06-21 22:26:19.202870
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'foo:bar', 'baz')
    assert d == {'foo': {'bar': 'baz'}}

# Generated at 2022-06-21 22:26:24.336929
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import gel.state
    import gel.state.local
    import gel.state.defaults
    import gel.config.tree
    import gel.localstate
    import gel

    # Test for method __setitem__ of class Tree
    tree = gel.config.tree.Tree(initial={})
    # Check that it returned the expected result
    assert tree == {}



# Generated at 2022-06-21 22:26:27.505183
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 1
    assert tree['a'] == 1
    try:
        tree['a:b:c:d'] = 2
    except Exception:
        pass
    else:
        assert False, 'Tree should raise on setitem with invalid path.'



# Generated at 2022-06-21 22:26:36.917666
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import re
    from random import choice
    from string import uppercase

    # A test case:
    test = Tree()
    test["firstname"] = "John"
    test["lastname"] = "Doe"
    test["vehicle"] = "Jeep"
    test["vehicle:brand"] = "Jeep"
    test["vehicle:brand:company"] = "Chrysler"
    test["vehicle:model"] = "Wrangler"
    test["vehicle:engine"] = "V8"
    test["other:countries"] = "Germany"
    test["other:countries:austria"] = "Vienna"
    test["other:countries:belgium"] = "Brussels"
    test["other:countries:luxembourg"] = "Luxembourg"

# Generated at 2022-06-21 22:26:45.590977
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    >>> items = {'a': 1, 'b': 2, 'c': 3}
    >>> t = RegistryTree('foobar', items)
    >>> t
    {'a': 1, 'b': 2, 'c': 3}
    >>> t.namespace
    'foobar'
    >>> t.register('d', 4)
    >>> t
    {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    """


# Alias
registry_tree = RegistryTree


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:26:49.080406
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, '1', 1)
    set_tree_node(a, '1:1', 2)
    set_tree_node(a, '1:2', 3)
    assert a == {'1': {'1': 2, '2': 3}}



# Generated at 2022-06-21 22:26:54.708338
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'x': 'test1',
        'y': [
            {
                'z': 'test2'
            }
        ]
    }
    assert get_tree_node(d, 'x', default=None) == 'test1'
    with pytest.raises(KeyError):
        get_tree_node(d, 'NOPE')
    assert get_tree_node(d, 'y:0:z') == 'test2'
    assert get_tree_node(d, 'y:0:NOPE') is None
    assert get_tree_node(d, 'y:0:NOPE', default=False) is False
    with pytest.raises(KeyError) as excinfo:
        get_tree_node(d, 'y:0:NOPE2', default=_sentinel)

# Generated at 2022-06-21 22:27:00.836631
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a']['b']['c'] = 'd'
    assert t['a:b:c'] == 'd'
    t.namespace = 'foo'
    t['a']['b']['e'] = 'w'
    print(t)
    assert t['foo:a:b:e'] == 'w'


if __name__ == '__main__':
    test_Tree()