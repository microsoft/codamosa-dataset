

# Generated at 2022-06-21 22:18:04.029054
# Unit test for function tree
def test_tree():
    """Test."""
    t = tree()
    t['a']['b']['c'] = 123
    t['a']['b']['d'] = 123
    assert t['a']['b']['c'] == t['a']['b']['d'] == 123
    assert t['a']['b']['c'] != 321



# Generated at 2022-06-21 22:18:09.706357
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    # No namespace
    t[':my_key'] = 'my_value'
    assert t[':my_key'] == 'my_value'

    # With namespace
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'

    t = Tree(namespace='foobar')
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'



# Generated at 2022-06-21 22:18:17.965980
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {
            'b': 1,
            'c': 2,
            'd': {
                'e': 3,
                'f': {
                    'g': 4,
                }
            }
        }
    }
    # Normal
    assert get_tree_node(d, 'a:b') == 1
    # Normal
    assert get_tree_node(d, 'a:c') == 2
    # Deep
    assert get_tree_node(d, 'a:d:e') == 3
    # Deep
    assert get_tree_node(d, 'a:d:f:g') == 4
    # Default
    assert get_tree_node(d, 'a:d:e:f', -99) == -99
    # Default

# Generated at 2022-06-21 22:18:23.283322
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit tests for set_tree_node
    """
    mapping = {}
    set_tree_node(mapping, key='foo:bar:baz', value='BINGO!')
    assert mapping['foo']['bar']['baz'] == 'BINGO!'



# Generated at 2022-06-21 22:18:29.096734
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'first': {
            'second': {
                'third': 'we are here!',
            }
        }
    }
    # First test the basic case
    assert 'we are here!' == get_tree_node(tree, 'first:second:third')
    # Test a case that doesn't exist
    assert None is get_tree_node(tree, 'first:does:not:exist', default=None)



# Generated at 2022-06-21 22:18:37.695146
# Unit test for function set_tree_node
def test_set_tree_node():
    class Dummy(object):

        def __init__(self, data):
            self.data = data

    node = Dummy(None)

    for i in range(0, 3):
        node = Dummy(node)

    set_tree_node(node, 'foo', 'bar')
    assert get_tree_node(node, 'foo') == 'bar'

    set_tree_node(node, 'foo:bar:baz', 'lol')
    assert get_tree_node(node, 'foo:bar:baz') == 'lol'



# Generated at 2022-06-21 22:18:40.776264
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert isinstance(t, Tree)
    assert t == {}
    assert len(t) == 0
    assert not t
    isinstance(t, collections.defaultdict)



# Generated at 2022-06-21 22:18:47.889546
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'foo': 'bar', 'baz': {'sp': {'am': '!'}}})
    t.__setitem__('foo', 'bar2', namespace='x')
    assert t['foo'] == 'bar2'
    assert t.namespace is None
    assert t['x:foo'] == 'bar2'

# Generated at 2022-06-21 22:18:50.090805
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree()
    assert reg is not None, "RegistryTree isn't created"
    return reg



# Generated at 2022-06-21 22:19:01.895554
# Unit test for function tree
def test_tree():
    result = tree()

    result['stuff'] = 'thing'
    result['stuff']['stuff'] = 'thing'
    result['stuff']['stuff']['stuff'] = 'thing'
    result['stuff']['stuff']['stuff']['stuff'] = 'thing'
    result['stuff']['stuff']['stuff']['stuff']['stuff'] = 'thing'
    result['stuff']['stuff']['stuff']['stuff']['stuff']['stuff'] = 'thing'
    result['stuff']['stuff']['stuff']['stuff']['stuff']['stuff']['stuff'] = 'thing'

    result['stuff:stuff:stuff:stuff:stuff:stuff:stuff:stuff']['stuff'] = 'thing'

# Generated at 2022-06-21 22:19:06.484730
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry_tree = RegistryTree()

    # Assert the value is None
    assert registry_tree['test_key'] is None



# Generated at 2022-06-21 22:19:08.535622
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    assert set_tree_node(mapping, '1:2:3', 'foo') == {'1': {'2': {'3': 'foo'}}}
    assert mapping == {'1': {'2': {'3': 'foo'}}}



# Generated at 2022-06-21 22:19:20.012279
# Unit test for function tree
def test_tree():
    # Standard tree operation
    t = tree()
    t['message']['hello'] = 'world'
    assert t['message']['hello'] == 'world', 'Tree data is accessible via dimension'

    # Check if path exists
    assert t['message'].get('sadface', None) is None, 'Tree supports defaultdict-like `get()`'

    # Tree supports type conversion to dict
    assert dict(t) == {'message': {'hello': 'world'}}, 'Tree can be type-converted to dict'

    # Tree _could_ support __contains__, but it is a no-op for now
    # assert 'message' in t

    # Specifying a default value will return value _at_ path, allowing for structure check

# Generated at 2022-06-21 22:19:30.668264
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Test: Tree.__getitem__

    Initialize Tree(initial={'A': {'B': {'C': 'D'}}})
    Verify that:
    * Calling tree['A:B:C'] returns 'D'
    * Calling tree['A:B'] returns {'C': 'D'}
    * Calling tree['A'] returns {'B': {'C': 'D'}}
    * Calling tree['X:Y:Z'] returns KeyError, without a default
    * Calling tree['X:Y:Z', '123'] returns '123'
    """
    initial = {'A': {'B': {'C': 'D'}}}
    tree = Tree(initial=initial)
    assert tree['A:B:C'] == 'D'

# Generated at 2022-06-21 22:19:34.255718
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'namespace': 'test'})
    assert isinstance(tree['data:tree'], Tree)
    assert tree['data:tree'].namespace == 'test:data:tree'



# Generated at 2022-06-21 22:19:39.483192
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    d = Tree()
    d['a1'] = 1
    d['a2:b1'] = 2
    d['a2:b2'] = 3

    assert(d['a1'] == 1)
    assert(d['a2:b1'] == 2)
    assert(d['a2:b2'] == 3)

    d['a3:b3:c3'] = Tree()

    assert(isinstance(d['a3:b3:c3'], Tree))



# Generated at 2022-06-21 22:19:48.825752
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node functionality and usage."""
    test_dict = {
        'foo': {
            'bar': 'baz',
            'new': {
                'foo': 'bar',
                'bar': 'baz'
            },
            'baz': 'foo',
        },
        'bar': 'baz',
    }

    # Normal usage
    assert get_tree_node(test_dict, 'foo:bar') == 'baz'
    assert get_tree_node(test_dict, 'bar') == 'baz'

    # Usage with default value that does not appear in original tree
    assert get_tree_node(test_dict, 'hello', default='world') == 'world'

    # Parent/child usage
    assert get_tree_node(test_dict, 'foo', parent=True)

# Generated at 2022-06-21 22:19:57.660480
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'1': {'2': {'3': '4'}}})
    assert t.get('1') == {'2': {'3': '4'}}
    assert t.get('1:2') == {'3': '4'}
    assert t.get('1:2:3') == '4'

    assert t.get('1:2:4') is _sentinel
    with pytest.raises(KeyError):
        t.get('1:2:4', _sentinel)



# Generated at 2022-06-21 22:20:01.894808
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():

    registry = Tree({'foo': {'bar': 'baz'}})
    assert registry['foo:bar'] == 'baz'

# Generated at 2022-06-21 22:20:04.870378
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    instance = Tree()
    instance['foo'] = 'bar'
    assert instance['foo'] == 'bar'

# Generated at 2022-06-21 22:20:12.929229
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Unit test for method __getitem__ of class Tree"""

    items = [
        ('a', 1),
        ('b', 2),
        ('c:d:e', 3)
    ]

    t = Tree(items)

    print(t['a'])
    print(t['b'])
    print(t['c:d:e'])
    print(t['f'])



# Generated at 2022-06-21 22:20:18.524598
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class HttpRouter(RegistryTree):
        _routes = {
            'http': {
                'GET': {
                    'foo': 'bar'
                }
            }
        }

    router = HttpRouter('http', initial=_routes, initial_is_ref=True)

    # TODO Add edge case/invalid input detection
    assert isinstance(router, Tree)

# Generated at 2022-06-21 22:20:28.775700
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import math
    import sys
    import unittest

    class Tree___setitem__Test(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_Tree___setitem__(self):
            import nineml.user as nineml

            class One(nineml.ComponentClass):
                """
                +---------+   +-------+
                |         |   |       |
                |    One  |   |  One  |
                |         |   |       |
                |         |   |       |
                +---------+   +-------+
                """

                c = nineml.Parameter('c', dimension=nineml.m)


# Generated at 2022-06-21 22:20:31.726833
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree({'foo': 'bar'})
    assert tree.get('foo') == 'bar'

# Generated at 2022-06-21 22:20:35.629429
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'a': {'b': 1}}

    # TODO Fix this.
    assert get_tree_node(tree, 'a:b', parent=True) == tree['a']
    assert get_tree_node(tree, 'a:b') == 1



# Generated at 2022-06-21 22:20:38.698434
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree()
    reg.register("flabergaster", 'monster')
    assert reg.flabergaster == 'monster'


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-21 22:20:46.044608
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # initialize instance
    self = Tree()

    # initialize parameters describing function inputs
    key = None
    value = None

    # set function parameters as attributes on instance
    self.key = key
    self.value = value

    # function input arguments
    args = (self.key, self.value)
    # function output arguments
    outargs = None

    # call the function
    retval = self.__setitem__(*args)

    # compare `retval` with `outargs`
    assert retval == outargs



# Generated at 2022-06-21 22:20:50.135356
# Unit test for function set_tree_node
def test_set_tree_node():
    test_mapping = tree()
    set_tree_node(test_mapping, 'this:is:a:test', True)
    assert test_mapping['this']['is']['a']['test']



# Generated at 2022-06-21 22:20:57.384211
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    def test(set_node=None, get_node=None, get_parent=None):
        # Setup
        rt = RegistryTree()

        # Test
        assert rt is not None
        rt.register('foo:bar:baz', 1)
        rt.register('foo:bar:bat', 1)
        rt.register('foo:bar:boo', 1)
        rt.register('foo:bar:bam', 1)
        assert rt['foo:bar:baz'] == 1
        assert rt['foo:bar:bat'] == 1
        assert rt['foo:bar:boo'] == 1
        assert rt['foo:bar:bam'] == 1
        assert set(rt['foo:bar']) == set(['baz', 'bat', 'boo', 'bam'])

# Generated at 2022-06-21 22:21:01.415670
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'user:name', 'foo')
    set_tree_node(mapping, 'user:email', 'foo@example.com')
    set_tree_node(mapping, 'user:roles:0', 'user')
    print(mapping)



# Generated at 2022-06-21 22:21:04.481023
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree(data='Tester')

# Generated at 2022-06-21 22:21:08.479570
# Unit test for function set_tree_node
def test_set_tree_node():
    A = {}
    set_tree_node(A, 'foo:bar:baz', value='test')
    assert A['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-21 22:21:19.892275
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    data = {
        'one': 123,
        'two': {
            'one': 'two',
            'three': {
                'one': 'two'
            }
        },
    }
    t.update(data)
    assert t['one'] == 123
    assert t['two']['one'] == 'two'
    assert t['two:three:one'] == 'two'

    t = Tree()
    t['one'] = 123
    t['two:one'] = 'two'
    t['two:three:one'] = 'two'
    assert t['one'] == 123
    assert t['two:one'] == 'two'
    assert t['two:three:one'] == 'two'



# Generated at 2022-06-21 22:21:24.353691
# Unit test for function tree
def test_tree():
    """Unit test function `test_tree`."""
    t = tree()
    t['a']['b'] = 1
    t['a']['c'] = 2
    t['b']['d'] = 3
    assert t['a']['b'] == 1
    assert t['a']['c'] == 2
    assert t['b']['d'] == 3



# Generated at 2022-06-21 22:21:29.255166
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'a:b:c', 123)
    assert get_tree_node(mapping, 'a:b:c') == 123


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-21 22:21:39.824685
# Unit test for constructor of class Tree
def test_Tree():
    # Instance empty
    t1 = Tree()

# Generated at 2022-06-21 22:21:47.992531
# Unit test for function tree
def test_tree():
    tree = Tree({'foo': 'bar'})
    tree['foo'] = 'bar'

# Generated at 2022-06-21 22:21:57.878302
# Unit test for function tree
def test_tree():
    from pprint import pprint
    from uuid import uuid4
    from json import dumps as jdumps
    from random import randint
    from random import random
    from random import choice

    t = tree()
    t['a']
    t['a']['b']  # Test for dimensions
    t['a']['b']['c'] = 'This is C'
    t['a']['f']['g'] = 'This is G'
    t['a']['f']['h'] = 'This is H'
    t['k'] = 'This is K'
    t['l']
    t['l']['m'] = 'This is M'
    t['l']['n'] = 'This is N'

# Generated at 2022-06-21 22:22:02.630231
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    d = RegistryTree()
    d.register('a:b:c', 'test')
    assert d['a:b:c'] == 'test'

# Generated at 2022-06-21 22:22:12.769548
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    obj = Tree()
    obj['a:b:c:d'] = 'testing'
    assert obj['a:b:c:d'] == 'testing'



# Generated at 2022-06-21 22:22:23.921713
# Unit test for function tree
def test_tree():
    t = tree()
    t['test']['test2'] = 'test3'
    assert t['test:test2'], 'test3'
    assert t['test']['test2'], 'test3'
    assert t['test']['test2:test3'], KeyError
    try:
        t['test']['test2:test3']
    except KeyError as exc:
        print('test_tree(): got exc {}'.format(exc))


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-21 22:22:29.047728
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 'A'
    assert tree['a'] == 'A'

    tree['b'] = 'B'
    assert tree['b'] == 'B'

    tree['a:b'] = 'AB'
    assert tree['a:b'] == 'AB'

    tree['a:b:c'] = 'ABC'
    assert tree['ab:c'] == 'ABC'



# Generated at 2022-06-21 22:22:37.307597
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Make sure it doesn't error
    tree = RegistryTree()
    assert isinstance(tree, dict)
    # Make sure registering doesn't error
    tree.register('foo:bar:baz', 'buz')
    # Make sure it didn't get called twice
    assert len(tree.keys()) == 1
    # Make sure the Tree node is still pointing to the original dict
    assert tree.get('foo:bar') == 'buz'
    # Make sure dereferencing is still possible
    assert tree.get('foo:bar:baz') == 'buz'

# Generated at 2022-06-21 22:22:40.591731
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Testing function Tree.__setitem__
    #
    # Args:
    #    None

    # Return:
    #    None

    # Raises:
    #    None

    obj = Tree()
    obj.__setitem__(None, None)



# Generated at 2022-06-21 22:22:44.715944
# Unit test for constructor of class Tree
def test_Tree():

    # Instantiate class Tree
    obj = Tree({1: 2, 2: [{3: 4}, {5: 6}]})

    # Access elements via : notation
    assert 4 == obj.get('2:0:3')
    assert obj.get('2:1:3') is None



# Generated at 2022-06-21 22:22:49.637914
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree[':a:b:c'] = 1
    assert tree['a:b:c'] == 1, "The tree didn't adhere to namespaces"
    assert tree['a:b:c'] != 2, "The tree had the wrong value"



# Generated at 2022-06-21 22:22:54.219111
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    result = tree()
    assert result == {}
    result['a']['b']['c']['d']['e'] = 'g'
    assert result == {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': 'g'
                    }
                }
            }
        }
    }

# Generated at 2022-06-21 22:23:05.123187
# Unit test for constructor of class RegistryTree

# Generated at 2022-06-21 22:23:11.661862
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class DummyMeta(type):
        """
        Metaclass for dummy Widget class
        """
        registry = RegistryTree()

        def __new__(mcs, name, bases, attrs, **kwargs):
            """
            Construct widget.
            """
            # Only skip the first time, when we're setting up the base Widget class
            if not name == 'Widget':
                namespace = camel_to_snake(name)
                mcs.registry.register(namespace, attrs.get('verbose_name'))
            new_class = super(DummyMeta, mcs).__new__(mcs, name, bases, attrs)

            return new_class

    class Widget(object, metaclass=DummyMeta):
        """
        Test widget
        """
        verbose_name = "Widget"

# Generated at 2022-06-21 22:23:14.079135
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'blue:shirt', 'something stupid')
    assert tree['blue']['shirt'] == 'something stupid'



# Generated at 2022-06-21 22:23:25.346450
# Unit test for constructor of class Tree
def test_Tree():
    test_tree = Tree(initial={1: 2, 3: 4}, initial_is_ref=True)
    print(test_tree)
    print(test_tree[1])
    print(test_tree[2])
    print(test_tree[0])
    return



# Generated at 2022-06-21 22:23:29.082529
# Unit test for function set_tree_node
def test_set_tree_node():
    m = tree()
    set_tree_node(m, 'foo', 1)
    assert m['foo'] == 1

    set_tree_node(m, 'bar:baz', 2)
    assert m['bar']['baz'] == 2



# Generated at 2022-06-21 22:23:32.037071
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Tests the set_tree_node function
    """
    testdict = {}
    set_tree_node(testdict, 'root_node:level1_node:level2_node:level3_node', 3)
    result_dict = {'root_node': {'level1_node': {'level2_node': {'level3_node': 3}}}}
    assert testdict == result_dict



# Generated at 2022-06-21 22:23:34.125398
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t[1] = 2
    t[1, 2] = 3
    t[1, 2, 3] = 4
    assert t[1] == 2
    assert t[1, 2] == 3
    assert t[1, 2, 3] == 4



# Generated at 2022-06-21 22:23:41.906277
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['value'] = 'top-level'
    tree['group:value'] = 'second-level'
    tree['group:subgroup:value'] = 'third-level'
    tree['group:subgroup:subgroup:value'] = 'fourth-level'
    assert tree['value'] == 'top-level'
    assert tree['group:value'] == 'second-level'
    assert tree['group:subgroup:value'] == 'third-level'
    assert tree['group:subgroup:subgroup:value'] == 'fourth-level'



# Generated at 2022-06-21 22:23:52.446986
# Unit test for function get_tree_node
def test_get_tree_node():
    import json
    kwargs = {}
    kwargs['payload'] = {
        'model': {
            'id': 'foo'
        },
        'items': [
            {
                'foo': {
                    'name': 'bar'
                }
            }
        ]
    }
    kwargs['default'] = {
        'model': {},
        'items': []
    }

    kwargs['mapping'] = kwargs['default']

    # Set to foo
    kwargs['key'] = 'payload:model:id'
    assert get_tree_node(**kwargs) == 'foo'

    # Set to []
    kwargs['key'] = 'payload:items'
    assert get_tree_node(**kwargs) == []

    # Test parent node
   

# Generated at 2022-06-21 22:24:00.321482
# Unit test for function tree
def test_tree():
    assert get_tree_node(tree(), 'A:B:C:D', _sentinel) is _sentinel
    tree_node = tree()
    set_tree_node(tree_node, 'A:B:C:D', 'X')
    set_tree_node(tree_node, 'A:B:C:E', 'Y')
    set_tree_node(tree_node, 'A:B:C:F', 'Z')
    set_tree_node(tree_node, 'A:B:C:G', 'Z')
    set_tree_node(tree_node, 'A:B:C:G', 'X')
    set_tree_node(tree_node, 'A:B:C:G:H', 'X')

# Generated at 2022-06-21 22:24:06.336615
# Unit test for function set_tree_node
def test_set_tree_node():
    storage = {}
    assert storage == {}
    set_tree_node(storage, 'a:b:c:d:e:f:g', True)
    assert storage == {'a': {'b': {'c': {'d': {'e': {'f': {'g': True}}}}}}}



# Generated at 2022-06-21 22:24:13.760175
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    def _test():
        expected = {'foo': 'bar', 'baz': {'qux': 'quux'}}
        t = Tree()

        # Full path
        t['foo'] = 'bar'
        assert t['foo'] == 'bar'

        # Nested
        t['baz:qux'] = 'quux'
        assert t['baz:qux'] == 'quux'

        # Multiple nested
        t['corge:grault:garply'] = 'plugh'
        assert t['corge:grault:garply'] == 'plugh'

        # Namespaced
        t.namespace = 'foo'
        t['bar'] = 'baz'
        assert t['foo:bar'] == 'baz'

        # KeyError

# Generated at 2022-06-21 22:24:16.699799
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t[':a:b'] = 1
    assert t['a:b'] == 1



# Generated at 2022-06-21 22:24:34.503840
# Unit test for function tree
def test_tree():
    t = tree()
    t['c']['d'] = 'e'
    assert t['c']['d'] == 'e'

    t['f:g:h:i:j:k:l:m:n'] = 10
    assert t['f']['g']['h']['i']['j']['k']['l']['m']['n'] == 10



# Generated at 2022-06-21 22:24:39.482402
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree(initial={'a': {'a': []}}, namespace='registry')
    assert reg['a'] == {'a': []}


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-21 22:24:46.021431
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Test `tree` and `get_tree_node`."""
    # Arrange
    root = Tree(namespace='root')
    root.update({
        'branch1': {'axes': {'a': 'leaf1'}},
        'branch2': {'axes': {'a': 'leaf2'}},
        'branch3': {'axes': {'a': 'leaf3'}},
    })

    # Act and Assert
    assert root['branch1:axes:a'] == 'leaf1'
    assert root['branch2:axes:a'] == 'leaf2'
    assert root['branch3:axes:a'] == 'leaf3'

    assert root.get('branch1:axes:a') == 'leaf1'

# Generated at 2022-06-21 22:24:53.435658
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree() # initial argument optional

    # test initial
    t = Tree(initial={'a': {'b': 'c'}})
    assert t['a']['b'] == 'c'

    # test initial_is_ref
    d0 = {'a': {'b': 'c'}}
    t0 = Tree(initial=d0, initial_is_ref=True)
    d0['a']['b'] = 'd'
    assert t0['a']['b'] == 'd'

    # test namespace
    t1 = Tree(namespace='x')
    t1['a']['b'] = 'c'
    assert t1['a']['b'] == 'c'
    assert t1['x']['a']['b'] == 'c'

    # test namespace +

# Generated at 2022-06-21 22:24:57.332374
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo', 1)
    assert mapping == {
        'foo': 1,
    }
    set_tree_node(mapping, 'foo', 2)
    assert mapping == {
        'foo': 2,
    }
    set_tree_node(mapping, 'foo:bar', 3)
    assert mapping == {
        'foo': {
            'bar': 3,
        }
    }



# Generated at 2022-06-21 22:25:07.724897
# Unit test for function set_tree_node
def test_set_tree_node():
    d = collections.defaultdict(dict)
    set_tree_node(d, 'a', 1)
    assert d['a'] == 1
    assert d == {'a': 1}
    set_tree_node(d, 'b:c', 2)
    assert d['b']['c'] == 2
    assert d == {'a': 1, 'b': {'c': 2}}
    set_tree_node(d, 'b:d:e', 3)
    assert d['b']['d']['e'] == 3
    assert d == {'a': 1, 'b': {'c': 2, 'd': {'e': 3}}}

if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-21 22:25:13.058390
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='test')
    assert t['foo'] == {}
    t['foo'] = 'bar'
    assert t == {'test': {'foo': 'bar'}}



# Generated at 2022-06-21 22:25:16.124257
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo:bar:baz'] = 1
    assert t['foo:bar:baz'] == 1
    assert t['foo:bar'] == {'baz': 1}



# Generated at 2022-06-21 22:25:21.311517
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import ibid
    t = Tree()
    t.set('a', 'b', 'c')
    ibid.log.debug("t.get('a:b')")
    ibid.log.debug(t.get('a:b'))
    assert t.get('a:b') == 'c'


if __name__ == "__main__":
    test_Tree___setitem__()

# Generated at 2022-06-21 22:25:25.320173
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}

# Generated at 2022-06-21 22:25:56.791279
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(
        {'foo': {'bar': 'baz'}},
        'foo:bar:spam',
        'ham'
    ) == {'foo': {'bar': 'ham'}}



# Generated at 2022-06-21 22:25:59.157494
# Unit test for constructor of class Tree
def test_Tree():
    main_tree = Tree()
    main_tree[':app'][':settings'][':config'] = 'All hail Lord Xenu!'

# Generated at 2022-06-21 22:26:07.200253
# Unit test for function tree
def test_tree():
    a = tree()

    a['foo']['bar']['baz'] = 123
    assert a['foo']['bar']['baz'] == 123

    a['foo']['bar']['baz']['kitty'] = 'meow'
    assert a['foo']['bar']['baz']['kitty'] == 'meow'

    assert a['doesnotexist'] == collections.defaultdict(dict)



# Generated at 2022-06-21 22:26:09.916660
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for constructor of class RegistryTree."""
    tree = RegistryTree({'a': {'b': 'c'}})
    assert tree['a:b'] == 'c'



# Generated at 2022-06-21 22:26:13.901783
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({
        'key': 'value',
        'key:sub': 'subvalue',
        'key:sub:subsub': 'subsubvalue'
    })

    assert t['key'] == 'value'
    assert t['key:sub'] == 'subvalue'
    assert t['key:sub:subsub'] == 'subsubvalue'



# Generated at 2022-06-21 22:26:20.386027
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for `set_tree_node`:
    Create tree, set value, then confirm it exists.
    """
    test_tree = {}
    set_tree_node(test_tree, 'foo:bar:baz', 'Hello World')
    assert test_tree['foo']['bar']['baz'] == 'Hello World'


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-21 22:26:26.484843
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert t.namespace == ''
    assert t.get('foo', 'bar') == 'bar'

    t = Tree({'foo': 'bar'})
    assert t.namespace == ''
    assert t.get('foo') == 'bar'

    t = Tree({'foo': 'bar'}, namespace='uwu')
    assert t.namespace == 'uwu'
    assert t.get('foo') == 'bar'
    assert t.get('foo', namespace='uwu') == 'bar'



# Generated at 2022-06-21 22:26:32.647084
# Unit test for constructor of class Tree
def test_Tree():
    data = {
        'foo': 'bar',
        'boo': {
            'hello': 'world'
        }
    }
    tree = Tree(initial=data)

# Generated at 2022-06-21 22:26:34.707403
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree.__setitem__('a', {'b':'c'})



# Generated at 2022-06-21 22:26:45.472991
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(namespace='/')
    _ = tree._namespace_key  # noqa

    tree[':'] = 'Root'
    tree['a:a:a:a:'] = 'Leaf'

    # Basic fetching
    assert tree['a:a:a:a:'] == 'Leaf'

    # Can fetch root node
    assert tree[':'] == 'Root'

    # Fetching parent node works

# Generated at 2022-06-21 22:27:56.879974
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test = Tree()
    assert test['foo'] == {}
    test['foo']['bar'] = 'baz'
    assert test['foo'] == {'bar': 'baz'}
    assert test['bar'] == {}
    assert test['foo:bar'] == 'baz'

