

# Generated at 2022-06-21 22:17:58.095832
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    assert '__setitem__' in dir(object())



# Generated at 2022-06-21 22:18:06.320444
# Unit test for constructor of class Tree
def test_Tree():
    """Constructor of class Tree"""
    expected_result = {
        'key0': 'value',
        'key1': {
            'key1': 'value',
            'key2': {'key3': 'value'}
        }
    }

    my_tree = Tree({'key0': 'value'})
    my_tree['key1:key2:key3'] = 'value'
    my_tree['key1'] = {'key1': 'value'}
    result = dict(my_tree)
    assert result == expected_result



# Generated at 2022-06-21 22:18:15.539491
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'spam': {
        'egg': 'ham',
        'sausage': 'bacon',
        'spam': {
            'foo': 'bar',
            'baz': 'qux'
            }
        },
    'spam2': {
        'foo': 'bar',
        'baz': 'qux'
        }
    })
    assert_equal(tree['spam:egg'], 'ham')
    assert_equal(tree['spam2']['foo'], 'bar')
    assert_equal(get_tree_node(tree, 'spam:egg'), 'ham')
    assert_equal(get_tree_node(tree, 'spam:egg:foo', default={'foo': 'bar'}), {'foo': 'bar'})
    # Partiall matches

# Generated at 2022-06-21 22:18:17.518181
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert 'bar' == tree['foo']
    assert 'bar' == tree.get('foo')



# Generated at 2022-06-21 22:18:27.795807
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from nose.tools import eq_
    from attrdict import AttrDict
    from . import Tree

    tree = Tree()
    eq_(tree, {})
    tree['a'] = 1
    tree['a:b'] = 2
    tree['a:b:c'] = 3
    tree['a:b:c'] = 4
    eq_(tree, {
        'a': 1,
        'a:b': 2,
        'a:b:c': 4,
    })

    tree = AttrDict()
    tree.a = 1
    tree.a.b = 1
    eq_(tree, {
        'a': {
            'b': 1,
        },
    })



# Generated at 2022-06-21 22:18:37.450298
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert get_tree_node(test_tree, 'a:b:c') == 'd'  # Standard
    assert get_tree_node(test_tree, 'a:b:c:') == 'd'  # Trailing
    assert get_tree_node(test_tree, 'a:b:c:d') == 'd'  # Unnecessary
    assert get_tree_node(test_tree, 'a:b:c:d:e:f:g:h:i') == 'd'  # Unnecessary


# Generated at 2022-06-21 22:18:46.692878
# Unit test for function tree
def test_tree():
    import random
    t = tree()

    # Create tree with levels, complete with random values.
    for i in range(1, 7):
        key = ':'.join(['level%s' % x for x in range(1, i)])
        t[key] = random.randrange(1, 100)

    # Print the tree levels
    for i in range(1, 7):
        key = ':'.join(['level%s' % x for x in range(1, i)])
        print(key, t[key])

    # This is our final value.
    assert t['level1:level2:level3:level4:level5:level6'] == t['level6']
    assert t['level1:level2:level3:level4:level5:level6'] == t['level5:level6']

# Generated at 2022-06-21 22:18:49.710844
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register('foo', 'bar')
    assert r['foo'] == 'bar'
    assert r.get('foo') == 'bar'
    assert r.register('foo', 'baz') == 'baz'

# Generated at 2022-06-21 22:19:01.585185
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a:b:c', 'd') == {'a': {'b': {'c': 'd'}}}
    assert set_tree_node({'a': {}}, 'a:b:c', 'd') == {'a': {'b': {'c': 'd'}}}
    assert set_tree_node({'a': {'b': {}}}, 'a:b:c', 'd') == {'a': {'b': {'c': 'd'}}}

    initial = {'a': {'b': {'c': 'd'}}}
    set_tree_node(initial, 'a:b:e', 'f')
    assert initial == {'a': {'b': {'c': 'd', 'e': 'f'}}}


# Generated at 2022-06-21 22:19:04.595488
# Unit test for function tree
def test_tree():
    assert tree()
    t = tree()
    t['a']['b']['c'] = 1
    assert t['a']['b']['c'] == 1



# Generated at 2022-06-21 22:19:10.223610
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': 1, 'b': 2, 'c': {'ca': 1, 'cb': 2}})
    assert t['a'] == 1
    assert t['b'] == 2
    assert t['c:ca'] == 1
    assert t['c:cb'] == 2



# Generated at 2022-06-21 22:19:17.213994
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree({'a':1, 'b':2})
    assert a['a'] == 1
    assert a['b'] == 2

    # Test that Tree is used as a factory for RegistryTree
    assert isinstance(a['c'], RegistryTree)

    # Test that it's a true factory, not a singleton
    assert id(a['c']) != id(a['d'])

# Generated at 2022-06-21 22:19:20.404018
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    # Success
    set_tree_node(mapping, 'test', 'value')
    assert 'value' == mapping['test']

    # Fail
    with pytest.raises(KeyError):
        set_tree_node(mapping, 'test:fail', 'value')



# Generated at 2022-06-21 22:19:29.189831
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class test_class:
        pass

    obj = test_class()
    obj.attr = "Attrib"

    # Create a new RegistryTree object
    tree = RegistryTree()
    tree1 = RegistryTree(namespace='test')

    # Register obj with RegistryTree and check for it by its attribute
    tree1.register(test_class, obj)
    assert tree1.get(test_class, namespace='test') == obj

    # Register obj with RegistryTree and check for it by its name
    tree.register(obj.__name__, obj)
    assert tree.get(obj.__name__) == obj

# Generated at 2022-06-21 22:19:31.845601
# Unit test for function set_tree_node
def test_set_tree_node():
    # Given
    tree = {}
    key = "one:two:three"
    value = 7
    # When
    result = set_tree_node(tree, key, value)
    # Then
    assert result == {"two": {"three": 7}}



# Generated at 2022-06-21 22:19:33.879173
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.register('foo', 'bar')
    assert t['foo'] == 'bar'



# Generated at 2022-06-21 22:19:35.580990
# Unit test for function get_tree_node
def test_get_tree_node():
    # return_default
    # return_parent
    raise NotImplementedError('I have not written the unit test for this yet.')



# Generated at 2022-06-21 22:19:42.631124
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    >>> d = tree()
    >>> d
    defaultdict(<function tree at 0x7f9e9f88af50>, {})
    >>> set_tree_node(d, 'foo:bar:baz', 'test')
    {'foo': {'bar': {'baz': 'test'}}}
    >>> d
    defaultdict(<function tree at 0x7f9e9f88af50>, {'foo': {'bar': {'baz': 'test'}}})
    """
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:19:43.616882
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    pass



# Generated at 2022-06-21 22:19:46.043511
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree()
    assert reg['foo'] == {}


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:19:54.091005
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a.b.c', "test")
    assert tree['a']['b']['c'] == "test"



# Generated at 2022-06-21 22:19:59.983940
# Unit test for function set_tree_node
def test_set_tree_node():
    fixture = tree()
    set_tree_node(fixture, 'test_1:test_2:test_3', 'hello')
    set_tree_node(fixture, 'something:else', 'world')
    assert fixture['test_1']['test_2']['test_3'] == 'hello'
    assert fixture['something']['else'] == 'world'



# Generated at 2022-06-21 22:20:02.932022
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    tree['foo']['baz'] = 'quux'
    assert tree['foo']['baz'] == 'quux'



# Generated at 2022-06-21 22:20:09.359598
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    d = Tree()
    d['a'] = 'foo'
    assert d['a'] == 'foo'
    d['a:b'] = 'bar'
    assert d['a:b'] == 'bar'
    assert d['a'] == tree()
    assert d['a']['b'] == 'bar'



# Generated at 2022-06-21 22:20:12.326880
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.__setitem__('durable:sm:data:a', '1')
    assert t['durable:sm:data:a'] == '1'



# Generated at 2022-06-21 22:20:20.215241
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 'b' == get_tree_node({'a': {'b': 'c'}}, 'a:b')
    assert 'd' == get_tree_node({'a': {'b': 'c'}}, 'a:b:d', default='d')
    assert 'c' == get_tree_node({'a': {'b': 'c'}}, 'a', parent=True)
    with pytest.raises(KeyError):
        get_tree_node({'a': {'b': 'c'}}, 'abc')



# Generated at 2022-06-21 22:20:22.183852
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # TODO: Test case
    assert get_tree_node(None, None) == None



# Generated at 2022-06-21 22:20:28.338980
# Unit test for constructor of class Tree
def test_Tree():
    d = Tree(initial={'foo': {'bar': 'baz'}}, initial_is_ref=False)
    assert 'baz' == d['foo:bar']
    assert 'baz' == d.get('foo:bar')

    d = Tree(initial={'foo': {'bar': 'baz'}}, initial_is_ref=True)
    assert 'baz' == d['foo:bar']
    assert 'baz' == d.get('foo:bar')



# Generated at 2022-06-21 22:20:36.801122
# Unit test for function tree
def test_tree():
    """Unit test function tree()."""
    # Test empty tree
    t = tree()
    assert not t

    # Test basic tree
    some_key = 'some_key'
    some_value = 'some_value'
    t[some_key] = some_value
    assert t[some_key] == some_value

    # Test sub-tree
    t = tree()
    some_sub_key = 'sub.sub.sub'
    t[some_sub_key] = some_value
    assert t[some_sub_key] == some_value



# Generated at 2022-06-21 22:20:42.230910
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree(initial={
        'global': {
            'foo': {
                'bar': ['baz']
            }
        }
    })
    print(t['global:foo:bar'])
    print(t['global:foo:bar:0'])

# Generated at 2022-06-21 22:20:56.699859
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Create empty instance of class Tree
    t = Tree()

    # Test assignment with namespace
    t.namespace = 'ns'
    t.__setitem__('foo', 'bar', namespace='ns2')
    assert t.__getitem__('foo', namespace='ns2') == 'bar'
    t['foo'] = 'bar2'
    assert t.__getitem__('foo') == 'bar2'
    t['foo'] = 'bar3'
    assert t.__getitem__('foo', default=None) == 'bar3'
    del t['foo']
    del t['foo']

    try:
        del t['foo']
    except KeyError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-21 22:21:00.863755
# Unit test for function tree
def test_tree():
    a_tree = tree()
    a_tree['some']['arbitrary']['value'] = True
    assert a_tree['some']['arbitrary']['value'] is True

    assert get_tree_node(a_tree, 'some:arbitrary:value')



# Generated at 2022-06-21 22:21:06.726479
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    with pytest.raises(KeyError):
        tree = Tree()
        tree['not:a: '] = 'value'
        tree.get('not:a: ')
        tree.get('not:a: ', 'default')

# Generated at 2022-06-21 22:21:10.170948
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    class Tree(CollectionsTree):
        namespace = 'test'

    t = Tree()
    # Set item
    t['a'] = 1

    # Test get
    assert t['a'] == 1

    # Test with namespace
    assert t['test:a'] == 1



# Generated at 2022-06-21 22:21:15.024634
# Unit test for function set_tree_node
def test_set_tree_node():
    mydict = {}
    set_tree_node(mydict, 'a:b:c', 1)
    assert mydict == {'a': {'b': {'c': 1}}}



# Generated at 2022-06-21 22:21:21.901144
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'one': {'two': {'three': {}}, 'four': {}}}
    set_tree_node(mapping, 'one:two:three:four', 'four')
    assert mapping['one']['two']['three']['four'] == 'four'



# Generated at 2022-06-21 22:21:24.775517
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'foo': 'bar'}, 'the_namespace')
    assert tree['foo'] == 'bar'
    assert tree['the_namespace:foo'] == 'bar'



# Generated at 2022-06-21 22:21:31.032439
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}

    set_tree_node(tree, 'foo:bar', 'bar')
    set_tree_node(tree, 'foo:baz', 'baz')

    assert tree['foo']['bar'] == 'bar'
    assert tree['foo']['baz'] == 'baz'



# Generated at 2022-06-21 22:21:36.464823
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {'b': {'c': 'd'}}
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'

    tree = {
        'a': [{'b': {'c': 'd'}}]
    }
    assert get_tree_node(tree, 'a:0:b:c') == 'd'

# Generated at 2022-06-21 22:21:41.286008
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    # Create a new RegistryTree
    dimension_0 = RegistryTree()
    dimension_0['Pizza']

    # Set the namespace
    dimension_0.namespace = 'Dimension 0'

    # Register the Key Pizzas
    dimension_0.register('Pizzas', ['Pizza', 'Pizza'])



# Generated at 2022-06-21 22:22:16.087028
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    # Basic usage
    tree['a:b:c:d'] = 1
    assert tree.get('a:b:c:d') == 1
    # Fetching a permissive item with a default
    assert tree.get('a:b:c:f', 'FAIL') == 'FAIL'
    # Fetching a permissive item with a default of ``None``
    assert tree.get('a:b:c:f', None) is None
    # Fetching a non-permissive item with a default
    try:
        tree.get('a:b:c:h', 'FAIL')
    except KeyError:
        pass

# Generated at 2022-06-21 22:22:19.979745
# Unit test for function tree
def test_tree():

    t = tree()
    t['dim1']['dim2']['dim3'] = 'some_value'
    assert t['dim1']['dim2']['dim3'] == 'some_value'



# Generated at 2022-06-21 22:22:24.761368
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    assert isinstance(RegistryTree(), RegistryTree)
    assert isinstance(RegistryTree(namespace='foo'), RegistryTree)
    assert isinstance(RegistryTree({'foo': 'bar'}), RegistryTree)
    assert isinstance(RegistryTree({'foo': 'bar'}, namespace='foo'), RegistryTree)



# Generated at 2022-06-21 22:22:30.605917
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    src = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    key = 'a:b:c'
    val = 'D'
    result = set_tree_node(src, key, val)
    assert result == {'a': {'b': {'c': 'D'}}}
    assert src['a']['b']['c'] == 'D'

# Generated at 2022-06-21 22:22:37.306830
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(d, 'a:b:c') == 'd'
    assert get_tree_node(d, 'a:b:c:d') is _sentinel
    assert get_tree_node(d, 'a:b:c:d', default=None) is None



# Generated at 2022-06-21 22:22:45.453639
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    data = Tree(namespace='my')
    data.register('foo', 'bar')
    data.register('foo:baz', 'baz')
    data.register('foo:baz:boo', 'boo')
    data.register('foo:baz:boo:moo', 'moo')
    data.register('foo:baz:moo:boo', 'moo')

    assert get_tree_node(data, 'foo') == 'bar'
    assert get_tree_node(data, 'foo:baz') == 'baz'
    assert get_tree_node(data, 'foo:baz:boo') == 'boo'

# Generated at 2022-06-21 22:22:51.515489
# Unit test for function tree
def test_tree():
    simple_tree = {
        'toplevel': {
            'sublevel': [
                'a',
                'b',
                'c'
            ]
        }
    }
    second_tree = tree()
    second_tree['toplevel']['sublevel'].append('d')

    assert simple_tree == second_tree



# Generated at 2022-06-21 22:22:56.341036
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {'foo': {'bar': {'hello': 'world'}}}
    assert get_tree_node(m, 'foo:bar:hello') == 'world'
    assert get_tree_node(m, 'foo:bar') == {'hello': 'world'}
    assert get_tree_node(m, 'foo:baz') is _sentinel

# Generated at 2022-06-21 22:23:03.127383
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Unit test for method __setitem__ of class Tree"""
    data = Tree(initial_is_ref=True)
    sample = {'a': {'b': {'c': {'d': {'e': 1}}}}}
    data.update(sample)
    data.register('a:1:2:3:4:5', 5)
    assert data == sample


if __name__ == '__main__':
    import nose
    nose.core.runmodule()

# Generated at 2022-06-21 22:23:08.277043
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 1
    t['a:b:c'] = 2
    t['a:b:d'] = 3
    assert t['a'] == 1
    assert t['a:b:c'] == 2
    assert t['a:b:d'] == 3
    assert t['a:b'] == Tree({'c': 2, 'd': 3})



# Generated at 2022-06-21 22:23:48.582931
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(
        {
            'a': 'A',
            'b': {
                'c': 'C',
                'd': [1, 2, 3, 4],
                'e': {1: 1, 2: 4, 3: 9},
                'x': False,
            },
            'f': ':fail:',
            'g': [
                {'key': 'value'},
                {'key': 'value', 'key2': 'value2'},
                {'key': 'value', 'key2': 'value2', 'key3': 'value3'},
            ],
            'h': {
                'i': 'I',
                'j': {
                    'k': 'K',
                },
            },
        },
        namespace='test',
    )

# Generated at 2022-06-21 22:23:52.289137
# Unit test for function set_tree_node
def test_set_tree_node():
    _mapping = tree()
    _key = 'original.value'
    _value = 'mapping.value'
    set_tree_node(_mapping, _key, _value)
    assert _mapping['original']['value'] == _value



# Generated at 2022-06-21 22:23:56.037346
# Unit test for function tree
def test_tree():
    """
    Run unit tests for tree.
    """
    from nose.tools import ok_
    t = tree()
    t['foo']['bar']['baz'] = 42
    ok_(t == {'foo': {'bar': {'baz': 42}}}, 'Tree function broken')



# Generated at 2022-06-21 22:23:59.841638
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo'] = {'bar': {'baz': 2}, 'men': 'bob'}
    assert t['foo:bar:baz'] == 2
    assert t['foo:men'] == 'bob'
    try:
        t['foo:bar:baz:foo']
    except KeyError:
        return True
    assert False



# Generated at 2022-06-21 22:24:04.026948
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, "abc:def:ghi", 123)
    assert d == {"abc": {"def": {"ghi": 123}}}



# Generated at 2022-06-21 22:24:11.523739
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class FooTree(RegistryTree):
        pass
    f = FooTree(namespace='foo')
    f.register('bar', 'baz', namespace='foo')
    assert f['bar'] == 'baz'  # Check that we can read back when namespace is defaulted
    assert f['foo:bar'] == 'baz'  # Check that we can read back when namespace is specified
    assert f.get('hello', 'world') == 'world'  # Check that we can get defaults
    assert f['foo:hello'] == 'world'  # Check that we can get defaults when namespace is specified



# Generated at 2022-06-21 22:24:17.101485
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(namespace='test')
    tree['test:foo'] = 'bar'

    tree['test:one:two:three'] = 'four'

    assert tree['foo'] == 'bar'
    assert tree['one:two:three'] == 'four'

    assert tree['dne'] is _sentinel
    assert tree.get('dne', 's') == 's'

# Generated at 2022-06-21 22:24:24.115545
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    Test RegistryTree constructor.
    """
    global _
    ref = dict(u1=1, u2=2, u3=3)
    _ = RegistryTree(initial=ref, namespace='universe')
    _.register('m1', 1)
    _.register('m2', 2)
    _.register('m3', 3)
    assert _.get('universe:u1') == 1
    assert _.get('universe:m1') == _.get('m1') == _['m1'] == 1

# Generated at 2022-06-21 22:24:32.577391
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    assert isinstance(tree, RegistryTree)
    assert tree.namespace == ''

    tree = RegistryTree(namespace='foo')
    assert tree.namespace == 'foo'

    tree = RegistryTree(initial_is_ref={'foo': 'bar'}, namespace='baz')
    assert tree.namespace == 'baz'
    assert tree['foo'] == 'bar'

# Generated at 2022-06-21 22:24:41.617118
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'a': {'b': {'c': 'd'}}}, namespace='a:b')
    assert tree['c'] == 'd'
    assert tree.get('c') == 'd'
    assert tree['c:d:e'] == {}
    assert tree.get('c:d:e:f') is None
    assert tree['c:d:e:f'] == {}
    assert tree.get('c:d:e:f') == {}

# Generated at 2022-06-21 22:25:53.899129
# Unit test for function get_tree_node
def test_get_tree_node():
    '''Tests get_tree_node function

    Checks that get_tree_node works as intended.
    '''
    mapping = {'a': {'b': {'c': {'d': 'e'}}}}
    keya = 'a'
    keyb = 'a:b'
    keyc = 'a:b:c'
    keyd = 'a:b:c:d'

    # Test fetching from 'top level'
    assert get_tree_node(mapping, keya) == {'b': {'c': {'d': 'e'}}}

    # Test fetching from one level below
    assert get_tree_node(mapping, keyb) == {'c': {'d': 'e'}}

    # Test fetching from two levels below

# Generated at 2022-06-21 22:26:03.937704
# Unit test for function tree
def test_tree():
    m = Tree()
    m['foo'] = 1
    m['hello:world:how:are:you'] = 2
    m['hello:world:how:are:you'] = 3
    m['how:are:you'] = 4
    m['foo'] = 5
    m['bar:boo'] = 3
    assert m['foo'] == 5
    assert m['bar:boo'] == 3
    assert m['hello:world:how:are:you'] == 3
    assert m['how:are:you'] == 4
    assert m['how']['are']['you'] == 4

    m = Tree(None, 'test')
    assert m['foo'] == {}
    assert m['foo']['bar'] == {}
    assert m['hello:world:how:are:you'] == {}

# Generated at 2022-06-21 22:26:12.386918
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('pouet')
    registry.register('plop')
    registry.register('squeeze')
    registry.register('nested:squeeze')
    registry.register('nested:plop')
    assert registry.namespace is None
    assert registry['pouet'] is not None
    assert registry['plop'] is not None
    assert registry['squeeze'] is not None
    assert registry['nested:squeeze'] is not None
    assert registry['nested:plop'] is not None
    assert registry['nested:plop'] is not None
    assert registry['plop'] is not None
    assert registry['pouet'] is not None

# Generated at 2022-06-21 22:26:22.480976
# Unit test for function get_tree_node
def test_get_tree_node():
    from pytest import raises

    foo = Tree({
        'bar': 'baz'
    })

    assert foo['bar'] == 'baz'
    assert foo.get('baz', '') == ''
    with raises(KeyError):
        foo['baz']
    bar = foo['bar']
    assert bar == 'baz'
    assert foo['bar'] == bar
    foo['baz:bar'] = 'baz'
    assert foo['baz']['bar'] == 'baz'
    foo['baz:bar:baz'] = 'baz'
    assert foo['baz:bar']['baz'] == 'baz'
    with raises(KeyError):
        foo['bar:bar']
    assert foo.get('bar:bar', '') == ''

    # Test against real dict
   

# Generated at 2022-06-21 22:26:24.849179
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree("george", namespace='name')
    assert tree['name:george']
    assert tree['name:george'] == {'name:george'}



# Generated at 2022-06-21 22:26:26.776981
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('foo:bar:baz', 'hello')
    assert registry.get('foo:bar:baz') is 'hello'



# Generated at 2022-06-21 22:26:29.094779
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pprint
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'
    tree[('foo', 'baz')] = 'bang'
    assert tree['foo:baz'] == 'bang'
    #print('\n%s' % tree)
    pprint(tree)



# Generated at 2022-06-21 22:26:31.996409
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    assert t['foo'] == {}
    # TODO Not the best test in the world, need to investigate various data positions
    assert not t['foo:bar']



# Generated at 2022-06-21 22:26:41.651433
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    }
    target = 'e'
    key = 'a:b:c:d'
    assert get_tree_node(data, key) == target
    assert get_tree_node(data, key, default='f') == target
    assert get_tree_node(data, 'bla:bla:blub', default='f') == 'f'
    try:
        get_tree_node(data, 'bla:bla:blub')
        raise ValueError('Should not have come here')
    except KeyError:
        pass



# Generated at 2022-06-21 22:26:49.928188
# Unit test for constructor of class Tree
def test_Tree():
    """
    Test tree functionality.
    """
    t = Tree()
    t['a:b:c'] = 'd'
    assert t['a']['b']['c'] == 'd'
    assert t.get('a:b:c', 'e') == 'd'
    assert t.get('a:b:x', 'e') == 'e'
    assert t.get('z:b:x', 'e') is _sentinel
    assert t.get('z:b:x') is _sentinel

    t = Tree({'a': 1})
    assert t['a'] == 1

    t = Tree({'a': 1}, initial_is_ref=True)
    t['a'] = 2
    assert t['a'] == 2