

# Generated at 2022-06-21 22:18:02.610828
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['test', 'a'] = 'b'
    assert tree['test', 'a'] == 'b'



# Generated at 2022-06-21 22:18:08.051216
# Unit test for function set_tree_node
def test_set_tree_node():
    node = tree()
    set_tree_node(node, 'bob', 'bob')
    set_tree_node(node, 'bob:joe:bob', 'joe')
    set_tree_node(node, 'bob:joe', 'joe')
    set_tree_node(node, 'bob:joe', 'joe')
    return node



# Generated at 2022-06-21 22:18:13.186667
# Unit test for function set_tree_node
def test_set_tree_node():
    """Ensure that setting works properly"""
    mapping = tree()
    set_tree_node(mapping, "a:b:c:d:e:f:g:h:i:j", "foo")
    assert mapping['a']['b']['c']['d']['e']['f']['g']['h']['i']['j'] == 'foo'


# Unittest for class tree:

# Generated at 2022-06-21 22:18:21.139575
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree(namespace='x')
    r.register('y', {'z': 1})
    assert r['y'] == {'z': 1}
    assert r['x:y'] == {'z': 1}
    assert r['x:y:z'] == 1

    r2 = RegistryTree(initial={'y': {'z': 1}}, namespace='x')
    assert r == r2


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 22:18:24.929410
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({
        'a': {
            'b': {
                'c': 1,
            },
        },
    })
    assert t['a:b:c'] == 1



# Generated at 2022-06-21 22:18:35.610802
# Unit test for function tree
def test_tree():
    T = tree()
    T['a']['d'] = 'x'
    T['a']['b'] = 'y'
    T['a']['c'] = 'z'
    assert(T['a']['d'] == 'x')
    assert(T['a']['b'] == 'y')
    assert(T['a']['c'] == 'z')
    assert(T['a'] == {'d': 'x', 'b': 'y', 'c': 'z'})
    assert('d' in T['a'])
    assert(T['a']['a'] == {})
    assert(T['a']['c']['d'] == {})
    assert(len(T['a']['c']) == 1)



# Generated at 2022-06-21 22:18:41.748301
# Unit test for function set_tree_node
def test_set_tree_node():
    from pprint import pprint
    t = tree()
    set_tree_node(t, 'a:b:c', 'hi')
    pprint(t)
    set_tree_node(t['a'], 'd:e', 'hey')
    pprint(t)
    set_tree_node(t, 'a:b:f', 'hello')
    pprint(t)



# Generated at 2022-06-21 22:18:46.631701
# Unit test for constructor of class Tree
def test_Tree():
    import pytest
    assert tree() == Tree()
    with pytest.raises(TypeError):
        Tree(initial='foobar')
    with pytest.raises(TypeError):
        Tree(initial_is_ref=True)
    assert Tree(initial={}) == {}
    assert Tree(initial_is_ref={}) == {}
    assert Tree(initial={'a': 'foo'}) == {'a': 'foo'}



# Generated at 2022-06-21 22:18:50.793073
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Test class can be instantiated
    r = RegistryTree()
    # Test get/set (equiv of a dictionary)
    r['foo'] = 'bar'
    assert r['foo'] == 'bar'
    assert r.get('foo') == 'bar'
    # Test get/set of 'sub trees'
    r['foo:bar'] = 'baz'
    assert r['foo:bar'] == 'baz'
    assert r.get('foo:bar') == 'baz'



# Generated at 2022-06-21 22:18:57.799726
# Unit test for function tree
def test_tree():
    t = tree()
    t['hello']['world']['lulz'] = 'wut'


# Generated at 2022-06-21 22:19:08.416493
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    assert (set_tree_node(t, 'a:b:c', 1) == t['a']['b'])
    assert (set_tree_node(t, 'a:b:d', 2) == t['a']['b'])
    assert (set_tree_node(t, 'a:b:d', 3) == t['a']['b'])
    assert (t['a']['b']['c'] == 1)
    assert (t['a']['b']['d'] == 3)



# Generated at 2022-06-21 22:19:19.907196
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', 'x') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:F', 'x') == 'x'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:F:x:y:z', 'x') == 'x'

# Generated at 2022-06-21 22:19:30.291693
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    this = Tree(namespace='myapp')
    this['foo'] = 'bar'
    this['bar'] = 'baz'
    this['stuff'] = 'thing'
    this['stuff'] = 'stuff'

    # Test with namespace
    assert this['myapp'] is this, this['myapp']

    # Test no namespace
    assert this['foo'] == 'bar', this['foo']
    assert this['bar'] == 'baz', this['bar']
    assert this['stuff'] == 'stuff', this['stuff']

    # Test other namespace
    other = Tree(initial=this, namespace='other')

    assert this['other'] is other, this['other']
    assert other['foo'] == 'bar', other['foo']
    assert other['stuff'] == 'stuff', other['stuff']

# Generated at 2022-06-21 22:19:39.623078
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Method `Tree.__setitem__` unit tests"""
    a = Tree()

    # key is string
    a.register('foo', 'bar')
    assert a.get('foo') == 'bar'
    a.register('foo', 'bar', namespace='ns1')
    assert a.get('foo', namespace='ns1') == 'bar'

    # key is iterable
    a.register(['a', 'b'], 'c')
    assert a.get(['a', 'b']) == 'c'

    # namespace is iterable
    a.register('foo', 'bar', namespace=['ns2'])
    assert a.get('foo', namespace=['ns2']) == 'bar'

    # namespace is also string
    a.register('foo', 'bar', namespace='ns3')
    assert a.get

# Generated at 2022-06-21 22:19:45.074137
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(namespace='test')
    rt.register('a', 'b')
    rt.register('c', 'd')
    rt.register('e', 'f')

    assert rt.get('test:a') == 'b'
    assert rt.get('test:c') == 'd'
    assert rt.get('test:e') == 'f'

# Generated at 2022-06-21 22:19:49.161758
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'home': {
            'user': [
                {
                    'name': 'John'
                },
                {
                    'name': 'Jane'
                }
            ]
        }
    }
    assert get_tree_node(mapping, 'home:user:0') == {'name': 'John'}
    assert get_tree_node(mapping, 'home:user:0') != {'name': 'Jane'}
    assert get_tree_node(mapping, 'home:user:1') != {'name': 'John'}
    assert get_tree_node(mapping, 'home:user:1') == {'name': 'Jane'}
    assert get_tree_node(mapping, 'home:user:1:name') == 'Jane'

# Generated at 2022-06-21 22:19:55.981476
# Unit test for constructor of class Tree
def test_Tree():
    T = Tree({'k1': 'v1', 'k2': {'k2a': 'v2a', 'k2b': 'v2b'}})
    assert T['k1'] == 'v1'
    assert T['k2:k2b'] == 'v2b'
    assert T['k3'] == Tree()



# Generated at 2022-06-21 22:20:07.620959
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree_1 = Tree()
    tree_1['A'] = 'A'
    tree_1['A:B'] = 'A:B'
    tree_1['A:B:C'] = 'A:B:C'
    tree_1['A:B:C:D'] = 'A:B:C:D'
    tree_1['A:B:C:D:E'] = 'A:B:C:D:E'
    tree_1['A:B:C:D:E:F'] = 'A:B:C:D:E:F'
    tree_1['A:B:C:D:E:F:G'] = 'A:B:C:D:E:F:G'

    tree_2 = Tree()
    tree_2.__setitem__('A', 'A')

# Generated at 2022-06-21 22:20:10.895601
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 'hey')
    assert t['a']['b']['c'] == 'hey'



# Generated at 2022-06-21 22:20:16.509236
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {
        'b': {
            'c': 'd',
            'e': ['f', 'g'],
        },
        'h': {
            'i': 'j',
        }
    }

    assert get_tree_node(a, 'b:c') is 'd'
    assert get_tree_node(a, 'b:e') is ['f', 'g']

# Generated at 2022-06-21 22:20:22.524331
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(initial={'a': 1}, namespace='test')
    assert tree._namespace_key('a') == 'test:a'
    assert tree._namespace_key('a') == 'test:a'



# Generated at 2022-06-21 22:20:26.585721
# Unit test for constructor of class Tree
def test_Tree():
    data = {
        'foo': {
            'bar': {
                'baz': 'value',
            }
        }
    }

    t = Tree(data, namespace='test')
    expected = 'value'
    actual = t['bar:baz']
    assert expected == actual



# Generated at 2022-06-21 22:20:31.374592
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['key1'] = 'value1'
    assert tree['key1'] == 'value1'
    assert tree['unknown'] is None
    assert tree.get('key1') == 'value1'

    tree['key2:key3'] = 'value2'
    assert tree['key2:key3'] == 'value2'

    tree['key2:key3'] = 'value3'
    assert tree['key2:key3'] == 'value3'



# Generated at 2022-06-21 22:20:42.132958
# Unit test for constructor of class Tree

# Generated at 2022-06-21 22:20:43.171599
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    d = {'a': {'a': {'a': 2}}}
    tr = Tree(d)
    assert tr['a:a:a'] == 2



# Generated at 2022-06-21 22:20:51.560483
# Unit test for function get_tree_node
def test_get_tree_node():
    import json
    import pytest

    data = Tree()
    data['foo:bar:xxx'] = 1
    data['foo:bar:yyy'] = 2
    data['bar:baz:xxx'] = 3

    assert data['foo:bar:xxx'] is 1
    assert data['foo:bar:yyy'] is 2
    assert data['bar:baz:xxx'] is 3
    with pytest.raises(KeyError):
        data['a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p']



# Generated at 2022-06-21 22:20:56.280842
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial=dict(treey=7))
    assert t['treey'] == 7
    with pytest.raises(KeyError):
        t['not_a_tree']
    t2 = Tree(initial=t, initial_is_ref=True)
    assert t2['treey'] == 7
    assert t['treey'] == 7
    t2['treey'] = 8
    assert t2['treey'] == 8
    assert t['treey'] == 8



# Generated at 2022-06-21 22:21:00.488202
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'root', 'value')
    assert mapping['root'] == 'value'
    set_tree_node(mapping, 'root:parent:child', 'value')
    assert mapping['root']['parent']['child'] == 'value'



# Generated at 2022-06-21 22:21:05.691394
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    result = set_tree_node(mapping, 'a:b:c', 3)
    assert result['c'] == 3
    assert mapping['a']['b']['c'] == 3



# Generated at 2022-06-21 22:21:13.678528
# Unit test for constructor of class Tree
def test_Tree():
    # Test namespaced constructor
    new_tree = Tree('test_name').data
    assert new_tree[0].namespace == 'test_name'
    assert new_tree[0].data == tree()
    assert new_tree[1].data == tree()
    assert new_tree[1].namespace == 'test_name'

    # Test actual data.
    new_tree['dimension1:dimension2'] = 'value'
    assert new_tree['dimension1:dimension2'] == 'value'

    new_tree = Tree({'dimension1': 'value'})
    assert new_tree['dimension1'] == 'value'

    # Test that namespaces are used
    new_tree = Tree('test_name')
    new_tree['dimension1'] = 'value'
    assert new_tree['dimension1'] == 'value'
   

# Generated at 2022-06-21 22:21:24.324612
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['hello'] = 'world'
    assert tree['hello'] == 'world'

    assert tree['hello:world'] is None
    tree['hello:world', 'there'] = 'earth'
    assert tree['hello:world', 'there'] == 'earth'

    tree['hello:world', 'there:earth'] = 'path'
    assert tree['hello:world', 'there:earth'] == 'path'

    tree['hello:world', 'there:earth:path'] = '.'
    assert tree['hello:world', 'there:earth:path'] == '.'

# Generated at 2022-06-21 22:21:28.410014
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pprint
    d = Tree()
    d['foo'] = 'bar'
    pprint(d)
    d['foo']['baz'] = 'bang'
    pprint(d)

# Generated at 2022-06-21 22:21:35.875192
# Unit test for function set_tree_node
def test_set_tree_node():
    d = collections.defaultdict(collections.OrderedDict)
    set_tree_node(d, 'name:first', 'Bart')
    set_tree_node(d, 'name:last', 'Simpson')
    # assert d[0]['name']['first'] == 'Bart'
    assert d['name']['first'] == 'Bart'
    assert d['name']['last'] == 'Simpson'
    assert get_tree_node(d, 'name:first') == 'Bart'



# Generated at 2022-06-21 22:21:38.086044
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    instance = Tree()
    instance['foo'] = 'bar'
    assert instance['foo'] == 'bar'


# Generated at 2022-06-21 22:21:41.768313
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    m = Tree()
    m['x'] = 5
    m['foo:bar'] = {'baz': 7}
    assert m.get('x') == 5
    assert m.get('foo:bar:baz') == 7



# Generated at 2022-06-21 22:21:43.645684
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 1
    assert t['a'] == 1



# Generated at 2022-06-21 22:21:45.362513
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    obj = Tree()
    obj[0] = 1
    assert obj[0] == 1
    assert obj[0:0] == 1

# Generated at 2022-06-21 22:21:50.485307
# Unit test for function set_tree_node
def test_set_tree_node():
    result = set_tree_node(Tree(), 'cat:dog:chicken', 'quackers')
    assert 'chicken' in result['dog']
    assert result['dog']['chicken'] == 'quackers'



# Generated at 2022-06-21 22:21:59.165641
# Unit test for constructor of class Tree
def test_Tree():
    """
    Unit test for `Tree` class, which should be tested generically.
    """

    # Create Tree
    tree = Tree()

    # Create namspace
    tree['demo'] = Tree('demo', namespace='demo')

    # Verify Tree contents
    assert 'demo' in tree
    assert 'demo' in tree['demo']
    assert 'demo:demo' in tree
    assert 'demo:demo' in tree['demo']
    assert 'demo' in tree['demo:demo']
    assert 'demo:demo' in tree['demo:demo']
    assert 'demo:demo:demo' in tree['demo:demo'], "collections.defaultdict(Tree) and not collections.defaultdict(dict) was created"

# Generated at 2022-06-21 22:22:02.467795
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = {'bar': {'baz': 'blub'}}
    assert (tree['foo']['bar']['baz']) == 'blub'



# Generated at 2022-06-21 22:22:11.650323
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    attrs = dict(test_value='test value')
    t = Tree(initial=attrs)
    assert t.get('test_value') == 'test value'
    assert t.get('test_value', default=123) == 'test value'
    assert t.get('nonexistant', default=123) == 123
    assert t['test_value'] == 'test value'
    with pytest.raises(KeyError):
        t.get('nonexistant')
    with pytest.raises(KeyError):
        t['nonexistant']



# Generated at 2022-06-21 22:22:23.790937
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('apples:red:delicious', '1')
    assert tree.get('apples:red:delicious') == '1'
    assert tree.get(['apples', 'red', 'delicious']) == '1'
    assert tree.get([[['apples', 'red'], 'delicious']]) == '1'

    tree = RegistryTree({'test': '1'})
    tree.register('test2', 2)
    assert tree.get('test') == '1'
    assert tree.get('test:') == '1'
    assert tree.get('test2') == 2
    assert tree.get('test2:') == 2
    assert tree.get('test3') is _sentinel


# Generated at 2022-06-21 22:22:32.474271
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    TEST_MAPPING = {
        'a': 1,
        'b': {
            'c': 2,
            'd': {
                'e': 3,
            }
        }
    }

    TEST_EXPECTED = {
        'a': {
            'a': 1
        },
        'b': {
            'c': 2,
            'd': {
                'e': 3,
            }
        },
        'b:c': {
            'c': 2
        },
        'b:d': {
            'd': {
                'e': 3,
            }
        }
    }


# Generated at 2022-06-21 22:22:35.026787
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'foo': {'bar': 'baz'}})
    assert t['foo:bar'] == 'baz'


# Generated at 2022-06-21 22:22:38.964674
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.defaultdict(lambda: {})
    set_tree_node(mapping, 'test:test:test:test', 'foo')
    assert mapping['test']['test']['test']['test'] == 'foo'



# Generated at 2022-06-21 22:22:44.467602
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import unittest
    from inspect import currentframe, getouterframes
    from os.path import basename, splitext

    class TestTree___setitem__(unittest.TestCase):

        def test_Tree___setitem__(self):
            _m = self
            args = _m.get_tree___setitem___arguments()
            _m.assertRaises(TypeError, _m.tree___setitem__, *args)
            _m.assertRaises(TypeError, _m.tree___setitem__, *args)

        def tree___setitem__(self, *args):
            return Tree.__setitem__(self, *args)

        def get_tree___setitem___arguments(self):
            return [None, None]

    filename = splitext(basename(__file__))

# Generated at 2022-06-21 22:22:51.233163
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    d = collections.defaultdict(dict)
    d['a']['b'] = 'c'
    t = Tree()
    t.update(d)
    assert(t['a:b'] == 'c')
    try:
        assert(t['nonexistent'] == 'c')
    except KeyError:
        "As expected"


if __name__ == '__main__':
    test_Tree___getitem__()

# Generated at 2022-06-21 22:22:52.162483
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass



# Generated at 2022-06-21 22:23:02.791838
# Unit test for constructor of class Tree
def test_Tree():
    """
    Sanity-check for class Tree.
    """
    t = Tree({'test': 'TEST', 'test:two': 'TEST 2'})
    assert t['test'] == 'TEST'
    assert t['test:two'] == 'TEST 2'

    t = Tree({'test': 'TEST', 'test:two': 'TEST 2'}, namespace='test')
    assert t['test'] == 'TEST'
    assert t['two'] == 'TEST 2'

    t = Tree({'test': 'TEST', 'test:two': 'TEST 2'}, initial_is_ref=True)
    assert t['test'] == 'TEST'
    assert t['test:two'] == 'TEST 2'


# Generated at 2022-06-21 22:23:10.752182
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_registry = RegistryTree()
    test_registry.register('test1', 'test1_value')
    test_registry.register('test2:test2_1', 'test2_value')
    assert test_registry['test1'] == 'test1_value'
    assert test_registry['test2:test2_1'] == 'test2_value'
    test_registry['test3:test3_1'] = 'test3_value'
    assert test_registry['test3:test3_1'] == 'test3_value'
    test_registry['test4:test4_1:test4_2'] = 'test4_value'
    assert test_registry['test4:test4_1:test4_2'] == 'test4_value'



# Generated at 2022-06-21 22:23:17.637878
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 3
    t['a']['b']['d'] = 4
    t['a']['e'] = 5
    assert t['a']['b']['c'] == 3
    assert t['a']['e'] == 5


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-21 22:23:24.292182
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'foo:bar:baz', 'quux')
    assert test_dict['foo']['bar']['baz'] == 'quux'
    try:
        test_dict['foo']['bar']['baz2']
        raise AssertionError('Test failed, tree node set improperly.')
    except KeyError:
        pass



# Generated at 2022-06-21 22:23:33.808579
# Unit test for function get_tree_node
def test_get_tree_node():
    # Create a Tree
    test_tree = Tree()

    # Fill it with data
    test_tree['one'] = 'One'
    test_tree['two:thing1'] = 'Thing1'
    test_tree['two:thing2'] = 'Thing2'
    test_tree['three:data:test1'] = 'Test1'
    test_tree['three:data:test2'] = 'Test2'

    # Test retrieval of data
    assert test_tree['one'] == 'One'
    assert test_tree['two:thing2'] == 'Thing2'
    assert test_tree['three:data:test2'] == 'Test2'

# Generated at 2022-06-21 22:23:34.834223
# Unit test for constructor of class Tree
def test_Tree():
    assert tree() == Tree()



# Generated at 2022-06-21 22:23:38.330175
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    assert t['a'] is t
    assert t['a:b'] is t['a']
    assert t['a:b']['a'] is t['a']



# Generated at 2022-06-21 22:23:46.126125
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Test __setitem__
    Test to check whether the method can also accept namespaces
    """
    t = Tree()
    t['a'] = 'a'
    t['a:b'] = 'b'
    t['a:b:c'] = 'c'
    t['d:e'] = 'e'
    assert all([
        t['a'] == 'a',
        t['a:b'] == 'b',
        t['a:b:c'] == 'c',
        t['d:e'] == 'e',
    ])



# Generated at 2022-06-21 22:23:54.151803
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    def test(tree, namespace, key, expected, return_parent_node=False):
        tree.namespace = namespace
        result = tree[key]
        if return_parent_node:
            result = result[tree.namespace]
        if result != expected:
            raise AssertionError(
                '\n%s[\'%s\']\n= %s !=\n%s' %
                (tree.__class__.__name__, key, result, expected)
            )
        print('PASS: %s[\'%s\'] = %s' % (tree.__class__.__name__, key, result))

    test({'a': 'b'}, '', 'a', 'b')

    test({'a:b:c': 3}, 'a:b', 'c', 3)

# Generated at 2022-06-21 22:23:56.374347
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree(namespace='ns')
    tree['a'] = 1
    tree['a'] = 2
    assert tree['ns:a'] == 2



# Generated at 2022-06-21 22:23:58.573020
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo.bar'] = 'fubar'
    assert t['foo']['bar'] == {'fubar'}, "__setitem__ did not work as expected"



# Generated at 2022-06-21 22:24:03.624290
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree() == {}
    assert Tree(['a']) == {0: 'a'}
    assert Tree('string') == {
        0: 's',
        1: 't',
        2: 'r',
        3: 'i',
        4: 'n',
        5: 'g'
    }
    assert Tree(('t', 'e', 's', 't')) == {
        0: 't',
        1: 'e',
        2: 's',
        3: 't'
    }
    assert Tree({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert Tree({'a': {'b': 1}}, initial_is_ref=True) == {'a': {'b': 1}}



# Generated at 2022-06-21 22:24:09.800720
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    >>> ns = 'yolo'
    >>> r = RegistryTree(namespace=ns)
    >>> r[':'.join([ns, '1'])] = 1
    >>> assert r['1']
    >>> r.register('2', 2)
    >>> assert r['2']
    >>> r = RegistryTree(namespace=ns, initial={'3':3})
    >>> assert r['3']
    >>> r = Tree(namespace=ns, initial={'3':3})
    >>> assert r['3']
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:24:14.091609
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Unit tests for method __getitem__ of class Tree."""

    from datetime import datetime
    from pprint import pformat

    now = datetime.now()
    my_tree = Tree(initial={'a': {'b': {'c': {'d': 'e'}}}})
    assert my_tree['a:b:c:d'] == 'e'

# Generated at 2022-06-21 22:24:24.392630
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Make sure that setting arbitrary tree nodes works as expected.
    """
    data = {}
    set_tree_node(data, 'abc:def:ghi', 'value')
    assert data == {'abc': {'def': {'ghi': 'value'}}}
    assert data.get('abc').get('def').get('ghi') == 'value'
    assert data['abc']['def']['ghi'] == 'value'

    # Ensure that stored values are still stored if set_tree_node is called again
    set_tree_node(data, 'abc:def:x', 'value2')
    assert data == {'abc': {'def': {'ghi': 'value', 'x': 'value'}}}
    assert data['abc']['def']['ghi'] == 'value'

# Generated at 2022-06-21 22:24:35.020994
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree.update(dict(
        a=1,
        b=2,
        c=dict(
            d=3,
            e=4,
        ),
        f=dict(
            g=dict(
                h=5,
                i=dict(
                    j=6
                )
            ),
            k=7,
        )
    ))

    assert tree['a'] == 1
    assert tree['b'] == 2
    assert tree['c:d'] == 3
    assert tree['c:e'] == 4
    assert tree['f:g:h'] == 5
    assert tree['f:g:i:j'] == 6
    assert tree['f:k'] == 7

    with pytest.raises(KeyError):
        tree['c:z']


# Generated at 2022-06-21 22:24:45.820563
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from interject import RegistryTree

    with_objs = RegistryTree({
        'one': 1,
        'two': {
            'three': 3,
            'four': 4,
        }
    })

    assert with_objs.get('one') == 1

    assert with_objs.get(['two', 'three']) == 3

    assert with_objs.get(['two', 'four']) == 4

    with_objs.register('five', 5)

    assert with_objs.get('five') == 5

    with_objs.register(['six', 'six'], 6)

    assert with_objs.get(['six', 'six']) == 6

    assert with_objs.get(['six', 'none']) is None

    assert with_objs.get('none') is None

# Generated at 2022-06-21 22:24:53.522590
# Unit test for function tree
def test_tree():
    t = tree()
    t[1][2][3] = 4
    t[2][3][4] = 5
    t[3][4][5] = 6
    assert t[1][2][3] == 4
    assert t[1][2][3] == 4
    assert t[2][3][4] == 5
    assert t[2][3][4] == 5
    assert t[3][4][5] == 6
    assert t[3][4][5] == 6



# Generated at 2022-06-21 22:24:57.035464
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': 'c',
        },
    }
    assert get_tree_node(tree, 'a:b') == 'c'



# Generated at 2022-06-21 22:25:02.440959
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    assert t.__getitem__('aiohttp.web.request', default=None) is None, ""
    assert t.__getitem__('aiohttp.web.request', default=None) is None, ""
    assert t.__getitem__('aiohttp.web.request', default=None) is None, ""
    assert t.__getitem__('aiohttp.web.request', default=None) is None, ""
    assert t.__getitem__('aiohttp.web.request', default=None) is None, ""



# Generated at 2022-06-21 22:25:11.427296
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test `get_tree_node`."""
    import pytest
    tree = {
        'a': {
            'b': {
                'c': None
            }
        }
    }

    # Test that default value is returned when value is not found
    assert get_tree_node(tree, 'a:b:c:d', default='d') == 'd'

    # Test that an exception is raised when value is not found, and no default is provided
    with pytest.raises(KeyError):
        get_tree_node(tree, 'a:b:c:d')

    # Test retrieval of nodes
    assert get_tree_node(tree, 'a') is tree['a']
    assert get_tree_node(tree, 'a:b') is tree['a']['b']
    assert get_tree

# Generated at 2022-06-21 22:25:19.935233
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Testing with a simple one-dimensional tree
    print("1-dimensional test")
    tree = Tree()
    assert tree['a'] == tree('a')
    assert tree.get('a') == tree('a')
    tree.update({'a': 'a', 'b': 'b'})
    assert tree['a'] == 'a'
    assert tree.get('a') == 'a'
    assert tree.get('c') == tree('c')
    assert tree.get('c', 'c') == 'c'
    try:
        tree['c']
    except KeyError:
        pass
    else:
        raise Exception("Should raise KeyError")

    # Testing with a nested tree, using ':' as the namespace delimeter.
    print("2-dimensional test")
    tree = Tree()

# Generated at 2022-06-21 22:25:26.831916
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(initial={'a': {'b': {'c': {'d': [1, 2, 3]}}}})
    assert tree['a:b:c:d'] == [1, 2, 3]



# Generated at 2022-06-21 22:25:36.156867
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Create instance of Tree
    tree = Tree()

    # Setting attributes of instance...
    tree['name'] = 'Adam'
    tree['children']['bob'] = 'Bob'
    tree['children']['tim'] = 'Tim'
    tree['parent']['mother'] = 'Mary'

    # Retrieving instances of Tree with method __getitem__
    assert tree['name'] == 'Adam'
    assert tree['children']['bob'] == 'Bob'
    assert tree['children']['tim'] == 'Tim'
    assert tree['parent']['mother'] == 'Mary'

# Generated at 2022-06-21 22:25:38.381569
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    assert tree.__setitem__('key', 'value') == {'key': 'value'}



# Generated at 2022-06-21 22:25:42.861372
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import nose

    tree = Tree()
    tree['a']['b']['c'] = 'foo'

    nose.tools.eq_(tree['a:b:c'], 'foo')
    nose.tools.ok_(tree['a:b:c:d'] is _sentinel)
    nose.tools.ok_(tree['a:b:c:d', 'bar'] is 'bar')


# vim: ts=4 sw=4 expandtab

# Generated at 2022-06-21 22:25:50.132049
# Unit test for function tree
def test_tree():
    # Test case for tree()
    t = tree()
    t['a']['b']['c'] = 'd'
    t['a']['b']['f'] = 'g'
    assert t['a']['b']['c'] == 'd'
    assert t['a']['b']['f'] == 'g'
    assert t['a:b:f'] == 'g'
    assert t['a']['b']['f'] == 'g'



# Generated at 2022-06-21 22:25:53.856283
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    def hello():
        print("Hello!")

    registry = RegistryTree()
    registry.register("hello", hello)
    registry["hello"]()

if __name__ == "__main__":
    test_RegistryTree()

# Generated at 2022-06-21 22:25:55.551108
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 'b'
    assert t['a'] == 'b'



# Generated at 2022-06-21 22:25:58.265401
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('registry:class:something', object)
    assert tree['registry:class:something'] is object
    instance = tree['registry:class:something']()
    assert isinstance(instance, object)

# Generated at 2022-06-21 22:26:01.911998
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Constructor is expected to return a RegistryTree-instance
    assert isinstance(RegistryTree(), RegistryTree)



# Generated at 2022-06-21 22:26:12.008335
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from tree_test_mapping import tree_test_mapping
    # Test without namespace
    my_tree = Tree(initial=tree_test_mapping)
    assert my_tree['foo'] == tree_test_mapping['foo']
    assert my_tree['foo:bar'] == tree_test_mapping['foo']['bar']
    assert my_tree['foo:bar:blech'] == tree_test_mapping['foo']['bar']['blech']
    assert my_tree['foo:bar:blech:baz'] == tree_test_mapping['foo']['bar']['blech']['baz']
    assert my_tree['quux:foo:bar:blech'] == tree_test_mapping['quux']['foo']['bar']['blech']
   

# Generated at 2022-06-21 22:26:22.487676
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}

    set_tree_node(mapping, 'test:node', 'nodevalue')

    assert mapping == {'test': {'node': 'nodevalue'}}



# Generated at 2022-06-21 22:26:26.601892
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pprint as pp
    t = Tree({
        'foo': {
            'bar': 'baz',
            'baz': {
                'foo': 'bar',
                'poo': 'goo',
            },
        },
    })
    assert t.get('foo:bar') == 'baz'
    assert t.get('foo:baz:foo') == 'bar'
    assert t.get('foo:baz:poo') == 'goo'
    assert t.get('foo:baz:bar') is None

    # Add a new node to the tree
    t['foo:baz:bar'] = 'baz'
    assert t.get('foo:baz:bar') == 'baz'

# Generated at 2022-06-21 22:26:32.770793
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    x = Tree()

    # Default return for an empty instance
    assert x['foo'] == x
    assert x['foo']['bar'] == x
    assert x['foo']['bar']['baz'] == x
    assert x['foo']['bar']['baz']['lol'] == x
    assert 'lol' in x['foo']['bar']['baz']

    # Simpler syntax
    x.register('lol', 'lol')
    x.register('foo:bar', 'bar')
    x.register('foo:bar:baz', 'baz')

    assert x['foo']['bar']['baz'] == 'baz'
    assert x['lol'] == 'lol'
    assert x['foo']['bar'] == 'bar'

    # Overwrite

# Generated at 2022-06-21 22:26:39.150354
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node()"""
    MAP = {'a': {'b': 1}}

    assert MAP['a'] == {'b': 1}
    assert set_tree_node(MAP, 'a:c', 2) == {'b': 1, 'c': 2}
    assert MAP['a'] == {'b': 1, 'c': 2}



# Generated at 2022-06-21 22:26:46.618484
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    d = Tree()
    d['a'] = '1'
    assert d['a'] == '1'

    d['a:b'] = '2'
    assert d['a:b'] == '2'

    d['a:b:c'] = '3'
    assert d['a:b:c'] == '3'

    d['a:b:c:d'] = '4'
    assert d['a:b:c:d'] == '4'

    d['a:b:c:d:e'] = '5'
    assert d['a:b:c:d:e'] == '5'



# Generated at 2022-06-21 22:26:53.180494
# Unit test for function tree
def test_tree():
    t = tree()
    t['a:b:c:d'] = 1
    # t['a']['b']['c']['d'] = 1
    assert t['a:b:c']['d'] == 1
    assert t['a']['b']['c']['d'] == 1
    assert t['a:b:c:d'] == 1

    t = tree()
    t['a:b:c:d']['g'] = 1
    assert t['a:b:c:d:g'] == 1
    assert t['a']['b']['c']['d']['g'] == 1

    t = tree()
    t['a:b']['c:e']['d'] = True

# Generated at 2022-06-21 22:26:56.311932
# Unit test for function tree
def test_tree():
    t = tree()
    assert t['a', 'b', 'c'], "Func tree() is not a tree, it's a bush!"

# Generated at 2022-06-21 22:27:06.429277
# Unit test for function set_tree_node
def test_set_tree_node():
    d_a = {"a": dict(), "b": dict()}
    d_b = {"a": dict(), "b": dict()}
    assert d_a == d_b
    set_tree_node(d_b, "a:foo", "bar")
    assert d_a != d_b
    assert d_b == {"a": {"foo": "bar"}, "b": dict()}
    set_tree_node(d_b, "b:foo", "baz")
    assert d_b == {"a": {"foo": "bar"}, "b": {"foo": "baz"}}
    set_tree_node(d_b, "b:foo", "qux")
    assert d_b == {"a": {"foo": "bar"}, "b": {"foo": "qux"}}

# Generated at 2022-06-21 22:27:15.520806
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'top-most value'
            }
        }
    }

    assert get_tree_node(mapping, 'a') == {
        'b': {
            'c': 'top-most value'
        }
    }

    assert get_tree_node(mapping, 'a:b') == {
        'c': 'top-most value'
    }

    assert get_tree_node(mapping, 'a:b:c') == 'top-most value'

    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel



# Generated at 2022-06-21 22:27:17.076934
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree() is Tree()
    assert Tree() is not Tree(initial=None)



# Generated at 2022-06-21 22:27:42.663183
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert_equal = assertEqual = nose.tools.assert_equal

    # Test single dimension
    tree_ = Tree({'foo': {'bar': 'baz'}})
    assert_equal(tree_['foo']['bar'], 'baz')
    assert_equal(tree_['foo'].get('bar'), 'baz')

    # Test multi-dimensional
    tree_ = Tree({'foo': {'bar': 'baz'}})
    assert_equal(tree_['foo:bar'], 'baz')

    tree_ = Tree({'foo': {'bar': {'baz': 'qux'}}})
    assert_equal(tree_['foo:bar:baz'], 'qux')


# Generated at 2022-06-21 22:27:50.646611
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    assert set_tree_node(t, 'a:b:c:d', 1) == {'c': {'d': 1}}
    assert set_tree_node(t, 'a:b:x', 2) == {'x': 2}
    assert set_tree_node(t, 'g:f:x', 3) == {'f': {'x': 3}}
    assert set_tree_node(t, 'a:b:x:y:z:x', 4) == {'x': {'y': {'z': {'x': 4}}}}
    assert t


# Generated at 2022-06-21 22:27:53.889828
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t[':foo:bar:baz'] = 'hello'
    assert t[':foo:bar:baz'] == 'hello'



# Generated at 2022-06-21 22:27:57.573043
# Unit test for function tree
def test_tree():
    data = tree()
    data['one']['two']['three'] = 'THREE'
    assert data['one']['two']['three'] == 'THREE'

