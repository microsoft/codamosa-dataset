

# Generated at 2022-06-21 22:18:10.904053
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    print('Testing Tree.__setitem__()... ', end='')
    root = Tree()
    root[':a:b:c'] = 1
    root[':a:b:d'] = 2
    root[':a:e'] = 3
    root[':f:g:h:i:j'] = 4
    assert root[':a']['b']['c'] == 1
    assert root[':a']['b']['d'] == 2
    assert root[':a']['e'] == 3
    assert root[':f']['g']['h']['i']['j'] == 4
    root[':a:b:c'] = 5
    assert root[':a']['b']['c'] == 5

# Generated at 2022-06-21 22:18:14.236510
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    assert type(RegistryTree()) is RegistryTree
    assert type(RegistryTree({})) is RegistryTree
    assert type(RegistryTree({}, initial_is_ref=True)) is RegistryTree
    assert type(RegistryTree({}, 'testnamespace')) is RegistryTree



# Generated at 2022-06-21 22:18:18.033211
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 'a'
    assert t.get('a') == 'a'

    t.register('b', 'b')
    assert t.get('b') == 'b'

    t['c:d'] = 'c:d'
    assert t.get('c:d') == 'c:d'



# Generated at 2022-06-21 22:18:23.794164
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = Tree(namespace='foobar')
    registry.register('my_key', 'my_value')
    assert registry == {
        'foobar': {
            'my_key': 'my_value'
        }
    }

    assert registry.get('my_key') == 'my_value'



# Generated at 2022-06-21 22:18:28.114819
# Unit test for function tree
def test_tree():
    """
    >>> test_tree()
    {'a': {'b': {'c': {'d': 'e'}}}}
    """
    d = tree()
    d['a']['b']['c']['d'] = 'e'
    pprint(d)



# Generated at 2022-06-21 22:18:30.577459
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(initial_is_ref=True)
    tree.register('b.c.d', 1)
    assert tree['b.c.d'] == 1



# Generated at 2022-06-21 22:18:34.019121
# Unit test for constructor of class Tree
def test_Tree():
    test_registry = RegistryTree()
    test_registry.namespace = 'test'
    test_registry['foo'] = 'bar'
    assert test_registry['test:foo'] == 'bar'



# Generated at 2022-06-21 22:18:39.854309
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'apples': 2,
        'pears': 2,
        'strawberries': {
            'ones': 1,
            'two': 2,
        }
    }

    assert get_tree_node(tree, 'strawberries:ones') == 1
    assert get_tree_node(tree, 'strawberries:nones') == _sentinel



# Generated at 2022-06-21 22:18:44.153438
# Unit test for function set_tree_node
def test_set_tree_node():
    d = collections.defaultdict(dict)
    assert set_tree_node(d, 'a:b:c:d', 'VALUE') == {'c': {'d': 'VALUE'}}
    assert set_tree_node(d, 'a:b', 'VALUE') == {'b': 'VALUE'}
    return True



# Generated at 2022-06-21 22:18:49.371951
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()

    registry['foo'] = 1
    registry['bar'] = 2

    assert registry['foo'] == 1
    assert registry['bar'] == 2

    registry.register('baz', 3)

    assert registry['baz'] == 3
    assert registry.data == {'foo': 1, 'bar': 2, 'baz': 3}

if __name__ == "__main__":
    test_RegistryTree()

# Generated at 2022-06-21 22:19:01.585690
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Regression test for #4
    t = Tree()
    t['a'] = 3
    assert t['a'] == 3

    # Regression test for #5
    t = Tree(namespace='a')
    t['b'] = 3
    assert t['b'] == 3
    assert t.get('a:b') == 3
    t['a:b'] = 7
    assert t['b'] == 7

    # Regression test for #6
    t = Tree(namespace='a')
    t['a:b'] = 42
    assert t['b'] == 42
    assert t['a:b'] == 42
    assert t.get('b') == 42



# Generated at 2022-06-21 22:19:08.253177
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}

    # Test default empty tree
    assert set_tree_node(tree, 'foo:bar', 'ok') == {'foo': {'bar': 'ok'}}

    # Test populate existing tree
    tree = {'foo': {'bar': {}}}
    assert set_tree_node(tree, 'foo:bar:baz', 'ok') == {'foo': {'bar': {'baz': 'ok'}}}



# Generated at 2022-06-21 22:19:11.324505
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_tree = Tree()
    test_tree["foo"] = "bar"
    assert test_tree['foo'] == "bar"



# Generated at 2022-06-21 22:19:20.553930
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Test :meth:`Tree._getitem_`

    """
    # Test without namespace
    test_tree = Tree()
    test_tree['beep'] = 'boop'
    assert test_tree['beep'] == 'boop'

    # Test with namespace
    test_tree = Tree(namespace='foo')
    test_tree['beep'] = 'boop'
    assert test_tree['beep'] == 'boop'
    assert test_tree['foo:beep'] == 'boop'
    assert test_tree['beep', 'foo'] == 'boop'
    assert test_tree['beep', 'foo:beep'] == 'boop'


# Generated at 2022-06-21 22:19:24.111808
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree()
    a.register('b:c:d', 'foo')
    assert a['b:c:d'] == 'foo'

# Generated at 2022-06-21 22:19:27.742314
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    assert tree.namespace is None
    tree.__setitem__("foo", "bar", namespace="alpha")

# Generated at 2022-06-21 22:19:32.672904
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    t.register('a', 'blue')
    t.register('b:c:d:e:f', 'green')
    print(t)
    print(t['b'])
    print(t['b:c'])
    print(t['b:c:d'])
    print(t['b:c:d:e'])
    print(t['b:c:d:e:f'])


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-21 22:19:40.335137
# Unit test for constructor of class Tree
def test_Tree():
    # Set up some test data
    key = 'test'
    value = 'success'

    t = Tree()
    t[key] = value

    assert(t[key] is value)

    # Namespace test
    t = Tree(namespace='test')
    t[key] = value

    assert(t[key] is value)
    assert(t['test:test'] is value)

    # Updating test
    t = Tree()
    t[key] = value

    assert(t[key] is value)

    t.update(namespace='test')
    assert(t[key] is value)
    assert(t['test:test'] is value)

# Generated at 2022-06-21 22:19:43.096861
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    rt = RegistryTree(initial={'x': {'y': {'z': 0}}})
    assert rt['x:y:z'] == 0



# Generated at 2022-06-21 22:19:50.986866
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    class Store(RegistryTree):
        namespace = 'store'

    # Create some test data
    store = Store(namespace='store')
    store['foo'] = 'bar'
    store['foo:bar'] = 'baz'

    # Override namespace

# Generated at 2022-06-21 22:19:59.385745
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('something', 'blabla')
    assert rt['something'] == 'blabla'



# Generated at 2022-06-21 22:20:01.622524
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree(namespace='testkey')
    assert reg.namespace == 'testkey', 'RegistryTree did not honor namespace'



# Generated at 2022-06-21 22:20:13.626226
# Unit test for function set_tree_node
def test_set_tree_node():
    # Create a tree
    m = tree()

    # Set a key that is as deep as possible
    set_tree_node(m, 'a:b:c:d', 1)

    # Set a key that's deeper than the tree we just created
    try:
        set_tree_node(m, 'a:b:c:d:e', 2)
    except KeyError:
        pass
    else:
        raise ValueError('Adding a key deeper than a tree should raise KeyError')

    # Make sure the first set value is correct
    if get_tree_node(m, 'a:b:c:d') != 1:
        raise ValueError('The key we set by indexing should have the correct value')

    # Make sure the second set value (the one that failed) is correct

# Generated at 2022-06-21 22:20:18.057382
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """assert 'value2' == Tree(dict(a=dict(b='value2'), a2='value')).get('a:b')"""
    assert 'value2' == Tree(dict(a=dict(b='value2'), a2='value')).get('a:b')



# Generated at 2022-06-21 22:20:28.340990
# Unit test for constructor of class Tree
def test_Tree():

    t = Tree()
    assert dict(t) == {}
    t = Tree({'foo': 'bar'})
    assert dict(t) == {'foo': 'bar'}
    t = Tree([('foo', 'bar')])
    assert dict(t) == {'foo': 'bar'}
    t = Tree(foo='bar')
    assert dict(t) == {'foo': 'bar'}
    t = Tree(foo={'bar': 'baz'})
    assert dict(t) == {'foo': {'bar': 'baz'}}
    t = Tree(namespace='a')
    assert dict(t) == {}
    t = Tree({'foo': 'bar'}, namespace='a')
    assert dict(t) == {'a': {'foo': 'bar'}}

# Generated at 2022-06-21 22:20:32.675312
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Setup
    mapping = Tree()
    mapping['foo:bar'] = 'baz'
    # Exercise
    node = mapping['foo:bar']
    # Verify
    assert mapping['foo:bar'] == 'baz'



# Generated at 2022-06-21 22:20:35.335721
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()

    class a(object):
        pass

    class b(object):
        pass

    registry.register(a, b)
    assert registry[a] == b

# Generated at 2022-06-21 22:20:42.813909
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'foo': 'FOO',
        'bar': {
            'baz': 'BAZ'
        }
    }

    # test_mapping = collections.defaultdict(get_tree_node, test_mapping)
    assert get_tree_node(test_mapping, 'foo') == 'FOO'
    assert get_tree_node(test_mapping, 'bar:baz') == 'BAZ'
    assert get_tree_node(test_mapping, 'bar:baz:fizz') is None

# Generated at 2022-06-21 22:20:46.590805
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t[':ab:c'] = '123'
    assert t['c'] == '123'
    assert t['ab:c'] == '123'
    assert '{}'.format(t) == "defaultdict(<class 'trees.Tree'>, {'ab': defaultdict(<class 'trees.Tree'>, {'c': '123'})})"

# Generated at 2022-06-21 22:20:55.897160
# Unit test for function tree
def test_tree():
    t0 = tree()
    t0['1']['1:1'] = {'1': 1, '2': 2}
    t0['1']['1:2'] = {'1': 1, '2': 2}
    t0['2']['2:1'] = {'1': 1, '2': 2}

    print(t0)
    pprint(t0)

    t1 = tree()
    t1['1:1:1'] = {'1': 1, '2': 2}
    t1['1:1:2'] = {'1': 1, '2': 2}
    t1['1:1:3'] = {'1': 1, '2': 2}
    t1['1:2:1'] = {'1': 1, '2': 2}
    t1

# Generated at 2022-06-21 22:21:07.666099
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    a = Tree()
    a['a'] = 1
    a['b:c'] = 2
    assert a['c'] == 2
    a['b:d'] = 3
    a['b:e:f'] = 3
    assert a['d'] == 3
    assert a['e:f'] == 3
    assert a['b:e'] == 'f'



# Generated at 2022-06-21 22:21:16.455029
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test `set_tree_node` function."""
    test_tree = tree()
    set_tree_node(test_tree, 'foo:bar:baz', 'qux')
    assert test_tree['foo']['bar']['baz'] == 'qux'
    set_tree_node(test_tree, 'hey:yo', 'there')
    assert test_tree['hey']['yo'] == 'there'



# Generated at 2022-06-21 22:21:21.709292
# Unit test for function set_tree_node
def test_set_tree_node():
    my_tree = {}
    set_tree_node(my_tree, 'hello:world:nice', 'day')
    assert get_tree_node(my_tree, 'hello:world:nice') == 'day'



# Generated at 2022-06-21 22:21:26.951079
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['hello'] = 'world'
    tree['foo'] = 'bar'
    tree['hello:world'] = 'yarr'
    assert tree['hello'] == 'world'
    assert tree['foo'] == 'bar'
    assert tree['hello:world'] == 'yarr'



# Generated at 2022-06-21 22:21:33.492052
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t[0] = 1
    t[0][1] = 2
    t[0][2] = 3
    t[0][1][1] = 4
    assert t[0] == {1: 2, 2: 3}
    assert t[0][1] == {1: 4}
    assert t[0][1][1] == 4
    assert t[0][2] == 3



# Generated at 2022-06-21 22:21:36.459759
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Create a new instance of the class Tree
    tree = Tree()

    # Check that the function __setitem__ changes the value at the specified key
    tree['key'] = 'value'
    assert tree['key'] == 'value'



# Generated at 2022-06-21 22:21:41.625747
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree(initial={'foo': {'bar': {'baz': 'bat'}}})
    assert(a == {'foo': {'bar': {'baz': 'bat'}}})
    a = Tree(initial=a)
    assert(a == {'foo': {'bar': {'baz': 'bat'}}})



# Generated at 2022-06-21 22:21:45.369973
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree()
    set_tree_node(tree, 'a:b:c', 'Hello World!')
    assert get_tree_node(tree, 'a:b:c') == 'Hello World!'


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-21 22:21:57.072242
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Run unit tests on get_tree_node
    """
    # Tests on a value contained within the tree
    tree = {
        'key': 'value',
        'key2': {
            'key3': {
                'key4': 'value2',
                'key5': 'value3'
            }
        }
    }

    value = get_tree_node(tree, 'key')
    assert value == 'value'

    value = get_tree_node(tree, 'key2:key3:key4')
    assert value == 'value2'

    value = get_tree_node(tree, 'key2:key3:key5')
    assert value == 'value3'

    # Tests on a value NOT contained within the tree
    value = get_tree_node(tree, 'key4')

# Generated at 2022-06-21 22:22:05.399106
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit tests for function get_tree_node.
    """
    data = {
        'a': [1, 2, 3],
        'b': {
            'c': 'foo',
            'd': {
                'e': 'bar',
                'f': [123, 456, 789],
                'g': {
                    'h': 'baz',
                },
            },
        },
    }
    assert get_tree_node(data, 'b:d:f:2') == 789



# Generated at 2022-06-21 22:22:11.068209
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    regtree = RegistryTree()
    regtree.set('a', 3)
    assert regtree.get('a') == 3



# Generated at 2022-06-21 22:22:22.624736
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('foo', 1)
    assert rt.get('foo') == 1

    rt = RegistryTree({'bar': {'baz': 1}})
    assert rt.get('bar:baz') == 1
    assert rt['bar:baz'] != 2

    rt = RegistryTree(rt)
    assert rt.get('bar:baz') == 1

    rt.register('baz', 2, namespace='bar')
    assert rt.get('bar:baz') == 2

    assert rt['bar:baz'] == 2
    assert rt.get('baz') is None
    assert rt.get('baz', 'foobar') == 'foobar'
    return True

# Generated at 2022-06-21 22:22:28.916833
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['a:a:a'] = 'a'

    # Test both tree.get and tree[] to confirm that default= works
    assert tree.get('a:a:a') == 'a'
    assert tree['a:a:a'] == 'a'
    assert tree.get('a:a:a:a') is None
    assert tree['a:a:a:a'] is None

    # Test Exception
    with pytest.raises(KeyError):
        tree.__getitem__('a:a:a:a') is None



# Generated at 2022-06-21 22:22:35.242996
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a':
                   {'a':
                        {'b':
                             {'c': 'd'}}}}
    assert get_tree_node(mapping, 'a:a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:a') == {'b': {'c': 'd'}}
    assert get_tree_node(mapping, 'a:a:b') == {'c': 'd'}
    assert get_tree_node(mapping, 'a:a:b:b') is _sentinel
    assert get_tree_node(mapping, 'a:a:b:b', default=None) is None

# Generated at 2022-06-21 22:22:38.003707
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a']['b']['c']
    assert tree.get('a:b:c', None) is not None, "Set item doesn't work"
    tree['a:b:c'] = 1
    assert tree.get('a:b:c') == 1, "Get item doesn't work"



# Generated at 2022-06-21 22:22:44.748462
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree()

    set_tree_node(tree, 'a', 'A')
    assert tree['a'] == 'A'

    set_tree_node(tree, 'b:b', 'BB')
    assert tree['b']['b'] == 'BB'

    set_tree_node(tree, 'c:c:c', 'CCC')
    assert tree['c']['c']['c'] == 'CCC'

    set_tree_node(tree, 'd:d:d:d', 'DDDD')
    assert tree['d']['d']['d']['d'] == 'DDDD'



# Generated at 2022-06-21 22:22:48.844458
# Unit test for function tree
def test_tree():
    t = tree()
    t['hello']['world']['goodbye']['world'] = 'hello world'
    assert t['hello']['world']['goodbye']['world'] == 'hello world'



# Generated at 2022-06-21 22:22:53.566688
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Test for method __setitem__(value) of class Tree
    t = Tree()
    t["a:b:c"] = "c"
    assert t["a:b:c"] == "c", "Wrong value for 'a:b:c': %s" % t["a:b:c"]



# Generated at 2022-06-21 22:22:57.332007
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree()
    a.update({
        'a:b': {'a': 10},
        'a:b:c': {'a': 10},
    })
    for i in a['a:b:c'].itervalues():
        assert i == 10

# Generated at 2022-06-21 22:23:03.381235
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(namespace='ns')
    assert rt.namespace == 'ns'
    assert rt.get('bar') is _sentinel
    assert rt['bar'] is _sentinel
    rt.register('baz', True)
    assert rt['baz'] is True
    assert rt.get('baz') is True
    assert rt.get('ns:baz') is True

# Generated at 2022-06-21 22:23:10.160704
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    T = Tree()
    T['a:b:c:d'] = 1
    assert T == {'a': {'b': {'c': {'d': 1}}}}



# Generated at 2022-06-21 22:23:18.167960
# Unit test for constructor of class Tree
def test_Tree():
    from nose.tools import assert_equal
    from random import randint

    # Test non-nested init
    t = Tree(initial={'foobar': randint(1, 100)})
    assert_equal(t['foobar'], t.foobar)

    # Test nested init
    t = Tree(initial={'foo': {'bar': randint(1, 100)}})
    assert_equal(t['foo:bar'], t.foo['bar'], t['foo']['bar'])

    # Test init with namespace
    t = Tree(initial={'foobar': randint(1, 100)}, namespace='test')
    assert_equal(t['test:foobar'], t['foobar'], t.foobar)
    assert_equal(t['test:foobar'], t.test.foobar)



# Generated at 2022-06-21 22:23:24.522333
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register("label", [("world_id", "world_id", 0.0)])
    assert tree.get("label") == [("world_id", "world_id", 0.0)]
    tree = RegistryTree()
    assert tree.get("label", _sentinel) == _sentinel

# End of unit test for constructor of class RegistryTree



# Generated at 2022-06-21 22:23:28.930597
# Unit test for constructor of class Tree
def test_Tree():
    """ Unit test for class Tree """
    t = Tree()
    assert t == {}
    t["a"] = 1
    assert t == {"a": 1}
    assert t["a"] == 1
    assert t.get("a") == 1



# Generated at 2022-06-21 22:23:31.389786
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'boo:far:a:b') == {}



# Generated at 2022-06-21 22:23:37.998782
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert rt.register('a', 'a') == rt.register('b', 'b') == rt.register('c', 'c') == rt.register('d', 'd') == rt
    assert rt.get('a') == 'a'
    assert rt.get('b') == 'b'
    assert rt.get('c') == 'c'
    assert rt.get('d') == 'd'

# Generated at 2022-06-21 22:23:46.557506
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import theano
    theano.config.warn.signal_transfer_error_inspected = False
    import numpy as np
    in_a = np.zeros((10, 3))
    in_b = np.zeros((10, 3))
    out = np.zeros((10, 3))
    t = Tree()
    t['a'] = in_a
    t['b'] = in_b
    t['c'] = out
    t['d'] = in_a

    # TODO: What happens if the key exists?

    # TODO: How does __setitem__ work across the namespace heirarchy?


# Generated at 2022-06-21 22:23:56.074456
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c:d:e:f:g:h:i:j', 'moo')
    assert test_dict == {'a': {'b': {'c': {'d': {'e': {'f': {'g': {'h': {'i': {'j': 'moo'}}}}}}}}}}

    test_dict = {}
    set_tree_node(test_dict, 'a:b:c:d:e:f:g:h:i:j', 'foo')
    assert test_dict == {'a': {'b': {'c': {'d': {'e': {'f': {'g': {'h': {'i': {'j': 'foo'}}}}}}}}}}

   

# Generated at 2022-06-21 22:24:00.838047
# Unit test for function tree
def test_tree():
    data = tree()
    data[0][0][0] = 10
    data[0][0][1] = 20
    data[0][1][0] = 30
    data[0][1][1] = 40
    data[1][0][0] = 50
    data[1][0][1] = 60
    data[1][1][0] = 70
    data[1][1][1] = 80

    assert data[1][1][1] == 80
    assert data[0][1][1] == 40



# Generated at 2022-06-21 22:24:06.382930
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert (get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd')
    assert (get_tree_node({'a': {'b': {'c': 'd'}}}, 'b:c', default=None) is None)



# Generated at 2022-06-21 22:24:18.994980
# Unit test for function tree
def test_tree():
    root = tree()
    assert root == {}
    root[0][1][2][3] = 0
    assert root[0][1][2][3] == 0
    assert root[0][1][2][3] == root[0][1][2][3]



# Generated at 2022-06-21 22:24:21.546460
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    assert tree.get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'



# Generated at 2022-06-21 22:24:24.367960
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'foo': 'bar'})
    assert tree['foo'] == 'bar'



# Generated at 2022-06-21 22:24:31.809882
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    assert t._namespace_key('foo:bar:baz') == 'foo:bar:baz'
    t = Tree(namespace='derp')
    assert t._namespace_key('foo:bar:baz') == 'derp:foo:bar:baz'



# Generated at 2022-06-21 22:24:42.074984
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'config:path', 1)
    set_tree_node(mapping, 'config:path:here', 24)
    set_tree_node(mapping, 'config:path:here:now', 21)
    assert mapping['config']['path']['here']['now'] == 21
    assert mapping['config']['path']['here'] == 24
    assert mapping['config']['path'] == 1


# Generated at 2022-06-21 22:24:52.094191
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    set_tree_node(test_tree, 'hello:world:stuff', 'foo')
    assert test_tree['hello']['world']['stuff'] == 'foo'
    assert test_tree['hello']['world'] == {'stuff': 'foo'}
    assert test_tree['hello'] == {'world': {'stuff': 'foo'}}
    assert test_tree['hello:world:stuff'] == 'foo'
    assert test_tree['hello:world:stuff:foo'] == {}
    assert test_tree['hello:world:stuff:foo:bar']['baz'] == {}

    test_tree['foo'] = 'bar'
    assert test_tree['foo'] == 'bar'
    test_tree['foo:bar'] = 'baz'

# Generated at 2022-06-21 22:25:02.891104
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'

    tree['foo:bar'] = 'baz'
    assert tree['foo:bar'] == 'baz'

    value = {'hello': 'world'}
    tree['foo:bar'].update(value)
    assert tree['foo:bar'] == value

    alist = list()
    tree['foo:bar:alist'] = alist
    assert tree['foo:bar:alist'] == alist

    tree['foo:bar:alist'].append('hello')
    assert tree['foo:bar:alist'] == ['hello']

    tree['foo'] = 'baz'
    assert tree['foo'] == 'baz'



# Generated at 2022-06-21 22:25:05.666325
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree({'foo': {'bar': 'baz'}})
    assert tree['foo:bar'] == 'baz'

# Generated at 2022-06-21 22:25:12.683546
# Unit test for function tree

# Generated at 2022-06-21 22:25:16.815495
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar']['baz'] = 'moo'
    assert t['foo']['bar']['baz'] == 'moo'
    assert t['foo']['bar'] == {'baz': 'moo'}



# Generated at 2022-06-21 22:25:31.426403
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Test case for testing the method __getitem__ of class Tree.
    """
    tree = Tree()
    tree['a'] = 'tree'
    tree['a:b'] = 'branch'
    tree['a:b:c'] = 'leaf'
    tree['a:b:c:d'] = 'branch'
    tree['a:b:c:e'] = 'leaf'

    assert tree['a:b:c'] == 'leaf'
    assert tree['a:b:c:e'] == 'leaf'
    assert tree['a:b:c:d'] == 'branch'

    # Test for raising KeyError
    try:
        tree['a:b:c:d:e']
    except KeyError:
        pass
    else:
        raise AssertionError('Exception not raised')



# Generated at 2022-06-21 22:25:37.305432
# Unit test for function set_tree_node
def test_set_tree_node():
    node = tree()
    set_tree_node(node, 'foo:bar:fubar', 100)
    assert node['foo']['bar']['fubar'] == 100
    set_tree_node(node['foo'], 'bar', 'bar-value')
    assert node['foo']['bar'] == 'bar-value'



# Generated at 2022-06-21 22:25:44.489829
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Initializations
    t = Tree()
    t['a'] = 1
    t['b'] = 2
    t['b:c'] = 3
    t['c:d:e'] = 4
    t['c:e'] = 5
    t['d'] = 6

    # Unit test for correct traversing
    assert t['a'] == 1
    assert t['b'] == 2
    assert t['b:c'] == 3
    assert t['c:d:e'] == 4
    assert t['c:d'] == tree()
    assert t['c:d'] == t[':c:d']
    assert t['c:d'] == t['']['c']['d']
    assert t['c:d:e'] == t['c:d']['e']

# Generated at 2022-06-21 22:25:52.335064
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree[":test_key_1"] = "test_value_1"
    assert tree[":test_key_1"] == "test_value_1"
    tree[":test_key_2"] = "test_value_2"
    assert tree[":test_key_2"] == "test_value_2"
    tree[":test_key_3"] = "test_value_3"
    assert tree[":test_key_3"] == "test_value_3"



# Generated at 2022-06-21 22:25:58.266106
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test for setting a tree node

    Returns:
        None

    """
    # Setup
    test_tree = tree()
    key_to_lookup = 'this:is:a:test'
    test_key = 'value'
    value = 'value'

    # Test
    set_tree_node(test_tree, key_to_lookup, value)

    # Assert result
    result = get_tree_node(test_tree, test_key)
    assert result == value



# Generated at 2022-06-21 22:26:04.311015
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class Foo(object):
        pass

    cls = Foo()
    cls.register(1, 2, namespace="a")

    assert cls.register(3, 4) == {'3': 4}

    print(cls)


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-21 22:26:12.386816
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3
        }
    }
    assert get_tree_node(data, 'b') == 2
    assert get_tree_node(data, 'b:e') == _sentinel
    assert get_tree_node(data, 'b:e', default=66) == 66
    assert get_tree_node(data, 'c:d') == 3
    assert get_tree_node(data, 'c:e') == _sentinel
    assert get_tree_node(data, 'c:d', parent=True) == data['c']



# Generated at 2022-06-21 22:26:22.483170
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node.
    Will crash if get_tree_node is broken.
    """
    data = dict(
        one=dict(
            foo='bar',
            bar=dict(
                foo='bar',
                bar='foo',
            ),
        ),
        two=dict(
            foo=dict(
                bar='foo',
                foo='bar',
            ),
        ),
    )

    assert get_tree_node(data, 'one:foo') == 'bar'
    assert get_tree_node(data, 'one:bar:foo') == 'bar'
    assert get_tree_node(data, 'one:bar:bar') == 'foo'
    assert get_tree_node(data, 'two:foo:foo') == 'bar'
    assert get_tree_node

# Generated at 2022-06-21 22:26:25.975226
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['hue']['huey']['ducky'] = 'joe'
    assert tree['hue']['huey']['ducky'] == 'joe'
    tree['hue']['penguin'] = 'tux'
    assert tree['hue']['penguin'] == 'tux'
    tree['hue']['huey']['ducky'] = 'jane'
    assert tree['hue']['huey']['ducky'] == 'jane'



# Generated at 2022-06-21 22:26:30.121812
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    data = {}
    tree = Tree(data)
    tree['foo'] = 123
    assert data == {'foo': 123}
    tree['bar:baz'] = 456
    assert data == {'foo': 123, 'bar': {'baz': 456}}
    tree['bar:qux'] = 789
    assert data == {'foo': 123, 'bar': {'baz': 456, 'qux': 789}}



# Generated at 2022-06-21 22:26:53.605778
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import pytest
    tree = Tree()
    tree['a'] = 'b'
    tree['a:b'] = 'c'

    assert tree['a'] == 'b'
    assert tree['a:b'] == 'c'

    # Use this test to check __getitem__ works with namespace
    # tree = Tree(namespace='a')
    # tree['b'] = 'c'

    # assert tree['b'] == 'c'

# Generated at 2022-06-21 22:26:54.650228
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'flub': 'berm'})
    assert {'flub': 'berm'} == dict(tree)



# Generated at 2022-06-21 22:27:00.754895
# Unit test for function get_tree_node
def test_get_tree_node():
    # Testing error
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:d')

    # testing failure
    assert get_tree_node(mapping, 'a:b:d', None) is None


# Generated at 2022-06-21 22:27:10.932446
# Unit test for constructor of class RegistryTree

# Generated at 2022-06-21 22:27:20.085229
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': {
                    'qux': 'The Value',
                    'mux': 'The Value2'
                }
            }
        }
    }

    assert get_tree_node(tree, 'foo:bar:baz:qux') == 'The Value'
    assert get_tree_node(tree, 'foo:bar:baz:qux') == 'The Value'
    assert get_tree_node(tree, 'foo:bar:baz:qux') == 'The Value'

    assert get_tree_node(tree, 'foo:bar:baz:qux') == 'The Value'
    assert get_tree_node(tree, 'foo:bar:baz:qux:buux') is _sentinel



# Generated at 2022-06-21 22:27:29.104540
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(tree(), 'hello', 'world') == {'hello': 'world'}

    test_dict = {'foo': {'hello': 'world'}}
    assert set_tree_node(test_dict, 'foo:hello', 'baz') == {'foo': {'hello': 'baz'}}

    assert set_tree_node(tree(), 'foo:bar:baz', 'quux') == {'foo': {'bar': {'baz': 'quux'}}}



# Generated at 2022-06-21 22:27:33.080111
# Unit test for function tree
def test_tree():
    """Assert a tree can be built up and queried."""
    # Build
    tree = tree()
    tree['foo'] = 'bar'
    tree['baz:hello'] = 'world'

    # Query
    assert tree['foo'] == 'bar'
    assert tree['baz:hello'] == 'world'



# Generated at 2022-06-21 22:27:36.169746
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar']['baz'] = 1
    assert t['foo']['bar']['baz'] == 1



# Generated at 2022-06-21 22:27:46.010050
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree()

    info = {}
    tree.set_tree_node(info, 'key1', 'value1')
    assert(tree['key1'] == 'value1')

    tree.set_tree_node(info, 'key2', 'value2')
    assert(tree['key1'] == 'value1')
    assert(tree['key2'] == 'value2')

    tree.set_tree_node(info, 'p1:p2:p3:key3', 'value3')
    assert(tree['key1'] == 'value1')
    assert(tree['key2'] == 'value2')
    assert(tree['key3'] == 'value3')
    assert(tree['p1'] == {'p2': {'p3': {'key3': 'value3'}}})

# Generated at 2022-06-21 22:27:58.220922
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t.data = tree()
    t['a'] = 'one'
    t['a:two'] = 'two'
    t['a:three:four'] = 'four'
    print(t.data)
    print(t.data['a'])
    print(t.data['a']['three'])
    print(t.data['a']['three']['four'])
    print(t.get('a:three'))
    print(t.get('a:five'))
    print(t.get('a:five', default='hi!'))

    t2 = Tree(initial_is_ref=t.data, namespace='spam')
    t['a:three:five'] = 'five'
    print(t2.get('a:three'))

