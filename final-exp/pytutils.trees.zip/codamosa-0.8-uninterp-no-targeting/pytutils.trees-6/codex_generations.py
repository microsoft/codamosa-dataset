

# Generated at 2022-06-21 22:18:01.209540
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tr = RegistryTree(namespace='foobar')
    assert isinstance(tr, dict)
    assert tr['namespace'] == 'foobar'



# Generated at 2022-06-21 22:18:04.736275
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class Registry(RegistryTree):
        namespace = 'reg'

    r = Registry()
    r.register('foo', 'bar')
    assert r['foo'] == 'bar'

# Generated at 2022-06-21 22:18:14.094745
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'foo': {
            'bar': {
                'baz': 'BAZ!'
            }
        }
    }

    try:
        assert get_tree_node(test_mapping, 'foo:bar:QUX') is _sentinel
    except KeyError as exc:
        assert exc.args[0] == "'QUX'"

    assert get_tree_node(test_mapping, 'foo:bar:QUX', default=None) is None
    assert get_tree_node(test_mapping, 'foo:bar:baz') == 'BAZ!'
    assert get_tree_node(test_mapping, 'foo:bar:baz', parent=True) == {
        'baz': 'BAZ!'
    }

# Generated at 2022-06-21 22:18:20.445051
# Unit test for function set_tree_node
def test_set_tree_node():
    m = tree()
    set_tree_node(m, 'a:b:c', 'd')
    assert m == {'a': {'b': {'c': 'd'}}}
    set_tree_node(m, 'foo:bar:baz', 'thing')
    assert m == {
        'a': {'b': {'c': 'd'}},
        'foo': {'bar': {'baz': 'thing'}},
    }
    set_tree_node(m, 'a:b:c', 'thing')
    assert m == {'a': {'b': {'c': 'thing'}}, 'foo': {'bar': {'baz': 'thing'}}}



# Generated at 2022-06-21 22:18:31.354264
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():

    map = Tree({
        'foo': {
            'bar': 'baz'
        },
        'foo_bar': {
            'baz': 'qux'
        },
        'foo_bar_baz': 'qux'
    })

    assert map['foo:bar'] == 'baz'
    assert map['foo_bar:baz'] == 'qux'
    # TODO Assert exception on key not found

    # Test namespace
    map = Tree({
        'foo': {
            'bar': 'baz'
        },
        'foo_bar': {
            'baz': 'qux'
        },
        'foo_bar_baz': 'qux'
    }, namespace='foo')


# Generated at 2022-06-21 22:18:42.771122
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t.update({
        'one': {
            'to': 'the',
            'two': {
                'three': 'four',
            }
        }
    })

    assert get_tree_node(t, 'one:to') == 'the'
    assert get_tree_node(t, 'one:two:three') == 'four'
    assert get_tree_node(t, 'one:two:three:four') is None
    assert get_tree_node(t, 'one:two:three:four', default=None) is None
    assert get_tree_node(t, 'one:two:three:four', default='five') == 'five'

    try:
        get_tree_node(t, 'one:two:three:four')
    except KeyError:
        pass 

# Generated at 2022-06-21 22:18:50.990264
# Unit test for function tree
def test_tree():
    """Unit test for function tree"""
    t = tree()
    t['A']['B']['C'] = 'C'
    t['A']['B']['D'] = 'D'
    t['Z']['Z']['Z'] = 'Y'
    assert t['A']['B']['C'] == 'C'
    assert t['Z']['Z']['Z'] == 'Y'
    assert t['Z']['Z'] == {'Z': 'Y'}

    t['Y'] = 'Y'

    t2 = tree()
    t2.update(t)
    assert t2['A']['B']['C'] == 'C'
    assert t2['Z']['Z']['Z'] == 'Y'

# Generated at 2022-06-21 22:19:02.649413
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Test for Tree.__setitem__"""
    tr = Tree()
    tr.__setitem__(key="foo", value=10)
    assert tr == {'foo': 10}

    tr.__setitem__(key="foo:bar:dowo", value="green")
    assert tr == {'foo': {'bar': {'dowo': 'green'}}}

    tr.__setitem__(key="foo:bar:dowo:two", value={"fish": "blub"})
    assert tr == {'foo': {'bar': {'dowo': {'two': {'fish': 'blub'}}}}}

    tr.__setitem__(key="foo:bar:dowo:two:fish:blub", value=2)

# Generated at 2022-06-21 22:19:15.094518
# Unit test for constructor of class Tree
def test_Tree():
    # Test normal initilization
    t = Tree()
    assert isinstance(t, Tree)

    # Test initial values
    t = Tree({'this': 'init', 'that': 'init'})
    assert t['this'] == 'init'
    assert t['that'] == 'init'

    # Test creating subclass of Tree
    class WeirdTree(Tree):
        pass

    # Test initial values to subclass
    t = WeirdTree({'this': 'init', 'that': 'init'})
    assert t['this'] == 'init'
    assert t['that'] == 'init'

    # Test subclass function override
    class WeirdTree(Tree):
        def get(self, *args, **kwargs):
            return "Goodbye World"

    t = WeirdTree({'this': 'init', 'that': 'init'})

# Generated at 2022-06-21 22:19:23.124055
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({
        'a': 1,
        'b': {'a': 1, 'b': 2},
        'c': {'a': 1, 'b': 2, 'c': 3},
        'd': {'a': 1, 'b': 2, 'c': 3, 'd': 4},
    }, namespace='foo')

    assert t['a'] == 1
    assert t['b'] == {'a': 1, 'b': 2}
    assert t['b:a'] == 1
    assert t['b:b'] == 2
    assert t['c:a'] == 1
    assert t['c:b'] == 2
    assert t['c:c'] == 3
    assert t['d:a'] == 1
    assert t['d:b'] == 2
    assert t['d:c'] == 3


# Generated at 2022-06-21 22:19:33.917027
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Method __getitem__ of class Tree has no unit tests defined.
    """
    raise NotImplementedError(
        "test_Tree___getitem__() not implemented.")



# Generated at 2022-06-21 22:19:40.220567
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'foo:bar:baz', 1) == {'foo': {'bar': {'baz': 1}}}
    assert set_tree_node({'foo': {'bar': {'baz': 1}}}, 'foo:bar:baz', 2) == {'foo': {'bar': {'baz': 2}}}
    assert set_tree_node({'foo': {'bar': {'baz': 1}}}, 'foo:bar:bing', 2) == {'foo': {'bar': {'baz': 1, 'bing': 2}}}



# Generated at 2022-06-21 22:19:43.379221
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    set_tree_node(d, 'test:test:test', 'value')
    assert get_tree_node(d, 'test:test:test') == 'value'



# Generated at 2022-06-21 22:19:49.477741
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class TestModule(object):
        functions = RegistryTree()

    TestModule.functions['test_function'] = 'test_function'
    TestModule.functions.register('test_function_2', 'test_function_2')

    assert TestModule.functions['test_function'] == 'test_function'
    assert TestModule.functions['test_function_2'] == 'test_function_2'
    assert TestModule.functions['test_function_3'] == KeyError

if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-21 22:19:53.408234
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    t['bar'] = {'baz': 'biz'}
    assert t['bar:baz'] == 'biz'
    t['a:b:c:d:e:f:g:h:i:j:k'] = {'l': {'m': 'n'}}
    assert t['a:b:c:d:e:f:g:h:i:j:k:l:m'] == 'n'



# Generated at 2022-06-21 22:19:59.586822
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree([('parent', [('key', ['c'])])])
    assert t['parent:key:0'] == 'c'

    t = Tree({'parent': {'key': 'c'}})
    assert t['parent:key'] == 'c'

    with pytest.raises(KeyError):
        t['parent:key:0']

    assert t['parent:key:0', 'd'] == 'd'



# Generated at 2022-06-21 22:20:10.062751
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Method `__getitem__` of class `Tree` should return the exact value at a provided key,
    or the default value. It should also be able to delve into a Tree using a key with a ':' separator.
    """
    sample = Tree(initial={'bla': {'foo': {'bar': 'corge'}}})
    assert sample['bla:foo'] == {'bar': 'corge'}
    assert sample['bla:foo:bar'] == 'corge'
    assert sample['bla:faz'] == Tree()
    assert sample['bla:faz', 'frotz'] == 'frotz'



# Generated at 2022-06-21 22:20:11.150493
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(initial={
        'a': {
            'b': 'c',
        },
    })
    assert tree['a:b'] == 'c'



# Generated at 2022-06-21 22:20:11.744414
# Unit test for function tree
def test_tree():
    pass

# Generated at 2022-06-21 22:20:22.667603
# Unit test for function tree
def test_tree():
    ref_tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    test_tree = tree()
    test_tree['a']['b']['c'] = 'd'
    assert test_tree == ref_tree
    # raise Exception(test_tree['a']['b'] is test_tree['a']['b'])
    # raise Exception(test_tree.get('a:b:c') == ref_tree['a']['b']['c'])
    assert test_tree.get('a:b:c') == ref_tree['a']['b']['c']
    assert test_tree.get('a:b:c:d', 'default') == 'default'

# Generated at 2022-06-21 22:20:29.576271
# Unit test for constructor of class Tree
def test_Tree():
    tree_obj = Tree(initial={'a': 1, 'b': 2}, namespace='ns',
                    initial_is_ref=False)
    tree_obj.update({'c': 3, 'd': 4})
    print(tree_obj)



# Generated at 2022-06-21 22:20:32.579749
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree()
    reg.register('foo', 'bar')
    assert reg.get('foo') == 'bar'



# Generated at 2022-06-21 22:20:35.236118
# Unit test for function set_tree_node
def test_set_tree_node():
    mydict = {}
    set_tree_node(mydict, 'hello:world', '!')

    assert mydict == {'hello': {'world': '!'}}



# Generated at 2022-06-21 22:20:37.883914
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'a:b:c', 1)
    assert data['a']['b']['c'] == 1



# Generated at 2022-06-21 22:20:44.985426
# Unit test for function tree
def test_tree():
    foo = tree()
    foo['bar']['baz'] = 'something'
    foo['bar']['bar']['baz']['baz'] = 'something else'
    assert foo['bar']['baz'] == 'something'
    assert foo['bar']['bar']['baz']['baz'] == 'something else'
    assert foo['bar']['bar']['baz'] == {'baz': 'something else'}



# Generated at 2022-06-21 22:20:54.728003
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    # key is a string
    tree.__setitem__('key', 'value')
    assert tree['key'] == 'value'
    # key is a list
    tree.__setitem__(['key1', 'key2', 'key3'], 'value')
    assert tree['key1']['key2']['key3'] == 'value'
    # key is a tuple
    tree.__setitem__(('key1', 'key2', 'key3'), 'value')
    assert tree['key1']['key2']['key3'] == 'value'
    # key is a dict
    tree.__setitem__({'key1': {'key2': 'key3'}}, 'value')

# Generated at 2022-06-21 22:20:58.104416
# Unit test for constructor of class Tree
def test_Tree():
    """Unit Test for `:class:`Tree`, see its docstring for details."""
    # Using a lambda as a mock requires a default value
    assert Tree(initial=None, namespace='', initial_is_ref=False)



# Generated at 2022-06-21 22:21:05.839285
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """ Unit test for method __getitem__ of class Tree """
    t = Tree()
    t['test1'] = 'test1_value'
    assert(t['test1'] == 'test1_value')
    t['test2:test3'] = 'test2_test3_value'
    assert(t['test2:test3'] == 'test2_test3_value')



# Generated at 2022-06-21 22:21:11.433893
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()

    # Set a key
    t['test'] = 'test_value'

    # Check that we can get it back
    assert t['test'] == 'test_value'

    # Check that we get a KeyError when asking for a missing key
    with pytest.raises(KeyError):
        t['other']

    # Check that we can get a default value for a missing key
    assert t['other', 'default_value'] == 'default_value'



# Generated at 2022-06-21 22:21:21.442019
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': 'bar',
        'baz': {
            'foo': 'that is totally not the same as bar'
        }
    }
    assert get_tree_node(tree, 'foo') == 'bar'
    assert get_tree_node(tree, 'foo', 'bar') == 'bar'
    assert get_tree_node(tree, 'baz:foo') == 'that is totally not the same as bar'
    # Test default on KeyError
    try:
        get_tree_node(tree, 'baz:foo:bar')
    except KeyError:
        pass
    else:
        assert False, 'Expected to raise KeyError'

    assert get_tree_node(tree, 'baz:foo:bar', 'default') == 'default'

    # Test parent ness

# Generated at 2022-06-21 22:21:34.434595
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from nose.tools import assert_equal
    from pprint import pprint

    tree = RegistryTree()

    tree.register(
        'foo.Foo',
    )

    pprint(tree)
    assert_equal(tree['foo']['Foo'], None)



# Generated at 2022-06-21 22:21:39.345731
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert Tree({'foo': 'bar'})['foo'] == 'bar'
    assert Tree({'foo': {'bar': 'baz'}})['foo:bar'] == 'baz'
    assert Tree({'foo': {'bar': {'baz': 'qwop'}}})['foo:bar:baz'] == 'qwop'



# Generated at 2022-06-21 22:21:45.362461
# Unit test for function set_tree_node
def test_set_tree_node():
    local_dict = {}
    set_tree_node(local_dict, "foo:bar:zoo:1", "rawrr")
    set_tree_node(local_dict, "foo:bar:zoo:2", "rawrr")
    assert local_dict['foo']['bar']['zoo']['1'] == 'rawrr'
    assert local_dict['foo']['bar']['zoo']['2'] == 'rawrr'



# Generated at 2022-06-21 22:21:51.261478
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert rt.register is rt.__setitem__


if __name__ == '__main__':
    test_RegistryTree()
    rt = RegistryTree()
    t = rt.register('', 'testing')
    assert t['testing'] == ''

# Generated at 2022-06-21 22:21:56.287734
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert get_tree_node({'foo': 1, 'baz:bar': 2}, 'foo') == 1
    assert get_tree_node({'foo': 1, 'baz:bar': 2}, 'baz:bar') == 2
    assert get_tree_node({'foo': 1, 'baz:bar': 2}, 'baz:bar:') is _sentinel



# Generated at 2022-06-21 22:21:57.663980
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['yolo'] = 1
    assert tree['yolo'] == 1



# Generated at 2022-06-21 22:22:09.925822
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from collections import defaultdict

    # Instance creation
    instance = defaultdict(Tree)

    # The following exception is expected to occur
    # set_tree_node() takes exactly 3 arguments (2 given)
    try:
        instance.__setitem__('foo')
        raise AssertionError("The following exception was expected to occur: TypeError('set_tree_node() takes exactly 3 arguments (2 given)')")
    except TypeError as e:
        pass

    # The following exception is expected to occur
    # set_tree_node() takes exactly 3 arguments (2 given)
    try:
        instance.__setitem__(1, 2)
        raise AssertionError("The following exception was expected to occur: TypeError('set_tree_node() takes exactly 3 arguments (2 given)')")
    except TypeError as e:
        pass

# Generated at 2022-06-21 22:22:20.979174
# Unit test for constructor of class Tree
def test_Tree():

    def run_test(namespace, use_class_defaults=False, namespace_func_call=True):
        t = Tree(namespace=namespace, initial_is_ref=use_class_defaults)
        t['one'] = 'one'
        if namespace and namespace_func_call:
            assert t['one'] == 'one'
            assert t.get('one') == 'one'
            assert t[':one'] == 'one'  # Namespaced.
        elif namespace and not namespace_func_call:
            assert t['one'] == 'one'
            assert t.get('one') == 'one'
            assert t[':one'] == 'one'  # Namespaced.
        else:
            assert t['one'] == 'one'
            assert t.get('one') == 'one'
            assert t

# Generated at 2022-06-21 22:22:23.919742
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'foo:bar', 'baz')
    assert t['foo']['bar'] == 'baz'



# Generated at 2022-06-21 22:22:26.170356
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Test RegistryTree() constructor."""
    RegistryTree()


if __name__ == '__main__':
    # Unit test for constructor of class RegistryTree
    test_RegistryTree()

# Generated at 2022-06-21 22:22:55.131443
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pprint
    tree = Tree({'a': {'b': {'c': {'d': 'e'}}}, 'a:b': {'c': {'d': 'e'}}}, initial_is_ref=True)
    tree['a:b:c:d'] = 'e'
    print("tree['a:b:c:d'] == %r" % (tree['a:b:c:d']))
    print("tree.get('a:b:c:d', 'f') == %r" % (tree.get('a:b:c:d', 'f')))
    print("tree.get('a:b:c:d:e', 'f') == %r" % (tree.get('a:b:c:d:e', 'f')))

# Generated at 2022-06-21 22:23:06.043955
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': 1,
            'c': {
                'd': 2
            }
        }
    }

    assert get_tree_node(test_tree, 'a:b') == 1
    assert get_tree_node(test_tree, 'a:c') == {'d': 2}
    assert get_tree_node(test_tree, 'a:c:d') == 2
    assert get_tree_node(test_tree, 'a:c:e') == _sentinel
    assert get_tree_node(test_tree, 'a:c:e', default=None) is None

    assert get_tree_node(test_tree, 'a:c:d', parent=True) == {'d': 2}

# Generated at 2022-06-21 22:23:08.938434
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    Unit test for the RegistryTree class.
    """
    tree = RegistryTree()
    tree.register('foo', 'bar')
    assert tree.get('foo') == 'bar'

# Generated at 2022-06-21 22:23:13.830843
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='foo')
    assert t.get('bar') is None
    assert t.get('foo:bar') is None
    t['bar'] = 'bar'
    assert t.get('foo:bar') == 'bar'
    assert t.get('bar') == 'bar'

# Generated at 2022-06-21 22:23:18.503973
# Unit test for function set_tree_node
def test_set_tree_node():
    test1 = tree()
    set_tree_node(test1, 'test1:test2:test3', 'test4')
    assert test1.get('test1:test2:test3') == 'test4'
    assert test1.get('test1:test2:test5') is None



# Generated at 2022-06-21 22:23:28.664623
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert(tree['foo'] == 'bar')
    del tree
    tree = Tree()
    tree['foo:bar'] = 'baz'
    assert(tree['foo:bar'] == 'baz')
    assert(tree['foo'] == {})
    assert(tree['foo']['bar'] == 'baz')
    assert(tree['foo']['bar']['baz'] is KeyError)
    del tree
    tree = Tree()
    tree['foo:bar'] = 'baz'
    assert(tree['foo:bar'] == 'baz')
    assert(tree['foo'] == {})
    assert(tree['foo']['bar'] == 'baz')

# Generated at 2022-06-21 22:23:32.636897
# Unit test for constructor of class Tree
def test_Tree():
    d = {
        'foo': {
            'bar': 'baz'
        }
    }
    d_tree = Tree(d)
    assert d_tree['foo:bar'] == 'baz'



# Generated at 2022-06-21 22:23:34.616999
# Unit test for function tree
def test_tree():
    root = tree()
    root["a"]["b"]["c"] = "blorg"
    root["a"]["d"] = "florg"
    assert root["a"]["b"]["c"] == "blorg"
    assert root["a"]["d"] == "florg"



# Generated at 2022-06-21 22:23:41.149724
# Unit test for constructor of class Tree
def test_Tree():
    test_tree = Tree([
        ('one', 1),
        ('two', 2),
        ('three', 3),
        ('four', 4),
    ])
    assert test_tree['one'] == 1
    assert test_tree['two'] == 2
    assert test_tree['three'] == 3
    assert test_tree['four'] == 4
    assert set(test_tree) == set(('one', 'two', 'three', 'four'))



# Generated at 2022-06-21 22:23:51.617671
# Unit test for function tree
def test_tree():
    """
    >>> from pprint import pprint
    >>> test_tree = tree()
    >>> test_tree['Foo']['Bar'] = 'Baz'
    >>> pprint(test_tree)
    defaultdict(<function tree at 0x7f25d4c34320>,
                {'Foo': defaultdict(<function tree at 0x7f25d4c34320>, {'Bar': 'Baz'})})
    >>> test_tree['Foo:Bar'] = 'Bazzzz'
    >>> pprint(test_tree)
    defaultdict(<function tree at 0x7f25d4c34320>,
                {'Foo': defaultdict(<function tree at 0x7f25d4c34320>, {'Bar': 'Bazzzz'})})
    """



# Generated at 2022-06-21 22:24:33.739879
# Unit test for function tree
def test_tree():
    tree = tree()
    tree['a']['b']['c'] = 'd'
    assert tree['a:b:c'] == 'd'
    set_tree_node(tree, 'a:b:c', 'e')
    assert tree['a:b:c'] == 'e'
    assert get_tree_node(tree, 'a:b')['c'] == 'e'



# Generated at 2022-06-21 22:24:45.056903
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test case
    test_map = {}
    test_map['one'] = {}
    test_map['one']['two'] = {}
    test_map['one']['three'] = {}
    test_map['one']['two']['four'] = 'four'

    # Test get_tree_node function
    assert get_tree_node(test_map, 'one:two:four') == 'four'
    assert get_tree_node(test_map, 'one:two:four:none') is _sentinel
    assert get_tree_node(test_map, 'one:two:four:none', []) == []
    assert get_tree_node(test_map, 'one:two:four', []) == 'four'

    # Test get_tree_node function with parent
    assert get_tree

# Generated at 2022-06-21 22:24:48.468128
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['apple:banana'] = 'pear'
    assert t['apple:banana'] == 'pear'



# Generated at 2022-06-21 22:24:53.218737
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 'A'
    assert tree['a'] == 'A'
    tree['a']['b'] = 'B'
    assert tree['a']['b'] == 'B'
    tree['a']['b']['c'] = 'C'
    assert tree['a']['b']['c'] == 'C'

    tree = Tree()
    tree['a']['b']['c'] = 'C'
    assert tree['a']['b']['c'] == 'C'

# Generated at 2022-06-21 22:25:05.172233
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from nose.tools import istest, eq_

    @istest
    def construction():
        """RegistryTree may be constructed in multiple ways."""
        # The name of this unit test is the class it covers.
        # The name of the class appears in the docstring of this unit test.
        # The name of the function is the method being tested.
        # The name of the argument to the function being tested appears in the docstring of this unit test.
        # Arguments to the function being tested are named as if they are being written as a function header, or in the line
        # that called them.

        # The default constructor implicitly constructs an instance of the class.
        eq_(RegistryTree, type(RegistryTree()))

        # The constructor can take an initial mapping.
        import collections

        initial = {}

# Generated at 2022-06-21 22:25:10.495838
# Unit test for function set_tree_node
def test_set_tree_node():
    test = {}
    set_tree_node(test, 'demo', 'demo_value')
    assert test['demo'] == 'demo_value'

    set_tree_node(test, 'demo:another', 'another_value')
    assert test['demo']['another'] == 'another_value'

    set_tree_node(test, 'demo:another:more', 'more_value')
    assert test['demo']['another']['more'] == 'more_value'

# Generated at 2022-06-21 22:25:19.424244
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    rt = RegistryTree(initial={
        'a': {'b': {'c': {'d': 'e'}}},
        'f': {'g': {'h': 'i'}},
    })

    assert rt.get('f:g:h') == 'i'
    assert rt.get('f:g:z') == _sentinel
    assert rt.get('f:g:z', default='default') == 'default'
    assert rt.get('f') == {'h': 'i'}
    assert rt.get('f', parent=True) == rt
    assert rt.get('ff', parent=True) == _sentinel
    assert rt.get('ff', parent=True, default=rt) == rt



# Generated at 2022-06-21 22:25:25.957843
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, 'b:c:d', 'test')
    assert a['b']['c']['d'] == 'test'
    assert set_tree_node(a, 'b:c:d', 'bazinga') == a['b']['c']
    assert a['b']['c']['d'] == 'bazinga'



# Generated at 2022-06-21 22:25:28.249098
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tr = Tree()
    tr['key'] = 'value'
    assert tr['key'] == 'value'



# Generated at 2022-06-21 22:25:39.697643
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'foo': 'bar'
                    }
                }
            }
        }
    }
    # Standard traversal
    assert get_tree_node(mapping, 'a:b:c:d:foo') == 'bar'
    # Traverse parent node
    assert get_tree_node(mapping, 'a:b:c:d:foo', parent=True) == {'foo': 'bar'}
    # Traverse to level
    assert get_tree_node(mapping, 'a:b:c:d') == {'foo': 'bar'}
    # Traverse to level and stop

# Generated at 2022-06-21 22:27:17.521541
# Unit test for function tree
def test_tree():
    test_tree = tree()
    test_tree['foo']['bar']['baz'] = 'test'
    test_tree['foo']['lol'] = 'test2'
    test_tree['foo']['bar']['baz'] = 'test3'
    test_tree['foo']['bar']['baz']['test'] = 'test4'



# Generated at 2022-06-21 22:27:23.880173
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import unittest

    class Tree___setitem___Test(unittest.TestCase):
        def test_Tree___setitem___Test(self):
            obj = RegistryTree()
            # Test if there is no impact on existing values.
            obj.register(key='B', value=2)
            obj.register(key='A', value=1)
            # Test invalid values for parameter key.
            with self.assertRaises(TypeError):
                obj.register(key=(), value=2)
            with self.assertRaises(TypeError):
                obj.register(key=self, value=2)
            with self.assertRaises(TypeError):
                obj.register(key=[], value=2)
            with self.assertRaises(TypeError):
                obj.register(key=[1], value=2)

# Generated at 2022-06-21 22:27:27.789394
# Unit test for constructor of class Tree
def test_Tree():
    x = Tree(initial=dict(Olympus=dict(Zeus='Father of Gods')))
    assert x['Olympus:Zeus'] == 'Father of Gods'



# Generated at 2022-06-21 22:27:33.639143
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree(initial_is_ref=True)
    registry['name'] = 'Vu Khoi Nguyen'
    registry['contact']['phone'] = '01234567890'
    assert registry == {
        'name': 'Vu Khoi Nguyen',
        'contact': {'phone': '01234567890'}
    }
    assert registry['contact']['phone'] == '01234567890'
    assert registry['name'] == 'Vu Khoi Nguyen'
    return True

# Generated at 2022-06-21 22:27:38.896283
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    foo = Tree()
    foo['baz:bar'] = 'ok'
    assert foo['baz:bar'] == 'ok'
    assert foo['baz']['bar'] == 'ok'
    assert foo['baz']['bar']['blah'] == {}



# Generated at 2022-06-21 22:27:41.659497
# Unit test for function tree
def test_tree():
    t = tree()
    t['who']['where']['when'] = 'why'
    assert t['who']['where']['when'] == 'why'



# Generated at 2022-06-21 22:27:45.181553
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()

    with pytest.raises(KeyError):
        assert tree['foo']['bar']['baz'] == []

    tree['foo'] = {'bar': {'baz': []}}
    assert tree['foo']['bar']['baz'] == []



# Generated at 2022-06-21 22:27:57.024781
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    assert (
        Tree({'foo': {'bar': 'baz'}}, initial_is_ref=True) ==
        Tree({'foo': {'bar': 'baz'}}, initial_is_ref=True)
    )

    # Test assignment
    t = Tree()
    t['foo'] = {'bar': 'baz'}
    assert t == {'foo': {'bar': 'baz'}}
    t['foo:bar:baz'] = 'blah'
    assert t == {'foo': {'bar': {'baz': 'blah'}}}
    t['foo:bar:baz2'] = 'blah2'
    assert t == {'foo': {'bar': {'baz': 'blah', 'baz2': 'blah2'}}}

    # Test reference assignment
