

# Generated at 2022-06-21 22:18:10.476265
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['aaa:bbb:ccc'] = 'foo'
    try:
        t['aaa:bbb:fff']
    except KeyError:
        pass
    else:
        raise AssertionError("expected KeyError")
    if t['aaa:bbb:ccc'] != 'foo':
        raise AssertionError("expected: %s, got %s" % ('foo', t['aaa:bbb:ccc']))

# Generated at 2022-06-21 22:18:17.517911
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node()"""
    tree_1 = {
        'a': 'avalue',
        'b': {
            'ba': 'baavalue',
            'bb': {
                'bba': 'bbaavalue',
                'bbb': 'bbbvalue',
            }
        },
    }

    assert get_tree_node(tree_1, 'a') == 'avalue'
    assert get_tree_node(tree_1, 'b:bb:bbb') == 'bbbvalue'
    assert get_tree_node(tree_1, 'b:bb:bbbbb', default=True) == True



# Generated at 2022-06-21 22:18:28.882973
# Unit test for function tree

# Generated at 2022-06-21 22:18:31.399115
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['abc'] = 'def'
    assert t.get('abc') == 'def'
    assert t['abc'] == 'def'



# Generated at 2022-06-21 22:18:34.542309
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree()
    a['d']['f'] = 'g'
    a['d']['f'] = 'h'
    print(a)



# Generated at 2022-06-21 22:18:38.647966
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    def _test_Tree___setitem___1():
        tree = Tree()
        tree['foo'] = 'bar'
        assert tree['foo'] == 'bar'

    _test_Tree___setitem___1()



# Generated at 2022-06-21 22:18:47.521289
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test data
    test_mapping = {'a': 10, 'b': {'c': 20}, 'c': {'d': {'e': 30}, 'f': {'g': 40}}}

    # Test Cases
    # Format 'expected_value' : ['key', default_value]

# Generated at 2022-06-21 22:18:50.491930
# Unit test for function set_tree_node
def test_set_tree_node():
    foo = tree()
    set_tree_node(foo, 'foo:bar:baz', '42')
    assert foo['foo']['bar']['baz'] == '42'



# Generated at 2022-06-21 22:18:53.947933
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 1
    assert t['a']['b']['c'] == 1



# Generated at 2022-06-21 22:19:04.780896
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'a': {'b': {'c': 123, 'd': 456}}, 'e': [1, 2, 3], 'g': b'0xcafe', 'h': u'unicode'})

    assert tree['a:b:c'] == 123
    assert tree['a:b:d'] == 456
    assert tree['e'] == [1, 2, 3]
    assert tree['h'] == u'unicode'

    with pytest.raises(KeyError):
        tree['g:c']

    with pytest.raises(KeyError):
        tree['a:b:f']

    assert tree['h', 'default'] == u'unicode'
    assert tree['g:c', 'default'] == 'default'

# Generated at 2022-06-21 22:19:20.659154
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'hello world'
            }
        }
    }

    assert get_tree_node(tree, 'a:b:c') == 'hello world'
    assert get_tree_node(tree, 'a:b:c:d') is _sentinel
    assert get_tree_node(tree, 'd') is _sentinel
    assert get_tree_node(tree, 'a:c') is _sentinel
    assert get_tree_node(tree, 'a:c', default='hello world') == 'hello world'

    # Test the parent switch
    assert get_tree_node(tree, 'a:b:c:d', default={}, parent=True) == {}

# Generated at 2022-06-21 22:19:27.571599
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(namespace='test')
    assert tree.namespace == 'test'

    # Ensure data is assigned to tree.data
    assert tree.data == tree

    # Ensure there's no leakage between namespaces
    tree['one'] = 2
    assert tree['one'] == 2
    assert tree.get('one') == 2
    tree2 = Tree(namespace='two')
    assert tree2.get('one') is None



# Generated at 2022-06-21 22:19:34.727021
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Test when key is not a string
    with pytest.raises(TypeError):
        tree_inst = Tree()
        tree_inst[None] = 'value'

    # Test when value is not a string
    with pytest.raises(TypeError):
        tree_inst = Tree()
        tree_inst['key'] = None

    # Test when key is a string and value is a string
    expected = 'value'
    tree_inst = Tree()
    tree_inst['key'] = 'value'
    actual = tree_inst['key']
    assert actual == expected

    # Test when key is a string with two dimensions and value is a string
    expected = 'value'
    tree_inst = Tree()
    tree_inst['key:subkey'] = 'value'

# Generated at 2022-06-21 22:19:42.248945
# Unit test for function tree
def test_tree():
    tr = tree()
    tr['one']['two'] = 1
    assert tr['one']['two'] == 1
    tr['one']['two:three'] = 2
    assert tr['one']['two']['three'] == 2
    tr['one:two:three:four:five'] = 5
    assert tr['one']['two']['three']['four']['five'] == 5
    tr['one:two:three:four:five']['six'] = 6
    assert tr['one']['two']['three']['four']['five']['six'] == 6
    assert tr['one:two:three:four:five:six'] == 6
    assert tr['foo']['bar']['baz'] == tr['foo:bar:baz']

# Generated at 2022-06-21 22:19:50.267721
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function `:module:~set_tree_node`."""
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'foobar')
    assert mapping == { 'a': { 'b': {'c': 'foobar'}}}
    mapping = {}
    set_tree_node(mapping, 'a:b', 'foobar')
    assert mapping == {'a': {'b': 'foobar'}}
    mapping = {}
    set_tree_node(mapping, 'a', 'foobar')
    assert mapping == {'a': 'foobar'}

    # Test with a list
    mapping = []
    with pytest.raises(AttributeError):
        set_tree_node(mapping, 'a', 'foobar')

# Generated at 2022-06-21 22:19:51.935031
# Unit test for constructor of class Tree
def test_Tree():
    test = Tree()



# Generated at 2022-06-21 22:19:57.003141
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.register('foo', 'bar')
    assert t['foo'] == 'bar'
    t.register('foo:boo', 'moo')
    assert 'moo' == t['foo:boo']
    assert 'moo' == t.get('foo:boo')

# Generated at 2022-06-21 22:20:07.527640
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    d = Tree()
    d['a', 'b', 'c'] = 1
    d['a', 'b', 'd'] = 2
    d['a', 'b', 'e'] = {'f': 2}
    assert d['a', 'b', 'c'] == 1
    assert d['a', 'b', 'd'] == 2
    assert d['a', 'b', 'e'] == {'f': 2}
    assert d['a', 'b'] == {'c': 1, 'd': 2, 'e': {'f': 2}}
    assert d['a'] == {'b': {'c': 1, 'd': 2, 'e': {'f': 2}}}



# Generated at 2022-06-21 22:20:13.579170
# Unit test for function set_tree_node
def test_set_tree_node():
    dict_outp = {
        "key": {
            "key": {
                "key_outp": "value"
            }
        }
    }
    dict_inp = {"key": {"key": {"key_inp": "value"}}}
    dict_outp = set_tree_node(dict_inp, "key:key:key_outp", "value")
    assert dict_inp == dict_outp



# Generated at 2022-06-21 22:20:21.725677
# Unit test for function get_tree_node
def test_get_tree_node():
    import pytest
    data = {'a': {'b': {'c': 0}}, 'd': {'e': {'f': 1}}}

    value = get_tree_node(data, 'a:b:c')
    assert value == data['a']['b']['c']

    value = get_tree_node(data, 'a:b:c:d')
    assert value == 0

    with pytest.raises(KeyError):
        get_tree_node(data, 'a:b:c:d', default=_sentinel)



# Generated at 2022-06-21 22:20:41.842864
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': {
            'bar': 'baz',
            'qux': 1337,
        },
        'quux': {
            'quuz': 'corge'
        }
    }
    tree = get_tree_node(data, 'foo:bar')
    assert tree == 'baz'
    tree = get_tree_node(data, 'foo:qux')
    assert tree == 1337
    tree = get_tree_node(data, 'foo:bar', 1337)
    assert tree == 'baz'
    tree = get_tree_node(data, 'foo:quux', 1337)
    assert tree == 1337

# Generated at 2022-06-21 22:20:46.361008
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree.update({
        'a': {
            '1': {
                'c': 42
            },
            '2': {
                'd': 'Hello World'
            }
        },
        'b': {
            '1': 1,
            '2': 2,
            '3': 3,
            '4': {
                'e': 'Something'
            }
        }
    })
    key = 'b:4:e'
    print(tree[key])
    tree[key] = 'Amended text'
    print(tree[key])
    tree.update({
        'b:4:f': 'Amended text 2'
    })
    print(tree['b:4:f'])
    print(tree.get('b:4:f'))


# Unit test

# Generated at 2022-06-21 22:20:53.526463
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree()
    set_tree_node(tree, 'a.b', True)
    assert tree['a']['b'] is True
    set_tree_node(tree, 'c:d', False)
    assert tree['c']['d'] is False

    # Overwrite
    set_tree_node(tree, 'c:d', True)
    set_tree_node(tree, 'a.b', False)
    assert tree['a']['b'] is False
    assert tree['c']['d'] is True



# Generated at 2022-06-21 22:21:02.345096
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {
        1: {
            'a': 'foo',
            'b': ['bar', 1, {'x': 'y'}]
        },
        2: 'baz'
    }

    assert get_tree_node(m, '1:a') == 'foo'
    assert get_tree_node(m, '2') == 'baz'
    assert get_tree_node(m, '1:b:2:x') == 'y'

    try:
        get_tree_node(m, '1:x')
        assert False, "Should have raised KeyError."
    except KeyError:
        pass

    assert get_tree_node(m, '1:x', default='default') == 'default'



# Generated at 2022-06-21 22:21:09.497473
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo'] = {'bar': {'hoi': 'ndm'}}
    assert t['foo:bar:hoi'] == 'ndm'
    assert t['foo:bar:hoi2'] is KeyError
    assert t['foo:ping:pong'] is KeyError
    assert t['foo:bar:hoi2', 'ndm2'] == 'ndm2'



# Generated at 2022-06-21 22:21:13.050963
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': 1})
    assert t.get('a') == 1

# Unit test to check registry functionality

# Generated at 2022-06-21 22:21:19.818024
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    d = Tree({'a':1, 'b':2, 'c':3})
    assert d['a'] == 1
    assert d['b'] == 2
    assert d['c'] == 3
    d = Tree()
    d['a'] = 1
    assert d['a'] == 1



# Generated at 2022-06-21 22:21:23.541113
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert rt.get('a:b:c:d') is None

    rt.set('a', 'x')
    assert rt.get('a') == 'x'


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-21 22:21:35.214279
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    mapping = Tree()
    mapping['a:b:c'] = 'foo'
    assert mapping['a:b:c'] == 'foo'


if __name__ == '__main__':

    # Unit test for function get_tree_node
    def test_get_tree_node():
        mapping = {
            'a': {
                'b': {
                    'c': 'foo',
                },
                'd': 'bar',
            },
            'e': {'f': 'foobar'},
        }
        # TODO Make these tests follow paths, like we do in the code?
        assert get_tree_node(mapping, 'a:b:c') == 'foo'
        assert get_tree_node(mapping, 'a:b:c:d') == None

# Generated at 2022-06-21 22:21:43.995906
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Test that __setitem__ of class Tree works properly
    """
    import itertools

    t = Tree()
    # Test failure cases
    for key, value in itertools.chain(
            (('', 'value1'), (':foo', 'value2')),
            (['path' + str(i) for i in range(1, 8)], 'value3')
        ):
        t.__setitem__(key, value)
        t.__setitem__(key, value, namespace='foo')
        t.__setitem__(key, value, namespace='')


if __name__ == '__main__':
    test_Tree___setitem__()

# Generated at 2022-06-21 22:21:59.414808
# Unit test for constructor of class Tree
def test_Tree():
    # Instantiation with namespace
    namespace = 'foo'
    instance = Tree(namespace=namespace)
    assert instance.namespace == namespace

    # Instantiation with namespace and data
    data = {'bar': 'baz'}
    instance = Tree(data, namespace=namespace)
    assert instance['foo:bar'] == 'baz'

    # Instantiation with data as reference
    data = {'bar': 'baz'}
    instance = Tree(data, initial_is_ref=True)
    assert instance['bar'] == 'baz'
    data['bar'] = 'qux'
    assert instance['bar'] == 'qux'



# Generated at 2022-06-21 22:22:10.470734
# Unit test for function get_tree_node
def test_get_tree_node():
    toy_tree = {'a': {'b': {'c': {'d': 'e'}, 'f': 'g'}, 'h': 'i'}}

    assert get_tree_node(toy_tree, 'a') == {'b': {'c': {'d': 'e'}, 'f': 'g'}, 'h': 'i'}
    assert get_tree_node(toy_tree, 'a:b') == {'c': {'d': 'e'}, 'f': 'g'}
    assert get_tree_node(toy_tree, 'a:b:c') == {'d': 'e'}
    assert get_tree_node(toy_tree, 'a:b:c:d') == 'e'

# Generated at 2022-06-21 22:22:14.654837
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['simple'] = 'simple'
    assert tree['simple'] == 'simple'
    tree['with:many:dimention'] = 'also simple'
    assert tree['with:many:dimention'] == 'also simple'



# Generated at 2022-06-21 22:22:25.414064
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO Prettier unit tests. No time.
    tree_node = {
        'str': 'str',
        'dict': {
            'str': 'str',
            'dict': {
                'str': 'str',
                'dict': {'str': 'str'}
            }
        }
    }
    assert get_tree_node(tree_node, 'dict:dict:dict:str') == 'str'
    assert get_tree_node(tree_node, 'dict:dict:dict:str:str', default='str') == 'str'
    assert get_tree_node(tree_node, 'dict:dict:str') == 'str'
    assert get_tree_node(tree_node, 'str') == 'str'
    with pytest.raises(KeyError) as excinfo:
        get

# Generated at 2022-06-21 22:22:29.856416
# Unit test for function tree
def test_tree():
    import pytest
    t = tree()
    t['a']['b']['c'] = 'd'
    assert t['a']['b']['c'] == 'd'
    t['a']['b']['c'] = 'e'
    assert t['a']['b']['c'] == 'e'



# Generated at 2022-06-21 22:22:32.326322
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(namespace='test')
    rt['cow'] = 'cow'
    assert rt.get('cow') == rt.get('test:cow') == 'cow'



# Generated at 2022-06-21 22:22:36.047984
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            }
        },
        'x': {
            'y': {
                'z': 'k',
            }
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'x:y:z') == 'k'



# Generated at 2022-06-21 22:22:41.821720
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': {'b': {'c': 'hello'}}})
    # Assert that hello is accessible via __getitem__, either directly or via get()
    assert t['a:b:c'] == t.get('a:b:c') == 'hello'

    # Assert that tree() is the same as the Tree constructor
    assert t == tree({'a': {'b': {'c': 'hello'}}})

    # Assert that we can access a parent node
    assert t.get('a:b', parent=True) == {'c': 'hello'}

    # Assert that we can specify a namespace on instantiation
    t = Tree({'a': {'b': {'c': 'hello'}}}, namespace='foo')
    assert t['foo:a:b:c'] == t.get

# Generated at 2022-06-21 22:22:44.781770
# Unit test for function tree
def test_tree():
    """Test tree()"""
    t = tree()
    t['child']['grandchild'] = 'blah blah blah blah blah blah blah blah blah blah'
    assert t['child']['grandchild'] == 'blah blah blah blah blah blah blah blah blah blah'



# Generated at 2022-06-21 22:22:48.117706
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'foo': 1, 'bar:baz': 5})
    assert tree['foo'] == 1
    assert tree['bar:baz'] == 5

# Generated at 2022-06-21 22:23:07.762249
# Unit test for constructor of class Tree
def test_Tree():
    """Test data structure that allows for : notation to delve down into dimensions."""
    t = Tree()

    # Set a basic key and value
    t['foo'] = 'bar'

    # Fetch the value by key and namespace
    assert t['foo'] == 'bar'
    assert t.get('foo') == 'bar'

    # Tuple should be treated as key, not namespace
    t[('foo', 'bar')] = 'baz'
    assert t['foo:bar'] == 'baz'

    # Set a key in a namespace and fetch it by :
    t['foo', 'bar'] = 'baz'
    assert t['foo:bar'] == 'baz'
    assert t['foo', 'bar'] == 'baz'

    # Update with a dict

# Generated at 2022-06-21 22:23:15.725918
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    foo = RegistryTree(initial={
        'plugins': {
            'active': ['A', 'B'],
            'installed': ['A', 'B', 'C', 'D'],
            'available': ['A', 'B', 'C', 'D', 'E', 'F', 'G'],
        }
    })

    assert foo['plugins:installed'] == ['A', 'B', 'C', 'D']
    assert foo['plugins:available'] == ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    assert foo['plugins:active'] == ['A', 'B']


# Unit tests for RegistryTree

# Generated at 2022-06-21 22:23:24.004412
# Unit test for function set_tree_node
def test_set_tree_node():
    my_dict = {}
    set_tree_node(my_dict, 'key:yee', 'yeehaw')
    assert my_dict['key']['yee'] == 'yeehaw'

    my_dict = tree()
    my_dict['key']['yee'] = 'foo'
    set_tree_node(my_dict, 'key:yee', 'yeehaw')
    assert my_dict['key']['yee'] == 'yeehaw'



# Generated at 2022-06-21 22:23:28.501956
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register('foo', 'bar')
    assert r.foo == 'bar'
    assert r['foo'] == 'bar'
    assert r.get('foo') == 'bar'
    r.register('fancy:pants', 'swag')
    assert r['fancy:pants'] == 'swag'
    assert r.fancy.pants == 'swag'

# Generated at 2022-06-21 22:23:38.517464
# Unit test for function get_tree_node
def test_get_tree_node():
    result = get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar')
    assert result == 'baz'

    result = get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', default='wibble')
    assert result == 'baz'

    result = get_tree_node({'foo': {'bar': 'baz'}}, 'foo:baz', default='wibble')
    assert result == 'wibble'

    result = get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', parent=True)
    assert result == {'bar': 'baz'}



# Generated at 2022-06-21 22:23:49.029797
# Unit test for function tree

# Generated at 2022-06-21 22:23:53.068012
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from pprint import pprint
    r = RegistryTree(namespace='a')
    r.register('a', 'apple')
    r.register('b', 'ball')
    r.register('c', 'cat')
    r['d'] = 'dog'

# Generated at 2022-06-21 22:24:00.685523
# Unit test for function tree
def test_tree():
    with pytest.raises(KeyError):
        assert get_tree_node(tree(), 'a:b')

    d = tree()
    d['a']['b'] = 'd'
    assert get_tree_node(d, 'a:b') == 'd'

    d['a']['b'] = tree()
    assert get_tree_node(d, 'a:b') == tree()

    d['a']['b']['c'] = tree()
    assert get_tree_node(d, 'a:b:c') == tree()

    # Test setting a node on a tree
    assert set_tree_node(d, 'a:b:c', 42) == 42
    assert get_tree_node(d, 'a:b:c') == 42



# Generated at 2022-06-21 22:24:06.719189
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd',
            }
        }
    }
    assert get_tree_node(mapping, 'a:b') == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c') == 'd'



# Generated at 2022-06-21 22:24:13.261013
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'this':
            {
                'is':
                    {
                        'a':
                            {
                                'test':
                                    'yup'
                            }
                    }
            }
    }
    assert get_tree_node(mapping, 'this:is:a:test') == 'yup'
    assert get_tree_node(mapping, 'this:is', default='nothing') == 'nothing'

    mapping = tree()
    mapping['this']['is']['deeply']['nested'] = 'yup'
    assert get_tree_node(mapping, 'this:is:deeply:nested') == 'yup'

# Generated at 2022-06-21 22:24:43.577549
# Unit test for function tree
def test_tree():
    assert get_tree_node(tree(), 'test', default='Default Value') == 'Default Value'
    assert get_tree_node(tree(foo=tree(bar=tree(baz='blah'))), 'foo:bar:baz') == 'blah'
    assert get_tree_node(tree(foo=tree(bar=tree(baz='blah'))), 'foo:bar:baz:quux', default=42) == 42

    root = tree()
    set_tree_node(root, 'foo:bar:baz:quux', 42)
    assert get_tree_node(root, 'foo:bar:baz:quux') == 42

    assert set_tree_node(root, 'foo:bar:baz:quux', 42) == {'baz': {'quux': 42}}




# Generated at 2022-06-21 22:24:48.823373
# Unit test for function tree
def test_tree():
    """Test that tree returns a nested defaultdict"""
    t = tree()
    assert isinstance(t, collections.defaultdict), "'tree' should return a defaultdict"
    assert isinstance(t[1], collections.defaultdict), "'tree' should return a nested defaultdict"



# Generated at 2022-06-21 22:24:51.808986
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for constructor of class RegistryTree"""
    assert RegistryTree()



# Generated at 2022-06-21 22:24:53.898062
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 1
    assert tree['a'] == 1



# Generated at 2022-06-21 22:24:57.388716
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Initialization
    node = Tree()
    node['foo:bar:baz'] = 'bat'
    # Test
    assert node['foo:bar:baz'] == 'bat'



# Generated at 2022-06-21 22:24:59.748997
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Unit test for method :func:`__getitem__` of class Tree
    """
    # TODO Write unit tests
    raise NotImplementedError()

# Generated at 2022-06-21 22:25:06.349713
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'foo', 'bar')
    assert t['foo'] == 'bar'
    set_tree_node(t, 'bar:foo', 'bar')
    assert t['bar']['foo'] == 'bar'
    set_tree_node(t, 'bar:foo:foo', 'bar')
    assert t['bar']['foo']['foo'] == 'bar'

# Generated at 2022-06-21 22:25:09.248046
# Unit test for function tree
def test_tree():
    import json
    test_tree = tree()
    test_tree['a']['b']['c']['d']['e'] = 'f'
    print(json.dumps(test_tree))



# Generated at 2022-06-21 22:25:18.920019
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    foo_class_list = []
    # Define a class to register
    class Foo():
        pass
    # Instantiate a RegistryTree class
    registry = RegistryTree()
    # Register 4 Foo objects
    for i in range(4):
        foo_obj = Foo()
        foo_class_list.append(foo_obj)
        # Register a member of a class
        registry.register(['foo', 'Foo', str(i)], foo_obj)
    # Iterate over registered Foo objects
    for i, value in enumerate(registry['foo']['Foo']):
        # Assert that the value of the class member is the same as the one registered
        assert value == foo_class_list[i]

# Generated at 2022-06-21 22:25:26.727805
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Unit test for method __setitem__ of class Tree"""

    tree = Tree()
    tree['red'] = 'blue'
    assert tree['red'] == 'blue'

    tree['a:b'] = 'c'
    assert tree['a:b'] == 'c'

    from collections import defaultdict
    tree = defaultdict(Tree)
    tree['red'] = 'blue'
    assert tree['red'] == 'blue'

    tree['a:b'] = 'c'
    assert tree['a:b'] == 'c'



# Generated at 2022-06-21 22:25:54.057012
# Unit test for constructor of class Tree
def test_Tree():

    # Instantiate
    tree = Tree()

    # Set item and get item
    tree['a'] = 1
    assert tree['a'] == 1

    # Test namespace
    tree.namespace = 'ns'
    tree.update([
        ('b', 20),
        ('c:0', 30),
        ('d:z', 40)
    ])

    assert tree['ns:b'] == 20
    assert tree['ns:c:0'] == 30
    assert tree['ns:d:z'] == 40


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-21 22:25:58.469599
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'

    t['foo:bar'] = 'baz:quux'
    assert t['foo:bar'] == 'baz:quux'

    t['foo:bar:baz'] = 'quux'
    assert t['foo:bar:baz'] == 'quux'



# Generated at 2022-06-21 22:26:06.346801
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(collections.defaultdict)
    set_tree_node(tree, 'foo:bar', 'baz')
    assert tree['foo']['bar'] == 'baz'

    set_tree_node(tree, 'foo:bar:tst:ud:dk:multidim', 'fun')
    assert tree['foo']['bar']['tst']['ud']['dk']['multidim'] == 'fun'



# Generated at 2022-06-21 22:26:14.601408
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    assert set_tree_node(d, 'a', 1) == {'a': 1}
    assert d == {'a': 1}

    d = {'a': {'b': {}}}
    assert set_tree_node(d, 'a:b:c', 1) == {'a': {'b': {'c': 1}}}
    assert d == {'a': {'b': {'c': 1}}}

    d = {'a': {'b': {}}}
    assert set_tree_node(d, 'a:b:c:d', 1) == {'a': {'b': {'c': {'d': 1}}}}
    assert d == {'a': {'b': {'c': {'d': 1}}}}



# Generated at 2022-06-21 22:26:23.846244
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Test various ways of setting a value on a tree.
    t = Tree()
    t['a'] = 1
    t['a:b'] = 2
    t['a:b:c'] = 3
    t['a:b:c:d'] = 5
    assert t['a'] == 1
    assert t['a:b'] == 2
    assert t['a:b:c'] == 3
    assert t['a:b:c:d'] == 5

    # Test setting a value to a namespace
    t = Tree(namespace='ns')
    t['a'] = 1
    assert t['a'] == 1
    assert t['ns:a'] == 1



# Generated at 2022-06-21 22:26:30.842220
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pprint

    ctf = Tree()
    ctf['foo']['bar']['baz'] = 'value'
    ctf['foo']['baz']['bar'] = 'value2'
    ctf['foo']['baz']['bar:baz'] = 'value3'

    pprint(ctf.data)
    assert ctf.data == {'foo': {'bar': {'baz': 'value'},
                                'baz': {'bar': 'value2',
                                        'bar:baz': 'value3'}}}

    assert ctf['foo:baz:bar'] == 'value2'
    assert ctf['foo:bar:baz'] == 'value'
    assert ctf['foo:baz:bar:baz'] == None


#

# Generated at 2022-06-21 22:26:32.934019
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('eh:oh:eh', 'meh')
    assert registry.get('eh:oh:eh') == 'meh'

# Generated at 2022-06-21 22:26:35.430815
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b'] = 3
    assert t['a']['b'] == 3



# Generated at 2022-06-21 22:26:39.865677
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    test_tree = RegistryTree()
    assert test_tree['foo:bar'] == test_tree.get('foo:bar')


test_tree = RegistryTree()
test_tree['test'] = 'val'
assert test_tree['test'] == 'val'

# Generated at 2022-06-21 22:26:42.020853
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a:b:c', 'foo') == {'a': {'b': {'c': 'foo'}}}



# Generated at 2022-06-21 22:27:14.846190
# Unit test for constructor of class Tree
def test_Tree():
    d = Tree()
    assert d['aaa'] == {}
    assert d['aaa']['bbb'] == {}

    d = Tree({'a': 'a'})
    assert d['a'] == 'a'

    d = Tree(initial_is_ref=True)
    assert d.data == {}



# Generated at 2022-06-21 22:27:22.255145
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    map_ = [
        ('a', 1), ('a:b:c', 2), ('b:c:d', 3), ('b:c', 4), ('a:b:d:e:f:g', 5),
        ('a:c:d:e:f:g', 6), ('b:c:d:e:f:g', 7), ('a:b:d:e:f:g:h', 8),
    ]
    tree_ = Tree(initial=map_)

# Generated at 2022-06-21 22:27:30.519252
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('.::foo::bar')

    assert registry.data == {'::foo::bar': {}}
    assert registry.data == registry['.::foo::bar']

    registry.register(':baz', namespace='.::foo')
    assert registry.data == {'::foo::bar': {}, '::foo:baz': {}}


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-21 22:27:31.999510
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a:b:c'] = 'c'
    assert t['a:b:c'] == 'c'



# Generated at 2022-06-21 22:27:43.314514
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Setup
    tree = Tree()

    # Exercise 1
    tree['one'] = 1
    # Verify outcome 1
    assert tree.get('one') == 1

    # Exercise 2
    tree['two:uno'] = 1
    # Verify outcome 2
    assert tree.get('two:uno') == 1
    assert tree.get('two') == Default(Tree)

    # Exercise 3
    tree['three:uno:dos'] = 1
    # Verify outcome 3
    assert tree.get('three', default=None) is not None
    assert tree.get('three:uno') is not None
    assert tree.get('three:uno:dos') == 1

    # Exercise 4
    # Verify outcome 4
    assert tree.get('three:uno:dos:nada', default=None) is None

# Generated at 2022-06-21 22:27:54.089151
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for `set_tree_node`."""
    t = tree()
    # Set a single node
    assert set_tree_node(t, 'path:to:leaf', 'data')
    assert t['path']['to']['leaf'] == 'data'

    # Set an array node
    assert set_tree_node(t, 'path:to:leafs', ['data', 'data2'])
    assert t['path']['to']['leafs'][0] == 'data'
    assert t['path']['to']['leafs'][1] == 'data2'

    # Set another single node, by overwriting the old array
    assert set_tree_node(t, 'path:to:leafs', 'data3')

# Generated at 2022-06-21 22:27:58.851576
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo:bar:baz'] = 'yay'
    assert t['foo:bar:baz'] == 'yay'
    # Test on pre-existing namespace
    t['fizz'] = 'buzz'
    assert t['fizz'] == 'buzz'

