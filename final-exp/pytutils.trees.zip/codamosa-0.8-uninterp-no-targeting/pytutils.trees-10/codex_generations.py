

# Generated at 2022-06-21 22:18:10.440871
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['x:y:z'] = 'value'
    outcome = 'value'
    expected = 'value'
    assert outcome == expected

    tree = Tree()
    tree[':x:y:z'] = 'value'
    outcome = 'value'
    expected = 'value'
    assert outcome == expected

    tree = Tree()
    tree['x::y:z'] = 'value'
    outcome = 'value'
    expected = 'value'
    assert outcome == expected

    tree = Tree()
    tree['x:y::z'] = 'value'
    outcome = 'value'
    expected = 'value'
    assert outcome == expected

    tree = Tree()
    tree['x::y::z'] = 'value'
    outcome = 'value'
    expected = 'value'

# Generated at 2022-06-21 22:18:11.297704
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass # TODO



# Generated at 2022-06-21 22:18:14.003433
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree({'a': {'b': 1}, 'c': 2})
    assert a.get('a:b') == 1
    assert a.get('c') == 2



# Generated at 2022-06-21 22:18:20.759234
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Test function Tree structures."""

    t = Tree()
    t['a'] = '1'
    t['b'] = '2'
    t['c'] = '3'
    t['d'] = '4'

    assert t['b'] == '2'
    assert t['c'] == '3'

    t['x:y'] = '5'
    t['x:z'] = '6'
    t['y:a'] = '7'
    t['y:b'] = '8'

    assert t['x:y'] == '5'
    assert t['x:z'] == '6'
    assert t['y:a'] == '7'
    assert t['y:b'] == '8'

    t['a'] = '9'
    t['b'] = '0'


# Generated at 2022-06-21 22:18:24.573203
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='foo')
    assert t.namespace is not None
    t['foo'] = 1
    assert t['foo'] == 1
    assert t.namespace == 'foo'

# Generated at 2022-06-21 22:18:35.262335
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Test with no default
    t = Tree()
    t['a'] = 0
    t['a:b'] = 1
    t['a:c'] = 2
    t['a:c:d'] = 3
    t['a:c:e'] = 4
    t['a:c:e:f'] = 5
    t['a:c:e:f:g'] = 6
    t['a:c:e:f:h'] = 7
    assert t['a'] == 0
    assert t['a:b'] == 1
    assert t['a:c'] == 2
    assert t['a:c:d'] == 3
    assert t['a:c:e'] == 4
    assert t['a:c:e:f'] == 5
    assert t['a:c:e:f:g'] == 6

# Generated at 2022-06-21 22:18:45.587296
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from pprint import pprint

    # Instantiate class with argument
    x = Tree(initial={'foo': 'bar'})

    # Call method with argument
    x['foo'] = 'baz'
    x['bar'] = 'foo'

    # Assert type is as expected
    assert isinstance(x, Tree)

    # Assert value is as expected
    assert x == {'bar': 'foo', 'foo': 'baz'}
    pprint(x)

    # Call method without argument
    x['a1'] = 'b1'
    x['a2'] = 'b2'

    # Assert value is as expected
    assert x == {'a1': 'b1', 'a2': 'b2', 'bar': 'foo', 'foo': 'baz'}
    pprint(x)


#

# Generated at 2022-06-21 22:18:54.243213
# Unit test for function get_tree_node
def test_get_tree_node():
    # set up a dict, with another dict inside, to test
    # get_tree_node.
    tree = {
        'a': {
            'b': 'c'
        }
    }
    # retrieve a value
    print(get_tree_node(tree, 'a:b'))
    # retrieve parent
    print(get_tree_node(tree, 'a:b', parent=True))
    # missing key
    print(get_tree_node(tree, 'a:c'))


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-21 22:18:57.951006
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {'a': {'b': {'c': 3}}}
    set_tree_node(d, 'a:b:c', 2)
    assert d == {'a': {'b': {'c': 2}}}



# Generated at 2022-06-21 22:19:03.757393
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 'd'
    assert get_tree_node(t, 'a:b:c') == 'd'
    assert set_tree_node(t, 'a:b', 't')['a']['b'] == 't'
    assert get_tree_node(t, 'a:b:c') is None

# Generated at 2022-06-21 22:19:09.354201
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    >>> r = RegistryTree()
    >>> r['z'] = 'x'
    >>> r['z']
    'x'
    """

# Generated at 2022-06-21 22:19:14.711054
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['1:2:3'] = 4

# Generated at 2022-06-21 22:19:19.454442
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()

    assert registry.get('foo') is None
    registry.register('foo', 'foo')
    assert registry.get('foo') == 'foo'

    registry.register('foo.bar', 'bar')
    assert registry.get('foo.bar') == 'bar'


# Test for constructor of class Tree

# Generated at 2022-06-21 22:19:23.478222
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['v:0:0:0'] = 1
    assert tree['v:0:0:0'] == 1



# Generated at 2022-06-21 22:19:29.226893
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = tree()
    test_mapping['foo'] = tree()
    test_mapping['foo']['bar'] = {
        'baz': 'cheese'
    }
    assert get_tree_node(test_mapping, 'foo:bar:baz') == 'cheese'
    assert get_tree_node(test_mapping, 'foo:bar:baz', parent=True) == {'baz': 'cheese'}



# Generated at 2022-06-21 22:19:37.637858
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test for normal key
    test_tree = {'lvl1': {'lvl2': {'lvl3': 'leaf'}}}
    assert get_tree_node(test_tree, 'lvl1:lvl2:lvl3') == 'leaf'

    # Test for missing key
    with pytest.raises(KeyError):
        get_tree_node(test_tree, 'lvl1:lvl2:missing')

    # Test for invalid key
    with pytest.raises(KeyError):
        get_tree_node(test_tree, 'lvl1:lvl3:leaf')

    # Test for default value
    assert get_tree_node(test_tree, 'lvl1:lvl2:missing', default=None) is None



# Generated at 2022-06-21 22:19:43.101353
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 34}}, 'a:b', 42) == 34
    with pytest.raises(KeyError):
        get_tree_node({}, 'a:b', 42)
    with pytest.raises(KeyError):
        get_tree_node({'a': {'b': 34}}, 'a:b')



# Generated at 2022-06-21 22:19:48.483788
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    config_tree = Tree()

    # Testing parameters
    key = 'test_key'
    value = 'test_value'
    namespace = 'test_ns'

    # Testing the call of the __setitem__ method
    value_returned = config_tree._namespace_key(key, namespace)
    assert value_returned == 'test_ns:test_key'
    config_tree.__setitem__(key, value, namespace)



# Generated at 2022-06-21 22:19:53.073405
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test for function `set_tree_node` .

    """
    t = tree()
    assert set_tree_node(t, 'foo:bar', 1) == {'bar': 1}



# Generated at 2022-06-21 22:20:01.663938
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Unit test for method __setitem__ of class Tree

    """
    # Test raising error if no default is provided
    _data = {}
    _key = 'foo'
    _value = 'bar'
    tree = Tree()
    tree.__setitem__(_key, _value)
    assert dict(_data) == dict(tree)

    # Test raising error if default is provided
    _data = {_key: _value}
    tree = Tree(initial=_data)
    tree.__setitem__(_key, _value)
    assert dict(_data) == dict(tree)

    # TODO: More tests



# Generated at 2022-06-21 22:20:08.786519
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for constructor of class RegistryTree."""
    tree = RegistryTree()



# Generated at 2022-06-21 22:20:17.915503
# Unit test for constructor of class Tree
def test_Tree():
    """
    Demonstrate usage of Tree class.
    """
    from pprint import pprint
    t = Tree(namespace='example')
    t.register(u'foo', 1)
    t.register(u'bar', 2)
    t.register(u'baz:k1', 42)
    t.register(u'baz:k2', True)
    t.register(u'baz:k3', {'foo': 'bar', 'baz': 'baz'})
    t.register(u'baz:k4', 'foobar')
    t.register(u'baz:k5', [1, 2, 3])
    pprint(t.data)



# Generated at 2022-06-21 22:20:28.257530
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert t is not None, 'Tree instantiated'
    t = Tree(namespace=':')
    assert t is not None, 'Tree instantiated'
    assert ':' in t, 'Tree has ":" namespace with instantiation'
    assert t[':'] is not None, 'Tree has ":" namespace with instantiation'
    assert t['larry'] is None, 'Tree looks like a tree, not a dictionary'

    t = Tree(initial={'namespace': 'namespace', 'value': True})
    assert t.get('value') is True, 'Tree initialized with initial'
    assert 'namespace' in t, 'Tree initialized with initial'
    assert 'larry' not in t, 'Tree initialized with initial'

    t['larry'] = 1

# Generated at 2022-06-21 22:20:39.501796
# Unit test for constructor of class Tree
def test_Tree():
    import pprint
    log = pprint.pprint

    tree = Tree()
    tree['a']['a']['a'] = 1
    log(tree)
    log(tree['a'])
    log(tree['a']['a']['a'])
    tree['a']['a']['b'] = 2
    log(tree['a']['a'])
    tree['a']['a']['c']['d'] = 4
    log(tree['a']['a']['c'])
    log(tree['a']['a']['c']['d'])
    assert tree['a']['a']['c']['d'] == 4
    tree['a:a:a:a'] = 5

# Generated at 2022-06-21 22:20:43.661545
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'a': 1, 'b': 2, 'c': {'d': {'e': 3}}})
    assert t['a'] == 1
    assert t['c:d:e'] == 3
    assert t.get('x', 4) == 4



# Generated at 2022-06-21 22:20:46.827290
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Test case for function Tree.__getitem__."""
    tree = Tree()
    tree['foo']['bar'] = 'test'
    assert tree['foo:bar'] == 'test'
    tree['foo:baz'] = 'test2'
    assert tree['foo:baz'] == 'test2'


# Generated at 2022-06-21 22:20:56.044730
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    assert test_dict == set_tree_node(test_dict, 'a', 2)
    assert test_dict == {'a': 2}

    test_dict = {}
    assert test_dict == set_tree_node(test_dict, 'a:b:c:e', 2)
    assert test_dict == {'a': {'b': {'c': {'e': 2}}}}

    test_dict = {'a': {'b': {'c': {'e': 1}}}}
    assert test_dict == set_tree_node(test_dict, 'a:b:d:e', 2)
    assert test_dict == {'a': {'b': {'c': {'e': 1}, 'd': {'e': 2}}}}


# Generated at 2022-06-21 22:21:00.613098
# Unit test for constructor of class Tree
def test_Tree():
    mapping = Tree(namespace='foo')
    data = {'bar': {'baz': 'bam',
                    'more': ['values', 'here']}}
    mapping.update(data)
    assert mapping['bar:baz'] == 'bam'
    assert mapping['bar:more:1'] == 'here'



# Generated at 2022-06-21 22:21:11.840373
# Unit test for function tree
def test_tree():
    t = tree()

    t['a']['b'] = 1
    t['a']['c'] = 2
    t['a']['d'] = 3

    t['a']['e'] = {'f': 1, 'g': 2}

    assert t['a'] == {'b': 1, 'c': 2, 'd': 3, 'e': {'f': 1, 'g': 2}}
    assert t['a']['e'] == {'f': 1, 'g': 2}
    assert t['a']['b'] == 1
    assert t['a']['c'] == 2
    assert t['a']['d'] == 3

    assert get_tree_node(t, 'a:e') == {'f': 1, 'g': 2}
    assert get_tree_node

# Generated at 2022-06-21 22:21:16.868571
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t.namespace = 'src'
    t['foo']['bar'] = 'herp'
    t['foo']['bar']
    assert t['foo']['bar'] == 'herp'



# Generated at 2022-06-21 22:21:30.586177
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    data = {'a': {'b': 1}}
    t = Tree(data)
    t['a:b'] = 2
    assert t['a:b'] == 2



# Generated at 2022-06-21 22:21:33.204958
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree.update({'hi': {'there': 'sup'}})
    assert tree['hi:there'] == 'sup'



# Generated at 2022-06-21 22:21:37.806714
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    obj = Tree()
    obj['a']['b'] = 'c'
    assert obj['a:b'] == 'c'
    assert obj['a']['b'] == 'c'
    assert obj.get('a:b') == 'c'
    assert obj['a:b:c:d'] == Tree()



# Generated at 2022-06-21 22:21:46.881176
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'key1': {
            'key2': {
                'key3': {
                    'key4': 'val4',
                }
            }
        },
    }

    assert get_tree_node(test_dict, 'key1:key2:key3:key4') == 'val4'
    assert get_tree_node(test_dict, 'key1:key2:key3:key5') is _sentinel
    assert get_tree_node(test_dict, 'key1:key2:key3:key5', default='default') == 'default'

    test_dict2 = {
        'key1': {
            'key2': {
                'key3': {
                    'key4': 'val4',
                }
            }
        }
    }
    assert get

# Generated at 2022-06-21 22:21:55.589071
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'toplevel': {
            'second': {
                'third': 'leaf',
            },
        },
    }

    assert get_tree_node(data, 'toplevel') == data['toplevel']
    assert get_tree_node(data, 'toplevel:second') == data['toplevel']['second']
    assert get_tree_node(data, 'toplevel:second:third') == 'leaf'

    try:
        get_tree_node(data, 'toplevel:second:fourth')
    except KeyError:
        pass
    else:
        raise



# Generated at 2022-06-21 22:22:00.428870
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    d = {'a': {'b': {'c': 'd'}}}
    t = Tree(d)
    t['a:b:c'] = 'e'

# Generated at 2022-06-21 22:22:03.699193
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'foo:bar:baz', 'hello')

# Generated at 2022-06-21 22:22:08.695470
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
            'biz': {
                'buz': 'yay'
            }
        }
    }

    assert 'baz' == get_tree_node(mapping, 'foo:bar')
    assert 'yay' == get_tree_node(mapping, 'foo:biz:buz')

    try:
        get_tree_node(mapping, 'foo:biz:biz:buz')
    except KeyError:
        assert True



# Generated at 2022-06-21 22:22:11.665934
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = RegistryTree()
    tree.register('a')
    assert tree['a'] is not None
    tree = RegistryTree()
    tree.register('b', 'c', 'd')
    assert tree['b']['c']['d'] is not None

# Generated at 2022-06-21 22:22:23.085786
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo'] = 'blah'
    assert t['foo'] == 'blah'
    t['bar:baz'] = 'quux'
    assert t['bar:baz'] == 'quux'
    assert t['bar']['baz'] == 'quux'
    t2 = Tree(t)
    assert t2['bar']['baz'] == 'quux'
    assert t['bar']['baz'] == 'quux'
    t3 = Tree(t2, initial_is_ref=True)
    assert t3['bar']['baz'] == 'quux'
    assert t3['bar']['baz'] == 'quux'

# Generated at 2022-06-21 22:22:46.190797
# Unit test for function set_tree_node
def test_set_tree_node():
    output = {}
    expected = {'a': {'b': {'c': 'd'}}}

    set_tree_node(output, 'a:b:c', 'd')
    assert output == expected



# Generated at 2022-06-21 22:22:53.308564
# Unit test for function tree
def test_tree():
    tree = tree()
    tree['a'] = 'foo'

# Generated at 2022-06-21 22:22:57.034154
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Unit test for method __getitem__ of class Tree"""
    tree = Tree()
    tree['a'] = 1
    tree['b:c'] = 2

    assert tree['a'] == 1
    assert tree['b:c'] == 2



# Generated at 2022-06-21 22:23:00.257765
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = {}
    set_tree_node(test_tree, 'testing:this:out', 555)
    assert test_tree == {'testing': {'this': {'out': 555}}}



# Generated at 2022-06-21 22:23:06.777486
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': 'b'})
    assert t['a'] == 'b'

    t = Tree({'a': 'b'}, initial_is_ref=True)
    assert t['a'] == 'b'

    t = Tree()
    t['a'] = 'b'
    assert t['a'] == 'b'

    t = Tree(namespace='lol')
    assert t._namespace_key('a') == 'lol:a'



# Generated at 2022-06-21 22:23:12.464625
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': {'b': 'value'}}
    assert get_tree_node(d, 'a') == {'b': 'value'}
    assert get_tree_node(d, 'a:b') == 'value'
    assert get_tree_node(d, 'a:c') is _sentinel



# Generated at 2022-06-21 22:23:14.361350
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'foo': 'bar'}, namespace='baz')
    assert t['foo'] == 'bar'
    assert t['baz:foo'] == 'bar'

# Generated at 2022-06-21 22:23:17.068612
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    assert isinstance(tree, dict)
    assert isinstance(tree, collections.defaultdict)



# Generated at 2022-06-21 22:23:18.185206
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass  # Build me!



# Generated at 2022-06-21 22:23:26.624030
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'foo': 'bar'})
    assert tree['foo'] == 'bar'

    tree = Tree({'foo': 'bar'}, 'myns')
    assert tree['foo'] == 'bar'
    assert tree['myns:foo'] == 'bar'

    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'

    tree = Tree(namespace='myns')
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'
    assert tree['myns:foo'] == 'bar'



# Generated at 2022-06-21 22:24:07.732150
# Unit test for constructor of class Tree
def test_Tree():
    assert isinstance(Tree(), Tree)



# Generated at 2022-06-21 22:24:08.766893
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass



# Generated at 2022-06-21 22:24:13.739623
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(namespace='argv')
    tree.register(':0', 'run.py')
    tree.register(':1', 'test')
    tree.register(':2', '-m')
    tree.register(':3', 'tests.unit.test_collections')
    assert tree['0'] == 'run.py'
    assert tree['3'] == 'tests.unit.test_collections'
    assert tree[':3'] == 'tests.unit.test_collections'
    assert tree.get('3', default='boo') == 'tests.unit.test_collections'



# Generated at 2022-06-21 22:24:24.243540
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'foo': {'bar': 'baz'}}
    set_tree_node(mapping, 'foo:bar', 'baz2')
    assert mapping == {'foo': {'bar': 'baz2'}}

    mapping = {'foo': {'bar': 'baz'}}
    assert set_tree_node(mapping, 'foo:bar2', 'baz2') == {'bar': 'baz2'}
    assert mapping == {'foo': {'bar': 'baz', 'bar2': 'baz2'}}

    try:
        mapping = {'foo': {'bar': 'baz'}}
        set_tree_node(mapping, 'foo:bar:bar', 'baz2')
    except KeyError:
        pass
    else:
        assert False


# Unit

# Generated at 2022-06-21 22:24:33.598669
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'uno:dos:tres', 'valor')
    assert mapping['uno']['dos']['tres'] == 'valor'
    set_tree_node(mapping, 'uno', 'otro_valor')
    assert mapping['uno'] == 'otro_valor'
    set_tree_node(mapping, 'uno:dos:tres:cuatro', 'valor')
    assert mapping['uno']['dos']['tres']['cuatro'] == 'valor'



# Generated at 2022-06-21 22:24:37.124753
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry_tree = RegistryTree()
    registry_tree.register('SomeKey', 'SomeValue')

    assert registry_tree.get('SomeKey') == 'SomeValue'

# Generated at 2022-06-21 22:24:45.229126
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 'a'
    t['a:b'] = 'a:b'
    t['a:c'] = 'a:c'
    t['b'] = 'b'
    t['b:c'] = 'b:c'
    t['b:d'] = 'b:d'
    assert t['a'] == 'a'
    assert t['a:b'] == 'a:b'
    assert t['a:c'] == 'a:c'
    assert t['b'] == 'b'
    assert t['b:c'] == 'b:c'
    assert t['b:d'] == 'b:d'



# Generated at 2022-06-21 22:24:53.389582
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {
        "foo": {
            "bar": {"baz": 1},
            "meh": [1, 2, 3, 4]
        }
    }
    assert get_tree_node(a, "foo:bar:baz") == 1
    assert get_tree_node(a, "foo:bar:d") is _sentinel
    try:
        assert get_tree_node(a, "foo:bar:d") == _sentinel
    except KeyError:
        pass

    b = {
        "foo": {
            "bar": "baz",
            "baz": "baz"
        }
    }
    assert get_tree_node(b, "foo:bar", parent=True) == b['foo']

# Generated at 2022-06-21 22:24:56.516479
# Unit test for function tree
def test_tree():
    tree = tree()
    tree['a']['b']['c'] = 'd'
    assert tree['a:b:c'] == 'd'



# Generated at 2022-06-21 22:25:01.265926
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    expected_value = 'foo'
    expected_key = 'bar'
    tree_instance = Tree()
    tree_instance.__setitem__(
        key=expected_key,
        value=expected_value
    )
    assert expected_value == tree_instance[expected_key]



# Generated at 2022-06-21 22:26:40.539977
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['a'] = 'alpha'
    data['b:b'] = 'bravo'
    data['b:b:b'] = 'bravo'
    data['b:b:c'] = 'charlie'
    data['b:c'] = 'charlie'
    data['b:c:b'] = 'bravo'
    data['c:b'] = 'bravo'

    assert 'alpha' == get_tree_node(data, 'a')
    assert 'bravo' == get_tree_node(data, 'b:b:b')
    assert 'bravo' == get_tree_node(data, 'b:c:b')
    assert 'bravo' == get_tree_node(data, 'c:b')

    # Test default value

# Generated at 2022-06-21 22:26:47.860103
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test = {
        'root': {
            'a': 'b',
            'c': {
                'd': 'e',
                'f': {
                    'g': 'h'
                },
                'i': None
            },
            'j': 'k'
        }
    }
    tree = Tree(initial=test)
    assert tree.get('root:a') == 'b'
    assert tree.get('root:c:f:g') == 'h'
    assert tree.get('root:c:i') is None
    assert tree.get('root:c:j', default='l') == 'l'

# Generated at 2022-06-21 22:26:52.520289
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['abc'] = 'foo'
    tree['abc:def:zzz'] = 'bar'
    tree['abc:def:xyz'] = 'baz'
    tree['abc:bar:xyz'] = 'qux'
    assert tree['abc'] == 'foo'
    assert tree['abc:def:zzz'] == 'bar'
    assert tree['abc:def:xyz'] == 'baz'
    assert tree['abc:bar:xyz'] == 'qux'


if __name__ == '__main__':
    test_tree()
    print("OK!")

# Generated at 2022-06-21 22:26:58.059944
# Unit test for function set_tree_node
def test_set_tree_node():
    # Setup
    m = {}

    # Exercise
    set_tree_node(m, 'a:b:c', 'd')

    # Assert
    assert m['a']['b']['c'] == 'd'


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-21 22:27:08.290913
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'Baz',
                'faz': 'Faz'
            }
        }
    }
    assert get_tree_node(tree, 'foo:bar:baz') == 'Baz'
    assert get_tree_node(tree, 'foo:bar:faz') == 'Faz'

    assert get_tree_node(tree, 'foo:bar:baz:placeholder') is None
    assert get_tree_node(tree, 'placeholder:placeholder') is None
    try:
        assert get_tree_node(tree, 'placeholder:placeholder', default=_sentinel)
    except Exception:
        pass
    else:
        assert False



# Generated at 2022-06-21 22:27:11.542267
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(initial={'a': {'b': {'c': 1, 'd': 2}}})
    assert tree
    assert tree['a:b:c'] == 1
    assert tree['a:b:d'] == 2



# Generated at 2022-06-21 22:27:20.154983
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={'a': 1, 'b': 'c'})
    assert t['a'] == 1
    assert t['b'] == 'c'
    t = Tree(initial={'a': 1, 'b': 'c'}, namespace='a:b:c')
    assert t['a'] == 1
    assert t['b'] == 'c'
    assert t.get('d', namespace=':a') == _sentinel
    assert t.get('d', namespace='a:b:c') == _sentinel
    t.register('e', 'f', namespace=':a')
    assert t.get('e', namespace='a:b:c') == 'f'
    assert t.get('e', namespace='a') == 'f'



# Generated at 2022-06-21 22:27:32.433526
# Unit test for constructor of class Tree
def test_Tree():
    test_data = {
        'test': {
            'test2': {
                'test3': 5,
            }
        },
    }

    test_data2 = {
        'test': {
            'test2': {
                'test3': 5,
            }
        },
    }

    test_data3 = {
        'test': {
            'test2': {
                'test3': 3,
            }
        },
    }

    tree = Tree(test_data)
    tree2 = Tree(test_data2)
    tree3 = Tree(test_data3)

    assert tree['test']['test2']['test3'] == 5
    assert tree2['test']['test2']['test3'] == 5

# Generated at 2022-06-21 22:27:37.580687
# Unit test for function set_tree_node
def test_set_tree_node():
    test = tree()
    set_tree_node(test, 'foo:bar:baz', 'Hello')
    set_tree_node(test, 'foo:bar:quux', 'World')
    print(test)


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-21 22:27:46.429066
# Unit test for function tree