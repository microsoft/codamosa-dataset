

# Generated at 2022-06-21 22:18:05.197076
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['foo']['bar']['biz'] = 42

    assert get_tree_node(data, 'foo') is data['foo']
    assert get_tree_node(data, 'foo:bar') is data['foo']['bar']
    assert get_tree_node(data, 'foo:bar:biz') == 42



# Generated at 2022-06-21 22:18:11.375685
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree_class = RegistryTree

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    tree = tree_class(initial={tree_class.namespace: {'a': a, 'b': b, 'c': c}})
    assert tree == {
        'a': a,
        'b': b,
        'c': c,
    }



# Generated at 2022-06-21 22:18:13.439968
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.__setitem__('testing one two three')
    assert t == 'testing one two three'



# Generated at 2022-06-21 22:18:15.539829
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('ns:key', 'value')
    assert tree.get('ns:key') == 'value'



# Generated at 2022-06-21 22:18:20.876849
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {
        'a': {
            'b': {
                'c': 123,
                'd': 456
            }
        }
    }
    set_tree_node(d, 'a:b:c', 999)
    assert d['a']['b']['c'] == 999



# Generated at 2022-06-21 22:18:31.742992
# Unit test for constructor of class Tree
def test_Tree():
    t1 = Tree()
    t1['foo'] = 'bar'
    assert t1['foo'] == 'bar'

    t2 = Tree(t1)
    assert t2['foo'] == 'bar'

    t3 = Tree(t1, initial_is_ref=True)
    assert t3['foo'] == 'bar'
    t1['foo'] = 'baz'
    assert t3['foo'] == 'baz'

    t4 = Tree(namespace='foo')
    t4['bar'] = 'baz'
    assert t4['bar'] == 'baz'
    assert t4['foo:bar'] == 'baz'

    t5 = Tree(None, 'foo')
    t5['bar'] = 'baz'
    assert t5['bar'] == 'baz'
    assert t

# Generated at 2022-06-21 22:18:43.073654
# Unit test for function tree
def test_tree():
    # This is weird..
    items = [
        ('a:b:c:d:e:f:g', 0),
        ('a:x:c:d:e:f:g', 0),
        ('a:b:c:d:e:f:h', 0),
        ('a:b:c:j:e:f:h', 0),
    ]

    tree = tree()
    for key, value in items:
        tree[key] = value

    assert tree['a:b:c:d:e:f:g'] == 0
    assert tree['a:b']['c']['d']['e']['f']['g'] == 0
    assert tree['a:b']['c']['j']['e']['f']['h'] == 0

    tree

# Generated at 2022-06-21 22:18:50.391292
# Unit test for function tree
def test_tree():
    assert set_tree_node(tree(), 'one:two:three', 3) == {'one': {'two': {'three': 3}}}
    assert get_tree_node(tree(), 'one:two:three', 3) == 3
    assert get_tree_node({'one': {'two': {'three': 3}}}, 'one:two:three') == 3
    assert get_tree_node({'one': {'two': {'three': 3}}}, 'one:two:three', 3) == 3
    assert get_tree_node({'one': {'two': {'three': 3}}}, 'one:three', 3) == 3
    assert get_tree_node({'one': {'two': {'three': 3}}}, 'one:four', 3) == 3



# Generated at 2022-06-21 22:18:53.462991
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='global')
    t['hello'] = 'world'
    assert t['global:hello'] == 'world'



# Generated at 2022-06-21 22:18:56.434892
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo', 'king', 'bar'] = 'bar'
    assert tree.data == {'foo': {'king': {'bar': 'bar'}}}



# Generated at 2022-06-21 22:19:08.891028
# Unit test for function set_tree_node
def test_set_tree_node():
    from pprint import pprint
    from re import match

    input_ = {
        'a': 1,
        'b': 2,
        'c': 3
    }

    # TODO: FIXME
    output = copy.deepcopy(input_)
    output['d'] = {
        'e': {
            'f': {
                'g': 7
            }
        }
    }

    set_tree_node(input_, 'd:e:f:g', 7)
    # assert input_ == output


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-21 22:19:20.229626
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from pytest import raises
    from operator import eq
    # True
    t = tree()
    t['foo']['bar'] = 'baz'
    eq(
        Tree(initial=t)['foo']['bar'],
        'baz'
    )
    # True
    t = tree()
    t['foo']['1']['2']['3']['4']['5']['bar'] = 'baz'
    eq(
        Tree(initial=t, namespace='foo')['1:2:3:4:5:bar'],
        'baz'
    )
    # True
    t = tree()
    t['foo']['1']['2']['3']['4']['5']['bar'] = 'baz'

# Generated at 2022-06-21 22:19:24.257207
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    a = Tree()
    a.__setitem__('a','b','c','d','e','f','g','h')
    assert len(a.keys()) == 1



# Generated at 2022-06-21 22:19:25.257044
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass # DONE



# Generated at 2022-06-21 22:19:32.958853
# Unit test for function tree
def test_tree():
    """
    $ python -m treehouse.utils.tree test_tree
    """
    t = RegistryTree()
    t.register('a', 'a')
    t.register('a:b', 'b')
    t.register('a:b:c', 'c')
    t.register('a:b:c:d', 'd')
    assert t.get('a') == 'a'
    assert t.get('a:b') == 'b'
    assert t.get('a:b:c') == 'c'
    assert t.get('a:b:c:d') == 'd'
    assert t.get('a:b:c:d:e') is None

    t = RegistryTree()
    t.register('a:a', 'a')
    t.register('a:b', 'b')

# Generated at 2022-06-21 22:19:34.425979
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    t.register(1, 'first')
    assert t.get(1) == 'first'



# Generated at 2022-06-21 22:19:37.499295
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    test = test_dict
    for k in 'a:b:c'.split(':'):
        assert test[k] is not None
        test = test[k]



# Generated at 2022-06-21 22:19:47.255458
# Unit test for function tree
def test_tree():
    t = tree()
    t[1][2][3][4] = 10
    assert t[1][2][3][4] == 10
    assert t[2][2] == tree()
    t[1][2][3] = [1, 2, 3]
    assert t[1][2][3] == [1, 2, 3]

    t = tree()
    t[1][2][3][4] = 10
    t[1][2][3][5] = 11
    t[1][2][3][6] = 12
    assert t[1][2][3][4] == 10
    assert t[1][2][3][5] == 11
    assert t[1][2][3][6] == 12

    t = tree()

# Generated at 2022-06-21 22:19:52.550040
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree(namespace='test')
    value = 'value'
    tree['key'] = value
    assert tree['test:key'] == value
    assert tree['key'] == value



# Generated at 2022-06-21 22:19:56.859218
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    >>> _ = RegistryTree()
    >>> _ = RegistryTree(initial={'foo': {'bar': 'baz'}})
    >>> _ = RegistryTree(initial={'foo': {'bar': 'baz'}}, initial_is_ref=True)
    """

# Generated at 2022-06-21 22:20:11.024624
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    import pytest
    test_tree = {
        'foo': {
            'bar': {
                'baz': {
                    'qux': [
                        {
                            'qux1': 'quux'
                        }
                    ]
                }
            }
        }
    }

    with pytest.raises(KeyError):
        get_tree_node(test_tree, 'foo:bar:baz:quxx')

    with pytest.raises(KeyError):
        get_tree_node(test_tree, 'foo:bar:baz:qux:quux')

    with pytest.raises(KeyError):
        get_tree_node(test_tree, 'foo:bar:baz:qux:0:quux')


# Generated at 2022-06-21 22:20:21.864664
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import unittest
    # AssertionError with message "None != 'bar'"
    testing = unittest.TestCase('__init__')
    tst = Tree()
    tst['foo'] = {'bar': 'baz'}
    testing.assertEqual(tst['foo:bar'], 'baz')
    testing.assertEqual(tst['foo']['bar'], 'baz')
    testing.assertEqual(tst.get('foo:bar'), 'baz')
    testing.assertEqual(tst.get('foo/bar'), 'baz')
    testing.assertEqual(tst.get('bar'), None)
    testing.assertEqual(tst.get('bar', 'bar'), 'bar')


if __name__ == '__main__':
    test_Tree___

# Generated at 2022-06-21 22:20:30.737702
# Unit test for function tree
def test_tree():
    mapping = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': {
                'g': 'h',
            }
        }
    }
    assert get_tree_node(mapping, 'a') == 'b'
    assert get_tree_node(mapping, 'c:d') == 'e'
    assert get_tree_node(mapping, 'c:f:g') == 'h'
    # Parent
    assert get_tree_node(mapping, 'c:f:g', parent=True) == {'g': 'h'}
    assert get_tree_node(mapping, 'c:f', parent=True) == {'d': 'e', 'f': {'g': 'h'}}
    # KeyError

# Generated at 2022-06-21 22:20:41.744234
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'key': 'value', 'foo': {'bar': 'baz'}})

    # Make sure all expected keys are there
    assert t['key'] == 'value'
    assert t['foo'] == {'bar': 'baz'}
    assert t['foo:bar'] == 'baz'

    # Make sure updates work as intended
    t['foo:bar'] = 'foobar'
    assert t['foo:bar'] == 'foobar'
    assert t['foo'] == {'bar': 'foobar'}

    # Make sure namespace works as intended
    t = Tree({'key': 'value', 'foo': {'bar': 'baz'}}, 'one:two')
    assert t['foo:bar'] == 'baz'

# Generated at 2022-06-21 22:20:49.694804
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t.update({'foo': {'bar': 'baz'}})
    assert t == {'foo': {'bar': 'baz'}}

    t = Tree({'foo': {'bar': 'baz'}})
    assert t == {'foo': {'bar': 'baz'}}

    # This is supported, but totally meaningless
    t = Tree(initial_is_ref={'foo': {'bar': 'baz'}})
    assert t == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-21 22:20:53.414541
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.__setitem__('foo', 'bar')
    t.__setitem__('spam', 'eggs')
    via_dict = {'spam': 'eggs', 'foo': 'bar'}
    assert t == via_dict
    return t



# Generated at 2022-06-21 22:20:57.315224
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    my_tree = RegistryTree()
    my_tree.register('hello:there:buddy')
    my_tree['hello']['test']['test1'] = {}
    my_tree['hello']['test']['test1']['test2'] = 'test3'
    assert my_tree['hello:test:test1:test2'] == 'test3'


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-21 22:21:02.554714
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, "a", 1)
    set_tree_node(tree, "b", 2)
    set_tree_node(tree, "c:d", 3)
    set_tree_node(tree, "c:e:f", 4)
    assert tree == {"a": 1, "b": 2, "c": {"d": 3, "e": {"f": 4}}}



# Generated at 2022-06-21 22:21:07.091626
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('foo:bar:baz', 'foobarbaz')
    assert tree['foo:bar:baz'] == 'foobarbaz'



# Generated at 2022-06-21 22:21:10.059534
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    obj = Tree()
    obj.__setitem__("key", "value")
    assert obj["key"] == "value"


if __name__ == '__main__':
    # test_Tree___setitem__()
    pass

# Generated at 2022-06-21 22:21:19.919723
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()

    assert isinstance(rt, RegistryTree)
    assert isinstance(rt, Tree)
    assert isinstance(rt, collections.defaultdict)

    # Tree's __init__ calls Tree.update with initial kwarg.
    # RegistryTree.update should define a namespace for the tree.
    data = {'foo': 'bar'}
    rt = RegistryTree(data, 'baz')

    assert rt.get('foo') == 'bar'
    assert rt.get('baz:foo') == 'bar'



# Generated at 2022-06-21 22:21:23.305500
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    x = Tree()
    x[1] = 1
    assert x == {1: 1}
    x[1][2] = 2
    assert x == {1: {2: 2}}
    x['foo:bar:baz'] = 3
    assert x == {1: {2: 2}, 'foo': {'bar': {'baz': 3}}}



# Generated at 2022-06-21 22:21:27.547248
# Unit test for function tree
def test_tree():
    """Test _sentinel return value."""
    tre = tree()
    try:
        tre['foo']['bar']
        assert False, 'sentinel keyerror was not correctly raised'
    except KeyError:
        pass



# Generated at 2022-06-21 22:21:29.402761
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['test'] = 1
    assert tree['test'] == 1



# Generated at 2022-06-21 22:21:40.071388
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['a'] = 'this is a'
    tree['tree']['a'] = 'this is a tree'
    tree['with']['some']['crazy']['levels'] = 'some crazy levels'
    tree['this']['is']['a']['simple']['registry']
    assert tree['a'] == 'this is a'
    assert tree['tree']['a'] == 'this is a tree'
    assert tree['with']['some']['crazy']['levels'] == 'some crazy levels'
    assert 'simple' in tree['this']['is']['a']
    assert tree['this']['is']['a']['simple']['registry'] == Tree()

    # Ensure that `tree` is not modified when we initialize `another

# Generated at 2022-06-21 22:21:44.113358
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.__setitem__('foo', 'bar')
    assert t.foo == 'bar'
    t.__setitem__('baz:bar', 'foo')
    assert t.baz.bar == 'foo'
    return True

# Generated at 2022-06-21 22:21:47.437372
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import json
    tree = Tree({'foo': {'bar': 1}})
    assert tree['foo'] == {'bar': 1}, json.dumps({'foo': {'bar': 1}}, indent=4)
    assert tree['foo:bar'] == 1, json.dumps({'foo': {'bar': 1}}, indent=4)



# Generated at 2022-06-21 22:21:57.286520
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({
        'a': {
            'b': {
                'c': 1,
                'd': 2,
            },
            'e': 3
        },
        'f': 4
    })
    assert tree.get('a:b:c') == 1
    assert tree.get('d') == tree.get('a:e') == 3
    assert '%s' % tree == "defaultdict(<class '%s'>, {'a': defaultdict(<class '%s'>, {'b': defaultdict(<class '%s'>, {'d': 2, 'c': 1}), 'e': 3}), 'f': 4})" % (
        Tree.__name__, Tree.__name__, Tree.__name__)



# Generated at 2022-06-21 22:22:01.900448
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Test that RegistryTree class constructor is working."""
    regtree = RegistryTree()
    regtree.update(tree(['a', 'b']))
    print(regtree)
    regtree['some:data'] = 5
    print(regtree)

# Generated at 2022-06-21 22:22:07.294762
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'root', 'value')
    assert tree == {'root': 'value'}
    set_tree_node(tree, 'leaf:child', 'child value')
    assert tree == {'root': 'value', 'leaf': {'child': 'child value'}}



# Generated at 2022-06-21 22:22:20.470154
# Unit test for constructor of class Tree
def test_Tree():
    data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    tree = Tree(data)
    tree.register('a:b:c', 'e')
    tree.register('a:b:c:h', 'i')
    tree.register('a:b:k:l:m:n', 'o')

    tree2 = Tree(tree.data)
    assert tree2 is tree.data
    assert tree == tree2
    assert tree is not tree2



# Generated at 2022-06-21 22:22:23.517367
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'foo:bar', 'baz')
    assert data['foo']['bar'] == 'baz'

# Generated at 2022-06-21 22:22:32.325733
# Unit test for function get_tree_node
def test_get_tree_node():
    # Default value
    tree = {
        'a': 1,
        'b': {
            'c': 3
        }
    }

    assert get_tree_node(tree, 'a') == 1
    assert get_tree_node(tree, 'b:c') == 3
    assert get_tree_node(tree, 'b:d') is _sentinel

    assert get_tree_node(tree, 'b:d', 0) == 0

    # Parent lookup
    assert get_tree_node(tree, 'b:c', parent=True) == {'c': 3}

    with pytest.raises(KeyError):
        get_tree_node(tree, 'b:d:e:f:g:h:i:j:k:l:m:n:o:p')

    # TODO: Finish tests

# Generated at 2022-06-21 22:22:37.588905
# Unit test for function tree
def test_tree():
    my_tree = tree()
    my_tree[0][1][2] = 3
    assert my_tree[0][1][2] == 3
    assert my_tree[1][1][2] == tree()

    # Edge cases
    assert tree()[0][0][0] == tree()
    assert tree() == tree()



# Generated at 2022-06-21 22:22:40.199923
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['foo:bar:baz'] = 123
    assert tree['foo:bar:baz'] == 123
    assert tree['foo:bar:baz:zoq'] == {}



# Generated at 2022-06-21 22:22:41.246951
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # TODO: Add an actual test
    pass



# Generated at 2022-06-21 22:22:47.674092
# Unit test for function tree
def test_tree():
    import pprint
    assert get_tree_node(tree(), 'foo:bar:baz') == tree()

    t = tree()
    t['foo']['bar']['baz'] = 'win'
    assert get_tree_node(t, 'foo:bar:baz') == 'win'

    t = tree()
    t['foo']['bar']['baz'] = 'win'
    assert get_tree_node(t, 'foo:bar:baz', parent=True) == {'baz': 'win'}

    t = tree()
    t['foo']['bar']['baz'] = 'win'
    set_tree_node(t, 'foo:bar:baz', 'lose')

# Generated at 2022-06-21 22:22:52.162998
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.defaultdict(dict)
    assert set_tree_node(mapping, 'foo:bar:baz', 'bam') == mapping['foo']['bar']
    assert mapping == {'foo': {'bar': {'baz': 'bam'}}}



# Generated at 2022-06-21 22:22:57.716647
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # create new empty tree
    T = RegistryTree()

    # register item in tree via str key
    T.register('key_str', 'value_str')

    # register item in tree via tuple key
    T.register(('key_tuple',), 'value_tuple')

    # register item in tree via list key
    T.register(['key_list'], 'value_list')

    # register item in tree via dict key
    T.register({'k': 'key_dict'}, 'value_dict')

    # register item in tree via namespace
    T.register('key_with_namespace', 'value_with_namespace', namespace='namespace_1')

    # register item in tree via namespace with tuple

# Generated at 2022-06-21 22:23:01.095468
# Unit test for constructor of class Tree
def test_Tree():
    class Thing(Tree):
        name = 'thing'
        namespace = 'jellybeans'
        mode = 'dry'

    try:
        Thing()
    except TypeError:
        assert True



# Generated at 2022-06-21 22:23:16.883426
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping[1][2][3] = 'Hello world!'
    assert get_tree_node(mapping, '1:2:3') == 'Hello world!'



# Generated at 2022-06-21 22:23:22.562484
# Unit test for constructor of class Tree
def test_Tree():
    """
    Test Tree constructor.
    Create a tree and add an item to it.
    Run `get` and make sure the value is the same.
    """
    expected = 42
    tree = Tree()
    tree.register('foo', expected)
    value = tree.get('foo')
    assert value == expected
    return True



# Generated at 2022-06-21 22:23:30.452213
# Unit test for function get_tree_node
def test_get_tree_node():
    m1 = tree()
    m1[1][2][3] = 'three'
    m2 = tree()
    m2['one']['two']['three'] = 'three'
    m3 = tree()
    m3[1][2][3] = 'three'
    m3[1][2][4] = 'four'

    cases = [
        (m1, '1:2:3', 'three'),
        (m2, 'one:two:three', 'three'),
        (m3, '1:2:3', 'three'),
        (m3, '1:2:4', 'four'),
        (m3, '1:x:4', None),
    ]


# Generated at 2022-06-21 22:23:33.771544
# Unit test for function set_tree_node
def test_set_tree_node():
    test = {}

    set_tree_node(test, 'one', 1)
    set_tree_node(test, 'two:two', 2)
    set_tree_node(test, 'two:four', 4)
    set_tree_node(test, 'three:one', 3)

    assert test == {
        'one': 1,
        'two': {
            'two': 2,
            'four': 4,
        },
        'three': {
            'one': 3
        }
    }



# Generated at 2022-06-21 22:23:43.919839
# Unit test for function get_tree_node
def test_get_tree_node():
    config = {
        "debug": True,
        "db_host": "localhost",
        "db": {
            "name": "testdb",
            "user": "mike",
            "pass": "mysecret",
        },
        "session": {
            "driver": "files",
            "files": {
                "path": "/tmp/sessions",
            },
            "cookie": {
                "name": "SID",
                "secure": True,
            },
        },
    }
    assert get_tree_node(config, 'debug') is True
    assert get_tree_node(config, 'session:driver') == 'files'
    assert get_tree_node(config, 'session:cookie:name') == 'SID'


# Generated at 2022-06-21 22:23:48.123754
# Unit test for function set_tree_node
def test_set_tree_node():
    my_tree = tree()
    set_tree_node(my_tree, 'one:two:three', 'four')
    assert my_tree['one']['two']['three'] == 'four'



# Generated at 2022-06-21 22:23:57.289748
# Unit test for function tree
def test_tree():
    t = tree()
    t['name'] = 'Foo'
    t['age'] = 33
    t['info']['sex'] = 'M'
    t['info']['kids'] = 2
    t['info']['likes'] = ['fishing', 'reading']
    t['info']['hair'] = {'brown': 100}

    t['name:a'] = 'Foo'
    t['age:a'] = 33
    t['info:a']['sex:a'] = 'M'
    t['info:a']['kids:a'] = 2
    t['info:a']['likes:a'] = ['fishing', 'reading']
    t['info:a']['hair:a'] = {'brown:a': 100}


# Generated at 2022-06-21 22:24:08.817067
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    expected = 'value3.2.1'
    t = Tree({
        'key1': 'value1',
        'key2:key2.1': 'value2.1',
        'key2:key2.2': 'value2.2',
        'key2:key2.2:key2.2.1': 'value2.2.1',
        'key2:key2.2:key2.2.2': 'value2.2.2',
        'key3:key3.1': 'value3.1',
        'key3:key3.2:key3.2.1': 'value3.2.1',
        'key3:key3.2:key3.2.2': 'value3.2.2',
    })


# Generated at 2022-06-21 22:24:10.753502
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'test': {'test': {}}})
    assert tree['test']['test'] == {}



# Generated at 2022-06-21 22:24:21.928728
# Unit test for function set_tree_node
def test_set_tree_node():
    example_dict = {}

    set_tree_node(example_dict,
                  "a:b:c",
                  "some_value")

    assert example_dict == {
        'a': {
            'b': {
                'c': 'some_value'
            }
        }
    }

    set_tree_node(example_dict,
                  "a:d:e",
                  "another_value")

    assert example_dict == {
        'a': {
            'b': {
                'c': 'some_value'
            },
            'd': {
                'e': 'another_value'
            }
        }
    }

    set_tree_node(example_dict,
                  "a:b:f",
                  "yet_another_value")


# Generated at 2022-06-21 22:24:49.733279
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'



# Generated at 2022-06-21 22:24:57.487971
# Unit test for function get_tree_node
def test_get_tree_node():
    """Ensure that get_tree_node works as intended."""
    mapping = {
        'foo': {
            'bar': {
                'baz': 'value',
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'value'
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'foo:bar:baz:quux')



# Generated at 2022-06-21 22:25:02.062854
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    t = tree()
    set_tree_node(t, 'a:b:c', 'd')
    assert t['a']['b']['c'] == 'd'

    t = {'a': {}}
    set_tree_node(t, 'a:b:c', 'd')
    assert t['a']['b']['c'] == 'd'



# Generated at 2022-06-21 22:25:11.192939
# Unit test for function get_tree_node
def test_get_tree_node():
    source_tree = {'root': {'child': {'grandchild': 'grandchild value'}}}
    tree_node = get_tree_node(source_tree, 'root:child:grandchild')
    assert tree_node == 'grandchild value'

    tree_node = get_tree_node(source_tree, 'root:child:grandchild', parent=True)
    assert tree_node == {'grandchild': 'grandchild value'}

    try:  # Throw an error
        get_tree_node(source_tree, 'root:child:grandchild:greatgrandchild')
    except KeyError:
        pass
    else:
        assert False, "Should throw an error"

    tree_node = get_tree_node(source_tree, 'root:child:grandchild:greatgrandchild', default='default node')

# Generated at 2022-06-21 22:25:14.736568
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree(initial={'foo': 'bar'})
    registry.register('qux', 'quux')
    assert registry.get('foo') == 'bar'
    assert registry.get('qux') == 'quux'

# Generated at 2022-06-21 22:25:20.790233
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for :func:`set_tree_node`"""
    tree = {}
    set_tree_node(tree, "first", "one")
    assert tree == {"first": "one"}
    set_tree_node(tree, "second", "one")
    assert tree == {"first": "one", "second": "one"}
    set_tree_node(tree, "first:second", "two")
    assert tree == {"first": {"second": "two"}, "second": "one"}
    set_tree_node(tree, "first:second:third", "three")
    assert tree == {"first": {"second": {"third": "three"}}, "second": "one"}



# Generated at 2022-06-21 22:25:23.419330
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'a': {'aa': 'a'}})
    assert t['a:aa'] == 'a'



# Generated at 2022-06-21 22:25:30.971452
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        # Initial
        'foo': {
            'bar': 'baz',
            'biz': {
                # Goal
                'qux': 1,
                # Goal
                'quux': 2,
            }
        }
    }
    assert get_tree_node(mapping, 'foo') == {'bar': 'baz', 'biz': {'quux': 2, 'qux': 1}}
    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:biz') == {'qux': 1, 'quux': 2}
    assert get_tree_node(mapping, 'foo:biz:qux') == 1
    assert get_tree_node(mapping, 'foo:biz:quux') == 2

# Generated at 2022-06-21 22:25:33.698368
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree2 = Tree()
    tree2["test"]["test"] = "test"
    pprint(tree2)



# Generated at 2022-06-21 22:25:35.687428
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class SubRegistryTree(RegistryTree):
        pass

    assert isinstance(SubRegistryTree(), RegistryTree)

# Generated at 2022-06-21 22:26:37.492246
# Unit test for function get_tree_node
def test_get_tree_node():

    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b') == {
        'c': 'd'
    }
    assert get_tree_node(tree, 'a') == {
        'b': {
            'c': 'd'
        }
    }
    assert get_tree_node(tree, 'b:c:d') is _sentinel



# Generated at 2022-06-21 22:26:41.692303
# Unit test for function set_tree_node
def test_set_tree_node():
    fixture = tree()
    set_tree_node(fixture, 'level1:level2:level3', 1234)
    assert fixture['level1']['level2']['level3'] == 1234



# Generated at 2022-06-21 22:26:44.549831
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    value = 'hello'
    t = Tree()
    t[''] = value
    assert t[''] == value, "Tree[''] should return `value`"



# Generated at 2022-06-21 22:26:45.786037
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    assert isinstance(t, RegistryTree)



# Generated at 2022-06-21 22:26:48.116831
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    mapping = tree()
    assert set_tree_node(mapping, 'foo:bar', 'baz') == {'bar': 'baz'}



# Generated at 2022-06-21 22:26:54.138437
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {
        'a': {
            'b': {
                'c': 'suh dude',
            },
        },
        'foo': 'bar',
    }

    assert get_tree_node(a, 'a:b:c') == 'suh dude'
    assert get_tree_node(a, 'foo') == 'bar'
    assert get_tree_node(a, 'a:b') == {'c': 'suh dude'}
    assert get_tree_node(a, 'a:b:b') is _sentinel
    assert get_tree_node(a, 'a:b:b', default='bingo') == 'bingo'
    assert get_tree_node(a, 'a:b:c', parent=True) == {'c': 'suh dude'}
    assert get

# Generated at 2022-06-21 22:27:04.450978
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    Simple unit test for constructor of class RegistryTree
    """

    # 3 cases for RegistryTree construction:
    # 1. Initial is not None, initial_is_ref is False
    # 2. Initial is None, initial_is_ref is False
    # 3. Initial is not None, initial_is_ref is True
    initial_1 = {'key_1': 'val_1'}
    initial_2 = {'key_1': 'val_1'}
    initial_3 = {'key_1': 'val_1'}
    registry_tree_1 = RegistryTree(initial=initial_1, initial_is_ref=False)
    registry_tree_2 = RegistryTree(initial=None, initial_is_ref=False)

# Generated at 2022-06-21 22:27:14.036175
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(data, 'a:b') == {'c': 'd'}
    assert get_tree_node(data, 'a:b:c') == 'd'
    assert get_tree_node(data, 'a:b:c:d', default=False) is False
    assert get_tree_node(data, 'a:b:c:e', default=False) is False
    assert get_tree_node(data, 'a:b', parent=True) == {'b': {
        'c': 'd'
    }}



# Generated at 2022-06-21 22:27:17.599746
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    >>> test_map = collections.defaultdict(tree)
    >>> test_map = set_tree_node(test_map, 'bob:dole', 'why not')
    >>> test_map['bob']['dole']
    'why not'

    """


# Generated at 2022-06-21 22:27:22.952223
# Unit test for function get_tree_node
def test_get_tree_node():
    test_1 = {
        'first_1': {
            'second_1': {
                'third_1': 'example_1'
            },
            'second_2': 'example_2'
        },
        'first_2': 'example_3'
    }

    assert get_tree_node(test_1, 'first_1:second_1:third_1') == 'example_1'
    assert get_tree_node(test_1, 'first_1:second_2') == 'example_2'
    assert get_tree_node(test_1, 'first_2') == 'example_3'

