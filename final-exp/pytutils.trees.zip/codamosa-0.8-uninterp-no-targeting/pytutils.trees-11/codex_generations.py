

# Generated at 2022-06-21 22:18:10.006622
# Unit test for constructor of class Tree
def test_Tree():
    d = Tree()
    # Test item insertion
    d['a']['b'] = 'c'
    assert d['a:b'] == 'c'
    assert d['a']['b'] == 'c'

    # Test item selection
    d['a']['b'] = 'c'
    assert d['a:b'] == 'c'
    assert d['a']['b'] == 'c'

    # Test tree creation
    d['a']['b']['c'] = 'd'
    assert d['a:b:c'] == 'd'

    # Test tree creation
    d['a']['b']['c'] = 'd'
    assert d['a:b:c'] == 'd'
    assert d['a']['b']['c'] == 'd'



# Generated at 2022-06-21 22:18:16.332238
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 1)
    assert t['a']['b']['c'] == 1
    set_tree_node(t, 'a:b', 2)
    assert t['a']['b'] == 2
    set_tree_node(t, 'a:b:c', 3)
    assert t['a']['b'] == 3


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-21 22:18:19.664976
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register(['foo', 'foo:bar'], 'baz')
    assert registry['foo:foo:bar'] == 'baz'



# Generated at 2022-06-21 22:18:22.956003
# Unit test for function set_tree_node
def test_set_tree_node():
    x = {}
    set_tree_node(x, 'a:b', 1)
    assert x == {'a': {'b': 1}}



# Generated at 2022-06-21 22:18:28.472398
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    assert RegistryTree().namespace == ''
    assert RegistryTree(namespace='main').namespace == 'main'
    assert RegistryTree().namespace == ''

    tree = RegistryTree(initial={'foo': 1})
    tree.register('foo', 2)
    assert tree['foo'] == 2
    tree.register('foo', 2, namespace='main')
    assert tree.get('foo', namespace='main') == 2

# Generated at 2022-06-21 22:18:31.353746
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'foo:bar:1', 'my_value')
    assert t['foo']['bar'][1] == 'my_value'



# Generated at 2022-06-21 22:18:36.150899
# Unit test for constructor of class Tree
def test_Tree():
    a = {'a': {'b': {'c': 10}}}
    t = Tree(a)
    assert t['a:b:c'] == 10
    t['a:b:c:d:e'] = 11
    assert t['a:b:c:d:e'] == 11



# Generated at 2022-06-21 22:18:42.115246
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Test the method __setitem__ of class Tree.
    """
    tree = Tree()
    tree['tree:test'] = 1
    assert tree['tree:test'] == 1
    assert tree.get('tree:test') == 1
    assert tree.get('tree:nope', None) is None
    tree['tree:test'] = 2
    assert tree['tree:test'] == 2



# Generated at 2022-06-21 22:18:45.064150
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': {'b': {'c': 'd'}}})
    assert t == {'a': {'b': {'c': 'd'}}}
    assert t.get('a:b:c') == 'd'

# Generated at 2022-06-21 22:18:51.395726
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    assert t['a']['b'] == t.get('a:b') == {}
    t['a:b:c:d:e'] = 'f'
    assert t['a:b:c:d:e'] == t.get('a:b:c:d:e') == 'f'
    assert t['a:b:c:d'] == t.get('a:b:c:d') == {'e': 'f'}
    assert t['a:b:c'] == t.get('a:b:c') == {'d': {'e': 'f'}}
    assert t['a:b'] == t.get('a:b') == {'c': {'d': {'e': 'f'}}}

# Generated at 2022-06-21 22:19:06.309151
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function `get_tree_node`

    This test assumes that dict assignment ordering has been sorted and that Python 3.6
    guarantees dict insertion ordering to remain the same throughout the program lifetime.

    This test isn't strictly necessary, but makes me feel all warm and fuzzy inside.
    """
    # Setup
    namespace = '^_^'
    key = ':3:4:5'
    key_list = [':', '3', '4', '5']
    default = KeyError('Oh noes! :(')

    # Test
    node = get_tree_node(tree(), key, default=default)

    # Assert
    assert isinstance(node, Tree) is False
    assert key_list == [child for child in node]



# Generated at 2022-06-21 22:19:18.572447
# Unit test for function tree
def test_tree():
    some_tree = tree()
    assert len(some_tree) == 0, 'Empty tree is not empty'
    some_tree['fruits']
    assert len(some_tree) == 1, 'Empty node does not register key'
    # Set a value
    some_tree['fruits']['banana']['yellow'] = True
    assert some_tree['fruits']['banana']['yellow'] is True, 'Tree does not return value'
    some_tree['fruits']['banana']['yellow'] = False
    assert some_tree['fruits']['banana']['yellow'] is False, 'Tree does not update value'
    # Test a different way of doing the same thing
    some_tree['vegetables']['carrot'] = 'orange'

# Generated at 2022-06-21 22:19:19.318909
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    pass



# Generated at 2022-06-21 22:19:23.723425
# Unit test for function tree
def test_tree():
    """Test function tree"""
    t = tree()
    t['a']['b'] = 'c'
    assert t['a']['b'] == 'c'
    # TODO More



# Generated at 2022-06-21 22:19:24.328147
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()

# Generated at 2022-06-21 22:19:32.427376
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'a:b:c:d:e') is not None
    assert get_tree_node(tree(), 'a:b:c:d:e:f') is not None
    assert get_tree_node(tree(), 'a:') is not None
    assert get_tree_node(tree(), 'a:b:c') is not None
    assert get_tree_node(tree(), 'a:b:c:d:e:f:g') is not None
    assert get_tree_node(tree(), '', default='lol') == 'lol'

    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'

# Generated at 2022-06-21 22:19:40.915745
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, "foo:bar", 'baz')
    assert test_dict['foo']['bar'] == 'baz'
    set_tree_node(test_dict, "foo:baz:bing:dong", 'woop')
    assert test_dict['foo']['baz']['bing']['dong'] == 'woop'
    set_tree_node(test_dict, "foo:baz:bing:bang", 'bong')
    assert test_dict['foo']['baz']['bing']['bang'] == 'bong'
    set_tree_node(test_dict, "foo:baz:bing:woop", 'dang')

# Generated at 2022-06-21 22:19:48.061347
# Unit test for function get_tree_node
def test_get_tree_node():
    _dummy_case = {
        'me': 'you',
        'me:something': 'not you',
        'you': {
            'you:you': 'me'
        }
    }

    assert get_tree_node(_dummy_case, 'me') == 'you'
    assert get_tree_node(_dummy_case, 'me:something') == 'not you'
    assert get_tree_node(_dummy_case, 'you:you') == 'me'
    assert get_tree_node(_dummy_case, 'me:something:not:there') is None



# Generated at 2022-06-21 22:19:53.231835
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class MyRegistryTree(RegistryTree):
        namespace = 'foo'

    tree = MyRegistryTree()
    tree.register('bar', 'baz')
    assert tree.get('foo:bar') == 'baz'



# Generated at 2022-06-21 22:20:05.018243
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Test __setitem__ method of Tree

    Tests whether expected behavior of __setitem__ are being met.
    1. Single dimensional insertion.
    2. Multi-dimensional insertion.
    3. Namespaced, single dimensional insertion.
    4. Namespaced, multi-dimensional insertion.
    """
    mytree = Tree()
    mytree['firstkey'] = 'firstvalue'
    assert mytree['firstkey'] == 'firstvalue'
    mytree['firstkey:secondkey'] = 'secondvalue'
    assert mytree['firstkey:secondkey'] == 'secondvalue'
    namespace = 'namespace'
    mytree.namespace = namespace
    mytree['firstkey'] = 'firstvalue'
    assert mytree['firstkey'] == 'firstvalue'
    mytree['firstkey:secondkey'] = 'secondvalue'
   

# Generated at 2022-06-21 22:20:18.481664
# Unit test for function get_tree_node
def test_get_tree_node():
    import json
    import os
    with open(os.path.join(os.path.dirname(__file__), './config.json')) as f:
        data = json.load(f)
    assert get_tree_node(data, 'setting:key') == 'value'
    assert get_tree_node(data, 'setting:key:more') == 'value'
    # FIXME:  Make this raise KeyError, not None
    assert get_tree_node(data, 'no:path:here') is None
    try:
        get_tree_node(data, 'no:path:here', default=_sentinel)
    except KeyError as exc:
        assert isinstance(exc, KeyError)



# Generated at 2022-06-21 22:20:26.305960
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import inspect
    rt = RegistryTree()
    result = rt['test_tree']
    assert result is rt, \
        "__init__() did not return an instance of RegistryTree."
    assert isinstance(rt, RegistryTree), \
        "__init__() did not create an instance of RegistryTree."
    assert isinstance(result, RegistryTree), \
        "__init__() did not create an instance of RegistryTree."
    assert inspect.isclass(result.__class__), \
        "__init__() did not create an instance of RegistryTree."



# Generated at 2022-06-21 22:20:29.239462
# Unit test for function set_tree_node
def test_set_tree_node():
    thing = tree()
    set_tree_node(thing, 'a:b:c:d', 'Zoo')

    assert thing['a']['b']['c']['d'] == 'Zoo'



# Generated at 2022-06-21 22:20:38.215361
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({})
    assert isinstance(t, Tree)
    assert t.namespace is None
    assert t.data == t.dict
    t.namespace = 'node'
    assert t.namespace == 'node'
    t.update({'foo': 'bar'})
    assert t['foo'] == 'bar'
    assert t['node:foo'] == 'bar'
    t.update({'baz': 'bleh'})
    assert t['baz'] == 'bleh'
    assert t['node:baz'] == 'bleh'



# Generated at 2022-06-21 22:20:40.848316
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert isinstance(rt, RegistryTree)
    assert isinstance(rt, Tree)
    assert isinstance(rt, collections.defaultdict)

# Generated at 2022-06-21 22:20:45.406955
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Test for `Tree.__getitem__`
    """
    collection = Tree(initial={':a': {'b': {'c': 1}}})
    value = collection['a:b:c']
    assert value == 1, '__getitem__ should correctly extract value from tree'



# Generated at 2022-06-21 22:20:53.676852
# Unit test for function get_tree_node
def test_get_tree_node():
    config = Tree({
        'one': {
            'two': {
                'three': 'ok',
            }
        }
    })
    assert get_tree_node(config, 'one:two:three') == 'ok'
    assert get_tree_node(config, 'does-not-exist') == _sentinel
    try:
        get_tree_node(config, 'does-not-exist')
    except KeyError:
        assert True, 'KeyError raised for missing key.'
    assert get_tree_node(config, 'does-not-exist', 'default') == 'default', 'Default value works.'



# Generated at 2022-06-21 22:21:02.885108
# Unit test for constructor of class Tree
def test_Tree():
    # my_tree = Tree()
    # my_tree = Tree({'turtles': 'turtles everywhere'})
    # my_tree = Tree({'turtles': 'turtles everywhere'}, initial_is_ref=True)
    # my_tree = Tree({'turtles': 'turtles everywhere'}, initial_is_ref=True, namespace='turtles')

    # my_tree = Tree()
    my_tree = Tree()
    my_tree.update({'turtles': 'turtles everywhere'})
    # my_tree.update({'turtles': 'turtles everywhere'}, )
    # my_tree.update({'turtles': 'turtles everywhere'}, initial_is_ref=True)
    # my_tree.update({'turtles': 'turtles everywhere'}, initial_is_ref=True, namespace='turtles

# Generated at 2022-06-21 22:21:04.537745
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t[('one', 'two', 'three')] = 'four'
    assert t[('one', 'two', 'three')] == 'four'



# Generated at 2022-06-21 22:21:12.096972
# Unit test for function tree
def test_tree():
    x = tree()
    x[1][2] = 3
    x[1][4] = 5

    assert x[1][2] == 3
    assert x[1][4] == 5
    assert x[1] == {2: 3, 4: 5}

    assert x[1][2] == 3
    assert x[1][3] == {}
    assert x[1][3][2] == {}
    assert x[1][3][2][1] == {}  # o_O
    assert x[1][3][2][1]['foo'] == {}  # o_O
    assert x[1][3][2][1]['foo']['bar'] == {}  # o_O
    assert x[1][3][2][1]['foo']['bar']['baz'] == {}  # o

# Generated at 2022-06-21 22:21:26.258580
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='a')
    t.register('b:c', 1)
    t.register('d:e:f:g', 2)
    assert t == {'b': {'c': 1}, 'd': {'e': {'f': {'g': 2}}}}, t

    t = Tree([('foo', 'bar')])
    t.register('b:c', 1)
    t.register('d:e:f:g', 2)
    assert t == {'b': {'c': 1}, 'd': {'e': {'f': {'g': 2}}}}, t

    t = Tree(initial_is_ref=t)
    t.register('b:c', 1)
    t.register('d:e:f:g', 2)

# Generated at 2022-06-21 22:21:30.828812
# Unit test for function set_tree_node
def test_set_tree_node():
    foo = {}
    set_tree_node(foo, 'a:b:c:d', 'foo bar')
    assert foo == {'a': {'b': {'c': {'d': 'foo bar'}}}}



# Generated at 2022-06-21 22:21:35.735587
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()  # Simple, tree-like dict
    t['foo:bar']['baz'] = 'baz'  # Fetching a node in key : notation - returning a new instance if none found
    assert t['foo:bar']['baz'] == 'baz'  # Retrieving a value by key

    # TODO: Expand test case logic



# Generated at 2022-06-21 22:21:45.646582
# Unit test for constructor of class Tree
def test_Tree():
    """Test that Tree works as expected."""
    t = Tree()
    assert not t
    t.update({'a': {'b': 1}, 'c': {'d': {'e': {'f': {'g': 1}}}}})

    assert t['c']['d']['e']['f']['g'] == 1
    assert re.match(r'{(\'c\': {\'d\': {\'e\': {\'f\': {\'g\': 1}}}},)? \'a\': {\'b\': 1}}', str(t))

    assert t['a']['b'] == 1
    assert t['c']['d']['e']['f']['g'] == 1
    assert t['a'] == {'b': 1}


# Generated at 2022-06-21 22:21:51.647619
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'hello:world:ai:hello', 'there')
    set_tree_node(d, 'hello:world:jh', 'there')
    assert d == {'hello': {'world': {'ai': {'hello': 'there'}, 'jh': 'there'}}}



# Generated at 2022-06-21 22:21:54.138213
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    #
    t['a'] = 'aval'
    assert t['a'] == 'aval'



# Generated at 2022-06-21 22:22:05.197406
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 'foo')
    set_tree_node(t, 'a:d:e', 'bar')
    set_tree_node(t, 'a:b:f', 'baz')
    set_tree_node(t, 'a:b:0:d:e:f:g', 'qux')

# Generated at 2022-06-21 22:22:07.602847
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('foo', 'bar')
    assert tree.get('foo') == 'bar'

# Generated at 2022-06-21 22:22:13.824247
# Unit test for constructor of class Tree
def test_Tree():
    test = tree()
    test['alphafoundation']['foo'] = 'oof'
    t = tree()
    t['foo']['bar'] = 'bar'
    test['alphafoundation']['t'] = t
    t = tree()
    t['foo']['bar'] = 'baz'
    test['alphafoundation']['t1'] = t
    t = tree()
    t['foo']['bar'] = 'baz'
    test['zetafoundation']['t2'] = t

# Generated at 2022-06-21 22:22:22.153290
# Unit test for function tree

# Generated at 2022-06-21 22:22:43.810048
# Unit test for function set_tree_node
def test_set_tree_node():
    m = tree()
    set_tree_node(m, 'some:key:some:more:keys', 'some value')
    set_tree_node(m, 'another:key', 'another value')
    assert m['some']['key']['some']['more']['keys'] == 'some value'
    assert m['another']['key'] == 'another value'



# Generated at 2022-06-21 22:22:45.764822
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'



# Generated at 2022-06-21 22:22:53.308899
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> lolol = {'a': {'b': {'c': 'd'}}}
    >>> get_tree_node(lolol, 'a') == {'b': {'c': 'd'}}
    True
    >>> get_tree_node(lolol, 'a:b') == {'c': 'd'}
    True
    >>> get_tree_node(lolol, 'a:b:c') == 'd'
    True

    """
    pass



# Generated at 2022-06-21 22:23:04.101744
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test use of set_tree_node.
    """
    from pprint import pprint

    mapping = tree()
    set_tree_node(mapping, 'key1', 'value1')
    set_tree_node(mapping, 'key2:subkey1', 'subvalue1')
    set_tree_node(mapping, 'key2:subkey2', 'subvalue2')
    set_tree_node(mapping, 'key3', {'subkey1': 'subvalue1', 'subkey2': 'subvalue2'})
    pprint(mapping)
    print('key1: %s' % mapping['key1'])
    print('key2: %s' % mapping['key2'])

# Generated at 2022-06-21 22:23:08.711583
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 3
    assert t['a'] == 3
    t['a:b'] = 5
    assert t['a:b'] == 5
    t['a:c:d'] = 9
    assert t['a:c:d'] == 9
    assert t['a']['c']['d'] == 9



# Generated at 2022-06-21 22:23:16.793945
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node.
    """
    test_value = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': 'f'
                    }
                }
            }
        }
    }
    tree_test_value = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': 'f'
                    }
                }
            }
        }
    }
    set_tree_node(tree_test_value, 'a:b:c:d:e', 'f')
    assert tree_test_value == test_value



# Generated at 2022-06-21 22:23:20.833809
# Unit test for function tree
def test_tree():
    test_tree = tree()
    test_tree['a'] = 1
    test_tree['b']['a'] = 2

    assert test_tree == {'a': 1, 'b': {'a': 2}}



# Generated at 2022-06-21 22:23:23.791418
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from .constants import JSON_TREE_DATA

    t = RegistryTree(namespace='test', initial=JSON_TREE_DATA)
    assert t['test:foo:bar'] == 42
    assert t['test:some:thing'] == 'value'
    assert t.get('test:foo:nothing', None) is None
    assert t.get('test:foo:nothing', 666) == 666

# Generated at 2022-06-21 22:23:27.889035
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Unit test for module method `Tree.__getitem__`.

    """
    tree = Tree()
    tree['a'] = 1
    assert tree['a'] == 1

    tree['b:x'] = 2
    assert tree['b:x'] == 2



# Generated at 2022-06-21 22:23:38.899086
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'd1'
            },
            'f': 'd2'
        }
    }

    assert get_tree_node(d, 'a:b') == {'c': 'd', 'e': 'd1'}
    assert get_tree_node(d, 'a:b:c', 'default') == 'd'
    assert get_tree_node(d, 'a:b:g', 'default') == 'default'
    assert get_tree_node(d, 'a:b:g') == KeyError
    assert get_tree_node(d, 'a:b') is not d['a']['b']

# Generated at 2022-06-21 22:24:17.988383
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry_tree = RegistryTree(initial={'foo': {'bar': 'baz'}}, namespace='foo')
    assert registry_tree['bar'] == 'baz'

# Generated at 2022-06-21 22:24:20.678872
# Unit test for constructor of class Tree
def test_Tree():
    tr = Tree({'a': 1}, namespace='tr')
    assert tr.get('a') == 1
    assert tr.get('tr:a') == 1



# Generated at 2022-06-21 22:24:32.086140
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import sys
    import inspect
    import unittest

    class Factory1(object):
        pass

    class Factory2(object):
        pass

    class RegistryTestCase(unittest.TestCase):
        def test_factory(self):
            import sys
            import inspect
            self.registry = RegistryTree()
            self.registry.register('test:test', Factory1)
            self.registry.register('test2:test', Factory2)
            self.assertEqual(self.registry.get('test:test'), Factory1)
            self.assertEqual(self.registry.get('test2:test'), Factory2)

    suite = unittest.TestLoader().loadTestsFromTestCase(RegistryTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-21 22:24:35.798666
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data = tree()
    assert not set_tree_node(test_data, 'foo:bar:baz', 'blah')
    assert set_tree_node(test_data, 'foo:bar:baz', 'blah')['baz'] == 'blah'
    assert set_tree_node(test_data, 'foo:bar:baz', 'blah2')['baz'] == 'blah2'



# Generated at 2022-06-21 22:24:43.127438
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 123
    t['a']['g']['h']['i'] = 'abc'
    t['a']['x']['y'] = 'hey'
    assert t['a']['b']['c'] == 123
    assert t['a']['g']['h']['i'] == 'abc'



# Generated at 2022-06-21 22:24:46.908353
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree()
    reg.register('foo.bar', 'baz')
    assert reg['foo.bar'] == 'baz'



# Generated at 2022-06-21 22:24:53.828628
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree[0][0] = 0
    tree[0][1] = 1
    tree[0][2] = 2
    tree[0][3] = 3
    tree[1][0] = 4
    tree[1][1] = 5
    tree[1][2] = 6
    tree[1][3] = 7
    tree[2][0] = 8
    tree[2][1] = 9
    tree[2][2] = 10
    tree[2][3] = 11
    assert tree[0][0] == 0
    assert tree[0][1] == 1
    assert tree[0][2] == 2
    assert tree[0][3] == 3
    assert tree[1][0] == 4
    assert tree[1][1] == 5

# Generated at 2022-06-21 22:24:54.906759
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass



# Generated at 2022-06-21 22:25:06.606979
# Unit test for function tree
def test_tree():
    _tree = Tree()
    _tree['foo']['bar']['baz'] = 'qux'
    assert _tree['foo:bar:baz'] == 'qux'
    assert _tree['foo:bar']['baz'] == 'qux'
    assert _tree['foo']['bar']['baz'] == 'qux'
    _tree['foo:bar']['baz:qux'] = 'quux'
    assert _tree['foo:bar:baz:qux'] == 'quux'
    assert _tree['foo:bar']['baz:qux'] == 'quux'
    assert _tree['foo']['bar:baz:qux'] == 'quux'

# Generated at 2022-06-21 22:25:07.892433
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class TestRegistryTree(RegistryTree):
        pass



# Generated at 2022-06-21 22:26:33.528924
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'foo': {'1': 'bar'}})
    assert t.get('foo:1', 'gimme') == 'bar'
    assert t.get('foo:2', 'gimme') == 'gimme'
    assert t.get('a') is None  # doesn't raise key error



# Generated at 2022-06-21 22:26:42.439212
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'a': {'b': 'c'}, 'b': ['c', 'd']}
    assert get_tree_node(tree, 'a:b') == 'c'
    assert get_tree_node(tree, 'b:0') == 'c'
    assert get_tree_node(tree, 'b', default=()) == ['c', 'd']
    assert get_tree_node(tree, 'b:2', default=()) == ()
    assert get_tree_node(tree, 'b:2', default=None) is None
    assert get_tree_node(tree, 'b:2') is None



# Generated at 2022-06-21 22:26:50.760980
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a:b:c:d:e:f:g:h', 'test') == {'a': {'b': {'c': {'d': {'e': {'f': {'g': {'h': 'test'}}}}}}}}
    assert set_tree_node({'a': {}}, 'a:b:c:d:e:f:g:h', 'test') == {'a': {'b': {'c': {'d': {'e': {'f': {'g': {'h': 'test'}}}}}}}}

# Generated at 2022-06-21 22:26:57.662078
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Test method __setitem__ of class Tree.

    """
    t = Tree()
    t.__setitem__('a.b.c', 1)
    assert t['a']['b']['c'] == 1
    t.__setitem__('a.b.d', 2)
    assert t['a']['b']['d'] == 2
    assert t.get('a.b.d') == 2
    assert t.get('a.b.e', 3) == 3


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:27:08.424596
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tr = Tree()
    assert tr['foo'] == dict()
    tr['foo']['bar'] = 'baz'
    tr['foo:bar'] = 'baz'
    assert tr['foo:bar'] == 'baz'
    assert tr['foo']['bar'] == 'baz'
    tr['foo']['bar']['baz'] = 1
    assert tr['foo:bar:baz'] == 1
    assert tr['foo']['bar']['baz'] == 1
    assert tr['foo:bar:baz:qux'] == dict()
    tr['foo'] = 'bar'
    assert tr['foo'] == 'bar'
    tr['foo:bar'] = 'baz'
    assert tr['foo'] == 'bar'

# Generated at 2022-06-21 22:27:12.569794
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree.update({'a': {'b': {'c': 1, 'd': 2, 'e': 3}}})
    assert tree.get('a:b:c') == 1
    # test_Tree___getitem__()
    pass



# Generated at 2022-06-21 22:27:16.320179
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['this']['is']['a']['test'] = True
    assert t['this']['is']['a']['test'] is True
    assert t['this']['is']['a']['not'] is None



# Generated at 2022-06-21 22:27:19.353135
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 'd'
    t['a']['b']['e'] = 'f'
    t['a']['g']['h'] = 'i'
    print(t)



# Generated at 2022-06-21 22:27:21.172131
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['location:north'] = 'Lothlorien'
    assert tree['location:north'] == 'Lothlorien'



# Generated at 2022-06-21 22:27:27.426606
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a']['b'] = 'c'
    assert t['a']['b'] == 'c'


if __name__ == '__main__':
    test_Tree()