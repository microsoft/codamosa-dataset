

# Generated at 2022-06-21 22:18:02.027553
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={'test': 'hello'}, initial_is_ref=True)
    t.update({'test': 'world'})
    assert t.get('test') == 'world'

# Generated at 2022-06-21 22:18:04.211010
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a']['b'] = 'c'
    assert t.a.b == 'c'



# Generated at 2022-06-21 22:18:06.844152
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Create a Tree instance
    tree = Tree()
    # Register 'value' under 'key'
    tree.register('key', 'value')
    # Check the value is registered under 'key'
    assert tree['key'] == 'value'



# Generated at 2022-06-21 22:18:09.342650
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('some_key', 'some_value')
    assert registry['some_key'] == 'some_value'

# Generated at 2022-06-21 22:18:19.907962
# Unit test for function get_tree_node
def test_get_tree_node():
    tn = collections.OrderedDict()
    tn['a'] = 'A'
    tn['a:b'] = 'AB'
    tn['a:b:c'] = 'ABC'
    tn['a:b:c:d'] = 'ABCD'
    tn['a:b:e'] = 'ABE'
    assert get_tree_node(tn, 'a:b:c:d') == 'ABCD'
    assert get_tree_node(tn, 'a:b:e') == 'ABE'
    assert get_tree_node(tn, 'a:b:c') == 'ABC'
    assert get_tree_node(tn, 'a') == 'A'
    assert get_tree_node(tn, 'a:b:c', default='abcd') == 'ABC'

# Generated at 2022-06-21 22:18:23.685483
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    test_RegistryTree
    """
    r = RegistryTree()
    r.register('test:test', 'Test value')
    assert r['test:test'].value == 'Test value'



# Generated at 2022-06-21 22:18:24.746602
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert Tree()['foo'] == {}



# Generated at 2022-06-21 22:18:29.362402
# Unit test for constructor of class Tree
def test_Tree():
    data = '''\
    foo:
        bar:
            baz:
                quux:
                    hello: world
    '''
    tree = Tree(yaml.safe_load(data))
    assert tree['foo']['bar']['baz']['quux']['hello'] == 'world'



# Generated at 2022-06-21 22:18:40.826893
# Unit test for function get_tree_node
def test_get_tree_node():

    # Test initialization
    # 1. dictionaries
    d = {'test': {'test2': 'test3'}}
    assert get_tree_node(d, 'test:test2') == 'test3'

    # 2. treelike custom object
    class TreeLikeObj(object):
        def __init__(self, dct, name=None):
            self.dct = dct
            self.name = name

        def __getitem__(self, key):
            return self.dct[key]

    t = TreeLikeObj(d)
    assert get_tree_node(t, 'test:test2') == 'test3'

    # Test parent node
    assert get_tree_node(d, 'test:test2', parent=True) == {'test2': 'test3'}

    # Test default

# Generated at 2022-06-21 22:18:48.993763
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    c = tree()
    c['a']['b']['c'] = 1
    c['a']['d'] = 1

    d = Tree()
    d['a']['b']['c'] = 1
    d['a']['d'] = 1

    assert get_tree_node(c, 'a') == {'d': 1, 'b': {'c': 1}}
    assert get_tree_node(c, 'a:b') == {'c': 1}
    assert get_tree_node(c, 'a:b:c') == 1
    assert get_tree_node(c, 'a:d') == 1
    assert get_tree_node(c, 'a:e', 'bar') == 'bar'

# Generated at 2022-06-21 22:18:53.902912
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert isinstance(rt, RegistryTree) is True

# Unit test to verify that RegistryTree uses default namespace

# Generated at 2022-06-21 22:18:59.903739
# Unit test for function tree
def test_tree():
    t = tree()
    assert t['foo']['bar']['baz'] == {}
    assert t['foo']['bar']['baz']['blah'] == {}
    assert t['foo']['bar']['baz']['blah'] == {}
    # assert t['foo']['biz']['baz']['blah'] == {}



# Generated at 2022-06-21 22:19:11.709151
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'foo': {'bar': 'baz'}})
    assert tree['foo'] == {'bar': 'baz'}
    assert tree['foo:bar'] == 'baz'
    assert tree.get('foo:bar') == 'baz'
    assert tree['foo:bar2'] is None
    assert tree['foo:bar3'] is None
    assert tree.get('foo:bar3') is None
    # Get default
    assert tree.get('foo:bar3', 'bar') == 'bar'
    # Raise KeyError
    with pytest.raises(KeyError):
        assert tree['foo:bar3'] == 'bar'

    # Get a node
    assert tree.get('foo:bar', node=True) == {'bar': 'baz'}

# Generated at 2022-06-21 22:19:15.895606
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    a = Tree()
    a['a'] = {'a': '1'}
    a['a:a'] = '1'
    a['a:a:a'] = '1'
    a.setdefault('a:a:a', '2')
    print(a)

# Generated at 2022-06-21 22:19:23.429059
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'a') == {}  # No contents, no cry.
    assert get_tree_node(tree(), 'top:left:middle:bottom') == {}
    assert get_tree_node(tree(), 'top:left:middle:right') == {}
    nested = tree()
    nested['left'] = tree()
    nested['left']['middle'] = tree()
    nested['left']['middle']['bottom'] = 'value'
    assert get_tree_node(nested, 'top:left:middle:bottom') == {}
    assert get_tree_node(nested, 'left:middle:bottom') == 'value'
    assert get_tree_node(nested, 'left:middle') == {'bottom': 'value'}

# Generated at 2022-06-21 22:19:31.182041
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'foo': {
            'bar': 'baz'
        }
    }

    assert get_tree_node(test_mapping, 'foo') == {'bar': 'baz'}
    assert get_tree_node(test_mapping, 'foo:bar') == 'baz'
    assert get_tree_node(test_mapping, 'foo:bar:baz') == {}
    assert get_tree_node(test_mapping, 'foo:bar:baz:kazoo', default=1) == 1
    assert get_tree_node(test_mapping, 'foo:bar:baz:kazoo', parent=True) == {}



# Generated at 2022-06-21 22:19:36.585188
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = dict(
        a=dict(
            b=dict(
                c=dict(
                    d=dict(
                        e=5,
                    ),
                ),
            ),
        ),
    )
    assert get_tree_node(mapping, 'a:b') == {'c': {'d': {'e': 5}}}
    assert get_tree_node(mapping, 'a:b:c') == {'d': {'e': 5}}
    assert get_tree_node(mapping, 'a:b:c:d') == {'e': 5}

# Generated at 2022-06-21 22:19:45.165723
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from copy import deepcopy

    test_dict = {
        'a': {
            'b': {
                'c': 'd',
            }
        }
    }
    test_keys = [
        # key, value, expected
        ('a:b:c', 'd', None),
        ('a:b:d', 'e', None),
        ('a:b', 'e', test_dict)
    ]
    for key, value, expected in test_keys:
        test_result = deepcopy(test_dict)
        set_tree_node(test_result, key, value)
        if expected is not None and test_result == expected:
            continue
        assert test_result == expected



# Generated at 2022-06-21 22:19:47.508435
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class SomeClass(object):
        def __init__(self):
            self.registry = RegistryTree()

    c = SomeClass()
    c.registry.register('foo:bar:baz', 'spam')
    assert c.registry.get('foo:bar:baz') == 'spam'
    assert c.registry['foo:bar:baz'] == 'spam'

# Generated at 2022-06-21 22:19:58.218391
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        'node_1': {
            'node_1_1': {
                'node_1_1_1': None
            },
            'node_1_2': None
        },
        'node_2': {
            'node_1_1': {
                'node_1_1_1': None
            },
            'node_1_2': None
        },
    }
    set_tree_node(mapping, 'node_1:node_1_2', 'Hello world')
    assert mapping['node_1']['node_1_2'] == 'Hello world'



# Generated at 2022-06-21 22:20:06.950477
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Unit test for method __getitem__ of class Tree."""
    # Create instance at random
    foo = Tree()
    # Try to retrieve value at key that does not exist
    assert foo['foo'] == foo
    # Assign a value to key
    foo['foo'] = 'bar'
    # Check that value was properly returned
    assert foo['foo'] == 'bar'



# Generated at 2022-06-21 22:20:15.272282
# Unit test for function set_tree_node
def test_set_tree_node():
    node = {
        'spam': {
            'egg': 1,
            'frying': 2
        },
        'meat': {
            'spam': {
                'egg': 1,
                'frying': 2
            }
        }
    }
    set_tree_node(node, 'spam:egg', 3)
    set_tree_node(node, ':spam', 3)
    set_tree_node(node, 'meat:spam', 3)
    assert node == {
        'spam': 3,
        'meat': {
            'spam': 3
        }
    }



# Generated at 2022-06-21 22:20:22.616813
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='test')
    t.register('test', 'test')
    assert t == {'test': {'test': 'test'}}
    assert t.get('test') == 'test'
    assert t.get('test:test') == 'test'
    assert t.get('doesnotexist') is _sentinel

    t['doesexist'] = 'test2'
    assert t['doesexist'] == 'test2'
    assert t['test:doesexist'] == 'test2'



# Generated at 2022-06-21 22:20:24.468083
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree().namespace == ''
    assert Tree(namespace='foo').namespace == 'foo'



# Generated at 2022-06-21 22:20:31.933923
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': 'bar',
        'baz': {
            'bat': 'bam'
        },
        'quux': {
            'bang': 'boom'
        }
    }

    assert get_tree_node(data, 'foo') == 'bar'
    assert get_tree_node(data, 'baz:bat') == 'bam'
    assert get_tree_node(data, 'baz:bat:') is None
    assert get_tree_node(data, 'baz:bat:', default='nope') == 'nope'

    with pytest.raises(KeyError):
        get_tree_node(data, 'baz:bat:')

# Generated at 2022-06-21 22:20:34.625624
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'foo': 'bar'})
    assert t['foo'] == t.get('foo') == t.getitem('foo') == 'bar'



# Generated at 2022-06-21 22:20:40.473334
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():

    tree = Tree(initial={'foo': {'bar': {'baz': 'baf'}}})

    assert tree['foo:bar:baz'] == 'baf', 'Failed to get.'

    try:
        tree['foo:bar:baf']
        assert False, 'Failed to raise KeyError.'
    except KeyError:
        pass

    assert tree.get('foo:bar:baf') == 0, 'Failed to get default value.'

# Generated at 2022-06-21 22:20:46.912149
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():

    tree = Tree()
    tree['a'] = 1
    tree['b'] = 2
    tree['a:b'] = 3
    tree['a:b:c'] = 4
    assert tree['a'] == 1
    assert tree['a:b'] == 3
    assert tree['a:b:c'] == 4
    assert tree['a:b:d'] == {}


if __name__ == '__main__':
    test_Tree___getitem__()

# Generated at 2022-06-21 22:20:49.450359
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={'foo': 'bar'})
    assert t['foo'] == 'bar'



# Generated at 2022-06-21 22:20:54.675240
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    Unit test for class RegistryTree.

    Shows how to use it.

    """
    tree = RegistryTree()

    tree.register('foo:bar', 'BAR!')
    tree.register('foo:command', 'COMMAND!')

    assert 'BAR!' == tree.get('foo:bar')
    assert 'COMMAND!' == tree.get('foo:command')

    assert 'BAR!' == tree['foo:bar']
    assert 'COMMAND!' == tree['foo:command']

# Generated at 2022-06-21 22:21:03.085573
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert get_tree_node(dict(foo=dict(bar=dict(baz=1))), 'foo:bar:baz') == 1

# Generated at 2022-06-21 22:21:11.773446
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b'] = 1
    t['a']['c'] = 2
    t['d']['e'] = 3
    t['f']['g']['h']['i'] = 4
    assert t['a']['b'] == 1
    assert t['a']['c'] == 2
    assert t['d']['e'] == 3
    assert t['f']['g']['h']['i'] == 4
    t['f']['g']['h']['i'] = 5
    assert t['f']['g']['h']['i'] == 5

# Generated at 2022-06-21 22:21:21.518400
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:c', default='e') == 'd'
    assert get_tree_node(mapping, 'a:b:d', default='e') == 'e'
    assert get_tree_node(mapping, 'a:b:c', parent=True) == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d', default='e') == 'e'

# Generated at 2022-06-21 22:21:27.090330
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    obj = Tree(namespace='foo')
    obj.__setitem__('key', 'value')
    assert obj['foo:key'] == 'value', "Failed to set a tuple-like key with namespace."
    obj.__setitem__('key', 'value', namespace='bar')
    assert obj['bar:key'] == 'value', "Failed to set a tuple-like key overriding namespace."
    obj.__setitem__('spam:key', 'value')
    assert \
        obj['foo:spam:key'] == 'value', "Failed to set a tuple-like key with extended namespace."
    obj.__setitem__('spam:key', 'value', namespace='bar')

# Generated at 2022-06-21 22:21:31.984862
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for RegistryTree."""
    rt = RegistryTree()
    assert rt.namespace is None
    assert rt.data is None
    rt = RegistryTree(namespace='lol', initial={'foo': 'bar'})
    assert rt['lol:foo'] == 'bar'

# Generated at 2022-06-21 22:21:35.308517
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    test_registry = RegistryTree()
    test_registry.register(['foo', 'bar', 'baz'], 'foobarbaz')
    assert test_registry['foo:bar:baz'] == 'foobarbaz'



# Generated at 2022-06-21 22:21:45.288836
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 1
            }
        }
    }
    assert get_tree_node(mapping, 'a') == {'b': {'c': 1}}
    assert get_tree_node(mapping, 'a:b:c') == 1
    assert get_tree_node(mapping, 'a:b', parent=True) == {'c': 1}

    mapping['a']['b']['c'] = {
        'x': {
            'y': {
                'z': 2
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c:x:y:z') == 2


# Generated at 2022-06-21 22:21:57.036371
# Unit test for function tree
def test_tree():
    t = tree()
    assert t['bacon']['lettuce']['tomato']['ketchup'] == tree()
    assert t['bacon']['lettuce']['tomato']['ketchup'] is t['bacon']['lettuce']['tomato']['ketchup']
    t['bacon']['lettuce']['tomato']['ketchup'] = 123
    assert t['bacon']['lettuce']['tomato']['ketchup'] == 123
    t['bacon:lettuce']['tomato']['ketchup'] = 456
    assert t['bacon']['lettuce']['tomato']['ketchup'] == 456

# Generated at 2022-06-21 22:22:09.184813
# Unit test for function get_tree_node
def test_get_tree_node():
    import pytest
    with pytest.raises(KeyError) as excinfo:
        get_tree_node({}, 'a')
    assert excinfo.value.message == "'a'"

    with pytest.raises(KeyError) as excinfo:
        get_tree_node({'a': {}}, 'a:b')
    assert excinfo.value.message == "'b'"

    # full
    assert get_tree_node({'a': {}}, 'a') == {}
    assert get_tree_node({'a': {'b': 1}}, 'a') == {'b': 1}
    assert get_tree_node({'a': {'b': 1}}, 'a:b') == 1

    # parent

# Generated at 2022-06-21 22:22:14.077410
# Unit test for function get_tree_node
def test_get_tree_node():
    # Construct a mock mapping
    test_mapping = tree()
    test_mapping['foo']['bar']['baz'] = 'qux'
    assert get_tree_node(test_mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(test_mapping, 'foo')['bar']['baz'] == 'qux'



# Generated at 2022-06-21 22:22:18.459542
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    assert hasattr(RegistryTree(), 'namespace')



# Generated at 2022-06-21 22:22:26.918762
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'foo', 1) == {'foo': 1}
    assert set_tree_node({}, 'bar:baz', 2) == {'bar': {'baz': 2}}
    assert set_tree_node({'bar': {}}, 'bar:baz', 2) == {'bar': {'baz': 2}}
    assert set_tree_node({'bar': {}}, 'bar:baz', 2) == {'bar': {'baz': 2}}
    assert set_tree_node({'qux': {'bar': {}}}, 'qux:bar:baz', 2) == {'qux': {'bar': {'baz': 2}}}
    return True



# Generated at 2022-06-21 22:22:30.236964
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class Foo(RegistryTree):
        namespace = 'test'

    assert Foo['foo'] == Foo['test:foo'] == Foo.get('foo', default='blah')

    Foo.register('bar', 'bleh')

    assert Foo.bar == 'bleh'



# Generated at 2022-06-21 22:22:35.371888
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('test:18', 'hello')
    assert rt['test:18'] == 'hello'

    rt = RegistryTree()
    rt.register('test:18', 'hello')
    assert 'hello' == rt['test:18']

# Generated at 2022-06-21 22:22:38.535236
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from nose.tools import assert_equals

    tree = Tree()
    tree['hello:world'] = '42'
    assert_equals(tree['hello:world'], '42')



# Generated at 2022-06-21 22:22:43.110305
# Unit test for function tree
def test_tree():

    # Create tree
    tree = Tree()

    # Set keys in different dimensions
    tree['a:d'] = 1
    tree['a:e:f'] = 2
    tree['b:c:d'] = 3

    # Test they are indeed set
    assert tree['a:d'] == 1
    assert tree['a:e:f'] == 2
    assert tree['b:c:d'] == 3



# Generated at 2022-06-21 22:22:47.657441
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()

    def foo():
        pass

    rt.register('spam', foo)
    rt.register('spam:spam', foo)


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 22:22:50.630438
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert Tree(
        initial={'a': {'b': 'c'}},
        namespace='abc'
    )['b'] == 'c'



# Generated at 2022-06-21 22:22:54.482199
# Unit test for function set_tree_node
def test_set_tree_node():
    """ Unit test for function set_tree_node """
    mapping = {}

    key = 'foo:bar:boo'
    value = 'bla'

    set_tree_node(mapping, key, value)

    assert mapping['foo']['bar']['boo'] == 'bla'



# Generated at 2022-06-21 22:22:59.716724
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    submapping = tree()
    set_tree_node(mapping, 'subtree:subsubtree', submapping)
    set_tree_node(mapping, 'subtree:subsubtree:hey', 'ho')
    assert mapping['subtree']['subsubtree']['hey'] == 'ho'



# Generated at 2022-06-21 22:23:06.916553
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    assert set_tree_node(data, 'items', {'item1': 'value1'}) == data
    assert data['items'] == {'item1': 'value1'}
    assert set_tree_node(data, 'items:item1:item2', 'value2') == data['items']



# Generated at 2022-06-21 22:23:09.140656
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'foo:bar', 'baz')
    assert t['foo']['bar'] == 'baz'

# Generated at 2022-06-21 22:23:15.353594
# Unit test for function set_tree_node
def test_set_tree_node():
    my_dict = dict()
    set_tree_node(my_dict, 'foo:bar', 'baz')
    assert my_dict == {'foo': {'bar': 'baz'}}
    set_tree_node(my_dict, 'child:child2', 'child2_leaf')
    assert my_dict == {'foo': {'bar': 'baz'}, 'child': {'child2': 'child2_leaf'}}



# Generated at 2022-06-21 22:23:18.009861
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    for data in tree:
        tree[data]
    del tree



# Generated at 2022-06-21 22:23:28.306976
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert rt['a'] == {}
    rt2 = RegistryTree(rt)
    assert rt2['a'] == {}
    rt3 = RegistryTree(rt, 'a')
    assert rt3['b'] == {}
    rt4 = RegistryTree(rt2, 'a')
    assert rt4['b'] == {}
    assert rt['a'] == {}
    assert rt2['a'] == {}
    assert rt3['b'] == {}
    assert rt4['b'] == {}
    assert_raises(KeyError, rt.__getitem__, 'a:b')
    assert_raises(KeyError, rt2.__getitem__, 'a:b')

# Generated at 2022-06-21 22:23:35.018244
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data = {}
    set_tree_node(test_data, 'foo:bar:far', 'spam')
    assert test_data == {'foo': {'bar': {'far': 'spam'}}}
    set_tree_node(test_data, 'foo:foo:far', 'spam')
    assert test_data == {'foo': {'bar': {'far': 'spam'}, 'foo': {'far': 'spam'}}}



# Generated at 2022-06-21 22:23:41.541185
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    obj = Tree()

    def run(result, expected, input, message):
        obj._namespace_key = lambda x: x
        result = obj.__getitem__(input)
        assert result == expected, message

    run('foo', 'foo', 'foo', 'Simple')
    run('foo:bar', 'foo:bar', 'foo:bar', 'Compound with namespace')
    run('bar', 'bar', 'bar', 'Compound with no namespace')



# Generated at 2022-06-21 22:23:43.727180
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['hello.world'] = 'hello, world'

    assert tree['hello']['world'] == 'hello, world'



# Generated at 2022-06-21 22:23:47.987265
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Tree: Get item via namespace-prefixed key
    """
    tree = Tree(namespace='core')
    tree['core:foo'] = 'bar'
    assert tree['core:foo'] == 'bar'
    return True



# Generated at 2022-06-21 22:23:50.112906
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(initial={'foo:bar': 'baz'})
    assert tree['foo:bar'] == 'baz'



# Generated at 2022-06-21 22:23:59.179216
# Unit test for constructor of class Tree
def test_Tree():
    import json
    t = Tree({'namespace': 'myapp'})
    assert t['namespace'] == 'myapp'
    # Test namespace prefix
    assert t['settings:key'] is None

# Generated at 2022-06-21 22:24:07.003501
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    obj = Tree(initial_is_ref=True)
    data = {'foo': {'bar': {'baz': 'biz'}}}
    obj.data = data
    assert obj.get('foo') == {'bar': {'baz': 'biz'}}
    assert obj.get('foo:bar') == {'baz': 'biz'}
    assert obj.get('foo:bar:baz') == 'biz'



# Generated at 2022-06-21 22:24:09.683065
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(initial={1: 2}, namespace='f')
    assert rt.namespace is 'f'
    assert rt[1] is 2



# Generated at 2022-06-21 22:24:17.713947
# Unit test for function tree
def test_tree():
    from pprint import pprint
    t = tree()
    t[1][2][3] = 'hello, world!'
    t[1][2][4] = 'hello, world!'
    t[1][1][3] = 'hello, world!'
    t[1][1][4] = 'hello, world!'
    t[2][2][3] = 'hello, world!'
    t[2][1][3] = 'hello, world!'
    t[2][1][4] = 'hello, world!'
    t[2][2][4] = 'hello, world!'
    pprint(dumps(t))



# Generated at 2022-06-21 22:24:19.238798
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'hello:there:world', 123)
    assert mapping['hello']['there']['world'] == 123



# Generated at 2022-06-21 22:24:26.124370
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    root = RegistryTree()
    root.register('alice:bob', 1)
    assert root.get('alice:bob') == 1

    root.register('alice:bob2', 2, namespace='alice')
    assert root.get('alice:bob2') == 2

    root.register('alice:bob3', value=3, namespace='alice')
    assert root.get('alice:bob3') == 3

    root.register('alice:bob4', value=4, namespace='alice:bob4')
    assert root.get('alice:bob4:bob4') == 4

    with pytest.raises(KeyError):
        root.get('alice:bob3:bob3')



# Generated at 2022-06-21 22:24:31.755020
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    value = 1
    key = 'foo'
    namespace = 'bar'
    expected = tree._namespace_key(key, namespace=namespace)
    tree.register(key, value, namespace=namespace)
    assert expected in tree and tree[expected] == value



# Generated at 2022-06-21 22:24:34.459555
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree({'test': 'test'})
    tree.set_tree_node('test', 'test')



# Generated at 2022-06-21 22:24:44.169068
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree_data = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': {
                'g': 'h',
            },
        },
    }
    assert get_tree_node(tree_data, 'c:f:g') == 'h'
    assert get_tree_node(tree_data, 'c:f:g') == tree_data['c']['f']['g']
    assert get_tree_node(tree_data, 'c:f') == {'g': 'h'}
    assert get_tree_node(tree_data, 'c:f') == tree_data['c']['f']
    assert get_tree_node(tree_data, 'c:f:z', default=None) is None

# Generated at 2022-06-21 22:24:51.576196
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    rt = RegistryTree(namespace='foo')
    rt['baz'] = {
        'a': {
            '1': 2,
            '2': 3
        }
    }
    try:
        rt['baz:a:1'] = 20
    except Exception as exc:
        pytest.fail("Error while registering: %s" % exc)
    assert rt['baz:a:1'] == 20
    assert rt['foo:baz:a:1'] == 20

test_Tree___setitem__()



# Generated at 2022-06-21 22:25:01.705671
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    m = tree()
    m['a']['b']['c'] = 'd'
    assert get_tree_node(m, 'a:b:c') == 'd'
    assert get_tree_node(m, 'a:b:c:d') is None



# Generated at 2022-06-21 22:25:06.879394
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree(namespace='foo')
    t['bar'] = 'baz'
    assert t['bar'] == 'baz'
    assert t.get('bar') == 'baz'
    assert t.get('bar:foo') == 'baz'
    assert t.get('bar:foo:baz') is None



# Generated at 2022-06-21 22:25:11.426330
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(initial={'b': 1}, initial_is_ref=False)
    tree.register('c', 2)
    assert tree == {'b': 1, 'c': 2}
    assert tree.get('b') == 1
    assert tree.get('c') == 2
    assert tree.get('b', 'd') == 'd'

if __name__ == '__main__':
    import sys
    test_RegistryTree()
    # TODO  Run tests

# Generated at 2022-06-21 22:25:16.774970
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree()
    assert reg['wow'] is None
    assert reg['such:cool'] is None
    assert reg['wow:many:levels'] is None

    reg['such:cool'] = 7
    reg['wow:many:levels'] = 8
    reg.register('wow:many:levels', 12)
    assert reg['wow'] == {'many': {'levels': 12}}

# Generated at 2022-06-21 22:25:18.681526
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('foo', 'bar')
    assert rt['foo'] == 'bar', 'Should have registered foo to bar'

# Generated at 2022-06-21 22:25:19.716554
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    pass



# Generated at 2022-06-21 22:25:25.806947
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import pytest
    t = Tree(initial={'one': {'two': {'three': 'four'}}})
    assert 'four' == t['one:two:three']
    with pytest.raises(KeyError):
        t['one:two:three:four']

# Generated at 2022-06-21 22:25:36.257926
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'a': {'b': {'c': 'd'}}})
    # print(t['a:b:c'])
    assert t['a:b:c'] == 'd'
    # print(t['a::c'])
    assert t['a::c'] == 'd'
    # print(t['a:::c'])
    assert t['a:::c'] == 'd'
    # print(t['a:::c:f:g:i:j'])
    assert t['a:::c:f:g:i:j'] == {}
    # print(t['c'])
    assert t['c'] == {}



# Generated at 2022-06-21 22:25:44.050559
# Unit test for function get_tree_node
def test_get_tree_node():
    assert_equals(get_tree_node({'one': 'two'}, 'one'), 'two')
    assert_equals(get_tree_node({'one': {'two': 'three'}}, 'one:two'), 'three')

    # Try a list traversal
    assert_equals(get_tree_node({'one': [{'two': 'three'}]}, 'one:0:two'), 'three')

    # Make sure you can specify not to delve down so deep
    assert_equals(get_tree_node({'one': {'two': 'three'}}, 'one:two', parent=True), {'two': 'three'})

    # Try a list traversal

# Generated at 2022-06-21 22:25:51.588522
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'one': 'one',
        'two': {
            'one': 'two:one',
            'two': {
                'one': 'two:two:one'
            }
        }
    }

    assert get_tree_node(tree, 'one') == 'one'
    assert get_tree_node(tree, 'two:one') == 'two:one'
    assert get_tree_node(tree, 'two:two:one') == 'two:two:one'



# Generated at 2022-06-21 22:26:04.057205
# Unit test for function tree
def test_tree():
    tree_ = tree()
    assert tree_ == {}
    assert tree_['one'] == {}
    assert tree_['one']['two'] == {}
    assert tree_['one']['three'] == {}
    assert tree_['one']['two'] == {}
    assert tree_['one']['two']['four'] == {}



# Generated at 2022-06-21 22:26:11.796293
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for :func:`get_tree_node`
    """
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:') is _sentinel
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:', default=None) is None

    raises(KeyError, lambda: get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:'))


# Generated at 2022-06-21 22:26:13.553742
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    '''
    Test the method `__setitem__` of class `Tree`
    '''
    pass



# Generated at 2022-06-21 22:26:17.140176
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({
        'foo': {
            'baz': 'bat'
            }
        })
    assert t == {'foo': {'baz': 'bat'}}



# Generated at 2022-06-21 22:26:19.107410
# Unit test for constructor of class Tree
def test_Tree():
    test_t = Tree(initial_is_ref=True, initial={'hello': 1})
    assert test_t['hello'] == 1



# Generated at 2022-06-21 22:26:22.764601
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree(initial={'name': 'a', 'size': 42},
             initial_is_ref=False,
             namespace='a')
    assert a == {'name': 'a', 'size': 42}



# Generated at 2022-06-21 22:26:28.480622
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    assert data == {}
    set_tree_node(data, 'one:two', 'value')
    assert data == {'one': {'two': 'value'}}
    set_tree_node(data, 'one:three', 'value')
    assert data == {'one': {'two': 'value', 'three': 'value'}}
    set_tree_node(data, 'four:one:two:three', 'value')
    assert data == {'four': {'one': {'two': {'three': 'value'}}}}



# Generated at 2022-06-21 22:26:30.363945
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({"foo": "bar"})
    assert t.get("foo") == "bar"



# Generated at 2022-06-21 22:26:40.978242
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'point1': 'treehouse',
        'point2': {
            'subpoint1': 'subtreehouse',
            'subpoint2': 'subbasement'
        },
        'point3': {
            'subpoint0': {
                'subsubpoint1': 'subbasement',
                'subsubpoint2': 'subbasement',
            }
        },
    }

    assert get_tree_node(mapping, 'point1') == 'treehouse'
    assert get_tree_node(mapping, 'point2:subpoint1') == 'subtreehouse'
    assert get_tree_node(mapping, 'point3:subpoint0:subsubpoint1', None) is None
    assert get_tree_node(mapping, 'point3:subpoint0:subsubpoint1')

# Generated at 2022-06-21 22:26:48.573120
# Unit test for function get_tree_node
def test_get_tree_node():

    mapping = {'a': {'b': 'c'}}
    assert get_tree_node(mapping, 'a:b') == 'c'

    mapping = {'a': {'b': 'c'}}
    assert get_tree_node(mapping, 'a:c') is _sentinel

    mapping = {'a': {'b': 'c'}}
    assert get_tree_node(mapping, 'a:c', default='fallback') == 'fallback'

    with pytest.raises(KeyError):
        mapping = {'a': {'b': 'c'}}
        get_tree_node(mapping, 'a:c')



# Generated at 2022-06-21 22:27:04.166078
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    global RegistryTree
    RegistryTree = RegistryTree(None, namespace='something')



# Generated at 2022-06-21 22:27:06.081353
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert callable(rt)
    assert isinstance(rt, Tree)
    assert isinstance(rt, RegistryTree)

# Generated at 2022-06-21 22:27:09.168237
# Unit test for function set_tree_node
def test_set_tree_node():
    dst = {}
    set_tree_node(dst, 'foo', 'bar')
    assert dst == {'foo': 'bar'}



# Generated at 2022-06-21 22:27:13.076837
# Unit test for constructor of class Tree
def test_Tree():
    pytest.skip()
    tree = Tree(initial=dict(foo='bar', bar='foo'), initial_is_ref=True)
    assert tree['foo'] == 'bar'
    assert tree['bar'] == 'foo'



# Generated at 2022-06-21 22:27:16.783610
# Unit test for function tree
def test_tree():
    tree = {}
    for i in range(100):
        set_tree_node(tree, 'foo:bar:%s' % i, i)

    counter = 0
    for i in range(100):
        assert tree['foo:bar:%s' % i] == counter
        counter += 1



# Generated at 2022-06-21 22:27:20.560916
# Unit test for function tree
def test_tree():
    for i in range(10000):
        some_tree = tree()
        some_tree['this']['is']['a']['test']['end'] = '!'
        assert some_tree['this']['is']['a']['test']['end'] == '!'


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-21 22:27:22.573463
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    a['a:b'] = 'c'
    set_tree_node(a, 'a:b', 'd')
    assert a['a'] == {'b': 'd'}



# Generated at 2022-06-21 22:27:33.906185
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()

    assert len(rt) is 0

    # Test that setting and getting works
    rt['foo'] = 'bar'
    assert rt['foo'] is 'bar'

    # Test that setting and getting works recursively
    rt['a:b:c'] = 'd'
    assert rt['a:b:c'] is 'd'

    # Test that getting an undefined key with no value defaults to None
    assert rt['undefined'] is None

    # Test that getting an undefined key with a value
    assert rt['undefined', 1] is 1

    # Test that setting an element, then retrieving it from a child does not
    # error
    rt['a'] = tree()
    assert rt['a:b'] is None

    # Test that a namespace can be specified, and that it

# Generated at 2022-06-21 22:27:44.198925
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    assert tree['some:key'] == {}
    assert tree['some:key'] == tree.__setitem__('some:key', 'some:value')
    assert tree['some:key'] == 'some:value'


if __name__ == '__main__':
    import argparse
    argparser = argparse.ArgumentParser()
    argparser.add_argument('tests', nargs='*')
    argparser.add_argument('--test', action='store_true', default=False)

    args = argparser.parse_args()

    params = dict()
    for k, v in vars(args).items():
        if k != 'tests' or (k == 'tests' and v):
            params[k] = v

# Generated at 2022-06-21 22:27:48.631342
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({
        'a': 'b',
        'c': {
            'd': 'e',
            'f': 'g',
        },
    })
    assert t['a'] == 'b'
    assert t['c:d'] == 'e'
    assert t['c:f'] == 'g'

