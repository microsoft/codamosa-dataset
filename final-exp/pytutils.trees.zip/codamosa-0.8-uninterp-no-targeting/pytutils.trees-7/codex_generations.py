

# Generated at 2022-06-21 22:18:06.194448
# Unit test for function tree
def test_tree():
    """Utility function for testing tree."""
    data = tree()
    data['a']['b']['c'] = 'd'
    data['a']['b']['e'] = 'd'
    assert data['a']['b']['c'] is 'd'

    data = tree()
    data['a']['e'] = 'd'
    data['a']['b']['c'] = 'd'
    assert data['a']['e'] is 'd'
    assert data['a']['b']['c'] is 'd'



# Generated at 2022-06-21 22:18:13.185326
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    d = Tree({'root': {'sub': {'subsub': {'subsubsub': 123}}}})
    d['test:test:test:test'] = 555
    assert d['test:test:test:test'] == 555
    assert d['test']['test']['test']['test'] == 555
    assert d.namespace is None
    d.namespace = 'test'
    assert d['test:test:test:test'] == 555
    assert d['test']['test']['test']['test'] == 555



# Generated at 2022-06-21 22:18:15.627505
# Unit test for function set_tree_node
def test_set_tree_node():
    test = tree()
    set_tree_node(test, 'foo:bar:baz', 'test')
    assert test['foo']['bar']['baz'] == 'test'



# Generated at 2022-06-21 22:18:20.199517
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': 'A'})
    assert t['a'] == 'A'

    t = Tree({'a': 'A'}, namespace='test')
    assert t['a'] == 'A'
    assert t['test:a'] == 'A'



# Generated at 2022-06-21 22:18:21.178278
# Unit test for function get_tree_node
def test_get_tree_node():
    raise NotImplementedError



# Generated at 2022-06-21 22:18:25.835910
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['a'] = 'A'
    assert tree['a'] == 'A'
    assert tree['b'] == {}
    assert tree['c:d'] == {}

    assert tree.get('c:d') == {}



# Generated at 2022-06-21 22:18:37.092639
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Build mock object
    mock_tree = tree()
    mock_tree['a:b'] = 'c'
    mock_tree['a:d:e'] = 'f'
    mock_tree['a:g:h'] = 'i'
    mock_tree['k'] = 'l'
    mock_tree['m:n'] = 'o:p'

    # Test individual values; we don't really need a test for this one

# Generated at 2022-06-21 22:18:46.434921
# Unit test for function set_tree_node
def test_set_tree_node():
    from databrew import Tree
    t = Tree()
    set_tree_node(t, 'bar:baz', 42)
    assert t['bar']['baz'] == 42
    set_tree_node(t, 'baz:baz', 100)
    assert t['baz']['baz'] == 100
    t = {}
    set_tree_node(t, 'bar:baz', 42)
    assert t['bar']['baz'] == 42
    set_tree_node(t, 'baz:baz', 100)
    assert t['baz']['baz'] == 100
    t = collections.defaultdict(dict)
    set_tree_node(t, 'bar:baz', 42)
    assert t['bar']['baz'] == 42
    set_tree_

# Generated at 2022-06-21 22:18:49.467024
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Test case demonstrating the use of method `__setitem__` of module :mod:`py_config.tree`"""
    tree_instance = Tree()
    tree_instance['foo'] = 'bar'
    assert tree_instance['foo'] == 'bar'

# Generated at 2022-06-21 22:18:55.129796
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    set_tree_node(a, 'a:b:c:d', 'Shazam!')
    assert a == {
        'a': {
            'b': {
                'c': {
                    'd': 'Shazam!'
                }
            }
        }
    }


# Generated at 2022-06-21 22:19:04.253141
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    t['foo'] = 'bar'
    assert t['foo'] == 'bar'

    t['foo:bar'] = 'baz'
    assert t['foo'] == {'bar': 'baz'}

    t.update({
        'a': 1,
        'b': 2,
        'c': {
            'd': 4,
        },
    })

    for key, value in t.items():
        print(key, value)



# Generated at 2022-06-21 22:19:09.455579
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(collections.defaultdict)
    # tree['one']['two']['three'] = 'four'
    set_tree_node(tree, 'one:two:three', 'four')
    assert tree['one']['two']['three'] == 'four'



# Generated at 2022-06-21 22:19:20.591033
# Unit test for function tree
def test_tree():
    # Simple test for function tree.
    t = tree()
    t['a']['b']['c'] = 1
    t['a']['b']['d'] = 2
    t['a']['e'] = 3
    assert t.a.b.c == 1
    assert t['a:b:c'] == 1
    assert t['a:b:d'] == 2
    assert t['a:e'] == 3

    # Test namespace
    n = tree(namespace='test')
    assert n == {'test': collections.defaultdict(tree, {})}
    n.test.a = 1
    assert n.test.a == 1
    n.test.b = 2
    assert n.test.b == 2

# Generated at 2022-06-21 22:19:30.958953
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={
        'a': {
            'b': {
                'c': {
                    'd': 1,
                }
            }
        },
        'e': 2
    })

    # Test plain access
    assert t['a']['b']['c']['d'] == 1
    assert t['e'] == 2

    # Test implicit dimensions
    assert t['a']['b']['c']['f'] == Tree()

    # Test nested class access with namespace
    assert t.get('e', namespace='a:b:c') == Tree()
    assert t.get('f', namespace='a:b') is None

    # Test nested class access with namespace
    assert t.get('d', namespace='a:b:c') == 1

# Generated at 2022-06-21 22:19:39.101269
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    k1, v1 = 'test', 'value'
    k2, v2 = 'test:test', 'value:value'
    t = Tree({k1: v1, k2: v2})

    r = t.__getitem__(k1)
    assert r == v1, "%r != %r" % (r, v1)

    r = t.__getitem__(k2)
    assert r == v2, "%r != %r" % (r, v2)

    try:
        r = t.__getitem__(k2 + ':test')
        assert False, "Did not raise KeyError"
    except KeyError:
        pass



# Generated at 2022-06-21 22:19:43.002508
# Unit test for function tree
def test_tree():
    tree = Tree()

    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'

    assert tree['lulz'] == Tree

    tree['a:b'] = 'c'
    assert tree['a:b'] == 'c'



# Generated at 2022-06-21 22:19:50.931881
# Unit test for function tree
def test_tree():
    """Unit test coverage of tree() and tree::set_tree_node()."""
    assert get_tree_node(tree(), 'foo') == {}

    tree_1st = tree()
    tree_1st['foo'] = {'bar': {'baz': 'quux'}}
    assert get_tree_node(tree_1st, 'foo') == {'bar': {'baz': 'quux'}}
    assert get_tree_node(tree_1st, 'foo:bar:baz') == 'quux'

    assert get_tree_node(tree_1st, 'foo:bar:nonex') is _sentinel
    assert get_tree_node(tree_1st, 'foo:bar:nonex', default='quux') == 'quux'


# Unit test class tree

# Generated at 2022-06-21 22:20:02.043239
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'one': {
            'two': {
                'three': {
                    'four': 4
                }
            }
        }
    }
    value = get_tree_node(tree, 'one:two:three:four')
    assert value == 4

    value = get_tree_node(tree, 'one:three:four')
    assert value is _sentinel

    value = get_tree_node(tree, 'one:three:four', default=False)
    assert value is False

    value = get_tree_node(tree, 'one:two:three')
    assert isinstance(value, dict)
    assert value == tree['one']['two']['three']

    parent = get_tree_node(tree, 'one:two:three:four', parent=True)

# Generated at 2022-06-21 22:20:09.728740
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'foo') is _sentinel
    assert get_tree_node({'foo': None}, 'foo', default=None) is None
    assert get_tree_node({'foo': {'bar': None}}, 'foo:bar', default=None) is None
    assert get_tree_node({'foo': {'bar': None}}, 'foo:bar', parent=True) == {'bar': None}



# Generated at 2022-06-21 22:20:20.509939
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import pytest

    fixture = {
        # Basic
        'A': 'leaf',
        'B': {
            'C': {'leaf': 'C.leaf'}
        },
        # Multiple dimensions
        'D': {
            'E': {
                'F': {
                    'G': {
                        'H': {'leaf': 'H.leaf'}
                    }
                }
            }
        },
        # Inherit namespace
        'I': tree()
    }

    t = Tree(initial=fixture, namespace='root')

# Generated at 2022-06-21 22:20:34.373576
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    try:
        x = t['one']
        raise AssertionError('`x = t.__getitem__(key)` should raise KeyError')
    except KeyError:
        pass
    t.__setitem__('one', {
        'two': {
            'four': 'banana'
        },
        'three': 'eggs'
    })
    assert t['one']['two']['four'] == 'banana', 'Setting value failed'
    assert t['one']['three'] == 'eggs', 'Setting value failed'
    t['one']['three'] = 'spam'
    assert t['one']['three'] == 'spam', 'Setting value failed'
    t.__setitem__('apple', 'pear')

# Generated at 2022-06-21 22:20:36.700939
# Unit test for constructor of class Tree
def test_Tree():
    registry = RegistryTree()
    registry.register('foo', 'bar')
    assert registry['foo'] == 'bar'



# Generated at 2022-06-21 22:20:47.187087
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'b': {
            'c': 'd',
            'd': {
                'e': 'f'
            }
        }
    }

    assert get_tree_node(test_tree, 'b:d:e') == 'f'
    assert get_tree_node(test_tree, 'b:d:x', default='f') == 'f'
    assert get_tree_node(test_tree, 'b:c') == 'd'
    assert get_tree_node(test_tree, 'b:c', parent=True) == {'c': 'd', 'd': {'e': 'f'}}
    assert get_tree_node(test_tree, 'b:c', parent=False) == 'd'

# Generated at 2022-06-21 22:20:50.937994
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree({'foo': 'bar'})
    assert registry['foo'] == 'bar'
    registry.register('bar', 'baz')
    assert registry['bar'] == 'baz'



# Generated at 2022-06-21 22:20:54.000134
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test the set_tree_node function."""
    tree = {}
    set_tree_node(tree, 'a:b:c', 'hello world')
    assert tree['a']['b']['c'] == 'hello world'



# Generated at 2022-06-21 22:20:59.893886
# Unit test for constructor of class Tree
def test_Tree():
    my_tree = Tree(initial={'a': {'b': {'c': 'd'}}}, namespace='ns')
    assert my_tree['a']['b']['c'] == 'd'
    assert my_tree['ns:a']['b']['c'] == 'd'
    assert my_tree['ns:a:b']['c'] == 'd'


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-21 22:21:03.315785
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('foo', 1)  # tree['foo'] = 1
    assert tree['foo'] == 1

# Generated at 2022-06-21 22:21:04.685705
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('foo')

# Generated at 2022-06-21 22:21:08.593611
# Unit test for constructor of class Tree
def test_Tree():
    expected_data = {
        'foo': {
            'bar': 'baz'
        }
    }
    data = Tree(expected_data)
    assert data == expected_data



# Generated at 2022-06-21 22:21:20.133191
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    r = RegistryTree()

    # Instantiate a new RegistryTree and add a new item to it
    r.register('super.meta.new_item', 4)

    # Check value of new item
    assert r['super.meta.new_item', 4]

    # Instantiate a new RegistryTree as 'sub' under the former
    new_registry = r['super.meta', RegistryTree()]

    # Add a new item to the 'sub' Tree
    new_registry.register('new_item', 3)

    # Check value of new item
    assert r['super.meta.new_item', 3]

    # Instantiate a new RegistryTree as 'sub' under the former, using the same name
    sub_r = r['super.meta', RegistryTree()]

    # Check that 'sub' is the same object as 'new_reg

# Generated at 2022-06-21 22:21:42.929631
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():

    tree_instance = Tree()

    tree_instance[":'name':'py3status'"] = "'py3status'"
    tree_instance[":'python':'2.7'"] = "'2.7'"
    tree_instance[":'location':'tychonievich'"] = "'tychonievich'"

    assert tree_instance[":'name'"] == "'py3status'"
    assert tree_instance[":'python'"] == "'2.7'"
    assert tree_instance[":'location'"] == "'tychonievich'"

    tree_instance[":languages:'python':'2.7'"] = "'2.7'"
    tree_instance[":languages:'python':'3.4'"] = "'3.4'"
    tree_instance[":languages:'python':'3.5'"]

# Generated at 2022-06-21 22:21:54.231124
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Test method __getitem__ of class Tree"""
    tree = Tree()
    assert get_tree_node(tree, ':') is tree
    assert get_tree_node(tree, 'var:') is tree['var']
    assert get_tree_node(tree, 'var:column') is tree['var']['column']
    assert get_tree_node(tree, 'var:column:') is tree['var']['column']
    assert get_tree_node(tree, 'var:column:foo') is tree['var']['column']['foo']
    tree['var']['column']['foo'] = {'foo': 'bar'}
    assert get_tree_node(tree, 'var:column:foo') == {'foo': 'bar'}

# Generated at 2022-06-21 22:22:00.648412
# Unit test for constructor of class Tree
def test_Tree():
    test_data = {
        'foo': {
            'bar': 'baz',
            'baz': {
                'bar': 'baz',
                'baz': 'bar',
                'a': 'b'
            }
        }
    }
    t = Tree(test_data)
    assert t.get('foo:bar') == 'baz'
    assert t.get('foo:baz:baz') == 'bar'

# Generated at 2022-06-21 22:22:07.346349
# Unit test for constructor of class Tree
def test_Tree():
    """Test functionality of `~Tree.update`"""
    tree = Tree(initial={
        'foobar': {
            'foo': 'bar',
            'bar': 'foo',
        }
    }, namespace='foobar')
    assert tree.get('foo', namespace='foobar') == 'bar'
    assert tree.get('bar', namespace='foobar') == 'foo'


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-21 22:22:10.264568
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t.register('foo', dict(a=1, b=2))
    assert t.get('foo:a') == 1
    assert t.get('foo:b') == 2



# Generated at 2022-06-21 22:22:21.519968
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node using the very useful Python "assert" keyword.
    :return:
    """
    t = tree()
    # t = {}
    set_tree_node(t, 'a', 'a')
    assert get_tree_node(t, 'a') == 'a'
    set_tree_node(t, 'a:b', 'ab')
    assert get_tree_node(t, 'a:b') == 'ab'
    set_tree_node(t, 'a:b:c', 'abc')
    assert get_tree_node(t, 'a:b:c') == 'abc'
    set_tree_node(t, 'a:b:c:d', 'abcd')

# Generated at 2022-06-21 22:22:30.461364
# Unit test for function tree
def test_tree():
    from pprint import pprint
    t = tree()
    t['a:b:c:d:e'] = 10
    t['a:b:n'] = 20
    t['a:c'] = 30
    t['b:n'] = 40
    pprint(t)

    # Unit test for function get_tree_node
    assert t['a:b:c:d:e'] == 10
    assert t['a:b:n'] == 20
    assert t['a:c'] == 30
    assert t['b:n'] == 40

    # Unit test for function set_tree_node
    set_tree_node(t, 'a:b:n', 56)
    assert t['a:b:n'] == 56

    # Unit test for class Tree
    t = Tree()

# Generated at 2022-06-21 22:22:31.634420
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert(rt is not None)



# Generated at 2022-06-21 22:22:42.226164
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    my_tree = Tree()

    my_tree['hi'] = 'there'
    assert my_tree['hi'] == 'there'
    assert my_tree['hi:there'] == 'there'
    my_tree['test'] = {
        'foo': 'bar',
        'lol': [1, 2, 3],
        'sup': {
            'dawg': 'sup',
        },
    }
    assert my_tree['test']['foo'] == 'bar'
    assert my_tree['test']['lol'][2] == 3
    assert my_tree['test']['sup']['dawg'] == 'sup'

    my_tree['test:lol'] = 'lol'
    assert my_tree['test:lol'] == 'lol'


# Generated at 2022-06-21 22:22:45.335951
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    r = Tree()
    r['a'] = {'b': {'c': 1, 'd': 2}}
    assert r['a:b:c'] == 1
    assert r['a:b:d'] == 2
    assert r['a:b:k'] is None



# Generated at 2022-06-21 22:23:10.075970
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tr = Tree()
    tr['a'] = ['1', '2' ,'3']
    tr['b'] = 123

    # 'a' is a list and 'b' is a number
    assert tr['a'] == ['1', '2', '3']
    assert tr['b'] == 123

    # The element does not exist.
    with pytest.raises(Exception):
        tr['c']

    # specify a default value
    assert tr.get('c', 'default') == 'default'

    # specify a namespace
    tr['c'] = 'c'
    assert tr.get('c', 'default', namespace='ns1') == 'c'
    assert tr.get('c', 'default', namespace='ns2') == 'default'

    # use default value and specify a namespace
    tr['c'] = 'c'

# Generated at 2022-06-21 22:23:18.130346
# Unit test for function set_tree_node
def test_set_tree_node():
    import inspect
    import collections

    mapping = {}
    assert set_tree_node(mapping, 'test:test2:test3', 'should be a value') is mapping
    assert mapping['test']['test2']['test3'] == 'should be a value'
    assert inspect.cleandoc(
        """
        defaultdict(<type 'dict'>, {'test': {'test2': {'test3': 'should be a value'}}})
        """.strip('\n')) in repr(mapping)

    mapping = tree()
    assert set_tree_node(mapping, 'test:test2:test3', 'should be a value') is mapping
    assert mapping['test']['test2']['test3'] == 'should be a value'

# Generated at 2022-06-21 22:23:28.407342
# Unit test for function tree

# Generated at 2022-06-21 22:23:30.054819
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree(namespace='app')
    registry.register('foo', 'myval')
    assert registry.get('app:foo') == 'myval'

# Generated at 2022-06-21 22:23:33.306925
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():

    class config(Tree):
        pass

    config['a:b:c'] = 'test'

    assert config['a:b:c'] == 'test'



# Generated at 2022-06-21 22:23:36.184316
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_tree = Tree()
    test_tree['foo'] = {'bar': 1}
    assert test_tree['foo:bar'] == 1



# Generated at 2022-06-21 22:23:46.923792
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['a']['b']['c'] = 123
    tree['a']['p'] = 42
    assert tree['a']['p'] == 42
    assert tree['a']['b']['c'] == 123
    assert tree['a']['b'] == {'c': 123}
    assert tree['a'] == {'b': {'c': 123}, 'p': 42}
    assert tree['q'] == {}
    tree['a']['b']['c'] = 234
    assert tree['a']['b']['c'] == 234
    tree['a']['b']['c'] = 345
    assert tree['a']['b']['c'] == 345

# Generated at 2022-06-21 22:23:56.378943
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()

    assert tree['a'] == {}
    assert tree['a']['b'] == {}
    assert tree['a']['b']['c'] == {}
    assert tree.get('a:b:c') == {}
    assert tree.get('a') == {'b': {'c': {}}}
    assert tree.get('a:b') == {'c': {}}
    assert tree.get('a:b:c') == {}
    tree['a']['b']['c'] = []
    assert tree.get('a:b:c') == []

    tree['a']['b']['d'] = []
    assert tree.get('a') == {'b': {'c': [], 'd': []}}

# Generated at 2022-06-21 22:23:58.717027
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Test method `Tree.__setitem__`
    """
    instance = Tree()
    instance['foo'] = 'bar'  # calls __setitem__
    assert instance['foo'] == 'bar'



# Generated at 2022-06-21 22:24:07.729695
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from boussole.exceptions import SettingsKeyNotFound
    tree = Tree()
    assert sorted(tree['test']) == ['a', 'b', 'c']
    assert tree['test'] == {'a': {'b': {'c': {}}}}
    assert tree['test']['a']['b']['c'] == {}
    tree['test']['a']['b']['c'] = 'abc'
    assert tree['test'] == {'a': {'b': {'c': 'abc'}}}



# Generated at 2022-06-21 22:24:42.234346
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    assert Tree().__setitem__() == 'No return value'


# Generated at 2022-06-21 22:24:52.215517
# Unit test for function get_tree_node
def test_get_tree_node():
    # Minimal list
    assert get_tree_node({'a': 20}, 'a') == 20

    # Nested dict
    mapping = dict(a=dict(b=dict(c=10)))
    assert get_tree_node(mapping, 'a') == {'b': {'c': 10}}
    assert get_tree_node(mapping, 'a:b') == {'c': 10}
    assert get_tree_node(mapping, 'a:b:c') == 10

    # Nested dict, non-existent key
    assert get_tree_node(mapping, 'a:b:c:d') == _sentinel

    # Nested dict, non-existent key, default
    assert get_tree_node(mapping, 'a:b:c:d', default=False) is False
    assert get

# Generated at 2022-06-21 22:25:02.940520
# Unit test for function set_tree_node
def test_set_tree_node():
    _tree = tree()
    assert _tree is set_tree_node(_tree, 'raiz:dow:child1', 'child1')['raiz']['dow']['child1']
    assert _tree is set_tree_node(_tree, 'raiz:top', 'top')['raiz']['top']
    assert _tree is set_tree_node(_tree, 'root', 'root')['root']
    assert _tree is set_tree_node(_tree, 'root:test:test2', 3)['root']['test']['test2']
    assert _tree is set_tree_node(_tree, 'raiz:dow', 'dow')['raiz']['dow']



# Generated at 2022-06-21 22:25:11.636396
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Tree[key]
    mapping = Tree({
        'foo': ('bar', ('bar', ('bar', 'bar'))),
        # {'foo': ('bar', ('bar', ('bar', 'bar')))}
        'fuu': ('bar', ('bar', ('bar', 'bar'))),
        # {'fuu': ('bar', ('bar', ('bar', 'bar')))}
    })

    # ('bar', ('bar', ('bar', 'bar')))
    assert mapping['foo'] == ('bar', ('bar', ('bar', 'bar')))
    # bar
    assert mapping['foo:1'] == 'bar'
    # bar
    assert mapping['foo:1:2'] == 'bar'
    # KeyError
    assert mapping['foo:1:2:1'] == 'bar'
    # KeyError
   

# Generated at 2022-06-21 22:25:17.857475
# Unit test for function tree
def test_tree():
    """
    Test tree()
    """
    t = tree()
    t["a"]["b"]["c"] = 5
    assert t["a"]["b"]["c"] == 5
    assert t["a:b"]["c"] == 5
    assert t["a"]["b:c"] == 5
    assert t[":"]["a"]["b"]["c"] == 5
    assert t[""]["a"]["b"]["c"] == 5



# Generated at 2022-06-21 22:25:18.611172
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()

# Generated at 2022-06-21 22:25:20.405785
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # TODO Write this
    raise NotImplementedError



# Generated at 2022-06-21 22:25:29.436539
# Unit test for constructor of class Tree
def test_Tree():
    root = Tree()
    root['a'] = 1
    assert root['a'] == 1
    assert root.namespace == ''
    root = Tree(initial={'a': 1})
    assert root['a'] == 1
    root = Tree(initial_is_ref=root)
    assert root['a'] == 1
    #     assert root.namespace == ''
    root = Tree(initial_is_ref=root, namespace='x')
    assert root['a'] == 1
    root['x:y'] = 2
    assert root['a'] == 1
    assert root['x:y'] == 2
    assert root['y'] == 2
    assert root.namespace == 'x'
    root['x:z'] = 3
    assert root['x:z'] == 3
    assert root['z'] == 3
    root.names

# Generated at 2022-06-21 22:25:37.449440
# Unit test for function set_tree_node
def test_set_tree_node():
    node = tree()
    set_tree_node(node, 'test', 'value')
    assert node['test'] == 'value'

    set_tree_node(node, 'test:key', 'value2')
    assert 'key' in node['test']
    assert node['test']['key'] == 'value2'

    set_tree_node(node, 'test2:key2', 'value3')
    assert 'key2' in node['test2']
    assert node['test2']['key2'] == 'value3'



# Generated at 2022-06-21 22:25:39.494565
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    assert tree.__setitem__('foo', 'bar') == {'foo': 'bar'}



# Generated at 2022-06-21 22:27:03.114216
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 1
    t['b:c'] = 2
    assert t['a'] == 1
    assert t['b:c'] == 2
    assert t['a:c'] == Tree()
    assert t['a:c'] == {}

    # Now with namespace
    t = Tree(namespace='d')
    t['a'] = 1
    t['b:c'] = 2
    assert t['a'] == 1
    assert t['b:c'] == 2
    assert t['a:c'] == Tree()
    assert t['a:c'] == {}

    # Retrieve with namespace
    assert t.get('a', namespace='d') == 1
    assert t.get('b:c', namespace='d') == 2

# Generated at 2022-06-21 22:27:06.913877
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Test for method __setitem__ of class Tree"""
    #TODO
    t = Tree()
    t['foo.bar'] = 'test'
    assert t['foo.bar'] == 'test'
    t['foo.bar'] = 'test2'
    assert t['foo.bar'] == 'test2'
    try:
        t['foo.other']
        assert False
    except KeyError:
        assert True
    t['foo.other']
    assert t['foo.bar'] == 'test2'
    assert t['foo.other'] is None

# Generated at 2022-06-21 22:27:13.076730
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from ansible.plugins import module_loader
    d = RegistryTree(base_class=module_loader.AnsibleModule)
    d.register('shell', module_loader.AnsibleModule)

# Generated at 2022-06-21 22:27:15.099711
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    m = Tree()
    m['foo'] = 'bar'
    assert m['foo'] == 'bar'
    assert m['foo:bar'] is None

# Generated at 2022-06-21 22:27:22.418996
# Unit test for function set_tree_node
def test_set_tree_node():
    d1 = {}
    set_tree_node(d1, 'a:b:c:d:e', 'f')
    assert d1['a']['b']['c']['d']['e'] == 'f'
    set_tree_node(d1, 'a:b:c:d:e', 'g')
    assert d1['a']['b']['c']['d']['e'] == 'g'
    set_tree_node(d1, 'a:b:c:d:e', 'h')
    assert d1['a']['b']['c']['d']['e'] == 'h'
    set_tree_node(d1, 'a:b:c:d:f', 'g')

# Generated at 2022-06-21 22:27:24.216643
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    initial = {'foo': 'bar'}
    t = Tree(initial)
    t['f'] = 'b'
    assert t['f'] == 'b', '__setitem__ should allow setting any arbitrary key.'


# Generated at 2022-06-21 22:27:27.586373
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    assert isinstance(t, Tree)
    assert issubclass(t.default_factory, RegistryTree)



# Generated at 2022-06-21 22:27:29.900828
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('foo', 'bar')
    assert rt['foo'] == 'bar'

# Generated at 2022-06-21 22:27:34.871087
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    d = Tree()
    d['a']['b']['c'] = '1'
    assert d['a:b:c'] == '1'
    with pytest.raises(KeyError):
        d['a:b:c:d']
    assert d.get('a:b:c:d') is None
    assert d.get('a:b:c:d', 'this is None') == 'this is None'



# Generated at 2022-06-21 22:27:45.007243
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'test': {
            'test_test': [
                {
                    'test': True,
                }
            ]
        }
    }

    assert get_tree_node(data, 'test') == {'test_test': [{'test': True}]}
    assert get_tree_node(data, 'test:test_test') == [{'test': True}]
    assert get_tree_node(data, 'test:test_test:0') == {'test': True}
    assert get_tree_node(data, 'test:test_test:0:test') is True
    assert get_tree_node(data, 'test:test_test:0:test:test', parent=True) == {'test': True}
