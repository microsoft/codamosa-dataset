

# Generated at 2022-06-21 22:18:02.946495
# Unit test for constructor of class Tree
def test_Tree():
    t1 = Tree({'a': 1, 'b': 2})
    t2 = Tree({'b': 2, 'a': 1})
    assert t1 == t2



# Generated at 2022-06-21 22:18:05.843372
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree(initial={'logger': 'logger'}, initial_is_ref=True)
    assert reg.register('foo', 'bar') == reg['logger']



# Generated at 2022-06-21 22:18:10.670601
# Unit test for function tree
def test_tree():
    root = tree()
    root['a'] = 1
    root['b']['c'] = 2
    root['b']['d']['e'] = 3

    assert root.data == {
        'a': 1,
        'b': {
            'c': 2,
            'd': {
                'e': 3,
            }
        }
    }



# Generated at 2022-06-21 22:18:14.041968
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert get_tree_node(Tree({'a': 1, 'b': 2}), 'a') == 1
    assert get_tree_node(Tree({'a': {'b': 2, 'c': 3}, 'b': 2}), 'a:c') == 3



# Generated at 2022-06-21 22:18:16.426342
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(initial_is_ref={'test': 'alo'})
    assert tree['test'] == 'alo'
    assert tree['test'] == tree.data['test']



# Generated at 2022-06-21 22:18:28.162275
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    assert t.register('a', 'A') == {'a': 'A'}
    assert t.register('b', 'B') == {'b': 'B'}

    # Test namespace
    t = Tree(namespace='ns1')
    assert t.register('a', 'A') == {'a': 'A'}
    assert t.register('b', 'B') == {'b': 'B'}
    assert t.register('ns2:a', 'A') == {'ns2:a': 'A'}
    assert t.register('ns2:b', 'B') == {'ns2:b': 'B'}

    # Test __setitem__
    t = Tree()
    assert t.__setitem__('a', 'A') == {'a': 'A'}


# Generated at 2022-06-21 22:18:39.429458
# Unit test for function get_tree_node
def test_get_tree_node():
    x = {
        'a': {
            'b': {
                'c': 'BcC'
            }
        }
    }

    assert get_tree_node(x, 'a:b:c') == 'BcC'
    assert get_tree_node(x, 'a:b:c', parent=True) == {'c': 'BcC'}
    assert get_tree_node(x, 'a:b:c', default=False) == 'BcC'
    assert get_tree_node(x, 'a:b:c', default=False, parent=True) == {'c': 'BcC'}
    assert get_tree_node(x, 'a:b:c:d', default=False) is False

# Generated at 2022-06-21 22:18:42.408651
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test setting tree node"""
    mapping = tree()
    set_tree_node(mapping, 'foo:bar', 'value')
    assert mapping['foo']['bar'] == 'value'



# Generated at 2022-06-21 22:18:47.655941
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    '''This test method is to check functionality of class RegistryTree'''

    registry = RegistryTree()

    registry.register('a', 1)
    registry.register('b:c', 2)
    registry.register('b:c:d', 3)

    # output: 1
    print(registry.get('a'))

    # output: {'c': 3}
    print(registry.get('b'))

    # output: {'d': 3}
    print(registry.get('b:c'))

    # output: 3
    print(registry.get('b:c:d'))

# Generated at 2022-06-21 22:18:55.129215
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test for set_tree_node"""
    conf = {}
    set_tree_node(conf, 'test', 'hi')
    assert conf['test'] == 'hi'
    set_tree_node(conf, 'test:foo', 'bar')
    assert conf['test']['foo'] == 'bar'
    set_tree_node(conf, 'test:foo:baz', 'qux')
    assert conf['test']['foo']['baz'] == 'qux'



# Generated at 2022-06-21 22:18:59.802060
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': 'b'}, initial_is_ref=True)
    assert len(t) == 1
    assert t['a'] == 'b'

# Generated at 2022-06-21 22:19:01.792415
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    assert isinstance(tree, collections.defaultdict)


# Generated at 2022-06-21 22:19:13.737604
# Unit test for function set_tree_node
def test_set_tree_node():
    from pprint import pprint
    result = tree()
    set_tree_node(result, 'foo:bar', 'value')
    set_tree_node(result, 'foo:baz', 'value')
    set_tree_node(result, 'foo:baz:baz', 'value')
    set_tree_node(result, 'foo:baz:baz:baz', 'value')
    set_tree_node(result, 'foo:baz:baz:baz:baz:baz', 'value')

    pprint(result)

    assert result['foo']['bar'] == 'value'
    assert result['foo']['baz']['baz']['baz']['baz']['baz'] == 'value'



# Generated at 2022-06-21 22:19:22.223537
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'a': {
            'b': {
                'c': 1
            }
        },
        'd': 'test',
        'e': {
            'f': [1, 2, 3]
        }
    }
    assert get_tree_node(data, 'a:b:c') == 1
    assert get_tree_node(data, 'd') == 'test'
    assert get_tree_node(data, 'e:f') == [1, 2, 3]
    assert get_tree_node(data, 'e:f:1') == 2
    assert get_tree_node(data, 'e:f:1', default=False) == 2
    assert get_tree_node(data, 'xyz', default=False) is False

# Generated at 2022-06-21 22:19:31.182307
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'already': {'exists': {'value': 'val', 'int': 1}}})

    result = tree['already:exists:value']
    expected = 'val'
    assert result == expected

    result = tree['already:exists:value', tree['already:exists:int']]
    expected = 'val1'
    assert result == expected

    result = tree['not:exists']
    expected = _sentinel
    assert result == expected

    # Make sure this works

# Generated at 2022-06-21 22:19:35.016240
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data = Tree()
    test_data['foo'] = 1
    test_data['bar:foo'] = 2
    test_data['bar:stoo:gew'] = 3
    assert test_data['foo'] == 1
    assert test_data['bar:foo'] == 2
    assert test_data['bar:stoo:gew'] == 3
    assert test_data['bar'] == {'foo': 2, 'stoo': {'gew': 3}}

# Generated at 2022-06-21 22:19:39.882261
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='test')
    t['foo'] = 'bar'
    t['bar'] = 'baz'
    assert t['foo'] == 'bar'
    assert t['bar'] == 'baz'
    assert t['test:foo'] == 'bar'
    assert t['test:bar'] == 'baz'

# Generated at 2022-06-21 22:19:47.011259
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    root = Tree()

    root['key'] = 'value'
    assert root['key'] == 'value'
    assert root['im_key'] is KeyError

    root['im_key'] = 'im_value'
    assert root['im_key'] == 'im_value'

    root['im_key_0'] = 'im_value_0'
    assert root['im_key_0'] == 'im_value_0'

    root['im_key'] = 'im_value_1'
    assert root['im_key'] == 'im_value_1'



# Generated at 2022-06-21 22:19:49.748330
# Unit test for constructor of class Tree
def test_Tree():
    # Constructor
    tree = Tree(initial={'test': 'value'})
    assert tree['test'] == 'value'
    assert tree['test'] != 'key'
    assert tree['test'] is not 'value'
    assert tree['test'] is not 'key'



# Generated at 2022-06-21 22:19:55.003170
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a', 'val') == {'a': 'val'}
    assert set_tree_node({}, 'a:b', 'val') == {'a': {'b': 'val'}}
    assert set_tree_node({}, 'a:b:c', 'val') == {'a': {'b': {'c': 'val'}}}

    assert set_tree_node({'a': {}}, 'a:b', 'val') == {'a': {'b': 'val'}}
    assert set_tree_node({'a': {}}, 'a:b:c', 'val') == {'a': {'b': {'c': 'val'}}}

# Generated at 2022-06-21 22:20:02.410148
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'Hello')
    assert tree['a']['b']['c'] == 'Hello'



# Generated at 2022-06-21 22:20:14.369865
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'foo') is _sentinel
    assert get_tree_node({}, 'foo:bar') is _sentinel
    assert get_tree_node({}, '') == {}
    assert get_tree_node({}, '') == {}
    assert get_tree_node({'foo': {'bar': 0}}, 'foo:bar') == 0
    assert get_tree_node({'foo': {'bar': 0}}, 'foo:bar') == 0
    assert get_tree_node({'foo': {'bar': 0}}, '') == {'foo': {'bar': 0}}
    assert get_tree_node({'foo': {'bar': 0}}, 'foo') == {'bar': 0}


# Generated at 2022-06-21 22:20:18.441214
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Unit test for method __getitem__ of class Tree

    """
    tree = Tree()
    tree['test']['dimension']['dimension2'] = 'test2'
    assert tree['test:dimension:dimension2'] == 'test2'
    return



# Generated at 2022-06-21 22:20:22.813970
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    assert t['a'] == 1
    t['a:b:c:d'] = 2
    assert t['a'] == {'b': {'c': {'d': 2}}}



# Generated at 2022-06-21 22:20:27.536749
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, 'a:b', 'foo')
    assert a['a']['b'] == 'foo'
    a = tree()
    set_tree_node(a, 'a:b:c', 'foo')
    assert a['a']['b']['c'] == 'foo'



# Generated at 2022-06-21 22:20:36.342768
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 1
    assert tree == {'a': 1}

    tree['b:c'] = 2
    assert tree == {'a': 1, 'b': {'c': 2}}

    tree['b:d'] = 3
    assert tree == {'a': 1, 'b': {'c': 2, 'd': 3}}

    tree['b:d:e:f:g:h'] = 4
    assert tree == {'a': 1, 'b': {'c': 2, 'd': {'e': {'f': {'g': {'h': 4}}}}}}


# Generated at 2022-06-21 22:20:46.782445
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {
        'key1': 'value1',
        'key2': {
            'key21': 'value21',
            'key22': {
                'key221': 'value221',
            }
        }
    }
    assert get_tree_node(t, 'key1') == 'value1'
    assert get_tree_node(t, 'key2:key21') == 'value21'
    assert get_tree_node(t, 'key2:key22:key221') == 'value221'
    assert get_tree_node(t, 'key2:key23') is _sentinel
    assert get_tree_node(t, 'key2:key23', default='my default') == 'my default'


# Generated at 2022-06-21 22:20:51.369275
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree({'d': {'e': {'f': 'g'}}})
    registry['a']['b'] = 'c'

    assert registry == {'a': {'b': 'c'}, 'd': {'e': {'f': 'g'}}}

# Generated at 2022-06-21 22:20:59.121575
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_tree = Tree({
        'item1': {
            'item2': 'foo'
        },
        'item3': 'bar'
    })
    assert test_tree['item1:item2'] == 'foo'
    assert test_tree['item3'] == 'bar'

    test_tree = Tree({
        'item1': {
            'item2': {
                'item3': 'foo'
            }
        }
    })
    assert test_tree['item1:item2:item3'] == 'foo'
    assert test_tree['item1:item1:item1'] is None



# Generated at 2022-06-21 22:21:01.534783
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree()
    assert a
    assert isinstance(a, collections.defaultdict)



# Generated at 2022-06-21 22:21:11.296329
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'key', 'value')
    assert data['key'] == 'value'
    set_tree_node(data, 'key:subkey', 'subkeyvalue')
    assert data['key']['subkey'] == 'subkeyvalue'
    set_tree_node(data, 'key:subkey:subsubkey', 'subsubkeyvalue')
    assert data['key']['subkey']['subsubkey'] == 'subsubkeyvalue'



# Generated at 2022-06-21 22:21:17.076612
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree.register(':a', dict(a=1, b=2, c=3))
    assert tree == {
        'a': {
            'a': 1,
            'b': 2,
            'c': 3,
        }
    }



# Generated at 2022-06-21 22:21:22.243803
# Unit test for function tree
def test_tree():
    t = tree()
    t['a:b:c'] = 'abc'
    t['a:b:d'] = 'abd'
    assert t['a:b:c'] == 'abc'
    assert t['a:b:d'] == 'abd'



# Generated at 2022-06-21 22:21:26.532828
# Unit test for function get_tree_node
def test_get_tree_node():
    TREE = {'a': {'b': {'c': 3}}}
    assert get_tree_node(TREE, 'a:b:c') == 3
    assert get_tree_node(TREE, 'a:b') == {'c': 3}



# Generated at 2022-06-21 22:21:30.016647
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import unittest
    tree = Tree({'foobar': {'bar': 'baz'}})
    assert tree['foobar:bar'] == 'baz'



# Generated at 2022-06-21 22:21:40.161800
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 1
    assert t['a'] == 1
    t['b'] = 2
    assert t['b'] == 2
    t['c:d:e'] = 3
    assert t['c:d:e'] == 3
    assert t['c'] == {'d': {'e': 3}}
    assert t['c:d'] == {'e': 3}
    assert t['g:h:i:j:k:l:m:n'] == {}
    assert t['c:d:e:f:g:h:i:j:k:l:m:n'] == {}
    assert t['c:d:f'] == {}
    assert t['g'] == {}
    t['a'] = 2
    assert t['a'] == 2



# Generated at 2022-06-21 22:21:44.802813
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Testing for parameter `default` not defined (which is _sentinel)
    e = None
    try:
        Tree()['a']
    except Exception as exc:
        e = exc
    assert type(e) is KeyError

    # Testing for parameter `default` defined
    assert Tree()['a', 'default'] is 'default'



# Generated at 2022-06-21 22:21:49.267625
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'foo')
    assert set_tree_node(tree, 'a:b:c') == 'foo'



# Generated at 2022-06-21 22:21:58.589492
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree()
    a['a'] = 1
    a['b'] = 2
    a['c'] = {'d': 3, 'e': 4, 'f': {'g': 5}}
    assert a['c']['d'] == 3
    assert a['c']['d:e'] == 4
    assert a['c']['d:e:f']['g'] == 5

    # Test default value
    assert a.get('c:d:e:f:g') is None
    assert a.get('c:d:e:f:g', 'hello world') == 'hello world'

    # Test `parent` argument
    assert a['c:d:e:f:g'] is None
    parent = a.get('c:d:e:f:g', parent=True)
    assert parent

# Generated at 2022-06-21 22:22:10.139526
# Unit test for function tree
def test_tree():
    inp_data = [
        ('a', 'apple'),
        ('a:b', 'banana'),
        ('a:c', 'cat'),
        ('a:c:d', 'dog'),
        ('a:c:d:e', 'egg'),
        ('a:c:d:e:f', 'font'),
        ('a:c:d:e:f:g', 'garden'),
    ]


# Generated at 2022-06-21 22:22:19.492765
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(tree(), 'foo:bar', 42) == {'foo': {'bar': 42}}



# Generated at 2022-06-21 22:22:22.988909
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for func get_tree_node."""
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'



# Generated at 2022-06-21 22:22:31.679041
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 'A'
    assert t['a'] == 'A'
    t['a']['b'] = 'AB'
    assert t['a:b'] == 'AB'
    assert t['a']['b'] == 'AB'
    t['a:c:d'] = 'ACD'
    assert t['a']['c']['d'] == 'ACD'
    assert t['a']['c']['d'] == 'ACD'
    assert t['a:c'] == {'d': 'ACD'}
    assert t['a:c:d'] == 'ACD'
    assert t['a'] == {'b': 'AB', 'c': {'d': 'ACD'}}
    assert t['b'] is None

# Generated at 2022-06-21 22:22:35.127081
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Test tree constructor
    t = RegistryTree()
    t.register('foo.bar', 'baz')
    assert t['foo.bar'] == 'baz'



# Generated at 2022-06-21 22:22:44.249116
# Unit test for function tree
def test_tree():
    # Setup
    foo = tree()
    foo['bar'] = True
    foo['bat']['bash'] = False
    foo['blah']['blargh']['bleh'] = True

    assert foo['bar'] is True
    assert foo['bat']['bash'] is False
    assert foo['blah']['blargh']['bleh'] is True
    assert foo['nothing']['here'] == {}

    # Teardown
    del foo

    # Setup
    foo = Tree()
    foo['bar'] = True
    foo['bat']['bash'] = False
    foo['blah']['blargh']['bleh'] = True

    assert foo['bar'] is True
    assert foo['bat']['bash'] is False

# Generated at 2022-06-21 22:22:48.260747
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_node = {'nest': {}}
    set_tree_node(tree_node, 'nest:two:three', 'four')
    assert tree_node['nest']['two']['three'] == 'four'



# Generated at 2022-06-21 22:22:52.301074
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar']['baz'] = 'baz'
    assert t['foo']['bar']['baz'] == 'baz'


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-21 22:23:01.093466
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt['foo']['bar']['baz'] = 'FOOBARBAZ'
    print(rt['foo']['bar']['baz'])

    rt = RegistryTree(initial={'foo': {'bar': {'baz': 'FOOBARBAZ'}}}, initial_is_ref=True)
    rt['foo']['bar']['baz'] = 'BAZBARFOO'
    print(rt['foo']['bar']['baz'])


if __name__ == '__main__':
    from confu.utils import run_doctests
    run_doctests()

# Generated at 2022-06-21 22:23:05.170969
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('hello', 'world')
    tree.register('how:are:you?', 'today')
    assert tree.get('hello') == 'world'
    assert tree.get('how:are:you?') == 'today'


# Generated at 2022-06-21 22:23:09.334008
# Unit test for function tree
def test_tree():
    expected = {'a': {'b': {'c': 'd'}}}
    actual = tree()
    actual['a']['b']['c'] = 'd'
    assert expected == dict(actual)



# Generated at 2022-06-21 22:23:25.732008
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree.setdefault('a', {})
    tree['a']['b'] = 'b'
    tree['a']['c'] = 'c'
    tree['d'] = {'e': 'e'}

    assert tree['a'] == {'b': 'b', 'c': 'c'}, "Simple get should pass"
    assert tree['a:b'] == 'b', "Deep get should pass"
    assert tree['d:e'] == 'e', "Deep get should pass"
    assert tree['d'] == {'e': 'e'}, "Simple get should pass"



# Generated at 2022-06-21 22:23:29.152335
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    set_tree_node(a, 'b:c', 'plain')
    assert a == {'b': {'c': 'plain'}}
    set_tree_node(a, 'b:c', 'overwrite')
    assert a == {'b': {'c': 'overwrite'}}



# Generated at 2022-06-21 22:23:32.451289
# Unit test for constructor of class Tree
def test_Tree():
    # Create registry tree
    registry = RegistryTree()
    registry['test:test'] = 'test'
    assert registry['test:test'] == 'test'

# Generated at 2022-06-21 22:23:42.782460
# Unit test for function get_tree_node

# Generated at 2022-06-21 22:23:53.421161
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': 'bar'}, 'bar') == _sentinel
    assert get_tree_node({'foo': 'bar'}, 'bar', default='baz') == 'baz'
    assert get_tree_node(
        {'foo': {'bar': {'baz': 'moo'}}}, 'foo:bar:baz') == 'moo'
    assert get_tree_node(
        {'foo': {'bar': {'baz': 'moo'}}}, 'foo:baz') == _sentinel

# Generated at 2022-06-21 22:24:00.908219
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}

    # Set items on a tree
    set_tree_node(tree, '', 'root')
    set_tree_node(tree, 'foo', 'bar')
    set_tree_node(tree, 'foo:bar', 'derp')
    set_tree_node(tree, 'foo:bar:herp', 'derp')
    set_tree_node(tree, 'foo:baz', 'derp')
    set_tree_node(tree, 'foo:baz:herp', 'derp')

    # Check that they're all there.

# Generated at 2022-06-21 22:24:11.488452
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Test passing an empty string as key
    tree = Tree()
    tree['a'] = 'b'
    with pytest.raises(KeyError):
        tree['']
    # Test passing a value as key that doesn't exist
    with pytest.raises(KeyError):
        tree['c']
    # Test passing a key in which a node is not a dict
    tree['d'] = 'e'
    with pytest.raises(KeyError):
        tree['d:f']
    # Test passing a key in which a node is not a dict and default is _sentinel
    tree['g'] = 'h'
    with pytest.raises(KeyError):
        tree['g:i', _sentinel]
    # Test passing an existing key
    assert(tree['a'] == 'b')
    # Test passing

# Generated at 2022-06-21 22:24:22.448904
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert Tree({'a': {'b': {'c': 'd'}}}).__getitem__('a:b:c') == 'd'
    assert Tree({'a': {'b': {'c': 'd'}}}).__getitem__('a:b:c:d', default='oops') == 'oops'
    assert Tree({'a': {'b': {'c': 'd'}}}).__getitem__('a:b:c:d') == KeyError
    assert Tree({'a': {'b': {'c': 'd'}}}).__getitem__('a:b:c:d', default='oops', namespace='x') == 'oops'

# Generated at 2022-06-21 22:24:28.455164
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    assert isinstance(r, collections.defaultdict)
    assert isinstance(r, Tree)
    assert isinstance(r, RegistryTree)
    assert isinstance(r.__class__, RegistryTree)

# Generated at 2022-06-21 22:24:32.114683
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree([('foo', 'bar')])
    assert tree['foo'] == 'bar'
    assert tree.get('foo') == 'bar'

# Generated at 2022-06-21 22:24:45.640080
# Unit test for constructor of class Tree
def test_Tree():
    test_object = dict(((1, 1), (2, 2), (3, 3)))
    test_tree = Tree(test_object)
    assert test_tree[1] == 1
    assert test_tree[2] == 2
    assert test_tree[3] == 3

    test_object = dict(((1, dict(((1, 1),))), (2, 2), (3, 3)))
    test_tree = Tree(test_object)
    assert test_tree[1][1] == 1

    test_tree[4][5] = 6
    assert test_tree[4][5] == 6

    test_tree[4][6][7] = 8
    assert test_tree[4][6][7] == 8

# Generated at 2022-06-21 22:24:48.221705
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    assert tree == collections.defaultdict(RegistryTree)


# Test set_tree_node function

# Generated at 2022-06-21 22:24:53.108549
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(namespace='foo')
    tree['bar:baz'] = {'dur': 'hey'}
    assert tree['bar:baz:dur'] == 'hey'
    assert tree.namespace == 'foo'
    assert tree._namespace_key('bar') == 'foo:bar'

    tree['bar:baz'] = {'dur': 'hey'}
    assert tree['bar:baz:dur'] == 'hey'
    assert tree.namespace == 'foo'
    assert tree._namespace_key('bar') == 'foo:bar'

# Generated at 2022-06-21 22:24:59.817777
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Nonexistent key
    assert Tree()['foo'] == {}

    # Non-falsy default

# Generated at 2022-06-21 22:25:01.660925
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('foo', 'bar')
    assert tree['foo'] == 'bar'



# Generated at 2022-06-21 22:25:11.022594
# Unit test for function set_tree_node
def test_set_tree_node():

    # Test None
    data = tree()
    set_tree_node(data, 'top-level', None)
    assert data['top-level'] is None

    # Test non-None
    data = tree()
    set_tree_node(data, 'first-level', 'first value')
    assert data['first-level'] == 'first value'

    # Test same parent, different child
    set_tree_node(data, 'first-level:second-level', 'second value')
    assert data['first-level:second-level'] == 'second value'

    # Test same child, different parent
    set_tree_node(data, 'second-level:third-level', 'third value')
    assert data['second-level:third-level'] == 'third value'

    # Test same parent, different child, different parent
    set

# Generated at 2022-06-21 22:25:16.525355
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    t['a:b'] = 2
    t['a:b:c'] = 3
    t['a:b:d'] = 4

    assert t['a'] == 1
    assert t['a:b'] == 2
    assert t['a:b:c'] == 3
    assert t['a:b:d'] == 4



# Generated at 2022-06-21 22:25:26.442549
# Unit test for function tree
def test_tree():
    res = tree()
    res['one:two:three'] = None
    res['one:two:four'] = None
    res['one:two:five'] = None
    res['one:two']['six'] = None
    res['one:two']['seven'] = None

    assert get_tree_node(res, 'one:two:three') is None
    assert get_tree_node(res, 'one:two:six') is None
    assert get_tree_node(res, 'one:two', parent=True) == res['one']
    assert get_tree_node(res, 'one:two:six', parent=True) == res['one']['two']
    assert get_tree_node(res, 'eight', default=False) is False



# Generated at 2022-06-21 22:25:37.403113
# Unit test for constructor of class Tree
def test_Tree():
    test_dict = {
        'a': 'A',
        'b': {
            'c': 'C',
            'd': 'D'
        }
    }
    test_tree = Tree(test_dict)
    assert test_tree['a'] == test_dict['a']
    assert test_tree['b:c'] == test_dict['b']['c']
    assert test_tree['b:d'] == test_dict['b']['d']
    assert test_tree['b'] == test_dict['b']
    assert test_tree['b']['c'] == test_dict['b']['c']
    assert test_tree['b']['d'] == test_dict['b']['d']



# Generated at 2022-06-21 22:25:40.061554
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = Tree()
    set_tree_node(mapping, 'clusters:machine1:status', 'up')

    assert mapping['clusters:machine1:status'] == 'up'



# Generated at 2022-06-21 22:25:52.567590
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'a': {'b': {'c': 1}}})
    assert tree['a']['b']['c'] == 1
    return True



# Generated at 2022-06-21 22:26:00.320570
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test setting arbitrary tree node.
    """
    mapping = tree()
    assert set_tree_node(mapping, 'level1:level2:foo', 'bar') == {'level2': {'foo': 'bar'}}
    assert mapping == {'level1': {'level2': {'foo': 'bar'}}}
    assert set_tree_node(mapping, 'level1:level2:bar', 'foo') == {'level2': {'foo': 'bar', 'bar': 'foo'}}
    assert mapping == {'level1': {'level2': {'foo': 'bar', 'bar': 'foo'}}}
    assert set_tree_node(mapping, 'level1:level2:foo', 'baz') == {'level2': {'foo': 'baz', 'bar': 'foo'}}

# Generated at 2022-06-21 22:26:04.549893
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t[1] = 'a'
    t[2] = 'b'
    t['1:1'] = 'c'
    t['2:1'] = 'd'
    return t

# Generated at 2022-06-21 22:26:08.447858
# Unit test for function tree
def test_tree():
    from pprint import pprint

    tree_ = tree()
    tree_['a']['b']['c']['d'] = 'apple'
    tree_['a']['b']['e'] = 'banana'

    pprint(tree_)



# Generated at 2022-06-21 22:26:12.135360
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    print('Testing __setitem__')
    t = Tree()
    t['foo'] = 1
    assert t['foo'] == 1
    t['foo:bar'] = True
    assert t['foo:bar'] is True
    assert t['foo']['bar'] is True



# Generated at 2022-06-21 22:26:18.596249
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree_ = Tree(namespace='test')
    tree_['foo'] = 'bar'
    assert tree_['foo'] == 'bar'
    tree_.register('nonspaced', 'baz')
    assert tree_['nonspaced'] == 'baz'
    assert tree_['test:foo'] == 'bar'
    tree_.register('test:spaced', 'bat')
    assert tree_['test:spaced'] == 'bat'
    assert tree_['spaced', 'test'] == 'bat'



# Generated at 2022-06-21 22:26:27.669150
# Unit test for function get_tree_node
def test_get_tree_node():

    # Create mapping
    mapping = {
        'level_one': {
            'hello': {
                'world': 42
            }
        }
    }

    # Try to get 'hello:world'
    result = get_tree_node(mapping, 'hello:world')
    assert result == 42
    assert result is mapping['level_one']['hello']['world']

    # Try to get 'hello:world' with parent flag
    result = get_tree_node(mapping, 'hello:world', parent=True)
    assert result == {'world': 42}
    assert result is mapping['level_one']['hello']

    # Try to get 'level_one:hello:world' with default 'whatsup'

# Generated at 2022-06-21 22:26:37.248955
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, '<:a:b:c:d:e:f:g', 'anything')
    assert tree['<']
    assert tree['<']['a']
    assert tree['<']['a']['b']
    assert tree['<']['a']['b']['c']
    assert tree['<']['a']['b']['c']['d']
    assert tree['<']['a']['b']['c']['d']['e']
    assert tree['<']['a']['b']['c']['d']['e']['f']

# Generated at 2022-06-21 22:26:47.637355
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree(initial={'foo': {'bar': 'baz'}})

    # No namespace, no prefix
    eq_(t['foo:bar'], 'baz')

    # Namespace, no prefix
    t.namespace = 'nobody'
    eq_(t['foo:bar'], 'baz')

    # Namespace, prefix

# Generated at 2022-06-21 22:26:53.848461
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c:d:1', 42)
    set_tree_node(d, 'a:b:c:d:2', 4815)
    set_tree_node(d, 'a:b:c:d:3', 42)
    set_tree_node(d, 'a:b:c:z', [1, 2, 3])
    set_tree_node(d, 'a:b:c:y', {'a': 42})
    set_tree_node(d, 'a:b:c:y:z', [1, 2, 3])
    set_tree_node(d, 'a:b:c:x', [1, 2, 3])

# Generated at 2022-06-21 22:27:09.694151
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-21 22:27:18.210664
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO
    a = get_tree_node(
        {'a': {'b': 1, 'c': {'d': 1}}},
        'a:c:d'
    )
    assert a == 1
    a = get_tree_node(
        {'a': {'b': 1, 'c': {'d': 1}}},
        'a:c:z',
        default=-1
    )
    assert a == -1
    with pytest.raises(KeyError):
        get_tree_node(
            {'a': {'b': 1, 'c': {'d': 1}}},
            'a:c:z'
        )



# Generated at 2022-06-21 22:27:24.232800
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    assert t['bar'] == t
    assert t['foo:bar'] == t['bar']
    t['foo:bar:baz'] = 'qux'
    assert t['foo:bar:baz'] == 'qux'
    assert t['foo:bar:baz:qux'] == t['baz']



# Generated at 2022-06-21 22:27:28.519372
# Unit test for function tree
def test_tree():
    test_mapping = tree()
    test_mapping['first']['second']['third'] = 'Value'
    assert test_mapping['first']['second']['third'] == 'Value'



# Generated at 2022-06-21 22:27:33.503823
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    # Unit test for branch coverage of method __setitem__ of class Tree
    #     with namespace = 'a'
    #     without key = 'a', value = 'b' in t
    assert t.__setitem__('a', 'b', namespace='a') is None
    #     without t.get('a') == 'b'
    assert t.get('a') != 'b'



# Generated at 2022-06-21 22:27:35.874848
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={'a': 1, 'b': 2})
    assert t['a'] == 1 and t['b'] == 2

# Generated at 2022-06-21 22:27:45.781453
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree()
    a['foo'] = 'bar'
    assert a['foo'] == 'bar'
    assert a['baz:bleh'] == {}
    a['baz:bleh'] = 'what'
    assert a['baz:bleh'] == 'what'
    b = Tree(initial={'foo': 'bar'}, initial_is_ref=True)
    assert len(b) == 0
    assert b['foo'] == 'bar'
    c = Tree(namespace='foo')
    c['bar'] = 'baz'
    assert c['bar'] == 'baz'
    assert c['foo:bar'] == 'baz'
    c['bleh:bing'] = 'boom'
    assert c['bleh:bing'] == 'boom'

# Generated at 2022-06-21 22:27:51.163573
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    intree = Tree(initial_is_ref=True)
    intree.__setitem__('test', 'value')
    assert intree['test'] == 'value'
    intree.__setitem__('test', dict(value='value2'))
    assert intree['test:value'] == 'value2'



# Generated at 2022-06-21 22:28:02.544377
# Unit test for constructor of class Tree
def test_Tree():
    # Test constructor
    t = Tree(initial={'k': {'k2': 'v2'}})
    assert t['k:k2'] == 'v2'
    t = Tree(initial={'k': {'k2': 'v2'}}, initial_is_ref=True)
    assert t['k:k2'] == 'v2'
    # Test update
    t.update({'k2:k3': 'v3'})
    assert t['k2:k3'] == 'v3'
    t.update({'k:k3': 'v3'})
    assert t['k:k3'] == 'v3'
    # Test setitem
    t['k2:k3'] = 'v4'
    assert t['k2:k3'] == 'v4'
    # Ensure default