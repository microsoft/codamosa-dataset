

# Generated at 2022-06-21 22:18:04.572910
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('test_foo', lambda x: x*3)
    registry.register('test_bar', lambda x: x+5)
    foo = registry['test_foo'](3)
    assert foo == 9
    bar = registry['test_bar'](3)
    assert bar == 8

# Generated at 2022-06-21 22:18:09.841268
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('foo:bar:baz', 'quux')
    assert registry.get('foo:bar:baz') == 'quux'

    registry = RegistryTree(namespace='baz')
    registry.register('foo:bar:baz', 'quux')
    assert registry.get('foo:bar:baz', namespace='baz') == 'quux'



# Generated at 2022-06-21 22:18:15.077040
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()

    registry.register('a:b:c', 'c')
    registry.register('a:b:d', 'd')
    registry.register('a:b:e', 'e')

    registry.register('w:x:y', 'y')
    registry.register('w:x:z', 'z')

    assert 'a' in registry
    assert 'x' in registry



# Generated at 2022-06-21 22:18:21.390951
# Unit test for function tree
def test_tree():
    from pprint import pprint
    from copy import deepcopy
    t = tree()
    t['foo'] = 'bar'
    t['foo']['bar'] = 1
    t['foo']['bar']['blubb'] = 'foobar'
    t['foo']['moo']['blo']['blubb'] = 'bar'
    a = deepcopy(t['foo'])
    t['foo']['bar']['blubb'] = 'blo'
    pprint(a)
    pprint(t)
    t['foo']['bar']['blubb'] = 'foobar'
    pprint(t)
    t['foo']['bar']['blubb'] = 'foobar'

# Generated at 2022-06-21 22:18:24.415056
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    registry = RegistryTree()
    registry.register('test:beer:name', 'Wheat')
    registry.register('test:beer:abv', '4.6')
    registry.register('test:beer:style', 'Wheat Beer')
    assert registry['test:beer:name'] == 'Wheat'
    assert registry['test:beer:abv'] == '4.6'
    assert registry['test:beer:style'] == 'Wheat Beer'
    assert registry['test:beer:color'] is _sentinel



# Generated at 2022-06-21 22:18:25.541928
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={}, namespace='server')
    assert 'server:_tree' == t._namespace_key('_tree', namespace='server')
    assert t['_tree'] is t

# Generated at 2022-06-21 22:18:36.162334
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Method __getitem__ for class Tree should:
        * Return default when getting on a key that does not exist
        * Return default when getting on a path that does not exist
        * Return value when getting on a key that exists
        * Return value when getting on a path that exists
    """
    tree = Tree()
    tree['a'] = 0
    assert tree.get('a', 1) == 0
    assert tree.get('b', 1) == 1
    assert tree['a'] == 0
    assert tree['b'] == tree.default_factory()
    tree['b'] = 1
    assert tree['b'] == 1
    assert tree.get('b', 0) == 1
    assert tree.get('c', 0) == 0
    tree['c'] = 2
    assert tree['c'] == 2

# Generated at 2022-06-21 22:18:42.861409
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': {'bar': {'baz': 'quux'}}}, 'foo:bar:baz') == 'quux'
    try:
        get_tree_node({'foo': 'bar'}, 'foo:bar:baz')
        raise AssertionError('This should fail.')
    except KeyError:
        pass



# Generated at 2022-06-21 22:18:51.729816
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(dict) # initial tree
    assert set_tree_node(tree, 'a:b:c', 3) == {'a': {'b': {'c': 3}}}
    assert tree == {'a': {'b': {'c': 3}}}

    # Catch raise
    try:
        set_tree_node(tree, 'a:b:c')
    except TypeError:
        pass
    else:
        assert False

    # Catch exception
    try:
        set_tree_node(tree, 'a:b:c')
    except TypeError:
        pass
    else:
        assert False

    # Now with namespace
    tree = collections.defaultdict(dict) # initial tree

# Generated at 2022-06-21 22:18:53.805482
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'foo': 'bar'})
    assert t['foo'] == 'bar'



# Generated at 2022-06-21 22:19:04.547262
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={'a': {'b': {'c': 1}}})
    assert t['a'] == {'b': {'c': 1}}
    assert t['a:b:c'] == 1
    assert t['a:b'] == {'c': 1}
    assert 'd' not in t['a:b']
    assert t['a:b:d'] == Tree()
    assert t['a:b:d']['e'] == {}
    assert t['a:b:d:e:f'] == {}

# Generated at 2022-06-21 22:19:06.472653
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree('test')
    assert t['key'] == 'test'



# Generated at 2022-06-21 22:19:18.713384
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data = tree()
    test_data['a'] = tree()
    test_data['a']['b'] = 1
    test_data['a']['c'] = 2
    test_data['b'] = 3

    assert test_data['a:b'] == 1

    set_tree_node(test_data, 'a:b:d', 4)
    assert test_data['a:b:d'] == 4

    set_tree_node(test_data, 'a:b', {
        'd': 4,
        'e': 'Test'
    })
    assert test_data['a:b:d'] == 4
    assert test_data['a:b:e'] == 'Test'

    test_data['a:b:d'] = 'D'

# Generated at 2022-06-21 22:19:27.245611
# Unit test for constructor of class Tree
def test_Tree():
    initial_dict = {
        'namespace': {
            'foo': 'bar',
        },
        'bar': 'baz',
        'level2': {
            'level3': {
                'level4': {
                    'foo': 'bar'
                },
            }
        }
    }
    t = Tree(initial=initial_dict, namespace='level2')
    t['foo'] = 'baz'
    assert t['level3:level4:foo'] == 'bar'
    assert t['level3:level4']['foo'] == 'bar'

# Generated at 2022-06-21 22:19:28.798583
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('foo.bar', 'baz')
    assert registry.get('foo.bar') == 'baz'

# Generated at 2022-06-21 22:19:32.033773
# Unit test for function tree
def test_tree():
    """Test that tree behaves properly."""
    tree_data = tree()
    tree_data['a']['b'] = 1
    tree_data['a']['c'] = 2
    tree_data['d']['e'] = 3
    import pprint
    pprint.pprint(tree_data)



# Generated at 2022-06-21 22:19:35.827956
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {"a": {"b": {"c": {"d": 1}}}}
    assert get_tree_node(test_dict, 'a:b:c:d') == 1
    assert get_tree_node(test_dict, 'a:b:c:d:e', default=1) == 1



# Generated at 2022-06-21 22:19:37.467297
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('grumpy:cat:foo', 'bar')

# Generated at 2022-06-21 22:19:43.239784
# Unit test for function get_tree_node
def test_get_tree_node():
    with pytest.raises(KeyError):
        get_tree_node({'a': {'b': 'c'}}, 'a:x:x')

    assert get_tree_node({'a': {'b': 'c'}}, 'a:x', default='d') == 'd'
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'



# Generated at 2022-06-21 22:19:49.652908
# Unit test for function tree
def test_tree():
    t = tree()
    t[1][2][3] = 'hi'
    assert t[1][2][3] == 'hi'
    assert get_tree_node(t, '1:2:3') == 'hi'
    assert get_tree_node(t, '1:2:3:4') == None
    assert set_tree_node(t, '1:2:3:4', 4) == {3: 'hi', 4: 4}
    assert get_tree_node(t, '1:2:3:4') == 4
    assert t[1][2][3][4] == 4

# Generated at 2022-06-21 22:20:06.670456
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t[':foo'] = 'bar'
    assert t[':foo'] == 'bar'

    t = Tree()
    t['foo'] = 'bar'
    assert t[':foo'] == 'bar'

    t = Tree(namespace='baz')
    t['foo'] = 'bar'
    assert t[':baz:foo'] == 'bar'

# Generated at 2022-06-21 22:20:12.416656
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for constructor of class RegistryTree"""
    class Registry(RegistryTree):
        pass

    registry = Registry(namespace='test', initial={
        'a': {
            'b': {
                'c': 12
            }
        },
    })
    assert registry['a.b.c'] == 12
    assert registry['a']['b']['c'] == 12



# Generated at 2022-06-21 22:20:14.553587
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registrytree = RegistryTree()
    registrytree.register('key', 'value')
    assert registrytree.get('key') == 'value'



# Generated at 2022-06-21 22:20:19.003456
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Setup
    tree = Tree()
    expected_result = {'a': {'b': {'c': 'a:b:c'}}}

    # Exercise
    tree['a:b:c'] = 'a:b:c'

    # Verify
    assert tree == expected_result



# Generated at 2022-06-21 22:20:29.167178
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from copy import copy
    ns = 'test'
    initial = {
        'a': 'alpha',
        'b': {
            'ba': 'beta alpha',
            'bb': 'beta beta'
        },
        'c': 'gamma',
        'd': {
            'da': 'delta alpha',
            'db': 'delta beta',
            'dd': 'delta delta'
        }
    }

    data = copy(initial)

    tree = RegistryTree(initial, namespace=ns, initial_is_ref=False)

    assert tree == initial
    assert tree.data == data

    tree = RegistryTree(data, namespace=ns, initial_is_ref=True)
    data['f'] = 'foo'

    # Now check if reference is preserved
    assert tree.data == data

# Generated at 2022-06-21 22:20:32.131812
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 123
    assert tree['foo'] == 123



# Generated at 2022-06-21 22:20:34.370675
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, 'a:b', 1)
    assert a['a']['b'] == 1



# Generated at 2022-06-21 22:20:36.702214
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'a': {'b': 'c'}})
    assert tree['a:b'] == 'c'



# Generated at 2022-06-21 22:20:39.298895
# Unit test for function tree
def test_tree():
    """Function test for `tree`."""
    d = tree()
    d['a']['b']['c'] = 3
    return d



# Generated at 2022-06-21 22:20:46.573424
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'a': {'b': {'c': {'d': 'e'}}}})
    assert tree['a:b:c:d'] == 'e'
    assert tree['a:b:c'] == {'d': 'e'}
    assert tree['a:b'] == {'c': {'d': 'e'}}
    assert tree['a'] == {'b': {'c': {'d': 'e'}}}
    assert tree['a:b:c:f'] is KeyError



# Generated at 2022-06-21 22:21:02.584724
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test function get_tree_node()"""
    tree_like_dict = collections.defaultdict(dict)
    tree_like_dict['first']['second']['third'] = 'something'
    assert 'something' == get_tree_node(tree_like_dict, 'first:second:third')
    assert 'something' == get_tree_node(tree_like_dict, 'first:second:third:', default=None), 'Must be None'
    assert 'something' == get_tree_node(tree_like_dict, 'first:second:third', default=None)
    assert 'something' == get_tree_node(tree_like_dict, 'first:second:third', default=_sentinel)

# Generated at 2022-06-21 22:21:08.442845
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'this:is:a:test', 'This is a test')
    assert test_dict['this']['is']['a']['test'] == 'This is a test', "set_tree_node does not set value correctly."



# Generated at 2022-06-21 22:21:09.745454
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass



# Generated at 2022-06-21 22:21:21.660645
# Unit test for function tree
def test_tree():
    from collections import namedtuple
    Item = namedtuple('Item', 'path parent value')
    tests = [
        Item('a', '$', 'a'),
        Item('b', 'a', 'b'),
        Item('c:c', 'b', 'c:c'),
        Item('d:d', 'c:c', 'd:d'),
        Item('e', 'd:d', 'e'),
        Item('f', 'e', 'f'),
        Item('f', 'e', 'f:f'),
        Item('g:g:g', 'e', 'g:g:g'),
    ]
    mapping = tree()
    for item in tests:
        set_tree_node(mapping, item.path, item.value)


# Generated at 2022-06-21 22:21:33.300571
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Tests the method `__getitem__` of the `Tree` class."""
    from collections import namedtuple
    TreeInst = Tree()
    TreeInst['simple'] = 'simple'
    TreeInst['nested:item'] = 'nested_item'
    TreeInst['nested:list:list1'] = 'nested_list'
    TreeInst['nested:list:list2'] = 'nested_list'
    TreeInst['nested:list:list3'] = 'nested_list'
    TreeInst['nested:list:list4'] = 'nested_list'
    TreeInst['nested:list:list5'] = 'nested_list'
    TreeInst.namespace = 'namespace'
    namespace_key = TreeInst._namespace_key

# Generated at 2022-06-21 22:21:38.974889
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'a:b', default=[]) == []
    assert get_tree_node({'a': 'foo'}, 'a', default=[]) == 'foo'
    assert get_tree_node({'a': {'b': 'foo'}}, 'a:b', default=[]) == 'foo'
    assert get_tree_node({'a': {'b': 'foo'}}, 'a:b:c', default=[]) == []
    assert get_tree_node({'a': {'b': 'foo'}}, 'a:b:c', parent=True) == {'b': 'foo'}



# Generated at 2022-06-21 22:21:46.908643
# Unit test for function tree
def test_tree():
    a = tree()
    a['foo']['bar']['baz'] = 42
    a['foo']['bar']['boom'] = 45
    a['foo']['bar']['baz']['shark'] = None
    a['asd'] = {'fasd': {'basd': 2}}
    assert a['foo']['bar']['baz'] == 42 and a['foo']['bar']['boom'] == 45
    assert a['foo']['bar']['baz']['shark'] is None
    assert a['asd'] == {'fasd': {'basd': 2}}
    print(a)

# Generated at 2022-06-21 22:21:50.291303
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c']['d'] = 1
    assert t['a']['b']['c']['d'] == 1



# Generated at 2022-06-21 22:21:59.083505
# Unit test for function get_tree_node
def test_get_tree_node():
    dict_tree = {'a': {'b': 1, 'c': 2}, 'b': {'a': 3, 'b': 4}, 'c': 5}
    assert get_tree_node(dict_tree, 'a') == {'b': 1, 'c': 2}
    assert get_tree_node(dict_tree, 'a:b') == 1
    assert get_tree_node(dict_tree, 'a:c') == 2
    assert get_tree_node(dict_tree, 'b') == {'a': 3, 'b': 4}
    assert get_tree_node(dict_tree, 'a:b', default=None) == 1
    assert get_tree_node(dict_tree, 'a:d')  # KeyError

    # Test traversal with : notation

# Generated at 2022-06-21 22:22:00.593907
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    instance = RegistryTree()
    assert isinstance(instance, RegistryTree)



# Generated at 2022-06-21 22:22:15.555429
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import pprint
    tree = RegistryTree(namespace='root')
    tree.register('key1', 'value1')
    tree.register('key2:key2.1', 'value2.1')
    pprint.pprint(tree.data)

    tree2 = RegistryTree(tree, namespace='ns2')
    tree2.register('key3', 'value3')
    tree2.register('key2:key2.2', 'value2.2')
    tree2.register('key2:key2.2', 'value2.2')
    tree2.register('key2:key2.2', 'value2.2')
    tree2.register('key2:key2.3:subsubsubsubsubsub', 'value2.3')
    tree2.register('key4', 'value4')
    pprint

# Generated at 2022-06-21 22:22:21.125446
# Unit test for constructor of class Tree
def test_Tree():
    """Tests Tree class"""
    t = Tree(namespace='test', initial_is_ref=True)
    t.register('one', 'unn')
    t.register('two', 'too')

    assert t.get('one') == 'unn'
    assert t.get('test:one') == 'unn'
    assert t.get('test:none') is None



# Generated at 2022-06-21 22:22:24.990793
# Unit test for constructor of class Tree
def test_Tree():
    expected = {
        'a': {'b': 'c'},
        'one': {'two': 'three'},
    }
    tree = Tree(expected)
    for key, value in expected.items():
        assert tree[key] == value



# Generated at 2022-06-21 22:22:27.728856
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'adam:is:idiot', True)

# Generated at 2022-06-21 22:22:30.022197
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    d = {'a': 'a', 'b': {'c': 'c', 'd': 'd'}}
    r = RegistryTree(d)



# Generated at 2022-06-21 22:22:39.430634
# Unit test for function tree
def test_tree():
    a = tree()
    a['x']['y']['z'] = 123
    assert a['x']['y']['z'] == 123
    a['x']['y']['z'] += 1
    assert a['x']['y']['z'] == 124
    a['x']['y']['z'] += 1
    assert a['x']['y']['z'] == 125

    # Test set
    a['x']['y']['z'] = 5
    assert a['x']['y']['z'] == 5
    assert a['x']['y']['z'] == 5



# Generated at 2022-06-21 22:22:46.769038
# Unit test for function set_tree_node
def test_set_tree_node():
    node = {}
    # Ensure we can define a tree node with no prefix
    set_tree_node(node, 'foo:bar:baz', 'foobarbaz')
    # Ensure we can define a tree node with a prefix
    set_tree_node(node, 'baz:quux:quoob', 'bazquuxquoob', prefix='foo')
    # Ensure we can overwrite a node
    set_tree_node(node, 'foo:bar:baz', 'foobarbaz2')
    # Ensure ``node`` matches what we expect
    assert len(node) == 2
    assert 'foo' in node
    assert 'baz' in node
    assert node['foo']['bar']['baz'] == 'foobarbaz2'

# Generated at 2022-06-21 22:22:51.274802
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar'] = 'baz'
    print(t)
    assert t['foo']['bar'] == 'baz'
    assert t['foo']['bar']['qux'] == {}



# Generated at 2022-06-21 22:23:00.639557
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from collections import OrderedDict
    class_names = OrderedDict()
    class_names['twitter'] = 'twitter'
    class_names['twitter.tweet'] = 'TwitterTweet'
    class_names['twitter.tweet.user'] = 'TwitterUser'
    rt = RegistryTree(initial=class_names, initial_is_ref=True)
    assert rt.get('twitter') == 'twitter'
    assert rt.get('twitter.tweet') == 'TwitterTweet'
    assert rt.get('twitter.tweet.user') == 'TwitterUser'
    assert rt.get('twitter.tweet.user') == 'TwitterUser'


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-21 22:23:03.627630
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    assert t['foo:bar:baz'] == {}
    assert t['foo:bar:baz'] is t['foo:bar:baz']



# Generated at 2022-06-21 22:23:25.733507
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    # Set key=value at root
    set_tree_node(t, 'foo', 'foo')
    t.get('foo') == 'foo'

    # Set key=value at first dimension
    set_tree_node(t, 'foo:bar', 'bar')
    t.get('foo:bar') == 'bar'

    # Set key=value at second dimension
    set_tree_node(t, 'foo:bar:baz', 'baz')
    t.get('foo:bar:baz') == 'baz'



# Generated at 2022-06-21 22:23:32.213844
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from nose.tools import assert_raises, assert_equals

    t = Tree()
    t['one'] = '1'
    assert_equals(t['one'], '1')

    t['two:a'] = '2a'
    assert_equals(t['two:a'], '2a')

    t['two:b'] = '2b'
    assert_equals(t['two:b'], '2b')



# Generated at 2022-06-21 22:23:42.551228
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()

    t['a'] = '1'
    t.b = '2'
    t.c.d = '3'
    print("t['a'] = ", t['a'])
    print("t.b = ", t.b)
    print("t.c.d = ", t.c.d)
    print("t['c']['d'] = ", t['c']['d'])
    print("t['c:d'] = ", t['c:d'])
    print()

    t = Tree({'a': 1, 'b': 2, 'c:d': 3})
    print("t['a'] = ", t['a'])
    print("t.b = ", t.b)
    print("t.c.d = ", t.c.d)

# Generated at 2022-06-21 22:23:53.177307
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert t['foo']
    assert t['foo']['bar']
    assert t['foo']['bar']['baz']

    t = Tree(namespace='foo')
    assert t['bar']
    assert t['bar']['baz']
    assert t['bar']['baz']['beep']

    t = Tree(t, initial_is_ref=True)
    assert t['bar']
    assert t['bar']['baz']
    assert t['bar']['baz']['beep']

    t = Tree(t, initial_is_ref=True, namespace='foo')
    assert t['bar']
    assert t['bar']['baz']
    assert t['bar']['baz']['beep']

    t = Tree

# Generated at 2022-06-21 22:24:00.035050
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Unit test for method __setitem__ of class Tree
    """
    root = Tree()

    raises(KeyError, root.__setitem__, 'something:ingoing', 'some_value')
    raises(KeyError, root.__setitem__, 'ingoing', 'some_value')

    root.__setitem__('something', 'some_value')
    assert root['something'] == 'some_value'

    root.__setitem__('something:ingoing', 'some_value')
    assert root['something:ingoing'] == 'some_value'

    root.__setitem__('something', 'some_value')
    assert root['something'] == 'some_value'



# Generated at 2022-06-21 22:24:10.869419
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'a': {'b': 1}})
    assert tree['a'] == {'b': 1}
    assert tree['a:b'] == 1
    assert tree['a:b:c'] == Tree()
    assert tree['a:b:c'].namespace == 'a:b:c'
    assert tree['a:b:c'].get('d', 2) == 2
    assert tree['a:b:c:d'] == Tree()
    # TODO Note to self: Add a .namespace attribute and write a test for it.
    #   Then, when you're done, add a .get_node method, which accepts a list of keys.
    #   This will allow for greater clarity in the code.



# Generated at 2022-06-21 22:24:22.059040
# Unit test for function tree
def test_tree():
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a') == {'b': {'c': 1}}
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:', parent=True) == {}
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c') == 1
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c', parent=True) == {'c': 1}
    get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c:d', default=True) is True

# Generated at 2022-06-21 22:24:34.180784
# Unit test for function get_tree_node
def test_get_tree_node():
    from pprint import pformat
    from nose.tools import assert_equals


# Generated at 2022-06-21 22:24:41.260462
# Unit test for constructor of class Tree
def test_Tree():
    """Test for construction of Tree"""
    t = Tree(namespace='test', initial={
        'a': {
            'b': {
                'c': 'd'
            }
        }
    })
    assert t['a:b:c'] == 'd'



# Generated at 2022-06-21 22:24:43.733514
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'foo:bar:baz', 'value')
    assert d['foo']['bar']['baz'] == 'value'



# Generated at 2022-06-21 22:25:14.642576
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['a'] = 'b'
    assert tree['a'] == 'b'



# Generated at 2022-06-21 22:25:21.162382
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_raises, assert_equal

    data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    # Test that it can dig deep
    assert_equal(get_tree_node(data, 'a:b:c'), 'd')
    # Test that it can dig shallow
    assert_equal(get_tree_node(data, 'a'), {
        'b': {
            'c': 'd'
        }
    })
    # Test that it can dig using parent
    assert_equal(get_tree_node(data, 'a:b:c', parent=True), {
        'c': 'd'
    })
    # Test that it raises the proper error

# Generated at 2022-06-21 22:25:24.443798
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 1
    assert t['a']['b']['c'] == 1



# Generated at 2022-06-21 22:25:31.346287
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for get_tree_node function
    """
    from nose.tools import assert_equals
    from nose.tools import assert_raises

    mapping = tree()
    mapping[0][0] = {0: 0}
    mapping[1][2] = 3

    assert_equals(get_tree_node(mapping, '1:2'), 3)
    assert_equals(get_tree_node(mapping, '0:0:0'), 0)
    assert_equals(get_tree_node(mapping, '1:2:2'), 3)
    assert_raises(KeyError, get_tree_node, mapping, '0:3')
    assert_equals(get_tree_node(mapping, '0:3', default=-1), -1)



# Generated at 2022-06-21 22:25:37.171154
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t.register('foo', 1)
    t.register('foo:bar', 'baz')
    t.register('foo:bam', 'baz')

    assert t['foo:bar'] == 'baz'
    assert dict(t['foo']) == {'bar': 'baz', 'bam': 'baz'}



# Generated at 2022-06-21 22:25:40.771119
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['a']['b']['c'] = 'd'
    v = get_tree_node(mapping, 'a:b:c')
    assert v == 'd'
    assert get_tree_node(mapping, 'a:b:d') is _sentinel



# Generated at 2022-06-21 22:25:46.382799
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(
        {'foo': {'bar': {'baz': 1}}}, 'foo:bar:baz', 2
    ) == {'foo': {'bar': {'baz': 2}}}

    assert set_tree_node(
        {'foo': {'bar': {'baz': 1}}}, 'foo:boohoo', 2
    ) == {'foo': {'bar': {'baz': 1}, 'boohoo': 2}}



# Generated at 2022-06-21 22:25:56.870547
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3',
            'key4': {
                'key5': 'value5',
            },
        },
    }

    assert get_tree_node(mapping, 'key1') == 'value1'
    assert get_tree_node(mapping, 'key2:key3') == 'value3'
    assert get_tree_node(mapping, 'key2:key4') == {'key5': 'value5'}

    try:
        get_tree_node(mapping, 'key2:key5')
        raise AssertionError("No KeyError was raised on missing key")
    except KeyError:
        pass


# Generated at 2022-06-21 22:25:58.280925
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree({'foo': 'bar'})
    assert tree['foo'] == 'bar'
    return True



# Generated at 2022-06-21 22:26:03.102508
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'one:two:three', 'test')
    assert data['one']['two']['three'] == 'test'



# Generated at 2022-06-21 22:27:22.067435
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = '1'
    t['b'] = '2'
    t['c:d'] = t['c:e'] = '3'
    t['a'] == '1'
    t['b'] == '2'
    t['c:d'] == '3'
    t['c:e'] == '3'
    t['c:f'] == {'d': '3', 'e': '3'}

# Generated at 2022-06-21 22:27:25.751771
# Unit test for function set_tree_node
def test_set_tree_node():
    class Test(Exception):
        pass

    test_node = tree()

    set_tree_node(test_node, 'foobar', 'hello')
    assert test_node['foobar'] == 'hello'
    set_tree_node(test_node, 'foo:bar', 'hello')
    assert test_node['foo']['bar'] == 'hello'

    try:
        set_tree_node(test_node, 'foo:bar', 'failure')
    except Test:
        pass
    else:
        assert False, 'Missing KeyError on existing key'

# Generated at 2022-06-21 22:27:34.606923
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree()
    reg.register('bacon', 'bacon should be in the default namespace')
    assert reg['bacon'] == 'bacon should be in the default namespace'
    assert reg['bacon', 'test:ns'] == 'bacon should be in the default namespace'
    assert reg['bacon', 'test:ns'] == reg['bacon', 'test:ns']
    assert reg['bacon', 'test:ns'] != reg['bacon', 'other:ns']
    reg.register('spam', 'spam should be in the default namespace', namespace='test:ns')
    assert reg['spam'] == 'spam should be in the default namespace'
    assert reg['spam', 'test:ns'] == 'spam should be in the default namespace'
    assert not reg['spam', 'other:ns']


# Generated at 2022-06-21 22:27:43.190737
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    ret_value = object()
    a = Tree()

    def set_tree_node(a, u, v):
        a[u] = v
        return ret_value

    def get_tree_node(a, v):
        return a[v]

    a.set_tree_node = MethodType(set_tree_node, a, Tree)
    a.get_tree_node = MethodType(get_tree_node, a, Tree)
    a.namespace = 'test'
    u = 'test:data:id'
    v = 'test'
    assert a.__setitem__(u, v) is ret_value

# Generated at 2022-06-21 22:27:51.364085
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # RegistryTree as an instantiated class
    p = RegistryTree()
    p.register('category:true:false:null:question', 'forty-two')
    assert p['category:true:false:null:question'] == 'forty-two'

    # RegistryTree as a class and registry tree
    RegistryTree.register(RegistryTree, 'category:true:false:null:question', 'forty-two')
    assert RegistryTree[
           'category:true:false:null:question'] == 'forty-two'


# Unit tests for function tree_node(mapping, key, default=None, parent=False)

# Generated at 2022-06-21 22:28:02.642487
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    assert(set_tree_node(d, 'a:b:c', 'd') == {'b': {'c': 'd'}})
    assert(set_tree_node(d, 'a:f:b', 'c') == {'f': {'b': 'c'}})

    assert(set_tree_node(d, 'a:b:c', 'd') == {'b': {'c': 'd'}})
    assert(set_tree_node(d, 'a:f:b', 'c') == {'f': {'b': 'c'}})
