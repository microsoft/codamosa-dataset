

# Generated at 2022-06-21 22:18:03.174206
# Unit test for constructor of class Tree
def test_Tree():
    test = Tree({
        'a': {'b': {'c': 'd'}}
    }, namespace='foo')

    assert test['a:b:c'] == 'd'
    assert test['a'] == {'b': {'c': 'd'}}
    assert test['a:b'] == {'c': 'd'}

# Generated at 2022-06-21 22:18:06.360813
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry['A']['B']['C'] = 'D'
    assert registry.get('A:B:C') == 'D'


if '__main__' == __name__:
    test_RegistryTree()

# Generated at 2022-06-21 22:18:15.578625
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import os

    # Create an instance of the class RegistryTree
    M = RegistryTree()

    # Test the constructor and __init__ method
    assert(isinstance(M, RegistryTree))
    assert(isinstance(M, Tree))
    assert(isinstance(M, collections.defaultdict))
    assert(isinstance(M, collections.MutableMapping))

    # Test the .data attribute
    assert(isinstance(M.data, collections.defaultdict))

    # Test __getitem__
    assert(M['foo']['bar'] == {})

    # Test __setitem__
    M['foo']['bar'] = 'baz'
    assert(M['foo']['bar'] == 'baz')

    # Test register method
    assert(M.register('foo')['bar'] == {})


# Unit test

# Generated at 2022-06-21 22:18:22.854019
# Unit test for function set_tree_node
def test_set_tree_node():
    data = tree()
    set_tree_node(data, 'a:b:c:d:e:f:g:h:i:j:k:l:m', 'value')
    assert data['a']['b']['c']['d']['e']['f']['g']['h']['i']['j']['k']['l']['m'] == 'value'



# Generated at 2022-06-21 22:18:33.413584
# Unit test for function get_tree_node
def test_get_tree_node():
    map = {
        'foo': {
            'bar': 'baz',
            'qux': 1,
            'corge': {
                'grault': [0, 1, 2],
                'garply': Tree({'waldo': 'fred', 'kumquat': 'eggs'}),
            },
        },
    }
    assert get_tree_node(map, 'foo:bar') == 'baz'
    assert get_tree_node(map, 'foo:qux') == 1
    assert get_tree_node(map, 'foo:corge:grault') == [0, 1, 2]
    assert get_tree_node(map, 'foo:corge:garply:waldo') == 'fred'
    assert get_tree_node(map, 'foo:nope') is _sentinel

# Generated at 2022-06-21 22:18:34.542310
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    pass



# Generated at 2022-06-21 22:18:40.679421
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    >>> test_RegistryTree()
    """
    registry = RegistryTree()
    registry.register('testing', 5)
    registry.register('foo:bar:baz', 7)
    assert registry.get('testing') == 5
    assert registry.get('foo:bar:baz') == 7


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:18:48.893778
# Unit test for constructor of class Tree
def test_Tree():
    import datetime

    nested_dict = {
        'emails': {
            'primary': {
                'address': 'primary@email.tld',
            },
            'secondary': {
                'address': 'secondary@email.tld',
            },
        },
        'name': 'Mr. Nested',
        'address': '101 Ave.',
        'age': 21,
        'registered': datetime.datetime(year=2037, month=1, day=19, hour=3, minute=14, second=7, tzinfo=datetime.timezone.utc),
    }

    nt = Tree(nested_dict)
    assert nt['emails:primary:address'] == 'primary@email.tld'
    assert nt.namespace == ''

# Generated at 2022-06-21 22:19:00.742213
# Unit test for function get_tree_node
def test_get_tree_node():
    # import pytest

    def _test(expected, tree, key, default, parent=False):
        # TODO reenable assert when pytest removed
        # assert get_tree_node(tree, key, default=default, parent=parent) == expected
        assert get_tree_node(tree, key, default=default, parent=parent)
    assert get_tree_node({}, 'a', default=1) == 1
    assert get_tree_node({'a': 1}, 'a', default='b') == 1
    assert get_tree_node({'a': {'b': 1}}, 'a', default='c') == {'b': 1}
    assert get_tree_node({'a': {'b': 1}}, 'a:b', default='c') == 1

# Generated at 2022-06-21 22:19:02.196344
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert rt == {}



# Generated at 2022-06-21 22:19:14.231502
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Unit test for method __setitem__ of class Tree
    """
    logger = logging.getLogger('test_Tree___setitem__')
    t = Tree()
    k = 'test'
    v = 'value'
    t[k] = v
    assert t[k] == v, \
        "Assertion failed, %s[%s] \
        should equal %s but equals %s" % (t, k, v, t[k])
    logger.debug("%s[%s] = %s" % (t, k, v))



# Generated at 2022-06-21 22:19:23.576554
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Verify exception is raised during lookup of key:err:key
    tree_ = tree()
    tree_[u'key'][u'err'] = None
    try:
        tree_[u'key:err:key']
        assert False
    except KeyError:
        assert True

    # Verify exception is raised during lookup of key:err
    try:
        tree_[u'key:err']
        assert False
    except KeyError:
        assert True

    # Verify exception is raised during lookup of err
    try:
        tree_[u'err']
        assert False
    except KeyError:
        assert True

    # Verify exception is not raised during lookup of key, as it is present in tree_
    try:
        tree_[u'key']
        assert True
    except KeyError:
        assert False

    # Verify

# Generated at 2022-06-21 22:19:29.302297
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['one'] = 1
    tree['on:e'] = 1
    tree['one:two'] = 2
    # Check if output is as expected
    assert tree['one'] == 1
    assert tree['one:two'] == 2
    # Test error catching
    try:
        tree['one:two:three']
    except KeyError:
        pass
    else:
        assert False, 'Should have raised KeyError'



# Generated at 2022-06-21 22:19:32.887910
# Unit test for function set_tree_node
def test_set_tree_node():
    _mapping = tree()
    _mapping = set_tree_node(_mapping, 'a:b', 'c')
    assert _mapping == {'a': {'b': 'c'}}



# Generated at 2022-06-21 22:19:36.176103
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree()
    a['foo'] = 'bar'
    assert a['foo'] == 'bar'
    a['foo:bar'] = 'baz'
    assert a['foo:bar'] == 'baz'
    assert a['foo:bar:baz'] == Tree()



# Generated at 2022-06-21 22:19:39.235186
# Unit test for function tree
def test_tree():
    junk = tree()
    junk['a']['b']['c'] = 123
    assert junk['a']['b']['c'] == 123



# Generated at 2022-06-21 22:19:44.703463
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    >>> t = Tree()
    >>> t['test'] = {'1': 1, '2': 2}
    >>> t['test:1']
    1
    >>> t['test:3']
    Traceback (most recent call last):
        ...
    KeyError: 'test:3'
    >>> t['test:3', default=3]
    3
    """
    pass



# Generated at 2022-06-21 22:19:46.331681
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    d = Tree()
    d['a'] = 'a'
    d['a:b'] = 'ab'
    assert d['a'] == 'a'
    assert d['a:b'] == 'ab'
    assert d['a:b:c'] == Tree()

# Generated at 2022-06-21 22:19:50.267592
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'test:test2', 'test3') == {'test': {'test2': 'test3'}}
    assert set_tree_node({'test': {'test2': 'test3'}}, 'test4:test5', 'test6') == {'test': {'test2': 'test3'}, 'test4': {'test5': 'test6'}}



# Generated at 2022-06-21 22:19:55.566430
# Unit test for function tree
def test_tree():
    """Test tree function.
    """
    t = tree()
    t['root']['src']['xml']['test'] = 'test'
    assert t['root']['src']['xml']['test'] == 'test'



# Generated at 2022-06-21 22:20:06.578219
# Unit test for function set_tree_node
def test_set_tree_node():
    expected = {
        'a': {
            'b': {
                'c': {
                    'g': 'h',
                    'd': 'e',
                    'f': 'g'
                }
            }
        }
    }
    actual = tree()
    actual[':a:b:c:g'] = 'h'
    actual[':a:b:c:d'] = 'e'
    actual[':a:b:c:f'] = 'g'

    # TODO: Fix this goddamn test and quit sucking.
    # assert expected == actual

# Generated at 2022-06-21 22:20:09.590366
# Unit test for function set_tree_node
def test_set_tree_node():
    root = tree()
    set_tree_node(root, 'foo:bar', 1)
    root['foo:bar'].should.equal(1)



# Generated at 2022-06-21 22:20:17.965720
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'root': ['1'],
        'parent': {
            'child': ['2'],
        },
        'no_parent': '1',
    }
    assert get_tree_node(test_mapping, 'no_parent') == '1'
    assert get_tree_node(test_mapping, 'root:0') == '1'
    assert get_tree_node(test_mapping, 'no_parent:use:parent', default='2') == '2'
    assert get_tree_node(test_mapping, 'parent:child:0') == '2'



# Generated at 2022-06-21 22:20:20.686314
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()

    r.namespace = 'test'
    assert r.namespace == 'test'



# Generated at 2022-06-21 22:20:29.959587
# Unit test for function tree
def test_tree():
    assert get_tree_node({}, 'foo:bar:baz') == {}
    assert get_tree_node({}, 'foo:bar:baz', default=None) is None
    try:
        get_tree_node({}, 'foo:bar:baz')
    except KeyError:
        pass
    else:
        raise AssertionError("Should raise KeyError")

    assert get_tree_node({}, 'derp') == {}
    assert get_tree_node({'foo': {'bar': {'baz': 'derp'}}}, 'foo:bar:baz') == 'derp'
    assert get_tree_node({'foo': {'bar': {'baz': 'derp'}}}, 'foo:bar:baz', parent=True) == {'baz': 'derp'}

# Generated at 2022-06-21 22:20:40.802153
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t.update({'foo': 'bar', 'a': {'b': {'c': 'd'}}})
    assert t['foo'] == 'bar'
    assert t['a.b.c'] == 'd'
    assert t['a:b:c'] == 'd'
    assert t.get('foo') == 'bar'
    assert t.get('foo.bar') is None
    assert t.get('foo.bar', 'baz') == 'baz'
    assert t.get('a:b:c') == 'd'
    assert t.get('a.b.c') == 'd'

    t = Tree({'foo': 'bar'})
    assert t['foo'] == 'bar'

    t = Tree(['foo', 'bar'])

# Generated at 2022-06-21 22:20:44.501716
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Test RegistryTree basic functionality."""
    fn = lambda *args, **kwargs: None
    myregistry = RegistryTree()
    myregistry.register('foo', fn)
    assert myregistry.get('foo') == fn



# Generated at 2022-06-21 22:20:54.489450
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Test :func:`RegistryTree` ."""
    registry = RegistryTree({
        'key': 'value',
        'key2': {
            'foo': 'bar',
        },
    })

    # Verify that the root doesn't receive a namespace
    assert registry['key'] == 'value'
    assert registry['key2']['foo'] == 'bar'

    # Verify that the root receives the namespace
    registry = RegistryTree({
        'key': 'value',
        'key2': {
            'foo': 'bar',
        },
    }, namespace='test')

    assert registry['key'] == 'value'
    assert registry['key2']['foo'] == 'bar'

    assert registry.namespace == 'test'

    # Verify that the root doesn't receive the namespace when setting

# Generated at 2022-06-21 22:20:56.740072
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a:b:c', 'd') == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-21 22:21:03.670170
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'foo', 'bar') == {'foo': 'bar'}
    assert set_tree_node({}, 'foo:bar', 'baz') == {'foo': {'bar': 'baz'}}
    assert set_tree_node({}, 'foo:bar:baz', 'snafu') == {'foo': {'bar': {'baz': 'snafu'}}}
    assert set_tree_node({'foo': 'bar'}, 'foo:bar:baz', 'snafu') == {
        'foo': {'bar': {'baz': 'snafu'}}}

# Generated at 2022-06-21 22:21:13.986283
# Unit test for function tree
def test_tree():
    value = tree()

    value['dim1']['dim1-1']['dim1-1-1'] = 'yes'
    value['dim1']['dim1-2'] = 'yes'
    value['dim2']['dim2-1'] = 'yes'
    value['dim2']['dim2-2']['dim2-2-1'] = 'yes'

    assert value['dim1']['dim1-1']['dim1-1-1'] == 'yes'
    assert value['dim1']['dim1-2'] == 'yes'
    assert value['dim2']['dim2-1'] == 'yes'
    assert value['dim2']['dim2-2']['dim2-2-1'] == 'yes'


# Generated at 2022-06-21 22:21:15.573769
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass  # TODO: Implement test



# Generated at 2022-06-21 22:21:24.761844
# Unit test for function tree
def test_tree():
    """Run a unit test for the tree() function"""
    t = tree()
    t["a"]["b"]["c"] = 3
    t["a"]["d"] = 4
    t["a"]["b"] = 5
    assert t['a']['b']['c'] == 3
    assert t['a']['u'] == {}
    assert t['a']['b'] == 5
    assert t['x']['y']['z'] == {}

    t = tree()
    t[0][1][2] = "foo"
    assert t[0][1][2] == "foo"



# Generated at 2022-06-21 22:21:30.585680
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    module_name = os.path.splitext(os.path.basename(__file__))[0]
    registry = RegistryTree()
    registry.register(__name__, 'test_RegistryTree')
    assert registry.get(module_name) == 'test_RegistryTree'



# Generated at 2022-06-21 22:21:36.844716
# Unit test for function get_tree_node
def test_get_tree_node():
    x = {
        'a': 1,
        'b': {
            'c': 2
        }
    }

    assert get_tree_node(x, 'a') == 1
    assert get_tree_node(x, 'b:c') == 2
    try:
        get_tree_node(x, 'c')
    except KeyError:
        pass
    else:
        raise AssertionError('Key c should not exist')



# Generated at 2022-06-21 22:21:46.311021
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree.update({
        'interface': {
            'audit': {
                'email': {
                    'fromname': 'fromname',
                    'fromaddress': 'fromaddress',
                    'subject': 'subject',
                    'replyto': 'replyto',
                    'body': 'template',
                },
            },
        },
        'product': {
            'gpg_key': 'gpg_key',
            'gpg_key_id': 'gpg_key_id',
        },
    })

    # tree[] should be able to return hashes, i.e. dicts and dict-like things

# Generated at 2022-06-21 22:21:56.882633
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    assert t._namespace_key("name") == "name"
    t.namespace = "nameps"
    assert t._namespace_key("name") == "nameps:name"
    assert t._namespace_key("name", namespace="name") == "name:name"
    t["test"] = "test"
    assert t.data["test"] == "test"
    t["a"] = "b"
    assert t.data["a"] == "b"
    t["a:b"] = "c"
    assert t.data["a"]["b"] == "c"
    t["a:b:c"] = "d"
    assert t.data["a"]["b"]["c"] == "d"



# Generated at 2022-06-21 22:21:59.998899
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    inst = RegistryTree(namespace='test').register('foo', 'bar')
    assert inst['test:foo'] == 'bar'

# Generated at 2022-06-21 22:22:09.187748
# Unit test for constructor of class Tree
def test_Tree():
    # Arrange
    test_mapping = {
        'a': 1,
        'b': 2,
        'c': {
            'x': 1,
            'y': 2,
            'z': 3
        }
    }

    # Act
    test_tree = Tree(test_mapping, 'test')

    # Assert
    assert test_tree == test_mapping
    assert test_tree.namespace == 'test'

    # Act
    test_tree = Tree(test_tree)

    # Assert
    assert test_tree == test_mapping
    assert test_tree.namespace is None



# Generated at 2022-06-21 22:22:16.645504
# Unit test for constructor of class Tree
def test_Tree():
    import pprint
    data = {'a': {'b': {'c': {'e': 1}}}}
    t = Tree(data)
    t['a']['b']['c']['f'] = 2
    t.update({'a': {'b': {'c': {'g': 3}}}})

# Generated at 2022-06-21 22:22:34.182798
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import unittest
    tree = Tree()
    tree.register = Tree.__setitem__
    tree.register('foo', 'bar')
    tree.register('foot:foot', 'baz')
    try:
        tree.__getitem__('foo')
        tree.__getitem__('foot:foot')
        tree.__getitem__('nosuchthing')
    except KeyError as e:
        assert e.args[0] == 'nosuchthing'
    else:
        assert False, "Should have raised KeyError"
    tree.register('myns:foo', 'foo')
    tree.register('myns:foot:foot', 'foo')

# Generated at 2022-06-21 22:22:35.170022
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass



# Generated at 2022-06-21 22:22:44.330752
# Unit test for function get_tree_node
def test_get_tree_node():
    # Start with a nested dict and a key to fetch
    nested_dict = {
        'foo': {
            'bar': {
                'baz': True
            },
            'qux': True
        },
    }
    key = 'foo:bar:baz'

    # Fetch the value
    value = get_tree_node(nested_dict, key)
    assert value is True, 'Fetched a value as expected'

    # Try to fetch a value that doesn't exist
    value = get_tree_node(nested_dict, 'foo:bar:bux', default=False)
    assert value is False, 'Value not found, got default'

    # Try to fetch a value that doesn't exist

# Generated at 2022-06-21 22:22:48.359988
# Unit test for constructor of class Tree
def test_Tree():
    mapping = Tree({'level_1': {'level_2': {'alpha': 0, 'beta': 1, 'gamma': 2}}})
    assert mapping['level_1:level_2:gamma'] == 2



# Generated at 2022-06-21 22:22:56.237617
# Unit test for constructor of class Tree
def test_Tree():
    class NameTree(Tree):
        namespace = 'name'

    tree = NameTree()
    tree.register('scott', 'thing')

# Generated at 2022-06-21 22:22:58.831472
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(initial={'test1': 'test2'}, initial_is_ref=True)

    assert tree['test1'] == 'test2'



# Generated at 2022-06-21 22:23:07.832999
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz',
            },
        },
    }
    assert get_tree_node(mapping, 'foo') == {'bar': {'baz': 'foobarbaz'}}
    assert get_tree_node(mapping, 'foo:bar') == {'baz': 'foobarbaz'}
    assert get_tree_node(mapping, 'foo:bar') == {'baz': 'foobarbaz'}
    assert get_tree_node(mapping, 'foo:bar:baz') == 'foobarbaz'



# Generated at 2022-06-21 22:23:16.951188
# Unit test for function set_tree_node
def test_set_tree_node():
    # Single level keys
    set_tree_node(tree(), 'foo', 'bar')
    assert tree()['foo'] == 'bar'
    assert tree()['foo:bar'] == tree.default_factory()

    # Multi level keys
    set_tree_node(tree(), 'foo:bar:baz', 'spam')
    assert tree()['foo']['bar']['baz'] == 'spam'

    # Get parent keys
    set_tree_node(tree(), 'foo:bar:baz', 'spam')
    assert tree()['foo:bar'] == {'baz': 'spam'}
    assert tree()['foo:bar:baz'] == 'spam'

    # Replace existing values
    set_tree_node(tree(), 'foo', 'not bar')
    assert tree()['foo']

# Generated at 2022-06-21 22:23:27.590907
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(dict)
    set_tree_node(tree, "a:b:c", 0)
    assert tree == {"a": {"b": {"c": 0}}}, tree

    # Also test that we can set existing attributes
    tree = collections.defaultdict(dict)
    tree["a"]["b"]["c"] = 0
    set_tree_node(tree, "a:b:c", 1)
    assert tree == {"a": {"b": {"c": 1}}}, tree

    # Also test that we can set values on a list
    tree = collections.defaultdict(dict)
    tree["values"] = [0, 1, 2]
    set_tree_node(tree, "values:1", 10)
    assert tree == {"values": [0, 10, 2]}, tree


# Unit test

# Generated at 2022-06-21 22:23:29.424509
# Unit test for constructor of class Tree
def test_Tree():
    node = Tree(dict(name='Dan'))
    assert(node.get('name') == 'Dan')


# Generated at 2022-06-21 22:23:42.997969
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('foo', 'bar')
    assert tree.foo == 'bar'



# Generated at 2022-06-21 22:23:46.386320
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'a': 'b'})
    assert tree['a'] == 'b'
    assert tree['a:a'] is None
    assert tree['b'] is None



# Generated at 2022-06-21 22:23:49.302916
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['data'] = {}
    tree['data']['form'] = {
        'x': 2
    }
    assert tree['data:form:x'] == 2



# Generated at 2022-06-21 22:23:53.299326
# Unit test for function tree
def test_tree():
    data = tree()
    data['a'] = 1
    data['b']['c'] = 3
    assert data == {'a': 1, 'b': {'c': 3}}, "Wat? %s" % data


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-21 22:24:00.811263
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from nose.tools import assert_equals, assert_raises
    from copy import deepcopy
    from json import dumps

    td = {
        'namespace': 'client',
        'data': {
            'config': {
                'foo': 'bar',
                'baz': {
                    'bay': 'bat',
                    'bar': 'bam',
                },
            },
        },

    }
    tree = Tree()
    tree.update(td['data'])
    tree.namespace = td['namespace']

# Generated at 2022-06-21 22:24:11.487589
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b') == {'c': 'd'}
    assert get_tree_node(mapping, 'a:b:c:d') is _sentinel

    # Make sure we can fetch by an iterable and not just a string.
    assert get_tree_node(mapping, ['a', 'b', 'c']) == 'd'
    assert get_tree_node(mapping, ['a', 'b']) == {'c': 'd'}
    assert get_tree_node(mapping, ['a', 'b', 'c', 'd']) is _sentinel



# Generated at 2022-06-21 22:24:22.449039
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'foo': {
            'bar': 'baz'
        }
    }

    if get_tree_node(test_data, 'foo') != {'bar': 'baz'}:
        raise Exception('Key `foo` not found.')

    if get_tree_node(test_data, 'foo:bar') != 'baz':
        raise Exception('Key `foo:bar` not found.')

    if get_tree_node(test_data, 'foo:bar:bat') is not None:
        raise Exception('Key `foo:bar:bat` should not exist.')


# Generated at 2022-06-21 22:24:34.376002
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.defaultdict(collections.defaultdict)
    set_tree_node(mapping, 'a:b:c', 1)
    assert mapping['a']['b']['c'] == 1
    set_tree_node(mapping, 'a:d', 2)
    assert mapping['a']['d'] == 2
    set_tree_node(mapping, 'a:d', 3)
    assert mapping['a']['d'] == 3
    mapping = collections.defaultdict(dict)
    set_tree_node(mapping, 'a:b:c', 1)
    assert mapping['a']['b']['c'] == 1
    mapping = dict()
    set_tree_node(mapping, 'a:b:c', 1)

# Generated at 2022-06-21 22:24:45.450569
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import unittest

    class TestTree___setitem__(unittest.TestCase):
        def setUp(self):
            self.t = Tree()

        def test_set_key_value(self):
            self.t[_('a')] = _('b')
            self.assertEqual(self.t[_('a')], _('b'))

        def test_set_key_value_with_namespace(self):
            self.t[_('a')] = _('b')
            self.t.namespace = _('abc')
            self.t[_('a')] = _('b')
            self.assertEqual(self.t[_('abc:a')], _('b'))

        def test_set_key_value_with_namespace_and_delving(self):
            self.t

# Generated at 2022-06-21 22:24:47.192751
# Unit test for function tree
def test_tree():
    t = tree()
    t['aa']['bb']['cc'] = 'muh'
    assert t['aa:bb:cc'] == 'muh'



# Generated at 2022-06-21 22:25:19.691549
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Get tree node unit test. Tests if only the node asked for is returned.
    """
    root = {'a': {
        'b': {
            'c': 'd',
            'd': 'e'
        },
        'c': 'd',
        'd': 'e'
    }}

    # Just fetch it. If you can't, there is a problem.
    get_tree_node(root, 'a')
    get_tree_node(root, 'a:b')
    get_tree_node(root, 'a:b:c')

    # Fetch a value and check if it is what we expect.
    assert get_tree_node(root, 'a:b:d') is 'e'

    # Fetch a value and check if it is what we expect.
    assert get_tree_

# Generated at 2022-06-21 22:25:24.344304
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from nose.tools import assert_equals
    rt = RegistryTree()
    event_node = rt.register('event_type', 'handler', namespace='handler')
    assert_equals('handler', event_node['handler'])

# Generated at 2022-06-21 22:25:27.108201
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'first': {
            'second': {
                'third': 'value',
            }
        }
    }

    assert get_tree_node(tree, 'first:second:third') == 'value'



# Generated at 2022-06-21 22:25:33.288360
# Unit test for function tree
def test_tree():
    assert tree() == {}

    tree_ = tree()
    tree_[1][2][3] = 'hello'
    assert tree_
    assert tree_[1] == {'2': {'3': 'hello'}}
    assert tree_[1][2] == {'3': 'hello'}
    assert tree_[1][2][3] == 'hello'



# Generated at 2022-06-21 22:25:35.639387
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['key'] = 'value'
    assert tree['key'] == 'value'



# Generated at 2022-06-21 22:25:40.619380
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    d = tree()
    print(d['a']['b']['c'])
    d.__setitem__('a:b:c:d:e', 'testing')
    print(d['a']['b']['c']['d']['e'])
    print(d['a:b']['c:d']['e'])



# Generated at 2022-06-21 22:25:50.461242
# Unit test for function tree
def test_tree():
    from nose.tools import assert_equal, assert_in, assert_raises, assert_dict_equal

    # Setup
    test_value = 'value'
    test_tree = tree()

    # Test 1
    test_tree[':a'] = test_value
    assert_equal(test_value, test_tree[':a'])

    # Test 2
    test_tree[':b:c'] = test_value
    assert_equal(test_value, test_tree[':b:c'])
    assert_equal(test_value, test_tree[':b']['c'])

    # Test 3
    with assert_raises(KeyError):
        _ = test_tree[':c:b:a:d']

    # Test 4
    test_tree[':c:b:a:d'] = test_

# Generated at 2022-06-21 22:25:55.582203
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar']['baz'] = 'fizz'
    t['foo']['bar']['buzz'] = 'fuzz'
    assert t['foo']['bar']['baz'] == 'fizz'
    assert t['foo']['bar']['buzz'] == 'fuzz'



# Generated at 2022-06-21 22:26:01.554353
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equals
    from nose.tools import assert_raises
    from nose.tools import assert_true

    # setup
    mapping = {
        'key': {
            'subkey': 'value'
        }
    }

    # test single level
    assert_equals(get_tree_node(mapping, 'key:subkey'), 'value')
    assert_equals(get_tree_node(mapping, 'key:subkey', default=None), 'value')
    assert_equals(get_tree_node(mapping, 'key:subkey', default=False), 'value')
    assert_equals(get_tree_node(mapping, 'key:subkey', default=object), 'value')

# Generated at 2022-06-21 22:26:05.360830
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert Tree()['non-existent'] is _sentinel
    assert Tree({'existent': 'value'})['existent'] == 'value'
    assert Tree({'existent': {'deep': 'value'}})['existent:deep'] == 'value'

# Generated at 2022-06-21 22:27:09.244566
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('cmd:foo:bar', 'foo_bar')

    assert tree['cmd:foo:bar'] == 'foo_bar'

# Generated at 2022-06-21 22:27:16.620894
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = Tree()

    # Test simple set
    tree['a'] = 1
    assert tree.get('a') == 1

    # Test set in depth
    tree['a:b'] = 2
    assert tree.get('a:b') == 2

    # Test default
    assert tree.get('a:e', 3) == 3
    assert tree.get('a:e', _sentinel) == _sentinel

    # Test default with no default
    with pytest.raises(KeyError):
        assert tree.get('a:e')



# Generated at 2022-06-21 22:27:19.032834
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    t = Tree()
    t['foo'] = {'bar': 'baz'}
    # Basic usage
    assert t.get('foo:bar') == 'baz'



# Generated at 2022-06-21 22:27:22.876788
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    assert Tree()['foo'] is Tree()
    assert Tree()['foo:bar'] is Tree()
    assert Tree()['foo:bar:baz'] is Tree()
    assert Tree()['foo:bar']['baz'] == Tree()['foo:bar:baz']
    assert Tree()['foo:bar'] == Tree()['foo']['bar']
    assert Tree()['foo:bar:baz'] == Tree()['foo']['bar']['baz']



# Generated at 2022-06-21 22:27:27.474390
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Silly Rube Goldberg test for this class
    # It's a class, so it deserves some testing

    r = RegistryTree()
    assert not r.data, "Empty tree should have empty data"

    r['root'] = 'previous-root'
    assert r['root'] == 'previous-root', "Tree should have set root to 'previous-root'"

    t = r['subtree']
    assert t.namespace == 'subtree', "Get item should instantiate another subtree with specified namespace"

    t.register('subroot', 'subvalue')
    assert r['subtree:subroot'] == 'subvalue'

    r = RegistryTree(namespace='initial')
    assert r.namespace == 'initial', "Tree should have specified namespace"

    r = RegistryTree(initial={'initial': 'value'})

# Generated at 2022-06-21 22:27:30.563364
# Unit test for constructor of class Tree
def test_Tree():
    """Create a :class:`Tree` and set a key and value on it."""
    tree = Tree()
    tree.set('foo', 'bar')
    assert tree['foo'] == 'bar'



# Generated at 2022-06-21 22:27:40.888206
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    sample_tree = RegistryTree()
    print("Printing sample tree")
    print(sample_tree)
    sample_tree.register("1:2:3:4:5:6:7", "test")
    print("Printing sample tree after registering 1:2:3:4:5:6:7 to 'test'")
    print(sample_tree)
    print("Printing value at 1:2:3:4:5:6:7 test:", sample_tree.get("1:2:3:4:5:6:7"))
    print("Printing value at 1:2:3:4:5:6 test:", sample_tree.get("1:2:3:4:5:6"))

# Generated at 2022-06-21 22:27:43.231014
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['one:two:three'] = 'four'
    assert tree['one:two:three'].value == 'four'



# Generated at 2022-06-21 22:27:48.081916
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from pprint import pprint
    _tree = Tree()
    _tree['foo']['bar'] = 'baz'
    _tree['foo']['baz']['bar'] = 'bar'
    _tree['foo']['baz']['bar']['baz'] = 'baz'
    _tree['foo']['cool'] = 'beans'

    pprint(_tree)

# Generated at 2022-06-21 22:27:58.771819
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Create a registry tree, add some voodoo to it, get it for the black magic."""
    # Create a RegistryTree and add a plugin.
    registry = RegistryTree()
    registry.register('plugin:voodoo', 'black magic')
    assert registry['plugin:voodoo'] == 'black magic'
    # Now create an instance, with given default namespace, and add another plugin.
    registry = RegistryTree({
        'plugin:kungfu': 'high kick'
    }, namespace='plugin')
    registry.register('plugin:voodoo', 'black magic')
    assert registry['voodoo'] == 'black magic'
    # Test kungfu
    assert registry['kungfu'] == 'high kick'