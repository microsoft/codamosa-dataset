

# Generated at 2022-06-21 22:18:05.110457
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        }
    })
    assert t['c:d'] == 3, 'c:d'
    assert t['c:e'] == 4, 'c:e'
    assert t['c'] == {'d': 3, 'e': 4}, 'c'



# Generated at 2022-06-21 22:18:08.980842
# Unit test for function tree
def test_tree():
    """Test helper function tree."""
    test = tree()
    test['x']['y']['z'] = 'foo'
    test['x']['y']['bar']['baz'] = 'flurb'
    return test



# Generated at 2022-06-21 22:18:19.776568
# Unit test for constructor of class Tree
def test_Tree():
    intree = Tree({'foo': 'bar', 'baz': 'quux'}, initial_is_ref=True)
    # Detect if value is being passed by ref, not by value
    intree.data['foo'] = '_foo'
    assert intree['foo'] == '_foo'

    from copy import deepcopy
    intree = deepcopy(intree)
    assert intree['foo'] == 'bar'

    assert intree.namespace == ''

    # Test if namespace is added
    intree.namespace = 'a'
    intree['foo'] = '_bar'
    assert intree['foo'] == '_bar'


if __name__ == "__main__":
    import sys
    import nose
    nose.main(argv=[sys.argv[0], __file__])

# Generated at 2022-06-21 22:18:23.536346
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_tree = Tree()
    test_tree['a:b'] = 'foo'
    assert test_tree['a:b'] == 'foo'
    assert test_tree['b'] == {}


# Generated at 2022-06-21 22:18:31.641877
# Unit test for function tree
def test_tree():
    import pprint
    a = tree()
    print(a)

    a['foo']['bar']['baz'] = 'qwerty'
    print(a)

    a['foo:asdf'] = 'fdsa'
    print(a)

    # Extreme unit test.
    a['foo:bar:baz:qwerty:asdf:fdsa:123']['zxcv'] = 'bazinga'
    pprint.pprint(a)
    assert a['foo:bar:baz:qwerty:asdf:fdsa:123:zxcv'] == 'bazinga'



# Generated at 2022-06-21 22:18:43.034492
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'a': {
            'b': 1,
            'c': 2,
        },
        'b': {
            'd': 3,
        }
    }

    i_a_b = get_tree_node(test_data, 'a:b')
    i_b_d = get_tree_node(test_data, 'b:d')
    i_a_d = get_tree_node(test_data, 'a:d')
    i_a_d_default = get_tree_node(test_data, 'a:d', default=4)

    assert i_a_b == 1, 'get_tree_node: a:b'
    assert i_b_d == 3, 'get_tree_node: b:d'

# Generated at 2022-06-21 22:18:50.367948
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    t['foo:bar'] = 'baz'
    assert t['foo'] == {'bar': 'baz'}
    t['foo:bar:baz'] = 'qux'
    assert t['foo'] == {'bar': {'baz': 'qux'}}
    t['foo:bar:baz:qux'] = 'quux'
    assert t['foo'] == {'bar': {'baz': {'qux': 'quux'}}}
    t['foo:bar:baz:quux'] = 'quuz'
    assert t['foo'] == {'bar': {'baz': {'qux': 'quux', 'quux': 'quuz'}}}

# Generated at 2022-06-21 22:18:59.200997
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    d = Tree()
    d['a:b:c:d'] = 1
    d['a:b:c'] = 2
    d['a:b'] = 3
    d['a'] = 4
    assert d['a:b:c:d'] == 1
    assert d['a:b:c'] == 2
    assert d['a:b'] == 3
    assert d['a'] == 4
    assert d['a:b:c:d:e'] is None
    assert d['a:b:c:d:e', 'x'] == 'x'



# Generated at 2022-06-21 22:19:03.190851
# Unit test for function tree
def test_tree():
    tree_ = tree()
    tree_['a']['b']['c']['d'] = 'hi'
    assert tree_['a']['b']['c']['d'] == 'hi'
    print('test_tree passed.')


# Generated at 2022-06-21 22:19:05.430724
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t["a:b"] = "c"
    assert(t["a"]["b"] == "c")



# Generated at 2022-06-21 22:19:20.999033
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_tree = {'a': {'b': 1, 'c': 2}, 'd': {'e': 3, 'f': {'g': 4, 'h': 5}}}
    tree = Tree(initial_is_ref=True)
    tree is test_tree
    tree['a:b'] == 1
    tree['a:c'] == 2
    tree['d'] == {'e': 3, 'f': {'g': 4, 'h': 5}}
    tree['d:e'] == 3

    # KeyError
    with pytest.raises(KeyError):
        tree['d:e:f']

    # KeyError
    with pytest.raises(KeyError):
        tree['d:f:h:g']

    # KeyError

# Generated at 2022-06-21 22:19:26.130477
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Unit test for method __getitem__ of class Tree
    """
    t = Tree()
    t['a'] = {'b': {'c': 'd'}}
    item = t['a']
    assert item == {'b': {'c': 'd'}}



# Generated at 2022-06-21 22:19:35.620515
# Unit test for function set_tree_node
def test_set_tree_node():
    data = collections.defaultdict(dict)
    set_tree_node(data, 'wat', 42)
    assert data['wat'] == 42
    set_tree_node(data, 'wat:wat', 43)
    assert data['wat']['wat'] == 43
    set_tree_node(data, 'wat:wat:wat:wat:wat:wat', 42)
    assert data['wat']['wat']['wat']['wat']['wat']['wat'] == 42

    # Badness
    try:
        set_tree_node(data, 'wat:wat:wat:wat2:wat:wat', 42)
    except KeyError:
        pass
    else:
        assert False, 'Did not catch KeyError for bad key.'



# Generated at 2022-06-21 22:19:39.492617
# Unit test for function get_tree_node
def test_get_tree_node():
    node = Tree({'a': {'b': {'c': 'd'}}, 'e': {'f': {'g': 'h'}}})
    assert get_tree_node(node, 'a:b:c') == 'd'

# Generated at 2022-06-21 22:19:41.396904
# Unit test for function tree
def test_tree():
    assert get_tree_node(tree(), 'first:second') == tree()['first']['second']
    assert get_tree_node(tree(), 'first:second', parent=True) == tree()['first']


# Generated at 2022-06-21 22:19:44.429271
# Unit test for function tree
def test_tree():
    t = tree()
    t['one']['two']['three']['four'] = 'four'
    yield assert_equal, t['one']['two']['three']['four'], 'four'

# Generated at 2022-06-21 22:19:47.413418
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    def _test():
        tree = RegistryTree(namespace='test')
        tree.register('test', 'test_value')
        assert tree.get('test') == 'test_value'

    # Should not raise
    _test()



# Generated at 2022-06-21 22:19:53.315220
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['1']['2']['3']['4']['5'] = 'hello'

    assert get_tree_node(data, '1', parent=True) == {2: {}}
    assert get_tree_node(data, '1') == {'2': {u'3': {u'4': {u'5': 'hello'}}}}
    assert get_tree_node(data, '1:2:3:4:5', default=None) == 'hello'
    assert get_tree_node(data, '1:2:3:4:6', default=None) is None
    assert get_tree_node(data, '1:2:3:4:6') == _sentinel



# Generated at 2022-06-21 22:20:00.807012
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar']['baz'] = 'hello'
    assert t['foo:bar:baz'] == 'hello'
    assert t['foo']['bar']['baz'] == 'hello'

    t2 = tree()
    t2['q']['w']['e'] = 'fuck'
    assert t2['q:w:e'] == 'fuck'
    assert t2['q']['w']['e'] == 'fuck'



# Generated at 2022-06-21 22:20:08.833515
# Unit test for function tree
def test_tree():
    tree = tree()
    assert tree == {}

    tree[1][2][3] = 4
    assert tree[1][2][3] == 4
    assert tree[1][2] == {3: 4}
    assert tree[1] == {2: {3: 4}}
    assert tree == {1: {2: {3: 4}}}

    tree = tree()
    assert tree == {}


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-21 22:20:16.113488
# Unit test for function set_tree_node
def test_set_tree_node():
    candidate = {'foo': {'bar': 'baz'}}
    set_tree_node(candidate, 'foo:bar', 'boop')
    assert candidate['foo']['bar'] == 'boop'



# Generated at 2022-06-21 22:20:21.908234
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Create a registry tree
    registry = RegistryTree()

    # Register a function under a namespace
    registry.register('foo.bar.baz', lambda x: x)
    registry.register('foo.bar', lambda x: x)

    # Test the registry tree
    assert registry['foo.bar'](10) == 10
    assert registry['foo.bar.baz'](10) == 10



# Generated at 2022-06-21 22:20:24.566924
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert isinstance(rt, RegistryTree)
    assert isinstance(rt, Tree)
    assert isinstance(rt, collections.defaultdict)

# Generated at 2022-06-21 22:20:26.129543
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial=[1, 2, 3])
    assert isinstance(t, collections.defaultdict)


# Generated at 2022-06-21 22:20:28.130922
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register('a.value', 'foo')
    assert r.get('a.value') == 'foo'

# Generated at 2022-06-21 22:20:38.457927
# Unit test for function tree
def test_tree():
    t = tree()
    assert t['name']['first'] == {}
    assert t['name']['middle'] == {}
    assert t['name']['last'] == {}
    assert t['birthdate']['year'] == {}

    t['name']['first'] = 'A'
    t['name']['middle'] = 'B'
    t['name']['last'] = 'C'
    t['birthdate']['year'] = 'D'

    assert t['name']['first'] == 'A'
    assert t['name']['middle'] == 'B'
    assert t['name']['last'] == 'C'
    assert t['birthdate']['year'] == 'D'



# Generated at 2022-06-21 22:20:39.790813
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    my_tree = Tree()
    my_tree.__setitem__('foo', 'bar', namespace='herp')
    assert my_tree.get('herp:foo') == 'bar'



# Generated at 2022-06-21 22:20:43.203776
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'f.o.o', 'bar')
    assert mapping['f']['o']['o'] == 'bar'



# Generated at 2022-06-21 22:20:49.166242
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': 'A'}, namespace='foo')
    t['b'] = 'B'
    assert t['foo:a'] == 'A'
    assert t['foo:b'] == 'B'
    assert 'a' not in t
    with raises(KeyError):
        t['a']
    assert 'b' not in t
    with raises(KeyError):
        t['b']
    assert t.get('foo:a') == 'A'
    assert t.get('foo:b') == 'B'
    assert t.get('a') is None
    assert t.get('b') is None
    t.update(dict(c='C'))
    t.update(dict(c='C'), namespace='foo:bar')
    assert t['foo:bar:c'] == 'C'

# Generated at 2022-06-21 22:20:52.078903
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'a': {'b': {'c': {'d': {'e': 1}}}}} )
    assert t['a:b:c:d:e'] == 1


# Generated at 2022-06-21 22:20:58.931933
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'foo:bar', 'baz')
    assert test_dict['foo']['bar'] == 'baz'



# Generated at 2022-06-21 22:21:06.844802
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg1 = RegistryTree()
    reg2 = RegistryTree({'a': 'b'})
    reg3 = RegistryTree(reg1)
    reg4 = RegistryTree(initial_is_ref=reg1)

    reg1.register('test', 'aaa')
    assert reg3.get('test') == 'aaa'
    assert reg4.get('test') == 'aaa'



# Generated at 2022-06-21 22:21:14.005370
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 1
    t['a']['b']['d'] = 2
    t['a']['e'] = 3
    t['a']['f']['g'] = 4
    t['a']['f']['h'] = 5

    assert get_tree_node(t, 'a:b:d') == 2
    assert get_tree_node(t, 'a:b') == {'c': 1, 'd': 2}
    assert get_tree_node(t, 'a', default=_sentinel) == {'b': {'c': 1, 'd': 2}, 'e': 3, 'f': {'g': 4, 'h': 5}}
    with pytest.raises(KeyError):
        get

# Generated at 2022-06-21 22:21:22.054583
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pformat
    tree = Tree(namespace='foo')
    tree.register('bar', 'baz')
    tree.register('bar', 'boz')
    tree.register('foo', 'far')
    assert pformat(tree) == r"{'foo': {'bar': ['baz', 'boz'], 'far': 'far'}}"

# Generated at 2022-06-21 22:21:33.823980
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 'Hello'
    assert t['a']['b']['c'] == 'Hello'

    t = tree()
    t['a']['b']['c']['d']['e']['f']['g']['h']['i']['j']['k']['l']['m']['n']['o']['p'] = 'Hello'
    assert t['a']['b']['c']['d']['e']['f']['g']['h']['i']['j']['k']['l']['m']['n']['o']['p'] == 'Hello'

# Generated at 2022-06-21 22:21:36.295628
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test for function set_tree_node"""
    test_dict = {}
    set_tree_node(test_dict, 'foo', 'bar')
    assert test_dict['foo'] == 'bar'



# Generated at 2022-06-21 22:21:45.906310
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree[':'] = ':_value'
    assert tree[':'] == ':_value'
    tree['A'] = 'A_value'
    assert tree['A'] == 'A_value'
    tree['A:A1'] = 'A:A1_value'
    assert tree['A:A1'] == 'A:A1_value'
    tree['A:A1:A1A'] = 'A:A1:A1A_value'
    assert tree['A:A1:A1A'] == 'A:A1:A1A_value'
    tree['B'] = 'B_value'
    assert tree['B'] == 'B_value'
    tree['B:B1'] = 'B:B1_value'

# Generated at 2022-06-21 22:21:52.725626
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree(initial={
        'a': 7,
        'b': {
            'c': 3,
        }
    })

    assert t['a'] == 7
    assert t['b:c'] == 3

    assert t.get('a') == 7
    assert t.get('b:c') == 3
    assert t.get('e') == t.get('e', None) is None



# Generated at 2022-06-21 22:21:59.388833
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    assert t.namespace == ''
    t.namespace = 'main'
    assert t.namespace == 'main'

    t['foo'] = 'bar'
    assert t['foo'] == 'bar'

    t['bar'] = 'baz'
    assert t['bar'] == 'baz'

    t['dee'] = Tree('dum')
    assert t['dee']['dum']
    assert t['dee'] == 'dum'

    t['dee:dum'] = 'dum'

# Generated at 2022-06-21 22:22:10.471941
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    >>> test_get_tree_node()
    {'list': [1, 2, 3], 'dict': {'nested': 'dict'}, 'str': 'string'}
    {'list': [1, 2, 3], 'dict': {'nested': 'dict'}}
    ['list', 'dict', 'nested']
    """
    t = {
        'list': [1, 2, 3],
        'dict': {
            'nested': 'dict'
        },
        'str': 'string'
    }

    print(get_tree_node(t, 'dict:nested'))
    print(get_tree_node(t, 'dict:nested', parent=True))
    print(get_tree_node(t, 'dict:nested', parent=True, default=[]))



# Generated at 2022-06-21 22:22:25.201004
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo'] = 'bar'

    assert t['foo'] == 'bar'
    assert get_tree_node(t, 'foo') == 'bar'
    assert get_tree_node(t, 'foo', default='baz') == 'bar'

    with pytest.raises(KeyError):
        get_tree_node(t, 'bar')
    assert get_tree_node(t, 'bar', default='baz') == 'baz'
    assert get_tree_node(t, 'bar', default='baz', parent=True) == t

    s = t['running:stats'] = {}
    t['running:stats']['a'] = 'b'
    assert t['running:stats:a'] == 'b'

# Generated at 2022-06-21 22:22:33.665303
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': {
                            'f': 'foo'
                        }
                    }
                }
            }
        }
    }

    assert 'foo' == get_tree_node(tree, 'a:b:c:d:e:f')
    assert 'foo' == get_tree_node(tree, 'a:b:c:d:e:f')
    assert tree['a'] == get_tree_node(tree, 'a:b:c:d:e:f', parent=True)

    # Test default value
    assert 'bar' == get_tree_node(tree, 'a:b:c:d:e:z', default='bar')

    # Test KeyError

# Generated at 2022-06-21 22:22:35.471550
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    assert tree.__class__.__name__ == 'RegistryTree'



# Generated at 2022-06-21 22:22:42.388008
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    test_tree['a']['b']['c'] = 'd'
    set_tree_node(test_tree, 'a:b:c', 'd')
    set_tree_node(test_tree, 'a:b:c:d:e:f', 'g')
    assert test_tree['a']['b']['c'] == 'd'
    assert test_tree['a']['b']['c']['d']['e']['f'] == 'g'



# Generated at 2022-06-21 22:22:53.222177
# Unit test for function tree
def test_tree():
    # test tree
    data = tree()
    data['a']['b']['c'] = 'd'
    data['a']['b']['d'] = 'e'
    data['a']['f'] = 'g'
    data['a']['f']['h'] = 'i'
    data['a']['j']['k']['l']['m']['n']['o']['p'] = 'q'

    # test get_tree_node & set_tree_node
    assert data['a']['b']['c'] == 'd'
    assert data['a']['b']['d'] == 'e'
    assert data['a']['f'] == 'g'
    assert data['a']['f']['h']

# Generated at 2022-06-21 22:23:01.307382
# Unit test for function get_tree_node
def test_get_tree_node():
    from collections import OrderedDict

    assert get_tree_node({}, 'a:b:c:d', default=None) == None
    assert get_tree_node(OrderedDict(a=OrderedDict(b=OrderedDict(c=OrderedDict(d='d')))), 'a:b:c:d') == 'd'
    assert get_tree_node(OrderedDict(a=OrderedDict(b=OrderedDict(c=OrderedDict(d='d')))), 'a:b:c:e') == _sentinel



# Generated at 2022-06-21 22:23:10.211086
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('remoting:dict', dict)
    rt.register('remoting:defaultdict', collections.defaultdict)
    rt.register('remoting:namespace:defaultdict', collections.defaultdict)
    rt.register('remoting:namespace:tree', tree)
    rt.register('remoting:namespace:tree1', tree)
    rt.register('remoting:namespace:tree2', tree)
    rt.register('remoting:namespace:tree3', tree)
    rt.register('remoting:namespace:tree4', tree)
    # Test if namespace is added
    assert rt['remoting:dict'] == dict

    # Test if namespace is appended
    assert rt['remoting:namespace:defaultdict'] == collections.defaultdict

# Generated at 2022-06-21 22:23:15.146532
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree().namespace == None
    assert Tree(namespace='test').namespace == 'test'
    assert Tree(initial={'test': 'test'})['test'] == 'test'
    assert Tree(initial={'test': 'testtest'}, namespace='mytest')['mytest:test'] == 'testtest'



# Generated at 2022-06-21 22:23:18.101450
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(initial={'a': {'b': 'c'}})

    assert tree['a:b'] == 'c'

# Generated at 2022-06-21 22:23:28.091823
# Unit test for function tree
def test_tree():
    mytree = tree()
    mytree['foo']['bar'] = 'Baz'
    assert mytree['foo']['bar'] == 'Baz'
    mytree['foo']['boo']['bap'] = 'Bop'
    assert mytree['foo']['boo']['bap'] == 'Bop'
    assert mytree['foo']['boo'].get('zoop', default='Bop') == 'Bop'
    try:
        mytree['foo']['bar'] == 'Bap'
    except AssertionError:
        pass
    try:
        mytree['foo']['boo']['bap'] == 'Boo'
    except AssertionError:
        pass



# Generated at 2022-06-21 22:23:33.722358
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['1'] = '1'
    assert t['1'] == '1'



# Generated at 2022-06-21 22:23:43.880789
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function `set_tree_node`
    """
    # Create an empty tree
    tree = {}
    # First try: Set node
    assert set_tree_node(tree, 'a:b:c', 'value') is True
    # First try: Set node
    assert set_tree_node(tree, 'a:b:d', 'value2') is True
    # Should throw KeyError, as it doesnt exist yet
    with pytest.raises(KeyError):
        get_tree_node(tree, 'a:b:c', default=_sentinel)

    # Should return value after setting tree_node
    assert get_tree_node(tree, 'a:b:c') == 'value'

# Generated at 2022-06-21 22:23:47.348110
# Unit test for function tree
def test_tree():
    one = tree()
    one[1][1] = 'one'
    one[2][2] = 'two'
    one[3][3] = 'three'



# Generated at 2022-06-21 22:23:51.769922
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {'a': {'b': {'c': 'foo'}}}
    assert get_tree_node(test_tree, 'a:b:c') == 'foo'
    assert get_tree_node(test_tree, 'a:b:c:d', default='bar') == 'bar'


# Generated at 2022-06-21 22:23:54.708366
# Unit test for function tree
def test_tree():
    t = tree()
    t['an']['arbitrary']['key'] = 1
    assert t['an']['arbitrary']['key'] == 1



# Generated at 2022-06-21 22:23:56.781139
# Unit test for function set_tree_node
def test_set_tree_node():
    root = tree()
    set_tree_node(root, 'a:b:c', 1)
    assert root['a']['b']['c'] == 1



# Generated at 2022-06-21 22:24:01.735298
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    # Create a tree node at key 'test:test_node'
    t['test:test_node'] = True

    # Check the created tree node is set to the value True
    assert t['test:test_node'] is True, "Failed to set tree node to True"



# Generated at 2022-06-21 22:24:05.927131
# Unit test for constructor of class Tree
def test_Tree():
    expected = {
        'key': {
            'subkey': 'valu 123',
        },
    }
    tree = Tree(initial={
        'key': {
            'subkey': 'valu 123',
        },
    })
    assert tree == expected



# Generated at 2022-06-21 22:24:08.277193
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'



# Generated at 2022-06-21 22:24:10.019247
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Tests for Tree.setitem"""
    import pytest
    tree = Tree()
    tree['test'] = 'test_value'
    assert tree['test'] == 'test_value', "Set item is not set properly"



# Generated at 2022-06-21 22:24:25.690200
# Unit test for function tree
def test_tree():
    t = tree()
    t['hello']['world']['one'] = 1
    t['hello:world:two'] = 2
    t['hello']['world']['three'] = 3
    assert t['hello:world:one'] is 1
    assert t['hello:world:two'] is 2
    assert t['hello:world:three'] is 3
    assert t['hello:world:four'] is None
    assert get_tree_node(t, 'hello:world:one') is 1
    assert get_tree_node(t, 'hello:world:two') is 2
    assert get_tree_node(t, 'hello:world:three') is 3
    assert get_tree_node(t, 'hello:world:four') is None


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-21 22:24:35.487921
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    # Test of assertion TypeError
    try:
        tree.__setitem__(1, 1)
    except TypeError:
        pass
    else:
        assert False, "Unable to catch the assertion"
    # Test of assertion TypeError
    try:
        tree.__setitem__("1", 1, namespace=[])
    except TypeError:
        pass
    else:
        assert False, "Unable to catch the assertion"
    # Test of assertion TypeError
    try:
        tree.__setitem__("1", {})
    except TypeError:
        pass
    else:
        assert False, "Unable to catch the assertion"
    # Test of assertion TypeError
    try:
        tree.__setitem__("1:2:3", 1)
    except TypeError:
        pass

# Generated at 2022-06-21 22:24:39.482330
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'hello':'world'})
    assert 'world' == tree.get('hello')
    assert 'world' == tree.get('hello:world')



# Generated at 2022-06-21 22:24:46.039029
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    my_registry = RegistryTree(initial={'foo': 'bar'}, namespace='com.lucj')
    assert 'foo' not in my_registry
    assert 'com.lucj:foo' in my_registry
    assert my_registry['com.lucj:foo'] == 'bar'
    assert my_registry.get('com.lucj:foo') == 'bar'
    my_registry['com.lucj:foo'] = 'baz'
    assert my_registry['com.lucj:foo'] == 'baz'
    my_registry['com.lucj:lucj:foo'] = 'bar'
    assert my_registry['com.lucj:lucj:foo'] == 'bar'

# Generated at 2022-06-21 22:24:58.005324
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    print(t)
    t.register('a')
    print(t)
    t.register('a')
    print(t)
    t.register('b')
    print(t)
    t.register('b')
    print(t)
    t.register('a', 'c')
    print(t)
    t.register('a', 'd')
    print(t)
    t.register('b', 'f')
    print(t)
    t.register('b', 'g')
    print(t)
    t.register('h', 'i')
    print(t)
    t.register('h', 'j')
    print(t)
    t.register('h', 'k')
    print(t)

    t.register('foo', 'bar')


# Generated at 2022-06-21 22:25:08.875901
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'unicorns': {
            'dreaming': 'wooooo',
            'awake': 'pfft'
        }
    }
    assert get_tree_node(test_tree, 'unicorns:awake') == 'pfft'
    assert get_tree_node(test_tree, 'unicorns:dreaming') == 'wooooo'
    assert get_tree_node(test_tree, 'unicorns:not_a_key') is _sentinel
    assert get_tree_node(test_tree, 'unicorns:not_a_key', default='rainbows') == 'rainbows'
    assert get_tree_node(test_tree, 'unicorns:not_a_key', parent=True) == test_tree['unicorns']



# Generated at 2022-06-21 22:25:16.123980
# Unit test for function tree
def test_tree():
    t = tree()
    t['hello']['world']['how']['are']['you']['today'] = 'good'
    assert t['hello:world:how:are:you']['today'] == 'good'
    t['hello:world:how:are']['you:today'] = 'bad'
    assert t['hello:world:how']['are:you:today'] == 'bad'



# Generated at 2022-06-21 22:25:19.313268
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'level1': {'level2': {'level3': {'level4': 5}}}})
    assert tree['level1:level2:level3:level4'] == 5

# Generated at 2022-06-21 22:25:29.073028
# Unit test for constructor of class Tree
def test_Tree():
    d = Tree({'a': {'b': {'c': 'd'}}})
    assert d['a:b:c'] == 'd'
    assert d['a:b'] == {'c': 'd'}
    assert d['a'] == {'b': {'c': 'd'}}

    d = Tree(initial_is_ref=True, initial=d)
    assert d['a:b:c'] == 'd'
    assert d['a:b'] == {'c': 'd'}
    assert d['a'] == {'b': {'c': 'd'}}
    d['a:b:c'] = 'e'
    assert d['a:b:c'] == 'e'
    assert d['a:b'] == {'c': 'e'}
    assert d['a']

# Generated at 2022-06-21 22:25:32.396154
# Unit test for function tree
def test_tree():
    import pprint
    t = tree()
    t['a']['b'] = 1
    t['a']['c'] = 2
    pprint.pprint(t)



# Generated at 2022-06-21 22:25:45.936695
# Unit test for constructor of class Tree
def test_Tree():
    """
    Tests:
        tree()
        tree(initial={'a': 1, 'b': 2})
        Tree()
        Tree(initial={'a': 1, 'b': 2})
    """
    # The tree test
    t = tree()
    t['b'] = 2
    t['b:c'] = 5
    t['b:c']['d'] = 8
    t['b']['a'] = 9

    assert t == {'b': {'c': {'d': 8}, 'a': 9}}

    # Same thing but with passing an initial dict
    t = tree(initial={'a': 1, 'b': 2})
    assert t == {'b': 2, 'a': 1}

    # Same unit tests as above, but using the Tree class.
    t = Tree()

# Generated at 2022-06-21 22:25:49.119438
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Unit tests, should do some of these at some point.
    """
    tree = Tree()
    tree['root:child:leaf'] = 'foo'
    assert tree['root:child:leaf'] == 'foo'



# Generated at 2022-06-21 22:25:56.710851
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = dict(foo=dict(bar=dict(baz=1)))
    assert get_tree_node(mapping, 'foo:bar:baz') == 1
    assert get_tree_node(mapping, 'foo:bar:baz', default=None) == 1
    assert get_tree_node(mapping, 'foo:bar:baz2', default=None) is None
    assert get_tree_node(mapping, 'foo:bar:baz2') == mapping['foo']['bar']['baz2']



# Generated at 2022-06-21 22:25:58.405461
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register('spam', 43.0)

    assert r.get('spam') == 43.0

# Generated at 2022-06-21 22:26:03.504190
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():

    t = Tree()

    t['a:b:c'] = 1
    t['d:e'] = 2

    assert t['a:b:c'] == 1
    assert t['d:e'] == 2



# Generated at 2022-06-21 22:26:13.040525
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from nose.tools import eq_

    tree = Tree({'a': {'b': {'c': 10}}})
    eq_({'a': {'b': {'c': 10}}}, tree)
    eq_(10, tree['a:b:c'])
    eq_(10, tree['a', 'b', 'c'])
    eq_(10, tree.get('a:b:c'))
    eq_({'b': {'c': 10}}, tree['a:b'])
    eq_({'b': {'c': 10}}, tree['a', 'b'])
    eq_({'a': {'b': {'c': 10}}}, tree)
    eq_({'c': 10}, tree['a:b:c:'])

# Generated at 2022-06-21 22:26:23.473124
# Unit test for function get_tree_node
def test_get_tree_node():
   
    # Create a registry to hold all global variables
    registry = RegistryTree()
    registry.register('chain_of_supervision:boss:name', 'John')
    registry.register('chain_of_supervision:boss:email', 'john@example.com')
    registry.register('chain_of_supervision:boss:phone_number', '123123123')
    registry.register('chain_of_supervision:boss:address:street', 'Main Street')
    registry.register('chain_of_supervision:boss:address:postal_code', '8000')
    registry.register('chain_of_supervision:boss:address:city', 'Aalborg')
    registry.register('chain_of_supervision:boss:address:country', 'Denmark')
    
    # Checking whether we can get a single node in the tree


# Generated at 2022-06-21 22:26:28.716615
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_tree = Tree()
    test_tree['monkey'] = 'banana'
    test_tree['sneeze'] = 'tissue'
    assert test_tree['monkey'] == 'banana'
    assert test_tree['sneeze'] == 'tissue'
    test_tree['banana'] = {'monkey': 'sneeze'}
    assert test_tree['banana:monkey'] == 'sneeze'
    assert test_tree['banana'] == {'monkey': 'sneeze'}



# Generated at 2022-06-21 22:26:31.921147
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={'test': '0', 'test:foo': '0'}, namespace='test')
    assert t['foo'] == '0'
    assert t['test:foo'] == '0'
    assert t.namespace == 'test'

# Generated at 2022-06-21 22:26:42.552647
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test for function `set_tree_node`
    """

# Generated at 2022-06-21 22:27:04.046757
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    my_tree = Tree()
    my_tree['a']['b']['c']['d']['e'] = 'eurgh'
    my_tree['a']['b']['c']['d']['f'] = 'feurgh'
    my_tree['a']['b']['c']['d']['g'] = 'geurgh'

    assert my_tree['a']['b']['c']['d'] == {'e': 'eurgh', 'f': 'feurgh', 'g': 'geurgh'}
    assert my_tree['a']['b']['c'] == {'d': {'e': 'eurgh', 'f': 'feurgh', 'g': 'geurgh'}}
    assert my_tree['a']

# Generated at 2022-06-21 22:27:07.512076
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert rt.namespace is None, "Tree.namespace should default to None"
    assert not rt, "RegistryTree should default to empty, initializing as an empty dictionary"

# Generated at 2022-06-21 22:27:10.685722
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    key = 'foo:bar:baz'
    value = 'baz'

    set_tree_node(mapping, key, value)

    assert mapping['foo']['bar']['baz'] == value



# Generated at 2022-06-21 22:27:13.369418
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    assert Tree().__setitem__("key1:key2","value") == {'key1': {'key2': 'value'}}

# Generated at 2022-06-21 22:27:18.014010
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['psychic:crystal ball:the future'] = 'tomorrow'
    assert t['psychic:crystal ball']['the future'] == 'tomorrow'
    t = Tree()
    t['psychic:crystal ball']['the future'] = 'tomorrow'
    assert t['psychic:crystal ball']['the future'] == 'tomorrow'


# Generated at 2022-06-21 22:27:21.877067
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test function `set_tree_node`."""
    test_tree = {}
    test_key = 'rofl:mao:python:rocks'
    test_value = 'Yes'
    set_tree_node(test_tree, test_key, test_value)
    assert test_tree['rofl']['mao']['python']['rocks'] == test_value



# Generated at 2022-06-21 22:27:30.819204
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['a'] = 1
    tree['b'] = 2
    tree['c'] = {'d': 3}
    assert tree['a'] == 1
    assert tree['b'] == 2
    assert tree['c:d'] == 3
    assert tree.get('c:d') == 3
    assert tree.get('e') is None
    tree['non_existent:dimension'] = 123
    assert tree['non_existent:dimension'] == 123



# Generated at 2022-06-21 22:27:32.589529
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'foo:bar', 'baz')
    assert data['foo']['bar'] == 'baz'



# Generated at 2022-06-21 22:27:43.596643
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.update({"a": "b"})
    t.__setitem__("c:d", "e")
    print(t["a"])
    print(t["c:d"])


if __name__ == '__main__':
    test_Tree___setitem__()
    res = RegistryTree(initial={'a': 'b'})
    res.register('a:b', 'f')
    print(res)
    print(res.get('a:b'))
    res = RegistryTree(initial=[{'a': 'b'}], initial_is_ref=True)
    print(res[0])
    print(id(res[0]))
    print(id(res[0]))
    print(res[0])
    res = RegistryTree()

# Generated at 2022-06-21 22:27:54.473581
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.namespace = 'namespace'
    r.register('module1:submodule1:submodule2:submodule3:submodule4:submodule5', 'submodulelevel5')
    r.register('module1:submodule1:submodule2:submodule3:submodule4', 'submodulelevel4')
    r.register('module1:submodule1:submodule2:submodule3', 'submodulelevel3')
    r.register('module1:submodule1:submodule2', 'submodulelevel2')
    r.register('module1:submodule1', 'submodulelevel1')
    r.register('module1', 'module1')
    r.register('module2', 'module2')