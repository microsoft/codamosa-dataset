

# Generated at 2022-06-26 02:49:17.530785
# Unit test for function get_tree_node
def test_get_tree_node():
    # Simple test case
    assert False
    assert get_tree_node(var_0, u'foo:bar') == None


# Generated at 2022-06-26 02:49:19.634971
# Unit test for function get_tree_node
def test_get_tree_node():
    instance = test_case_0()
    assert instance.get_tree_node(mapping, key) == "Not Yet Implemented"


# Generated at 2022-06-26 02:49:31.006362
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test with a simple key
    var_0 = tree()
    var_0['a']['b']['c'] = tree()
    var_0['a']['b']['c']['d'] = 'e'
    var_0['a']['b']['g'] = 5

    var_1 = var_0['a']['b']['g']

# Generated at 2022-06-26 02:49:37.623212
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = 'a'
    var_2 = 'b'
    var_3 = 'c'
    var_4 = "a:b:c"
    var_5 = 1
    var_6 = 'a'
    var_7 = 'b'
    var_8 = 'c'
    var_9 = "a:b:c"
    var_10 = True
    set_tree_node(var_0, var_4, var_5)
    set_tree_node(var_0, var_9, var_10)
    assert get_tree_node(var_0, var_4) == 1

# Generated at 2022-06-26 02:49:45.135289
# Unit test for function get_tree_node
def test_get_tree_node():
    # Init var
    var_0 = tree()
    # Call function
    var_1 = get_tree_node(var_0, 'a:b:c:d')
    # Check
    assert(var_1 == {})
    # Check default
    var_2 = get_tree_node(var_0, 'a:b:c:d', default='foo')
    assert(var_2 == 'foo')



# Generated at 2022-06-26 02:49:48.593078
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, 'foo', 'bar')
    var_1 = var_0['foo']



# Generated at 2022-06-26 02:49:57.411353
# Unit test for function set_tree_node
def test_set_tree_node():
    from collections import defaultdict
    my_tree = defaultdict(tree)
    set_tree_node(my_tree, 'a:b:c', 'foo')

    assert( my_tree['a']['b'] == 'foo' )

    my_tree['a']['b'] = 'bar'
    set_tree_node(my_tree, 'a:b:c', 'baz')

    assert( my_tree['a']['b'] == 'baz' )

    set_tree_node(my_tree, 'a:b:c:d:e:f', 'foobar')

    assert( my_tree['a']['b'] == 'foobar' )


# Generated at 2022-06-26 02:49:59.862810
# Unit test for function get_tree_node
def test_get_tree_node():
    foo = tree()
    foo['user']['name'] = 'John Doe'
    foo['user']['address'] = 'No Street 666'
    foo['user']['phone'] = '+1 234 5678'
    foo['user']['dos']['donts']['dos and donts']['dos and donts'] = 'my brain hurts'
    print(foo)


# Generated at 2022-06-26 02:50:02.043898
# Unit test for function get_tree_node
def test_get_tree_node():
    assert_equal(get_tree_node(var_0, 'key') == _sentinel, True)


# Generated at 2022-06-26 02:50:12.290013
# Unit test for function set_tree_node
def test_set_tree_node():
    import tempfile
    import os
    import errno


# Generated at 2022-06-26 02:50:17.535270
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = {}
    set_tree_node(var_0, 'a:b', False)
    print(var_0['a']['b'])


# Generated at 2022-06-26 02:50:21.815275
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = set_tree_node(var_0, "b:bee", "buh")
    var_2 = set_tree_node(var_0, "b:bee", "buh")
    assert var_2 is not None
    assert var_1 == var_2



# Generated at 2022-06-26 02:50:28.279769
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    if var_0 is None:
        raise ValueError('var_0 must be defined')
    set_tree_node(var_0, 'get', 'help')
    if var_0 is None:
        raise ValueError('var_0 must be defined')
    if get_tree_node(var_0, 'get') is not 'help':
        raise ValueError('var_0 must be defined')


# Generated at 2022-06-26 02:50:33.207214
# Unit test for function get_tree_node
def test_get_tree_node():
    # Assumes the existence of a tree called `var_0`
    node = get_tree_node(var_0, 'w')
    assert node == {'x': {'y': 'z'}}

    node = get_tree_node(var_0, 'w:x')
    assert node == {'y': 'z'}

    node = get_tree_node(var_0, 'w:x:y')
    assert node == 'z'

    with pytest.raises(KeyError):
        get_tree_node(var_0, 'w:x:y:q')


# Generated at 2022-06-26 02:50:41.687162
# Unit test for function get_tree_node
def test_get_tree_node():
    # Get
    assert(get_tree_node(var_0['a']['b']['c'], 'a:b:c') == {})

    # Set
    assert(get_tree_node(var_0['a']['b']['c']['d'], 'a:b:c:d', value='test') == 'test')
    assert(var_0['a']['b']['c']['d'] == 'test')

    # Set, with invalid path
    assert(get_tree_node(var_0['a']['b']['c'], 'a:b:c:d:y', value='test') == 'test')
    assert(var_0['a']['b']['c']['d']['y'] == 'test')

    #

# Generated at 2022-06-26 02:50:43.354154
# Unit test for function get_tree_node
def test_get_tree_node():
    try:
        test_case_0()
        assert True
    except:
        assert False
    return



# Generated at 2022-06-26 02:50:50.008491
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    assert var_0.get_tree_node(var_0, '1', default=_sentinel) is _sentinel
    assert var_0.get_tree_node(var_0, '1', '2', parent=True) == ''
    assert var_0.get_tree_node(var_0, '1', default=_sentinel) is _sentinel


# Generated at 2022-06-26 02:50:52.245157
# Unit test for function get_tree_node
def test_get_tree_node():
    t = Tree()
    t['a:b:c'] = 'dd'
    assert t['a:b:c'] == 'dd'
    assert t['b:d'] is None

# Generated at 2022-06-26 02:51:05.285576
# Unit test for function get_tree_node
def test_get_tree_node():
    assert '{}' == json.dumps(get_tree_node(var_0, 'foo', default='bar'))
    assert '{}' == json.dumps(get_tree_node(var_0, 'foo', default='bar'))
    assert '{}' == json.dumps(get_tree_node(var_0, 'foo', default='bar'))
    assert '{}' == json.dumps(get_tree_node(var_0, 'foo', default='bar'))
    assert '{}' == json.dumps(get_tree_node(var_0, 'foo', default='bar'))
    assert '{}' == json.dumps(get_tree_node(var_0, 'foo', default='bar'))

# Generated at 2022-06-26 02:51:18.076079
# Unit test for function get_tree_node
def test_get_tree_node():
    # Init 
    var_0 = tree()
    var_0['foo']['bar'] = 123
    var_0['foo']['baz'] = {'quux': 'quuux'}

    # Test
    assert get_tree_node(var_0, 'foo:bar') == 123

    # Test
    assert get_tree_node(var_0, 'foo:baz:quux') == 'quuux'



# Generated at 2022-06-26 02:51:27.567350
# Unit test for function get_tree_node
def test_get_tree_node():
    try:
        assert(get_tree_node({}, 'a') == _sentinel)
    except:
        pass

    try:
        assert(get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c')
    except:
        pass

    try:
        assert(get_tree_node({'a': {'b': 'c'}}, 'a:b', default=None) == 'c')
    except:
        pass

    try:
        assert(get_tree_node(var_0, 'a', default=None) is None)
    except:
        pass

    try:
        assert(get_tree_node({'a': {'b': 'c'}}, 'a:b', default=None) == 'c')
    except:
        pass



# Generated at 2022-06-26 02:51:28.025958
# Unit test for function get_tree_node
def test_get_tree_node():
    pass

# Generated at 2022-06-26 02:51:39.313078
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    set_tree_node(d, "a", 1)
    assert d["a"] == 1
    set_tree_node(d, "a:b:c:d", 1)
    assert d["a"]["b"]["c"]["d"] == 1
    try:
        set_tree_node(d, "a:b:c", 2)
    except TypeError:
        pass
    else:
        assert False
    set_tree_node(d, "a:b:c:d:e:f:g", 1)
    assert d["a"]["b"]["c"]["d"]["e"]["f"]["g"] == 1

# Generated at 2022-06-26 02:51:48.895386
# Unit test for function get_tree_node
def test_get_tree_node():
    err_msg = 'Tree parsing error, could not parse `{}`'
    assert get_tree_node(test_case_0, 'a') == 'b', err_msg.format('a')
    assert get_tree_node(test_case_0, 'a:c') == 'd', err_msg.format('a:c')
    assert get_tree_node(test_case_0, 'a:c:e') == 'f', err_msg.format('a:c:e')
    assert get_tree_node(test_case_0, 'a:c:e:g') == 'h', err_msg.format('a:c:e:g')

# Generated at 2022-06-26 02:51:52.710621
# Unit test for function set_tree_node
def test_set_tree_node():
    assert tree() == {}
    assert tree({'a': {'a': {'a': 1}}}) == {'a': {'a': {'a': 1}}}
    assert tree({'a': {'a': {'a': 1}}}, initial_is_ref=True) == {'a': {'a': {'a': 1}}}


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:52:00.553075
# Unit test for function set_tree_node
def test_set_tree_node():
  print("Test set_tree_node")
  var_0 = tree()
  set_tree_node(var_0, ":a:b:c:d:e:f:g:h:i:j:k:l", "abcdefghijkl")
  assert var_0["a"]["b"]["c"]["d"]["e"]["f"]["g"]["h"]["i"]["j"]["k"]["l"] == "abcdefghijkl"


# Generated at 2022-06-26 02:52:07.786915
# Unit test for function get_tree_node
def test_get_tree_node():
    # Variables
    var_0 = {'a': {'b': {'c': 'A'}}}
    var_1 = 'a:b:c'
    var_2 = _sentinel
    var_3 = False

    # Begin of test

# Generated at 2022-06-26 02:52:11.088526
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 'hi' == get_tree_node({'hi': {'my': 'name'}, 'name': 'is', 'is': 'bob'}, 'hi:my')
    assert get_tree_node({'hi': {'my': 'name'}, 'name': 'is', 'is': 'bob'}, 'hi:me') is _sentinel


# Generated at 2022-06-26 02:52:20.496109
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test function: get_tree_node"""
    num_errors = 0
    var_1 = tree()
    var_1['var_2:var_3']['var_4'] = 'harbinger'
    var_5 = get_tree_node(var_1, 'var_2:var_3', default=_sentinel)
    var_6 = {
        'var_4': 'harbinger'
    }
    if (var_5 != var_6):
        num_errors += 1
        dflt_str = ':'.join(map(str, (var_5, var_6)))
        print('Expected: {0}'.format(repr(var_6)))
        print('Received: {0}'.format(repr(var_5)))



# Generated at 2022-06-26 02:52:31.008162
# Unit test for function get_tree_node
def test_get_tree_node():
    test = {
        'a': {
            'b': [1, 2, 3],
            'c': 'Hello',
            'd': {
                'e': {
                    'f': 'Goodbye'
                }
            }
        }
    }

    assert get_tree_node(test, 'a:b') == [1, 2, 3]
    assert get_tree_node(test, 'a:c') == 'Hello'
    assert get_tree_node(test, 'a:d:e:f') == 'Goodbye'
    assert get_tree_node(test, 'a:c:d') is None
    assert get_tree_node(test, 'a:d:e:f', 'peekaboo') == 'peekaboo'


# Generated at 2022-06-26 02:52:47.509492
# Unit test for function set_tree_node
def test_set_tree_node():
    import pytest
    from random import randint
    from random import seed
    from random import choice
    
    for _ in range(100):
        seed(randint(1, 100))
        m = {randint(0, 100): choice(['a', 'b', 'D', 'z']) for _ in range(10) if _ is not 0}
        s = choice([True, False])
        t = tree()
        for i in m:
            set_tree_node(t, str(i), m[i])
        m = set_tree_node(t, str(i), m[i])
        assert t == m
        


# Generated at 2022-06-26 02:52:50.843754
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(var_0, 'spam:eggs', 'foo'), var_0
    return None


# Generated at 2022-06-26 02:53:00.409545
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = tree()
    var_1['a']['b']['c'] = 'testing'
    var_1['a']['b']['d'] = 'testing'
    var_1['a']['b']['e'] = 'testing'
    set_tree_node(var_1['a'], 'b:f', 'testing')
    assert get_tree_node(var_1['a'], 'b:c', default=None) == 'testing'
    assert get_tree_node(var_1['a'], 'b:f', default=None) == 'testing'
    assert get_tree_node(var_1['a'], 'b:g', default=None) is None


# Generated at 2022-06-26 02:53:04.877016
# Unit test for function get_tree_node
def test_get_tree_node():
    var_a = tree()
    var_a['a']['b']['c']['d']['e'] = 42
    assert get_tree_node(var_a, 'a:b:c:d:e') == 42


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:53:11.886476
# Unit test for function get_tree_node
def test_get_tree_node():
    input0 = ["d:f", {'z': 12}]
    expected_output = 12
    output0 = get_tree_node(*input0)
    assert output0 == expected_output

    # Put your own custom tests here if you want
    # (you'll also need to add your custom test cases to the list below)
    input1 = ["d:f", {'z': 12}]
    expected_output = 12
    output1 = get_tree_node(*input1)
    assert output1 == expected_output

    input2 = ["d:f", {'z': 12}]
    expected_output = 12
    output2 = get_tree_node(*input2)
    assert output2 == expected_output

    input3 = ["d:f", {'z': 12}]
    expected_output = 12
    output3

# Generated at 2022-06-26 02:53:16.987905
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    key = '0:1:2:3'
    value = "pwnfunc"
    parent_node = set_tree_node(mapping, key, value)

# Generated at 2022-06-26 02:53:25.502742
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert 'd' == get_tree_node(tree, 'a:b:c')
    assert 'c' == get_tree_node(tree, 'a:b', parent=True)
    assert 'a' == get_tree_node(tree, 'a:b', parent=True, parent=True)
    assert 'a' == get_tree_node(tree, 'a', parent=True)

    with pytest.raises(KeyError):
        get_tree_node(tree, 'non::existent')
    assert 'default' == get_tree_node(tree, 'non::existent', default='default')

    tree = tree()

# Generated at 2022-06-26 02:53:33.619829
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['a']['b']['c'] = 1
    t['a']['b']['d'] = 2
    t['a']['c']['d'] = 3

    assert get_tree_node(t, 'a:b:c') == 1
    assert get_tree_node(t, 'a:b') == {'c': 1, 'd': 2}
    assert get_tree_node(t, 'a:d') == KeyError
    assert get_tree_node(t, 'a:c:d') == 3
    assert get_tree_node(t, 'a:c:d', default=None) == 3



# Generated at 2022-06-26 02:53:40.764310
# Unit test for function get_tree_node
def test_get_tree_node():
    try:
        assert get_tree_node(var_0, '0',)
        assert False, "Expected exception to be raised"
    except KeyError:
        pass
    assert get_tree_node(var_0, '0', default=None) is None
    assert get_tree_node(var_0, '0', default=None, parent=True) is var_0
    # Test error handling
    try:
        assert get_tree_node(var_0, '0', default=None, parent=True, )
        assert False, "Expected exception to be raised"
    except TypeError:
        pass
    assert get_tree_node(var_0, '0',) is var_0['0']
    assert get_tree_node(var_0, '0', default=None, parent=True,) is var

# Generated at 2022-06-26 02:53:51.164404
# Unit test for function set_tree_node
def test_set_tree_node():
    treenode0 = None
    treenode1 = None
    treenode2 = None
    treenode0 = tree()

    treenode1 = treenode0['a']
    # {'a':{}}
    treenode1 = treenode1['b']
    # {'a':{'b':{}}}

    treenode2 = set_tree_node(treenode0, 'a:b:c', 'd')
    # {'a':{'b':{'c':'d'}}}
    assert treenode0 == {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    assert treenode2 == {
        'c': 'd',
    }

    treenode2 = set_tree_node

# Generated at 2022-06-26 02:54:08.721745
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = "0:0:0"
    var_2 = "0"
    var_0 = set_tree_node(var_0, var_1, var_2)
    var_3 = var_0["0"]["0"]["0"] == "0"
    assert var_3


# Generated at 2022-06-26 02:54:10.036962
# Unit test for function set_tree_node
def test_set_tree_node():
    assert True
    return True



# Generated at 2022-06-26 02:54:22.047821
# Unit test for function get_tree_node
def test_get_tree_node():
    # Try to get something in an empty tree.
    tree_0 = tree()
    key_0 = "test_key"
    default_0 = "default_value"
    # Try to get something with a default value in an empty tree.
    result_0 = get_tree_node(tree_0, key_0, default_0)
    print(result_0)
    assert result_0 == default_0

    # Add a key and try to get it.
    tree_0[key_0] = "test_value"
    result_0 = get_tree_node(tree_0, key_0)
    print(result_0)
    assert result_0 == "test_value"

    # Try to get a key in a deeper dimension.

# Generated at 2022-06-26 02:54:28.262914
# Unit test for function get_tree_node
def test_get_tree_node():
    input_var_0 = tree()
    input_var_1 = 'var_0'
    expected_return_value = None
    actual_return_value = get_tree_node(input_var_0, input_var_1)
    assert actual_return_value == expected_return_value


# Generated at 2022-06-26 02:54:38.741197
# Unit test for function set_tree_node
def test_set_tree_node():
    actual_output = tree()
    initial_result = set_tree_node(actual_output, 'foo:bar', 'ham')

    expected_output = [tree(), 'ham']

    assert actual_output == expected_output

    actual_output = initial_result
    initial_result = set_tree_node({'foo': {'bar': 'ham'}}, 'foo:bar', 'spam')

    expected_output = 'ham'

    assert actual_output == expected_output
    assert initial_result == {'foo': {'bar': 'spam'}}



# Generated at 2022-06-26 02:54:46.465002
# Unit test for function set_tree_node
def test_set_tree_node():

    def test_0():
        """Example 0"""
        mapping = tree()
        key = ':a:b:c:d:e:f:g:h'
        value = 'value'
        set_tree_node(mapping, key, value)
        # assertEquals(result,
        #              )

    test_0()



# Generated at 2022-06-26 02:54:58.263552
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    assert get_tree_node(var_0, 'a', default=None) is None, 'TEST FAILED: tree:0, node:a'
    var_0['a']['b']['c']['d'] = 'asdf'
    assert get_tree_node(var_0, 'a:b:c:d', default=None) == 'asdf', 'TEST FAILED: tree:0, node:a:b:c:d'
    assert get_tree_node(var_0, 'a:b:c:d:e', default=None) is None, 'TEST FAILED: tree:0, node:a:b:c:d:e'

# Generated at 2022-06-26 02:54:59.014538
# Unit test for function get_tree_node
def test_get_tree_node():
    assert True


# Generated at 2022-06-26 02:55:00.669209
# Unit test for function get_tree_node
def test_get_tree_node():
    pass

# Generated at 2022-06-26 02:55:12.914930
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['var_0']['var_0'] = 'var_0'
    var_0['var_1']['var_1'] = 'var_1'
    var_0['var_2']['var_2']['var_2'] = 'var_2'
    var_0['var_3']['var_3']['var_3']['var_3'] = 'var_3'
    var_0['var_4']['var_4']['var_4']['var_4']['var_4'] = 'var_4'
    var_0['var_5']['var_5']['var_5']['var_5']['var_5']['var_5'] = 'var_5'

# Generated at 2022-06-26 02:55:43.075431
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0["a"]["b"]["c"] = "d"
    var_1 = var_0
    assert(type(var_1) == type(tree()))
    assert(var_1["a"]["b"]["c"] == "d")
    assert(get_tree_node(var_0, "a:b:c") == "d")
    var_1["a"]["b"]["c"] = "e"
    assert(var_1["a"]["b"]["c"] == "e")
    var_2 = var_1["a"]
    assert(type(var_2) == type(tree()))
    assert(var_2["b"]["c"] == "e")
    var_3 = var_2["b"]

# Generated at 2022-06-26 02:55:47.697620
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:55:52.226735
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['b'] = 1
    var_0['a']['c'] = 2
    var_0['d']['e'] = 3
    assert get_tree_node(var_0, 'a')['b'] == 1
    assert get_tree_node(var_0, 'a:c') == 2
    assert get_tree_node(var_0, 'd')['e'] == 3


# Generated at 2022-06-26 02:55:55.683851
# Unit test for function set_tree_node
def test_set_tree_node():
    # Check return value from function
    var_0 = set_tree_node(tree(), "var_0", var_0)


# Generated at 2022-06-26 02:55:59.438362
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(0, [0]) == _sentinel
    assert get_tree_node(0, 0, _sentinel) == _sentinel


# Generated at 2022-06-26 02:56:06.729578
# Unit test for function get_tree_node
def test_get_tree_node():
    # Notes:
    # - More tests can be added here
    # - Each test case should be easy to understand
    var_0 = tree()
    var_0['a']['b']['c'] = 1
    var_1 = 1
    assert var_0['a:b:c'] == var_1


# Generated at 2022-06-26 02:56:09.296765
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    key = ''
    default = _sentinel
    parent = False
    expected_output = '' # TODO
    test_output = get_tree_node(mapping, key, default, parent)
    assert test_output == expected_output, "Expected: %s\n Got: %s" % (expected_output, test_output)


# Generated at 2022-06-26 02:56:10.385059
# Unit test for function set_tree_node
def test_set_tree_node():
    assert True, 'unimplemented'


# Generated at 2022-06-26 02:56:13.071988
# Unit test for function get_tree_node
def test_get_tree_node():
    a = [1,2,3]
    a.append(a)
    print(a)


# Generated at 2022-06-26 02:56:22.104251
# Unit test for function get_tree_node
def test_get_tree_node():

    assert get_tree_node(tree(), 'key_1') == _sentinel
    assert get_tree_node(tree(), 'key_1', default='default_val') == 'default_val'

    tree1 = tree()
    tree1['key_1']['key_2']['key_3'] = 'value'
    assert get_tree_node(tree1, 'key_1:key_2:key_3') == 'value'
    assert get_tree_node(tree1, 'key_1:key_2:key_3', parent=True) == tree()['key_2']



# Generated at 2022-06-26 02:57:11.166835
# Unit test for function set_tree_node
def test_set_tree_node():

    # Testing arguments
    tree = {'foo': {'bar': None}}
    key = 'foo:bar'
    value = 'baz'

    # Function call
    set_tree_node(tree, key, value)

    # Validation
    assert tree == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-26 02:57:20.223372
# Unit test for function get_tree_node
def test_get_tree_node():
    print("Testing function get_tree_node")

    # Test case 1
    var_0 = tree()
    var_0['a']['b']['c'] = 1
    var_0['a']['b']['d'] = 2
    print(get_tree_node(var_0, 'a:b:c'))
    print(get_tree_node(var_0, 'x:y:z', 'a'))
    try:
        print(get_tree_node(var_0, 'x:y:z'))
    except KeyError:
        pass
    else:
        print("Test case 1 failed")


# Generated at 2022-06-26 02:57:24.321177
# Unit test for function get_tree_node
def test_get_tree_node():
    mytree = {
        'key-0': {
            'key-1': {
                'key-2': 'value-2',
            },
        },
    }

    assert get_tree_node(mytree, 'key-0:key-1:key-2') == 'value-2'



# Generated at 2022-06-26 02:57:34.111135
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test cases here
    var_0 = tree()
    assert get_tree_node(var_0, "foo")
    assert get_tree_node(var_0, "foo:bar")
    assert get_tree_node(var_0, "foo:bar:baz")
    assert get_tree_node(var_0, "foo:bar", default=None, parent=True)
    assert get_tree_node(var_0, "foo:bar:baz", default=None, parent=True)



# Generated at 2022-06-26 02:57:39.756439
# Unit test for function set_tree_node
def test_set_tree_node():

    # Pass case 0
    var_0 = {}
    set_tree_node(var_0, 'a:b:c', 'd')
    assert var_0 == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-26 02:57:41.196274
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, "a:b", "c")
    assert var_0["a:b"] == "c", "Test case failed!"


# Generated at 2022-06-26 02:57:48.354696
# Unit test for function get_tree_node
def test_get_tree_node():
    # test_case_0
    var_0 = tree()
    var_0['foo']['bar']['baz'] = 'this is a test'
    var_1 = get_tree_node(var_0, 'foo:bar:baz', default=_sentinel)
    var_2 = 'this is a test'
    if var_1 is not var_2:
        raise Exception("expected: {!r}, got {!r}", format(var_2, var_1))
    var_3 = var_0['foo']['bar']
    var_4 = get_tree_node(var_0, 'foo:bar:baz', parent=True, default=_sentinel)
    var_5 = var_3

# Generated at 2022-06-26 02:57:55.770781
# Unit test for function set_tree_node
def test_set_tree_node():
    from nose.tools import assert_equals, assert_raises
    a = {}
    set_tree_node(a, 'a:b', 'foo')
    set_tree_node(a, 'a:c', 'bar')
    set_tree_node(a, 'd', 'bar')
    assert_equals(a, {'a': {'b': 'foo', 'c': 'bar'}, 'd': 'bar'})


# Generated at 2022-06-26 02:58:02.299887
# Unit test for function get_tree_node
def test_get_tree_node():
    #
    test_case = {}
    #
    for key, value in (('a', 1), ('b:a:b:c', 2), ('b:a', 3)):
        set_tree_node(test_case, key, value)
        assert get_tree_node(test_case, key) is value



# Generated at 2022-06-26 02:58:09.089395
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = get_tree_node(var_0, ':')
    assert var_1 is var_0

    var_0[':']['abc']['def']['ghi'] = 123

    var_1 = get_tree_node(var_0, ':abc:def:ghi', default=None)
    var_2 = get_tree_node(var_0, ':abc:def:ghi', default=None)
    assert var_1 is 123
    assert var_2 is 123

    var_3 = get_tree_node(var_0, ':abc:def:ghi')
    assert var_3 is 123
