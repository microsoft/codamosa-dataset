

# Generated at 2022-06-26 02:49:24.081395
# Unit test for function get_tree_node
def test_get_tree_node():
    # Set up test objects
    test_mapping = {
        'foo': {
            'bar': {
                'baz': 1
            }
        }
    }
    test_mapping_2 = {
        'foo': {
            'bar': {
                'baz': 1,
                'qux': 2
            }
        }
    }
    test_mapping_3 = {
        'foo': {
            'bar': {
                'baz': 1,
                'qux': 2
            }
        }
    }

    # Assert
    assert get_tree_node(test_mapping, 'foo:bar:baz') == 1
    assert get_tree_node(test_mapping_2, 'foo:bar:qux') == 2

# Generated at 2022-06-26 02:49:30.421327
# Unit test for function get_tree_node
def test_get_tree_node():
    """Empty tree/dict/whatever."""
    tree_0 = Tree()
    assert get_tree_node(tree_0, 'foo') == tree_0['foo']
    assert get_tree_node(tree_0, 'foo:bar') == tree_0['foo']['bar']
    assert get_tree_node(tree_0, 'foo:bar:baz') == tree_0['foo']['bar']['baz']



# Generated at 2022-06-26 02:49:32.423685
# Unit test for function get_tree_node
def test_get_tree_node():
    my_tree = tree()
    my_tree['foo']['bar']['baz'] = 'a'
    assert get_tree_node(my_tree, 'foo:bar:baz') == 'a'



# Generated at 2022-06-26 02:49:35.170899
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    set_tree_node(tree_0, 'foo:bar:baz', 'moo')
    assert tree_0['foo']['bar']['baz'] == 'moo'



# Generated at 2022-06-26 02:49:41.062648
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Assert known-good return values for a variety of test cases.
    """
    test_mapping = {
        'flowers': {
            'blue': 'violet',
            'red': 'rose',
        }
    }
    assert get_tree_node(test_mapping, 'flowers:red') == 'rose'
    assert get_tree_node(test_mapping, 'flowers') == {'blue': 'violet', 'red': 'rose'}
    assert get_tree_node(test_mapping, 'flowers', parent=True) == test_mapping
    assert get_tree_node(test_mapping, 'flowers:red', parent=True) == {'blue': 'violet', 'red': 'rose'}

# Generated at 2022-06-26 02:49:43.947442
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_1 = Tree()
    tree_1.set_tree_node(tree_1, 'foo', 'bar')
    assert tree_1['foo'] == 'bar'


# Generated at 2022-06-26 02:49:50.581662
# Unit test for function set_tree_node
def test_set_tree_node():
    # Configure arguments and expected results
    args1 = [{}, 'a', 'b']
    args2 = [{}, 'a:b', 'c']
    args3 = [{}, 'a:b:c', 'd']
    args4 = [{}, 'a:b:c:d', 'e']
    args5 = [{}, 'g:h:j', 'k']
    expected_results = [{'a':'b'}, {'a': {'b':'c'}}, {'a': {'b': {'c':'d'}}}, {'a': {'b': {'c': {'d':'e'}}}}, {'g': {'h': {'j':'k'}}}]
    # Perform test
    results = []

# Generated at 2022-06-26 02:49:58.638648
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['foo:bar:baz'] = 'qux'
    assert get_tree_node(tree_0, 'foo:bar') == tree_0['foo']['bar']
    assert get_tree_node(tree_0, 'foo:bar:baz') == 'qux'
    assert get_tree_node(tree_0, 'foo:bar:baz', parent=True) == tree_0['foo']['bar']
    try:
        get_tree_node(tree_0, 'quux')
        assert False
    except KeyError:
        pass


# Generated at 2022-06-26 02:50:10.162882
# Unit test for function get_tree_node
def test_get_tree_node():
    print('Testing...')
    test_tree = Tree(initial=dict(cat=dict(dog=dict(human=dict(man=dict(woman='girl'))))))

    print(test_tree['cat:dog:human:man:woman'])

    test_tree['cat:dog:human:man:woman'] = 'female'
    print(test_tree['cat:dog:human:man:woman'])

    print(test_tree['cat:dog:human:man'])
    print(test_tree['cat:dog:human:man:woman:girl'])
    print(test_tree.get('cat:dog:human:man:woman:girl'))
    print(test_tree.get('cat:dog:human:man:woman:girl', 'nothing'))

    return


# Generated at 2022-06-26 02:50:20.112101
# Unit test for function get_tree_node
def test_get_tree_node():
    # Initialize test tree
    tree_1 = {
        'base': {
            'deep': {
                'deeper': {
                    'deepest': 'leaf',
                }
            }
        }
    }

    # Test basic fetching and traversal

# Generated at 2022-06-26 02:50:24.089367
# Unit test for function set_tree_node
def test_set_tree_node():
    # TODO: test here
    pass



# Generated at 2022-06-26 02:50:29.499147
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree({
        'foo': {
            'bar': 'baz',
        }
    })

    assert get_tree_node(tree_0, 'foo:bar') == 'baz'
    assert get_tree_node(tree_0, 'foo') == {'bar': 'baz'}
    assert get_tree_node(tree_0, 'foo:bar:baz') is None



# Generated at 2022-06-26 02:50:40.117886
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_node = {'key_1': {'key_2': {'key_3': {'key': 'value'}}}}
    assert get_tree_node(tree_node, 'key_1') == {'key_2': {'key_3': {'key': 'value'}}}
    assert get_tree_node(tree_node, 'key_1:key_2') == {'key_3': {'key': 'value'}}
    assert get_tree_node(tree_node, 'key_1:key_2:key_3') == {'key': 'value'}
    assert get_tree_node(tree_node, 'key_1:key_2:key_3:key') == 'value'

# Generated at 2022-06-26 02:50:43.741116
# Unit test for function set_tree_node
def test_set_tree_node():
    map1 = {}
    key1 = "Active_Job.1.JobID"
    value1 = "jid"
    set_tree_node(map1, key1, value1)
    assert map1 == {'Active_Job': {'1': {'JobID': 'jid'}}}


# Generated at 2022-06-26 02:50:53.907856
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['foo'] = 'bar'
    tree_0['prefix:foo'] = 'bar2'
    assert tree_0['foo'] == 'bar'
    assert tree_0['bar'] == tree_0.default_factory()
    assert tree_0['prefix:foo'] == 'bar2'
    assert tree_0['prefix:prefix:foo'] == tree_0.default_factory()
    assert tree_0.get('prefix:foo') == 'bar2'
    assert tree_0.get('prefix:bar') == tree_0.default_factory()
    assert tree_0.get('prefix:foo', default=1) == 'bar2'
    try:
        foo = tree_0['prefix:bar']
        assert False
    except KeyError as exc:
        pass

# Generated at 2022-06-26 02:51:05.793124
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {'a': {'aa': {'aaa': 1, 'aab': 2}, 'ab': {'aba': 3, 'abb': 4}}}
    assert get_tree_node(test_dict, 'a:aa:aaa') == 1
    assert get_tree_node(test_dict, 'a') == {'aa': {'aaa': 1, 'aab': 2}, 'ab': {'aba': 3, 'abb': 4}}
    assert get_tree_node(test_dict, 'a:ab') == {'aba': 3, 'abb': 4}
    assert get_tree_node(test_dict, 'b', default='default') == 'default'

# Generated at 2022-06-26 02:51:07.942207
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_1 = Tree()

    tree_1['foo'] = 'bar'

    assert tree_1['foo'] == 'bar'



# Generated at 2022-06-26 02:51:12.964190
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_1 = Tree()
    set_tree_node(tree_1, "key", "value")
    print(tree_1)



# Generated at 2022-06-26 02:51:24.220837
# Unit test for function get_tree_node
def test_get_tree_node():
    print("Unit test for function get_tree_node...")
    # Initialize a tree
    tree = {'root': {'child_1': 1, 'child_2': 2}, 'root_2': 3}

    # Test 1: return the root
    key = ""
    expected_value = {'child_1': 1, 'child_2': 2}
    result = get_tree_node(tree, key)
    assert expected_value == result

    # Test 2: return the child_1
    key = ":child_1"
    expected_value = 1
    result = get_tree_node(tree, key)
    assert expected_value == result

    # Test 3: return the child_2
    key = ":child_2"
    expected_value = 2

# Generated at 2022-06-26 02:51:30.958683
# Unit test for function get_tree_node
def test_get_tree_node():
    print("Testing get_tree_node")
    test = tree()
    assert get_tree_node(test, 'a') == {}
    assert get_tree_node(test, 'a:b') == {}
    assert get_tree_node(test, 'a:b', default=None) is None
    test['a']['b'] = 'x'
    assert get_tree_node(test, 'a:b') == 'x'
    assert get_tree_node(test, 'a:b', parent=True) == {'b': 'x'}
    assert get_tree_node(test, 'a:b:c') == {}
    try:
        get_tree_node(test, 'a:c')
        assert False, "Should've raised exception."
    except KeyError:
        pass

# Generated at 2022-06-26 02:51:43.201956
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_1 = Tree({'a': {'b': {'c': 'baz'}}})
    tree_2 = Tree({'a': {'b': {'c': 'baz'}}}, 'foo')
    assert get_tree_node(tree_1, 'a:b:c') == 'baz'
    with pytest.raises(KeyError):
        get_tree_node(tree_1, 'a:b:z')
    assert get_tree_node(tree_1, 'a:b:z', default='qux') == 'qux'
    assert get_tree_node(tree_1, 'a:b:c', parent=True) == {'c': 'baz'}



# Generated at 2022-06-26 02:51:44.933951
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['foo'] = 'bar'
    assert tree_0['foo'] == 'bar'
    assert tree_0['foo:bar'] == None




# Generated at 2022-06-26 02:51:54.055907
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:52:01.783682
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['one:two:three'] = 'hello'
    print(tree_0)
    print(tree_0['one:two:three'])
    assert tree_0['one:two:three'] == 'hello'
    tree_0['one']['two']['three'] = 'hello'
    assert tree_0['one:two:three'] == 'hello'
    # print(tree_0['one:two:three'])



# Generated at 2022-06-26 02:52:06.421801
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = json.loads('{"fruits": {"apple": ["red", "green", "yellow"],"banana": ["yellow"]}}')
    assert get_tree_node(test_dict, 'fruits:apple') == ["red", "green", "yellow"]


# Generated at 2022-06-26 02:52:13.454154
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test case 0
    tree_0 = {
        'a': {
            'b': {
                'c': 'd'
            },
            'e': 'f',
        },
        'g': {
            'h': 'i'
        },
        'j': 'k'
    }

    assert get_tree_node(tree_0, 'a:b:c') == 'd'
    assert get_tree_node(tree_0, 'a:b') == {'c': 'd'}
    assert get_tree_node(tree_0, 'j') == 'k'

    try:
        get_tree_node(tree_0, 'j:k')
    except KeyError:
        pass

# Generated at 2022-06-26 02:52:22.547265
# Unit test for function get_tree_node
def test_get_tree_node():

    # Create tree
    tree_0 = Tree()
    tree_0['a'] = 1
    tree_0['b'] = 2
    tree_0['c'] = 3
    tree_0['deep'] = {'d': 4, 'e': 5}
    tree_0['deep']['f'] = 6

    # --- Tests ---

    # Fetch root node
    assert tree_0 == get_tree_node(tree_0, '')

    # Fetch top-level node
    assert 1 == get_tree_node(tree_0, 'a')

    # Fetch deep node
    assert 4 == get_tree_node(tree_0, 'deep:d')

    # Attempt to fetch missing node
    fails = False

# Generated at 2022-06-26 02:52:33.059291
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_1 = {
        'a' : {
            '1' : 1,
            '2' : 2,
            '3' : {
                'a' : 1,
                'b' : 2,
            },
            '4' : {
                '5' : {
                    'c' : 3,
                    'd' : 4,
                }
            }
        }
    }

    assert get_tree_node(tree_1, 'a') == tree_1.get('a')
    assert get_tree_node(tree_1, 'a:1') == 1
    assert get_tree_node(tree_1, 'a:2') == 2
    assert get_tree_node(tree_1, 'a:3:a') == 1

# Generated at 2022-06-26 02:52:36.663471
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {}
    get_tree_node(mapping, 'p', default=_sentinel, parent=False)
    assert mapping is None
    mapping = {}
    get_tree_node(mapping, 'p', default=_sentinel, parent=True)
    assert mapping is None


# Generated at 2022-06-26 02:52:46.318255
# Unit test for function get_tree_node
def test_get_tree_node():
    '''
    Tests the get_tree_node function

    Arguments: None

    Output:
        Prints the value of node at 'key'

    '''
    mapping = {'one': {'two': {1: 100, 2: 200}}, 'zero': 'omnom'}
    key = 'one:two'
    default = 'OM NOM'
    get_tree_node(mapping, key, default)
    print("Get Tree Node: ", mapping)
    print("\n")


# Generated at 2022-06-26 02:52:56.623816
# Unit test for function get_tree_node
def test_get_tree_node():
    mytree = Tree()
    mytree['a']['b']['c'] = 1
    assert get_tree_node(mytree, 'a') == mytree['a']
    assert get_tree_node(mytree, 'a:b:c') == 1



# Generated at 2022-06-26 02:53:03.683514
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_1 = Tree({'key': 'value'})
    tree_2 = Tree({'key': {'subkey': 'subvalue'}})
    assert get_tree_node(tree_1, 'key') == 'value'
    assert get_tree_node(tree_2, 'key:subkey') == 'subvalue'



# Generated at 2022-06-26 02:53:09.450267
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    tree_0.__setitem__('foo', 'bar')
    tree_0.__setitem__('foo:bar', 'baz')
    tree_0.__setitem__('foo:foo:bar', 'qux')
    # TODO: Assert expected result.
    print(tree_0)
    # TODO: Assert expected result.
    print(tree_0.__getitem__('foo:foo:bar'))
    # TODO: Assert expected result.
    print(tree_0.__getitem__('foo:bar'))
    # TODO: Assert expected result.
    print(tree_0.__getitem__('foo'))


# Generated at 2022-06-26 02:53:20.315431
# Unit test for function get_tree_node
def test_get_tree_node():
    t_0 = Tree()
    t_0['a']['b']['c'] = 1
    t_0['a']['b']['d'] = 2
    t_0['a']['e']['f'] = 3
    t_0['a']['e']['g']['h']['i'] = 4
    t_0['g']['h']['i'] = 5

    assert get_tree_node(t_0, 'a', parent=True) is t_0
    assert get_tree_node(t_0, 'a:b:c') == 1
    assert get_tree_node(t_0, 'a:b', parent=True)['d'] == 2

# Generated at 2022-06-26 02:53:32.167764
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {'k1': {'k2': 'v2'}, 'k3': [{'k4': 'v4'}]}
    tree_1 = get_tree_node(test_dict, 'k1:k2')
    assert tree_1 == 'v2'
    tree_2 = get_tree_node(test_dict, 'k3')
    assert tree_2 == [{'k4': 'v4'}]
    tree_3 = get_tree_node(test_dict, 'k3:k4')
    assert tree_3 == 'v4'
    tree_4 = get_tree_node(test_dict, 'k1', default='v1')
    assert tree_4 == {'k2': 'v2'}

# Generated at 2022-06-26 02:53:33.760914
# Unit test for function get_tree_node
def test_get_tree_node():
    pass
    # Add some tests


# Generated at 2022-06-26 02:53:40.789395
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = Tree()
    mapping.setdefault('foo', tree())['bar'] = 'baz'
    assert get_tree_node(mapping, 'foo') == {'bar': 'baz'}
    assert get_tree_node(mapping, 'foo:bar') == 'baz'

    mapping.setdefault('foo', tree())['bar']['baz']['quux'] = 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'

    mapping = Tree(initial=tree())
    mapping.setdefault('foo', tree())['bar']['baz']['quux'] = 'qux'
    assert get_tree_node(mapping, 'foo:bar:baz:quux') == 'qux'
    assert get

# Generated at 2022-06-26 02:53:49.232581
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    tree_0.set_tree_node('name:0:1:2:3:4:5:6:7:8:9:10:11:12:13:14:15:16', 'a')
    leaf = tree_0.get_tree_node('name:0:1:2:3:4:5:6:7:8:9:10:11:12:13:14', 'a')
    assert leaf == 'a'


# Generated at 2022-06-26 02:54:00.692863
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {
        'one': {'two': {'three': 3}}
    }

    assert get_tree_node(t, 'one:two:three') == 3
    assert get_tree_node(t, 'one') == {'two': {'three': 3}}
    assert get_tree_node(t, 'one:two') == {'three': 3}
    assert get_tree_node(t, 'one:two:four', default=4) == 4

    try:
        get_tree_node(t, 'one:two:four')
    except KeyError:
        return
    assert False, 'Should have raised KeyError from get_tree_node'


# Generated at 2022-06-26 02:54:12.204756
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()

# Generated at 2022-06-26 02:54:21.577689
# Unit test for function get_tree_node
def test_get_tree_node():
    pass


# Generated at 2022-06-26 02:54:29.440718
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = tree()
    test_tree['test_1']['test_2']['test_3'] = 'test_3'
    print(test_tree)
    print(get_tree_node(test_tree, 'test_1:test_2:test_3'))
    print(get_tree_node(test_tree, 'test_1:test_2:test_3:test_4'))



# Generated at 2022-06-26 02:54:31.041491
# Unit test for function set_tree_node
def test_set_tree_node():
    test_case_0()

# Generated at 2022-06-26 02:54:40.781818
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {
            'b': {
                'c': 'd',
            },
            'e': 'f',
        },
        'g': {
            'h': 'i',
            'j': 'k',
        },
    }
    assert get_tree_node(d, 'a:b:c') == 'd'
    assert get_tree_node(d, 'a:b', default=None) == {'c': 'd'}
    assert get_tree_node(d, 'a:b', default=None, parent=True) == {'b': {'c': 'd'}}
    assert get_tree_node(d, 'a:c') is None
    assert get_tree_node(d, 'a:c', default=None) is None

# Generated at 2022-06-26 02:54:51.807840
# Unit test for function get_tree_node
def test_get_tree_node():
    """This function tests if get_tree_node() returns the correct output. """
    test_mapping = {'one': {'two': {'three': {'four': {'five': 'six'}}}}}
    # returned object
    assert get_tree_node(test_mapping, 'one') == {'two': {'three': {'four': {'five': 'six'}}}}
    assert get_tree_node(test_mapping, 'one:two:three:four:five') == 'six'
    assert get_tree_node(test_mapping, 'one:two:three:four:five', parent=True) == {'five': 'six'}

# Generated at 2022-06-26 02:55:02.307710
# Unit test for function set_tree_node
def test_set_tree_node():
    from mock import MagicMock
    import sys
    import collections

    m = collections.namedtuple('m', 'a')

    root = MagicMock(a={})
    t = MagicMock()
    set_tree_node(root, 'a:b', t)
    assert root.a['b'] is t

    root = MagicMock()
    set_tree_node(root, 'b:c:d:e:f', t)
    assert root == {'b': {'c': {'d': {'e': {'f': t}}}}}

    root = MagicMock()
    set_tree_node(root, 'b', t)
    assert root == {'b': t}

    assert sys.modules['x'] is None
    set_tree_node(sys.modules, 'x', t)


# Generated at 2022-06-26 02:55:10.225460
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node

    Returns:
        None

    Raises:
        None
    """
    treedict = {
        'John':        'John',
        'jane':        {
            'Mary':   'Jane',
            'joe':    {
                'Jim':   'joe'
            }
        },
        'Jackson':     {
            'susan':  'Jill',
            'bob':    'jack'
        }
    }

    assert get_tree_node(treedict, 'John')  == 'John'
    assert get_tree_node(treedict, 'Jane')  == { 'Mary':   'Jane', 'joe':    { 'Jim': 'joe' } }

# Generated at 2022-06-26 02:55:23.067878
# Unit test for function get_tree_node
def test_get_tree_node():
    test = Tree()

    test["1"] = "a"
    test[":foo:2"] = "b"
    test["3"] = "c"

    assert test[":foo:2"] == "b"
    assert test["2"] == "b"
    assert test.get("2") == "b"
    assert test[":foo:2"] == "b"

    # make sure the other keys are set properly
    assert test["3"] == "c"
    assert test["1"] == "a"

    # make sure that the dictionary returns the proper value when trying to access a key that is not set
    assert test.get("1000", "d") == "d"
    assert test.get("1000") is None

    # test the exception

# Generated at 2022-06-26 02:55:26.605813
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {'b': {'c': {'d': 1}}}
    assert get_tree_node(a, 'b:c') == {'d': 1}
    assert get_tree_node(a, 'b:c:d') == 1
    assert get_tree_node(a, 'b:c:d', default=None) == 1
    assert get_tree_node(a, 'b:c:e', default=None) is None



# Generated at 2022-06-26 02:55:39.266985
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test case 0
    test_tree_0 = {'a':{'b':{'c':'d'}}}

# Generated at 2022-06-26 02:56:01.142542
# Unit test for function get_tree_node
def test_get_tree_node():
    # Create test tree
    test_tree = tree()
    test_tree[ 'foo' ][ 'bar' ][ 'baz' ] = 'quux'
    # Test it works
    assert(get_tree_node(test_tree, 'foo:bar:baz') == 'quux')


# Generated at 2022-06-26 02:56:12.829749
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = tree()
    tree_0[1][1][1] = 'foo'
    tree_0[1][1][2] = 'bar'
    tree_0[2][2][2] = 'baz'

    assert get_tree_node(tree_0, '2:2:2') == 'baz'
    assert get_tree_node(tree_0, '1:1:1') == 'foo'
    assert get_tree_node(tree_0, '1:1') == {1: 'foo', 2: 'bar'}
    assert get_tree_node(tree_0, '1') == {1: {1: 'foo', 2: 'bar'}}

    # Test default

# Generated at 2022-06-26 02:56:18.623453
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree(initial={'a': 1, 'b': {'c': 2, 'd': {'e': 3}}})  # tree_0 with 2 dimensions
    assert get_tree_node(tree_0, 'b:d:e') == 3


# Generated at 2022-06-26 02:56:23.184562
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    key_0 = 'key'
    tree_0['key'] = 'value'
    value_0 = get_tree_node(tree_0, key_0)
    assert value_0 == 'value'


# Generated at 2022-06-26 02:56:31.645812
# Unit test for function get_tree_node
def test_get_tree_node():
    test_obj = {'1': 'a', '2': {'11': 'aa', '22': 'bb'}}
    assert get_tree_node(test_obj, '1') == 'a'
    assert get_tree_node(test_obj, '2:11') == 'aa'
    assert get_tree_node(test_obj, '3') is _sentinel
    assert get_tree_node(test_obj, '3', default='d') == 'd'
    try:
        get_tree_node(test_obj, '3')
    except KeyError:
        pass


# Generated at 2022-06-26 02:56:42.198503
# Unit test for function get_tree_node
def test_get_tree_node():
    from itertools import izip

    tree_0 = Tree()
    tree_0['d'] = 'value'
    assert tree_0['d'] == 'value'

    tree_0['p'] = {'d': 'value'}
    assert tree_0['p:d'] == 'value'

    assert tree_0['p:d:s'] is _sentinel
    assert tree_0.get('p:d:s') is None
    assert tree_0.get('p:d:s', 'default') == 'default'

    tree_0['p:d:s'] = 'value'
    assert tree_0['p:d:s'] == 'value'



# Generated at 2022-06-26 02:56:53.408388
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = Tree()
    test_tree.set_tree_node(test_tree, 'a:b', 0)
    assert test_tree.get('a:b') == 0
    test_tree.set_tree_node(test_tree, 'a:b:c', 1)
    assert test_tree.get('a:b')[0] == 1
    test_tree.set_tree_node(test_tree, 'a:b:c:d', 5)
    assert test_tree.get('a:b')[0][0] == 5
    test_tree.set_tree_node(test_tree, 'a:b:c:f', 3)
    assert test_tree.get('a:b')[0][1] == 3


# Generated at 2022-06-26 02:57:01.792134
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = tree()
    tree_0['test']['test_1'] = 'test_1'
    tree_0['test']['test_2'] = 'test_2'
    tree_0['test']['test_3'] = 'test_3'
    assert get_tree_node(tree_0, 'test:test_1') == 'test_1'


# Generated at 2022-06-26 02:57:08.257802
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    This test case contains test input for get_tree_node, 
    and the expected outputs.
    """

# Generated at 2022-06-26 02:57:19.848545
# Unit test for function get_tree_node
def test_get_tree_node():
    # Create test cases
    my_tree_0 = Tree({'root': {'level1': {'level2': {}}}
                      }, initial_is_ref=True)
    tkey_0 = 'root'
    tvalue_gold_0 = {'level1': {'level2': {}}}
    tkey_1 = 'root:level1:level2'
    tvalue_gold_1 = {}
    tkey_2 = 'root:level1:level2:not_here'
    tvalue_gold_2 = None

    # Run test cases and return results
    my_get_tree_node_0 = get_tree_node(my_tree_0.data, tkey_0)
    my_get_tree_node_1 = get_tree_node(my_tree_0.data, tkey_1)

# Generated at 2022-06-26 02:58:15.851833
# Unit test for function set_tree_node
def test_set_tree_node():
    my_tree = Tree()
    set_tree_node(my_tree, 'a:b:c:d', 42)
    assert my_tree['a:b:c:d'] == 42



# Generated at 2022-06-26 02:58:20.520502
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = tree()
    node = 'some-node'
    value = 'some-value'
    tree = set_tree_node(tree, node, value)
    assert value == tree[node]


# Generated at 2022-06-26 02:58:29.457805
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Get a tree node
    """
    tree_0 = {
        'foo': 'bar',
        'baz': {
            'foo': 'bar',
            'qux': {
                'corge': 'grault'
            }
        },
        'baz:qux:corge': 'grault',
        'baz:qux:corge:garply': 'grault',
    }


    test_cases = (
        ('foo', 'bar'),
        ('baz:foo', 'bar'),
        ('baz:qux:corge', 'grault'),
        ('baz:qux:corge:garply', _sentinel),
    )

    for key, expected_value in test_cases:
        actual_value = get_tree_node(tree_0, key)


# Generated at 2022-06-26 02:58:34.928850
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Tests normal operation.
    """
    d = {'grand': {'child': {'baby': 'gurgle'}}}
    assert get_tree_node(d, 'grand') == d['grand']



# Generated at 2022-06-26 02:58:36.039336
# Unit test for function get_tree_node
def test_get_tree_node():
    pass



# Generated at 2022-06-26 02:58:48.820701
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree(tree, namespace='ambit')
    tree_0['nope'] = 'yep'
    tree_0['foo'] = 'val'
    tree_0['foo'] = tree
    tree_0['foo']['bar'] = 'val'
    tree_0['foo']['bar'] = tree
    tree_0['foo']['bar']['baz'] = 'val'
    tree_0['foo']['bar']['baz'] = 'val2'

    # Test 1: Simple retrieval
    assert tree_0['foo'] == {'bar': {'baz': 'val2'}}
    # Test 2: Default retrieval
    assert tree_0.get('bar', default='nope') == 'nope'
    # Test 3: Nested retrieval
    assert tree_0

# Generated at 2022-06-26 02:59:00.398740
# Unit test for function get_tree_node
def test_get_tree_node():
    # Arrange
    tree_ = {
        'groups': {
            'group1': [1, 2, 3],
            'group2': [4, 5, 6, 7],
            'development': {
                'stage1': 'http://stage1:8080',
                'stage2': 'http://stage2:8080',
                'prod': 'http://prod:8080',
                },
            'test': 'http://test:8080',
            }
        }

    assert get_tree_node(tree_, 'groups') == tree_.get('groups')
    assert get_tree_node(tree_, 'groups:group1') == tree_.get('groups').get('group1')
    assert get_tree_node(tree_, 'groups:group2') == tree_.get('groups').get('group2')

# Generated at 2022-06-26 02:59:02.064220
# Unit test for function get_tree_node
def test_get_tree_node():
    # ...
    print('You probably want to write tests for get_tree_node()')
    assert True


# Generated at 2022-06-26 02:59:06.108132
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_1 = {
        'key1': 'value1',
        'dict': {
            'key2': 'value2',
            'key3': 'value3'
        }
    }

    assert get_tree_node(tree_1, 'dict:key2') == 'value2'
    assert get_tree_node(tree_1, 'dict:key3') == 'value3'


# Generated at 2022-06-26 02:59:16.420545
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'foo': 'bar',
        'bar': [
            'baz',
            'baz',
            'baz',
            {'baz': 'baz'}
        ],
    }
    assert 'bar' == get_tree_node(test_dict, 'foo')
    assert 'baz' == get_tree_node(test_dict, 'bar')
    assert [
        'baz',
        'baz',
        'baz',
        {'baz': 'baz'}
    ] == get_tree_node(test_dict, 'bar')
    assert 'baz' == get_tree_node(test_dict, 'bar:0')
    assert 'baz' == get_tree_node(test_dict, 'bar:1')