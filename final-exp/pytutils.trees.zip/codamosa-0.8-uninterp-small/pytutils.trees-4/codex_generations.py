

# Generated at 2022-06-26 02:49:19.884751
# Unit test for function get_tree_node
def test_get_tree_node():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:49:31.047548
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = tree()
    test_tree['foo']['bar']['baz']['deep'] = 'DEEP'
    test_tree['foo']['bar']['qux'] = 'QUX'
    test_tree['foo']['other']['no'] = 'NO'
    assert get_tree_node(test_tree, 'foo:bar:baz:deep') == 'DEEP'
    assert get_tree_node(test_tree, 'foo:bar:baz:DOES_NOT_EXIST', default=False) is False
    assert get_tree_node(test_tree, 'foo:bar:qux') == 'QUX'
    assert get_tree_node(test_tree, 'foo:other:no') == 'NO'

# Generated at 2022-06-26 02:49:38.634547
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 1,
                'd': 2,
            }
        }
    }
    assert set_tree_node(mapping, 'a:b:c', 100) == {
        'a': {
            'b': {
                'c': 100,
                'd': 2,
            }
        }
    }
    assert mapping == {
        'a': {
            'b': {
                'c': 100,
                'd': 2,
            }
        }
    }

    mapping = {
        'a': {
            'b': {
                'c': 1,
                'd': 2,
            }
        }
    }

# Generated at 2022-06-26 02:49:43.064504
# Unit test for function set_tree_node
def test_set_tree_node():
    t = Tree()
    t.set('parent', 'one:two:three:four').set('one:two:three:four', 'value set')
    assert t['parent:one:two:three:four'] == 'value set'



# Generated at 2022-06-26 02:49:49.231895
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = collections.OrderedDict((
        ('a', {
            'b': {
                'c': 'd'
            }
        }),
        ('e', {
            'f': {
                'g': 'h'
            }
        }),
    ))
    assert get_tree_node(mapping, 'e:f:g') == 'h'
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert mapping['e']['f']['g'] == 'h'
    assert mapping['a']['b']['c'] == 'd'


# Generated at 2022-06-26 02:49:59.160900
# Unit test for function get_tree_node
def test_get_tree_node():
    my_tree = {
        'foo': 'bar',
        'baz': {
            'a': 'b',
            'c_d': {
                'e': 'f',
                'g': 'h'
            }
        }
    }

    assert get_tree_node(my_tree, 'foo') == 'bar'
    assert get_tree_node(my_tree, 'baz:c_d:g') == 'h'
    assert get_tree_node(my_tree, 'baz:c_d:h') == _sentinel

    with pytest.raises(KeyError):
        get_tree_node(my_tree, 'baz:c_d:h')

    assert get_tree_node(my_tree, 'baz:c_d:h', default=_sentinel)

# Generated at 2022-06-26 02:50:02.631022
# Unit test for function get_tree_node
def test_get_tree_node():
    registry_tree = RegistryTree()
    registry_tree.register('key_0', 'value_0')
    assert registry_tree.get('key_0') == 'value_0'


# Generated at 2022-06-26 02:50:12.714594
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(tree)
    set_tree_node(tree, 'apples', 'value1')
    set_tree_node(tree, 'apples:granny_smith', 'value2')
    set_tree_node(tree, 'pears:bartlett', 'value3')
    assert get_tree_node(tree, 'apples', default=None) == 'value1'
    assert get_tree_node(tree, 'apples:granny_smith', default=None) == 'value2'
    assert get_tree_node(tree, 'pears') == {'bartlett': 'value3'}
    assert get_tree_node(tree, 'pears:bartlett') == 'value3'
    assert get_tree_node(tree, 'pears:test', default=None) is None
   

# Generated at 2022-06-26 02:50:23.536321
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    get_tree_node is a function that allows you to traverse a tree-like dict
    based on a string with the following form:
    'foo:bar:baz'
    The function will return the value at the specified location in the dict
    or raise a KeyError if the value is not found.

    Example:
    get_tree_node({'foo': {'bar': {'baz': 1}}}, 'foo:bar:baz') == 1
    """
    assert get_tree_node({'foo': {'bar': {'baz': 1}}}, 'foo:bar:baz') == 1
    assert get_tree_node({'foo': {'bar': {'baz': 1}}}, 'foo:bar') == {'baz': 1}

# Generated at 2022-06-26 02:50:24.184518
# Unit test for function get_tree_node
def test_get_tree_node():
    assert True

# Generated at 2022-06-26 02:50:30.610038
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dictionary = {}
    test_key = 'this:is:test:key'
    test_value = "test_value"
    set_tree_node(test_dictionary, test_key, test_value)

# Generated at 2022-06-26 02:50:36.483721
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({"a": {'b': 1}}, "a") == {"b": 1}
    assert get_tree_node({"a": {'b': 1}}, "a:b") == 1
    assert get_tree_node({"a": {'b': 1}}, "a:b:c") == None


# Generated at 2022-06-26 02:50:42.425773
# Unit test for function set_tree_node
def test_set_tree_node():
    registry_tree = RegistryTree(initial_is_ref=True)

    # Test 0: Test simple input
    registry_tree['test:test_0'] = True
    assert registry_tree['test:test_0'] is True

    # Test 1: Test multiple dimensions
    registry_tree['test:test_1:test_1_1'] = {'result': True}
    assert registry_tree['test:test_1:test_1_1'] == {'result': True}

    # Test 2: Test namespace works
    registry_tree.namespace = 'test_tree'
    registry_tree['test_2'] = True
    assert registry_tree['test_tree:test_2'] is True


# Generated at 2022-06-26 02:50:46.338011
# Unit test for function get_tree_node
def test_get_tree_node():
    arr = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(arr, 'a:b:c') == 'd'



# Generated at 2022-06-26 02:50:55.683263
# Unit test for function get_tree_node
def test_get_tree_node():
    # Unit test for function get_tree_node
    test_node = Tree()
    assert get_tree_node(test_node, "test", default=None) == None
    set_tree_node(test_node, "test", "test")
    assert get_tree_node(test_node, "test", default="test") == "test"
    # Fails if key not found (even if default is set)
    try:
        get_tree_node(test_node, "test_1", default=None)
    except KeyError:
        pass
    else:
        raise ValueError("KeyError not raised")

    test_node = Tree(namespace='test')
    assert get_tree_node(test_node, "test:test", default=None) == None
    test_node = Tree()

# Generated at 2022-06-26 02:51:07.350062
# Unit test for function get_tree_node
def test_get_tree_node():
    # Case 0
    mapping = {
        'foo': {
            'bar': {
                'baz': 'zab'
            }
        }
    }
    key = 'foo:bar:baz'
    result = get_tree_node(mapping, key)
    assert result == 'zab'
    # Case 1
    mapping = {
        'foo': {
            'bar': {
                'baz': 'zab'
            }
        }
    }
    key = 'foo:bar:baz'
    result = get_tree_node(mapping, key)
    assert result == 'zab'
    # Case 2
    mapping = {
        'foo': {
            'bar': {
                'baz': 'zab'
            }
        }
    }

# Generated at 2022-06-26 02:51:12.436971
# Unit test for function get_tree_node
def test_get_tree_node():
    assert(get_tree_node({'a': {'b': {'c': 3}}}, 'a:b:c') == 3)
    with py.test.raises(KeyError):
        get_tree_node({'a': {'b': {'c': 3}}}, 'a:b:d')


# Generated at 2022-06-26 02:51:23.831316
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 'foo' == get_tree_node({'a': {'b': 'foo'}}, 'a:b')
    assert None is get_tree_node({'a': {'b': 'foo'}}, 'a:b:c')
    try:
        assert None is get_tree_node({'a': {'b': 'foo'}}, 'a:b:c', default=_sentinel)
    except KeyError:
        pass
    assert {} is get_tree_node({'a': {'b': 'foo'}}, 'a:c', default={})
    try:
        assert {} is get_tree_node({'a': {'b': 'foo'}}, 'a:c', default=_sentinel)
    except KeyError:
        pass



# Generated at 2022-06-26 02:51:28.497122
# Unit test for function get_tree_node
def test_get_tree_node():
    inp = {'a': {'b': {'c': {'d': 42}}}}
    assert get_tree_node(inp, 'a:b:c:d') == 42
    assert get_tree_node(inp, 'a:b:c:d', parent=True) == {'d': 42}
    assert get_tree_node(inp, 'a:b:c:d', parent=False) == 42



# Generated at 2022-06-26 02:51:32.717149
# Unit test for function set_tree_node
def test_set_tree_node():
    # Arrange
    value = 10
    mapping = {}

    # Act
    set_tree_node(mapping, 'x1:y1:z1', value)

    # Assert
    assert mapping['x1']['y1']['z1'] == value



# Generated at 2022-06-26 02:51:41.327990
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'key:0:1', 'value')

    assert mapping['key']['0']['1'] == 'value'

    parent = set_tree_node(mapping, 'key:0:1', 'value')

    assert mapping['key']['0'] == parent



# Generated at 2022-06-26 02:51:49.931690
# Unit test for function get_tree_node
def test_get_tree_node():

    nest = {
        'a': {
            'b': {
                'c': 42
            }
        }
    }

    assert get_tree_node(nest, 'a:b:c', default=2) == 42

    try:
        get_tree_node(nest, 'a:b:d')
    except KeyError:
        pass
    else:
        assert False, "Expected KeyError"

    assert get_tree_node(nest, 'a:b:d', default=2) == 2

    try:
        get_tree_node(nest, 'a:b:c', parent=True)[2] = 1
    except KeyError:
        assert False, "Expected no KeyError"



# Generated at 2022-06-26 02:51:56.842162
# Unit test for function get_tree_node
def test_get_tree_node():
    assert set_tree_node(Tree(), 'a:b:c', 'value') == {'a': {'b': {'c': 'value'}}}
    assert set_tree_node(Tree(), 'a:b:c:d', 'value') == {'a': {'b': {'c': {'d': 'value'}}}}
    assert set_tree_node(Tree(), 'a:b:c:d', 'value') == {'a': {'b': {'c': {'d': 'value'}}}}
    assert set_tree_node(Tree(), 'a:b:c:d', 'value') == {'a': {'b': {'c': {'d': 'value'}}}}

# Generated at 2022-06-26 02:52:05.382344
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = tree()
    test_mapping['foo']['bar'] = 'lol'
    assert get_tree_node(test_mapping, 'foo:bar') == 'lol'
    assert get_tree_node(test_mapping, 'foo:bar:baz') is None
    assert get_tree_node(test_mapping, 'foo:bar:baz', parent=True) == 'lol'

    with pytest.raises(KeyError):
        get_tree_node(test_mapping, 'foo:bar:baz')


# Generated at 2022-06-26 02:52:13.123311
# Unit test for function get_tree_node
def test_get_tree_node():
    my_tree = tree()
    my_tree['a']['b']['c']['d']['e']['f']['g']['h']['i']['j']['k']['l']['n']['o'] = 1
    assert get_tree_node(my_tree, 'a:b:c:f') == {'g': {'h': {'i': {'j': {'k': {'l': {'n': {'o': 1}}}}}}}}
    assert get_tree_node(my_tree, 'a:b:c:d') == {'e': {'f': {'g': {'h': {'i': {'j': {'k': {'l': {'n': {'o': 1}}}}}}}}}}


# Generated at 2022-06-26 02:52:22.153062
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    n = {'a':1}
    n['b'] = n
    t['o']['m']['g'] = 'wtf'
    t['o']['m']['n'] = n
    assert get_tree_node(t, 'o:m:g') == 'wtf'
    assert get_tree_node(t, 'o:m:n:a') == 1
    assert get_tree_node(t, 'o:m:n:b:a') == 1
    try:
        get_tree_node(t, 'o:m:g:n')
    except KeyError:
        assert True
    else:
        assert False, "Should have raised"
    # assert get_tree_node(t, 'o:m:g:n', default='default')

# Generated at 2022-06-26 02:52:29.110942
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Verify that set_tree_node works as expected.
    """
    dict_result1 = {'blah': {'foo': {'bar': 'bar'}}}
    dict_result2 = {'foo': 'bar'}

    set_tree_node(dict_result1, 'blah:foo:bar', 'bar')

    assert dict_result1 == dict_result2, "set_tree_node fails to set the correct value in the tree."
    return True


# Generated at 2022-06-26 02:52:37.897767
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    get_tree_node(mapping, key, default=_sentinel, parent=False)

    Arguments:
        mapping collections.Mapping: Mapping to fetch from
        key str|unicode: Key to lookup, allowing for : notation
        default object: Default value. If set to `:module:_sentinel`, raise KeyError if not found.
        parent bool: If True, return parent node. Defaults to False.

    Returns:
        object: Value at specified key
    """
    # First test for correct value
    mapping = {
        'a': { 'b': { 'c': 1, 'd': 2 }},
        'x': { 'y': { 'z': 0, 'p': 5 }}
    }
    result = get_tree_node(mapping, 'a:b:c')

# Generated at 2022-06-26 02:52:43.639006
# Unit test for function set_tree_node

# Generated at 2022-06-26 02:52:50.996700
# Unit test for function set_tree_node
def test_set_tree_node():
    # Initialize the test tree
    test_tree = tree()
    assert test_tree == {}

    set_tree_node(test_tree, 'foo', 'bar')
    assert test_tree == {'foo': 'bar'}

    set_tree_node(test_tree, 'foo:hello', 'world')
    assert test_tree == {'foo': {'hello': 'world'}}

    # Check whether we can overwrite value
    set_tree_node(test_tree, 'foo:hello', 'Universe')
    assert test_tree == {'foo': {'hello': 'Universe'}}

    # Try and break it
    try:
        set_tree_node(test_tree, 'foo:hello:', 'Fails')
    except AttributeError:
        pass


# Generated at 2022-06-26 02:53:05.450777
# Unit test for function set_tree_node
def test_set_tree_node():
    dict_0 = dict()
    set_tree_node(dict_0, "path:to:key", "value")
    print(dict_0)

    dict_1 = dict()
    set_tree_node(dict_1, "path", dict())
    set_tree_node(dict_1, "path:to:key", "value")
    print(dict_1)

# Generated at 2022-06-26 02:53:10.798365
# Unit test for function set_tree_node
def test_set_tree_node():
    # Base case
    test_dict = {}
    set_tree_node(test_dict, 'a', 'b')
    assert test_dict['a'] == 'b'

    # One level deep
    set_tree_node(test_dict, 'a:b', 'c')
    assert test_dict['a']['b'] == 'c'

    # Two levels deep
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict['a']['b']['c'] == 'd'



# Generated at 2022-06-26 02:53:19.184838
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    example_path = 'namespace:module:function'
    node = set_tree_node(mapping, example_path, 'node_value')
    assert node == 'node_value'
    assert get_tree_node(mapping, 'namespace')['module']['function'] == 'node_value'
    assert get_tree_node(mapping, 'namespace:module')['function'] == 'node_value'
    assert get_tree_node(mapping, 'namespace:module:function') == 'node_value'



# Generated at 2022-06-26 02:53:27.801753
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'a': {
            'b': {
                'c': 'd'
                }
            }
        }

    answer = get_tree_node(test_tree, 'a:b:c', default=_sentinel)
    assert answer == 'd'

    with pytest.raises(KeyError):
        answer = get_tree_node(test_tree, 'a:b:c:d', default=_sentinel)


# Generated at 2022-06-26 02:53:33.617840
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5, 'f': {'g': 7, 'h': 8}}}

    assert get_tree_node(test_mapping, 'a') == 1
    assert get_tree_node(test_mapping, 'c:d') == 4
    assert get_tree_node(test_mapping, 'f:g') == 7
    assert get_tree_node(test_mapping, 'h', default=None) is None


# Generated at 2022-06-26 02:53:37.687765
# Unit test for function set_tree_node
def test_set_tree_node():
    registry_tree_0 = RegistryTree()
    registry_tree_0.set_tree_node('my_key:my_second_key', 'my_value')
    assert registry_tree_0['my_key:my_second_key'] == 'my_value'



# Generated at 2022-06-26 02:53:45.553202
# Unit test for function set_tree_node
def test_set_tree_node():
    config = {
        'processes': {
            'stop_file': '/tmp/stop',
        }
    }
    set_tree_node(config, 'processes:stop_file', '/var/run/stop')
    assert config['processes']['stop_file'] == '/var/run/stop'



# Generated at 2022-06-26 02:53:47.917895
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test standard behaviour
    tree_0 = {}
    set_tree_node(tree_0, 'foo', 42)
    assert tree_0['foo'] == 42


# Generated at 2022-06-26 02:53:55.751288
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    key = "parent:child"
    value = "value"

    expected = {
        "parent": {
            "child": "value"
        }
    }

    set_tree_node(tree, key, value)
    assert tree == expected, "test_set_tree_node failed"


# Generated at 2022-06-26 02:54:04.260968
# Unit test for function get_tree_node
def test_get_tree_node():
    # Create a simple tree structure
    tree = {
        'section_1': {
            'node_1': 1,
            'node_2': {
                'node_2_1': 1,
            }
        },
        'section_2': {
            'node_3': {
                'node_3_1': 1,
                'node_3_2': 2,
                'node_3_3': {},
            }
        }
    }

    # Assert that we can traverse the tree
    assert tree['section_1']['node_2']['node_2_1'] == 1
    assert get_tree_node(tree, 'section_1:node_2:node_2_1') == 1

    # Assert that we can traverse the tree with parent=True
    assert get_tree_node

# Generated at 2022-06-26 02:54:20.380630
# Unit test for function set_tree_node
def test_set_tree_node():
    assert tree is collections.defaultdict  # We do not need to test, we rely on the stdlib.


# Generated at 2022-06-26 02:54:22.263406
# Unit test for function get_tree_node
def test_get_tree_node():
    get_tree_node(None, None)


# Generated at 2022-06-26 02:54:32.378308
# Unit test for function get_tree_node
def test_get_tree_node():
    my_tree = {
        'foo': {
            'bar': {
                'baz': 'BAR',
            },
            'qux': 'QUX',
        },
        'quuz': {
            'corge': 'CORGE'
        }
    }
    assert get_tree_node(my_tree, 'foo') == {'bar': {'baz': 'BAR'}, 'qux': 'QUX'}
    assert get_tree_node(my_tree, 'foo:bar') == {'baz': 'BAR'}
    assert get_tree_node(my_tree, 'foo:bar:baz') == 'BAR'
    assert get_tree_node(my_tree, 'quuz:corge') == 'CORGE'



# Generated at 2022-06-26 02:54:34.735638
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {'a': {'b': 'c'}}
    print(get_tree_node(a, 'a:b'))


# Generated at 2022-06-26 02:54:38.998490
# Unit test for function get_tree_node
def test_get_tree_node():

    x = {'a': {'b': {'c': {'d': {'e': 'hello'}}}}}

    assert get_tree_node(x, 'a:b:c:d:e') == 'hello'



# Generated at 2022-06-26 02:54:46.742051
# Unit test for function get_tree_node
def test_get_tree_node():
    obj = tkinter.Frame(root,height=100,width=100)
    obj.pack()
    obj = tkinter.Frame(root,height=100,width=100)
    obj.pack()
    assert get_tree_node(obj, 'root:height') == 100
    assert get_tree_node(obj, 'root:width') == 100

# Generated at 2022-06-26 02:54:58.757780
# Unit test for function get_tree_node
def test_get_tree_node():
    foo = tree()
    foo['bar']['baz']['kazoo'] = 'qaz'
    assert get_tree_node(foo, 'bar') == foo['bar']
    assert get_tree_node(foo, 'bar:baz') == foo['bar']['baz']
    assert get_tree_node(foo, 'bar:baz:kazoo') == foo['bar']['baz']['kazoo']
    assert get_tree_node(foo, 'bar:baz:kazoo', default='qaz') == foo['bar']['baz']['kazoo']
    assert get_tree_node(foo, 'bar:baz:kazoo') == get_tree_node(foo, 'bar:baz:kazoo', default='qaz')
   

# Generated at 2022-06-26 02:55:01.355800
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {}
    tree['a'] = {}
    tree['a']['b'] = {}
    tree['a']['b']['c'] = 123

# Generated at 2022-06-26 02:55:13.042449
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': 'A',
        'b': {
            'c': 'C',
            'd': 'D',
        },
    }
    assert get_tree_node(d, 'a') == 'A'
    assert get_tree_node(d, 'b:c') == 'C'
    assert get_tree_node(d, 'b:d') == 'D'

    root = Tree()
    root['a:b:c'] = 'C'
    root['a:b:d'] = 'D'

    assert get_tree_node(root, 'a:b:c') == 'C'
    assert get_tree_node(root, 'a:b:d') == 'D'

# Generated at 2022-06-26 02:55:21.651236
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'pages': {
            'about': {
                'content': 'This is the about page',
                'title': 'About page'
            },
            'home': {
                'content': 'This is the home page',
                'title': 'My website'
            }
        }
    }
    result = get_tree_node(test_dict, 'pages:about:content')
    assert result == 'This is the about page'


# Generated at 2022-06-26 02:56:03.734327
# Unit test for function get_tree_node
def test_get_tree_node():
    # Initialize the tree
    test_tree = tree()
    test_tree['test']['test2']['test3'] = 'works'

    # Assert that get_tree_node works
    assert get_tree_node(test_tree, 'test:test2:test3') == 'works'

    # Assert that get_tree_node works with multiple nodes
    assert get_tree_node(test_tree, 'test:test2:test3', parent=True) == test_tree['test']['test2']

    # Assert that get_tree_node works with default
    assert get_tree_node(test_tree, 'test3', default='works') == 'works'

    # Assert that get_tree_node raises KeyError when not found

# Generated at 2022-06-26 02:56:07.017390
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo', 7)
    assert mapping['foo'] == 7



# Generated at 2022-06-26 02:56:09.734050
# Unit test for function set_tree_node
def test_set_tree_node():
    test_mapping = {}
    test_key = 'foo:bar:baz'
    test_value = 'qux'
    test_parent = collections.defaultdict(set)
    test_parent.update({'foo': {'bar': {'baz': 'qux'}}})
    assert set_tree_node(test_mapping, test_key, test_value) == test_parent


# Generated at 2022-06-26 02:56:22.227050
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test0
    registry_tree_0 = Tree()
    registry_tree_0['a:b:c:d:e:f:g:h:i'] = 'Value'
    registry_tree_0['0:1:2:3'] = 'Test'
    registry_tree_0['foo:bar'] = 'hello, world!'
    assert get_tree_node(registry_tree_0, 'a:b:c:d:e:f:g:h:i') == 'Value'
    assert get_tree_node(registry_tree_0, '0:1:2:3') == 'Test'
    assert get_tree_node(registry_tree_0, 'foo:bar') == 'hello, world!'

# Generated at 2022-06-26 02:56:32.663295
# Unit test for function set_tree_node
def test_set_tree_node():
    import random

    mapping = {}
    for attr in ['foo', 'bar', 'baz', 'doo', 'dah', 'dat']:
        set_tree_node(mapping, attr, str(random.randint(100000, 999999)))
        # Ensure we can fetch the data again
        assert get_tree_node(mapping, attr) == get_tree_node(mapping, attr)
    assert get_tree_node(mapping, 'foo') == '1'
    assert get_tree_node(mapping, 'bar') == '2'
    assert get_tree_node(mapping, 'baz') == '3'
    assert get_tree_node(mapping, 'doo') == '4'
    assert get_tree_node(mapping, 'dah') == '5'

# Generated at 2022-06-26 02:56:37.588560
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree.namespace, 'foo:bar', default=None) is None
    assert get_tree_node(tree, 'foo:bar') == tree['foo:bar']


# Generated at 2022-06-26 02:56:45.499396
# Unit test for function get_tree_node
def test_get_tree_node():
    # Set up a test tree
    test_tree = tree()
    test_tree[0][0][0][0] = "B"
    test_tree[0][0][0][1] = "D"
    test_tree[0][0][1][0] = "A"
    test_tree[0][0][1][1] = "C"
    test_tree[0][1][0][0] = "a"
    test_tree[0][1][0][1] = "b"
    test_tree[0][1][1][0] = "c"
    test_tree[0][1][1][1] = "d"
    test_tree[1] = "a"
    # Test for return value of the function

# Generated at 2022-06-26 02:56:53.610875
# Unit test for function set_tree_node
def test_set_tree_node():
    x = tree()
    set_tree_node(x, 'foo:bar', 'baz')
    expected = {'foo': {'bar': 'baz'}}
    if x != expected:
        raise AssertionError("Failed to set_tree_node")
    #test that it doesn't overwrite dicts
    set_tree_node(x, 'foo:bar:quux', 'baz')
    expected = {'foo': {'bar': 'baz', 'quux': 'baz'}}
    if x != expected:
        raise AssertionError("Failed to set_tree_node")


# Generated at 2022-06-26 02:57:05.129838
# Unit test for function get_tree_node
def test_get_tree_node():
    # Initialize unit test for function get_tree_node
    test_data = {
        'app1': {
            'hosts': ['192.168.0.1', '192.168.0.2'],
            'ports': [5000, 5001],
        },
        'app2': {
            'hosts': ['1.1.1.1', '2.2.2.2'],
            'ports': [8000, 8001],
        }
    }
    # Test to make sure get_tree_node returns the correct value
    assert(get_tree_node(test_data, 'app1:ports') == [5000, 5001]), "get_tree_node function not returning the " \
                                                                    "correct value"
    # Test to make sure get_tree_node raises a KeyError

# Generated at 2022-06-26 02:57:13.977092
# Unit test for function get_tree_node
def test_get_tree_node():
    test_case_data = tree()
    # Case 1: Get a top level node
    test_case_data['top_level_node'] = 'top_level_node_value'
    looks_good = get_tree_node(test_case_data, 'top_level_node') == 'top_level_node_value'
    assert looks_good, 'When getting a node at the top level, it is not returned'

    # Case 2: Delve one level in
    test_case_data['bottom_level_node:one_level_down'] = 'nested_node_value'
    looks_good = get_tree_node(test_case_data, 'bottom_level_node:one_level_down') == 'nested_node_value'

# Generated at 2022-06-26 02:58:41.650387
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    This function ensures that the set_tree_node function is working
    as intended by testing it on a dict and a nested dict
    """
    #test a dict
    d = {}
    d = set_tree_node(d, 'a', 1)
    d = set_tree_node(d, 'b', 2)

    #test a nested dict
    d = set_tree_node(d, 'c:d', 3)
    d = set_tree_node(d, 'c:e', 4)
    d = set_tree_node(d, 'c:f', 5)

    # test a double nested dict
    d = set_tree_node(d, 'c:g:h', 6)
    d = set_tree_node(d, 'c:g:i', 7)
    d = set_

# Generated at 2022-06-26 02:58:46.598571
# Unit test for function get_tree_node
def test_get_tree_node():
    simp_dict = {"a" : {"b" : {"c" : "c"}}, "d" : "d"}
    assert(get_tree_node(simp_dict, 'a:b:c') == "c")


# Generated at 2022-06-26 02:58:47.356683
# Unit test for function set_tree_node
def test_set_tree_node():
    test_case_0()
    assert True



# Generated at 2022-06-26 02:58:56.463383
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {'foo': {'bar': 'baz'}}
    set_tree_node(test_dict, 'foo:bar:baz', {'whoa': 'horse'})
    assert test_dict['foo']['bar']['baz']['whoa'] == 'horse'
    assert test_dict['foo']['bar'] == 'baz'


# Generated at 2022-06-26 02:59:02.585689
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.defaultdict(collections.defaultdict)
    key = 'a:b'
    value = 'c'
    set_tree_node(mapping, key, value)
    target = 'c'
    assert mapping['a']['b'] == target


# Generated at 2022-06-26 02:59:07.110744
# Unit test for function set_tree_node
def test_set_tree_node():
    initial = {
        'a': {
            'b': {
                'c': 'foo'
            }
        }
    }

    # set_tree_node(mapping=initial, key='a:b:d', value='bar')
    set_tree_node(mapping=initial, key='a:b:c', value='bar')
    assert initial['a']['b']['c'] == 'bar'

if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-26 02:59:10.924528
# Unit test for function get_tree_node
def test_get_tree_node():
    registry_tree_1 = RegistryTree()
    registry_tree_1.register('core:something', 'hi')
    assert 'hi' == registry_tree_1.get('core:something')



# Generated at 2022-06-26 02:59:14.749822
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    get_tree_node() returns the correct value.
    """
    tree = {'foo': {'bar': {'baz': 'quux'}}}

    assert get_tree_node(tree, 'foo:bar:baz') == 'quux'
