

# Generated at 2022-06-26 02:49:25.219297
# Unit test for function get_tree_node
def test_get_tree_node():

    #Build testable tree
    tree = { 'my_cool_node' : { 'my_cool_subnode' : 'my_cool_stuff' } }
    test_tree = Tree(tree, namespace='default')
    assert test_tree['my_cool_node:my_cool_subnode'] == 'my_cool_stuff'

    # Test with : sign
    assert test_tree['my_cool_node:my_cool_subnode'] == 'my_cool_stuff'

    # Should give same result
    assert get_tree_node(tree, 'my_cool_node:my_cool_subnode') == 'my_cool_stuff'



# Generated at 2022-06-26 02:49:34.442011
# Unit test for function get_tree_node
def test_get_tree_node():
    d = collections.OrderedDict()
    d['a'] = 1
    d['b'] = 2
    d['c'] = 3

    assert get_tree_node(d, 'a') == 1
    assert get_tree_node(d, 'b') == 2
    assert get_tree_node(d, 'c') == 3

    d['d'] = dict(a=1, b=2, c=3)
    assert get_tree_node(d, 'd:a') == 1
    assert get_tree_node(d, 'd:b') == 2
    assert get_tree_node(d, 'd:c') == 3

    d['e'] = dict(a=1, b=2, c=dict(a=1, b=2, c=3))

# Generated at 2022-06-26 02:49:37.168267
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = tree()
    test_key = 'x:a:b'
    value = 'c'
    set_tree_node(tree, test_key, value)
    assert tree['x']['a']['b'] == value


# Generated at 2022-06-26 02:49:39.421402
# Unit test for function get_tree_node
def test_get_tree_node():
    example_mapping = {
        'root': {
            'foo': {
                'bar': 'baz'
            }
        }
    }
    assert get_tree_node(example_mapping, 'root:foo:bar') == 'baz'



# Generated at 2022-06-26 02:49:44.866193
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping["stuff"]["and"]["things"]["and"] = "blah"
    assert get_tree_node(mapping, "stuff:and:things:and") == "blah"
    assert get_tree_node(mapping, "stuff:and:things:and:this_is_too_deep") is None


# Generated at 2022-06-26 02:49:55.666182
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = set_tree_node({}, 'a:b:c', 1)
    assert tree_0['a']['b']['c'] == 1

    tree_1 = set_tree_node({}, 'a:b:c', 1)
    assert tree_1['a']['b']['c'] == 1
    tree_1 = set_tree_node(tree_1, 'a:b:e', 3)
    assert tree_1['a']['b']['c'] == 1
    assert tree_1['a']['b']['e'] == 3

    tree_2 = set_tree_node(tree_1, 'a:b:c', 2)
    assert tree_2['a']['b']['c'] == 1

# Generated at 2022-06-26 02:50:07.196836
# Unit test for function get_tree_node
def test_get_tree_node():
    # Initialize input variables
    test_data_0 = {"foo": "bar", "baz": {"moo": {"dog": "hahaha"}}}
    test_data_1 = {"foo": "bar", "baz": {"moo": {"dog": "hahaha"}}}
    test_data_2 = {"foo": "bar", "baz": {"moo": {"dog": "hahaha"}}}
    test_data_3 = {"foo": "bar", "baz": {"moo": {"dog": "hahaha"}}}
    test_data_4 = {"foo": "bar", "baz": {"moo": {"dog": "hahaha"}}}
    test_data_5 = {"foo": "bar", "baz": {"moo": {"dog": "hahaha"}}}
    test_data_6

# Generated at 2022-06-26 02:50:11.684412
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree_0, 'a:b:c')
    assert get_tree_node(tree_0, 'a:b:c:d')
    assert get_tree_node(tree_0, 'a:b:c:d:e')
    assert get_tree_node(tree_0, 'a:b:c:d:e')

# Generated at 2022-06-26 02:50:16.931864
# Unit test for function set_tree_node
def test_set_tree_node():
    mock_mapping = { 'foo': { 'bar': 'baz' } }
    assert set_tree_node(mock_mapping, 'foo:bar:foo', 'bar') == { 'bar': 'baz' }
    assert mock_mapping == { 'foo': { 'bar': 'baz', 'foo': 'bar' } }


# Generated at 2022-06-26 02:50:18.254388
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    test_node = set_tree_node(test_tree, 'a:b:c', 'd')
    assert test_node['c'] == 'd'



# Generated at 2022-06-26 02:50:24.956297
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()

# Generated at 2022-06-26 02:50:32.745090
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Set arbitrary node on a tree-like mapping structure, allowing for : notation to signify dimension.

    Arguments:
        mapping collections.Mapping: Mapping to fetch from
        key str|unicode: Key to set, allowing for : notation
        value str|unicode: Value to set `key` to
        parent bool: If True, return parent node. Defaults to False.

    Returns:
        object: Parent node.

    """
    tree = {}
    key = ''
    value = ''
    assert set_tree_node(tree, key, value) == set_tree_node(tree, key, value)
    assert set_tree_node(tree, key, value) == set_tree_node(tree, key, value)

# Generated at 2022-06-26 02:50:39.694953
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {"a":{"b":{"c":"d"}}}
    assert get_tree_node(test_data, "a:b:c") == "d", "Should be d"
    assert get_tree_node(test_data, "a:b") == {"c":"d"}, "Should be d"
    assert_raises(KeyError, get_tree_node, test_data, "q")
    assert get_tree_node(test_data, "q", "default") == "default", "Default should have been returned"


# Generated at 2022-06-26 02:50:49.003981
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = Tree()
    test_tree.set_tree_node(test_tree, 'file:system:config', 'windows')
    #Test that node was set correctly
    assert (test_tree['file:system:config'] == 'windows')
    #Test that set_tree_node does not replace parent node
    assert (test_tree['file:system'] == {'config': 'windows'})


# Generated at 2022-06-26 02:50:53.232677
# Unit test for function get_tree_node
def test_get_tree_node():
    test_cases = [
        (
            {
                'a': {
                    'b': [
                        'c',
                        'd'
                    ]
                }
            },
            'a:b:0',
            'c'
        ),
    ]
    for tc in test_cases:
        assert get_tree_node(*tc[:2]) == tc[2]


# Generated at 2022-06-26 02:51:05.470084
# Unit test for function get_tree_node
def test_get_tree_node():
    expected_1 = ['d', 'e', 'f']
    expected_2 = ['j', 'k', 'l']
    expected_3 = None
    # get_tree_node :
    tree_1 = {1: expected_1, 2: expected_2}
    actual_1 = get_tree_node(tree_1, 1)
    assert expected_1 == actual_1
    actual_2 = get_tree_node(tree_1, 2)
    assert expected_2 == actual_2
    actual_3 = get_tree_node(tree_1, 3, default='boo')
    assert expected_3 == actual_3
    actual_4 = get_tree_node(tree_1, 3)
    assert expected_3 == actual_4
    # get_tree_node :

# Generated at 2022-06-26 02:51:12.499463
# Unit test for function get_tree_node
def test_get_tree_node():
    map = {'a': 'A', 'b': 'B', 'c': {'x': 'X', 'y': 'Y'}}
    print(get_tree_node(map, 'a'))
    print(get_tree_node(map, 'b'))
    print(get_tree_node(map, 'c'))
    print(get_tree_node(map, 'c:x'))
    print(get_tree_node(map, 'c:y'))


# Generated at 2022-06-26 02:51:21.984098
# Unit test for function set_tree_node
def test_set_tree_node():
    a = set_tree_node({}, 'x:y', 'z')
    assert isinstance(a, dict)
    assert a['x']['y'] == 'z'

    a = set_tree_node({}, 'x:y:z', 'wow')
    assert isinstance(a['x'], dict)
    assert a['x']['y']['z'] == 'wow'

    a = set_tree_node({}, 'x:b:c', 'asd')
    assert isinstance(a['x'], dict)
    assert a['x']['b']['c'] == 'asd'



# Generated at 2022-06-26 02:51:24.812261
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree()
    set_tree_node(tree, 'foo:bar:baz', 7)
    assert tree['foo']['bar']['baz'] == 7



# Generated at 2022-06-26 02:51:31.226081
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'foo',
            },
        },
        'b': {
            'c': 'bar',
        },
    }

    assert get_tree_node(tree, 'a:b:c') == 'foo'
    assert get_tree_node(tree, 'a:b:d', default=False) is False
    assert get_tree_node(tree, 'a:b:nope') is KeyError
    assert get_tree_node(tree, 'a:b:c', parent=True) == {'c': 'foo'}
    assert get_tree_node(tree, 'a:b:c', parent=True) == {'c': 'foo'}

# Generated at 2022-06-26 02:51:44.045866
# Unit test for function get_tree_node
def test_get_tree_node():
    m_0 = {'a': {'b': 'c', 'd': {'e': {'f': 'g'}}}}

    # Sane case
    assert get_tree_node(m_0, 'a:d:e:f') == 'g'

    # Bad dimension
    with pytest.raises(KeyError):
        get_tree_node(m_0, 'a:d:e:f:g')

    # Correct dimension, bad key
    with pytest.raises(KeyError):
        get_tree_node(m_0, 'a:d:e:g')

    # Sane case, parent True
    assert get_tree_node(m_0, 'a:d:e:f', parent=True) == {'f': 'g'}

    # Bad dimension, parent True
   

# Generated at 2022-06-26 02:51:51.573371
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['foo:bar'] = 'foobar'
    tree_0['foo:bar:baz'] = 'foobarbaz'
    tree_0['foo:bar:baz:qux'] = 'foobarbazqux'

    assert get_tree_node(tree_0, 'foo:bar') == 'foobar'
    assert get_tree_node(tree_0, 'foo:bar:baz') == 'foobarbaz'
    assert get_tree_node(tree_0, 'foo:bar:baz:qux') == 'foobarbazqux'



# Generated at 2022-06-26 02:51:57.391943
# Unit test for function get_tree_node
def test_get_tree_node():
    nested_list = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]

    # Basic case

# Generated at 2022-06-26 02:52:08.319257
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    assert tree_0.get('foo') is _sentinel

    tree_0.set('foo', 'bar')

    assert tree_0.get('foo') == 'bar'
    assert tree_0['foo'] == 'bar'

    tree_0.set('foo:baz', 'quux')

    assert tree_0.get('foo:baz') == 'quux'
    assert tree_0.get('foo')['baz'] == 'quux'
    assert tree_0['foo']['baz'] == 'quux'

    tree_0.set('foo:baz:quux', 'quux')

    assert tree_0.get('foo:baz:quux') == 'quux'

# Generated at 2022-06-26 02:52:10.838885
# Unit test for function set_tree_node
def test_set_tree_node():
    nodes = collections.defaultdict(tree)
    nodes['foo']['bar']['test'] = 'test'
    assert nodes['foo']['bar']['test'] == 'test'


# Unit test function get_tree_node()

# Generated at 2022-06-26 02:52:20.265045
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {'a': {'a': {'1': '3'}}}
    tree_1 = tree()
    tree_1['a']['a']['b']['c'] = None
    tree_2 = Tree()
    tree_2['a']['a']['b']['c'] = None

    assert get_tree_node(tree_0, 'a:a:1') == '3'
    assert get_tree_node(tree_0, 'a:a:2', default='2') == '2'
    assert get_tree_node(tree_0, 'a:a:1:1', default='2') == '2'
    assert get_tree_node(tree_0, 'a:a:1:1', parent=True) == '3'

    assert get_tree

# Generated at 2022-06-26 02:52:30.107449
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}

    set_tree_node(d, 'a:b:c', 'test')
    assert d['a']['b']['c'] == 'test'
    assert d['a']['b'] == {'c': 'test'}

    set_tree_node(d, 'a:c:d', 'test')
    assert d['a']['c']['d'] == 'test'
    assert d['a']['c'] == {'d': 'test'}

    d = {}
    set_tree_node(d, 'a:a:a', 'test')
    assert d['a']['a']['a'] == 'test'



# Generated at 2022-06-26 02:52:38.584823
# Unit test for function set_tree_node
def test_set_tree_node():
    test_mapping = {}

# Generated at 2022-06-26 02:52:46.009695
# Unit test for function set_tree_node
def test_set_tree_node():
    # Tree structure in `target`
    target = {
        'my': {
            'test': {
                'tree': 'hello world'
            }
        }
    }

    # Set node
    set_tree_node(target, 'my:test:tree', 'foo')
    assert target['my']['test']['tree'] == 'foo'


# Generated at 2022-06-26 02:52:56.365168
# Unit test for function get_tree_node
def test_get_tree_node():
	mapping = Tree()
	mapping['a'] = {'c' : {'g' : {'h' : 'test'}}}
	key = 'a:c:g:h'
	def test_key_not_found():
		get_tree_node(mapping, key)
	assert_raises(KeyError, test_key_not_found)
	assert_raises(collections.Mapping(mapping))

if __name__ == '__main__':
    print(__doc__)

# Generated at 2022-06-26 02:53:04.462852
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'blah') is _sentinel
    assert get_tree_node({'blah': True}, 'blah') is True
    assert get_tree_node({'blah': {'foo': True}}, 'blah:foo') is True



# Generated at 2022-06-26 02:53:10.438391
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    This function tests the set_tree_node function.
    :return:
    """
    my_tree = {}
    set_tree_node(my_tree, 'b', 3)
    set_tree_node(my_tree, 'a', 4)
    set_tree_node(my_tree, 'a:b:c', 5)
    set_tree_node(my_tree, 'a:b:d', 6)
    assert my_tree == {'b': 3, 'a': {'b': {'c': 5, 'd': 6}}}


# Generated at 2022-06-26 02:53:20.685044
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {
        'key0': {
            'key00': {
                'key000': 'value000',
                'key001': {
                    'key0010': 'value0000'
                }
            }
        }
    }

    # Test tree
    print ("Test tree:")
    print (tree_0)

    # Test case 0
    tree_0_get_0 = get_tree_node(tree_0, 'key0:key00:key000')
    print ("Test case 0:")
    print (tree_0_get_0)

    # Test case 1
    tree_0_get_1 = get_tree_node(tree_0, 'key0:key00:key001:key0010')
    print ("Test case 1:")
    print (tree_0_get_1)

   

# Generated at 2022-06-26 02:53:28.708974
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', parent=True) == {'c': 'd'}
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'c') == _sentinel

# Generated at 2022-06-26 02:53:33.054257
# Unit test for function get_tree_node
def test_get_tree_node():
    """Assert that get_tree_node function works correctly"""
    data = {
        'foo': {
            'bar': {
                'baz': 'quux',
            }
        },
    }
    value = 'quux'

    result = get_tree_node(data, 'foo:bar:baz')
    assert value == result



# Generated at 2022-06-26 02:53:39.254073
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['foo:bar:baz'] = 'foobarbaz'

    root_node = get_tree_node(tree_0, 'foo:bar:baz')
    assert root_node['baz'] == 'foobarbaz'
    assert len(root_node) == 1

    parent_node = get_tree_node(tree_0, 'foo:bar:baz', parent=True)
    assert parent_node['bar'] == {'baz': 'foobarbaz'}



# Generated at 2022-06-26 02:53:46.112647
# Unit test for function set_tree_node
def test_set_tree_node():
    data = []
    default_value = 'defaultvalue'
    key = 'item:subitem'
    value = 'myvalue'
    tree_0 = Tree()
    result = set_tree_node(tree_0, key, value)
    assert result == {'subitem': 'myvalue'}


# Generated at 2022-06-26 02:53:49.422939
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {
        'foo': {
            'bar': {
                'baz': 'baz',
            }
        }
    }
    assert get_tree_node(tree_0, 'foo:bar:baz') == 'baz'



# Generated at 2022-06-26 02:53:53.856661
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = Tree({'foo': {'bar': {'baz': 'hello'}}})
    assert get_tree_node(tree, 'foo:bar:baz') == 'hello'

# Generated at 2022-06-26 02:53:57.066181
# Unit test for function get_tree_node
def test_get_tree_node():
    import unittest
    return unittest.TestSuite(
        unittest.makeSuite(TestGetTreeNode)
    )



# Generated at 2022-06-26 02:54:12.568325
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['colors']['blue'] = 0x0000ff
    tree_0['colors']['red'] = 0xff0000
    tree_0['colors']['green'] = 0x00ff00
    tree_0['colors']['black'] = 0x000000
    tree_0['colors']['white'] = 0xffffff
    tree_0['colors']['yellow'] = 0xffff00
    assert tree_0['colors']['blue'] == 0x0000ff
    assert tree_0['colors:blue'] == 0x0000ff
    assert tree_0['colors:blue:'] == 0x0000ff

    assert tree_0['colors']['blue'] == tree_0['colors']['blue']
    assert tree_

# Generated at 2022-06-26 02:54:17.761694
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    set_tree_node(tree_0, 'foo:bar:baz', 'hotdiggity')
    assert tree_0['foo:bar:baz'] == 'hotdiggity'



# Generated at 2022-06-26 02:54:21.789464
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = Tree({'a': {'b': 'c:d'}})
    assert get_tree_node(tree, 'a:b') == 'c:d'
    assert get_tree_node(tree, 'a:b:c') == ['d']
    assert get_tree_node(tree, 'a:b:c', default=None) is None



# Generated at 2022-06-26 02:54:31.347805
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    assert tree_0 == {}
    tree_0['a'] = 1
    assert tree_0 == {'a': 1}
    tree_0['b']['c'] = 2
    assert tree_0 == {'a': 1, 'b': {'c': 2}}
    tree_0['b']['d'] = 3
    assert tree_0 == {'a': 1, 'b': {'c': 2, 'd': 3}}
    tree_0['b']['e'] = 4
    assert tree_0 == {'a': 1, 'b': {'c': 2, 'd': 3, 'e': 4}}


# Generated at 2022-06-26 02:54:40.894953
# Unit test for function get_tree_node
def test_get_tree_node():
    # Key without namespace
    test_key = 'leaf'

    # Test tree
    test_tree = tree()
    test_tree['branch']['leaf'] = 'value'

    # Test
    test_tree_node = get_tree_node(test_tree, test_key)

    # Test assertion
    assert test_tree_node == 'value', 'get_tree_node: no namespace failed'

    # With namespace
    test_key = 'branch:leaf'

    # Test
    test_tree_node = get_tree_node(test_tree, test_key)

    # Test assertion
    assert test_tree_node == 'value', 'get_tree_node: with namespace failed'

    # Default
    test_key = 'branch:test:test:test:test:test'
    test_tree_

# Generated at 2022-06-26 02:54:48.890889
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    tree_0.set_tree_node(tree_0, 'a:b:c:d', 'banana')
    assert tree_0['a:b']['c:d'] == 'banana'
    assert tree_0['a:b:c'] == tree()
    assert tree_0['a'] == tree()


# Generated at 2022-06-26 02:55:01.381454
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:55:07.578137
# Unit test for function get_tree_node
def test_get_tree_node():
    # Invalid Argument Tests
    assert get_tree_node({}, "") == {}
    assert get_tree_node({}, None) == None

    # Valid Argument Tests
    assert get_tree_node({"key": "value"}, "key") == "value"
    assert get_tree_node({"key": "value"}, "not_key") == _sentinel
    assert get_tree_node({"key": "value"}, "not_key", default="value") == "value"



# Generated at 2022-06-26 02:55:12.882312
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test case:
    # Expected result:
    """Assert that get_tree_node() returns correct value when key is found."""
    tree_1 = {'a': { 'aa': { 'aaa': 'aaaa', 'aab': 'aaba' }, 'ab': 'aba' }, 'b': 'b'}
    assert get_tree_node(tree_1, 'a:aa:aaa') == 'aaaa'


# Generated at 2022-06-26 02:55:24.368688
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {
        "a": {
            "b": {
                "c": 3
            }
        }
    }

    """
    Get cases:
    """
    # Empty dict should return None
    assert get_tree_node({}, "a:b:c") == None

    # Try to get empty key
    assert get_tree_node(tree_0, "") == None

    # Try to get with "." in key
    assert get_tree_node(tree_0, "a.b.c") == None

    # Try to get with ":" in key
    assert get_tree_node(tree_0, "a:b:c") == 3

    # Try to get with "a" in key

# Generated at 2022-06-26 02:55:42.135382
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    assert tree_0['foo'] == {}
    assert tree_0['foo:bar'] == {}
    assert tree_0['foo:bar:baz'] == {}
    assert tree_0['qux'] == {}
    set_tree_node(tree_0, 'foo:bar:baz', 123)
    assert tree_0['foo'] == {'bar': {'baz': 123}}
    set_tree_node(tree_0, 'foo:bar:baz', 321)
    assert tree_0['foo'] == {'bar': {'baz': 321}}


# Generated at 2022-06-26 02:55:52.539432
# Unit test for function set_tree_node
def test_set_tree_node():

    mapping = {
        'user': {
            'name': 'Dan',
        },
    }

    set_tree_node(mapping, 'user:name', 'Dan')

    assert mapping['user']['name'] == 'Dan'

    set_tree_node(mapping, 'user:likes', 'ponies')

    assert mapping['user']['likes'] == 'ponies'

    try:
        set_tree_node(mapping, 'city', 'London')
    except KeyError:
        pass
    else:
        assert False, 'Managed to set city on user, which is impossible'

    set_tree_node(mapping, 'city', 'London')

    assert mapping['city'] == 'London'


# Generated at 2022-06-26 02:56:03.179609
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', parent=True) == {'bar': 'baz'}
    assert get_tree_node({}, 'foo', 42) == 42
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:not_there', 42) == 42
    try:
        get_tree_node({}, 'foo')
    except KeyError:
        pass
    else:
        assert False, 'Did not raise KeyError'

# Generated at 2022-06-26 02:56:13.326223
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['beer'] = 'yum'
    tree_0['food:tacos'] = 'yay'
    tree_0['food:burgers'] = 'woah'

    assert get_tree_node(tree_0, 'food:burgers') == 'woah'
    assert get_tree_node(tree_0, 'beer') == 'yum'

    # This should throw an error
    try:
        get_tree_node(tree_0, 'beer:whiskey')
    except KeyError:
        pass
    else:
        raise AssertionError("Shouldn't be here! KeyError should've been raised by now.")

    # Defaulting to _sentinel should raise a KeyError

# Generated at 2022-06-26 02:56:14.765209
# Unit test for function get_tree_node
def test_get_tree_node():
    pass


# Generated at 2022-06-26 02:56:23.992946
# Unit test for function get_tree_node
def test_get_tree_node():
    # Tree to fetch from
    tree_0 = {
        'a': {
            'b': 2,
            'c': 3,
            'd': {
                'e': 'e',
                'f': {
                    'g': 'g'
                }
            }
        }
    }
    # Test Case 1
    expected = {
        'a': {
            'b': 2,
            'c': 3,
            'd': {
                'e': 'e',
                'f': {
                    'g': 'g'
                }
            }
        }
    }
    actual = get_tree_node(tree_0, 'a', default=None)
    assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)
    # Test Case 2
    expected

# Generated at 2022-06-26 02:56:29.033642
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a', 0) == {'a': 0}
    assert set_tree_node({}, 'a:b:c', 0) == {'a': {'b': {'c': 0}}}
    assert set_tree_node({'a': {'b': {'c': 0}}}, 'a:b:c', 1) == {'a': {'b': {'c': 1}}}
    assert set_tree_node({'a': {'b': {'c': 0}}}, 'a:b:d', 1) == {'a': {'b': {'c': 0, 'd': 1}}}


# Generated at 2022-06-26 02:56:33.028098
# Unit test for function get_tree_node
def test_get_tree_node():
    node = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(node, 'a:b:c') == 'd'
    assert get_tree_node(node, 'a:b:c:d', default='x') == 'x'
    try:
        get_tree_node(node, 'a:b:c:d')
    except KeyError:
        pass
    else:
        raise AssertionError("Should have raised KeyError")

    assert get_tree_node(node, 'a:b:c', parent=True) == node['a']['b']



# Generated at 2022-06-26 02:56:37.798960
# Unit test for function get_tree_node
def test_get_tree_node():
    "Test getting a tree node"
    test_tree = {
        'foo': 'bar'
    }
    assert get_tree_node(test_tree, 'foo') == 'bar'



# Generated at 2022-06-26 02:56:43.228165
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    level_0_key = 'foo'
    level_0_value = 'bar'
    set_tree_node(tree_0, level_0_key, level_0_value)
    t0v1 = tree_0[level_0_key]
    t0v2 = tree_0['foo']
    assert t0v1 == t0v2
    assert t0v1 == level_0_value


# Generated at 2022-06-26 02:57:05.534560
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = get_tree_node(var_0, 'foo:bar')
    var_2 = foo
    var_3 = [1, 2, 3]
    var_4 = {'foo': 'bar'}
    var_5 = get_tree_node(var_0, 'foo:bar:0:baz', default=var_1)
    var_6 = get_tree_node(var_0, 'foo:bar:0:baz', default=var_2)
    var_7 = get_tree_node(var_0, 'foo:bar:0:baz', default=var_3)
    var_8 = get_tree_node(var_0, 'foo:bar:0:baz', default=var_4)
    var_9 = get_tree

# Generated at 2022-06-26 02:57:14.085506
# Unit test for function get_tree_node
def test_get_tree_node():
    # Assert the key __default__ is in var_0 (Result : True)
    assert '__default__' in var_0
    # Assert the key foods is in var_0[fruits] (Result : True)
    assert 'foods' in var_0.get(var_0, 'fruits')
    # Assert the key foods is in var_0[fruits] (Result : False)
    assert 'foods' not in get_tree_node(var_0, 'vegetables')
    # Assert the key foods is in var_0[fruits] (Result : True)
    assert 'foods' in var_0.get(var_0, 'fruits')
    # Assert the key avocado is in var_0[fruits:vegetables] (Result : True)

# Generated at 2022-06-26 02:57:16.955534
# Unit test for function get_tree_node
def test_get_tree_node():
    assert True



# Generated at 2022-06-26 02:57:19.394744
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node('mapping', 'key', 'value') == None


# Generated at 2022-06-26 02:57:27.844020
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:y:z', 'test')
    set_tree_node(tree, 'a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:y:z', 'test2')

# Generated at 2022-06-26 02:57:36.307150
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = dict()
    tree_0['module'] = tree_0
    tree_0['dimensions'] = tree_0
    tree_0['modules'] = tree_0
    tree_0['timestamp'] = tree_0
    # Check that the function set_tree_node returns the correct output
    assert get_tree_node(tree_0, 'module:dimensions:modules:timestamp') == tree_0
    set_tree_node(tree_0, 'module:dimensions:modules:timestamp', tree_0)
    # Check that the function set_tree_node returns the correct output
    assert get_tree_node(tree_0, 'module:dimensions:modules:timestamp') == tree_0
    set_tree_node(tree_0, 'module:dimensions:modules:timestamp', tree_0)

# Generated at 2022-06-26 02:57:46.805744
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = tree()
    var_2 = tree()
    var_2['1'] = tree()
    var_3 = tree()
    var_3['1'] = tree()
    var_4 = tree()
    var_4['1'] = tree()
    var_4['2'] = tree()
    var_5 = tree()
    var_5['1'] = tree()
    var_5['2'] = tree()
    var_5['3'] = tree()
    var_6 = tree()
    var_6['1'] = tree()
    var_6['2'] = tree()
    var_6['3'] = tree()
    var_7 = tree()
    var_7['1'] = tree()
    var_7['2'] = tree()
    var_

# Generated at 2022-06-26 02:57:57.185810
# Unit test for function get_tree_node
def test_get_tree_node():
    r = tree()
    r['a']['b']['c'] = 1
    r['a']['b']['d'] = 2
    r['a']['e'] = 4
    r['a']['c'] = 3
    r['a']['e']['d'] = 2

    assert get_tree_node(r, 'a:b:c') == 1
    assert get_tree_node(r, 'a:c') == 3
    assert get_tree_node(r, 'a:b:d') == 2
    assert get_tree_node(r, 'a:e:d') == 2
    assert get_tree_node(r, 'a:d') is None
    assert get_tree_node(r, 'a:d', default=False) is False
    assert get

# Generated at 2022-06-26 02:58:07.475936
# Unit test for function get_tree_node
def test_get_tree_node():
    class TestMapping():
        def __iter__(self):
            return iter({})
        def __len__(self):
            return 0
        def __getitem__(self, key):
            return key
    mapping = TestMapping()

    key = 'foo:bar'

    # Unit test for function get_tree_node
    def test_get_tree_node():
        assert get_tree_node(mapping, key) == key

    # Unit test for function get_tree_node
    def test_get_tree_node():
        assert get_tree_node(mapping, key, parent=True) == 'foo'

    # Unit test for function get_tree_node
    def test_get_tree_node():
        assert get_tree_node(mapping, key, default=['foo', 'bar']) == key

# Generated at 2022-06-26 02:58:12.337435
# Unit test for function get_tree_node
def test_get_tree_node():
    # Assigning variables
    var_0 = {}

    # Calling function
    get_tree_node(var_0, "var_0", True)

var_2 = OrderedDict()


# Generated at 2022-06-26 02:58:39.719668
# Unit test for function get_tree_node
def test_get_tree_node():
    pass


# Generated at 2022-06-26 02:58:44.241107
# Unit test for function get_tree_node
def test_get_tree_node():
    def test_get_tree_node_0():
        var_0 = tree()
        return get_tree_node(var_0, 'ra')


# Generated at 2022-06-26 02:58:50.947420
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = Tree({'dogs': ['lab', 'pug', 'pitbull']})
    assert tree['dogs:0'] == 'lab'
    assert tree['dogs:1'] == 'pug'
    assert tree['dogs:2'] == 'pitbull'
    assert tree.get('cats:0') is None

    tree = Tree()
    tree['dogs'] = ['lab', 'pug', 'pitbull']
    assert tree['dogs:0'] == 'lab'
    assert tree['dogs:1'] == 'pug'
    assert tree['dogs:2'] == 'pitbull'
    assert tree.get('cats:0') is None



# Generated at 2022-06-26 02:58:56.886038
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    set_tree_node(var_1, 'foo:bar:baz', 'waz')
    assert var_1['foo']['bar']['baz'] == 'waz'


# Generated at 2022-06-26 02:59:01.189566
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = get_tree_node(test_case_0, var_0=test_case_0)

    assert True

# Generated at 2022-06-26 02:59:09.542062
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test 1
    # Test fixture
    var_0 = tree()
    var_0['hello']['world']['how']['are']['you'] = 'Good, thanks!'
    # Test case
    var_1 = get_tree_node(var_0, 'hello:world:how:are', _sentinel)
    assert var_1 == {'you': 'Good, thanks!'}

    # Test 2
    # Test fixture
    var_2 = tree()
    var_2['hello']['world']['how']['are']['you'] = 'Good, thanks!'
    # Test case
    var_3 = get_tree_node(var_2, 'hello:world:how:are:you', _sentinel)
    assert var_3 == 'Good, thanks!'

    # Test 3

# Generated at 2022-06-26 02:59:12.191711
# Unit test for function set_tree_node
def test_set_tree_node():
    # Assign
    var_0 = tree()

    # Call
    var_1 = set_tree_node(var_0, 'a', 1)

    # Assert
    assert var_0['a'] == 1


# Generated at 2022-06-26 02:59:19.821084
# Unit test for function get_tree_node
def test_get_tree_node():
    config = {
        'key1': {
            'subkey1': 'val1',
            'subkey2': 'val2',
            'subkey3': {
                'subsubkey1': 'val3'
            }
        },
        'key2': 'val4'
    }

    assert get_tree_node(config, 'key1:subkey1') == 'val1'
    assert get_tree_node(config, 'key1:subkey3:subsubkey1'), 'val3'
    assert get_tree_node(config, 'key2') == 'val4'
    assert get_tree_node(config, 'key3', default='val5') == 'val5'