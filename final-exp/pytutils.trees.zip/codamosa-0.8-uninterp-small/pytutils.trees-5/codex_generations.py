

# Generated at 2022-06-26 02:49:24.678603
# Unit test for function get_tree_node
def test_get_tree_node():

    # Ensure that the correct exception is thrown on bad input
    try:
        get_tree_node(1, 2)
    except:
        pass
    else:
        raise AssertionError('Exception not thrown on bad input')

    var_1 = tree()
    var_2 = tree()
    var_3 = tree()
    var_1['1'] = var_2
    var_1['1:2']['3'] = var_3

    # Ensure that the correct exception is thrown on bad input
    try:
        get_tree_node(1, 2)
    except:
        pass
    else:
        raise AssertionError('Exception not thrown on bad input')

    var_1 = tree()
    var_2 = tree()
    var_3 = tree()
    var_1['1'] = var_2

# Generated at 2022-06-26 02:49:29.641998
# Unit test for function get_tree_node
def test_get_tree_node():
    # Example 1
    test_mapping = {'node_0': {'node_1': {'node_1_1': 'result'}}}
    expected_result = "result"
    observed_result = get_tree_node(test_mapping, 'node_0:node_1:node_1_1')
    assert expected_result == observed_result

    # Example 2
    test_mapping = {'node_0': {'node_1': {'node_1_1': 'result'}}}
    expected_result = {'node_1_1': 'result'}
    observed_result = get_tree_node(test_mapping, 'node_0:node_1', parent=True)
    assert expected_result == observed_result

    # Example 3

# Generated at 2022-06-26 02:49:37.718424
# Unit test for function get_tree_node
def test_get_tree_node():
    import collections
    mapping = collections.defaultdict(collections.defaultdict)
    mapping[0][0] = 0
    mapping[1][2] = 1
    mapping[1][1] = 1
    assert get_tree_node(mapping, '0:0') == 0
    assert get_tree_node(mapping, '1:1') == 1
    assert get_tree_node(mapping, '1:2') == 1
    assert get_tree_node(mapping, ':', default=0) == 0
    assert get_tree_node(mapping, '0') == {0: 0}
    assert get_tree_node(mapping, '1') == {1: 1, 2: 1}

# Generated at 2022-06-26 02:49:45.827051
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = set_tree_node(var_0, 'a:b:c:d:e', 'f')
    var_2 = assertEqual(var_1, var_0['a']['b']['c'])
    var_3 = get_tree_node(var_1, 'a:b:c:d:e')
    var_4 = assertEqual(var_3, 'f')
    return var_3


# Generated at 2022-06-26 02:49:55.436452
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:49:59.213268
# Unit test for function get_tree_node
def test_get_tree_node():
    var_4 = tree()
    var_4["one"]["two"]["three"]["four"] = 4
    assert get_tree_node(var_4, "one:two:three", default=_sentinel) == {'four': 4}


# Generated at 2022-06-26 02:50:03.044712
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {'a': {'b': 1}}
    var_1 = 'a:b'
    var_2 = get_tree_node(var_0, var_1)

# Generated at 2022-06-26 02:50:04.619261
# Unit test for function set_tree_node
def test_set_tree_node():
    assert True



# Generated at 2022-06-26 02:50:06.346804
# Unit test for function get_tree_node
def test_get_tree_node():
    assert "Dummy test" == "Dummy test"



# Generated at 2022-06-26 02:50:12.780427
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['test_case_0']['test_case_0_a']['test_case_0_a_0'] = 'test_case_0_a_0 set'
    var_1 = var_0['test_case_0']['test_case_0_a']['test_case_0_a_0']
    var_2 = 'test_case_0_a_0 set'
    var_3 = (var_1 == var_2)
    return var_3


# Generated at 2022-06-26 02:50:17.536516
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, "a", 1)
    set_tree_node(var_0, "b", 2)


# Generated at 2022-06-26 02:50:24.004714
# Unit test for function get_tree_node
def test_get_tree_node():
    from random import randint

    # Basic function tests
    var_0 = tree()
    var_0['a']['b']['c'] = 'd'
    var_1 = var_0
    var_2 = var_0['a']
    var_3 = get_tree_node(var_1, 'a')
    var_4 = get_tree_node(var_1, 'a:b')
    var_5 = get_tree_node(var_1, 'a:b:c')
    var_6 = get_tree_node(var_1, 'a:b:c:d')
    var_7 = get_tree_node(var_1, 'x')
    var_8 = get_tree_node(var_1, 'y')

# Generated at 2022-06-26 02:50:25.047550
# Unit test for function set_tree_node
def test_set_tree_node():
    assert False


# Generated at 2022-06-26 02:50:28.376262
# Unit test for function get_tree_node
def test_get_tree_node():
    test_0 = {}
    actual = get_tree_node(test_0, 'key')
    expected = None
    assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)


# Generated at 2022-06-26 02:50:31.201575
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    set_tree_node(var_1, 'foo:bar:baz', 'lorem')
    return var_1


# Generated at 2022-06-26 02:50:39.625468
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = {'a': {'b': {'c': 'd'}}}
    var_2 = get_tree_node(var_1, 'a:b:c')
    if var_2 != 'd':
        raise AssertionError('"a:b:c" should be "d".')
    var_3 = get_tree_node(var_1, 'b:c:d', 'default')
    if var_3 != 'default':
        raise AssertionError('"b:c:d" should be "default".')


# Generated at 2022-06-26 02:50:45.925831
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_node = None
    tree_node = get_tree_node(var_0, str('var_1'), _sentinel, True)


# Generated at 2022-06-26 02:50:50.958847
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    result_0 = set_tree_node(var_0, 'one:two:three', 'hello')
    result_1 = get_tree_node(var_0, 'one:two:three')
    assert result_0 == get_tree_node(var_0, 'one:two')
    assert result_1 == 'hello'


# Generated at 2022-06-26 02:50:54.547821
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    set_tree_node(var_1, 'test:test', 'value')
    assert get_tree_node(var_1, 'test:test') == 'value'
    var_2 = tree()
    set_tree_node(var_2, 'test:test:test', 'value')
    assert get_tree_node(var_2, 'test:test:test') == 'value'



# Generated at 2022-06-26 02:51:06.542575
# Unit test for function get_tree_node
def test_get_tree_node():
    try:
        assert get_tree_node(var_0, ":") == None
    except AssertionError as exc:
        raise AssertionError(exc.message)
    else:
        try:
            assert get_tree_node(var_0, ":1") == None
        except AssertionError as exc:
            raise AssertionError(exc.message)
        else:
            try:
                assert get_tree_node(var_0, ":2:c") == None
            except AssertionError as exc:
                raise AssertionError(exc.message)
            else:
                try:
                    assert get_tree_node(var_0, ":1:c") == None
                except AssertionError as exc:
                    raise AssertionError(exc.message)

# Generated at 2022-06-26 02:51:13.189443
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node
    """
    test_key_0 = 'arr:fun:fun:arr:num:0'
    test_value_0 = 'd20'
    assert get_tree_node(test_case_0(), test_key_0) == test_value_0


# Generated at 2022-06-26 02:51:24.374802
# Unit test for function get_tree_node
def test_get_tree_node():
    # No exceptions expected for this usage
    get_tree_node(test_case_0(), 'var_0')
    # No exceptions expected for this usage
    get_tree_node(test_case_0(), 'var_0', parent=True)
    # No exceptions expected for this usage
    get_tree_node(test_case_0(), 'var_0:0')
    # No exceptions expected for this usage
    get_tree_node(test_case_0(), 'var_0:0', parent=True)
    # No exceptions expected for this usage
    get_tree_node(test_case_0(), 'var_0:1', default=None)
    # No exceptions expected for this usage
    get_tree_node(test_case_0(), 'var_0:1', default=None, parent=True)
    # No

# Generated at 2022-06-26 02:51:25.325183
# Unit test for function set_tree_node
def test_set_tree_node():
    test_case_0()

# Generated at 2022-06-26 02:51:27.455344
# Unit test for function get_tree_node
def test_get_tree_node():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 02:51:31.343100
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = tree()
    set_tree_node(var_0, 'bar:baz', 'foo')
    set_tree_node(var_1, 'bar:baz', 'foo')
    assert var_0 == var_1

# Generated at 2022-06-26 02:51:40.138855
# Unit test for function get_tree_node
def test_get_tree_node():
    # Should create a tree node and return the value
    department_tree = Tree()
    department_tree['research:michigan']['Paris Hilton'] = {'title': 'manager', 'years_worked': 5}
    assert department_tree['research:michigan:Paris Hilton'] == {'title': 'manager', 'years_worked': 5}
    assert department_tree['research:michigan']['Paris Hilton'] == {'title': 'manager', 'years_worked': 5}
    assert department_tree['research:michigan:Paris Hilton']['title'] == 'manager'



# Generated at 2022-06-26 02:51:46.362416
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {'foo': 0, 'bar': 1}
    assert get_tree_node(test_tree, 'foo') == 0
    assert get_tree_node(test_tree, 'foobar') is None
    assert get_tree_node(test_tree, 'foobar', None) is None
    assert get_tree_node(test_tree, 'foobar', None, parent=True) is test_tree
    assert get_tree_node(test_tree, 'bar', None, parent=True) is test_tree


# Generated at 2022-06-26 02:51:55.046292
# Unit test for function set_tree_node

# Generated at 2022-06-26 02:52:00.388805
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {'a': {'b': ['c', 'd', 'e']}}
    assert get_tree_node(test_mapping, 'a:b') == ['c', 'd', 'e']
    assert get_tree_node(test_mapping, 'a:b:1') == 'd'



# Generated at 2022-06-26 02:52:03.894224
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = var_0['hello']['world']
    var_2 = get_tree_node(var_0, 'hello:world')
    assert var_1 == var_2



# Generated at 2022-06-26 02:52:14.073584
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test case 0

    # Test case 1

    pass


# Generated at 2022-06-26 02:52:15.612328
# Unit test for function get_tree_node
def test_get_tree_node():
    print('test_get_tree_node()', '#' * 20)
    var_0 = tree()


# Generated at 2022-06-26 02:52:22.002267
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Fetch arbitrary node from a tree-like mapping structure with traversal help:
    Dimension can be specified via ':'

    Arguments:
        mapping collections.Mapping: Mapping to fetch from
        key str|unicode: Key to lookup, allowing for : notation
        default object: Default value. If set to `:module:_sentinel`, raise KeyError if not found.
        parent bool: If True, return parent node. Defaults to False.

    Returns:
        object: Value at specified key
    """
    assert True


# Generated at 2022-06-26 02:52:28.112120
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_ = {
        'a': {
            'b': {
                'c': {
                    'd': 'hello'
                }
            }
        }
    }
    assert get_tree_node(tree_, 'a:b:c:d', default='world') == 'hello'
    assert get_tree_node(tree_, 'a:b:c:e', default='world') == 'world'



# Generated at 2022-06-26 02:52:30.678764
# Unit test for function set_tree_node
def test_set_tree_node():
    # TODO: Implement unit test for function set_tree_node
    raise NotImplementedError('Not implemented')


# Generated at 2022-06-26 02:52:39.073239
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = {'1': 'value_1', '2': {'2.1': 'value_2.1', '2.2': {'2.2.1': 'value_2.2.1'}}}
    # Test with strings
    assert get_tree_node(var_1, '1') == 'value_1'
    assert get_tree_node(var_1, '2') == {'2.1': 'value_2.1', '2.2': {'2.2.1': 'value_2.2.1'}}
    assert get_tree_node(var_1, '2:2.1') == 'value_2.1'

# Generated at 2022-06-26 02:52:49.611211
# Unit test for function get_tree_node
def test_get_tree_node():
    '''
    Ensure get_tree_node fetches the proper node from a nested structure
    '''
    # Create a simple set of nested nested dictionaries
    # Create a test structure
    test_node_1 = 'This is a test node'
    test_node_2 = 'This is another test node'
    test_node_3 = 'This is yet another test node'
    test_nested_dict = {
        'root_node': {
            'second_level': {
                'third_level': {'third_level_node': test_node_3},
            },
            'second_level_node': test_node_2,
        },
        'root_node_jr': test_node_1,
    }

    # Ensure that basic nested lookups work

# Generated at 2022-06-26 02:52:56.734854
# Unit test for function set_tree_node
def test_set_tree_node():

    # Setup environment
    mapping = {"a": {} }

    # Test function
    set_tree_node(mapping, "a:b", 1)
    result = mapping == {"a": {"b": 1}}

    # Assert test result
    if not result:
        raise AssertionError('Set tree node test failed.')


# Generated at 2022-06-26 02:53:01.572382
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {"a": 1}
    var_1 = get_tree_node(var_0, "a")
    test.compare(var_1, 1, "get_tree_node")



# Generated at 2022-06-26 02:53:10.798127
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test setup
    var_0 = tree()
    var_1 = 1
    var_2 = 2
    var_3 = 3

    var_0['a'] = var_1
    var_0['b'] = tree()
    var_4 = ['c', 'd', 'e']
    for var_5 in var_4:
        var_0['b'][var_5] = var_2
    var_0['b']['f'] = var_3

    # Example from function documentation
    var_6 = get_tree_node(var_0, 'b:e:g:h:i', default=4)
    assert var_6 == 4
    var_6 = get_tree_node(var_0, 'b:f')
    assert var_6 == 3

    # Test failure conditions

# Generated at 2022-06-26 02:53:26.759728
# Unit test for function get_tree_node
def test_get_tree_node():
    dict_0 = {'foo': 'bar', 'baz': {'bing': 'bong'}}
    assert get_tree_node(dict_0, 'foo') == 'bar'
    assert get_tree_node(dict_0, 'baz:bing') == 'bong'



# Generated at 2022-06-26 02:53:36.682700
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:53:42.442812
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data_1 = collections.defaultdict(tree)
    test_data_1['foo:bar:baz'] = 1
    test_data_1['foo:bar:xyz'] = 2
    test_data_1['foo:bar:xyz:abc'] = 3
    test_data_1['foo:bar:xyz:abc']
    test_data_1['foo:bar:abc:abc'] = 4
    test_data_1['foo:bar:abc:def'] = 5

    test_data_2 = {
        'foo': {
            'bar': 'baz'
        }
    }
    set_tree_node(test_data_2, 'foo:bar', 'xyz')
    assert test_data_2['foo']['bar'] == 'xyz'
    test_data_

# Generated at 2022-06-26 02:53:49.359480
# Unit test for function get_tree_node
def test_get_tree_node():
    # No exceptions thrown
    test_key = 'taco:bell:beans:logger'
    test_mapping = tree()
    test_set_tree_node(test_mapping, test_key, 'yum')
    assert get_tree_node(test_mapping, test_key) == 'yum'
    assert get_tree_node(test_mapping, test_key, parent=True) == {'logger': 'yum'}



# Generated at 2022-06-26 02:53:51.903855
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    assert mapping['LOL'] == tree()
    assert g

# Generated at 2022-06-26 02:53:53.478864
# Unit test for function get_tree_node
def test_get_tree_node():
    assert True


# Generated at 2022-06-26 02:54:02.756583
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['a']['a']['e'] = 'a'
    var_0['a']['a']['c'] = 'b'
    var_0['a']['c']['a'] = 'c'
    var_0['a']['d']['b'] = 'd'
    var_0['a']['e']['b'] = 'e'
    var_0['a']['e']['b'] = 'e'
    var_0['a']['e']['c'] = 'f'
    var_0['b']['a'] = 'g'
    var_0['b']['a']['e'] = 'h'

# Generated at 2022-06-26 02:54:12.826024
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, "foo", 0) == {'foo': 0}
    assert set_tree_node({}, "foo:bar", 0) == {'foo': {'bar': 0}}
    assert set_tree_node({}, "foo:bar:baz", 0) == {'foo': {'bar': {'baz': 0}}}
    assert set_tree_node({'foo': {'bar': {}}}, "foo:bar:baz", 0) == {'foo': {'bar': {'baz': 0}}}
    assert set_tree_node({'foo': {'bar': {'baz': 0}}}, "foo:bar:baz", 1) == {'foo': {'bar': {'baz': 1}}}


# Generated at 2022-06-26 02:54:17.487810
# Unit test for function get_tree_node
def test_get_tree_node():
    try:
        assert func(var_0, 'x', default=_sentinel, parent=False) == _sentinel
    except:
        raise AssertionError
    var_0 = tree()


# Generated at 2022-06-26 02:54:29.786328
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
         'id': 1,
         'name': 'John Doe',
         'shipping': {
             'address': '1234 Wall Street',
             'zipcode': '12345'
         },
         'products': [
             {
                 'id': 1,
                 'name': 'Hammer'
             }
         ]
     }

    assert get_tree_node(mapping, 'shipping:address') == '1234 Wall Street'
    assert get_tree_node(mapping, 'products:0:id') == 1
    assert get_tree_node(mapping, 'id') == 1
    assert get_tree_node(mapping, 'shipping', default='Not found') == 'Not found'

# Generated at 2022-06-26 02:54:52.606945
# Unit test for function get_tree_node
def test_get_tree_node():
    print('Testing get_tree_node')
    print('Function get_tree_node passed')



# Generated at 2022-06-26 02:54:56.640536
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = tree()
    var_1['key0']
    var_0 = get_tree_node(var_1, 'key0', False, False)



# Generated at 2022-06-26 02:54:59.082064
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(var_0, 'a:b:c') == None


# Generated at 2022-06-26 02:55:07.766229
# Unit test for function get_tree_node
def test_get_tree_node():

    # Imports
    import collections

    # Setup
    mapping = collections.OrderedDict([('name', 'Peter'), ('occupation', 'Cat Person')])
    key = 'name'
    default = _sentinel

    # Exercise
    result = get_tree_node(mapping, key, default)

    # Verify
    assert result == 'Peter'



# Generated at 2022-06-26 02:55:15.114508
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0["color"]["favorite"] = "yellow"
    var_0["color"]["dark"]["favorite"] = "black"
    var_0["color"]["light"]["favorite"] = "white"
    var_0["color"]["dark"]["second favorite"] = "blue"
    var_0["color"]["dark"]["third favorite"] = "red"
    var_0["color"]["light"]["second favorite"] = "green"
    var_0["color"]["light"]["third favorite"] = "purple"
    var_1 = get_tree_node(var_0, "color:light")
    var_2 = get_tree_node(var_0, "color:dark")


# Generated at 2022-06-26 02:55:25.094489
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'a': {'b': {'c': {'d': 1}}}}
    key = 'a:b:c:e'
    value = 'test'

    set_tree_node(mapping, key, value)
    assert get_tree_node(mapping, key) == 'test'

    # Dry test with real values to ensure no side-effects
    real_mapping = {
        "a": {
            "b": {
                "c": {
                    "d": '1'
                }
            }
        }
    }

    set_tree_node(real_mapping, key, value)
    assert get_tree_node(real_mapping, key) == 'test'
    assert get_tree_node(real_mapping, 'a:b:c:d') == '1'

# Generated at 2022-06-26 02:55:29.332998
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()

# Generated at 2022-06-26 02:55:41.179484
# Unit test for function get_tree_node
def test_get_tree_node():
    import random
    t = tree()
    assert not get_tree_node(t, '1:2')
    t[1][2] = 3
    assert get_tree_node(t, '1:2') == get_tree_node(t, [1, 2]) == 3

    assert get_tree_node(t, [1, 2, 3]) is None

    assert get_tree_node(t, [1, 2, 3], default=9) == get_tree_node(t, [1, 2, 3], default=9) == 9

    try:
        get_tree_node(t, [1, 2, 3])
        return False
    except KeyError:
        pass


# Generated at 2022-06-26 02:55:46.572855
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, 'foo:bar:baz', 'foobarbaz')
    assert var_0['foo']['bar']['baz'] == 'foobarbaz'

# Generated at 2022-06-26 02:55:48.525150
# Unit test for function get_tree_node
def test_get_tree_node():
    assert hasattr(get_tree_node, '__call__')


# Generated at 2022-06-26 02:56:34.212845
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping[1]['a']['b'] = 'c'
    assert get_tree_node(mapping, '1:a:b') == 'c'



# Generated at 2022-06-26 02:56:44.381048
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['b']['c'] = 'test'
    var_0['a']['c'] = 'test2'

    assert var_0['a']['b']['c'] == 'test'
    assert var_0['a']['c'] == 'test2'

    assert get_tree_node(var_0, 'a:b:c') == 'test'
    assert get_tree_node(var_0, 'a:c') == 'test2'

    assert getattr(var_0.get('a:b:c'), '__call__') is None
    assert getattr(var_0.get('a:c'), '__call__') is None


# Generated at 2022-06-26 02:56:47.171845
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    key = ':'.join([str(i) for i in range(100)])
    value = 'foo'
    res = set_tree_node(mapping, key, value)



# Generated at 2022-06-26 02:56:55.089034
# Unit test for function get_tree_node
def test_get_tree_node():
    env_0 = tree()
    env_0['type']['base']['name'] = 'Language'
    env_0['type']['base']['python']['name'] = 'Language.Python'
    env_0['type']['base']['python']['name_short'] = 'Python.Python'
    env_0['type']['base']['python']['path'] = 'type.base.python'
    env_0['type']['base']['python']['python']['name'] = 'Python.Python.Python'
    env_0['type']['base']['python']['python']['name_short'] = 'Python.Python'

# Generated at 2022-06-26 02:56:59.846297
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_1 = tree()

# Generated at 2022-06-26 02:57:02.827695
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO: make this test useful
    var_1 = get_tree_node(var_0, 'something')
    return var_1


# Generated at 2022-06-26 02:57:13.553217
# Unit test for function set_tree_node
def test_set_tree_node():

    # No arg test
    assert set_tree_node(tree(), 
                         "a:b:c", 
                         "d") == {"a": {"b": {"c": "d"}}}
    assert set_tree_node(tree(), 
                         "a",
                         "a") == {"a": "a"}

    # One arg test
    assert set_tree_node(Tree(), 
                         "a:b:c", 
                         "d") == {"a": {"b": {"c": "d"}}}
    assert set_tree_node(Tree(), 
                         "a",
                         "a") == {"a": "a"}

    assert set_tree_node(Tree(), 
                         ":a:b:c", 
                         "d") == {"a": {"b": {"c": "d"}}}
    assert set_tree

# Generated at 2022-06-26 02:57:16.955485
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    # Test case 0


# Generated at 2022-06-26 02:57:23.724284
# Unit test for function set_tree_node
def test_set_tree_node():
    key_0 = 'a:a:a'
    value_0 = 'b'
    var_0 = set_tree_node(tree, key_0, value_0)
    key_1 = 'a:a:a'
    value_1 = None
    value_1 = var_0.get(key_1, value_1)
    assert value_1 == 'b'


# Generated at 2022-06-26 02:57:33.195057
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    set_tree_node(d, 'a:b:c:d:e', 'hither')
    assert d['a']['b']['c']['d']['e'] == 'hither'

    set_tree_node(d, 'a:b:c:d', 'thither')
    assert d['a:b:c:d'] == 'thither'



# Generated at 2022-06-26 02:59:17.163627
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {'foo': {'bar': {'x': 1, 'y': 2}}}
    assert get_tree_node(data, 'foo:bar:x') == 1
    assert get_tree_node(data, 'foo:bar:y') == 2
    # assert get_tree_node(data, 'foo:bar:z') == 3
    assert get_tree_node(data, 'foo:bar:z', 3) == 3

