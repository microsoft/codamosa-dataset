

# Generated at 2022-06-26 02:49:24.281672
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    set_tree_node(tree_0, 'a:b:c:d:e:f:g', 1)
    set_tree_node(tree_0, 'a:b:c:d:e:f:h', 2)
    set_tree_node(tree_0, 'a:b:c:i:j:k:l', 3)
    set_tree_node(tree_0, 'a:b:c:i:j:k:l', 2)
    assert tree_0 == {'a': {'b': {'c': {'d': {'e': {'f': {'g': 1, 'h': 2}}},
                                    'i': {'j': {'k': {'l': 2}}}}}}}


# Generated at 2022-06-26 02:49:34.007954
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test case data
    TREE_0 = (
        {
            'key_0': 'value_0',
            'key_1': {
                'key_2': 'value_1',
                'key_3': 'value_2'
            },
            'key_4': 'value_3'
        },
        {
            'key_0': 'value_0',
            'key_1': {
                'key_2': 'value_1',
                'key_3': 'value_2',
                'key_5': 'value_4'
            },
            'key_4': 'value_3'
        }
    )

    # Test case execution
    tree_0 = TREE_0[0]

# Generated at 2022-06-26 02:49:37.725356
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': 1}, 'a') == 1
    assert get_tree_node({'a': 1}, 'b', 'd') == 'd'
    assert get_tree_node({'a': {'b': 1}}, 'a:b') == 1
    assert get_tree_node({'a': {'b': 1}}, 'a:c') is None

# Generated at 2022-06-26 02:49:39.490338
# Unit test for function get_tree_node
def test_get_tree_node():
    pass

# Generated at 2022-06-26 02:49:40.753973
# Unit test for function get_tree_node
def test_get_tree_node():

    pass


# Generated at 2022-06-26 02:49:44.398452
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    tree_0.set_tree_node({'a': {'b': 'c'}}, 'a:b', 'c')
    assert tree_0.get('a:b') == 'c'


# Generated at 2022-06-26 02:49:54.778867
# Unit test for function get_tree_node
def test_get_tree_node():

    assert(get_tree_node({}, 'a') is _sentinel)
    assert(get_tree_node({'a': 1}, 'a') == 1)
    assert(get_tree_node({'a': 1}, 'b') is _sentinel)
    assert(get_tree_node({'a': {'b': 1}}, 'a:b') == 1)
    assert(get_tree_node({'a': {'b': 1}}, 'a:b', default=2) == 1)
    assert(get_tree_node({'a': {'b': 1}}, 'a:c', default=2) == 2)
    assert(get_tree_node({'a': {'b': 1}}, 'a:b', default=2, parent=True) == {'b': 1})

# Generated at 2022-06-26 02:49:58.232213
# Unit test for function get_tree_node
def test_get_tree_node():
    actual = get_tree_node(tree, 'a:b:c')
    expected = tree['a']['b']['c']
    assert actual == expected, "TEST #1 FAILED"


# Generated at 2022-06-26 02:50:09.727582
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test that using an invalid key raises a KeyError
    try:
        tree_0 = Tree()
        get_tree_node(tree_0, 'key')
    except KeyError:
        pass
    else:
        raise Exception("Function get_tree_node does not throw KeyError when given an invalid key")

    # Test that using a valid key does not raise a KeyError
    tree_1 = Tree()
    tree_1['key'] = 'value'
    try:
        get_tree_node(tree_1, 'key')
    except KeyError:
        raise Exception("Function get_tree_node throws a KeyError when given a valid key")

    # Test that using a valid key returns the correct value
    tree_2 = Tree()
    tree_2['key'] = 'value'

# Generated at 2022-06-26 02:50:13.950277
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = tree()
    set_tree_node(tree, 'one:two:three', {'some': 'thing'})
    assert get_tree_node(tree, 'one:two:three').get('some') == 'thing'

    tree_2 = Tree()
    tree_2.set('one:two:three', {'some': 'thing'})
    assert tree_2.get('one:two:three').get('some') == 'thing'



# Generated at 2022-06-26 02:50:16.432967
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(dict(), str()) == None


# Generated at 2022-06-26 02:50:26.895274
# Unit test for function get_tree_node
def test_get_tree_node():
    # Initializes data to be used in tests
    test_initial = {
        'key': {
            'parent': {
                'node': 'value'
            }
        }
    }
    test_default = 'default_value'
    test_key = 'key:parent:node'
    test_parent = True
    # Returns an instance of the class you're testing
    var_0 = Tree(initial=test_initial)
    # Gets a function to test
    function_to_test = get_tree_node
    # Gets arguments to pass to the function
    args = [var_0, test_key, test_default, test_parent]
    # Gets expected output
    expected_output = 'value'
    # Calls the function and saves results
    results = function_to_test(*args)
    # Checks if function returned expected

# Generated at 2022-06-26 02:50:37.100008
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    set_tree_node(var_1, "foo", "bar")
    set_tree_node(var_1, "foo:bar:1:abc", "def")
    set_tree_node(var_1, "foo:bar:2:abc", "def")
    set_tree_node(var_1, "foo:bar:3:abc", "def")
    set_tree_node(var_1, "foo:bar:4:abc", "def")
    set_tree_node(var_1, "foo:bar:5:abc", "def")
    set_tree_node(var_1, "foo:bar:6:abc", "def")


# Generated at 2022-06-26 02:50:48.609509
# Unit test for function get_tree_node
def test_get_tree_node():
    dottedpath_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test = 0

# Generated at 2022-06-26 02:50:56.673473
# Unit test for function set_tree_node
def test_set_tree_node():
    import re, sys, os, inspect
    name = os.path.join(os.path.dirname(__file__),__name__+'.py')
    this_dir = os.path.dirname(name)
    sys.path.append(this_dir)
    function_name = inspect.currentframe().f_code.co_name
    tree = get_tree_node(var_0, function_name, default={})
    if not tree:
        tree = {}
        set_tree_node(var_0, function_name, tree)
    tree['name'] = "test_set_tree_node"
    tree['tree'] = var_0
    tree['test_set_tree_node'] = tree
    tree['test_case_0'] = {'var_0': var_0}

# Generated at 2022-06-26 02:51:00.377645
# Unit test for function get_tree_node
def test_get_tree_node():
    foo = tree()
    foo['one']['two']['three'] = 'bar'
    assert get_tree_node(foo, 'one:two:three') == 'bar'
    assert get_tree_node(foo, 'one:two', parent=True) == {'three': 'bar'}



# Generated at 2022-06-26 02:51:07.076716
# Unit test for function set_tree_node
def test_set_tree_node():

    # Test case for set_tree_node
    test_tree = RegistryTree()
    test_tree.register('three:two:one:value', 'two', namespace='one')
    test_tree.register('three:two:one:value', 'one', namespace='two')
    test_tree.register('three:two:one:value', 'three')
    test_tree.register('three:two:one:value', 'four', namespace='three')
    assert test_tree['three:two:one'] == 'two'
    assert test_tree['three:two'] == 'one'
    assert test_tree['three'] == 'three'

# Generated at 2022-06-26 02:51:14.714737
# Unit test for function get_tree_node
def test_get_tree_node():
    # Get a value that exists
    try:
        assert get_tree_node({'foo': [1, 2, 3]}, 'foo') == [1, 2, 3]
    except:
        print('failed test #1')

    # Get a value that doesn't exist
    try:
        assert get_tree_node({'foo': [1, 2, 3]}, 'bar') is _sentinel
    except:
        print('failed test #2')

    # Get a value that exists, but has a different type than the default
    try:
        assert get_tree_node({'foo': [1, 2, 3]}, 'foo', None) == [1, 2, 3]
    except:
        print('failed test #3')

    # Get a value that doesn't exist, but has a default

# Generated at 2022-06-26 02:51:18.462818
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {"a": 1}
    assert set_tree_node(a, "a", 2) == {"a": 2}

    b = tree()
    set_tree_node(b, "a:b:c", 15)
    assert len(b.keys()) == 1
    assert b["a"]["b"]["c"] == 15

    c = tree()
    set_tree_node(c, "a:b:c", 15)
    set_tree_node(c, "a:b:d", 19)
    set_tree_node(c, "a:e", 200)
    set_tree_node(c, "a:e", 300)
    assert len(c.keys()) == 1
    assert len(c["a"].keys()) == 3

# Generated at 2022-06-26 02:51:23.872720
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Function get_tree_node test stub.

    Generic function to test `get_tree_node`, i.e. a function returning a node
    from a tree like structure based on a key, which can be of a specific `delimiter`
    to separate dimensions.

    :return: Test result
    :rtype: int
    """

    assert isinstance(var_0, tree)

    return 0

# Generated at 2022-06-26 02:51:31.498517
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0[('a', 'b', 'c')] = 1
    var_1 = get_tree_node(var_0, ('a', 'b', 'c'))
    assert var_1 == 1



# Generated at 2022-06-26 02:51:41.706653
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()

    assert get_tree_node(var_0, 'foo', default='default') == 'default'
    var_0['foo'] = 'bar'
    assert get_tree_node(var_0, 'foo', default='default') == 'bar'

    set_tree_node(var_0, 'a:b:c', 'foo')
    assert get_tree_node(var_0, 'a:b') == {'c': 'foo'}
    assert get_tree_node(var_0, 'a') == {'b': {'c': 'foo'}}
    assert get_tree_node(var_0, 'a') == {'b': {'c': 'foo'}}



# Generated at 2022-06-26 02:51:43.516480
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {'foo': {'bar': 'baz'}}
    var_1 = 'foo:bar'
    var_2 = get_tree_node(var_0, var_1)
    assert var_2 == 'baz'



# Generated at 2022-06-26 02:51:46.908886
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'some': {'nested': 'dicts'}, 'and': {'other': {'deeper': 'nested'}}}, 'and:other:deeper') == 'nested'


# Generated at 2022-06-26 02:51:48.183111
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(var_0, 'eggs')


# Generated at 2022-06-26 02:51:55.954656
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = collections.defaultdict(tree)
    var_0[1][1] = 'a'
    var_0[1][2] = 'b'
    var_0[2][1] = 'c'
    var_0[2][2] = 'd'
    var_0[2][3] = 'e'
    var_1 = var_0[1][1]
    assert var_1 == 'a'
    var_2 = var_0[2][3]
    assert var_2 == 'e'
    var_3 = var_0[1][2]
    assert var_3 == 'b'
    var_4 = var_0[2][1]
    assert var_4 == 'c'
    var_5 = get_tree_node(var_0, '1:1')

# Generated at 2022-06-26 02:51:58.397716
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, 'var_1', 'test_str')


# Generated at 2022-06-26 02:52:01.209200
# Unit test for function set_tree_node
def test_set_tree_node():
    """set_tree_node"""

    var_0 = set_tree_node(tree(), 'key_0', 0)

    assert var_0 is not None



# Generated at 2022-06-26 02:52:07.667235
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = get_tree_node(var_0, 'nested:deeply:key', default='default')
    assert 'default' == var_1
    var_0['nested']['deeply']['key'] = 'value'
    var_2 = get_tree_node(var_0, 'nested:deeply:key')
    assert 'value' == var_2


# Generated at 2022-06-26 02:52:14.290676
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': {'baz': 'quux'}},
               'tea': 'coffee'}
    print(get_tree_node(mapping, 'foo:bar:baz'))
    print(get_tree_node(mapping, 'foo:bar:baz', parent=True))
    print(get_tree_node(mapping, 'foo:bar:baz', parent='bingo'))
    print(get_tree_node(mapping, 'foo:bar:baz', parent=False, default='bingo'))
    print(get_tree_node(mapping, 'foo:bar', default='fofofo'))
    print(get_tree_node(mapping, 'foo:bark'))

# Generated at 2022-06-26 02:52:19.339007
# Unit test for function set_tree_node
def test_set_tree_node():
    assert globals()['var_0'] == tree()


# Generated at 2022-06-26 02:52:28.108459
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 1,
                'd': 2
            },
            'f': {
                'g': 3,
                'h': 4
            }
        }
    }

    assert get_tree_node(tree, 'a:f:h') == 4
    assert get_tree_node(tree, 'a:b') == {'c': 1, 'd': 2}
    assert get_tree_node(tree, 'a:b:c') == 1
    assert get_tree_node(tree, 'a:b:c', parent=True) == {'d': 2}



# Generated at 2022-06-26 02:52:37.276024
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = collections.defaultdict(list, {'i': -9})
    var_2 = collections.defaultdict(list, {'i': -9})
    var_1[0].append(5)
    var_2[0].append(5)
    var_1[1] = {0: 1, 1: 2}
    var_2[1] = {0: 1, 1: 2}
    var_1[2] = {0: 1, 1: 2}
    var_2[2] = {0: 1, 1: 2}
    var_1[2][0] = var_1[1]
    var_2[2][0] = var_2[1]
    var_1[2][0][0] = var_1[0]

# Generated at 2022-06-26 02:52:43.202950
# Unit test for function get_tree_node
def test_get_tree_node():
    assert(get_tree_node(dict({}), '', 'default') == 'default')
    assert(get_tree_node(dict({'foo': dict({'bar': dict({})})}), 'foo:bar', 'default') == dict({}))
    assert(get_tree_node(dict({'foo': dict({'bar': dict({})})}), 'foo:bar:baz', 'default') == 'default')
    assert(get_tree_node(dict({'foo': dict({'bar': dict({})})}), 'foo:bar:baz') == None)
    assert(get_tree_node(dict({}), '') == None)
    assert(get_tree_node(dict({'foo': dict({'bar': dict({})})}), 'foo:bar') == dict({}))

# Generated at 2022-06-26 02:52:45.196243
# Unit test for function set_tree_node
def test_set_tree_node():
    assert callable(set_tree_node)


# Generated at 2022-06-26 02:52:49.638821
# Unit test for function get_tree_node
def test_get_tree_node():
    test_key = "a:b:c:d:e"
    test_value = 0
    test_mapping = tree()
    assert test_value == get_tree_node(test_mapping, test_key, test_value)
    test_mapping['a']['b']['c']['d']['e'] = test_value
    assert test_value == get_tree_node(test_mapping, test_key, test_value)



# Generated at 2022-06-26 02:52:55.978558
# Unit test for function get_tree_node
def test_get_tree_node():

    # This is the 1st test case
    var_0 = tree()

    value = get_tree_node(var_0, 'namespace:key', default=_sentinel, parent=False)

    # print var_0
    # print value



# Generated at 2022-06-26 02:53:04.234644
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = {}
    set_tree_node(var_0, 'var_0:var_1', 'test_var_1')
    set_tree_node(var_0, 'var_0:var_2', 'test_var_2')

# Generated at 2022-06-26 02:53:04.928918
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()



# Generated at 2022-06-26 02:53:10.402311
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node
    """

# Generated at 2022-06-26 02:53:25.141661
# Unit test for function set_tree_node
def test_set_tree_node():
    print('Testing set_tree_node')
    test_cases = [
        [{'foo': 'bar'}, 'shit:fuck:bollocks', 'poo'],
        [tree(), 'shit:fuck:bollocks', 'poo'],
    ]
    for args in test_cases:
        tree_node = set_tree_node(*args)
        tree_sub_node = args[0]
        for key in args[1].split(':'):
            tree_sub_node = tree_sub_node.get(key)
        print("Resulting node at %s: " % args[1], tree_sub_node)
        # TODO Compare value of tree_sub_node to last member of tree_node


# Generated at 2022-06-26 02:53:28.787261
# Unit test for function set_tree_node
def test_set_tree_node():
    nodes = {}
    set_tree_node(nodes, 'foo:bar:faz', 'baz')

    assert nodes == {'foo': {'bar': {'faz': 'baz'}}}


# Generated at 2022-06-26 02:53:30.617098
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node("a", "b", "c") == ('a', ('b', ('c',)))
    assert 1 == 1



# Generated at 2022-06-26 02:53:38.232186
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a:b:c': 1,
        'a:b:d': 2,
        'a:c:e': 3,
        'd:e:f': 4
    }

    assert get_tree_node(mapping, 'a:b:c') == 1
    assert get_tree_node(mapping, 'a:b:c', default=None) == 1
    assert get_tree_node(mapping, 'a:b:b', default=None) is None
    assert get_tree_node(mapping, 'a:b:b', default=_sentinel) is _sentinel



# Generated at 2022-06-26 02:53:47.713938
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = 'foo'
    var_2 = 'bar'
    var_3 = {var_1: var_2}
    set_tree_node(var_0, 'foo:bar', 'foobar')
    var_0 = {'foo': {'bar': 'foobar'}}
    assert var_0 == var_3, '{var_0} == {var_3}'


# Generated at 2022-06-26 02:53:53.630805
# Unit test for function set_tree_node
def test_set_tree_node():
    # setup
    mapping = None
    key = 'var_0'
    value = None

    # procedure
    tree_node = set_tree_node(mapping, key, value)

    # results
    assert tree_node == None



# Generated at 2022-06-26 02:54:01.719257
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_0['a']['b']['c'] = 'd'
    var_0['a']['b']['e'] = 'f'
    var_0['a']['i']['j'] = 'k'
    print(var_0)

    h = set_tree_node(var_0, 'a:b:f', 'hello')
    print(var_0)
    print(h)
    set_tree_node(var_0, 'a:b:f', 'goodbye')
    print(var_0)
    print(h)



# Generated at 2022-06-26 02:54:09.716525
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['nested']['key'] = 'value'
    var_1 = get_tree_node(var_0, 'nested:key')
    var_2 = get_tree_node(var_0, 'nested:key', _sentinel)
    var_3 = get_tree_node(var_0, 'nested:key:nope', _sentinel)
    pass


# Generated at 2022-06-26 02:54:20.272592
# Unit test for function get_tree_node
def test_get_tree_node():
    # Maybe I should write some tests...
    var_0 = tree()
    var_0['foo']['bar'] = 'baz'
    var_1 = var_0['foo']['bar']
    assert var_1 == 'baz', "o_O O_o"
    var_2 = var_0['foo:bar']
    assert var_2 == 'baz', "o_O O_o"
    del var_0['foo']['bar']
    try:
        var_3 = var_0['foo']['bar']
    except KeyError:
        pass



# Generated at 2022-06-26 02:54:25.062437
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = collections.defaultdict(int)
    test_mapping[1][2][3] = 4
    assert get_tree_node(test_mapping, '1:2:3') == 4



# Generated at 2022-06-26 02:54:49.522476
# Unit test for function get_tree_node
def test_get_tree_node():
    print(u'Testing get_tree_node')
    # Initialize test data.
    mapping = tree()
    key = 'foo'
    default = None
    parent = True
    expected_value = None

    # Call function get_tree_node with args mapping, key, default and parent.
    actual_value = get_tree_node(mapping, key, default, parent)

    # Assert result equals expected.
    assert actual_value == expected_value


# Generated at 2022-06-26 02:54:55.715551
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, ":test:test:test", 1)
    var_1 = get_tree_node(var_0, ":test:test:test")
    assert var_1 == 1


# Generated at 2022-06-26 02:55:02.836846
# Unit test for function set_tree_node
def test_set_tree_node():
    # Raise TypeError if `mapping` isn't a collections.Mapping
    # Raise TypeError if `key` isn't str or unicode
    # Raise TypeError if `value` isn't str or unicode
    # Set arbitrary node on a tree-like mapping structure, allowing for : notation to signify dimension.
    # Arguments:
    #     mapping collections.Mapping: Mapping to fetch from
    #     key str|unicode: Key to set, allowing for : notation
    #     value str|unicode: Value to set `key` to
    #     parent bool: If True, return parent node. Defaults to False.
    # Returns:
    #     object: Parent node.
    pass


# Generated at 2022-06-26 02:55:13.587452
# Unit test for function get_tree_node
def test_get_tree_node():
    print ("Testing 'get_tree_node'")
    var_0 = tree()
    var_1 = {'a': 5}
    var_0['a']['b']['c']['d'] = var_1
    assert get_tree_node(var_0, 'a:b:c:d') == var_1

    var_0 = {'a': 5}
    var_1 = 'a:b:c:d'
    assert get_tree_node(var_0, var_1) == var_0['a']
    assert get_tree_node(var_0, var_1, default="absent") == var_0['a'] == 5

# Generated at 2022-06-26 02:55:24.495631
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = set_tree_node(var_0,'key_0','val_0')
    assert var_1 == {'key_0': 'val_0'}

    var_0 = tree()
    var_1 = set_tree_node(var_0,'key_0:key_1:key_2','val_0')
    assert var_1 == {'key_0': {'key_1': {'key_2': 'val_0'}}}
    assert var_0 == {'key_0': {'key_1': {'key_2': 'val_0'}}}

    var_0 = tree()
    var_1 = set_tree_node(var_0,'key_0:key_1:key_2','val_0',parent=True)

# Generated at 2022-06-26 02:55:33.268189
# Unit test for function set_tree_node
def test_set_tree_node():
    """Raise exception for function 'test_set_tree_node'."""
    try:
        set_tree_node(var_0, 'key', 'value')
        assert False
    except KeyError as exc:
        pass
    # Do repr

# Generated at 2022-06-26 02:55:42.866391
# Unit test for function set_tree_node
def test_set_tree_node():
    class TestCases(object):
        class TestCase_0(object):
            def __init__(self):
                # Set up paramaters
                self.mapping = tree()
                self.key = u"namespace:foo:bar:0"
                self.value = u"some-value"
                # Set up expected results
                self.expected = u"some-value"
                # Perform test
                self.actual = set_tree_node(self.mapping, self.key, self.value)
                # Verify
                self.assertEqual(self.actual, self.expected)
            def assertEqual(self, actual, expected):
                if actual != expected:
                    raise AssertionError("Got %r expected %r" % (actual, expected))

# Generated at 2022-06-26 02:55:50.476475
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_node = tree()

    tree_node['key_1'] = {'key_2': 'value'}
    assert get_tree_node(tree_node, 'key_1') == tree_node['key_1']
    assert get_tree_node(tree_node, 'key_1:key_2') == tree_node['key_1']['key_2']
    assert get_tree_node(tree_node, 'key_0', default=None) is None



# Generated at 2022-06-26 02:55:57.491539
# Unit test for function set_tree_node
def test_set_tree_node():
    try:
        # AssertionError: assert None == 'test'
        assert set_tree_node(tree(), 'test', None) == 'test'
    except AssertionError as exc:
        # Not sure why the last message is still the previous assertion error.
        raise AssertionError(str(exc))


# Generated at 2022-06-26 02:56:01.244518
# Unit test for function get_tree_node
def test_get_tree_node():
    key = 'var_0:var_1'
    value = 'var_2:var_3:var_4'
    test_case_0[key] = value
    assert get_tree_node(test_case_0, key) == value


# Generated at 2022-06-26 02:56:41.638713
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function get_tree_node

    Arguments:
        None

    Returns:
        None

    Raises:
        None
    """
    raise NotImplementedError('Test not implemented')


# Generated at 2022-06-26 02:56:51.947066
# Unit test for function get_tree_node
def test_get_tree_node():
    try:
        assert get_tree_node({}, 'a') is _sentinel
    except KeyError:
        pass
    try:
        assert get_tree_node(tree(), 'a') is _sentinel
    except KeyError:
        pass
    try:
        assert get_tree_node(Tree(), 'a') is _sentinel
    except KeyError:
        pass

    assert get_tree_node({}, 'a', None) is None
    assert get_tree_node(tree(), 'a', None) is None
    assert get_tree_node(Tree(), 'a', None) is None



# Generated at 2022-06-26 02:57:00.659808
# Unit test for function get_tree_node
def test_get_tree_node():

    # Setup mock data for testing
    mock_mapping = 5
    mock_key = 5
    mock_default = 5
    mock_parent = 5

    # Call function under test
    result = get_tree_node(mock_mapping, mock_key, mock_default, mock_parent)

    # Check if results are as expected
    ## TODO: Assertions.


# Generated at 2022-06-26 02:57:07.840519
# Unit test for function get_tree_node
def test_get_tree_node():
    # Simple case:
    assert get_tree_node({'test': 'value'}, 'test'), 'value'

    # KeyError raised:
    with pytest.raises(KeyError):
        get_tree_node({'test': 'value'}, 'no_such_key')

    # KeyError not raised:
    assert get_tree_node({'test': 'value'}, 'no_such_key', default='default') == 'default'

    # Parent not returned:
    assert get_tree_node({'test': 'value', 'test2': {'test3': 'value3'}}, 'test2:test3') == 'value3'

    # Parent returned:

# Generated at 2022-06-26 02:57:12.471719
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 2 == get_tree_node(
        {
            'foo': {
                'bar': 1,
                'baz': 2
            }
        },
        'foo:baz'
    )



# Generated at 2022-06-26 02:57:22.575696
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(var_0, 'a:b:c:d:e', default='f') == 'f'
    assert get_tree_node(var_0, 'a:b:c:d:e', default=None) is None
    try:
        assert get_tree_node(var_0, 'a:b:c:d:e')
    except:
        pass
    else:
        assert False


# Generated at 2022-06-26 02:57:23.255786
# Unit test for function get_tree_node
def test_get_tree_node():
    pass

# Generated at 2022-06-26 02:57:35.366698
# Unit test for function set_tree_node
def test_set_tree_node():
    # Empty mapping
    var_0 = {}
    var_1 = 'test_key_0'
    var_2 = 'test_value_0'
    var_3 = set_tree_node(var_0, var_1, var_2)
    var_4 = var_3['test_key_0']
    assert var_4 == 'test_value_0'
    # Mapping given
    var_0 = {'test_key_0': 'test_value_0'}
    var_1 = 'test_key_0'
    var_2 = 'test_value_1'
    var_3 = set_tree_node(var_0, var_1, var_2)
    var_4 = var_3['test_key_0']
    assert var_4 == 'test_value_1'

# Generated at 2022-06-26 02:57:46.647609
# Unit test for function get_tree_node
def test_get_tree_node():
    original = {
        'a': {
            'b': {
                'c': '1',
                'd': '2',
            },
            'e': {
                'f': '3',
                'g': '4',
            },
        },
        'h': {
            'i': {
                'j': '5',
            },
        },
    }
    print('TEST get_tree_node')
    result = get_tree_node(original, 'a:b:c')
    if result == '1':
        print('[SUCCESS] Original value retrieved correctly')
    else:
        print('[FAILED] Incorrect value retrieved')
        print('Expected: %r' % '1')
        print('Received: %r' % result)

    result = get_tree_node

# Generated at 2022-06-26 02:57:57.197162
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['test']['test2'] = "foo"
    var_1 = get_tree_node(var_0,'test')
    var_2 = var_1 == {'test2': 'foo'}
    var_3 = get_tree_node(var_0,'test:test2')
    var_4 = var_3 == 'foo'
    var_5 = get_tree_node(var_0,'test_no_key')
    var_6 = get_tree_node(var_0,'test_no_key', default='bar')
    var_7 = var_6 == 'bar'
    var_8 = get_tree_node(var_0,'test:test2', parent=True)