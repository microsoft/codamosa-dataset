

# Generated at 2022-06-26 02:49:18.758713
# Unit test for function set_tree_node
def test_set_tree_node():
    instance = tree()
    result = set_tree_node(instance, 'server:name', 'localhost')
    assert result == {'server': {'name': 'localhost'}}



# Generated at 2022-06-26 02:49:24.256050
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['hello']['there']['human'] = 'friend'
    assert get_tree_node(mapping, 'hello:there:human') == 'friend'

    with pytest.raises(KeyError):
        get_tree_node(mapping, 'hello:there:no')




# Generated at 2022-06-26 02:49:29.635618
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'a': {'b': 'c'}}
    assert get_tree_node(tree, 'a') == {'b': 'c'}
    assert get_tree_node(tree, 'a:b') == 'c'
    assert get_tree_node(tree, 'd') is _sentinel
    assert get_tree_node(tree, 'a:b:c') is _sentinel



# Generated at 2022-06-26 02:49:31.167049
# Unit test for function set_tree_node
def test_set_tree_node():
    assert False, 'TODO Implement set_tree_node'


# Generated at 2022-06-26 02:49:38.765737
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = collections.OrderedDict()

    test_tree['a'] = 1
    test_tree['b'] = {'c': 2, 'd': 3}

    assert get_tree_node(test_tree, 'b') == {'c': 2, 'd': 3}
    assert get_tree_node(test_tree, 'b:c') == 2
    assert get_tree_node(test_tree, 'b:c', default=None) == 2
    assert get_tree_node(test_tree, 'i') is None
    assert get_tree_node(test_tree, 'z') is None
    assert get_tree_node(test_tree, 'j') is None
    assert get_tree_node(test_tree, 'j', default=None) is None

# Generated at 2022-06-26 02:49:48.495732
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {'foo': {'blah': 'bar'}}
    assert get_tree_node(a, 'foo:blah', _sentinel) == 'bar'
    assert get_tree_node(a, 'foo:blah2', _sentinel) is _sentinel
    try:
        get_tree_node(a, 'foo:blah2')
    except KeyError:
        pass
    else:
        raise AssertionError("KeyError not raised")
    assert get_tree_node(a, 'foo', _sentinel) == {'blah': 'bar'}
    assert get_tree_node(a, 'foo', _sentinel, parent=True) == a
    assert get_tree_node(a, 'bar', 'blah') == 'blah'

# Generated at 2022-06-26 02:49:55.213277
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {"a": {"b": "c"}}

    assert get_tree_node(test_dict, "a") == {"b": "c"}
    assert get_tree_node(test_dict, "a:b") == "c"

    test_dict = {"a": {"b": {"c": "d"}}}

    assert get_tree_node(test_dict, "a:b") == {"c": "d"}
    assert get_tree_node(test_dict, "a:b:c") == "d"



# Generated at 2022-06-26 02:49:56.511160
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Woohoo!
    """
    return True



# Generated at 2022-06-26 02:50:08.260500
# Unit test for function set_tree_node
def test_set_tree_node():
    saw_special_class = False
    saw_special_method = False
    saw_special_node = False

    d = {'a': {'b': {'c': 42, 'd': 'foo'}}}
    assert set_tree_node(d, 'a:b:c', 'bar') == {'c': 'bar', 'd': 'foo'}
    assert d == {'a': {'b': {'c': 'bar', 'd': 'foo'}}}

    try:
        # No value for key `a`
        set_tree_node(d, 'a:c:d', 'bar')
    except Exception as exc:
        assert isinstance(exc, KeyError)
        saw_special_class = True
    assert saw_special_class

    saw_special_class = False

# Generated at 2022-06-26 02:50:13.950222
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {'a': 'foo', 'b': {'c': 'bar', 'd': 'asdf'}}
    assert get_tree_node(test_dict, 'a') == 'foo'
    assert get_tree_node(test_dict, 'b:d') == 'asdf'
    assert get_tree_node(test_dict, 'b') == {'c': 'bar', 'd': 'asdf'}
    try:
        get_tree_node(test_dict, 'f')
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-26 02:50:17.710353
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(var_0, 'key0', 'value0') != None


# Generated at 2022-06-26 02:50:28.189203
# Unit test for function get_tree_node
def test_get_tree_node():

    from collections import OrderedDict

    # Test with a tree-like mapping (dictionary)
    tree_like_dict = OrderedDict()
    tree_like_dict["one"] = "two"
    tree_like_dict["three"] = OrderedDict()
    tree_like_dict["three"]["four"] = "five"

    # Test with no namespace
    assert get_tree_node(tree_like_dict, "one") == "two"
    assert get_tree_node(tree_like_dict, "three:four") == "five"

    # Test with a namespace
    assert get_tree_node(tree_like_dict, "one", namespace="tld") == "two"
    assert get_tree_node(tree_like_dict, "three:four", namespace="tld") == "five"

# Generated at 2022-06-26 02:50:29.609692
# Unit test for function get_tree_node
def test_get_tree_node():
   assert False


# Generated at 2022-06-26 02:50:40.174681
# Unit test for function get_tree_node
def test_get_tree_node():
    # E = event
    # O = outcome

    # E: set {'foo': {'bar': 'baz'}} (Tree)
    var_0 = tree()

    var_1 = ['foo', 'bar', 'baz']
    var_1.append(var_0)
    var_1.append(var_0)

    var_1.insert(1, var_0)
    # var_0['foo']
    # E: set {'bar': 'baz'} (Tree) on var_0['foo']
    var_0['foo']['bar'] = 'baz'
    # E: set 'baz' (str) on var_0['foo']['bar']
    var_0['foo']['bar'] = 'baz'

    # E: set {} (Tree) on var

# Generated at 2022-06-26 02:50:48.229085
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['foo']['bar'] = 'baz'
    var_1 = get_tree_node(var_0, 'foo:bar', 'default')
    assert var_1 == 'baz'
    var_2 = get_tree_node(var_0, 'foo', 'default')
    assert var_2 == {'bar': 'baz'}
    var_3 = get_tree_node(var_0, 'fooo:bar', 'default')
    assert var_3 == 'default'
    var_4 = get_tree_node(var_0, 'foo:barr', 'default')
    assert var_4 == 'default'


# Generated at 2022-06-26 02:50:51.074864
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {}
    var_1 = 'test'
    var_2 = get_tree_node(var_0, var_1)
    assert var_2 == _sentinel


# Generated at 2022-06-26 02:50:59.597148
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = get_tree_node(collections.OrderedDict([('a', 1), ('b', 2), ('c', 3)]), 'a')
    assert var_0 == 1
    var_1 = get_tree_node(collections.OrderedDict([('a', 1), ('b', 2), ('c', 3)]), 'b')
    assert var_1 == 2
    var_2 = get_tree_node(collections.OrderedDict([('a', 1), ('b', 2), ('c', 3)]), 'c')
    assert var_2 == 3

# Generated at 2022-06-26 02:51:10.570222
# Unit test for function get_tree_node
def test_get_tree_node():
    from unittest import TestCase, main

    class TestGetTreeNode(TestCase):

        def test_case_0(self):
            var_0 = tree()
            var_0['a']['b']['c'] = 0
            var_0['a']['b']['d'] = 1
            var_0['a']['b']['e'] = 2
            var_0['a']['f']['g'] = 3
            var_0['a']['f']['h']['i'] = 4
            self.assertEqual(get_tree_node(var_0, 'a:b:c'), 0)
            self.assertEqual(get_tree_node(var_0, 'a:b:d'), 1)

# Generated at 2022-06-26 02:51:21.720477
# Unit test for function set_tree_node
def test_set_tree_node():
    my_tree_3 = tree()
    set_tree_node(my_tree_3, 'foobar', 'baz')
    assert my_tree_3 == {'foobar': 'baz'}

    set_tree_node(my_tree_3, 'foo:bar', 'baz')
    assert my_tree_3 == {'foobar': 'baz', 'foo': {'bar': 'baz'}}

    set_tree_node(my_tree_3, 'foo:baz:bar', 'baz')
    assert my_tree_3 == {'foobar': 'baz', 'foo': {'bar': 'baz', 'baz': {'bar': 'baz'}}}


# Generated at 2022-06-26 02:51:28.061049
# Unit test for function get_tree_node
def test_get_tree_node():
    # Set up test case
    var_0 = tree()
    var_0['']['banana']['chocolate'] = 'test'
    var_0['']['banana']['rock'] = 'test'
    var_0['']['banana']['tree'] = 'test'
    var_0['']['banana']['apple'] = 'test'

    # Run function
    var_1 = get_tree_node(var_0, '', None)

    # Check result
    assert var_1 == {}



# Generated at 2022-06-26 02:51:42.116447
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'base' : {
            'a' : 'b',
            'b' : 'c'
        },
        'base:a' : {
            'c' : 'd'
        },
        'base:b' : {
            'c' : 'e'
        },
        'base:a:c': 'f'
    }

    assert get_tree_node(tree, 'base') == {
        'a' : 'b',
        'b' : 'c'
    }

    assert get_tree_node(tree, 'base:a') == {
        'c' : 'd'
    }

    assert get_tree_node(tree, 'base:b') == {
        'c' : 'e'
    }

    # Case of nested value
    assert get_tree

# Generated at 2022-06-26 02:51:43.375048
# Unit test for function set_tree_node
def test_set_tree_node():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:51:46.729980
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['b']['c'] = 3
    assert get_tree_node(var_0, 'a:b')['c'] == 3
    assert get_tree_node(var_0, 'a:b:c') == 3
    assert get_tree_node(var_0, 'a:b:c', default=1) == 3
    assert get_tree_node(var_0, 'a:b:d', default=1) == 1


# Generated at 2022-06-26 02:51:55.106668
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_2 = tree()
    var_3 = tree()
    var_4 = tree()
    var_2['0'] = var_4
    var_1 = tree()
    var_1['0'] = var_2
    var_0['0'] = var_1
    var_5 = var_0['0']['0']['0']
    var_6 = var_5['0']
    var_7 = {'0': '0', '1': '1'}
    var_8 = var_7['0']
    var_9 = {'0': '0', '1': '1'}
    var_9['0'] = var_8
    var_6['0'] = var_9
    return var_0


# Generated at 2022-06-26 02:51:57.436390
# Unit test for function set_tree_node
def test_set_tree_node():

    assert get_tree_node(tree(), 'foo', default=None) is None


# Generated at 2022-06-26 02:52:01.403590
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = set_tree_node('test_set_tree_node', 'a', var_0)
    var_2 = {'a': var_1}
    assert var_2 == var_0


# Generated at 2022-06-26 02:52:11.227318
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'Baz'
        }
    }
    assert get_tree_node(mapping, 'foo:bar') == 'Baz'

    mapping = {
        'foo': {
            'bar': 'Baz'
        }
    }
    assert get_tree_node(mapping, 'foo:bar') == 'Baz'

    # Test parent node
    mapping = {
        'foo': {
            'bar': 'Baz'
        }
    }
    assert get_tree_node(mapping, 'foo:bar', parent=True) == {'bar': 'Baz'}

    # Test with missing node
    mapping = {
        'foo': {
            'bar': 'Baz'
        }
    }

# Generated at 2022-06-26 02:52:17.906584
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = dict()
    base = {'a': {'b': {'c': 'd'}}}
    key = "a:b:c"
    value = "D"
    expect = {'a': {'b': {'c': 'D'}}}
    set_tree_node(test_dict, key, value)
    if test_dict != expect:
        raise AssertionError("Expected: %s, Got: %s, Key: %s" % (expect, test_dict, key))


# Generated at 2022-06-26 02:52:19.756057
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(var_0, 'key_0', default=_sentinel, parent=False) is None


# Generated at 2022-06-26 02:52:22.739144
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = dict()
    test_dict[1] = 0
    assert set_tree_node(test_dict, "1", 2) == None
    assert test_dict[1] == 2
    

# Generated at 2022-06-26 02:52:31.527821
# Unit test for function get_tree_node
def test_get_tree_node():

    # Setup
    var_0 = tree()
    var_0['a']['b']['c'] = 1
    var_1 = var_0['a']['b']['c']

    # Testing code
    assert get_tree_node(var_0, 'a:b:c') == var_1, 'Failed asserting that {} is {}'.format(get_tree_node(var_0, 'a:b:c'), var_1)


# Generated at 2022-06-26 02:52:34.673566
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['test']['test2']['foo'] = 'bar'
    assert get_tree_node(var_0, 'test:test2:foo') == 'bar'


# Generated at 2022-06-26 02:52:39.102714
# Unit test for function set_tree_node

# Generated at 2022-06-26 02:52:43.749416
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': {'d': 'e'}}}}) == {'b': {'c': {'d': 'e'}}}


# Generated at 2022-06-26 02:52:47.274803
# Unit test for function set_tree_node
def test_set_tree_node():
    foo = Tree()
    foo['a:b:c:d'] = 'bar'
    assert (foo['a:b:c:d'] == 'bar'), 'foo["a:b:c:d"] == "bar" Failed'


# Generated at 2022-06-26 02:52:55.533310
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['0:0:0'] = 'hello'
    var_0['0:0:1'] = 'world'
    var_0['0:0:2'] = '!'
    res_0 = get_tree_node(var_0, '0:0:1')
    assert res_0 == 'world'


# Generated at 2022-06-26 02:53:05.882514
# Unit test for function set_tree_node
def test_set_tree_node():
    # Bases
    from collections import OrderedDict
    from io import StringIO
    import json

    # Assignment
    var_0 = OrderedDict()
    var_0['foo'] = OrderedDict()
    var_0['foo']['bar'] = 'baz'
    var_0['foo']['baz'] = 'bar'
    var_1 = json.dumps(var_0)
    var_2 = StringIO()
    var_2.write(str(var_1))
    var_2.seek(0)


# Generated at 2022-06-26 02:53:07.467297
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO: Add your test here for get_tree_node
    pass


# Generated at 2022-06-26 02:53:16.685890
# Unit test for function get_tree_node
def test_get_tree_node():
    # Set testing values
    key = None
    default = _sentinel
    parent = False
    
    # Call function
    try:
        return_value = get_tree_node(mapping, key, default, parent)
    except Exception as e:
        print('Exception raised: ' + str(e))
    else:
        print('No exception raised.')
    
    # Return the results
    return return_value
    

# Generated at 2022-06-26 02:53:20.532699
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node()


# Generated at 2022-06-26 02:53:30.144216
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = collections.defaultdict(tree)
    tree['bar']['foo'] = 'baz'

    # Test with default
    assert get_tree_node(tree, 'bar:foo', default='faz') == 'baz'
    # Test with missing key
    assert get_tree_node(tree, 'bla', default='faz') == 'faz'



# Generated at 2022-06-26 02:53:30.965416
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()



# Generated at 2022-06-26 02:53:32.247374
# Unit test for function get_tree_node
def test_get_tree_node():
    assert True


# Generated at 2022-06-26 02:53:37.687999
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(None, None) == _sentinel
    assert get_tree_node(None, 'hello') == _sentinel
    assert get_tree_node('string', None) == _sentinel
    assert get_tree_node(['a', 'b', 'c'], None) == _sentinel


# Generated at 2022-06-26 02:53:39.526844
# Unit test for function get_tree_node
def test_get_tree_node():
    pass


# Generated at 2022-06-26 02:53:49.635107
# Unit test for function get_tree_node
def test_get_tree_node():
    # add more tests here
    var_0 = tree()
    var_0['foo']['bar'] = 'ok'
    assert get_tree_node(var_0, 'foo')
    assert get_tree_node(var_0, 'foo:bar') == 'ok'
    assert get_tree_node(var_0, 'foo:bar', parent=True)
    assert get_tree_node(var_0, 'bar')
    assert not get_tree_node(var_0, 'bar:baz')
    assert get_tree_node(var_0, 'bar:baz', default=None) is None



# Generated at 2022-06-26 02:54:01.532428
# Unit test for function set_tree_node
def test_set_tree_node():
    print("Running test for function set_tree_node")

    # Test case 0
    dict_0 = {}
    dict_1 = set_tree_node(dict_0, "key_0", "test")
    assert dict_1 == {"test"}
    assert dict_0 == {"test"}

    # Test case 1
    dict_0 = {}
    dict_1 = set_tree_node(dict_0, "key_0:key_1", "test")
    assert dict_1 == {"test"}
    assert dict_0 == {"test"}

    # Test case 2
    dict_0 = {}
    dict_1 = set_tree_node(dict_0, "key_0:key_1:key_2", "test")
    assert dict_1 == {"test"}
    assert dict_0 == {"test"}

    #

# Generated at 2022-06-26 02:54:10.180979
# Unit test for function set_tree_node
def test_set_tree_node():
    expected = {\
        'a' : 1,
        'b' : {\
            'a' : 2,
            'b' : {\
                'a' : 3\
            }\
        }\
    }
    d = tree()
    set_tree_node(d, 'a', 1)
    set_tree_node(d, 'b:a', 2)
    set_tree_node(d, 'b:b:a', 3)
    assert d == expected


# Generated at 2022-06-26 02:54:15.390329
# Unit test for function get_tree_node
def test_get_tree_node():
    test_obj = tree()
    test_obj[['a', 'b']] = 5
    assert get_tree_node(test_obj, ['a', 'b']) == 5



# Generated at 2022-06-26 02:54:20.932908
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    set_tree_node(var_0, 'var_1:var_2:var_3:var_4:var_5', {'var_6': {'var_7': 'var_8'}})
    var_9 = get_tree_node(var_0, 'var_1:var_2:var_3:var_4:var_5')


# Generated at 2022-06-26 02:54:40.781464
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = 'var_0:var_1'
    var_2 = var_0
    var_3 = 'var_2:var_3:var_4'
    var_4 = 'foo'
    var_5 = 'bar'

    var_0['var_0:var_1']['var_0:var_1:var_2'] = 'var_2:var_3:var_4:var_5'
    var_0[var_1][var_1 + ':var_2'] = 'var_2:var_3:var_4:var_5'
    var_0['var_0']['var_1']['var_2'] = 0

# Generated at 2022-06-26 02:54:43.908816
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(tree(), 'bar', 123) == {'bar': 123}



# Generated at 2022-06-26 02:54:48.927035
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = set_tree_node(var_0, 'a:b:c', 1)
    assert var_0['a']['b']['c'] == var_1['c']



# Generated at 2022-06-26 02:54:56.218248
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'key_1': 'value_1', 'key_2': {'key_3': 'value_2'}}
    assert get_tree_node(mapping, 'key_1') == 'value_1'
    assert get_tree_node(mapping, 'key_2:key_3') == 'value_2'



# Generated at 2022-06-26 02:55:03.487257
# Unit test for function get_tree_node
def test_get_tree_node():
    # Populate a test case
    var_0 = tree()
    var_1 = tree()
    var_2 = tree()
    var_3 = tree()
    var_4 = tree()
    var_1['var_3'] = var_3
    var_0['var_1'] = var_1
    var_0['var_2'] = var_2
    var_4['var_1'] = var_1
    var_4['var_2'] = var_2

    # Assert that function returns correct results
    assert get_tree_node(var_0, 'var_1', default=_sentinel) == var_1
    assert get_tree_node(var_0, 'var_2', default=_sentinel) == var_2

# Generated at 2022-06-26 02:55:06.746650
# Unit test for function get_tree_node
def test_get_tree_node():
    expected = 2
    actual = get_tree_node(tree(0), '')
    assert expected == actual


# Generated at 2022-06-26 02:55:14.815397
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = {}
    set_tree_node(var_0, 'a', 1)
    assert var_0 == {'a': 1}
    set_tree_node(var_0, 'a:b', 23)
    assert var_0 == {'a': {'b': 23}}
    set_tree_node(var_0, 'a:c:d:e:f', 23)
    assert var_0 == {'a': {'b': 23, 'c': {'d': {'e': {'f': 23}}}}}
    set_tree_node(var_0, 'a:c:d:e:f:g:h', 23)

# Generated at 2022-06-26 02:55:24.954442
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c:d', 1)
    set_tree_node(tree, 'a:b:c:e', 1)
    assert tree == {
        'a': {
            'b': {
                'c': {
                    'd': 1,
                    'e': 1,
                },
            },
        },
    }
    assert get_tree_node(tree, 'a:b:c:e') == 1
    assert get_tree_node(tree, 'a:b:c:d') == 1
    assert get_tree_node(tree, 'a:b:c') == {'d': 1, 'e': 1}
    assert get_tree_node(tree, 'a:b:c:f') == _sentinel
    # TODO

# Generated at 2022-06-26 02:55:27.504863
# Unit test for function set_tree_node
def test_set_tree_node():
    node = tree()
    set_tree_node(tree=node, key='a:b:c', value=42)
    assert node['a']['b']['c'] == 42


# Generated at 2022-06-26 02:55:39.919452
# Unit test for function get_tree_node
def test_get_tree_node():
    nodes = tree()
    test_nodes = {
        'a': {'b': 'c'},
        'a:b': 'c',
        'a:b:c': {'d': {'e': 'f'}},
        'a:b:c:d:e': 'f'
    }
    # Test if we're actually working with a tree
    for key, value in test_nodes.items():
        assert key.count(':') == key.count('.'.split(key))
        assert get_tree_node(nodes, key, default=_sentinel) is _sentinel
        nodes[key] = value
    # Test if we got a tree as expected

# Generated at 2022-06-26 02:56:12.938569
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['x']['y']['z'] = [1, 2, 3]
    assert(get_tree_node(var_0, 'x:y:z') == [1, 2, 3])
    var_0['x']['v']['w'] = [3, 1, 2]
    assert(get_tree_node(var_0, 'x:v') == {'w': [3, 1, 2]})
    assert(get_tree_node(var_0, 'x:v:w') == [3, 1, 2])
    var_0['x']['q']['p']['b'] = {'c': 3, 'd': 'Hello'}

# Generated at 2022-06-26 02:56:23.424535
# Unit test for function get_tree_node
def test_get_tree_node():
    # Assign value to var_0
    var_0 = tree()

    var_0['a']['b']['c']['d'] = "d value"

    var_1 = get_tree_node(var_0, 'a:b:c:d', default='default')
    var_2 = get_tree_node(var_0, 'a:b:c:e', default='default')

    try:
        var_3 = get_tree_node(var_0, 'a:b:c:f')
    except KeyError as var_4:
        var_5 = var_4.args

    try:
        var_6 = get_tree_node(var_0, 'a:b:c:d', default='default')
    except KeyError:
        var_6 = 'default'



# Generated at 2022-06-26 02:56:31.987993
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test with basic usage
    assert get_tree_node({'foo': {'bar': 1}}, 'foo:bar') == 1
    set_tree_node({'foo': {}}, 'foo:bar', 1)
    assert get_tree_node({'foo': {'bar': 1}}, 'foo:bar') == 1
    # Test with default value
    assert get_tree_node({'foo': {}}, 'foo:bar', default='baz') == 'baz'
    # Test with parent
    assert get_tree_node({'foo': {}}, 'foo:bar', parent=True) == {'foo': {}}



# Generated at 2022-06-26 02:56:36.855577
# Unit test for function set_tree_node
def test_set_tree_node():
    print(test_case_0())
    assert test_case_0() == True
    print('All unit tests passed')


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-26 02:56:45.293725
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['b']['c'] = 0xA
    assert get_tree_node(var_0, 'a:b:c', default=0xB) == 0xA
    assert get_tree_node(var_0, 'a:b:c') == 0xA
    assert get_tree_node(var_0, 'a:b:c:d', default=0xB) == 0xB
    assert get_tree_node(var_0, 'a:b:c:d') == 0xB
    assert get_tree_node(var_0, 'a:b:e', default=0xB) == 0xB
    assert get_tree_node(var_0, 'a:b:e') == 0xB


# Generated at 2022-06-26 02:56:53.920856
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, 'a', 'b')
    assert a['a'] == 'b'

    a['d'] = 'e'
    assert a['d'] == 'e'
    set_tree_node(a, 'd', 'f')
    assert a['d'] == 'f'

    set_tree_node(a, 'd:a', 'b')
    assert a['d']['a'] == 'b'

    a = tree()
    a['d:a'] = 1
    assert a['d']['a'] == 1
    a['d:a:b'] = 2
    assert a['d']['a']['b'] == 2


# Generated at 2022-06-26 02:57:02.687374
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    test_var_0 = tree()
    set_tree_node(var_0, 'django:db:backends:mysql', ':module:django.db.backends.mysql')
    set_tree_node(test_var_0, 'django:db:backends:mysql', ':module:django.db.backends.mysql')
    assert var_0 == test_var_0


# Generated at 2022-06-26 02:57:12.388927
# Unit test for function set_tree_node
def test_set_tree_node():

    # Extract data from:
    #     def set_tree_node(mapping, key, value):
    #         basename, dirname = key.rsplit(':', 2)
    #        parent_node = get_tree_node(mapping, dirname)
    #        parent_node[basename] = value
    #        return parent_node
    data = dict(
    )  # dict
    expected = dict(
    )  # dict
    result = set_tree_node(data)
    assert expected == result, "Testing with: " + repr(data)



# Generated at 2022-06-26 02:57:20.393702
# Unit test for function set_tree_node
def test_set_tree_node():
    # FIXME: Docstring says this is collections.Mapping, but is actually tree()

    # (across all branches)
    mapping = tree()
    key = 'foo'
    value = 'bar'
    result = set_tree_node(mapping, key, value)
    expected = 'bar'

    assert result == expected


# Generated at 2022-06-26 02:57:24.622492
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    my_tree, var_2 = set_tree_node(var_0, "hello:world", "foo"), var_0
    my_tree[:][:][:][:]
    try:
        my_tree[:][:][:][:]
    except Exception as e:
        print(e)


# Generated at 2022-06-26 02:58:26.470902
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test that `get_tree_node`:
    * Returns values
    * Returns parent nodes
    * Raises KeyError if not found
    """
    # Base case
    var_0 = tree()
    var_0['a']['b']['c'] = 'd'
    assert get_tree_node(var_0, 'a:b:c') == 'd'
    assert get_tree_node(var_0, 'a:b', parent=True)['c'] == 'd'

# Generated at 2022-06-26 02:58:29.187870
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'foo') == {}


# Generated at 2022-06-26 02:58:32.991109
# Unit test for function get_tree_node
def test_get_tree_node():
    # get_tree_node(mapping, key, default=_sentinel, parent=False):
    assert 1 == 1
    return True



# Generated at 2022-06-26 02:58:34.423989
# Unit test for function set_tree_node
def test_set_tree_node():
    assert True


# Generated at 2022-06-26 02:58:38.179995
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['b']['c']['d'] = 42
    key = 'b:c:d'
    default = _sentinel
    parent = False
    expected = 42
    actual = get_tree_node(mapping, key, default, parent)
    assert expected == actual



# Generated at 2022-06-26 02:58:43.447274
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = tree()
    test_tree['x']['y']['z'] = 0
    assert get_tree_node(test_tree, 'x:y:z') == 0



# Generated at 2022-06-26 02:58:44.312226
# Unit test for function get_tree_node
def test_get_tree_node():
    pass

# Generated at 2022-06-26 02:58:50.946612
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:59:00.894187
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    This unit test depends on the following functions (implemented outside of this testing file):
    1. import collections
    2. def get_tree_node(mapping, key, default=_sentinel, parent=False):
    3. def set_tree_node(mapping, key, value):
    4. def tree():
    """
    # Initialize the tree
    mytree = tree()
    mytree['mead']['meadows'] = 'are delightful'
    mytree['mead']['meadows']['dandelions'] = 'are inedible'

    # Test a mapping and a key that exists
    assert get_tree_node(mytree, 'mead:meadows') == 'are delightful', 'A node exists in the mapping'

    # Test a mapping and a key that does not exist

# Generated at 2022-06-26 02:59:09.105266
# Unit test for function get_tree_node
def test_get_tree_node():

    assert True == get_tree_node(var_0, 'a:b:c', default=_sentinel)
    assert True == get_tree_node(var_0, 'a:b:c')
    assert True == get_tree_node(var_0, 'a:b:d', parent=True)
    assert True == get_tree_node(var_0, 'a:b:d', parent=True)
    assert True == get_tree_node(var_0, 'a:e', parent=True)
    assert True == get_tree_node(var_0, 'a:z:y', default=_sentinel)
    assert True == get_tree_node(var_0, 'a:z:y', default=_sentinel)
