

# Generated at 2022-06-26 02:49:26.027017
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = {}
    # Simple assign
    var_1 = set_tree_node(var_0, 'test', 'hello')
    assert var_1['test'] == 'hello'
    # Three-dimensional assign
    var_2 = set_tree_node(var_0, 'test:0:1', 'hello')
    assert var_2[0][1] == 'hello'


if __name__ == "__main__":
    test_set_tree_node()
    print("Everything's good to go.")

# Generated at 2022-06-26 02:49:29.236821
# Unit test for function set_tree_node
def test_set_tree_node():

    result = set_tree_node(tree(), 'foo:bar:baz', 'quux')

    expected = {'foo': {'bar': {'baz': 'quux'}}}
    assert result == expected



# Generated at 2022-06-26 02:49:34.147061
# Unit test for function set_tree_node
def test_set_tree_node():
    # assert <insert> == <insert>
    # assert <insert> == <insert>
    # assert <insert> == <insert>
    # assert <insert> == <insert>
    # assert <insert> == <insert>
    # assert <insert> == <insert>
    pass



if __name__ == '__main__':
    test_case_0()
    test_set_tree_node()

# Generated at 2022-06-26 02:49:40.461110
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:49:46.184586
# Unit test for function get_tree_node
def test_get_tree_node():
    assert type(get_tree_node('mapping', 'key', 'default', 'parent')) == object
    assert get_tree_node('mapping', 'key', 'default', 'parent') == _sentinel
    assert type(get_tree_node('mapping', 'key', 'default', 'parent')) == object
    assert get_tree_node('mapping', 'key', 'default', 'parent') == _sentinel



# Generated at 2022-06-26 02:49:57.175755
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:50:01.876803
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    key = "a"
    value = "1"
    try:
        assert set_tree_node(mapping, key, value) == { "a": "1"}
    except AssertionError:
        raise AssertionError('test_set_tree_node Failed')


# Generated at 2022-06-26 02:50:11.279151
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': 'd'}}}
    node = get_tree_node(mapping, 'a:b:c')
    assert node == 'd'
    node = get_tree_node(mapping, 'a')
    assert node == {'b': {'c': 'd'}}
    node = get_tree_node(mapping, 'a', parent=True)
    assert node == mapping
    assert_raises(KeyError, get_tree_node, mapping, 'a:b', 'default')
    assert get_tree_node(mapping, 'a:b', 'default', parent=True) == {'c': 'd'}



# Generated at 2022-06-26 02:50:16.331082
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_0['a:b:c:d'] = '1'
    var_0['a:b:c']['e'] = '1'

# Generated at 2022-06-26 02:50:26.795457
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    try:
        get_tree_node(var_0, 'asdf', default=_sentinel)
    except:
        pass
    else:
        assert False, 'Expected an exception'
    try:
        get_tree_node(var_0, 'asdf', parent=True)
    except:
        pass
    else:
        assert False, 'Expected an exception'
    try:
        get_tree_node(var_0, 'asdf', default=_sentinel, parent=True)
    except:
        pass
    else:
        assert False, 'Expected an exception'
    # TODO: Raise better exception
    # Currently: NotImplementedError:
    # https://github.com/omnilib/omnilib/blob/master/omnilib/

# Generated at 2022-06-26 02:50:37.877767
# Unit test for function get_tree_node
def test_get_tree_node():
    root = tree()
    root['a'] = tree()
    root['a']['b'] = 'test'
    root['a']['c'] = 'test2'
    root['b'] = 'test3'
    assert get_tree_node(root, 'a:b') == 'test'
    assert get_tree_node(root, 'a:c') == 'test2'
    assert get_tree_node(root, 'b') == 'test3'
    assert get_tree_node(root, 'c', default='test4') == 'test4'



# Generated at 2022-06-26 02:50:47.101968
# Unit test for function get_tree_node
def test_get_tree_node():
    base = {
        'foo': {'bar': 'baz'}
    }
    assert get_tree_node(base, 'foo:bar') == 'baz'
    assert get_tree_node(base, 'foo:baz') is _sentinel
    assert get_tree_node(base, 'foo:baz', default='qux') == 'qux'
    # TODO: Need a better way of testing parent node returns
    # assert get_tree_node(base, 'foo:baz', parent=True) == {'bar': 'baz'}



# Generated at 2022-06-26 02:50:50.733495
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    key, value = 'a', 'b'
    set_tree_node(var_0, key, value)
    assert var_0 == {'a': 'b'}



# Generated at 2022-06-26 02:50:59.300230
# Unit test for function get_tree_node
def test_get_tree_node():
    print('Testing get_tree_node()')
    data = {
        'foo': {
            'bar': 'baz',
            'baz': {
                'bam': 'bap',
                'ban': {
                    'bo': 'ba'
                }
            },
            'bap': 'bam'
        },
        'baz': 'boz'
    }
    print(data)
    print(get_tree_node(data, 'foo:bar'))
    print(get_tree_node(data, 'foo:ban'))
    print(get_tree_node(data, 'foo:ban:0'))
    print(get_tree_node(data, 'foo:ban:bo'))
    print(get_tree_node(data, 'foo:ban:bo', default=None))

# Generated at 2022-06-26 02:51:09.323966
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {
        "a": 0,
        "b": {
            "c": 1,
            "d": 2,
            "e": {
                "f": 3,
                "g": {
                    "h": 4
                }
            }
        }
    }
    assert get_tree_node(m, 'b:c') == 1
    assert get_tree_node(m, 'b:e:g:h') == 4
    assert get_tree_node(m, 'b:e:g:h', parent=True) == m['b']['e']['g']

    m['b']['e']['g']['nope'] = 'oh no'

# Generated at 2022-06-26 02:51:15.597700
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, '', 0) == 0
    assert get_tree_node({}, '', 0, parent=True) is None
    assert get_tree_node({}, '', _sentinel) is _sentinel
    assert get_tree_node(tree(), 'a:b:c:d', _sentinel) is _sentinel
    assert get_tree_node(tree(), 'a:b:c:d', _sentinel, parent=True) is _sentinel

    var_0 = tree()
    var_0['a']['b']['c']['d'] = 1

    assert get_tree_node(var_0, 'a:b:c:d') == 1
    assert get_tree_node(var_0, 'a:b:c:d', _sentinel) == 1
   

# Generated at 2022-06-26 02:51:22.982728
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = set_tree_node(var_0, 'foo', 'foo')
    var_2 = set_tree_node(var_0, 'foo:bar', 'bar')
    var_3 = set_tree_node(var_0, 'foo:bar:baz', 'baz')
    var_4 = set_tree_node(var_0, 'not:foo', 'nfoo')
    var_5 = set_tree_node(var_0, 'foo:bar:baz:buz', 'buz')


# Generated at 2022-06-26 02:51:26.790709
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = 'this is a test'
    actual = get_tree_node(test_data, 'test')
    expected = 'this is a test'
    print('Expected: %s' % expected)
    print('Actual: %s' % actual)
    assert actual == expected


# Generated at 2022-06-26 02:51:29.978463
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {}

# Generated at 2022-06-26 02:51:35.078211
# Unit test for function set_tree_node
def test_set_tree_node():
    treenode0 = None
    treenode1 = None
    mapping0 = None
    treenode2 = None
    key0 = None
    value0 = None
    treenode3 = None

    # Call set_tree_node
    set_tree_node(mapping0, key0, value0)



# Generated at 2022-06-26 02:51:48.755958
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {'b': {'c': 3, 'd': 4}, 'e': 5}

    if not a['b']['c'] == 3:
        raise Exception('Failed test')

    if not get_tree_node(a, 'b:c') == 3:
        raise Exception('Failed test')

    if not get_tree_node(a, 'b:c') == 3:
        raise Exception('Failed test')

    try:
        get_tree_node(a, 'f')
        raise Exception('Failed test')
    except KeyError:
        pass

    if not get_tree_node(a, 'f', default='g') == 'g':
        raise Exception('Failed test')


# Generated at 2022-06-26 02:51:54.235610
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = {
        'foo': {
            'bar': 'baz'
        }
    }
    assert get_tree_node(var_1, 'foo:bar') == 'baz'
    assert get_tree_node(var_1, 'yo:dawg:i:heard:you:like:cheese') == {}
    assert get_tree_node(var_1, 'yo:dawg:i:heard:you:like:cheese') == {}


# Generated at 2022-06-26 02:52:01.550120
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = get_tree_node(var_0, 'foo')
    var_2 = set_tree_node(var_0, 'foo', True)
    var_3 = set_tree_node(var_0, 'foo:bar:baz', True)
    var_4 = get_tree_node(var_0, 'foo:bar:baz')
    return var_0, var_1, var_2, var_3, var_4, var_0


# Generated at 2022-06-26 02:52:05.877424
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0["foo"]["bar"]["baz"] = "hello world"
    assert get_tree_node(var_0, "foo:bar:baz") == "hello world"



# Generated at 2022-06-26 02:52:10.359676
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = { 'base_key': { 'parent_node': { 'node_value': 'value' } } }
    assert get_tree_node(mapping, 'base_key:parent_node:node_value') == 'value'

    # Try passing no default and expect a KeyError
    with py.test.raises(KeyError):
        get_tree_node(mapping, 'not_there')



# Generated at 2022-06-26 02:52:13.176463
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(
        {"a": {"b": {"c": "d"}}},
        "a:b:c"
    ) == "d"



# Generated at 2022-06-26 02:52:15.389714
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_0 = set_tree_node(var_0, 'a:b:c:d', 1)


# Generated at 2022-06-26 02:52:19.064226
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:52:19.901698
# Unit test for function set_tree_node
def test_set_tree_node():
    pass



# Generated at 2022-06-26 02:52:24.702870
# Unit test for function set_tree_node
def test_set_tree_node():
    print("Starting test: set_tree_node")
    var_0 = tree()
    set_tree_node(var_0, 'A:B:C:D', 123)
    assert var_0['A']['B']['C']['D'] == 123
    print("Ending test: set_tree_node")



# Generated at 2022-06-26 02:52:39.267373
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()

# Generated at 2022-06-26 02:52:46.052179
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = {}
    var_1 = collections.defaultdict(tree, {})
    var_1['var_2']['var_3'] = 'var_4'
    var_5 = get_tree_node(var_1, 'var_2:var_3')
    assert var_5 == 'var_4'


# Generated at 2022-06-26 02:52:49.023638
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node("mapping", "key", default="_sentinel", parent="False") == None


# Generated at 2022-06-26 02:53:00.241566
# Unit test for function get_tree_node
def test_get_tree_node():
    # AssertionError: Expected 'foo' to equal 'bar'
    # assert get_tree_node(None, None) == "bar"
    assert get_tree_node(None, None) == None
    # AssertionError: Expected 'foo' to equal 'bar'
    # assert get_tree_node(None, None) == "bar"
    assert get_tree_node(None, None) == None
    # AssertionError: Expected True to equal False
    # assert get_tree_node(None, None) == False
    assert get_tree_node(None, None) == None
    # AssertionError: 'foo' != 'bar'
    # assert get_tree_node(None, None) != "bar"
    assert get_tree_node(None, None) != None
    assert get_

# Generated at 2022-06-26 02:53:02.953271
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {}
    var_0['a'] = {'b': {'c': 'Hello world'}}


# Generated at 2022-06-26 02:53:08.270791
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test case 0
    mock_mapping = {'a':{'b':{'c': True}}}
    mock_key = 'a:b:c'
    mock_default = _sentinel
    # Assert that function returns 'expected'
    expected = True
    assert get_tree_node(mock_mapping, mock_key, mock_default) == expected


# Generated at 2022-06-26 02:53:19.884460
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0["key_0"] = "value_0"
    tree_0["key_1"] = "value_1"
    tree_0["key_2"] = "value_2"
    tree_0[":key_0"] = "value_0"
    tree_0[":key_1"] = "value_1"
    tree_0[":key_2"] = "value_2"
    tree_0["foo:bar:baz:key_0"] = "value_0"
    tree_0["foo:bar:baz:key_1"] = "value_1"
    tree_0["foo:bar:baz:key_2"] = "value_2"
    tree_0["foo:bar:key_0"] = "value_0"
    tree_

# Generated at 2022-06-26 02:53:27.505858
# Unit test for function get_tree_node
def test_get_tree_node():
    db = tree()
    db['foo']['bar'] = 5
    assert db['foo']['bar'] == 5
    db['foo:bar:baz'] = 4
    assert db['foo:bar:baz'] == 4
    assert db['foo']['bar']['baz'] == 4

    assert get_tree_node(db, 'foo:baz') is None


# Generated at 2022-06-26 02:53:30.024036
# Unit test for function set_tree_node
def test_set_tree_node():
    global var_0
    set_tree_node(var_0,':a:b:c:d:e:f:g:h:i:j:k:l:needle', True)



# Generated at 2022-06-26 02:53:31.765291
# Unit test for function set_tree_node
def test_set_tree_node():
    # Arrange
    mapping = {'foo': {'bar': 'asdf'}}
    key = 'foo:bar'
    value = 'value'

    # Act
    result = set_tree_node(mapping, key, value)

    # Assert
    assert result == value
    assert mapping['foo']['bar'] == value


# Generated at 2022-06-26 02:53:54.610347
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(tree(), 'one:two:three', 'value') == {'one': {'two': {'three': 'value'}}}


# Generated at 2022-06-26 02:54:03.132174
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, ':') == _sentinel
    assert get_tree_node({'a': 1}, 'a') == 1
    assert get_tree_node({'b': 2}, 'a') == _sentinel

    input_dict = {
        'a': 1,
        'b:c': 2,
        'd:e': {
            'f': 3,
            'g': 4
        }
    }
    # Test mapping
    assert get_tree_node(input_dict, 'a') == 1
    assert get_tree_node(input_dict, 'b:c') == 2
    assert get_tree_node(input_dict, 'd:e') == {'f': 3, 'g': 4}
    assert get_tree_node(input_dict, 'd:e:f')

# Generated at 2022-06-26 02:54:13.177998
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['a']['b'] = 'c'
    assert(mapping['a']['b'] == 'c')

    # Test default value returns default
    assert(get_tree_node(mapping, 'a:b:c', default='foo') == 'foo')

    # Test set then get
    set_tree_node(mapping, 'a:b:c:d:e', 'bar')
    assert(get_tree_node(mapping, 'a:b:c:d:e') == 'bar')

    # Test get parent
    assert(get_tree_node(mapping, 'a:b:c:d:e', parent=True) == {'e': 'bar'})

    # Test exception

# Generated at 2022-06-26 02:54:22.982827
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test 1
    mapping_1 = {'a': {'b': {'c': 1}}}
    key_1 = 'a:b'
    value_1 = 0
    result = set_tree_node(mapping_1, key_1, value_1)
    assert result == {'b': 0}

    # Test 2
    mapping_2 = {'a': {'b': {'c': 1}}}
    key_2 = 'a'
    value_2 = 0
    result = set_tree_node(mapping_2, key_2, value_2)
    assert result == {'b': {'c': 1}}

    # Test 3
    mapping_3 = {'a': {'b': {'c': 1}}}
    key_3 = 'a:b'
    value_3 = 0


# Generated at 2022-06-26 02:54:27.477191
# Unit test for function get_tree_node
def test_get_tree_node():
    # following 2 should print the same
    print(get_tree_node({}, 'test'))
    print(get_tree_node({}, 'test', default=_sentinel))


# Generated at 2022-06-26 02:54:34.262397
# Unit test for function set_tree_node
def test_set_tree_node():
    test_value = 'foo'
    test_mapping = tree()
    test_key = 'bar'

    set_tree_node(test_mapping, test_key, test_value)
    assert test_mapping['bar'] == test_value
    assert test_mapping['bar'] is not test_value



# Generated at 2022-06-26 02:54:39.928132
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, 'a:b:c:d:e:f:g:h:i:j:k', 'value')
    assert a['a']['b']['c']['d']['e']['f']['g']['h']['i']['j']['k'] == 'value'


# Generated at 2022-06-26 02:54:43.539092
# Unit test for function get_tree_node
def test_get_tree_node():
    input_0 = {}
    input_1 = ""
    output = get_tree_node(input_0, input_1)


# Generated at 2022-06-26 02:54:45.314226
# Unit test for function set_tree_node
def test_set_tree_node():
    assert False


# Generated at 2022-06-26 02:54:48.579431
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO Add tests for this function
    raise NotImplementedError("Test not implemented for get_tree_node")


# Generated at 2022-06-26 02:55:28.775011
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = dict()
    set_tree_node(tree, "key", 0)
    if tree['key'] != 0:
        return False


# Generated at 2022-06-26 02:55:40.596022
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {'1': {'2': {'3': {'4': 'a'}}}, '5': {'6': {'7': {'8': 'b'}}}}
    assert get_tree_node(test_mapping, '1:2:3:4') == 'a'
    assert get_tree_node(test_mapping, '5:6:7:8') == 'b'
    assert get_tree_node(test_mapping, '5:6:7:2', default='no value') == 'no value'
    try:
        get_tree_node(test_mapping, '5:6:7:9')
    except KeyError:
        pass
    else:
        raise AssertionError('expected KeyError')


# Generated at 2022-06-26 02:55:51.839044
# Unit test for function get_tree_node
def test_get_tree_node():
    assert(None == get_tree_node({}, "abc"))
    assert(None == get_tree_node({}, "abc:def"))
    assert(None == get_tree_node({"abc": {}}, "abc:def"))
    assert(None == get_tree_node({"abc": {"def": {}}}, "abc:ghi:jkl"))
    assert(None == get_tree_node({"abc": {"def": {}}}, "abc:def:ghi"))
    assert(get_tree_node({"abc": {"def": {}}}, "abc:def") == {})
    assert(get_tree_node({"abc": {"def": {}}}, "abc") == {'def': {}})

# Generated at 2022-06-26 02:55:53.242014
# Unit test for function get_tree_node
def test_get_tree_node():
    assert(1 == 0)



# Generated at 2022-06-26 02:55:58.686466
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'foo:ba:r', ) == ()

    assert get_tree_node({'foo':{'ba':{'r':'baz'}}}, 'foo:ba:r', ) == 'baz'



# Generated at 2022-06-26 02:56:04.125154
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    test_set_tree_node_0(var_0)

    test_set_tree_node_1()

    test_set_tree_node_2()

    test_set_tree_node_3()

    test_set_tree_node_4()

    test_set_tree_node_5()

    test_set_tree_node_6()

    test_set_tree_node_7()

    test_set_tree_node_8()

    test_set_tree_node_9()

    test_set_tree_node_10()

    test_set_tree_node_11()



# Generated at 2022-06-26 02:56:13.531087
# Unit test for function get_tree_node
def test_get_tree_node():


    var_0 = tree()
    var_0.update({'cms': {'admin': {'sites': {'1': {'domain': 'example.com', 'name': 'example.com'}, '__ROOT__': ['1']}}}})

    var_1 = 'cms:admin'
    var_2 = get_tree_node(var_0, var_1)

    assert var_2 == {
        'sites': {
            '1': {'domain': 'example.com', 'name': 'example.com'},
            '__ROOT__': ['1']
        }
    }


    var_1 = 'cms:admin:sites:__ROOT__'
    var_2 = get_tree_node(var_0, var_1)


    assert var_2 == ['1']





# Generated at 2022-06-26 02:56:18.623481
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    set_tree_node(var_1, u'a:b:c', 42)
    assert get_tree_node(var_1, u'a:b:c') == 42


# Generated at 2022-06-26 02:56:30.827774
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': 'c',
        },
        'd': {
            'e': {
                'f': 'g'
            }
        },
        'h': 'j'
    }
    assert get_tree_node(tree, 'h') == 'j'
    assert get_tree_node(tree, 'a:b') == 'c'
    assert get_tree_node(tree, 'd:e:f') == 'g'
    with pytest.raises(KeyError):
        get_tree_node(tree, 'd:f', _sentinel)
    assert get_tree_node(tree, 'd:f', default='i') == 'i'

# Generated at 2022-06-26 02:56:39.791931
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    var_0 = tree()
    var_0['foo']['bar'] = 'baz'

# Generated at 2022-06-26 02:58:19.801497
# Unit test for function set_tree_node
def test_set_tree_node():
    print("Starting unit test for function: set_tree_node")
    var_0 = tree()
    var_0.update(tree())
    var_0.update(tree())
    var_0['a'].update(tree())
    var_0['a'].update(tree())
    var_0['a']['b'].update(tree())
    var_0['a']['b'].update(tree())
    var_0['a']['b']['c'].update(tree())
    var_0['a']['b']['c'].update(tree())
    var_0['a']['b']['c']['d'].update(tree())
    var_0['a']['b']['c']['d'].update(tree())
    var_

# Generated at 2022-06-26 02:58:29.194343
# Unit test for function set_tree_node
def test_set_tree_node():
    test_0 = 'key1:key2:key3'
    test_1 = 'key1:key2'
    test_2 = 'key1:key2:key3:key4'
    test_3 = 'key1:key2:key3:key5'
    test_4 = 'key1:key2:key6'
    test_5 = 'key1:key7'
    test_6 = 'key1:key8'
    test_7 = 'key1:key2:key9'
    test_8 = 'key1:key10'
    test_9 = 'key1:key2:key3:key11'
    test_10 = 'key1:key2:key12'
    test_11 = 'key1:key2:key3:key13'

# Generated at 2022-06-26 02:58:37.946987
# Unit test for function get_tree_node
def test_get_tree_node():
    a = tree()
    a['x'] = 'x'
    a['y']['y1'] = 'y1'
    a['y']['y2'] = 'y2'
    assert(get_tree_node(a, 'y:y1') == 'y1')
    assert(get_tree_node(a, 'y:y2') == 'y2')
    assert(get_tree_node(a, 'x') == 'x')
    assert(get_tree_node(a, 'z') is _sentinel)



# Generated at 2022-06-26 02:58:45.688225
# Unit test for function get_tree_node
def test_get_tree_node():
    assert(get_tree_node({"a": 1}, "a") == 1)
    assert(get_tree_node({"a": {"b": 1}}, "a:b") == 1)
    assert(get_tree_node({"a": {"b": {"c": 1}}}, "a:b:c") == 1)



# Generated at 2022-06-26 02:58:52.179080
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_0 = set_tree_node(var_0, "0x00:0x00:0x00", 0x0)
    var_0 = set_tree_node(var_0, "0x00:0x00:0x01", 0x1)
    var_0 = set_tree_node(var_0, "0x00:0x01:0x00", 0x2)
    var_0 = set_tree_node(var_0, "0x01:0x00:0x00", 0x3)
    var_0 = set_tree_node(var_0, "0x00:0x01:0x01", 0x4)

# Generated at 2022-06-26 02:58:55.220592
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 'bar' == get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar')


# Generated at 2022-06-26 02:58:59.915635
# Unit test for function set_tree_node
def test_set_tree_node():
    assert 0 == 0


# Generated at 2022-06-26 02:59:04.988753
# Unit test for function set_tree_node
def test_set_tree_node():
    # Get a nondefault argument
    var_2 = {'b': {'c': {'d': 'e'}}}
    var_3 = 'a:b:c:d'
    var_4 = 'f'
    var_1 = set_tree_node(var_2, var_3, var_4)
    assert var_1 == {'b': {'c': {'d': 'f'}}}


# Generated at 2022-06-26 02:59:12.403610
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': 0, 'd': 1}, 'e': 2}}
    assert get_tree_node(mapping, 'a:b:c') == 0
    assert get_tree_node(mapping, 'a:b:d') == 1
    assert get_tree_node(mapping, 'a:e') == 2
    assert get_tree_node(mapping, 'a:b:f') is _sentinel


# Generated at 2022-06-26 02:59:15.862209
# Unit test for function set_tree_node
def test_set_tree_node():
    key = 'key'
    value = 1
    t = tree()
    t[key] = value
    assert value == t[key]
