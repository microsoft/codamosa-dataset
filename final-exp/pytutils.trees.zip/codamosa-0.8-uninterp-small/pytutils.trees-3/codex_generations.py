

# Generated at 2022-06-26 02:49:24.943374
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = {}

# Generated at 2022-06-26 02:49:32.999847
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test case 0
    tree_0 = Tree()
    set_tree_node(tree_0, 'test:test:test2', 3)
    assert tree_0['test:test:test2'] == 3

    # Test case 1
    tree_1 = Tree()
    set_tree_node(tree_1, 'test:test:test2', 3)
    assert tree_1['test:test:test2'] == 3

    # Test case 2
    tree_2 = Tree()
    set_tree_node(tree_2, 'test:test:test2', 3)
    assert tree_2['test:test:test2'] == 3



# Generated at 2022-06-26 02:49:39.708790
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'foo', 1) == {'foo': 1}
    assert set_tree_node({}, 'foo:bar:baz', 1) == {'foo': {'bar': {'baz': 1}}}
    assert set_tree_node({'foo': {'bar': {'baz': 1}}}, 'foo:bar:baz', 2) == {'foo': {'bar': {'baz': 2}}}
    assert set_tree_node({'foo': {'bar': {'baz': 1}}}, 'foo:bar:baz:doo', 2) == {'foo': {'bar': {'baz': {'doo': 2}}}}

# Generated at 2022-06-26 02:49:48.689513
# Unit test for function get_tree_node
def test_get_tree_node():
    x = tree()
    assert get_tree_node(x, 'test:test:test') == x['test']['test']['test']
    x['test']['test']['test'] = 1
    assert get_tree_node(x, 'test:test:test') == x['test']['test']['test'] == 1
    assert get_tree_node(x, 'test:test:test', default='test') == 1
    try:
        get_tree_node(x, 'test:test:test:test')
        assert False
    except KeyError:
        assert True
    assert get_tree_node(x, 'test:test:test:test', default=1) == 1

# Generated at 2022-06-26 02:49:58.591524
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test for valid mappings
    tree_1 = Tree()
    tree_1['A:B:C'] = 'C'
    tree_1['A:B:D'] = 'D'
    tree_1['A:B:E'] = 'E'
    tree_1['A:F'] = 'F'

    assert get_tree_node(tree_1, 'A:B:C') == 'C'
    assert get_tree_node(tree_1, 'A:B') == tree_1['A']['B']
    assert get_tree_node(tree_1, 'A') == tree_1['A']

    # Test for invalid mappings
    with pytest.raises(KeyError):
        get_tree_node(tree_1, 'A:B:G')

# Generated at 2022-06-26 02:50:02.176081
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    result = set_tree_node(test_dict,'one:two:three','4')
    assert result == {'two': {'three': '4'}}


# Generated at 2022-06-26 02:50:12.387526
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'name': 'test',
        'value': {
            'label': 'test value',
            'default': 'test value'
        },
        'desc': 'Test value'
    }

    assert get_tree_node(test_dict, 'name') == 'test'
    assert get_tree_node(test_dict, 'value:label') == 'test value'
    assert get_tree_node(test_dict, 'value:default') == 'test value'
    assert get_tree_node(test_dict, 'desc') == 'Test value'

    assert get_tree_node(test_dict, 'value', parent=True) == {'label': 'test value', 'default': 'test value'}

if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-26 02:50:17.297848
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_node_0 = Tree()
    tree_node_0['tree_node_0'] = 'tree_node_0'
    tree_node_1 = tree_node_0['tree_node_0', 'tree_node_0']
    assert tree_node_1 == 'tree_node_0'



# Generated at 2022-06-26 02:50:27.759000
# Unit test for function get_tree_node
def test_get_tree_node():
    dict_0 = {'a': {'b': {'c': {'d': {'e': {}, 'f': {}}}}}, 'g': {'h': {'i': {'j': {}}}}}
    assert get_tree_node(dict_0, "a:b:c:d") == dict_0['a']['b']['c']['d']
    assert get_tree_node(dict_0, "a:b:c:d:e") == dict_0['a']['b']['c']['d']['e']
    assert get_tree_node(dict_0, "g:h:i:j") == dict_0['g']['h']['i']['j']

# Generated at 2022-06-26 02:50:33.097209
# Unit test for function set_tree_node
def test_set_tree_node():
    m = {}
    set_tree_node(m, "foo", "bar")
    assert m["foo"] == "bar", "Failed!"
    set_tree_node(m, "foo:bar", "baz")
    assert m["foo"]["bar"] == "baz", "Failed!"


# Generated at 2022-06-26 02:50:38.155392
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = Tree()
    test_tree.set_tree_node("a:b:c", "d")
    assert test_tree["a"]["b"]["c"] == "d"


# Generated at 2022-06-26 02:50:51.797906
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test input
    a = {'a': {'b': {'c':{'d':'e'}}}}
    assert set_tree_node(a, 'a:b:c:d', 'f') == {'d': 'f'}
    assert set_tree_node(a, 'a:b:c:d', 'foo:bar:key', parent=True) == {'d': {'foo': {'bar': {'key': 'key'}}}}
    assert set_tree_node(a, 'a:b:c:d', 'foo:bar:key') == {'foo': {'bar': {'key': 'key'}}}


# Generated at 2022-06-26 02:50:59.433806
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    assert tree_0.set_tree_node(key='foo', value='bar') == tree_0['foo'] == 'bar'
    assert tree_0.set_tree_node(key='foo:bar', value='baz') == tree_0['foo:bar'] == 'baz'
    assert tree_0.set_tree_node(key='foo:bar:baz', value='bat') == tree_0['foo:bar:baz'] == 'bat'
    assert tree_0.set_tree_node(key='foo:bar:baz:bat', value='bat2') == tree_0['foo:bar:baz:bat'] == 'bat2'


# Generated at 2022-06-26 02:51:10.094343
# Unit test for function get_tree_node
def test_get_tree_node():
    # tree dictionary
    tree_dict = {'foo': {'bar': 'baz'}}
    tree_dict['foo']['0'] = 'baz'

    # test1: node: foo
    result = get_tree_node(tree_dict, 'foo')
    assert (result=={'bar': 'baz', '0': 'baz'})

    # test2: node: foo:bar
    result = get_tree_node(tree_dict, 'foo:bar')
    assert (result=='baz')

    # test3: node: foo:0
    result = get_tree_node(tree_dict, 'foo:0')
    assert (result=='baz')

    # test4: node: foo:1
    result = get_tree_node(tree_dict, 'foo:1')


# Generated at 2022-06-26 02:51:19.471861
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Get tree node works as excpected.
    """
    tree_0 = Tree()
    tree_0['a:a:a:a'] = 3
    assert tree_0.get('a:a:a:a') == 3
    assert tree_0.get('a:a:a') == {'a': 3}
    assert tree_0.get('a:a') == {'a': {'a': 3}}
    assert tree_0.get('a') == {'a': {'a': {'a': 3}}}



# Generated at 2022-06-26 02:51:25.614607
# Unit test for function get_tree_node
def test_get_tree_node():

    # Test for get_tree_node
    mapping = {"a": {"b": {"c": "c"}}}
    assert get_tree_node(mapping, "a:b:c", default=None) == "c"
    assert get_tree_node(mapping, "a:b", default=None) == {"c": "c"}

    # Exceptions
    with pytest.raises(KeyError):
        get_tree_node(mapping, "a:b:c:d", default=None)


# Generated at 2022-06-26 02:51:35.600450
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for get_tree_node"""
    test = Tree({'a': {'b': {'c': 'd'}}})

    # Can fetch lower depth nodes
    assert get_tree_node(test, 'a') is test['a']
    assert get_tree_node(test, 'a:b') is test['a']['b']

    # Can fall back to default
    default = object()
    assert get_tree_node(test, 'not_a:key', default=default) is default

    # If a node is not present in parent, raise an exception
    with pytest.raises(KeyError):
        get_tree_node(test, 'a:not_a:key')
        get_tree_node(test, 'a:not_a:key', default=_sentinel)


# Unit test

# Generated at 2022-06-26 02:51:37.357028
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test get_tree_node with multiple dimension
    test_get_tree_node_0()


# Generated at 2022-06-26 02:51:47.467505
# Unit test for function get_tree_node
def test_get_tree_node():
    f = 0
    # Case 0
    tree_0 = Tree(initial={'a': {'b': 'c'}})

    assert(get_tree_node(tree_0, 'a:b') == 'c')
    print('Passed!')

    # Case 1
    try:
        get_tree_node(tree_0, 'c')
        f = 1
    except KeyError:
        pass
    assert(f == 0)
    print('Passed!')

    # Case 2
    assert(get_tree_node(tree_0, 'c', default='default') == 'default')
    print('Passed!')

    # Case 3
    tree_3 = tree()
    tree_3['k']['a']['b']['c'] = 3


# Generated at 2022-06-26 02:51:55.136242
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree_1 = Tree()
    assert test_tree_1["dimension:key"] == {}, "Failed when defaultdict gets a blank key"

    test_tree_2 = Tree()
    test_tree_2["dimension:key"] = 2
    assert test_tree_2["dimension:key"] == 2, "Failed when setting on blank dimension"

    test_tree_3 = Tree()
    test_tree_3["dimension:key1"] = 1
    test_tree_3["dimension:key2"] = 2
    assert test_tree_3["dimension:key1"] == 1, "Failed when setting on blank dimension"
    assert test_tree_3["dimension:key2"] == 2, "Failed when setting on blank dimension"



# Generated at 2022-06-26 02:52:01.978358
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['foo'] = 'bar'
    result = get_tree_node(tree_0, 'foo')
    assert result == 'bar'


# Generated at 2022-06-26 02:52:08.042316
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    test_tree[":foo"][":bar"][":baz"] = "bamf"

    foo = test_tree[":foo"]
    bar = test_tree[":foo:bar"]
    baz = test_tree[":foo:bar:baz"]

    assert test_tree[":foo:bar:baz"] == "bamf"



# Generated at 2022-06-26 02:52:14.686344
# Unit test for function get_tree_node
def test_get_tree_node():

    t_0 = tree()
    t_0['hello'] = 2
    t_0['hello']['world'] = 3
    t_0['hello']['world']['bob'] = 4
    t_0['bonjour']['monde'] = 'chien'

    node_0 = get_tree_node(t_0, 'hello:world:bob')

    assert node_0 == 4

    node_1 = get_tree_node(t_0, 'bonjour:monde')

    assert node_1 == 'chien'

    node_2 = get_tree_node(t_0, 'hello:world')

    assert isinstance(node_2, collections.defaultdict)


# Generated at 2022-06-26 02:52:18.021402
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    See if we can fetch a node at some depth
    """
    simple_dict = {'a': {0: {'b': 'c'}}}
    assert get_tree_node(simple_dict, 'a:0:b') == 'c'


# Generated at 2022-06-26 02:52:28.148282
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree_0 = {'one' : 1, 'two' : {'one' : 1.1, 'two' : 1.2, 'three' : {'one' : 1.21, 'two' : 1.22}}}

    # Test 1
    test_key_0 = 'one'
    test_default_0 = None
    test_parent_0 = False
    assert get_tree_node(test_tree_0, test_key_0, test_default_0, test_parent_0) == 1

    # Test 2
    test_key_0 = 'two:three:one'
    test_default_0 = None
    test_parent_0 = False
    assert get_tree_node(test_tree_0, test_key_0, test_default_0, test_parent_0) == 1.

# Generated at 2022-06-26 02:52:37.276232
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': {'c': {'e': 1}, 'd': 2}}
    assert get_tree_node(d, 'a:c:e') == 1

    d = {'a': {'c': {'e': 1}}}
    assert get_tree_node(d, 'a:c:d') is _sentinel

    d = {'a': {'c': {'e': 1}}}
    try:
        r = get_tree_node(d, 'a:c:d')
        assert False, 'get_tree_node should throw'
    except Exception as e:
        assert True

    d = {'a': {'c': {'e': 1}}}
    assert get_tree_node(d, 'a:c:d', 0) == 0



# Generated at 2022-06-26 02:52:41.449220
# Unit test for function get_tree_node
def test_get_tree_node():
    config = Tree({'a': {'b': {'c': 1}}})
    assert get_tree_node(config, 'a:b:c') == 1

# Generated at 2022-06-26 02:52:49.768296
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(dict(a=1), 'a') == 1
    assert get_tree_node(dict(a=dict(b=2)), 'a') == dict(b=2)
    assert get_tree_node(dict(a=dict(b=2)), 'a:b') == 2
    #assert get_tree_node(dict(a=dict(b=2)), ['a', 'b']) == 2
    assert get_tree_node(dict(a=dict(b=2)), 'a:b:c') is _sentinel
    assert get_tree_node(dict(a=dict(b=2)), 'a:b:c', default=3) == 3


# Generated at 2022-06-26 02:52:58.156315
# Unit test for function set_tree_node
def test_set_tree_node():
    # Tests that the set_tree_node function creates an index with the right key and value
    index_1 = {u"key_1": {u"key_2": u"value"}}
    set_tree_node(index_1, u"key_1:key_2", u"value")
    assert index_1[u"key_1"][u"key_2"] == u"value", "The set_tree_node function failed to create an attribute tree with the right index and value"


# Generated at 2022-06-26 02:53:03.268960
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['alpha:beta:gamma'] = 'delta'
    assert get_tree_node(tree_0, 'alpha:beta:gamma') == 'delta'



# Generated at 2022-06-26 02:53:15.952103
# Unit test for function set_tree_node
def test_set_tree_node():
    t = collections.defaultdict(dict)
    t['level_0_1']['level_1_2'] = 'level_2_0'
    set_tree_node(t, 'level_0_1:level_1_2', 'level_2_0')
    assert t['level_0_1']['level_1_2'] == 'level_2_0'



# Generated at 2022-06-26 02:53:22.127401
# Unit test for function get_tree_node
def test_get_tree_node():
	tree_0 = Tree()
	tree_0['a'] = 1
	tree_0['b'] = 2
	tree_0['c'] = 3
	tree_0['a:b'] = 4
	tree_0['a:c'] = 5
	tree_0['a:b:c'] = 6
	tree_0['a:b:c:d'] = 7

	assert get_tree_node(tree_0, 'a') == 1
	assert get_tree_node(tree_0, 'b') == 2
	assert get_tree_node(tree_0, 'c') == 3
	assert get_tree_node(tree_0, 'a:b') == 4
	assert get_tree_node(tree_0, 'a:c') == 5

# Generated at 2022-06-26 02:53:28.918924
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'test': 'fake'}, 'test', default=_sentinel) == 'fake'

    with nose.tools.assert_raises(KeyError):
        get_tree_node({'test': 'fake'}, 'fake', default=_sentinel)

    assert get_tree_node({'test': 'fake'}, 'fake', default=123) == 123


# Generated at 2022-06-26 02:53:37.527442
# Unit test for function get_tree_node
def test_get_tree_node():
    # test_case_0:
    test_input_0 = collections.defaultdict(tree)
    expected_output_0 = None
    actual_output_0 = get_tree_node(test_input_0, "")
    assert actual_output_0 == expected_output_0, (actual_output_0, expected_output_0)

    # test_case_1:
    test_input_1 = collections.defaultdict(tree)
    expected_output_1 = None
    actual_output_1 = get_tree_node(test_input_1, "")
    assert actual_output_1 == expected_output_1, (actual_output_1, expected_output_1)


# Generated at 2022-06-26 02:53:46.654518
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0.__setitem__('foo:bar:bas', 42)
    output_0 = tree_0.__getitem__('foo:bar:bas')
    output_1 = tree_0.__getitem__('foo:bar:bas', namespace='foo')
    assert output_0 == output_1 == tree_0.foo.bar.bas == 42



# Generated at 2022-06-26 02:53:49.664433
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    result_dict = {'a': {'b': {'c': 'd'}}}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert result_dict == test_dict


# Generated at 2022-06-26 02:53:55.873472
# Unit test for function set_tree_node
def test_set_tree_node():
    my_dict = {}
    set_tree_node(my_dict, 'test1:test2:test3', 'test3_value')
    assert my_dict['test1']['test2']['test3'] == 'test3_value'



# Generated at 2022-06-26 02:53:57.343940
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()

# Generated at 2022-06-26 02:54:04.759819
# Unit test for function get_tree_node
def test_get_tree_node():

    # Create a dictionary
    dictionary = {
        'a': 1,
        'b': 2
    }

    # Create a nested dictionary
    nested_dictionary = {
        'a': 1,
        'b': 2,
        'c': {
            'c1': 11,
            'c2': 22,
            'c3': {
                'c31': 111,
                'c32': 222
            }
        }
    }

    # Normal key
    assert get_tree_node(dictionary, 'a') == 1
    assert get_tree_node(dictionary, 'b') == 2

    # Normal key in multiple dictionaries
    assert get_tree_node(nested_dictionary, 'a') == 1
    assert get_tree_node(nested_dictionary, 'b') == 2

    #

# Generated at 2022-06-26 02:54:13.674282
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test function get_tree_node"""
    import unittest

    class TestGetTreeNode(unittest.TestCase):
        """Get tree node"""

        def setUp(self):
            self.tree = {
                'a': {
                    'b': 1
                }
            }

        def test_existing_path(self):
            """Test find node in existing path"""
            self.assertEqual(get_tree_node(self.tree, 'a:b'), 1)

        def test_existing_path_parent(self):
            """Test find parent node in existing path"""
            self.assertEqual(get_tree_node(self.tree, 'a:b', parent=True), self.tree['a'])

        def test_existing_path_parent(self):
            """Test find parent node in existing path"""

# Generated at 2022-06-26 02:54:22.988896
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['a']['b'] = {}
    tree_0['a']['b']['c'] = 123
    assert tree_0['a:b:c'] == 123, "Failed"


# Generated at 2022-06-26 02:54:27.453184
# Unit test for function get_tree_node
def test_get_tree_node():
    x = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f',
            }
        }
    }
    assert get_tree_node(x, 'a:b:c') == 'd'
    assert get_tree_node(x, 'a:b') == {'c': 'd', 'e': 'f'}
    assert get_tree_node(x, 'a:b:c', parent=True) == {'c': 'd', 'e': 'f'}
    assert get_tree_node(x, 'a:b:f', 'x') == 'x'



# Generated at 2022-06-26 02:54:33.902865
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': 'bar'}, 'bar') == _sentinel
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo') == {'bar': 'baz'}
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:baz') == _sentinel
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar:baz', default='default') == 'default'

# Generated at 2022-06-26 02:54:42.033196
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    # get_tree_node(mapping, key, default=_sentinel)
    # tree_0[k]: v
    k = "a"
    v = 1
    set_tree_node(tree_0, k, v)
    assert get_tree_node(tree_0, k) == v
    #
    k = "b:a"
    v = 2
    set_tree_node(tree_0, k, v)
    assert get_tree_node(tree_0, k) == v
    #
    k = "b:b:a"
    v = 3
    set_tree_node(tree_0, k, v)
    assert get_tree_node(tree_0, k) == v
    #
    k = "b"
    v = 2

# Generated at 2022-06-26 02:54:46.191480
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    tree_0.set_tree_node(tree_0, 'a:b:c', 'Testing tree')


# Generated at 2022-06-26 02:54:51.959546
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'hello': {
            'world': 'foo'
        }
    }
    assert get_tree_node(test_tree, 'hello:world') == 'foo'

    test_tree = tree()
    test_tree['hello']['world'] = 'foo'
    assert test_tree['hello']['world'] == 'foo'

    test_tree = Tree()
    test_tree['hello']['world'] = 'foo'
    assert test_tree['hello']['world'] == 'foo'


# Generated at 2022-06-26 02:54:59.832183
# Unit test for function get_tree_node
def test_get_tree_node():
    mock_mapping = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(mock_mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mock_mapping, 'foo:bar:baz:quux', default=True) is True


# Generated at 2022-06-26 02:55:12.782585
# Unit test for function get_tree_node
def test_get_tree_node():
    #print "********** Uncomment each test case line by line after fixing error *******"
    tree_0 = Tree()
    tree_0['a']['b']['c'] = 123
    #print tree_0

# Generated at 2022-06-26 02:55:24.339571
# Unit test for function get_tree_node
def test_get_tree_node():
    print("Testing function get_tree_node")
    mapping = {'foo': {'bar': {'baz': 'wut'}}}
    assert get_tree_node(mapping, 'foo:bar:baz', _sentinel) == 'wut'
    assert get_tree_node(mapping, 'foo:bar', _sentinel) == {'baz': 'wut'}
    assert get_tree_node(mapping, 'foo:bar:quux', default='quuux') == 'quuux'
    assert get_tree_node(mapping, 'foo:bar:baz', default='quuux') == 'wut'
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'wut'}
    assert get_tree_

# Generated at 2022-06-26 02:55:35.668409
# Unit test for function get_tree_node
def test_get_tree_node():
    def _test_case_0():
        get_tree_node({}, 'A')
        get_tree_node({'A': '1'}, 'A')
        get_tree_node({'A': '1'}, 'B', default='2')
        get_tree_node({'A': {'B': {'C': '1'}}}, 'A:B:C', default='2')

    def _test_case_1():
        get_tree_node({'A': ['1']}, 'A', parent=True)

    def _test_case_2():
        get_tree_node({'A': ['1']}, 'A:0', parent=True)

    def _test_case_3():
        get_tree_node({'A': ['1']}, 'A:0:1', parent=True)



# Generated at 2022-06-26 02:55:44.656019
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = tree()
    test_data['a']['b']['c']['d'] = 'z'
    assert get_tree_node(test_data, 'a:b:c:d') == 'z'
    assert get_tree_node(test_data, 'a:b:c:d:e:f:g') == _sentinel
    assert get_tree_node(test_data, 'a:b:c:d:e:f:g', default='foo') == 'foo'


# Generated at 2022-06-26 02:55:50.408735
# Unit test for function set_tree_node
def test_set_tree_node():
    # Initialize.
    var_1 = {}
    var_2 = 'key'
    var_3 = 'value'

    # Run function.
    var_4 = set_tree_node(var_1, var_2, var_3)

    # Check result.
    assert var_1 == {'key': 'value'}
    assert var_4 == {'key': 'value'}



# Generated at 2022-06-26 02:56:02.382061
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:56:13.046092
# Unit test for function get_tree_node
def test_get_tree_node():
    l = {
        'deep': {'nested': {'key': 'value'}},
        'shallow': {'key': 'value2'}
    }
    assert get_tree_node(l, 'deep:nested') == {'key': 'value'}
    assert get_tree_node(l, 'shallow') == {'key': 'value2'}
    assert get_tree_node(l, 'shallow:key') == 'value2'
    assert get_tree_node(l, 'other', default='dflt') == 'dflt'
    assert get_tree_node(l, 'deep:nested', parent=True)['deep']['nested'] == {'key': 'value'}

    # Ensure KeyError is properly raised.

# Generated at 2022-06-26 02:56:14.612247
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 1 == 1



# Generated at 2022-06-26 02:56:22.845820
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    var_2 = [var_1]
    set_tree_node(var_2[0], "a", 56)
    assert tree() == var_1
    assert 56 == var_1["a"]
    set_tree_node(var_1, "b", 112)
    assert tree() == var_1["b"]
    assert 112 == var_1["b"]
    set_tree_node(var_1["b"], "c", 168)
    assert tree() == var_1["b"]["c"]
    assert 168 == var_1["b"]["c"]


# Generated at 2022-06-26 02:56:27.939503
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test for setting arbitrary node of tree-like mapping structure."""
    # TODO: Implement unit test for function set_tree_node.
    raise NotImplementedError("Unit test for function set_tree_node.")



# Generated at 2022-06-26 02:56:28.723686
# Unit test for function get_tree_node
def test_get_tree_node():
    print(get_tree_node(None, None, None))


# Generated at 2022-06-26 02:56:33.225852
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {
        "foo": {
            "bar": {
                "baz": "quux"
            }
        }
    }

    var_1 = get_tree_node(var_0, "foo:bar:baz")
    var_1 = get_tree_node(var_0, "foo:bar:baz", parent=True)

    var_1 = get_tree_node(var_0, "foo:bar:baz:parent")

    var_1 = get_tree_node(var_0, "foo:bar:baz:parent", parent=True)

    var_1 = get_tree_node(var_0, "foo:bar:baz:parent", default="default value")


# Generated at 2022-06-26 02:56:43.653308
# Unit test for function set_tree_node
def test_set_tree_node():
    from nose.tools import assert_equal
    from nose.tools import assert_raises
    from nose.tools import assert_true
    from nose.tools import assert_false
    var_1 = tree()
    set_tree_node(var_1, 'key_0', 'value_0')
    set_tree_node(var_1, 'key_1', 'value_1')
    assert_equal(var_1, {'key_0': 'value_0', 'key_1': 'value_1'})
    try:
        set_tree_node(var_1, 'key_2', 'value_2')
    except KeyError as exc:
        assert_true(False, 'KeyError should not be raised')
    except Exception as exc:
        pass


# Generated at 2022-06-26 02:57:07.619171
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {'key': 'value'}
    var_1 = get_tree_node(var_0, 'key')

    var_0 = {'a': 1, 'b': '2', 'c': 3.0}
    var_1 = get_tree_node(var_0, 'a')
    var_2 = get_tree_node(var_0, 'b')
    var_3 = get_tree_node(var_0, 'c')
    var_4 = get_tree_node(var_0, 'd')
    var_5 = get_tree_node(var_0, 'a', default=True)

    var_0 = {'a': {'b': {'c': 'd'}}}

# Generated at 2022-06-26 02:57:12.039477
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test for correct return type of get_tree_node(mapping, key, default=, parent=)
    assert(isinstance(get_tree_node({}, ""), collections.Mapping))


# Generated at 2022-06-26 02:57:20.524827
# Unit test for function set_tree_node
def test_set_tree_node():
    my_dict = collections.defaultdict(tree)
    set_tree_node(my_dict, "one", "hello")
    assert my_dict["one"] == "hello"

    set_tree_node(my_dict, "one:two", "goodbye")
    assert my_dict["one"]["two"] == "goodbye"


# Generated at 2022-06-26 02:57:24.573768
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': {'baz': 'qux'}}}
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'
    assert get_tree_node(mapping, 'foo') == {'bar': {'baz': 'qux'}}
    try:
        get_tree_node(mapping, 'foo:bar:qux')
    except KeyError:
        assert True
    else:
        assert False



# Generated at 2022-06-26 02:57:35.768957
# Unit test for function get_tree_node
def test_get_tree_node():
    class _Test:
        def key(self, val=_sentinel):
            if val is not _sentinel:
                self.val = val
                return self
            return self.val

    test_mapping = {'key0': 'value0', 'key1': {'key1': 'value1'}}

    # Assert that get_tree_node raises KeyError if node not found
    pytest.raises(KeyError, get_tree_node, test_mapping, 'key3')

    # Assert that get_tree_node returns the correct value
    # Single dimension
    assert get_tree_node(test_mapping, 'key0') == 'value0'
    # Multi-dimension
    assert get_tree_node(test_mapping, 'key1:key1') == 'value1'
    # Nonex

# Generated at 2022-06-26 02:57:39.757028
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, 'a:b:c:d', 'test_value')
    print(a)


# Generated at 2022-06-26 02:57:47.950564
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_get_tree_node_dict_0 = {}
    tree_get_tree_node_dict_0['a'] = {}
    tree_get_tree_node_dict_0['a']['b'] = {}
    tree_get_tree_node_dict_0['a']['c'] = {}
    tree_get_tree_node_dict_0['a']['b']['d'] = 1
    tree_get_tree_node_dict_0['a']['b']['e'] = 1
    tree_get_tree_node_dict_0['a']['c']['f'] = 1
    tree_get_tree_node_dict_0['a']['c']['g'] = 1

    tree_get_tree_node_str_0 = 'a'
   

# Generated at 2022-06-26 02:57:53.516103
# Unit test for function set_tree_node
def test_set_tree_node():
    '''
    Set arbitrary node on a tree-like mapping structure, allowing for : notation to signify dimension.
    '''
    # if the first test fails, this will kill the whole test suite
    assert True
    # Your code here



# Generated at 2022-06-26 02:57:55.486096
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = {}
    var_0 = {'var_1': None}
    var_0 = {'var_1': None}



# Generated at 2022-06-26 02:58:03.343833
# Unit test for function get_tree_node
def test_get_tree_node():
    print(get_tree_node(var_0, 'a:b:c'))
    print(get_tree_node(var_0, 'a:b:c:d', default='notfound'))
    try:
        get_tree_node(var_0, 'a:b:c:d')
    except Exception as e:
        print(e)


# Generated at 2022-06-26 02:58:40.703663
# Unit test for function get_tree_node
def test_get_tree_node():
    # Here we make a mock object, simulating a dictionary
    #
    tree = {'a': {'b': 'c'}}
    #
    assert get_tree_node(tree, 'a') == {'b': 'c'}, "Get 'a' should get {'b': 'c'}, got %s" % get_tree_node(
        tree, 'a')
    assert get_tree_node(tree, 'a:b') == 'c', "Get 'a:b' should get 'c', got %s" % get_tree_node(tree, 'a:b')
    assert get_tree_node(tree, 'z') == None, "Get 'z' should get None, got %s" % get_tree_node(tree, 'z')
    assert get_tree_node(tree, 'a:z')

# Generated at 2022-06-26 02:58:50.754682
# Unit test for function set_tree_node
def test_set_tree_node():
    from random import randint
    from string import ascii_letters
    from collections import defaultdict
    from itertools import cycle
    from copy import deepcopy
    from nose.tools import assert_equal, assert_is_instance


# Generated at 2022-06-26 02:59:00.497100
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
            'a': {
                'b': {
                    'c': 'd'
                }
            }
        }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b')['c'] == 'd'
    assert get_tree_node(mapping, 'a:b', default=None)['c'] == 'd'
    assert get_tree_node(mapping, 'a:b:c', default=None) == 'd'
    # test_case_0()


if __name__ == '__main__':
    from test_case_0 import test_case_0
    test_case_0()

# Generated at 2022-06-26 02:59:02.507416
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(mapping=None, key=None, default=None, parent=None) == None


# Generated at 2022-06-26 02:59:04.760565
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, var_1, var_2)
    assert var_0 == var_3


# Generated at 2022-06-26 02:59:10.818612
# Unit test for function get_tree_node
def test_get_tree_node():
    assert raise_if_not(get_tree_node('mapping', 'key', default='default', parent='parent') == _sentinel, AssertionError)
    assert get_tree_node('mapping', 'key', default=_sentinel, parent='parent')


# Generated at 2022-06-26 02:59:19.428226
# Unit test for function get_tree_node
def test_get_tree_node():
    abc = {'a': {'b': {'c': {'d': 'e', 'f': 'g'}}}}
    assert get_tree_node(abc, 'a:b:c:d') == 'e'

    abc = {'a': {'b': {'c': {'d': 'e', 'f': 'g'}}}}
    assert get_tree_node(abc, 'a:h:c:d', default='yes') == 'yes'

    abc = {'a': {'b': {'c': {'d': 'e', 'f': 'g'}}}}
    assert get_tree_node(abc, 'a:h:c:d', parent=True) == {'b': {'c': {'d': 'e', 'f': 'g'}}}