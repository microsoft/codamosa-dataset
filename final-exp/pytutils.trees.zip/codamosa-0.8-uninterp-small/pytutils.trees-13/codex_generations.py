

# Generated at 2022-06-26 02:49:24.416509
# Unit test for function get_tree_node
def test_get_tree_node():
    tests = [
        # (input, output)
        ((tree(), 'foo', None, _sentinel), None),
        ((tree(), 'foo', 'bar', _sentinel), 'bar'),
        ((tree(), 'foo:bar', None, _sentinel), None),
        ((tree(), 'foo:bar', 'baz', _sentinel), 'baz'),
        ((tree(), 'foo', None, True), {}),
        ((tree(), 'foo:bar', None, True), {}),
        (({'foo': 'bar'}, 'foo', None, True), {}),
        (({'foo': {'bar': True}}, 'foo:bar', None, True), {'foo': {'bar': True}}),
        (({'foo': {'bar': True}}, 'foo:bar', None, False), True),
    ]



# Generated at 2022-06-26 02:49:29.397008
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {"root": {"child": 1}}
    set_tree_node(test_dict, "root:child", 2)
    assert test_dict == {"root": {"child": 2}}
    set_tree_node(test_dict, "root:another", 3)
    assert test_dict == {"root": {"child": 2, "another": 3}}


# Generated at 2022-06-26 02:49:37.592937
# Unit test for function get_tree_node
def test_get_tree_node():
    x = Tree({
        'foo': 'bar',
        'bar': {
            'baz': 'qux',
        }
    })
    assert x.get('foo') == 'bar'
    assert x.get('baz:qux') == 'qux'
    assert x.get('baz:qux:') == 'qux'
    assert x.get('baz:qux', parent=True) == {'baz': 'qux'}
    assert x.get('baz:qux:') == 'qux'
    assert x.get('baz:qux:', parent=True) == {'baz': 'qux'}
    assert x.get('baz') == {'qux': ''}

# Generated at 2022-06-26 02:49:46.755797
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()

# Generated at 2022-06-26 02:49:57.317303
# Unit test for function get_tree_node
def test_get_tree_node():
    # init a tree
    tree = {'a': 'value1', 'b': {'c': 'value3', 'd': 'value4'}}
    # test get_tree_node for key in root
    assert get_tree_node(tree, 'a') == 'value1'
    assert get_tree_node(tree, 'b') == {'c': 'value3', 'd': 'value4'}
    # test get_tree_node for key not in root
    assert get_tree_node(tree, 'b:c') == 'value3'
    assert get_tree_node(tree, 'b:d') == 'value4'
    # test get_tree_node for key not in the tree

# Generated at 2022-06-26 02:50:05.140519
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()

# Generated at 2022-06-26 02:50:12.216656
# Unit test for function get_tree_node
def test_get_tree_node():
    # Positive case
    tree_0 = Tree()
    tree_0['a']['b']['c'] = 'abc'
    assert get_tree_node(tree_0, 'a:b:c') == 'abc'

    # Negative case
    assert get_tree_node(tree_0, 'a:b:d') == _sentinel

    tree_1 = tree()
    tree_1['a']['b']['c'] = tree_1
    assert get_tree_node(tree_1, 'a:b:c') is tree_1



# Generated at 2022-06-26 02:50:22.898579
# Unit test for function get_tree_node
def test_get_tree_node():

    tree_0 = Tree()
    tree_0['1'] = {'a': 1, 'b': 2, 'c': 3}
    tree_0['1']['1'] = {'a': 1, 'b': 2, 'c': 3}
    tree_0['1']['2'] = {'a': 1, 'b': 2, 'c': 3}
    tree_0['1']['3'] = {'a': 1, 'b': 2, 'c': 3}

    assert tree_0['1:1:a'] == 1
    assert tree_0['1:2'] == {'a': 1, 'b': 2, 'c': 3}
    assert tree_0['1:1:1:a'] == 1
    assert tree_0['1:2:2:b'] == 1


#

# Generated at 2022-06-26 02:50:31.688490
# Unit test for function get_tree_node
def test_get_tree_node():
    # Case 1:
    #   mapping: {
    #       'foo': {
    #           'bar': 'baz'
    #       }
    #   }
    #   key: 'foo:bar'
    #   expected: 'baz'
    mapping = {
        'foo': {
            'bar': 'baz'
        }
    }
    key = 'foo:bar'
    expected = 'baz'
    actual = get_tree_node(mapping, key)
    assert(expected == actual)

    # Case 2:
    #   mapping: {
    #       'foo': {
    #           'bar': 'baz'
    #       }
    #   }
    #   key: 'foo:biz:bop'
    #   expected: KeyError

# Generated at 2022-06-26 02:50:41.015893
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'first_name': 'A', 'last_name': 'B'}
    assert get_tree_node(d, 'first_name') == 'A'
    assert get_tree_node(d, 'does_not_exit', default=None) is None

    d = {'first_name': 'A', 'last_name': 'B', 'misc': {'misc2': {'misc3': {'misc4': 'bar'}}}}
    assert get_tree_node(d, 'misc:misc2:misc3:misc4') == 'bar'

    # test parent node
    assert get_tree_node(d, 'misc:misc2', parent=True) == {'misc2': {'misc3': {'misc4': 'bar'}}}



# Generated at 2022-06-26 02:50:49.242216
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test for function set_tree_node
    """
    my_tree = tree()
    my_dict = dict()
    my_dict['name'] = 'joe'
    my_dict['age'] = 'joe'
    set_tree_node(my_tree, 'person:name', 'joe')
    set_tree_node(my_dict, 'person:name', 'joe')
    assert my_tree['person']['name'] == my_dict['person']['name']



# Generated at 2022-06-26 02:50:52.927944
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping_0 = {
        'animal': {
            'dog': {
                'toy': 'tug'
            },
            'cat': {
                'toy': 'ball'
            }
        }
    }

    result = get_tree_node(test_mapping_0, 'animal:dog:toy')
    print('result:', result)
    assert result == 'tug'


# Generated at 2022-06-26 02:51:00.383871
# Unit test for function get_tree_node
def test_get_tree_node():
    input = {'a': 1, 'b': {'c': [1, 2, 3], 'd': 4, 'e': {'f': 5, 'g': 6}}}
    assert get_tree_node(input, 'b:e:f') == 5
    assert get_tree_node(input, 'b:foo') is _sentinel



# Generated at 2022-06-26 02:51:08.375772
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = {'a': 1, 'b': 2}
    set_tree_node(tree_0, 'b', 3)
    assert tree_0 == {'a': 1, 'b': 3}, 'test_set_tree_node: %s != {\'a\': 1, \'b\': 3}' % tree_0
    set_tree_node(tree_0, 'c', 4)
    assert tree_0 == {'a': 1, 'b': 3, 'c': 4}, 'test_set_tree_node: %s != {\'a\': 1, \'b\': 3, \'c\': 4}' % tree_0


# Generated at 2022-06-26 02:51:15.366774
# Unit test for function get_tree_node
def test_get_tree_node():
    # get_tree_node(mapping, key, default=_sentinel, parent=False):
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': 100,
                        'f': 200,
                    },
                    'g': {'h': 300},
                },
                'i': {'j': 400},
            },
        }
    }
    assert get_tree_node(mapping, 'a:b:c:d:e') == 100
    assert get_tree_node(mapping, 'a:b:c:d:f') == 200
    assert get_tree_node(mapping, 'a:b:g:h') == 300

# Generated at 2022-06-26 02:51:25.421888
# Unit test for function get_tree_node
def test_get_tree_node():
    dict1 = {
        'a': {
            'b': {
                'c': 'd'
            }
        },
        'e': 'f'
    }
    dict2 = {
        'a': {
            'b': 1,
            'c': 2
        }
    }
    dict3 = {
        'a': 'b',
        'e': 'f'
    }
    assert get_tree_node(dict1, 'a:b:c') == 'd'
    assert get_tree_node(dict1, 'e') == 'f'
    assert get_tree_node(dict1, 'g') == _sentinel
    assert get_tree_node(dict2, 'a:b') == 1
    assert get_tree_node(dict2, 'a:c') == 2
   

# Generated at 2022-06-26 02:51:27.566299
# Unit test for function set_tree_node
def test_set_tree_node():
  test = tree()
  assert set_tree_node(test, 'a:b:c', 3) == 3
  assert test['a']['b']['c'] == 3



# Generated at 2022-06-26 02:51:29.928377
# Unit test for function get_tree_node
def test_get_tree_node():
   pass
   # TODO Write code here to test get_tree_node
   #assert(False), "get_tree_node not yet implemented"


# Generated at 2022-06-26 02:51:35.989764
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {'a': {'b': {'c': 'd'}}}

    assert get_tree_node(tree_0, 'a:b:c') == 'd'
    assert get_tree_node(tree_0, 'a:b') == {'c': 'd'}
    assert get_tree_node(tree_0, 'z') is _sentinel



# Generated at 2022-06-26 02:51:45.762964
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['a'] = 1
    tree_0['l'] = tree_0['l'] = tree_0['l'] = tree_0['l'] = tree_0['l'] = tree_0['l'] = {}

# Generated at 2022-06-26 02:51:54.783748
# Unit test for function get_tree_node
def test_get_tree_node():

    containers = (
        dict,
        Tree,
    )

    for keys in (
        'foo:bar:baz:quz',
        ['foo', 'bar', 'baz', 'quz'],
    ):
        for container in containers:
            # Container should not be constructed yet
            # TODO Use pytest's autouse and yield instead
            container_ = container(initial_is_ref=True)

            # Set arbitrary tree
            set_tree_node(container_, keys, 'value')

            # Fetch arbitrary tree
            val = get_tree_node(container_, keys)
            assert val == 'value'

# Generated at 2022-06-26 02:52:06.633636
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = tree()
    set_tree_node(tree, 'a', 1)
    assert(tree['a'] == 1)

    set_tree_node(tree, 'a:b', 2)
    assert(tree['a'] == {'b': 2})

    set_tree_node(tree, 'a:c', 3)
    assert(tree['a'] == {'b': 2, 'c': 3})

    set_tree_node(tree, 'a', {'d': 4, 'f': 5})
    assert(tree['a'] == {'b': 2, 'c': 3, 'd': 4, 'f': 5})

    set_tree_node(tree, 'a:e', 6)

# Generated at 2022-06-26 02:52:14.005595
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree(initial={'hello':'test'})

    expected_result_0 = 'test'
    assert ( get_tree_node(tree_0, 'hello') == expected_result_0 )

    expected_result_1 = 'test'
    assert ( get_tree_node(tree_0, 'hello:') == expected_result_1 )

    expected_result_2 = 'test'
    assert ( get_tree_node(tree_0, 'hello:hello') == expected_result_2 )

    expected_result_3 = 'test'
    assert ( get_tree_node(tree_0, 'hello:hello:hello') == expected_result_3 )

    expected_result_4 = 'test'

# Generated at 2022-06-26 02:52:17.416075
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }

    assert get_tree_node(tree_0, key='a:b:c') == 'd'



# Generated at 2022-06-26 02:52:21.025485
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = tree()
    set_tree_node(tree_0, 'foo:bar:baz', 'derp')
    result = get_tree_node(tree_0, 'foo:bar:baz')

# Generated at 2022-06-26 02:52:31.877738
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = tree()
    tree_0['foo']['bar'] = 'abc'
    assert get_tree_node(tree_0, 'foo:bar') == 'abc'
    assert get_tree_node(tree_0, 'foo:bar') == 'abc'
    assert get_tree_node(tree_0, 'foo:baz') == {}
    assert get_tree_node(tree_0, 'foo:baz:bob', parent=True) == {}

    tree_1 = {'foo': {'bar': 'abc'}}
    assert get_tree_node(tree_1, 'foo:bar') == 'abc'
    assert get_tree_node(tree_1, 'foo:baz') == None

# Generated at 2022-06-26 02:52:34.716546
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    set_tree_node(tree_0, 'foo:bar:baz', 'test')
    assert tree_0['foo:bar:baz'] == 'test'



# Generated at 2022-06-26 02:52:37.116873
# Unit test for function get_tree_node
def test_get_tree_node():
    local_tree = {'foo': {'bar': 42}}
    value = get_tree_node(local_tree, 'foo:bar')
    assert value == 42


# Generated at 2022-06-26 02:52:45.911717
# Unit test for function set_tree_node
def test_set_tree_node():
    # Create a tree with a single node
    tree_0 = Tree()
    set_tree_node(tree_0, 'a.b.c.d', 'test')
    # Assert if the value at node tree_0['a']['b']['c']['d'] is 'test'
    assert(tree_0['a']['b']['c']['d'] == 'test')


# Generated at 2022-06-26 02:52:48.303668
# Unit test for function get_tree_node
def test_get_tree_node():

    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 02:52:54.121467
# Unit test for function get_tree_node
def test_get_tree_node():
    pass


# Generated at 2022-06-26 02:53:03.282156
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {
        'foo': {
            'bar': {
                'baz': 'bravo'
            }
        }
    }
    assert get_tree_node(tree_0, 'foo:bar:baz') == 'bravo'
    assert get_tree_node(tree_0, 'foo:bar:baz', 'default') == 'bravo'
    assert get_tree_node(tree_0, 'foo:bar:qux', 'default') == 'default'
    assert get_tree_node(tree_0, 'foo:bar:qux') == None
    assert get_tree_node(tree_0, 'foo:bar:qux', parent=True) == tree_0['foo']['bar']
    # FIXME get_tree_node does not return parent if root key

# Generated at 2022-06-26 02:53:07.321704
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0[':first:second:third:fourth'] = 'test'
    assert tree_0[':first:second']['third']['fourth'] == 'test'



# Generated at 2022-06-26 02:53:12.257538
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    set_tree_node(tree_0, "a:b", "c")
    assert(tree_0['a:b'] == "c")



# Generated at 2022-06-26 02:53:21.177593
# Unit test for function get_tree_node
def test_get_tree_node():
    t0 = Tree()
    assert get_tree_node(t0, 'a:b:c:d:e') is None
    assert get_tree_node(t0, 'a:b:c:d:e:f') is None
    assert get_tree_node(t0, 'a:b:c:d:e', default='default') == 'default'
    assert get_tree_node(t0, 'a:b:c:d:e', parent=True) is None

    t0['a']['b']['c']['d']['e'] = 'f'
    assert get_tree_node(t0, 'a:b:c:d:e') == 'f'

# Generated at 2022-06-26 02:53:32.547745
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'one': {
            'two': {
                'three': {
                    'four': 4,
                }
            }
        }
    }
    assert get_tree_node(mapping, 'one:two:three:four') == 4
    assert get_tree_node(mapping, 'one:two:three:four', default=None) == 4
    assert get_tree_node(mapping, 'one:two:three:four:five:six', default=None) is None
    assert get_tree_node(mapping, 'one:two:three:four:five:six') == get_tree_node(mapping, 'one:two:three:four:five:six', default=_sentinel)


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-26 02:53:36.224936
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = tree()
    set_tree_node(tree, "1:2:3", 4)
    assert tree[1][2][3] == 4


# Generated at 2022-06-26 02:53:40.621266
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()

# Generated at 2022-06-26 02:53:51.099839
# Unit test for function get_tree_node
def test_get_tree_node():

    # Given
    test_dict = {
        'a': {
            'A': 'A',
            'B': [
                'B',
                'C'
            ]
        }
    }

    # When
    test_node_0 = get_tree_node(test_dict, 'a:A')

    # Then
    assert test_node_0 == 'A'

    # When
    test_node_0 = get_tree_node(test_dict, 'a:B')

    # Then
    assert test_node_0 == ['B', 'C']

    # When
    test_node_0 = get_tree_node(test_dict, 'a:B:0')

    # Then
    assert test_node_0 == 'B'

    # When
    test_node_0 = get_tree_

# Generated at 2022-06-26 02:54:01.842572
# Unit test for function get_tree_node
def test_get_tree_node():
    import collections
    import collections
    import pytest
    # tree_0 = {'a': {'b': {'f': 1, 'g': 1}, 'c': {'f': 1}, 'd': {'e': {'h': 1}}}


    # tree_0['a:b:f'] == 1
    assert(get_tree_node(tree_0, 'a:b:f') == 1)

    # tree_0['a:c:f'] == 1
    assert(get_tree_node(tree_0, 'a:c:f') == 1)

    # tree_0['a:d:e:h'] == 1
    assert(get_tree_node(tree_0, 'a:d:e:h') == 1)



# Generated at 2022-06-26 02:54:22.308418
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test 1: Get item in first dimension
    tree_1 = Tree({'a': 'b'})
    assert(get_tree_node(tree_1, 'a') == 'b')

    # Test 2: Get item in second dimension
    tree_2 = Tree({'a': {'b': 'c'}})
    assert(get_tree_node(tree_2, 'a:b') == 'c')

    # Test 3: Default value returned
    tree_3 = Tree()
    assert(get_tree_node(tree_3, 'a:b', 'c') == 'c')

    # Test 4: KeyError raised
    tree_4 = Tree()
    with pytest.raises(KeyError):
        get_tree_node(tree_4, 'a:b')



# Generated at 2022-06-26 02:54:31.071192
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['foo'] = {'bar': {'baz': 'qux'}}
    assert get_tree_node(tree_0, 'foo:bar:baz') == 'qux'
    try:
        node = get_tree_node(tree_0, 'foo:bar:bar')
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised')
    node = get_tree_node(tree_0, 'foo:bar:baz:call:me:maybe', default='lol')
    assert node == 'lol'



# Generated at 2022-06-26 02:54:39.068640
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = tree()
    assert get_tree_node(tree_0, 'a') == tree_0['a']
    assert get_tree_node(tree_0, 'a:b') == tree_0['a']['b']
    # Test parent
    assert get_tree_node(tree_0, 'a:b', parent=True) == tree_0['a']
    # Test default values
    assert get_tree_node(tree_0, 'a:b:c:d:e:f', default='foo') == 'foo'



# Generated at 2022-06-26 02:54:47.713600
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test for get_tree_node"""
    tree_0 = {
        'a': {
            'b': {
                'c': 'd',
                'e': {
                    'f': 'g',
                    'h': 'i'
                }
            }
        }
    }

    assert (get_tree_node(tree_0, 'a:b:e:f')) == 'g'

# Generated at 2022-06-26 02:54:51.222608
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['a']['b'] = 'c'
    assert tree_0['a:b'] == 'c'
    assert tree_0.get('a:b') == 'c'

    # Test exceptions
    try:
        tree_0['a:c']
        assert False
    except KeyError:
        pass

# Generated at 2022-06-26 02:54:52.877851
# Unit test for function set_tree_node
def test_set_tree_node():
    assert True


# Generated at 2022-06-26 02:54:57.455199
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    test_tree.set_tree_node('test:test:test', 'test')
    assert test_tree['test']['test']['test'] == 'test'



# Generated at 2022-06-26 02:55:00.561380
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    node = tree_0.set_tree_node("stack:overflow.com", "This is a test")
    assert node == {"overflow.com": {"stack": "This is a test"}}


# Generated at 2022-06-26 02:55:12.881465
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 123,
                'd': {
                    'e': 456,
                    'f': 789,
                }
            }
        }
    }

    # Direct access
    assert tree['a']['b']['c'] == 123

    # : delimited
    assert get_tree_node(tree, 'a:b:c') == 123

    # Parent node
    assert get_tree_node(tree, 'a:b:d', parent=True) is tree['a']['b']

    # No default
    with pytest.raises(KeyError):
        get_tree_node(tree, 'a:b:d:e:f')

    # Default value

# Generated at 2022-06-26 02:55:21.321066
# Unit test for function get_tree_node
def test_get_tree_node():
    test_map = {1: {2: {3: 'four'}}}
    assert get_tree_node(test_map, '1:2:3') == 'four'
    try:
        get_tree_node(test_map, '1:2:3:4')
    except KeyError:
        pass
    else:
        assert False, 'Nothing should be gettable from 1:2:3:4'


# Generated at 2022-06-26 02:55:45.780015
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['hi']['this']['is']['cool'] = True
    assert get_tree_node(tree_0, 'hi:this:is:cool') == True


# Generated at 2022-06-26 02:55:52.618512
# Unit test for function get_tree_node
def test_get_tree_node():
    a_dict = {'a': {'b': {'c': 1}}}
    assert get_tree_node(a_dict, 'a:b') == {'c': 1}
    assert get_tree_node(a_dict, 'a:b:c') == 1
    assert get_tree_node(a_dict, 'd', default={}) == {}
    assert get_tree_node(a_dict, 'a:d', default={}) == {}
    assert get_tree_node(a_dict, 'a:e', default=_sentinel)
    # assert get_tree_node(a_dict, 'a:e')


# Generated at 2022-06-26 02:56:03.203670
# Unit test for function set_tree_node
def test_set_tree_node():
    # Prepare test case
    testTree = collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict()))
    testTree['_namespace']['test']['test1']['test2'] = 123
    testTree['_namespace']['test']['test1']['test3'] = 456
    testTree['_namespace']['test']['test4']['test5'] = 789
    testTree['_namespace']['test']['test6'] = 901

    # Test set_tree_node
    set_tree_node(testTree, 'test:test7:test8:test9', 123)
    assert testTree['_namespace']['test']['test7']['test8']['test9'] == 123

    # Test set_

# Generated at 2022-06-26 02:56:05.458234
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(None, 'test') == None


# Generated at 2022-06-26 02:56:11.593099
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_ = Tree(initial={'master': {'slave': 'slave-value'}}, namespace='test')
    assert get_tree_node(tree_, 'test:master')['test:master']['slave'] == 'slave-value'
    assert get_tree_node(tree_, 'test:master:slave') == 'slave-value' 
    assert get_tree_node(tree_, 'test:master:salve') == None

# Generated at 2022-06-26 02:56:19.777412
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping_0 = {'a':{'b':{'c':'d', 'e':'f'}, 'g':'h'}}
    key_0 = 'a:b:c'
    default_0 = 'd'
    value_0 = mincepy.get_tree_node(mapping_0, key_0, default_0)
    assert value_0 == 'd'



# Generated at 2022-06-26 02:56:31.704246
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {'my': {'test': 'data'},
              'hello': 'world',
              'foo': {'bar': {'baz': 'yay'}},
              'list': ['1', '2', '3'],
              'dict': {'1': '1', '2': '2', '3': '3'},
              'my': 'json',
              'a': {'b': {'d': 'e'}}}
    test_get_tree_node_0 = get_tree_node(tree_0, 'my')
    assert test_get_tree_node_0 == {'test': 'data'}
    test_get_tree_node_1 = get_tree_node(tree_0, 'my:test')
    assert test_get_tree_node_1 == 'data'

# Generated at 2022-06-26 02:56:39.066281
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test valid set_tree_node
    a = {}
    set_tree_node(a, 'a', 1)
    assert a['a'] == 1

    # Test invalid set_tree_node
    b = {}
    set_tree_node(b, 'b:c', 2)
    assert 'c' not in b['b']



# Generated at 2022-06-26 02:56:41.782642
# Unit test for function set_tree_node
def test_set_tree_node():
    data = Tree()
    res = set_tree_node(data, 'key:tree:item', 'value')
    assert data['key']['tree']['item'] == 'value'
    assert res == data['key']['tree']



# Generated at 2022-06-26 02:56:53.461845
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    set_tree_node: Set arbitrary node on a tree-like mapping structure, allowing for : notation to signify dimension.
    Code:
        def set_tree_node(mapping, key, value):
            basename, dirname = key.rsplit(':', 2)
            parent_node = get_tree_node(mapping, dirname)
            parent_node[basename] = value
            return parent_node
    """
    tree_0 = Tree()

    # Single value
    tree_0['test'] = 'test'
    assert tree_0['test'] == 'test'

    # Multi-value
    tree_0['test:multi'] = 'multi'
    assert tree_0['test']['multi'] == 'multi'
    assert tree_0['test:multi'] == 'multi'

    # Sub

# Generated at 2022-06-26 02:57:47.235726
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {}
    tree_0['1'] = {'1.1': {'1.1.1': 1, '1.1.2': 2, '1.1.3': 3}, '1.2': {'1.2.1': 1, '1.2.2': 2, '1.2.3': 3}, '1.3': {'1.3.1': 1, '1.3.2': 2, '1.3.3': 3}}

# Generated at 2022-06-26 02:57:57.316506
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    This function is supposed to get the value of a node in a tree of nodes
    """
    test_dict = {'key-1': 'value-1',
                 'key-2': {'key-2-1': 'value-2-1',
                           'key-2-2': 'value-2-2',
                           'key-2-3': 'value-2-3'}}

    # test case 1: get value of a root node
    node = get_tree_node(test_dict, 'key-1')
    # print(node)
    assert node == 'value-1'

    # test case 2: get value of a leaf node
    node = get_tree_node(test_dict, 'key-2:key-2-1')
    # print(node)

# Generated at 2022-06-26 02:58:07.522160
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {'a': {'b': {'c': 'd'}}}
    set_tree_node(a, 'a:b:c', 'dd')
    assert a['a']['b']['c'] == 'dd'
    set_tree_node(a, 'a:b:foo', 'bar')
    assert a['a']['b']['foo'] == 'bar'
    set_tree_node(a, 'a:b:c:d:e', 'f')
    assert a['a']['b']['c']['d']['e'] == 'f'
    set_tree_node(a, 'foo:bar:baz', 'bar')
    assert a['foo']['bar']['baz'] == 'bar'

# Generated at 2022-06-26 02:58:17.041072
# Unit test for function get_tree_node
def test_get_tree_node():

    # Test nested access
    data = {'Chapter 1': {'Chapter 2': {'Chapter 3': "Page 1 to 30"}}}
    assert get_tree_node(data, 'Chapter 1') == {'Chapter 2': {'Chapter 3': "Page 1 to 30"}}
    assert get_tree_node(data, 'Chapter 1:Chapter 2') == {'Chapter 3': "Page 1 to 30"}
    assert get_tree_node(data, 'Chapter 1:Chapter 2:Chapter 3') == "Page 1 to 30"

    # Test failure
    assert get_tree_node(data, 'Chapter 2') == None

    return True



# Generated at 2022-06-26 02:58:28.214996
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['key1:key2:key3'] = 'value'
    tree_0['key1:key4'] = 'value'
    tree_0['key5'] = 'value'

    result_0 = get_tree_node(tree_0, 'key1:key2:key3')
    assert result_0 == 'value'

    result_1 = get_tree_node(tree_0, 'key1:key2:key3', parent=True)
    assert result_1['key3'] == 'value'

    result_2 = get_tree_node(tree_0, 'key1:key2:keyz', default=None)
    assert result_2 is None

    result_3 = None

# Generated at 2022-06-26 02:58:39.277766
# Unit test for function get_tree_node
def test_get_tree_node():
    # arrange
    mapping = Tree()
    key = 'a:b:c:d:e:f:g'
    value = 'test'

    # act
    try:
        get_tree_node(mapping, key, default=_sentinel)
    except KeyError:
        pass
    else:
        assert False

    # assert
    assert get_tree_node(mapping, key, default='test') == 'test'

    # arrange
    set_tree_node(mapping, key, 'test')
    result = get_tree_node(mapping, key)

    # assert
    assert result == value

    # arrange
    result = get_tree_node(mapping, key, default=_sentinel, parent=True)

# Generated at 2022-06-26 02:58:50.355089
# Unit test for function get_tree_node
def test_get_tree_node():
    # If a dict is passed as mapping, it should return the item in a dict
    t = {'a':{'b':{'c':1}}}
    assert(get_tree_node(t, 'a:b:c', default=_sentinel)==1)
    assert(get_tree_node(t, 'a:d:e', default=_sentinel)==_sentinel)
    assert(get_tree_node(t, 'a:d:e', default=None)==None)
    assert(get_tree_node(t, 'a:d:e:f:g')=={})
    assert(get_tree_node(t, 'a:d:e:f:g', parent=True)=={'f':{'g':{}}})

# Generated at 2022-06-26 02:59:00.748012
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_1 = {
        'a': {
            'one': 1,
            'two': 2,
            'three': 3,
            '*': {
                'four': 4,
            },
            '**': {
                'five': 5,
            },
        },
    }

    res = get_tree_node(tree_1, 'a:one')
    assert res == 1

    res = get_tree_node(tree_1, 'a:three')
    assert res == 3

    res = get_tree_node(tree_1, 'a:*')
    assert res == {
        'four': 4,
    }

    res = get_tree_node(tree_1, 'a:**')
    assert res == {
        'five': 5,
    }

    res = get_tree_

# Generated at 2022-06-26 02:59:08.844527
# Unit test for function set_tree_node
def test_set_tree_node():
    testing_dict = {
        'a': {
            'b': {
                'c': 'd',
            }
        }
    }

    set_tree_node(testing_dict, 'b:c', 'd') # Success
    try:
        set_tree_node(testing_dict, 'c:d', 'e') # Failure
    except KeyError:
        assert True
    else:
        assert False

    testing_dict_2 = {
        'a:b:c': 'd',
    }

    set_tree_node(testing_dict_2, 'a:b:c', 'e') # Success
    try:
        set_tree_node(testing_dict_2, 'c:d', 'e') # Failure
    except KeyError:
        assert True
    else:
        assert False

   

# Generated at 2022-06-26 02:59:18.832199
# Unit test for function get_tree_node
def test_get_tree_node():
    A_list = [1, 2, 3]
    A_tuple = (1, 2, 3)
    A_dict = {1: 'a', 2: 'b', 3: 'c'}
    A_set = set(A_list)
    B_list = [4, 5, 6]
    B_tuple = (4, 5, 6)
    B_dict = {4: 'd', 5: 'e', 6: 'f'}
    B_set = set(B_list)
    C_list = [7, 8, 9]
    C_tuple = (7, 8, 9)
    C_dict = {7: 'g', 8: 'h', 9: 'i'}
    C_set = set(C_list)
    D_list = [10, 11, 12]
