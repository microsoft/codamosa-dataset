

# Generated at 2022-06-26 02:49:26.709599
# Unit test for function get_tree_node
def test_get_tree_node():
    storage = {'a': {'b': {'c': '1'}}}
    assert get_tree_node(storage, 'a:b:c') == '1'
    assert get_tree_node(storage, 'a:b:c:d') == _sentinel
    assert get_tree_node(storage, 'a:b:c:d', default='1') == '1'
    try:
        get_tree_node(storage, 'a:b:c:d')
    except KeyError:
        assert True
    else:
        assert False



# Generated at 2022-06-26 02:49:28.152100
# Unit test for function get_tree_node
def test_get_tree_node():
    # Case 0
    test_case_0()



# Generated at 2022-06-26 02:49:36.634058
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()

    test_set_tree_node_key_0 = '~{S-m|Z_b!7\\5'
    test_set_tree_node_value_0 = ' !`\x12\x1cGxu\x1c\x07'

    set_tree_node(test_tree, test_set_tree_node_key_0, test_set_tree_node_value_0)

# Generated at 2022-06-26 02:49:48.322208
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping_0 = tree()
    get_tree_node(mapping_0, '\x12\x1a\x13\x10L\x1b\x0f', False, False)
    get_tree_node(mapping_0, '\x1a\t\x10\x02\x19\x0f\x0e\x08\x1b', True, False)
    get_tree_node(mapping_0, '\x12\x1a\x13\x10L\x1b\x0f', False, True)
    get_tree_node(mapping_0, '\x1a\t\x10\x02\x19\x0f\x0e\x08\x1b', True, True)


# Generated at 2022-06-26 02:49:56.167717
# Unit test for function get_tree_node
def test_get_tree_node():
    #assert str(get_tree_node(0, 0, 0)) == "AssertionError: 0 is not a Mapping"
    assert get_tree_node({}, 0, 0) == 0
    assert get_tree_node({"key 0":{}}, "key 0:0", 0) == 0
    assert get_tree_node({"key 0":{"key 1":{}}}, "key 0:key 1", 0) == {"key 1": {}}
    assert get_tree_node({"key 0":{"key 1":{}}}, "key 0:key 1", 0, True) == {"key 0": {"key 1": {}}}


# Generated at 2022-06-26 02:50:07.754931
# Unit test for function get_tree_node
def test_get_tree_node():
    str_0 = 'Y' + 'a'
    str_1 = '\x7f' + '\x80\x81'
    str_2 = '\x7f\x7f' + '\x80\x81'
    obj_0 = {str_0: str_1, 'k': str_2}
    int_0 = get_tree_node(obj_0, 'Ya', _sentinel, True)
    int_1 = get_tree_node(obj_0, 'k:')
    int_2 = get_tree_node(obj_0, 'k', default=_sentinel)
    int_3 = get_tree_node(obj_0, 'k')

# Generated at 2022-06-26 02:50:10.952295
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'tree.list:[0].list:[0]') == {}
    assert get_tree_node(tree(), 'tree.list:[0].list:[0]', default=None) is None


# Generated at 2022-06-26 02:50:16.465952
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test exception raising
    pytest.raises(TypeError, set_tree_node, {}, ':', None)
    # Test non-edge case
    mapping_0 = {'': 0}
    mapping_0 = set_tree_node(mapping_0, ':', 0)
    assert mapping_0 == {'': 0}


# Generated at 2022-06-26 02:50:17.026302
# Unit test for function set_tree_node
def test_set_tree_node():
    assert False, 'Not Implemented'


# Generated at 2022-06-26 02:50:27.479936
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test for set_tree_node
    """
    # Test assignment to a dictionary with one key
    set_tree_node(globals(), 'string_0', 'Hello world!')

    # Test assignment to a nested dictionary using ':' notation
    set_tree_node(globals(), 'tree_0:dict_0', 'bar')

    # Test assignment to a nested dictionary using ':' notation
    set_tree_node(globals(), 'tree_0:key_0:dict_0', 'baz')

    # Test raising KeyError with default of _sentinel
    try:
        set_tree_node(globals(), 'tree_0:key_1:dict_0', 'baz')
    except KeyError:
        pass

    # Test assignment to a nested dictionary using ':' notation
    set_tree

# Generated at 2022-06-26 02:50:40.089463
# Unit test for function set_tree_node
def test_set_tree_node():
    # Setup
    mapping_0 = {'\x19\x1e\x14Y\x06\x0e)ZKy': '\x19\x1e\x14Y\x06\x0e)ZKy', '*\x0c\x16\x12\x14\x07>\x14N': '*\x0c\x16\x12\x14\x07>\x14N'}

# Generated at 2022-06-26 02:50:50.821095
# Unit test for function set_tree_node
def test_set_tree_node():
    mock_mapping_0 = tree()
    assert set_tree_node(mock_mapping_0, 'foo', 'bar') == {'foo': 'bar'}
    assert set_tree_node(mock_mapping_0, 'foo:bar', 'baz') == {'foo': {'bar': 'baz'}}
    assert set_tree_node(mock_mapping_0, 'foo:bar:baz', 'quux') == {'foo': {'bar': {'baz': 'quux'}}}


# Generated at 2022-06-26 02:50:54.248294
# Unit test for function get_tree_node
def test_get_tree_node():

    assert(get_tree_node({'a': {'b': {'c': 42}}}, 'a:b:c') == 42)

    # TODO: verify exceptions
    # assert(get_tree_node({'a': {'b': {'c': 42}}}, 'a:b:d') == KeyError)



# Generated at 2022-06-26 02:51:02.628108
# Unit test for function get_tree_node
def test_get_tree_node():
    with pytest.raises(KeyError):
        get_tree_node(str, 'yud\x0bj|2<6b', _sentinel)

    str_2 = 'yud\x0bj|2<6b'
    str_3 = str_2.title()
    str_4 = ':\x0b\x0b'
    str_5 = str_0.split(',')
    registry_tree_1 = tree()

test_get_tree_node()

# Generated at 2022-06-26 02:51:03.809606
# Unit test for function get_tree_node
def test_get_tree_node():
    test_case_0()


# Generated at 2022-06-26 02:51:06.659731
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(
        mapping={'a': {'b': {'c': 'd'}}},
        key='a:b:c',
    ) is 'd'


# Generated at 2022-06-26 02:51:11.423051
# Unit test for function set_tree_node
def test_set_tree_node():
    str_0 = 'z3q@pj\x0bt'
    tree_0 = Tree()
    tree_0.set_tree_node(str_0, '2\x0b', '')
    assert str_0 == 'z3q@pj\x0bt'


# Generated at 2022-06-26 02:51:14.689049
# Unit test for function set_tree_node
def test_set_tree_node():
    # TODO: Test set_tree_node for edge cases
    assert True, "TODO: Test set_tree_node for edge cases"



# Generated at 2022-06-26 02:51:25.191195
# Unit test for function get_tree_node
def test_get_tree_node():
    str_0 = '\x7f\x11\x15'
    str_1 = u'\u00c9\x1d<'
    str_3 = '\x00\x0f'
    str_4 = 'm\x0c\x11I'
    str_5 = '\x15@\x02'
    str_6 = '\x1aI\x1b'
    str_7 = 'c\x01\x0b'
    str_8 = '\x00\x1a\x1a'
    registry_tree_0 = RegistryTree(str_0)
    registry_tree_0.register = True

# Generated at 2022-06-26 02:51:34.896239
# Unit test for function set_tree_node
def test_set_tree_node():

    # Unit test for function set_tree_node
    registry_tree_0 = RegistryTree('yud\x0bj|2<6b:Iy!6')
    registry_tree_0.update('yud\x0bj|2<6b:Iy!6')
    registry_tree_0('yud\x0bj|2<6b:Iy!6')
    registry_tree_0.get('yud\x0bj|2<6b:Iy!6')
    registry_tree_0.register('yud\x0bj|2<6b:Iy!6')
    str_0 = 'yud\x0bj|2<6b:Iy!6'
    registry_tree_1 = RegistryTree(str_0)

# Generated at 2022-06-26 02:51:42.506312
# Unit test for function get_tree_node
def test_get_tree_node():
    arg_0 = 'ZGQ8W4=:GJ?Y\n'
    arg_1 = 'J5F5+'
    arg_2 = None
    arg_3 = True
    registry_tree_0 = RegistryTree(arg_2)
    arg_2 = registry_tree_0.get(arg_0, arg_1, arg_3)
    assert arg_2 == None


# Generated at 2022-06-26 02:51:46.614406
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        'a': {
            'b': [
                {
                    'c': 'd',
                    'e': 'f'
                }, {
                    'c': 'g',
                    'e': 'h'
                }
            ]
        }
    }
    assert set_tree_node(mapping, 'a:b:1:e', 'i') == {'c': 'g', 'e': 'i'}
    assert set_tree_node(mapping, 'a:b:3', 'j') == 'j'
    assert set_tree_node(mapping, 'a:b:0:i', 'j') == 'j'



# Generated at 2022-06-26 02:51:54.817468
# Unit test for function get_tree_node
def test_get_tree_node():
    l_str_0 = "yud\x0bj|2<6b:Iy!6"
    l_registrytree_0 = RegistryTree(l_str_0)
    l_registrytree_0.update({"3,\x1f": 2, '49\x0c!P/': 3, '-\x1a\x1b,;': 17})
    assert get_tree_node(l_registrytree_0, "3,\x1f") == 2
    assert get_tree_node(l_registrytree_0, "49\x0c!P/") == 3
    assert get_tree_node(l_registrytree_0, "-\x1a\x1b,;") == 17


# Generated at 2022-06-26 02:52:06.632751
# Unit test for function get_tree_node
def test_get_tree_node():
    str_1 = 'yud\x0bj|2<6b:Iy!6:'
    int_2 = get_tree_node(str_1, 'yud\x0bj|2<6b:Iy!6:', 1, True)
    assert int_2 == 0, 'AssertionError: 10 != 0'
    int_3 = get_tree_node({'yud\x0bj|2<6b:Iy!6:': 1, ':': {'yud\x0bj|2<6b:Iy!6:': 1}}, 'yud\x0bj|2<6b:Iy!6:', 1, True)
    assert int_3 == 1, 'AssertionError: 10 != 1'

# Generated at 2022-06-26 02:52:08.146749
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 1}}, 'a:b') == 1
    assert get_tree_node({'a': {'b': 1}}, 'a:b:c', default=2) == 2


# Generated at 2022-06-26 02:52:13.292625
# Unit test for function get_tree_node
def test_get_tree_node():
    registry_tree_0 = RegistryTree(initial_is_ref=False)
    registry_tree_0.__setitem__('Z:A', 'aa', namespace=None)

# Generated at 2022-06-26 02:52:22.312997
# Unit test for function set_tree_node
def test_set_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a') == {'b': {'c': 'd'}}
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b') == {'c': 'd'}
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node(tree(), 'a:b:c') == tree()
    assert get_tree_node(tree(), 'a:b:c', default=None) is None
    assert get_tree_node(tree(), 'a:b:c', default='d') == 'd'
    # Test .get(key, default)
   

# Generated at 2022-06-26 02:52:32.474321
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'key': 'value'}
    assert get_tree_node(mapping, 'key') == 'value'
    assert get_tree_node(mapping, 'key_not_found', default='default') == 'default'
    mapping = {'key0': {'key1': {'key2': 'value'}}}
    assert get_tree_node(mapping, 'key0') == {'key1': {'key2': 'value'}}
    assert get_tree_node(mapping, 'key0:key1:key2') == 'value'
    mapping = {'key0': 0, 'key1': 1, 'key2': 2}
    assert get_tree_node(mapping, 'key0:key1:key2') == 2


# Generated at 2022-06-26 02:52:40.202164
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping_0 = collections.defaultdict(tree)

    # SFTT 0:

# Generated at 2022-06-26 02:52:49.942662
# Unit test for function get_tree_node
def test_get_tree_node():
    str_0 = '\x7f\x17\t\x18H\x04aMe(v`\x13\x7f\n'
    key_0 = '\x7f\x17\t\x18H\x04aMe(v`\x13\x7f\n'
    dict_0 = {key_0: str_0}
    # Return value should be a list
    value_0 = get_tree_node(dict_0, key_0)
    assert isinstance(value_0, list)

    # Return value should be a dict
    value_1 = get_tree_node(dict_0, key_0)
    assert isinstance(value_1, dict)

    # Return value should be a object

# Generated at 2022-06-26 02:53:00.464402
# Unit test for function get_tree_node
def test_get_tree_node():
    str_0 = 'wg'
    str_1 = 'wr'
    dict_0 = { str_0: dict_0, str_1: dict_0 }
    dict_1 = { str_0: dict_0 }
    dict_2 = { str_1: dict_0 }
    result = get_tree_node(dict_0, 'wr', default=None, parent=True)
    assert result == dict_2
    result = get_tree_node(dict_1, 'wg', default=None, parent=False)
    assert result == dict_0


# Generated at 2022-06-26 02:53:08.823008
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test case with : as the key to retrieve
    str_0 = 'yud\x0bj|2<6b:Iy!6'
    registry_tree_0 = RegistryTree(str_0)

    # Retrieve yud
    yud = get_tree_node(registry_tree_0, 'yud')
    assert yud == '\x0b'

    # Retrieve j
    j = get_tree_node(registry_tree_0, 'j')
    assert j == J_STRING

    # Retrieve 6b
    b = get_tree_node(registry_tree_0, '6b')
    assert b == 'I'

    # Retrieve y
    y = get_tree_node(registry_tree_0, 'y')
    assert y == '!'

    # Test

# Generated at 2022-06-26 02:53:10.227974
# Unit test for function set_tree_node
def test_set_tree_node():
    assert False


# Generated at 2022-06-26 02:53:20.637323
# Unit test for function get_tree_node
def test_get_tree_node():
    # First set of arguments to test_get_tree_node
    str_1 = '8\x0b]\t\x0bI>\t8'
    str_2 = '%'
    dict_3 = {}
    dict_3 = {'ms': '1', 's': '2', 'm': '4', 'h': '5'}
    dict_4 = {'ms': '1', 's': '2', 'm': '4', 'h': '5'}
    dict_4['s'] = '7'
    dict_4['m'] = '9'
    dict_4['ms'] = '3'
    dict_4['h'] = '8'
    dict_5 = {}

# Generated at 2022-06-26 02:53:28.384958
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'two:three', '4') == {'two': {'three': '4'}}
    assert set_tree_node({'one': {'two': '3'}}, 'one:three', '4') == {'one': {'two': '3', 'three': '4'}}

if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-26 02:53:37.828317
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:53:45.687379
# Unit test for function set_tree_node
def test_set_tree_node():
    # {0:0} -> 1
    test_case_1()

    # {0:{0:2}} -> 3
    test_case_2()

    # {0:{0:[2}}} -> 3
    test_case_3()

    # {0:{0:{2}}} -> 3
    test_case_4()



# Generated at 2022-06-26 02:53:52.240802
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping_0 = {}
    str_0 = 'uO#W;V>|v1hX9'
    str_1 = '0Y2T_'
    # Call set_tree_node with arguments mapping_0, str_0, str_1

# Generated at 2022-06-26 02:54:02.396235
# Unit test for function set_tree_node
def test_set_tree_node():
    str0 = 'yud\x0bj|2<6b:Iy!6'
    str1 = '2<6b:Iy!6'
    str2 = 'yud'
    str3 = 'yud\x0bj|'
    str4 = 'yud\x0bj|2<6b:Iy!6'
    str5 = '\x0bj|'
    str6 = '2<6b'
    str7 = '\x0bj|2<6b:Iy!6'
    str8 = 'yud\x0bj|2<6b'
    str9 = ':Iy!6'
    str10 = '\x0bj|2<6b:Iy!6'
    str11 = '2<6b'

# Generated at 2022-06-26 02:54:12.909728
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 3 == get_tree_node({'a': {'b': {'c': 3}}}, 'a:b:c')
    assert [3] == get_tree_node({'a': {'b': {'c': 3}}}, 'a:b:c', default=_sentinel)
    assert {'c': [3]} == get_tree_node({'a': {'b': {'c': 3}}}, 'a:b', parent=True)
    assert {'b': {'c': [3]}} == get_tree_node({'a': {'b': {'c': 3}}}, 'a', parent=True)
    assert None is get_tree_node({'a': {'b': {'c': 3}}}, 'a:b:c:d', default=None)
    assert None is get_

# Generated at 2022-06-26 02:54:31.506089
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'a:b:c') == _sentinel
    try:
        get_tree_node({}, 'a:b:c', _sentinel)
    except KeyError:
        pass
    else:
        assert False, "Failed to raise KeyError"
    assert get_tree_node({'a': {'b': {'c': 3}}}, 'a:b:c') == 3
    assert get_tree_node({'a': {'b': {'c': 3}}}, 'a:b:c') == 3
    assert get_tree_node({'a': {'b': {'c': 3}}}, 'a:b:c') == 3



# Generated at 2022-06-26 02:54:34.330023
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    tree_0.__setitem__(tree_0)


# Generated at 2022-06-26 02:54:39.286870
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = Tree()
    var_1.__setitem__(var_1, 'a:b:c:d', 'value')
    var_2 = var_1.__getitem__(var_1, 'a:b:c:d')
    assert var_2 == 'value'


# Generated at 2022-06-26 02:54:41.113576
# Unit test for function get_tree_node
def test_get_tree_node():

    print(get_tree_node(tree_0, tree_0))

# Generated at 2022-06-26 02:54:44.343158
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    get_tree_node(tree_0, tree_0)


# Generated at 2022-06-26 02:54:55.747853
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {}
    tree_0['b'] = {}
    tree_0['b']['e'] = {}
    tree_0['b']['e']['f'] = {}
    tree_0['b']['e']['f']['g'] = {}
    tree_0['b']['e']['f']['g']['h'] = {}
    tree_0['b']['e']['f']['g']['h']['i'] = {}
    tree_0['b']['e']['f']['g']['h']['i']['j'] = {}
    tree_0['b']['e']['f']['g']['h']['i']['j']['k'] = {}


# Generated at 2022-06-26 02:54:58.389940
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    # Test for bad type for 'value' (string expected)
    pass


# Generated at 2022-06-26 02:55:00.184558
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(mapping, key, default=_sentinel, parent=False) == tree_1


# Generated at 2022-06-26 02:55:12.816439
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = tree()
    set_tree_node(tree, 'hello', 'world')
    set_tree_node(tree, 'lol', 'rofl')
    set_tree_node(tree, 'lol.rofl', 'lmao')
    set_tree_node(tree, 'lol::rofl', 'lmao')
    set_tree_node(tree, 'lol:rofl', 'lmao')
    set_tree_node(tree, 'lol:rofl:lmao', 'bbq')
    assert tree['hello'] == 'world'
    assert tree['lol']['rofl'] == 'lmao'
    assert tree['lol:rofl'] == 'lmao'
    assert tree['lol::rofl'] == 'lmao'

# Generated at 2022-06-26 02:55:15.249816
# Unit test for function set_tree_node
def test_set_tree_node():
    # I don't know what to put here.
    pass


# Generated at 2022-06-26 02:55:43.853312
# Unit test for function set_tree_node
def test_set_tree_node():
    x = {'a': {'b': {'c': 42}} }
    assert set_tree_node(x, 'a:b:c', 'yolo') == {'a': {'b': {'c': 'yolo'} }}
    x = {'a': {'b': {'c': 42}} }
    assert set_tree_node(x, 'a:b:d', 'yolo') == {'a': {'b': {'c': 42, 'd': 'yolo'} }}
    x = {'a': {'b': {'c': 42}} }
    assert set_tree_node(x, 'a:b:d:e', 'yolo') == {'a': {'b': {'c': 42, 'd': {'e': 'yolo'} } } }
   

# Generated at 2022-06-26 02:55:52.672212
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test Imports
    from collections import OrderedDict

    # Test Setup
    tree = tree()
    tree.update({
        'a': 1,
        'b': {
            'c': 2,
            'd': {
                'e': 3
            },
        },
    })

    # Test Cases
    get_tree_node(tree, ':b')
    get_tree_node(tree, 'b:')
    get_tree_node(tree, 'b:d:')
    get_tree_node(tree, 'b:d:e')
    get_tree_node(tree, 'd:e', parent=True)
    get_tree_node(tree, 'd:e:f')



# Generated at 2022-06-26 02:55:56.682412
# Unit test for function get_tree_node
def test_get_tree_node():
    mock = {'1': {'2': {'3': 'test'}}}
    assert get_tree_node(mock, '1:2:3') == 'test'



# Generated at 2022-06-26 02:56:00.831921
# Unit test for function get_tree_node
def test_get_tree_node():
    reg = RegistryTree()
    reg.register('foo', 'bar')
    reg.register('foobar', 'baz')
    reg.register('foo:bar', 'baz')

    assert reg.__getitem__('foo:bar', namespace='foo') == 'baz'

# Generated at 2022-06-26 02:56:12.248930
# Unit test for function set_tree_node
def test_set_tree_node():
    print("Testing set_tree_node")

    # Setup a mock tree
    tree_0 = Tree()
    tree_0.__setitem__('set', 'get', 'get')
    mock_tree = tree_0
    mock_key = 'nodeset'
    mock_value = 'set'
    mock_parent_node = mock_tree
    mock_namespace = 'set'

    # Call function under test
    result = set_tree_node(mock_tree, mock_key, mock_value, mock_parent_node, mock_namespace)

    # Perform assertions
    assert mock_tree is result
    assert mock_parent_node is result
    assert mock_tree['nodeset'] == 'set'



# Generated at 2022-06-26 02:56:20.070391
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(test_dict, 'a:b:c') == 'd'
    test_dict = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(test_dict, 'a:b:c:d') == _sentinel



# Generated at 2022-06-26 02:56:25.602537
# Unit test for function get_tree_node
def test_get_tree_node():
    assert isinstance(get_tree_node(mapping = None, key = '', default = _sentinel, parent = False), object)
    assert isinstance(get_tree_node(mapping = None, key = '', default = _sentinel, parent = True), object)


# Generated at 2022-06-26 02:56:30.459633
# Unit test for function set_tree_node
def test_set_tree_node():
    if tree_0:
        tree_0 = tree.__init__()
    var_0 = set_tree_node(tree_0, 'key_0', 'value_0')
    var_1 = set_tree_node(tree_0, 'key_1', 'value_1')



# Generated at 2022-06-26 02:56:39.676607
# Unit test for function get_tree_node
def test_get_tree_node():
    TREE_NODE_0 = RegistryTree()
    GET_TREE_NODE_0 = TREE_NODE_0.__getitem__(TREE_NODE_0)
    TREE_NODE_0.register(TREE_NODE_0, GET_TREE_NODE_0)
    GET_TREE_NODE_1 = TREE_NODE_0.get('TREE_NODE_1')


# Generated at 2022-06-26 02:56:42.843357
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 1}}, 'foo:bar') == 1



# Generated at 2022-06-26 02:57:34.474822
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        "a": 10,
        "b": 20,
        "c": {
            "d": 30,
            "e": 40
        }
    }
    print(get_tree_node(test_dict, "a"))
    print(get_tree_node(test_dict, "c"))
    print(get_tree_node(test_dict, "c:d"))

# Generated at 2022-06-26 02:57:37.839381
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(tree(), 'foo', 'bar') == tree()


# Generated at 2022-06-26 02:57:42.786714
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(None, None) is None
    assert get_tree_node(None, None, None) is None
    assert get_tree_node(None, None, None, None) is None



# Generated at 2022-06-26 02:57:44.822559
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree({'hello': {'world': '!'}})
    var_0 = tree_0.__setitem__('hello:world', '!')


# Generated at 2022-06-26 02:57:56.786827
# Unit test for function get_tree_node
def test_get_tree_node():

    # Case 0
    m = {'c': {'d': {'f': 'g'}}, 'a': {'b': 1}}
    k = 'a:b'
    d = _sentinel
    p = False
    n = get_tree_node(m, k, d, p)
    assert n == 1

    # Case 1
    m = {'a': {'b': 1}}
    k = 'a:b'
    d = _sentinel
    p = False
    n = get_tree_node(m, k, d, p)
    assert n == 1

    # Case 2
    m = {'c': {'d': {'f': 'g'}}, 'a': {'b': 1}}
    k = 'a:c'
    d = _sentinel
    p = False

# Generated at 2022-06-26 02:58:00.975348
# Unit test for function set_tree_node
def test_set_tree_node():
    print(set_tree_node(None, None, None))
    print(set_tree_node(None, None, None))
    print(set_tree_node(None, None, None))


# Generated at 2022-06-26 02:58:04.708267
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    # Returns: object: Value at specified key
    var_0 = tree_0.get(tree_0)



# Generated at 2022-06-26 02:58:17.412562
# Unit test for function get_tree_node
def test_get_tree_node():
    key = None
    mapping = {"key": "value"}
    #Test list
    # get_tree_node(mapping,key)
    assert mapping[key] == "value"
    key = "key"
    # get_tree_node(mapping,key)
    assert mapping[key] == "value"
    key = "key:"
    # get_tree_node(mapping,key)
    assert mapping[key] == "value"
    key = "key:key"
    # get_tree_node(mapping,key)
    assert mapping[key] == "value"
    key = "key:key:key"
    # get_tree_node(mapping,key)
    assert mapping[key] == "value"
    key = "key:key:key:key"
    # get_tree_node

# Generated at 2022-06-26 02:58:20.902186
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    var_0 = tree_0.get_tree_node({':': ''})


# Generated at 2022-06-26 02:58:25.673764
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert get_tree_node(test_data, 'foo:bar:baz') == 'qux'

