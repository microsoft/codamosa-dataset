

# Generated at 2022-06-26 02:49:20.690459
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree()
    tree.set_tree_node('foo', 'bar')
    assert tree['foo'] == 'bar'



# Generated at 2022-06-26 02:49:24.082384
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_1 = Tree({'a': 'a'})
    assert tree_1.get('a') == 'a'


test_get_tree_node()

test_case_0()

# Generated at 2022-06-26 02:49:25.725423
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test case 0
    print('Test case 0')
    pass

# Generated at 2022-06-26 02:49:29.277794
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {
        'a': 1,
        'b': {
            'c': 2
        }
    }

    assert get_tree_node(t, 'a') == 1
    assert get_tree_node(t, 'b:c') == 2


# Generated at 2022-06-26 02:49:35.569291
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = {
        'a': {
            'b': {
                'c': 1,
                'd': 2,
            },
            'e': 3
        },
        'f': 4
    }

    assert get_tree_node(tree_0, 'a:b:c') == 1
    assert get_tree_node(tree_0, 'a:b:d') == 2
    assert get_tree_node(tree_0, 'a:e') == 3
    assert get_tree_node(tree_0, 'f') == 4


# Generated at 2022-06-26 02:49:39.273755
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree(
        {
            'one': {
                'two': {
                    'three': {
                        'four': 'Fred'
                    },
                    'fiver': {
                        'sixer': 'Bob'
                    },
                }
            }
        },
    )

    import pytest
    with pytest.raises(KeyError):
        get_tree_node(tree_0, 'one:two:three:four:five')

# Generated at 2022-06-26 02:49:48.635497
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()

    ## Below is a sample test case:
    ## key = 'foo'
    ## tree_0['foo'] = 'bar'
    ## assert get_tree_node(tree_0, key) is 'foo'

    # Write your own test case here
    assert get_tree_node(tree_0, 'foo') is _sentinel
    assert get_tree_node(tree_0, 'foo', 'bar') is 'bar'
    tree_0['foo'] = 'bar'
    assert get_tree_node(tree_0, 'foo') is 'bar'
    tree_0['foo:bar'] = 'foo'
    assert get_tree_node(tree_0, 'foo:bar') is 'foo'
    tree_0['foo:bar:baz'] = 'bar'
    assert get

# Generated at 2022-06-26 02:49:57.400402
# Unit test for function set_tree_node
def test_set_tree_node():
    t = {}
    data = {
        'foo': 'bar',
        'fizz': {
            'buzz': ['buzz', 'fizz']
        },
        'qwerty': {
            'bar': {
                'foo': 'baz'
            }
        }
    }

    for key, value in data.iteritems():
        set_tree_node(t, key, value)

    assert t == {
        'foo': 'bar',
        'fizz': {
            'buzz': ['buzz', 'fizz']
        },
        'qwerty': {
            'bar': {
                'foo': 'baz'
            }
        }
    }

# Generated at 2022-06-26 02:50:08.539214
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test case 1
    tree_1 = Tree()
    tree_1['a:b:c'] = 'D'
    tree_1['a:F'] = 'G'
    tree_1['H'] = 'I'
    assert tree_1['a:b:c'] == 'D'
    assert tree_1['a:F'] == 'G'
    assert tree_1['H'] == 'I'

    # Test case 2
    tree_2 = Tree()
    tree_2['a:b:c'] = 'D'
    tree_2['a:b:E'] = 'F'
    try:
        tree_2['a:b:c:f'] 
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-26 02:50:18.659600
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 1}, 'c': 2}, ':a:b', default='c') == 1
    assert get_tree_node({'a': {'b': 1}, 'c': 2}, ':a:b:c')[1] == 2
    assert get_tree_node({'a': {'b': 1}, 'c': 2}, ':a:c') == 2
    assert get_tree_node({'a': {'b': 1}, 'c': 2}, ':a:b:c', default='d') == 'd'
    assert get_tree_node({'a': {'b': 1}, 'c': 2}, ':a:b:c', default='d') == 'd'


# Generated at 2022-06-26 02:50:26.643988
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = Tree()
    tree_0.set_tree_node(tree_0.data, 'pt.mc', 'a')
    assert tree_0.get('pt.mc') == 'a'



# Generated at 2022-06-26 02:50:31.296164
# Unit test for function set_tree_node
def test_set_tree_node():
    import copy

    tree_0 = {
        'path': {
            'to': {
                'node': 'value'
            }
        }
    }

    tree_0_copy = copy.deepcopy(tree_0)

    set_tree_node(tree_0_copy, 'path:to:node', 'foobar')

    assert tree_0_copy['path']['to']['node'] == 'foobar'



# Generated at 2022-06-26 02:50:36.002806
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'k1:k2:k3', 'v3')
    assert d['k1']['k2']['k3'] == 'v3'


# Generated at 2022-06-26 02:50:42.640466
# Unit test for function set_tree_node
def test_set_tree_node():
    "__set_tree_node__"
    MAPPING = tree()

    def _test_set_tree_node(key, value, expected_key, expected_value, expected_mapping=None):
        if not expected_mapping:
            expected_mapping = MAPPING

        set_tree_node(MAPPING, key, value)
        print(MAPPING[expected_key])
        assert MAPPING[expected_key] == expected_value

    _test_set_tree_node('a', 1, 'a', 1)
    _test_set_tree_node(':a', 1, 'a', 1)
    _test_set_tree_node('a:a', 1, 'a', 1)

# Generated at 2022-06-26 02:50:53.402522
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(dict(a=1, b='c', d=dict(e=3)), 'b') == 'c'
    assert get_tree_node(dict(a=1, b='c', d=dict(e=3)), 'a') == 1
    assert get_tree_node(dict(a=1, b='c', d=dict(e=3)), 'd:e') == 3
    assert get_tree_node(dict(a=1, b='c', d=dict(e=3)), 'd:e', parent=True) == dict(e=3)
    assert get_tree_node(dict(a=1, b='c', d=dict(e=3)), 'd') == dict(e=3)

# Generated at 2022-06-26 02:51:05.578378
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree_0, 'a:b:c:d:e:f:g', default='Testing') == 'Testing'
    assert get_tree_node(tree_0, 'a:b:c:d:e:f:g', default='Testing', parent=True) == 'Testing'
    tree_0['a:b:c:d:e:f:g'] = 'Test'
    assert get_tree_node(tree_0, 'a:b:c:d:e:f:g', default='Testing') == 'Test'
    assert get_tree_node(tree_0, 'a:b:c:d:e:f:g', default='Testing', parent=True) == 'Test'
    del tree_0['a:b:c:d:e:f:g']

#

# Generated at 2022-06-26 02:51:12.032865
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test 1
    # Check that function returns None if key is not in mapping
    test_mapping = {'test': {'test': '123'}}
    assert get_tree_node(test_mapping, 'test1', None) == None

    # Test 2
    # Check that key is found when key is in mapping
    assert get_tree_node(test_mapping, 'test') == {'test': '123'}


# Generated at 2022-06-26 02:51:21.260308
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_0 = tree()
    set_tree_node(tree_0, 'color:blue', True)
    set_tree_node(tree_0, 'color:black', True)
    set_tree_node(tree_0, 'color:red:hex', '#FF0000')
    set_tree_node(tree_0, 'color:red:rgb', '255,0,0')

    assert get_tree_node(tree_0, 'color:blue') is True
    assert get_tree_node(tree_0, 'color:blue:hex') is _sentinel


# Generated at 2022-06-26 02:51:29.420580
# Unit test for function get_tree_node
def test_get_tree_node():
    # 1st Test case for get_tree_node
    tree_1 = Tree()
    tree_1['gdfgsfgs'] = 1
    assert tree_1['gdfgsfgs'] == 1
    assert tree_1['fdsgsdgs'] == None
    tree_1['fsdfgsdgs:gsdgsdgs'] = 2
    assert tree_1['fsdfgsdgs:gsdgsdgs'] == 2
    tree_1['fdsfgsdgs:gsdgsdgs:gsdgsdgs'] = 3
    assert tree_1['fdsfgsdgs:gsdgsdgs:gsdgsdgs'] == 3
    tree_1['fdsfgsdgs:gsdgsdgs:gsdgsdgs:fdsgdsfgdf'] = 4
    assert tree_

# Generated at 2022-06-26 02:51:35.505815
# Unit test for function set_tree_node
def test_set_tree_node():
    test_cases = (
        (tree(), 'key', 'value', {'key': 'value'}),
        (tree(), 'key:value', 'value', {'key': {'value': 'value'}}),
    )
    for c, i, r, e in test_cases:
        set_tree_node(c, i, r)
        assert c == e



# Generated at 2022-06-26 02:51:43.966241
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {
        'a': {
            'b': 'c'
        }
    }
    print(set_tree_node(tree, 'x:y:z', 'w'))
    print(tree)
    print(set_tree_node(tree, 'a:x', 'y'))
    print(tree)


# Generated at 2022-06-26 02:51:47.700570
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'root': {'child': {'leaf': 'value'}}}
    assert get_tree_node(d, 'root:child')['leaf'] == 'value'
    assert get_tree_node(d, 'root:child:leaf') == 'value'


# Generated at 2022-06-26 02:51:55.721110
# Unit test for function get_tree_node
def test_get_tree_node():
    # test with no : in key
    test_mapping = {'test_key': 'test_value'}
    assert get_tree_node(test_mapping, 'test_key') == 'test_value'

    # test with : in key
    test_mapping = {'test_key': {'sub_key': 'test_value'}}
    assert get_tree_node(test_mapping, 'test_key:sub_key') == 'test_value'

    # test parent node
    test_mapping = {'test_key': {'sub_key': 'test_value'}}
    assert get_tree_node(test_mapping, 'test_key:sub_key', parent=True) == {'sub_key': 'test_value'}

    # test with no node found
    test_mapping

# Generated at 2022-06-26 02:52:00.786891
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = {'a':{'b': 1}}
    set_tree_node(test_tree, 'a:b:c:d:e:f:g', 1)
    assert test_tree['a']['b']['c']['d']['e']['f']['g'] == 1


# Generated at 2022-06-26 02:52:08.984335
# Unit test for function get_tree_node
def test_get_tree_node():
    """Function get_tree_node"""

    tree_0 = {'a': {'b': {'c': 1, 'd': 2}}}
    assert get_tree_node(tree_0, 'a') == {'b': {'c': 1, 'd': 2}}
    assert get_tree_node(tree_0, 'a:b') == {'c': 1, 'd': 2}
    assert get_tree_node(tree_0, 'a:b:c') == 1
    assert get_tree_node(tree_0, 'a:b:d') == 2



# Generated at 2022-06-26 02:52:14.727813
# Unit test for function set_tree_node
def test_set_tree_node():
    # Create a test tree
    tree = {
        'pb': {
            'salt': {'build': {}},
            'realm': 'dev',
            'environment': 'dev'
        }
    }

    # Add a new key to the tree
    tree = set_tree_node(tree, 'pb:salt:build:foo', 'bar')

    # Assert a value exists
    assert tree.get('pb').get('salt').get('build').get('foo') == 'bar'


# Generated at 2022-06-26 02:52:24.052663
# Unit test for function get_tree_node
def test_get_tree_node():
    # Set up
    mapping = Tree()
    mapping['foo:bar'] = 'bar'
    mapping['foo:baz']['tender'] = 'love'
    # Test
    assert get_tree_node(mapping, 'foo:bar') == 'bar'
    assert get_tree_node(mapping, 'foo:baz:tender') == 'love'  # Nested
    assert get_tree_node(mapping, 'foo:yum', parent=True) == mapping['foo']  # Test parent
    assert get_tree_node(mapping, 'foo:yum') is _sentinel  # Test no default
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'foo:yum')

# Generated at 2022-06-26 02:52:34.527523
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    print("\nTest case 0: tree_0 = Tree()")
    print("tree_0.get('a:b:c', 'za')")
    print("tree_0.get('a:d', 'za')")
    print("tree_0.get('a', 'za')")
    print("tree_0.get('a:b:c:d:e:f:g:h', 'za')")
    print("tree_0.get('a:b:c', 'za':3)")
    print("tree_0.get('a:b:c:d:e:f:g:h', 'za':8)")

# Generated at 2022-06-26 02:52:47.105616
# Unit test for function set_tree_node
def test_set_tree_node():
    a = 1
    b = 5
    c = 7
    e = 8
    tree = {
        'a': a,
        'b': b,
        'c': c,
        'd': {'e': e},
    }
    # Expected:
    # tree = {
    #     'a': 1,
    #     'b': 5,
    #     'c': 7,
    #     'd': {
    #         'e': 8,
    #         'e1': 9,
    #         'e2': 10,
    #     },
    # }
    assert tree['d']['e'] == e
    assert set_tree_node(tree, 'd:e1', 9)['e1'] == 9
    assert tree['d']['e2'] == 10

# Generated at 2022-06-26 02:52:59.290776
# Unit test for function set_tree_node
def test_set_tree_node():
    """Sanity check for set_tree_node.
    """
    tree_0 = Tree()
    ret_0 = set_tree_node(tree_0, 'k1', 'v1')
    ret_1 = set_tree_node(tree_0, 'k2:k3', 'v2')
    ret_2 = set_tree_node(tree_0, 'k4:k5:k6', 'v3')

    assert ret_0 == {'k1': 'v1'}
    assert ret_1 == {'k2': {'k3': 'v2'}}
    assert ret_2 == {'k4': {'k5': {'k6': 'v3'}}}

    assert tree_0['k1'] == 'v1'

# Generated at 2022-06-26 02:53:17.238641
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_1 = Tree()
    tree_1['A'] = 'Apple'
    tree_1['B:C'] = 'Banana'
    tree_1['B:D'] = 'Candy'
    tree_1['E'] = 'Egg'

    assert tree_1['A'] == 'Apple'
    assert tree_1['B'] == {'C': 'Banana', 'D': 'Candy'}
    assert tree_1['E'] == 'Egg'

# Generated at 2022-06-26 02:53:25.502172
# Unit test for function set_tree_node
def test_set_tree_node():
    initial = {
        'a': {
            'b': {
                'c': 'z',
            },
        },
        'd': {
            'e': {
                'f': 'y',
            },
        },
    }
    set_tree_node(initial, 'a:b:c', 'd')
    assert initial['a']['b']['c'] == 'd'
    set_tree_node(initial, 'a:b', 'c')
    assert initial['a']['b'] == 'c'
    set_tree_node(initial, 'a', '.')
    assert initial['a'] == '.'
    set_tree_node(initial, 'a:b:c:d:e:f', 'b')

# Generated at 2022-06-26 02:53:34.339391
# Unit test for function get_tree_node
def test_get_tree_node():
    from collections import defaultdict

# Generated at 2022-06-26 02:53:39.252360
# Unit test for function get_tree_node
def test_get_tree_node():
    config = {'foo': {'bar': {'baz': [1, 2, 3]}}}
    assert get_tree_node(config, 'foo:bar:baz:2') == 3
    assert get_tree_node(config, 'foo:bar:baz:100', default=False) == False
    assert get_tree_node(config, 'foo:bar:baz:100', default=False, parent=True) == {1: 2, 3: 4}


# Generated at 2022-06-26 02:53:50.669933
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = Tree()
    tree_0['one'] = '1'
    assert tree_0['one'] == '1'
    tree_0['one.two'] = '2'
    assert tree_0['one.two'] == '2'
    assert tree_0['one:two'] == '2'
    assert tree_0.get('one:two') == '2'
    tree_0['one.two.three'] = '3'
    assert tree_0.get('one:two:three') == '3'
    assert tree_0.get('one.two.three') == '3'
    assert tree_0.get('one:two.three', 'foo') == '3'
    assert tree_0.get('one.two:three', 'foo') == '3'
    assert tree_0.get

# Generated at 2022-06-26 02:54:01.929730
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_1 = Tree({
        'f': 'r',
        'a': {
            't': 's',
            'b': {
                'r': 'a',
                ':': {
                    't': 's',
                    ' ': {
                        'c': 'a',
                        'R': 'a'
                    }
                }
            }
        }
    })
    assert tree_1.get('f') == 'r'
    assert tree_1.get('a:t') == 's'
    assert tree_1.get('a:b:r') == 'a'
    assert tree_1.get('a:b::t') == 's'
    assert tree_1.get('a:b: :c') == 'a'

# Generated at 2022-06-26 02:54:09.237356
# Unit test for function set_tree_node
def test_set_tree_node():
    t = Tree()
    a = set_tree_node(t, 'a:b:c:d', 1)
    assert get_tree_node(t, 'a:b:c:d') == 1
    assert t == {'a': {'b': {'c': {'d': 1}}}}
    assert a == {'d': 1}



# Generated at 2022-06-26 02:54:14.007728
# Unit test for function get_tree_node
def test_get_tree_node():
    node = get_tree_node({'foo': {'bar': 'jim'}}, 'foo:bar')
    assert node == 'jim'


if __name__ == '__main__':
    pass

# Generated at 2022-06-26 02:54:23.297580
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test 0
    config_0 = Tree()
    key_0 = 'test'
    default_0 = _sentinel
    parent_0 = False
    assert get_tree_node(config_0, key_0, default_0, parent_0) == _sentinel

    # Test 1
    config_1 = {'test': 'value'}
    key_1 = 'test'
    default_1 = _sentinel
    parent_1 = False
    assert get_tree_node(config_1, key_1, default_1, parent_1) == 'value'

    # Test 2
    config_2 = {'test': 'value'}
    key_2 = 'missing'
    default_2 = _sentinel
    parent_2 = False

# Generated at 2022-06-26 02:54:26.611598
# Unit test for function get_tree_node
def test_get_tree_node():
    test_cases = [
    ]
    for test_case in test_cases:
        try:
            result = test_case['result']
            assert result['result'] == get_tree_node(test_case['structure'], test_case['key'])
        except KeyError as exc:
            assert True == False, "KeyError: {0}".format(exc)
        except Exception as exc:
            assert True == False, "Exception: {0}".format(exc)

# Generated at 2022-06-26 02:54:39.059162
# Unit test for function get_tree_node
def test_get_tree_node():
    assert var_0 is not None
    assert callable(var_0)

    var_1 = get_tree_node(var_0, 'key', 'default')


# Generated at 2022-06-26 02:54:40.796676
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(None, None) == None



# Generated at 2022-06-26 02:54:51.808238
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Arguments:
        mapping collections.Mapping: Mapping to fetch from
        key str|unicode: Key to lookup, allowing for : notation
        default object: Default value. If set to `:module:_sentinel`, raise KeyError if not found.
        parent bool: If True, return parent node. Defaults to False.

    Returns:
        object: Value at specified key
    """

    # print('''\n
    #     Arguments:
    #         mapping collections.Mapping: Mapping to fetch from
    #         key str|unicode: Key to lookup, allowing for : notation
    #         default object: Default value. If set to `:module:_sentinel`, raise KeyError if not found.
    #         parent bool: If True, return parent node. Defaults to False.
    #
    #     Returns:

# Generated at 2022-06-26 02:54:59.212393
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': {'d': 0}}}}, 'a:b:c:d') == 0
    assert get_tree_node({'a': {'b': {'c': {'d': 0}}}}, 'a:b:c:d', parent=True) == {'d': 0}



# Generated at 2022-06-26 02:55:10.372101
# Unit test for function get_tree_node
def test_get_tree_node():
    # Tests for get_tree_node function
    var_2 = get_tree_node({}, '')
    assert var_2 is None

    var_3 = get_tree_node({}, '')
    assert var_3 is None

    var_0 = get_tree_node({}, 'a')
    assert var_0 is None

    var_1 = get_tree_node({}, 'q:a:a:a:a:a:a:a:a:a:a:a:a')
    assert var_1 is None


# Generated at 2022-06-26 02:55:12.219404
# Unit test for function get_tree_node
def test_get_tree_node():
    assert callable(get_tree_node)


# Generated at 2022-06-26 02:55:24.046047
# Unit test for function get_tree_node
def test_get_tree_node():
    _kwargs_0 = {'key': 'a:b', 'mapping': {'a': {'b': 'b'}}}
    _fn_0 = get_tree_node(**_kwargs_0)
    assert _fn_0 == 'b'
    _kwargs_1 = {'key': u'a:b', 'mapping': {u'a': {u'b': u'c'}}}
    _fn_1 = get_tree_node(**_kwargs_1)
    assert _fn_1 == u'c'

# Generated at 2022-06-26 02:55:35.240128
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
            'qux': {
                'quux': 'corge'
            }
        }
    }

    # First, test the most basic case.
    assert get_tree_node(mapping, 'foo:bar') == 'baz'

    # Now, test the `default` argument. Also test `parent` flag.
    assert get_tree_node(mapping, 'foo:quux', default=_sentinel, parent=True) is _sentinel
    assert get_tree_node(mapping, 'foo:quux', default='grault', parent=True) == mapping['foo']

    # Test `parent` flag at depth.

# Generated at 2022-06-26 02:55:39.521975
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0=tree()
    set_tree_node(var_0,"a:b:c","triangle")
    assert str(var_0)==str(tree( {"a": tree({"b": tree({"c": "triangle"})})}))


# Generated at 2022-06-26 02:55:42.124401
# Unit test for function get_tree_node
def test_get_tree_node():
    var_a = get_tree_node(var_0, 'a')
    pass


# Generated at 2022-06-26 02:56:08.562986
# Unit test for function set_tree_node
def test_set_tree_node():
    key = tree()
    set_tree_node(key, "jim:jimbo:jimbo:clark", "jimbo")
    assert key == {'jim': {'jimbo': {'jimbo': 'jimbo'}}}



# Generated at 2022-06-26 02:56:14.499167
# Unit test for function set_tree_node
def test_set_tree_node():
    # Tree Structure
    tree = {
        'a': {
            'a': {
                'a': 'a',
                'b': 'b',
            },
            'b': 'c',
        },
        'b': 'd',
    }

    set_tree_node(tree, 'a:a:a', 'a')
    set_tree_node(tree, 'a:a:b', 'b')
    set_tree_node(tree, 'a:b', 'c')
    set_tree_node(tree, 'b', 'd')

    assert tree == {
        'a': {
            'a': {
                'a': 'a',
                'b': 'b',
            },
            'b': 'c',
        },
        'b': 'd',
    }


# Unit

# Generated at 2022-06-26 02:56:21.656711
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    key = 'test'
    default = _sentinel
    parent = False
    assert (get_tree_node(mapping, key, default, parent) == {'key2': {'key3': 'value3'}, 'key1': 'value1'} or
    get_tree_node(mapping, key, default, parent) == {'key1': 'value1', 'key2': {'key3': 'value3'}})


# Generated at 2022-06-26 02:56:32.212858
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {'a': {'b': {'c': 'foo'}}}
    assert 'foo' == get_tree_node(test_mapping, 'a:b:c')
    assert 'foo' == get_tree_node(test_mapping, 'a:b:c', default=None)
    assert test_mapping['a'] == get_tree_node(test_mapping, 'a:b:c', parent=True)
    assert None is get_tree_node(test_mapping, 'a:b:d', default=None)
    try:
        get_tree_node(test_mapping, 'a:b:d')
    except KeyError:
        pass
    else:
        assert False, 'Should have raised KeyError'


# Generated at 2022-06-26 02:56:43.618430
# Unit test for function set_tree_node
def test_set_tree_node():
    # Case 0: Simply set node
    var_0 = tree()
    set_tree_node(var_0, 'foo', 'bar')
    var_0_expected = {'foo': 'bar'}
    assert var_0 == var_0_expected

    # Case 1: Delve  into the tree
    var_1 = tree()
    set_tree_node(var_1, 'foo:bar', 'baz')
    var_1_expected = {
        'foo': {
            'bar': 'baz',
        }
    }
    assert var_1 == var_1_expected

    # Case 2: Delve deeper into the tree
    var_2 = tree()
    set_tree_node(var_2, 'foo:bar:baz', 'bork')

# Generated at 2022-06-26 02:56:47.766806
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    set_tree_node(var_1, '0:0:0', 'hello world')
    print(var_1['0']['0'])


# Generated at 2022-06-26 02:56:52.013383
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': {'baz': 123}}}
    key = 'foo:bar:baz'
    default = 555
    parent = True
    assert get_tree_node(mapping, key, default, parent) == mapping["foo"]


# Generated at 2022-06-26 02:56:57.531496
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO:
    #   1. Check that the function returns the correct value
    #   2. Check that the function raises the proper exception
    var_0 = tree()
    var_0['foo'] = 'bar'
    result = get_tree_node(var_0, 'foo')
    assert result == 'bar'


# Generated at 2022-06-26 02:57:06.524153
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a:b:c'].update({'1': '2'})
    var_0['d'] = '1'
    var_0['a']['b']['e'] = '5'
    pprint(var_0)
    assert get_tree_node(var_0, 'a:b:c') == {'1': '2'}
    assert get_tree_node(var_0, 'a:b:c', default='0') == {'1': '2'}
    assert get_tree_node(var_0, '1', default='0') == '0'
    assert get_tree_node(var_0, 'a:b:c:1') == '2'

# Generated at 2022-06-26 02:57:11.159066
# Unit test for function set_tree_node
def test_set_tree_node():
    # TODO more tests
    test_mapping = tree()
    set_tree_node(test_mapping, 'test', 355)
    assert test_mapping['test'] == 355



# Generated at 2022-06-26 02:58:04.995762
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test to ensure that an exception is raised if the rows are not equal
    if (set_tree_node(None, None, None) == "Wrong"):
        raise AssertionError()


# Generated at 2022-06-26 02:58:17.439243
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'level1_0': {
            'level2_0': 'ok'
        }
    }
    assert get_tree_node(tree, 'level1_0') == tree['level1_0']
    assert get_tree_node(tree, 'level1_0:level2_0') == 'ok'

    with pytest.raises(KeyError):
        get_tree_node(tree, 'level1_1')
    with pytest.raises(KeyError):
        get_tree_node(tree, 'level1_1:level2_0')
    with pytest.raises(KeyError):
        get_tree_node(tree, 'level1_0:level2_1')

# Generated at 2022-06-26 02:58:22.072516
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = get_tree_node({}, '', default=_sentinel, parent=False)
    var_1 = get_tree_node({}, '', default=_sentinel, parent=True)


# Generated at 2022-06-26 02:58:25.115365
# Unit test for function set_tree_node

# Generated at 2022-06-26 02:58:28.888219
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(mapping=tree(), key='0', default=None, parent=False) == None


# Generated at 2022-06-26 02:58:34.511443
# Unit test for function get_tree_node
def test_get_tree_node():
    class A(object):
        pass
    a = A()
    a.foo = {'bar': {'baz': 'quux'}}
    assert get_tree_node(a, 'foo:bar:baz') == 'quux'



# Generated at 2022-06-26 02:58:40.957810
# Unit test for function set_tree_node
def test_set_tree_node():
    with pytest.raises(TypeError):
        # Checks if int type raises TypeError
        set_tree_node(int(), str(), list())

    with pytest.raises(TypeError):
        # Checks if str type raises TypeError
        set_tree_node(str(), str(), list())

    with pytest.raises(TypeError):
        # Checks if list type raises TypeError
        set_tree_node(list(), str(), list())

    with pytest.raises(TypeError):
        # Checks if dict type raises TypeError
        set_tree_node(dict(), str(), list())

    with pytest.raises(TypeError):
        # Checks if tuple type raises TypeError
        set_tree_node(tuple(), str(), list())


# Generated at 2022-06-26 02:58:46.119422
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    key = "a:b"
    value = "2"
    out_val = set_tree_node(mapping, key, value)

    assert out_val == {"a": "2"}


# Generated at 2022-06-26 02:58:51.392852
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_data = tree()
    tree_data['a'] = {'b': {'c': {'g': '1'}}}
    tree_data['d'] = [{'e': {'f': {'h': '2'}}}]
    tree_data['i'] = '3'
    result = get_tree_node(tree_data, 'a:b:c:g')
    assert result == '1'
    result = get_tree_node(tree_data, 'd:e:f:h', parent=True)
    assert result == {'h': '2'}


# Generated at 2022-06-26 02:59:01.001571
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(var_0, 'key_2')
    assert get_tree_node(var_0, 'key_0')
    assert get_tree_node(var_0, 'key_1')
    assert get_tree_node(var_0, 'key_0')
    assert get_tree_node(var_0, 'key_1')
    assert get_tree_node(var_1, 'key_2')
    assert get_tree_node(var_2, 'key_0')
    assert get_tree_node(var_3, 'key_1')
    assert get_tree_node(var_4, 'key_2')
    assert get_tree_node(var_5, 'key_0')
    assert get_tree_node(var_6, 'key_1')
   