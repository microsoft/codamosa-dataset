

# Generated at 2022-06-26 02:49:22.839517
# Unit test for function get_tree_node
def test_get_tree_node():


    # Call function get_tree_node
    var_0 = get_tree_node(test_case_0, '0')
    assert var_0 == 0, "Expected 0, got %s" % var_0

    # Call function get_tree_node
    var_1 = get_tree_node(test_case_0, '1')
    assert var_1 == 1, "Expected 1, got %s" % var_1

    # Call function get_tree_node
    var_2 = get_tree_node(test_case_0, '2')
    assert var_2 == 2, "Expected 2, got %s" % var_2

    # Call function get_tree_node
    var_3 = get_tree_node(test_case_0, '3')

# Generated at 2022-06-26 02:49:26.515629
# Unit test for function get_tree_node
def test_get_tree_node():
    state = {
        'foo': {
            'bar': {
                'zip': 'zap',
            },
        },
    }
    assert 'zap' == get_tree_node(state, 'foo:bar:zip')



# Generated at 2022-06-26 02:49:31.088088
# Unit test for function get_tree_node
def test_get_tree_node():

    # Set up test case
    mapping = {'a': {'b': 1}, 'b': 2}

    # Run method
    node = get_tree_node(mapping, 'a:b')

    # Check result
    if node != 1:
        raise RuntimeError('Unexpected result: {0}'.format(node))


# Generated at 2022-06-26 02:49:33.621944
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = tree()
    set_tree_node(tree, 'blah:blah2', 'Test value')
    assert tree['blah']['blah2'] == 'Test value'



# Generated at 2022-06-26 02:49:34.689485
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO: Implement unit test

    pass


# Generated at 2022-06-26 02:49:40.831676
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['b']['c'] = 123
    var_0['a']['b']['d'] = 456
    var_0['a']['b']['e'] = 789
    assert get_tree_node(var_0, 'a') == {'b': {'c': 123, 'd': 456, 'e': 789}}
    assert get_tree_node(var_0, 'a:b') == {'c': 123, 'd': 456, 'e': 789}
    assert get_tree_node(var_0, 'a:b', default=_sentinel) == {'c': 123, 'd': 456, 'e': 789}

# Generated at 2022-06-26 02:49:49.258094
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = {}
    var_2 = {}
    var_1[1] = var_2
    var_1[1][4] = 'abc'
    var_3 = get_tree_node(var_1, '1:4')
    assert var_3 == 'abc'
    var_3 = get_tree_node(var_1, '1:4', default='default')
    assert var_3 == 'abc'
    var_3 = get_tree_node(var_1, '1:4', default='default', parent=True)
    assert var_3 == var_2
    expected_exception = (KeyError, AssertionError)
    with raises(expected_exception):
        var_3 = get_tree_node(var_1, '1:5')

# Generated at 2022-06-26 02:49:50.961757
# Unit test for function set_tree_node
def test_set_tree_node():
    assert var_0 == set_tree_node(var_0, 'cat', 'meow')


# Generated at 2022-06-26 02:49:56.593259
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a'] = 1
    var_0['b'] = 2
    var_0['c'] = 3
    assert var_0.a == 1
    var_0['c']['d'] = 4
    var_0['c']['e'] = 5
    assert var_0['c']['d'] == 4
    assert len(var_0.c) == 2


# Generated at 2022-06-26 02:50:01.875270
# Unit test for function get_tree_node
def test_get_tree_node():
    try:
        assert get_tree_node(None, None)
    except TypeError as exc:
        pass
    else:
        raise Exception('Wrong type for argument `mapping` caused no exception. You are on your own here.')

    assert get_tree_node({}, 'foo', default={}).get('bar') is None



# Generated at 2022-06-26 02:50:12.486454
# Unit test for function get_tree_node
def test_get_tree_node():
    key = 'arbitrary_key'
    mapping = {
        'example': {
            'keyspace': {
                'any': {
                    'arbitrary_key': 'some_value'
                }
            }
        }
    }
    kwargs = {
        'key': key,
        'mapping': mapping,
        'default': _sentinel,
        'parent': False
    }

    actual = get_tree_node(**kwargs)
    expected = 'some_value'
    msg = 'Expected: %s\nActual:   %s' % (expected, actual)
    assert actual == expected, msg



# Generated at 2022-06-26 02:50:15.773185
# Unit test for function get_tree_node
def test_get_tree_node():
    # Validate: Default value - get_tree_node
    assert get_tree_node(mapping=var_0, key='get_tree_node', default=_sentinel) == _sentinel


# Generated at 2022-06-26 02:50:16.827991
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 1 == 1



# Generated at 2022-06-26 02:50:27.220247
# Unit test for function set_tree_node
def test_set_tree_node():

    # Test with simple static data
    mapping = {'a': {'b': {'c': {'d': 'e'}}}}
    key = 'a:b:c:d:e:f:g:h:i'

    result = set_tree_node(mapping, key, 'value')

    # Ensure correct result
    assert result['d'] == 'e'
    assert result['c'] == {'d': 'e'}
    assert result['b'] == {'c': {'d': 'e'}}
    assert result['a'] == {'b': {'c': {'d': 'e'}}}

    # Test __setitem__ by setting a value with square brackets and ensure it works.
    mapping['a:b:c:d:e:f:g:h:i'] = 'value2'

   

# Generated at 2022-06-26 02:50:33.785659
# Unit test for function get_tree_node
def test_get_tree_node():
    # var_0 ---> defaultdict(<class '__main__.tree'>, {})
    var_0 = tree()
    # Set var_0[foo] to 'bar'
    var_0[foo] = 'bar'
    # Set var_0[baz:lol] to 'lmao'
    var_0[baz:lol] = 'lmao'
    # var_1 ---> 'bar'
    var_1 = 'bar'
    var_2 = 'lmao'
    var_3 = get_tree_node(var_0, 'foo')
    # var_3 ---> 'bar'
    var_3 = get_tree_node(var_0, 'foo')
    var_4 = get_tree_node(var_0, 'baz:lol')
    # var_

# Generated at 2022-06-26 02:50:37.878246
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(tree(), 'a', 1) == {'a': 1}
    assert set_tree_node(tree(), 'a:b:c', 1) == {'a': {'b': {'c': 1}}}


# Generated at 2022-06-26 02:50:43.286623
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0[1][2][3] = 4
    var_1 = var_0[1][2][3]
    assert var_1 == 4, 'Expected 4, got {0}'.format(var_1)


# Generated at 2022-06-26 02:50:53.687863
# Unit test for function set_tree_node
def test_set_tree_node():
    # Caso de prueba 0
    param_0_0 = Tree()
    param_0_1 = 'foo:bar:baz'
    param_0_2 = 'quux'
    set_tree_node(param_0_0, param_0_1, param_0_2)
    # Verificación 0
    assert param_0_0['foo']['bar']['baz'] == 'quux'
    # Caso de prueba 1
    param_1_0 = Tree()
    param_1_1 = 'foo:bar:baz:quuux'
    param_1_2 = 'quux'
    set_tree_node(param_1_0, param_1_1, param_1_2)
    # Verificación 1
    assert param_1_

# Generated at 2022-06-26 02:51:05.721612
# Unit test for function get_tree_node
def test_get_tree_node():
    # Initialize a dict with a few keys
    mapping = {'A': {'B': {'C': {'D': 'cow'}, 'E': {'F': 'dog'} }}}
    assert get_tree_node(mapping, 'A:B:E:F') == 'dog'
    assert get_tree_node(mapping, 'A:B') == {'C': {'D': 'cow'}, 'E': {'F': 'dog'}}

    with pytest.raises(KeyError):
        get_tree_node(mapping, 'A:B:G')
    assert get_tree_node(mapping, 'A:B:G', default='goat') == 'goat'
    assert get_tree_node(mapping, 'A:B:G', default=None) is None

   

# Generated at 2022-06-26 02:51:08.811355
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    set_tree_node(var_1, 'a:b:c', 'test')
    assert get_tree_node(var_1, 'a:b:c') == 'test'


# Generated at 2022-06-26 02:51:23.951441
# Unit test for function get_tree_node
def test_get_tree_node():
    var_3 = get_tree_node(test_case_0(), '0')
    assert isinstance(var_3, tree)
    var_4 = get_tree_node(var_3, '1')
    assert isinstance(var_4, tree)
    var_5 = get_tree_node(var_4, '2')
    assert isinstance(var_5, tree)
    var_6 = get_tree_node(var_5, '3')
    assert isinstance(var_6, tree)
    var_7 = get_tree_node(var_6, '4')
    assert isinstance(var_7, tree)
    var_8 = get_tree_node(var_7, '5')
    assert isinstance(var_8, tree)

# Generated at 2022-06-26 02:51:24.839950
# Unit test for function get_tree_node
def test_get_tree_node():
    assert False


# Generated at 2022-06-26 02:51:31.971214
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {
            'b': {
                'c': 3
            }
        }
    }

    assert get_tree_node(d, 'a:b:c') == 3
    assert get_tree_node(d, 'a:b:c:d', default=_sentinel) == _sentinel  # TODO: check this
    assert get_tree_node(d, 'a:b:c:d', default='foo') == 'foo'
    assert get_tree_node(d, 'foo:bar:baz', default='foo') == 'foo'

test_case_0()

# Generated at 2022-06-26 02:51:35.454598
# Unit test for function set_tree_node
def test_set_tree_node():
    print("Testing set_tree_node")
    var_0 = tree()
    set_tree_node(var_0, 'a:b:c:d:e:f', 1)
    print(var_0)

# Generated at 2022-06-26 02:51:45.366597
# Unit test for function set_tree_node

# Generated at 2022-06-26 02:51:54.413663
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': {'baz': True}}}
    assert get_tree_node(mapping, 'foo:bar:baz')
    assert True is get_tree_node(mapping, 'foo:bar:baz', default=False)
    assert False is get_tree_node(mapping, 'foo:bar:foo', default=False)
    assert dict == get_tree_node(mapping, 'foo:bar', default=False, parent=True).__class__
    assert dict == get_tree_node(mapping, 'foo', default=False, parent=True).__class__
    assert dict == get_tree_node(mapping, 'foo:bar:baz', default=False, parent=True).__class__

    # Default to `_sentinel` should raise KeyError

# Generated at 2022-06-26 02:51:58.078364
# Unit test for function get_tree_node
def test_get_tree_node():
    # assert get_tree_node(tree(), 'key')
    # assert get_tree_node(tree(), 'key', default='value')
    pass



# Generated at 2022-06-26 02:52:08.875515
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['k']['e']['y']['s']['a']['r']['e']['c']['o']['o']['l'] = 'yeah'
    var_0['k']['e']['y']['s']['a']['r']['e']['d']['o']['o']['m']['s'] = 'yeah'
    var_0['k']['e']['y']['s']['a']['r']['e']['c']['o']['o']['l']['s']['t']['o']['o']['l'] = 'yeah'

# Generated at 2022-06-26 02:52:10.594466
# Unit test for function set_tree_node
def test_set_tree_node():
    result = set_tree_node(dict(), 'key::key2', 'value')
    assert result == {'key': {'key2': 'value'}}


# Generated at 2022-06-26 02:52:19.975122
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {
        'x': {
            'foo': 'bar',
            'baz': {
                'f': 'd'
            }
        }
    }

    assert get_tree_node(m, 'x:foo') == 'bar'
    assert get_tree_node(m, 'x:baz:f') == 'd'
    assert get_tree_node(m, 'x') == {'baz': {'f': 'd'}, 'foo': 'bar'}

    try:
        get_tree_node(m, 'x:y')
    except KeyError:
        pass
    else:
        raise AssertionError()

    assert get_tree_node(m, 'x:y', 'DEFAULT') == 'DEFAULT'

# Generated at 2022-06-26 02:52:37.090121
# Unit test for function get_tree_node
def test_get_tree_node():
    print("Testing: get_tree_node")
    result = 'Failed'

    try:
        var_0 = tree()
        var_0['a.b.c']['d'] = {}

        assert get_tree_node(var_0, 'a:b:c:d') == {}
        assert get_tree_node(var_0, 'a:b:c') == get_tree_node(var_0, 'a:b:c', default=None)
        assert get_tree_node(var_0, 'a:b:c:d:e:f', default={}) == {}

        get_tree_node(var_0, 'a:b:c:d:e:f')

        result = 'Passed'
    except Exception as e:
        print(e)
    finally:
        print

# Generated at 2022-06-26 02:52:48.904819
# Unit test for function get_tree_node
def test_get_tree_node():
    mockMapping = tree({'var_0':tree({'var_1':tree({'var_2': 'var_2'})})})
    assert get_tree_node(mockMapping, 'var_0:var_1:var_2') == 'var_2'
    # elif call.func == tree.get_tree_node and kall.args[0] == mockMapping:
    #     assert kall.args == (mockMapping, 'var_0:var_1', 'var_2'), "Function get_tree_node called on mockMapping with arguments: 'var_0:var_1' and 'var_2'"
    #     assert kall.return_value == 'var_2', "Function get_tree_node returned: 'var_2'"
    # elif call.func == tree.get

# Generated at 2022-06-26 02:52:57.872678
# Unit test for function set_tree_node
def test_set_tree_node():
    test = {
        'foo': {
            'bar': {}
        }
    }
    set_tree_node(test, 'foo:bar:baz', 'woot')
    assert test['foo']['bar']['baz'] == 'woot'

    # Test empty tree creation
    test = {}
    set_tree_node(test, 'foo:bar:baz', 'woot')
    assert test['foo']['bar']['baz'] == 'woot'



# Generated at 2022-06-26 02:53:07.060894
# Unit test for function set_tree_node
def test_set_tree_node():
    case_0 = {}
    set_tree_node(case_0, "", 3)
    set_tree_node(case_0, "a", 3)
    set_tree_node(case_0, "a:b", 3)
    set_tree_node(case_0, "a:c", 3)
    assert case_0 == {'a': {'b': 3, 'c': 3}}, "set_tree_node(case_0, '', 3) failed"



# Generated at 2022-06-26 02:53:17.097358
# Unit test for function get_tree_node
def test_get_tree_node():

    var_0 = None
    try:
        var_0 = get_tree_node(None, None)
    except Exception as e:
        if 'NO' not in str(e):
            print("[FAIL] get_tree_node: Test case 0 failed. Unexpected exception thrown.")
            return False
    if var_0 is not None:
        print("[FAIL] get_tree_node: Test case 0 failed. Wrong return value.")
        return False
    return True



# Generated at 2022-06-26 02:53:24.551909
# Unit test for function set_tree_node
def test_set_tree_node():

    # AssertionError: Expected [3, {'a': 2}] but got [3, {}]
    assert set_tree_node({}, 'a:b', 3) == {'a': {'b': 3}}, "Case 0 failed"

    # AssertionError: Expected [{'a': {'b': {'c': 4}}}] but got [{'a': {'b': {'d': 4}}}]
    assert set_tree_node({'a': {'b': 3}}, 'a:b:c', 4) == {'a': {'b': {'c': 4}}}, "Case 1 failed"


# Generated at 2022-06-26 02:53:33.965874
# Unit test for function set_tree_node
def test_set_tree_node():
    from nose.tools import assert_raises

    assert_raises(AssertionError, set_tree_node)

# Generated at 2022-06-26 02:53:40.252599
# Unit test for function set_tree_node
def test_set_tree_node():
    obj = dict()
    obj = set_tree_node(obj, 'a', 1)
    obj = set_tree_node(obj, 'b', 1)
    obj = set_tree_node(obj, 'c', 1)
    obj = set_tree_node(obj, 'd', 1)
    obj = set_tree_node(obj, 'foo:bar:baz', 1)
    assert obj == {
        'a': 1,
        'b': 1,
        'c': 1,
        'd': 1,
        'foo': {
            'bar': {
                'baz': 1
            },
        },
    }



# Generated at 2022-06-26 02:53:42.337080
# Unit test for function set_tree_node
def test_set_tree_node():
    assert True



# Generated at 2022-06-26 02:53:50.217265
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f',
            }
        },
        'g': {
            'h': {
                'i': 'j',
            }
        },
    }
    assert get_tree_node(tree, 'a:b') == {'c': 'd', 'e': 'f'}
    assert get_tree_node(tree, 'a:b:e') == 'f'
    assert get_tree_node(tree, 'a:b:e:f') == _sentinel



# Generated at 2022-06-26 02:54:13.695064
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equals, assert_raises, assert_true, assert_false
    # TODO: Add your test cases here!

    # FIXME: Workaround for assert_raises bug
    # See https://github.com/nose-devs/nose/issues/917
    def assert_raises_fixed(exception, func, *args, **kwargs):
        try:
            func(*args, **kwargs)
        except exception:
            pass
        else:
            raise AssertionError("Did not raise %s" % exception)

    assert_raises(TypeError, get_tree_node, var_0, ) # Test no params
    assert_raises_fixed(KeyError, get_tree_node, var_0, ) # Test no params

# Generated at 2022-06-26 02:54:15.928659
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node() == 'Placeholder'


# Generated at 2022-06-26 02:54:21.466694
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_node = {'a': {'b': {'c': 3}}}
    set_tree_node(tree_node, 'a:b:d', 4)
    assert tree_node['a']['b']['d'] == 4
    set_tree_node(tree_node, 'a:b', {'e': 5})
    assert tree_node['a']['b']['e'] == 5


# Generated at 2022-06-26 02:54:29.080022
# Unit test for function get_tree_node
def test_get_tree_node():
    var_exp = """Hello"""
    var_0 = tree()
    var_1 = tree()
    var_0['foo'] = var_1
    var_1['bar'] = var_exp
    var_2 = get_tree_node(var_0, 'foo')
    assert var_exp is var_2['bar'], "var_2['bar'] is var_exp"


# Generated at 2022-06-26 02:54:40.356055
# Unit test for function set_tree_node
def test_set_tree_node():

    # Test 0: Empty key
    var_0 = tree()
    set_tree_node(var_0, '', 'empty')
    assert var_0 == {'empty': tree()}

    # Test 1: Key with one element
    var_0 = tree()
    set_tree_node(var_0, 'foo', 'bar')
    # TODO assert equality
    assert var_0 == {'foo': tree(bar=tree())}

    # Test 2: Key with multiple elements
    var_0 = tree()
    set_tree_node(var_0, 'foo:bar', 'baz')
    # TODO assert equality
    assert var_0 == {'foo': tree(bar=tree(baz=tree()))}



# Generated at 2022-06-26 02:54:49.174801
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({
        'foo': {
            'bar': {
                'baz': None,
            },
            'bruh': None,
        },
    }, 'foo:bruh:doh', 'herp derp') == {
        'bar': {
            'baz': None,
        },
        'bruh': {
            'doh': 'herp derp',
        },
    }



# Generated at 2022-06-26 02:54:59.766697
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = tree()
    var_1['var_2']['var_3']['var_4']['var_5'] = 'var_6'
    var_7 = get_tree_node(var_1, 'var_2')
    var_8 = get_tree_node(var_1, 'var_2')
    assert var_7 is var_8
    var_9 = get_tree_node(var_1, 'var_3')
    assert False, 'test case for get_tree_node failed'


# Generated at 2022-06-26 02:55:03.368700
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(var_0, 'key:subkey', None, True) == {}



# Generated at 2022-06-26 02:55:09.493159
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = {}
    var_1 = set_tree_node(var_0, 'a:b:c', 1)
    assert var_0 == {'a': {'b': {'c': 1}}}
    assert var_1 == {'b': {'c': 1}}


# Generated at 2022-06-26 02:55:12.947491
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {'a': {'b': {'c': 'd'}}}
    assert var_0 == get_tree_node(var_0, 'a') == get_tree_node(var_0, 'a:b:c') == get_tree_node(var_0, 'a:b:c:d')


# Generated at 2022-06-26 02:55:53.322266
# Unit test for function get_tree_node
def test_get_tree_node():
    # Populate some initial data.
    # This is a tree, it has defaultdicts as children, so they can be accessed as if they were normal dicts.
    # It's easier to use : notation to delve into the depths, but this is not required.
    var_0 = tree()
    var_0['a'] = 1
    var_0['b']['c'] = 2
    var_0['b']['d'] = 3
    var_0['b']['e']['f']['g'] = 4

    # Fetch node 'g' on tree
    var_1 = get_tree_node(var_0, 'b:e:f:g')

    assert var_1 == 4


# Generated at 2022-06-26 02:55:59.908800
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, '1:2:3:4:5', 'value') == {'1': {'2': {'3': {'4': {'5': 'value'}}}}}
    assert set_tree_node({}, '1', 'value') == {'1': 'value'}



# Generated at 2022-06-26 02:56:09.848430
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0["a"] = "b"
    var_0["a"]["b"] = "c"
    var_0["a"]["b"]["c"] = "d"

    assert get_tree_node(var_0, "a") == "b"
    assert get_tree_node(var_0, "a:b") == "c"
    assert get_tree_node(var_0, "a:b:c") == "d"


# Generated at 2022-06-26 02:56:13.879126
# Unit test for function set_tree_node
def test_set_tree_node():
    assert sorted(set_tree_node(tree(), 'a:b:c:d:a:1:2:3:4:1', 'value')) == ['value']


# Generated at 2022-06-26 02:56:21.624207
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, "") is _sentinel
    assert get_tree_node({}, "a") is _sentinel
    assert get_tree_node({}, "a:b") is _sentinel
    assert get_tree_node({}, "a:b:c") is _sentinel

    assert get_tree_node({'a': 'b'}, "a") == 'b'
    assert get_tree_node({'a': 'b'}, "a:b") == 'b'



# Generated at 2022-06-26 02:56:32.428280
# Unit test for function get_tree_node
def test_get_tree_node():
    my_tree = tree()
    my_tree['fred']['child1']['child3'] = 'child3_value'
    my_tree['fred']['child2'] = 'child2_value'
    assert my_tree['fred']['child2'] == 'child2_value'
    assert my_tree['fred']['child1']['child3'] == 'child3_value'
    assert get_tree_node(my_tree, 'fred:child2') == 'child2_value'
    assert get_tree_node(my_tree, 'fred:child1:child3') == 'child3_value'
    assert get_tree_node(my_tree, 'doesntexist', default='default_value') == 'default_value'
    with pytest.raises(KeyError):
        get

# Generated at 2022-06-26 02:56:42.332538
# Unit test for function get_tree_node
def test_get_tree_node():
    my_dict = {
        'foo': {
            'bar': {
                'bazz': 'FOO'
            },
            'bazz': 'BAR'
        },
        'bazz': {
            'bazz': 'BAZZ'
        },
        'bazz': 'BAZZ'
    }

    assert get_tree_node(my_dict, 'bazz') == 'BAZZ'
    assert get_tree_node(my_dict, 'foo:bazz') == 'BAR'
    assert get_tree_node(my_dict, 'foo:bar:bazz') == 'FOO'



# Generated at 2022-06-26 02:56:53.215813
# Unit test for function set_tree_node
def test_set_tree_node():
    class TestClass:
        __mapping = {}
        mapping = property(lambda self: self.__mapping)

    test_object = TestClass()

    # No input
    set_tree_node(test_object.mapping, 'test', 'value')
    assert test_object.mapping == {'test': 'value'}

    # Two level input
    set_tree_node(test_object.mapping, 'test:value', 'value')
    assert test_object.mapping == {'test': {'value': 'value'}}
    set_tree_node(test_object.mapping, 'test:value', 'value')
    assert test_object.mapping == {'test': {'value': 'value'}}



# Generated at 2022-06-26 02:57:04.818603
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = {'a': {'b': {'c': 'd'}}}
    if var_1['a']['b']['c'] != get_tree_node(var_1, 'a:b:c'):
        raise AssertionError
    var_2 = {'a': {'b': {'c': 'd', 'e': 'f'}, 'g': {'h': 'i'}}}
    if var_2['a']['b']['e'] != get_tree_node(var_2, 'a:b:e'):
        raise AssertionError
    if var_2['a']['g'] != get_tree_node(var_2, 'a:g'):
        raise AssertionError


# Generated at 2022-06-26 02:57:13.887381
# Unit test for function get_tree_node
def test_get_tree_node():
    class Mock():
        pass

    # Construct mock arguments
    moc_arg_0 = Mock()
    moc_arg_0.__class__ = collections.Mapping
    moc_arg_0.mock_children = collections.OrderedDict([("a", Mock())])
    moc_arg_0.mock_children["b"] = Mock()
    moc_arg_0.mock_children["b"].mock_children = collections.OrderedDict([("c", Mock())])
    moc_arg_0.mock_children["b"].mock_children["c"].mock_children = collections.OrderedDict([("d", Mock())])
    moc_arg_0.mock_children["b"].mock_children["c"].mock_children["d"].m

# Generated at 2022-06-26 02:58:47.776230
# Unit test for function get_tree_node
def test_get_tree_node():
    # Testing a non-existent node
    sub_tree = get_tree_node(test_case_0, "moo")
    assert sub_tree == None

    # Testing a non-existent node with default value
    sub_tree = get_tree_node(test_case_0, "moo", "cow")
    assert sub_tree == "cow"

    # Testing a non-existent node with default value
    sub_tree = get_tree_node(test_case_0, "moo", "cow", parent=True)
    assert sub_tree == None


# Generated at 2022-06-26 02:59:00.008174
# Unit test for function get_tree_node
def test_get_tree_node():
    test_inputs = []
    test_inputs.append((dict(a=dict(b=dict(c=dict(d=dict(e=dict(f=1)))))), "a"))
    test_inputs.append((dict(a=dict(b=dict(c=dict(d=dict(e=dict(f=1)))))), "a:b"))
    test_inputs.append((dict(a=dict(b=dict(c=dict(d=dict(e=dict(f=1)))))), "a:b:c:d:e:f"))
    test_inputs.append((dict(a=dict(b=dict(c=dict(d=dict(e=dict(f=1)))))), "a:b:c:d:e:f:g"))
    test_inputs.append

# Generated at 2022-06-26 02:59:07.288525
# Unit test for function get_tree_node
def test_get_tree_node():

    var_0 = tree()
    var_0['foo']['bar'] = 'baz'
    var_1 = tree()
    var_1['bar']['baz'] = 'foo'
    var_2 = {
        'foo': {
            'bar': 'baz'
        },
        'bar': {
            'baz': 'foo'
        }
    }
    var_3 = get_tree_node(var_0, 'foo:bar')
    var_4 = get_tree_node(var_1, 'bar:baz')
    var_5 = get_tree_node(var_2, 'foo:bar')
    var_6 = get_tree_node(var_2, 'bar:baz')


# Generated at 2022-06-26 02:59:09.539985
# Unit test for function get_tree_node
def test_get_tree_node():
    print(get_tree_node(tree(), 'foo:bar:thing'))


# Generated at 2022-06-26 02:59:12.011074
# Unit test for function get_tree_node
def test_get_tree_node():
    assert var_0 == get_tree_node(var_0, key)
