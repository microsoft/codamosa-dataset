

# Generated at 2022-06-26 02:49:15.303786
# Unit test for function get_tree_node
def test_get_tree_node():
    assert False


# Generated at 2022-06-26 02:49:22.422207
# Unit test for function get_tree_node
def test_get_tree_node():
    with pytest.raises(KeyError):
        assert get_tree_node(tree(), 'a') is _sentinel

    assert get_tree_node(tree(), 'a', 'b') == 'b'
    assert get_tree_node(tree(), 'a', 'b', parent=True) == None
    assert get_tree_node(tree(), 'a:b') == None

    assert get_tree_node(tree(), 'a:b') == None
    assert get_tree_node(tree(), 'a:b:c', parent=True) == None
    assert get_tree_node(tree(), 'a:b:c', parent=True) == None



# Generated at 2022-06-26 02:49:32.886061
# Unit test for function set_tree_node
def test_set_tree_node():
    test_cases = [
        # Single dimension
        (
            {'test': 'value'},
            {'test': {'test': 'value'}},
            'test',
            'value'
        ),
        # Nested
        (
            {},
            {'test': {'test': 'value'}},
            'test:test',
            'value'
        ),
        # Override
        (
            {'test': {'test': 'value'}},
            {'test': {'test': 'override'}},
            'test:test',
            'override'
        )
    ]

    for (input_map, expected, key, value) in test_cases:
        output_map = input_map.copy()

# Generated at 2022-06-26 02:49:36.405330
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = tree()
    tree['a']['b']['c'] = 1
    tree['a']['b']['d'] = 1
    tree['a']['e'] = 1
    tree['f'] = 1
    assert get_tree_node(tree, 'a:b:c') == 1



# Generated at 2022-06-26 02:49:48.190255
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0["a:b:c"] = [
        {
            "x": "y"
        },
        {
            "x2": "y2"
        }
    ]
    var_0["a:b:c3"] = 42
    var_0["a:b:c2"] = "toto"
    var_1 = get_tree_node(var_0, "a:b:c")
    assert var_1 == [
        {
            "x": "y"
        },
        {
            "x2": "y2"
        }
    ]
    var_2 = get_tree_node(var_0, "a:b:c:x:nope")
    assert var_2 is _sentinel
    var_3 = get_tree_

# Generated at 2022-06-26 02:49:52.869729
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    set_tree_node(d, 'foo:bar', 'baz')
    assert d['foo']['bar'] == 'baz'
    set_tree_node(d, 'foo:bar:gaz', 'bam')
    assert d['foo']['bar']['gaz'] == 'bam'


# Generated at 2022-06-26 02:49:55.117775
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = 'test'
    result = get_tree_node(var_0, var_1)
    assert result == None

# Generated at 2022-06-26 02:49:58.530381
# Unit test for function set_tree_node
def test_set_tree_node():
    # Function body
    # Case 0
    var = tree()
    set_tree_node(var, 'x:y:z', 'lol')
    assert var['x']['y']['z'] == 'lol'


# Generated at 2022-06-26 02:50:02.799162
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.defaultdict(tree)
    key = ':hi:bye:spider'
    value = 4
    result = set_tree_node(mapping, key, value)
    assert result == {'hi': {'bye': {'spider': 4}}}



# Generated at 2022-06-26 02:50:12.844989
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = tree()
    var_2 = tree()
    var_3 = tree()
    var_4 = tree()
    var_5 = tree()
    var_6 = tree()
    var_7 = tree()
    var_8 = tree()
    var_9 = tree()
    var_10 = tree()
    var_11 = tree()
    var_12 = tree()
    var_13 = tree()
    var_14 = tree()
    var_15 = tree()
    var_16 = tree()
    var_17 = tree()
    var_18 = tree()
    var_19 = tree()
    var_20 = tree()
    var_21 = tree()
    var_22 = tree()
    var_23 = tree()
    var_24 = tree()

# Generated at 2022-06-26 02:50:19.951802
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_0['a']['b'] = 'c'
    set_tree_node(var_0, 'a:b', 'c')
    var_1 = tree()
    var_1['a']['b']['c'] = 'd'
    set_tree_node(var_1, 'a:b:c', 'd')



# Generated at 2022-06-26 02:50:24.408842
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    key = 'a:b:c'
    value = 8
    expected = {'a': {'b': {'c': 8}}}
    actual = set_tree_node(mapping, key, value)
    assert actual == expected



# Generated at 2022-06-26 02:50:27.368421
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = dict()
    set_tree_node(tree, 'foo:bar:baz', 'test')
    assert tree == {'foo': {'bar': {'baz': 'test'}}}



# Generated at 2022-06-26 02:50:30.039149
# Unit test for function set_tree_node
def test_set_tree_node():
    print("Unit test for function: set_tree_node")
    print("test case 0")
    var_0 = tree()
    print("test case 0 passed")


# Generated at 2022-06-26 02:50:40.511012
# Unit test for function get_tree_node
def test_get_tree_node():
    # Testcase 0
    var_0 = tree()
    var_0['level_0:val_0'] = '#0'
    var_0['level_0:level_1:val_0'] = '#1'
    var_0['level_0:level_1:val_1'] = '#2'
    var_0['level_0:level_1:val_2'] = '#3'
    var_0['level_0:level_2:val_0'] = '#4'
    var_0['level_0:level_2:val_1'] = '#5'
    var_0['level_0:level_2:level_3:val_0'] = '#6'

# Generated at 2022-06-26 02:50:43.628706
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {'a': {'b': {'c': 'd'}}}
    actual_output = get_tree_node(test_data, 'a:b')
    expected_output = {'c': 'd'}
    assert actual_output == expected_output

# Generated at 2022-06-26 02:50:46.056495
# Unit test for function get_tree_node
def test_get_tree_node():
    #TODO: Write a unittest
    pass


# Generated at 2022-06-26 02:50:55.509779
# Unit test for function set_tree_node
def test_set_tree_node():
    v1 = tree()
    k = 'a:b:c'
    v = 'd'
    set_tree_node(v1, k, v)

# Generated at 2022-06-26 02:51:07.205554
# Unit test for function get_tree_node
def test_get_tree_node():
    first_item = "first_item"
    second_item = "second_item"
    key_1 = "key_1"
    key_2 = "key_2"
    key_3 = "key_3"
    key_4 = "key_4"
    key_12 = ":".join([key_1, key_2])
    key_124 = ":".join([key_12, key_4])
    value_1 = 1
    value_2 = 2
    value_3 = 3
    value_4 = 4


# Generated at 2022-06-26 02:51:12.306834
# Unit test for function get_tree_node
def test_get_tree_node():
    # Simple test case
    get_tree_node(var_0, "foo.bar.baz.foo.bar.baz", default=None, parent=False)
    get_tree_node(var_0, "foo.bar.baz.foo.bar.baz", default=None, parent=True)


# Generated at 2022-06-26 02:51:20.894044
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    key = 'a:b:c'
    value = 'test'
    assert set_tree_node(mapping, key, value) == {'a': {'b': {'c': 'test'}}}
    assert mapping == {'a': {'b': {'c': 'test'}}}, mapping



# Generated at 2022-06-26 02:51:24.759757
# Unit test for function set_tree_node
def test_set_tree_node():

    # Setup
    mapping = tree()
    key = 'foo:bar:baz'
    value = 42

    # Exercise
    set_tree_node(mapping, key, value)

    # Verify
    assert mapping['foo']['bar']['baz'] == value



# Generated at 2022-06-26 02:51:27.565247
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    key = 'deu'
    value = 'german'

    # Test set
    set_tree_node(mapping, key, value)
    assert mapping[key] == value

    return True



# Generated at 2022-06-26 02:51:29.929523
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()

    # AssertionError: 'my_key' not found
    get_tree_node(var_0, 'my_key')


# Generated at 2022-06-26 02:51:31.499159
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'foo') == tree()


# Generated at 2022-06-26 02:51:40.675211
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = var_0['key']
    var_2 = var_0['key']['key']
    var_3 = get_tree_node(var_0, 'key')
    var_4 = get_tree_node(var_0, 'key:key')
    var_5 = get_tree_node(var_0, 'key:key:key')
    var_6 = get_tree_node(var_0, 'key:key', default=1)
    var_7 = get_tree_node(var_0, 'key:key:key', default=1)


# Generated at 2022-06-26 02:51:46.528648
# Unit test for function set_tree_node
def test_set_tree_node():
    #:::testcase.start
    #:::testcase.parse
    # Makes a tree from a dictionary
    var_1 = Tree(initial={'foo': 'bar'})
    var_2 = var_1
    str_1 = str(var_1)

    #:::testcase.output
    print(var_2)
    print(str_1)

    test_assert(var_2, var_1)
    test_assert(str_1, "{'foo': 'bar'}")


# Generated at 2022-06-26 02:51:48.340445
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = {'foo':{'bar': {'baz':'qux'}}}


# Generated at 2022-06-26 02:51:49.305251
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO
    pass


# Generated at 2022-06-26 02:51:55.164325
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['Spam'] = tree()
    var_0['Spam']['Spam'] = tree()
    var_0['Spam']['Spam']['Spam'] = 'Test'
    util.assert_equals('Test', get_tree_node(var_0, 'Spam:Spam:Spam'))
    util.assert_equals(var_0['Spam']['Spam'], get_tree_node(var_0, 'Spam:Spam:Spam', parent=True))



# Generated at 2022-06-26 02:52:00.965544
# Unit test for function get_tree_node
def test_get_tree_node():
    # Check type of returned object
    assert isinstance(get_tree_node(var_0, 'key'), object) is True


# Generated at 2022-06-26 02:52:08.163407
# Unit test for function set_tree_node
def test_set_tree_node():
    assert var_0 == set_tree_node(var_0, 'a:b:c', 'hello world')
    assert var_0 == set_tree_node(var_0, ':a:b:c', 'hello world')
    assert var_0 == set_tree_node(var_0, ':a:b:c:d', 'hello world')
    assert var_0 == set_tree_node(var_0, ':a:b:c:e:f', 'hello world')


# Generated at 2022-06-26 02:52:17.160720
# Unit test for function set_tree_node
def test_set_tree_node():
    print('Test: set_tree_node')
    root = tree()

    assert get_tree_node(root, 'hello:world', default=None) is None
    assert get_tree_node(root, 'hello', default=None) is None
    assert 'hello' not in root

    set_tree_node(root, 'hello', u'world')
    assert root['hello'] == u'world'
    assert get_tree_node(root, 'hello:world', default=None) is None
    assert get_tree_node(root, 'hello', default=None) == u'world'

    set_tree_node(root, 'hello:world', 'woo')
    assert root['hello']['world'] == 'woo'

# Generated at 2022-06-26 02:52:26.977415
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
            'test': {
                'test-1': {
                    'test-1-1': 'oh my'
                    }
                }
            }
    value = get_tree_node(mapping, 'test:test-1:test-1-1')
    assert value == 'oh my'
    value = get_tree_node(mapping, 'test:test-1:test-1-1', default=True)
    assert value == 'oh my'

    value = get_tree_node(mapping, 'test:test-1:test-1-2', default=True)
    assert value == True

    value = get_tree_node(mapping, 'test:test-1:test-2')
    assert value is None


# Generated at 2022-06-26 02:52:32.933667
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = Tree()
    var_1.__setitem__('foo:bar', 'foobar', namespace='')
    var_1.__setitem__('foo', 'bar', namespace='')
    var_1.__setitem__('foo:baz', 'foobaz', namespace='')
    assert var_1 == {'foo': {'bar': 'foobar', 'baz': 'foobaz'}}


# Generated at 2022-06-26 02:52:35.991962
# Unit test for function set_tree_node
def test_set_tree_node():
    """Verify that the set_tree_node function works as expected"""
    # Call function with args: d, ['foo', 'bar', 'baz'], 'x'
    # TODO: Verify this
    assert False



# Generated at 2022-06-26 02:52:48.504820
# Unit test for function get_tree_node
def test_get_tree_node():

    # Set up test variables
    var_0 = tree()
    var_1 = var_0['a']['b']['c'] = 1
    var_2 = var_0['a']['d'] = 2
    var_3 = var_0['a']['e'] = 3
    var_4 = var_0['a']['f']['g'] = 4
    var_5 = var_0['a']['f']['h'] = 5
    var_6 = var_0['a']['f']['i'] = 6
    var_7 = var_0['a']['f']['j'] = 7
    var_8 = var_0['a']['f']['k'] = 8

# Generated at 2022-06-26 02:52:59.865291
# Unit test for function get_tree_node
def test_get_tree_node():
    # Simple test
    var_0 = Tree()
    var_0['root']['sub1']['subsub1'] = 'value1'
    assert get_tree_node(var_0, 'root:sub1:subsub1') == 'value1'
    assert get_tree_node(var_0, 'non_existent', default=_sentinel) is _sentinel
    ## Set default value
    assert get_tree_node(var_0, 'non_existent', default='value1') == 'value1'
    ## Test parent
    assert get_tree_node(var_0, 'root:sub1:subsub1', parent=True)['subsub1'] == 'value1'
    assert get_tree_node(var_0, 'root:sub1', parent=True)['sub1'] == get_tree

# Generated at 2022-06-26 02:53:06.832144
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = tree()
    var_0 = get_tree_node(var_1, 'a')
    var_0 = get_tree_node(var_1, 'b:c')
    var_0 = get_tree_node(var_1, 'b:c:d')
    var_0 = get_tree_node(var_1, 'b:c:d:e')
    var_0 = get_tree_node(var_1, 'b:c:d:e', default='*')



# Generated at 2022-06-26 02:53:16.647585
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {'foo': 'Foo', 'bar': 'Bar'}
    print(var_0)
    var_1 = {'foo': {'bar': 'bar', 'baz': 'baz'}}
    print(var_1)
    print(get_tree_node(var_1, 'foo:bar'))


if __name__ == '__main__':
    test_case_0()
    test_get_tree_node()

# Generated at 2022-06-26 02:53:28.031866
# Unit test for function get_tree_node
def test_get_tree_node():
    test_map = {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'b': [1, 2, 3]}
    assert get_tree_node(test_map, 'a:b:c') == 1
    assert get_tree_node(test_map, 'b:1') == 2



# Generated at 2022-06-26 02:53:35.131182
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'a': {'d': {'m': 'n'}, 'e': '3'}, 'b': '2', 'c': '3'}
    assert get_tree_node(tree, 'a:d:m') == 'n'
    assert get_tree_node(tree, 'b') == '2'
    assert get_tree_node(tree, 'c') == '3'
    assert get_tree_node(tree, 'a:d:n') == _sentinel
    try:
        get_tree_node(tree, 'a:d:n', default=None)
        raise Exception
    except KeyError:
        pass



# Generated at 2022-06-26 02:53:39.355342
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['b']['c'] = 1

    assert get_tree_node(var_0, 'a:b:c') == 1
    assert get_tree_node(var_0, 'a:b:c:d') == _sentinel
    assert get_tree_node(var_0, 'a:b:c:d', default=None) is None


# Generated at 2022-06-26 02:53:50.695072
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_input = tree()
    set_tree_node(tree_input, 'foo', 'foo')
    set_tree_node(tree_input, 'foo:bar', 'bar')
    set_tree_node(tree_input, 'foo:baz:faz', 'faz')
    set_tree_node(tree_input, 'foo:baz:faz:boo:moo', 'moo')
    assert get_tree_node(tree_input, 'foo') == 'foo'
    assert get_tree_node(tree_input, 'foo:bar') == 'bar'
    assert get_tree_node(tree_input, 'foo:baz:faz') == 'faz'

# Generated at 2022-06-26 02:53:57.348592
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['b']['c']['d']['e'] = 'foo'
    var_1 = get_tree_node(var_0, 'a:b:c:d:e')
    assert var_1 == 'foo'

# Generated at 2022-06-26 02:53:59.118852
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, key, value)


# Generated at 2022-06-26 02:54:11.388204
# Unit test for function get_tree_node
def test_get_tree_node():
    print("Testing get_tree_node ...")
    tree = {'a': {'b': [1, 2, 3]}, 'c': {'d': {'e': {'f': 'g'}}}, 'h': 'i'}
    assert get_tree_node(tree, 'a:b:0') == 1
    assert get_tree_node(tree, 'c:d:e:f') == 'g'
    assert get_tree_node(tree, 'c:d:e:f2', default=None) is None
    assert get_tree_node(tree, 'c:d:e:f2') == 'g'
    assert get_tree_node(tree, 'h') == 'i'
    assert get_tree_node(tree, 'h') == get_tree_node(tree, 'h:')

# Generated at 2022-06-26 02:54:12.950737
# Unit test for function get_tree_node
def test_get_tree_node():
    # assert True
    pass



# Generated at 2022-06-26 02:54:17.626167
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = {'a':{'b':{}}}
    set_tree_node(var_1, 'a:b:c', 1)

# Generated at 2022-06-26 02:54:23.345850
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, '0:1:2:3') == {'0':{'1':{'2':{'3': None}}}}
    assert get_tree_node({}, u'0:1:2:3') == {u'0':{u'1':{u'2':{u'3': None}}}}


# Generated at 2022-06-26 02:54:40.731528
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {'a': {}}
    var_1 = 'a:foo:bar'
    var_2 = None
    var_3 = False
    var_4 = get_tree_node(var_0, var_1, var_2, var_3)
    if var_4 != {'foo': {'bar': {}}}:
        raise AssertionError("get_tree_node(var_0, var_1, var_2, var_3) == '{}' failed: {}".format({'foo': {'bar': {}}}, var_4))
    var_0 = {'foo': {'bar': {}}}
    var_1 = 'foo:bar'
    var_2 = None
    var_3 = False

# Generated at 2022-06-26 02:54:46.465136
# Unit test for function get_tree_node
def test_get_tree_node():
    foo = tree()
    foo['hello']['world'] = 'value'
    assert foo['hello'] == {'world': 'value'}
    assert get_tree_node(foo, 'hello:world') == 'value'



# Generated at 2022-06-26 02:54:48.611470
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, key="foo:bar:baz", value="value")
    assert var_0 == {'foo': {'bar': {'baz': 'value'}}}


# Generated at 2022-06-26 02:54:56.814660
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'key_0': {'key_1': 'value_1'}, 'key_2': {'key_3': 'value_3'}}
    assert get_tree_node(d, 'key_2') == {'key_3': 'value_3'}
    assert get_tree_node(d, 'key_2', parent=True) == d
    assert get_tree_node(d, 'key_2:key_3') == 'value_3'
    assert get_tree_node(d, 'key_2:key_4') is _sentinel
    assert get_tree_node(d, 'key_2:key_4', default='value_4') == 'value_4'
    assert get_tree_node(d, 'key_2:key_4', default=None) is None




# Generated at 2022-06-26 02:55:01.908676
# Unit test for function get_tree_node
def test_get_tree_node():
    from mock import MagicMock

    # Setup mock object for argument `mapping`

    # Setup mock object for argument `parent`

    # Setup mock object for argument `default`

    # Setup mock object for argument `key`

    # Execute function
    result = get_tree_node(
        mapping=mapping,
        key=key,
        default=default,
        parent=parent
    )

    # Check the result
    assert result == expected_result



# Generated at 2022-06-26 02:55:13.235452
# Unit test for function get_tree_node
def test_get_tree_node():
    # AssertionError: Namespace supplied, but not used in _namespace_key
    RegistryTree({}, namespace='bar')
    # AssertionError: Namespace supplied, but not used in _namespace_key
    RegistryTree({}, namespace='bar', initial_is_ref=True)
    # AssertionError: Namespace supplied, but not used in _namespace_key
    RegistryTree({}, namespace='bar', initial={})
    # AssertionError: initial_is_ref is True, but no initial specified.
    RegistryTree(initial={}, initial_is_ref=True)
    # AssertionError: initial_is_ref is True, but no initial specified.
    RegistryTree(initial_is_ref=True)
    # AssertionError: initial_is_ref is True, but no initial specified.
    RegistryTree

# Generated at 2022-06-26 02:55:21.935575
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = None
    # Assigning arguments
    var_0 = tree()
    var_1 = 'foo:bar:baz'
    var_2 = 'qux'

    # Call to set_tree_node
    set_tree_node(var_0, var_1, var_2)

    # Return type assertion
    assert isinstance(var_0, collections.defaultdict)
    assert var_0 == {'foo': {'bar': {'baz': 'qux'}}}



# Generated at 2022-06-26 02:55:25.461469
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()

    assert(mapping == {})

    set_tree_node(mapping, 'hello', 'world')
    assert(mapping == {'hello': 'world'})

    set_tree_node(mapping, 'a:b:c', 'test 2')
    assert(mapping == {'hello': 'world', 'a': {'b': {'c': 'test 2'}}})



# Generated at 2022-06-26 02:55:29.459010
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = b'hello:a:1'
    var_2 = b'test'
    var_3 = set_tree_node(var_0, var_1, var_2)
    assert var_3[var_1.split(':')[0]] == var_2



# Generated at 2022-06-26 02:55:41.211687
# Unit test for function get_tree_node
def test_get_tree_node():
    # Get tree node default case
    var_0 = tree()
    var_1 = get_tree_node(var_0, "bonus_xp")
    assert(var_1 == {})

    # Get tree node invalid key case
    var_0 = tree()
    try:
        var_1 = get_tree_node(var_0, "key:does:not:exist")
        assert(False)
    except KeyError:
        assert(True)

    # Get tree node invalid key default case
    var_0 = tree()
    var_1 = get_tree_node(var_0, "key:does:not:exist", default = "return this")
    assert(var_1 == "return this")

    # Get tree node default case
    var_0 = tree()
    var_0["bonus_xp"]

# Generated at 2022-06-26 02:56:11.999852
# Unit test for function get_tree_node
def test_get_tree_node():
    # Get value
    var_0 = tree()
    var_0['a']['b']['c'][1] = 2
    var_1 = get_tree_node(var_0, 'a:b:c:1')
    assert var_1 == 2, "var_1 == 2"
    # Get parent
    var_2 = get_tree_node(var_0, 'a:b:c:1', parent=True)
    del var_2[1]
    assert var_0['a']['b']['c'] == {}, "var_0['a']['b']['c'] == {}"
    # Handle bad keys

# Generated at 2022-06-26 02:56:20.784162
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = tree()
    var_2 = 'synchronizer'
    var_3 = 'sync'
    var_4 = 'salt'
    var_5 = 'salt'
    var_6 = 'salt'
    var_1[var_2][var_3][var_4] = var_5
    if not (var_6 == var_1[var_2][var_3][var_4]):
        raise Exception('AssertionError')



# Generated at 2022-06-26 02:56:22.711598
# Unit test for function get_tree_node
def test_get_tree_node():
    import doctest
    doctest.testmod()



# Generated at 2022-06-26 02:56:24.273191
# Unit test for function set_tree_node
def test_set_tree_node():
    return


# Generated at 2022-06-26 02:56:25.007566
# Unit test for function get_tree_node
def test_get_tree_node():
    assert var_0 == {}


# Generated at 2022-06-26 02:56:26.016941
# Unit test for function get_tree_node
def test_get_tree_node():
    # This is an auto-generated function.
    # Replace with actual unit test cases
    assert 1 == 1


# Generated at 2022-06-26 02:56:27.900143
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = lambda:collections.defaultdict(tree)
    mapping = tree()
    key = 0
    value = 0.0
    ret = None

    assert ret == set_tree_node(mapping, key, value)



# Generated at 2022-06-26 02:56:30.496861
# Unit test for function get_tree_node
def test_get_tree_node():
    # Monkey patching
    var_0 = {
        'a': {
            'b': 'c'
        }
    }
    var_1 = 'a:b'
    var_2 = get_tree_node(var_0, var_1)
    # Check if var_2 is equal to 'c'
    assert var_2 == 'c'


# Generated at 2022-06-26 02:56:42.803468
# Unit test for function get_tree_node
def test_get_tree_node():

    test_data = {'jelly': {'jam': {'spam': {'foo': 'bar'}}}}

    assert get_tree_node(test_data, 'jelly:jam:spam:foo') == 'bar'
    assert get_tree_node(test_data, 'jelly:jam:spam:foo', default=None) == 'bar'
    assert get_tree_node(test_data, 'jelly:jam:spam:baz', default=None) is None
    assert get_tree_node(test_data, 'jelly:jam:spam:baz', _sentinel) == 'wat'

    with pytest.raises(KeyError):
        get_tree_node(test_data, 'jelly:jam:spam:baz')

    pytest.raises(KeyError)

# Generated at 2022-06-26 02:56:44.974518
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 'This test needs an actual implementation' is True


# Generated at 2022-06-26 02:57:34.611583
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': {'baz': 'bizzle'}}}

    assert get_tree_node(mapping, 'foo:bar:baz') == 'bizzle'
    assert get_tree_node(mapping, 'foo:bar:durf', default='durf') == 'durf'
    assert get_tree_node(mapping, 'foo:bar', parent=True) == {'bar': {'baz': 'bizzle'}}
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 'bizzle'}



# Generated at 2022-06-26 02:57:44.951578
# Unit test for function get_tree_node
def test_get_tree_node():
    assert set_tree_node(tree(), 'test_key_test_key', 'test_key_test_key') == tree()
    assert get_tree_node(tree(), 'test_key_test_key', parent=True) == set_tree_node(tree(), 'test_key_test_key', 'test_key_test_key')
    assert get_tree_node(tree(), 'test_key_test_key', default=_sentinel, parent=True) == get_tree_node(tree(), 'test_key_test_key', default=_sentinel, parent=True)

# Generated at 2022-06-26 02:57:54.565736
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    var_2 = 'test'
    set_tree_node(var_1, key=var_2, value=99)
    var_3 = get_tree_node(var_1, key=var_2)
    var_4 = 99
    assert var_3 == var_4, "Expecting %s, got %s for variable '%s'" % (var_4, var_3, 'var_3')


# Generated at 2022-06-26 02:58:06.706325
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {}
    var_1 = get_tree_node(var_0, 'key_0', default=None)
    assert var_1 is None
    var_0['key_0'] = 'value_0'
    var_2 = get_tree_node(var_0, 'key_0', default=None)
    assert var_2 == 'value_0'
    var_3 = get_tree_node(var_0, 'key_1', default=None)
    assert var_3 is None
    var_0['key_1'] = 'value_1'
    var_4 = get_tree_node(var_0, 'key_1', default=None)
    assert var_4 == 'value_1'

# Generated at 2022-06-26 02:58:08.147113
# Unit test for function get_tree_node
def test_get_tree_node():
    pass # TODO


# Generated at 2022-06-26 02:58:15.482292
# Unit test for function get_tree_node
def test_get_tree_node():
    test_container = {'key_0': {'key_1': 'value_1'}}
    test_key = 'key_0:key_1'
    test_default = 'value_2'

    actual = get_tree_node(test_container, test_key, default=test_default)
    expected = 'value_1'
    assert actual == expected


# Generated at 2022-06-26 02:58:20.097463
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['b']['c'] = 'A'
    assert get_tree_node(var_0, 'a:b:c') == 'A'


# Generated at 2022-06-26 02:58:24.476530
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(var_0, 'foo:bar:baz', 'hello world') == (tree(), 'foo', tree(), 'bar', tree(), 'baz', 'hello world')


# Generated at 2022-06-26 02:58:29.761375
# Unit test for function get_tree_node
def test_get_tree_node():
    # Case 0
    mapping = {
        'mod': {
            'fixtures': {
                'lib': {
                    'cfg': {
                        'key': 'value'
                    }
                }
            }
        }
    }
    key = 'mod:fixtures:lib:cfg:key'
    expected_result = 'value'
    actual_result = get_tree_node(mapping, key, parent=True)
    print('Expected result: ', str(expected_result))
    print('Actual result: ', str(actual_result))
    assert str(expected_result) == str(actual_result)



# Generated at 2022-06-26 02:58:39.659706
# Unit test for function get_tree_node
def test_get_tree_node():
    # Create a mock mapping
    class MockMapping(object):
        def __init__(self, node=None):
            self.node = node

        def __getitem__(self, key):
            return self.node

        def __setitem__(self, key, value):
            self.node = value

    # Test with no dimensions
    key = 'foo'
    var_0 = tree()
    var_0[key] = 'bar'
    assert get_tree_node(var_0, key) == 'bar'

    # Test with one dimension, and a parent node.
    key = 'foo:bar'
    var_0 = tree()
    get_tree_node(var_0, key, parent=True)[key.split(':')[-1]] = 'baz'