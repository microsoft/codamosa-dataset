

# Generated at 2022-06-26 02:49:25.511608
# Unit test for function get_tree_node
def test_get_tree_node():
    # Arg test
    # Function test
    var_0 = tree()
    var_0['a']['b']['c'] = 'd'
    var_1 = get_tree_node(var_0, 'a:b:c', default=_sentinel)
    assert(var_1 == 'd')


# Generated at 2022-06-26 02:49:32.886347
# Unit test for function set_tree_node
def test_set_tree_node():
    m = tree()
    k = tree()
    v = tree()
    foo = tree()

    key = ':'.join(k)
    value = ':'.join(v)
    set_tree_node(m, key, value)

    namespace = 'foo'
    key = ':'.join([namespace] + k)
    set_tree_node(foo, key, value)

    m2 = RegistryTree()
    m2.register(key, value)

    m3 = RegistryTree()
    m3.register(k, value, namespace=namespace)



# Generated at 2022-06-26 02:49:33.703068
# Unit test for function get_tree_node
def test_get_tree_node():
    pass


# Generated at 2022-06-26 02:49:36.185993
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_0 = tree()
    tree_0['a']['b']['c'] = 'd'

    assert_equal(get_tree_node(tree_0, 'a:b:c'), 'd')



# Generated at 2022-06-26 02:49:38.523033
# Unit test for function get_tree_node
def test_get_tree_node():
    param0 = collections.defaultdict(tree)
    param1 = 'a:b:c:d'
    expected_result = None
    result = get_tree_node(param0, param1)
    assert result == expected_result



# Generated at 2022-06-26 02:49:43.846037
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    expected = None
    mapping = {}
    key = 'key'
    default = None

    # Invocation
    get_tree_node(
        mapping=mapping,
        key=key,
        default=default,
    )
    # Verification
    assert expected == result
    

# Generated at 2022-06-26 02:49:44.670799
# Unit test for function set_tree_node
def test_set_tree_node():
    pass



# Generated at 2022-06-26 02:49:47.405420
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup:
    mapping = tree()
    key = 'foo'
    default = _sentinel

    # Test:
    # Test:
    # Test:
    # Test:
    # Test:
    # Test:


# Generated at 2022-06-26 02:49:54.696190
# Unit test for function set_tree_node
def test_set_tree_node():
    var_5 = tree()
    assert var_5
    assert set_tree_node(var_5, 'test', 'foo') == var_5['test']
    assert set_tree_node(var_5, 'test:this', 'foo') == var_5['test']['this']
    assert set_tree_node(var_5, 'test:that', 'foo') == var_5['test']['that']
    assert var_5['test']['this'] == 'foo'
    assert var_5['test']['that'] == 'foo'


# Generated at 2022-06-26 02:49:55.708469
# Unit test for function set_tree_node
def test_set_tree_node():
    pass


# Generated at 2022-06-26 02:50:03.163510
# Unit test for function get_tree_node
def test_get_tree_node():
    d = collections.defaultdict(tree)
    d[1][2][3][5] = 10
    assert d[1][2][3][5] == 10
    assert d[0][0][0][0] == {}


# Generated at 2022-06-26 02:50:13.100359
# Unit test for function get_tree_node
def test_get_tree_node():
    # Set up test variables
    var_0 = {
    }
    var_1 = set(['foo', 'bar', 'baz', 'lol'])
    var_2 = {
        'list': [1, 2, 3, 4],
        'tuple': (1, 2, 3, 4),
        'set': var_1,
        'dict': {
            'foo': 1,
            'bar': 2,
            'baz': 3,
            'lol': 4
        }
    }
    var_3 = [
        var_1,
        var_2,
        'asdf',
        2
    ]
    var_4 = 'a:b:c:d'
    var_5 = 0

    # Get base case

# Generated at 2022-06-26 02:50:14.852822
# Unit test for function set_tree_node
def test_set_tree_node():
    assert(1 == 1)
    assert(1 == 2)


# Generated at 2022-06-26 02:50:25.376575
# Unit test for function set_tree_node
def test_set_tree_node():
    import mock

    patcher_mapping = mock.patch("%s.mapping" % __name__)
    patcher_key = mock.patch("%s.key" % __name__)
    patcher_value = mock.patch("%s.value" % __name__)
    patcher_parent = mock.patch("%s.parent" % __name__)
    patcher_namedtuple = mock.patch("%s.namedtuple" % __name__)
    patcher_basename = mock.patch("%s.basename" % __name__)
    patcher_dirname = mock.patch("%s.dirname" % __name__)
    patcher_parent_node = mock.patch("%s.parent_node" % __name__)
    patcher_key = patcher_key.start()

# Generated at 2022-06-26 02:50:31.263593
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_node_0 = set_tree_node(var_0, 'var_0', 'var_1')
    test_0 = get_tree_node(var_0, 'var_0')
    assert(test_0 == 'var_1')
    tree_node_1 = set_tree_node(var_0, 'var_0', 'var_1')
    test_1 = get_tree_node(var_0, 'var_0')
    assert(test_1 == 'var_1')




# Generated at 2022-06-26 02:50:41.219607
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_node_0 = tree()
    set_tree_node(tree_node_0, "1", 48)
    set_tree_node(tree_node_0, "0:5", 40)
    set_tree_node(tree_node_0, "2", 13)
    set_tree_node(tree_node_0, "0:5:1", 15)
    set_tree_node(tree_node_0, "0:0", 38)
    set_tree_node(tree_node_0, "0:0:2", 22)
    set_tree_node(tree_node_0, "0:0:2:1", 28)
    set_tree_node(tree_node_0, "2:2", 49)

# Generated at 2022-06-26 02:50:44.231022
# Unit test for function get_tree_node
def test_get_tree_node():

    var_0 = collections.defaultdict(get_tree_node)


# Generated at 2022-06-26 02:50:53.941838
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['foo']['bar']['baz'] = {'yo': 'dawg'}
    assert var_0['foo:bar:baz']['yo'] == 'dawg'
    assert var_0['foo:bar']['baz']['yo'] == 'dawg'
    assert var_0['foo']['bar:baz']['yo'] == 'dawg'
    assert var_0['foo']['bar:baz']['yo'] == 'dawg'
    assert get_tree_node(var_0, 'foo:bar:baz', default='test') == 'test'

    tree_obj = Tree()
    tree_obj['foo']['bar']['baz'] = 'dawg'
   

# Generated at 2022-06-26 02:50:55.246678
# Unit test for function get_tree_node
def test_get_tree_node():
    assert True


# Generated at 2022-06-26 02:51:07.017568
# Unit test for function set_tree_node
def test_set_tree_node():
    class filter_0(object):
        def __init__(self, *args):
            self.args = args
        def __or__(self, other):
            return filter_0(other, *self.args)
        def __call__(self, arg):
            for each in self.args:
                if not each(arg): return False
            return True
        def __invert__(self):
            return filter_0(*[~i for i in self.args])

    t0 = filter_0(lambda x : x > 1)
    t1 = filter_0(lambda x : x % 2 == 0, lambda x : x < 10)
    # Assign t1, filter_0 to filter_1
    filter_1 = t1
    # Assign filter_0 to filter_2
    filter_2 = filter_0


# Generated at 2022-06-26 02:51:23.347528
# Unit test for function get_tree_node
def test_get_tree_node():
    assert_raises(Exception, get_tree_node, var_0, 'a', _sentinel)
    assert_equals(get_tree_node(var_0, 'a', 8), 8)
    assert_equals(get_tree_node(var_0, 'a', 0), 0)
    assert_equals(get_tree_node(var_0, 'a', 'c'), 'c')
    assert_equals(get_tree_node(var_0, 'a', 4), 4)
    assert_equals(get_tree_node(var_0, 'a', 6), 6)
    assert_equals(get_tree_node(var_0, 'a', 0), 0)
    assert_equals(get_tree_node(var_0, 'a', 'test'), 'test')
   

# Generated at 2022-06-26 02:51:30.545164
# Unit test for function set_tree_node
def test_set_tree_node():
    expected = 'var_1'
    actual = set_tree_node(var_0, "node:node_2:node_3:node_4:node_5", expected)
    assert actual['node']['node_2']['node_3']['node_4']['node_5'] == expected

    expected = 'var_2'
    actual = set_tree_node(var_0, "node:node_2:node_3:node_4", expected)
    assert actual['node']['node_2']['node_3']['node_4'] == expected

    expected = 'var_3'
    actual = set_tree_node(var_0, "node:node_2:node_3", expected)

# Generated at 2022-06-26 02:51:36.134277
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        'foo' : {
            'bar' : {
                'baz' : 'qux'
            }
        }
    }

    set_tree_node(mapping, 'foo:bar:baz', 'fux')
    assert mapping['foo']['bar']['baz'] == 'fux'



# Generated at 2022-06-26 02:51:37.093119
# Unit test for function set_tree_node
def test_set_tree_node():
    assert True


# Generated at 2022-06-26 02:51:45.443145
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = tree()
    var_1["foo"]["bar"]["baz"] = "foobarbaz"
    var_2 = get_tree_node(var_1, "foo:bar:baz")
    assert var_2 == "foobarbaz"
    var_3 = get_tree_node(var_1, "foo:bar:baz", parent=True)
    assert var_3["baz"] == "foobarbaz"
    var_4 = get_tree_node(var_1, "foo:bar:baz", default="default")
    assert var_4 == "foobarbaz"


# Generated at 2022-06-26 02:51:49.336235
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c', _sentinel)


# Generated at 2022-06-26 02:51:56.541745
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    set_tree_node(var_1, 'a', 5)
    set_tree_node(var_1, 'a:b:c', 10)
    set_tree_node(var_1, 'a:b:d', 20)
    # Using `get_tree_node()` to check because `tree()` does not define a `__repr__` function
    assert get_tree_node(var_1, 'a:b:c') == 10
    assert get_tree_node(var_1, 'a:b:d') == 20
    # Assert that a simple test case works
    assert 5 == 5

    # Test with identical variable names
    var_1 = tree()
    set_tree_node(var_1, 'a', 5)

# Generated at 2022-06-26 02:52:07.746536
# Unit test for function get_tree_node
def test_get_tree_node():
    try:
        # Test case 0:
        assert get_tree_node(var_0, 'a:b:c:d') == 'foo'
        assert get_tree_node(var_0, 'a:b:c:d', default=None) == 'foo'
        assert get_tree_node(var_0, 'a:b:e:f', default=None) == None
        assert get_tree_node(var_0, 'a:b:c:d', default=22) == 'foo'
        assert get_tree_node(var_0, 'a:b:e:f', default=22) == 22
        assert get_tree_node(var_0, 'a:b:e:f') == _sentinel

    except AssertionError as error:
        print(error)
        raise Assert

# Generated at 2022-06-26 02:52:14.547720
# Unit test for function get_tree_node
def test_get_tree_node():

    a = Tree()
    a[1, 2] = 3
    assert a[1, 2] == 3

    assert 'a' in a
    with pytest.raises(KeyError):
        a['a']['b']

    a['a']['b'] = 1
    assert a['a']['b'] == 1
    a['a']['b'] = 2
    assert a['a']['b'] == 2

    assert 'a:b' in a
    assert a['a:b'] == 2
    a['a:b'] = 3
    assert a['a:b'] == 3

    a['a']['c'] = 3

    assert a['a']['b'] == 3
    assert a['a:b'] == 3


# Generated at 2022-06-26 02:52:17.873562
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, 'foo', 1)
    set_tree_node(var_0, 'foo:bar', 2)
    assert var_0['foo']['bar'] == 2


# Generated at 2022-06-26 02:52:31.868628
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = OrderedDict()
    var_1 = {'k1': 'v1', 'k2': var_0}
    var_0['k3'] = 'v3'
    var_0['k4'] = [1, 2, 3]
    var_0['k5'] = {'k6': 'v6'}
    var_2 = var_0['k5']
    var_3 = var_1['k2']
    var_4 = 'k2'
    var_5 = ':'.join([var_4, 'k3'])
    var_6 = ':'.join([var_4, 'k4'])
    var_7 = ':'.join([var_4, 'k5'])

# Generated at 2022-06-26 02:52:32.779199
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 1 == 1



# Generated at 2022-06-26 02:52:38.891767
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['a']['b']['1'] = 'c'
    t['a']['b']['2'] = 'd'
    assert get_tree_node(t['a'], 'b:1') == 'c'
    assert get_tree_node(t['a'], 'b:2') == 'd'

# Generated at 2022-06-26 02:52:44.020428
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:52:50.394658
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, 'a:b:c:d:e:f:g:h:i', 'A very long string')
    assert var_0['a:b:c:d:e:f:g:h:i'] == 'A very long string'

    # TODO: Set self.elements in OrderableTestCase (Line:27)
    try:
        set_tree_node(var_0, 'a:b:c:d:e:f:g:h:i', 'A very long string')
    except KeyError:
        pass
    else:
        assert False



# Generated at 2022-06-26 02:53:00.666186
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    assert get_tree_node(var_0, 'root:layer_0', default=None, parent=False) is None, "Failed to set root:layer_0 on var_0"
    var_0['root']['layer_0'] = 'somevalue'
    assert get_tree_node(var_0, 'root:layer_0', default=None, parent=False) == 'somevalue', "Failed to set root:layer_0 on var_0"
    var_0['root']['layer_0']['layer_1'] = 'somevalue'

# Generated at 2022-06-26 02:53:09.363358
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'key': {
            'foo': 'bar',
            'lorem': {
                'ipsum': 'dolor'
            }
        }
    }
    assert get_tree_node(mapping, 'key') == mapping['key']
    assert get_tree_node(mapping, 'key:lorem') == mapping['key']['lorem']
    assert get_tree_node(mapping, 'key:lorem:ipsum') == mapping['key']['lorem']['ipsum']
    assert get_tree_node(mapping, 'lorem:ipsum') == 'dolor'



# Generated at 2022-06-26 02:53:20.287121
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()

    assert get_tree_node(var_0, ':') is var_0

    var_0[":foo"] = "bar"
    assert get_tree_node(var_0, ':foo') == "bar"
    assert get_tree_node(var_0, ':foo', default=None) == "bar"
    assert get_tree_node(var_0, ':foo', default=None, parent=True) is var_0

    assert get_tree_node(var_0, ':foo:bar') is not None
    assert get_tree_node(var_0, ':foo:bar') == dict()

    assert get_tree_node(var_0, ':foo:baz', default=None) is None


# Generated at 2022-06-26 02:53:22.311489
# Unit test for function get_tree_node
def test_get_tree_node():
    assert tree()[None][None][None] == tree()


# Generated at 2022-06-26 02:53:29.676187
# Unit test for function set_tree_node
def test_set_tree_node():
    case0 = tree()
    set_tree_node(case0, 'foo:bar:baz', 'Hi!')
    set_tree_node(case0, 'foo:bar', 'Hi!') # This should probably raise an error.
    assert case0['foo']['bar']['baz'] == 'Hi!'


if __name__ == '__main__':
    # Test case inspection
    test_case_0()

    test_set_tree_node()

# Generated at 2022-06-26 02:53:41.599270
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = [None] * 9
    var_0[0] = 1
    var_0[1] = 2
    var_0[2] = 3
    var_0[3] = 4
    var_0[4] = 5
    var_0[5] = 6
    var_0[6] = 7
    var_0[7] = 8
    var_0[8] = 9
    var_0[3] = {}
    set_tree_node(var_0[3], '4:5:6', 'hello')
    var_0[0] = "hello world"
    print(get_tree_node(var_0[3], '4:5:6'))


# Generated at 2022-06-26 02:53:51.227696
# Unit test for function get_tree_node
def test_get_tree_node():
    def check(mapping, key, default, parent):
        assert get_tree_node(mapping, key, default=default, parent=parent) == \
            mapping[key] if parent else mapping[key]

    check(var_0, 'foo:bar', _sentinel, parent=True)
    check(var_0, 'foo:bar', _sentinel, parent=False)
    check(var_0, 'foo:bar:baz', _sentinel, parent=True)
    check(var_0, 'foo:bar:baz', _sentinel, parent=False)
    check(var_0, 'foo:bar:baz:moo', _sentinel, parent=True)
    check(var_0, 'foo:bar:baz:moo', _sentinel, parent=False)

# Generated at 2022-06-26 02:53:53.583578
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    assert var_0 is not None



# Generated at 2022-06-26 02:53:59.296389
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {'muh': {'muh': 'muh'}}
    get_tree_node(test_tree, 'muh')
    # assert get_tree_node(test_tree, 'muh') == {'muh': 'muh'}

    # Should raise KeyError, unless we catch it



# Generated at 2022-06-26 02:54:09.822604
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = None
    var_0 = get_tree_node(var_0, '', (lambda a, *args: a))
    var_1 = None
    var_2 = None
    var_2 = get_tree_node(var_1, '', (lambda a, *args: a))
    var_3 = True
    var_2 = getattr(var_1, '', (lambda a, *args: a))
    var_4 = True
    var_2 = getattr(var_1, '', (lambda a, *args: a))
    var_5 = var_2


# Generated at 2022-06-26 02:54:11.622703
# Unit test for function get_tree_node
def test_get_tree_node():
    assert True == True


# Generated at 2022-06-26 02:54:21.269369
# Unit test for function get_tree_node
def test_get_tree_node():
    # See if mapping stuff works
    tree = Tree({'dimensions': {'height': 480, 'width': 640}})
    assert get_tree_node(tree, 'dimensions:width') == 640
    assert get_tree_node(tree, 'dimensions:height') == 480

    # See if default works
    assert get_tree_node(tree, 'dimensions:foo', default='bar') == 'bar'
    try:
        get_tree_node(tree, 'dimensions:foo')
    except KeyError:
        pass
    else:
        raise AssertionError('get_tree_node did not raise KeyError')


# Generated at 2022-06-26 02:54:22.644016
# Unit test for function get_tree_node
def test_get_tree_node():
    test_case_0()


# Generated at 2022-06-26 02:54:29.021744
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['bla']['bla'] = 'bla'
    assert get_tree_node(var_0, 'bla:bla') == 'bla'


if __name__ == "__main__":
    test_get_tree_node()

# Generated at 2022-06-26 02:54:35.132347
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    key = "alpha"
    value = "beta"
    result = mapping
    assert (isinstance(result, collections.defaultdict))
    assert (isinstance(result, collections.defaultdict))
    assert (result[key] == value)


# Generated at 2022-06-26 02:54:50.729608
# Unit test for function set_tree_node
def test_set_tree_node():
    result = set_tree_node({}, 'hi:mom', 'hello')
    assert result == {'hi': {'mom': 'hello'}}
    result = set_tree_node({'hi': {'mom': 'hello'}}, 'hi:mom:dad', 'hello')
    assert result == {'hi': {'mom': {'dad': 'hello'}}}



# Generated at 2022-06-26 02:54:54.128807
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'test') is _sentinel
    test_case_0()


# Generated at 2022-06-26 02:54:56.930798
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = set_tree_node(test_case_0(), 'adam:test:test2:test:test2', 'test_set_tree_node_0')


# Generated at 2022-06-26 02:55:03.663091
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:55:10.733910
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = tree()
    var_0['AAA']['BBB'] = var_1
    var_2 = var_1
    get_tree_node(var_0, 'AAA:BBB')  # expected ()
    get_tree_node(var_0, 'AAA:CCC')  # expected KeyError('AAA:CCC')


# Generated at 2022-06-26 02:55:23.066117
# Unit test for function get_tree_node
def test_get_tree_node():
    class Test(object):
        def __init__(self, **kwargs):
            self.data = collections.defaultdict(dict)
            self.data.update(kwargs)

        def __getitem__(self, key):
            return self.data[key]

        def __setitem__(self, key, value):
            self.data[key].update(value)

    test = Test(a=tree(), b=tree(c=tree(d=tree())))

    assert get_tree_node(test, 'a:b:c:d') is None
    assert get_tree_node(test, 'a:b:c:d', default=5) == 5
    assert get_tree_node(test, 'b:c:d') is None


# Generated at 2022-06-26 02:55:28.208444
# Unit test for function get_tree_node
def test_get_tree_node():
    assert repr(get_tree_node(None, 'foo')) == repr(None)
    assert repr(get_tree_node(None, 'foo', default=None)) == repr(None)
    assert repr(get_tree_node(None, 'foo', default='')) == repr('')
    assert repr(get_tree_node({}, 'foo')) == repr(None)
    assert repr(get_tree_node({}, 'foo', default=None)) == repr(None)
    assert repr(get_tree_node({}, 'foo', default='')) == repr('')
    assert repr(get_tree_node({'foo': 'bar'}, 'foo', default=None)) == repr('bar')

# Generated at 2022-06-26 02:55:29.757962
# Unit test for function get_tree_node
def test_get_tree_node():
    """Function has no unit test"""
    pass


# Generated at 2022-06-26 02:55:34.963603
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_1 = set_tree_node(var_0, 'a:b:c', 'value')
    assert var_1 == {'b': {'c': 'value'}}



# Generated at 2022-06-26 02:55:37.523559
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'asdfg') == tree()


# Generated at 2022-06-26 02:56:05.457363
# Unit test for function set_tree_node
def test_set_tree_node():
    obj = tree()
    return set_tree_node(obj, 'a:b:c:d', 'value') is not None


# Generated at 2022-06-26 02:56:10.393558
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = {}
    assert set_tree_node(var_0, "var_1", 1) == {}
    assert var_0 == {"var_1": 1}
    assert set_tree_node(var_0, "var_5:var_5", 1) == {"var_5": {}}
    assert var_0 == {"var_5": {"var_5": 1}, "var_1": 1}
    assert set_tree_node(var_0, "var_5:var_5", 1) == {"var_5": {}}
    assert var_0 == {"var_5": {"var_5": 1}, "var_1": 1}

# Generated at 2022-06-26 02:56:14.387367
# Unit test for function get_tree_node
def test_get_tree_node():
    assert(get_tree_node({'foo': {'bar': {'baz': 'qux'}}}, 'foo:bar:baz') == 'qux')



# Generated at 2022-06-26 02:56:23.635842
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Checks `get_tree_node` so that it is used properly with all the different types of arguments
    """

    get_tree_node()
    get_tree_node(mapping=None)
    get_tree_node(key=None)
    get_tree_node(default=None)
    get_tree_node(parent=None)
    get_tree_node(mapping=None, key=None)
    get_tree_node(mapping=None, default=None)
    get_tree_node(mapping=None, parent=None)
    get_tree_node(key=None, default=None)
    get_tree_node(key=None, parent=None)
    get_tree_node(default=None, parent=None)

# Generated at 2022-06-26 02:56:26.269287
# Unit test for function get_tree_node
def test_get_tree_node():
    print("Test get_tree_node")
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 02:56:28.399629
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_0['a']['b']['c'] = 1
    assert set_tree_node(var_0, 'a:b:c', 2) == var_0['a']['b']



# Generated at 2022-06-26 02:56:32.384995
# Unit test for function get_tree_node
def test_get_tree_node():
    test = tree()
    test['foo']['bar']['baz'] = 'foo'
    assert get_tree_node(test, 'foo:bar:baz') == 'foo'
    assert get_tree_node(test, 'foo:bar') == tree(baz='foo')

    assert get_tree_node(test, 'foo:qux') is _sentinel
    try:
        get_tree_node(test, 'foo:qux')
    except KeyError:
        pass
    else:
        assert False

    assert get_tree_node(test, 'foo:qux', default='foo') == 'foo'



# Generated at 2022-06-26 02:56:34.678222
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node() == {}



# Generated at 2022-06-26 02:56:39.547539
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'key':'value'}
    key = 'key:value'
    expected = 'value'
    actual = get_tree_node(mapping, key)
    assert actual == expected



# Generated at 2022-06-26 02:56:45.975174
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['b']['c'] = 'd'
    var_0['a']['b']['e'] = 'f'
    var_0['a']['g']['h'] = 'i'
    var_0['j']['k']['l'] = 'm'
    var_0['j']['k']['n'] = 'o'
    var_0['j']['p']['q'] = 'r'
    val_0 = get_tree_node(var_0, 'a:b')
    val_1 = get_tree_node(var_0, 'a:b:c')
    val_2 = get_tree_node(var_0, 'a:b:e')
    val_3

# Generated at 2022-06-26 02:57:43.876322
# Unit test for function get_tree_node
def test_get_tree_node():
    node = ('var_0', 'var_0', 'var_0')
    assert get_tree_node(node, 'var_0:var_0') == var_0
    return 'test_get_tree_node passed.'



# Generated at 2022-06-26 02:57:47.186943
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(None, "test_key", "test_value") is None


# Generated at 2022-06-26 02:57:49.073852
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree, 'a') == tree


# Generated at 2022-06-26 02:57:54.632217
# Unit test for function get_tree_node

# Generated at 2022-06-26 02:58:01.667064
# Unit test for function set_tree_node
def test_set_tree_node():
    assert get_tree_node(test_case_0, 'a:b:c', default=None) is None
    set_tree_node(test_case_0, 'a:b:c', 'd')
    assert get_tree_node(test_case_0, 'a:b:c') == 'd'



# Generated at 2022-06-26 02:58:08.952765
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = 'a:b:c'
    var_2 = get_tree_node(var_0, var_1)
    assert var_2 == var_0['a']['b']['c']
    var_2 = get_tree_node(var_0, 'a:b')
    assert var_2 == var_0['a']['b']
    var_2 = get_tree_node(var_0, 'a')
    assert var_2 == var_0['a']
    var_2 = get_tree_node(var_0, var_1, parent=True)
    assert var_2 == var_0['a']['b']
    var_2 = get_tree_node(var_0, 'a:b', parent=True)
   

# Generated at 2022-06-26 02:58:13.170544
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_0[0]['foo'] = 'bar'
    assert var_0[0]['foo'] == 'bar'


# Generated at 2022-06-26 02:58:14.578282
# Unit test for function set_tree_node
def test_set_tree_node():
    assert tree()
    return True

# Generated at 2022-06-26 02:58:26.848583
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'foo'
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == 'foo'
    assert get_tree_node(tree, 'a:b:d') is None
    assert get_tree_node(tree, 'a:b:d', parent=True) == {'c': 'foo'}
    assert get_tree_node(tree, 'a:b:d', '', parent=True) == {'c': 'foo'}
    assert get_tree_node(tree, 'a:b:d', 'foobar') == 'foobar'
    assert get_tree_node(tree, 'a:b:d', parent=True) == 'foobar'
    assert get_tree

# Generated at 2022-06-26 02:58:38.920849
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = {'key': 'value', 'nested': {'test': 'stuff'}}
    expected_0 = {'key': 'new-value', 'nested': {'test': 'stuff'}}
    result_0 = set_tree_node(var_0, 'key', 'new-value')
    assert result_0 is var_0
    assert result_0 == expected_0

    result_1 = set_tree_node(var_0, 'nested:test', 'otherstuff')
    assert result_1 is var_0['nested']
    assert result_1 == {'test': 'otherstuff'}
    assert var_0 == {'key': 'new-value', 'nested': {'test': 'otherstuff'}}

    var_1 = {'test': 'stuff'}
    set_tree