

# Generated at 2022-06-26 02:49:31.047626
# Unit test for function get_tree_node
def test_get_tree_node():
    print('Testing get_tree_node')

    try:
        iter(get_tree_node(None, None, None, None))
    except TypeError:
        pass
    else:
        assert False
    # Basic test: simple values
    assert get_tree_node({1: 2, 3: 4}, '1', None, None) == 2
    assert get_tree_node({'a': 'b', 'c': 'd'}, 'c', None, None) == 'd'
    # Basic test: simple values, parent lookup
    assert get_tree_node({1: 2, 3: 4}, '1', None, True) == {1: 2, 3: 4}
    assert get_tree_node({2: 3, 4: 5}, '1:2:3', None, True) == {2: 3, 4: 5}

# Generated at 2022-06-26 02:49:38.634334
# Unit test for function get_tree_node
def test_get_tree_node():

    # Path: C:\Users\Jano\PycharmProjects\pycobertura\tests\utils\test_tree.py
    from utils.test_tree import test_get_tree_node
    from utils.tree import get_tree_node

    var_2 = tree()
    var_2['foo']['bar']['baz'] = 'x'

    var_3 = get_tree_node(var_2, 'foo:none:none')
    assert var_3 == {'bar': {'baz': 'x'}}

    var_4 = get_tree_node(var_2, 'foox:none:none', default=0)
    assert var_4 == 0

    var_5 = get_tree_node(var_2, 'foo:barx:none', default=0)
   

# Generated at 2022-06-26 02:49:46.828240
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = {}
    var_i = 'test'
    var_j = set_tree_node(var_1, var_i, '')
    assertEqual(var_j==None, True)
    assertEqual(var_1=={'test': ''}, True)
    var_i = 'test:level'
    var_j = set_tree_node(var_1, var_i, '')
    assertEqual(var_j==None, True)
    assertEqual(var_1=={'test': {'level': ''}}, True)


# Generated at 2022-06-26 02:49:49.824515
# Unit test for function set_tree_node
def test_set_tree_node():
    assert 'Test'
    assert True
    assert False
    # TODO Write a test case
    # assert tree == set_tree_node(mapping, key, value)


# Generated at 2022-06-26 02:49:52.371735
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': 'c'}}
    assert get_tree_node(mapping, 'a:b') == 'c'



# Generated at 2022-06-26 02:49:54.539173
# Unit test for function set_tree_node
def test_set_tree_node():
    assert tree_0 == set_tree_node(test_case_0, 'A', 'B')
    assert var_0 == tree_0



# Generated at 2022-06-26 02:50:05.899441
# Unit test for function get_tree_node
def test_get_tree_node():
    root = tree()
    node = root

# Generated at 2022-06-26 02:50:14.044188
# Unit test for function get_tree_node
def test_get_tree_node():

    tree_0 = {}
    tree_0['0'] = {
        '0': 'A',
        '1': 'B',
        '2': 'C',
        '3': {
            '0': 'D',
            '1': 'E'
        }
    }
    tree_0['1'] = {
        '0': 'F',
        '1': 'G',
        '2': 'H',
        '3': {
            '0': 'I',
            '1': 'J'
        }
    }
    tree_0['2'] = {
        '0': 'K',
        '1': 'L',
        '2': 'M',
        '3': {
            '0': 'N',
            '1': 'O'
        }
    }


# Generated at 2022-06-26 02:50:20.773625
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = tree()
    set_tree_node(tree, 'foo:bar:baz', 'value')
    assert tree['foo']['bar']['baz'] == 'value'
    set_tree_node(tree, 'foo:bar:baz', 'value')
    assert tree['foo']['bar']['baz'] == 'value'
    set_tree_node(tree, 'foo:bar:baz', 'value')
    assert tree['foo']['bar']['baz'] == 'value'



# Generated at 2022-06-26 02:50:26.860974
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0.update({'a': {'b': {'c': 1}}})
    assert get_tree_node(mapping=var_0, key='a:b:c') == 1
    assert get_tree_node(mapping=var_0, key='a', parent=True) == {'b': {'c': 1}}


# Generated at 2022-06-26 02:50:30.398355
# Unit test for function set_tree_node
def test_set_tree_node():
    # TODO: Implement test for set_tree_node
    pass

# Generated at 2022-06-26 02:50:40.751624
# Unit test for function get_tree_node
def test_get_tree_node():
    print('Testing get_tree_node...')
    input_data = {
        'a': {
            'b': {
                'c': 10
            }
        },
        'd': {
            'e': {
                'f': 11
            }
        },
        'g': {
            'h': {
                'i': 12
            }
        }
    }

    # Test case 0
    print('Test 0...')
    print('Test 0 input:')
    pprint({'mapping': input_data, 'key': 'a:b:c'})
    print('Test 0 output:')
    pprint(get_tree_node(input_data, 'a:b:c'))

    # Test case 1
    print('Test 1...')
    print('Test 1 input:')
    pprint

# Generated at 2022-06-26 02:50:42.058639
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO: Implement test here
    assert True



# Generated at 2022-06-26 02:50:49.888303
# Unit test for function get_tree_node
def test_get_tree_node():

    # Get value from dict
    test_dict = {'a':{'b':{'c':'foo'}}}
    assert get_tree_node(test_dict, 'a:b:c') == 'foo'

    # Get value from dict
    test_dict = {'a':{'b':{'c':'foo'}}}
    assert get_tree_node(test_dict, 'a:b') == {'c':'foo'}


# Generated at 2022-06-26 02:50:56.553961
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['foo']['bar']['baz'] = 'fubar'
    assert get_tree_node(var_0, 'foo:bar:baz') == 'fubar'
    assert get_tree_node(var_0, 'foo:bar:baz', parent=True)['baz'] == 'fubar'
    with pytest.raises(KeyError):
        get_tree_node(var_0, 'foo:bar:baz:quux')
    with pytest.raises(KeyError):
        get_tree_node(var_0, 'quux:bar:baz')


# Generated at 2022-06-26 02:51:05.091211
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = tree()
    var_1['BEFORE']['AFTER'] = 'VALUE'
    var_1['BEFORE']['BEFORE']['AFTER'] = 'VALUE'
    var_1['BEFORE']['BEFORE']['BEFORE']['AFTER'] = 'VALUE'
    result = get_tree_node(var_1, 'BEFORE:AFTER')
    assert(result == 'VALUE')
    result = get_tree_node(var_1, 'BEFORE:BEFORE:AFTER')
    assert(result == 'VALUE')
    result = get_tree_node(var_1, 'BEFORE:BEFORE:BEFORE:AFTER')
    assert(result == 'VALUE')

# Generated at 2022-06-26 02:51:22.104943
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Run test for get_tree_node
    """

    # Test
    test_var_0 = tree()
    test_var_1 = test_var_0['b']['a'] = 'z'
    test_var_2 = test_var_1['b']['a']['z']['b']['a']['z']['b']['a']['z'] = 'b'
    test_var_3 = get_tree_node(test_var_0, 'b')
    test_var_4 = get_tree_node(test_var_0, 'b:a')
    test_var_5 = get_tree_node(test_var_0, 'b:a:z:b:a:z:b:a:z')


# Generated at 2022-06-26 02:51:26.003107
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = {'a': {'b': {'c': 'd'}}}

    var_0 = get_tree_node(var_1, 'a:b:c')
    if var_0 != 'd':
        raise AssertionError('Value mismatch.')


# Generated at 2022-06-26 02:51:30.108639
# Unit test for function set_tree_node
def test_set_tree_node():
    assert (set_tree_node({}, 'foo:bar', 1) == {'foo': {'bar': 1}})
    assert (set_tree_node({'foo': {}}, 'foo:bar', 1) == {'foo': {'bar': 1}})
    mapping = {'foo': {}}
    set_tree_node(mapping, 'foo:bar', 1)
    assert (mapping == {'foo': {'bar': 1}})



# Generated at 2022-06-26 02:51:35.505460
# Unit test for function get_tree_node
def test_get_tree_node():
    test_0 = tree()
    test_1 = get_tree_node(test_0, 'var_0')
    test_1 = {'var_0': 'var_0'}
    test_2 = get_tree_node(test_0, 'var_0')

    assert test_0 == test_1
    assert test_0 == test_2


# Generated at 2022-06-26 02:51:44.084299
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a']['b'] = {'c': {'d': 'e'}}
    pass
    assert(var_0 == {
        'a': {
            'b': {
                'c': {
                    'd': 'e'
                }
            }
        }
    })
    assert(get_tree_node(var_0, 'a:b:c') == {'d': 'e'})



# Generated at 2022-06-26 02:51:53.281158
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'a': {
            'b': {
                'c': 'd',
            },
        },
    }
    # Exact match
    assert get_tree_node(data, 'a:b:c') == 'd'
    # Partial match
    assert get_tree_node(data, 'a:b') == {'c': 'd'}
    # Null match
    assert get_tree_node(data, 'a:f') is None
    # Key not found, default not specified.
    try:
        get_tree_node(data, 'x:x:x')
    except KeyError:
        pass
    else:
        assert False
    # Key not found, default specified.
    assert get_tree_node(data, 'x:x:x', default='default') == 'default'

# Generated at 2022-06-26 02:51:59.248689
# Unit test for function get_tree_node
def test_get_tree_node():
    # Get a node with a valid key
    sample_dict = {'test': {'test1': 'test2'}}
    test = get_tree_node(sample_dict, 'test:test1')
    assert test == 'test2', "get_tree_node failed to fetch a valid node"
    print("test_get_tree_node OK")


# Generated at 2022-06-26 02:52:00.324262
# Unit test for function get_tree_node
def test_get_tree_node():
    assert 0


# Generated at 2022-06-26 02:52:01.314608
# Unit test for function get_tree_node
def test_get_tree_node():
    assert False


# Generated at 2022-06-26 02:52:11.196045
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_1 = tree()
    for var_4 in range(10):
        var_5 = tree()
        for var_6 in range(10):
            var_7 = tree()
            for var_8 in range(10):
                var_9 = tree()
                for var_10 in range(10):
                    var_9[var_10] = (var_10 + (((var_8 + (((var_6 + ((var_4 * 10) + var_5)) * 10) + var_7)) * 10) + var_9))
                var_7[var_8] = var_9
            var_5[var_6] = var_7
        var_1[var_4] = var_5

    for var_4 in range(10):
        var_5 = tree

# Generated at 2022-06-26 02:52:20.496503
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(var_0, '', _sentinel) == _sentinel
    assert get_tree_node(var_0, '', _sentinel, True) == _sentinel
    assert get_tree_node(var_0, '', _sentinel, False) == _sentinel
    assert get_tree_node(var_0, '', _sentinel, False) == _sentinel
    assert get_tree_node(var_0, '', _sentinel, False) == _sentinel
    assert get_tree_node(var_0, '', _sentinel, False) == _sentinel
    assert get_tree_node(var_0, '', _sentinel, False) == _sentinel
    assert get_tree_node(var_0, '', _sentinel, False) == _sentinel
   

# Generated at 2022-06-26 02:52:24.554630
# Unit test for function get_tree_node
def test_get_tree_node():
    # Raise exception if not found
    try:
        get_tree_node(LokiConfig, 'dummy')
    except KeyError:
        pass
    # Try to get with a default
    assert get_tree_node(LokiConfig, 'dummy', 'default') == 'default'

# Generated at 2022-06-26 02:52:30.838821
# Unit test for function set_tree_node
def test_set_tree_node():
    imports = {
        'pip-requires': 'pip_requires',
        'requirements': 'extra/requirements',
        'entry_points': 'entry_points',
        'setuptools': 'extra/setuptools',
        'console_scripts': 'console_scripts',
    }
    for prefix, value in imports.items():
        tree_0 = set_tree_node(tree(), prefix, value)


# Generated at 2022-06-26 02:52:36.248149
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = tree()
    test_mapping['a']['b']['c'] = 1
    assert(get_tree_node(test_mapping, 'a:b:c') == 1)
    assert(get_tree_node(test_mapping, 'a:b', parent=True) == {'c': 1})
    assert(get_tree_node(test_mapping, 'a:b:c:d') is None)


# Generated at 2022-06-26 02:52:46.052479
# Unit test for function get_tree_node
def test_get_tree_node():
    foo_bar_1 = {'foo': {'bar': 'spam'}}

    assert(get_tree_node(foo_bar_1, 'foo:bar')) == 'spam', "get_tree_node didn't return spam from foo:bar"


# Generated at 2022-06-26 02:52:49.821252
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_0 = set_tree_node(var_0, "a", 1)
    assert var_0["a"] == 1


# Generated at 2022-06-26 02:52:54.360392
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = dict()
    var_1 = get_tree_node(var_0, 'key_0')
    assert var_1 is None
    pass


# Generated at 2022-06-26 02:52:57.233130
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': {'baz': 4}}}
    assert get_tree_node(mapping, 'foo:bar:baz') == 4


# Generated at 2022-06-26 02:52:59.273373
# Unit test for function set_tree_node
def test_set_tree_node():
    # TODO
    return None


# Generated at 2022-06-26 02:53:07.397994
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = {'example': {'sub-example': {'sub-sub-example': 'sub-sub-sub-example value'}}}
    var_1 = get_tree_node(var_0, 'example:sub-example:sub-sub-example')
    assert var_1 == 'sub-sub-sub-example value'
    var_2 = get_tree_node(var_0, 'example:sub-example:sub-sub-example2')
    assert var_2 == _sentinel
    var_3 = get_tree_node(var_0, 'example:sub-example:sub-sub-example2', default='default value')
    assert var_3 == 'default value'


# Generated at 2022-06-26 02:53:14.352206
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a:b:c:d'] = 1
    assert var_0 == {'a': {'b': {'c': {'d': 1}}}}
    assert get_tree_node(var_0, 'a:b:c:d') == 1



# Generated at 2022-06-26 02:53:21.710094
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
            'A': {
                'B': 'C',
                'D': {
                    'E': 'F',
                    'G': {
                        'H': 'I',
                        'J': 'K',
                    },
                    'L': 'M',
                },
                'N': 'O',
            },
            'P': 'Q',
    }

    r_0 = d['A']
    # A
    r_1 = r_0['B']
    # B
    r_2 = r_0['D']
    # D
    r_3 = r_2['G']
    # G
    r_4 = r_3['H']
    # H
    r_5 = r_4
    # I
    assert get_tree_node(d, 'A:B') == r

# Generated at 2022-06-26 02:53:29.983614
# Unit test for function set_tree_node
def test_set_tree_node():
    var_1 = tree()
    var_2 = set_tree_node(var_1, 'a:b:c', 'value')
    assert var_2['a']['b']['c'] == 'value'
    assert var_1['a']['b']['c'] == 'value'

    var_3 = tree()
    var_4 = set_tree_node(var_3, '', 'value')
    assert var_4 == 'value'
    assert var_3 == 'value'


# Generated at 2022-06-26 02:53:32.731596
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    assert get_tree_node(var_0, 'one:two:three', parent=True) == {'two': {'three': {}}}


# Generated at 2022-06-26 02:53:42.882513
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    var_0['key'] = 1
    assert var_0['key'] == 1


# Generated at 2022-06-26 02:53:44.339282
# Unit test for function set_tree_node
def test_set_tree_node():
    test_case_0()



# Generated at 2022-06-26 02:53:47.786268
# Unit test for function get_tree_node
def test_get_tree_node():
    status, msg = doctest.testmod(verbose=True)

# Generated at 2022-06-26 02:54:00.354494
# Unit test for function get_tree_node
def test_get_tree_node():
    test_var = tree()

    test_var['my_var'] = 'my_value'
    assert get_tree_node(test_var, 'my_var') == 'my_value'

    test_var['foo']['bar'] = 'my_value'
    assert get_tree_node(test_var, 'foo:bar') == 'my_value'

    test_var['foo']['bar']['doe'] = 'my_value'
    assert get_tree_node(test_var, 'foo:bar:doe') == 'my_value'

    get_tree_node(test_var, 'foo:bar:doe:rofl', default='notfound') == 'notfound'



# Generated at 2022-06-26 02:54:08.576765
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['a:b:c'] = 'd'
    var_1 = get_tree_node(var_0, 'a:b:c')
    assert var_1 == 'd'
    var_2 = get_tree_node(var_0, 'a:b:c:d:e')
    assert var_2 == 'd'


# Generated at 2022-06-26 02:54:14.525813
# Unit test for function get_tree_node
def test_get_tree_node():
    var_1 = tree()
    var_1['1']['2']['3'] = 4
    var_2 = get_tree_node(var_1, '1', default=_sentinel)
    assert var_2 == {'2': {'3': 4}}, 'Expected {\'2\': {\'3\': 4}}, got {}'.format(repr(var_2))
    var_3 = get_tree_node(var_1, '1:2:3', default=_sentinel)
    assert var_3 == 4, 'Expected 4, got {}'.format(repr(var_3))
    var_4 = get_tree_node(var_1, '1:2', default=_sentinel)

# Generated at 2022-06-26 02:54:16.129863
# Unit test for function set_tree_node
def test_set_tree_node():
    pass



# Generated at 2022-06-26 02:54:16.865966
# Unit test for function get_tree_node
def test_get_tree_node():
    assert False



# Generated at 2022-06-26 02:54:21.986541
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO
    assert ( [1, 1] == get_tree_node([1, 1, 1], "0") )
    assert ( [1, 1] == get_tree_node([1, 1, 1], "1") )
    assert ( [1, 1] == get_tree_node([1, 1, 1], "2") )


# Generated at 2022-06-26 02:54:25.735168
# Unit test for function set_tree_node
def test_set_tree_node():
    name = "name"
    value = tree()
    var_0 = set_tree_node(value, "name", name)
    return var_0


# Generated at 2022-06-26 02:54:51.323740
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {
        'a': {
            'b': 1
        },
        'b': {
            'a': 2
        }
    }
    assert get_tree_node(t, 'a:b') == 1
    assert get_tree_node(t, 'b:a') == 2
    with pytest.raises(KeyError):
        get_tree_node(t, 'a:c')

# Generated at 2022-06-26 02:54:56.640918
# Unit test for function set_tree_node
def test_set_tree_node():
    var = tree()

    set_tree_node(var, 'foo:bar:baz', 'qux')

    assert(get_tree_node(var, 'foo:bar:baz') == 'qux')



# Generated at 2022-06-26 02:54:58.654066
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(tree(), 'foo') == {}



# Generated at 2022-06-26 02:55:04.095181
# Unit test for function get_tree_node
def test_get_tree_node():
    print("## Testing get_tree_node ")

    var_1 = tree()
    var_0 = get_tree_node(var_1, 'var_2:var_6', default=_sentinel)
    assert var_0 == var_1['var_2']['var_6']

    var_1 = tree()
    var_0 = get_tree_node(var_1, 'var_2:var_6', default=_sentinel)
    assert var_0 == var_1['var_2']['var_6']

    var_1 = tree()
    var_0 = get_tree_node(var_1, 'var_2:var_6', default='var_7')
    assert var_0 == var_1['var_2']['var_6']


# Generated at 2022-06-26 02:55:14.006824
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = collections.defaultdict(collections.defaultdict)
    test_tree['foo']['bar'] = 'baz'

    try:
        node = get_tree_node(test_tree, 'foo:bar')
    except Exception as exc:
        raise AssertionError('Raised exception %s on a valid key' % type(exc))
    else:
        if node != 'baz':
            raise AssertionError('Did not return correct value. Got: %s' % node)

    try:
        node = get_tree_node(test_tree, 'foo:baz')
    except KeyError:
        pass
    else:
        raise AssertionError('Failed to raise KeyError on an invalid key')


# Generated at 2022-06-26 02:55:15.389240
# Unit test for function get_tree_node
def test_get_tree_node():
    # TODO
    pass



# Generated at 2022-06-26 02:55:21.756411
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    mapping = {"a": {"b": "c"}}
    key = "a:b"

    # Invoke method
    result = get_tree_node(mapping, key)

    # Check result
    assert result == "c"
    assert key == "a:b"
    assert mapping == {"a": {"b": "c"}}



# Generated at 2022-06-26 02:55:24.465647
# Unit test for function get_tree_node
def test_get_tree_node():
    input_var_0 = tree()
    var_0 = get_tree_node(input_var_0, 'Jack:Tom', default=_sentinel, parent=False)
    # Assertion:
    assert var_0 == 5, 'value is not correct'



# Generated at 2022-06-26 02:55:28.529540
# Unit test for function get_tree_node
def test_get_tree_node():
    assert not get_tree_node(None, '', default=None, parent=False)
    assert not get_tree_node(None, '', default=None, parent=False)
    assert not get_tree_node(None, '', default=None, parent=False)
    assert not get_tree_node(None, '', default=None, parent=False)


# Generated at 2022-06-26 02:55:29.823793
# Unit test for function get_tree_node
def test_get_tree_node():
    test_case_0()


# Generated at 2022-06-26 02:56:22.341552
# Unit test for function get_tree_node
def test_get_tree_node():
    import json

    # Testing `mapping` argument
    try:
        get_tree_node()
    except Exception as e:
        assert(str(e) == "get_tree_node() missing 1 required positional argument: 'mapping'")
    else:
        raise AssertionError('Expected Exception not thrown')
    try:
        get_tree_node(tree())
    except Exception as e:
        assert(str(e) == "get_tree_node() missing 1 required positional argument: 'key'")
    else:
        raise AssertionError('Expected Exception not thrown')

    # Testing `key` argument

# Generated at 2022-06-26 02:56:27.358838
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['foo']['bar']['baz'] = 'bar'
    assert get_tree_node(var_0, 'foo:bar:baz') == 'bar'



# Generated at 2022-06-26 02:56:29.884990
# Unit test for function set_tree_node
def test_set_tree_node():
    pass
    # var_0 = set_tree_node(tree(), 'a:b:c', 2)
    # assert var_0



# Generated at 2022-06-26 02:56:40.672094
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'nested': {
            'map': {
                'with': {
                    'adjacent': {
                        'stuff': {
                            'inside': 'yep',
                        },
                    },
                },
            },
        },
    }
    assert get_tree_node(tree, 'nested:map:with:adjacent:stuff:inside') == 'yep'
    assert get_tree_node(tree, 'nested:map:with:adjacent:stuff:inside:does:not:exist', default=False) is False



# Generated at 2022-06-26 02:56:45.046439
# Unit test for function set_tree_node
def test_set_tree_node():
    var_0 = tree()
    set_tree_node(var_0, 'test', 'hello')
    assert var_0['test'] == 'hello'



# Generated at 2022-06-26 02:56:53.242806
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'x', 'y')
    assert tree == {'x':'y'}

    set_tree_node(tree, 'x:y', 'z')
    assert tree['x']['y'] == 'z'

    set_tree_node(tree, 'x:x', 't')
    assert tree['x']['x'] == 't'

    set_tree_node(tree, 'x:x:x', 'r')
    assert tree['x']['x']['x'] == 'r'



# Generated at 2022-06-26 02:56:57.720925
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test for function get_tree_node.
    """
    assert get_tree_node({'a': {'b': 1}}, 'a:b') == 1
    try:
        assert get_tree_node({'a': {'b': 1}}, 'a:c')
    except KeyError:
        pass
    else:
        assert False



# Generated at 2022-06-26 02:57:06.591537
# Unit test for function get_tree_node
def test_get_tree_node():
    TREE = {'a': {
        'b': {
            'c': 1,
            'd': 2
        }
    }
    }
    assert get_tree_node(TREE, 'a:b:c') == 1

    # TODO Not sure why this fails.
    # assert get_tree_node(TREE, 'a:b:c:d:e', default=3)
    assert get_tree_node(TREE, 'a:b:d:e:f:g:h:i', default=3) == 3
    try:
        get_tree_node(TREE, 'a:b:d:e:f:g:h:i')
    except KeyError:
        pass
    else:
        raise AssertionError()



# Generated at 2022-06-26 02:57:10.697353
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = RegistryTree()
    var_0.register('a:thing', 'woo')
    assert var_0['a:thing'] == 'woo'


# Generated at 2022-06-26 02:57:20.498650
# Unit test for function set_tree_node
def test_set_tree_node():
    import json
    raw = json.loads('''
    {
        "domain.com": {
            "type": "mysql",
            "host": "server_name",
            "user": "db_user",
            "pass": "db_pass",
            "database": "db_name"
        },
        "local_domain.com": {
            "type": "mysql",
            "host": "server_name",
            "user": "db_user",
            "pass": "db_pass",
            "database": "db_name"
        }
    }''')

    set_tree_node(raw, 'local_domain.com:foo:bar:baz', 12345)
    print(raw)



# Generated at 2022-06-26 02:59:04.347750
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'nest1:nest2:asdf', 'value')
    assert t.get('nest1').get('nest2').get('asdf') == 'value'
    assert t.get('nest1').get('nest2').asdf == 'value'



# Generated at 2022-06-26 02:59:16.180387
# Unit test for function get_tree_node
def test_get_tree_node():
    var_0 = tree()
    var_0['foo'] = 'bar'
    var_0['spam']['eggs'] = 'ham'
    var_0['foo:bar:baz'] = 'ham'
    var_0['foo:bar:spam']['eggs'] = 'pancakes'

    assert var_0['foo'] == 'bar'
    assert var_0['spam']['eggs'] == 'ham'
    assert var_0['foo:bar:baz'] == 'ham'
    assert var_0['foo:bar:spam']['eggs'] == 'pancakes'
    assert var_0['foo']['bar']['spam']['eggs'] == 'pancakes'