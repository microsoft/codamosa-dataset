

# Generated at 2022-06-24 03:14:14.877268
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    my_tree = Tree()
    my_tree['test1'] = 'value1'
    my_tree['test2'] = 'value2'
    expected = {'test1': 'value1', 'test2': 'value2'}
    assert my_tree == expected

# Generated at 2022-06-24 03:14:18.078395
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    assert tree.get('a', default=1) == 1
    tree['a'] = 2
    tree['a:a'] = 3
    assert tree == {'a': {'a': 3}}



# Generated at 2022-06-24 03:14:21.003179
# Unit test for constructor of class Tree
def test_Tree():
    test_tree = {
        'key': {
            'subkey': 'subvalue',
        },
    }
    test_class = Tree(initial=test_tree, initial_is_ref=True)
    assert test_class['key:subkey'] == test_tree['key']['subkey']



# Generated at 2022-06-24 03:14:32.204831
# Unit test for constructor of class Tree
def test_Tree():
    import json

    # Constructor is callable
    t = Tree()

    # Update is callable
    t.update({'one': 'two'})

    # __setitem__ is callable
    t['tree'] = 'is cool'

    # __getitem__ is callable
    assert 'is cool' == t['tree']

    # Default is callable
    assert 'is cool' == t.get('tree')

    # __getitem__ supports a default
    # assert 'is cool' == t.get('tree', 'is cool')
    assert 'is meh' == t.get('moo', 'is meh')

    # JSON serialization works
    assert json.dumps(t._get_data) == json.dumps({'tree': 'is cool'})

    # Get returns parent node
    assert t.get

# Generated at 2022-06-24 03:14:40.632055
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Test w/ namespace
    t = Tree(namespace='test')
    t['test:test'] = 'test'
    t.__setitem__('test', 'test')
    assert t['test'] == 'test', "Namespaced Tree __setitem__() is broken"

    # Test w/o namespace
    t = Tree()
    t.__setitem__('test2', 'test2')
    assert t['test2'] == 'test2', "Un-namespaced Tree __setitem__() is broken"



# Generated at 2022-06-24 03:14:46.298315
# Unit test for function set_tree_node
def test_set_tree_node():
    node = tree()
    assert isinstance(node, collections.defaultdict)

    set_tree_node(node, 'foo:bar:baz', 'bop')
    assert node['foo']['bar']['baz'] == 'bop'



# Generated at 2022-06-24 03:14:54.975920
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pprint

    initial_tree = {'a': {'x': {'foo': 'bar'}}}

    t1 = Tree(initial_tree)
    pprint(t1.data)

# Generated at 2022-06-24 03:15:01.119587
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Unit test for method __getitem__ of class Tree"""
    t = Tree()
    t['foo'] = 'FOO'
    t['bar'] = 'BAR'
    t['baz:qux:bar'] = 'BAZ'
    t['baz:qux:spam'] = 'QUX'

    assert t['foo'] == 'FOO'
    assert t['bar'] == 'BAR'
    assert t['baz:qux:bar'] == 'BAZ'
    assert t['baz:qux:spam'] == 'QUX'
    assert t['quux'] == {}

    print('test_Tree___getitem__ passed')



# Generated at 2022-06-24 03:15:08.678993
# Unit test for function set_tree_node
def test_set_tree_node():
    d = collections.defaultdict(dict)
    set_tree_node(d, 'a:b:c', 'blah')
    assert d['a']['b']['c'] == 'blah'
    set_tree_node(d, 'n', 'non-nested')
    assert d['n'] == 'non-nested'
    assert d['a']['b']['c'] == 'blah'



# Generated at 2022-06-24 03:15:10.216820
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register('test', 'nice')
    assert r.get('test') == 'nice'

# Generated at 2022-06-24 03:15:12.258949
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rg = RegistryTree(namespace='rg')
    rg.register('foo', 'bar')
    assert rg == {'rg': {'foo': 'bar'}}



# Generated at 2022-06-24 03:15:19.335257
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    res = set_tree_node(mapping, 'key', 'value')
    assert res == mapping
    assert mapping == {'key': 'value'}

    mapping = tree()
    res = set_tree_node(mapping, 'key', 'value')
    assert res == mapping
    assert all(mapping.values()) == {'key': 'value'}

    mapping = tree()
    res = set_tree_node(mapping, 'key:key_two:key_three:key_four', 'value')
    assert res == mapping
    assert mapping == {'key': {'key_two': {'key_three': {'key_four': 'value'}}}}



# Generated at 2022-06-24 03:15:22.810137
# Unit test for constructor of class Tree
def test_Tree():
    a = {'a': {'b': {'c': 'C!'}}}
    b = Tree(initial=a)
    assert b == a
    b = Tree(initial_is_ref=a)
    assert b == a



# Generated at 2022-06-24 03:15:27.411167
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    assert tree == {}
    tree = Tree({'a': 1, 'b': 2})
    assert tree == {'a': 1, 'b': 2}
    tree = Tree({'a': 1, 'b': 2}, initial_is_ref=True)
    assert tree == {'a': 1, 'b': 2}



# Generated at 2022-06-24 03:15:36.445133
# Unit test for function tree
def test_tree():
    t = tree()
    for key, value in {
        'pets:dogs:fido:wags_tail': True,
        'pets:dogs:marvin:wags_tail': True,
        'pets:cats:marsha:meows': True,
        'pets:cats:frazzle:purrs': True
    }:

        set_tree_node(t, key, value)
    assert t['pets']['cats']['frazzle']['purrs'] is True
    assert t.get('pets', {}).get('cats', {}).get('frazzle', {}).get('purrs') is True
    assert t.get('pets', {}).get('cats', {}).get('frazzle', {}).get('purrs') is True
    assert get_tree_node

# Generated at 2022-06-24 03:15:39.246618
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import IPython
    rt = RegistryTree()
    rt.register('a:1:2:3:4', 'lala')
    IPython.embed()

# Generated at 2022-06-24 03:15:44.924483
# Unit test for function set_tree_node
def test_set_tree_node():
    registry = tree()
    set_tree_node(registry, 'main:section:subsection:key1:key2', 'value')
    assert registry['main']['section']['subsection']['key1']['key2'] == 'value'
    set_tree_node(registry, 'main:section:subsection:key1:key2', 'value2')
    assert registry['main']['section']['subsection']['key1']['key2'] == 'value2'



# Generated at 2022-06-24 03:15:47.452332
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'tree': {}}
    set_tree_node(mapping, 'tree:asdf', 'fdsa')
    assert mapping['tree']['asdf'] == 'fdsa'



# Generated at 2022-06-24 03:15:56.378186
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': {
                    'd': 1,
                }
            }
        },
        'e': {
            'f': {
                'g': 5,
            }
        }
    }

    assert get_tree_node(mapping, 'a:b:c:d') == 1

    with pytest.raises(KeyError):
        get_tree_node(mapping, 'a:b:c:e')

    assert get_tree_node(mapping, 'a:b:c:e', default=0) == 0

# Generated at 2022-06-24 03:15:58.056481
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t[':asd'] = 123
    assert t[':asd'] == 123



# Generated at 2022-06-24 03:16:00.815808
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # TODO: Implement validation for Tree.__setitem__
    assert True # TODO: Implement test



# Generated at 2022-06-24 03:16:07.916392
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    t.__setitem__('a', 1)
    t['b'] = 2

    assert t['a'] == 1
    assert t['b'] == 2

    t['a']['b'] = 3
    t['a']['c'] = 4

    assert t['a']['c'] == 4

    assert t['a']['b'] == 3
    assert t['a:b'] == 3 and t['b'] == 2
    assert t['a:c'] == 4 and t['c'] == 4

# Generated at 2022-06-24 03:16:12.216163
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    registry = RegistryTree()

    registry['foo'] = 'bar'
    registry['foo:bar'] = 'baz'
    registry['foo:bar:baz'] = 'chaz'

    assert registry['foo'] == 'bar'
    assert registry['foo:bar'] == 'baz'
    assert registry['foo:bar:baz'] == 'chaz'

    

# Generated at 2022-06-24 03:16:18.230752
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a', 'A')
    assert tree['a'] == 'A'

    set_tree_node(tree, 'b:c', 'B:C')
    assert tree['b']['c'] == 'B:C'

    set_tree_node(tree, 'd:g:a', 'D:G:A')
    assert tree['d']['g']['a'] == 'D:G:A'

    tree['e:f:h:g:a'] = 'E:F:H:G:A'
    print(tree)

    set_tree_node(tree, 'e:f:h:g:a', 'E:F:H:G:A')
    print(tree)


# Generated at 2022-06-24 03:16:20.468283
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree(initial={'a': {'b': 'c'}})
    assert a.get('a:b') == 'c'

# Generated at 2022-06-24 03:16:28.388854
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from pprint import pprint
    from tree import RegistryTree, Tree

    a = RegistryTree()
    a.register('a', 'a')
    a.register('b', 'b')
    a.register('c', 'c')
    a.register('d', 'd')
    a.register('e', 'e')
    a.register('f', 'f')
    a.register('g', 'g')
    a.register('h', 'h')
    a.register('i', 'i')
    a.register('j', 'j')
    a.register('k', 'k')
    b = RegistryTree()
    b.register('a', 'a')
    b.register('b', 'b')
    b.register('c', 'c')
    b.register('d', 'd')

# Generated at 2022-06-24 03:16:32.751570
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree_ = Tree()
    tree_['foo'] = 'bar'
    assert tree_['foo'] == 'bar'
    assert len(tree_) == 1
    tree_['foo'] = 'baaz'
    assert tree_['foo'] == 'baaz'
    assert len(tree_) == 1



# Generated at 2022-06-24 03:16:42.980375
# Unit test for function get_tree_node
def test_get_tree_node():
    mock_tree = Tree({
        'one': {
            'three': 3,
            'four': {
                'five': 5,
            },
        },
        'two': 2,
    })
    assert get_tree_node(mock_tree, 'one:three') == 3
    assert get_tree_node(mock_tree, 'two') == 2
    assert get_tree_node(mock_tree, ':two') == 2
    assert get_tree_node(mock_tree, 'one:four:five:six') == {}
    assert get_tree_node(mock_tree, 'one:four:five:six:seven:eight:nine:ten') == {}

    # test default arg

# Generated at 2022-06-24 03:16:50.969943
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'one': 1,
        'two': {
            'three': 3,
            'four': {'five': 5}
        }
    }
    assert (get_tree_node(data, 'one', default='?') == 1)
    assert (get_tree_node(data, 'two:three', default='?') == 3)
    assert (get_tree_node(data, 'two:four', default='?') == {'five': 5})
    assert (get_tree_node(data, 'two:four:five', default='?') == 5)
    assert (get_tree_node(data, 'seven:eight:nine', default='?') == '?')
    assert (get_tree_node(data, 'seven:eight:nine') == _sentinel)



# Generated at 2022-06-24 03:16:52.796569
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(initial={
        'toy': {
            'racecar': 123
        },
    })
    assert tree['toy:racecar'] == 123



# Generated at 2022-06-24 03:17:02.686975
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c']['d']['e'] = 42
    assert t['a']['b']['c']['d']['e'] == 42

    # Specify level, to avoid looping through the whole tree.
    assert t['a:b:c:d:e'] == 42
    # Allowed to end with ':'
    assert t['a:b:c:d:e:'] == 42
    assert t[':a:b:c:d:e:'] == 42

    # Allowed to have any number of repetitions of ':'
    assert t['::a::b::c::d::e::'] == 42

    # Not existing key, raises KeyError

# Generated at 2022-06-24 03:17:07.583333
# Unit test for function set_tree_node
def test_set_tree_node():
    original_dict = tree()
    set_tree_node(original_dict, 'new_key', 'new_value')
    assert original_dict['new_key'] == 'new_value'

    # Now with dirs
    set_tree_node(original_dict, 'some:nested:dir:key', 'value')
    assert original_dict['some']['nested']['dir']['key'] == 'value'



# Generated at 2022-06-24 03:17:18.478782
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    class Foo(Tree):
        pass

    f = Foo(namespace='test')

    f['test:foo:bar:baz'] = 'test0'
    assert f['test:foo:bar:baz'] == 'test0'

    f['test:foo:bar:buz'] = 'test1'
    assert f['test:foo:bar:buz'] == 'test1'

    f['test:foo:bar2:baz'] = 'test2'
    assert f['test:foo:bar2:baz'] == 'test2'

    f['test:foo:bar2:buz'] = 'test3'
    assert f['test:foo:bar2:buz'] == 'test3'

    f['test:foo2:bar:baz'] = 'test4'

# Generated at 2022-06-24 03:17:20.623064
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-24 03:17:28.608734
# Unit test for function get_tree_node

# Generated at 2022-06-24 03:17:33.162671
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    def foo():
        pass

    def bar():
        pass

    x = RegistryTree()
    x.register('foo', foo)
    x.register('bar', bar)
    assert x() == {'foo': foo, 'bar': bar}

# Generated at 2022-06-24 03:17:38.043933
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    assert r == {}
    r.register('a:b', 1)
    r.register('a:c', 2)
    assert r['a'] == {'b': 1, 'c': 2}
    assert r['a:c'] == 2
    assert r.get('a:d', 4) == 4


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:17:40.699460
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    assert r == Tree()


__all__ = ['tree', 'Tree', 'RegistryTree', 'test_RegistryTree']

# Generated at 2022-06-24 03:17:44.920356
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from unittest import TestCase
    from unittest.mock import Mock

    class TestClass(TestCase):

        def test_namespace(self):
            tree = RegistryTree()
            tree.register(1, Mock())

            self.assertIsInstance(tree[1], Mock)

# Generated at 2022-06-24 03:17:49.287975
# Unit test for function set_tree_node
def test_set_tree_node():
    mydict = collections.defaultdict(dict)
    set_tree_node(mydict, 'a:b:c', 'abc')
    assert mydict == {'a': {'b': {'c': 'abc'}}}

# Generated at 2022-06-24 03:17:50.489395
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='foo')
    assert t.namespace == 'foo'

# Generated at 2022-06-24 03:17:58.945063
# Unit test for function get_tree_node
def test_get_tree_node():
    try:
        get_tree_node({}, 'a')
    except Exception as exc:
        assert isinstance(exc, KeyError)

    assert get_tree_node({'a': 'b'}, 'a') == 'b'
    assert get_tree_node({'a': 'b'}, 'a', default='c') == 'b'
    assert get_tree_node({'a': 'b'}, 'a', default='c', parent=True) == {'a': 'b'}
    assert get_tree_node({'a': {}}, 'a:b') == {}
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'

# Generated at 2022-06-24 03:18:07.219198
# Unit test for function get_tree_node
def test_get_tree_node():
    root = {
        'foo': {
            'bar': {
                'baz': 1
            },
            'bat': 2
        }
    }

    assert get_tree_node(root, 'foo:bar:') == {'baz': 1}
    assert get_tree_node(root, 'foo:bar:baz') == 1
    assert get_tree_node(root, 'foo:bat') == 2
    assert get_tree_node(root, 'spam') == _sentinel



# Generated at 2022-06-24 03:18:17.433774
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'foo': {'bar': {'baz': 'bip'}}}, 'domain')
    assert t['foo:bar:baz'] == 'bip'
    assert t['foo:bar:baz', 'domain'] == 'bip'
    assert t['foo:bar:baz', 'domain:subdomain'] == 'bip'
    assert t['foo:bar:baz', 'subdomain'] == 'bip'
    assert t['foo:bar:baz', 'subdomain:subdomain'] == 'bip'
    assert t.data['domain:foo:bar:baz'] == 'bip'
    assert t.data['subdomain:foo:bar:baz'] == 'bip'



# Generated at 2022-06-24 03:18:25.103669
# Unit test for function get_tree_node
def test_get_tree_node():
    tests = [
        ({
            'a': {
                'b': {
                    'c': 'd'
                }
            }
        }, 'a:b:c', 'd'),
        ({
            'a': {
                'b': {
                    'c': 'd'
                }
            }
        }, 'a:b', {'c': 'd'}),
        ({
            'a': {
                'b': {
                    'c': 'd'
                }
            }
        }, 'a:b:c:d:e:f:g:h', _sentinel),
        ({
            'a': {
                'b': {
                    'c': 'd'
                }
            }
        }, 'a:nonexistent', _sentinel),
    ]

# Generated at 2022-06-24 03:18:31.910225
# Unit test for constructor of class Tree
def test_Tree():
    foo = Tree()
    foo["x"]["y"]["z"] = 10

# Generated at 2022-06-24 03:18:32.649728
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    assert t['foo'] is None



# Generated at 2022-06-24 03:18:35.928048
# Unit test for function tree
def test_tree():
    t = tree()
    t[1][2][3] = 42
    assert t[1][2][3] == 42
    assert get_tree_node(t, '1:2:3') == 42
    set_tree_node(t, '1:2:4', 43)
    assert t[1][2][4] == 43



# Generated at 2022-06-24 03:18:39.820554
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    items = [(':'.join(map(str, node)), str(node)) for node in ((1,2,3), (0,1,2), (3,4,5))]
    rt = RegistryTree(items)
    assert rt.get('0:1:2') == '(0, 1, 2)'

# Generated at 2022-06-24 03:18:45.948356
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'foo': {
            'bar': {
                'something': {
                    'foo': 'bar',
                }
            },
        }
    }
    assert get_tree_node(data, 'foo:bar:something:foo') == 'bar'
    assert get_tree_node(data, 'foo:bar:something:foo:bar:foo') is _sentinel



# Generated at 2022-06-24 03:18:49.287468
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('hello.goodbye', 'howdy.adios')
    assert isinstance(tree, RegistryTree)
    assert 'howdy.adios' == tree.get('hello.goodbye')

# Generated at 2022-06-24 03:18:52.248832
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a:b:c:d'] = 'foo'
    assert tree['a:b']['c']['d'] == 'foo'



# Generated at 2022-06-24 03:19:01.437471
# Unit test for constructor of class Tree
def test_Tree():
    # def tree():
    #     """Extremely simple one-lined tree based on defaultdict."""
    #     return collections.defaultdict(Tree)

    tree = Tree()
    tree['a']['b']['c']['d']['e'] = 'a:b:c:d:e'
    tree['a']['b']['c']['f'] = 'a:b:c:f'
    tree['a']['b']['c']['g'] = 'a:b:c:g'
    tree['a']['b']['h'] = 'a:b:h'
    tree['a']['i']['j'] = 'a:i:j'

# Generated at 2022-06-24 03:19:06.713984
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree()
    assert a == {}
    b = Tree(initial={'hello': 'world'})
    assert b == {'hello': 'world'}


# Unit Test for get_tree_node

# Generated at 2022-06-24 03:19:12.222240
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree()
    a['a'] = 'foo'
    b = Tree(a)
    b['b'] = 'bar'
    assert b['b'] == 'bar'
    assert 'a' not in b
    c = Tree(b)
    c['a'] = 'baz'
    assert c['a'] == 'baz'
    assert c['b'] == 'bar'

# Generated at 2022-06-24 03:19:16.289747
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.__setitem__("foo:bar", "baz")
    assert t("foo:bar") == "baz"


# pylint: disable=unused-import,redefined-outer-name,unused-variable

# Generated at 2022-06-24 03:19:24.870038
# Unit test for function get_tree_node
def test_get_tree_node():
    test_data = {
        'root': {
            'berries': 'delicious',
            'apples': 'green',
            'sub': {
                'level2': 'hooray',
                'subsub': {
                    'subsubsub': 'whoot'
                }
            }
        }
    }

    assert get_tree_node(test_data, 'root') == test_data['root']
    assert get_tree_node(test_data, 'root:sub') == test_data['root']['sub']
    assert get_tree_node(test_data, 'root:sub:level2') == 'hooray'
    assert get_tree_node(test_data, 'root:sub:subsub') == test_data['root']['sub']['subsub']
    assert get_tree

# Generated at 2022-06-24 03:19:26.729562
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['a'] = 'b'
    assert tree['a'] == 'b'

# Generated at 2022-06-24 03:19:29.920560
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert t._namespace == ''
    t['x'] = 1
    assert t == {'x': 1}
    t = Tree(namespace='ns')
    assert t._namespace == 'ns'
    t['x'] = 1
    assert t == {'ns': {'x': 1}}
    t = Tree(initial={'x': 1}, initial_is_ref=True)
    assert t == {'x': 1}
    assert t.data == {'x': 1}
    assert t['x'] == 1



# Generated at 2022-06-24 03:19:41.632108
# Unit test for function tree
def test_tree():
    import json

    data = {
        'list': [1, 2, 3],
        'dict': {
            'key': 'value'
        },
        'bool': True,
        'int': 123,
        'str': 'abc',
        'default': ['a', 'b'],
    }

    def _compare_tree(a, b):
        if isinstance(b, dict):
            assert isinstance(a, dict)
            assert sorted(a.keys()) == sorted(b.keys())
            for k, v in b.items():
                _compare_tree(a[k], v)
        elif isinstance(b, list):
            assert isinstance(a, list)
            assert len(a) == len(b)
            for i in range(len(b)):
                _compare_

# Generated at 2022-06-24 03:19:44.563036
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(initial={'foo': 'bar'})
    assert tree['foo'] == 'bar'
    tree = Tree(initial_is_ref=tree)
    assert tree['foo'] == 'bar'

# Generated at 2022-06-24 03:19:50.904412
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['a:b:c'] = 'Humuhumunukunukuapua\'a'
    tree['a:d'] = 'Kauila'
    assert tree['a:b:c'] == 'Humuhumunukunukuapua\'a'
    assert tree.get('a:e') is None
    assert tree.get('a:e', 'None') == 'None'



# Generated at 2022-06-24 03:19:56.454470
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    initial = {}
    test_object = Tree(initial, namespace='', initial_is_ref=False)
    # __setitem__: No exception raised
    key = 'test'
    value = 'test'
    test_object.__setitem__(key, value, namespace=None)



# Generated at 2022-06-24 03:20:05.801843
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['foo']['bar']['baz'] = 1
    assert get_tree_node(mapping, 'foo:bar:baz') == 1
    assert get_tree_node(mapping, 'foo:bar:baz', 2) == 1
    assert get_tree_node(mapping, 'foo:bar', 2) == {'baz': 1}
    assert get_tree_node(mapping, 'foo:bar2', 2) is 2
    assert get_tree_node(mapping, 'foo:bar:baz', parent=True) == {'baz': 1}
    assert get_tree_node(mapping, 'fool:baz', parent=True) == mapping



# Generated at 2022-06-24 03:20:11.369646
# Unit test for function get_tree_node
def test_get_tree_node():
    # Given the tree below
    m = Tree({ 'a': { 'b': { 'c': { 'd': '01' } } } })
    # When I lookup various paths
    assert m.get('a:b:c:d') == '01'
    assert m.get('a:b:c:e', '02') == '02'
    assert m.get('a:b:c:e') == _sentinel
    assert m.get('a:b:c:e', default='02') == '02'



# Generated at 2022-06-24 03:20:12.513223
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    assert isinstance(r, collections.defaultdict)



# Generated at 2022-06-24 03:20:18.187572
# Unit test for function tree
def test_tree():
    """Test tree function."""
    t = tree()
    t['a']['b']['c']['d'] = 'Value'

    assert t['a:b:c:d'] == 'Value', "Getter"
    t['a:b:c:d'] = 'Another Value'
    assert t['a']['b']['c']['d'] == 'Another Value', "Setter"



# Generated at 2022-06-24 03:20:23.730627
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    Construct a RegistryTree and make sure you can use the methods provided
    """
    registry = RegistryTree()
    registry.register("test_key", "test_value")
    assert registry.get("test_key") == "test_value"
    assert registry["test_key"] == "test_value"


if __name__ == '__main__':
    # Run all unit tests
    test_RegistryTree()

# Generated at 2022-06-24 03:20:33.928000
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree()
    t = reg.register

    t('foo:bar:baz', dict(one=1, two=2, three=3))
    t('foo:bar:baz2', dict(four=4, five=5, six=6))
    t('foo:boo', dict(seven=7, eight=8, nine=9))
    t('foo:boo2', dict(ten=10, eleven=11, twelve=12))


# Generated at 2022-06-24 03:20:38.075306
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(tree(), 'foo:bar', 'baz') == {'foo': {'bar': 'baz'}}
    assert set_tree_node(tree(), 'foo:bar:boo', 'baz') == {'foo': {'bar': {'boo': 'baz'}}}

# Generated at 2022-06-24 03:20:48.789926
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():

    # Instantiate class_instance
    class_instance = Tree()
    key = ()
    default = 'abcd'

    # Assert set of keys returned is equal to that in returns
    assert class_instance.__getitem__(key, default) == default
    assert class_instance.get(key, default) == default

    class_instance = Tree()
    key = ['abcd', 'efgh']
    default = None
    expected__returned = {}

    # Assert set of items returned is equal to that in returns
    assert class_instance.__getitem__(key, default) == expected__returned
    assert class_instance.get(key, default) == expected__returned

    class_instance = Tree()
    key = [1, 1]
    default = None
    expected__returned = {}

    # Assert set

# Generated at 2022-06-24 03:20:56.570223
# Unit test for function tree
def test_tree():
    my_tree = tree()
    my_tree[1][2][3] = 'value'
    my_tree[1][2][4] = 'value'
    my_tree[1][5][6] = 'value'
    my_tree[7][8][9] = 'value'
    assert my_tree[1][2][4] == 'value'
    assert my_tree[7][8][9] == 'value'
    # print my_tree
    assert 3 not in my_tree
    assert 1 in my_tree



# Generated at 2022-06-24 03:21:00.635614
# Unit test for constructor of class Tree
def test_Tree():
    T = Tree({'foo': 'bar'})
    assert T['foo'] == 'bar'
    assert T['foo:baz'] == {}
    T['foo:bar'] = 'baz'
    assert T['foo'] == 'bar'
    assert T['foo:bar'] == 'baz'

# Generated at 2022-06-24 03:21:04.915038
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree()
    assert Tree([])
    assert Tree([], 'prefix', True)
    tree = Tree()
    assert tree == Tree()



# Generated at 2022-06-24 03:21:16.560269
# Unit test for function tree
def test_tree():
    """Test tree."""
    t = tree()
    t['a']['b']['c'] = 10
    t['a']['b']['d'] = 11
    assert t['a']['b']['c'] == 10
    assert t['a']['b']['d'] == 11
    # Test namespace
    t2 = tree(namespace='w')
    t2['x']['y']['z'] = 10
    assert t2['x']['y']['z'] == 10
    assert t2['w:x']['y']['z'] == 10
    assert t2['w:x:y:z'] == 10
    # Test initial value
    t3 = tree(initial={'a': {'b': {'c': 10}}})
    assert t

# Generated at 2022-06-24 03:21:20.925815
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(initial={
        'foo': {
            'bar': 'baz',
        },
    })
    assert tree['foo:bar'] == 'baz'


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:21:28.374141
# Unit test for function tree
def test_tree():
    from pyperf import bisect
    root = tree()
    root['a'] = 1
    root['b'] = 2

    subtree = root['c']
    subtree['d'] = 3

    assert 'a' in root
    assert 'd' in subtree

    assert 'c' in root
    assert 'c' in root
    assert 'd' in root['c']



# Generated at 2022-06-24 03:21:34.417391
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree().__class__ is Tree

    assert Tree({}).__class__ is Tree
    assert Tree({'foo': 'boo'}).__class__ is Tree
    assert Tree({'foo': 'boo'}, initial_is_ref=True).__class__ is Tree
    assert Tree({'foo:boo': 'my'}).__class__ is Tree
    assert Tree({'foo:boo': 'my'}, initial_is_ref=True).__class__ is Tree



# Generated at 2022-06-24 03:21:38.462505
# Unit test for function tree
def test_tree():
    t = tree()
    t[1][2][3] = "hi!"
    t[1][2][3] = "hello!"
    t[1][2][3] = "goodbye!"
    assert t[1][2][3] == "goodbye!"



# Generated at 2022-06-24 03:21:47.860499
# Unit test for function tree
def test_tree():
    test_data = {
        'foo': 'bar',
        'biz': {
            'boo': 'poo',
            'fiz': {
                'baz': 'buz'
            }
        }
    }
    t = tree()

# Generated at 2022-06-24 03:21:50.245841
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Unit test for method __getitem__ of class Tree
    """
    test_tree = Tree()

    test_tree['foo'] = 'bar'

    assert test_tree['foo'] == 'bar'



# Generated at 2022-06-24 03:21:53.432464
# Unit test for constructor of class Tree
def test_Tree():
    with pytest.raises(TypeError):
        tr = Tree()

    data = tree()
    tr = Tree(initial=data, initial_is_ref=True)
    assert tr.data is data
    assert tr['data'] is data



# Generated at 2022-06-24 03:22:01.204020
# Unit test for function set_tree_node
def test_set_tree_node():
    test = collections.defaultdict(dict)
    set_tree_node(test, 'foo:bar:baz', 'blah')
    assert test['foo']['bar']['baz'] == 'blah'
    test = collections.defaultdict(dict)
    set_tree_node(test, 'foo:bar', 'blah')
    assert test['foo']['bar'] == 'blah'



# Generated at 2022-06-24 03:22:06.982404
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data = {}
    set_tree_node(test_data, 'foo:bar:baz', 'value')
    assert test_data == {'foo': {'bar': {'baz': 'value'}}}
    set_tree_node(test_data, 'foo:bar:bob', 'value')
    assert test_data == {'foo': {'bar': {'baz': 'value', 'bob': 'value'}}}



# Generated at 2022-06-24 03:22:15.799097
# Unit test for function get_tree_node
def test_get_tree_node():
    # test basic functionality
    assert get_tree_node({'this': {'is': {'deep': 'nested'}}}, 'this:is:deep') == 'nested'
    # test default
    assert get_tree_node({'this': {'is': {'deep': 'nested'}}}, 'this:not:here', default='default') == 'default'
    # test parent
    assert get_tree_node({'this': {'is': {'deep': 'nested'}}}, 'this:is', parent=True) == {'is': {'deep': 'nested'}}
    # test error handling

# Generated at 2022-06-24 03:22:21.921642
# Unit test for constructor of class Tree
def test_Tree():
    # Use : to delve down into dimensions without choosing doors [][][]
    config = {
        'foo': 'bar',
        'bazzy': {
            'razzy': 'drazzy',
            'mazzy': {
                'frazzy': 'prazzy',
            }
        },
    }
    tree = Tree(config)
    assert tree['foo'] == config['foo']
    assert tree['bazzy:razzy'] == config['bazzy']['razzy']
    assert tree['bazzy:mazzy:frazzy'] == config['bazzy']['mazzy']['frazzy']
    assert tree['bazzy:mazzy:frazzy:bazzy'] is not config['bazzy']['mazzy']['frazzy']['bazzy']


# Generated at 2022-06-24 03:22:31.735333
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    new_test = Tree(initial_is_ref=True)
    # And the list:
    new_test[u'bar'] = 100
    new_test[u'bar2'] = 100
    # Now, to put something in bar3:
    new_test[u'bar3'] = {u'bar3.1': {u'bar3.1.1': 10, u'bar3.1.2': 20}}
    # And now, to put something in bar3.1.1:
    new_test[u'bar3:bar3.1:bar3.1.1'] = 10
    assert new_test[u'bar3:bar3.1:bar3.1.1'] == 10



# Generated at 2022-06-24 03:22:38.349203
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import pytest
    with pytest.raises(TypeError) as excinfo:
        assert RegistryTree()
    assert_that(str(excinfo.value), equal_to("object argument must be a mapping or iterable"))


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-24 03:22:40.667921
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from pprint import pprint
    from register import RegistryTree
    reg = RegistryTree()
    reg.register('foo', 'bar')


# Generated at 2022-06-24 03:22:43.885831
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t["a:b:c"] = "d"
    print(t)
    print(t["a:b:c"])

if __name__ == "__main__":
    test_Tree___setitem__()

# Generated at 2022-06-24 03:22:45.998155
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tmp = Tree()
    tmp.set('a:b', 500)
    tmp.set('c:d', 500)

# Generated at 2022-06-24 03:22:55.569240
# Unit test for function get_tree_node
def test_get_tree_node():
    data = [
        {
            'name': 'foo',
            'data': {
                'boom': 'bam'
            }
        },
        {
            'name': 'bar',
            'data': {
                'boom': 'baz'
            }
        }
    ]

    assert get_tree_node(data, '0') == data[0]
    assert get_tree_node(data, '1') == data[1]
    assert get_tree_node(data, '0:data') == data[0]['data']
    assert get_tree_node(data, '0:data:boom') == data[0]['data']['boom']
    assert get_tree_node(data, '1:data:boom') == data[1]['data']['boom']

# Generated at 2022-06-24 03:23:03.631696
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_object = Tree()
    test_object['a:b:1'] = 1
    test_object['a:b:2'] = 2
    test_object['c:d:1'] = 3
    test_object['c:d:2'] = 4

    assert test_object['a:b:1'] == 1
    assert test_object['a:b:2'] == 2
    assert test_object['c:d:1'] == 3
    assert test_object['c:d:2'] == 4

    test_object = Tree()
    test_object['a:b:1'] = 1
    test_object['a:b:2'] = 2
    test_object['c:d:1'] = 3
    test_object['c:d:2'] = 4


# Generated at 2022-06-24 03:23:08.476667
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('key:b:c:d:e', 'value', namespace='a')


if __name__ == '__main__':
    import DJV
    DJV.run_tests()

# Generated at 2022-06-24 03:23:12.921294
# Unit test for function tree
def test_tree():
    tree = tree()
    tree['hello']['world']['thisworks'] = 'yes'
    # Result:
    # {'hello': {'world': {'thisworks': 'yes'}}}
    assert tree == {'hello': {'world': {'thisworks': 'yes'}}}


# Generated at 2022-06-24 03:23:17.461136
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Unit test for method `__setitem__` of class `Tree`."""
    test_item = Tree({
        'foo': 'bar',
    })

    test_item['foo'] = 'baz'
    assert test_item['foo'] == 'baz'

    test_item['faz:boo'] = 'far'
    assert test_item['faz']['boo'] == 'far'



# Generated at 2022-06-24 03:23:23.790773
# Unit test for function set_tree_node
def test_set_tree_node():

    a = {}

    path_a = 'test:some:data'
    path_a_data = 'parent node'

    path_b = 'test:other:data'
    path_b_data = 'sibling node'

    a = set_tree_node(a, path_a, path_a_data)
    a = set_tree_node(a, path_b, path_b_data)

    assert a['test']['some']['data'] == path_a_data
    assert a['test']['other']['data'] == path_b_data



# Generated at 2022-06-24 03:23:29.561936
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Tree.__getitem__: 1
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'

    # Tree.__getitem__: 2
    t = Tree()
    t['foo:bar'] = 10
    t['foo:baz'] = 15
    assert t['foo'] == {'baz': 15, 'bar': 10}



# Generated at 2022-06-24 03:23:32.354383
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = {}
    set_tree_node(test_tree, 'test.test1.test2', "this was a triumph")
    assert test_tre

# Generated at 2022-06-24 03:23:40.909948
# Unit test for function tree
def test_tree():
    t = tree()
    t['hello']['world']['foo']['bar'] = 'baz'
    t['hello']['world']['this']['thing'] = 'yep'
    t['hello']['world']['this']['another'] = 'yep'
    assert t['hello']['world']['this']['another'] == 'yep'
    assert t['hello']['world']['this']['thing'] == 'yep'
    assert t['hello']['world']['foo']['bar'] == 'baz'


if __name__ == '__main__':
    test_tree()



# Generated at 2022-06-24 03:23:48.621307
# Unit test for function tree
def test_tree():
    import unittest

    class TestTree(unittest.TestCase):
        def test_basic_tree(self):
            t = tree()
            t['a']['b']['c']['d'] = 'dentist'
            self.assertEqual(t['a'], {'b': {'c': {'d': 'dentist'}}})
            self.assertEqual(t['a']['b'], {'c': {'d': 'dentist'}})
            self.assertEqual(t['a']['b']['c'], {'d': 'dentist'})
            self.assertEqual(t['a']['b']['c']['d'], 'dentist')

# Generated at 2022-06-24 03:23:50.607159
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'



# Generated at 2022-06-24 03:23:57.000057
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equals, assert_raises

    data = {
        'app': {
            'subapp': {
                'subsubapp': {
                    'deepnode': 'super deep node!'
                }
            }
        }
    }

    assert_equals('super deep node!', get_tree_node(data, 'app:subapp:subsubapp:deepnode'))
    assert_raises(KeyError, get_tree_node, data, 'app:subapp:subsubapp:deepnode:nope')



# Generated at 2022-06-24 03:24:00.725657
# Unit test for function tree
def test_tree():
    """Test the tree."""
    from pprint import pprint

    t = tree()
    t['foo']['bar']
    t['foo']['baz']

    t['corge']['grault']['garply']

    pprint(t)

# Generated at 2022-06-24 03:24:02.916194
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    obj = Tree()
    obj[':a:b'] = 'c'
    assert obj == {'a': {'b': 'c'}}



# Generated at 2022-06-24 03:24:08.279680
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    assert set_tree_node({}, 'foo', 'bar') == {'foo': 'bar'}
    assert set_tree_node({}, 'foo:bar', 'baz') == {'foo': {'bar': 'baz'}}
    assert set_tree_node({}, ':foo:bar:baz', 'snafu') == {'foo': {'bar': {'baz': 'snafu'}}}



# Generated at 2022-06-24 03:24:11.944085
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] is 'bar'

    t['foo:bar'] = 'bar'
    assert t['foo:bar'] is 'bar'

